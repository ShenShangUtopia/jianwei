"""课件库：每份课件一个目录（原文件、PDF、缩略图、笔迹、黑板）。"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
import uuid
import re
from pathlib import Path

from ..kit.home import home
from .convert import SUPPORTED, ConvertError, kind_of, to_pdf


def root() -> Path:
    p = home() / "lectures"
    p.mkdir(parents=True, exist_ok=True)
    return p


def folder(lid: str) -> Path:
    if not isinstance(lid,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}",lid):
        raise ValueError("课件编号无效")
    return root() / lid


def _write(path: Path, data) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


save_json = _write


def all_lectures() -> list:
    out = []
    for d in root().iterdir():
        m = read_json(d / "meta.json") if d.is_dir() else None
        if isinstance(m, dict) and (d / "doc.pdf").is_file():
            out.append(m)
    return sorted(out, key=lambda m: -float(m.get("opened") or m.get("added") or 0))


def update(lid: str, **kw) -> None:
    p = folder(lid) / "meta.json"
    m = read_json(p, {})
    m.update(kw)
    _write(p, m)


def remove(lid: str) -> None:
    d = folder(lid)
    if d.parent == root() and d.is_dir():
        shutil.rmtree(d, ignore_errors=True)


def _digest(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def import_file(src, status=None, use_com=True) -> dict:
    """导入一个文件，返回 meta。同一个文件再导入一次直接返回原来那份（笔迹和黑板都还在）。"""
    from PySide6.QtPdf import QPdfDocument

    from .pageview import render_page
    src = Path(src)
    if src.suffix.lower() not in SUPPORTED:
        raise ConvertError(f"不支持 {src.suffix or '这种'} 文件。可以导入 PPT、Word 和 PDF。")
    if not src.is_file():
        raise ConvertError("找不到这个文件")
    say = status or (lambda _s: None)
    say("正在检查文件，识别是否重复导入…")
    digest = _digest(src)
    for m in all_lectures():
        if m.get("sha1") == digest:
            say("这份课件已经导入过")
            m["existing"] = True
            return m
    lid = uuid.uuid4().hex[:12]
    d = folder(lid)
    d.mkdir(parents=True)
    try:
        stored = d / ("source" + src.suffix.lower())
        say("正在保存原文件…")
        shutil.copyfile(src, stored)
        engine = to_pdf(stored, d / "doc.pdf", say, use_com=use_com)
        say("正在检查转换结果并生成预览…")
        doc = QPdfDocument()
        doc.load(str(d / "doc.pdf"))
        pages = doc.pageCount()
        if pages <= 0:
            raise ConvertError("转换结果没有内容，这个文件可能已损坏")
        tl = read_json(d / "anim.json")
        first_shot = tl["slides"][0]["last"] if tl else 0   # 缩略图用第一张放完动画的样子
        steps = pages - len(tl["slides"]) if tl else 0
        if tl:
            pages = len(tl["slides"])
        pt = doc.pagePointSize(0)
        kind = kind_of(src)
        if kind == "pdf":
            kind = "slides" if pt.width() > pt.height() else "doc"
        thumb_w = 480
        render_page(doc, first_shot, thumb_w, max(1, int(thumb_w * pt.height() / max(1, pt.width())))).save(str(d / "thumb.png"))
        doc.close()
        meta = dict(id=lid, title=src.stem, kind=kind, pages=pages, engine=engine, src_name=src.name, sha1=digest, added=time.time(), opened=0, page=0, steps=steps)
        _write(d / "meta.json", meta)
        if engine.endswith("原样出图"):
            start_text_layer(d, stored)
        return meta
    except BaseException:
        shutil.rmtree(d, ignore_errors=True)
        raise


_TEXT_RUNNING: set = set()


def start_text_layer(d: Path, stored: Path) -> None:
    """放映用的是图，框选取字要另一份带文字的 PDF：在后台慢慢做，做好之前框选会改用本机识别。"""
    import threading
    from . import convert
    key = str(d)
    if key in _TEXT_RUNNING:
        return
    _TEXT_RUNNING.add(key)
    work = d / "work.pptx" if (d / "work.pptx").is_file() else stored

    def run():
        try:
            convert.text_layer(work, d / "text.pdf")
        except Exception:  # noqa: BLE001  只是取字用，失败就算了
            pass
        finally:
            if work.name == "work.pptx":
                work.unlink(missing_ok=True)
            _TEXT_RUNNING.discard(key)
    threading.Thread(target=run, daemon=True, name="lecture-text").start()


def resume_text_layer(d: Path, meta: dict) -> bool:
    """原样出图的课件还没有文字层（导入后很快关了程序，或上次没做成）：打开时再在后台做一次。"""
    if not str(meta.get("engine", "")).endswith("原样出图") or (d / "text.pdf").is_file():
        return False
    if os.environ.get("JIANWEI_SELFTEST") == "1":
        return False
    src = next((p for p in d.glob("source.*") if p.is_file()), None)
    if src is None:
        return False
    start_text_layer(d, src)
    return True


def from_clip(clip,store,title="素材课件"):
    """新建独立课件；底图与笔迹分离，原始素材和源课件均不改动。"""
    from PySide6.QtCore import QMarginsF, QSizeF
    from PySide6.QtGui import QPainter, QPdfWriter, QPageLayout, QPageSize
    lid = uuid.uuid4().hex[:12]
    d = folder(lid)
    d.mkdir(parents=True)
    w,h = clip["space"]["width"],clip["space"]["height"]
    writer = QPdfWriter(str(d/"doc.pdf"))
    writer.setResolution(72)
    writer.setPageLayout(QPageLayout(QPageSize(QSizeF(w,h),QPageSize.Unit.Point,"clip"),QPageLayout.Orientation.Portrait,QMarginsF()))
    painter = QPainter(writer)
    from PySide6.QtCore import QRectF, QSize
    painter.drawImage(QRectF(0,0,w,h),store.render(clip,QSize(max(1,int(w)),max(1,int(h))),include_ink=False))
    painter.end()
    del painter,writer
    store.render(clip,QSize(480,max(1,int(480*h/w)))).save(str(d/"thumb.png"))
    meta = dict(id=lid,title=title,kind="slides",pages=1,engine="素材",src_name=title,
                added=time.time(),opened=0,page=0,steps=0,clip_id=clip["id"])
    _write(d/"meta.json",meta)
    return meta
