# 见微 0.3.14 · 交接（2026-11-21）

`store.VERSION` = **0.3.14**。没打包（`tools/release.py` 的 `OUT` / `TAG` 还是 0.3.10）。
- 用户说明：`RELEASE-0.3.14.md`。
- 上一版：`HANDOFF-0.3.13.md`。
- 测试报告（四个 Sonnet 子代理测 0.3.13，只测不改）：`测试/0.3.13/`，含习题台、物理与几何、化学与生物、外壳与页面。截图在 `测试/0.3.13/shots/`；`shots/chem/stale-*` 大多是子代理脚本 bug 留下的无效图，可删。

## 1. 习题台（`native/bank/`）
- `data.py`：`compare_answer` 重写，新增 `choice_key`、`choice_mine`、`grade_choice`、`_nums`、`_norm`、`_strip_note`、`_shape`。
  - 步骤：先做 NFKC，统一减号，把 ×10^n 改成 e 记法，去掉带中文的全角括号说明，再分两路。
    - 选择题：比开头的字母集合。
    - 数值题：数（含 √、π、a/b、%）按多重集匹配，`≈` 后面算近似值。
  - 再查区间开闭、不等号序列；ln、sin、√、π 缺了不算对。
  - 测试用了报告里的 53 个案例；题库里每题自己的答案对自己全对；39 道字母答案换成别的字母全错。
- `desk.py` 判分与学习记录：
  - `check_answer` 的学习记录：选择题用 `grade_choice`；单选、填空里答案是数值的，用对照结果。没有 id 的临时题不记。
  - `check_out` 另起一行、可折行。setText 被包了一层：空串时隐藏。
- `desk.py` 做题时盖住画面：
  - `_draw_cover` 是叠加层。视图有 `reveals`（`sb_text.py` 的 flow、data 两种模式会设），且没切到本题补图（`figure_bridge` 的 `_fig_on`）时，做题状态整块盖住。
  - 做题时把「控件」页内容藏起来。
  - 物理题做题时 `view.state.playing=False, t=0`；看讲解时恢复播放。做题时按空格走 `_learn`。
- `desk.py` 窄窗口：`resizeEvent` 在宽度小于 1150 时收紧：
  - 左栏 250、右栏 300；
  - 提示键变成 1 / 2 / 3，「显示答案」变成「答案」，「错题本」变成「错题N」。
  - 学习窗口最小 1000 宽时，习题台约 932 宽，`minimumSizeHint` 918。
- `desk.py` 其它：
  - `gate_note` 拆成两个定宽标签，原来的会行叠行。
  - `open_practice` 在没有模型时先问，析题里已有内容也先问。
- `selftest.py` 新加 5 项：讲解步骤卡盖住、物理做题不播、物理讲解接着播、对照另起一行、判分 9 例。

## 2. 外壳
- `learning_ui.Review`：
  - 按键和两个 QTextBrowser 都设成 NoFocus、关掉 autoDefault。
  - `keyPressEvent`：空格、回车在没翻面时翻面；翻面后不替用户选；做完后回车关窗；没翻面按 1、2 时提示。
  - `preview_selftest` 加了 3 项（QTest 按键）。
- `shell._topband`：band 的 resizeEvent 在放不下时依次收起 `rail_count`、`clock_label`，只恢复自己收起的。
- `modules.py`：七个主操作键改成 `"primary"`。
- `ui_kit.py`：六套 FAINT 加深或提亮，外加默认的 `C.FAINT`。
- `bank/fx.spaced_options`：用于今日一题预览（`pages.py`、`modules.py`）。
- `reading/page.py`：
  - 没密钥不再写进 `engine_note`，`update_status(hint)` 用灰色显示。
  - 服务商名从 `llm.settings()["name"]` 取，界面文字的 DeepSeek 改成 AI。
- `lecture/panel.py` 识图的两处文字同样改了。

## 3. 实验台
- **`kit/bench_transfer.sync_geometry`**：以前每次画布绘制后都无条件 `notes.update()`，透明批注层和画布互相触发，静止时每秒约 120 个 Paint 事件。0.3.11 的静止不重画因此实际没生效。现在只在对齐变化时 update。
  - `physics_perf_selftest` 新加一项：数画布真正的 Paint 事件。
- `kit/ctx.reg`：登记控件的 `set` / `press` 包一层，调完 `poke()` 加 `draw()`。题目导入、互通、AI 控制改控件后立刻重画。
- `chem.py`：
  - `draw_live` 包住 `draw`，在真正绘制时记 `LV["last"]`。以前在 tick 里同步读，因为 update 是异步的，永远是 False，导致时钟动画冻结。
  - `fingerprint` 加了 lit、name、gas_to、搅拌中、gas_seal，`sel` 改用 id。
  - 无色溶液加底色和液面线。
  - `oxygen_demo` 默认 `gas_seal=True`。
  - `B.chem_live` 新增 `new_lamp`、`toggle_lamp`、`lamps`。
- `kit/bench.Toasts.show`：相同 html 只刷新计时（用 `gen` 属性防止旧计时器误删）。
- `bio.py`：
  - `fit_scale` 最小到 0.6。
  - `add()` 找不到空位就 toast 并拒绝；以前会斜叠，`cascade` 已不再用于新卡。
- 几何画板：
  - `geo_draw.draw_features`：先挑屏幕内的点，按离中心距离取 12 个，屏幕上 10 px 内的点去重。
  - `geo_calc.analyze`：
    - 变号处先二分（碰到极点返回该点），收敛点 |f| 小才算零点，否则记为间断。
    - `_robust_span` 用 5%–95% 分位。
    - `_jump` / `_locate_jump`：中点越界算偶次极点；差值远大于导数乘 dx 算跳跃。
    - 零点串合并；单调性用两端函数值判断。
    - 二阶导用 90% 分位，并加噪声门限。
    - 定义域边界记成 `edges`，不算间断。新增 `domain` 和 `domain_text`。
  - `geo.py` 性质面板加了「定义域」一行。
  - `kit/expr._pow`：分母为奇数的分数次幂，x < 0 时取实根。

## 4. 测试
- 单项都过了：bank、preview（53 项）、reading（37 项）、physics-perf（22 项）。
- 全量 `main.py --self-test --no-single`：结果见 §6。

## 5. 没做 / 下一步
- 化学：
  - 器材多了挤到浮窗下、标签互相压（`chem.py` 的 `near_free` 第二轮不限安全区，报告 2.2）；
  - 示例提示在面板和 toast 各出现一次（2.3 的后半）。
- 生物：拖动后缩放窗口，手动排布会被重排掉（3.3）。
- 几何：
  - `log10(x)` 被解析成 y=x（报告 G7）；
  - 可去间断 (x²−1)/(x−1) 没报；
  - 面板「可视范围」没扣掉两侧面板（G9）。
- 外壳：
  - 复习、预习窗口的强调色跟着学科走（报告 #6）；
  - 课件框选在行距紧时会把多行连成一行（#7）；
  - 查询面板头部挤（#9）。
- 习题台：只记第一次对照（同一个 event_id）；提示阶梯、错题本闭环见 `调研/习题台与析题.md`。
- `调研/总览.md`：
  - 第 5 条化学还剩器材避让；
  - 第 7 条外壳的主键和时钟这次已顺手做了；
  - 第 8 条数学的 1/x 性质、定义域已做；
  - 第 6、9、10 条没动。

## 6. 全量自测
`main.py --self-test --no-single`（离屏、隔离数据，2026-11-21）：**全部 OK**，失败列表为空。

第一次跑时 math-fn 有两项按旧行为写的检查失败，都是期望值过时，已改：
- tan 在 kπ 确实是拐点，以前算不出来；
- 1/x 取样恰好落在 0 时，0 记为定义域边界。

math-fn 另外新加 6 项：1/x、ln x 的定义域，1/x² 的间断和单调性，一次函数没有拐点，floor 的跳跃。冻结版没打。
