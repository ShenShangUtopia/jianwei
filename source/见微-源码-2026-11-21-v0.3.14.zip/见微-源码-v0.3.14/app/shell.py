"""见微 · 主壳：无边框纸面窗 + 左侧导航 + 托盘。"""
from __future__ import annotations

import os
import sys
import threading
from datetime import datetime

from PySide6.QtCore import (QEasingCurve, QPoint, QPointF, QPropertyAnimation, QRectF, Qt, QTimer,
                            QVariantAnimation, Signal)
from PySide6.QtGui import QAction, QColor, QIcon, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QHBoxLayout, QLabel, QMenu, QPushButton, QStackedWidget, QSystemTrayIcon,
    QVBoxLayout, QWidget,
)

import pages
import store
import guanlan_host
from countdown import CountdownPill

from native.design.icons import draw_icon  # noqa: F401
from native.design.tokens import T
from native.design import ux
from native.design.widgets import IconButton, RailButton, paint_seal
from ui_kit import C, f


def _theme() -> str:
    import ui_kit
    return ui_kit.theme()

NAV = [
    ("today", "今日"),
    ("lecture", "课件"),
    ("reading", "读文"),
    ("studio", "习题台"),
    ("lab", "实验室"),
    ("guanlan", "观澜"),
    ("countdown", "倒计时"),
    ("settings", "设置"),
]
# 窄栏分组：这个键前面写一行小标题。设置单独放在最下面
NAV_GROUP = {"lecture": "学习", "guanlan": "桌面"}


def _ridge(rng, x0: float, x1: float, base: float, amp: float, rise: str = "left", n: int = 72) -> QPainterPath:
    """一道山脊线：几个正弦叠出来的起伏，一头从雾里慢慢升起。返回从山脊到 base 的封闭形。"""
    import math
    phases = [rng.uniform(0, math.tau) for _ in range(4)]
    path = QPainterPath(QPointF(x0, base))
    for i in range(n + 1):
        t = i / n
        wave = sum(a * math.sin(f * t * math.tau + ph) for a, f, ph in zip((1.0, 0.5, 0.26, 0.12), (1.0, 2.3, 4.6, 8.3), phases)) / 1.88
        k = t if rise == "left" else 1 - t if rise == "right" else 1.0
        env = min(1.0, k / 0.45) ** 1.6 if rise in ("left", "right") else 1.0
        path.lineTo(x0 + (x1 - x0) * t, base - amp * (0.58 + 0.42 * wave) * env)
    path.lineTo(x1, base)
    path.closeSubpath()
    return path


# 主窗口的三种布局：导航放哪、占多宽
LAYOUTS = (("side", "左边宽栏 · 带分组和倒计时"),
           ("top", "顶上横排 · 内容用满整个宽度"),
           ("compact", "左边窄栏 · 只留一列图标"))
RAIL_W = {"side": 196, "compact": 72, "top": 0}
TOP_H = 58


class NavButton(QPushButton):
    """主窗口的导航键。mode：side 左图标右文字 / compact 上图标下小字 / top 横排（选中时下面一道朱砂）。"""

    def __init__(self, icon: str, text: str, mode: str = "side"):
        super().__init__()
        self.icon, self.label, self.mode, self._hover = icon, text, mode, False
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFlat(True)
        self.setAccessibleName(text)
        self.setStyleSheet("background:transparent;border:none;")
        if mode == "top":
            from PySide6.QtGui import QFontMetrics
            self.setFixedSize(QFontMetrics(f(13, 700)).horizontalAdvance(text) + 52, 38)
        elif mode == "compact":
            self.setFixedHeight(56)
            self.setToolTip(text)
        else:
            self.setFixedHeight(40)

    def enterEvent(self, e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        on = self.isChecked()
        w, h = self.width(), self.height()
        if on or self._hover or self.isDown():
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(T.rail2))
            p.drawRoundedRect(QRectF(0, 0, w, h), 9, 9)
        col = QColor(T.railon if on or self._hover else T.railfg)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(T.brand))
        if self.mode == "top":
            if on:
                p.drawRoundedRect(QRectF(w / 2 - 10, h - 4, 20, 3), 1.5, 1.5)
            draw_icon(p, self.icon, QRectF(14, (h - 18) / 2, 18, 18), col, 1.6)
            p.setPen(col)
            p.setFont(f(13, 700 if on else 500))
            p.drawText(QRectF(38, 0, w - 44, h - 1), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.label)
        elif self.mode == "compact":
            if on:
                p.drawRoundedRect(QRectF(0, h * .26, 3, h * .48), 1.5, 1.5)
            draw_icon(p, self.icon, QRectF((w - 20) / 2, 9, 20, 20), col, 1.6)
            p.setPen(col)
            p.setFont(f(11, 700 if on else 500))
            p.drawText(QRectF(0, 32, w, h - 34), int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop), self.label)
        else:
            if on:
                p.drawRoundedRect(QRectF(0, h * .24, 3, h * .52), 1.5, 1.5)
            draw_icon(p, self.icon, QRectF(14, (h - 18) / 2, 18, 18), col, 1.6)
            p.setPen(col)
            p.setFont(f(13, 700 if on else 500))
            p.drawText(QRectF(44, 0, w - 50, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.label)
        p.end()


class ShellIcon(QPushButton):
    """标题栏上的小图标键（昼夜、最小化、关闭）。dark=True 时画在深色的顶栏上。"""

    def __init__(self, icon: str, tip: str = "", dark: bool = False, size: int = 30):
        super().__init__()
        self.icon, self.dark, self._hover = icon, dark, False
        self.setFixedSize(size, size)
        self.setToolTip(tip)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFlat(True)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self, e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        danger = self.icon == "close" and self._hover
        if self._hover or self.isDown():
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(T.brand) if danger else QColor(T.rail2) if self.dark else C.KEYHOVER)
            p.drawRoundedRect(QRectF(self.rect()).adjusted(1, 1, -1, -1), 7, 7)
        if danger:
            col = QColor("#FFFFFF")
        elif self.dark:
            col = QColor(T.railon if self._hover else T.railfg)
        else:
            col = QColor(C.INK if self._hover else C.SOFT)
        m = int(self.width() * 0.23)
        draw_icon(p, self.icon, self.rect().adjusted(m, m, -m, -m), col)
        p.end()


class CrumbButton(QPushButton):
    """模块桌面 / 工作台的顶栏上：看完整页面时显示「‹ 桌面 / 课件」，点一下回去。在桌面上时不显示。"""

    def __init__(self, home: str):
        super().__init__()
        self.home, self.page, self._hover = home, "", False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFlat(True)
        self.setStyleSheet("background:transparent;border:none;")
        self.setToolTip(f"回到{home}（Esc）")
        self.setFixedHeight(36)
        self.hide()

    def set_page(self, page: str) -> None:
        self.page = page
        from PySide6.QtGui import QFontMetrics
        w = QFontMetrics(f(13, 500)).horizontalAdvance(self.home) + QFontMetrics(f(13, 700)).horizontalAdvance(page)
        self.setFixedWidth(w + 62)
        self.setVisible(bool(page))
        self.update()

    def enterEvent(self, e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        from PySide6.QtGui import QFontMetrics
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self._hover or self.isDown():
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(T.rail2))
            p.drawRoundedRect(QRectF(self.rect()), 9, 9)
        h = self.height()
        draw_icon(p, "chevron_l", QRectF(8, (h - 16) / 2, 16, 16), QColor(T.railon if self._hover else T.railfg), 1.8)
        p.setFont(f(13, 500))
        p.setPen(QColor(T.railon if self._hover else T.railfg))
        hw = QFontMetrics(p.font()).horizontalAdvance(self.home)
        p.drawText(QRectF(28, 0, hw + 2, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.home)
        p.setPen(QColor(T.railfg))
        p.drawText(QRectF(28 + hw + 6, 0, 12, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "/")
        p.setFont(f(13, 700))
        p.setPen(QColor(T.railon))
        p.drawText(QRectF(28 + hw + 20, 0, self.width(), h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.page)
        p.end()


class RailCountdown(QWidget):
    """导航旁边的倒计时（每分钟刷新）。side：天数 + 学期刻度；compact：只有天数；top：横着一行。"""

    def __init__(self, cfg: dict, mode: str = "side"):
        super().__init__()
        self.cfg, self.mode = cfg, mode
        if mode == "top":
            self.setFixedSize(132, 38)
        else:
            self.setFixedHeight(92 if mode == "side" else 52)
        self._t = QTimer(self)
        self._t.timeout.connect(self.update)
        self._t.start(60_000)
        self.setToolTip("高考倒计时 · 在「倒计时」页可调")

    def paintEvent(self, _ev) -> None:
        from ui_kit import serif
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        now = datetime.now()
        target, start = store.target_dt(self.cfg), store.start_dt(self.cfg)
        secs = max(0.0, (target - now).total_seconds())
        frac = min(1.0, max(0.0, 1 - secs / max(1.0, (target - start).total_seconds())))
        if self.mode != "side":
            num = str(int(secs // 86400))
            name = str(self.cfg.get("label", "高考"))
            if self.mode == "compact":
                p.setFont(serif(21, 600))
                p.setPen(QColor(T.railon))
                p.drawText(QRectF(0, 2, self.width(), 26), int(Qt.AlignmentFlag.AlignCenter), num)
                p.setFont(f(10.5, 500))
                p.setPen(QColor(T.railfg))
                p.drawText(QRectF(0, 30, self.width(), 16), int(Qt.AlignmentFlag.AlignCenter), f"天 · {name}")
            else:
                big = serif(22, 600)
                p.setFont(big)
                nw = p.fontMetrics().horizontalAdvance(num)
                small = f(11, 500)
                from PySide6.QtGui import QFontMetrics
                lead, tail = f"距{name}", "天"
                lw, tw = QFontMetrics(small).horizontalAdvance(lead), QFontMetrics(small).horizontalAdvance(tail)
                x = self.width() - (lw + 7 + nw + 5 + tw) - 4
                base = self.height() / 2 + 8
                p.setFont(small)
                p.setPen(QColor(T.railfg))
                p.drawText(QPointF(x, base - 1), lead)
                p.drawText(QPointF(x + lw + 7 + nw + 5, base - 1), tail)
                p.setFont(big)
                p.setPen(QColor(T.railon))
                p.drawText(QPointF(x + lw + 7, base), num)
            p.end()
            return
        x, w = 14, self.width() - 28
        p.setPen(QColor(T.railfg))
        p.setFont(f(10.5, 500, 1.0))
        p.drawText(QRectF(x, 0, w, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   f"距 {self.cfg.get('year', '2027')} {self.cfg.get('label', '高考')}")
        num = str(int(secs // 86400))
        p.setFont(serif(32, 600))
        p.setPen(QColor(T.railon))
        fm = p.fontMetrics()
        p.drawText(QPointF(x, 54), num)
        p.setFont(f(12, 500))
        p.setPen(QColor(T.railfg))
        p.drawText(QPointF(x + fm.horizontalAdvance(num) + 6, 54), "天")
        # 刻度尺：走过的部分亮，当前位置一道朱砂
        n, y = 34, 68
        for i in range(n):
            cx = x + i * w / (n - 1)
            passed = i / (n - 1) <= frac
            p.setPen(QPen(QColor(T.railon if passed else T.rail2), 1))
            p.drawLine(QPointF(cx, y), QPointF(cx, y + (10 if i % 5 == 0 else 6)))
        p.setPen(QPen(QColor(T.brand), 2))
        cx = x + frac * w
        p.drawLine(QPointF(cx, y - 3), QPointF(cx, y + 13))
        p.end()


class _Seal(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(36, 36)

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        paint_seal(p, QRectF(self.rect()))
        p.end()


class _EdgeGrip(QWidget):
    """窗口边缘的一条隐形把手：按下交给系统改大小（无边框窗口自己不会有这个）。"""

    def __init__(self, parent, edges, cursor):
        super().__init__(parent)
        self.edges = edges
        self.setCursor(cursor)

    def mousePressEvent(self, ev) -> None:
        handle = self.window().windowHandle()
        if ev.button() == Qt.MouseButton.LeftButton and handle is not None:
            handle.startSystemResize(self.edges)


class _PageFade(QWidget):
    """切页时的一层过渡：把旧页面的截图盖在新页面上，淡出并略微上移。

    只是每帧贴一张图（不用 QGraphicsOpacityEffect —— 那会让整页每帧离屏重画），不拦鼠标。
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._pm: QPixmap | None = None
        self._k = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(150)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.setStartValue(1.0)
        self._anim.setEndValue(0.0)
        self._anim.valueChanged.connect(self._step)
        self._anim.finished.connect(self._done)
        self.hide()

    def play(self, pm: QPixmap) -> None:
        self._anim.stop()
        self._pm, self._k = pm, 1.0
        self.setGeometry(self.parentWidget().rect())
        self.show()
        self.raise_()
        self._anim.start()

    def _step(self, v) -> None:
        self._k = float(v)
        self.update()

    def _done(self) -> None:
        self._pm = None
        self.hide()

    def paintEvent(self, _ev) -> None:
        if self._pm is None:
            return
        p = QPainter(self)
        p.setOpacity(self._k)
        p.fillRect(self.rect(), C.PAPER)    # 先垫一层纸底：旧页完整盖住新页再淡出，两页的字不会叠在一起
        p.drawPixmap(0, int(-(1 - self._k) * 8), self._pm)
        p.end()


class Shell(QWidget):
    toast_sig = Signal(str)
    guanlan_done = Signal()     # 后台线程抓完今日版，回到界面线程换内容

    def __init__(self, tray_enabled: bool = True, start_page: str = "today",
                 jobs_enabled: bool = True):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("见微 · 高考学习舱")
        self.setMinimumSize(980, 640)
        self.resize(1180, 780)
        ux.install()

        self.cfg = store.load_config()
        geo = self.cfg.get("shellGeom")
        if isinstance(geo, list) and len(geo) == 4:
            self.setGeometry(self._on_screen(*[int(v) for v in geo]))
        self.pill: CountdownPill | None = None
        self.guanlan = guanlan_host.GuanlanHost()
        self.guanlan.on_material=self.collect_material
        import ui_kit as _kit
        # 0.3.4 的「舒展 / 分栏 / 紧凑」改成了页面布局 + 疏密两项：旧配置换算一次
        pl = self.cfg.get("pageLayout")
        if pl == "dense":
            self.cfg["density"] = "dense"
        if pl in ("stack", "split", "dense", None):
            self.cfg["pageLayout"] = "pages"
        _kit.set_page_layout(self.cfg.get("pageLayout"))
        _kit.set_dense(self.cfg.get("density") == "dense")
        self.tab = "today"
        self.guanlan.set_theme(_theme(), _kit.skin())
        self._native = None  # 学习窗口（习题台 · 实验台 · 工作台 · 析题），第一次打开时才建
        self._drag: QPoint | None = None
        self._tray: QSystemTrayIcon | None = None
        self._page_index = {k: i for i, (k, _) in enumerate(NAV)}
        self._builders = {"today": pages.build_overview, "lecture": pages.build_lecture, "guanlan": pages.build_guanlan,
                          "countdown": pages.build_countdown, "studio": pages.build_studio, "lab": pages.build_lab,
                          "settings": pages.build_settings, "reading": pages.build_reading}
        self._built: set[str] = set()       # 已经建好、且没过期的页面
        self._day = datetime.now().date()   # 过了零点，带日期的页面要重建
        self._save_timer = QTimer(self)     # 拖滑块时每一格都会来存配置：攒到停手再写盘
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(350)
        self._save_timer.timeout.connect(self.save)

        self._build()
        E, C_ = Qt.Edge, Qt.CursorShape
        self._grips = [(_EdgeGrip(self, E.RightEdge, C_.SizeHorCursor), "r"), (_EdgeGrip(self, E.BottomEdge, C_.SizeVerCursor), "b"),
                       (_EdgeGrip(self, E.RightEdge | E.BottomEdge, C_.SizeFDiagCursor), "c"),
                       (_EdgeGrip(self, E.LeftEdge, C_.SizeHorCursor), "l"), (_EdgeGrip(self, E.TopEdge, C_.SizeVerCursor), "t")]
        self._toast_timer = QTimer(self)
        self._toast_timer.setSingleShot(True)
        self._toast_timer.timeout.connect(lambda: self._toast.hide())   # 换布局后提示条是新的那个
        if tray_enabled:
            self._build_tray()
        self.toast_sig.connect(self._show_toast)
        self.guanlan_done.connect(self._guanlan_updated)
        from PySide6.QtGui import QKeySequence, QShortcut
        self._esc_key = QShortcut(QKeySequence("Esc"), self, activated=self._esc)
        self._import_watch = QTimer(self)      # 课件导入完了：刷新模块桌面 / 工作台上的课件列表
        self._import_watch.setInterval(400)
        self._import_watch.timeout.connect(self._watch_import)

        self._clock = QTimer(self)
        self._clock.timeout.connect(self._refresh_clock)
        self._clock.timeout.connect(self._auto_look)
        self._clock.start(30000)
        self._sync_pill_reserve()    # 旧配置里残留的让位值清一次就够了（以前每 4 秒查一遍）

        self.goto(start_page)
        if self.cfg.get("showPill"):
            QTimer.singleShot(600, lambda: self.show_pill(True, quiet=True))
        if self.cfg.get("showGuanlanOnStart", True):
            QTimer.singleShot(900, self._open_guanlan_once)
        if jobs_enabled:
            self._setup_daily_jobs()
            # 等启动时的观澜浮窗、胶囊都起来、机器空下来再热（开机自启时也不和登录抢资源）
            QTimer.singleShot(12_000, self.prewarm_web)
        self._setup_panel_hotkey()

    # ------------------------------------------------------------ 常驻节律
    def _setup_daily_jobs(self) -> None:
        import scheduler
        self.jobs = scheduler.DailyJobs(self.guanlan, self.cfg, self.save, self)
        self.jobs.toast.connect(self.toast_sig.emit)
        self.jobs.fetch_done.connect(self._guanlan_updated)

    def _setup_panel_hotkey(self) -> None:
        """把观澜原有的 Alt+Shift+G 收进见微；原版在跑时注册会失败，不报错。"""
        self._hotkey = None
        try:
            self.guanlan._ensure_path()
            from ui.window import HotkeyFilter  # type: ignore
            filt = HotkeyFilter(self.toggle_guanlan)
            if filt.install():
                self._hotkey = filt
        except Exception:
            self._hotkey = None

    def _open_guanlan_once(self) -> None:
        if not self.guanlan.is_visible() and self.guanlan.show():
            self.cfg["showGuanlan"] = True
            self._sync_pill_reserve()

    def _sync_pill_reserve(self) -> None:
        """胶囊固定屏幕居中；这个钩子保留，用于把旧配置里残留的让位值清掉。"""
        reserve = 0
        if self.cfg.get("pillReserveRight") != reserve:
            self.cfg["pillReserveRight"] = reserve
            if self.pill is not None and self.pill.isVisible():
                self.pill.apply_config(self.cfg)

    # ------------------------------------------------------------ 结构
    def _build(self) -> None:
        """搭窗口里的全部东西。都挂在 _root 下面：换布局时把 _root 整个拆掉重搭。"""
        mode = self.cfg.get("layout")
        self._layout_mode = mode if mode in RAIL_W else "side"
        import ui_kit
        self._page_mode = ui_kit.PAGE_LAYOUT
        self._home_mode = self._page_mode in ("desktop", "workspace")
        self.crumb = None
        self.settings_btn = None
        self.home = None
        outer = self.layout()
        if outer is None:
            outer = QHBoxLayout(self)
            outer.setContentsMargins(0, 0, 0, 0)
            outer.setSpacing(0)
        self._root = QWidget()
        outer.addWidget(self._root)
        self._rail_sub, self._rail_labels = None, []

        self.surface = QWidget()
        self.surface.setObjectName("surface")
        self.surface.setStyleSheet("#surface{background:transparent;}")
        lay = QVBoxLayout(self.surface)
        lay.setContentsMargins(0, 0, 8, 8)
        lay.setSpacing(0)
        if self._home_mode or self._layout_mode == "top":
            frame = QVBoxLayout(self._root)
            frame.setContentsMargins(0, 0, 0, 0)
            frame.setSpacing(0)
            frame.addWidget(self._homeband() if self._home_mode else self._topband())
            frame.addWidget(self.surface, 1)
        else:
            frame = QHBoxLayout(self._root)
            frame.setContentsMargins(0, 0, 0, 0)
            frame.setSpacing(0)
            frame.addWidget(self._rail(self._layout_mode))
            frame.addWidget(self.surface, 1)
            lay.addWidget(self._titlebar())
        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)
        self._build_pages()

        self._fade = _PageFade(self.stack)

        self._toast = QLabel(self.surface)
        self._toast.setFont(f(11.5))
        self._toast.setStyleSheet(f"background:{T.fg};color:{T.stage};border-radius:6px;padding:8px 16px;")
        self._toast.hide()
        self._toast_anim = QPropertyAnimation(self._toast, b"pos", self)
        self._toast_anim.setDuration(180)
        self._toast_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def _titlebar(self) -> QWidget:
        bar = QWidget()
        bar.setFixedHeight(44)
        bar.mousePressEvent = self._bar_press
        bar.mouseMoveEvent = self._bar_move
        bar.mouseReleaseEvent = self._bar_release
        bar.mouseDoubleClickEvent = self._bar_double
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(30, 0, 4, 0)
        lay.setSpacing(4)
        self.clock_label = QLabel()
        self.clock_label.setFont(f(11, 500, 0.6))
        self.clock_label.setStyleSheet(self._clock_qss())
        lay.addWidget(self.clock_label, 0, Qt.AlignmentFlag.AlignVCenter)
        lay.addStretch(1)
        self._window_keys(lay, dark=False)
        self._refresh_clock()
        return bar

    def _clock_qss(self) -> str:
        # 顶栏布局、模块桌面、工作台里，时钟写在深色的栏上
        on_dark = getattr(self, "_layout_mode", "side") == "top" or getattr(self, "_home_mode", False)
        return f"color:{T.railfg if on_dark else C.FAINTH};background:transparent;"

    def _window_keys(self, lay, dark: bool) -> None:
        self.theme_btn = ShellIcon("moon" if _theme() == "day" else "sun", "切换白天 / 夜晚配色", dark)
        self.theme_btn.clicked.connect(self.toggle_theme)
        lay.addWidget(self.theme_btn)
        lay.addSpacing(4)
        for icon, slot, tip in (("min", self.showMinimized, "最小化"),
                                ("close", self._close_clicked, "关闭")):
            b = ShellIcon(icon, tip, dark)
            b.clicked.connect(slot)
            lay.addWidget(b)

    def _nav_button(self, key: str, text: str, mode: str) -> NavButton:
        b = NavButton(key, text, mode)
        b.setAutoExclusive(True)
        b.setProperty("navKey", key)
        b.clicked.connect(lambda _=False, k=key: self.goto(k))
        self.nav_buttons.append(b)
        return b

    def _drag_handle(self, w: QWidget, double: bool = False) -> None:
        w.mousePressEvent = self._bar_press
        w.mouseMoveEvent = self._bar_move
        w.mouseReleaseEvent = self._bar_release
        if double:
            w.mouseDoubleClickEvent = self._bar_double

    def _rail(self, mode: str = "side") -> QWidget:
        """左边的深色栏。side：印 + 名字 + 分组导航 + 倒计时；compact：只有印、一列图标键和天数。"""
        rail = QWidget()
        rail.setFixedWidth(RAIL_W[mode])
        self._drag_handle(rail)
        lay = QVBoxLayout(rail)
        self.nav_buttons: list[QPushButton] = []
        if mode == "compact":
            lay.setContentsMargins(6, 14, 6, 12)
            lay.setSpacing(3)
            lay.addWidget(_Seal(), 0, Qt.AlignmentFlag.AlignHCenter)
            lay.addSpacing(12)
            for key, text in NAV:
                if key == "settings":
                    lay.addStretch(1)
                elif key in NAV_GROUP:
                    lay.addSpacing(8)
                lay.addWidget(self._nav_button(key, text, "compact"))
            lay.addSpacing(6)
            self.rail_count = RailCountdown(self.cfg, "compact")
            lay.addWidget(self.rail_count)
            return rail
        lay.setContentsMargins(10, 16, 10, 16)
        lay.setSpacing(3)
        head = QHBoxLayout()
        head.setContentsMargins(6, 0, 0, 0)
        head.setSpacing(10)
        head.addWidget(_Seal())
        brand = QVBoxLayout()
        brand.setSpacing(0)
        name = QLabel("见微")
        name.setFont(f(16, 700, 3))
        name.setStyleSheet("color:white;background:transparent;")   # 窄栏昼夜都是深色，不走配色映射
        sub = QLabel("高考学习舱")
        sub.setFont(f(10.5, 500, 1.2))
        sub.setStyleSheet(f"color:{T.railfg};background:transparent;")
        self._rail_sub = sub
        brand.addWidget(name)
        brand.addWidget(sub)
        head.addLayout(brand, 1)
        lay.addLayout(head)
        lay.addSpacing(18)
        for key, text in NAV:
            if key == "settings":
                lay.addStretch(1)       # 设置不是天天用的：沉到最下面，和上面几项分开
            if key in NAV_GROUP:
                lay.addSpacing(10)
                g = QLabel(NAV_GROUP[key])
                g.setFont(f(10, 600, 3.0))
                g.setContentsMargins(14, 0, 0, 2)
                g.setStyleSheet(f"color:{T.railfg};background:transparent;")
                lay.addWidget(g)
                self._rail_labels.append(g)
            lay.addWidget(self._nav_button(key, text, "side"))
        lay.addSpacing(10)
        self.rail_count = RailCountdown(self.cfg, "side")
        lay.addWidget(self.rail_count)
        return rail

    def _topband(self) -> QWidget:
        """顶栏布局：一条深色的栏横在最上面——印、名字、横排导航、倒计时、时钟、窗口键。"""
        band = QWidget()
        band.setFixedHeight(TOP_H)
        self._drag_handle(band, double=True)
        lay = QHBoxLayout(band)
        lay.setContentsMargins(16, 0, 10, 0)
        lay.setSpacing(2)
        seal = _Seal()
        seal.setFixedSize(32, 32)
        lay.addWidget(seal)
        lay.addSpacing(8)
        name = QLabel("见微")
        name.setFont(f(16, 700, 3))
        name.setStyleSheet("color:white;background:transparent;")
        lay.addWidget(name)
        lay.addSpacing(20)
        self.nav_buttons: list[QPushButton] = []
        for key, text in NAV:
            if key == "settings":
                continue
            if key in NAV_GROUP:
                lay.addSpacing(12)
            lay.addWidget(self._nav_button(key, text, "top"))
        lay.addStretch(1)
        self.rail_count = RailCountdown(self.cfg, "top")
        lay.addWidget(self.rail_count)
        lay.addSpacing(10)
        self.clock_label = QLabel()
        self.clock_label.setFont(f(11, 500, 0.6))
        self.clock_label.setStyleSheet(self._clock_qss())
        lay.addWidget(self.clock_label)
        lay.addSpacing(10)
        lay.addWidget(self._nav_button("settings", "设置", "top"))    # 设置靠右，和窗口键挨着
        lay.addSpacing(6)
        self._window_keys(lay, dark=True)
        # nav_buttons 要和 NAV 同一个顺序（goto 里按顺序对应）
        order = {k: i for i, (k, _) in enumerate(NAV)}
        self.nav_buttons.sort(key=lambda b: order[b.property("navKey")])
        self._refresh_clock()
        # 0.3.14：窗口窄（≤ 约 1100）时放不下：先收倒计时，再收时钟，不让导航键和它们叠字
        extras = (self.rail_count, self.clock_label)
        squeezed = []                   # 只恢复自己收起来的（倒计时可能本来就关着）

        def fit(_e=None, band=band, lay=lay):
            while squeezed:
                squeezed.pop().setVisible(True)
            for x in extras:
                lay.invalidate()
                if lay.minimumSize().width() <= band.width():
                    break
                if not x.isHidden():
                    x.setVisible(False)
                    squeezed.append(x)
        band.resizeEvent = lambda e, fit=fit: (QWidget.resizeEvent(band, e), fit())
        return band

    def _homeband(self) -> QWidget:
        """模块桌面 / 工作台的顶栏：没有导航，只有印、名字、返回、倒计时、时钟、设置和窗口键。"""
        band = QWidget()
        band.setFixedHeight(TOP_H)
        self._drag_handle(band, double=True)
        lay = QHBoxLayout(band)
        lay.setContentsMargins(16, 0, 10, 0)
        lay.setSpacing(2)
        seal = _Seal()
        seal.setFixedSize(32, 32)
        lay.addWidget(seal)
        lay.addSpacing(8)
        name = QLabel("见微")
        name.setFont(f(16, 700, 3))
        name.setStyleSheet("color:white;background:transparent;")
        lay.addWidget(name)
        lay.addSpacing(18)
        self.crumb = CrumbButton("桌面" if self._page_mode == "desktop" else "工作台")
        self.crumb.clicked.connect(lambda: self.goto("home"))
        lay.addWidget(self.crumb)
        lay.addStretch(1)
        self.nav_buttons = []
        self.rail_count = RailCountdown(self.cfg, "top")
        lay.addWidget(self.rail_count)
        lay.addSpacing(10)
        self.clock_label = QLabel()
        self.clock_label.setFont(f(11, 500, 0.6))
        self.clock_label.setStyleSheet(self._clock_qss())
        lay.addWidget(self.clock_label)
        lay.addSpacing(10)
        self.settings_btn = NavButton("settings", "设置", "top")
        self.settings_btn.clicked.connect(lambda: self.goto("settings"))
        lay.addWidget(self.settings_btn)
        lay.addSpacing(6)
        self._window_keys(lay, dark=True)
        self._refresh_clock()
        return band

    def set_page_layout(self, name: str) -> None:
        """换页面布局（经典页面 / 模块桌面 / 工作台）：窗口里的东西整个拆掉按新布局重搭。"""
        import ui_kit
        name = ui_kit.set_page_layout(name)
        if name == self._page_mode:
            return
        self.cfg["pageLayout"] = name
        self.save()
        self.tab = "settings" if self.tab == "settings" else "today"
        self._rebuild_chrome()

    def set_density(self, value: str) -> None:
        """疏密（标准 / 紧凑）：页面和模块按新间距重建，停在原来那一页。"""
        import ui_kit
        want = value == "dense"
        if want == ui_kit.dense():
            return
        ui_kit.set_dense(want)
        self.cfg["density"] = "dense" if want else "normal"
        self.save()
        self._drop_pages()
        self._build_pages()

    def set_layout(self, mode: str) -> None:
        """换导航位置（侧栏 / 顶栏 / 窄栏）：把窗口里的东西整个拆掉，按新布局重搭，停在原来那一页。"""
        if mode not in RAIL_W or mode == self._layout_mode:
            return
        self.cfg["layout"] = mode
        self.save()
        if self._home_mode:     # 模块桌面 / 工作台没有导航：记下来，换回经典页面时生效
            self._layout_mode = mode
            return
        self._rebuild_chrome()

    def _rebuild_chrome(self) -> None:
        from shiboken6 import delete
        self._toast_timer.stop()
        self._toast_anim.stop()
        self._toast_anim.deleteLater()
        self._drop_pages()
        old = self._root
        self.layout().removeWidget(old)
        old.setParent(None)
        delete(old)
        self._build()
        for grip, _where in self._grips:
            grip.raise_()
        self._bg_key = None
        self.update()

    def _refresh_nav_icons(self) -> None:
        """窄栏的键自己按令牌画，换主题时重画一次即可。"""
        for b in getattr(self, "nav_buttons", []):
            b.update()
        sub = getattr(self, "_rail_sub", None)
        if sub is not None:
            sub.setStyleSheet(f"color:{T.railfg};background:transparent;")
        for g in getattr(self, "_rail_labels", []):
            g.setStyleSheet(f"color:{T.railfg};background:transparent;")

    def _build_pages(self) -> None:
        """让所有页面过期：正在看的那一页马上重建，其余等点到再建。

        以前这里一次建六页（换主题、重扫题库、启动都要等一秒多）；现在启动只建「今日」。
        """
        if self.stack.count() == 0:
            for _key, _ in NAV:
                self.stack.addWidget(QWidget())     # 占位，点到时换成真页面
            self.stack.addWidget(QWidget())         # 最后一格留给模块桌面 / 工作台
        self._built.clear()
        if self._home_mode:
            self._rebuild_home()
        first = self.tab if hasattr(self, "tab") else "today"
        self.tab = first
        self.goto(first, animate=False)

    def _rebuild_home(self) -> None:
        """模块桌面 / 工作台本身（栈的最后一格）。数据变了、换了配色都整块重建。"""
        if not self._home_mode:
            return
        import modules
        i = len(NAV)
        home = modules.Desktop(self) if self._page_mode == "desktop" else modules.Workspace(self)
        if self.stack.count() > i:
            old = self.stack.widget(i)
            current = self.stack.currentIndex() == i
            self.stack.removeWidget(old)
            old.hide()
            old.deleteLater()       # 可能正在它里面的某个键的点击处理里：别当场删
        else:
            current = False
        self.stack.insertWidget(i, home)
        self.home = home
        if current:
            self.stack.setCurrentIndex(i)

    def refresh_home(self) -> None:
        if self._home_mode:
            QTimer.singleShot(0, self._rebuild_home)

    def _ensure_page(self, key: str) -> None:
        if key in self._built:
            return
        import ui_kit
        i = self._page_index[key]
        page = self._builders[key](self)
        ui_kit.restyle_tree(page)
        old = self.stack.widget(i)
        current = self.stack.currentIndex() == i
        self.stack.removeWidget(old)
        old.hide()
        old.deleteLater()
        self.stack.insertWidget(i, page)
        if current:
            self.stack.setCurrentIndex(i)
        self._built.add(key)

    def _drop_pages(self) -> None:
        """把建好的页面立刻拆掉、换回占位（换主题前用）。

        换主题要给整个应用重设样式表，Qt 会把每个活着的控件重新抛光一遍；
        这些页面反正要按新配色重建，先拆掉就不用白抛一次。
        """
        from shiboken6 import delete
        for key in list(self._built):
            i = self._page_index[key]
            old = self.stack.widget(i)
            self.stack.removeWidget(old)
            self.stack.insertWidget(i, QWidget())
            old.setParent(None)
            delete(old)
        self._built.clear()
        i = len(NAV)
        if self.stack.count() > i and getattr(self, "home", None) is not None:   # 模块桌面 / 工作台也先拆
            old = self.stack.widget(i)
            self.stack.removeWidget(old)
            self.stack.insertWidget(i, QWidget())
            old.setParent(None)
            delete(old)
            self.home = None
        tab = getattr(self, "tab", "today")
        self.stack.setCurrentIndex(i if tab == "home" else self._page_index.get(tab, 0))

    def refresh_pages(self, keys=("today", "guanlan")) -> None:
        """数据变了（观澜更新、换了一天……）：这几页过期；正在看的话马上重建，停在原处。"""
        self._built.difference_update(keys)
        if self.tab in keys:
            self.goto(self.tab, animate=False)
        self.refresh_home()

    # ------------------------------------------------------------ 主题
    def set_skin(self, skin: str) -> None:
        """换皮肤（水墨 / 青瓷）：昼夜不变，全部窗口跟着换。"""
        import ui_kit
        if skin != ui_kit.skin():
            self._apply_look(ui_kit.theme(), skin)

    def toggle_theme(self) -> None:
        import ui_kit
        nxt = "night" if ui_kit.theme() == "day" else "day"
        self.cfg["themeMode"] = nxt      # 手动切过就固定下来；想再跟随时间，到设置里选
        self._apply_look(nxt, ui_kit.skin())

    def _theme_mode(self) -> str:
        mode = self.cfg.get("themeMode")
        if mode in ("auto", "day", "night"):
            return mode
        return self.cfg.get("theme") if self.cfg.get("theme") in ("day", "night") else "auto"

    @staticmethod
    def _auto_theme() -> str:
        return "day" if 7 <= datetime.now().hour < 19 else "night"

    def set_theme_mode(self, mode: str) -> None:
        """昼夜：auto 跟随时间（开着的时候到点也会换），day / night 固定。"""
        import ui_kit
        self.cfg["themeMode"] = mode if mode in ("auto", "day", "night") else "auto"
        want = self._auto_theme() if self.cfg["themeMode"] == "auto" else mode
        if want != ui_kit.theme():
            self._apply_look(want, ui_kit.skin())
        else:
            self.cfg["theme"] = "auto" if self.cfg["themeMode"] == "auto" else want
            self.save()

    def _apply_look(self, nxt: str, skin: str) -> None:
        import ui_kit
        ui_kit.apply_theme(nxt, skin)
        self.cfg["theme"] = "auto" if self.cfg.get("themeMode") == "auto" else nxt
        self.cfg["skin"] = skin
        self.save()
        self._drop_pages()
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(ui_kit.qss())
        self.theme_btn.icon = "moon" if nxt == "day" else "sun"
        self.theme_btn.update()
        self._refresh_nav_icons()
        self.rail_count.update()
        self.clock_label.setStyleSheet(self._clock_qss())
        self._build_pages()
        self.update()
        if self._native is not None:
            self._native.set_theme(nxt)
        self.guanlan.set_theme(nxt, skin)
        if self.pill is not None and self.pill.isVisible():     # 时间胶囊跟着换风格（深浅仍看壁纸）
            self.pill.apply_config(self.cfg)
        if self._tray is not None and self._tray.contextMenu() is not None:
            self._tray.contextMenu().setStyleSheet(self._menu_qss())
        for w in (self.surface,):
            w.style().unpolish(w)
            w.style().polish(w)
            w.update()

    # ------------------------------------------------------------ 绘制
    def paintEvent(self, _ev) -> None:
        # 纸底只随尺寸 / 主题变化：缓存成图。按钮悬停、滚动、提示条这些局部重绘都会落到这里，
        # 以前每次都要重算四个大径向渐变
        dpr = self.devicePixelRatioF()
        import ui_kit
        key = (self.width(), self.height(), round(dpr, 3), _theme(), ui_kit.skin(), self._layout_mode, self._home_mode)
        if getattr(self, "_bg_key", None) != key:
            pm = QPixmap(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
            pm.setDevicePixelRatio(dpr)
            pm.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pm)
            self._paint_bg(painter)
            painter.end()
            self._bg, self._bg_key = pm, key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._bg)
        p.end()

    def _paint_bg(self, p: QPainter) -> None:
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        import ui_kit
        path = QPainterPath()
        path.addRoundedRect(rect, 12, 12)
        p.fillPath(path, C.PAPER)
        # 左侧深色窄栏：见微的识别，昼夜都是深色
        rail_w = 0 if self._home_mode else RAIL_W[self._layout_mode]
        top_h = TOP_H if (self._home_mode or self._layout_mode == "top") else 0
        p.save()
        p.setClipPath(path)
        if rail_w:
            p.fillRect(QRectF(0, 0, rail_w, self.height()), QColor(T.rail))
        if top_h:
            p.fillRect(QRectF(0, 0, self.width(), top_h), QColor(T.rail))
        if ui_kit.skin() == "ink":
            self._paint_ink(p, rail_w, top_h)
        elif ui_kit.skin() == "doodle":
            self._paint_doodle(p, rail_w, top_h)
        p.restore()
        p.setPen(QPen(C.WINDOW_LINE, 2 if ui_kit.skin() == "doodle" else 1))
        p.drawPath(path)

    def _paint_doodle(self, p: QPainter, rail_w: float, top_h: float) -> None:
        """手绘皮肤的底：内容区右上角几朵描线的云；宽侧栏底下一小幅简笔风景（太阳、两道山丘）。"""
        w, h = float(self.width()), float(self.height())
        night = _theme() == "night"
        line = QColor(C.KEYLINE if not night else C.FAINT)

        def cloud(cx: float, cy: float, s: float, alpha: float) -> None:
            path = QPainterPath()
            for dx, dy, r in ((-22, 4, 13), (-6, -5, 17), (14, -1, 14), (28, 6, 10)):
                blob = QPainterPath()
                blob.addEllipse(QPointF(cx + dx * s, cy + dy * s), r * s, r * s)
                path = path.united(blob)
            base = QPainterPath()
            base.addRoundedRect(QRectF(cx - 34 * s, cy + 2 * s, 72 * s, 15 * s), 7 * s, 7 * s)
            path = path.united(base).simplified()
            fill = QColor(C.CARD)
            fill.setAlphaF(alpha)
            pen = QColor(line)
            pen.setAlphaF(min(1.0, alpha * 0.9))
            p.setPen(QPen(pen, 2))
            p.setBrush(fill)
            p.drawPath(path)

        y0 = top_h if top_h else 44
        cloud(w - 250, y0 + 40, 1.0, 0.55 if not night else 0.30)
        cloud(w - 120, y0 + 78, 0.72, 0.42 if not night else 0.22)
        cloud(rail_w + (w - rail_w) * 0.58, y0 + 30, 0.6, 0.35 if not night else 0.18)

        if rail_w >= 150:       # 宽侧栏底下：太阳和两道山丘，压在倒计时后面
            p.save()
            p.setClipRect(QRectF(0, 0, rail_w, h))
            foot = h - 104
            sun = QColor("#FFC93C")
            p.setPen(QPen(QColor("#12141F"), 2))
            p.setBrush(sun)
            p.drawEllipse(QPointF(rail_w - 46, foot - 34), 15, 15)
            for cx, r, col in ((40, 92, "#3A4568" if not night else "#262A40"), (150, 110, "#32405F" if not night else "#1E2134")):
                hill = QPainterPath()
                hill.addEllipse(QPointF(cx, foot + r - 22), r * 1.25, r)
                p.setBrush(QColor(col))
                p.drawPath(hill)
            veil = QLinearGradient(0, foot + 4, 0, foot + 40)
            rail = QColor(T.rail)
            veil.setColorAt(0.0, QColor(rail.red(), rail.green(), rail.blue(), 0))
            veil.setColorAt(1.0, rail)
            p.fillRect(QRectF(0, foot + 4, rail_w, h - foot), veil)
            p.restore()

    def _paint_ink(self, p: QPainter, rail_w: float = 196, top_h: float = 0) -> None:
        """水墨皮肤的底：宣纸上几根纸筋、右上角一抹远山和一轮朱砂日，窄栏底下几重夜山。

        都画进缓存的底图里（尺寸或主题变了才重画），不占每帧的开销。山形用固定的种子，每次打开都是同一幅。
        """
        import random
        w, h = float(self.width()), float(self.height())
        night = _theme() == "night"
        rng = random.Random(27)
        ink = QColor(C.INK)

        # 纸筋：极淡的短纤维，近看才有
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        for _ in range(int((w - rail_w) * (h - top_h) / 5200)):
            x, y = rng.uniform(rail_w + 4, w), rng.uniform(top_h, h)
            a, ln = rng.uniform(0, 3.1416), rng.uniform(5, 16)
            c = QColor(ink)
            c.setAlphaF(rng.uniform(0.012, 0.035) if not night else rng.uniform(0.01, 0.026))
            p.setPen(QPen(c, rng.choice((0.6, 0.8, 1.0))))
            import math
            p.drawLine(QPointF(x, y), QPointF(x + math.cos(a) * ln, y + math.sin(a) * ln * 0.35))

        # 远山：三重，越远越淡；山脚化进纸里
        rng = random.Random(27)     # 山形和纸筋分开取随机数：换布局时山还是那几座
        x0 = rail_w + (w - rail_w) * 0.38
        base = 114.0 + (top_h if top_h else 44)
        p.setPen(Qt.PenStyle.NoPen)
        for amp, alpha, depth, shift in ((66, 0.065, 110, 0), (48, 0.095, 96, 46), (30, 0.135, 80, 104)):
            ridge = _ridge(rng, x0 + shift, w + 30, base, amp, "left")
            g = QLinearGradient(0, base - amp, 0, base + depth * 0.25)
            top = QColor(ink)
            top.setAlphaF(alpha if not night else alpha * 0.9)
            g.setColorAt(0.0, top)
            g.setColorAt(1.0, QColor(ink.red(), ink.green(), ink.blue(), 0))
            p.fillPath(ridge, g)
        # 试过在山上加一轮朱砂日：落在页头文字旁边像个提醒红点，去掉了。整幅只有印和指针是红的

        if rail_w < 150:        # 窄栏和顶栏布局没有地方放这幅夜山
            return
        # 窄栏底下的夜山：浓墨底上几层更淡的墨
        p.save()
        p.setClipRect(QRectF(0, 0, 196, h))
        foot = h - 96
        for amp, alpha, shift in ((78, 0.050, -6), (56, 0.075, 30), (34, 0.11, 0)):
            ridge = _ridge(rng, -10, 206, foot + shift * 0.2, amp, "none")
            g = QLinearGradient(0, foot - amp, 0, foot + 30)
            g.setColorAt(0.0, QColor(255, 255, 255, int(255 * alpha)))
            g.setColorAt(1.0, QColor(255, 255, 255, 0))
            p.fillPath(ridge, g)
        veil = QLinearGradient(0, foot - 10, 0, h)      # 山脚以下压回底色，倒计时的字才清楚
        veil.setColorAt(0.0, QColor(0, 0, 0, 0))
        rail = QColor(T.rail)
        veil.setColorAt(0.35, rail)
        veil.setColorAt(1.0, rail)
        p.fillRect(QRectF(0, foot - 10, 196, h - foot + 10), veil)
        p.restore()

    # ------------------------------------------------------------ 导航
    def goto(self, key: str, animate: bool = True) -> None:
        import ui_kit
        if self._home_mode and key in ("home", "today"):
            key = "home"            # 模块桌面 / 工作台本身就是「今日」
        elif key not in self._page_index:
            key = "home" if self._home_mode else "today"
        i = len(NAV) if key == "home" else self._page_index[key]
        fade = getattr(self, "_fade", None)
        snap = None
        if (animate and fade is not None and i != self.stack.currentIndex() and self.isVisible()
                and not self.isMinimized() and ui_kit.motion()):
            snap = self.stack.grab()        # 旧页面的样子：盖在新页面上淡出
        if key == "lecture" and i != self.stack.currentIndex():
            self._built.discard("lecture")  # 课件可能在学习窗口里导入、删除过：每次点进来都按最新的列
        self.tab = key
        if key != "home":
            self._ensure_page(key)
        self.stack.setCurrentIndex(i)
        for b, (k, _) in zip(self.nav_buttons, NAV):
            b.setChecked(k == key)
        if self.crumb is not None:
            self.crumb.set_page("" if key == "home" else dict(NAV).get(key, ""))
        if self.settings_btn is not None:
            self.settings_btn.setChecked(key == "settings")
        if snap is not None:
            fade.play(snap)
        self.raise_()

    def _esc(self) -> None:
        """模块桌面 / 工作台里看完整页面时，Esc 回去。"""
        if self._home_mode and self.tab != "home":
            self.goto("home")

    # ------------------------------------------------------------ 窗口
    def _bar_press(self, ev) -> None:
        if ev.button() == Qt.MouseButton.LeftButton:
            # 交给系统拖动：拖到屏幕边能贴边、拖到顶能最大化
            handle = self.windowHandle()
            if handle is not None and handle.startSystemMove():
                return
            self._drag = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def _bar_double(self, _ev) -> None:
        self.showNormal() if self.isMaximized() else self.showMaximized()

    @staticmethod
    def _on_screen(x: int, y: int, w: int, h: int):
        """上次的位置还在某块屏幕上才用，否则放回主屏。"""
        from PySide6.QtCore import QRect
        from PySide6.QtGui import QGuiApplication
        rect = QRect(x, y, max(980, w), max(640, h))
        for screen in QGuiApplication.screens():
            if screen.availableGeometry().intersects(rect.adjusted(40, 0, -40, -rect.height() + 40)):
                return rect
        geo = QGuiApplication.primaryScreen().availableGeometry()
        return QRect(geo.x() + 40, geo.y() + 40, min(rect.width(), geo.width() - 80), min(rect.height(), geo.height() - 80))

    def resizeEvent(self, ev) -> None:
        super().resizeEvent(ev)
        w, h, m = self.width(), self.height(), 5
        for grip, where in getattr(self, "_grips", []):
            grip.setGeometry(*{"r": (w - m, 12, m, h - 24), "b": (12, h - m, w - 24, m), "c": (w - 12, h - 12, 12, 12),
                               "l": (0, 12, m, h - 24), "t": (12, 0, w - 24, m)}[where])
            grip.setVisible(not self.isMaximized())
            grip.raise_()

    def showEvent(self, ev) -> None:
        super().showEvent(ev)
        import ui_kit
        if ev.spontaneous() or not ui_kit.motion():
            return      # 从任务栏还原是系统自己的动画；自测截图时不放
        # 从托盘 / 胶囊唤出来时淡入，不是整块突然贴到屏幕上
        self.setWindowOpacity(0.0)
        anim = QPropertyAnimation(self, b"windowOpacity", self)
        anim.setDuration(170)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._appear = anim
        anim.start()

    def _remember_geometry(self) -> None:
        if not self.isMaximized():
            g = self.geometry()
            self.cfg["shellGeom"] = [g.x(), g.y(), g.width(), g.height()]
            self.save()

    def _bar_move(self, ev) -> None:
        if self._drag is not None:
            self.move(ev.globalPosition().toPoint() - self._drag)

    def _bar_release(self, _ev) -> None:
        self._drag = None

    def _close_clicked(self) -> None:
        self._remember_geometry()
        if self.cfg.get("closeToTray", True) and self._tray is not None:
            self.hide()
        else:
            self.quit_app()

    def closeEvent(self, ev) -> None:
        if self.cfg.get("closeToTray", True) and self._tray is not None:
            ev.ignore()
            self.hide()
            return
        self.quit_app()
        ev.accept()

    def quit_app(self) -> None:
        from shiboken6 import isValid
        inspector=getattr(self,'_backup_inspector',None)
        if inspector is not None and isValid(inspector) and inspector.isRunning():
            self.toast('备份校验尚未结束，请稍候再退出')
            return
        try:
            if self._save_timer.isActive():
                self.save()
            if self.pill:
                self.pill.close()
            if self._native is not None:
                self._native.shutdown()
                self._native.close()
            if getattr(self, "_hotkey", None) is not None:
                self._hotkey.remove()
            self.guanlan.hide()
        except Exception:
            pass
        QApplication.instance().quit()

    def _refresh_clock(self) -> None:
        now = datetime.now()
        self.clock_label.setText(f"{now:%Y.%m.%d} 周{'一二三四五六日'[now.weekday()]} {now:%H:%M}")
        if now.date() != self._day:
            # 见微常驻托盘，会开着过夜：过了零点，今日一题、天数、日期这些要换成新一天的
            self._day = now.date()
            self.refresh_pages()

    def _auto_look(self) -> None:
        """昼夜设成跟随时间时：开着过了早上 7 点 / 晚上 7 点自己换（由时钟定时器来问，自测时不动）。"""
        import ui_kit
        if os.environ.get("JIANWEI_SELFTEST") == "1":
            return
        if self._theme_mode() == "auto" and self._auto_theme() != ui_kit.theme():
            self._apply_look(self._auto_theme(), ui_kit.skin())

    # ------------------------------------------------------------ 托盘
    def _build_tray(self) -> None:
        self._tray = QSystemTrayIcon(self._make_icon(), self)
        self._tray.setToolTip("见微 · 高考学习舱")
        menu = QMenu()
        menu.setStyleSheet(self._menu_qss())
        for text, fn in (("打开见微", self._tray_show),
                         ("课件", lambda: (self._tray_show(), self.goto("lecture"))),
                         ("习题台", lambda: self.open_studio("")),
                         ("格物实验台", lambda: self.open_lab("")),
                         ("观澜浮窗", self.toggle_guanlan),
                         ("倒计时胶囊", self.toggle_pill),
                         ("桌面悬浮工具栏", self.toggle_desktop_tools),
                         ("暮省全屏", self.evening),
                         ("立即更新内容", self.refresh_guanlan)):
            a = QAction(text, self)
            a.triggered.connect(fn)
            menu.addAction(a)
        menu.addSeparator()
        quit_action = QAction("退出见微", self)
        quit_action.triggered.connect(self.quit_app)
        menu.addAction(quit_action)
        self._tray.setContextMenu(menu)
        self._tray.activated.connect(
            lambda r: self._tray_show() if r in (QSystemTrayIcon.ActivationReason.Trigger,
                                                 QSystemTrayIcon.ActivationReason.DoubleClick) else None)
        self._tray.show()

    @staticmethod
    def _menu_qss() -> str:
        return (f"QMenu{{background:{C.CARDH};color:{C.INKH};border:1px solid {C.KEYLINEH};padding:6px;}}"
                "QMenu::item{padding:7px 28px 7px 16px;border-radius:5px;font-size:12.5px;}"
                f"QMenu::item:selected{{background:{C.KEYHOVERH};}}"
                f"QMenu::separator{{height:1px;background:{C.LINEH};margin:5px 8px;}}")

    def _tray_show(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def toggle_desktop_tools(self):
        from native.kit.desktop_tools import toggle_desktop_tools
        toggle_desktop_tools()

    def _make_icon(self) -> QIcon:
        pm = QPixmap(64, 64)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        paint_seal(p, QRectF(4, 4, 56, 56))
        p.end()
        return QIcon(pm)

    # ------------------------------------------------------------ 提示
    def toast(self, text: str) -> None:
        self.toast_sig.emit(text)

    def _show_toast(self, text: str) -> None:
        import ui_kit
        fresh = not self._toast.isVisible()
        self._toast.setText(text)
        self._toast.setStyleSheet(f"background:{T.fg};color:{T.stage};border-radius:6px;padding:8px 16px;")
        self._toast.adjustSize()
        end = QPoint(max(16, (self.surface.width() - self._toast.width()) // 2), self.surface.height() - 56)
        self._toast_anim.stop()
        self._toast.show()
        self._toast.raise_()
        if fresh and ui_kit.motion() and self.isVisible():   # 新出现的从下面滑上来一点；连续提示只换字
            self._toast.move(end + QPoint(0, 14))
            self._toast_anim.setStartValue(end + QPoint(0, 14))
            self._toast_anim.setEndValue(end)
            self._toast_anim.start()
        else:
            self._toast.move(end)
        self._toast_timer.start(2400)   # 连续提示时重新计时，不会被上一条的定时器提前关掉

    # ------------------------------------------------------------ 配置
    def save(self) -> None:
        self._save_timer.stop()
        store.save_config(self.cfg)

    def save_soon(self) -> None:
        """稍后保存：连续的改动（拖滑块）合成一次写盘。退出、隐藏前会补存。"""
        self._save_timer.start()

    def apply_pill(self, now: bool = False) -> None:
        """把配置应用到桌面胶囊。now=False 时稍后再存盘（滑块拖动用），一次性的操作传 now=True。"""
        if now:
            self.save()
        else:
            self.save_soon()
        if self.pill is not None and self.pill.isVisible():
            self.pill.apply_config(self.cfg)

    def preset_pill(self, w: int, h: int) -> None:
        self.cfg["width"], self.cfg["height"] = w, h
        self.apply_pill(now=True)
        self.toast(f"已切换 {w}×{h}")

    def center_pill(self) -> None:
        from countdown import centers_on_top
        self.cfg["pillX"] = None
        self.apply_pill(now=True)
        self.toast("已回到顶部居中" if centers_on_top(self.cfg) else "已回到默认位置")

    def set_pill_layout(self, name: str) -> None:
        """换胶囊版式：位置回到这种版式的默认处（横尺、迷你顶上居中；方块、竖条靠左）。"""
        from countdown import LAYOUT_NAMES, pill_layout
        if pill_layout(dict(pillLayout=name)) == pill_layout(self.cfg):
            return
        self.cfg["pillLayout"] = pill_layout(dict(pillLayout=name))
        self.cfg["pillX"] = None
        self.apply_pill(now=True)
        self._built.discard("countdown")
        self.toast(f"胶囊换成「{LAYOUT_NAMES[self.cfg['pillLayout']]}」")

    def show_pill(self, on: bool, quiet: bool = False) -> None:
        if on:
            if self.pill is None:
                self.pill = CountdownPill(self.cfg)
                self.pill.moved.connect(self._pill_moved)
                self.pill.action.connect(self._pill_action)
            self.pill.apply_config(self.cfg)
            self.pill.show()
            self.pill.raise_()
            self.cfg["showPill"] = True
        else:
            if self.pill is not None:
                self.pill.hide()
            self.cfg["showPill"] = False
        if getattr(self, "tab", "") != "countdown":
            self._built.discard("countdown")    # 倒计时页上的「显示 / 隐藏」键要跟着变
        self.save()
        if not quiet:
            self.toast("胶囊已显示" if on else "胶囊已隐藏")

    def _pill_moved(self, x, top: int) -> None:
        """胶囊拖到哪就记到哪，下次启动还在那里。"""
        self.cfg["pillX"] = x
        self.cfg["marginTop"] = top
        self.save()

    def _pill_action(self, key: str) -> None:
        if key == "open":
            self._tray_show()
        elif key == "guanlan":
            self.toggle_guanlan()
        elif key == "studio":
            self.open_studio("")
        elif key == "settings":
            self._tray_show()
            self.goto("countdown")
        elif key == "hide":
            self.show_pill(False)
        elif key == "center":
            self.center_pill()
        elif key == "top":
            self.cfg["zorder"] = "bottom" if str(self.cfg.get("zorder", "bottom")) == "top" else "top"
            self.apply_pill(now=True)
            self._built.discard("countdown")    # 倒计时页上的勾选框要跟着变：下次点到时重建
        elif key == "seconds":
            self.cfg["showSeconds"] = not self.cfg.get("showSeconds", True)
            self.apply_pill(now=True)
            self._built.discard("countdown")
        elif key.startswith("layout:"):
            self.set_pill_layout(key.split(":", 1)[1])

    def toggle_pill(self) -> None:
        self.show_pill(not (self.pill is not None and self.pill.isVisible()))

    # ------------------------------------------------------------ 模块
    def toggle_guanlan(self) -> None:
        self.cfg["showGuanlan"] = self.guanlan.toggle()
        self.save()
        QTimer.singleShot(120, self._sync_pill_reserve)
        self.toast("观澜浮窗已打开" if self.cfg["showGuanlan"] else "观澜浮窗已收起")

    def evening_archive(self) -> None:
        """重播往期：只有 2.0 生成的期数能播；1.x 的 .html 还在「晚间暮省」文件夹里，可以直接打开。"""
        from PySide6.QtWidgets import QInputDialog
        self.guanlan._ensure_home()
        self.guanlan._ensure_path()
        from core.evening import archived_dates  # type: ignore
        dates = archived_dates()
        if not dates:
            self.toast("还没有往期：播过一次之后这里才有")
            return
        d, ok = QInputDialog.getItem(self, "往期暮省", "选一期重播", dates, 0, False)
        if ok and d:
            self.guanlan.evening(d)

    def evening(self) -> None:
        self.guanlan.evening()
        self.toast("正在生成今晚的暮省页")

    def _guanlan_updated(self) -> None:
        """今日版换了：浮窗就地换内容，主窗口的「今日」「观澜」两页也跟着换（以前要重启才看得到）。"""
        self.guanlan.reload()
        self.refresh_pages()

    def refresh_guanlan(self) -> None:
        def work():
            try:
                self.guanlan._ensure_home()
                self.guanlan._ensure_path()
                from core.curator import run as run_curator  # type: ignore
                run_curator(force=True, log_fn=lambda *_: None)
                self.guanlan_done.emit()
                self.toast_sig.emit("观澜内容已更新")
            except Exception as exc:
                self.toast_sig.emit(f"更新失败：{exc}")
        self.toast("正在更新观澜内容…")
        threading.Thread(target=work, daemon=True).start()

    def open_studio(self, qid: str = "", lab: bool = False, mode: str = "", imp: bool = False) -> None:
        if lab:
            self.open_web("lab", mode=mode)
        else:
            self.open_web("studio", qid=qid, imp=imp)

    def collect_material(self,payload):
        from native.kit.composition import collect
        return collect(self.native_window().clip_bus,payload)

    def native_window(self):
        if self._native is None:
            import ui_kit
            from native.data_import import run_once
            msg = run_once()   # 题库读入之前先导入 1.x 的记录，一启动就点开也能看到
            if msg:
                self.toast(msg)
            from native.main_win import NativeWindow
            self._native = NativeWindow("night" if ui_kit.theme() == "night" else "day")
        return self._native

    def open_web(self, key: str, qid: str = "", mode: str = "", imp: bool = False) -> None:
        """习题台、实验台、工作台、析题都在原生窗口里打开（不依赖网页与浏览器内核）。"""
        try:
            w = self.native_window()
            if key == "import":
                w.open_lab("import")
            elif key == "bench":
                w.open_lab(f"bench/{mode}" if mode else "bench")
            elif key == "lab":
                w.open_lab(mode)
            elif key == "lecture":
                w.open_lecture()
            elif key == "classroom":
                w.goto("classroom")
                w.present()
            elif imp:
                w.open_import()
            else:
                w.open_question(qid)
        except Exception as exc:  # noqa: BLE001  打不开也要有交代：记日志并提示
            import traceback
            try:
                (store.HOME / "logs").mkdir(parents=True, exist_ok=True)
                with open(store.HOME / "logs" / "app.log", "a", encoding="utf-8") as fh:
                    fh.write(traceback.format_exc() + "\n")
            except Exception:
                pass
            self.toast(f"打开失败：{exc}")

    def prewarm_web(self) -> None:
        """空闲时先导入数据、备好学习窗口，第一次点开不用等。"""
        try:
            from native.data_import import run_once
            msg = run_once()
            if msg:
                self.toast(msg)
            if self.cfg.get("prewarmWeb", True):
                self.native_window()
        except Exception:
            import traceback
            traceback.print_exc()

    # ------------------------------------------------------------ 课件
    def lecture_backend(self):
        """学习窗口里的课件页：导入队列、放映器都在它那里，主窗口的课件页借它干活（不必把学习窗口显示出来）。"""
        return self.native_window().page("lecture")

    def play_lecture(self, meta: dict) -> None:
        try:
            from native.lecture.player import open_player
            backend = self.lecture_backend()
            player = open_player(meta, self, backend.clip_bus)     # 在主窗口所在的屏幕上全屏
            backend.players.append(player)
            player.destroyed.connect(backend._player_gone)
            player.destroyed.connect(lambda *_: QTimer.singleShot(0, lambda: self.refresh_pages(("lecture",))))
        except Exception as exc:  # noqa: BLE001
            self._log_exc()
            self.toast(f"打不开这份课件：{exc}")

    def import_lectures(self, paths=None) -> bool:
        """导入课件。paths 不给就弹文件框。返回有没有开始导入。"""
        try:
            from native.lecture.convert import FILTER
            backend = self.lecture_backend()
            if paths is None:
                from PySide6.QtWidgets import QFileDialog
                paths, _ = QFileDialog.getOpenFileNames(self, "导入课件", "", FILTER)
            if not paths:
                return False
            backend.import_paths(list(paths))
            if self._home_mode:
                self.toast("正在导入课件…")
                self._import_watch.start()
            return True
        except Exception as exc:  # noqa: BLE001
            self._log_exc()
            self.toast(f"导入没有开始：{exc}")
            return False

    def _watch_import(self) -> None:
        b = self._native.pages.get("lecture") if self._native is not None else None
        if b is None or b.worker is not None or b.queue:
            if b is None:
                self._import_watch.stop()
            return
        self._import_watch.stop()
        text = b.status.text()
        if text:
            self.toast(text if len(text) < 60 else text[:58] + "…")
        self.refresh_pages(("lecture",))

    def analyze_text(self, text: str) -> None:
        """模块里粘贴的题：打开学习窗口的析题页，填进去直接开始。"""
        text = (text or "").strip()
        if not text:
            self.toast("先把题目粘贴进来")
            return
        try:
            w = self.native_window()
            page = w.goto("analysis")
            w.present()
            page.text.setPlainText(text)
            page.go()
        except Exception as exc:  # noqa: BLE001
            self._log_exc()
            self.toast(f"析题没有开始：{exc}")

    def read_text(self, text: str) -> None:
        """读文模块里粘贴的文字：打开读文页，填进去（语种按有没有汉字猜）。"""
        try:
            self.goto("reading")        # 读文模块就在主窗口里，窗口本来就开着
            reading = getattr(self.stack.currentWidget(), "reading", None)
            if reading is not None and (text or "").strip():
                reading.set_text(text)
        except Exception as exc:  # noqa: BLE001
            self._log_exc()
            self.toast(f"读文没有打开：{exc}")

    def delete_lecture(self, meta: dict) -> None:
        from PySide6.QtWidgets import QMessageBox
        from native.lecture import library
        ask = QMessageBox(QMessageBox.Icon.Question, "删除课件",
                          f"删除「{meta.get('title')}」？\n这份课件里的笔迹和黑板也会一起删除，你电脑上的原文件不受影响。",
                          QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel, self)
        ask.setDefaultButton(QMessageBox.StandardButton.Cancel)
        if ask.exec() == QMessageBox.StandardButton.Yes:
            library.remove(meta["id"])
            if self._native is not None and "lecture" in self._native.pages:
                self._native.pages["lecture"].refresh()
            self.refresh_pages(("lecture",))

    @staticmethod
    def _log_exc() -> None:
        import traceback
        try:
            (store.HOME / "logs").mkdir(parents=True, exist_ok=True)
            with open(store.HOME / "logs" / "app.log", "a", encoding="utf-8") as fh:
                fh.write(traceback.format_exc() + "\n")
        except Exception:
            pass

    def open_lab(self, mode: str = "") -> None:
        self.open_studio("", lab=True, mode=mode)

    def open_question(self, qid: str) -> None:
        self.open_studio(qid)

    def random_question(self) -> None:
        import random
        qs = store.questions()
        if not qs:
            self.toast("题库为空")
            return
        q = random.choice(qs)
        self.open_studio(q["id"])
        self.toast(f"{q['subject']} · {q['title']}")

    def rescan_bank(self) -> None:
        store._QS = None
        self.refresh_pages(("today", "studio", "settings"))
        n = len(store.questions())
        self.toast(f"题库已重扫：{n} 题")

    # ------------------------------------------------------------ 自启
    def autostart_enabled(self) -> bool:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_READ)
            try:
                winreg.QueryValueEx(key, "JianweiSuite")
                return True
            finally:
                winreg.CloseKey(key)
        except Exception:
            return False

    def set_autostart(self, on: bool) -> None:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
            if on:
                exe = sys.executable
                if getattr(sys, "frozen", False):
                    cmd = f'"{exe}" --background'
                else:
                    cmd = f'"{exe}" "{os.path.join(os.path.dirname(__file__), "main.py")}" --background'
                winreg.SetValueEx(key, "JianweiSuite", 0, winreg.REG_SZ, cmd)
            else:
                try:
                    winreg.DeleteValue(key, "JianweiSuite")
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
            self.toast("开机自启已开启" if on else "开机自启已关闭")
        except Exception as exc:
            self.toast(f"设置失败：{exc}")
