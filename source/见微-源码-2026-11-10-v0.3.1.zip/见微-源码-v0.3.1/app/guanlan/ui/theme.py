"""观澜的视觉：和见微同一套「青瓷仪器」。夜是墨绿，昼是冷瓷，朱砂印做识别，青瓷色做强调。

C 的颜色在换主题时整体替换；控件里存过颜色的都要重建（MainWindow.set_theme 会做）。
"""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase


NIGHT = dict(
    PANEL="#101916", CARD="#18221E", CARD_HOVER="#1F2B26", GROOVE="#0A110E",
    TEXT="#E8EFEB", TEXT_SOFT="#C6D2CC", MUTED="#9AAAA2", DIM="#7C8C84",
    ACCENT="#6FC7B6", ON_ACCENT="#0B1412", SEAL="#D2492F", WARN="#FF8A73",
    HAIRLINE="#27332E", HAIRLINE_STRONG="#3A4942", EDGE="#060B09",
)
DAY = dict(
    PANEL="#F5F7F4", CARD="#FFFFFF", CARD_HOVER="#EBF0EC", GROOVE="#E2E7E2",
    TEXT="#14201D", TEXT_SOFT="#33423D", MUTED="#58675F", DIM="#6F7E76",
    ACCENT="#0F6B62", ON_ACCENT="#FFFFFF", SEAL="#C8402A", WARN="#C2331F",
    HAIRLINE="#DDE3DD", HAIRLINE_STRONG="#C3CBC4", EDGE="#A5AFA7",
)


class C:
    """当前主题的颜色。"""
    dark = True


def use(name: str) -> None:
    C.dark = name != "day"
    for key, value in (NIGHT if C.dark else DAY).items():
        setattr(C, key, QColor(value))


use("night")


def tint(color: QColor, alpha: float) -> QColor:
    out = QColor(color)
    out.setAlphaF(alpha)
    return out


UI_FAMILIES = ["Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans SC", "DengXian"]
SERIF_FAMILIES = ["Noto Serif SC", "SimSun", "Songti SC", "STSong"]
NUM_FAMILIES = ["Bahnschrift", "Segoe UI", "Cambria", "Times New Roman"]


def _pick_family(candidates: list[str]) -> str:
    available = set(QFontDatabase.families())
    for family in candidates:
        if family in available:
            return family
    return candidates[-1]


UI_FAMILY = _pick_family(UI_FAMILIES)
SERIF_FAMILY = _pick_family(SERIF_FAMILIES)
NUM_FAMILY = _pick_family(NUM_FAMILIES)


_FONTS: dict = {}


def font(size: float = 13, weight: int = 400, family: str | None = None,
         spacing: float = 0.0, italic: bool = False) -> QFont:
    # 这些字体对象在每个控件的每次重绘里都要用：建一次就留着（调用方只读，不改它）
    key = (size, weight, family, spacing, italic)
    f = _FONTS.get(key)
    if f is not None:
        return f
    f = QFont(family or UI_FAMILY)
    f.setPixelSize(max(1, int(size + 0.5)))
    if weight == 600:   # 微软雅黑没有半粗，Windows 上合成出来的字发糊
        weight = 700
    f.setWeight(QFont.Weight(weight))
    f.setItalic(italic)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    f.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    _FONTS[key] = f
    return f


def motion() -> bool:
    """要不要放过渡动画。自测截图时关掉，不然截到的是过渡到一半的画面。"""
    import os
    return os.environ.get("JIANWEI_SELFTEST") != "1" and os.environ.get("QT_QPA_PLATFORM") != "offscreen"


def serif(size: int = 22, weight: int = 400, spacing: float = 0.0) -> QFont:
    return font(size, weight, SERIF_FAMILY, spacing)


def mono(size: int = 12, weight: int = 400, spacing: float = 0.0) -> QFont:
    """读数、日期用的仪表数字。"""
    return font(size, weight, NUM_FAMILY, spacing)


_SHADOW_TILES: dict = {}


def _shadow_tile(blur: int, radius: float, alpha: int):
    """柔和阴影的九宫格素材，只生成一次。

    QGraphicsDropShadowEffect 挂在大面板上时，面板里任何一处重绘都要把整块面板离屏重画再模糊一遍；
    预先模糊好一块小图，之后每帧只是贴九张切片。"""
    key = (blur, round(radius, 1), alpha)
    if key in _SHADOW_TILES:
        return _SHADOW_TILES[key]
    from PySide6.QtCore import QRectF, Qt
    from PySide6.QtGui import QImage, QPainter, QPixmap
    from PySide6.QtWidgets import QGraphicsBlurEffect, QGraphicsPixmapItem, QGraphicsScene

    pad = int(blur)
    core = int(radius * 2 + 4)
    size = core + 2 * pad
    src = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    src.fill(Qt.GlobalColor.transparent)
    p = QPainter(src)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(0, 0, 0, alpha))
    p.drawRoundedRect(QRectF(pad, pad, core, core), radius, radius)
    p.end()
    scene = QGraphicsScene()
    item = QGraphicsPixmapItem(QPixmap.fromImage(src))
    blur_fx = QGraphicsBlurEffect()
    blur_fx.setBlurRadius(blur)
    blur_fx.setBlurHints(QGraphicsBlurEffect.BlurHint.QualityHint)
    item.setGraphicsEffect(blur_fx)
    scene.addItem(item)
    out = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    scene.render(p, QRectF(0, 0, size, size), QRectF(0, 0, size, size))
    p.end()
    tile = (QPixmap.fromImage(out), pad, pad + int(radius) + 1)
    _SHADOW_TILES[key] = tile
    return tile


def paint_shadow(p, rect, blur: int = 30, radius: float = 10, dy: int = 8, alpha: int = 130) -> None:
    """在 rect 外围画阴影（九宫格贴图）。"""
    from PySide6.QtCore import QRectF
    pm, pad, corner = _shadow_tile(blur, radius, alpha)
    size = pm.width()
    mid = size - 2 * corner
    r = QRectF(rect).adjusted(-pad, -pad + dy, pad, pad + dy)
    c = min(float(corner), r.width() / 2, r.height() / 2)
    x0, x1, x2 = r.left(), r.left() + c, r.right() - c
    y0, y1, y2 = r.top(), r.top() + c, r.bottom() - c
    s0, s1, s2 = 0.0, float(corner), float(corner + mid)
    cols = ((x0, c, s0, corner), (x1, x2 - x1, s1, mid), (x2, c, s2, corner))
    rows = ((y0, c, s0, corner), (y1, y2 - y1, s1, mid), (y2, c, s2, corner))
    for ty, th, sy, sh in rows:
        for tx, tw, sx, sw in cols:
            if tw > 0 and th > 0:
                p.drawPixmap(QRectF(tx, ty, tw, th), pm, QRectF(sx, sy, sw, sh))


def qss() -> str:
    a = C.ACCENT.name()
    return f"""
QWidget {{ background: transparent; color: {C.TEXT.name()}; }}
QToolTip {{
    background-color: {C.CARD.name()};
    color: {C.TEXT.name()};
    border: 1px solid {C.HAIRLINE_STRONG.name()};
    padding: 5px 8px;
    font-size: 12px;
}}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {C.HAIRLINE_STRONG.name()}; min-height: 28px; border-radius: 2px; }}
QScrollBar::handle:vertical:hover {{ background: {C.DIM.name()}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QMenu {{ background: {C.CARD.name()}; color: {C.TEXT.name()}; border: 1px solid {C.HAIRLINE_STRONG.name()}; padding: 4px; font-size: 13px; }}
QMenu::item {{ padding: 6px 24px 6px 12px; border-radius: 3px; }}
QMenu::item:selected {{ background: {C.CARD_HOVER.name()}; }}
QMenu::separator {{ height: 1px; background: {C.HAIRLINE.name()}; margin: 4px 6px; }}
QMenu::indicator {{ width: 13px; height: 13px; left: 4px; }}
QComboBox {{ background: {C.CARD.name()}; color: {C.TEXT.name()}; border: 1px solid {C.HAIRLINE_STRONG.name()}; border-radius: 5px; padding: 4px 8px; font-size: 13px; }}
QComboBox QAbstractItemView {{ background: {C.CARD.name()}; color: {C.TEXT.name()}; selection-background-color: {C.CARD_HOVER.name()}; selection-color: {C.TEXT.name()}; border: 1px solid {C.HAIRLINE_STRONG.name()}; }}
QPushButton#primary {{ background: {a}; color: {C.ON_ACCENT.name()}; border: none; border-bottom: 2px solid {C.ACCENT.darker(135).name()}; border-radius: 5px; font-size: 13px; font-weight: 600; padding: 7px 14px; }}
QPushButton#primary:hover {{ background: {C.ACCENT.lighter(108).name()}; }}
QPushButton#primary:pressed {{ border-bottom-width: 1px; padding-top: 8px; }}
QPushButton#ghost {{ background: {C.CARD.name()}; color: {C.TEXT_SOFT.name()}; border: 1px solid {C.HAIRLINE_STRONG.name()}; border-bottom: 2px solid {C.EDGE.name()}; border-radius: 5px; font-size: 13px; padding: 6px 14px; }}
QPushButton#ghost:hover {{ background: {C.CARD_HOVER.name()}; color: {C.TEXT.name()}; }}
QPushButton#ghost:pressed {{ border-bottom-width: 1px; padding-top: 7px; }}
"""
