"""见微 · 六个页面：今日 / 观澜 / 倒计时 / 习题台 / 实验室 / 设置。

页面由主壳按需建：第一次点到才建，换主题或数据变了只重建正在看的那一页（其余标记为待重建）。
颜色在建的时候按当前主题取（ui_kit.lab / C.*H），自己画的控件在重绘时取 —— 不再靠事后扫一遍控件树换色。
"""
from __future__ import annotations

import math
import os
import subprocess
from datetime import datetime, timedelta

from PySide6.QtCore import QPointF, QRect, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFontMetricsF, QLinearGradient, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import (
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QSizePolicy,
    QSlider, QVBoxLayout, QWidget,
)

import store
from countdown import draw_pill, format_milestones, parse_milestones, phase_week
from native.design.icons import draw_icon
from ui_kit import Btn, C, Card, Check, Chip, Combo, Dot, SmoothScroll, divider, f, kicker, lab, label, row, serif

WEEK_CN = "一二三四五六日"


def _clip(text: str, n: int = 56) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= n else text[: n - 1] + "…"


def _tint(color: QColor, alpha: float) -> QColor:
    out = QColor(color)
    out.setAlphaF(alpha)
    return out


def scroll(widget: QWidget) -> SmoothScroll:
    area = SmoothScroll()
    area.setWidgetResizable(True)
    area.setFrameShape(SmoothScroll.Shape.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    area.setWidget(widget)
    area.setStyleSheet("QScrollArea{background:transparent;border:none;}")
    return area


class Page(QWidget):
    def __init__(self, ctx, kick: str, title: str, sub: str = ""):
        super().__init__()
        self.ctx = ctx
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        inner = QWidget()
        self.body = QVBoxLayout(inner)
        self.body.setContentsMargins(30, 20, 30, 28)
        self.body.setSpacing(14)
        self.body.addWidget(kicker(kick))
        head = QHBoxLayout()
        head.setSpacing(10)
        head.addWidget(lab(title, 22, "INK", 700, 0.4))
        if sub:
            head.addWidget(lab(sub, 11, "FAINT"), 0, Qt.AlignmentFlag.AlignBottom)
        head.addStretch(1)
        self.head = head
        self.body.addLayout(head)
        self.body.addWidget(divider())
        self.body.addSpacing(2)
        self.inner = inner
        self.area = scroll(inner)
        outer.addWidget(self.area)

    def add(self, w):
        if isinstance(w, QWidget):
            self.body.addWidget(w)
        else:
            self.body.addLayout(w)
        return w


class _Hover(QWidget):
    """自己画的可点小块的公共部分：悬停状态、手形光标、松开才算点。"""

    def __init__(self, on_click=None):
        super().__init__()
        self._hover = False
        self._down = False
        self.on_click = on_click
        if on_click is not None:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, _e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self._hover = False
        self._down = False
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._down = True
            self.update()

    def mouseReleaseEvent(self, e):  # noqa: N802
        was = self._down
        self._down = False
        self.update()
        if was and e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()) and self.on_click:
            self.on_click()


# ------------------------------------------------------------------ 今日
class Hero(QWidget):
    """今日页最上面一块：剩余天数 + 一把学期时间尺（和桌面胶囊同一个母题）。每半分钟自己刷新。"""

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setFixedHeight(158)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._t = QTimer(self)
        self._t.setInterval(30_000)
        self._t.timeout.connect(self.update)

    def showEvent(self, e):  # noqa: N802
        self._t.start()
        super().showEvent(e)

    def hideEvent(self, e):  # noqa: N802
        self._t.stop()      # 看不见的时候不跑定时器
        super().hideEvent(e)

    def paintEvent(self, _e):  # noqa: N802
        from native.design.tokens import T
        cfg = self.ctx.cfg
        now = datetime.now()
        target, start = store.target_dt(cfg), store.start_dt(cfg)
        if start >= target:
            start = target - timedelta(days=280)
        total = max(1.0, (target - start).total_seconds())
        secs = max(0.0, (target - now).total_seconds())
        frac = min(1.0, max(0.0, 1 - secs / total))
        days = str(int(secs // 86400))
        name = str(cfg.get("label", "高考"))
        w, h = self.width(), self.height()

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(QPen(C.LINE, 1))
        p.setBrush(C.CARD)
        p.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), 9, 9)

        pad, base = 28, 104
        p.setFont(f(10, 600, 2.4))
        p.setPen(C.FAINT)
        p.drawText(QPointF(pad, 36), f"{cfg.get('year', '2027')} 届 · 距{name}")
        big = serif(66, 600)
        p.setFont(big)
        p.setPen(C.INK)
        p.drawText(QPointF(pad - 3, base), days)
        nw = QFontMetricsF(big).horizontalAdvance(days)
        p.setFont(f(14, 500))
        p.setPen(C.SOFT)
        p.drawText(QPointF(pad + nw + 6, base), "天")
        if secs > 0:
            rest = int(secs % 86400)
            p.setFont(f(12, 400))
            p.setPen(C.FAINT)
            p.drawText(QPointF(pad + nw + 30, base), f"{rest // 3600} 时 {rest % 3600 // 60:02d} 分")
        p.setFont(f(11))
        p.setPen(C.FAINT)
        p.drawText(QPointF(pad, 134), f"{target:%Y.%m.%d %H:%M} 开考 · 第 {phase_week()} 周 · 周{WEEK_CN[now.weekday()]}")

        # 右边：学期时间尺
        x0, x1 = max(pad + nw + 170.0, w * 0.44), w - pad - 2.0
        if x1 - x0 < 200:
            p.end()
            return
        width = x1 - x0
        nx = x0 + width * frac
        p.setFont(f(10, 600, 2.0))
        p.setPen(C.FAINT)
        p.drawText(QPointF(x0, 36), "学期刻度")
        pct = f"已过 {int(frac * 100)}%"
        p.setFont(serif(13, 600))
        p.setPen(C.INK2)
        p.drawText(QRectF(x1 - 120, 22, 120, 20), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), pct)

        bar_y, tick_top = 96.0, 82.0
        end_text = f"{name} {target.month}/{target.day}"
        end_font = f(10.5, 700)
        end_w = QFontMetricsF(end_font).horizontalAdvance(end_text)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        weeks = max(1, int(total // (86400 * 7)))
        step = 1
        while width / (weeks / step) < 5 and step < 8:
            step *= 2
        for i in range(0, weeks + 1, step):
            x = x0 + width * i / weeks
            p.setPen(QPen(_tint(C.INK, 0.62) if x <= nx else _tint(C.FAINT, 0.45), 1))
            p.drawLine(QPointF(x, bar_y - 6), QPointF(x, bar_y - 1))
        months, (y, m) = [], (start.year, start.month)
        while True:
            when = datetime(y, m, 1)
            if when > target:
                break
            if when >= start:
                months.append(when)
            y, m = (y + 1, 1) if m == 12 else (y, m + 1)
        lab_font = f(10.5)
        fm = QFontMetricsF(lab_font)
        every = 1 if width / max(1, len(months)) >= 34 else 2
        for i, when in enumerate(months):
            x = x0 + width * (when - start).total_seconds() / total
            passed = x <= nx
            p.setPen(QPen(_tint(C.INK, 0.85) if passed else _tint(C.FAINT, 0.7), 1))
            p.drawLine(QPointF(x, tick_top), QPointF(x, bar_y - 1))
            text = f"{when.month}月"
            tw = fm.horizontalAdvance(text)
            if i % every == 0 and x + tw < x1 - end_w - 10 and abs(x + tw / 2 - nx) > tw / 2 + 8:
                p.setFont(lab_font)
                p.setPen(C.SOFT if passed else C.FAINT)
                p.drawText(QPointF(x, tick_top - 7), text)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.LINE)
        p.drawRoundedRect(QRectF(x0, bar_y, width, 4), 2, 2)
        fill = QLinearGradient(x0, 0, max(nx, x0 + 1), 0)
        fill.setColorAt(0, _tint(C.INK2, 0.55))
        fill.setColorAt(1, C.INK2)
        p.setBrush(fill)
        p.drawRoundedRect(QRectF(x0, bar_y, max(4.0, nx - x0), 4), 2, 2)

        gold = QColor(T.gold)
        cap_font = f(10.5)
        cap = f"今天 · 还剩 {max(0, math.ceil(secs / 604800))} 周"
        cap_w = QFontMetricsF(cap_font).horizontalAdvance(cap)
        cap_x = max(x0, min(x1 - cap_w, nx - cap_w / 2))
        for item in cfg.get("milestones") or []:
            try:
                when = datetime.strptime(str(item.get("date")), "%Y-%m-%d")
            except (ValueError, AttributeError):
                continue
            if not start <= when <= target:
                continue
            x = x0 + width * (when - start).total_seconds() / total
            p.setPen(QPen(C.CARD, 1))
            p.setBrush(gold)
            p.drawPolygon(QPolygonF([QPointF(x, bar_y - 2.5), QPointF(x + 4.5, bar_y + 2), QPointF(x, bar_y + 6.5), QPointF(x - 4.5, bar_y + 2)]))
            text = str(item.get("label") or "")
            lw = QFontMetricsF(cap_font).horizontalAdvance(text)
            if text and not (cap_x - 8 < x + lw / 2 and x - lw / 2 < cap_x + cap_w + 8):
                p.setFont(cap_font)
                p.setPen(gold)
                p.drawText(QRectF(x - lw / 2 - 2, bar_y + 10, lw + 4, 18), int(Qt.AlignmentFlag.AlignCenter), text)
        p.setFont(end_font)
        p.setPen(C.INK2)
        p.drawText(QRectF(x1 - end_w - 2, tick_top - 20, end_w + 2, 16), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), end_text)
        p.setPen(QPen(C.INK2, 1.6))
        p.drawLine(QPointF(x1, tick_top - 2), QPointF(x1, bar_y + 4))
        p.setPen(QPen(C.ACCENT, 2))
        p.drawLine(QPointF(nx, tick_top - 8), QPointF(nx, bar_y + 6))
        p.setPen(QPen(C.CARD, 1.5))
        p.setBrush(C.ACCENT)
        p.drawEllipse(QPointF(nx, tick_top - 9), 3.6, 3.6)
        p.setFont(cap_font)
        p.setPen(C.SOFT)
        p.drawText(QRectF(cap_x, bar_y + 10, cap_w + 2, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), cap)
        p.end()


class EntryTile(_Hover):
    """一个入口：图标 + 名字 + 一句话。整块可点。"""

    def __init__(self, icon: str, name: str, desc: str, on_click, tip: str = ""):
        super().__init__(on_click)
        self.icon, self.name, self.desc = icon, name, desc
        self.setFixedHeight(62)
        self.setMinimumWidth(170)
        if tip:
            self.setToolTip(tip)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5 - (0 if self._down else 1))
        if self._down:
            r.translate(0, 1)
        if not self._down:      # 下沿：和按键同一个做法
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.KEYEDGE if self._hover else C.LINE)
            p.drawRoundedRect(r.adjusted(0, 0, 0, 1), 8, 8)
        p.setPen(QPen(C.KEYEDGE if self._hover else C.LINE, 1))
        p.setBrush(C.KEYHOVER if self._hover else C.CARD)
        p.drawRoundedRect(r, 8, 8)
        box = QRectF(r.x() + 13, r.y() + (r.height() - 34) / 2, 34, 34)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_tint(C.INK2, 0.16 if self._hover else 0.10))
        p.drawRoundedRect(box, 7, 7)
        draw_icon(p, self.icon, box.adjusted(8, 8, -8, -8), C.INK2, 1.6)
        tx = box.right() + 12
        tw = r.right() - tx - 26
        p.setFont(f(12.5, 700))
        p.setPen(C.INK)
        p.drawText(QRectF(tx, r.y() + 11, tw, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.name)
        p.setFont(f(10.5))
        p.setPen(C.FAINT)
        fm = QFontMetricsF(p.font())
        p.drawText(QRectF(tx, r.y() + 31, tw, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   fm.elidedText(self.desc, Qt.TextElideMode.ElideRight, tw))
        draw_icon(p, "chevron_r", QRectF(r.right() - 24, r.center().y() - 7, 14, 14), C.INK2 if self._hover else C.FAINT, 1.5)
        p.end()


def _today_question_card(ctx) -> Card:
    q = store.question_of_day()
    card = Card("今日一题", f"每天换一道 · {store.bank_years()} 高考题")
    if not q:
        card.add(label("题库尚未就绪", 12, C.FAINT, wrap=True))
        return card
    card.add(lab(f"{q['subject']} · {q['year']} 年 · {q['paper']}", 10.5, "INK2", 700, 1.0))
    card.add(lab(q["title"], 15.5, "INK", 700, wrap=True))
    card.add(lab(_clip(q["stem"], 150), 11.5, "SOFT", wrap=True))
    card.body.addStretch(1)
    btn = Btn("打开解析 →", "primary")
    btn.setFixedWidth(112)
    btn.clicked.connect(lambda: ctx.open_question(q["id"]))
    rnd = Btn("换一道", "soft", "从题库里随机抽一道")
    rnd.clicked.connect(ctx.random_question)
    card.add(row(btn, rnd, None))
    return card


def _guanlan_card(ctx) -> Card:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    card = Card("观澜 · 今日焦点", store.guanlan_date() or "等待今日版")
    title = lab(_clip(lead.get("title", ""), 46) or "今日版尚未生成", 15.5, "INK", 700, wrap=True)
    if not stories:
        title.setToolTip("在「观澜」页点「刷新内容」抓取一次")
    card.add(title)
    if lead.get("summary"):
        card.add(lab(_clip(lead["summary"], 78), 11.5, "SOFT", wrap=True))
    for i, st in enumerate(stories[1:4], start=2):
        line = QHBoxLayout()
        line.setSpacing(8)
        n = QLabel(f"{i:02d}")
        n.setFont(serif(11, 600))
        n.setStyleSheet(f"color:{C.INK2H};background:transparent;")
        n.setFixedWidth(18)
        line.addWidget(n)
        line.addWidget(lab(_clip(st["title"], 34), 11.5, "BODY"), 1)
        card.body.addLayout(line)
    card.body.addStretch(1)
    btn = Btn("打开浮窗", "soft", "在桌面上打开观澜浮窗")
    btn.setFixedWidth(96)
    btn.clicked.connect(ctx.toggle_guanlan)
    more = lab(f"共 {len(stories)} 条 · 约 15 分钟" if stories else "到「观澜」页刷新一次即可", 10.5, "FAINT")
    card.add(row(btn, more, None))
    return card


def _entries(ctx) -> QGridLayout:
    grid = QGridLayout()
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setHorizontalSpacing(12)
    grid.setVerticalSpacing(10)
    items = [
        ("guanlan", "观澜浮窗", "每日 7 条世界线索 · 人物 · 金句", ctx.toggle_guanlan),
        ("countdown", "时间胶囊", "贴在桌面上的一把时间尺", ctx.toggle_pill),
        ("studio", "习题台", "真题一题一图 · 引导动画讲过程", lambda: ctx.open_studio("")),
        ("lab", "格物实验台", "四科实验 · 自由工作台", lambda: ctx.open_lab("")),
        ("analysis", "析题", "粘贴一道题：解题、选实验、演示", lambda: ctx.open_lab("import")),
        ("lecture", "课件", "导入课件 · 放映 · 画笔与黑板", lambda: ctx.open_web("lecture")),
    ]
    for i, (icon, name, desc, fn) in enumerate(items):
        grid.addWidget(EntryTile(icon, name, desc, fn), i // 3, i % 3)
    for c in range(3):
        grid.setColumnStretch(c, 1)
    return grid


def build_overview(ctx) -> QWidget:
    now = datetime.now()
    hello = "早上好" if now.hour < 11 else "中午好" if now.hour < 14 else "下午好" if now.hour < 18 else "晚上好"
    page = Page(ctx, "见微 · 高考学习舱", "今日", f"{hello} · {now:%Y 年 %m 月 %d 日} 周{WEEK_CN[now.weekday()]}")
    page.add(Hero(ctx))
    grid = QGridLayout()
    grid.setSpacing(14)
    grid.addWidget(_today_question_card(ctx), 0, 0)
    grid.addWidget(_guanlan_card(ctx), 0, 1)
    grid.setColumnStretch(0, 1)
    grid.setColumnStretch(1, 1)
    page.add(grid)
    page.add(_entries(ctx))
    from native.learning_ui import card as learning_card
    learn = learning_card(ctx)
    for b in learn.findChildren(QPushButton):     # 这张卡里是原生按钮：套上主窗口的按键样式
        if not b.objectName():
            b.setObjectName("btn")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFont(f(12))
    for lb in learn.findChildren(QLabel):
        if not lb.styleSheet():
            lb.setFont(f(11.5))
            lb.setStyleSheet(f"color:{C.SOFTH};background:transparent;")
    page.add(learn)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 观澜
def build_guanlan(ctx) -> QWidget:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    page = Page(ctx, "观澜 · 每日世界线索", "观澜视界", "阅读浮窗 · 晚间暮省")
    lead_card = Card("", pad=(26, 22, 26, 22))
    lead_card.add(kicker(f"今日焦点 · {store.guanlan_date() or '—'}"))
    lead_card.add(lab(lead.get("title", "") or "今日版尚未生成", 22, "INK", 700, 0.2, wrap=True))
    if lead.get("summary"):
        lead_card.add(lab(lead["summary"], 12.5, "SOFT", wrap=True))
    elif not stories and not store.guanlan_date():
        lead_card.add(label("还没有任何一期内容。点下面的「刷新内容」抓取今天的世界线索（需要联网，约 30 秒）；"
                            "之后见微在托盘里常驻时，每天 07:15 会自动更新。", 12, C.SOFT, wrap=True))
    page.add(lead_card)

    acts = QHBoxLayout()
    acts.setSpacing(8)
    for text, variant, fn in (("打开观澜浮窗", "primary", ctx.toggle_guanlan), ("暮省全屏", "", ctx.evening),
                              ("往期暮省", "", ctx.evening_archive), ("刷新内容", "", ctx.refresh_guanlan)):
        b = Btn(text, variant)
        b.clicked.connect(fn)
        acts.addWidget(b)
    acts.addStretch(1)
    acts.addWidget(lab("每天 07:15 自动抓取；刷新需要网络，约 30 秒", 10.5, "FAINT"))
    page.add(acts)

    if stories:
        list_card = Card("今日线索", f"共 {len(stories)} 条 · 在浮窗里读全文")
        for i, st in enumerate(stories, 1):
            line = QHBoxLayout()
            line.setSpacing(12)
            idx = QLabel(f"{i:02d}")
            idx.setFont(serif(13, 600))
            idx.setStyleSheet(f"color:{C.INK2H if i == 1 else C.FAINTH};background:transparent;")
            idx.setFixedWidth(24)
            line.addWidget(idx, 0, Qt.AlignmentFlag.AlignTop)
            col = QVBoxLayout()
            col.setSpacing(2)
            col.addWidget(lab(st["title"], 12.5, "INK", 500, wrap=True))
            meta = " · ".join(x for x in [st.get("section", ""), st.get("source", ""),
                                          (f"{st['minutes']} 分钟" if st.get("minutes") else "")] if x)
            if meta:
                col.addWidget(lab(meta, 10.5, "FAINT"))
            line.addLayout(col, 1)
            list_card.body.addLayout(line)
            if i < len(stories):
                list_card.body.addWidget(divider())
        page.add(list_card)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 实验室
_SUBJ = (("math", "数学", "#2B55A6", "#86ADF0"), ("phys", "物理", "#BF4D27", "#EE8A5E"),
         ("chem", "化学", "#0F7D78", "#4CC3B5"), ("bio", "生物", "#53831F", "#9CCC5A"))
# 题库里文科也有题：给一套同样明度的颜色（昼 / 夜）
_SUBJ_NAME = {"数学": ("#2B55A6", "#86ADF0"), "物理": ("#BF4D27", "#EE8A5E"), "化学": ("#0F7D78", "#4CC3B5"),
              "生物": ("#53831F", "#9CCC5A"), "语文": ("#8A5A2B", "#D9A66B"), "英语": ("#6B4FA0", "#B79BE8"),
              "历史": ("#9A3B3B", "#E58B8B"), "地理": ("#2F7A8C", "#6CC4D8"), "政治": ("#7A6A1F", "#D4C261")}


def _subj_color(key: str) -> str:
    import ui_kit
    night = ui_kit.theme() == "night"
    for k, _, day, dark in _SUBJ:
        if k == key:
            return dark if night else day
    pair = _SUBJ_NAME.get(key)
    if pair:
        return pair[1] if night else pair[0]
    return C.INK2.name()


class _SubjTile(_Hover):
    """一科一格：大数字 + 学科色细条，点一下进实验台对应学科。"""

    def __init__(self, key: str, name: str, count: int, on_click):
        super().__init__(on_click)
        self.key, self.name, self.count = key, name, count
        self.setFixedHeight(92)
        self.setMinimumWidth(120)
        self.setToolTip(f"打开格物实验台 · {name}")

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        col = QColor(_subj_color(self.key))
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(QPen(col if self._hover else C.LINE, 1))
        p.setBrush(C.CARD)
        p.drawRoundedRect(r, 9, 9)
        if self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_tint(col, 0.06))
            p.drawRoundedRect(r, 9, 9)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawRoundedRect(QRectF(16, 16, 22, 4), 2, 2)
        p.setPen(QPen(C.SOFT))
        p.setFont(f(12, 600, 1.2))
        p.drawText(QRectF(16, 26, r.width() - 32, 22), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   self.name)
        p.setPen(QPen(col))
        p.setFont(serif(30, 600))
        p.drawText(QRectF(16, 44, r.width() - 32, 40), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   str(self.count))
        p.setPen(QPen(col if self._hover else C.FAINT))
        p.setFont(f(10.5))
        p.drawText(QRectF(16, 44, r.width() - 32, 40), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter),
                   "个实验 →" if self._hover else "个实验")
        p.end()


def build_lab(ctx) -> QWidget:
    st = store.lab_stats()
    page = Page(ctx, "格物实验台 · 高中数理化生", "实验室",
                f"{st['total']} 个教材实验 · {len(st['benches'])} 个自由工作台 · 题目导入")
    page.add(lab("按新课标必修与选择性必修排列的四科实验：每个都能调参、拖拽、反复做，旁边给实时读数、原理与探究建议。"
                 "自由工作台不按教材顺序，自己挑器材、药品和场景；遇到一道题，可以粘贴进来，让 DeepSeek 选实验、配好参数再演示。",
                 12, "SOFT", wrap=True))

    tiles = QHBoxLayout()
    tiles.setSpacing(12)
    for key, name, _, _ in _SUBJ:
        tiles.addWidget(_SubjTile(key, name, st["subj"].get(key, 0),
                                  lambda k=key: ctx.open_lab(f"subj/{k}")), 1)
    page.add(tiles)

    acts = QHBoxLayout()
    acts.setSpacing(8)
    for text, variant, mode in (("打开格物实验台", "primary", ""), ("析题", "", "import"), ("自由工作台", "", "bench")):
        b = Btn(text, variant)
        b.clicked.connect(lambda _=False, m=mode: ctx.open_lab(m))
        acts.addWidget(b)
    acts.addStretch(1)
    acts.addWidget(lab("在学习窗口里打开", 10.5, "FAINT"))
    page.add(acts)

    bench = Card("自由工作台", "自己选器材，搭想做的实验")
    for i, b in enumerate(st["benches"]):
        line = QHBoxLayout()
        line.setSpacing(12)
        line.addWidget(Dot(QColor(_subj_color(b["subj"])), 7), 0, Qt.AlignmentFlag.AlignVCenter)
        n = lab(b["title"], 12.5, "INK", 700)
        n.setFixedWidth(112)
        line.addWidget(n)
        line.addWidget(lab(b["sub"], 11, "SOFT", wrap=True), 1)
        if b["id"] in ("draw", "scene"):
            line.addWidget(lab("原变换实验室", 10, "FAINT"))
        go = Btn("进入", "soft")
        go.setFixedWidth(64)
        go.clicked.connect(lambda _=False, k=b["id"]: ctx.open_lab(f"bench/{k}"))
        line.addWidget(go)
        bench.body.addLayout(line)
        if i < len(st["benches"]) - 1:
            bench.add(divider())
    page.add(bench)

    ds = store.deepseek_settings()
    imp = Card("题目导入", "粘贴题干 → 解题、选实验、配参数 → 直接演示")
    imp.add(label("分析分四步：解题并挑实验 → 设好控件 → 读出画面数值和答案比对 → 不符就重解。"
                  "数都由程序算，再用第二种方法核对；没有密钥时用离线读题器处理常见题型。", 11.5, C.SOFT, wrap=True))
    state = lab(("● DeepSeek 已配置（" + ds["model"] + "）") if ds["key"] else "○ 未配置 DeepSeek 密钥，使用离线读题器",
                11, "JADE" if ds["key"] else "ACCENT", 700)
    go_imp = Btn("打开导入", "soft")
    go_imp.clicked.connect(lambda: ctx.open_lab("import"))
    go_set = Btn("去设置密钥")
    go_set.clicked.connect(lambda: ctx.goto("settings"))
    imp.add(row(state, None, go_set, go_imp))
    page.add(imp)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 倒计时
class PillPreview(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setFixedHeight(132)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._t = QTimer(self)
        self._t.setInterval(1000)
        self._t.timeout.connect(self.update)

    def showEvent(self, e):  # noqa: N802
        self._t.start()
        super().showEvent(e)

    def hideEvent(self, e):  # noqa: N802
        self._t.stop()      # 不在这一页时不用每秒重画
        super().hideEvent(e)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        # 一小块模拟桌面：胶囊是半透明的，放在白卡片上看不出真实效果
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), 7, 7)
        light = str(self.ctx.cfg.get("pillStyle", "auto")) == "porcelain"
        g = QLinearGradient(0, 0, self.width(), self.height())
        g.setColorAt(0, QColor("#DCE6E2" if light else "#2A4A52"))
        g.setColorAt(1, QColor("#AFC4C8" if light else "#16282C"))
        p.fillPath(path, g)
        cw, ch = int(self.ctx.cfg.get("width", 860)), int(self.ctx.cfg.get("height", 60))
        scale = min(1.0, (self.width() - 40) / max(1, cw))
        p.translate((self.width() - cw * scale) / 2, (self.height() - ch * scale) / 2)
        p.scale(scale, scale)
        draw_pill(p, cw, ch, self.ctx.cfg, datetime.now(), None, 0.7)
        p.end()


def _slider(ctx, label_text: str, key: str, lo: int, hi: int, changed=None) -> tuple[QWidget, QSlider, QLabel]:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(3)
    top = QHBoxLayout()
    v = QLabel(str(ctx.cfg.get(key)))
    v.setFont(serif(12, 600))
    v.setStyleSheet(f"color:{C.INKH};background:transparent;")
    top.addWidget(lab(label_text, 11, "SOFT"))
    top.addStretch(1)
    top.addWidget(v)
    s = QSlider(Qt.Orientation.Horizontal)
    s.setRange(lo, hi)
    s.setValue(int(ctx.cfg.get(key, lo)))
    s.setCursor(Qt.CursorShape.PointingHandCursor)
    s.setProperty("jw_default", int(store.DEFAULT_CONFIG.get(key, lo)))   # 双击滑块回到默认值
    s.setToolTip("拖动调整；双击回到默认值")

    def on_change(val):
        v.setText(str(val))
        ctx.cfg[key] = val
        ctx.apply_pill()
        if changed:
            changed()

    s.valueChanged.connect(on_change)
    lay.addLayout(top)
    lay.addWidget(s)
    return box, s, v


def build_countdown(ctx) -> QWidget:
    page = Page(ctx, "倒计时 · 时间胶囊", "高考倒计时", "贴在桌面上的一把时间尺")
    preview = Card("", pad=(16, 14, 16, 14))
    pill_view = PillPreview(ctx)
    preview.add(pill_view)
    preview.add(lab("一周一格、一月一道长刻度，朱砂指针是今天。桌面上可以直接拖动；右键有常用操作，双击打开见微，鼠标移到尺上能看任意一天",
                    10.5, "FAINT", wrap=True))
    page.add(preview)

    ctrl = Card("外观与行为", "改动立即生效，自动保存")
    date_row = QHBoxLayout()
    date_row.setSpacing(8)
    date_row.addWidget(lab("目标时刻", 11, "SOFT"))
    edit = QLineEdit(ctx.cfg.get("target", "2027-06-07 09:00:00"))
    edit.setFixedWidth(190)
    edit.setPlaceholderText("2027-06-07 09:00:00")
    date_row.addWidget(edit)
    ok = Btn("应用")
    ok.setFixedWidth(56)

    def apply_date():
        txt = edit.text().strip()
        try:
            datetime.strptime(txt, "%Y-%m-%d %H:%M:%S")
            ctx.cfg["target"] = txt
            ctx.apply_pill()
            ctx.save()
            pill_view.update()
            ctx.toast("目标时刻已更新")
        except Exception:
            ctx.toast("格式应为 2027-06-07 09:00:00")

    ok.clicked.connect(apply_date)
    edit.returnPressed.connect(apply_date)
    date_row.addWidget(ok)
    date_row.addSpacing(18)
    date_row.addWidget(lab("样式", 11, "SOFT"))
    style_box = Combo()
    for text, key in (("跟随壁纸明暗", "auto"), ("墨色", "ink"), ("瓷白", "porcelain")):
        style_box.addItem(text, key)
    style_box.setCurrentIndex(max(0, style_box.findData(str(ctx.cfg.get("pillStyle", "auto")))))

    def set_style(_i):
        ctx.cfg["pillStyle"] = style_box.currentData()
        ctx.apply_pill()
        pill_view.update()

    style_box.currentIndexChanged.connect(set_style)
    date_row.addWidget(style_box)
    date_row.addStretch(1)
    ctrl.body.addLayout(date_row)

    mile_row = QHBoxLayout()
    mile_row.setSpacing(8)
    mile_row.addWidget(lab("尺上节点", 11, "SOFT"))
    mile = QLineEdit(format_milestones(ctx.cfg.get("milestones")))
    mile.setPlaceholderText("可选：2027-03-10 一模；2027-04-20 二模")
    mile_row.addWidget(mile, 1)
    mile_ok = Btn("应用")
    mile_ok.setFixedWidth(56)

    def apply_miles():
        items = parse_milestones(mile.text())
        ctx.cfg["milestones"] = items
        mile.setText(format_milestones(items))
        ctx.apply_pill()
        pill_view.update()
        ctx.toast(f"尺上有 {len(items)} 个节点")

    mile_ok.clicked.connect(apply_miles)
    mile.returnPressed.connect(apply_miles)
    mile_row.addWidget(mile_ok)
    ctrl.body.addLayout(mile_row)
    ctrl.body.addSpacing(2)

    sliders = QGridLayout()
    sliders.setHorizontalSpacing(26)
    sliders.setVerticalSpacing(6)
    knobs: dict[str, tuple[QSlider, QLabel]] = {}
    for i, (text, key, lo, hi) in enumerate((("宽度", "width", 640, 1200), ("高度", "height", 52, 88),
                                             ("距顶部", "marginTop", 0, 160),
                                             ("指针光晕", "aurora", 0, 160),   # 默认 96；上限要盖住默认值，否则一碰就被截断
                                             ("底色浓度", "shade", 40, 150))):
        box, s, v = _slider(ctx, text, key, lo, hi, pill_view.update)
        knobs[key] = (s, v)
        sliders.addWidget(box, i // 2, i % 2)
    ctrl.body.addLayout(sliders)
    ctrl.body.addSpacing(2)

    def sync_knobs():
        """预设、居中这类操作改了配置：把滑块挪到新值（不再触发保存）。"""
        for key, (s, v) in knobs.items():
            s.blockSignals(True)
            s.setValue(int(ctx.cfg.get(key, s.value())))
            s.blockSignals(False)
            v.setText(str(s.value()))
        pill_view.update()

    checks = QHBoxLayout()
    checks.setSpacing(20)
    for text, key in (("显示秒", "showSeconds"), ("显示日期", "showDate"),
                      ("点击穿透", "clickThrough"), ("启动时显示", "showPill")):
        cb = Check(text)
        cb.setChecked(bool(ctx.cfg.get(key)))
        cb.toggled.connect(lambda v, k=key: (ctx.cfg.__setitem__(k, v), ctx.apply_pill(), ctx.save(), pill_view.update()))
        checks.addWidget(cb)
    top_cb = Check("置顶显示")
    top_cb.setChecked(str(ctx.cfg.get("zorder", "bottom")) == "top")
    top_cb.setToolTip("默认沉在最底层：只在壁纸上可见，任何窗口都能压住它")
    top_cb.toggled.connect(lambda v: (ctx.cfg.__setitem__("zorder", "top" if v else "bottom"),
                                      ctx.apply_pill(), ctx.save()))
    checks.addWidget(top_cb)
    checks.addStretch(1)
    ctrl.body.addLayout(checks)
    ctrl.body.addSpacing(2)

    btns = QHBoxLayout()
    btns.setSpacing(8)
    b_show = Btn("显示胶囊", "primary")
    b_show.clicked.connect(lambda: ctx.show_pill(True))
    b_hide = Btn("隐藏胶囊")
    b_hide.clicked.connect(lambda: ctx.show_pill(False))
    b_center = Btn("回到顶部居中")
    b_center.clicked.connect(lambda: (ctx.center_pill(), sync_knobs()))
    for b in (b_show, b_hide, b_center):
        btns.addWidget(b)
    btns.addStretch(1)
    btns.addWidget(lab("预设", 10.5, "FAINT"))
    for name, (w, h) in (("紧凑", (720, 52)), ("标准", (860, 60)), ("宽幅", (1060, 72))):
        b = Btn(name, "soft")
        b.clicked.connect(lambda _=False, w=w, h=h: (ctx.preset_pill(w, h), sync_knobs()))
        btns.addWidget(b)
    ctrl.body.addLayout(btns)
    page.add(ctrl)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 习题台
class QuestionList(QWidget):
    """题目索引：整张表自己画，只画看得见的那几行。

    以前每道题是一行控件（标签 ×4 + 按钮 + 容器），两百多题就是一千多个控件，
    建页面和换主题各要半秒多；现在是一个控件，滚动、筛选都只是重画。
    """

    ROW = 42

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.rows: list[dict] = []
        self.hover = -1
        self.empty_text = "这个科目还没有题目"
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_rows(self, rows: list[dict], empty_text: str = "") -> None:
        self.rows = rows
        self.hover = -1
        if empty_text:
            self.empty_text = empty_text
        self.setFixedHeight(max(self.ROW * len(rows), 96))
        self.update()

    def _at(self, y: float) -> int:
        i = int(y // self.ROW)
        return i if 0 <= i < len(self.rows) else -1

    def _row_rect(self, i: int) -> QRect:
        return QRect(0, i * self.ROW, self.width(), self.ROW)

    def _set_hover(self, i: int) -> None:
        if i != self.hover:
            old, self.hover = self.hover, i
            for k in (old, i):
                if k >= 0:
                    self.update(self._row_rect(k))
            self.setCursor(Qt.CursorShape.PointingHandCursor if i >= 0 else Qt.CursorShape.ArrowCursor)

    def mouseMoveEvent(self, e):  # noqa: N802
        self._set_hover(self._at(e.position().y()))

    def leaveEvent(self, _e):  # noqa: N802
        self._set_hover(-1)

    def mouseReleaseEvent(self, e):  # noqa: N802
        i = self._at(e.position().y())
        if e.button() == Qt.MouseButton.LeftButton and i >= 0:
            self.ctx.open_question(self.rows[i]["id"])

    def paintEvent(self, ev):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, R = self.width(), self.ROW
        if not self.rows:
            p.setFont(f(12))
            p.setPen(C.FAINT)
            p.drawText(self.rect(), int(Qt.AlignmentFlag.AlignCenter), self.empty_text)
            p.end()
            return
        f_subj, f_year, f_title, f_small, f_go = f(10.5, 700), serif(11.5, 500), f(12.5), f(10.5), f(11.5, 700)
        fm_title, fm_small = QFontMetricsF(f_title), QFontMetricsF(f_small)
        center = int(Qt.AlignmentFlag.AlignCenter)
        left = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        right = int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        first = max(0, ev.rect().top() // R)
        last = min(len(self.rows) - 1, ev.rect().bottom() // R)
        for i in range(first, last + 1):
            q = self.rows[i]
            y = i * R
            hot = i == self.hover
            if hot:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(C.KEYHOVER)
                p.drawRoundedRect(QRectF(0, y + 2, w, R - 4), 6, 6)
            elif i < len(self.rows) - 1 and i + 1 != self.hover:
                p.setPen(QPen(C.LINE2, 1))
                p.drawLine(QPointF(10, y + R - 0.5), QPointF(w - 10, y + R - 0.5))
            col = QColor(_subj_color(q["subject"]))
            chip = QRectF(10, y + (R - 20) / 2, 40, 20)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_tint(col, 0.13))
            p.drawRoundedRect(chip, 4, 4)
            p.setFont(f_subj)
            p.setPen(col)
            p.drawText(chip, center, q["subject"])
            p.setFont(f_year)
            p.setPen(C.FAINT)
            p.drawText(QRectF(62, y, 40, R), left, q["year"])
            go_w = 64
            paper_w = min(150.0, fm_small.horizontalAdvance(q["paper"]) + 4)
            title_w = max(60.0, w - 108 - paper_w - go_w - 22)
            p.setFont(f_title)
            p.setPen(C.INK)
            p.drawText(QRectF(108, y, title_w, R), left, fm_title.elidedText(q["title"], Qt.TextElideMode.ElideRight, title_w))
            p.setFont(f_small)
            p.setPen(C.FAINT)
            p.drawText(QRectF(w - go_w - 14 - paper_w, y, paper_w, R), right, q["paper"])
            if hot:
                p.setFont(f_go)
                p.setPen(C.INK2)
                p.drawText(QRectF(w - go_w - 6, y, go_w - 6, R), right, "解析 →")
            else:
                draw_icon(p, "chevron_r", QRectF(w - 28, y + (R - 14) / 2, 14, 14), C.FAINT, 1.4)
        p.end()


def build_studio(ctx) -> QWidget:
    qs = store.questions()
    subjects = []
    for q in qs:
        if q["subject"] and q["subject"] not in subjects:
            subjects.append(q["subject"])
    page = Page(ctx, "习题台 · 题目可视化", "习题台",
                f"{len(qs)} 题 · {store.bank_years()} 高考题")
    top = QHBoxLayout()
    top.setSpacing(8)
    for text, variant, fn in (("打开习题台", "primary", lambda: ctx.open_studio("")), ("随机一题", "", ctx.random_question),
                              ("导入题目", "", lambda: ctx.open_studio("", imp=True)),
                              ("格物实验台", "", lambda: ctx.goto("lab")), ("课件", "", lambda: ctx.open_web("lecture"))):
        b = Btn(text, variant)
        b.clicked.connect(lambda _=False, fn=fn: fn())
        top.addWidget(b)
    top.addStretch(1)
    top.addWidget(lab("一题一图，引导动画讲过程", 10.5, "FAINT"))
    page.add(top)

    state = {"cur": "全部", "text": ""}
    holder = Card("题目索引", "", pad=(12, 16, 12, 10))
    holder.head.setContentsMargins(8, 0, 8, 0)
    count = lab("", 10.5, "FAINT")
    holder.head.insertWidget(1, count, 0, Qt.AlignmentFlag.AlignBottom)
    listing = QuestionList(ctx)
    holder.add(listing)

    def fill():
        cur, text = state["cur"], state["text"].strip().lower()
        shown = [q for q in qs if (cur == "全部" or q["subject"] == cur)
                 and (not text or text in (q["title"] + " " + q["year"] + " " + q["paper"] + " " + q["subject"] + " " + q["stem"]).lower())]
        listing.set_rows(shown, "没有匹配的题目，换个关键词试试" if text else "这个科目还没有题目")
        count.setText(f"{len(shown)} 题" if len(shown) == len(qs) else f"{len(shown)} / {len(qs)} 题")

    chips = QHBoxLayout()
    chips.setSpacing(6)
    chip_widgets: list[Chip] = []

    def set_subject(name: str) -> None:
        state["cur"] = name
        for c in chip_widgets:
            c.setChecked(c.text() == name)
        fill()
        page.area.scroll_top()

    for name in ["全部"] + subjects:
        ch = Chip(name)
        ch.setChecked(name == "全部")
        ch.clicked.connect(lambda _=False, n=name: set_subject(n))
        chip_widgets.append(ch)
        chips.addWidget(ch)
    chips.addStretch(1)
    search = QLineEdit()
    search.setPlaceholderText("搜题目、年份、试卷")
    search.setClearButtonEnabled(True)
    search.setFixedWidth(220)
    search.textChanged.connect(lambda t: (state.__setitem__("text", t), fill()))
    chips.addWidget(search)
    page.add(chips)
    fill()
    page.add(holder)
    page.body.addStretch(1)
    page.question_list, page.search = listing, search
    return page


# ------------------------------------------------------------------ 设置
def _deepseek_card(ctx) -> Card:
    """格物实验台「题目导入」的 DeepSeek 密钥：存在数据目录的 deepseek.env，不进 config.json、不进网页。"""
    card = Card("DeepSeek 题目分析", "析题、课堂、导入题目时使用")
    ds = store.deepseek_settings()
    from_env = bool(os.environ.get("DEEPSEEK_API_KEY"))

    def describe(key: str) -> str:
        if from_env:
            return "当前密钥来自环境变量 DEEPSEEK_API_KEY（优先于这里填的）"
        if key:
            return f"已保存：{key[:3]}…{key[-4:]}　·　存放在 {store.DEEPSEEK_ENV}"
        return "未填写。没有密钥时，导入题目只能用关键词匹配粗选实验"

    status = label(describe(ds["key"]), 11, C.SOFT, wrap=True)
    edit = QLineEdit()
    edit.setEchoMode(QLineEdit.EchoMode.Password)
    edit.setPlaceholderText("sk-…（在 platform.deepseek.com 申请）")
    edit.setMinimumWidth(280)
    save = Btn("保存", "primary")
    test = Btn("测试连接")
    clear = Btn("清除", "danger")

    def do_save():
        key = edit.text().strip()
        if not key:
            ctx.toast("先粘贴密钥")
            return
        store.save_deepseek_key(key)
        edit.clear()
        status.setText(describe(key))
        ctx.toast("DeepSeek 密钥已保存")

    def do_clear():
        store.save_deepseek_key("")
        status.setText(describe(""))
        ctx.toast("已清除 DeepSeek 密钥")

    def do_test():
        cur = store.deepseek_settings()
        key = edit.text().strip() or cur["key"]
        if not key:
            ctx.toast("还没有密钥可测")
            return
        ctx.toast("正在连接 DeepSeek…")

        def work():
            import urllib.request
            try:
                req = urllib.request.Request(cur["base"] + "/models", headers={"Authorization": "Bearer " + key})
                with urllib.request.urlopen(req, timeout=15) as r:
                    ok = r.status == 200
                ctx.toast_sig.emit("DeepSeek 连接正常" if ok else "DeepSeek 返回异常")
            except Exception as exc:
                code = getattr(exc, "code", None)
                ctx.toast_sig.emit("密钥无效（401）" if code == 401 else f"连接失败：{exc}")

        import threading
        threading.Thread(target=work, daemon=True).start()

    save.clicked.connect(do_save)
    edit.returnPressed.connect(do_save)
    test.clicked.connect(do_test)
    clear.clicked.connect(do_clear)
    card.add(row(edit, save, test, clear, None))
    card.add(status)
    card.add(divider())
    timing_box = Check("记录析题本地耗时（仅时长与状态，不含题目、答案或密钥）")
    timing_box.setChecked(ctx.cfg.get("analysisTiming") is True)
    timing_box.toggled.connect(lambda value: (ctx.cfg.__setitem__("analysisTiming", value), ctx.save()))
    card.add(timing_box)
    return card


def build_settings(ctx) -> QWidget:
    page = Page(ctx, "见微 · 设置", "设置", "本地运行 · 不上传任何数据")

    def check(card, text, key, default=False, tip=""):
        cb = Check(text)
        cb.setChecked(bool(ctx.cfg.get(key, default)))
        cb.toggled.connect(lambda v, k=key: (ctx.cfg.__setitem__(k, v), ctx.save()))
        if tip:
            cb.setToolTip(tip)
        card.add(cb)
        return cb

    startup = Card("启动与托盘")
    cb1 = Check("开机自动启动（随 Windows 登录，静默驻留托盘）")
    cb1.setChecked(ctx.autostart_enabled())
    cb1.toggled.connect(ctx.set_autostart)
    startup.add(cb1)
    check(startup, "关闭窗口时最小化到托盘，而不是退出", "closeToTray", True)
    check(startup, "启动时直接进入托盘（不显示主窗口）", "startMinimized", False)
    check(startup, "空闲时预先备好学习窗口（第一次点开更快，多占一些内存）", "prewarmWeb", True,
          "关掉后少占一些内存；第一次打开习题台、实验台要多等一会儿")
    page.add(startup)

    daily = Card("每日节律", "由见微接管，不依赖原版观澜进程")
    check(daily, "启动时打开观澜浮窗（侧边窗口）", "showGuanlanOnStart", True)
    check(daily, "每天 07:15 自动更新世界线索", "autoFetch", True)
    check(daily, "每天 22:20 自动生成并全屏播放暮省", "autoEvening", True)
    scene_row = QHBoxLayout()
    scene_row.setSpacing(8)
    scene_row.addWidget(lab("暮省夜景", 11, "SOFT"))
    scene_box = Combo()
    for text, key in (("每晚轮换", "auto"), ("观澜 · 潮线", "tide"), ("远山 · 月下层峦", "ridge"), ("观星 · 星图", "stars"), ("灯下 · 一盏灯", "lamp"), ("月白 · 信笺", "moon")):
        scene_box.addItem(text, key)
    scene_box.setCurrentIndex(max(0, scene_box.findData(str(ctx.cfg.get("eveningTheme", "auto")))))
    scene_box.currentIndexChanged.connect(lambda _i: (ctx.cfg.__setitem__("eveningTheme", scene_box.currentData()), ctx.save()))
    scene_row.addWidget(scene_box)
    scene_row.addWidget(lab("山形、潮线和星位每晚都不一样；选好后点「现在生成暮省」能直接看", 10.5, "FAINT"))
    scene_row.addStretch(1)
    daily.add(scene_row)
    acts = QHBoxLayout()
    acts.setSpacing(8)
    b_now = Btn("现在生成暮省")
    b_now.clicked.connect(ctx.evening)
    b_fetch = Btn("现在就抓取")
    b_fetch.clicked.connect(ctx.refresh_guanlan)
    acts.addWidget(b_now)
    acts.addWidget(b_fetch)
    acts.addStretch(1)
    daily.add(acts)
    page.add(daily)

    page.add(_deepseek_card(ctx))

    data = Card("数据与题库")
    data.add(label(f"数据目录：{store.HOME}", 11, C.SOFT, wrap=True))
    qs = store.questions()
    data.add(label(f"本地题库：{len(qs)} 题（{store.bank_years()} 高考题）。题目可视化在本机运行，不联网。",
                   11, C.SOFT, wrap=True))
    btns = QHBoxLayout()
    btns.setSpacing(8)
    open_dir = Btn("打开数据目录")
    open_dir.clicked.connect(lambda: subprocess.Popen(["explorer", str(store.HOME)]))
    rescan = Btn("重新扫描题库")
    rescan.clicked.connect(ctx.rescan_bank)

    def import_1x():
        from native.data_import import run_once
        ctx.toast(run_once(force=True) or "没有找到可导入的 1.x 记录（先运行一次 1.7，它会导出记录）")
    imp1 = Btn("从 1.x 导入记录")
    imp1.clicked.connect(import_1x)
    btns.addWidget(open_dir)
    btns.addWidget(rescan)
    btns.addWidget(imp1)
    from native.backup_ui import controls as backup_controls
    before = btns.count()
    backup_controls(ctx, btns)
    for i in range(before, btns.count()):     # 备份的两个键是学习窗口那套样式：换成主窗口的按键
        b = btns.itemAt(i).widget()
        if isinstance(b, QPushButton):
            b.setStyleSheet("")
            b.setObjectName("btn")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFont(f(12))
    btns.addStretch(1)
    data.add(btns)
    page.add(data)

    about = Card("关于")
    about.add(label(f"见微 · 高考学习舱　v{store.VERSION}", 13, C.INK, 600))
    about.add(label("一个托盘，几件每天用得上的事：观澜（每日世界线索与暮省）、时间胶囊（桌面上的一把时间尺）、"
                    "习题台（真题可视化）、实验台（四科实验与自由工作台）、析题（AI 读题、程序复算）、课件与课堂。"
                    "界面是「青瓷仪器」：墨绿窄栏、朱砂印、冷瓷面板，读数用等高的仪表数字。", 11.5, C.SOFT, wrap=True))
    page.add(about)
    page.body.addStretch(1)
    return page
