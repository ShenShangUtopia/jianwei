"""见微 · 主壳：无边框纸面窗 + 左侧导航 + 托盘。"""
from __future__ import annotations

import os
import sys
import threading
from datetime import datetime

from PySide6.QtCore import (QEasingCurve, QPoint, QPointF, QPropertyAnimation, QRectF, Qt, QTimer,
                            QVariantAnimation, Signal)
from PySide6.QtGui import QAction, QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QHBoxLayout, QLabel, QMenu, QPushButton, QStackedWidget, QSystemTrayIcon,
    QVBoxLayout, QWidget,
)

import pages
import store
import guanlan_host
from countdown import CountdownPill

from native.design.icons import draw_icon  # noqa: F401
from native.design.tokens import T
from native.design import ux
from native.design.widgets import IconButton, RailButton, paint_seal
from ui_kit import C, f


def _theme() -> str:
    import ui_kit
    return ui_kit.theme()

NAV = [
    ("today", "今日"),
    ("guanlan", "观澜"),
    ("countdown", "倒计时"),
    ("studio", "习题台"),
    ("lab", "实验室"),
    ("settings", "设置"),
]


class RailCountdown(QWidget):
    """窄栏底部：距考天数 + 学期刻度，一眼可见（每分钟刷新）。"""

    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        self.setFixedHeight(92)
        self._t = QTimer(self)
        self._t.timeout.connect(self.update)
        self._t.start(60_000)
        self.setToolTip("高考倒计时 · 在「倒计时」页可调")

    def paintEvent(self, _ev) -> None:
        from ui_kit import serif
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        now = datetime.now()
        target, start = store.target_dt(self.cfg), store.start_dt(self.cfg)
        secs = max(0.0, (target - now).total_seconds())
        frac = min(1.0, max(0.0, 1 - secs / max(1.0, (target - start).total_seconds())))
        x, w = 14, self.width() - 28
        p.setPen(QColor(T.railfg))
        p.setFont(f(10.5, 500, 1.0))
        p.drawText(QRectF(x, 0, w, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   f"距 {self.cfg.get('year', '2027')} {self.cfg.get('label', '高考')}")
        num = str(int(secs // 86400))
        p.setFont(serif(32, 600))
        p.setPen(QColor(T.railon))
        fm = p.fontMetrics()
        p.drawText(QPointF(x, 54), num)
        p.setFont(f(12, 500))
        p.setPen(QColor(T.railfg))
        p.drawText(QPointF(x + fm.horizontalAdvance(num) + 6, 54), "天")
        # 刻度尺：走过的部分亮，当前位置一道朱砂
        n, y = 34, 68
        for i in range(n):
            cx = x + i * w / (n - 1)
            passed = i / (n - 1) <= frac
            p.setPen(QPen(QColor(T.railon if passed else T.rail2), 1))
            p.drawLine(QPointF(cx, y), QPointF(cx, y + (10 if i % 5 == 0 else 6)))
        p.setPen(QPen(QColor(T.brand), 2))
        cx = x + frac * w
        p.drawLine(QPointF(cx, y - 3), QPointF(cx, y + 13))
        p.end()


class _Seal(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(36, 36)

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        paint_seal(p, QRectF(self.rect()))
        p.end()


class _EdgeGrip(QWidget):
    """窗口边缘的一条隐形把手：按下交给系统改大小（无边框窗口自己不会有这个）。"""

    def __init__(self, parent, edges, cursor):
        super().__init__(parent)
        self.edges = edges
        self.setCursor(cursor)

    def mousePressEvent(self, ev) -> None:
        handle = self.window().windowHandle()
        if ev.button() == Qt.MouseButton.LeftButton and handle is not None:
            handle.startSystemResize(self.edges)


class _PageFade(QWidget):
    """切页时的一层过渡：把旧页面的截图盖在新页面上，淡出并略微上移。

    只是每帧贴一张图（不用 QGraphicsOpacityEffect —— 那会让整页每帧离屏重画），不拦鼠标。
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._pm: QPixmap | None = None
        self._k = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(150)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.setStartValue(1.0)
        self._anim.setEndValue(0.0)
        self._anim.valueChanged.connect(self._step)
        self._anim.finished.connect(self._done)
        self.hide()

    def play(self, pm: QPixmap) -> None:
        self._anim.stop()
        self._pm, self._k = pm, 1.0
        self.setGeometry(self.parentWidget().rect())
        self.show()
        self.raise_()
        self._anim.start()

    def _step(self, v) -> None:
        self._k = float(v)
        self.update()

    def _done(self) -> None:
        self._pm = None
        self.hide()

    def paintEvent(self, _ev) -> None:
        if self._pm is None:
            return
        p = QPainter(self)
        p.setOpacity(self._k)
        p.fillRect(self.rect(), C.PAPER)    # 先垫一层纸底：旧页完整盖住新页再淡出，两页的字不会叠在一起
        p.drawPixmap(0, int(-(1 - self._k) * 8), self._pm)
        p.end()


class Shell(QWidget):
    toast_sig = Signal(str)
    guanlan_done = Signal()     # 后台线程抓完今日版，回到界面线程换内容

    def __init__(self, tray_enabled: bool = True, start_page: str = "today",
                 jobs_enabled: bool = True):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("见微 · 高考学习舱")
        self.setMinimumSize(980, 640)
        self.resize(1180, 780)
        ux.install()

        self.cfg = store.load_config()
        geo = self.cfg.get("shellGeom")
        if isinstance(geo, list) and len(geo) == 4:
            self.setGeometry(self._on_screen(*[int(v) for v in geo]))
        self.pill: CountdownPill | None = None
        self.guanlan = guanlan_host.GuanlanHost()
        self.guanlan.on_material=self.collect_material
        self.guanlan.set_theme(_theme())
        self._native = None  # 学习窗口（习题台 · 实验台 · 工作台 · 析题），第一次打开时才建
        self._drag: QPoint | None = None
        self._tray: QSystemTrayIcon | None = None
        self._page_index = {k: i for i, (k, _) in enumerate(NAV)}
        self._builders = {"today": pages.build_overview, "guanlan": pages.build_guanlan, "countdown": pages.build_countdown,
                          "studio": pages.build_studio, "lab": pages.build_lab, "settings": pages.build_settings}
        self._built: set[str] = set()       # 已经建好、且没过期的页面
        self._day = datetime.now().date()   # 过了零点，带日期的页面要重建
        self._save_timer = QTimer(self)     # 拖滑块时每一格都会来存配置：攒到停手再写盘
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(350)
        self._save_timer.timeout.connect(self.save)

        self._build()
        E, C_ = Qt.Edge, Qt.CursorShape
        self._grips = [(_EdgeGrip(self, E.RightEdge, C_.SizeHorCursor), "r"), (_EdgeGrip(self, E.BottomEdge, C_.SizeVerCursor), "b"),
                       (_EdgeGrip(self, E.RightEdge | E.BottomEdge, C_.SizeFDiagCursor), "c"),
                       (_EdgeGrip(self, E.LeftEdge, C_.SizeHorCursor), "l"), (_EdgeGrip(self, E.TopEdge, C_.SizeVerCursor), "t")]
        self._toast_timer = QTimer(self)
        self._toast_timer.setSingleShot(True)
        self._toast_timer.timeout.connect(self._toast.hide)
        if tray_enabled:
            self._build_tray()
        self.toast_sig.connect(self._show_toast)
        self.guanlan_done.connect(self._guanlan_updated)

        self._clock = QTimer(self)
        self._clock.timeout.connect(self._refresh_clock)
        self._clock.start(30000)
        self._sync_pill_reserve()    # 旧配置里残留的让位值清一次就够了（以前每 4 秒查一遍）

        self.goto(start_page)
        if self.cfg.get("showPill"):
            QTimer.singleShot(600, lambda: self.show_pill(True, quiet=True))
        if self.cfg.get("showGuanlanOnStart", True):
            QTimer.singleShot(900, self._open_guanlan_once)
        if jobs_enabled:
            self._setup_daily_jobs()
            # 等启动时的观澜浮窗、胶囊都起来、机器空下来再热（开机自启时也不和登录抢资源）
            QTimer.singleShot(12_000, self.prewarm_web)
        self._setup_panel_hotkey()

    # ------------------------------------------------------------ 常驻节律
    def _setup_daily_jobs(self) -> None:
        import scheduler
        self.jobs = scheduler.DailyJobs(self.guanlan, self.cfg, self.save, self)
        self.jobs.toast.connect(self.toast_sig.emit)
        self.jobs.fetch_done.connect(self._guanlan_updated)

    def _setup_panel_hotkey(self) -> None:
        """把观澜原有的 Alt+Shift+G 收进见微；原版在跑时注册会失败，不报错。"""
        self._hotkey = None
        try:
            self.guanlan._ensure_path()
            from ui.window import HotkeyFilter  # type: ignore
            filt = HotkeyFilter(self.toggle_guanlan)
            if filt.install():
                self._hotkey = filt
        except Exception:
            self._hotkey = None

    def _open_guanlan_once(self) -> None:
        if not self.guanlan.is_visible() and self.guanlan.show():
            self.cfg["showGuanlan"] = True
            self._sync_pill_reserve()

    def _sync_pill_reserve(self) -> None:
        """胶囊固定屏幕居中；这个钩子保留，用于把旧配置里残留的让位值清掉。"""
        reserve = 0
        if self.cfg.get("pillReserveRight") != reserve:
            self.cfg["pillReserveRight"] = reserve
            if self.pill is not None and self.pill.isVisible():
                self.pill.apply_config(self.cfg)

    # ------------------------------------------------------------ 结构
    def _build(self) -> None:
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._rail())

        self.surface = QWidget()
        self.surface.setObjectName("surface")
        self.surface.setStyleSheet("#surface{background:transparent;}")
        outer.addWidget(self.surface, 1)

        lay = QVBoxLayout(self.surface)
        lay.setContentsMargins(0, 0, 8, 8)
        lay.setSpacing(0)
        lay.addWidget(self._titlebar())
        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)
        self._build_pages()

        self._fade = _PageFade(self.stack)

        self._toast = QLabel(self.surface)
        self._toast.setFont(f(11.5))
        self._toast.setStyleSheet(f"background:{T.fg};color:{T.stage};border-radius:6px;padding:8px 16px;")
        self._toast.hide()
        self._toast_anim = QPropertyAnimation(self._toast, b"pos", self)
        self._toast_anim.setDuration(180)
        self._toast_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def _titlebar(self) -> QWidget:
        bar = QWidget()
        bar.setFixedHeight(44)
        bar.mousePressEvent = self._bar_press
        bar.mouseMoveEvent = self._bar_move
        bar.mouseReleaseEvent = self._bar_release
        bar.mouseDoubleClickEvent = self._bar_double
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(30, 0, 4, 0)
        lay.setSpacing(4)
        self.clock_label = QLabel()
        self.clock_label.setFont(f(11, 500, 0.6))
        self.clock_label.setStyleSheet(f"color:{C.FAINTH};background:transparent;")
        lay.addWidget(self.clock_label, 0, Qt.AlignmentFlag.AlignVCenter)
        lay.addStretch(1)
        self.theme_btn = IconButton("moon" if _theme() == "day" else "sun", "切换白天 / 夜晚配色", 30)
        self.theme_btn.clicked.connect(self.toggle_theme)
        lay.addWidget(self.theme_btn)
        lay.addSpacing(4)
        for icon, slot, tip in (("min", self.showMinimized, "最小化"),
                                ("close", self._close_clicked, "关闭")):
            b = IconButton(icon, tip, 30)
            b.clicked.connect(slot)
            lay.addWidget(b)
        self._refresh_clock()
        return bar

    def _rail(self) -> QWidget:
        rail = QWidget()
        rail.setFixedWidth(196)
        rail.mousePressEvent = self._bar_press
        rail.mouseMoveEvent = self._bar_move
        rail.mouseReleaseEvent = self._bar_release
        lay = QVBoxLayout(rail)
        lay.setContentsMargins(10, 16, 10, 16)
        lay.setSpacing(3)
        head = QHBoxLayout()
        head.setContentsMargins(6, 0, 0, 0)
        head.setSpacing(10)
        head.addWidget(_Seal())
        brand = QVBoxLayout()
        brand.setSpacing(0)
        name = QLabel("见微")
        name.setFont(f(16, 700, 3))
        name.setStyleSheet("color:white;background:transparent;")   # 窄栏昼夜都是深色，不走配色映射
        sub = QLabel("高考学习舱")
        sub.setFont(f(10.5, 500, 1.2))
        sub.setStyleSheet(f"color:{T.railfg};background:transparent;")
        self._rail_sub = sub
        brand.addWidget(name)
        brand.addWidget(sub)
        head.addLayout(brand, 1)
        lay.addLayout(head)
        lay.addSpacing(18)
        self.nav_buttons: list[QPushButton] = []
        for key, text in NAV:
            b = RailButton(key, text, compact=False, height=40)
            b.setAutoExclusive(True)
            b.setProperty("navKey", key)
            b.clicked.connect(lambda _=False, k=key: self.goto(k))
            lay.addWidget(b)
            self.nav_buttons.append(b)
        lay.addStretch(1)
        self.rail_count = RailCountdown(self.cfg)
        lay.addWidget(self.rail_count)
        return rail

    def _refresh_nav_icons(self) -> None:
        """窄栏的键自己按令牌画，换主题时重画一次即可。"""
        for b in getattr(self, "nav_buttons", []):
            b.update()
        sub = getattr(self, "_rail_sub", None)
        if sub is not None:
            sub.setStyleSheet(f"color:{T.railfg};background:transparent;")

    def _build_pages(self) -> None:
        """让所有页面过期：正在看的那一页马上重建，其余等点到再建。

        以前这里一次建六页（换主题、重扫题库、启动都要等一秒多）；现在启动只建「今日」。
        """
        if self.stack.count() == 0:
            for _key, _ in NAV:
                self.stack.addWidget(QWidget())     # 占位，点到时换成真页面
        self._built.clear()
        first = self.tab if hasattr(self, "tab") else "today"
        self.tab = first
        self.goto(first, animate=False)

    def _ensure_page(self, key: str) -> None:
        if key in self._built:
            return
        import ui_kit
        i = self._page_index[key]
        page = self._builders[key](self)
        ui_kit.restyle_tree(page)
        old = self.stack.widget(i)
        current = self.stack.currentIndex() == i
        self.stack.removeWidget(old)
        old.hide()
        old.deleteLater()
        self.stack.insertWidget(i, page)
        if current:
            self.stack.setCurrentIndex(i)
        self._built.add(key)

    def _drop_pages(self) -> None:
        """把建好的页面立刻拆掉、换回占位（换主题前用）。

        换主题要给整个应用重设样式表，Qt 会把每个活着的控件重新抛光一遍；
        这些页面反正要按新配色重建，先拆掉就不用白抛一次。
        """
        from shiboken6 import delete
        for key in list(self._built):
            i = self._page_index[key]
            old = self.stack.widget(i)
            self.stack.removeWidget(old)
            self.stack.insertWidget(i, QWidget())
            old.setParent(None)
            delete(old)
        self._built.clear()
        self.stack.setCurrentIndex(self._page_index.get(getattr(self, "tab", "today"), 0))

    def refresh_pages(self, keys=("today", "guanlan")) -> None:
        """数据变了（观澜更新、换了一天……）：这几页过期；正在看的话马上重建，停在原处。"""
        self._built.difference_update(keys)
        if self.tab in keys:
            self.goto(self.tab, animate=False)

    # ------------------------------------------------------------ 主题
    def toggle_theme(self) -> None:
        import ui_kit
        nxt = "night" if ui_kit.theme() == "day" else "day"
        ui_kit.apply_theme(nxt)
        self.cfg["theme"] = nxt
        self.save()
        self._drop_pages()
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(ui_kit.qss())
        self.theme_btn.icon = "moon" if nxt == "day" else "sun"
        self.theme_btn.update()
        self._refresh_nav_icons()
        self.rail_count.update()
        self.clock_label.setStyleSheet(f"color:{C.FAINTH};background:transparent;")
        self._build_pages()
        self.update()
        if self._native is not None:
            self._native.set_theme(nxt)
        self.guanlan.set_theme(nxt)
        for w in (self.surface,):
            w.style().unpolish(w)
            w.style().polish(w)
            w.update()

    # ------------------------------------------------------------ 绘制
    def paintEvent(self, _ev) -> None:
        # 纸底只随尺寸 / 主题变化：缓存成图。按钮悬停、滚动、提示条这些局部重绘都会落到这里，
        # 以前每次都要重算四个大径向渐变
        dpr = self.devicePixelRatioF()
        key = (self.width(), self.height(), round(dpr, 3), _theme())
        if getattr(self, "_bg_key", None) != key:
            pm = QPixmap(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
            pm.setDevicePixelRatio(dpr)
            pm.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pm)
            self._paint_bg(painter)
            painter.end()
            self._bg, self._bg_key = pm, key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._bg)
        p.end()

    def _paint_bg(self, p: QPainter) -> None:
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        path = QPainterPath()
        path.addRoundedRect(rect, 9, 9)
        p.fillPath(path, C.PAPER)
        # 左侧墨绿窄栏：见微的识别，昼夜都是深色
        p.save()
        p.setClipPath(path)
        p.fillRect(QRectF(0, 0, 196, self.height()), QColor(T.rail))
        p.restore()
        p.setPen(QPen(C.WINDOW_LINE, 1))
        p.drawPath(path)

    # ------------------------------------------------------------ 导航
    def goto(self, key: str, animate: bool = True) -> None:
        import ui_kit
        key = key if key in self._page_index else "today"
        i = self._page_index[key]
        fade = getattr(self, "_fade", None)
        snap = None
        if (animate and fade is not None and i != self.stack.currentIndex() and self.isVisible()
                and not self.isMinimized() and ui_kit.motion()):
            snap = self.stack.grab()        # 旧页面的样子：盖在新页面上淡出
        self.tab = key
        self._ensure_page(key)
        self.stack.setCurrentIndex(i)
        for b, (k, _) in zip(self.nav_buttons, NAV):
            b.setChecked(k == key)
        if snap is not None:
            fade.play(snap)
        self.raise_()

    # ------------------------------------------------------------ 窗口
    def _bar_press(self, ev) -> None:
        if ev.button() == Qt.MouseButton.LeftButton:
            # 交给系统拖动：拖到屏幕边能贴边、拖到顶能最大化
            handle = self.windowHandle()
            if handle is not None and handle.startSystemMove():
                return
            self._drag = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def _bar_double(self, _ev) -> None:
        self.showNormal() if self.isMaximized() else self.showMaximized()

    @staticmethod
    def _on_screen(x: int, y: int, w: int, h: int):
        """上次的位置还在某块屏幕上才用，否则放回主屏。"""
        from PySide6.QtCore import QRect
        from PySide6.QtGui import QGuiApplication
        rect = QRect(x, y, max(980, w), max(640, h))
        for screen in QGuiApplication.screens():
            if screen.availableGeometry().intersects(rect.adjusted(40, 0, -40, -rect.height() + 40)):
                return rect
        geo = QGuiApplication.primaryScreen().availableGeometry()
        return QRect(geo.x() + 40, geo.y() + 40, min(rect.width(), geo.width() - 80), min(rect.height(), geo.height() - 80))

    def resizeEvent(self, ev) -> None:
        super().resizeEvent(ev)
        w, h, m = self.width(), self.height(), 5
        for grip, where in getattr(self, "_grips", []):
            grip.setGeometry(*{"r": (w - m, 12, m, h - 24), "b": (12, h - m, w - 24, m), "c": (w - 12, h - 12, 12, 12),
                               "l": (0, 12, m, h - 24), "t": (12, 0, w - 24, m)}[where])
            grip.setVisible(not self.isMaximized())
            grip.raise_()

    def showEvent(self, ev) -> None:
        super().showEvent(ev)
        import ui_kit
        if ev.spontaneous() or not ui_kit.motion():
            return      # 从任务栏还原是系统自己的动画；自测截图时不放
        # 从托盘 / 胶囊唤出来时淡入，不是整块突然贴到屏幕上
        self.setWindowOpacity(0.0)
        anim = QPropertyAnimation(self, b"windowOpacity", self)
        anim.setDuration(170)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._appear = anim
        anim.start()

    def _remember_geometry(self) -> None:
        if not self.isMaximized():
            g = self.geometry()
            self.cfg["shellGeom"] = [g.x(), g.y(), g.width(), g.height()]
            self.save()

    def _bar_move(self, ev) -> None:
        if self._drag is not None:
            self.move(ev.globalPosition().toPoint() - self._drag)

    def _bar_release(self, _ev) -> None:
        self._drag = None

    def _close_clicked(self) -> None:
        self._remember_geometry()
        if self.cfg.get("closeToTray", True) and self._tray is not None:
            self.hide()
        else:
            self.quit_app()

    def closeEvent(self, ev) -> None:
        if self.cfg.get("closeToTray", True) and self._tray is not None:
            ev.ignore()
            self.hide()
            return
        self.quit_app()
        ev.accept()

    def quit_app(self) -> None:
        from shiboken6 import isValid
        inspector=getattr(self,'_backup_inspector',None)
        if inspector is not None and isValid(inspector) and inspector.isRunning():
            self.toast('备份校验尚未结束，请稍候再退出')
            return
        try:
            if self._save_timer.isActive():
                self.save()
            if self.pill:
                self.pill.close()
            if self._native is not None:
                self._native.shutdown()
                self._native.close()
            if getattr(self, "_hotkey", None) is not None:
                self._hotkey.remove()
            self.guanlan.hide()
        except Exception:
            pass
        QApplication.instance().quit()

    def _refresh_clock(self) -> None:
        now = datetime.now()
        self.clock_label.setText(f"{now:%Y.%m.%d} 周{'一二三四五六日'[now.weekday()]} {now:%H:%M}")
        if now.date() != self._day:
            # 见微常驻托盘，会开着过夜：过了零点，今日一题、天数、日期这些要换成新一天的
            self._day = now.date()
            self.refresh_pages()

    # ------------------------------------------------------------ 托盘
    def _build_tray(self) -> None:
        self._tray = QSystemTrayIcon(self._make_icon(), self)
        self._tray.setToolTip("见微 · 高考学习舱")
        menu = QMenu()
        import ui_kit
        menu.setStyleSheet(ui_kit._swap(
            "QMenu{background:#FFFFFF;color:#081F5C;border:1px solid #E6EAF1;padding:6px;}"
            "QMenu::item{padding:6px 26px 6px 16px;border-radius:3px;font-size:12px;}"
            "QMenu::item:selected{background:#F2F5FB;}"
            "QMenu::separator{height:1px;background:#EDF0F6;margin:4px 8px;}"))
        for text, fn in (("打开见微", self._tray_show),
                         ("观澜浮窗", self.toggle_guanlan),
                         ("倒计时胶囊", self.toggle_pill),
                         ("习题台", lambda: self.open_studio("")),
                         ("格物实验台", lambda: self.open_lab("")),
                         ("课件", lambda: self.open_web("lecture")),
                         ("桌面悬浮工具栏", self.toggle_desktop_tools),
                         ("暮省全屏", self.evening),
                         ("立即更新内容", self.refresh_guanlan)):
            a = QAction(text, self)
            a.triggered.connect(fn)
            menu.addAction(a)
        menu.addSeparator()
        quit_action = QAction("退出见微", self)
        quit_action.triggered.connect(self.quit_app)
        menu.addAction(quit_action)
        self._tray.setContextMenu(menu)
        self._tray.activated.connect(
            lambda r: self._tray_show() if r in (QSystemTrayIcon.ActivationReason.Trigger,
                                                 QSystemTrayIcon.ActivationReason.DoubleClick) else None)
        self._tray.show()

    def _tray_show(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def toggle_desktop_tools(self):
        from native.kit.desktop_tools import toggle_desktop_tools
        toggle_desktop_tools()

    def _make_icon(self) -> QIcon:
        pm = QPixmap(64, 64)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        paint_seal(p, QRectF(4, 4, 56, 56))
        p.end()
        return QIcon(pm)

    # ------------------------------------------------------------ 提示
    def toast(self, text: str) -> None:
        self.toast_sig.emit(text)

    def _show_toast(self, text: str) -> None:
        import ui_kit
        fresh = not self._toast.isVisible()
        self._toast.setText(text)
        self._toast.setStyleSheet(f"background:{T.fg};color:{T.stage};border-radius:6px;padding:8px 16px;")
        self._toast.adjustSize()
        end = QPoint(max(16, (self.surface.width() - self._toast.width()) // 2), self.surface.height() - 56)
        self._toast_anim.stop()
        self._toast.show()
        self._toast.raise_()
        if fresh and ui_kit.motion() and self.isVisible():   # 新出现的从下面滑上来一点；连续提示只换字
            self._toast.move(end + QPoint(0, 14))
            self._toast_anim.setStartValue(end + QPoint(0, 14))
            self._toast_anim.setEndValue(end)
            self._toast_anim.start()
        else:
            self._toast.move(end)
        self._toast_timer.start(2400)   # 连续提示时重新计时，不会被上一条的定时器提前关掉

    # ------------------------------------------------------------ 配置
    def save(self) -> None:
        self._save_timer.stop()
        store.save_config(self.cfg)

    def save_soon(self) -> None:
        """稍后保存：连续的改动（拖滑块）合成一次写盘。退出、隐藏前会补存。"""
        self._save_timer.start()

    def apply_pill(self, now: bool = False) -> None:
        """把配置应用到桌面胶囊。now=False 时稍后再存盘（滑块拖动用），一次性的操作传 now=True。"""
        if now:
            self.save()
        else:
            self.save_soon()
        if self.pill is not None and self.pill.isVisible():
            self.pill.apply_config(self.cfg)

    def preset_pill(self, w: int, h: int) -> None:
        self.cfg["width"], self.cfg["height"] = w, h
        self.apply_pill(now=True)
        self.toast(f"已切换 {w}×{h}")

    def center_pill(self) -> None:
        self.cfg["pillX"] = None
        self.apply_pill(now=True)
        self.toast("已回到顶部居中")

    def show_pill(self, on: bool, quiet: bool = False) -> None:
        if on:
            if self.pill is None:
                self.pill = CountdownPill(self.cfg)
                self.pill.moved.connect(self._pill_moved)
                self.pill.action.connect(self._pill_action)
            self.pill.apply_config(self.cfg)
            self.pill.show()
            self.pill.raise_()
            self.cfg["showPill"] = True
        else:
            if self.pill is not None:
                self.pill.hide()
            self.cfg["showPill"] = False
        self.save()
        if not quiet:
            self.toast("胶囊已显示" if on else "胶囊已隐藏")

    def _pill_moved(self, x, top: int) -> None:
        """胶囊拖到哪就记到哪，下次启动还在那里。"""
        self.cfg["pillX"] = x
        self.cfg["marginTop"] = top
        self.save()

    def _pill_action(self, key: str) -> None:
        if key == "open":
            self._tray_show()
        elif key == "guanlan":
            self.toggle_guanlan()
        elif key == "studio":
            self.open_studio("")
        elif key == "settings":
            self._tray_show()
            self.goto("countdown")
        elif key == "hide":
            self.show_pill(False)
        elif key == "center":
            self.center_pill()
        elif key == "top":
            self.cfg["zorder"] = "bottom" if str(self.cfg.get("zorder", "bottom")) == "top" else "top"
            self.apply_pill(now=True)
            self._built.discard("countdown")    # 倒计时页上的勾选框要跟着变：下次点到时重建
        elif key == "seconds":
            self.cfg["showSeconds"] = not self.cfg.get("showSeconds", True)
            self.apply_pill(now=True)
            self._built.discard("countdown")

    def toggle_pill(self) -> None:
        self.show_pill(not (self.pill is not None and self.pill.isVisible()))

    # ------------------------------------------------------------ 模块
    def toggle_guanlan(self) -> None:
        self.cfg["showGuanlan"] = self.guanlan.toggle()
        self.save()
        QTimer.singleShot(120, self._sync_pill_reserve)
        self.toast("观澜浮窗已打开" if self.cfg["showGuanlan"] else "观澜浮窗已收起")

    def evening_archive(self) -> None:
        """重播往期：只有 2.0 生成的期数能播；1.x 的 .html 还在「晚间暮省」文件夹里，可以直接打开。"""
        from PySide6.QtWidgets import QInputDialog
        self.guanlan._ensure_home()
        self.guanlan._ensure_path()
        from core.evening import archived_dates  # type: ignore
        dates = archived_dates()
        if not dates:
            self.toast("还没有往期：播过一次之后这里才有")
            return
        d, ok = QInputDialog.getItem(self, "往期暮省", "选一期重播", dates, 0, False)
        if ok and d:
            self.guanlan.evening(d)

    def evening(self) -> None:
        self.guanlan.evening()
        self.toast("正在生成今晚的暮省页")

    def _guanlan_updated(self) -> None:
        """今日版换了：浮窗就地换内容，主窗口的「今日」「观澜」两页也跟着换（以前要重启才看得到）。"""
        self.guanlan.reload()
        self.refresh_pages()

    def refresh_guanlan(self) -> None:
        def work():
            try:
                self.guanlan._ensure_home()
                self.guanlan._ensure_path()
                from core.curator import run as run_curator  # type: ignore
                run_curator(force=True, log_fn=lambda *_: None)
                self.guanlan_done.emit()
                self.toast_sig.emit("观澜内容已更新")
            except Exception as exc:
                self.toast_sig.emit(f"更新失败：{exc}")
        self.toast("正在更新观澜内容…")
        threading.Thread(target=work, daemon=True).start()

    def open_studio(self, qid: str = "", lab: bool = False, mode: str = "", imp: bool = False) -> None:
        if lab:
            self.open_web("lab", mode=mode)
        else:
            self.open_web("studio", qid=qid, imp=imp)

    def collect_material(self,payload):
        from native.kit.composition import collect
        return collect(self.native_window().clip_bus,payload)

    def native_window(self):
        if self._native is None:
            import ui_kit
            from native.data_import import run_once
            msg = run_once()   # 题库读入之前先导入 1.x 的记录，一启动就点开也能看到
            if msg:
                self.toast(msg)
            from native.main_win import NativeWindow
            self._native = NativeWindow("night" if ui_kit.theme() == "night" else "day")
        return self._native

    def open_web(self, key: str, qid: str = "", mode: str = "", imp: bool = False) -> None:
        """习题台、实验台、工作台、析题都在原生窗口里打开（不依赖网页与浏览器内核）。"""
        try:
            w = self.native_window()
            if key == "import":
                w.open_lab("import")
            elif key == "bench":
                w.open_lab(f"bench/{mode}" if mode else "bench")
            elif key == "lab":
                w.open_lab(mode)
            elif key == "lecture":
                w.open_lecture()
            elif key == "classroom":
                w.goto("classroom")
                w.present()
            elif imp:
                w.open_import()
            else:
                w.open_question(qid)
        except Exception as exc:  # noqa: BLE001  打不开也要有交代：记日志并提示
            import traceback
            try:
                (store.HOME / "logs").mkdir(parents=True, exist_ok=True)
                with open(store.HOME / "logs" / "app.log", "a", encoding="utf-8") as fh:
                    fh.write(traceback.format_exc() + "\n")
            except Exception:
                pass
            self.toast(f"打开失败：{exc}")

    def prewarm_web(self) -> None:
        """空闲时先导入数据、备好学习窗口，第一次点开不用等。"""
        try:
            from native.data_import import run_once
            msg = run_once()
            if msg:
                self.toast(msg)
            if self.cfg.get("prewarmWeb", True):
                self.native_window()
        except Exception:
            import traceback
            traceback.print_exc()

    def open_lab(self, mode: str = "") -> None:
        self.open_studio("", lab=True, mode=mode)

    def open_question(self, qid: str) -> None:
        self.open_studio(qid)

    def random_question(self) -> None:
        import random
        qs = store.questions()
        if not qs:
            self.toast("题库为空")
            return
        q = random.choice(qs)
        self.open_studio(q["id"])
        self.toast(f"{q['subject']} · {q['title']}")

    def rescan_bank(self) -> None:
        store._QS = None
        self.refresh_pages(("today", "studio", "settings"))
        n = len(store.questions())
        self.toast(f"题库已重扫：{n} 题")

    # ------------------------------------------------------------ 自启
    def autostart_enabled(self) -> bool:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_READ)
            try:
                winreg.QueryValueEx(key, "JianweiSuite")
                return True
            finally:
                winreg.CloseKey(key)
        except Exception:
            return False

    def set_autostart(self, on: bool) -> None:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
            if on:
                exe = sys.executable
                if getattr(sys, "frozen", False):
                    cmd = f'"{exe}" --background'
                else:
                    cmd = f'"{exe}" "{os.path.join(os.path.dirname(__file__), "main.py")}" --background'
                winreg.SetValueEx(key, "JianweiSuite", 0, winreg.REG_SZ, cmd)
            else:
                try:
                    winreg.DeleteValue(key, "JianweiSuite")
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
            self.toast("开机自启已开启" if on else "开机自启已关闭")
        except Exception as exc:
            self.toast(f"设置失败：{exc}")
