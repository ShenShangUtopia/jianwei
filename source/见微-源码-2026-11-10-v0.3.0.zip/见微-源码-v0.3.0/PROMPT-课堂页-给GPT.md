# 给 GPT：见微「课堂」页（OpenMAIC 整合 · 界面这一份）

2026-11-09。用户要把清华开源项目 OpenMAIC（多智能体互动课堂，MIT 许可，Next.js 16 + PostgreSQL，v1.4.2）整合进见微，整合后版本叫 **0.3.x**，要求在 **4GB 内存**的电脑上能跑。工作分两份，**文件不重叠，两边可以同时做**：

| 谁 | 做什么 | 文件 |
|---|---|---|
| Claude | 课堂服务：便携 PostgreSQL、OpenMAIC 服务端（Node）、DeepSeek 配置、内存上限、闲置自动关、打包进绿色版、4GB 实测 | `F:\space for Claude\openmaic\**`、`app/native/classroom/service.py`、`app/native/classroom/runtime_selftest.py`、`tools/release.py` 里和课堂运行时有关的部分 |
| **GPT（你）** | 见微里的「课堂」页面、窄栏入口、打开课堂窗口、页面自测 | `app/native/classroom/page.py`、`app/native/classroom/window.py`、`app/native/classroom/fake_service.py`、`app/native/classroom/selftest.py`（`__init__.py` Claude 已建好，空的）、`main_win.py` 里加一个模式、`design/icons.py` 加一个图标、`kit/quick_open.py` 的快捷键说明、自测接入总自测 |

先读 `HANDOFF-给GPT.md` 开头（版本命名规则：1.x→0.1.x，2.x→0.2.x，当前 0.2.17），再读本文。**不要改 `service.py` 和 `openmaic\` 目录**；接口不够用就在 `HANDOFF-给GPT.md` 末尾写需求，Claude 来加。**不要升版本号、不要打包**，0.3.0 由 Claude 统一出。

> **2026-11-10 更新：服务端已经实测跑通。** 运行包在 `F:\space for Claude\openmaic\runtime-dist`，开发时 `service.runtime_dir()` 会自动找到它。实测：首次启动约 43 秒（要建数据库），之后约 4 秒；空闲约 500MB；用 DeepSeek 生成一堂 4 页的课，峰值 621MB。首页会自动选好 DeepSeek Flash，输入主题后点「进入课堂」就能生成。
> 想用真服务调试页面：把 `JIANWEI_HOME` 指到临时目录，往里放一份 `deepseek.env`（向用户要，**不要复制用户真实数据目录里的那份**），再调用 `service.start()`。页面自测仍然只用 `fake_service`。

## 一、服务接口（Claude 写，你只调用）

`app/native/classroom/service.py` 提供下面这些，**在 Claude 写好之前，你用 `fake_service.py` 按同样的接口开发和自测**：

```python
STATES = ("absent", "stopped", "starting", "ready", "stopping", "error")

def available() -> bool          # 绿色版里带了课堂运行时（没带就是 absent，页面显示「这个版本没有课堂组件」）
def status() -> dict             # {"state": 上面之一, "message": 给人看的一句话（中文）, "url": "http://127.0.0.1:端口" 或 "",
                                 #  "rss_mb": 服务进程合计内存（MB，int，没在跑为 0）, "key_ok": 见微里配了 DeepSeek 密钥没有}
def start() -> None              # 不阻塞：后台线程启动数据库和服务端，状态经 starting → ready / error
def stop() -> None               # 不阻塞：经 stopping → stopped；见微退出时也要调用
def touch() -> None              # 有人在用：重置闲置计时（服务 10 分钟没人 touch 自动 stop）
def subscribe(fn) -> callable    # fn(status_dict) 在状态变化时被调用（可能在后台线程！你要用信号转回界面线程）；返回取消订阅的函数
def url(path: str = "") -> str   # 例如 url("/") 或 url("/classroom/xxx")；没 ready 时返回 ""
```

- 第一次启动要初始化数据库，可能要 20～60 秒；之后启动约 5～15 秒。`message` 会说明正在做哪一步。
- 密钥：服务从见微现有的 `%LOCALAPPDATA%\Jianwei\deepseek.env` 读 DeepSeek 密钥，**页面不要读、不要显示、不要写日志**。`key_ok` 为 False 时页面提示去析题页右上角「DeepSeek 密钥…」设置，并提供一个按钮跳过去（`main_win.goto("analysis")` 后调用该页的 `edit_key()`）。
- 端口、数据目录都由服务决定，页面不要写死。

## 二、页面要做的事（`page.py`）

1. **窄栏入口**：`main_win.MODES` 末尾加 `("classroom", "课堂")`，`MODE_ICONS` 和 `design/icons.py` 加一个「讲台/黑板」类图标（照现有图标的画法和线宽）；`page()` 里懒加载 `ClassroomPage`。快捷键自动是 Ctrl+6，`quick_open.py` 的说明补上。
2. **页面布局**（用 `design/tokens.py` 的颜色和 `qss()`，不写局部样式，参考析题页的「欢迎页」风格）：
   - 标题「课堂」+ 一句说明：「输入一个主题或上传资料，AI 老师和同学给你上一堂课：幻灯片、测验、互动演示、白板讲解。」
   - 状态卡：当前状态的中文、`message`、内存占用（ready 时显示「约 N MB」）、一个主按钮（stopped→「启动课堂」，starting→禁用的「正在启动…」带进度动画，ready→「打开课堂」，error→「重试」）和一个次按钮「关闭服务」（ready 时可用）。
   - `absent` 时只显示说明，没有按钮。`key_ok=False` 时主按钮换成「先设置 DeepSeek 密钥」。
   - 底部小字：「课堂组件来自开源项目 OpenMAIC（清华大学 THU-MAIC，MIT 许可）」，带「许可」链接打开 `service.runtime_dir()/"LICENSE"`（Claude 会放这个文件；不存在就不显示链接）。
3. **打开课堂窗口**（`window.py`）：用系统 Edge 的应用模式打开 `service.url("/")`，不要在见微里嵌浏览器内核（QtWebEngine 太占内存，也会让绿色版变大很多）。
   - 找 `msedge.exe`：注册表 `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe`，再试 `%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe` 和 `%ProgramFiles%\...`；都没有就用 `QDesktopServices.openUrl` 交给默认浏览器。
   - 参数：`--app=<url> --user-data-dir=<JIANWEI_HOME 或 %LOCALAPPDATA%\Jianwei>\classroom-edge --no-first-run --no-default-browser-check --disable-features=Translate,msEdgeSidebarV2 --renderer-process-limit=3 --window-size=1400,900`。独立的 user-data-dir 才不会和用户自己的 Edge 混在一起，也能在关窗后知道窗口没了。
   - 记住启动的 Edge 进程；**不要强杀**（见微的老规矩）。窗口开着时每 60 秒调用一次 `service.touch()`；窗口关了就不再 touch，让服务自己闲置关闭。
   - 已经开着窗口时再点「打开课堂」不要再开第二个（检查进程还在就用 `--app` 再调用一次也可以，Edge 会把同一 user-data-dir 的请求交给已有实例）。
4. **见微退出时**调用 `service.stop()`（找主窗口的 closeEvent 或 `QApplication.aboutToQuit`，别阻塞退出超过 3 秒）。
5. **析题 → 课堂**（小功能，做完上面再做）：析题页答案卡标题行加一个按钮「做成一堂课」（只在 `service.available()` 时显示），点了以后：确保服务 ready（没启动就先启动，页面上给提示），然后打开 `service.url("/")` 并把题目文字复制到剪贴板，状态栏提示「题目已复制，在课堂里粘贴就能生成」。不要往 OpenMAIC 的接口直接发请求（那部分 Claude 之后看它的 API 再接）。

## 三、自测（`selftest.py`，接进总自测）

- 用 `fake_service.py`：能手动驱动状态（absent / stopped / starting / ready / error / key_ok=False），检查每种状态下按钮文字、可用性、显示的说明都对；`subscribe` 的回调从后台线程触发时界面不崩、文字会更新。
- `window.py` 的 Edge 查找和参数拼接写成纯函数测，**自测里不要真的启动 Edge**。
- 主窗口：`MODES` 里有课堂，`goto("classroom")` 懒加载成功，Ctrl+6 对应课堂。
- 照见微的规矩：`test_runtime`、隔离 `JIANWEI_HOME` 和 `LOCALAPPDATA`、不读真实密钥、不联网、不弹 Python 错误框、不强杀进程、不启动 Word。
- 截图：stopped、starting、ready、error、absent、缺密钥，昼夜两套主题，放在你的工作目录，在 `HANDOFF-给GPT.md` 里写清楚路径。

## 四、完成的标准

- 析题、习题台、课件等原有自测全部照常通过（`python -m native.analysis.selftest` 等，和打包用的总自测）。
- `HANDOFF-给GPT.md` 末尾写一节「课堂页」：做了什么、文件、自测命令、截图位置、没做或没验证的地方（比如没有在真机上点开 Edge）。
- 不要声称课堂能用——服务部分是 Claude 的，你只保证页面在假服务下的每种状态都对。
