# 交接给 Fable 5.2（2026-11-10）

你接手的是用户的「见微」——一个 PySide6 学习桌面程序。本文是 Claude（Opus 5.5）这几轮工作的上下文，读完就能接着干。

## 项目与路径

- 源码：`F:\space for Claude\jianwei\src2`（app 代码在 `app\`；入口 `app\main.py`；版本号在 `app\store.py` 的 `VERSION`，**当前是 0.3.0**）。
- Python：`F:\space for Claude\jianwei\.venv\Scripts\python.exe`。
- 发行：在 `src2` 下依次运行 `python tools/release.py build`、`smoke`、`pack`。产物放在 `F:\space for Claude\jianwei\release-<版本>-<日期>\`，然后复制到 **`F:\AI\`**（用户 2026-11-10 新指定的位置；更早的版本都在桌面 `AI\jianwei\`）。
- 版本命名：1.x 改名为 0.1.x，2.x 改名为 0.2.x，整合 OpenMAIC 后是 0.3.x。`backup._version` 会把旧的三段式 1.x/2.x 映射到 0.1/0.2，这样旧备份不会被判成「更新的版本」。
- GPT 也在同一个 `src2` 目录里开发、出版本：动版本号前先看 `store.VERSION`；给 GPT 的交接写在 `HANDOFF-给GPT.md` 末尾，或者单独写一个 `PROMPT-*.md`。

## 0.3.0 做了什么：整合 OpenMAIC

OpenMAIC v1.4.2 是清华的多智能体 AI 互动课堂（Next.js 16 + PostgreSQL，MIT 许可），现在是见微的「课堂」模式（Ctrl+6）。

- **服务端（Claude 写）**：`app\native\classroom\service.py`。
  - 启动便携 PostgreSQL 16 和 Node 26 上的 OpenMAIC standalone 服务，DeepSeek 配置按见微的设置生成。
  - 闲置 10 分钟自动关；每次启动按 `server\links.json` 重建 pnpm 的 junction（`fix_links`）。
  - 遇到中文路径时，先转 8.3 短路径，转不出就改放 `%PUBLIC%\Jianwei\pg-*`。
  - 自测：`runtime_selftest.py`。
- **界面（GPT 写）**：`page.py`、`window.py`（Edge `--app` 独立窗口，独立的 user-data-dir）、`fake_service.py`、`selftest.py`（95 项）；析题答案卡上有「做成一堂课」。
- **运行包**：`F:\space for Claude\openmaic\runtime-dist`，由 `openmaic\assemble.py --src <构建好的 OpenMAIC 目录>` 生成。`release.py build` 会把它复制成绿色版里的 `classroom\`（不复制 junction）。
- **构建 OpenMAIC**：这台 8GB 机器只能用低内存 webpack 模式构建，配置在 `F:\space for Claude\openmaic\build-lowmem\`。关键是 `webpackBuildWorker: true`，并关闭 cache、minimize、devtool；约 11 分钟，峰值约 1.8GB。源码在 `F:\space for Claude\openmaic\OpenMAIC-1.4.2`；那里的依赖装在机械盘上，很慢。上次构建是在 `C:\omb` 做的，那个目录已交给用户手动删除。
- **实测**：首次启动约 43 秒，之后约 4 秒；空闲约 500MB；用 DeepSeek 生成一堂 4 页的课，峰值 621MB。真 Edge 窗口联调通过（打开、复用、关窗被检测到、服务停止）。

## 规矩（用户定的，必须遵守）

- 测试必须把 `JIANWEI_HOME` 和 `LOCALAPPDATA` 指到临时目录；不能碰用户真实的数据目录。
- **绝不打印、不写入日志用户的 DeepSeek 密钥**。真实密钥在 `%LOCALAPPDATA%\Jianwei\deepseek.env`，不要去复制它；测试要用密钥就向用户要，用完删掉副本。
- 不要乱杀进程（只停自己启动的）。WPS 测试留下的文稿用 COM 关闭。测试里不要启动 Word。不要有 Python 报错弹窗（`release.py` 已经配置好）。
- `E:\U盘备份` 里的真实课件只读。
- 不绕过验证码。
- 用户用中文交流，回复要简洁直白。

## 可能的下一步

- 课堂的 TTS/ASR 目前用浏览器原生，视频和图片生成都关着；可以考虑接入见微已有的语音。
- 绿色版多了约 0.5GB；可以研究精简 `server\node_modules`（比如 aws-sdk、mistral 等没用到的 provider）。
- 课堂生成的课和见微的讲台、析题互通（目前只做到复制题目）。
