# 见微 · 高考学习舱 —— 施工中交接

> **2026-11-07 2.9更新**：下面的“暂停”和旧视觉为历史记录，用户已授权继续。当前原生源码、模型/备份/复习/析题联动与裁剪范围，以`HANDOFF-给GPT.md`开头、`RELEASE-0.2.9.md`和`WORK-2.9.md`最新进度为准。发行必须走独立release脚本，不覆盖src2/dist/桌面快捷方式；所有自动验证隔离数据、静默错误、不强杀、不启动Word。真机项目见`真机验收清单.md`。

> 施工暂停时间：**2026-10-24 19:30**（用户要求暂停，等验收后再继续）
> 一个 Windows 桌面软件，托盘 + 三个模块：**观澜视界 / 倒计时胶囊 / 析题台**
> 视觉基调：青瓷蓝 · 简洁明快（纸底 `#F7F2EB`、墨蓝 `#081F5C`、单色相阶梯、数字用衬线）

---

## 1. 一句话现状

**19:30 快照：三个模块都在，能无头跑通、能打包、桌面快捷方式已就位。**
- 外壳 + 观澜内嵌 + 倒计时胶囊：已渲染验证（`tmp/selftest/`），观澜浮窗真数据 448×704 正常。
- 析题台：三引擎（graph / physics / subjects）+ **60 道 2023–2025 真题**，`tools/audit.py` 输出 **`AUDIT PASS`**（60 题、8 科、0 JS 异常）。
- 打包：`dist/Jianwei/Jianwei.exe`（onedir，114 MB）冻结版 `--self-test` 通过；`Desktop\见微.lnk` 已生成。
- 4 个子代理在 19:28 被我全部停掉（它们各自的最后一版都通过了审计；仍有 4 处已知毛病没修完，见 §4）。
- **全程未启动任何可见窗口、未弹出任何对话框。**


---

## 2. 已完成（可验收）

| 部件 | 文件 | 状态 |
| --- | --- | --- |
| 数据层（配置 / 题库索引 / 观澜摘要 / 首次播种） | `app/store.py` | ✅ 跑通，已从本机观澜发行版播入 2026-10-24 当日内容 |
| 视觉底座（色板 / 字体 / QSS / 卡片 / 刻度条 / 按钮） | `app/ui_kit.py` | ✅ |
| 主壳（无边框纸面窗 / 左导航 5 页 / 托盘 / 提示条） | `app/shell.py` | ✅ 截图通过 |
| 今日页（距考天数 + 学期刻度 + 今日一题 + 观澜焦点 + 模块卡） | `app/pages.py` | ✅ 观澜/倒计时/设置齐 |
| 观澜页（焦点 + 6 条线索 + 打开浮窗 / 暮省 / 刷新） | `app/pages.py` | ✅ 真数据渲染 |
| 倒计时页（实时预览 + 目标时刻 + 4 滑块 + 4 开关 + 3 预设） | `app/pages.py` | ✅ |
| 倒计时胶囊（逐像素磨砂 + 极光 + 进度细线 + 拖拽 + 点击穿透） | `app/countdown.py` | ✅ 画得出来；未在真桌面挂过（不弹窗策略） |
| 观澜内嵌（复用原源码，独立数据目录，禁托盘/热键/自启） | `app/guanlan/`、`app/guanlan_host.py` | ✅ 补丁 `JIANWEI_EMBED` / `JIANWEI_GUANLAN_HOME` |
| 析题台宿主（本地静态服务 + Edge 无边框应用窗） | `app/studio_server.py` | ✅ 服务能起，Edge 未实测打开 |
| 析题台底座（内核 / 主程序 / 版式 / 审计页） | `app/studio/web/js/core.js`、`app.js`、`css/studio.css`、`audit.html` | ✅ 契约已冻结，三个视图按契约并行开发 |
| 入口 + 无头自检 | `app/main.py`（`--self-test`） | ✅ `SELFTEST_OK`，5 页 + 胶囊 3 尺寸出图 |
| 题库审计 harness | `tools/audit.py` | ✅ 现输出 `questions=60`，仅 2 个 FAIL（函数视图未交付） |
| 打包 | `build.py` + `dist/Jianwei/` | ✅ onedir 114 MB，冻结版 `--self-test` 通过；快捷方式脚本已修 |
| 图标 | `app/assets/icon.ico` | ✅ 墨蓝圆角方块 + 「见」+ 朱砂点 |
| 归档登记 | `INDEX.md` 已加 jianwei 一行 | ✅ |

**观澜模块的接入细节**（重要，别踩）：
- 源码从 `10-projects/guanlan/source` 拷到 `app/guanlan/`（core/ui/assets，13 MB）。
- `core/paths.py` 打了两个补丁：`JIANWEI_GUANLAN_HOME` 覆盖数据目录、`ASSET_DIR` 指向源码树。
- `ui/window.py` 打了三个补丁：`_setup_tray` / `_setup_hotkey` / `_ensure_autostart` 在 `JIANWEI_EMBED=1` 时直接 return，避免与正在运行的独立版观澜抢托盘、抢 `Alt+Shift+G`、抢开机自启项。
- **没有动** `观澜桌面视界/`（锚点）与 `10-projects/guanlan/source`（源）。

---

## 3. 子代理交付（19:28 全部停止）

| 子代理 | 交付 | 状态 |
| --- | --- | --- |
| `82edf03e` 函数变换 | `js/views/graph.js` 51 KB + `css/graph.css` | 可渲染、可拖动/滚轮/旋转；**公式栏还没从 expr 求值**（disp 仍是模板），旋转手柄图标是「?」 |
| `c114209c` 物理仿真 | `js/views/physics.js` 69 KB + `css/physics.css` | 抛体已跑通；**`params` 未覆盖默认值**（v0=3 显示 5） |
| `55bfd274` 跨学科 | `js/views/subjects.js` 126 KB + `css/subjects.css` | 14 mode 基本可用；**`composition` 仍渲染示例内容**，`flow/data` 走兜底 |
| `75c44def` 题库 | `bank-2023/2024/2025/2026.js` | **60 题**：数 17 · 物 13 · 化 8 · 生 6 · 语 4 · 英 4 · 史 4 · 地 4；2026 卷 3 题标注「回忆版待校」 |

**契约（已冻结，改动要三方同步）**：
- `JW.registerView(engine, mountFn)`；`mountFn(host, q, api) -> {applyStep(i), destroy()}`
- `api = JW.makeApi({host, q})`
- `q.view`：
  - 函数 → `{engine:'graph', mode:'trig'|'poly'|'conic'|'vec'|'piecewise'|'lab', expr, params:[{k,label,min,max,step,v}], xr, yr, ghost, marks}`
  - 物理 → `{engine:'physics', kind:'projectile'|..., params:{...}, cue}`
  - 学科 → `{engine:'subjects', mode:'reaction'|..., params:{}, data:{...}}`

---

## 4. 待办（按优先级）

0. **4 个子代理 19:15 时仍全部 running**（函数视图 51 KB / 物理 66 KB / 跨学科 126 KB / 题库 60 题），已在按实测反馈返修：公式与图不一致、`params` 不吃默认值、`composition` 用示例内容、`flow` 未注册。
1. **回收 4 个子代理**：跑 `python tools/audit.py --shots 1`，必须 `AUDIT PASS`。
2. **三方对齐**：题库 `view` 写法与视图实际支持字段可能有出入 → 以审计输出逐条修。
3. **截图验收**：`python app/main.py --self-test tmp/selftest` + `tools/audit.py --shots 2`，人工看 5 页外壳与每科题目页。
4. **打包**：✅ 已完成 —— `build.py`（PyInstaller onedir）产出 `dist/Jianwei/Jianwei.exe`（114 MB），冻结版 `--self-test` 通过；桌面快捷方式 `Desktop\见微.lnk` 由 `make_shortcut.py`（UTF-16LE VBS）生成；自启值 `JianweiSuite` 在设置页写。
5. **胶囊真机验证**：需要 **用户亲自** 打开才能确认磨砂取景与 `WDA_EXCLUDEFROMCAPTURE` 效果（开发者按约定不启动可见窗口）。
6. **视觉打磨**：胶囊左块（届别/距高考）行距、今日页下半部留白、析题台右栏密度。
7. **写 HANDOFF 终版** + README 四行 + 归档检查。

---

## 5. 坑与约定（给接手的人）

- **不要弹窗**：用户明确要求开发全程不显示窗口；验证一律 `--self-test`（offscreen）与 Edge `--headless=new`。唯一例外是用户亲自验收。
- **QSS 坑**：给容器 `setStyleSheet("background:transparent;")` 会**级联到所有子控件**，把卡片/按钮底色一起洗掉（已踩，已全删）。要透明就用 objectName 作用域或干脆不写。
- **按钮样式**：动态属性选择器 `[variant="primary"]` 在本机实测不生效，已改为 objectName（`btn` / `btn-primary` / `btn-soft`）。
- **字体**：offscreen 渲染要 `QT_QPA_FONTDIR=C:\Windows\Fonts`，否则全是豆腐块；正常桌面模式无需设置。
- **中文控制台**：本机 PowerShell 是 CP936，`print` 中文会乱码但不影响功能；日志一律写 UTF-8 文件。
- **观澜数据**：首次运行从 `观澜桌面视界/data/` 播种到 `%LOCALAPPDATA%\Jianwei\guanlan\data\`；刷新会覆盖播种内容。
- **端口**：析题台服务每次随机端口（`127.0.0.1:0`），不要写死。

## 6. 验收命令（都不弹窗）

```powershell
cd 10-projects\jianwei
..\..\.venv\Scripts\python.exe app\main.py --self-test tmp\selftest
..\..\.venv\Scripts\python.exe tools\audit.py --no-shots
..\..\.venv\Scripts\python.exe tools\audit.py --shots 1
```

看 `tmp/selftest/shell-*.png`、`tmp/audit/*.png`。

---

## 7. 只使用见微（内嵌接管，2026-10-25 完成）

目标：**不再需要原版观澜与 C# 胶囊**，打开见微就有侧边浮窗、顶部胶囊、每晚暮省、每日抓取。

### 7.1 已经在见微里的东西

| 能力 | 实现 | 证据 |
| --- | --- | --- |
| 侧边浮窗 | `app/guanlan/`（观澜源码）+ `app/guanlan_host.py`；`Alt+Shift+G` 已收进见微（`HotkeyFilter`），托盘/今日页/观澜页都能开 | `tmp/selftest-exe/panel.png` 448×704 真数据 |
| 顶部胶囊 | `app/countdown.py`，启动即显示（`showPill`） | `tmp/selftest/pill-sizes.png` |
| 每日 07:15 抓取 | `app/scheduler.py` 的 `DailyJobs`，见微常驻托盘时自动跑；抓完发 `fetch_done` 让浮窗就地换内容 | `Jianwei.exe --fetch` 退出码 0 |
| 每晚 22:20 暮省 | 双保险：见微内部定时器 + 计划任务 `JianweiEveningReview` → `Jianwei.exe --evening`；两边用 `store.evening_page_today()` 互斥，不会重复开窗 | `Jianwei.exe --evening-no-open` 生成 99 KB 页面 |
| 内容数据 | `%LOCALAPPDATA%\Jianwei\guanlan\`（首次从发行版播种，之后 `sync_from_release()` 只在发行版更新时补一次） | 今日 2026-10-25 已同步 |

### 7.2 一键接管 / 撤销

```powershell
cd 10-projects\jianwei
python switch_to_jianwei.py            # dry-run：只打印计划
python switch_to_jianwei.py --apply    # 真正接管（会停原版两进程、换自启、建 22:20 任务、后台启动见微）
python switch_to_jianwei.py --revert   # 回到接管前
```

`--apply` 会先备份到 `%LOCALAPPDATA%\Jianwei\backup\<时间>\`（含原 HKCU Run 值、C# 启动快捷方式、旧任务 XML）。

### 7.3 内嵌的三条硬坑（都已踩过）

1. **路径先于环境变量**：`core.paths.ROOT` 在 **import 时**求值。任何提前 `import ui.window`（比如只为拿 `HotkeyFilter`）都会让 ROOT 锁到 exe 旁，浮窗变「等待今天的筛选」。修法：`GuanlanHost._ensure_path()` 先 `_ensure_home()`；`paths.base_dir()` 的 frozen 兜底也指向 `%LOCALAPPDATA%\Jianwei\guanlan`。
2. **定时抓取只能有一个主人**：内嵌后 `ui/window.py::_auto_check` 在 `JIANWEI_EMBED=1` 时直接 return，由 `scheduler.DailyJobs` 统一负责。
3. **托盘/热键/自启不能有两份**：`JIANWEI_EMBED=1` 下 `_setup_tray` / `_setup_hotkey` / `_ensure_autostart` 全部短路；热键改由见微注册（原版在跑时注册会失败，静默降级）。

---

## 8. 这一轮修掉的四处（2026-10-25 上午）

| # | 问题 | 修法 | 证据 |
| --- | --- | --- | --- |
| 1 | 函数图公式栏只显示模板式，与曲线对不上 | `eqText()` 改为：题目给了 `expr` 就用「代入当前参数」的真实解析式；新增 `substDisplay()` 做排版（去 `1(`、去 `/1`、`+(-1)`→` − 1`、负号改 `−`、补 `²`） | `m-2023-nh1-04` 显示 `y = (x−1)² − 1` |
| 2 | 图上的顶点/开口读数来自画布参数，不是函数本身 | 新增 `quadVertex()`（三点定二次）与 `extremaInfo()`（采样求极值、周期、振幅）；poly 用真顶点，trig 用实测周期/振幅 | 顶点 `(1, −1)`、开口「向上」与曲线一致 |
| 3 | 物理视图不吃题目的 `params` | 其实 `applyParams()` 已修好（子代理最后一版）；复核 `p-2023-qgj-14`：v₀=3、h₀=0.8、R=1.2、T=0.4、落地 5 m/s，与题干/答案一致 | 截图 `tmp/audit/check-p-2023-qgj-14.png` |
| 4 | 英语应用文渲染成示例议论文；`flow`/`data` 走兜底 | `composition` 已改读 `data.tasks/angles`（子代理最后一版）；`flow`/`data` 已注册；本轮又补：拉丁文按词折行、卡片高度自适应、结构整体垂直居中、兜底提示文案分流 | 截图 `tmp/audit/check-e3.png`、`check-m-2025-nh1-04.png` |

审计：`tools/audit.py --no-shots` → `AUDIT PASS`（60 题 / 8 科 / 0 JS 异常）；`dist/Jianwei` 已重打。

### 还剩的打磨项（下一轮）
1. 物理画布：抛物场景纵向留白偏大、`地面` 字压在虚线上、y 轴刻度密度不一致。
2. 函数视图：旋转手柄图标仍是「?」，公式/矩阵区仍挤在画布上方（应移入右栏）。
3. 应用文/流程图在窄屏的折行还可以再紧一点。

---

## 9. 第二轮功能（2026-10-25 上午，施工中 → 待集成）

用户要求：**不要任何前台测试弹窗**（全部无头验证），并且要能「导入题目 → 快速解析 → 可视化」，近三年题目尽量全录，还允许派子代理并行。

### 9.1 我自己写的（已在树里）

| 功能 | 位置 | 状态 |
| --- | --- | --- |
| 导入题目（粘贴题干→自动判断题型→立即出图→存本机） | `js/import.js` + `css/import.css`；入口 `#btn-import`、`?import=1`、见微托盘页「导入题目」 | ✅ headless 验证：5 类题干分别判成 physics/projectile、graph/poly、solid、subjects/reaction、subjects/map |
| 同类题（按知识点重合度推荐 3 道，可点跳转） | `js/app.js::renderRelated` + `#related-card` | ✅ 抽查 3 题都有 3 条 |
| 答案对照（自己先写，只比对数字/关键结论） | `js/app.js::compareAnswer` + `#selfcheck` | ✅ |
| 答案默认展开（不再藏在按钮后面） | `js/app.js` | ✅ |
| 胶囊：磨砂玻璃（壁纸取样 + 18× 降采样 + 奶白霜面 + 冷墨压暗）+ 动态极光 + 每 7 秒掠光 | `app/countdown.py` | ✅ 三种底色对照图 `tmp/pill-contrast2.png` |
| 胶囊：**沉最底层**、永不抢焦点、屏幕居中 | `_assert_zorder()` + `HWND_BOTTOM` + `WindowDoesNotAcceptFocus` | ✅ 实测 x=418（1536 宽屏居中）、前台窗口另有其人 |
| 析题台不再强抢前台（改用浏览器标签打开，file:// 离线可用） | `studio_server.open()` | ✅ |

### 9.2 子代理并行中（交付后需跑 `tools/wire_studio.py` 接线）

| 代理 | 交付 | 用途 |
| --- | --- | --- |
| solid | `js/views/solid.js` + `css/solid.css` | 立体几何：8 种几何体、拖动旋转、截面、二面角/线面角 |
| 题库×3 | `js/data/bank-extra-mp.js` / `-cb.js` / `-le.js` | 数理 / 化生 / 语英史地 扩容 |
| study | `js/study.js` + `css/study.css` | 知识卡抽屉（40+ 考点）、错题本、三级提示 |
| player | `js/player.js` + `css/player.css` | 逐步讲解播放器、键盘导航、存图 |
| ux | `js/ux.js` + `css/ux.css` | 版式/空态/焦点态/窄窗折叠/快捷键面板 |

### 9.3 集成清单（等子代理交付后按序执行）

```powershell
python tools/wire_studio.py          # 接线（幂等，缺文件会跳过）
python tools/audit.py --no-shots     # 必须 AUDIT PASS
python build.py                      # 重打包
# 静默重启（主窗口不显示，胶囊与浮窗自己回来）
Stop-Process -Name Jianwei -Force; Start-Process dist\Jianwei\Jianwei.exe -ArgumentList '--background'
```

---

## 10. 10:05 快照（本轮收工）

**一句话**：见微成为唯一入口；析题台从 60 题扩到 **206 题 / 8 科 / 4 个可视化引擎**，加了导入、同类题、答案对照、知识卡、错题本、提示阶梯、逐步播放、存图、快捷键，并新增**立体几何 3D 引擎**（8 种几何体、拖动旋转、截面、二面角/线面角/外接球）。

### 10.1 交付清单

| 模块 | 文件 | 说明 |
| --- | --- | --- |
| 立体几何 3D | `js/views/solid.js` + `css/solid.css` | 画家算法投影、拖动旋转/滚轮缩放、8 种几何体、截面对角线/截面/关系角、读数与公式 |
| 导入题目 | `js/import.js` + `css/import.css` | 粘贴题干→自动判型（函数/物理/学科/立体）→出图；存 localStorage，最多 200 题 |
| 学习助手 | `js/study.js` + `css/study.css` | 知识卡抽屉（40+ 高频考点）、错题本（星标 + 左栏筛选）、三级提示 |
| 讲解播放器 | `js/player.js` + `css/player.css` | 播放/上一步/下一步/倍速、键盘 ←→ 空格 R、存图（PNG 下载） |
| 界面打磨 | `js/ux.js` + `css/ux.css` | 间距/焦点态/空态/窄窗折叠/快捷键面板 |
| 题库扩容 | `bank-extra-mp.js`、`bank-extra-cb.js`、`bank-extra-le.js`、`bank-solid.js` | 数 53 · 物 37 · 化 31 · 生 30 · 语 15 · 英 15 · 史 15 · 地 15 = **206**（应用内）/211（含重复 id 计数差异） |
| 接线 | `tools/wire_studio.py` | 幂等：把上面所有 css/js 接进 index.html 与 audit.html |

### 10.2 验证（全部无头，没有开过任何前台窗口）

- `tools/audit.py` → **AUDIT PASS**：206 题逐题挂载视图、跑到最后一步、无 JS 异常；引擎 graph/physics/subjects/solid 全在线。
- 冻结版 `dist/Jianwei/Jianwei.exe --self-test` → `SELFTEST_OK` + `PANEL_OK 448 704`。
- 打包目录核对：solid/study/player/ux/import + 三个额外题库 + ux.css 都在 `_internal/studio/web`。
- 真机窗口核对（Win32）：胶囊 700×52 @ (418,18) —— 1536 逻辑宽下正中；浮窗 448×704 @ (1076,8)；前台窗口不是见微（没抢焦点）。

### 10.3 这轮改过的视觉决策

1. 胶囊从 880×64 收到 **700×52**，重心更轻，不再挡住桌面图标。
2. 磨砂底改成**壁纸取样**：本机 `SetWindowDisplayAffinity` 返回 0（不可用），实时截屏会把胶囊自己拍进去（越拍越黑），改用壁纸同位置重采样 + 18× 降采样，视觉等价且永不递归。
3. 极光：5 团径向渐变呼吸漂移 + 每 7 秒一道掠光；奶白霜面 38/24/14 与冷墨压暗叠加，读作玻璃而不是黑块。
4. 胶囊**沉最底层**（HWND_BOTTOM + WS_EX_NOACTIVATE + 1.5s 复assert），任何窗口都能压住它，且永不抢焦点。

### 10.3.1 收尾又修的一个公共 bug

`core.js::JW.compile` 里 `with(Math)` 是死代码，`sin/cos/abs/sqrt/ln` 从没进过求值作用域 ——
所有 `graph` 的 trig/piecewise 曲线都会在采样时抛 ReferenceError，被 try/catch 吞成 NaN，
画面上只有关键点没有曲线（题库里三道路由题因此被改成 flow）。
已改成 `const {sin,cos,…} = __F;` 显式注入，并用 tmp/compile-test.html 的 6 个用例 headless 全 PASS。

### 10.4 已知未打磨（下一轮）

- 物理画布：抛物场景纵向留白偏大、`地面` 字压在虚线上、y 轴刻度密度不一致。
- 函数视图：解析式/矩阵块仍挤在画布上方（应移进右栏 210px 列）。
- 立体几何：球/圆台的标注在极端旋转角下会轻微重叠。
- 题库里少数 2026 卷为回忆版，已在 note 标注。

---

## 11. 数学模块增强（2026-10-25 晚）

用户要求：数学模块要有函数性质分析（零点/极值/驻点/渐近线等）、图像可视角平移、画布与控制栏比例可调、可自行输入函数；实验室要按"知识块"进入而不是按年份题目；物理要更多可自行搭建的场景。

### 11.1 已交付（我写的 `js/graphplus.js` + `css/graphplus.css`）

| 功能 | 说明 | 入口 |
| --- | --- | --- |
| 函数性质分析 | 零点（二分精修）、驻点、极大/极小、拐点、垂直/水平渐近线、单调区间、奇偶、周期、值域；全部按当前视野实算 | 函数视图右栏「函数性质」卡 |
| 图上标记 | 零点/极值/拐点画在**原画布**上（不是叠层），可逐类开关；渐近线虚线 | 卡片下方四个开关 |
| 视角平移/缩放 | ←↑↓→ 每次移 22% 视野，＋/－ 缩放 1.22×；开「视野」后按住画布拖动＝平移视野（触摸友好） | 画布右下角浮动键盘 |
| 比例调节 | 画布/控制栏之间的竖条可拖动，比例存 localStorage | 画布右侧细条 |
| 自定义函数 | 输入 `2*sin(x)+1` 之类，支持 sin cos tan sqrt abs ln exp ^ π 与 A/B/H/K；回车或「应用」即挂载 | 右栏顶部 |
| 实验室按知识块 | 函数与导数 / 指数与对数 / 三角函数 / 解析几何 / 绝对值与分段，共 15 个预设，点一下换函数 | `变换实验室` 页左栏 |
| 周期检测 | 采样自相关找最小滞后周期，比"极大值间距"稳（2sin(2x)+1 → 3.14） | 性质卡「周期」行 |
| 调试钩子 | `?testfn=表达式` 自动应用一次自定义函数；`?testpreset=N` 自动点第 N 个实验室预设（都无窗口） | URL 参数 |

### 11.2 实现要点（后人别踩）

- 性质分析靠 `graph.js` 暴露的 `host.__gx = { range, setRange, fn, params, plot, canvas, spec }`，只读+视图控制，不改内部。
- 标记必须画在**视图自己的 canvas** 上：先包一层 `canvas.render = base + paint`，任何重绘都会带标记；叠层方案在本机会因布局时序拿到 0 高度。
- 实验室是**参数曲线**（p(t)=M·(t,sin t)+T），f(x) 性质对它是无意义的，已自动隐藏性质卡与标记。
- `graph.js` 的平移系数探针失败时原来返回 0（拖动完全没反应），已改为 1。

---

## 12. 昼夜两套配色（2026-10-25 夜）

用户要求：范围＝**见微本体 + 由它衍生的界面**（析题台等），不含观澜浮窗与桌面时钟；要有白天/夜晚两套。

### 12.1 析题台（web）

| 文件 | 作用 |
| --- | --- |
| `css/nocturne.css` | 夜航玻璃拟态：深夜底 `#060A13→#0B1322`、两处光源光斑、2.5% 颗粒、无色玻璃面板（白 14%→7% 渐变）、1px 受光描边、方向性阴影、香槟金 `#E4B863` 唯一强调色、16–20px 圆角、`cubic-bezier(.16,1,.3,1)` 弹簧过渡。**全部规则挂在 `html[data-theme="night"]` 下**，白天完全不受影响。 |
| `js/nocturne.js` | 主题管理：`localStorage['jw.theme']`；没存过时按小时（7–19 白天）自动选；`?theme=day|night` 可强制；切换时同时换**画布色板**（`JW.C` 的 paper/ink/grid/accent/data）并重挂当前视图；顶栏插入「夜晚/白昼」按钮。 |

用法：右上角按钮切换；`http://…/index.html?theme=night` 直接指定；Qt 打开析题台时会把本体主题作为 `theme=` 传进去。

### 12.2 见微本体（Qt）

- `ui_kit.py`：`_THEMES`（day/night 各 11 个色）+ `apply_theme()` + `qss()`（夜间用「白天色值→夜晚色值」替换生成，另追加按钮/输入/滑杆/复选框的夜间规则）+ `restyle_tree()`（把控件里写死的白天色值就地换掉，属性 `origStyle` 记录原文，切回白天可逆）。
- `shell.py`：标题栏「夜晚/白天」按钮 → `toggle_theme()`：换主题、存配置、重设全局 QSS、重建页面、`restyle_tree`、重绘；`paintEvent` 夜间画深夜底 + 两处径向光源。
- `main.py`：启动先 `apply_theme(cfg.theme)`；`theme: "auto"` 按小时解析（7–19 白天）。
- `studio_server.page_url()`：追加 `theme=<当前主题>`，让浏览器里的析题台和本体一致。

### 12.3 一条硬教训（别踩）

**本机 Edge 对 `backdrop-filter` 的软件合成有 bug**：夜间一旦给面板加模糊，右侧栏、顶栏按钮会整块不画（表现为「内容消失」，元素还能点）。所以夜间统一 `backdrop-filter:none !important`，玻璃感靠层次/描边/内阴影/颗粒表达。

### 12.4 只改前端时的快速刷新（不用重打包）

析题台是 `file://` 打开的静态页，改了 `app/studio/web/**` 只要同步到发行目录即可，浏览器下次打开就是新版：

```powershell
# 在 10-projects/jianwei 下
python -c "import shutil,pathlib;s=pathlib.Path('app/studio/web');d=pathlib.Path('dist/Jianwei/_internal/studio/web');shutil.rmtree(d,ignore_errors=True);shutil.copytree(s,d)"
```

Python 侧（`app/*.py`）改动仍需 `python build.py` 重打包并重启。

---

## 13. 物理仿真：17 个场景（2026-10-25 晚）

- 原有 10 个（projectile / incline / spring / circular / wave / optics / circuit / efield / collision / gravity）全部修好「开始模拟没反应」：canvas 改为绝对铺满 `.ph-plot`，高度交给父级 flex/grid；每个场景都有随时间可见的变化。
- 新增 7 个：`efield2`（同/异号 + 可拖电荷 + 电场线/等势面 + 试探电荷沿场线）、`magnet`（B 可调、正负电荷、三维螺旋 + 残影）、`induction`（切割磁感线、Φ/E/I、楞次方向）、`gravity2`（低轨/转移椭圆/高轨/返回、开普勒等面积）、`shm`（弹簧/单摆 + x-t 同步 + 能量条）、`lens`（三条特殊光线、实/虚像、实时 u/v/m）、`interference`（条纹随 λ/d、屏上光强曲线）。
- 未知 kind 仍回退 projectile；每个场景 3 条 hints、中文单位滑块、stats；applyStep 0/1/2 画面两两不同。
- 自测：`tmp/motion-final.txt`（t=0 与 0.6T 哈希全不同、交互 play/pause/reset/scrub/slow/one-shot 全通过）；`tools/audit.py` AUDIT PASS。
- 夜间主题下画布用 `C.card` / `C.ink` 自动反差，昼夜都核对过。

---

## 14. 主题层重做：同一副骨架，两套颜色（2026-10-26 晨）

用户反馈：① 白天要像夜晚那样“有骨架”，只换颜色；② 有些界面没适配黑夜。

### 14.1 做法

`css/nocturne.css` 重写成「一套骨架 + 两套色板」：

- `html[data-theme="day"]` / `html[data-theme="night"]` 只定义变量：`--t-panel`、`--t-panel-solid`、`--t-border`、`--t-ink`、`--t-accent`、`--t-shadow`、`--t-field`、`--t-scrim`、`--t-radius` 等，并同步底座变量 `--paper/--card/--ink/--ink2/--line/--soft/--faint/--accent/--jade`（base CSS 全靠这些）。
- 其余组件规则统一写 `html[data-theme] …`，圆角/层次/描边/交互完全一致：白天是纸面玻璃（白 92%→72%），夜晚是无色玻璃（白 14%→7%）。
- 场景层 `#nv-scene` 白天是暖白 + 冷蓝微光，夜晚是深墨 + 两处光源 + 2.5% 颗粒。

### 14.2 夜间补齐的“洞”

| 界面 | 问题 | 处理 |
| --- | --- | --- |
| 学习助手抽屉 | 关闭状态也在 DOM 里，给了面板底色后整片盖住右栏（看起来像“文字被洗白”） | 只在 `.st-drawer.is-open` 上底色 |
| 导入弹窗 | 残留一行 `backdrop-filter` 让整块面板不画，只剩文字浮在页面上 | 删掉；面板改实底 `--t-panel-solid` |
| 立体几何下接框 | `<select>` 白底白字 | `--t-field` + `--t-ink` |
| 右栏年份吸顶头 | 用 `var(--paper)` 而上层被改成透明 → 吸顶不再遮挡 | 显式 `background: var(--t-paper)` |
| 场景搭建器 | 20KB 亮色 CSS，夜间半透明混色不可读 | 夜间保留**亮纸台面**（不透明纸底 + 深遮罩），里面的物理预览仍是深色仪器窗 |
| 列表项过渡 | 206 个 `.qi` 各带 transform 过渡，滚动时出现重影 | 只过渡背景，不动 transform |

### 14.3 排查工具

`tmp/preview.py`：每次生成带新版本号的临时页再截图，绕开 Edge 对 `file://` CSS 的缓存（这次误判的根源）。
`tmp/bisect2.py`：按分节切 CSS 并量化右栏暗像素数，用来定位“哪一段把界面洗白”。

### 14.4 本体（Qt）

`ui_kit.qss()` 的白天规则也换成同一骨架：卡片 12px 圆角、按钮 10px、底部变量仍走 `_THEMES` 的 day/night 替换（所以 QSS 里只许写调色板里有的颜色值，写 `#FFFDFA` 这种“调色板外的颜色”会导致夜间不替换）。
`Shell.paintEvent` 白天补了两处柔和光斑（暖白 + 淡蓝），和夜晚的光源结构对应。

### 14.5 追加（同日晚些）

- 错题本空态（`.st-empty`）原来在夜里是浅灰底 + 浅字，已改成玻璃底 + 可读文字（昼夜都套 `--t-*`）。
- 夜间底座变量补了一整套映射：`--paper: rgba(0,0,0,0)`（让画布透出玻璃）、`--card/--ink/--ink2/--line/--soft/--faint/--accent/--jade`；吸顶年份头因此不再透出下层文字。
- 列表项 `.qi` 不再对 `transform` 做过渡（206 个元素各自合成层，滚动会重影）。
- `tmp/preview.py` 增加 `click=` 参数：可以“打开某控件后再截图”，用来核对抽屉、错题本、搭建器这类交互态。

---

## 15. 模块拆分：习题台 / 变换实验室（2026-10-26 晚）

用户要求：两个模块**完全分开**；习题台少流程图、多动画指引与绘图；实验室要像 GeoGebra 一样自由，并带平移/旋转/缩放/对称；物理给一个自由工作台（运动学、力学、电学、磁场、电场、光学、波、万有引力）。

### 15.1 结构

| 页面 | 角色 | 入口 |
| --- | --- | --- |
| `index.html` | **习题台**（原析题台）：题库 + 引导动画 | Qt 导航「习题台」、托盘「习题台」 |
| `lab.html` | **变换实验室**：`?mode=math` / `?mode=physics` | Qt 导航「实验室」、托盘「变换实验室」、习题台页两个按钮 |
| `js/lab.js` + `css/lab.css` | 实验室外壳：三列、模式切换、主题、状态栏，给引擎一份 `shell` API | — |
| `js/lab-math.js` / `js/lab-phys.js` | 两个引擎（子代理实现），契约 `mount(shell) -> api` | — |

旧的自制「变换实验室」（app.js 里的 `openLab`/`setLabChrome`/#tabs）已全部删除；`#tabs` 也从 index.html 移除。

### 15.2 习题台改造

- 新增 `js/guide.js` + `css/guide.css`：画布底部的**引导条**（上一步/播放/下一步/重播 + 步点 + 一句话说明）与画布上的**聚光圈 + 标签**；打开一道题自动播一遍，手指一碰画面就停。
- 视图提供 `focus(i)`：`graph.js` 给出关键点/零点，`subjects.js` 的讲解模式给出当前行；没有 focus 的视图只显示文字引导。
- 通用「流程 / 因果链」模式从**方框+箭头**改成**讲义式逐行**（序号点 + 大字 + 细分隔线），和题目讲解步骤对齐；点行会驱动整套步骤。
- 右栏默认只留「解题路径」，知识点/同类题/为什么收进「补充材料」折叠（记忆状态）。

### 15.3 工具

- `tmp/shot.py`：任意页面 + 主题 + 可选点击选择器截图（带版本号绕缓存），实验室两个引擎的自测都靠它。

### 15.4 实验室两个引擎（已接上）

- **数学（`js/lab-math.js` 145 KB + `css/lab-math.css`）**：无限自适应网格、轴向数字、平移/缩放（拖空白、方向键、五键条、滚轮、双指、＋－、适配视野）；点/线段/直线/圆/多边形/向量/`y=f(x)`；吸附；选中光晕、拖点、Shift 多选、显隐、删除；**仿射变换**（平移/旋转/缩放/点对称/线对称），原像虚线 ghost、当前像实线，右栏显示本次 T 与累计 M，可连续叠加；预设（三角形四连演示、二次/三角/反比例/圆与切线）；测量（距离/角度/面积）；localStorage 自动保存；`exportPNG()` 按主题导出。
  自检 `__labMathTest()` → **12/12 PASS**，errors 空；昼夜均 PASS。
- **物理（`js/lab-phys.js` + `css/lab-phys.css`）**：按章节分组的物体库（运动学/力学/电学/磁场/电场/光学/波/万有引力），点选落到画布；属性检查器（质量、初速、抛射角、g、电荷、B/E、焦距、波长……）+ 实时读数；仿真播放/单步/复位/倍速/时间轴；矢量、轨迹、网格、比例尺、地面开关；12 个预设场景；导出 PNG / 清空场景。
  自检 `__labPhysTest()` → **7/7 PASS**（放置 8 类、改参重算、播放前进、暂停不动、复位归零、预设不报错、导出 PNG）。
  规模：**30 个可放置对象 / 8 个章节**（运动学 4、力学 5、电学 6、磁场 3、电场 2、光学 6、波 2、万有引力 2），**12 个预设**；1/240 s 定步长半隐式欧拉；支持 `?preset=id&t=秒` 深链。

**已知边界（写在引擎注释里，也记在这里）**：电学是“元件自由摆放 + 简化串联” `I=E/(r+ΣR)`，导线不参与拓扑；光学只取第一个光源/第一个透镜做三特殊光线；磁场仅垂直纸面；圆周为匀速模型；轨道演示内部时间 ×1200（读数真实量纲）；碰撞一维刚性；无撤销/重做；触摸端物体库拖放关闭（用点选落中央，画布双指缩放仍支持）。

两个引擎都只改了各自文件，外壳 `lab.js/lab.css/lab.html` 未动；接线在 `lab.html` 里按顺序加载 `lab.js → lab-math.js → lab-phys.js`。

### 15.5 打开方式

- 本体左侧导航「实验室」→ 两个按钮（数学画板 / 物理工作台）
- 托盘菜单「变换实验室」
- 直接 `lab.html?mode=math|physics&theme=day|night`

---

## 16. 暮省不能完全全屏（2026-10-27 晨）

现象：暮省页打开后窗口没铺满（留任务栏 / 像最大化而 not 全屏）。

定位：页面本身是满视口的（`html,body{width/height:100%}`、无 letterbox），问题在 **Edge kiosk 窗口**这一层——`--kiosk` 在不同 Windows/Edge 组合下会留任务栏，或按系统缩放开出「最大化但不是全屏」的窗口。

修法（vendored 观澜，`app/guanlan/core/` 两个文件）：

1. **kiosk 参数补全**（`core/evening.py`）：`--kiosk` 之外加 `--start-fullscreen`、`--edge-kiosk-type=fullscreen`；去掉 `--disable-software-rasterizer`（和 `--disable-gpu` 一起用会让部分机器画面不全）。
2. **窗口兜底铺设**（`_fit_window_to_monitor(pid)`）：拿到 edge_pid 后开一个线程，枚举该进程树的可见顶层窗口，取最大那个，按 `GetMonitorInfo` 的**物理监视器矩形**做 `SetWindowLong(WS_POPUP)` + `SetWindowPos`，无边框铺满；失败会自动重试 16 次（Edge 建窗有延迟）。
3. **页面手动兜底**（`core/evening_templates.py`）：右上角「退出全屏」左边加一个「全屏」按钮，调用 `requestFullscreen()`；已经在全屏时按钮自动隐藏，失败时提示按 F11。

验证：`py_compile` 通过；`_fit_window_to_monitor(…, apply=False)` 对真实进程能正确枚举窗口并取到监视器矩形；打包后 `--evening-no-open` 生成的页面里含 `enterFullscreen`；kiosk 实机全屏需要你在晚上 22:20 或手动点一次确认（无头环境无法验证真窗口）。

顺带：上一轮被打断的重打包已重做，`dist` 完整（含实验室两个引擎、习题台引导层、暮省修复）。

---

## 17. 暮省“起不来/报错”的排查与回退（2026-10-28）

现象：22:20 拉起暮省时失败。日志只有 `evening kiosk window not found for pid=1816`；`C:\Temp` 下当天没有 Edge profile 目录，`edge.pid` 是旧值。

排查结论（都写在 `tmp/probe-*.py` 里，可复跑）：

1. **页面本身没问题**：headless 打开生成的 index.html，0 个 JS 错误、15 页幻灯片。
2. **本地服务没问题**：`_EveningHandler` 直连返回 200 / text/html。
3. **机器上开着系统代理**（`127.0.0.1:7897`，Clash）。新 profile 的 Edge 可能把 `127.0.0.1` 也送进代理——已给启动参数加 `--no-proxy-server`。
4. **最要命的是我加的那层“找窗口/校验标题”逻辑**：Edge 常把窗口交给别的进程，用进程树找不到，判定失败后把刚起来的浏览器 `taskkill` 了——用户看到的就是“闪一下/报错”。已回退。
5. 顺带发现：这台机器上从本会话上下文起 Edge GUI 窗口会白屏（file:// 与 http:// 都白），但请求确实到达服务端；真机桌面里的 Edge 是否同样白屏未能复现，需要用户侧确认。

当前状态（已重打包，dist 里可验证）：

- `open_fullscreen` 回到 10-26 验证过的 kiosk 参数（`--kiosk` + 原 flag 组）。
- 窗口铺满改成 **`_best_effort_fit`**：按标题 `暮省 · YYYY` 找窗口，找到才铺满置顶，**找不到只记日志、绝不杀进程**。
- 页面右上保留「全屏」按钮（`requestFullscreen`），kiosk 异常时可手动补一刀。

待用户确认：报错到底长什么样（Edge 错误页 / Windows 对话框 / 见微提示），以便对症。

---

## 18. 回到旧观澜验证过的暮省启动配方（2026-10-30）

用户问“为什么之前可以”。翻旧观澜 `HANDOFF.md §5.6`，当时写明的关键点：

1. **file:// 不行**：Edge 在 kiosk 下会白页，必须本地 HTTP；
2. **GPU 必须关**：`--disable-gpu --disable-gpu-compositing --disable-software-rasterizer`；
3. 服务用**独立的 `python -m http.server 8899 --bind 127.0.0.1`** 进程，不是宿主进程里的线程；
4. profile 放 `C:\Temp\guanlan-evening-*`；
5. 启动后**重试 AppActivate**，防止被其他窗口盖住；
6. 退出靠页面 `window.close()`（已验证）。

对照发现我这几版偏离了 3、4、5，还自己加了 Win32 窗口铺设（就是“只覆盖左上角”的来源）。现在已恢复：

- 新增内部命令 `Jianwei.exe --evening-serve <port>`：独立进程提供静态页（等价旧 `python -m http.server`），实测打包版返回 200。
- `open_fullscreen` 改为：先起独立服务 → 等 200 → 写 `play.ps1`（参数与旧版一致、profile 回 `C:\Temp`、AppActivate 重试 12 次）→ 等 Edge 退出 → 收服务进程。
- **删掉全部 Win32 窗口铺设/校验/杀进程逻辑**（`_fit_window`、`_wait_titled_window` 等不再被调用）。
- 页面右上「全屏」按钮保留作手动兜底。
- `--evening` 恢复为“生成页面 + 浏览器 kiosk”；逐页渲染 + Qt 播放器（`evening_slides.py` / `evening_viewer.py`）保留但未接入，作为以后兜底方案。

验证（未开前台窗口）：打包版 `--evening-serve 8898` 返回 200；`play.ps1` 的参数与旧配方逐字一致；服务进程可正常回收。

---

## 19. 暮省改用「逐页渲染 + 自带播放器」（2026-10-30）

浏览器 kiosk 在这台机器上始终不稳（Edge 起了就退、窗口白页），根因与 UAC 关闭、Edge 156 在提权令牌下的行为有关，参数层面已试遍：单 HTTP 服务、GPU 三项关闭、C:\Temp profile、AppActivate 重试、`$args` 保留字修复——簇仍会 6~20 秒退出且不建窗口。

新主路径（已验证出画面）：

1. 生成暮省页（同旧流程）；
2. `evening_slides.render()`：无头 Edge 按 `?preview=1&slide=N` 逐页截图，**4 线程并发、每页独立 profile**，11 页约 37 秒，输出 `%LOCALAPPDATA%\Guanlan\evening\slides\slide-NN.png`；
3. `evening_viewer.show()`：见微自己的 Qt 全屏播放器（无边框 + 置顶），等比铺满，支持 ←/→/空格翻页、Esc 退出、末页自动关闭、26 秒自动翻页、底部进度条；
4. 渲染失败才回退浏览器 kiosk。

实测：打包版 `Jianwei.exe --evening` 60 秒内在 1920×1080 全屏显示 `暮省 / 2026.10.30 / 11 页`，窗口标题「暮省」，PrintWindow 抓图内容正确。

已知取舍：幻灯片是静态截图，页面里的按钮/进度点不可点（翻页改用方向键/点击左右半屏）；封面 3 分钟节奏改为每页 26 秒。

补充：托盘菜单「暮省全屏」与 22:20 内部定时现在都改为 **spawn `Jianwei.exe --evening`**（`guanlan_host.evening()`），与计划任务走同一条已验证路径，界面线程不再被渲染阻塞。

---

## 20. 暮省白屏/起不来的最终根因：Chromium 沙箱（2026-11-02）

结论：**这台机器 UAC 关闭（EnableLUA=0），所有进程都是管理员令牌；Edge 156 的渲染进程沙箱在这种环境下起不来**，页面能请求到（服务端 200）但窗口空白或直接退出。加上 **`--no-sandbox`** 后一切正常。

验证矩阵（`tmp/token_probe*.py`）：

| 组合 | 结果 |
| --- | --- |
| 旧参数（GPU 三项关闭） | 进程在、无窗口 / 白窗 |
| 旧参数 + `--no-sandbox` | **窗口「暮省 · 日期」1920×1080，画面正常** |
| `--no-sandbox` + `--disable-gpu-sandbox` | 正常 |
| 降权令牌（Safer NORMALUSER / CreateRestrictedToken+LUA） | 令牌造出来了（Low 完整性），但 Edge 无法在受限令牌下启动（err 5） |
| `--app` / `--kiosk` / 默认 profile | 都不如 `--no-sandbox` 有效 |

另外两个坑，一并记下：

1. **会话不同看不到窗口**：`query session` 显示控制台是 3 号会话，而计划任务有时在 1 号会话；Windows 的窗口枚举**跨会话不可见**，所以“找不到窗口”有时是探测端在另一个会话里。
2. 输出重定向与 `$args` 保留字：PowerShell 里不能用 `$args` 当变量名（已改 `$ea`）。

当前暮省链路（已打包验证）：

1. 生成页面 → 2. 独立进程 `--evening-serve 8899` 提供静态页 → 3. `play.ps1` 用 kiosk 启动 Edge，参数 **含 `--no-sandbox`** → 4. 20 秒内按标题找窗口，找到才继续；5. 找不到则回退“逐页截图 + Qt 播放器”。

验证记录：打包版 `Jianwei.exe --evening` 日志出现 `evening window ready: '暮省 · 2026.11.02 ...'`，PrintWindow 抓图内容为封面「暮省 / 2026年11月2日 周一 / 今日 7 则」。

补充两点（同日）：

- **防重入**：`core.evening.run()` 开头用 `evening.lock`（msvcrt 非阻塞锁）保证同一时刻只播一次；内部定时与计划任务同时触发时，后到的记 `another evening instance is running; skip this trigger`。实测第二条触发被正确跳过。
- **安全取舍**：`--no-sandbox` 会关闭渲染进程沙箱。暮省页是从本机 8899 端口加载的**自生成静态页**，不访问外网；这个取舍只作用于该 kiosk 进程，不影响用户日常 Edge。

---

## 21. 实验室换成「格物实验台」（2026-11-03）

用户要求：把格物实验台（`F:\space for Claude\lab`）接进见微，替换原变换实验室，并把原实验室有、格物没有的功能整合进去。

| 部分 | 位置 | 说明 |
| --- | --- | --- |
| 实验台本体 | `app/studio/web/gewu/` | 从 `lab/` 拷来（67 个实验、自由工作台、题目导入）；`index.html` 改了品牌、异步加载网络字体（被墙时不卡首屏）、读 `?theme=day/night` |
| 见微配色 | `gewu/jianwei.css` | 纸底墨蓝 / 深墨冷光，只换底色文字线条，学科色保留 |
| 接入层 | `gewu/jianwei.js` | `#subj/<math/phys/chem/bio>` 入口；标签页标题跟随当前实验 |
| 原变换实验室 → 两个新工作台 | `gewu/bench-legacy.js` + `gewu/legacy/` | 「几何画板」= 原 `lab-math.js`（点线圆、函数、仿射变换、测量）；「场景搭建」= 原 `lab-phys.js`（30 类物体 8 章、光学/波/天体、12 预设）。适配器给出原 `shell` 接口；引擎只挂载一次，切走只搬 DOM（状态保留），挂到 window/document 的键盘与指针监听只在该工作台打开时放行 |
| 样式桥 | `gewu/legacy/legacy.css` | 原 `--t-*` 变量映射到格物色板 + 原外壳通用件 `.lab-*`；`#lab-left/#lab-right` 已改为 `.lg-left/.lg-right` |
| 本机服务 | `app/studio_server.py` | 固定端口 **27631**（localStorage 按源隔离，端口变了画板与导入记录就“丢了”），被占用才退随机端口；关掉 `allow_reuse_address`（Windows 上会和别的程序共用端口）；新增 `/gewu/api/health`、`/gewu/api/chat`（DeepSeek 转发，校验 Origin，别的网页借不走密钥）；`/gewu/api/catalog` 不提供 |
| DeepSeek 密钥 | `store.deepseek_settings()` / `save_deepseek_key()`，设置页卡片 | 环境变量 `DEEPSEEK_API_KEY` 优先，其次 `%LOCALAPPDATA%\Jianwei\deepseek.env`（与 lab/.env 同格式）；每次请求现读 |
| 入口 | `shell.open_lab(target)` | target 为实验台内路由：`""` 首页、`bench`、`bench/draw`、`import`、`subj/phys`……；旧名 `math/physics` 自动映射到 `bench/draw` / `bench/scene` |
| 本体页面 | `pages.build_lab` | 四科实验数（`store.lab_stats()` 扫描脚本得出）、五个工作台、导入状态；今日页「模块」加一行；习题台页按钮改为跳实验室页 |
| 习题台 | `index.html` 顶栏 | 新增「格物实验台」按钮，带主题和当前题目的学科 |

已删：`lab.html`、`js/lab.js`、`css/lab.css`（引擎与其 CSS 移到 `gewu/legacy/`），以及开发残留 `_syntax*.html`。

顺手修：`main.py` 里 `--evening-serve` 分支的 `from pathlib import Path` 让 `Path` 变成 `main()` 的局部变量，`--self-test` 一跑就 `UnboundLocalError`；已删。提示条改为窗口底部居中，不再压住侧栏页脚。

验证：offscreen `--self-test` 六页出图正常（实验室页、设置页昼夜两套）；服务端脚本测试 page 200 / health / 跨站 POST 403 / 无密钥 400 / 端口被占退随机；浏览器里几何画板、场景搭建、化学工作台来回切换状态保留、无 JS 报错，昼夜切换画布实时换色。

注意：`gewu/` 是 `lab/` 的副本（加了见微专属文件）。以后改格物实验台，两边要同步：通用实验改 `lab/` 后拷进来；`index.html`、`import.js` 的引擎提示文案、`jianwei.*`、`bench-legacy.js`、`legacy/` 是见微专属。

## 22. 全面检查（2026-11-03，v1.2）

| # | 问题 | 修法 |
| --- | --- | --- |
| 1 | `store.questions()` 用正则切题，把生物食物网视图里的 `id:'草'/'兔'/'鹰'…` 也当成题（212 条，含 6 条空题、1 个重复），今日一题 / 随机一题可能落到空题上 | 没有 `subject` 的跳过、同 id 只取第一条（与网页 `JW.addQuestions` 口径一致）；现与网页题库逐条比对 206 = 206 |
| 2 | 22:20 内部定时仍在进程内跑 `core.evening.run`（没有逐页播放器兜底、还占一个线程），与 §19 的设计不符 | 改为调 `guanlan_host.evening()`，与托盘「暮省全屏」同一条独立进程路径 |
| 3 | `config.json` / `deepseek.env` 带 BOM（记事本另存）时解析失败 → 配置被默认值静默覆盖、密钥读不到 | 用户可编辑的文件统一按 `utf-8-sig` 读；配置解析失败先改名留底 `config.broken-时间.json` 再重写 |
| 4 | 倒计时「极光」滑杆范围 0–90，默认值 96，一碰就被截成 90 | 范围放到 0–160 |
| 5 | 夜间滑杆已填充段是近白色，刺眼 | 夜间 `sub-page` 用香槟金 |
| 6 | 每次启动都弹「胶囊已显示」 | 启动时静默显示胶囊 |
| 7 | 「2023—2025」写死在四处，题库实际含 2026 | `store.bank_years()` / 网页按题目年份计算 |
| 8 | 观澜首次使用空态只有「今日版尚未生成」；今日页写「共 0 条 · 约 15 分钟」 | 给出「点刷新内容」的说明 |
| 9 | 标题栏副标题与时钟底对齐，看着像错位的第二行 | 同一中线对齐；提示条圆角放大 |
| 10 | 今日页距考时刻写死 09:00 | 显示目标时刻的真实时分 |
| 11 | `switch_to_jianwei.py` 第 73 行 f-string 引号嵌套是语法错误（脚本根本跑不起来）；`RUN_PS` 无效转义 | 修正 |
| 12 | 若干未使用的导入/变量；`evening.py` docstring 无效转义告警 | 清理 |

检查范围与结果：pyflakes（见微自身代码 0 告警）；`node --check` 全部前端脚本 0 失败；`tools/audit.py` AUDIT PASS（206 题、4 引擎、0 异常）；格物实验台 67 个实验 + 5 个工作台 + 首页/导入/工作台首页共 75 个路由逐个挂载 0 报错；几何画板自检 12/12、场景搭建自检 7/7（在工作台内运行）；昼夜两套 Qt 页面截图复核。

## 23. 全面美化（2026-11-03，v1.3）

| 部分 | 改动 |
| --- | --- |
| 倒计时胶囊 `countdown.py` | 两端留白按圆角算（以前右侧时钟挤进半圆）；极光从几团小光斑改成横向拉长的柔光带；天数改用等高数字衬线（Georgia 旧式数字 5 会掉到基线下）；第二行字号下限 9px；分隔线两头渐隐；底缘进度线渐变 + 末端光点；左栏加「已走 x%」 |
| 观澜浮窗 `guanlan/ui/` | 档案页容器样式按 objectName 限定（以前 border 级联到每个 QLabel，每行字都套框，第三个方块被挤出右缘）；人物/金句/档案页同类容器一并修；`TextBlock` 加避头尾（「。」不再单独成行）和 `fit()`（高度跟随实际行数，消掉标题与正文间的大空当）；页面顶部留白；金句卡高度 214→178；`clear_layout` 先 hide 再 deleteLater（重建时不叠影） |
| 主窗口 `shell.py` / `ui_kit.py` | 侧栏六个线性图标（选中墨蓝 / 夜间金色，换主题重画）；侧栏底部换成「距考天数 + 学期进度」小卡；数字字体改 Cambria（等高数字）；修 `restyle_tree` 夜→昼不还原的老 bug（标题栏「见微」变成浅色看不见） |
| 习题台 `css/polish.css`（最后加载） | 函数视图的解析式 / 旋转矩阵原本没有任何样式（裸文本），改成画布上方两张小卡；画布下的微调键改成一排轻按钮；画面内引导条与下方播放器重复 → 引导条只保留一句旁白（胶囊样式），控制交给播放器；画布左上角操作说明降为淡字 |
| 打包环境 | **v1.1/v1.2 绿色版缺 `requests`/`bs4`，观澜抓取不可用**——本机新建的 .venv 当时只装了 PySide6 和 PyInstaller。已补装，v1.3 起恢复；以后重建环境记得 `pip install PySide6 pyinstaller requests beautifulsoup4` |

## 24. 题目分析参照 VeloΦ + 习题台 / 实验台内嵌窗口（2026-11-03，v1.4）

### 题目分析（`gewu/solver.js` 新增、`gewu/import.js` 重写主流程；`lab/` 同步）

参照 VeloΦ 26.59 的 AI 读题（github.com/Stevenzhang543/VeloPhi，`src/ai/import/`）：AI 只读题、列式，数值由程序算，每一步输出都校验。

| 做法 | 实现 |
| --- | --- |
| 方程模型复算 | 第一步多一个 `model`（knowns 按题目原单位、unknowns 国际单位、equations 带 `why`、asks 带模型自己的 `claimed`）。`solver.js`：自写表达式解析器（不用 eval，白名单函数，支持 `2√3`、`²`、隐式乘法）+ Levenberg–Marquardt（多初值、上下界）+ SVD 零空间判断「条件不足」+ 相对残差判断「互相矛盾」。复算与 `claimed` 不符 → 第四步重新检查；无唯一解 → 先把结论发回让模型复查一次 |
| 校验 / 修正循环 | `askJSON(engine, msgs, check)`：读不出 JSON（空、截断、夹杂文字）或校验不过（subject、实验 id、控件名、选项值、单位、方程语法）→ 把问题清单发回，最多两次，DeepSeek 对话模型最后一次改用推理模型；只有可选的方程模型不合格时退回「不带模型」继续 |
| 单位、角度 | 滑块值可写 `{"value":72,"unit":"km/h"}`，程序换算到控件单位；题目写了 sin37° = 0.6 时 37° → 36.87°（方程已知量与滑块都做） |
| 网络 | 连接失败、429/5xx 自动重试一次 |
| 讲题卡 | 新增假设、思路与规律、检验、易错点、结论；「程序复算」一栏：AI 解答 / 程序复算逐问对照 + 可展开的方程与依据 |
| 实验核对 | 正方向约定不同（读数 −3.92、答案 4）按大小比较；协议要求实验常数（g = 9.8）与题目不同时不配对 |
| 转发服务 | `studio_server.chat_payload()` / `lab/serve.py build_payload()`：接受多轮 `messages`（旧网页的 `user` 仍兼容），对话模型 `max_tokens` 8192，返回 `truncated`、`transient` |

验收：`solver.js` 单测 30 项（含矛盾、条件不足、角度对齐、单位）；页面内用模拟回复走通「截断 → 修正 → 实验 id 错 → 修正 → 复算不符 → 第四步改正 → 控件名错 → 修正 → 单位换算 / 角度对齐」；真实 DeepSeek（对话模型）斜面题一次通过，模型写出的方程模型复算 a = 4 m/s²、t = 2 s 与答案一致。

### 内嵌窗口（`app/webwin.py`）

- 习题台、格物实验台、导入题目、自由工作台都在见微自己的 QtWebEngine 窗口里打开（`Shell.open_web()`；`open_studio` / `open_lab` 都走它）。QtWebEngine 不可用时退回 Edge。
- `main.py` 在 QApplication 之前设 `AA_ShareOpenGLContexts`（QtWebEngine 要求）。
- 存储：命名配置 `jianwei`，落在 `%LOCALAPPDATA%\Jianwei\web\storage`；习题台仍是 `file://` 源，实验台仍是 `http://127.0.0.1:27631` 源。
- 站外链接交给系统浏览器；`target=_blank` 在本窗口打开；下载弹「另存为」；JS 错误写 `logs/web.log`。
- 换昼夜不刷新页面：习题台调 `JWTheme.set`，实验台点它自己的主题按钮（注意 `App`、`Lab` 是顶层 `const`，不在 `window` 上，要用 `typeof App`）；夜间标题栏用 DWM 深色。
- 关窗只是隐藏（位置记在 `web/window.json`）；退出见微时先删窗口再停服务。
- 从 Edge 搬旧记录：窗口顶部一次性提示 →「搬过来」→ `StudioHost.open_migration()` 在 Edge 开 `web/migrate.html` 两次（`file://` 源、本机服务源）→ 页面把 localStorage POST 到 `/gewu/api/migrate`（启动时生成的口令；`file://` 的 Origin 是 `null`，只收 `jw.*` 键；主题键不搬）→ 存成 `web/migrate-<源>.json` → 内嵌窗口加载到对应源时写入（没有的键直接写，列表合并去重，已有的不覆盖），改名 `.done`。
- 自检 `--self-test` 增加 `WEBWIN_AVAILABLE` / `WEBWIN_PAGE`（`QT_QPA_PLATFORM=windows` 时真的加载实验台并跑脚本；offscreen 下 GPU 上下文会丢，只报可用性）。
- 体积：QtWebEngine 钩子原样会带上 QML、Qt Quick 3D、开发者工具、全部语言包（解压 603 MB）。`build.prune()` 在打包后从 WebEngine / Widgets / 插件出发沿 PE 导入表找依赖，删掉没人引用的 Qt DLL、.pyd、`qml/`、devtools 资源、除中英文外的语言包 → 解压 363 MB，绿色版 zip 约 154 MB（v1.3 是 61 MB，主要多了 194 MB 的 Qt6WebEngineCore.dll）。冻结版自检 `WEBWIN_PAGE object/object/67` 通过。
- 习题台夜间顺手修了一处老问题：解题路径的当前步在 `ux.css` 里写死白底，夜间白底浅字看不见 → `polish.css` 给夜间换成淡金底。

## 25. 数学 / 化学 / 生物的程序题型（2026-11-04，v1.5）

用户要求「以 VeloΦ 为榜样，改进数学、化学、生物的题目分析」。VeloΦ 的物理读题里，属于六个「任务领域」的题由专门的解析求解器算（优先级最高），模板 / 方程模型只是兜底。这里照搬到三科：新增 `gewu/tasks.js`（`lab/` 同步），AI 在第一步填 `task`（可为数组），程序用专门算法求解，与 AI 的 `claimed` 逐项对照。

| 学科 | 题型（kind） | 程序做什么 |
| --- | --- | --- |
| 数学 | func 函数分析 | 求零点（变号二分 + 偶重根黄金分割，排除间断点）、极值、最值、单调区间、切线、定积分（Simpson） |
| 数学 | conic 直线与曲线 | 曲线隐式方程 + 直线参数化求交点 → 弦长、中点、三角形面积、点线距离、交点个数 |
| 数学 | solid 立体几何 | AI 只给坐标；`given` 里的棱长 / 垂直 / 平行先核对，不符退回；算距离、线线角、线面角、二面角（沿棱的真实二面角或锐二面角）、点面距、体积、面积 |
| 数学 | prob 概率分布 | 二项、超几何、正态（erf）、分布列（和须为 1）；事件 P、E、D |
| 数学 | seq 数列 | 等差 / 等比 / 递推求项与和；**检验 AI 求出的通项公式**（前 20 项逐项比对） |
| 化学 | reaction 方程式与计量 | 原子 + 电荷守恒检查（不守恒退回并附程序配平结果，复用 chem.js 的 balance）、摩尔质量（教材相对原子质量）、不足量、产率、剩余量、配平式比对 |
| 化学 | solution 溶液 pH | 强酸碱、多元弱酸碱、弱酸强碱盐、强酸弱碱盐、混合稀释；电荷守恒对数二分精确求 [H⁺]、电离度 |
| 化学 | equilibrium 化学平衡 | 三段式：由 K / 平衡量 / 转化率求反应进度，算 K、浓度、分数、转化率、压强比 |
| 生物 | cross 遗传杂交 | 配子枚举（任意对数、复等位基因、共显性 / 不完全显性、伴 X、致死），select 选表型后 self / random 多代；概率（含条件概率）、表型比、基因型比 |
| 生物 | dna 碱基与中心法则 | 互补链、转录、翻译（复用 bio.js 密码子表）、GC 比例、氢键数 |
| 生物 | foodweb 能量流动 | 按比例与效率精确计算，或「至少 / 最多」走最短 / 最长链 |

其他：
- `solver.js`：`Solver.exact()` 识别精确值（分数、k√m/q、(a+b√m)/q、kπ/q），容差 1e-12~1e-13，2 万个随机数 0 误认；`comb/perm/fact` 进函数白名单；`Solver.fn()` 编译单/多变量函数。
- `import.js`：`check1` 里 `buildTasks` 校验（不合格进修正循环，只有 task/model 不合格时可退回无 task）；`verifyAll` 合并题型与方程模型的不符证据，**只让 AI 重新检查一次**；重新检查的结论存 `l.recheck`（旧记录在 `l.calc` 上，卡片兼容）；第一步提示词里附 `Tasks.catalog()`（约 5K 字）。
- `parse()` 先严格解析，失败再 `lenient()`：字符串外的 `1.8×10⁻⁵`、`1.8×10^-5`、裸分数 `1/16`、结尾逗号自动修好（实测 DeepSeek 写过这种 JSON，以前要多一轮修正）。
- 遗传题的坑：豌豆的 Y/y 不能被当成 Y 染色体（只有存在伴 X 位点时 Y 才是染色体）；条件字符串带 `_` 是表型，否则是基因型（`"AA"` 致死）。
- 化学电荷写法：推荐 `Fe^3+`；没写 ^ 时单元素 `Fe3+` 读作 3 价、多原子一位数字 `NH4+` 读作下标 + 1 价、`SO42-` 有歧义退回。

验收：`skill/tasks.test.js` 89 项全过（每科都有反例：坐标不符、未配平、电荷歧义、概率和不为 1、伴 X 两雌）；页面模拟「参数错 → 修正 → 答案错 → 程序 1/16 对 1/8 → 改正」走通；真实 DeepSeek（对话模型）三题：正方体线面角 1/3 + 体积 2/3 ✓、醋酸滴定两个点 pH 4.74 / 8.72 ✓（task 数组）、豌豆 F₁ 黄圆自交 yyrr = 1/36 ✓（修 Y/y 后一次通过）。

## 26. 分析提速 + 题型图解（2026-11-04，v1.6）

### 提速

| 做法 | 效果 |
| --- | --- |
| 流式转发：`studio_server.stream_reply()` / `lab/serve.py stream_reply()` 把 DeepSeek 的 SSE 转成每行一个 JSON（`{"d": 正文增量}`、`{"r": 思考字数}`、`{"done": true}`）；`Importer.ask()` 边收边交给 `onText` / `onThink` | 第一步一边写一边在导入页显示草稿（题意、已知、步骤逐条出现，`peek()` 从没写完的 JSON 里取字段）；实测 1.6 s 出草稿、2.3 s 出第 1 步 |
| 默认引擎改为对话模型（有程序核对兜底），推理模型改名「深度思考」；记住上次的选择 | 单次调用从 10~20 s 降到 3~5 s |
| AI 重新检查（第四步）不再阻塞：`verifyAll` 把它放进 `l._fix`，与配置实验（第二步）同时跑，用到最终答案（第三步）前再 await | 模拟测得两步完全重叠 |
| 程序求解已全部核对一致时跳过第三步（实验读数配对），卡片上写「已由程序核对」 | 省一次调用和最多 9 s 的读数等待 |
| 同一道题（同一引擎）分析过就直接打开记录；卡片上有「重新分析」 | 0.8 s 打开，不调用模型 |
| 状态行带计时；卡片记下用时与调用次数 | — |

实测（DeepSeek 对话模型，正方体线面角 + 体积，含打开实验、配置参数）：全程 8.2 s、2 次调用（v1.5 默认推理模型时一步就要 10~20 s，共 3~4 次串行调用）。

### 图解（新增 `gewu/viz.js`，`lab/` 同步）

`tasks.js` 每个题型的 `run()` 多返回 `viz`（普通 JSON，随记录保存），`Viz.mount(host, 题型结果, key)` 画成可以一步步翻的 SVG 图，讲题卡下方「图解」一栏；翻到第几步、立体图的视角记在 `Viz.state[key]`，卡片重画不丢。

| 题型 | 图解的几步 |
| --- | --- |
| func | 图像 → 零点 → 单调性（导数正负着绿 / 红）→ 极值 → 最值 → 切线 → 定积分有向面积 |
| conic | 曲线（行进方块法画隐函数）→ 直线 → 交点 → 弦 / 中点 / 三角形 / 垂线段，等比例坐标 |
| solid | 自动求凸包得到棱，被挡住的棱画虚线，可拖动旋转；每一问高亮对应的线、面：线面角画两端垂线与射影，二面角画平面角，体积把面填色 |
| prob | 分布列柱状图 / 正态曲线，事件对应的柱或面积高亮，期望线、E ± σ |
| seq | 前若干项的点图（只画到所问项附近）、前 n 项和 |
| reaction | 方程式 + 分子小球 + 原子守恒表（✓/✗）→ 各物质的物质的量条形图（给的量、反应 / 生成的量、不足量） |
| solution | pH 色带与指针 → 弱电解质各形态的分布曲线（标出当前 pH 处的比例） |
| equilibrium | 三段式表 → 起始 / 平衡条形图 → K 的表达式与数值 |
| cross | 双亲配子 → 棋盘法（按表型着色、致死格划掉）→ 概率问题圈出事件格（条件概率的条件格虚线框）→ 表型分布 |
| dna | 双链与氢键（2 / 3 条）→ 转录出 mRNA → 密码子与氨基酸 |
| foodweb | 食物网（逐级 / 跨级箭头错开）→ 每一问用到的食物链高亮，节点旁写需要的量 |

自测：`skill/viz.gallery.js` 在页面里画出 13 张图（返回出错的题型）；昼夜两套主题都看过。修过的显示问题：σ 标注压住柱顶数字、pH 标签压住曲线名、数列指数增长时前面的项看不清、食物网跨级箭头与逐级箭头重叠、线面角的射影画到了几何体外面（改为线段两端作垂线）。

## 27. 流畅性优化（2026-11-04）

用户要求「优化流畅性」。先写基准（PySide6 实测，单位 ms），再按热点改：

| 热点 | 原因 | 改法 | 前 → 后 |
| --- | --- | --- | --- |
| 观澜面板里任何小重绘（标签悬停、滚动、动画帧、刷新转圈） | `Panel` 挂着 `QGraphicsDropShadowEffect(blur 42)`：子控件一重绘，整块面板离屏重画再模糊 | `theme.paint_shadow()`：预先模糊好的九宫格阴影，由 `MainWindow.paintEvent` 贴在面板外围；`Panel` 底板（渐变 + 噪点 + 描边）按尺寸缓存成图 | 标签栏重绘 9.0 → 0.5；滚动一步 12.3 → 3.5；整面板 10.3 → 3.5 |
| 倒计时胶囊常驻 20 fps 全量重画 | 每帧重算底色、极光、文字、字体 | `draw_pill` 拆成 base / motion / top 三层（预览与自检仍用合成的 `draw_pill`）；浮窗缓存 base（配置 / 尺寸 / 壁纸变才重画）和 top（每秒）；帧率自适应：掠光扫过 30 fps、平时 10 fps、关极光 4 fps；`_font` 加 lru_cache | 每帧 3.1 → 0.8；主线程占用约 62 → 14 ms/s；掠光反而更顺（20 → 30 fps） |
| 胶囊每 30 秒卡一下 | `_grab_bg` 每次把整张壁纸平滑缩放到屏幕大小（4K 壁纸几十毫秒） | 缩放结果按（壁纸路径 + 修改时间, 屏幕尺寸）缓存，平时只裁一小块；换壁纸 30 秒内跟上 | — |
| 主窗口局部重绘 | 纸底四个大径向渐变每次重算 | `Shell.paintEvent` 按（尺寸, dpr, 主题）缓存底图 | 整窗 13.1 → 9.6 |
| 开机后第一次点开习题台 / 实验台要等很久 | QtWebEngine 冷启动（加载 Chromium、杀毒扫描子进程） | 启动 12 秒后 `Shell.prewarm_web()`：起本机服务 + `webwin.prewarm()` 用一张隐藏空白页拉起渲染进程；真窗口建好 3 秒后释放；`aboutToQuit` 时立即销毁（页面晚于 profile 销毁会让退出卡死——测试时踩到过）；配置 `prewarmWeb: false` 可关 | 冷启动实测 22 s 建窗 / 63 s 加载；预热后 0.08 s / 0.9 s（不预热的热启动 0.5 s / 1.6 s） |

验证：胶囊缓存分层与一次性绘制逐像素比对（最大通道差 8，仅 80 个边缘像素）；观澜面板截图前后一致；`--self-test` 通过；预热后直接 `app.quit()` 与走 `quit_app()` 都能正常退出。基准脚本思路：offscreen 下 `widget.repaint()/grab()` 计时（见本节表格）。

## 2.0 暮省原生化（2026-11-05）

- 上面关于 Edge、kiosk、`--evening-serve`、`play.ps1`、逐页截图的记录都是 1.x 的历史，2.0 已全部移除。
- `guanlan/core/evening.py` 只产出纯数据：`prepare()` 写 `%LOCALAPPDATA%\Guanlan\evening\deck.json` 和 `晚间暮省/archive/<日期>.json`。
- `native/evening.py` 全屏播放：4 种材质 × 4 种封面版式，字号按屏宽算，放不下整页缩小（下限 0.55）。
- 入口只有一条：`Jianwei.exe --evening`（独立进程，evening.lock 防重）；`--evening-date YYYY-MM-DD` 重播往期；`--evening-no-open` 只生成。
- 测试时必须把 `LOCALAPPDATA` 也指向临时目录：`evening_page_today()` 看 deck.json 的日期，写到真实目录会让当晚的定时暮省被跳过。

## 2.0 课件（2026-11-06）

`native/lecture/`：导入 Word / PPT / PDF，全屏放映，笔画，框选后带入黑板或上网查询。
- `convert.py`：统一转 PDF。先用 Office / WPS（PowerShell + COM，禁用宏；上次成功的引擎优先，超时只放弃不杀 Office；用户本来开着就不 Quit），都没有用内置方式（见下）。
- `pageview.py`：QPdfDocument 渲染、缓存、缩放，笔迹存页面坐标（`ink.py`）。框选后 `text_in_rect` 逐字取文字层。
- `board.py`：黑板，无限画布，存在课件目录 `board/`。可成独立窗口（`player.BoardWindow`），有第二块屏时放那块屏。
- `lookup.py`：搜索。预热连接（开始框选就握手）+ 并发 + 先到先显示；相关性过滤。必应对程序访问会返回随机内容，百度要验证码，都没用，也不要去绕。无文字层时用 Windows 自带 OCR（常驻 PowerShell 进程）。
- 只发送文字，不上传截图。AI 摘要用 DeepSeek，没密钥就只有资料卡片。
- 动画（anim.py / effects.py）：每个动画步骤是 PDF 的一页（COM 脚本复制幻灯片并隐藏形状 / 把段落设全透明；内置排版直接少画）。放映时比较前后两页，变化的像素做成图层放效果，所以任何引擎都能放。`anim.json` 是页码和步骤的对应表，没有这个文件就是一页一步。PageView.page 是第几张，PageView.pdf 才是 PDF 页码；笔迹按张存。动作路径 / 强调只做脉冲。
- 核查（lookup._verify）：结果先显示，DeepSeek 流式回 JSON，每判完一条就亮一条，结束后重排，筛掉的折叠。结论里引用被筛掉的编号会被去掉。只看摘要，界面上写明了。
- 无 Office：builtin.py 画图表、SmartArt、公式 EMF（GDI+ 转 PNG）；legacy.py 自己读 CFB，.ppt 取文字 / 位置 / 图片，.doc 取正文和图片，.rtf 取文字。
- 视频、音频不播放。
- 自测：`python -m native.lecture.selftest <dir>`（离屏，不联网）。

## 当前交付：2.3.0（2026-11-06）

画笔与互通阶段 1–5 已完成。下方阶段 1/2 记录为历史状态，不能据此判断当前阶段未开始。版本源为 `app/store.py`。

核心接口：`kit/clip.py` 的 ClipStore/ClipBus 由 NativeWindow 显式持有；`lecture/board_transfer.py`、`lecture/transfer.py` 与 `lecture/inserts.py` 管理双向传送与虚拟插页；`kit/bench_transfer.py` 为五个工作台添加参考图、批注、状态快照、脱离窗口；`clip_ui.py`/`transfer_router.py` 管理通用交互与素材篮。数据新增 clips/、workbench-notes/、workbench-state/；几何画板仍以 lab-math.json 为权威存档，关闭时刷新，不用二级缓存覆盖它。

Clip v1 只接受受控 UUID/本地资产名，矢量笔迹与图像分层；state_graph 使用受限数据图，无任意类反序列化。素材篮裁剪索引不删除已被插页引用的资产。插页使用稳定 history_id，清空笔迹后也持久记录空层。原文件及动画映射不变。

新增专项：`native.kit.clip_selftest`（11 项）、`native.kit.workbench_selftest`（五工作台及比例标定）、`native.kit.interop_selftest`（17 项）。既有课件、析题、题库 412 次、67 实验/5 工作台回归通过。所有测试用 test_runtime + 隔离数据，不启动 Word、不强杀、不读真实密钥；自测环境跳过后台 OCR/联网预热，Qt 回调异常算失败。真机边界与复现步骤见 RELEASE-0.2.3.md。

发行用 `python tools/release.py build` → `smoke` → `pack`；只在独立 release-2.3-2026-11-06/source 调用 build.build()，不覆盖 src2/dist 或桌面快捷方式。打包核对源码指纹、冻结版结果、ZIP CRC、SHA256；桌面 AI 只新增 v2.3 压缩包。


最终冻结版验收（2026-11-06）：returncode=0；pen=PEN_OK、clip=OK、work-transfer=OK、interop=OK、lecture=LECTURE_OK，TEST_PROCESS_EXIT 0。报告：release-2.3-2026-11-06/frozen-verification.json；修正后使用 Windows 系统 ICU，冻结版启动及全部专项通过。

## 2.3.1 PPT 转换加速（2026-11-06）

动画的每个画面曾重复解码相同图片并创建 QTextLayout。builtin.Package 现在按素材名复用解码图，使用 64 MiB LRU 上限和 QImage 隐式共享副本；关系表按 part 缓存，返回独立字典。SlidePainter 按文字节点、尺寸、母版/版式、主题及样式复用排版，段落隐藏只改变绘制，不改变行位；每张幻灯片结束即释放上一张排版，最多 256 条。

新增 native.lecture.speed_selftest（受 test_runtime 保护、隔离数据、不调用 Office）：含共享图片、段落交替隐藏的 4 张/40 画面夹具，逐页像素和 PDF 文字层比较一致；布局计算 80→8，图片解码 40→1。预热后本机对比 3.0993s→0.1086s，约 28.54 倍，仅代表该重复资源夹具，不代表 Office COM 或所有真实课件。课件完整回归 LECTURE OK / TEST_PROCESS_EXIT 0。大图超过预算仍正常解码但不常驻缓存，返回图修改不会污染缓存。

版本 app/store.py=2.3.1；tools/release.py 当前输出 release-2.3.1-2026-11-06，保留 v2.3 包；冻结自测纳入 ppt-speed-result.txt。

## 2.4 前端美术与按键（2026-11-06）

见 RELEASE-0.2.4.md。令牌、统一样式表、图标在 native/design；主窗口与学习窗口共用墨绿窄栏 RailButton；PenBar 改图标键（tool_box、width_box 隐藏保留，供状态读写和自测）。

## 2.5：自由工作台铺满窗口（2026-11-07）

见 `RELEASE-0.2.5.md`。外壳在 `app/native/kit/bench_ui.py`（`BenchChrome`），素材栏在 `kit/bench.py`（`Palette` 分页）。

- 素材的 section 要写 `tab`：`reagent` / `item` / `exp`（默认 item），`B.palette(secs, labels={"item": "元件"})` 改页名。
- 工作台在画布上放东西、画读数都要用 `B.safe()` 避开浮窗，需要跟着开合调整时用 `B.on_safe(fn)`。
- 检查器重建后调用 `B.show_panel()`（`clear_panel` 也会排一次）：面板显示中新加的控件可能只靠布局的延迟显示而留白，几何画板出现过。
- 顶条由 `kit/bench_transfer.py` 建好交给 `chrome.attach_bar`；独立画布时 `release_bar`。
- 窄栏显隐走 `NativeWindow.sync_chrome()`。
- 浮窗必须保持不透明（`FloatFrame`）：透明的话画布每帧都会带着里面的键重画。

## 当前工作：2.6（2026-11-07）

用户已批准直接实施PROMPT-物品与讲题可视化，并特别强调减少同质化流程图。实现范围和明确未覆盖项见RELEASE-0.2.6.md；设计记录见DESIGN-物品与讲题可视化.md。不要把兜底卡当专用补图，不要声称七阶段清单每项都完成。

新增analysis/figure：schema纯数据预算验证、stream增量完整图元、evidence数值绑定、view/glyphs/curated原生图、bank_figures静态补图及源哈希校验、export原生PDF/长图、mistakes斜面对比。32+4道固定假回复回归，不联网。AI内部taskRes/calc等字段会被剔除，只信程序生成证据。协议figure靠前且避免大批量flow。原图优先显示；旧图阶段数不同按比例同步，不能说同步真实物理时间。

工作台新增：chem_model容器轮廓/容积/热容；apparatus_model保守气体传递、平衡滴定与传感器；circ新增电阻箱/NTC/LDR/fuse，仍用原节点解；mech增加实际质量/无摩擦轨道对象；geo_construct依赖点解析作图；scene_types3八种明确解析模型；bio/bio_model第六工作台。新模块已显式登记all_modules。Palette收藏/最近合并workbench-ui其他字段，BenchChrome._save也须合并，不可覆盖materials。

Clip的analysis来源新增step/tab/parameters，声明图发送SVG并回跳状态。查询浮窗未嵌完整图解；通用变式求解、完整错因诊断、全部器材清单等不在本版完成范围，参见release。

新专项：native.analysis.figure.selftest、integration_selftest、subject_selftest、transfer_selftest；native.kit.apparatus_selftest、extension_selftest。都通过kit/test_runtime，用隔离目录，不能启动Word/强杀/打印密钥。打包总自测新增这些marker；build.py额外收bank-figures.json。版本app/store.py=2.6.0，发行release-2.6-2026-11-07；不覆盖src2/dist或桌面快捷方式。题库206原文/答案未改；DATA-REVIEW-2.6.md记录一个可复算二面角疑点。

### 2.6 后续收尾更新
静态补图最终52份，其中19份专门替换原flow默认展示，不再仅给已有图题加图。固定JSON假回复扩大到54题，42图元，54题昼夜渲染通过。curated_stem.py逐题数理化生模型，reviewed.py保存23道逐题图的题干/答案签名，变化后失配停用。Bank.figure_bridge对original_flow默认启用新图，可切回原图。source题库SHA256仍与2.5一致。


### 2.13.1 化学符号预览补丁

builtin.py 新增 Word VML imagedata、PPT OLE 内嵌 pic 预览、连接线缺省颜色与复合双线。metafile.py 使用内存 GDI 回放 EMF/WMF（含 EMZ/WMZ），限制输入与像素尺寸，双背景恢复透明度；不启动 PowerShell/Office、不激活 OLE。Package.image 按需 LRU。legacy.metafiles_to_png API 保留。chemical_selftest 纳入冻结总自测；样例涵盖图片预览和双线像素分离，实际用户课件尚未提供。已导入缓存需重新生成副本，原笔迹保留。版本2.13.1，构建 release-2.13.1-2026-11-08。使用 test_runtime，所有测试隔离数据与 offscreen+Windows字体目录，禁止错误弹窗/强杀/读取密钥。

2.13.1最终候选目录为 release-2.13.1-2026-11-08-final；先前同版本目录中的自测虽然全部通过，但源码后来补了Symbol私用区数字与等号修复，不能用于最终验收。最终包只从-final目录的成功自测生成。


### 2.14 框选DS识图
vision.py使用deepseek-flash /chat/completions image_url内存PNG；仅裁剪图片，最大2048边/8MiB，12项内存LRU，3秒连接/22秒读取。模型环境变量DEEPSEEK_VISION_MODEL。仅读图提取text/query/uncertainty，不当成解题结论；不确定先核对。LookupPanel保留文字快速路径，图片有key自动DS，手动DS重读绕过缓存；失败OCR回退、原文编辑、线程事件取消、ticket拒绝迟到结果；_reset清job拒绝旧搜索。新增vision_selftest模拟API，无网络，整体自测30组。真实有机推断DOCX实际渲染40页，第一页Br₂/C=O已显示（verify-real-chem，原件未改且不打包）。不读取/打印真实密钥，不调用Word/强杀线程；走test_runtime防错误弹窗。版本2.14.0，发行release-2.14-2026-11-08。
