"""静态补图生成器：只读取仓库题库，不访问用户数据或网络。"""
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"app"))
from native.analysis.figure.bank_figures import for_question

source=root/"app/native/bank/questions.json"
original=source.read_bytes()
questions=json.loads(original)
figures={}
for q in questions:
    diagram=for_question(q)
    if diagram.get("specific"):
        figures[q["id"]]=diagram
target=root/"app/native/analysis/figure/bank-figures.json"
target.write_text(json.dumps(dict(v=1,source_sha256=hashlib.sha256(original).hexdigest(),figures=figures),ensure_ascii=False,separators=(",",":")),encoding="utf-8")
assert source.read_bytes()==original
print("BANK_FIGURES",len(figures),dict(Counter(q["view"]["engine"] for q in questions)))
