"""见微 · 题库训练/审计：用 2023–2025 真题逐题挂载可视化，抓异常并出图。

用法：
  python tools/audit.py                 # 审计 + 每科出一张样图
  python tools/audit.py --shots 6       # 每科出 6 张
  python tools/audit.py --only m-2024   # 只跑 id 前缀包含的题
"""
from __future__ import annotations

import argparse
import html
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "app" / "studio" / "web"
OUT = ROOT / "tmp" / "audit"
EDGE_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def edge() -> str:
    for p in EDGE_CANDIDATES:
        if Path(p).exists():
            return p
    raise SystemExit("未找到 Edge")


def run(url: str, extra: list[str], timeout: int = 120) -> subprocess.CompletedProcess:
    profile = ROOT / "tmp" / "edge-profile"
    cmd = [edge(), "--headless=new", "--disable-gpu", "--no-sandbox",
           "--hide-scrollbars", f"--user-data-dir={profile}"] + extra + [url]
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                          encoding="utf-8", errors="replace")


def parse_out(dom: str) -> str:
    m = re.search(r'<pre id="out"[^>]*>(.*?)</pre>', dom, re.S)
    return html.unescape(m.group(1)) if m else "(no audit output)"


def audit() -> tuple[bool, str]:
    res = run((WEB / "audit.html").as_uri(), ["--dump-dom"])
    text = parse_out(res.stdout or "")
    ok = text.startswith("AUDIT PASS")
    return ok, text


def bank_records() -> list[dict]:
    recs = []
    for f in sorted((WEB / "js" / "data").glob("bank-*.js")):
        src = f.read_text(encoding="utf-8")
        for m in re.finditer(r"\{[^{}]*?id\s*:\s*'([^']+)'", src):
            pass
        for m in re.finditer(r"id\s*:\s*'([^']+)'", src):
            start = m.start()
            tail = src[start:start + 1600]
            def g(k):
                mm = re.search(k + r"\s*:\s*'([^']*)'", tail)
                return mm.group(1) if mm else ""
            recs.append({"id": m.group(1), "subject": g("subject"),
                         "year": g("year"), "title": g("title")})
    seen, out = set(), []
    for r in recs:
        if r["id"] not in seen:
            seen.add(r["id"])
            out.append(r)
    return out


def shots(limit_per_subject: int, only: str = "") -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    recs = [r for r in bank_records() if not only or only in r["id"]]
    by_subject: dict[str, list[dict]] = {}
    for r in recs:
        by_subject.setdefault(r["subject"] or "?", []).append(r)
    made = 0
    for subject, items in by_subject.items():
        for r in items[:limit_per_subject]:
            png = OUT / f"{r['id']}.png"
            url = (WEB / "index.html").as_uri() + "?q=" + r["id"]
            run(url, [f"--screenshot={png}", "--window-size=1440,900",
                      "--virtual-time-budget=2500"])
            if png.exists():
                made += 1
    return made


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--shots", type=int, default=1)
    ap.add_argument("--only", default="")
    ap.add_argument("--no-shots", action="store_true")
    args = ap.parse_args()

    ok, text = audit()
    print(text)
    print("=" * 60)
    recs = bank_records()
    counts: dict[str, int] = {}
    for r in recs:
        counts[r["subject"]] = counts.get(r["subject"], 0) + 1
    print("题库：", len(recs), "题", json.dumps(counts, ensure_ascii=False))
    if not args.no_shots:
        n = shots(args.shots, args.only)
        print(f"截图：{n} 张 → {OUT}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
