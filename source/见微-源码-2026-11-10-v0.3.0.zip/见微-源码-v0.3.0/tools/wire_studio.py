"""见微 · 析题台装配：把新增的视图 / 题库 / 学习助手模块接进 index.html 与 audit.html。

幂等：已经接过的不会重复插入；文件还不存在的先跳过（等子代理交付后再跑一次即可）。
用法：python tools/wire_studio.py
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "app" / "studio" / "web"

VIEW_CSS = ["studio.css", "graph.css", "physics.css", "subjects.css", "solid.css", "import.css", "study.css", "player.css", "ux.css", "graphplus.css", "builder.css", "guide.css", "nocturne.css"]
VIEW_JS = [
    "js/core.js", "js/nocturne.js",
    "js/views/graph.js", "js/views/physics.js", "js/views/subjects.js", "js/views/solid.js",
    "js/data/bank-2023.js", "js/data/bank-2024.js", "js/data/bank-2025.js", "js/data/bank-2026.js",
    "js/data/bank-extra-mp.js", "js/data/bank-extra-cb.js", "js/data/bank-extra-le.js",
    "js/data/bank-solid.js",
    "js/import.js", "js/guide.js", "js/app.js",
    "js/study.js", "js/player.js", "js/ux.js", "js/graphplus.js", "js/builder.js",
]
AUDIT_JS = [p for p in VIEW_JS if p != "js/app.js" and p not in ("js/study.js", "js/player.js", "js/ux.js")]


def present(rel: str) -> bool:
    return (WEB / rel).exists()


def link(rel: str) -> str:
    return f'<link rel="stylesheet" href="css/{rel}">'


def script(rel: str) -> str:
    return f'<script src="{rel}"></script>'


def wire(path: Path, js_list: list[str]) -> list[str]:
    html = path.read_text(encoding="utf-8")
    changed = []

    # css：删掉旧 link，按顺序重插
    body = re.sub(r'\n?<link rel="stylesheet" href="css/[^"]+">', "", html)
    css_block = "\n".join(link(c) for c in VIEW_CSS if present(f"css/{c}"))
    body = body.replace("</head>", css_block + "\n</head>", 1)

    # js：删掉旧 script（只删 studio 的），按顺序重插
    body = re.sub(r'\n?<script src="js/[^"]+"></script>', "", body)
    js_block = "\n".join(script(s) for s in js_list if present(s))
    body = re.sub(r"\n?</body>", "\n" + js_block + "\n</body>", body, count=1)

    if body != html:
        path.write_text(body, encoding="utf-8")
        changed.append(path.name)
    return changed


def main() -> int:
    changed = []
    changed += wire(WEB / "index.html", VIEW_JS)
    changed += wire(WEB / "audit.html", AUDIT_JS)
    missing = [s for s in VIEW_JS + [f"css/{c}" for c in VIEW_CSS] if not present(s)]
    print("wired:", ", ".join(changed) or "（没有变化）")
    if missing:
        print("还没交付（下次再跑）：", ", ".join(missing))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
