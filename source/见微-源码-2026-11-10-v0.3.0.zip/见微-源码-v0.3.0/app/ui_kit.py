"""见微 · 主窗口的视觉底座（配色与学习窗口的 design/tokens 同一套：墨绿窄栏、朱砂印、冷瓷面板）。"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPainter, QPen
import re

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget


_THEMES = {
    "day": dict(
        PAPER="#E9EDE9", SIDE="#15231F", CARD="#FFFFFF", INK="#14201D", INK2="#0F6B62",
        SOFT="#58675F", FAINT="#7F8D86", LINE="#D9DFD9", LINE2="#E7EBE6", BODY="#33423D",
        ACCENT="#C8402A", JADE="#21804F", DEEP="#080E0C", WINDOW_LINE="#C3CBC4",
        KEY="#FFFFFF", KEYLINE="#C3CBC4", KEYEDGE="#A5AFA7", KEYHOVER="#E2E7E2", PRI="#14201D", PRIHOVER="#25342F", PRIEDGE="#000000", ONPRI="#F5F7F4",
        SOFTKEY="#F5F7F4", MUTEDLINE="#C3CBC4",
    ),
    "night": dict(
        PAPER="#0C1311", SIDE="#080E0C", CARD="#1A2420", INK="#E6EEE9", INK2="#6FC7B6",
        SOFT="#93A39C", FAINT="#7A8A83", LINE="#25312C", LINE2="#1E2925", BODY="#C2CFC9",
        ACCENT="#EE6448", JADE="#5CC98A", DEEP="#050A08", WINDOW_LINE="#25312C",
        KEY="#1F2B26", KEYLINE="#34423C", KEYEDGE="#080D0B", KEYHOVER="#27342F", PRI="#E6EEE9", PRIHOVER="#FFFFFF", PRIEDGE="#93A39C", ONPRI="#0C1311",
        SOFTKEY="#1A2420", MUTEDLINE="#34423C",
    ),
}
CURRENT_THEME = "day"

# 页面代码里还写着上一代配色的字面量：一律当作语义名，按当前主题换成新色（昼夜都换）
_LEGACY = {
    "#F7F2EB": "PAPER", "#FBF8F3": "CARD", "#FFFFFF": "CARD", "#081F5C": "INK", "#334EAC": "INK2", "#5F6E8C": "SOFT",
    "#93A0B8": "FAINT", "#E6EAF1": "LINE", "#F0F2F6": "LINE2", "#B4553C": "ACCENT", "#3F6F62": "JADE", "#050C1C": "DEEP",
    "#E2E7F0": "WINDOW_LINE", "#44557A": "BODY", "#B9C3D6": "FAINT", "#EDF0F6": "LINE", "#F2F5FB": "KEYHOVER",
}


class C:
    PAPER = QColor("#E9EDE9")
    SIDE = QColor("#15231F")
    CARD = QColor("#FFFFFF")
    INK = QColor("#14201D")
    INK2 = QColor("#0F6B62")
    SOFT = QColor("#58675F")
    FAINT = QColor("#7F8D86")
    LINE = QColor("#D9DFD9")
    LINE2 = QColor("#E7EBE6")
    ACCENT = QColor("#C8402A")
    JADE = QColor("#21804F")
    DEEP = QColor("#080E0C")


def apply_theme(name: str) -> str:
    """切到 day / night，并把 C.* 与 C.*H 都更新（内联样式用字符串拼接读 H 版）；学习窗口的令牌同步切换。"""
    global CURRENT_THEME
    pal = _THEMES.get(name) or _THEMES["day"]
    CURRENT_THEME = name if name in _THEMES else "day"
    for k, v in pal.items():
        setattr(C, k, QColor(v))
        setattr(C, k + "H", v)
    from native.design import tokens
    tokens.set_theme("night" if CURRENT_THEME == "night" else "day")
    return CURRENT_THEME


def theme() -> str:
    return CURRENT_THEME


def _swap(text: str) -> str:
    """把旧配色字面量换成当前主题色值（一次扫描，不会连环替换）。"""
    pal = _THEMES[CURRENT_THEME]
    return re.sub(r"#[0-9a-fA-F]{6}\b", lambda m: pal[_LEGACY[m.group(0).upper()]] if m.group(0).upper() in _LEGACY else m.group(0), text)


def qss() -> str:
    return _qss(_THEMES[CURRENT_THEME])


def restyle_tree(root) -> None:
    """把控件里写死的旧配色字面量换成当前主题色；origStyle 留原文，切主题时重新换算。"""
    if root is None:
        return
    try:
        widgets = [root] + root.findChildren(QWidget)
    except Exception:
        return
    for w in widgets:
        try:
            orig = w.property("origStyle")
            if orig is None:
                orig = w.styleSheet() or ""
                w.setProperty("origStyle", orig)
            want = _swap(orig)
            if w.styleSheet() != want:
                w.setStyleSheet(want)
        except Exception:
            continue


def _pick(cands: list[str]) -> str:
    fams = set(QFontDatabase.families())
    for c in cands:
        if c in fams:
            return c
    return cands[-1]


UI = _pick(["Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC", "Segoe UI"])
NUM = _pick(["Bahnschrift", "Segoe UI", "Cambria"])   # 仪表读数：DIN 系等高数字
MONO = _pick(["Consolas", "Cascadia Mono", "Courier New"])


def f(size: float = 13, weight: int = 400, spacing: float = 0.0) -> QFont:
    font = QFont(UI)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    return font


def serif(size: float = 40, weight: int = 600, spacing: float = 0.0) -> QFont:
    font = QFont(NUM)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return font


def mono(size: float = 13, weight: int = 400) -> QFont:
    font = QFont(MONO)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    return font


def _qss(t: dict) -> str:
    return f"""
QWidget {{ color: {t['INK']}; font-family: '{UI}'; }}
QToolTip {{ background: {t['INK']}; color: {t['PAPER']}; border: none; padding: 5px 8px; font-size: 11px; }}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px 0; }}
QScrollBar::handle:vertical {{ background: {t['KEYLINE']}; border-radius: 2px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {t['KEYEDGE']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
QFrame#card {{ background: {t['CARD']}; border: 1px solid {t['LINE']}; border-radius: 9px; }}
QPushButton {{ border: none; background: transparent; }}
QPushButton#ghost {{ color: {t['SOFT']}; background: transparent; border: 1px solid {t['LINE']}; border-radius: 5px; padding: 0 10px; }}
QPushButton#ghost:hover {{ color: {t['INK']}; background: {t['KEYHOVER']}; }}
QPushButton#btn, QPushButton#btn-soft {{
    background: {t['KEY']}; border: 1px solid {t['KEYLINE']}; border-bottom: 2px solid {t['KEYEDGE']}; border-radius: 5px;
    padding: 6px 13px 5px 13px; color: {t['INK']}; font-size: 12px;
}}
QPushButton#btn:hover, QPushButton#btn-soft:hover {{ background: {t['KEYHOVER']}; border-color: {t['KEYEDGE']}; }}
QPushButton#btn:pressed, QPushButton#btn-soft:pressed {{ border-bottom: 1px solid {t['KEYEDGE']}; margin-top: 1px; }}
QPushButton#btn-primary {{
    background: {t['PRI']}; border: 1px solid {t['PRI']}; border-bottom: 2px solid {t['PRIEDGE']}; border-radius: 5px;
    padding: 6px 13px 5px 13px; color: {t['ONPRI']}; font-size: 12px;
}}
QPushButton#btn-primary:hover {{ background: {t['PRIHOVER']}; border-color: {t['PRIHOVER']}; }}
QPushButton#btn-primary:pressed {{ border-bottom: 1px solid {t['PRIEDGE']}; margin-top: 1px; }}
QPushButton#btn-danger {{
    background: {t['KEY']}; border: 1px solid {t['KEYLINE']}; border-bottom: 2px solid {t['ACCENT']}; border-radius: 5px;
    padding: 6px 13px 5px 13px; color: {t['ACCENT']}; font-size: 12px;
}}
QPushButton#btn-danger:hover {{ background: {t['KEYHOVER']}; border-color: {t['ACCENT']}; }}
QPushButton#btn-danger:pressed {{ border-bottom: 1px solid {t['ACCENT']}; margin-top: 1px; }}
QPushButton#chip {{
    background: {t['KEY']}; border: 1px solid {t['KEYLINE']}; border-bottom: 2px solid {t['KEYEDGE']}; border-radius: 5px;
    padding: 4px 11px 3px 11px; color: {t['SOFT']}; font-size: 11.5px;
}}
QPushButton#chip:hover {{ background: {t['KEYHOVER']}; }}
QPushButton#chip:pressed {{ border-bottom: 1px solid {t['KEYEDGE']}; margin-top: 1px; }}
QPushButton#chip:checked {{ background: {t['PRI']}; border-color: {t['PRIEDGE']}; color: {t['ONPRI']}; font-weight: 600; }}
QLabel#kicker {{ color: {t['FAINT']}; font-size: 10px; }}
QLabel#h2 {{ color: {t['INK']}; font-size: 17px; font-weight: 600; }}
QLabel#body {{ color: {t['BODY']}; font-size: 12.5px; }}
QSlider::groove:horizontal {{ height: 3px; background: {t['KEYLINE']}; border-radius: 1px; }}
QSlider::sub-page:horizontal {{ background: {t['INK2']}; height: 3px; border-radius: 1px; }}
QSlider::handle:horizontal {{ width: 8px; height: 16px; margin: -7px 0; border-radius: 2px;
    background: {t['KEY']}; border: 1px solid {t['FAINT']}; border-bottom: 2px solid {t['FAINT']}; }}
QCheckBox {{ color: {t['BODY']}; font-size: 12px; spacing: 8px; }}
QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid {t['FAINT']}; border-radius: 3px; background: {t['KEY']}; }}
QCheckBox::indicator:checked {{ background: {t['INK2']}; border-color: {t['INK2']}; }}
QLineEdit, QDateEdit {{
    background: {t['KEY']}; border: 1px solid {t['KEYLINE']}; border-radius: 5px;
    padding: 6px 9px; color: {t['INK']}; font-size: 12px;
}}
QLineEdit:focus {{ border-color: {t['INK2']}; }}
QComboBox {{ background: {t['KEY']}; color: {t['INK']}; border: 1px solid {t['KEYLINE']}; border-radius: 5px; padding: 5px 9px; font-size: 12px; }}
"""


def label(text: str, size: float = 12.5, color: QColor | None = None,
          weight: int = 400, wrap: bool = False, spacing: float = 0.0) -> QLabel:
    w = QLabel(text)
    w.setFont(f(size, weight, spacing))
    w.setStyleSheet(f"color:{color.name() if color else C.BODYH}; background: transparent;")
    w.setWordWrap(wrap)
    w.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
    return w


def kicker(text: str) -> QLabel:
    w = QLabel(text)
    w.setObjectName("kicker")
    w.setFont(f(10, 600, 2.4))
    w.setStyleSheet(f"color:{C.FAINTH};background:transparent;")
    return w


def divider(vertical: bool = False) -> QFrame:
    line = QFrame()
    line.setFixedHeight(1) if not vertical else line.setFixedWidth(1)
    line.setStyleSheet(f"background:{C.LINEH};border:none;")
    return line


class Card(QFrame):
    def __init__(self, title: str = "", sub: str = "", pad: tuple[int, int, int, int] = (20, 18, 20, 18)):
        super().__init__()
        self.setObjectName("card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(*pad)
        self.body.setSpacing(9)
        if title:
            head = QHBoxLayout()
            head.setSpacing(8)
            t = QLabel(title)
            t.setFont(f(13, 600, 0.4))
            t.setStyleSheet("color:#081F5C;background:transparent;")
            head.addWidget(t)
            self.head = head
            if sub:
                s = QLabel(sub)
                s.setFont(f(10.5))
                s.setStyleSheet("color:#93A0B8;background:transparent;")
                head.addWidget(s, 0, Qt.AlignmentFlag.AlignBottom)
            head.addStretch(1)
            self.body.addLayout(head)
        self._title = title

    def add(self, w):
        if isinstance(w, QWidget):
            self.body.addWidget(w)
        else:
            self.body.addLayout(w)
        return w


class Btn(QPushButton):
    def __init__(self, text: str, variant: str = "", tip: str = ""):
        super().__init__(text)
        self.setObjectName({"primary": "btn-primary", "soft": "btn-soft",
                            "danger": "btn-danger"}.get(variant, "btn"))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(f(12, 600 if variant == "primary" else 400))
        if tip:
            self.setToolTip(tip)


class Chip(QPushButton):
    def __init__(self, text: str):
        super().__init__(text)
        self.setObjectName("chip")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(f(11.5))


class TickRow(QWidget):
    """1 格 = 1 周：瓷器的刻度，不是进度条。"""

    def __init__(self, total: int = 32, filled: int = 12, label_text: str = ""):
        super().__init__()
        self.total, self.filled, self.label_text = total, filled, label_text
        self.setFixedHeight(34)
        self.setMinimumWidth(240)

    def set(self, total: int, filled: int, label_text: str = ""):
        self.total, self.filled, self.label_text = total, max(0, filled), label_text
        self.update()

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        w = self.width()
        right_pad = 92 if self.label_text else 0
        gap = 3.0
        cell = max(1.6, (w - right_pad - gap * (self.total - 1)) / max(1, self.total))
        y = 12
        for i in range(self.total):
            x = i * (cell + gap)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.ACCENT if i == self.filled - 1 else (C.INK if i < self.filled else C.LINE))
            p.drawRect(QRectF(x, y, cell, 12 if (i + 1) % 4 == 0 else 8))
        if self.label_text:
            p.setPen(QPen(C.FAINT))
            p.setFont(f(10.5))
            p.drawText(QRectF(w - right_pad + 10, y - 4, right_pad - 10, 18),
                       int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), self.label_text)
        p.end()


class Dot(QWidget):
    def __init__(self, color: QColor = C.JADE, size: int = 6):
        super().__init__()
        self.color, self.size = color, size
        self.setFixedSize(size, size)

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(self.color)
        p.drawEllipse(QRectF(0, 0, self.size, self.size))
        p.end()


apply_theme("day")


def row(*widgets, spacing: int = 8, stretch_last: bool = False) -> QHBoxLayout:
    lay = QHBoxLayout()
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(spacing)
    for w in widgets:
        if w is None:
            lay.addStretch(1)
        elif isinstance(w, QWidget):
            lay.addWidget(w)
        else:
            lay.addLayout(w)
    if stretch_last:
        lay.addStretch(1)
    return lay
