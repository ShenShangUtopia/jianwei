"""见微 · 每日节律：07:15 抓取世界线索、22:20 生成并全屏暮省。

这两件事原本分别由「观澜常驻进程里的定时器」和「Windows 计划任务」负责；
见微接管后由本模块统一驱动，见微常驻托盘即可，不依赖原版进程。
"""
from __future__ import annotations

import threading
from datetime import datetime, time as dtime

from PySide6.QtCore import QObject, QTimer, Signal

import store

FETCH_AT = dtime(7, 15)
EVENING_AT = dtime(22, 20)


class DailyJobs(QObject):
    toast = Signal(str)
    fetch_done = Signal()

    def __init__(self, host, cfg: dict, save, parent=None):
        super().__init__(parent)
        self.host = host
        self.cfg = cfg
        self.save = save
        self._busy = False
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.check)
        self._timer.start(60_000)
        QTimer.singleShot(2500, self.check)

    # ------------------------------------------------------------ 入口
    def check(self) -> None:
        if self._busy:
            return
        now = datetime.now()
        today = now.date().isoformat()

        if self.cfg.get("autoFetch", True) and now.time() >= FETCH_AT:
            if self.cfg.get("lastFetchDate") != today:
                if store.guanlan_date() == today:
                    self._mark("lastFetchDate", today)
                else:
                    self._fetch(today)
                    return

        if self.cfg.get("autoEvening", True) and now.time() >= EVENING_AT:
            if self.cfg.get("lastEveningDate") != today:
                self._evening(today)

    def _mark(self, key: str, value: str) -> None:
        self.cfg[key] = value
        try:
            self.save()
        except Exception:
            pass

    # ------------------------------------------------------------ 任务
    def _fetch(self, today: str) -> None:
        self._busy = True
        self.toast.emit("07:15 · 正在更新今日世界线索…")

        def work() -> None:
            ok = False
            try:
                self.host._ensure_home()
                self.host._ensure_path()
                from core.curator import run as run_curator  # type: ignore
                run_curator(force=True, log_fn=lambda *_: None)
                ok = True
            except Exception:
                ok = False
            self._busy = False
            if ok:
                self._mark("lastFetchDate", today)
                self.fetch_done.emit()
                self.toast.emit("今日世界线索已更新")
            else:
                self.toast.emit("今日更新没成功，稍后会自动再试")

        threading.Thread(target=work, daemon=True).start()

    def _evening(self, today: str) -> None:
        page = store.evening_page_today()
        if page:
            self._mark("lastEveningDate", today)
            return
        # 与托盘「暮省全屏」走同一条路：独立进程 Jianwei.exe --evening（进程内有 evening.lock，只播一次）
        self.toast.emit("22:20 · 正在生成今晚的暮省页")
        self._mark("lastEveningDate", today)
        try:
            self.host.evening()
        except Exception:
            pass


def run_evening(play: bool = True, date: str = "") -> int:
    """命令行/任务用：生成今晚的暮省并全屏播放（不经过主窗口）。date 给了就重播那一期。"""
    import guanlan_host
    host = guanlan_host.GuanlanHost()
    host._ensure_home()
    host._ensure_path()
    from core.evening import load_archived, prepare, texture_path  # type: ignore
    if date:
        state, deck = ("ok", load_archived(date)) if load_archived(date) else ("failed", None)
    else:
        chosen = store.load_config().get("eveningTheme")   # 设置里固定了夜景就用它，否则每晚轮换
        state, deck = prepare(chosen if chosen and chosen != "auto" else None)
    if state == "busy":
        return 0
    if not play:
        return 0 if state == "ok" else 1
    from native.evening import notify_failure, play as play_deck
    if state != "ok":
        notify_failure("这期暮省没有生成：还没有可用的内容。联网后在托盘菜单点「立即更新内容」，再试一次。")
        return 1
    return play_deck(deck, texture_path(deck.get("theme")))


def run_fetch() -> int:
    """命令行/任务用：立即抓取一次。"""
    import guanlan_host
    host = guanlan_host.GuanlanHost()
    host._ensure_home()
    host._ensure_path()
    try:
        from core.curator import run as run_curator  # type: ignore
        run_curator(force=True, log_fn=lambda *_: None)
        return 0
    except Exception:
        return 1
