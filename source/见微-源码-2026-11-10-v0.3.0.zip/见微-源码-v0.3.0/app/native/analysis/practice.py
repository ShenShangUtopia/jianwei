"""Deterministic student-step comparison and isolated variants; no model guessing."""
import copy
import json
import math
import re
import time

from . import tasks, solver
from .lesson import answer_from_program, ticket
from ..kit.home import home, save_json

INTERMEDIATE = {'projectile','incline','collision','circuit','lens','field','func','prob','reaction','dna'}
EXTRA = {
    'projectile': [('time','落地时间'),('range','水平射程'),('max_height','最大高度'),('impact_speed','落地速率')],
    'incline': [('a','加速度'),('N','支持力'),('f','摩擦力'),('work_friction','克服摩擦做功')],
    'collision': [('momentum','总动量'),('energy_before','碰前动能'),('energy_after','碰后动能'),('v1_after','碰后速度1'),('v2_after','碰后速度2')],
    'circuit': [('R_total','总电阻'),('I','干路电流'),('U','路端电压'),('I1','支路电流1'),('I2','支路电流2')],
    'lens': [('v','像距'),('m','放大率')],
    'prob': [('E','期望'),('D','方差')],
    'dna': [('mrna','mRNA'),('protein','氨基酸序列')],
    'reaction': [('balanced','化学方程式')],
}
ALIASES = {'a':'加速度','n':'支持力','f':'摩擦力','i':'干路电流','u':'路端电压','v':'像距','t':'落地时间','r':'轨道半径'}
UNITS = r'(mol/L|mmol|mol|mL|L|mg|g|m/s²|m/s\^2|m/s|km/h|kg|m|cm|mm|s|N|A|mA|V|Ω|J|°)?'


def close(a,b):
    # Absolute 0.005 from answer matching would incorrectly accept zero charge/mass.
    return abs(a-b)<=max(1e-300,.01*max(abs(a),abs(b)))


def constant(text):
    text=str(text)
    if len(text)>200 or text.count('(')>16 or re.search(r'\b(fact|comb|perm)\s*\(',text):
        return math.nan
    try:
        return float(solver.fn(text,[])())
    except (solver.ExprError,ValueError,OverflowError,ZeroDivisionError):
        return math.nan


def strip_claims(spec):
    spec=copy.deepcopy(spec)
    for ask in spec.get('asks',[]):
        ask.pop('claimed',None)
    return spec


def checkpoints(spec):
    spec=strip_claims(spec)
    asks=list(spec.get('asks') or [])
    extra=list(EXTRA.get(spec.get('kind'),[]))
    if spec.get('kind')=='field':
        extra=[('r','轨道半径'),('T','周期')] if spec.get('B') and not spec.get('E') and not spec.get('U') else [('a','加速度'),('time','板间时间')]
    labels=dict(extra)
    for ask in asks:
        if ask.get('what') in labels:
            ask['prompt']=labels[ask['what']]
    asks += [dict(what=w,prompt=p) for w,p in extra if not any(a.get('what')==w for a in asks)]
    spec['asks']=asks
    result=tasks.build(spec)
    if not result['ok']:
        raise ValueError('参数不足，无法建立可靠核对：'+'；'.join(result['errors']))
    if result['result'].get('failed_checks'):
        raise ValueError('程序独立核对未通过，不能用于诊断')
    if spec.get('kind')=='reaction':
        for sp in (result['result'].get('viz') or {}).get('sp',[]):
            asks.append(dict(what='mol',species=sp['f'],prompt=sp['f']+'的反应物质的量'))
        spec['asks']=asks
        result=tasks.build(spec)
        if not result['ok']:
            raise ValueError('无法建立物质的量核对')
    return result['result']


def _normal(text):
    return re.sub(r'\s+','',str(text)).replace('−','-').replace('＝','=')


def diagnose(spec, text):
    if not isinstance(text,str) or len(text)>12000:
        raise ValueError('请把步骤控制在12000字以内')
    result=checkpoints(spec)
    rows=result['rows']
    compared=[]
    for i,line in enumerate(text.splitlines(),1):
        match=re.fullmatch(r'\s*(?:第?\d+[步行.、：:]?\s*)?([^=＝:：]{1,40})\s*[=＝:：]\s*(.+)',line)
        if not match:
            continue
        label,rhs=match.groups()
        label=ALIASES.get(label.strip().lower(),label.strip())
        hits=[r for r in rows if _normal(r['prompt']).lower()==_normal(label).lower()]
        if len(hits)!=1:
            continue
        row=hits[0]
        expected=row.get('value')
        if isinstance(expected,(int,float)) and not isinstance(expected,bool) and math.isfinite(expected):
            symbolic=_normal(rhs).replace('θ','theta')
            if spec.get('kind')=='incline' and label=='加速度' and symbolic in ('g*sin(theta)','gsin(theta)','gsintheta') and spec.get('mu',0)>0 and not spec.get('F') and expected>0:
                compared.append(dict(line=i,label=label,ok=False,expected=row['text'],actual=rhs,reason='在当前已下滑且有摩擦的模型中，这一行列式省略了摩擦项 −μg cosθ。证据来自你填写的等式。'))
                continue
            raw=rhs.strip()
            unit=re.search(UNITS+'$',raw)
            given_unit=unit.group(1) if unit else None
            if given_unit:
                raw=raw[:unit.start()].strip()
            value=constant(raw)
            if not math.isfinite(value):
                continue
            if given_unit and given_unit!=row.get('unit'):
                cv=solver.convert(value,given_unit,row.get('unit'))
                if cv.get('error'):
                    continue
                value=cv['value']
            ok=close(value,expected)
            reason=''
            if not ok:
                if expected and close(value,-expected):
                    reason='数值符号相反，请检查正方向；仅凭结果不能确定错因。'
                if spec.get('kind')=='incline' and label=='加速度' and not spec.get('F'):
                    g=spec.get('g',9.8)
                    angle=math.radians(spec.get('angle',0))
                    if spec.get('mu',0)>0 and expected>0 and close(value,g*math.sin(angle)):
                        reason='数值与忽略摩擦时一致，可能漏了摩擦项；需要原列式才能确定。'
                if spec.get('kind')=='projectile' and label=='最大高度' and not spec.get('h0',0):
                    vy=spec['v0']*math.sin(math.radians(spec.get('angle',0)))
                    if vy>0 and close(value,vy/(2*spec.get('g',9.8))):
                        reason='数值与竖直初速度未平方时一致，可能漏平方；需要原列式才能确定。'
            compared.append(dict(line=i,label=label,ok=ok,expected=row['text'],actual=rhs,reason=reason))
        elif row.get('kind')=='equation':
            try:
                ok=tasks.compare(dict(row,value=tasks.parse_equation(row['text']),claimed=rhs),tasks.parse_equation)
            except Exception:
                continue
            if ok is not None:
                compared.append(dict(line=i,label=label,ok=ok,expected=row['text'],actual=rhs,reason='只核对物质及化学计量比例，不据此推断反应条件。'))
        elif row.get('kind')=='text':
            compared.append(dict(line=i,label=label,ok=_normal(rhs)==_normal(row['text']),expected=row['text'],actual=rhs,reason='只核对结果，无法反推推导过程。'))
    mismatches=[r for r in compared if not r['ok']]
    first=mismatches[0] if mismatches else None
    return dict(v=1,kind=spec.get('kind'),checked=compared,first=first,
                conclusion=(f"第{first['line']}行「{first['label']}」与当前参数的程序结果不符。" if first else '已识别的量均相符，但不能据此证明完整推导正确。' if compared else '看不出来：没有识别到可核对的量，请按列出的量名填写“量名=数值”。'),
                cause=(first['reason'] or '看不出来：数值不符不足以判断错误原因。') if first else '未判定具体错因。',
                scope='只核对已识别的行；未识别或未填写的步骤不判为正确。参数本身仍需与题干核对。')


def fields(spec):
    out=[]
    def walk(value,path):
        if len(path)>8:
            return
        if isinstance(value,dict):
            for k,v in value.items():
                if k not in ('asks','claimed','kind'):
                    walk(v,path+[k])
        elif isinstance(value,list):
            for i,v in enumerate(value):
                walk(v,path+[i])
        elif type(value) in (int,float) or isinstance(value,str) and path and (path[-1] in ('f','seq','rule','curve','line') or path[0]=='parents'):
            out.append(dict(path=path,value=value,label=' / '.join(map(str,path))))
    walk(spec,[])
    return out[:160]


def variant(lesson, index, changes):
    raw=lesson.get('task')
    specs=copy.deepcopy(raw if isinstance(raw,list) else [raw])
    if not 0<=index<len(specs) or not isinstance(specs[index],dict):
        raise ValueError('本题没有可重算的题型参数')
    spec=specs[index]
    allowed={tuple(f['path']):f['value'] for f in fields(spec)}
    for path,value in changes:
        path=tuple(path)
        if path not in allowed:
            raise ValueError('这个参数不支持修改')
        old=allowed[path]
        if type(old) in (int,float):
            value=constant(value)
            if not math.isfinite(value) or abs(value)>1e12:
                raise ValueError('参数必须是有限数值，绝对值不超过10¹²')
            # A JSON integer can be a mass, volume or coordinate, not a count.
            # Discrete constraints belong to the task validator, not the old type.
            if value.is_integer():
                value=int(value)
        else:
            value=str(value)
            if len(value)>400:
                raise ValueError('参数表达式过长')
            if re.search(r'\b(fact|comb|perm)\s*\(',value):
                raise ValueError('变式表达式不支持可能耗时过长的阶乘或组合函数')
            if path[-1]=='seq' and not re.fullmatch('[ACGTUacgtu]+',value):
                raise ValueError('碱基序列只允许ACGTU')
        target=spec
        for k in path[:-1]:
            target=target[k]
        target[path[-1]]=value
    # Keep only the selected variant: other tasks/AI claims refer to the old conditions.
    spec=strip_claims(spec)
    if spec.get('kind')=='prob' and (spec.get('dist') or {}).get('type')=='hypergeometric' and (spec['dist'].get('n',0)>500):
        raise ValueError('变式超出当前分布计算预算：抽样数最多500')
    result=tasks.build(spec,'')
    if not result['ok'] or result.get('result',{}).get('failed_checks'):
        raise ValueError('变式未通过程序求解或独立核对：'+'；'.join(result.get('errors',[])))
    t=result['result']
    new=dict(problem='变式条件：'+json.dumps({k:v for k,v in spec.items() if k!='asks'},ensure_ascii=False),task=spec,taskRes=[t],subject=t['subj'],topic='变式 · '+t['title'],summary='答案与图解均按新参数重算；原题和原答案保留。',knowns=[],assumptions=[],pitfalls=[],steps=t['detail'] or ['按新条件计算'],engine='program',t=time.time(),variant_of=copy.deepcopy(lesson.get('ticket',{})),ticket=ticket(str(spec),0))
    new['answer']=answer_from_program(new)
    return new


def save_attempt(reference, text, report):
    path=home()/'attempts.json'
    if path.exists():
        data=json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(data,dict) or data.get('v')!=1 or not isinstance(data.get('items'),list):
            raise ValueError('作答记录版本不支持，未覆盖原文件')
    else:
        data=dict(v=1,items=[])
    data['items'].append(dict(reference=reference,student=text,report=report,t=time.time()))
    data['items']=data['items'][-2000:]
    save_json('attempts.json',data)
