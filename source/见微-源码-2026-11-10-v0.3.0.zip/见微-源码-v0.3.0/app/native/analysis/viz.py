"""题型图解（由 gewu/viz.js 改写）：程序求解的结果画成可以一步步讲的图。

每个题型一种图：函数图像、圆锥曲线、可旋转的立体图、分布图、数列、原子守恒与物质的量、pH 与分布曲线、三段式、棋盘法、碱基配对与翻译、食物网。
入口 make_viz(task_result) 返回 VizFrame；不支持时返回 None。
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF
from PySide6.QtGui import QLinearGradient, QPainterPath

from ..design.tokens import T, alpha, qc
from . import solver as Solver
from .tasks_sci import AA, parse_formula
from .viz_core import H, N, PAL, W, Plot, VizFrame, X, cap_of, nice, sub_n, sup_n

ISF = math.isfinite


def _ok(v):
    return isinstance(v, (int, float)) and ISF(v)


# ---------------------------------------------------------------- 数学
def v_func(t):
    v = t["viz"]
    f = Solver.fn(v["f"], ["x"])

    def d(x):
        h = 1e-5 * max(1, abs(x))
        return (f(x + h) - f(x - h)) / (2 * h)
    if v["given"]:
        pad = (v["b"] - v["a"]) * 0.06
        x0, x1 = v["a"] - pad, v["b"] + pad
    else:
        xs = [x for x in v["zeros"] + [e["x"] for e in v["ext"]] + [q["x0"] for q in v["tang"]] + [z for q in v["ints"] for z in (q["lo"], q["hi"])] + [m["x"] for m in v["marks"]] + [m["x"] for m in v["mm"]] if ISF(x)]
        if not xs:
            x0, x1 = -5.0, 5.0
        else:
            lo, hi = min(xs), max(xs)
            span = max(hi - lo, 2)
            x0, x1 = max(lo - span * 0.5, -20), min(hi + span * 0.5, 20)
    smp = [(x0 + (x1 - x0) * i / 500, f(x0 + (x1 - x0) * i / 500)) for i in range(501)]
    fin = sorted(p[1] for p in smp if _ok(p[1]))
    y0 = fin[int(len(fin) * 0.03)] if fin else -1
    y1 = fin[max(0, math.ceil(len(fin) * 0.97) - 1)] if fin else 1
    for y in [e["y"] for e in v["ext"]] + [m["y"] for m in v["mm"]] + [m["y"] for m in v["marks"]] + [0]:
        if ISF(y):
            y0, y1 = min(y0, y), max(y1, y)
    if y1 - y0 < 1e-9:
        y0, y1 = y0 - 1, y1 + 1
    pad = (y1 - y0) * 0.14
    y0, y1 = y0 - pad, y1 + pad
    Pl = Plot(x0, x1, y0, y1)
    lim = (y1 - y0) * 4
    st = [(f"函数图像 y = {v['f']}" + (f"，x ∈ [{X(v['a'])}, {X(v['b'])}]" if v["given"] else ""), "base")]
    if v["zeros"]:
        st.append((f"零点：f(x) = 0 的 x 为 {'，'.join(X(z) for z in v['zeros'])}", "zeros"))
    st.append(("单调性：导数 f′(x) > 0 时递增（绿），f′(x) < 0 时递减（红）", "mono"))
    if v["ext"]:
        st.append(("极值：" + "；".join(f"{'极大值' if e['t'] == 'max' else '极小值'} {X(e['y'])}（x = {X(e['x'])}）" for e in v["ext"]), "ext"))
    if v["mm"]:
        st.append(("；".join(f"{'最大值' if m['t'] == 'max' else '最小值'} {X(m['y'])}（x = {X(m['x'])}）" for m in v["mm"]) + ("：比较极值与区间端点" if v["given"] else ""), "mm"))
    if v["tang"]:
        st.append(("；".join(f"x = {X(q['x0'])} 处切线：斜率 k = f′({X(q['x0'])}) = {X(q['k'])}" for q in v["tang"]), "tang"))
    if v["ints"]:
        st.append(("定积分 = 曲线与 x 轴围成的有向面积（x 轴上方为正，下方为负）", "int"))
    if v["marks"]:
        st.append(("；".join(f"f({X(m['x'])}) = {X(m['y'])}" for m in v["marks"]), "marks"))

    def draw(P, k):
        on = {s[1] for s in st[:k + 1]}
        Pl.draw(P)
        Pl.clip(P)
        if "int" in on:
            for q in v["ints"]:
                pts = [(q["lo"] + (q["hi"] - q["lo"]) * i / 120,) for i in range(121)]
                pts = [(p[0], f(p[0])) for p in pts if _ok(f(p[0]))]
                P.fill_poly([(Pl.sx(q["lo"]), Pl.sy(0))] + [(Pl.sx(x), Pl.sy(max(0, y))) for x, y in pts] + [(Pl.sx(q["hi"]), Pl.sy(0))], T.ok, 0.25)
                P.fill_poly([(Pl.sx(q["lo"]), Pl.sy(0))] + [(Pl.sx(x), Pl.sy(min(0, y))) for x, y in pts] + [(Pl.sx(q["hi"]), Pl.sy(0))], T.bad, 0.25)
        mono = "mono" in on
        run, cls = [], None

        def flush():
            if len(run) > 1:
                P.poly_line(run, cls or "curve")
        for x, y in smp:
            if not _ok(y) or y < y0 - lim or y > y1 + lim:
                flush()
                run, cls = [], None
                continue
            c = ("up" if d(x) > 0 else "down") if mono else "curve"
            if c != cls and run:
                last = run[-1]
                flush()
                run = [last]
            cls = c
            run.append((Pl.sx(x), Pl.sy(y)))
        flush()
        if "tang" in on:
            for q in v["tang"]:
                P.line(Pl.sx(x0), Pl.sy(q["k"] * x0 + q["b"]), Pl.sx(x1), Pl.sy(q["k"] * x1 + q["b"]), "hl2")
        Pl.unclip(P)
        if "zeros" in on:
            for z in v["zeros"]:
                P.dot(Pl.sx(z), Pl.sy(0), T.c2)
                P.small(Pl.sx(z), Pl.sy(0) + 18, X(z))
        if "ext" in on:
            for e in v["ext"]:
                P.line(Pl.sx(e["x"]), Pl.sy(0), Pl.sx(e["x"]), Pl.sy(e["y"]), "dash")
                P.dot(Pl.sx(e["x"]), Pl.sy(e["y"]))
                P.label(Pl.sx(e["x"]), Pl.sy(e["y"]) + (-10 if e["t"] == "max" else 20), f"{'极大' if e['t'] == 'max' else '极小'} {X(e['y'])}")
        if "mm" in on:
            for m in v["mm"]:
                P.ring(Pl.sx(m["x"]), Pl.sy(m["y"]), 9)
                P.strong(Pl.sx(m["x"]), Pl.sy(m["y"]) + (-16 if m["t"] == "max" else 28), f"{'最大' if m['t'] == 'max' else '最小'} {X(m['y'])}")
        if "tang" in on:
            for q in v["tang"]:
                y = q["k"] * q["x0"] + q["b"]
                P.dot(Pl.sx(q["x0"]), Pl.sy(y), T.c2)
                P.label(Pl.sx(q["x0"]) + 8, Pl.sy(y) - 10, f"y = {X(q['k'])}x {'−' if q['b'] < 0 else '+'} {X(abs(q['b']))}", "start")
        if "int" in on:
            for q in v["ints"]:
                P.line(Pl.sx(q["lo"]), Pl.T, Pl.sx(q["lo"]), Pl.T + Pl.h, "dash")
                P.line(Pl.sx(q["hi"]), Pl.T, Pl.sx(q["hi"]), Pl.T + Pl.h, "dash")
        if "marks" in on:
            for m in v["marks"]:
                P.dot(Pl.sx(m["x"]), Pl.sy(m["y"]), T.c2)
                P.label(Pl.sx(m["x"]), Pl.sy(m["y"]) - 10, f"({X(m['x'])}, {X(m['y'])})")
    return VizFrame("函数图像", [s[0] for s in st], draw)


def v_conic(t):
    v = t["viz"]
    parts = v["curve"].split("=")
    F = Solver.fn(f"({parts[0]})-({parts[1]})", ["x", "y"])
    bx = [math.inf, -math.inf, math.inf, -math.inf]
    R0, n0 = 25, 80
    g0 = [[F(-R0 + 2 * R0 * i / n0, -R0 + 2 * R0 * j / n0) for i in range(n0 + 1)] for j in range(n0 + 1)]
    for j in range(n0):
        for i in range(n0):
            a, b, c = g0[j][i], g0[j][i + 1], g0[j + 1][i]
            if (a > 0) != (b > 0) or (a > 0) != (c > 0):
                x, y = -R0 + 2 * R0 * i / n0, -R0 + 2 * R0 * j / n0
                bx = [min(bx[0], x), max(bx[1], x), min(bx[2], y), max(bx[3], y)]
    for q in v["pts"] + [v["O"], [0, 0]]:
        bx = [min(bx[0], q[0]), max(bx[1], q[0]), min(bx[2], q[1]), max(bx[3], q[1])]
    cx, cy = (bx[0] + bx[1]) / 2, (bx[2] + bx[3]) / 2
    sw, sh = max(bx[1] - bx[0], 2) * 1.3, max(bx[3] - bx[2], 2) * 1.3
    pw, ph = W - 60, H - 40
    if sw / pw > sh / ph:
        sh = sw * ph / pw
    else:
        sw = sh * pw / ph
    Pl = Plot(cx - sw / 2, cx + sw / 2, cy - sh / 2, cy + sh / 2)
    nx = 150
    ny = round(nx * Pl.h / Pl.w)
    gv = [[F(Pl.x0 + (Pl.x1 - Pl.x0) * i / nx, Pl.y0 + (Pl.y1 - Pl.y0) * j / ny) for i in range(nx + 1)] for j in range(ny + 1)]
    curve = QPainterPath()

    def at(i, j):
        return (Pl.sx(Pl.x0 + (Pl.x1 - Pl.x0) * i / nx), Pl.sy(Pl.y0 + (Pl.y1 - Pl.y0) * j / ny))
    for j in range(ny):
        for i in range(nx):
            c = [(i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)]
            vs = [gv[b][a] for a, b in c]
            if not all(_ok(z) for z in vs):
                continue
            e = []
            for k in range(4):
                a, b = vs[k], vs[(k + 1) % 4]
                if (a > 0) != (b > 0):
                    s = a / (a - b)
                    p1, p2 = at(*c[k]), at(*c[(k + 1) % 4])
                    e.append((p1[0] + (p2[0] - p1[0]) * s, p1[1] + (p2[1] - p1[1]) * s))
            for k in range(0, len(e) - 1, 2):
                curve.moveTo(*e[k])
                curve.lineTo(*e[k + 1])
    A, B, C = v["A"], v["B"], v["C"]
    if abs(B) > 1e-12:
        seg = (Pl.sx(Pl.x0), Pl.sy(-(A * Pl.x0 + C) / B), Pl.sx(Pl.x1), Pl.sy(-(A * Pl.x1 + C) / B))
    else:
        seg = (Pl.sx(-C / A), Pl.T, Pl.sx(-C / A), Pl.T + Pl.h)
    pts = v["pts"]
    two = len(pts) == 2
    O = v["O"]
    names = "ABCD"
    st = [(f"曲线 {v['curve']}", "curve"), (f"直线 {v['line']}", "line"), ("联立方程：交点 " + "、".join(f"{names[i] if i < 4 else ''}({X(q[0])}, {X(q[1])})" for i, q in enumerate(pts)) if pts else "直线与曲线没有交点", "pts")]
    for i, w in enumerate(v["whats"]):
        if w in ("chord", "midpoint", "area", "distance"):
            st.append((cap_of(t, i), w))

    def draw(P, k):
        on = {s[1] for s in st[:k + 1]}
        Pl.draw(P)
        Pl.clip(P)
        P.path_stroke(curve, "curve")
        if "line" in on:
            P.line(*seg, "hl2")
        if "area" in on and two:
            P.fill_poly([(Pl.sx(O[0]), Pl.sy(O[1])), (Pl.sx(pts[0][0]), Pl.sy(pts[0][1])), (Pl.sx(pts[1][0]), Pl.sy(pts[1][1]))], T.accent, 0.2)
        if on & {"chord", "midpoint", "area"} and two:
            P.line(Pl.sx(pts[0][0]), Pl.sy(pts[0][1]), Pl.sx(pts[1][0]), Pl.sy(pts[1][1]), "thick1")
        if "distance" in on:
            t2 = (A * O[0] + B * O[1] + C) / (A * A + B * B)
            fx, fy = O[0] - A * t2, O[1] - B * t2
            P.line(Pl.sx(O[0]), Pl.sy(O[1]), Pl.sx(fx), Pl.sy(fy), "thick3")
            P.dot(Pl.sx(fx), Pl.sy(fy), T.c2, 3.5)
        Pl.unclip(P)
        if "pts" in on:
            for i, q in enumerate(pts):
                P.dot(Pl.sx(q[0]), Pl.sy(q[1]))
                P.strong(Pl.sx(q[0]) + 8, Pl.sy(q[1]) - 8, names[i] if i < 4 else "", "start")
        if "midpoint" in on and two:
            m = ((pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2)
            P.dot(Pl.sx(m[0]), Pl.sy(m[1]), T.c2)
            P.label(Pl.sx(m[0]) + 8, Pl.sy(m[1]) + 16, f"M({X(m[0])}, {X(m[1])})", "start")
        if on & {"area", "distance"}:
            P.dot(Pl.sx(O[0]), Pl.sy(O[1]), T.c2, 3.5)
            P.label(Pl.sx(O[0]) - 8, Pl.sy(O[1]) + 16, "O" if O[0] == 0 and O[1] == 0 else "P", "end")
    return VizFrame("直线与曲线", [s[0] for s in st], draw)


def v_solid(t):
    v = t["viz"]
    names = list(v["points"])
    Pt = [v["points"][n] for n in names]

    def sub(p, q):
        return [p[i] - q[i] for i in range(3)]

    def dt(p, q):
        return sum(p[i] * q[i] for i in range(3))

    def cross(p, q):
        return [p[1] * q[2] - p[2] * q[1], p[2] * q[0] - p[0] * q[2], p[0] * q[1] - p[1] * q[0]]

    def ln(p):
        return math.hypot(*p)

    def scl(p, s):
        return [x * s for x in p]

    def add(p, q):
        return [p[i] + q[i] for i in range(3)]
    cen = [sum(p[i] for p in Pt) / len(Pt) for i in range(3)]
    rad = max([ln(sub(p, cen)) for p in Pt] + [1e-9])
    eps = 1e-6 * rad

    def PP(n):
        return v["points"][n]

    def hull2(idx, nrm):
        o = Pt[idx[0]]
        cand = next((i for i in idx if ln(sub(Pt[i], o)) > eps), idx[1])
        u0 = sub(Pt[cand], o)
        u = scl(u0, 1 / (ln(u0) or 1))
        w = cross(nrm, u)
        q = sorted([(dt(sub(Pt[i], o), u), dt(sub(Pt[i], o), w), i) for i in idx])

        def cr(a, b, c):
            return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        lo, hi = [], []
        for p in q:
            while len(lo) > 1 and cr(lo[-2], lo[-1], p) <= eps * rad:
                lo.pop()
            lo.append(p)
        for p in reversed(q):
            while len(hi) > 1 and cr(hi[-2], hi[-1], p) <= eps * rad:
                hi.pop()
            hi.append(p)
        return [p[2] for p in lo[:-1] + hi[:-1]]
    faces, seen, edges = [], set(), {}
    n = len(Pt)
    if n >= 4:
        for i in range(n):
            for j in range(i + 1, n):
                for k in range(j + 1, n):
                    nr = cross(sub(Pt[j], Pt[i]), sub(Pt[k], Pt[i]))
                    L = ln(nr)
                    if L < eps * rad:
                        continue
                    nr = scl(nr, 1 / L)
                    ds = [dt(sub(p, Pt[i]), nr) for p in Pt]
                    if not (all(x <= eps for x in ds) or all(x >= -eps for x in ds)):
                        continue
                    if dt(sub(cen, Pt[i]), nr) > 0:
                        nr = scl(nr, -1)
                    on = [m for m, x in enumerate(ds) if abs(x) <= eps]
                    key = tuple(on)
                    if key in seen:
                        continue
                    seen.add(key)
                    cyc = hull2(on, nr)
                    fi = len(faces)
                    faces.append(dict(cyc=cyc, nr=nr))
                    for m, a in enumerate(cyc):
                        b = cyc[(m + 1) % len(cyc)]
                        edges.setdefault((min(a, b), max(a, b)), []).append(fi)
    S = dict(yaw=-1.05, pitch=0.38, last=None)
    scale = min(W, H) * 0.38 / rad

    def rot(p):
        q = sub(p, cen)
        c1, s1 = math.cos(S["yaw"]), math.sin(S["yaw"])
        x, y = q[0] * c1 - q[1] * s1, q[0] * s1 + q[1] * c1
        c2, s2 = math.cos(S["pitch"]), math.sin(S["pitch"])
        return [x, y * c2 - q[2] * s2, y * s2 + q[2] * c2]

    def pr(p):
        r = rot(p)
        return (W / 2 + r[0] * scale, H / 2 + 6 - r[2] * scale)

    def front(nr):
        c1, s1 = math.cos(S["yaw"]), math.sin(S["yaw"])
        y = nr[0] * s1 + nr[1] * c1
        return y * math.cos(S["pitch"]) - nr[2] * math.sin(S["pitch"]) < 0

    def plane_pts(names3):
        a, b, c = [PP(x) for x in names3]
        nr = cross(sub(b, a), sub(c, a))
        L = ln(nr)
        if L < 1e-12:
            return [a, b, c]
        nr = scl(nr, 1 / L)
        on = [i for i, p in enumerate(Pt) if abs(dt(sub(p, a), nr)) <= eps]
        return [Pt[i] for i in hull2(on, nr)] if len(on) > 3 else [a, b, c]

    def foot(p, names3):
        a, b, c = [PP(x) for x in names3]
        nr = cross(sub(b, a), sub(c, a))
        return sub(p, scl(nr, dt(sub(p, a), nr) / dt(nr, nr)))
    st = ["立体图形（拖动可以旋转；虚线是被挡住的棱）"] + [cap_of(t, i) for i in range(len(v["asks"]))]

    def draw(P, k):
        def seg(p, q, cls):
            a, b = pr(p), pr(q)
            P.line(a[0], a[1], b[0], b[1], cls)

        def poly(ps, col):
            P.fill_poly([pr(x) for x in ps], col, 0.2)
        q = v["asks"][k - 1] if k > 0 else None
        if q:
            if q.get("plane"):
                poly(plane_pts(q["plane"]), T.accent)
            if q.get("planes"):
                poly(plane_pts(q["planes"][0]), T.accent)
                poly(plane_pts(q["planes"][1]), T.c2)
            if q.get("edge") and q.get("faces"):
                poly([PP(q["edge"][0]), PP(q["edge"][1]), PP(q["faces"][0])], T.accent)
                poly([PP(q["edge"][0]), PP(q["edge"][1]), PP(q["faces"][1])], T.c2)
            if q.get("what") == "area" and q.get("points"):
                poly([PP(x) for x in q["points"]], T.accent)
            if q.get("what") == "volume" and q.get("points"):
                ps = [PP(x) for x in q["points"]]
                if len(ps) == 4:
                    for tr in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)):
                        poly([ps[m] for m in tr], T.accent)
                else:
                    poly(ps[1:], T.c2)
                    for m in range(1, len(ps)):
                        poly([ps[0], ps[m], ps[m + 1 if m + 1 < len(ps) else 1]], T.accent)
        for (a, b), fs in edges.items():
            seg(Pt[a], Pt[b], "edge" if any(front(faces[fi]["nr"]) for fi in fs) else "hidden")
        if q:
            if q.get("between"):
                seg(PP(q["between"][0]), PP(q["between"][1]), "thick1")
            if q.get("lines"):
                seg(PP(q["lines"][0][0]), PP(q["lines"][0][1]), "thick1")
                seg(PP(q["lines"][1][0]), PP(q["lines"][1][1]), "thick2")
            if q.get("line") and q.get("plane"):
                p1, p2 = PP(q["line"][0]), PP(q["line"][1])
                F1, F2 = foot(p1, q["plane"]), foot(p2, q["plane"])
                seg(p1, p2, "thick1")
                seg(F1, F2, "thick2")
                for p, Fp in ((p1, F1), (p2, F2)):
                    if ln(sub(p, Fp)) > eps:
                        seg(p, Fp, "hl3dash")
                        s = pr(Fp)
                        P.dot(s[0], s[1], T.c2, 3.5)
                s = pr(F1 if ln(sub(p1, F1)) > ln(sub(p2, F2)) else F2)
                P.small(s[0] + 7, s[1] + 16, "射影", "start")
            if q.get("edge") and q.get("faces"):
                e0, e1 = PP(q["edge"][0]), PP(q["edge"][1])
                ue = sub(e1, e0)
                u = scl(ue, 1 / ln(ue))
                R, Sx = PP(q["faces"][0]), PP(q["faces"][1])
                Fp = add(e0, scl(u, dt(sub(R, e0), u)))
                r1 = sub(R, Fp)
                w0 = sub(sub(Sx, e0), scl(u, dt(sub(Sx, e0), u)))
                G_ = add(Fp, scl(w0, ln(r1) / (ln(w0) or 1)))
                seg(e0, e1, "thick3")
                seg(Fp, R, "thick1")
                seg(Fp, G_, "thick2")
                s = pr(Fp)
                P.dot(s[0], s[1], T.c2, 3.5)
                P.small(s[0] + 7, s[1] + 14, "二面角的平面角", "start")
            if q.get("what") == "distance_point_plane" and q.get("point") and q.get("plane"):
                p = PP(q["point"])
                Fp = foot(p, q["plane"])
                seg(p, Fp, "thick1")
                s = pr(Fp)
                P.dot(s[0], s[1], T.c2, 3.5)
        c2 = pr(cen)
        import re
        for nm in names:
            s = pr(PP(nm))
            dx, dy = s[0] - c2[0], s[1] - c2[1]
            L = math.hypot(dx, dy) or 1
            P.dot(s[0], s[1], T.fg, 3)
            P.strong(s[0] + dx / L * 14, s[1] + dy / L * 14 + 4, re.sub(r"(\D)(\d+)$", lambda m: m.group(1) + sub_n(m.group(2)), nm))

    def drag(kind, x, y):
        if kind == "down":
            S["last"] = (x, y)
        elif S["last"]:
            S["yaw"] -= (x - S["last"][0]) * 0.01
            S["pitch"] = max(-1.45, min(1.45, S["pitch"] + (y - S["last"][1]) * 0.01))
            S["last"] = (x, y)
    return VizFrame("立体图形", st, draw, "按住拖动旋转视角", drag)


def v_prob(t):
    v = t["viz"]

    def in_ev(x, e):
        return (e["lo"] is None or x > e["lo"] + 1e-9 or (e["lo_in"] and abs(x - e["lo"]) < 1e-9)) and (e["hi"] is None or x < e["hi"] - 1e-9 or (e["hi_in"] and abs(x - e["hi"]) < 1e-9))
    st = [(f"{v['name']}：分布列（柱高 = 概率）" if v["disc"] else f"{v['name']}：密度曲线（面积 = 概率）", None)]
    for i, w in enumerate(v["whats"]):
        if w != "pmf":
            st.append((cap_of(t, i), i))

    def phi(x):
        return math.exp(-((x - v["mu"]) ** 2) / (2 * v["sigma"] ** 2)) / (v["sigma"] * math.sqrt(2 * math.pi))
    if v["disc"]:
        x0, x1 = min(v["xs"]) - 0.8, max(v["xs"]) + 0.8
        Pl = Plot(x0, x1, 0, max(v["ps"]) * 1.2 or 1, xstep=max(1, nice((x1 - x0) / 14)))
    else:
        x0, x1 = v["mu"] - 4 * v["sigma"], v["mu"] + 4 * v["sigma"]
        Pl = Plot(x0, x1, 0, phi(v["mu"]) * 1.18, no_y_axis=True)

    def draw(P, k):
        i = st[k][1]
        w = None if i is None else v["whats"][i]
        ev = None if i is None else v["evs"][i]
        Pl.draw(P)
        if v["disc"]:
            bw = 0.7 * (Pl.sx(1) - Pl.sx(0))
            for j, x in enumerate(v["xs"]):
                hl = ev and in_ev(x, ev)
                P.rect(Pl.sx(x) - bw / 2, Pl.sy(v["ps"][j]), bw, Pl.sy(0) - Pl.sy(v["ps"][j]), T.accent if hl else T.c1, a=0.85 if hl else 0.35)
                if len(v["xs"]) <= 16:
                    P.tick(Pl.sx(x), Pl.sy(v["ps"][j]) - 5, N(v["ps"][j], 3))
        else:
            P.poly_line([(Pl.sx(x0 + (x1 - x0) * m / 240), Pl.sy(phi(x0 + (x1 - x0) * m / 240))) for m in range(241)])
            if ev:
                lo = max(ev["lo"] if ev["lo"] is not None else -math.inf, x0)
                hi = min(ev["hi"] if ev["hi"] is not None else math.inf, x1)
                P.fill_poly([(Pl.sx(lo), Pl.sy(0))] + [(Pl.sx(lo + (hi - lo) * m / 100), Pl.sy(phi(lo + (hi - lo) * m / 100))) for m in range(101)] + [(Pl.sx(hi), Pl.sy(0))], T.accent, 0.3)
        if w in ("E", "D"):
            P.line(Pl.sx(v["E"]), Pl.T, Pl.sx(v["E"]), Pl.T + Pl.h, "hl2")
            P.label(Pl.sx(v["E"]) + 6, Pl.T + 14, f"E = {X(v['E'])}", "start")
        if w == "D":
            s = math.sqrt(v["V"])
            y = Pl.T + Pl.h - 10
            P.line(Pl.sx(v["E"] - s), y, Pl.sx(v["E"] + s), y, "thick1")
            P.line(Pl.sx(v["E"] - s), y - 6, Pl.sx(v["E"] - s), y + 6, "hl1")
            P.line(Pl.sx(v["E"] + s), y - 6, Pl.sx(v["E"] + s), y + 6, "hl1")
            P.small(Pl.sx(v["E"] + s) + 8, y + 4, f"E ± σ，σ = √D = {X(s)}", "start")
    return VizFrame("概率分布", [s[0] for s in st], draw)


def v_seq(t):
    v = t["viz"]
    n = min(len(v["a"]), max([8] + [m for m in v["terms"] + v["sums"] if m <= 30]) + 2)
    st = [(f"数列的前 {n} 项（横轴 n，纵轴 aₙ）", "a")]
    if v["terms"]:
        st.append((f"所求的项：{'、'.join('a' + sub_n(m) for m in v['terms'])}" + ("（超出图中范围的项见上表）" if any(m > n for m in v["terms"]) else ""), "term"))
    st.append(("前 n 项和 Sₙ", "S"))

    def draw(P, k):
        which = st[k][1]
        arr = (v["S"] if which == "S" else v["a"])[:n]
        hl = v["sums"] if which == "S" else v["terms"] if which == "term" else []
        fin = [y for y in arr if _ok(y)]
        y0, y1 = min([0] + fin), max([0] + fin)
        if y1 - y0 < 1e-9:
            y1 += 1
        pd = (y1 - y0) * 0.1
        Pl = Plot(0.3, n + 0.7, y0 - pd, y1 + pd, xstep=max(1, nice(n / 12)))
        Pl.draw(P)
        P.poly_line([(Pl.sx(i + 1), Pl.sy(y)) if _ok(y) else None for i, y in enumerate(arr)], "faint")
        for i, y in enumerate(arr):
            if _ok(y):
                on = i + 1 in hl
                P.dot(Pl.sx(i + 1), Pl.sy(y), T.accent if on else T.c1, 6 if on else 3.5)
        for m in hl:
            if m <= n:
                P.strong(Pl.sx(m), Pl.sy(arr[m - 1]) - 12, N(arr[m - 1], 6))
    return VizFrame("数列", [s[0] for s in st], draw)


# ---------------------------------------------------------------- 化学
def v_reaction(t):
    v = t["viz"]
    sp = v["sp"]
    parsed = [dict(el={}, charge=-1) if x["f"] == "e^-" else parse_formula(x["f"]) for x in sp]
    els = sorted({k for p in parsed for k in p["el"]})
    has_q = any(p["charge"] for p in parsed)

    def count(side, k):
        return sum(x["coef"] * (parsed[i]["charge"] if k == "q" else parsed[i]["el"].get(k, 0)) for i, x in enumerate(sp) if x["side"] == side)
    eq = "  ⟶  ".join(" + ".join(("" if x["coef"] == 1 else N(x["coef"])) + x["label"] for x in sp if x["side"] == s) for s in (0, 1))
    st = [("配平：方程式两边每种原子（离子方程式还有电荷）的数目相等", "atoms")]
    if v["xi"] is not None:
        st.append((f"物质的量之比 = 化学计量数之比；反应进度 ξ = {X(v['xi'])} mol" + (f"（按不足量 {sp[v['limit']]['label']} 计算）" if v["limit"] is not None else ""), "mol"))

    def draw(P, k):
        P.title(W / 2, 30, eq)
        if st[k][1] == "atoms":
            slot = (W - 40) / len(sp)
            for m, x in enumerate(sp):
                cx = 20 + slot * (m + 0.5)
                cnt = round(x["coef"])
                shown = min(cnt, 12)
                for j in range(shown):
                    P.dot(cx - (min(shown, 6) - 1) * 7 + (j % 6) * 14, 64 + (j // 6) * 14, PAL(m), 5.5)
                P.small(cx, 104, f"{str(cnt) + '×' if cnt > 12 else ''}{x['label']}")
            rows = els + (["q"] if has_q else [])
            top = 126
            rh = min(24, (H - top - 10) / (len(rows) + 1))
            P.th(170, top, "原子")
            P.th(330, top, "左边")
            P.th(450, top, "右边")
            for r, e in enumerate(rows):
                y = top + rh * (r + 1)
                lv, rv = count(0, e), count(1, e)
                good = abs(lv - rv) < 1e-9
                P.line(110, y - rh + 7, 530, y - rh + 7, "grid")
                P.strong(170, y, "电荷" if e == "q" else e)
                P.label(330, y, N(lv))
                P.label(450, y, N(rv))
                P.txt(510, y, "✓" if good else "✗", 13, T.ok if good else T.bad, "middle", True)
            return
        given = {q["i"]: q["n"] for q in v["given"]}
        amt = [(x["coef"] * v["xi"] * (v["Y"] if x["side"] == 1 else 1), given.get(i)) for i, x in enumerate(sp)]
        mx = max([max(a[0], a[1] or 0) for a in amt] + [1e-12])
        top = 56
        rh = min(40, (H - top - 20) / len(sp))
        x0, bw = 170, W - 170 - 120
        for i, x in enumerate(sp):
            y = top + rh * i
            used, had = amt[i]
            P.label(x0 - 10, y + rh / 2 + 4, f"{'生成' if x['side'] else '反应'} {x['label']}", "end")
            has_had = had is not None and x["side"] == 0
            if has_had:
                P.rect(x0, y + 4, bw * had / mx, rh - 10, T.c1, a=0.3)
            P.rect(x0, y + 4 + ((rh - 10) * 0.3 if has_had else 0), bw * used / mx, (rh - 10) * (0.4 if has_had else 1), T.accent if x["side"] else T.c1, a=0.85)
            P.small(x0 + bw * max(used, had or 0) / mx + 8, y + rh / 2 + 4, f"{N(used)} mol" + (f" / 给了 {N(had)}" if has_had else "") + ("（不足量）" if v["limit"] == i else ""), "start")
        P.tick(x0, H - 6, "浅色：题目给的量　深色：参加反应 / 生成的量", "start")
    return VizFrame("化学方程式", [s[0] for s in st], draw)


def v_solution(t):
    v = t["viz"]
    weak = next((c for c in v["comps"] if c["Ka"]), None)
    pH = v["pH"]
    st = [(f"pH = {N(pH, 4)}：{'酸性' if pH < 6.9 else '碱性' if pH > 7.1 else '近中性'}（常温下 pH = 7 为中性）", "scale")]

    def is_base(c):
        return "base" in c["type"]

    def form_name(c, j):
        n = len(c["Ka"])
        h = n - j
        if is_base(c):
            return "B" + (("H" + (sub_n(h) if h > 1 else "") + (sup_n(h) if h > 1 else "") + "⁺") if h else "")
        return ("H" + (sub_n(h) if h > 1 else "") if h else "") + "A" + (((sup_n(j) if j > 1 else "") + "⁻") if j else "")

    def alphas(Ka, p):
        Hc = 10 ** -p
        tt = [1.0]
        for j, k in enumerate(Ka):
            tt.append(tt[j] * k / Hc)
        s = sum(tt)
        return [x / s for x in tt]
    if weak:
        st.append((f"{weak['name']} 各形态的分布：在 pH = {N(pH, 3)} 处，" + "，".join(f"{form_name(weak, j)} 占 {'不到 0.01' if a < 1e-4 else N(a * 100, 3)}%" for j, a in enumerate(alphas(weak["Ka"], pH))), "dist"))

    def draw(P, k):
        if st[k][1] == "scale":
            x0, x1, y = 50, W - 50, 150

            def sx(p):
                return x0 + (x1 - x0) * p / 14
            g = QLinearGradient(x0, 0, x1, 0)
            for off, col in ((0, "#d7263d"), (0.25, "#f49d37"), (0.45, "#e8d33f"), (0.55, "#5fb75f"), (0.75, "#2e86ab"), (1, "#6a4c93")):
                g.setColorAt(off, qc(col))
            path = QPainterPath()
            from PySide6.QtCore import QRectF
            path.addRoundedRect(QRectF(x0, y, x1 - x0, 34), 6, 6)
            P.p.fillPath(path, g)
            for p in range(15):
                P.line(sx(p), y + 34, sx(p), y + 40, "axis")
                P.tick(sx(p), y + 54, str(p))
            P.label(sx(3), y - 14, "酸性")
            P.label(sx(7), y - 14, "中性")
            P.label(sx(11), y - 14, "碱性")
            px = sx(max(0, min(14, pH)))
            P.fill_poly([(px, y - 2), (px - 8, y - 16), (px + 8, y - 16)], T.fg)
            P.title(px, y + 80, f"pH = {N(pH, 4)}")
            P.small(W / 2, y + 112, f"c(H⁺) = {N(10 ** -pH, 3)} mol/L　c(OH⁻) = {N(v['Kw'] / 10 ** -pH, 3)} mol/L")
            P.label(W / 2, 40, "　".join(f"{c['name']} {N(c['C'], 3)} mol/L" for c in v["comps"]))
            return
        Pl = Plot(0, 14, 0, 1.05, xstep=1)
        Pl.draw(P)
        P.tick(Pl.L + Pl.w - 4, Pl.T + Pl.h - 6, "pH →", "end")
        n = len(weak["Ka"]) + 1
        for j in range(n):
            P.poly_line([(Pl.sx(14 * m / 200), Pl.sy(alphas(weak["Ka"], 14 * m / 200)[j])) for m in range(201)], "curve", PAL(j))
            peak = 1 if j == 0 else 13 if j == n - 1 else -math.log10(math.sqrt(weak["Ka"][j - 1] * weak["Ka"][j]))
            P.txt(Pl.sx(max(0.6, min(13.4, peak))), Pl.sy(alphas(weak["Ka"], peak)[j]) - 8, form_name(weak, j), 12, PAL(j), "middle", True)
        right = pH < 10
        P.line(Pl.sx(pH), Pl.T, Pl.sx(pH), Pl.T + Pl.h, "hl2")
        P.strong(Pl.sx(pH) + (6 if right else -6), Pl.sy(0.5), f"pH = {N(pH, 3)}", "start" if right else "end")
    return VizFrame("溶液 pH", [s[0] for s in st], draw)


def v_equilibrium(t):
    v = t["viz"]
    n = len(v["sp"])

    def k_expr():
        def c(i):
            return f"c({v['sp'][i]})" + (sup_n(abs(round(v["nu"][i]))) if abs(v["nu"][i]) != 1 else "")
        nu_ = "·".join(c(i) for i in range(n) if v["nu"][i] > 0 and v["in_k"][i])
        de = "·".join(c(i) for i in range(n) if v["nu"][i] < 0 and v["in_k"][i])
        return f"K = {nu_ or '1'} / {'(' + de + ')' if de else '1'} = {N(v['K'], 4)}"
    st = [("三段式：起始量、转化量（与化学计量数成正比）、平衡量", "table"), ("起始与平衡时各物质的物质的量", "bars"), (f"平衡常数：{k_expr()}（浓度 = 物质的量 / {N(v['V'])} L）", "K")]

    def draw(P, k):
        which = st[k][1]
        if which in ("table", "K"):
            x0 = 140
            cw = min(110, (W - x0 - 20) / n)
            rows = [("起始 / mol", v["n0"]), ("转化 / mol", [abs(u * v["xi"]) for u in v["nu"]]), ("平衡 / mol", v["ne"])]
            if v["V"] != 1:
                rows.append(("平衡 / (mol/L)", [x / v["V"] for x in v["ne"]]))
            for i, s in enumerate(v["sp"]):
                P.th(x0 + cw * (i + 0.5), 46, s)
            for r, (lab, arr) in enumerate(rows):
                y = 80 + r * 34
                P.line(30, y - 22, x0 + cw * n, y - 22, "grid")
                P.label(x0 - 12, y, lab, "end")
                for i, x in enumerate(arr):
                    text = (("−" if v["nu"][i] < 0 else "+") if r == 1 else "") + N(x)
                    (P.strong if r == 2 else P.label)(x0 + cw * (i + 0.5), y, text)
            if which == "K":
                P.title(W / 2, 80 + len(rows) * 34 + 40, k_expr())
            else:
                P.small(W / 2, 80 + len(rows) * 34 + 30, f"反应进度 ξ = {N(v['xi'])} mol：反应物减少 ν·ξ，生成物增加 ν·ξ")
            return
        mx = max(v["n0"] + v["ne"] + [1e-12])
        Pl = Plot(-0.5, n - 0.5, 0, mx * 1.2, no_x=True, xstep=1)
        Pl.draw(P)
        bw = (Pl.sx(1) - Pl.sx(0)) * 0.32
        for i, s in enumerate(v["sp"]):
            P.rect(Pl.sx(i) - bw - 2, Pl.sy(v["n0"][i]), bw, Pl.sy(0) - Pl.sy(v["n0"][i]), T.c1, a=0.3)
            P.rect(Pl.sx(i) + 2, Pl.sy(v["ne"][i]), bw, Pl.sy(0) - Pl.sy(v["ne"][i]), T.accent, a=0.85)
            P.label(Pl.sx(i), Pl.T + Pl.h + 18, s)
            P.tick(Pl.sx(i) + 2 + bw / 2, Pl.sy(v["ne"][i]) - 5, N(v["ne"][i], 3))
        P.tick(W - 20, 26, "浅色：起始　深色：平衡", "end")
    return VizFrame("化学平衡", [s[0] for s in st], draw)


# ---------------------------------------------------------------- 生物
def _frac(p, tol=1e-9, q=512):
    r = Solver.rational(p, q, tol)
    return f"{r[0]}/{r[1]}" if r else N(p, 3)


def v_cross(t):
    v = t["viz"]
    idx = {p[0]: i for i, p in enumerate(v["pheno"])}
    st = [(f"亲本 {v['mom_name']} × {v['dad_name']}：各自产生的配子（等位基因分离、非等位基因自由组合）", "gam")]
    if v["grid"]:
        st.append(("棋盘法：雌雄配子随机结合，每格概率相等；颜色表示表型", "grid"))
    for i in range(len(t["rows"])):
        if v["hits"] and i < len(v["hits"]) and v["hits"][i]:
            st.append((cap_of(t, i), f"hit{i}"))
    st.append(("经选择 / 再交配后的表型分布" if v["multi"] else "子代表型分布：" + "、".join(p[0] for p in v["pheno"]), "ph"))

    def chips(P, lst, y, title):
        P.strong(30, y - 12, title, "start")
        cw = min(110, (W - 60) / len(lst))
        for i, q in enumerate(lst):
            x = 30 + cw * i
            P.rect(x, y, cw - 8, 40, T.surface, T.line, 8)
            P.strong(x + (cw - 8) / 2, y + 18, q["a"])
            P.tick(x + (cw - 8) / 2, y + 33, _frac(q["p"]))

    def draw(P, k):
        which = st[k][1]
        if which == "gam":
            chips(P, v["mom"], 70, f"♀ {v['mom_name']}{'' if v['has_x'] else '（亲本 1）'} 的配子")
            chips(P, v["dad"], 200, f"♂ {v['dad_name']}{'' if v['has_x'] else '（亲本 2）'} 的配子")
            return
        if which == "ph":
            tot = sum(p[1] for p in v["pheno"])
            mx = max(p[1] for p in v["pheno"])
            top = 40
            rh = min(42, (H - top - 20) / len(v["pheno"]))
            x0, bw = 150, W - 150 - 130
            for i, (lab, p) in enumerate(v["pheno"]):
                y = top + rh * i
                P.strong(x0 - 10, y + rh / 2 + 4, lab, "end")
                P.rect(x0, y + 4, bw * p / mx, rh - 10, PAL(i), rx=4)
                P.label(x0 + bw * p / mx + 8, y + rh / 2 + 4, _frac(p / tot, 1e-9, 5000), "start")
            return
        grid = v["grid"]
        R, Cn = len(grid), len(grid[0])
        x0, y0 = 110, 54
        cw = (W - x0 - 14) / Cn
        ch = min(46, (H - y0 - 8) / R)
        fs = min(14, cw / 5.5)
        hit = v["hits"][int(which[3:])] if which.startswith("hit") else None
        P.tick(x0 - 10, y0 - 30, "♀ \\ ♂", "end")
        for j, q in enumerate(v["dad"]):
            P.th(x0 + cw * (j + 0.5), y0 - 12, q["a"])
        for i, q in enumerate(v["mom"]):
            P.th(x0 - 10, y0 + ch * (i + 0.5) + 4, q["a"], "end")
        for i, row in enumerate(grid):
            for j, c in enumerate(row):
                h = hit[i * Cn + j] if hit else None
                x, y = x0 + cw * j, y0 + ch * i
                col = T.line if c["dead"] else PAL(idx.get(c["ph"], 0))
                a = 0.12 if (hit and h == 0) or c["dead"] else 0.32 if h == 1 else 0.95 if h == 2 else 0.55
                P.rect(x, y, cw - 2, ch - 2, col, T.accent if h == 2 else None, 3, a, 2)
                P.txt(x + cw / 2 - 1, y + ch / 2 + fs / 3, f"{c['g']} ✕" if c["dead"] else c["g"], fs, T.fg)
    return VizFrame("遗传图解", [s[0] for s in st], draw)


BASE_C = dict(A="#e76f51", T="#2a9d8f", U="#2a9d8f", G="#e9c46a", C="#457b9d")


def v_dna(t):
    v = t["viz"]
    mx = 24
    ln = len(v["seq"])
    off = max(0, min(ln - mx, (v["start"] if v["start"] >= 0 else 0) - 3)) if ln > mx else 0
    cut = ln > mx
    is_rna = v["strand"] == "mrna"
    st = []
    if not is_rna:
        st.append(("DNA 双链：A 与 T、G 与 C 互补配对（A–T 两个氢键，G≡C 三个）" + (f"，显示第 {off + 1}–{min(ln, off + mx)} 个碱基" if cut else ""), "dna"))
    st.append(("mRNA 序列" if is_rna else f"转录：以{'这条模板链' if v['strand'] == 'template' else '另一条（模板）链'}为模板，按 A–U、T–A、G–C、C–G 配对合成 mRNA", "rna"))
    st.append(("翻译：没有找到起始密码子 AUG" if v["start"] < 0 else f"翻译：从第一个 AUG 开始每 3 个碱基一个密码子，到终止密码子为止，共 {len(v['aa'])} 个氨基酸", "aa"))
    bw, x0 = (W - 60) / mx, 30

    def row(P, s, y, lab):
        P.tick(x0 - 6, y + 17, lab, "end")
        for i, b in enumerate(s[off:off + mx]):
            P.rect(x0 + bw * i + 1, y, bw - 2, 26, BASE_C.get(b, T.c1), rx=4)
            P.txt(x0 + bw * (i + 0.5), y + 18, b, 12, "#10233f", "middle", True)

    def draw(P, k):
        on = {s[1] for s in st[:k + 1]}
        coding = v["seq"] if v["strand"] == "coding" else v["comp"] if v["strand"] == "template" else None
        templ = v["seq"] if v["strand"] == "template" else v["comp"] if v["strand"] == "coding" else None
        if not is_rna and "dna" in on:
            row(P, coding, 40, "编码链")
            row(P, templ, 104, "模板链")
            for i, b in enumerate(coding[off:off + mx]):
                n2 = 3 if b in "GC" else 2
                cx = x0 + bw * (i + 0.5)
                for m in range(n2):
                    xx = cx - (n2 - 1) * 2.5 + m * 5
                    P.line(xx, 68, xx, 102, "hbond")
        yR = 60 if is_rna else 180
        if "rna" in on:
            row(P, v["mrna"], yR, "mRNA")
            if not is_rna:
                P.tick(W / 2, yR - 10, "↓ 转录（与模板链互补，T 换成 U）")
        if "aa" in on and v["start"] >= 0:
            yA = yR + 54
            m = 0
            p = v["start"]
            while p + 3 <= len(v["mrna"]) and m <= len(v["aa"]):
                a, b2 = p - off, p - off + 3
                p += 3
                if b2 <= 0 or a >= mx:
                    m += 1
                    continue
                xa = x0 + bw * max(a, 0) + 2
                xb = x0 + bw * min(b2, mx) - 2
                stop = m == len(v["aa"])
                if stop and not v["stop"]:
                    break
                P.poly_line([(xa, yR + 30), (xa, yR + 36), (xb, yR + 36), (xb, yR + 30)], "codon")
                P.rect(xa, yA, xb - xa, 30, T.bad if stop else T.c1, rx=15, a=0.75 if stop else 0.3)
                P.small((xa + xb) / 2, yA + 19, "终止" if stop else AA.get(v["aa"][m], v["aa"][m]))
                m += 1
    return VizFrame("碱基与中心法则", [s[0] for s in st], draw)


def v_foodweb(t):
    v = t["viz"]
    L = v["links"]
    nodes = list(dict.fromkeys(list(L) + [p for d in L.values() for p in d]))
    lv = {}

    def level(x, seen=()):
        if x in lv:
            return lv[x]
        if x not in L or x in seen:
            lv[x] = 0
            return 0
        lv[x] = 1 + max(level(p, (*seen, x)) for p in L[x])
        return lv[x]
    for x in nodes:
        level(x)
    top = max([lv[x] for x in nodes] + [1])
    by = {}
    for x in nodes:
        by.setdefault(lv[x], []).append(x)
    pos = {}
    for l_, xs in by.items():
        for i, x in enumerate(xs):
            pos[x] = (W / 2 + (90 if l_ % 2 else -90) if len(xs) == 1 else W * (i + 1) / (len(xs) + 1), H - 40 - (H - 90) * l_ / top)
    st = ["食物网：箭头表示能量流动的方向（被捕食者 → 捕食者），每传一级只有 " + "～".join(N(e * 100) + "%" for e in v["eff"]) + " 传下去"] + [cap_of(t, i) for i in range(len(v["flows"]))]

    def draw(P, k):
        f = v["flows"][k - 1] if k > 0 else None
        used = {tuple(e) for e in f["used"]} if f else None

        def edge_pt(c, u):
            kx, ky = 34 / abs(u[0] or 1e-9), 18 / abs(u[1] or 1e-9)
            k2 = min(kx, ky)
            return (c[0] + u[0] * k2, c[1] + u[1] * k2)
        for pred, d in L.items():
            for prey, sh in d.items():
                a, b = pos[prey], pos[pred]
                dx, dy = b[0] - a[0], b[1] - a[1]
                ln = math.hypot(dx, dy) or 1
                u = (dx / ln, dy / ln)
                on = used is not None and (prey, pred) in used
                p1, p2 = edge_pt(a, u), edge_pt(b, (-u[0], -u[1]))
                cls = "on" if on else "off" if used is not None else "flow"
                P.line(p1[0], p1[1], p2[0], p2[1], cls)
                col = T.accent if on else T.muted
                P.fill_poly([p2, (p2[0] - u[0] * 8 - u[1] * 4, p2[1] - u[1] * 8 + u[0] * 4), (p2[0] - u[0] * 8 + u[1] * 4, p2[1] - u[1] * 8 - u[0] * 4)], col)
                try:
                    share = float(sh)
                except (TypeError, ValueError):
                    share = math.nan
                if len(d) > 1 and _ok(share) and share != 1:
                    P.tick((a[0] + b[0]) / 2 - u[1] * 12, (a[1] + b[1]) / 2 + u[0] * 12 + 4, N(share * 100, 3) + "%")
        for x in nodes:
            cx, cy = pos[x]
            need = f["need"].get(x) if f else None
            dim = f is not None and need is None
            P.rect(cx - 32, cy - 16, 64, 32, T.chem if x not in L else T.surface, T.line, 10, 0.25 if dim else (0.5 if x not in L else 1), 1)
            P.strong(cx, cy + 5, x)
            if need is not None:
                s = N(need, 4)
                P.rect(cx + 38, cy - 11, 12 + 7 * len(s), 22, T.surface, T.accent, 6)
                P.txt(cx + 44, cy + 5, s, 11, T.fg, "start", True)
    return VizFrame("能量流动", st, draw)


R = dict(func=v_func, conic=v_conic, solid=v_solid, prob=v_prob, seq=v_seq, reaction=v_reaction, solution=v_solution, equilibrium=v_equilibrium, cross=v_cross, dna=v_dna, foodweb=v_foodweb)


def make_viz(t):
    if not t or not t.get("viz") or t.get("kind") not in R:
        return None
    return R[t["kind"]](t)


_ = (QPointF, alpha)
