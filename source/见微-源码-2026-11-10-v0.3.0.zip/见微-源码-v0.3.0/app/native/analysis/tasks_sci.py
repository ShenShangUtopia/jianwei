"""化学、生物题型：方程式与计量、溶液 pH、化学平衡；遗传杂交、碱基与中心法则、能量流动。"""
from __future__ import annotations

import json
import math
import re
from fractions import Fraction

from . import solver as Solver
from .task_core import P, REG, TaskError, asks_of, fail, fmt_n, fmt_x, is_int, isf, need_num, num, num_row, reg

MASS = dict(H=1, He=4, Li=7, Be=9, B=11, C=12, N=14, O=16, F=19, Ne=20, Na=23, Mg=24, Al=27, Si=28, P=31, S=32, Cl=35.5, Ar=40, K=39, Ca=40, Sc=45, Ti=48, V=51, Cr=52, Mn=55, Fe=56, Co=59, Ni=59, Cu=64, Zn=65, Ga=70, Ge=73, As=75, Se=79, Br=80, Kr=84, Rb=85.5, Sr=88, Ag=108, Cd=112, Sn=119, Sb=122, I=127, Xe=131, Cs=133, Ba=137, Pt=195, Au=197, Hg=201, Pb=207)
SUBS, SUPS = "₀₁₂₃₄₅₆₇₈₉", "⁰¹²³⁴⁵⁶⁷⁸⁹"


def parse_formula(s):
    """化学式 → {el: {元素: 个数}, charge}。支持括号、结晶水、^电荷。"""
    s = s.strip()
    if s in ("e", "e-", "e^-"):
        return dict(el={}, charge=-1)
    charge = 0
    cm = re.search(r"\^?\(?(\d*)([+-])\)?$", s)
    if cm and "^" in s:
        charge = (1 if cm.group(2) == "+" else -1) * (int(cm.group(1)) if cm.group(1) else 1)
        s = s[:cm.start()]
    s = re.sub(r"\^$", "", s)
    total = {}
    for part in re.split(r"[·.*]", s):
        mult = 1
        m = re.match(r"^(\d+)", part)
        p = part
        if m:
            mult = int(m.group(1))
            p = part[m.end():]
        i = [0]

        def number():
            mm = re.match(r"\d+", p[i[0]:])
            if mm:
                i[0] += mm.end()
                return int(mm.group(0))
            return 1

        def group():
            r = {}
            while i[0] < len(p):
                ch = p[i[0]]
                if ch in "([":
                    i[0] += 1
                    inner = group()
                    if i[0] >= len(p) or p[i[0]] not in ")]":
                        raise ValueError(f"括号不匹配：{part}")
                    i[0] += 1
                    n = number()
                    for k, v in inner.items():
                        r[k] = r.get(k, 0) + v * n
                elif ch in ")]":
                    return r
                else:
                    mm = re.match(r"[A-Z][a-z]?", p[i[0]:])
                    if not mm:
                        raise ValueError(f"不认识「{p[i[0]:]}」")
                    i[0] += mm.end()
                    if mm.group(0) not in MASS:
                        raise ValueError(f"没有元素 {mm.group(0)}")
                    n = number()
                    r[mm.group(0)] = r.get(mm.group(0), 0) + n
            return r
        for k, v in group().items():
            total[k] = total.get(k, 0) + v * mult
    return dict(el=total, charge=charge)


def balance(lhs, rhs):
    """有理数高斯消元配平；解不唯一时报错。"""
    sp = [parse_formula(x) for x in lhs + rhs]
    keys = sorted({k for s in sp for k in s["el"]})
    if any(s["charge"] for s in sp):
        keys.append("电荷")
    M = [[Fraction((s["charge"] if k == "电荷" else s["el"].get(k, 0)) * (1 if j < len(lhs) else -1)) for j, s in enumerate(sp)] for k in keys]
    n, r, piv = len(sp), 0, []
    for col in range(n):
        if r >= len(M):
            break
        k = next((i for i in range(r, len(M)) if M[i][col] != 0), None)
        if k is None:
            continue
        M[r], M[k] = M[k], M[r]
        pv = M[r][col]
        M[r] = [x / pv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][col] != 0:
                f = M[i][col]
                M[i] = [x - f * M[r][j] for j, x in enumerate(M[i])]
        piv.append(col)
        r += 1
    free = [c for c in range(n) if c not in piv]
    if len(free) != 1:
        raise ValueError("解不唯一" if len(free) > 1 else "无法配平")
    co = [Fraction(0)] * n
    co[free[0]] = Fraction(1)
    for i, c in enumerate(piv):
        co[c] = -M[i][free[0]]
    L = 1
    for x in co:
        L = L * x.denominator // math.gcd(L, x.denominator)
    ints = [int(x * L) for x in co]
    g = 0
    for x in ints:
        g = math.gcd(g, abs(x))
    return dict(coef=[x // (g or 1) for x in ints])


def norm_species(raw):
    s = str(raw).strip()
    s = re.sub(r"[₀-₉]", lambda m: str(SUBS.index(m.group(0))), s)

    def sup(m):
        return "^" + "".join(str(SUPS.index(c)) for c in m.group(1)) + ("+" if m.group(2) == "⁺" else "-")
    s = re.sub(r"([⁰¹²³⁴-⁹]*)([⁺⁻])", sup, s)
    s = re.sub(r"[↑↓]", "", s)
    s = re.sub(r"\((aq|s|l|g)\)$", "", s, flags=re.I)
    s = re.sub(r"[•∙⋅·*]", "·", s)
    s = re.sub(r"\s+", "", s)
    if re.match(r"^e\^?-?$|^e⁻$", s):
        return "e^-"
    if "^" not in s:
        # 没写 ^ 的电荷：Na+、OH- 直接认；Fe3+（单个元素）数字是电荷；NH4+、MnO4-（多原子、一位数字）数字是下标；SO42- 认不准，退回
        m = re.match(r"^(.*?)(\d*)([+-])$", s)
        if m and m.group(1):
            if not m.group(2):
                s = f"{m.group(1)}^{m.group(3)}"
            elif re.match(r"^[A-Z][a-z]?$", m.group(1)):
                s = f"{m.group(1)}^{m.group(2)}{m.group(3)}"
            elif len(m.group(2)) == 1:
                s = f"{m.group(1)}{m.group(2)}^{m.group(3)}"
            else:
                fail(f"「{raw}」的电荷有歧义，请用 ^ 写电荷（如 SO4^2-、PO4^3-、Fe^3+）")
    return s


def parse_equation(src):
    s = re.sub(r"[一-龥△]+", " ", str("" if src is None else src))
    s = re.sub(r"\(\s*\)", " ", s)
    parts = [x.strip() for x in re.split(r"<=>|⇌|⇋|<->|→|⟶|->|={1,3}|—+>?", s) if x.strip()]
    if len(parts) == 3:
        parts = [parts[0], parts[2]]   # 「=MnO2=」这类写在箭头上的催化剂
    if len(parts) != 2:
        fail(f"方程式「{src}」要有一个箭头或等号把反应物和生成物分开")
    species = []
    for si, side in enumerate(parts):
        t = re.sub(r"\s+", "", side)
        i = 0
        while i < len(t):
            cm = re.match(r"(\d+/\d+|\d*\.\d+|\d+)?", t[i:])
            coef = 1
            c0 = cm.group(0)
            nxt = t[i + len(c0)] if i + len(c0) < len(t) else ""
            if c0 and re.match(r"[A-Z(\[e]", nxt):
                coef = Solver.eval_const(c0)
                i += len(c0)
            body = ""
            while i < len(t):
                ch = t[i]
                if ch == "^":
                    m = re.match(r"\^\(?\d*[+-]\)?", t[i:])
                    if not m:
                        fail(f"「{side}」里 ^ 后面应是电荷")
                    body += m.group(0)
                    i += m.end()
                    continue
                if ch in "+-":
                    n2 = t[i + 1] if i + 1 < len(t) else None
                    if ch == "+" and n2 is not None and n2 != "+":
                        break   # 分隔物质的加号
                    body += ch
                    i += 1
                    break
                body += ch
                i += 1
            if i < len(t) and t[i] == "+":
                i += 1
            if not body:
                continue
            species.append(dict(f=norm_species(body), coef=coef, side=si, raw=body))
    if not any(x["side"] == 0 for x in species) or not any(x["side"] == 1 for x in species):
        fail(f"方程式「{src}」缺少反应物或生成物")
    return dict(species=species)


REG["__parse_equation__"] = parse_equation


def molar(f, masses=None):
    if f == "e^-":
        return 0
    try:
        el = parse_formula(f)["el"]
    except ValueError as e:
        fail(f"化学式「{f}」：{e}")
    return sum((masses or {}).get(k, MASS.get(k, math.nan)) * n for k, n in el.items())


def pretty(f):
    if f == "e^-":
        return "e⁻"

    def chg(m):
        return "".join(SUPS[int(c)] for c in m.group(1)) + ("⁺" if m.group(2) == "+" else "⁻")
    s = re.sub(r"\^(\d*)([+-])", chg, f)
    return re.sub(r"([A-Za-z)\]])(\d+)", lambda m: m.group(1) + "".join(SUBS[int(c)] for c in m.group(2)), s)


def eq_text(sp, coef):
    def side(k):
        return " + ".join(("" if coef[i] == 1 else fmt_n(coef[i])) + pretty(x["f"]) for i, x in enumerate(sp) if x["side"] == k)
    return f"{side(0)} = {side(1)}"


def check_balance(eq):
    sp = eq["species"]
    parsed = []
    for x in sp:
        try:
            parsed.append(dict(el={}, charge=-1) if x["f"] == "e^-" else parse_formula(x["f"]))
        except ValueError as e:
            fail(f"化学式「{x['raw']}」：{e}")
    keys = sorted({k for p in parsed for k in p["el"]})
    off = []
    for k in keys + ["电荷"]:
        def amount(side):
            return sum(x["coef"] * (parsed[i]["charge"] if k == "电荷" else parsed[i]["el"].get(k, 0)) for i, x in enumerate(sp) if x["side"] == side)
        lv, rv = amount(0), amount(1)
        if abs(lv - rv) > 1e-9:
            off.append(f"{k}：左边 {fmt_n(lv)}，右边 {fmt_n(rv)}")
    if not off:
        return None
    try:
        b = balance([x["f"] for x in sp if x["side"] == 0], [x["f"] for x in sp if x["side"] == 1])
        order = [x for x in sp if x["side"] == 0] + [x for x in sp if x["side"] == 1]
        hint = "程序配平结果：" + eq_text(order, b["coef"])
    except ValueError as e:
        hint = f"程序也无法唯一配平（{e}）"
    return f"方程式不守恒（{'；'.join(off)}）。{hint}"


def find_sp(eq, name, w):
    f = norm_species(name if name is not None else "")
    for i, x in enumerate(eq["species"]):
        if x["f"] == f:
            return i
    fail(f"{w}「{name}」不在方程式里（方程式中的物质：{'、'.join(x['raw'] for x in eq['species'])}）")


_DOC_RE = """{"kind":"reaction","equation":"2KMnO4+16HCl=2KCl+2MnCl2+5Cl2↑+8H2O","given":[{"species":"KMnO4","mass":15.8}],"masses":{"Cl":35.5},"asks":[{"what":"volume","species":"Cl2","claimed":5.6}]}
  equation 写配平后的方程式（离子用 ^ 写电荷：Fe^3+、NH4^+、SO4^2-、e^-；Na+、Cl-、OH- 这类也认）；程序检查原子与电荷守恒，不守恒会退回并给出程序的配平结果。
  given：题目给出的量，每项 {"species", 以及 mass（g）/ mol / volume（L，气体，标准状况）/ conc（mol/L）+ volume_mL 之一，可加 "purity"（纯度 0~1）}；给了多种反应物时程序按不足量计算。
  masses 可覆盖相对原子质量（默认 H 1、C 12、N 14、O 16、Na 23、Cl 35.5、Fe 56、Cu 64…）；"Vm" 可改气体摩尔体积（默认 22.4）；"yield" 为产率（0~1）。
  what：mol / mass / volume（某物质参加反应或生成的量）、remaining_mol / remaining_mass（过量反应物剩余）、molar_mass（摩尔质量）、coef（化学计量数）、balanced（配平的方程式，claimed 写方程式）。"""


@reg("reaction", "化学", "化学方程式与计量", _DOC_RE)
def run_reaction(s):
    eq = parse_equation(s.get("equation"))
    masses = {k: need_num(v, f"masses.{k}") for k, v in s["masses"].items()} if isinstance(s.get("masses"), dict) else {}
    bad = check_balance(eq)
    if bad:
        fail(bad)
    Vm = need_num(s["Vm"], "Vm", lambda x: x > 0, "正数") if s.get("Vm") is not None else 22.4
    Y = need_num(s["yield"], "yield", lambda x: 0 < x <= 1, "0~1 的数") if s.get("yield") is not None else 1
    sp = eq["species"]
    M = [molar(x["f"], masses) for x in sp]
    amt = []
    for k, g in enumerate(s["given"] if isinstance(s.get("given"), list) else []):
        if not isinstance(g, dict):
            fail(f"given[{k}] 必须是对象")
        i = find_sp(eq, g.get("species"), f"given[{k}].species")
        pur = need_num(g["purity"], f"given[{k}].purity", lambda x: 0 < x <= 1, "0~1 的数") if g.get("purity") is not None else 1
        if g.get("mol") is not None:
            n = need_num(g["mol"], f"given[{k}].mol")
        elif g.get("mass") is not None:
            n = need_num(g["mass"], f"given[{k}].mass") * pur / M[i]
        elif g.get("volume") is not None:
            n = need_num(g["volume"], f"given[{k}].volume") / Vm
        elif g.get("conc") is not None and g.get("volume_mL") is not None:
            n = need_num(g["conc"], f"given[{k}].conc") * need_num(g["volume_mL"], f"given[{k}].volume_mL") / 1000
        else:
            fail(f"given[{k}] 要给 mass、mol、volume 或 conc+volume_mL 之一")
        amt.append(dict(i=i, n=n, xi=n / sp[i]["coef"]))
    reac = [a for a in amt if sp[a["i"]]["side"] == 0]
    prod = [a for a in amt if sp[a["i"]]["side"] == 1]
    xi, limit = None, None
    if reac:
        m = min(reac, key=lambda a: a["xi"])
        xi, limit = m["xi"], m["i"]
    elif prod:
        xi = prod[0]["xi"] / Y

    def need():
        if xi is None:
            fail("要计算物质的量，given 里至少给一种物质的量")
        return xi
    rows = []
    for q in asks_of(s, ["mol", "mass", "volume", "remaining_mol", "remaining_mass", "molar_mass", "coef", "balanced"]):
        w = q["what"]
        if w == "balanced":
            rows.append(dict(prompt=P(q), kind="equation", value=eq, text=eq_text(sp, [x["coef"] for x in sp]), claimed=q.get("claimed")))
            continue
        i = find_sp(eq, q.get("species"), f"{w} 的 species")
        c = sp[i]
        y = Y if c["side"] == 1 else 1
        if w == "molar_mass":
            rows.append(num_row(q, M[i], "g/mol"))
        elif w == "coef":
            rows.append(num_row(q, c["coef"]))
        elif w == "mol":
            rows.append(num_row(q, need() * c["coef"] * y, "mol"))
        elif w == "mass":
            rows.append(num_row(q, need() * c["coef"] * y * M[i], "g"))
        elif w == "volume":
            rows.append(num_row(q, need() * c["coef"] * y * Vm, "L"))
        else:
            g = next((a for a in amt if a["i"] == i), None)
            if not g:
                fail(f"{w}：given 里没有给出「{q.get('species')}」的量")
            left = max(0, g["n"] - need() * c["coef"])
            rows.append(num_row(q, left, "mol") if w == "remaining_mol" else num_row(q, left * M[i], "g"))
    det = [f"方程式守恒：{eq_text(sp, [x['coef'] for x in sp])}", "摩尔质量：" + "，".join(f"{pretty(x['f'])} {fmt_n(M[i])}" for i, x in enumerate(sp) if x["f"] != "e^-") + " g/mol"]
    if xi is not None:
        det.append(f"反应进度 {fmt_x(xi)} mol" + (f"，不足量的是 {pretty(sp[limit]['f'])}" if limit is not None and len(reac) > 1 else "") + (f"，产率 {fmt_n(Y * 100)}%" if Y < 1 else ""))
    return dict(rows=rows, viz=dict(sp=[dict(f=x["f"], label=pretty(x["f"]), side=x["side"], coef=x["coef"], M=M[i]) for i, x in enumerate(sp)], given=[dict(i=a["i"], n=a["n"]) for a in amt], xi=xi, limit=limit if len(reac) > 1 else None, Y=Y), detail=det)


_DOC_SOL = """{"kind":"solution","components":[{"name":"CH3COOH","type":"weak_acid","Ka":[1.8e-5],"c":0.1,"V_mL":20},{"name":"NaOH","type":"strong_base","c":0.1,"V_mL":10}],"asks":[{"what":"pH","claimed":4.74}]}
  type：strong_acid / strong_base（"z" 为几元，默认 1）、weak_acid（"Ka":[Ka1,Ka2,…]）、weak_base（"Kb":[Kb1,…]）、salt_weak_acid（弱酸强碱盐如 CH3COONa、Na2CO3："Ka" 为对应弱酸的电离常数，按 H₂CO₃ 的 [Ka1,Ka2] 写；NaHCO3 再加 "z":1 表示只有一个 Na⁺）、salt_weak_base（强酸弱碱盐如 NH4Cl："Kb"）、ion（只算电荷的离子，"charge"）。
  c 为加入时的浓度（mol/L），V_mL 为加入体积，程序按混合后总体积换算（只有一种溶液可省略 V_mL）；"V_total_mL" 指定稀释后的总体积；"Kw" 默认 1e-14。程序由电荷守恒精确求解。
  what：pH、c_H、c_OH、alpha（"name" 那种弱电解质的电离度 / 水解度）。"""


@reg("solution", "化学", "溶液 pH", _DOC_SOL)
def run_solution(s):
    if not isinstance(s.get("components"), list) or not s["components"]:
        fail("components 必须是非空数组")
    Kw = need_num(s["Kw"], "Kw", lambda x: x > 0, "正数") if s.get("Kw") is not None else 1e-14
    T_ = ["strong_acid", "strong_base", "weak_acid", "weak_base", "salt_weak_acid", "salt_weak_base", "ion"]
    comps = []
    for k, c in enumerate(s["components"]):
        if not isinstance(c, dict):
            fail(f"components[{k}] 必须是对象")
        if c.get("type") not in T_:
            fail(f"components[{k}].type 只能是 {'、'.join(T_)}")

        def K(key):
            v = c.get(key)
            a = v if isinstance(v, list) else [v] if v is not None else []
            if not a:
                fail(f"components[{k}]（{c['type']}）需要 {key}")
            return [need_num(x, f"components[{k}].{key}[{i}]", lambda y: y > 0, "正数") for i, x in enumerate(a)]
        comps.append(dict(name=str(c.get("name") or c["type"]), type=c["type"], c=need_num(c.get("c", 0 if c["type"] == "ion" else None), f"components[{k}].c", lambda x: x >= 0, "非负数"), V=need_num(c["V_mL"], f"components[{k}].V_mL", lambda x: x > 0, "正数") if c.get("V_mL") is not None else None,
                          z=need_num(c["z"], f"components[{k}].z") if c.get("z") is not None else 1, zg=c.get("z") is not None, charge=need_num(c["charge"], f"components[{k}].charge") if c.get("charge") is not None else 0, Ka=K("Ka") if "weak_acid" in c["type"] else None, Kb=K("Kb") if "weak_base" in c["type"] else None))
    vols = [c["V"] for c in comps]
    Vsum = sum(vols) if all(v is not None for v in vols) else None
    if len(comps) > 1 and Vsum is None and s.get("V_total_mL") is None:
        fail("有多种溶液混合时，每种都要给 V_mL")
    Vt = need_num(s["V_total_mL"], "V_total_mL", lambda x: x > 0, "正数") if s.get("V_total_mL") is not None else Vsum
    for c in comps:
        c["C"] = c["c"] * c["V"] / Vt if Vt and c["V"] else c["c"]

    def acid(Ka, H):
        t = [1.0]
        for j, ka in enumerate(Ka):
            t.append(t[j] * ka / H)
        total = sum(t)
        return dict(avg=sum(j * x for j, x in enumerate(t)) / total, a0=t[0] / total, n=len(Ka))

    def base_acid(Kb):
        return [Kw / k for k in reversed(Kb)]   # 共轭酸的 Ka

    def charge(H):
        q = H - Kw / H
        for c in comps:
            C, ty = c["C"], c["type"]
            if ty == "strong_acid":
                q -= c["z"] * C
            elif ty == "strong_base":
                q += c["z"] * C
            elif ty == "ion":
                q += c["charge"] * C
            elif ty == "weak_acid":
                q -= C * acid(c["Ka"], H)["avg"]
            elif ty == "salt_weak_acid":
                q += C * ((c["z"] if c["zg"] else len(c["Ka"])) - acid(c["Ka"], H)["avg"])
            elif ty == "weak_base":
                a = acid(base_acid(c["Kb"]), H)
                q += C * (a["n"] - a["avg"])
            else:
                a = acid(base_acid(c["Kb"]), H)
                q += C * (a["n"] - a["avg"]) - C * (c["z"] if c["zg"] else a["n"])
        return q
    lo, hi = -16.0, 2.0
    for _k in range(200):
        m = (lo + hi) / 2
        if charge(10 ** m) > 0:
            hi = m
        else:
            lo = m
    H = 10 ** ((lo + hi) / 2)
    pH = -math.log10(H)
    rows = []
    for q in asks_of(s, ["pH", "c_H", "c_OH", "alpha"]):
        w = q["what"]
        if w == "pH":
            rows.append(num_row(q, pH))
        elif w == "c_H":
            rows.append(num_row(q, H, "mol/L"))
        elif w == "c_OH":
            rows.append(num_row(q, Kw / H, "mol/L"))
        else:
            c = next((x for x in comps if x["name"] == q.get("name")), None) or next((x for x in comps if "weak" in x["type"]), None)
            if not c or "weak" not in c["type"]:
                fail('alpha 需要 "name" 指向一种弱电解质或弱酸 / 弱碱盐')
            a = acid(c["Ka"], H) if c["Ka"] else acid(base_acid(c["Kb"]), H)
            v = 1 - a["a0"] if c["type"] == "weak_acid" else (len(c["Ka"]) - a["avg"]) / len(c["Ka"]) if c["type"] == "salt_weak_acid" else (a["n"] - a["avg"]) / a["n"] if c["type"] == "weak_base" else a["avg"] / a["n"]
            rows.append(num_row(q, v))
    return dict(rows=rows, viz=dict(pH=pH, Kw=Kw, comps=[dict(name=c["name"], type=c["type"], C=c["C"], Ka=c["Ka"] or (base_acid(c["Kb"]) if c["Kb"] else None)) for c in comps]),
                detail=["混合后：" + "，".join(f"{c['name']} {fmt_n(c['C'], 4)} mol/L" for c in comps) + (f"（总体积 {fmt_n(Vt)} mL）" if Vt else ""), f"电荷守恒解得 c(H⁺) = {fmt_n(H, 4)} mol/L，pH = {fmt_n(pH, 4)}"])


_DOC_EQ = """{"kind":"equilibrium","reaction":"N2+3H2⇌2NH3","V_L":2,"initial":{"N2":1,"H2":3},"at_eq":{"NH3":{"mol":0.4}},"asks":[{"what":"K"},{"what":"conversion","species":"N2","claimed":0.2}]}
  initial 为起始物质的量（mol，没写的为 0）；平衡信息三选一：K（浓度平衡常数）、at_eq（某物质平衡时的 {"mol":…} 或 {"conc":…}）、conversion（{"某反应物": 转化率}）。V_L 为容器体积（默认 1 L）；"exclude":["C"] 列出不写进 K 的固体、纯液体。
  what：K、mol / conc / fraction（平衡时某物质的物质的量 / 浓度 / 物质的量分数）、conversion（某反应物的转化率）、total_mol（平衡时气体总物质的量）、pressure_ratio（平衡与起始的压强比，恒温恒容）。"""


@reg("equilibrium", "化学", "化学平衡", _DOC_EQ)
def run_equilibrium(s):
    eq = parse_equation(s.get("reaction"))
    bad = check_balance(eq)
    if bad:
        fail(bad)
    V = need_num(s["V_L"], "V_L", lambda x: x > 0, "正数") if s.get("V_L") is not None else 1
    ex = {norm_species(x) for x in s.get("exclude") or []}
    sp = eq["species"]
    nu = [(-1 if x["side"] == 0 else 1) * x["coef"] for x in sp]
    init = s.get("initial") if isinstance(s.get("initial"), dict) else {}
    n0 = []
    for x in sp:
        k = next((z for z in init if norm_species(z) == x["f"]), None)
        n0.append(need_num(init[k], f"initial.{k}", lambda y: y >= 0, "非负数") if k else 0)

    def nn(xi):
        return [v + nu[i] * xi for i, v in enumerate(n0)]
    lo, hi = -math.inf, math.inf
    for i in range(len(sp)):
        lim = -n0[i] / nu[i]
        if nu[i] < 0:
            hi = min(hi, lim)
        else:
            lo = max(lo, lim)
    if not hi > lo:
        fail("起始物质的量不允许反应向任何方向进行（反应物和生成物都为 0？）")
    in_k = [x["f"] not in ex for x in sp]

    def ln_q(xi):
        return sum(nu[i] * math.log(max(v, 1e-300) / V) for i, v in enumerate(nn(xi)) if in_k[i])
    if s.get("K") is not None:
        K0 = need_num(s["K"], "K", lambda x: x > 0, "正数")
        lk = math.log(K0)
        a = lo + 1e-12 * (1 + abs(lo))
        b = hi - 1e-12 * (1 + abs(hi))
        for _k in range(200):
            m = (a + b) / 2
            if ln_q(m) > lk:
                b = m
            else:
                a = m
        xi = (a + b) / 2
    elif isinstance(s.get("at_eq"), dict) and s["at_eq"]:
        k, v = next(iter(s["at_eq"].items()))
        i = find_sp(eq, k, "at_eq")
        if isinstance(v, dict):
            val = need_num(v["mol"], f"at_eq.{k}.mol") if v.get("mol") is not None else need_num(v.get("conc"), f"at_eq.{k}.conc") * V
        else:
            val = need_num(v, f"at_eq.{k}")
        xi = (val - n0[i]) / nu[i]
    elif isinstance(s.get("conversion"), dict) and s["conversion"]:
        k, v = next(iter(s["conversion"].items()))
        i = find_sp(eq, k, "conversion")
        if nu[i] > 0:
            fail("conversion 要给反应物的转化率")
        xi = need_num(v, f"conversion.{k}", lambda x: 0 <= x <= 1, "0~1 的数") * n0[i] / -nu[i]
    else:
        fail("平衡信息要给 K、at_eq 或 conversion 之一")
    ne = nn(xi)
    if any(v < -1e-9 for v in ne):
        fail("按给出的条件，平衡时有物质的量为负（" + "，".join(f"{x['raw']} {fmt_n(ne[i])}" for i, x in enumerate(sp)) + "），请检查")
    gas = sum(v for i, v in enumerate(ne) if in_k[i])
    gas0 = sum(v for i, v in enumerate(n0) if in_k[i])
    K = math.exp(ln_q(xi))
    rows = []
    for q in asks_of(s, ["K", "mol", "conc", "fraction", "conversion", "total_mol", "pressure_ratio"]):
        w = q["what"]
        if w == "K":
            rows.append(num_row(q, K))
        elif w == "total_mol":
            rows.append(num_row(q, gas, "mol"))
        elif w == "pressure_ratio":
            rows.append(num_row(q, gas / gas0))
        else:
            i = find_sp(eq, q.get("species"), f"{w} 的 species")
            if w == "mol":
                rows.append(num_row(q, ne[i], "mol"))
            elif w == "conc":
                rows.append(num_row(q, ne[i] / V, "mol/L"))
            elif w == "fraction":
                rows.append(num_row(q, ne[i] / gas))
            else:
                if nu[i] > 0 or not n0[i]:
                    fail("conversion 要指向起始量不为 0 的反应物")
                rows.append(num_row(q, (n0[i] - ne[i]) / n0[i]))
    labels = [pretty(x["f"]) for x in sp]
    return dict(rows=rows, viz=dict(sp=labels, side=[x["side"] for x in sp], n0=n0, ne=ne, nu=nu, xi=xi, V=V, K=K, in_k=in_k),
                detail=["三段式（mol）：起始 " + "，".join(f"{labels[i]} {fmt_n(n0[i])}" for i in range(len(sp))) + "；转化 " + "，".join(fmt_n(abs(nu[i] * xi)) for i in range(len(sp))) + "；平衡 " + "，".join(f"{labels[i]} {fmt_n(ne[i])}" for i in range(len(sp))), f"K = {fmt_n(K)}（V = {fmt_n(V)} L）"])


# ---------------------------------------------------------------- 生物
def frac_text(v):
    r = Solver.rational(v, 5000, 1e-10)
    if r:
        return (str(r[0]) if r[1] == 1 else f"{r[0]}/{r[1]}") + (f"（{fmt_n(v, 4)}）" if r[1] > 1 else "")
    return fmt_n(v, 5)


def to_ints(ps):
    rs = [Solver.rational(p, 5000, 1e-10) or (round(p * 1e4), 10000) for p in ps]
    L = 1
    for r in rs:
        L = L * r[1] // math.gcd(L, r[1])
    ints = [r[0] * L // r[1] for r in rs]
    g = 0
    for x in ints:
        g = math.gcd(g, x)
    return [x // (g or 1) for x in ints]


_DOC_CROSS = """{"kind":"cross","loci":[{"alleles":["A","a"]},{"alleles":["XB","Xb"],"sex_linked":true}],"parents":["AaXBXb","AaXbY"],"lethal":["AA"],"asks":[{"what":"P","phenotype":"aaXbY","claimed":"1/12"},{"what":"phenotype_ratio"}]}
  loci：每对基因一项，alleles 按显性程度从高到低列出（"IA","IB","i" 这类复等位基因也行），"codominant":["IA","IB"] 表示共显性 / 不完全显性；伴 X 遗传写 "sex_linked":true，等位基因写成 "XB"、"Xb"，雄性写 Y。不考虑连锁与交叉互换。
  parents：两个亲本的基因型（伴 X 时一雌一雄）；lethal：致死的基因型（如 "AA"）或表型（带 _，如 "A_bb"）。
  写法：基因型如 "AaBb"、"XBXb"、"XbY"；表型用 "_" 表示任意：如 "A_bb"、"XBX_"、"XbY"、"ii"、"IA_"、"IAIB"。
  "select" 先从子代中挑出某表型（如 "A_B_"），"then" 再让它们 "self"（自交）或 "random"（自由交配），可写成数组表示多代。
  what：P（概率："phenotype" 或 "genotype"，可加 "sex":"male|female"，"given":{同样的条件} 表示条件概率）、phenotype_ratio、genotype_ratio（claimed 写 "9:3:3:1"）、count_phenotypes、count_genotypes。"""


@reg("cross", "生物", "遗传杂交", _DOC_CROSS)
def run_cross(s):
    if not isinstance(s.get("loci"), list) or not s["loci"]:
        fail("loci 必须是非空数组")
    loci = []
    for i, l in enumerate(s["loci"]):
        if not isinstance(l, dict) or not isinstance(l.get("alleles"), list) or len(l["alleles"]) < 2:
            fail(f"loci[{i}] 需要至少两个 alleles")
        al = [str(a) for a in l["alleles"]]
        x = bool(l.get("sex_linked"))
        if x and not all(a.startswith("X") for a in al):
            fail(f"loci[{i}] 是伴 X 遗传，等位基因要写成 XB、Xb 这样")
        loci.append(dict(al=al, x=x, co={str(c) for c in l.get("codominant") or []}))
    has_x = any(l["x"] for l in loci)
    tokens = sorted({a for l in loci for a in l["al"]}, key=lambda t: -len(t))
    if has_x and "Y" in tokens:
        fail("有伴 X 遗传时，常染色体基因不能用字母 Y（会和 Y 染色体混淆），请换一个字母")

    def tokenize(st, w, pattern):
        t = re.sub(r"\s", "", str("" if st is None else st)).replace("^", "")
        out, i = [], 0
        while i < len(t):
            if pattern and t.startswith("X_", i):
                out.append("X_")
                i += 2
                continue
            if pattern and t[i] == "_":
                out.append("_")
                i += 1
                continue
            tok = next((k for k in tokens if t.startswith(k, i)), None)   # 先认等位基因：豌豆的 Y/y（黄色）不是 Y 染色体
            if tok:
                out.append(tok)
                i += len(tok)
                continue
            if has_x and t[i] == "Y":
                out.append("Y")
                i += 1
                continue
            fail(f"{w}「{st}」里「{t[i:]}」认不出（等位基因：{'、'.join(tokens)}{'，雄性写 Y' if has_x else ''}）")
        return out

    def locus_of(tok):
        return next((i for i, l in enumerate(loci) if tok in l["al"]), -1)

    def sort_pair(p, i):
        if loci[i]["x"] and p[1] == "Y":
            return list(p)
        return sorted(p, key=lambda a: loci[i]["al"].index(a))

    def parse_geno(st, w):
        tk = tokenize(st, w, False)
        g = [[] for _l in loci]
        male = has_x and "Y" in tk
        for t in tk:
            if not (has_x and t == "Y"):
                g[locus_of(t)].append(t)
        for i, l in enumerate(loci):
            if l["x"]:
                if male:
                    if len(g[i]) != 1:
                        fail(f"{w}「{st}」是雄性，伴 X 位点应只有一个 X 基因")
                    g[i].append("Y")
                elif len(g[i]) != 2:
                    fail(f"{w}「{st}」伴 X 位点应有两个 X 基因（雄性要写 Y）")
            elif len(g[i]) != 2:
                fail(f"{w}「{st}」第 {i + 1} 对基因（{'/'.join(l['al'])}）应有两个，实际 {len(g[i])} 个")
        return dict(g=[sort_pair(p, i) for i, p in enumerate(g)], sex=("male" if male else "female") if has_x else None)

    def gkey(ind):
        return "".join("".join(p) for p in ind["g"])

    def label(p, i):
        l = loci[i]
        xs = [a for a in p if a != "Y"] if l["x"] else list(p)

        def rank(a):
            return l["al"].index(a)

        def co(a, b):
            return a in l["co"] and b in l["co"]
        vis = sorted([a for a in dict.fromkeys(xs) if not any(rank(b) < rank(a) and not co(a, b) for b in xs)], key=rank)
        if l["x"] and p[1] == "Y":
            return vis[0] + "Y"
        if len(vis) > 1:
            return "".join(vis)
        a = vis[0]
        hides = any(rank(b) > rank(a) and not co(a, b) for b in l["al"])
        return a + ("X_" if l["x"] else "_") if hides else a + a

    def pkey(ind):
        return "".join(label(p, i) for i, p in enumerate(ind["g"]))

    def matcher(cond, w):
        if cond is None:
            return lambda _i: True
        if isinstance(cond, str):
            cond = dict(phenotype=cond) if "_" in cond else dict(genotype=cond)
        if not isinstance(cond, dict):
            fail(f'{w} 必须是字符串或 {{"phenotype"/"genotype"/"sex"}}')
        parts = []
        if cond.get("sex"):
            if cond["sex"] not in ("male", "female"):
                fail(f"{w}.sex 只能是 male 或 female")
            parts.append(lambda ind, sx=cond["sex"]: not has_x or ind["sex"] == sx)
        for key in ("genotype", "phenotype"):
            if cond.get(key) is None:
                continue
            tk = tokenize(cond[key], f"{w}.{key}", True)
            per = [[] for _l in loci]
            last = -1
            for t in tk:
                i = last if t == "_" else next((j for j, l in enumerate(loci) if l["x"]), -1) if t == "X_" or (has_x and t == "Y") else locus_of(t)
                if i < 0:
                    fail(f"{w}.{key}「{cond[key]}」写法不对")
                per[i].append(t)
                last = i
            if has_x and "Y" in tk and not cond.get("sex"):
                parts.append(lambda ind: ind["sex"] == "male")
            if has_x and key == "phenotype" and any(loci[i]["x"] and len(p) == 2 and p[1] != "Y" for i, p in enumerate(per)):
                parts.append(lambda ind: ind["sex"] == "female")

            def check(ind, per=per, key=key):
                for i, p in enumerate(per):
                    if not p:
                        continue
                    if key == "phenotype":
                        if label(ind["g"][i], i) != "".join(p):
                            return False
                    else:
                        want = ["_" if t == "X_" else t for t in p]
                        have = list(ind["g"][i])
                        if len(want) != len(have):
                            return False
                        rest = list(have)
                        for t in want:
                            if t != "_":
                                if t not in rest:
                                    return False
                                rest.remove(t)
                return True
            parts.append(check)
        return lambda ind: all(f(ind) for f in parts)

    def gametes(ind):
        gs = [dict(a=[], p=1.0)]
        for pair in ind["g"]:
            gs = [dict(a=g["a"] + [a], p=g["p"] / 2) for g in gs for a in pair]
        return gs

    def do_cross(pool1, pool2):
        out = {}
        for m in pool1:
            for f in pool2:
                g = [sort_pair([m["a"][i], "Y"] if l["x"] and f["a"][i] == "Y" else [m["a"][i], f["a"][i]], i) for i, l in enumerate(loci)]
                male = has_x and any(l["x"] and f["a"][i] == "Y" for i, l in enumerate(loci))
                ind = dict(g=g, sex=("male" if male else "female") if has_x else None)
                k = gkey(ind) + (ind["sex"] or "")
                if k in out:
                    out[k]["p"] += m["p"] * f["p"]
                else:
                    out[k] = dict(ind, p=m["p"] * f["p"])
        return list(out.values())

    def merge(pool):
        m = {}
        for g in pool:
            k = "|".join(g["a"])
            if k in m:
                m[k]["p"] += g["p"]
            else:
                m[k] = dict(g)
        return list(m.values())
    lethal = [matcher(c, f"lethal[{i}]") for i, c in enumerate(s.get("lethal") or [])]

    def alive(pop_):
        keep = [x for x in pop_ if not any(f(x) for f in lethal)]
        t = sum(x["p"] for x in keep)
        if not t:
            fail("按给出的致死基因型，子代全部致死")
        return [dict(x, p=x["p"] / t) for x in keep]
    if not isinstance(s.get("parents"), list) or len(s["parents"]) != 2:
        fail("parents 必须是两个亲本的基因型")
    par = [parse_geno(p, f"parents[{i}]") for i, p in enumerate(s["parents"])]
    if has_x and sum(1 for p in par if p["sex"] == "male") != 1:
        fail("伴 X 遗传的两个亲本要一雌一雄（雄性写 Y）")
    mom = next(p for p in par if p["sex"] == "female") if has_x else par[0]
    dad = next(p for p in par if p["sex"] == "male") if has_x else par[1]
    pop = alive(do_cross(merge(gametes(mom)), merge(gametes(dad))))
    det = ["亲本配子：" + "　×　".join("、".join("".join(g["a"]) + " " + frac_text(g["p"]) for g in merge(gametes(p))) for p in (mom, dad))]
    if s.get("select") is not None or s.get("then") is not None:
        if s.get("select") is not None:
            f = matcher(s["select"], "select")
            keep = [x for x in pop if f(x)]
            t = sum(x["p"] for x in keep)
            if not t:
                fail("select 的表型在子代中不存在")
            pop = [dict(x, p=x["p"] / t) for x in keep]
            det.append(f"选出 {s['select'] if isinstance(s['select'], str) else json.dumps(s['select'], ensure_ascii=False)}：" + "，".join(f"{gkey(x)} {frac_text(x['p'])}" for x in pop))
        thens = s.get("then") or []
        for step in thens if isinstance(thens, list) else [thens]:
            if step == "self":
                if has_x:
                    fail("伴 X 遗传不能自交")
                out = {}
                for ind in pop:
                    for c in do_cross(merge(gametes(ind)), merge(gametes(ind))):
                        k = gkey(c)
                        if k in out:
                            out[k]["p"] += c["p"] * ind["p"]
                        else:
                            out[k] = dict(c, p=c["p"] * ind["p"])
                pop = alive(list(out.values()))
                det.append("自交一代")
            elif step == "random":
                def pool_of(sx):
                    raw = merge([dict(a=g["a"], p=g["p"] * ind["p"]) for ind in pop if not has_x or ind["sex"] == sx for g in gametes(ind)])
                    t = sum(g["p"] for g in raw)
                    return [dict(g, p=g["p"] / t) for g in raw]
                pop = alive(do_cross(pool_of("female"), pool_of("male")))
                det.append("自由交配一代")
            else:
                fail('then 只能是 "self" 或 "random"（或它们组成的数组）')

    def groups(keyf):
        m = {}
        for x in pop:
            m[keyf(x)] = m.get(keyf(x), 0) + x["p"]
        return sorted(m.items(), key=lambda kv: -kv[1])

    def ratio_row(q, gs):
        ints = to_ints([g[1] for g in gs])
        return dict(prompt=P(q), kind="ratio", value=[g[1] for g in gs], text=" : ".join(str(i) for i in ints) + "（" + "，".join(f"{g[0]} {ints[i]}" for i, g in enumerate(gs)) + "）", claimed=q.get("claimed"))
    rows = []
    for q in asks_of(s, ["P", "phenotype_ratio", "genotype_ratio", "count_phenotypes", "count_genotypes"]):
        w = q["what"]
        if w == "phenotype_ratio":
            rows.append(ratio_row(q, groups(pkey)))
        elif w == "genotype_ratio":
            rows.append(ratio_row(q, groups(gkey)))
        elif w == "count_phenotypes":
            rows.append(num_row(q, len(groups(pkey))))
        elif w == "count_genotypes":
            rows.append(num_row(q, len(groups(gkey))))
        else:
            ev = matcher(dict(phenotype=q.get("phenotype"), genotype=q.get("genotype"), sex=q.get("sex")), "asks")
            giv = matcher(q["given"], "asks.given") if q.get("given") else (lambda _i: True)
            pg = sum(x["p"] for x in pop if giv(x))
            pe = sum(x["p"] for x in pop if giv(x) and ev(x))
            if not pg:
                fail("asks.given 的条件在子代中不存在")
            rows.append({**num_row(q, pe / pg), "text": frac_text(pe / pg)})
    det.append(f"子代（{len(pop)} 种基因型）：" + "，".join(f"{gkey(x)} {frac_text(x['p'])}" for x in sorted(pop, key=lambda x: -x["p"])))
    det.append("表型：" + "，".join(f"{k} {frac_text(p)}" for k, p in groups(pkey)))
    gm, gd = merge(gametes(mom)), merge(gametes(dad))
    multi = s.get("select") is not None or s.get("then") is not None
    grid = None
    if len(gm) <= 8 and len(gd) <= 8:
        grid = []
        for m in gm:
            row = []
            for f in gd:
                ind = do_cross([dict(a=m["a"], p=1)], [dict(a=f["a"], p=1)])[0]
                row.append(dict(g=gkey(ind), ph=pkey(ind), dead=any(fn_(ind) for fn_ in lethal), ind=ind))
            grid.append(row)
    hits = []
    for q in s["asks"]:
        if q["what"] != "P" or not grid or multi:
            hits.append(None)
            continue
        ev = matcher(dict(phenotype=q.get("phenotype"), genotype=q.get("genotype"), sex=q.get("sex")), "asks")
        giv = matcher(q["given"], "asks.given") if q.get("given") else (lambda _i: True)
        hits.append([(2 if ev(c["ind"]) else 1) if not c["dead"] and giv(c["ind"]) else 0 for row in grid for c in row])
    if grid:
        for row in grid:
            for c in row:
                del c["ind"]
    return dict(rows=rows, viz=dict(mom=[dict(a="".join(g["a"]), p=g["p"]) for g in gm], dad=[dict(a="".join(g["a"]), p=g["p"]) for g in gd], grid=grid, pheno=groups(pkey), multi=multi, hits=hits, mom_name=str(s["parents"][par.index(mom)]), dad_name=str(s["parents"][par.index(dad)]), has_x=has_x), detail=det)


CODON = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
AA = dict(F="苯丙", L="亮", I="异亮", M="甲硫", V="缬", S="丝", P="脯", T="苏", A="丙", Y="酪", H="组", Q="谷酰胺", N="天冬酰胺", K="赖", D="天冬", E="谷", C="半胱", W="色", R="精", G="甘")


def aa_name(a):
    return AA[a] + ("" if a in "QN" else "氨酸")


def translate(mrna, from_start=True):
    st = mrna.find("AUG") if from_start else 0
    if st < 0:
        return dict(start=-1, aa=[], stop=False)
    aa, stop, i = [], False, st
    while i + 3 <= len(mrna):
        cd = mrna[i:i + 3]
        a = CODON["UCAG".index(cd[0]) * 16 + "UCAG".index(cd[1]) * 4 + "UCAG".index(cd[2])]
        if a == "*":
            stop = True
            break
        aa.append(a)
        i += 3
    return dict(start=st, aa=aa, stop=stop)


_DOC_DNA = """{"kind":"dna","seq":"TACGGATCC","strand":"template","asks":[{"what":"mrna","claimed":"AUGCCUAGG"},{"what":"protein"}]}
  seq 为碱基序列；strand：coding（DNA 编码链）、template（DNA 模板链，按与 mRNA 对齐的方向写，即 3′→5′）、mrna。
  what：complement（互补链）、mrna、protein（从第一个 AUG 开始翻译到终止密码子；"from_start":false 表示从第一个碱基起翻译；claimed 写氨基酸名，用 - 连接）、codons（密码子个数）、gc（G+C 所占比例）、count（"base" 的个数）、h_bonds（以 seq 为一条链的双链 DNA 的氢键数）。"""


@reg("dna", "生物", "碱基与中心法则", _DOC_DNA)
def run_dna(s):
    strand = s.get("strand") or "coding"
    if strand not in ("coding", "template", "mrna"):
        fail("strand 只能是 coding、template、mrna")
    seq = re.sub(r"[^ACGTU]", "", str(s.get("seq") or "").upper())
    if not seq:
        fail("seq 里没有碱基")
    if ("T" in seq) if strand == "mrna" else ("U" in seq):
        fail("mRNA 里不应有 T" if strand == "mrna" else "DNA 里不应有 U")
    comp = dict(A="U" if strand == "mrna" else "T", T="A", U="A", G="C", C="G")
    complement = "".join(comp[b] for b in seq)
    mrna = seq if strand == "mrna" else seq.replace("T", "U") if strand == "coding" else "".join(dict(A="U", T="A", G="C", C="G")[b] for b in seq)
    tr = translate(mrna, s.get("from_start") is not False)
    protein = "-".join(aa_name(a) for a in tr["aa"])

    def cnt(b):
        return seq.count(b)
    gc = (cnt("G") + cnt("C")) / len(seq)
    rows = []
    for q in asks_of(s, ["complement", "mrna", "protein", "codons", "gc", "count", "h_bonds"]):
        w = q["what"]
        if w == "complement":
            rows.append(dict(prompt=P(q), kind="text", value=complement, text=complement, claimed=q.get("claimed")))
        elif w == "mrna":
            rows.append(dict(prompt=P(q), kind="text", value=mrna, text=mrna, claimed=q.get("claimed")))
        elif w == "protein":
            rows.append(dict(prompt=P(q), kind="text", value=protein, text=protein or ("没有起始密码子 AUG" if tr["start"] < 0 else "（无）"), claimed=q.get("claimed")))
        elif w == "codons":
            rows.append(num_row(q, len(tr["aa"]) + (1 if tr["stop"] else 0)))
        elif w == "gc":
            rows.append(num_row(q, gc))
        elif w == "count":
            b = str(q.get("base") or "").upper()
            if not re.match(r"^[ACGTU]$", b):
                fail('count 需要 "base"：A、C、G、T 或 U')
            rows.append(num_row(q, cnt(b)))
        else:
            rows.append(num_row(q, 2 * (cnt("A") + cnt("T") + cnt("U")) + 3 * (cnt("G") + cnt("C"))))
    triples = " ".join(mrna[i:i + 3] for i in range(0, len(mrna), 3))
    return dict(rows=rows, viz=dict(seq=seq, strand=strand, comp=complement, mrna=mrna, start=tr["start"], stop=tr["stop"], aa=tr["aa"]),
                detail=[f"mRNA：{triples}", "翻译：" + ("没有 AUG" if tr["start"] < 0 else f"从第 {tr['start'] + 1} 个碱基起，{protein or '（无）'}{'，遇终止密码子停止' if tr['stop'] else ''}")])


_DOC_FW = """{"kind":"foodweb","links":{"鹰":{"兔":0.5,"鼠":0.5},"兔":{"草":1},"鼠":{"草":1}},"efficiency":0.1,"asks":[{"what":"producer","consumer":"鹰","amount":1,"mode":"exact","claimed":100}]}
  links：每种消费者吃什么，{"食物": 所占比例}（比例和为 1）；没有出现在 links 键里的是生产者。efficiency 为能量传递效率，可写一个数或 [0.1,0.2]。
  what：producer（"consumer" 增加 "amount" 需要消耗多少生产者）、gain（生产者 "producer" 有 "amount" 时 "consumer" 能增加多少）。mode：exact（按给出的比例和效率）、min / max（题目问「至少 / 最多」：min 走最短食物链、效率取大，max 走最长食物链、效率取小；gain 的 max 对应最多能增加多少）。"""


@reg("foodweb", "生物", "能量流动", _DOC_FW)
def run_foodweb(s):
    L = s.get("links")
    if not isinstance(L, dict):
        fail('links 必须是 {"消费者": {"食物": 比例}}')
    e0 = s.get("efficiency")
    if isinstance(e0, list):
        eff = [need_num(v, f"efficiency[{i}]", lambda x: 0 < x <= 1, "0~1 的数") for i, v in enumerate(e0)]
    else:
        eff = [need_num(e0 if e0 is not None else 0.1, "efficiency", lambda x: 0 < x <= 1, "0~1 的数")]
    e_min, e_max = min(eff), max(eff)
    for k, v in L.items():
        if not isinstance(v, dict) or not v:
            fail(f"links.{k} 必须是非空对象")

    def req(x, mode, seen=()):
        if x in seen:
            fail("食物网有环：" + " → ".join([*seen, x]))
        d = L.get(x)
        if not d:
            return 1
        parts = [(req(prey, mode, (*seen, x)), num(sh)) for prey, sh in d.items()]
        if mode == "exact":
            if len(eff) > 1:
                fail("mode exact 时 efficiency 要给一个确定的数")
            tot = sum(p[1] for p in parts)
            if not all(isf(p[1]) for p in parts) or abs(tot - 1) > 1e-6:
                fail(f"links.{x} 的比例之和应为 1（现在是 {fmt_n(tot)}）；比例未知时用 mode min / max")
            return sum(sh * r / eff[0] for r, sh in parts)
        return min(p[0] for p in parts) / e_max if mode == "min" else max(p[0] for p in parts) / e_min
    rows = []
    for q in asks_of(s, ["producer", "gain"]):
        mode = q.get("mode") or "exact"
        if mode not in ("exact", "min", "max"):
            fail("mode 只能是 exact、min、max")
        if not q.get("consumer") or q["consumer"] not in L:
            fail(f"「{q.get('consumer')}」不是 links 里的消费者")
        amount = need_num(q.get("amount"), f"{q['what']} 的 amount", lambda x: x > 0, "正数")
        if q["what"] == "producer":
            rows.append(num_row(q, amount * req(q["consumer"], mode), q.get("unit") or ""))
        else:
            rows.append(num_row(q, amount / req(q["consumer"], "min" if mode == "max" else "max" if mode == "min" else "exact"), q.get("unit") or ""))

    def flow(x, amt, mode, need, used):
        need[x] = need.get(x, 0) + amt
        d = L.get(x)
        if not d:
            return
        if mode == "exact":
            for p, sh in d.items():
                used.append([p, x])
                flow(p, num(sh) * amt / eff[0], mode, need, used)
            return
        cand = [(p, req(p, mode)) for p in d]
        pick = (min if mode == "min" else max)(cand, key=lambda c: c[1])
        used.append([pick[0], x])
        flow(pick[0], amt / (e_max if mode == "min" else e_min), mode, need, used)
    flows = []
    for i, q in enumerate(s["asks"]):
        mode = q.get("mode") or "exact"
        m2 = ("min" if mode == "max" else "max" if mode == "min" else "exact") if q["what"] == "gain" else mode
        amt = num(q.get("amount")) if q["what"] == "producer" else rows[i]["value"]
        need, used = {}, []
        if isf(amt):
            flow(q["consumer"], amt, m2, need, used)
        flows.append(dict(need=need, used=used, consumer=q["consumer"], what=q["what"], mode=mode))

    def rel(k, v):
        return k + " ← " + "、".join(p + (f" {fmt_n(num(sh) * 100)}%" if isf(num(sh)) and len(v) > 1 else "") for p, sh in v.items())
    return dict(rows=rows, viz=dict(links=L, eff=eff, flows=flows), detail=["传递效率 " + "～".join(fmt_n(e * 100) + "%" for e in eff) + "；食物关系：" + "；".join(rel(k, v) for k, v in L.items())])


_ = (TaskError, is_int)
