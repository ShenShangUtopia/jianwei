"""受预算约束的声明式讲题图；数据校验不依赖 Qt。"""
from .schema import validate, FigureError
from .fallback import from_problem

__all__ = ["validate", "FigureError", "from_problem"]
