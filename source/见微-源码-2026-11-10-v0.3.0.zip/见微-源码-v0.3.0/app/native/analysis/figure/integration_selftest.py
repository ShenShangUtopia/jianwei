"""流式片段、修正轮次、来源核对及页面票据。"""
import copy
import json
import sys
import time
from pathlib import Path
from ...kit import test_runtime

test_runtime.configure()


def main(output=None):
    app=test_runtime.application()
    from .. import llm, lesson
    from ..page import AnalysisPage
    from .fallback import from_problem
    from .evidence import reconcile
    from .stream import peek_figure
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    figure=from_problem("已知速度 v=10 m/s，时间 t=2 s，求位移。")
    raw=json.dumps(dict(figure=figure,steps=["检查条件"]),ensure_ascii=False)
    prefix=raw[:raw.index('"condition0"')+len('"condition0"')]
    assert peek_figure(prefix) is not None
    assert llm.peek(raw)["figure"]["v"]==1
    assert llm.peek(raw)["steps"]==["检查条件"]
    assert peek_figure('{"figure":{"layers":[{"id":"x","type":"text","text":"没有结束') is None
    assert peek_figure("x"*200001) is None
    bad=copy.deepcopy(figure)
    bad["steps"][0]["show"]=["missing"]
    response=dict(subject="历史",topic="因果链",module=None,steps=["看时间与条件"],answer="依据材料",figure=bad)
    checked=lesson.check1(response,"材料",())
    assert not checked["ok"] and "figure" not in checked["fallback"]
    fixed=dict(response,figure=figure)
    forged=lesson.check1(dict(fixed,taskRes=[dict(title="伪造程序核对")],calc=dict(verdict="solved")),"材料",())
    assert forged["ok"] and "taskRes" not in forged["value"] and "calc" not in forged["value"]
    class RecordedEngine:
        calls=0
        def ask(self,messages,**kwargs):
            self.calls+=1
            return json.dumps(response if self.calls<3 else fixed,ensure_ascii=False),False
    engine=RecordedEngine()
    result=llm.ask_json(engine,"题目",lambda j:lesson.check1(j,"材料",()))
    assert result["ok"] and engine.calls==3
    numeric=dict(v=1,layers=[dict(id="answer",type="text",x=50,y=50,text="结果",value=99,bind="task:0:row:0")],steps=[dict(say="核对",show=["answer"],highlight=[])])
    converted,notes=reconcile(numeric,dict(problem="",taskRes=[dict(rows=[dict(prompt="位移",text="20 m",value=20)])]))
    assert converted["layers"][0]["value"]==20 and notes and "99" in notes[0]
    assert "99" not in converted["layers"][0]["text"] and "20" in converted["layers"][0]["text"]
    page=AnalysisPage()
    page.resize(1500,850)
    page.show()
    page.engine_box.setCurrentIndex(1)
    page.go("结合材料，说明城市区位条件与交通发展的关系。")
    assert page.figure_view is not None and page.first_figure_ms is not None
    started=time.perf_counter()
    while page.L is None and time.perf_counter()-started<10:
        app.processEvents()
        time.sleep(.01)
    assert page.L and page.L.get("unsupported") and page.right.currentIndex()>0
    current=page.figure_view.figure
    page._on_draft(page.rev-1,dict(figure=figure,summary="过时"))
    assert page.figure_view.figure==current
    page.grab().save(str(out/"fallback-page.png"))
    page._on_draft(page.rev,dict(figure=figure,summary="正在分析"))
    same=page.figure_view
    page._on_draft(page.rev,dict(figure=figure,summary="继续分析"))
    assert page.figure_view is same
    value=dict(subject="数学",topic="连续分析",summary="",problem="一元二次函数",knowns=[],steps=["观察","核对"],answer="待核对",figure=figure,ticket=lesson.ticket("第二题",page.rev))
    page._on_done(page.rev,value)
    page._on_draft(page.rev,dict(figure=figure,summary="更新草稿"))
    page._on_done(page.rev,value)
    # 图只有一步时不出步骤按钮，步骤条直接显示这一步的话
    assert page.step_bar.isVisible() and page.step_text.text() and page.track.isHidden()
    first=page.first_figure_ms
    page.shutdown()
    page.close()
    (out/"timing.json").write_text(json.dumps(dict(local_fallback_first_ms=first,real_network="未实测；全部使用离线或假回复"),ensure_ascii=False),encoding="utf-8")
    print("FIGURE_PHASE2 OK stream, repairs, values, fallback, ticket, reuse; first local figure",first,"ms",flush=True)
    return 0


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
