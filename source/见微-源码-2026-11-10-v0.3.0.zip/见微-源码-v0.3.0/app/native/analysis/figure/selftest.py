"""图解脚本离屏回归；不联网，不读真实数据。"""
from __future__ import annotations

import copy
import json
import sys
from pathlib import Path
from ...kit import test_runtime

test_runtime.configure()


def main(output=None):
    test_runtime.application()
    from ...design import tokens
    from .schema import validate, FigureError
    from .fallback import from_problem
    from .view import FigureView
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    figure = dict(v=1,title="函数与因果关系 · 图解基础",subject="数学",layers=[
        dict(id="axis",type="numberline",x=80,y=430,w=420,h=40),
        dict(id="curve",type="function",expr="x^2-2",range=[-3,3,-3,6],x=80,y=110,w=420,h=330,color="c1"),
        dict(id="flow",type="flow",x=540,y=110,w=410,h=200,items=["读出条件","建立关系","程序复算"],color="accent"),
        dict(id="table",type="table",x=540,y=350,w=410,h=160,rows=[["输入","输出"],["x","x²−2"]]),
        dict(id="label",type="text",x=60,y=550,w=890,h=65,text="图元只描述数据，函数由安全表达式计算。",color="muted")],steps=[
            dict(say="先看坐标和条件",show=["axis","flow","label"],highlight=["axis"]),
            dict(say="函数曲线由程序逐点计算",show=["axis","curve","flow","table","label"],highlight=["curve"])])
    validate(figure)
    bad=[]
    for change in (lambda f:f.update(v=9),lambda f:f["layers"].append(f["layers"][0]),lambda f:f["layers"][1].update(expr="__import__('os')"),lambda f:f["layers"][1].update(expr="fact(9999999)"),lambda f:f["layers"][0].update(x=float("nan")),lambda f:f["steps"][0].update(show=["missing"]),lambda f:f.update(layers=[{}]*1000),lambda f:f["layers"][0].update(points=[[1,"bad"]])):
        candidate=copy.deepcopy(figure)
        change(candidate)
        try:
            validate(candidate)
            bad.append(candidate)
        except FigureError:
            pass
    cyclic=copy.deepcopy(figure)
    cyclic["cycle"]=cyclic
    try:
        validate(cyclic)
        bad.append("cycle")
    except FigureError:
        pass
    assert not bad,"非法脚本未被拒绝"
    heavy=dict(v=1,layers=[dict(id=f"g{i}",type="genetics",items=["AaBbCc","×","AaBbCc"]) for i in range(4)],steps=[dict(say="过密",show=[],highlight=[])])
    try:
        validate(heavy)
        raise AssertionError("绘制预算没有生效")
    except FigureError:
        pass
    for theme in ("day","night"):
        tokens.set_theme(theme)
        view=FigureView(figure)
        view.resize(1100,820)
        view.show()
        view.go(1)
        view.image().save(str(out/f"gallery-{theme}.png"))
        assert b"<svg" in view.svg()
        view.toggle_play()
        view.advance()
        view.advance()
        assert not view.timer.isActive()
        view.replace(from_problem("已知一个圆的半径为3，求其面积。"))
        assert view.figure["layers"] and "未经 AI" in view.figure["layers"][1]["text"]
        view.image().save(str(out/f"fallback-{theme}.png"))
        view.close()
    (out/"sample-v1.json").write_text(json.dumps(figure,ensure_ascii=False,indent=2),encoding="utf-8")
    print("FIGURE_PHASE1 OK schema=9 hostile cases, day/night, PNG/SVG, playback",flush=True)
    return 0


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
