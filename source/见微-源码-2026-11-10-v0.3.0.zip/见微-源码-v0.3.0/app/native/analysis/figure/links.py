"""Link only explicitly named quantities to existing Figure IDs, never infer proofs."""
import html
import re
from html.parser import HTMLParser


def terms(figure):
    result={}
    for layer in (figure or {}).get('layers',[]):
        names=list(layer.get('symbols',[]))
        label=layer.get('label','')
        if isinstance(label,str) and 1<len(label)<=16:
            names.append(label)
        for name in names:
            if isinstance(name,str) and 1<=len(name)<=24:
                result.setdefault(name,[]).append(layer['id'])
    return dict(list(sorted(result.items(),key=lambda x:-len(x[0])))[:64])


def linkify(text,figure,color=None):
    mapping=terms(figure)
    if not mapping:
        return text
    pattern=re.compile('|'.join('(?<![A-Za-z0-9_])'+re.escape(t)+'(?![A-Za-z0-9_])' if t.isascii() else re.escape(t) for t in mapping))
    class Parser(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=False)
            self.output=[]
            self.anchor=0
        def handle_starttag(self,tag,attrs):
            if tag=='a':
                self.anchor+=1
            self.output.append(self.get_starttag_text())
        def handle_endtag(self,tag):
            if tag=='a':
                self.anchor=max(0,self.anchor-1)
            self.output.append('</'+tag+'>')
        def handle_startendtag(self,tag,attrs):
            self.output.append(self.get_starttag_text())
        def handle_entityref(self,name):
            self.output.append('&'+name+';')
        def handle_charref(self,name):
            self.output.append('&#'+name+';')
        def handle_data(self,data):
            def replace(match):
                word=match.group()
                ids=','.join(mapping[word])
                style=f' style="color:{color};text-decoration:none"' if isinstance(color,str) and re.fullmatch(r'#[0-9a-fA-F]{6}',color) else ''
                return '<a href="jwlayer:'+html.escape(ids,quote=True)+'"'+style+'>'+html.escape(word)+'</a>'
            self.output.append(pattern.sub(replace,data) if not self.anchor else data)
    parser=Parser()
    parser.feed(text)
    parser.close()
    return ''.join(parser.output)
