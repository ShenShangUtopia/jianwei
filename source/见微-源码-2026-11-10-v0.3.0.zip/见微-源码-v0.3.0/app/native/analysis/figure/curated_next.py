"""Six individually reviewed original flow questions; signatures freeze the inputs."""
import hashlib
import math
from .schema import validate

SIGNATURES={
    'p-2023-b-08':'c42e58f4ea8f490d2ce19f3b10a61b82481241ac95669f19cef023468d81c7ed',
    'p-2024-b-08':'57723be7920e74a6c9c92862d5e866c6f1e06ff7449d13d5144f84f800770a7e',
    'c-2023-qgj-08':'8724e384221b9646f97e85ef6ae8e111e27dc8d7e72ff3bffc4d3a847357c922',
    'c-2023-qgy-13':'c114201d6039e075bc95078afbd1e7890f15271c1fb4867c3ad69ce059de5637',
    'b-2024-xkb-01':'6e8673f2d483ba2798ff5d3f12fb5a3c01d3debc773768493a1f014637d47010',
    'b-2025-qgj-29':'a909db7a9283d1d5a9ca80e6cc4e134fc23873e1192cb704d35b399f5539f0bb',
}


def for_question(q):
    ident=q.get('id')
    if ident not in SIGNATURES or hashlib.sha256((q['stem']+'\0'+q['answer']).encode()).hexdigest()!=SIGNATURES[ident]:
        return None
    layers=[]
    def add(type_,id,x,y,**rest):
        layers.append(dict(type=type_,id=id,x=x,y=y,**rest))
        return id
    def text(id,x,y,value,w=410,color='fg',**rest):
        return add('text',id,x,y,text=value,w=w,h=75,color=color,**rest)
    text('title',35,20,q.get('title','本题图解'),w=930,color='accent')
    text('note',35,565,'逐题核对的结构与关系示意；位置不代表真实比例。题干与原答案未修改。',w=930,color='muted')
    focus=[]
    if ident=='p-2023-b-08':
        radius=1.67e-27*2e6/(1.6e-19*.5)
        period=2*math.pi*1.67e-27/(1.6e-19*.5)
        add('rect','field',70,110,w=450,h=390,color='muted')
        for i in range(4):
            for j in range(3):
                add('circle',f'B{i}{j}',120+100*i,170+110*j,r=3,color='c3')
        add('circle','orbit',290,300,r=130,color='c1')
        add('point','proton',160,300,r=6,color='c2')
        add('arrow','speed',160,300,x2=160,y2=205,color='c2',symbols=['速率','v'])
        add('arrow','force',160,300,x2=245,y2=300,color='c3',symbols=['洛伦兹力','向心力'])
        add('line','radius',160,300,x2=290,y2=300,color='accent',symbols=['半径','r'])
        text('direction',80,480,'正电荷，磁场向纸外；速度向上时磁力向圆心。',w=450)
        text('r_answer',565,135,f'qvB=mv²/r\nr=mv/(qB)={radius:.5g} m≈{radius*100:.2g} cm',source='program')
        text('T_answer',565,280,f'T=2πr/v=2πm/(qB)\nT={period:.5g} s',source='program',symbols=['周期','T'])
        text('invariant',565,425,'改变速率会改变半径；在同一非相对论匀强磁场中，周期与速率无关。')
        focus=[['speed','force'],['radius','r_answer'],['T_answer'],['T_answer','invariant']]
    elif ident=='p-2024-b-08':
        add('arrow','p_axis',100,430,x2=100,y2=260,color='muted')
        add('arrow','v_axis',100,430,x2=490,y2=430,color='muted')
        add('plot','pv',70,100,points=[[220,430],[220,315],[420,315],[420,430]],color='c1')
        add('arrow','isobaric',220,315,x2=420,y2=315,color='accent',symbols=['等压','做功'])
        text('axis_units',110,235,'p（等压）',w=150,color='muted')
        text('pv_label',100,450,'V：2 L → 3 L；线下面积对应 W=100 J\n横轴为体积，竖轴为压强，坐标为示意。',w=440,source='problem')
        text('temperature',560,110,f'V₁/T₁=V₂/T₂\nT₂=300×3/2={300*3/2:g} K',source='program',symbols=['温度','T₂'])
        add('rect','gas',190,120,w=160,h=105,color='c1')
        add('arrow','heat',70,160,x2=190,y2=160,color='c2')
        text('Q',80,75,'吸热 Q=250 J',w=280,source='problem')
        add('arrow','work',350,160,x2=485,y2=160,color='c3')
        text('W',365,185,'对外做功100 J',w=220,source='problem')
        text('energy',560,300,f'内能变化 ΔU=Q−W\n={250-100:g} J（增加）',source='program',symbols=['内能','ΔU'])
        text('sign',560,430,'这里W取气体对外做功为正；若采用外界对气体做功，公式符号需相应改变。')
        focus=[['pv'],['temperature'],['heat','work'],['energy','sign']]
    elif ident=='c-2023-qgj-08':
        text('a',45,105,'A 合成氨：可逆反应不等于完全转化\n不能直接认定转移电子为6N_A',color='bad')
        add('arrow','forward',100,205,x2=370,y2=205,color='c1')
        add('arrow','backward',370,225,x2=100,y2=225,color='c2')
        text('b',530,105,'B 标准状况的CCl₄是液体\n22.4 L/mol不适用于这里',color='bad')
        add('rect','liquid',650,190,w=140,h=85,color='c1')
        text('c',45,300,'C 碳酸根水解：\nCO₃²⁻+H₂O ⇌ HCO₃⁻+OH⁻\nCO₃²⁻数目小于形式浓度对应值',color='bad')
        text('d',530,300,'D 乙烯：每个分子有一个碳碳双键\n1 mol乙烯有N_A个碳碳双键',color='ok')
        text('cc',635,410,'H₂C=CH₂',w=230,color='c1')
        add('line','double1',660,470,x2=790,y2=470,color='accent')
        add('line','double2',660,480,x2=790,y2=480,color='accent')
        focus=[['a','forward','backward'],['b','liquid'],['c'],['d','cc','double1','double2']]
    elif ident=='c-2023-qgy-13':
        add('bar','initial',70,165,w=390,h=230,scale_max=2,items=[2,1,0],labels=['SO₂','O₂','SO₃'],color='c1')
        add('bar','equilibrium',535,165,w=390,h=230,scale_max=2,items=[.4,.2,1.6],labels=['SO₂','O₂','SO₃'],color='c3')
        text('label1',70,85,'初始物质的量 / mol',source='problem')
        text('label2',535,85,'平衡物质的量 / mol',source='program')
        text('conversion',70,470,f'SO₂转化率=(2−0.4)/2={.8:.0%}',source='program')
        k=.8**2/(.2**2*.1)
        text('constant',535,470,f'浓度：0.2、0.1、0.8 mol/L\nK=[SO₃]²/([SO₂]²[O₂])={k:g}',source='program',symbols=['平衡常数','K'])
        focus=[['initial','equilibrium'],['equilibrium','constant'],['conversion'],['constant']]
    elif ident=='b-2024-xkb-01':
        text('fat_name',60,90,'脂肪：三酰甘油骨架示意\n元素为C、H、O，不含P',color='c1')
        add('line','glycerol',120,220,x2=120,y2=400,color='c1')
        for i in range(3):
            yy=230+i*75
            add('plot','chain'+str(i),120,yy,points=[[120,yy],[200,yy-18],[260,yy+10],[325,yy-18],[395,yy+10]],color='c1')
        text('phospho_name',545,90,'甘油磷脂示意：含磷头部+两条疏水链\n含P，许多类型还含N；不是脂肪。',color='c3')
        add('circle','phosphate',730,245,r=32,color='c3',symbols=['磷','含磷头部'])
        text('P',713,215,'P',w=60,color='c3')
        for i,xx in enumerate((710,750)):
            add('plot','tail'+str(i),xx,280,points=[[xx,280],[xx-10,315],[xx+10,350],[xx-10,385],[xx+10,425]],color='c3')
        text('answer',60,475,'D把脂肪也说成含磷，因此错误。图只解释该选项的结构区别，不替代完整分子结构。',w=880,color='bad')
        focus=[['fat_name','chain0','chain1','chain2'],['glycerol'],['phospho_name','phosphate'],['answer','phosphate']]
    else:
        add('bar','rates',70,145,w=440,h=330,items=[4,6,6+4],labels=['呼吸','净光合','真正光合'],color='c1')
        text('units',70,90,'统一单位：mg CO₂/(h·100 cm²)',w=470,source='problem')
        add('cell','leaf',585,150,w=280,h=230,color='c3')
        text('gross',560,410,f'真正光合=净光合+呼吸\n=6+4={6+4}',source='program',symbols=['真正光合','净光合','呼吸'])
        text('assumption',560,90,'按本题常规近似：光照与黑暗条件下呼吸速率相同；不将此近似当作所有植物的普遍规律。')
        focus=[['rates'],['rates','units'],['gross'],['gross','assumption']]
    ids=[l['id'] for l in layers]
    steps=[dict(say=str(s),show=ids,highlight=focus[min(i,len(focus)-1)]) for i,s in enumerate(q.get('steps') or ['观察本题关系'])]
    return validate(dict(v=1,title=q.get('title','本题图解'),subject=q['subject'],specific=True,original_flow=True,layers=layers,steps=steps))
