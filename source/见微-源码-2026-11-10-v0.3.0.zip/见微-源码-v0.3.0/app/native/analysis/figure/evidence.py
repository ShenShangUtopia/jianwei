"""数字来源绑定：程序结果优先，AI 数字只作为待核对主张。"""
import copy
import math
import re
import json


def reconcile(figure, lesson):
    out = copy.deepcopy(figure)
    checks = []
    text = str(lesson.get("problem", ""))
    given=set(re.findall(r"(?<![0-9.])[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?",text.replace("−","-")))
    for layer in out["layers"]:
        bind = layer.get("bind")
        if bind:
            hit = re.fullmatch(r"task:(\d+):row:(\d+)",bind)
            try:
                if not hit:
                    raise ValueError("来源格式")
                row = lesson["taskRes"][int(hit[1])]["rows"][int(hit[2])]
                val = row.get("value")
                claim = layer.get("value")
                if isinstance(val,(int,float)) and not isinstance(val,bool) and math.isfinite(val):
                    if claim is not None and abs(claim-val)>max(1e-6,abs(val)*.02):
                        checks.append(f"{layer['id']}：图中 {claim:g} 与程序 {val:g} 不符，已用程序值替换")
                    layer["value"] = val
                layer["label"] = str(row.get("prompt", ""))+"："+str(row.get("text",val))
                if layer.get("type") in ("text","formula"):
                    layer["text"]=layer["label"]
                    layer.pop("label",None)
                layer["source"] = "program"
                if layer.get("type")=="bar":
                    if isinstance(val,list) and all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in val):
                        layer["items"]=list(val)
                    elif isinstance(val,(int,float)) and not isinstance(val,bool) and math.isfinite(val):
                        layer["items"]=[val]
                elif layer.get("rows") or layer.get("items"):
                    checks.append(f"{layer['id']}：已核对标注，内部表格/集合数据仍需单独核对")
                    layer["color"]="warn"
            except (KeyError,IndexError,TypeError,ValueError):
                checks.append(f"{layer['id']}：数值来源不存在，不能核对")
                layer["color"] = "warn"
        elif layer.get("type")=="function":
            normalize=lambda s:re.sub(r"\s+","",str(s)).replace("²","^2").replace("³","^3").replace("**","^")
            expr=normalize(layer.get("expr",""))
            verified=any(normalize((task.get("viz") or {}).get("f",""))==expr for task in lesson.get("taskRes") or [])
            if not verified and expr not in normalize(text):
                checks.append(f"{layer['id']}：函数关系尚未与题干或程序模型核对")
                layer["color"]="warn"
        else:
            label = str(layer.get("label", ""))+str(layer.get("text", ""))+json.dumps(layer.get("items",[]),ensure_ascii=False)+json.dumps(layer.get("rows",[]),ensure_ascii=False)
            numbers = re.findall(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?",label)
            unsupported = [n for n in numbers if n not in given]
            if unsupported or (numbers and layer.get("source")!="problem") or "value" in layer:
                checks.append(f"{layer['id']}：AI 图中文字或数值未经程序核对")
                layer["color"] = "warn"
    return out,checks
