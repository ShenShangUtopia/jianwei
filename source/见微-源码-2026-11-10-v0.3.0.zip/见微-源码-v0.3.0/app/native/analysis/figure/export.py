"""原生讲题导出：完整文字与逐步图，长图有像素预算。"""
import math
from pathlib import Path
from PySide6.QtCore import QMarginsF,QRectF,Qt
from PySide6.QtGui import QColor,QFont,QImage,QPainter,QPageLayout,QPageSize,QPdfWriter,QTextDocument


def export_lesson(lesson,path,images):
    path=Path(path)
    title=str(lesson.get("topic") or "讲题")
    text="题目\n"+str(lesson.get("problem") or "")+"\n\n答案\n"+str(lesson.get("answer") or "尚未完成求解")
    text+="\n\n解题步骤\n"+"\n".join(f"{i+1}. {step}" for i,step in enumerate(lesson.get("steps") or []))
    doc=QTextDocument()
    doc.setDefaultFont(QFont("Microsoft YaHei",13))
    doc.setPlainText(title+"\n\n"+text)
    doc.setTextWidth(1100)
    captions=list(lesson.get("steps") or [])
    material=[(image,captions[i] if i<len(captions) else "图解步骤 "+str(i+1)) for i,image in enumerate(images)]
    if path.suffix.lower()==".pdf":
        writer=QPdfWriter(str(path))
        writer.setTitle(title)
        writer.setResolution(144)
        writer.setPageLayout(QPageLayout(QPageSize(QPageSize.PageSizeId.A4),QPageLayout.Orientation.Portrait,QMarginsF(12,12,12,12)))
        painter=QPainter(writer)
        width,height=writer.width(),writer.height()
        scale=width/1100
        pageheight=height/scale
        offset=0
        while offset<doc.size().height():
            painter.save()
            painter.scale(scale,scale)
            painter.setClipRect(QRectF(0,0,1100,pageheight))
            painter.translate(0,-offset)
            doc.drawContents(painter)
            painter.restore()
            offset+=pageheight
            if offset<doc.size().height():
                writer.newPage()
        for image,caption in material:
            writer.newPage()
            painter.setPen(QColor("black"))
            painter.setFont(QFont("Microsoft YaHei",13))
            painter.drawText(QRectF(0,0,width,height*.14),int(Qt.TextFlag.TextWordWrap),str(caption))
            ratio=min(width/max(1,image.width()),height*.8/max(1,image.height()))
            painter.drawImage(QRectF(0,height*.16,image.width()*ratio,image.height()*ratio),image)
        painter.end()
        del writer
    elif path.suffix.lower()==".png":
        fullheight=math.ceil(doc.size().height())+len(material)*820+40
        factor=min(1,math.sqrt(16_000_000/max(1,1200*fullheight)))
        result=QImage(max(1,int(1200*factor)),max(1,int(fullheight*factor)),QImage.Format.Format_RGB32)
        result.fill(QColor("white"))
        painter=QPainter(result)
        painter.scale(factor,factor)
        painter.translate(40,20)
        doc.drawContents(painter)
        y=doc.size().height()+20
        painter.setPen(QColor("black"))
        painter.setFont(QFont("Microsoft YaHei",13))
        for image,caption in material:
            painter.drawText(QRectF(0,y,1100,100),int(Qt.TextFlag.TextWordWrap),str(caption))
            ratio=min(1100/max(1,image.width()),700/max(1,image.height()))
            painter.drawImage(QRectF(0,y+105,image.width()*ratio,image.height()*ratio),image)
            y+=820
        painter.end()
        if not result.save(str(path),"PNG"):
            raise OSError("长图保存失败")
    else:
        raise ValueError("导出支持 PDF 或 PNG")
    if not path.exists() or path.stat().st_size==0:
        raise OSError("讲题导出没有生成有效文件")
