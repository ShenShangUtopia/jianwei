"""少量逐题设计的结构图；每题按内容画，不按学科批量套流程框。"""


def cell_question(q):
    from .reviewed import matches
    if not matches(q):
        return None
    ident=q["id"]
    layers=[]
    if ident=="b-2023-b-01":
        layers=[dict(id="ribosome",type="organelle",kind="ribosome",x=60,y=140,w=260,h=220,color="c1",label="核糖体：蛋白质合成场所"),dict(id="er",type="organelle",kind="rough_er",x=450,y=140,w=420,h=260,color="c3",label="粗面内质网及附着核糖体")]
    elif ident=="b-2023-b-02":
        layers=[dict(id="chloroplast",type="organelle",kind="chloroplast",x=50,y=160,w=400,h=230,color="c3",label="叶绿体：类囊体薄膜与基质"),dict(id="mitochondrion",type="organelle",kind="mitochondrion",x=530,y=160,w=400,h=230,color="c2",label="线粒体：内膜折叠形成嵴"),dict(id="site",type="text",x=60,y=450,w=870,h=100,text="光合色素分布在类囊体薄膜上；有氧呼吸第三阶段的场所是线粒体内膜。")]
    elif ident=="b-2024-b-06":
        for i,(kind,label) in enumerate((("ribosome","核糖体：合成"),("rough_er","内质网：加工"),("golgi","高尔基体：进一步加工和分拣"))):
            layers.append(dict(id=kind,type="organelle",kind=kind,x=50+i*310,y=180,w=250,h=240,color=f"c{i+1}",label=label))
            if i<2:
                layers.append(dict(id="arrow"+str(i),type="arrow",x=300+i*310,y=300,x2=350+i*310,y2=300,color="accent"))
    elif ident=="b-2025-b-01":
        layers=[dict(id="membrane",type="organelle",kind="membrane",x=100,y=120,w=800,h=340,color="c1",label="磷脂双分子层与膜蛋白"),dict(id="diffusion",type="arrow",x=300,y=160,x2=300,y2=420,color="c3"),dict(id="note",type="text",x=100,y=475,w=800,h=80,text="甘油、CO₂可通过自由扩散跨膜；自由扩散不需要载体蛋白，也不消耗ATP。")]
    if not layers:
        return None
    layers.append(dict(id="source",type="text",x=30,y=15,w=940,h=70,text=q["title"],color="accent"))
    ids=[l["id"] for l in layers]
    stages=[dict(say=step,show=ids,highlight=[ids[i%max(1,len(ids)-1)]]) for i,step in enumerate(q.get("steps") or [q["title"]])]
    return dict(v=1,title=q["title"],subject=q["subject"],specific=True,layers=layers,steps=stages)
