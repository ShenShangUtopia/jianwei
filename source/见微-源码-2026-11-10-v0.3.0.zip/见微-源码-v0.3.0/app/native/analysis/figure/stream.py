"""只取已经完整到达的 JSON 图元，不补造未闭合的字符串/对象。"""
import json
import re
from .schema import validate, FigureError


def without_figure(text):
    start=re.search(r'"figure"\s*:\s*',text)
    if not start:
        return text
    try:
        _value,end=json.JSONDecoder().raw_decode(text,start.end())
        return text[:start.start()]+text[end:]
    except (ValueError,RecursionError):
        return text[:start.start()]


def peek_figure(text):
    if not isinstance(text,str) or len(text)>200000:
        return None
    start = re.search(r'"figure"\s*:\s*\{',text)
    if not start:
        return None
    body = text[start.end()-1:]
    decoder = json.JSONDecoder()
    try:
        value,_ = decoder.raw_decode(body)
        return validate(value)
    except (ValueError,FigureError,RecursionError):
        pass
    match = re.search(r'"layers"\s*:\s*\[',body)
    if not match:
        return None
    i = match.end()
    layers = []
    while i<len(body) and len(layers)<192:
        while i<len(body) and body[i] in " \r\n\t,":
            i+=1
        try:
            layer,n = decoder.raw_decode(body,i)
        except (ValueError,RecursionError):
            break
        if not isinstance(layer,dict):
            break
        layers.append(layer)
        i=n
    if not layers:
        return None
    value=dict(v=1,title="读题中的图解 · 尚未核对",layers=layers,steps=[dict(say="图元正在逐步到达，数值随后由程序核对",show=[l.get("id") for l in layers],highlight=[])])
    try:
        return validate(value)
    except FigureError:
        return None
