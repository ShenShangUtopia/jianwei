"""从原题抽取条件/问题，不伪造求解结论。"""
import re


def from_problem(problem, subject="", steps=None, knowns=None):
    text = str(problem or "请补充题干")[:6000]
    pieces = [s.strip() for s in re.split(r"[。；;\n]",text) if s.strip()]
    pieces = pieces[:8] or [text[:200]]
    inputs = [str(x)[:180] for x in (knowns or [])[:8]] or pieces
    layers = [dict(id="context",type="text",x=40,y=45,w=920,h=76,text="题干条件与关系",color="accent"),
              dict(id="notice",type="text",x=40,y=575,w=920,h=50,text="这是从题干整理的，未经 AI 分析；不代表已完成证明或求解。",color="warn")]
    labels = []
    for i, line in enumerate(inputs):
        lid = f"condition{i}"
        labels.append(lid)
        layers.append(dict(id=lid,type="rect",x=45+(i%2)*470,y=140+(i//2)*102,w=440,h=86,text=line,color="c1",source="problem"))
    stages = []
    for i, line in enumerate((steps or [])[:40]):
        stages.append(dict(say=str(line),show=["context","notice"]+labels,highlight=[labels[i%len(labels)]]))
    if not stages:
        stages=[dict(say="先逐条核对题干中的已知条件",show=["context","notice"]+labels,highlight=labels)]
    return dict(v=1,title="题干关系整理",subject=str(subject),layers=layers,steps=stages)
