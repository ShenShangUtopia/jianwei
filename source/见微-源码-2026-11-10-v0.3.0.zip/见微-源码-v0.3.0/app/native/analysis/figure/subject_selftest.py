"""各学科原生图元与32道题的离线录制数据回归。"""
import json
import sys
from collections import defaultdict
from pathlib import Path
from ...kit import test_runtime

test_runtime.configure()


def main(output=None):
    test_runtime.application()
    from ...design import tokens
    from .bank_figures import for_question
    from .view import FigureView
    from .schema import validate,TYPES
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    questions=json.loads((Path(__file__).parents[2]/"bank/questions.json").read_text(encoding="utf-8"))
    selected=[]
    counts=defaultdict(int)
    for q in questions:
        if counts[q["subject"]]<4:
            selected.append(q)
            counts[q["subject"]]+=1
    assert len(selected)==32
    from .curated_stem import IDS
    for q in questions:
        if q["id"] in {*IDS,"b-2023-b-01","b-2023-b-02","b-2024-b-06","b-2025-b-01"} and q not in selected:
            selected.append(q)
    records=[]
    for q in selected:
        figure=for_question(q)
        validate(figure)
        from .. import lesson
        response=dict(subject=q["subject"],topic=q["title"],module=None,summary=q["title"],knowns=[],steps=q.get("steps") or [q["title"]],answer=q["answer"],figure=figure)
        class RecordedReply:
            name="recorded-fixture"
            def ask(self,messages,**kwargs):
                return json.dumps(response,ensure_ascii=False),False
        analyzed=lesson.analyze(q["stem"],RecordedReply())
        assert analyzed["figure"]["v"]==1 and analyzed["answer"]==q["answer"]
        for theme in ("day","night"):
            tokens.set_theme(theme)
            view=FigureView(figure)
            view.resize(1000,760)
            view.show()
            for k in range(len(view.stages)):
                view.go(k)
                image=view.image()
                assert not image.isNull()
            image.save(str(out/(q["id"]+"-"+theme+".png")))
            view.close()
        records.append(dict(id=q["id"],subject=q["subject"],stem=q["stem"],answer=q["answer"],figure=figure))
    for kind in sorted(TYPES):
        layer=dict(id="one",type=kind,x=100,y=120,w=400,h=300,points=[[160,180],[300,180],[200,380]],items=["条件","关系","结论"],rows=[["量","来源"]],labels=["F"],text="原生示意",color="c1")
        if kind=="function":
            layer.update(expr="sin(x)",range=[-5,5,-2,2])
        if kind=="pedigree":
            layer["items"]=[dict(id="I-1",sex="male",affected=False),dict(id="I-2",sex="female",affected=True),dict(id="II-1",sex="male",affected=None,parents=["I-1","I-2"])]
        view=FigureView(dict(v=1,layers=[layer],steps=[dict(say="示意",show=["one"],highlight=[])]))
        assert not view.image().isNull(),kind
        view.close()
    (out/"recorded-fixtures.json").write_text(json.dumps(records,ensure_ascii=False),encoding="utf-8")
    print("FIGURE_PHASE3 OK",len(selected),"questions",len(TYPES),"primitives",flush=True)
    return 0


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
