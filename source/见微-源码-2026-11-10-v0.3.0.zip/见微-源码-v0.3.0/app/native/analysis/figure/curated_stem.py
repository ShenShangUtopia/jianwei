"""原来使用flow骨架的逐题补图。常数来自列出的题干，派生量在此计算。"""
import math

IDS={"m-2023-b-04","m-2024-b-01","m-2023-b-08","m-2023-b-10","m-2024-b-09","m-2025-b-02","m-2025-b-07","m-2025-b-10","m-2026-nh1-02","p-2023-b-02","p-2024-b-02","p-2025-b-05","p-2025-b-07","c-2025-b-23","c-2024-b-20","c-2023-b-22","b-2024-xkb-06","b-2023-b-06","b-2025-b-05"}


def for_question(q):
    if q["id"] not in IDS:
        return None
    from .reviewed import matches
    if not matches(q):
        return None
    layers=[]
    def add(type_,**kw):
        lid="part"+str(len(layers))
        layers.append(dict(id=lid,type=type_,**kw))
        return lid
    def text(value,x,y,w=400,h=65,color="fg"):
        return add("text",text=value,x=x,y=y,w=w,h=h,color=color,source="program")
    def line(x,y,x2,y2,color="muted",kind="line"):
        return add(kind,x=x,y=y,x2=x2,y2=y2,color=color)
    text(q["title"],30,20,940,60,"accent")
    ident=q["id"]
    def plot(exprs,xr,yr,marks=(),equal=False,box=(100,135,800,360),xlabel="x",ylabel="y"):
        x,y,w,h=box
        if equal:
            scale=min(w/(xr[1]-xr[0]),h/(yr[1]-yr[0]))
            ww,hh=scale*(xr[1]-xr[0]),scale*(yr[1]-yr[0])
            x+=(w-ww)/2
            y+=(h-hh)/2
            w,h=ww,hh
        def coord(u,v):
            return (x+(u-xr[0])/(xr[1]-xr[0])*w,y+(yr[1]-v)/(yr[1]-yr[0])*h)
        if yr[0]<=0<=yr[1]:
            a,b=coord(xr[0],0),coord(xr[1],0)
            line(*a,*b)
            text(xlabel,b[0]-50,b[1]+5,80,30,"muted")
        if xr[0]<=0<=xr[1]:
            a,b=coord(0,yr[0]),coord(0,yr[1])
            line(*a,*b)
            text(ylabel,b[0]+8,b[1],70,30,"muted")
        for i,expr in enumerate(exprs):
            add("function",expr=expr,range=[*xr,*yr],x=x,y=y,w=w,h=h,color=f"c{i+1}")
        for u,v,label in marks:
            xx,yy=coord(u,v)
            add("point",x=xx,y=yy,r=5,color="c2")
            text(label,xx+8,yy-40,240,40,"c2")
        return coord
    if ident=="m-2023-b-04":
        plot(["2*sin(2*x+pi/6)"],[0,math.pi/2],[-1.3,2.4],[(0,1,"f(0)=1"),(math.pi/6,2,"最大值 2"),(math.pi/2,-1,"最小值 −1")])
        text("只考察题给区间 [0,π/2]；端点不能漏。",80,555,840)
    elif ident=="m-2024-b-01":
        plot(["x^3-3*x^2+2"],[-1,3],[-3,3],[(0,2,"极大值 2"),(2,-2,"极小值 −2")])
        text("f′(x)=3x(x−2)，变号点为0和2。",80,555,840)
    elif ident=="m-2023-b-08":
        plot(["x*ln(x)","2*x-e"],[.1,4.2],[-1,6],[(math.e,math.e,"(e,e)，切线斜率2")])
        text("蓝色：原曲线；橙色：y=2x−e，接触点和斜率都需满足。",80,555,840)
    elif ident=="m-2023-b-10":
        coord=plot(["sqrt(4-(x-1)^2)","-sqrt(4-(x-1)^2)","x+1"],[-2,4],[-2.5,3.5],[(-1,0,"交点 (−1,0)"),(1,2,"交点 (1,2)")],True)
        line(*coord(-1,0),*coord(1,2),"accent")
        text(f"弦长 = √[(1+1)²+(2−0)²] = {math.sqrt(8):.4g} = 2√2。",80,555,840)
    elif ident=="m-2024-b-09":
        coord=plot(["sqrt(2*(1-x^2/8))","-sqrt(2*(1-x^2/8))"],[-3.5,3.5],[-2,2],[(2,1,"题给点 (2,1)"),(-math.sqrt(6),0,"F₁"),(math.sqrt(6),0,"F₂")],True)
        text("b²=a²(1−e²)=a²/4，代入(2,1)得a²=8、b²=2；焦距2√6。",60,555,900)
    elif ident=="m-2025-b-02":
        coord=plot(["sqrt(3*x^2-12)","-sqrt(3*x^2-12)"],[-6,6],[-6,6],[(-4,0,"F₁"),(4,0,"F₂"),(3,math.sqrt(15),"P(3,√15)")],True)
        for focus in (-4,4):
            line(*coord(focus,0),*coord(3,math.sqrt(15)),"c3")
        text("右支距离差为2a=4；PF₁=8、PF₂=4、F₁F₂=8，周长20。",60,555,900)
    elif ident=="m-2025-b-07":
        plot(["2+sqrt(4-x^2)","2-sqrt(4-x^2)"],[-3,3],[-1,5],[(0,2,"圆心 (0,2)"),(0,0,"曲线经过极点")],True)
        text("ρ²=4ρsinθ ⇒ x²+y²=4y ⇒ x²+(y−2)²=4。",80,555,840)
    elif ident=="m-2025-b-10":
        coord=plot(["sqrt(4*x)","-sqrt(4*x)"],[-2,6],[-5,5],[(1,0,"焦点F(1,0)"),(4,4,"P(4,4)")],True)
        line(*coord(-1,-5),*coord(-1,5),"c3")
        line(*coord(1,0),*coord(4,4),"c2")
        text("准线 x=−1；PF=√[(4−1)²+4²]=5，等于P到准线的距离。",60,555,900)
    elif ident=="m-2026-nh1-02":
        coord=plot([],[-1,2],[-2,1],[(1,-1,"z=1−i")],True,xlabel="Re",ylabel="Im")
        line(*coord(0,0),*coord(1,-1),"c1","arrow")
        text("z=2/(1+i)=1−i，复平面中到原点距离 |z|=√2。",60,555,900)
    elif ident=="p-2023-b-02":
        coord=plot(["max(20-5*x,0)"],[0,6],[0,22],[(4,0,"4 s停止"),(6,0,"6 s仍静止")],xlabel="t / s",ylabel="v / (m/s)")
        add("region",points=[list(coord(0,0)),list(coord(0,20)),list(coord(4,0))],color="c3")
        text("位移是v–t图的面积：½×20×4=40 m；不能把匀减速公式延续到倒车。",60,555,900)
    elif ident=="p-2024-b-02":
        add("rect",x=260,y=140,w=300,h=350,color="muted")
        add("forces",x=340,y=240,w=120,h=120,points=[[400,145],[400,430]],labels=["N=600 N","G=500 N"],color="c1")
        line(630,390,630,210,"c3","arrow")
        text("a=2 m/s² 向上",650,260,250)
        text("N−mg=ma ⇒ N=50×(10+2)=600 N；体重计读支持力，不是重力。",60,555,900)
    elif ident=="p-2025-b-05":
        for xx in (150,850):
            line(xx,180,xx,450)
        for yy in (300,450):
            line(150,yy,566.7,yy)
            line(633.3,yy,850,yy)
        for xx1,xx2 in ((150,266.7),(333.3,466.7),(533.3,850)):
            line(xx1,180,xx2,180)
        for kind,cx,cy,label in (("bat",300,180,"E=6V"),("res",500,180,"r=0.5Ω"),("res",600,300,"R₁=6Ω"),("res",600,450,"R₂=3Ω")):
            add("circuit",kind=kind,x=cx-40,y=cy-40,w=80,h=80,label=label,color="c1")
        total=6/(.5+1/(1/6+1/3))
        u=6-total*.5
        text(f"并联等效R=2Ω；U={u:g}V，I₁={u/6:g}A，I₂={u/3:g}A。",80,555,840)
    elif ident=="p-2025-b-07":
        for a,b in ((140,250),(275,325),(350,460)):
            line(200,a,200,b,"c1")
        line(520,140,520,480,"c2")
        for sy in (262,338):
            for endy in (230,310,390):
                line(200,sy,520,endy,"muted")
        plot(["cos(pi*x/2)^2"],[-4.5,4.5],[-.1,1.15],[(0,1,"亮纹"),(2,1,"下一亮纹")],box=(610,160,330,310),xlabel="屏上x/mm",ylabel="相对光强")
        text("几何位置仅示意；光强图按Δx=λL/d=2.0 mm计算，不计单缝衍射包络。",50,555,900)
    elif ident=="c-2024-b-20":
        for i,(description,delta,col) in enumerate((("体积偏小：c偏高",9,"c2"),("100 mL刻度",0,"c3"),("体积偏大：c偏低",-9,"c1"))):
            x=90+i*310
            add("apparatus",kind="volumetric",x=x,y=170,w=180,h=310,color=col)
            line(x+65,205,x+115,205,"muted")
            line(x+65,205+delta,x+115,205+delta,col)
            text(description,x-10,110,260,55,col)
        text("俯视刻度线时实际液面低于刻度，V偏小，c=n/V偏高；液面/刻度位置为示意。",50,555,900)
    elif ident=="c-2023-b-22":
        for x,label in ((80,"盐酸 pH=2；相同体积V"),(680,"NaOH pH=12；相同体积V")):
            add("apparatus",kind="beaker",x=x,y=180,w=240,h=250,color="c1" if x==80 else "c2")
            text(label,x-20,110,290)
        add("apparatus",kind="beaker",x=410,y=360,w=180,h=220,color="c3")
        line(300,320,435,450,"c1","arrow")
        line(700,320,565,450,"c2","arrow")
        text("[H⁺]=[OH⁻]=0.010 mol/L，等体积恰好中和；常温混合液 pH=7。",60,580,900,55)
    elif ident=="c-2025-b-23":
        add("apparatus",kind="beaker",x=240,y=160,w=520,h=340,color="c1")
        for xx in (360,640):
            line(xx,180,xx,430,"c2")
        text("阴极：生成H₂",240,110,250)
        text("阳极：2Cl⁻→Cl₂+2e⁻",570,110,360)
        for i in range(4):
            add("circle",x=660+i%2*20,y=270-i*32,r=8,color="c3")
        text("NaCl溶液：1 L，0.10 mol/L",320,440,450,55)
        text("按题库的理想放电顺序：n(Cl₂)=0.10/2=0.050 mol；标况V=0.050×22.4=1.12 L。",60,555,900)
    elif ident=="b-2024-xkb-06":
        pts=[]
        for i in range(81):
            t=i/10
            value=.1 if t<1 else .1*math.exp((t-1)*math.log(10)/2) if t<3 else 1 if t<5 else math.exp(-(t-5)*.7)
            pts.append([100+t/8*800,480-value*300])
        add("plot",points=pts,color="c1")
        line(100,480,930,480)
        line(100,480,100,130)
        for x,label in ((150,"I 延滞"),(320,"II 对数"),(500,"III 稳定"),(770,"IV 衰亡")):
            text(label,x,500,160,40)
        text("定性曲线，不代表实测数量。III期增殖与死亡速率相当，并非没有增殖和死亡。",60,565,900)
    elif ident=="b-2023-b-06":
        for x,title,values in ((100,"亲代基因型频率",[.2,.6,.2]),(570,"随机交配后期望频率",[.25,.5,.25])):
            add("bar",x=x,y=180,w=330,h=260,items=values,color="c1" if x==100 else "c3")
            text(title,x,105,360)
            for i,(label,value) in enumerate(zip(("AA","Aa","aa"),values)):
                text(f"{label}\n{value:.0%}",x+i*110,455,95,65)
        text("p(a)=0.20+0.60/2=0.50；子代aa的期望频率=p(a)²=0.25（理想随机交配）。",55,565,910)
    elif ident=="b-2025-b-05":
        add("organelle",kind="chloroplast",x=40,y=180,w=400,h=240,color="c3",label="光照保持适宜：光反应继续")
        for xx,yy,label in ((570,210,"C₅ ↑"),(880,210,"C₃ ↓")):
            add("circle",x=xx,y=yy,r=40,color="c1")
            text(label,xx-45,yy-25,100,50)
        line(610,210,840,210,"c2","arrow")
        text("CO₂降低，固定速率变慢",620,110,300)
        line(880,250,880,390,"c3","arrow")
        line(880,390,570,390,"c3","arrow")
        line(570,390,570,250,"c3","arrow")
        text("还原和C₅再生",650,410,300)
        text("短时间内：C₃生成减少而继续被消耗，C₅消耗减少；ATP和[H]消耗减慢，含量上升。",40,555,920)
    ids=[layer["id"] for layer in layers]
    steps=[dict(say=step,show=ids,highlight=[ids[min(i+1,len(ids)-1)]]) for i,step in enumerate(q.get("steps") or [q["title"]])]
    return dict(v=1,title=q["title"],subject=q["subject"],specific=True,original_flow=True,layers=layers,steps=steps)
