"""学科矢量图元；只画题目指定的数据，不把示意尺寸当计算结果。"""
import math
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QPainterPath, QPolygonF
from ...design.tokens import T, qc


def arrow(p,a,b):
    p.drawLine(a,b)
    angle=math.atan2(b.y()-a.y(),b.x()-a.x())
    for sign in (-1,1):
        p.drawLine(b,b-QPointF(12*math.cos(angle+sign*.5),12*math.sin(angle+sign*.5)))


def punnett(view,p,l,r,col):
    import itertools
    items=l.get("items",[])
    def gametes(text):
        if not isinstance(text,str) or len(text) not in (2,4,6) or not text.isascii() or not text.isalpha():
            return None
        pairs=[text[i:i+2] for i in range(0,len(text),2)]
        if any(pair[0].upper()!=pair[1].upper() for pair in pairs):
            return None
        return sorted(set("".join(p) for p in itertools.product(*pairs)))
    father=gametes(items[0]) if len(items)>=3 else None
    mother=gametes(items[2]) if len(items)>=3 else None
    if not father or not mother:
        view.label(p,"遗传图：请提供可核对的亲本（如 Aa × Aa），复杂遗传请使用程序题型图解。",r,col)
        return
    rows=[["配子"]+father]
    for maternal in mother:
        rows.append([maternal]+["".join("".join(sorted(pair)) for pair in zip(maternal,paternal)) for paternal in father])
    view.draw_layer(p,dict(id="punnett",type="table",x=r.x(),y=r.y(),w=r.width(),h=r.height(),rows=rows),col,0)


def draw(view,p,l,r,col,t):
    kind=l["type"]
    x,y,w,h=r.x(),r.y(),r.width(),r.height()
    center=r.center()
    items=l.get("items",[])
    labels=l.get("labels",[])
    if kind=="organelle":
        model=l.get("kind","mitochondrion")
        if model=="membrane":
            for i in range(16):
                xx=x+(i+.5)*w/16
                for sign in (-1,1):
                    yy=y+h/2+sign*28
                    p.drawEllipse(QPointF(xx,yy),7,7)
                    p.drawLine(QPointF(xx-3,yy-sign*7),QPointF(xx-3,yy-sign*22))
                    p.drawLine(QPointF(xx+3,yy-sign*7),QPointF(xx+3,yy-sign*22))
            p.drawRoundedRect(QRectF(center.x()-13,center.y()-40,26,80),8,8)
        elif model in ("ribosome","rough_er","golgi"):
            if model=="ribosome":
                p.drawEllipse(QRectF(x+w*.2,y+h*.3,w*.6,h*.3))
                p.drawEllipse(QRectF(x+w*.3,y+h*.6,w*.4,h*.15))
            else:
                for i in range(4):
                    path=QPainterPath(QPointF(x+w*.1,y+h*.2+i*h*.17))
                    path.cubicTo(x+w*.3,y+i*h*.17,x+w*.7,y+h*.5+i*h*.1,x+w*.9,y+h*.2+i*h*.17)
                    p.drawPath(path)
                    if model=="rough_er":
                        for j in range(5):
                            p.drawEllipse(QPointF(x+w*(.2+j*.13),y+h*.17+i*h*.17),3,3)
        else:
            p.drawEllipse(r)
            p.drawEllipse(r.adjusted(6,6,-6,-6))
            if model=="chloroplast":
                for i in range(3):
                    for j in range(4):
                        p.drawEllipse(QRectF(x+w*(.16+i*.24),y+h*(.3+j*.1),w*.18,h*.1))
            else:
                path=QPainterPath(QPointF(x+w*.1,y+h*.5))
                for i in range(1,10):
                    path.lineTo(x+w*i*.085,y+h*(.25 if i%2 else .75))
                p.drawPath(path)
    elif kind=="forces":
        p.drawRect(QRectF(center.x()-25,center.y()-25,50,50))
        for i,point in enumerate(l.get("points",[])):
            dest=QPointF(*point)
            arrow(p,center,dest)
            if i<len(labels):
                view.label(p,labels[i],QRectF(dest.x()+6,dest.y()-15,150,32),col)
    elif kind=="circuit":
        from ...lab.benches.circ import ICON
        from ...kit.bench import paint_svg
        paint_svg(p,ICON.get(l.get("kind","res"),ICON["res"]),r)
    elif kind=="apparatus":
        from ...lab.benches.chem_model import prof
        model=l.get("kind","tube")
        profile=prof(model)
        mx=max(v[0] for v in profile)
        mh=max(v[1] for v in profile)
        points=[QPointF(center.x()-a/mx*w*.45,r.bottom()-b/mh*h) for a,b in reversed(profile)]
        points += [QPointF(center.x()+a/mx*w*.45,r.bottom()-b/mh*h) for a,b in profile]
        path=QPainterPath(points[0])
        for point in points[1:]:
            path.lineTo(point)
        p.drawPath(path)
    elif kind in ("ions","structure"):
        n=max(1,len(items))
        positions=[QPointF(x+(i+.5)*w/n,y+h/2) for i in range(n)]
        for i,pos in enumerate(positions):
            if kind=="structure" and i:
                p.drawLine(positions[i-1]+QPointF(30,0),pos-QPointF(30,0))
            p.drawEllipse(pos,28,28)
            view.label(p,items[i] if i<len(items) else "",QRectF(pos.x()-24,pos.y()-24,48,48),col)
    elif kind in ("cell","division"):
        p.drawEllipse(r)
        if kind=="cell":
            if l.get("kind")=="plant":
                p.drawRoundedRect(r.adjusted(-10,-10,10,10),25,25)
            p.drawEllipse(r.adjusted(w*.35,h*.3,-w*.35,-h*.3))
            for i in range(5):
                a=i*math.tau/5
                pos=center+QPointF(math.cos(a)*w*.3,math.sin(a)*h*.3)
                p.drawEllipse(pos,16,9)
        else:
            stage=l.get("kind","metaphase")
            for i in range(4):
                pos=QPointF(center.x()+(i-1.5)*w/8,center.y())
                if stage in ("anaphase","telophase"):
                    for sign in (-1,1):
                        dest=pos+QPointF(0,sign*h*.25)
                        p.drawLine(dest+QPointF(-7,8),dest)
                        p.drawLine(dest+QPointF(7,8),dest)
                else:
                    p.drawLine(pos-QPointF(7,12),pos+QPointF(7,12))
                    p.drawLine(pos-QPointF(7,-12),pos+QPointF(7,-12))
            if stage=="telophase":
                p.drawLine(QPointF(x,center.y()),QPointF(x+w,center.y()))
    elif kind=="pedigree":
        levels={}
        for person in items:
            levels[person["id"]]=max([levels[pid]+1 for pid in person.get("parents",[])]+[0])
        groups={}
        for person in items:
            groups.setdefault(levels[person["id"]],[]).append(person)
        positions={}
        for level,people in groups.items():
            for i,person in enumerate(people):
                positions[person["id"]]=QPointF(x+(i+.5)*w/len(people),y+(level+.5)*h/(max(levels.values())+1))
        for person in items:
            pos=positions[person["id"]]
            parents=[positions[pid] for pid in person.get("parents",[])]
            if parents:
                middle=QPointF(sum(q.x() for q in parents)/len(parents),max(q.y() for q in parents))
                if len(parents)==2:
                    p.drawLine(parents[0],parents[1])
                yy=(middle.y()+pos.y())/2
                p.drawLine(middle,QPointF(middle.x(),yy))
                p.drawLine(QPointF(middle.x(),yy),QPointF(pos.x(),yy))
                p.drawLine(QPointF(pos.x(),yy),pos)
        for person in items:
            pos=positions[person["id"]]
            p.setBrush(qc(col) if person.get("affected") is True else qc(T.stage))
            if person["sex"]=="female":
                p.drawEllipse(pos,18,18)
            elif person["sex"]=="male":
                p.drawRect(QRectF(pos.x()-18,pos.y()-18,36,36))
            else:
                p.drawPolygon(QPolygonF([pos+QPointF(0,-20),pos+QPointF(20,0),pos+QPointF(0,20),pos+QPointF(-20,0)]))
            if person.get("affected") is None:
                view.label(p,"?",QRectF(pos.x()-7,pos.y()-15,16,30),col)
            view.label(p,person["id"],QRectF(pos.x()-30,pos.y()+22,65,30),col)
        p.setBrush(Qt.BrushStyle.NoBrush)
    elif kind=="pyramid":
        n=max(1,min(6,len(items)))
        for i in range(n):
            topw=w*(i+1)/n
            loww=w*(i+2)/n if i<n-1 else w
            yy=y+i*h/n
            pts=[QPointF(center.x()-topw/2,yy),QPointF(center.x()+topw/2,yy),QPointF(center.x()+loww/2,yy+h/n),QPointF(center.x()-loww/2,yy+h/n)]
            p.drawPolygon(QPolygonF(pts))
            if i<len(items):
                view.label(p,items[i],QRectF(center.x()-topw/2+8,yy+2,topw-16,h/n-4),col)
    elif kind=="energy":
        pts=l.get("points",[])
        if pts:
            path=QPainterPath(QPointF(*pts[0]))
            for point in pts[1:]:
                path.lineTo(*point)
            p.drawPath(path)
        arrow(p,QPointF(x,y+h),QPointF(x+w,y+h))
        arrow(p,QPointF(x,y+h),QPointF(x,y))
    elif kind=="solid":
        from ...bank.solid_geom import build, rp
        key=l.get("kind","cube")
        if key not in ("cube","cuboid","prism","pyramid","cylinder","cone","sphere","frustum"):
            key="cube"
        geom=build(key,{**dict(a=2,b=2,h=2,r=1,R=1.5,n=4),**l.get("size",{})})
        angle=t*.25+.45
        def project(v):
            xx=v[0]*math.cos(angle)+v[2]*math.sin(angle)
            zz=-v[0]*math.sin(angle)+v[2]*math.cos(angle)
            return center+QPointF(xx*min(w,h)*.25,(-v[1]+zz*.35)*min(w,h)*.25)
        for face in geom["faces"]:
            names=face["v"]
            for i,name in enumerate(names):
                p.drawLine(project(rp(geom,name)),project(rp(geom,names[(i+1)%len(names)])))
    elif kind=="map":
        # Schematic contours/relationships only, never a claimed geographic boundary.
        if l.get("kind")=="contours":
            for i in range(4):
                p.drawEllipse(r.adjusted(i*w*.08,i*h*.08,-i*w*.08,-i*h*.08))
        for i,point in enumerate(l.get("points",[])):
            pos=QPointF(*point)
            p.drawEllipse(pos,5,5)
            if i<len(labels):
                view.label(p,labels[i],QRectF(pos.x()+8,pos.y()-15,170,40),col)
