"""仅在可复算的明确模型中生成错因对比，不臆测学生的错误过程。"""
import math


def for_lesson(lesson):
    task=next((t for t in lesson.get("taskRes") or [] if (t.get("viz") or {}).get("scene",{}).get("kind")=="incline"),None)
    if not task:
        return None
    p=task["viz"]["scene"]["params"]
    mu=p.get("mu",0)
    if mu<=0:
        return None
    angle=math.radians(p["angle"])
    g=p.get("g",9.8)
    right=g*(math.sin(angle)-mu*math.cos(angle))
    wrong=g*math.sin(angle)
    layers=[]
    for side,x in (("correct",40),("missing",530)):
        cx,cy=x+210,310
        layers.append(dict(id=side+"-slope",type="polygon",points=[[x+40,470],[x+400,470],[x+400,180]],color="muted"))
        points=[[cx,cy+115],[cx-85,cy-80]]
        labels=["重力 G","支持力 N"]
        if side=="correct":
            points.append([cx+90,cy-80])
            labels.append("沿斜面向上的摩擦力 f")
        layers.append(dict(id=side+"-forces",type="forces",x=cx-100,y=cy-100,w=200,h=200,points=points,labels=labels,color="c1" if side=="correct" else "bad"))
        text=(f"完整受力：a=g(sinθ−μcosθ)={right:.4g} m/s²" if side=="correct" else f"遗漏摩擦：错误得到 a=g sinθ={wrong:.4g} m/s²")
        layers.append(dict(id=side+"-label",type="text",x=x,y=60,w=430,h=100,text=text,color="ok" if side=="correct" else "bad",source="program"))
    layers.append(dict(id="notice",type="text",x=40,y=550,w=900,h=70,text="只比较已沿斜面下滑时的动力学方程；不是对学生实际错因的自动判定。斜面图为示意。",color="warn"))
    ids=[l["id"] for l in layers]
    return dict(v=1,title="漏画摩擦力会怎样",subject="物理",layers=layers,steps=[dict(say="同一题的受力图先作对比",show=ids,highlight=["correct-forces","missing-forces"]),dict(say="分叉出现在沿斜面列式：摩擦项不能漏",show=ids,highlight=["correct-label","missing-label"])])
