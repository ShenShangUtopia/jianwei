"""Opt-in allowlisted timing events: no prompts, answers, keys, hashes or URLs."""
import json
import math
import uuid
from ..kit.home import home,load_json


def write(values,force=False):
    if not force:
        config=load_json('config.json',{})
        if not isinstance(config,dict) or config.get('analysisTiming') is not True:
            return False
    event=dict(v=1,id=uuid.uuid4().hex)
    for key in ('first_packet_ms','first_condition_ms','first_native_ms','total_ms'):
        value=values.get(key)
        event[key]=round(value,3) if type(value) in (int,float) and math.isfinite(value) and 0<=value<=86400000 else None
    event['engine']=values.get('engine') if values.get('engine') in ('offline','deepseek') else 'other'
    event['status']=values.get('status') if values.get('status') in ('ok','error','cancelled') else 'error'
    event['schema_repairs']=min(2,max(0,values.get('schema_repairs',0))) if type(values.get('schema_repairs',0)) is int else 0
    folder=home()/'logs'
    folder.mkdir(exist_ok=True)
    path=folder/'analysis-timing.jsonl'
    # One bounded rotation, never copy general logs or user data into the trace.
    if path.exists() and path.stat().st_size>1024*1024:
        previous=folder/'analysis-timing.previous.jsonl'
        previous.unlink(missing_ok=True)
        path.replace(previous)
    with path.open('a',encoding='utf-8') as stream:
        stream.write(json.dumps(event,ensure_ascii=False,allow_nan=False)+'\n')
    return True
