"""讲解脚本：物理题由程序按算出的数一步一步写讲解，每一步说清楚画面停在哪个时刻、讲到哪几个量。

一步（beat）= dict(say=讲解文字, lv=画到第几层 0..2, t=从哪个时刻开始, play_to=播到哪个时刻（None 表示停住）, focus=[讲到的量])
可选：ask=「先想再看」时先问的问题；wrong=True 表示这一步讲常见错误；ghost=错误做法画在仿真上的样子
（世界坐标：path 一串点、at 标注位置、text 标注文字）。
focus 里的名字和仿真图上箭头 / 标注的文字一致（vx、mg、R、T……），画面据此加粗发光，其余变淡。

数全部来自题目参数和程序公式，不经过 AI；AI 的讲解仍在「完整解答」里。
拖动仿真右侧的条件时，页面用当前参数重新调用这里的函数，讲解里的数跟着变。
只写目前有仿真的题型；其他题型返回 None，页面照旧按图解分步。
"""
from __future__ import annotations

import math


def n(x) -> str:
    """讲解里的数：整数就写整数，否则留 6 位有效数字（显示时再约成 3 位并写 ≈）。"""
    if not math.isfinite(x):
        return "—"
    if abs(x - round(x)) < 1e-9 * max(1.0, abs(x)):
        return str(int(round(x)))
    return f"{x:.6g}"


def sgn(x) -> str:
    """代入式子里的负数加括号。"""
    return f"({n(x)})" if x < 0 else n(x)


# ---------------------------------------------------------------- 抛体
def projectile(p):
    v0, ang, h0, g = float(p.get("v0", 0)), float(p.get("angle", 0)), float(p.get("h0", 0)), float(p.get("g", 9.8))
    th = math.radians(ang)
    vx, vy0 = v0 * math.cos(th), v0 * math.sin(th)
    T = (vy0 + math.sqrt(vy0 * vy0 + 2 * g * h0)) / g
    R, H = vx * T, h0 + vy0 * vy0 / (2 * g)
    vye = vy0 - g * T
    ve = math.hypot(vx, vye)
    flat = abs(ang) < 1e-9
    known = f"已知：初速度 v_0 = {n(v0)} m/s" + ("，水平抛出" if flat else f"，与水平方向成 θ = {n(ang)}°") + (f"，离地高度 h_0 = {n(h0)} m" if h0 > 0 else "，从地面抛出") + f"，g = {n(g)} m/s^2。"
    beats = [dict(say=known, lv=0, t=0, focus=["v₀", "h₀", "θ"])]
    if flat:
        beats.append(dict(say=f"把运动拆成两个方向：水平方向不受力，做匀速直线运动，v_x = v_0 = {n(vx)} m/s；竖直方向只受重力，从 v_y = 0 开始做自由落体。",
                          ask="水平方向受不受力？两个方向各做什么运动？", lv=1, t=0, play_to=T * 0.45, focus=["vx", "vy"]))
        beats.append(dict(say=f"竖直方向：h_0 = ½g·T^2，所以 T = sqrt(2h_0/g) = sqrt(2×{n(h0)}/{n(g)}) = {n(T)} s。",
                          ask="落地时间只由哪个方向决定？和初速度有没有关系？", lv=2, t=T * 0.45, play_to=T, focus=["vy", "T"]))
    else:
        beats.append(dict(say=f"把初速度分解：v_x = v_0 cosθ = {n(vx)} m/s，v_y = v_0 sinθ = {n(vy0)} m/s。水平方向匀速，竖直方向是加速度为 g 的匀变速运动。",
                          ask="初速度斜着向上，怎么拆成水平和竖直两个分量？", lv=1, t=0, play_to=T * 0.3, focus=["vx", "vy", "v"]))
        if vy0 > 0:
            tp = vy0 / g
            beats.append(dict(say=f"竖直分速度减到 0 时到最高点：t = v_y/g = {n(tp)} s，最大高度 H = h_0 + v_y^2/(2g) = {n(H)} m。",
                              ask="到最高点时，速度是 0 吗？哪个分量变成了 0？", lv=2, t=T * 0.3, play_to=min(tp, T), focus=["vy", "H"]))
        beats.append(dict(say=f"竖直方向：h_0 + v_y T − ½g·T^2 = 0，解得飞行时间 T = {n(T)} s。", lv=2, t=min(vy0 / g, T) if vy0 > 0 else 0, play_to=T, focus=["T"]))
    beats.append(dict(say=f"水平方向一直匀速：R = v_x T = {n(vx)} × {n(T)} = {n(R)} m。", lv=2, t=T, focus=["R", "vx"]))
    beats.append(dict(say=f"落地速度把两个分量合起来：v_y = {n(vye)} m/s，v = sqrt(v_x^2 + v_y^2) = {n(ve)} m/s。",
                      ask="落地速度能不能把 v_x 和 v_y 直接相加？", lv=2, t=T, focus=["v", "vx", "vy"]))
    # 常见错误
    if flat:
        bad = v0 + g * T
        beats.append(dict(say=f"常见错误：把两个分速度直接相加，v = v_0 + gT = {n(bad)} m/s。速度是矢量，两个分量互相垂直，要用勾股定理合成，正确是 {n(ve)} m/s。",
                          wrong=True, lv=2, t=T, focus=["v", "vx", "vy"]))
    elif vy0 > 0 and h0 < 1e-9:
        tp = vy0 / g
        Rw = vx * tp
        beats.append(dict(say=f"常见错误：飞行时间只算了上升段 t = v_y/g = {n(tp)} s，于是 R = v_x t = {n(Rw)} m，只有正确射程的一半。上升和下落各用 {n(tp)} s，T = 2v_y/g = {n(T)} s。",
                          wrong=True, lv=2, t=tp, focus=["R", "T"],
                          ghost=dict(path=[(Rw, H), (Rw, 0)], at=(Rw, 0), text=f"错：R = {n(round(Rw, 2))} m")))
    else:
        Rw = v0 * T
        beats.append(dict(say=f"常见错误：水平位移用了 v_0 而不是 v_x，R = v_0 T = {n(Rw)} m。水平方向只有分量 v_x = v_0 cosθ 在起作用，正确是 {n(R)} m。",
                          wrong=True, lv=2, t=T, focus=["R", "vx"]))
    return beats


# ---------------------------------------------------------------- 斜面
def incline(p):
    ang, mu, m, L, g = float(p.get("angle", 30)), float(p.get("mu", 0)), float(p.get("m", 1)), float(p.get("L", 1)), float(p.get("g", 9.8))
    th = math.radians(ang)
    s, c = math.sin(th), math.cos(th)
    N = m * g * c
    a_raw = g * (s - mu * c)
    beats = [dict(say=f"先画受力：重力 mg = {n(m * g)} N 竖直向下，支持力 N 垂直斜面向上" + ("，摩擦力 f 沿斜面向上（阻碍下滑）。" if mu > 0 else "；斜面光滑，没有摩擦力。"),
                  ask="物块受哪几个力？各朝哪个方向？", lv=1, t=0, focus=["mg", "N", "f"])]
    if a_raw <= 1e-9:
        beats.append(dict(say=f"比较 μ = {n(mu)} 和 tanθ = {n(s / c)}：μ ≥ tanθ，最大静摩擦力挡得住下滑分力，物块保持静止，f = mg sinθ = {n(m * g * s)} N。",
                          ask="物块会不会滑下去？要比较哪两个数？", lv=1, t=0, focus=["f", "mg"]))
        beats.append(dict(say=f"常见错误：静止时还用 f = μN = {n(mu * N)} N 算摩擦力。μN 是滑动摩擦力（也近似最大静摩擦力），物块静止时摩擦力和下滑分力平衡，f = mg sinθ = {n(m * g * s)} N。",
                          wrong=True, lv=1, t=0, focus=["f"]))
        return beats
    f = mu * N
    T = math.sqrt(2 * L / a_raw)
    beats.append(dict(say=f"垂直斜面方向受力平衡：N = mg cosθ = {n(N)} N" + (f"，滑动摩擦力 f = μN = {n(mu)} × {n(N)} = {n(f)} N。" if mu > 0 else "。"),
                      ask="支持力 N 等于 mg 吗？", lv=1, t=0, focus=["N", "f"]))
    beats.append(dict(say=f"沿斜面方向用牛顿第二定律：mg sinθ − f = ma，所以 a = g(sinθ − μcosθ) = {n(a_raw)} m/s^2。",
                      ask="沿斜面方向，合力是哪两个力的差？", lv=2, t=0, focus=["F合", "a"]))
    beats.append(dict(say=f"从静止开始匀加速滑完 L = {n(L)} m：L = ½a·t^2，t = sqrt(2L/a) = {n(T)} s。", lv=2, t=0, play_to=T, focus=["L", "t"]))
    beats.append(dict(say=f"到底端的速度：v = a·t = {n(a_raw)} × {n(T)} = {n(a_raw * T)} m/s。", lv=2, t=T, focus=["v"]))
    if mu > 0 and abs(c - 1) > 1e-6:
        aw = g * (s - mu)
        if aw > 1e-9:
            dw = min(0.5 * aw * T * T, L)
            Tw = math.sqrt(2 * L / aw)
            beats.append(dict(say=f"常见错误：把支持力当成 N = mg，f = μmg = {n(mu * m * g)} N，得 a = {n(aw)} m/s^2、t = {n(Tw)} s。按这个加速度，{n(T)} s 时物块只滑到虚线处。N 要乘 cosθ，正确是 a = {n(a_raw)} m/s^2。",
                              wrong=True, lv=2, t=T, focus=["N", "f", "a"],
                              ghost=dict(path=[(0, L * s), (dw * c, (L - dw) * s)], at=(dw * c, (L - dw) * s), text="错：只滑到这里")))
        else:
            beats.append(dict(say=f"常见错误：把支持力当成 N = mg，f = μmg = {n(mu * m * g)} N，会以为物块滑不动。N 要乘 cosθ，正确是 a = {n(a_raw)} m/s^2。",
                              wrong=True, lv=2, t=T, focus=["N", "f"]))
    else:
        beats.append(dict(say=f"常见错误：以为下滑加速度就是 g。只有沿斜面的分力 mg sinθ 让物块加速，a = g sinθ = {n(a_raw)} m/s^2，比 g 小。",
                          wrong=True, lv=2, t=T, focus=["a", "mg"]))
    return beats


# ---------------------------------------------------------------- 一维碰撞
X1, X2 = -2.2, 2.2   # 和 ph_scenes2.Collision 一致：两球起点


def _collide_time(m1, m2, v1, v2):
    r1, r2 = 0.16 + 0.05 * m1, 0.16 + 0.05 * m2
    return (X2 - r2 - (X1 + r1)) / (v1 - v2) if v1 > v2 else math.inf


def collision(p):
    m1, m2, v1, v2 = float(p.get("m1", 1)), float(p.get("m2", 1)), float(p.get("v1", 0)), float(p.get("v2", 0))
    e = float(p.get("e", 1))
    if v1 <= v2:
        return [dict(say=f"v_1 = {n(v1)} m/s 不大于 v_2 = {n(v2)} m/s（向右为正），两球追不上，不会相碰。", lv=0, t=0, play_to=2.4, focus=["v₁", "v₂"])]
    tc = _collide_time(m1, m2, v1, v2)
    end = min(4, tc + 1.1)
    a = ((m1 - e * m2) * v1 + (1 + e) * m2 * v2) / (m1 + m2)
    b = ((m2 - e * m1) * v2 + (1 + e) * m1 * v1) / (m1 + m2)
    p0 = m1 * v1 + m2 * v2
    E0, E1 = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2, 0.5 * m1 * a * a + 0.5 * m2 * b * b
    kind = "弹性碰撞" if abs(e - 1) < 1e-9 else "完全非弹性碰撞" if abs(e) < 1e-9 else f"非弹性碰撞（恢复系数 e = {n(e)}）"
    dir2 = "向左" if v2 < 0 else "静止" if v2 == 0 else "向右"
    beats = [dict(say=f"规定向右为正。m_1 = {n(m1)} kg 以 v_1 = {n(v1)} m/s 向右，m_2 = {n(m2)} kg " + (f"以 {n(abs(v2))} m/s {dir2}（v_2 = {n(v2)} m/s）" if v2 else "静止") + f"，两球发生{kind}。",
                  lv=0, t=0, focus=["v₁", "v₂", "m₁", "m₂"])]
    beats.append(dict(say=f"两球组成的系统在水平方向不受外力，动量守恒：p = m_1v_1 + m_2v_2 = {n(m1)}×{n(v1)} + {n(m2)}×{sgn(v2)} = {n(p0)} kg·m/s。",
                      ask="碰撞前后，哪个量一定不变？速度为负时代入要注意什么？", lv=1, t=0, play_to=tc, focus=["v₁", "v₂", "p"]))
    if abs(e - 1) < 1e-9:
        how = f"弹性碰撞动能也守恒。联立 m_1v_1 + m_2v_2 = m_1v_1′ + m_2v_2′ 和动能守恒，解得 v_1′ = {n(a)} m/s，v_2′ = {n(b)} m/s。"
    elif abs(e) < 1e-9:
        how = f"完全非弹性碰撞后两球粘在一起共速：v′ = p/(m_1 + m_2) = {n(p0)}/{n(m1 + m2)} = {n(a)} m/s。"
    else:
        how = f"恢复系数 e 表示分离速度是接近速度的几倍：v_2′ − v_1′ = e(v_1 − v_2)。和动量守恒联立，解得 v_1′ = {n(a)} m/s，v_2′ = {n(b)} m/s。"
    beats.append(dict(say=how, ask="除了动量守恒，还需要哪个条件才能解出两个未知速度？", lv=2, t=tc, focus=["v₁", "v₂"]))

    def way(v):
        return "向左弹回" if v < -1e-9 else "停下" if abs(v) <= 1e-9 else "继续向右"
    if abs(e) < 1e-9:
        after =f"碰后两球一起{('以 ' + n(abs(a)) + ' m/s ' + ('向右' if a > 0 else '向左') + '运动') if abs(a) > 1e-9 else '停下'}。"
    else:
        after = f"看符号判断方向：v_1′ = {n(a)} m/s，m_1 {way(a)}；v_2′ = {n(b)} m/s，m_2 {way(b)}。"
    beats.append(dict(say=after, ask="碰后两球各往哪边走？", lv=2, t=tc, play_to=end, focus=["v₁", "v₂"]))
    if E0 - E1 > 1e-9 * max(1, E0):
        beats.append(dict(say=f"算动能：碰前 E_k = {n(E0)} J，碰后 E_k′ = {n(E1)} J，损失 ΔE = {n(E0 - E1)} J，转化成了内能。", lv=2, t=end, focus=["ΔE"]))
    else:
        beats.append(dict(say=f"核对动能：碰前 {n(E0)} J，碰后 {n(E1)} J，弹性碰撞没有损失。", lv=2, t=end, focus=["ΔE"]))
    if v2 < 0:
        pw = m1 * v1 + m2 * abs(v2)
        beats.append(dict(say=f"常见错误：忘了 v_2 向左要取负，把动量写成 {n(m1)}×{n(v1)} + {n(m2)}×{n(abs(v2))} = {n(pw)} kg·m/s。正确是 {n(p0)} kg·m/s，后面的速度也就全错了。",
                          wrong=True, lv=2, t=end, focus=["p", "v₂"]))
    elif e < 1 - 1e-9:
        beats.append(dict(say=f"常见错误：看到碰撞就用动能守恒。只有弹性碰撞动能才守恒，这里动能少了 {n(E0 - E1)} J，只能用动量守恒加题目给的碰撞条件。",
                          wrong=True, lv=2, t=end, focus=["ΔE"]))
    else:
        beats.append(dict(say=f"常见错误：以为弹性碰撞后两球「交换速度」。只有质量相等才交换，这里 m_1 = {n(m1)} kg、m_2 = {n(m2)} kg，碰后是 {n(a)} m/s 和 {n(b)} m/s。",
                          wrong=True, lv=2, t=end, focus=["v₁", "v₂"]))
    return beats


# ---------------------------------------------------------------- 闭合电路
def circuit(p):
    E, r, R1, R2 = float(p.get("E", 6)), float(p.get("r", 0)), float(p.get("R1", 1)), float(p.get("R2", 0))
    R3 = float(p.get("R3") or 0)
    par = p.get("mode") == "parallel" and R2 > 0
    Rp = R1 * R2 / (R1 + R2) if par else R1 + R2
    Rex = Rp + R3
    I = E / (Rex + r)
    U = E - I * r
    Up = I * Rp
    link = "并联" if par else "串联"
    known = f"已知：电动势 E = {n(E)} V，内阻 r = {n(r)} Ω，" + (f"R_1 = {n(R1)} Ω 与 R_2 = {n(R2)} Ω {link}" if R2 > 0 else f"外电阻 R_1 = {n(R1)} Ω") + (f"，干路再串 R_3 = {n(R3)} Ω" if R3 > 0 else "") + "。"
    beats = [dict(say=known, lv=1, t=0, focus=[])]
    if par:
        ext = f"先算外电阻：并联部分 R_并 = R_1R_2/(R_1 + R_2) = {n(R1)}×{n(R2)}/{n(R1 + R2)} = {n(Rp)} Ω" + (f"，再加 R_3，R_外 = {n(Rex)} Ω。" if R3 > 0 else "。")
    elif R2 > 0:
        ext = f"先算外电阻：串联直接相加，R_外 = R_1 + R_2" + (" + R_3" if R3 > 0 else "") + f" = {n(Rex)} Ω。"
    else:
        ext = f"外电阻 R_外 = {n(Rex)} Ω。"
    beats.append(dict(say=ext, ask="外电路的总电阻是多少？" + ("并联电阻能直接相加吗？" if par else ""), lv=1, t=0, focus=[]))
    beats.append(dict(say=f"闭合电路欧姆定律：I = E/(R_外 + r) = {n(E)}/({n(Rex)} + {n(r)}) = {n(I)} A。电流从正极出发，流过外电路回到负极。",
                      ask="干路电流怎么求？内阻要不要算进去？", lv=1, t=0, play_to=3, focus=[]))
    beats.append(dict(say=f"路端电压：U = E − Ir = {n(E)} − {n(I)}×{n(r)} = {n(U)} V，内阻上分去了 Ir = {n(I * r)} V。", lv=2, t=3, focus=[]))
    if par:
        beats.append(dict(say=f"并联部分两端电压 U_并 = I·R_并 = {n(Up)} V，各支路：I_1 = U_并/R_1 = {n(Up / R1)} A，I_2 = U_并/R_2 = {n(Up / R2)} A，加起来等于干路电流。", lv=2, t=3, focus=[]))
    elif R2 > 0:
        beats.append(dict(say=f"串联电流处处相等：U_1 = IR_1 = {n(I * R1)} V，U_2 = IR_2 = {n(I * R2)} V。", lv=2, t=3, focus=[]))
    beats.append(dict(say=f"功率：电源总功率 P_总 = EI = {n(E * I)} W，输出功率 P_出 = UI = {n(U * I)} W，效率 η = U/E = {n(round(U / E * 100, 2))}%。", lv=2, t=3, focus=[]))
    if r > 0:
        Iw = E / Rex
        beats.append(dict(say=f"常见错误：忘了内阻，I = E/R_外 = {n(Iw)} A，比正确的 {n(I)} A 大。电源内部也有电阻，路端电压也就不等于电动势。", wrong=True, lv=2, t=3, focus=[]))
    elif par:
        beats.append(dict(say=f"常见错误：并联电阻直接相加，R = R_1 + R_2 = {n(R1 + R2)} Ω。并联后总电阻比任何一个支路都小，正确是 {n(Rp)} Ω。", wrong=True, lv=2, t=3, focus=[]))
    return beats


# ---------------------------------------------------------------- 透镜
def lens(p):
    f, u = float(p.get("f", 1)), float(p.get("u", 1))
    h = float(p.get("h") or 0)
    unit = p.get("unit") or "m"
    beats = [dict(say=f"已知：凸透镜焦距 f = {n(f)} {unit}，物距 u = {n(u)} {unit}" + (f"，物高 h = {n(h)} {unit}" if h else "") + "。", lv=0, t=0, focus=[])]
    if abs(u - f) < 1e-9:
        beats.append(dict(say="物体正好在焦点上：折射光线都平行于主轴，不成像。", lv=1, t=0, focus=[]))
        return beats
    v = u * f / (u - f)
    m = abs(v) / u
    real = v > 0
    if u > 2 * f:
        where = f"u = {n(u)} > 2f = {n(2 * f)}，物体在二倍焦距以外，成倒立、缩小的实像，像在 f 和 2f 之间。"
    elif abs(u - 2 * f) < 1e-9:
        where = f"u = 2f = {n(2 * f)}，成倒立、等大的实像，像也在 2f 处。"
    elif u > f:
        where = f"f < u = {n(u)} < 2f，成倒立、放大的实像，像在 2f 以外。"
    else:
        where = f"u = {n(u)} < f = {n(f)}，物体在焦点以内，成正立、放大的虚像，和物体在透镜同侧。"
    beats.append(dict(say="先比较物距和焦距：" + where, ask="物体在 2f 以外、f 和 2f 之间，还是 f 以内？会成什么样的像？", lv=0, t=0, focus=[]))
    beats.append(dict(say="作图：平行于主轴的光线折射后过焦点 F′，过光心的光线方向不变" + ("，两条折射光线的交点就是像。" if real else "；两条折射光线发散，反向延长线的交点是虚像。"), lv=1, t=0, focus=[]))
    beats.append(dict(say=f"用成像公式：1/f = 1/u + 1/v，1/v = 1/{n(f)} − 1/{n(u)}，v = {n(v)} {unit}" + ("。" if real else "，负号表示虚像，在物体同侧。"),
                      ask="成像公式里 u、v、f 的关系是什么？", lv=2, t=0, focus=[]))
    beats.append(dict(say=f"放大率 |m| = |v|/u = {n(m)}" + (f"，像高 h′ = |m|h = {n(m * h)} {unit}" if h else "") + f"，{'倒立' if real else '正立'}{'放大' if m > 1 + 1e-9 else '缩小' if m < 1 - 1e-9 else '等大'}{'实像' if real else '虚像'}。", lv=2, t=0, focus=[]))
    if abs(u - f) > 1e-9 and abs(f - u) > 1e-12:
        vw = u * f / (f - u)
        beats.append(dict(say=f"常见错误：公式写成 1/f = 1/u − 1/v，算出 v = {n(vw)} {unit}，实像虚像正好反了。凸透镜成像公式是 1/f = 1/u + 1/v（实像 v 取正）。", wrong=True, lv=2, t=0, focus=[]))
    return beats


WRITERS = dict(projectile=projectile, incline=incline, collision=collision, circuit=circuit, lens=lens)
COLORED = {"projectile", "incline", "collision"}   # 步骤文字按量上色的题型（电路、光学的字母含义不同，不上色）


def params_of(sc_dict):
    """viz 里的 scene → 讲解函数要的参数（透镜带上单位换算系数）。"""
    p = dict(sc_dict.get("params") or {})
    if sc_dict.get("kind") == "lens" and sc_dict.get("src"):
        p = dict(sc_dict["src"])   # 场景按米缩放过，讲解用题目原来的数和单位
    return p


def from_scene(kind, sc_dict, now):
    """拖动仿真条件后：场景当前参数 → 讲解函数要的参数。"""
    p = dict(now)
    if kind == "lens":
        k = float(sc_dict.get("k") or 1)
        src = sc_dict.get("src") or {}
        p = dict(f=now.get("f", 1) / k, u=now.get("u", 1) / k, h=(now.get("h", 0) / k) if src.get("h") else 0, unit=src.get("unit", "m"))
    return p


def write(kind, params):
    fn = WRITERS.get(kind)
    if not fn:
        return None
    try:
        return fn(params) or None
    except (TypeError, ValueError, ZeroDivisionError, OverflowError):
        return None


def for_lesson(L):
    """第一个有仿真的程序题型 → (任务下标, 讲解步骤)；没有就 None。"""
    for i, t in enumerate(L.get("taskRes") or []):
        sc = (t.get("viz") or {}).get("scene") or {}
        if sc.get("kind") in WRITERS and not t.get("failed_checks"):
            beats = write(sc["kind"], params_of(sc))
            if beats:
                return i, beats
    return None


def kind_of(L, i):
    return (((L.get("taskRes") or [])[i].get("viz") or {}).get("scene") or {}).get("kind")
