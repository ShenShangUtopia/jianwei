"""题型求解器的公共部分（由 gewu/tasks.js 改写）：注册表、参数校验、行（row）与 claimed 对照。

题目属于某个常见题型时，AI 只把题目里的条件填进参数（task），答案由专门算法算出，再与 AI 的答案（claimed）逐项对照。
参数不合法（函数写错、坐标与题目条件不符、方程式不守恒、概率和不为 1……）时抛 TaskError，问题清单发回给 AI 修正。
"""
from __future__ import annotations

import json
import math
import re

from . import solver as Solver

REG: dict = {}
ORDER: list = []


def reg(tid, subj, title, doc):
    def deco(run):
        REG[tid] = dict(id=tid, subj=subj, title=title, doc=doc, run=run)
        ORDER.append(tid)
        return run
    return deco


class TaskError(Exception):
    def __init__(self, lst):
        super().__init__("；".join(lst))
        self.list = list(lst)


def fail(*m):
    raise TaskError(list(m))


def isf(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def num(v):
    if isinstance(v, bool):
        return math.nan
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str) and v.strip():
        return Solver.eval_const(re.sub(r"%$", "/100", v.strip()))
    return math.nan


def need_num(v, name, cond=lambda _x: True, hint=""):
    x = num(v)
    if not isf(x) or not cond(x):
        fail(f"{name} 必须是{hint or '数'}（收到 {json.dumps(v, ensure_ascii=False)}）")
    return x


def is_int(x):
    return float(x).is_integer()


def fmt_n(v, d=6):
    if not isf(v):
        return "—"
    if abs(v) >= 1e6 or (abs(v) < 1e-4 and v != 0):
        m, e = f"{v:.4e}".split("e")
        return f"{m}×10^{int(e)}"
    return f"{float(f'{v:.{d}g}'):.12g}"


def with_exact(v):
    e = Solver.exact(v)
    return f"{fmt_n(v)}（= {e}）" if e else fmt_n(v)


def fmt_x(x):
    if not isf(x):
        return "+∞" if isinstance(x, (int, float)) and x > 0 else "-∞"
    return Solver.exact(x) or fmt_n(x, 5)


def asks_of(s, allowed):
    asks = s.get("asks")
    if not isinstance(asks, list) or not asks:
        fail(f"asks 必须是非空数组，每项 {{\"what\": …}}，what 可选：{'、'.join(allowed)}")
    for i, a in enumerate(asks):
        if not isinstance(a, dict) or a.get("what") not in allowed:
            fail(f"asks[{i}].what「{a.get('what') if isinstance(a, dict) else a}」不支持，可选：{'、'.join(allowed)}")
    return asks


LABEL = dict(zeros="零点", local_max="极大值", local_min="极小值", max="最大值", min="最小值", tangent="切线", value="函数值", derivative="导数值", integral="定积分", monotonic="单调区间", range="值域", intersections="交点", count="个数", chord="弦长", midpoint="弦中点", area="面积", distance="距离",
             angle_lines="两直线所成角", angle_line_plane="线面角", dihedral="二面角", distance_point_plane="点到平面的距离", volume="体积", E="期望 E(X)", D="方差 D(X)", pmf="分布列", formula="通项公式检验", sum_formula="求和公式检验", mol="物质的量", mass="质量", remaining_mol="剩余的物质的量", remaining_mass="剩余质量",
             molar_mass="摩尔质量", coef="化学计量数", balanced="配平", pH="pH", c_H="c(H⁺)", c_OH="c(OH⁻)", alpha="电离度", K="平衡常数 K", conc="平衡浓度", fraction="物质的量分数", conversion="转化率", total_mol="气体总物质的量", pressure_ratio="平衡与起始压强比", phenotype_ratio="表型比", genotype_ratio="基因型比",
             count_phenotypes="表型种类数", count_genotypes="基因型种类数", complement="互补链", mrna="mRNA", protein="氨基酸序列", codons="密码子个数", gc="G+C 所占比例", h_bonds="氢键数", producer="消耗的生产者", gain="能增加的量")


def P(a):
    if a.get("prompt"):
        return a["prompt"]
    w = a.get("what")
    if w == "term":
        return f"第 {a.get('n')} 项"
    if w == "sum":
        return f"前 {a.get('n')} 项和"
    if w == "P":
        g = a.get("given")
        gs = ""
        if g:
            gs = " | " + (g if isinstance(g, str) else g.get("phenotype") or g.get("genotype") or g.get("sex") or "")
        return f"P({a.get('event') or a.get('phenotype') or a.get('genotype') or ''}{gs})"
    base = LABEL.get(w, w)
    if a.get("species"):
        return f"{a['species']} 的{base}"
    return f"碱基 {a['base']} 的个数" if w == "count" and a.get("base") else base


def num_row(a, v, unit=""):
    return dict(prompt=P(a), kind="num", value=v, unit=unit, text=with_exact(v) + (f" {unit}" if unit else "") if isf(v) else "不存在", claimed=a.get("claimed"))


def info_row(a, text):
    return dict(prompt=P(a), kind="info", value=None, text=text, claimed=a.get("claimed"))


# ---------------------------------------------------------------- 与 claimed 对照
def _claimed_num(c, row):
    if isinstance(c, str) and re.search(r"%\s*$", c) and row.get("unit") != "%":
        return Solver.eval_const(re.sub(r"%\s*$", "", c)) / 100
    return Solver.eval_const(c)


def _flat(c):
    for x in c:
        if isinstance(x, list):
            yield from _flat(x)
        else:
            yield x


def list_nums(c):
    if isinstance(c, list):
        items = list(_flat(c))
    else:
        s = re.sub(r"[{}（）()\[\]]", " ", str("" if c is None else c))
        items = [x for x in re.split(r"[,，、;；\s]+|(?<!\d)\s*和\s*", s) if x]
    out = []
    for x in items:
        v = float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) else Solver.eval_const(str(x).strip())
        if isf(v):
            out.append(v)
    return out


def norm_text(s):
    return re.sub(r"[\s\-—–_·、，,。.;；→]", "", str("" if s is None else s)).replace("氨酸", "").upper()


def compare(row, parse_equation=None):
    c = row.get("claimed")
    k = row["kind"]
    if k == "check":
        return row["ok"]
    if c is None or c == "" or k == "info":
        return None
    if k == "num":
        if not isf(row["value"]):
            return True if re.search(r"不存在|无|none", str(c), re.I) else None
        x = _claimed_num(c, row)
        return Solver.close(row["value"], x) if isf(x) else None
    if k == "nums":
        a, b = sorted(row["value"]), sorted(list_nums(c))
        if not b and not a:
            return True
        return (len(a) == len(b) and all(Solver.close(x, b[i]) for i, x in enumerate(a))) if b else None
    if k == "ratio":
        b = [float(x) for x in c] if isinstance(c, list) else [Solver.eval_const(x.strip()) for x in re.split(r"[:：∶]", str(c))]
        if not b or not all(isf(x) for x in b):
            return None

        def nm(v):
            s = sum(v) or 1
            return sorted(x / s for x in v)
        A, B = nm(row["value"]), nm(b)
        return len(A) == len(B) and all(abs(x - B[i]) < 0.005 for i, x in enumerate(A))
    if k == "text":
        return norm_text(c) == norm_text(row["value"])
    if k == "point":
        b = list_nums(c)
        return len(b) == len(row["value"]) and all(Solver.close(x, b[i]) for i, x in enumerate(row["value"]))
    if k == "points":
        b = list_nums(c)
        pts = [(b[i], b[i + 1]) for i in range(0, len(b) - 1, 2)]
        if len(pts) != len(row["value"]):
            return False if pts else None
        return all(any(Solver.close(p[0], q[0]) and Solver.close(p[1], q[1]) for q in pts) for p in row["value"])
    if k == "line":
        try:
            s = re.sub(r"^\s*[a-zA-Z]\s*[:：]\s*", "", str(c))
            parts = s.split("=")
            if len(parts) != 2:
                return None
            g = Solver.fn(f"({parts[0]})-({parts[1]})", ["x", "y"])
            kk, bb = row["value"]["k"], row["value"]["b"]
            sc = abs(g(1, 0) - g(0, 0)) + abs(g(0, 1) - g(0, 0)) or 1
            return all(abs(g(x, kk * x + bb)) / sc < 0.01 for x in (-1, 0, 2))
        except (Solver.ExprError, ValueError):
            return None
    if k == "equation":
        try:
            q = (parse_equation or REG["__parse_equation__"])(str(c))
            mine = row["value"]
            if len(q["species"]) != len(mine["species"]):
                return False
            ratio = None
            for sp in mine["species"]:
                other = next((s for s in q["species"] if s["f"] == sp["f"] and s["side"] == sp["side"]), None)
                if other is None:
                    return False
                r = other["coef"] / sp["coef"]
                if ratio is None:
                    ratio = r
                elif abs(r - ratio) > 1e-9 * ratio:
                    return False
            return True
        except (TaskError, ValueError, KeyError):
            return None
    return None


def roots(g, a, b, N=6000):
    """一维求根（函数零点、直线与曲线交点共用）。"""
    out = []
    xs = [a + (b - a) * i / N for i in range(N + 1)]
    ys = [g(x) for x in xs]
    scale = max((abs(y) for y in ys if isf(y)), default=0) or 1

    def add(r):
        if not any(abs(z - r) < 1e-7 * max(1, abs(b - a)) for z in out):
            out.append(r)
    for i in range(N):
        y0, y1 = ys[i], ys[i + 1]
        if not isf(y0) or not isf(y1):
            continue
        if y0 == 0:
            add(xs[i])
            continue
        if y0 * y1 < 0:
            lo, hi, flo = xs[i], xs[i + 1], y0
            for _k in range(100):
                m = (lo + hi) / 2
                fm = g(m)
                if not isf(fm):
                    break
                if fm == 0:
                    lo = hi = m
                    break
                if fm * flo < 0:
                    hi = m
                else:
                    lo, flo = m, fm
            r = (lo + hi) / 2
            fr = abs(g(r))
            if isf(fr) and fr <= 1e-6 * (1 + min(abs(y0), abs(y1))):   # 排除间断点（两侧都很大）
                add(r)
        elif i > 0 and isf(ys[i - 1]) and abs(y0) <= abs(ys[i - 1]) and abs(y0) <= abs(y1) and abs(y0) < 1e-3 * scale:
            lo, hi = xs[i - 1], xs[i + 1]   # 切点式的零点（偶重根）：|g| 的局部极小，黄金分割细化
            for _k in range(120):
                m1, m2 = lo + (hi - lo) * 0.382, lo + (hi - lo) * 0.618
                if abs(g(m1)) < abs(g(m2)):
                    hi = m2
                else:
                    lo = m1
            r = (lo + hi) / 2
            if abs(g(r)) < 1e-9 * (1 + scale):
                add(r)
    return sorted(out)
