"""离线读题器（VeloΦ 的规则读题思路）：没有密钥或断网时，用关键词打分定题型、抽带单位的数、按引用名挂到参数上、冲突标出。

能覆盖的题型直接填 task 交给程序求解；覆盖不了的返回 None，界面提示需要 AI。
"""
from __future__ import annotations

import re

CN = dict(zip("零一二三四五六七八九", range(10)))
UNIT = r"(?:km/h|m/s²|m/s\^?2|m/s|cm/s|kg|mg|g|N/kg|N/m|N|km|cm|mm|m|ms|min|s|h|kW|W|kJ|J|V|mA|A|kΩ|Ω|Hz|T|C|°|度|mol/L|mol|mL|L|%)"
_NUM = r"([-+−]?\d+(?:\.\d+)?(?:\s*[×x]\s*10\s*\^?\s*\(?[-−]?\d+\)?|\s*[×x]\s*10[⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)?)"
_SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹"


def to_num(t):
    t = t.replace("−", "-").replace(" ", "")
    m = re.match(r"([-+]?\d+(?:\.\d+)?)[×x]10\^?\(?([-\d]+)\)?$", t)
    if m:
        return float(m.group(1)) * 10 ** int(m.group(2))
    m = re.match(r"([-+]?\d+(?:\.\d+)?)[×x]10([⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)$", t)
    if m:
        e = int("".join("-" if c == "⁻" else str(_SUP.index(c)) for c in m.group(2)))
        return float(m.group(1)) * 10 ** e
    return float(t)


def quantities(text):
    """抽带单位的数，记下它前面最近的文字（引用名）。"""
    out = []
    for m in re.finditer(_NUM + r"\s*(" + UNIT + r")(?![a-zA-Z])", text):
        before = text[max(0, m.start() - 12):m.start()]
        out.append(dict(value=to_num(m.group(1)), unit=m.group(2).replace("度", "°").replace("m/s^2", "m/s²"), before=before, pos=m.start()))
    return out


def symbol(text, *names):
    """取 v0=20、μ=0.25、θ = 37° 这种带符号的量。"""
    for n in names:
        m = re.search(rf"(?<![A-Za-z]){n}\s*[=＝为]\s*" + _NUM, text)
        if m:
            return to_num(m.group(1))
    return None


def first(qs, unit, *near):
    """同单位的量里挑一个：优先前面带关键词的。"""
    cand = [q for q in qs if q["unit"] == unit]
    for w in near:
        for q in cand:
            if w in q["before"]:
                return q["value"]
    return cand[0]["value"] if cand else None


def g_of(text):
    m = re.search(r"g\s*(?:取|=|＝|为)\s*(\d+(?:\.\d+)?)", text)
    return float(m.group(1)) if m else None


def conv(v, unit):
    if v is None:
        return None
    return v / 3.6 if unit == "km/h" else v


KEYWORDS = dict(projectile=("平抛", "斜抛", "抛出", "水平抛", "竖直上抛", "抛体", "落地"), incline=("斜面", "倾角"), collision=("碰撞", "相碰", "弹性碰", "相撞"), circuit=("电动势", "内阻", "路端电压", "闭合电路", "串联", "并联"), lens=("透镜", "焦距", "物距", "像距"), field=("平行板", "偏转", "洛伦兹", "匀强磁场", "带电粒子"),
                func=("f(x)", "函数", "极值", "零点", "切线"), conic=("椭圆", "双曲线", "抛物线", "弦长"), seq=("数列", "等差", "等比", "通项"), prob=("二项分布", "超几何", "分布列", "正态分布"), reaction=("方程式", "标准状况", "物质的量", "mol"), solution=("pH", "电离常数", "滴定"), cross=("杂交", "基因型", "自交", "表现型"), dna=("mRNA", "转录", "碱基", "模板链"), foodweb=("食物链", "食物网", "能量传递"))


def classify(text):
    best, score = None, 0
    for k, words in KEYWORDS.items():
        s = sum(len(w) for w in words if w in text)
        if s > score:
            best, score = k, s
    return best


def _ask(what, prompt=None, **o):
    return dict(what=what, prompt=prompt or what, **o)


def read(text):
    """返回 {task, knowns, kind, conflicts} 或 None。"""
    t = str(text or "").strip().replace("，", "，")
    kind = classify(t)
    if not kind:
        return None
    qs = quantities(t)
    g = g_of(t)
    extra = {"g": g} if g else {}
    conflicts = []
    spec = None
    if kind == "projectile":
        v = first(qs, "m/s", "速度", "初速", "以") or conv(first(qs, "km/h"), "km/h") or symbol(t, "v0", "v₀")
        ang = first(qs, "°", "角", "仰") or symbol(t, "θ", "α")
        h = first(qs, "m", "高", "离地") if re.search(r"高", t) else None
        if re.search("水平抛|平抛", t):
            ang = 0
        if re.search("竖直上抛", t):
            ang = 90
        if v is None and not h:
            return None
        asks = []
        if re.search("落地时间|时间|多久", t):
            asks.append(_ask("time", "落地时间"))
        if re.search("水平位移|射程|水平距离", t):
            asks.append(_ask("range", "水平射程"))
        if re.search("最大高度|最高", t):
            asks.append(_ask("max_height", "最大高度"))
        if re.search("落地.{0,4}速度|落地速率", t):
            asks.append(_ask("impact_speed", "落地速度"))
        spec = dict(kind=kind, v0=v or 0, angle=ang or 0, h0=h or 0, asks=asks or [_ask("time", "落地时间"), _ask("range", "水平射程"), _ask("max_height", "最大高度"), _ask("impact_speed", "落地速度")], **extra)
    elif kind == "incline":
        ang = first(qs, "°", "倾角", "角") or symbol(t, "θ", "α")
        if ang is None:
            return None
        mu = symbol(t, "μ", "mu")
        if mu is None:
            m = re.search(r"摩擦因数[为是=＝]?\s*(\d+(?:\.\d+)?)", t)
            mu = float(m.group(1)) if m else (0 if re.search("光滑", t) else None)
        if mu is None:
            conflicts.append("没读到动摩擦因数，按光滑处理")
            mu = 0
        L = first(qs, "m", "长", "斜面")
        asks = []
        if re.search("加速度", t):
            asks.append(_ask("a", "加速度"))
        if re.search("时间|多久", t):
            asks.append(_ask("time", "滑到底端的时间"))
        if re.search("速度", t):
            asks.append(_ask("v_end", "到底端的速度"))
        spec = dict(kind=kind, angle=ang, mu=mu, m=first(qs, "kg") or 1, L=L or 1, asks=asks or [_ask("a", "加速度"), _ask("time", "滑到底端的时间"), _ask("v_end", "到底端的速度")], **extra)
    elif kind == "collision":
        ms = [q["value"] for q in qs if q["unit"] == "kg"]
        vs = [q["value"] for q in qs if q["unit"] == "m/s"]
        if len(ms) < 2 or not vs:
            return None
        v2 = vs[1] if len(vs) > 1 else 0
        if len(vs) > 1 and re.search("相向|反向", t):
            v2 = -abs(v2)
        e = 0 if re.search("完全非弹性|粘在一起|共速", t) else 1
        spec = dict(kind=kind, m1=ms[0], m2=ms[1], v1=vs[0], v2=v2, e=e, asks=[_ask("v1_after", "碰后 v₁"), _ask("v2_after", "碰后 v₂"), _ask("energy_loss", "损失的动能")])
    elif kind == "circuit":
        E_ = first(qs, "V", "电动势", "电源")
        if E_ is None:
            return None
        rs = [q for q in qs if q["unit"] == "Ω"]
        def is_r(q):
            return re.search(r"(内阻|内电阻)[为是=＝]?\s*$", q["before"])
        r = next((q["value"] for q in rs if is_r(q)), None)
        loads = [q["value"] for q in rs if not is_r(q)]
        if not loads:
            return None
        spec = dict(kind=kind, E=E_, r=r or 0, R1=loads[0], R2=loads[1] if len(loads) > 1 else 0, mode="parallel" if ("并联" in t and len(loads) > 1) else "series", asks=[_ask("I", "干路电流"), _ask("U", "路端电压"), _ask("P_out", "输出功率")])
    elif kind == "lens":
        f = symbol(t, "f")
        if f is None:
            m = re.search(r"焦距[为是=＝]?\s*(\d+(?:\.\d+)?)", t)
            f = float(m.group(1)) if m else None
        m = re.search(r"物距[为是=＝]?\s*(\d+(?:\.\d+)?)", t)
        u = float(m.group(1)) if m else symbol(t, "u")
        if f is None or u is None:
            return None
        if "凹透镜" in t:
            f = -abs(f)
        spec = dict(kind=kind, f=f, u=u, asks=[_ask("v", "像距"), _ask("m", "放大率"), _ask("nature", "像的性质")])
    elif kind == "func":
        m = re.search(r"f\s*\(x\)\s*[=＝]\s*([^，。；,;\n]+)", t) or re.search(r"y\s*[=＝]\s*([^，。；,;\n]+)", t)
        if not m:
            return None
        f = re.sub(r"\s+", "", m.group(1)).replace("²", "^2").replace("³", "^3").replace("−", "-")
        f = re.sub(r"(\d)(x)", r"\1*\2", f)
        f = re.sub(r"(\d)(sin|cos|tan|ln|exp|sqrt)", r"\1*\2", f)
        asks = []
        if "零点" in t:
            asks.append(_ask("zeros", "零点"))
        if "极大" in t or "极值" in t:
            asks.append(_ask("local_max", "极大值"))
        if "极小" in t or "极值" in t:
            asks.append(_ask("local_min", "极小值"))
        if "单调" in t:
            asks.append(_ask("monotonic", "单调区间"))
        spec = dict(kind=kind, f=f, asks=asks or [_ask("zeros", "零点"), _ask("local_max", "极大值"), _ask("local_min", "极小值"), _ask("monotonic", "单调区间")])
    elif kind == "conic":
        m = re.search(r"([^，。；,;\s]*[xy]\s*[²^][^，。；,;]*=[^，。；,;]+)", t)
        ln_ = re.search(r"直线[^，。；,;]*?(y\s*=\s*[^，。；,;与和]+|x\s*=\s*[^，。；,;与和]+)", t)
        if not m or not ln_:
            return None
        curve = re.sub(r"\s", "", m.group(1)).replace("²", "^2")
        line = re.sub(r"\s", "", ln_.group(1))
        line = re.sub(r"(\d)x", r"\1*x", line)
        spec = dict(kind=kind, curve=curve, line=line, asks=[_ask("intersections", "交点"), _ask("chord", "弦长")])
    elif kind == "dna":
        m = re.search(r"[ACGTU]{6,}", t)
        if not m:
            return None
        seq = m.group(0)
        strand = "mrna" if "U" in seq or ("T" not in seq and "mRNA" in t and "模板" not in t) else "template" if "模板链" in t else "coding"
        spec = dict(kind=kind, seq=seq, strand=strand, asks=[_ask("mrna", "mRNA"), _ask("protein", "氨基酸序列"), _ask("gc", "G+C 比例")] if strand != "mrna" else [_ask("protein", "氨基酸序列"), _ask("codons", "密码子个数")])
    elif kind == "cross":
        m = re.findall(r"\b((?:[A-Za-z]{2}){1,3})\b\s*(?:×|x|X|与)\s*((?:[A-Za-z]{2}){1,3})\b", t)
        if not m:
            return None
        p1, p2 = m[0]
        letters = []
        for ch in p1.upper():
            if ch not in letters:
                letters.append(ch)
        spec = dict(kind=kind, loci=[dict(alleles=[c, c.lower()]) for c in letters], parents=[p1, p2], asks=[_ask("phenotype_ratio", "表型比"), _ask("genotype_ratio", "基因型比")])
    if not spec:
        return None
    return dict(task=spec, kind=kind, knowns=[f"{q['value']:g} {q['unit']}" for q in qs], conflicts=conflicts)
