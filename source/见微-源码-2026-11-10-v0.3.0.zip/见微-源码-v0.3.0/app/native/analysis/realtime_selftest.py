"""Recorded streams only: early native diagrams, isolation and scene/result agreement."""
from ..kit import test_runtime
test_runtime.configure()
import json
import sys
import time
from pathlib import Path


def main(output=None):
    app = test_runtime.application()
    from . import lesson, tasks
    from .realtime import completed_field, exact_figure, LiveTasks
    from .selftest import VIZ_TASKS, PHYS
    from .page import AnalysisPage
    from ..bank.ph_scenes2 import Circuit, Collision
    from ..bank.ph_scenes1 import Projectile
    from ..bank.physics import apply_params
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    assert completed_field('{"figure":{"task":{"kind":"fake"}},"task":{"kind":', 'task') is None
    assert completed_field('{"figure":{"task":9},"task":{"kind":"func"},"summary":"unfinished', 'task') == {'kind':'func'}
    assert completed_field('x'*200001, 'task') is None
    questions = json.loads((Path(__file__).parents[1]/'bank/questions.json').read_text(encoding='utf-8'))
    q = next(q for q in questions if q['id']=='p-2023-b-02')
    assert exact_figure(q['stem'])
    assert not exact_figure(q['stem']+' 求平均速度。')
    assert not exact_figure(q['stem'].replace('20','21'))
    assert exact_figure(q['stem']) is not exact_figure(q['stem'])
    records = []
    for spec in VIZ_TASKS+[s for s,_ in PHYS]:
        count = [0]
        def build(s, problem):
            count[0] += 1
            return lesson.build_tasks(s, problem)
        live = LiveTasks('本题', build)
        prefix = json.dumps(dict(task=spec), ensure_ascii=False)[:-1]+',"summary":"'
        started = time.perf_counter()
        preview = live.preview(prefix)
        assert preview, spec['kind']
        assert live.preview(prefix) is None
        result = live.solve(spec)
        assert result['ok'] and count[0] == 1
        preview[0]['title'] = 'mutated'
        assert live.solve(spec)['results'][0]['title'] != 'mutated'
        records.append(dict(kind=spec['kind'], program_ms=round((time.perf_counter()-started)*1000,2)))
    specs = [
        dict(kind='projectile',v0=12,angle=-30,h0=10,g=10,asks=[dict(what='range')]),
        dict(kind='collision',m1=2,m2=3,v1=4,v2=0,e=.35,asks=[dict(what='v1_after')]),
        dict(kind='circuit',E=6,r=0,R1=4,R2=.5,R3=3,mode='parallel',asks=[dict(what='I')])]
    for spec, cls in zip(specs, (Projectile,Collision,Circuit)):
        result=tasks.build(spec)['result']
        sc=cls()
        apply_params(sc,result['viz']['scene']['params'])
        if spec['kind']=='projectile':
            assert sc.P.angle == -30
        elif spec['kind']=='collision':
            assert abs(sc.ev()['v1p']-result['rows'][0]['value'])<1e-9
        else:
            assert abs(sc.calc(0)['I']-result['rows'][0]['value'])<1e-9
            assert sc.calc(0)['I']==sc.calc(4)['I']
        assert all('absolute_error' in c for c in result['checks'])
    response=dict(subject='数学',topic='函数',task=VIZ_TASKS[0],module=None,summary='看本题曲线',steps=['读取条件','观察零点'],answer='由程序结果核对')
    page=AnalysisPage()
    page.resize(1500,900)
    page.show()
    page._active_problem='函数 f(x)=x^3-3*x'
    page._analysis_started=time.perf_counter()
    drafts=[]
    class Stream:
        name='recorded-live'
        def ask(self, messages, on_text=None, **kwargs):
            prefix=json.dumps(dict(subject='数学',topic='函数',task=VIZ_TASKS[0]),ensure_ascii=False)[:-1]+',"summary":"'
            on_text(prefix)
            assert drafts and drafts[-1].get('taskRes'), 'must publish before full reply'
            return json.dumps(response,ensure_ascii=False),False
    def on_draft(d):
        drafts.append(d)
        page._on_draft(page.rev,d)
        app.processEvents()
    analyzed=lesson.analyze(page._active_problem,Stream(),on_draft=on_draft)
    tabs=page.right.currentWidget()
    # 有程序图解时，题干整理的文字框不再占一个标签页，图解直接在最前面
    assert tabs.count()>=1 and tabs.currentWidget() is not page.figure_view and page.figure_view.isHidden()
    on_draft(dict(summary='后续文字'))
    assert page.right.currentWidget() is tabs
    page._on_draft(page.rev-1,dict(taskRes=analyzed['taskRes']))
    assert page.right.currentWidget() is tabs
    analyzed['figure']={'v':999}
    checked=lesson.check1(dict(response,figure={'v':999}),'本题')
    assert checked['ok'] and checked['value'].get('figureNote')
    page._on_done(page.rev,analyzed)
    app.processEvents()
    page.grab().save(str(out/'live-function.png'))
    page.shutdown()
    page.close()
    (out/'timings.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    print('REALTIME OK', len(records), 'cases', len({r['kind'] for r in records}), 'types; early publication, cache isolation, scene agreement, stale tickets; no network',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
