"""Two explicitly bounded mechanics models sharing one physical time coordinate."""
import math
from PySide6.QtCore import QPointF, Qt, QTimer
from PySide6.QtGui import QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QSlider, QLabel
from ..design.tokens import T, qc, font


class Clock(QWidget):
    def __init__(self, kind, params):
        super().__init__()
        self.kind,self.p=kind,dict(params)
        self.time=0.0
        g=self.p.get('g',9.8)
        th=math.radians(self.p.get('angle',0))
        if kind=='projectile':
            self.vx=self.p['v0']*math.cos(th)
            self.vy=self.p['v0']*math.sin(th)
            self.duration=(self.vy+math.sqrt(self.vy**2+2*g*self.p.get('h0',0)))/g
        else:
            self.acc=max(0,g*(math.sin(th)-self.p.get('mu',0)*math.cos(th)))
            self.duration=math.sqrt(2*self.p.get('L',1)/self.acc) if self.acc>0 else 5
        self.duration=max(self.duration,1e-9)
        self.samples=[self.state_at(self.duration*i/160) for i in range(161)]
        self.timer=QTimer(self)
        self.timer.setInterval(30)
        self.timer.timeout.connect(self.tick)
        lay=QVBoxLayout(self)
        self.canvas=_Canvas(self)
        self.canvas.setMinimumSize(360,280)
        lay.addWidget(self.canvas,1)
        row=QHBoxLayout()
        self.play=QPushButton('播放')
        self.play.clicked.connect(self.toggle)
        row.addWidget(self.play)
        self.slider=QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0,1000)
        self.slider.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.slider.valueChanged.connect(lambda v:self.seek(self.duration*v/1000))
        row.addWidget(self.slider,1)
        self.label=QLabel()
        row.addWidget(self.label)
        lay.addLayout(row)
        note=QLabel('同一时刻：受力与速度图共用滑块。忽略空气阻力；落地/到达斜面底端即停止，不演示碰撞。' if kind=='projectile' else '同一时刻：受力与速度图共用滑块。由静止释放、沿斜面向下为正；静止时采用所需静摩擦力。未给质量时受力按单位质量表示。')
        note.setWordWrap(True)
        lay.addWidget(note)
        self.seek(0)

    def state_at(self,t):
        t=min(self.duration,max(0,t)) if hasattr(self,'duration') else t
        g=self.p.get('g',9.8)
        if self.kind=='projectile':
            return dict(t=t,v=self.vy-g*t,vx=self.vx,x=self.vx*t,y=self.p.get('h0',0)+self.vy*t-g*t*t/2)
        return dict(t=t,v=self.acc*t,x=self.acc*t*t/2)

    def seek(self,t):
        self.time=min(self.duration,max(0,t))
        self.label.setText(f't = {self.time:.3g} s')
        self.canvas.update()

    def tick(self):
        self.slider.setValue(min(1000,self.slider.value()+6))
        if self.slider.value()==1000:
            self.timer.stop()
            self.play.setText('重播')

    def toggle(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play.setText('播放')
        else:
            if self.slider.value()==1000:
                self.slider.setValue(0)
            self.timer.start()
            self.play.setText('暂停')

    def hideEvent(self,event):
        self.timer.stop()
        self.play.setText('播放')
        super().hideEvent(event)


class _Canvas(QWidget):
    def __init__(self,owner):
        super().__init__(owner)
        self.owner=owner

    def paintEvent(self,event):
        o=self.owner
        p=QPainter(self)
        try:
            p.setRenderHint(QPainter.RenderHint.Antialiasing)
            p.fillRect(self.rect(),qc(T.stage))
            p.scale(self.width()/900,self.height()/400)
            p.setFont(font(13))
            def text(x,y,s,color=None):
                p.setPen(qc(color or T.fg))
                p.drawText(QPointF(x,y),s)
            def line(x,y,xx,yy,color):
                p.setPen(QPen(qc(color),2))
                p.drawLine(QPointF(x,y),QPointF(xx,yy))
            def arrow(dx,dy,s,color):
                x,y=210,195
                line(x,y,x+dx,y+dy,color)
                a=math.atan2(dy,dx)
                for d in (-.45,.45):
                    line(x+dx,y+dy,x+dx-10*math.cos(a+d),y+dy-10*math.sin(a+d),color)
                text(x+dx+8,y+dy,s,color)
            text(35,35,'受力示意（箭长仅示方向）')
            p.setPen(qc(T.fg))
            p.drawEllipse(QPointF(210,195),9,9)
            g=o.p.get('g',9.8)
            mass=o.p.get('m')
            unit='N' if mass else 'N/kg'
            m=mass or 1
            arrow(0,100,f'G={m*g:.3g} {unit}',T.bad)
            if o.kind=='incline':
                th=math.radians(o.p['angle'])
                sn,cs=math.sin(th),math.cos(th)
                line(65,195-145*math.tan(th),350,195+140*math.tan(th),T.muted)
                arrow(85*sn,-85*cs,f'N={m*g*cs:.3g} {unit}',T.accent)
                friction=min(g*sn,o.p.get('mu',0)*g*cs)
                if friction>0:
                    arrow(-85*cs,-85*sn,f'f={m*friction:.3g} {unit}',T.ok)
            text(475,35,'vᵧ–t（竖直向上为正）' if o.kind=='projectile' else 'v–t（沿斜面向下为正）')
            lo=min(0,min(s['v'] for s in o.samples))
            hi=max(1e-9,max(s['v'] for s in o.samples))
            pad=(hi-lo)*.15
            lo-=pad
            hi+=pad
            X=lambda t:490+340*t/o.duration
            Y=lambda v:325-240*(v-lo)/(hi-lo)
            line(490,70,490,325,T.muted)
            line(490,Y(0),845,Y(0),T.muted)
            path=QPainterPath()
            for i,s in enumerate(o.samples):
                pt=QPointF(X(s['t']),Y(s['v']))
                path.moveTo(pt) if i==0 else path.lineTo(pt)
            p.setPen(QPen(qc(T.accent),2))
            p.drawPath(path)
            state=o.state_at(o.time)
            line(X(o.time),75,X(o.time),325,T.muted)
            p.setBrush(qc(T.bad))
            p.drawEllipse(QPointF(X(o.time),Y(state['v'])),5,5)
            text(475,365,f"t={o.time:.3g} s，v={state['v']:.4g} m/s")
            text(475,390,f"横轴 0 → {o.duration:.4g} s；纵轴 m/s")
            text(35,365,'未给质量：单位质量受力' if not mass else f'质量 m={mass:g} kg')
        finally:
            p.end()


def make(result):
    if result.get('failed_checks'):
        return None
    kind=result.get('kind')
    params=(result.get('model_info') or {}).get('parameters') or {}
    if kind not in ('projectile','incline') or not params:
        return None
    # The existing task scene intentionally omits these extra-force cases.
    if kind=='incline' and (params.get('v0',0)!=0 or params.get('F',0)!=0):
        return None
    return Clock(kind,params)
