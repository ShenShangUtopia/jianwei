"""Independent variant references and conservative step checks, recorded data only."""
from ..kit import test_runtime
test_runtime.configure()
import copy
import json
import math
import sys
import time
from pathlib import Path


def main(output=None):
    app=test_runtime.application()
    from . import practice as p
    from .selftest import VIZ_TASKS,PHYS
    from .practice_ui import PracticeDialog
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    cases={s['kind']:copy.deepcopy(s) for s in VIZ_TASKS+[s for s,_ in PHYS]}
    assert len(cases)==17
    for kind,spec in cases.items():
        original=dict(task=spec,ticket=dict(id='original'))
        saved=copy.deepcopy(original)
        assert p.fields(spec),kind
        variant=p.variant(original,0,[])
        assert original==saved and variant['ticket']['id']!='original'
        assert 'figure' not in variant and 'calc' not in variant
        assert all(r['claimed'] is None for r in variant['taskRes'][0]['rows'])
    references=[
        (dict(kind='projectile',v0=20,angle=30,h0=0,g=10,asks=[dict(what='range',claimed=999)]),[(['v0'],10)],math.sqrt(3)*5),
        (dict(kind='incline',m=2,L=8,angle=30,mu=.2,g=10,asks=[dict(what='a')]),[(['mu'],.1)],5-math.sqrt(3)/2),
        (dict(kind='collision',m1=2,m2=1,v1=4,v2=-1,e=1,asks=[dict(what='v1_after')]),[(['e'],0)],7/3),
        (dict(kind='circuit',E=6,r=1,R1=2,R2=3,asks=[dict(what='I')]),[(['R1'],4)],.75),
        (dict(kind='lens',f=10,u=30,asks=[dict(what='v')]),[(['u'],20)],20),
        (dict(kind='field',q=1.6e-19,m=1.67e-27,v0=1e6,B=.5,asks=[dict(what='r')]),[(['B'],1)],.0104375),
        (dict(kind='prob',dist=dict(type='binomial',n=5,p=.3),asks=[dict(what='E')]),[(['dist','p'],.5)],2.5),
        (dict(kind='seq',type='recur',a1=1,rule='2*a+1',asks=[dict(what='term',n=6)]),[(['a1'],2)],95),
        (dict(kind='solution',components=[dict(name='HCl',type='strong_acid',c=.1)],asks=[dict(what='pH')]),[(['components',0,'c'],.01)],2),
        (dict(kind='foodweb',links={'兔':{'草':1}},efficiency=.1,asks=[dict(what='producer',consumer='兔',amount=1)]),[(['efficiency'],.2)],5),
        (dict(kind='conic',curve='x^2/16+y^2/9=1',line='y=x+1',asks=[dict(what='chord')]),[(['line'],'y=0')],8),
        (dict(kind='func',f='x^2',domain=[-3,3],asks=[dict(what='derivative',x=2)]),[(['f'],'x^3')],12),
        (dict(kind='solid',points=dict(A=[0,0,0],B=[2,0,0],C=[0,2,0],D=[0,0,2]),asks=[dict(what='volume',points=['A','B','C','D'])]),[(['points','D',2],3)],2),
        (dict(kind='reaction',equation='H2+Cl2=2HCl',given=[dict(species='H2',mol=1),dict(species='Cl2',mol=1)],asks=[dict(what='mol',species='HCl')]),[(['given',0,'mol'],.5)],1),
        (dict(kind='equilibrium',reaction='N2+3H2⇌2NH3',V_L=2,initial=dict(N2=1,H2=3),at_eq=dict(NH3=dict(mol=.4)),asks=[dict(what='K')]),[(['V_L'],4)],(.4/4)**2/((.8/4)*(2.4/4)**3)),
        (dict(kind='cross',loci=[dict(alleles=['A','a'])],parents=['Aa','Aa'],asks=[dict(what='P',genotype='aa')]),[(['parents',0],'aa'),(['parents',1],'aa')],1),
    ]
    for spec,changes,expected in references:
        value=p.variant(dict(task=spec,ticket={}),0,changes)['taskRes'][0]['rows'][0]['value']
        assert abs(value-expected)<max(1e-6,abs(expected)*1e-5),(spec['kind'],value,expected)
    dna=p.variant(dict(task=dict(kind='dna',seq='TACGGGATT',strand='template',asks=[dict(what='mrna')]),ticket={}),0,[(['seq'],'TACCCCATT')])
    assert dna['taskRes'][0]['rows'][0]['value']=='AUGGGGUAA'
    chemical=dict(kind='reaction',equation='H2+Cl2=2HCl',given=[dict(species='H2',mol=1)],asks=[dict(what='mol',species='HCl')])
    chem_report=p.diagnose(chemical,'化学方程式=H2+Cl2=HCl\nHCl的反应物质的量=1 mol')
    assert chem_report['first']['line']==1 and not chem_report['checked'][1]['ok']
    assert p.diagnose(chemical,'化学方程式=2H2+2Cl2=4HCl')['checked'][0]['ok']
    slope=dict(kind='incline',angle=30,mu=.2,m=2,L=4,g=10,asks=[dict(what='a')])
    report=p.diagnose(slope,'支持力=10*sqrt(3) N\n加速度=5 m/s²')
    assert report['first']['line']==2 and '可能漏' in report['cause']
    report=p.diagnose(slope,'加速度=g*sin(theta)')
    assert '等式' in report['cause'] and '省略' in report['cause']
    report=p.diagnose(slope,'加速度=-3.26794919243 m/s²')
    assert '符号相反' in report['cause']
    report=p.diagnose(slope,'加速度=99999')
    assert '看不出来' in report['cause']
    assert '看不出来' in p.diagnose(slope,'随便乱填42abc')['conclusion']
    projectile=dict(kind='projectile',v0=20,angle=30,h0=0,g=10,asks=[dict(what='time')])
    assert '漏平方' in p.diagnose(projectile,'最大高度=0.5 m')['cause']
    assert not p.close(0,1.6e-19)
    assert p.diagnose(projectile,'水平射程=0.03464101615 km')['checked']==[] # unsupported unit is not silently stripped
    p.save_attempt(dict(question='p-test'),'加速度=5',report)
    history=json.loads((p.home()/'attempts.json').read_text(encoding='utf-8'))
    assert history['v']==1 and history['items'][-1]['reference']['question']=='p-test'
    before=copy.deepcopy(history)
    (p.home()/'attempts.json').write_text('{"v":99,"items":[]}',encoding='utf-8')
    try:
        p.save_attempt({},'',{})
    except ValueError:
        pass
    else:
        raise AssertionError('future attempts must not be overwritten')
    (p.home()/'attempts.json').write_text(json.dumps(before),encoding='utf-8')
    dialog=PracticeDialog(dict(task=slope,ticket=dict(id='source')))
    dialog.show()
    def wait():
        start=time.monotonic()
        while dialog.worker and dialog.worker.isRunning() and time.monotonic()-start<10:
            app.processEvents()
            time.sleep(.005)
        app.processEvents()
        assert not dialog.worker.isRunning()
    wait()
    dialog.student.setPlainText('支持力=17.320508 N\n加速度=g*sin(theta)')
    dialog.diagnose()
    wait()
    assert '省略' in dialog.output.toPlainText()
    dialog.grab().save(str(out/'step-check.png'))
    dialog.recalculate()
    wait()
    assert dialog.pending and dialog.open.isEnabled()
    dialog.grab().save(str(out/'variant-result.png'))
    dialog.close()
    (out/'coverage.json').write_text(json.dumps(dict(variant_types=list(cases),intermediate_types=sorted(p.INTERMEDIATE),numeric_references=len(references),network=False),ensure_ascii=False,indent=2),encoding='utf-8')
    print('PRACTICE OK 17 variant types, 17 independent references; conservative step checks, isolation, persistence, UI',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
