"""题目分析主流程（VeloΦ 式）：AI 只读题、选路线、填参数；数全部由程序算；每个答案都过独立核对才显示。

路线优先级：task（专门题型）> model（方程模型）> module（实验）> 只讲解。没有密钥时走离线读题器。
analyze() 在工作线程里跑，不碰界面；票据 ticket 由界面比对，过时的回答直接丢弃。
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import time
from pathlib import Path

from ..kit.home import load_json, save_json
from . import llm, offline, solver as Solver, tasks

HISTORY = "lessons.json"
SUBJECTS = ("数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理")


def ticket(text, rev):
    return dict(id=f"{int(time.time() * 1000):x}", revision=rev, hash=hashlib.sha1(str(text).encode("utf-8")).hexdigest()[:12])


def protocol():
    return (Path(__file__).parent / "protocol.md").read_text(encoding="utf-8")


def strs(v):
    if isinstance(v, list):
        return [x if isinstance(x, str) else json.dumps(x, ensure_ascii=False) for x in v if x not in (None, "")]
    return [] if v in (None, "") else [str(v)]


def build_tasks(spec, problem):
    lst = spec if isinstance(spec, list) else [spec]
    if not lst or len(lst) > 6:
        return dict(ok=False, errors=["task 是一个对象，或 1~6 个对象组成的数组"])
    results, errors = [], []
    for i, s in enumerate(lst):
        t = tasks.build(s, problem)
        if t["ok"]:
            results.append(t["result"])
        else:
            errors += [f"task[{i}] {e}" if len(lst) > 1 else e for e in t["errors"]]
    return dict(ok=False, errors=errors) if errors else dict(ok=True, results=results)


def check1(A, problem, module_ids=(), task_builder=None):
    """第一步：字段齐全、实验 id 在目录里、题型与方程模型能用。可选部分不合格时可以退回「不带它」的结果。"""
    errors = []
    allowed={"subject","topic","module","summary","knowns","assumptions","method","steps","answer","check","pitfalls","task","model","scenario","conclusion","figure"}
    out = {key:value for key,value in A.items() if key in allowed}
    if out.get("subject") not in SUBJECTS:
        errors.append(f"subject 必须是 {'、'.join(SUBJECTS)} 之一")
    if out.get("module") in ("", "null"):
        out["module"] = None
    if out.get("module") is not None and module_ids and out["module"] not in module_ids:
        errors.append(f"module「{out['module']}」不是实验目录中的 id：只能照抄目录每行第一列，没有合适的实验就填 null")
    for k in ("knowns", "steps", "assumptions", "pitfalls"):
        out[k] = strs(out.get(k))
    for k in ("summary", "topic", "scenario", "method", "check", "conclusion"):
        if out.get(k) is not None:
            out[k] = str(out[k])
    if not out["steps"]:
        errors.append("steps 不能为空：按讲题顺序写出解题步骤")
    if out.get("answer") in (None, "") or not str(out["answer"]).strip():
        errors.append("answer 不能为空")
    else:
        out["answer"] = str(out["answer"])
    model_err, task_err, figure_err = [], [], []
    if out.get("figure") is not None:
        from .figure import validate, FigureError
        try:
            out["figure"] = validate(out["figure"])
        except FigureError as exc:
            figure_err = ["figure："+str(exc)]
    if out.get("model") is not None:
        b = Solver.build(out["model"], problem)
        if b["ok"]:
            out["_built"] = b
        else:
            model_err = b["errors"]
    if out.get("task") is not None:
        t = task_builder(out["task"]) if task_builder else build_tasks(out["task"], problem)
        if t["ok"]:
            out["_task"] = t["results"]
        else:
            task_err = t["errors"]
    if figure_err and out.get("_task") and not errors and not model_err and not task_err:
        out.pop("figure", None)
        out["figureNote"] = "AI图解未通过校验，使用程序题型图：" + "；".join(figure_err)
        figure_err = []
    if not errors and not model_err and not task_err and not figure_err:
        return dict(ok=True, value=out)
    fb = None
    if not errors:
        fb = dict(out)
        if model_err:
            fb.pop("model", None)
        if task_err:
            fb.pop("task", None)
        if figure_err:
            fb.pop("figure", None)
    return dict(ok=False, errors=errors + task_err + model_err + figure_err, fallback=fb)


def fmt_num(v):
    if v is None or not isinstance(v, (int, float)) or not math.isfinite(v):
        return "—"
    if abs(v) >= 1e5 or (abs(v) < 1e-3 and v != 0):
        return f"{v:.3e}"
    return f"{float(f'{v:.5g}'):.5g}"


def verdict_msg(built, res):
    m = built["model"]
    head = {"inconsistent": "方程互相矛盾，不存在同时满足全部方程的解", "underdetermined": f"条件不足，不能确定：{'、'.join(res['undetermined']) or '所求的量'}"}.get(res["verdict"], "数值求解失败（可能是初值或取值范围不合适）")
    lines = [f"程序解了你的方程模型，结论：{head}。"]
    if res["conflicts"]:
        lines.append("最小二乘解下不满足的方程：" + "；".join(f"第 {c['index'] + 1} 条（{m['equations'][c['index']]['text']}，相对残差 {c['residual']:.2g}）" for c in res["conflicts"]) + "。")
    lines.append("请逐条对照题目检查：是否漏了某个力或条件、系数或正负号是否写错、角度是否已按弧度处理、未知量是否多设或少设、非线性方程的 guess / min / max 是否能选出物理上合理的根。")
    lines.append("如果方程有误：改正后输出第一步的完整 JSON。")
    lines.append('如果方程与题目一致（题目本身在理想条件下就无解或条件不足）：方程保持不变，在 JSON 中加上 "conclusion"，用一两句话说明这在物理或数学上意味着什么，steps 和 answer 也据此改写。')
    return "\n".join(lines)


def run_task_evidence(L):
    ts = L.pop("_task", None)
    if not ts:
        return ""
    L["taskRes"] = ts
    parts = []
    for t in ts:
        bad = [x for x in t["rows"] if x["ok"] is False]
        if bad:
            parts.append(f"程序按你填写的题型参数（{t['title']}）用专门算法求解（算法本身可信，除非参数与题目不符）：\n" + "\n".join(f"- {x['prompt']}：原解答给出 {json.dumps(x['claimed'], ensure_ascii=False) if isinstance(x['claimed'], (dict, list)) else x['claimed']}，程序算得 {x['text']}" for x in bad) + "\n程序的推导：\n" + "\n".join("  " + d for d in t["detail"]))
    if not parts:
        return ""
    return "\n\n".join(parts) + f"\n你填的参数：{json.dumps(L.get('task'), ensure_ascii=False)}"


def calc(L, conv, engine, module_ids, status):
    built = L.pop("_built", None)
    if not built:
        return ""
    status("程序正在求解方程模型、复算答案…")
    res = Solver.solve(built["model"])
    if res["verdict"] != "solved" and engine:
        status("方程组没有唯一解，正在让 AI 复查方程…")
        try:
            r = llm.ask_json(engine, conv + [dict(role="user", content=verdict_msg(built, res))], lambda j: check1(j, L["problem"], module_ids), repairs=1, status=status)
            if r["value"].get("_built"):
                res2 = Solver.solve(r["value"]["_built"]["model"])
                if res2["verdict"] == "solved" or r["value"].get("conclusion"):
                    built, res = r["value"].pop("_built"), res2
                    L.update(r["value"])
                    if L.get("_task"):
                        L["taskRes"] = L.pop("_task")
        except llm.AskError:
            pass   # 复查失败就保留原结论
        L.pop("_built", None)
    L["assumptions"] = list(dict.fromkeys((L.get("assumptions") or []) + built["notes"]))
    m = built["model"]
    rows = []
    for a in res["answers"]:
        cl = math.nan if a["claimed"] in (None, "") else Solver.eval_const(a["claimed"])
        rows.append(dict(prompt=a["prompt"], unit=a["unit"], value=a["value"], claimed=a["claimed"], ok=None if a["value"] is None or not Solver.isf(cl) else Solver.close(a["value"], cl)))
    L["calc"] = dict(verdict=res["verdict"], knowns=[dict(name=k["name"], value=k["value"], unit=k["unit"], meaning=k["meaning"]) for k in m["knowns"]], unknowns=[dict(name=u["name"], unit=u["unit"], meaning=u["meaning"], value=res["values"].get(u["name"])) for u in m["unknowns"]],
                     equations=[dict(text=e["text"], why=e["why"]) for e in m["equations"]], conflicts=[dict(text=m["equations"][c["index"]]["text"], residual=c["residual"]) for c in res["conflicts"]], undetermined=res["undetermined"], rows=rows)
    bad = [x for x in rows if x["ok"] is False]
    if not bad:
        return ""
    return "程序按你在第一步写的方程模型做了数值求解（数值计算本身不会出错）：\n" + "\n".join(f"- {x['prompt']}：原解答给出 {x['claimed']}，按方程模型算得 {fmt_num(x['value'])}{' ' + x['unit'] if x['unit'] else ''}" for x in bad) + "\n方程模型：\n" + "\n".join(f"  {e['text']}" + (f"（{e['why']}）" if e["why"] else "") for e in m["equations"]) + "\n已知量（国际单位）：" + ("，".join(f"{k['name']} = {fmt_num(k['si'])}" for k in m["knowns"]) or "无")


def correct(L, evidence, engine, status):
    """第四步：拿着核对证据让 AI 重新检查。"""
    user = f"## 题目\n{L.get('problem') or '（见图片）'}\n\n## 原解答\n{json.dumps(dict(steps=L.get('steps'), answer=L.get('answer')), ensure_ascii=False)}\n\n## 核对结果\n{evidence}\n\n## 任务\n执行协议中的第四步，只输出 JSON。"
    try:
        F = llm.ask_json(engine, user, lambda j: dict(ok=True, value=j) if (j.get("answer") or j.get("error")) else dict(ok=False, errors=["必须给出 error 与 answer"]), repairs=1, status=status)["value"]
    except llm.AskError:
        return None
    box = L.setdefault("recheck", {})
    box["check"] = str(F["error"]) if F.get("error") else ""
    ans = "" if F.get("answer") is None else str(F["answer"])
    if ans and re.sub(r"\s", "", ans) != re.sub(r"\s", "", str(L.get("answer"))):
        box["oldAnswer"] = L.get("answer")
        L["answer"] = ans
    else:
        box["disputed"] = not F.get("model_wrong")
    steps = strs(F.get("steps"))
    if steps:
        L["steps"] = steps
    box["review"] = "model" if F.get("model_wrong") else "answer"
    return F


def task_rows(L):
    return [r for t in (L.get("taskRes") or []) for r in t["rows"]]


def status_of(L):
    """给界面的总结论：verified（程序核对通过）/ conflict（有不符）/ unchecked（没有可核对的数）/ pending。"""
    rows = task_rows(L) + ((L.get("calc") or {}).get("rows") or [])
    if any(t.get("failed_checks") for t in L.get("taskRes") or []):
        return "conflict"
    if any(r.get("ok") is False for r in rows):
        return "conflict"
    if any(r.get("ok") is True for r in rows):
        return "verified"
    if any(r.get("kind") != "info" and r.get("value") is not None for r in task_rows(L)):
        return "solved"   # 程序解出来了，但没有 AI 答案可比（离线读题）
    return "unchecked"


def answer_from_program(L):
    """把程序结果整理成答案与步骤（离线读题器、或 AI 的答案被证据推翻时用）。"""
    parts = []
    for t in L.get("taskRes") or []:
        for r in t["rows"]:
            parts.append(f"{r['prompt']}：{r['text']}")
    return "；".join(parts)


def analyze_offline(text, status=lambda _m: None, rev=0):
    status("离线读题：按关键词定题型、抽数值…")
    rd = offline.read(text)
    L = dict(problem=text, engine="offline", ticket=ticket(text, rev), subject="", topic="", summary="", knowns=[], steps=[], answer="", assumptions=[], pitfalls=[], t=time.time())
    if not rd:
        L["unsupported"] = True
        L["summary"] = "离线读题器认不出这道题的类型。填入 DeepSeek 密钥后，AI 可以读题、列方程，程序再复算。"
        return L
    t = build_tasks(rd["task"], text)
    if not t["ok"]:
        L["unsupported"] = True
        L["summary"] = "读到了题型，但条件不全：" + "；".join(t["errors"][:2])
        L["task"] = rd["task"]
        return L
    L["task"] = rd["task"]
    L["taskRes"] = t["results"]
    r0 = t["results"][0]
    L.update(subject=r0["subj"], topic=r0["title"], summary=f"离线读题器按「{r0['title']}」处理，程序已求解" + ("并做了独立核对。" if any(x.get("checks") for x in t["results"]) else "。"), knowns=rd["knowns"], assumptions=rd["conflicts"], answer=answer_from_program(L), steps=[d for r in t["results"] for d in r["detail"]])
    return L


def analyze(text, engine, module_ids=(), catalog_text="", status=lambda _m: None, on_draft=None, rev=0):
    """完整流程；engine=None 走离线。返回 lesson 字典。"""
    from .realtime import LiveTasks, exact_figure
    started = time.perf_counter()
    bank_figure = exact_figure(text)
    if bank_figure and on_draft:
        on_draft(dict(figure=bank_figure, topic="本题专用图解", problem=text,
                      summary="全文匹配题库；图解供参考，当前答案随后核对。"))
    if engine is None:
        L = analyze_offline(text, status, rev)
        if bank_figure:
            L["figure"] = bank_figure
        return L
    live = LiveTasks(text, build_tasks)
    timings = {}
    status("第 1 步：读题、解题、填题型参数并选择路线…")
    user = f"## 实验目录\n{catalog_text}\n\n## 程序题型（题目属于其中之一时填 task，程序用专门算法求解）\n{tasks.catalog()}\n\n## 题目\n{text}\n\n## 任务\n执行协议中的第一步，只输出 JSON。"
    last = [0.0]

    def live_text(t):
        cancel = getattr(engine, 'cancel', None)
        if cancel and cancel():
            return
        now = time.perf_counter()
        timings.setdefault('first_packet_ms',round((now-started)*1000,2))
        if now - last[0] >= 0.15:
            last[0] = now
            if on_draft:
                d = llm.peek(t)
                if bank_figure and not d.get('figure'):
                    d['figure'] = bank_figure
                preview = live.preview(t)
                if preview:
                    d.update(taskRes=preview, problem=text, topic=preview[0]['title'])
                    timings.setdefault('first_program_ms', round((time.perf_counter()-started)*1000, 2))
                on_draft(d)

    def live_think(n):
        now = time.perf_counter()
        timings.setdefault('first_packet_ms',round((now-started)*1000,2))
        if now - last[0] >= 0.3:
            last[0] = now
            status(f"AI 正在思考…（已想 {n} 字）")
    def packet():
        timings.setdefault('first_packet_ms',round((time.perf_counter()-started)*1000,2))
    r = llm.ask_json(engine, user, lambda j: check1(j, text, module_ids, live.solve), status=status, on_text=live_text, on_think=live_think,**({'on_packet':packet} if isinstance(engine,llm.Engine) else {}))
    timings['schema_repairs']=r.get('repairs',0)
    L = dict(problem=text, engine=engine.name, ticket=ticket(text, rev), t=time.time(), **{k: v for k, v in r["value"].items() if k != "problem"})
    if r.get("dropped"):
        L["calcNote"] = "题型参数或方程模型没有通过校验，已跳过这部分程序求解：" + "；".join(r["dropped"][:2])
    status("程序正在求解、核对答案…")
    evidence = [e for e in (run_task_evidence(L), calc(L, r["msgs"], engine, module_ids, status)) if e]
    if evidence:
        status("程序求解与解答不符，AI 正在重新检查…")
        correct(L, "\n\n".join(evidence), engine, status)
    if bank_figure and not L.get('figure'):
        L['figure'] = bank_figure
    timings['total_ms'] = round((time.perf_counter()-started)*1000, 2)
    L['timings'] = timings
    return L


def clean(L):
    """去掉不能进 JSON 的内部字段。"""
    return {k: v for k, v in L.items() if not k.startswith("_")}


def history():
    h = load_json(HISTORY, [])
    return h if isinstance(h, list) else []


def save_lesson(L):
    h = [x for x in history() if x.get("ticket", {}).get("id") != L.get("ticket", {}).get("id")]
    save_json(HISTORY, [clean(L)] + h[:29])


# ---------------------------------------------------------------- 第 2、3 步：实验（在主线程用）
def controls(ctx):
    out = []
    for c in ctx.ctrls:
        o = dict(name=c["name"], kind=c["kind"])
        if c.get("group"):
            o["group"] = c["group"]
        if c["kind"] == "slider":
            o.update(min=c["minF"](), max=c["maxF"](), step=c.get("step"), unit=c.get("unit") or None, value=c["get"]())
        elif c["kind"] in ("select", "choice"):
            o.update(options=c["options"](), value=c["get"]())
        elif c["kind"] in ("check", "text"):
            o["value"] = c["get"]()
        out.append(o)
    return out


def find_ctrl(ctrls, n):
    nm = lambda s: re.sub(r"\s+", "", str(s)).lower()   # noqa: E731
    return next((c for c in ctrls if c["name"] == n), None) or next((c for c in ctrls if nm(c["name"]) == nm(n)), None) or next((c for c in ctrls if nm(c["name"]).startswith(nm(n))), None)


def coerce(c, s, problem):
    """把一条设置换成控件能接受的值：选项匹配、单位换算、角度对齐。"""
    v, unit = s.get("value"), s.get("unit")
    if c["kind"] in ("select", "choice"):
        ops = c["options"]()
        op = next((o for o in ops if str(o["value"]) == str(v)), None) or next((o for o in ops if o.get("text") == v), None) or next((o for o in ops if str(v) in str(o.get("text"))), None)
        return dict(value=op["value"]) if op else dict(error=f"「{c['name']}」的值「{v}」不在 options 里，可选的 value：{'、'.join(str(o['value']) for o in ops)}")
    if c["kind"] != "slider":
        return dict(value=v)
    if isinstance(v, dict):
        unit, v = v.get("unit"), v.get("value")
    if isinstance(v, str):
        m = re.match(r"^\s*([-+−]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?)\s*(.*)$", v, re.I)
        if m:
            unit = unit if unit is not None else m.group(2)
            v = float(m.group(1).replace("−", "-"))
        else:
            v = Solver.eval_const(v)
    try:
        v = float(v)
    except (TypeError, ValueError):
        v = math.nan
    if not Solver.isf(v):
        return dict(error=f'「{c["name"]}」是滑块，value 必须是数（或 {{"value": 数, "unit": "单位"}}）')
    notes = []
    if unit not in (None, "") and str(unit).strip() and c.get("unit"):
        cv = Solver.convert(v, unit, c["unit"])
        if cv.get("error"):
            return dict(error=f"「{c['name']}」：{cv['error']}")
        if cv["value"] != v:
            notes.append(f"{c['name']}：{v:g} {unit} = {cv['value']:g} {c['unit']}")
        v = cv["value"]
    ang = Solver.stated_angles(problem)
    if c.get("unit") and Solver.norm_unit(c["unit"]) == "°" and v in ang:
        notes.append(f"按题目给出的三角函数值，{c['name']} {v:g}° 取为 {ang[v]}°，与按近似值手算的答案一致")
        v = ang[v]
    return dict(value=v, note="；".join(notes))


def check2(B, ctrls, problem):
    errors, settings, press, notes = [], [], [], []
    if not isinstance(B.get("settings"), list):
        errors.append("缺少 settings 数组（这是第二步：输出 settings、press、watch、caveats）")
    for i, s in enumerate(B.get("settings") if isinstance(B.get("settings"), list) else []):
        if not isinstance(s, dict):
            errors.append(f'settings[{i}] 必须是 {{"name": 控件名, "value": 值}}')
            continue
        c = find_ctrl(ctrls, s.get("name"))
        if not c or not c.get("set"):
            errors.append(f"settings[{i}].name「{s.get('name')}」不是可设置的控件（必须与控件列表里的 name 完全一致）")
            continue
        r = coerce(c, s, problem)
        if r.get("error"):
            errors.append(r["error"])
            continue
        if r.get("note"):
            notes.append(r["note"])
        settings.append(dict(name=c["name"], value=r["value"]))
    for n in strs(B.get("press")):
        c = find_ctrl(ctrls, n)
        if c and c.get("press"):
            press.append(c["name"])
        else:
            errors.append(f"press 里的「{n}」不是按钮控件")
    value = dict(settings=settings, press=press, watch=strs(B.get("watch")), caveats=str(B["caveats"]) if B.get("caveats") else "", notes=notes)
    if errors:
        return dict(ok=False, errors=errors, fallback=value if isinstance(B.get("settings"), list) else None)
    return dict(ok=True, value=value)


def configure(L, ctx, title, info, engine, status):
    status("第 2 步：配置实验参数…")
    user = f"## 题目\n{L['problem']}\n\n## 第一步结果\n{json.dumps({k: L.get(k) for k in ('summary', 'knowns', 'steps', 'answer', 'scenario')}, ensure_ascii=False)}\n\n## 实验「{title}」原理\n{re.sub(r'<[^>]+>', ' ', info or '')}\n\n## 控件列表\n{json.dumps(controls(ctx), ensure_ascii=False)}\n\n## 任务\n执行协议中的第二步，只输出 JSON。"
    return llm.ask_json(engine, user, lambda j: check2(j, ctx.ctrls, L["problem"]), status=status)["value"]


def apply_settings(L, B, ctx):
    """切换类控件先设；滑块超范围取端点。"""
    sets = sorted(B["settings"], key=lambda s: 0 if (find_ctrl(ctx.ctrls, s["name"]) or {}).get("kind") in ("select", "choice") else 1)
    ok, miss = [], []
    for s in sets:
        c = find_ctrl(ctx.ctrls, s["name"])
        if not c or not c.get("set"):
            miss.append(s["name"])
            continue
        r = coerce(c, s, L["problem"])
        if r.get("error"):
            miss.append(s["name"])
            continue
        v = r["value"]
        if c["kind"] == "slider":
            v = min(c["maxF"](), max(c["minF"](), float(v)))
        c["set"](v)
        ok.append(f"{c['name']} = {v:g}" if isinstance(v, float) else f"{c['name']} = {v}")
    for n in B.get("press") or []:
        c = find_ctrl(ctx.ctrls, n)
        if c and c.get("press"):
            c["press"]()
            ok.append(f"按下「{c['name']}」")
        else:
            miss.append(n)
    L.update(applied=dict(ok=ok, miss=miss), watch=B.get("watch") or [], caveats=B.get("caveats") or "", convNotes=B.get("notes") or [])


def compare_pairs(pairs, readings):
    """程序自己比较数值，避免模型凑数。readings 是读数文本（每行 名称：值）。"""
    def nums(s):
        out = []
        for t in re.findall(r"-?\d+(?:\.\d+)?(?:×10-?\d+)?", str(s).replace("−", "-")):
            m, _, e = t.partition("×10")
            out.append(float(m) * (10 ** int(e) if e else 1))
        return out
    lines = [(x.split("：", 1)[0].strip(), x.split("：", 1)[1].strip()) for x in readings.split("\n") if "：" in x]
    rows = []
    for p in pairs or []:
        if not isinstance(p, dict) or not p.get("readout"):
            continue
        hit = next((ln for ln in lines if ln[0] == p["readout"]), None) or next((ln for ln in lines if ln[0] in p["readout"] or p["readout"] in ln[0]), None)
        if not hit:
            continue
        tail = re.search(r"=\s*(-?\d[\d.]*(?:×10-?\d+)?)\s*[^\d=()（）]*$", hit[1])
        mv = tail.group(1) if tail else hit[1]
        av = p.get("answer_value")
        if isinstance(av, list):
            a = [float(x) for x in av]
        elif isinstance(av, (int, float)):
            a = [float(av)]
        elif re.search("[:：]", str(av)):
            a = nums(av)
        else:
            e = Solver.eval_const(av)
            a = [e] if Solver.isf(e) else nums(av)
        m = nums(mv)
        if not a or not m:
            continue
        if re.search("[:：]", hit[1]) and len(a) == len(m) and len(a) > 1:
            def nm(v):
                s = sum(v) or 1
                return sorted(x / s for x in v)
            ok = all(abs(x - nm(m)[i]) < 0.01 for i, x in enumerate(nm(a)))
            rows.append(dict(quantity=p.get("quantity"), readout=hit[0], answer=" : ".join(f"{x:g}" for x in a), measured=hit[1], ok=ok))
            continue
        n = len(a) if len(a) == len(m) else 1
        ok = all(Solver.close(a[i], m[i]) or (n == 1 and Solver.close(abs(a[i]), abs(m[i]))) for i in range(n))
        rows.append(dict(quantity=p.get("quantity"), readout=hit[0], answer=", ".join(f"{x:.4g}" for x in a[:n]), measured=hit[1], ok=ok))
    return rows
