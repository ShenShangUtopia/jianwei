"""Evidence-based checks and parameter edits; calculation stays off the UI thread."""
import copy

from PySide6.QtCore import QThread,Signal,Qt
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QLabel,QPlainTextEdit,QPushButton,QComboBox,QScrollArea,QWidget,QFormLayout,QLineEdit,QTabWidget)
from ..design.widgets import qss
from . import practice,tasks


class Calculation(QThread):
    def __init__(self,fn,parent):
        super().__init__(parent)
        self.fn=fn
        self.value,self.error=None,None

    def run(self):
        try:
            self.value=self.fn()
        except Exception as exc:
            self.error=str(exc)


class PracticeDialog(QDialog):
    variant_ready=Signal(object)

    def __init__(self,lesson,parent=None,reference=None):
        super().__init__(parent)
        self.lesson=copy.deepcopy({k:v for k,v in lesson.items() if not k.startswith('_')})
        self.reference=reference or lesson.get('ticket',{})
        spec=lesson.get('task')
        self.specs=spec if isinstance(spec,list) else [spec] if isinstance(spec,dict) else []
        self.worker=None
        self.pending=None
        self.setObjectName('jw2')
        self.setWindowTitle('检查步骤与改条件重算')
        self.setStyleSheet(qss())
        self.resize(820,720)
        root=QVBoxLayout(self)
        note=QLabel('先核对抽取参数。只比较能复算的量；未识别的步骤不判为正确。典型错误数值只能提示可能原因。')
        note.setWordWrap(True)
        root.addWidget(note)
        self.select=QComboBox()
        for s in self.specs:
            self.select.addItem(tasks.REG.get(s.get('kind'),{}).get('title',s.get('kind','题型')))
        root.addWidget(self.select)
        tabs=QTabWidget()
        root.addWidget(tabs,1)
        check=QWidget()
        cl=QVBoxLayout(check)
        self.labels=QLabel('可核对量：计算后显示；一行一个“量名=数值”，可附单位。')
        self.labels.setWordWrap(True)
        cl.addWidget(self.labels)
        self.student=QPlainTextEdit()
        self.student.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.student.setPlaceholderText('例如：\n支持力=16 N\n加速度=6 m/s²\n也可粘贴自己的步骤；无法识别的内容会保留但不作判断。')
        cl.addWidget(self.student)
        self.check=QPushButton('检查并保存我的步骤')
        self.check.clicked.connect(self.diagnose)
        cl.addWidget(self.check)
        tabs.addTab(check,'检查步骤')
        variant=QWidget()
        vl=QVBoxLayout(variant)
        hint=QLabel('仅修改下列参数；新答案和图解一起重算，原题与原记录保留。未列出的条件暂不支持修改。')
        hint.setWordWrap(True)
        vl.addWidget(hint)
        self.scroll=QScrollArea()
        self.scroll.setWidgetResizable(True)
        vl.addWidget(self.scroll,1)
        self.recalc=QPushButton('按新条件计算')
        self.recalc.clicked.connect(self.recalculate)
        vl.addWidget(self.recalc)
        tabs.addTab(variant,'改条件重算')
        self.output=QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setMaximumHeight(220)
        root.addWidget(self.output)
        self.open=QPushButton('打开新的答案与图解')
        self.open.setEnabled(False)
        self.open.clicked.connect(self.show_variant)
        root.addWidget(self.open)
        self.select.currentIndexChanged.connect(self.form)
        self.form()

    def form(self):
        self.pending=None
        self.open.setEnabled(False)
        host=QWidget()
        form=QFormLayout(host)
        self.edits=[]
        index=self.select.currentIndex()
        fs=practice.fields(self.specs[index]) if index>=0 else []
        for f in fs:
            edit=QLineEdit(str(f['value']))
            edit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
            form.addRow(f['label'],edit)
            self.edits.append((f['path'],edit))
        self.scroll.setWidget(host)
        self.recalc.setEnabled(bool(fs))
        self.check.setEnabled(bool(self.specs))
        self.labels.setText('正在建立可核对量；只识别明确的“量名=结果”。')
        self.start(lambda:practice.checkpoints(self.specs[index]),self.show_quantities) if index>=0 else None

    def show_quantities(self,t):
        self.labels.setText('可核对量：'+'、'.join(r['prompt'] for r in t['rows'])+'。每行写“量名=结果”。')

    def start(self,fn,done):
        if self.worker is not None and self.worker.isRunning():
            return
        self.check.setEnabled(False)
        self.recalc.setEnabled(False)
        self.select.setEnabled(False)
        worker=Calculation(fn,self)
        self.worker=worker
        def finished():
            self.select.setEnabled(True)
            self.check.setEnabled(bool(self.specs))
            self.recalc.setEnabled(bool(self.edits))
            if worker.error:
                self.output.setPlainText('无法可靠完成：'+worker.error)
            else:
                done(worker.value)
        worker.finished.connect(finished)
        worker.start()

    def diagnose(self):
        text=self.student.toPlainText()
        spec=copy.deepcopy(self.specs[self.select.currentIndex()])
        def done(report):
            lines=[report['conclusion'],report['cause'],report['scope']]
            for r in report['checked']:
                lines.append(f"第{r['line']}行 {r['label']}：{'相符' if r['ok'] else '不符'}；程序结果 {r['expected']}")
            try:
                practice.save_attempt(self.reference,text,report)
                lines.append('已保存作答记录。')
            except Exception:
                lines.append('核对已完成，但记录未能保存；原记录未覆盖。')
            self.output.setPlainText('\n'.join(lines))
        self.start(lambda:practice.diagnose(spec,text),done)

    def recalculate(self):
        self.pending=None
        self.open.setEnabled(False)
        changes=[(path,edit.text()) for path,edit in self.edits]
        index=self.select.currentIndex()
        def done(value):
            self.pending=value
            self.output.setPlainText(value['answer']+'\n\n'+'\n'.join(value['steps']))
            self.open.setEnabled(True)
        self.start(lambda:practice.variant(self.lesson,index,changes),done)

    def show_variant(self):
        if self.pending:
            self.variant_ready.emit(self.pending)
            self.accept()

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            event.ignore()
        else:
            super().closeEvent(event)

    def reject(self):
        if self.worker is None or not self.worker.isRunning():
            super().reject()
