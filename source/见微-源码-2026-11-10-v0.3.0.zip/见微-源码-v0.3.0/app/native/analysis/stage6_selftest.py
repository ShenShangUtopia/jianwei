"""Stage 6 deterministic UI, science, lifetime and timing privacy checks."""
import json
import math
import sys
from pathlib import Path
from unittest.mock import patch
from ..kit import test_runtime

test_runtime.configure()


def main(output=None):
    app=test_runtime.application()
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    from ..design import tokens
    from .figure.curated_next import SIGNATURES,for_question
    from .figure.view import FigureView
    from .figure.links import linkify
    from . import tasks,timing
    from .physics_clock import make
    from ..kit.home import home
    from ..lecture.local_diagram import resolve
    from ..lecture.panel import LookupPanel
    from ..lecture import lookup
    questions=json.loads((Path(__file__).parents[1]/'bank/questions.json').read_text(encoding='utf-8'))
    figures={}
    for q in questions:
        if q['id'] not in SIGNATURES:
            continue
        f=for_question(q)
        assert f and not for_question(dict(q,answer=q['answer']+' changed'))
        figures[q['id']]=f
        assert resolve(q['stem'])==f
        assert resolve(q['stem']+' 123') is None
        for theme in ('day','night'):
            tokens.set_theme(theme)
            view=FigureView(f)
            view.resize(1050,800)
            view.show()
            for i in range(len(f['steps'])):
                view.go(i)
                app.processEvents()
                assert not view.image().isNull() and not view.canvas.error
            view.grab().save(str(out/(q['id']+'-'+theme+'.png')))
            svg=view.svg()
            ids={l['id'] for l in f['layers']}
            view.set_hover(ids|{'not-real'})
            assert view.hover_ids<=ids and view.svg()==svg
            view.set_hover([])
            if q['id']=='p-2023-b-08':
                view.go(1)
                assert 'jwlayer:radius' in view.caption.text()
                view.caption.linkHovered.emit('jwlayer:radius')
                assert view.hover_ids=={'radius'}
                view.go(0)
                assert not view.hover_ids
            view.close()
    assert len(figures)==6
    bars=[l for l in figures['c-2023-qgy-13']['layers'] if l['type']=='bar']
    assert len(bars)==2 and all(l['scale_max']==2 for l in bars)
    from .figure.schema import validate,FigureError
    broken=json.loads(json.dumps(figures['c-2023-qgy-13']))
    next(l for l in broken['layers'] if l['type']=='bar')['scale_max']='bad'
    try:
        validate(broken)
        raise AssertionError('bar scale must be numeric')
    except FigureError:
        pass
    f=figures['p-2023-b-08']
    linked=linkify('<b>半径 r</b> <a href="x">半径</a> &lt;script&gt;',f)
    assert 'jwlayer:radius' in linked and '<a href="x">半径</a>' in linked and '&lt;script&gt;' in linked
    from .page import AnalysisPage
    from PySide6.QtWidgets import QLabel
    page=AnalysisPage()
    page._on_done(page.rev,dict(figure=f,subject='物理',summary='核对半径与周期',answer='半径由程序核对',steps=['半径与周期分别求解'],problem='合成界面检查'))
    label=next(lb for lb in page.findChildren(QLabel) if 'jwlayer:radius' in lb.text())
    label.linkHovered.emit('jwlayer:radius')
    assert page.figure_view.hover_ids=={'radius'}
    label.linkHovered.emit('')
    assert not page.figure_view.hover_ids
    page.shutdown()
    page.close()
    for kind,spec in [('projectile',dict(v0=20,angle=30,h0=0,g=10)),('incline',dict(angle=30,mu=.2,m=2,L=4,g=10))]:
        result=tasks.build(dict(kind=kind,asks=[dict(what='time')],**spec))
        assert result['ok'] and not result['result']['failed_checks']
        clock=make(result['result'])
        clock.resize(1000,540)
        clock.show()
        clock.slider.setValue(500)
        state=clock.state_at(clock.time)
        if kind=='projectile':
            assert math.isclose(clock.duration,2) and abs(state['v'])<1e-10
        else:
            assert math.isclose(clock.acc,5-math.sqrt(3))
            assert math.isclose(state['v'],clock.acc*clock.time)
        app.processEvents()
        clock.grab().save(str(out/(kind+'-clock.png')))
        clock.toggle()
        assert clock.timer.isActive()
        clock.hide()
        assert not clock.timer.isActive()
        clock.close()
    assert make(tasks.build(dict(kind='incline',angle=30,v0=2,asks=[dict(what='a')]))['result']) is None
    long=tasks.build(dict(kind='projectile',v0=1e7,angle=30,g=10,asks=[dict(what='time')]))
    assert long['ok'] and not long['result']['failed_checks']
    assert not timing.write(dict(total_ms=1))
    assert not (home()/'logs/analysis-timing.jsonl').exists()
    secret='SYNTHETIC-NOT-A-REAL-KEY'
    assert timing.write(dict(total_ms=12,first_packet_ms=float('nan'),engine=secret,prompt=secret,answer=secret,key=secret,status='ok'),force=True)
    raw=(home()/'logs/analysis-timing.jsonl').read_text(encoding='utf-8')
    event=json.loads(raw)
    assert secret not in raw and event['first_packet_ms'] is None and event['engine']=='other'
    assert set(event)=={'v','id','total_ms','first_native_ms','first_condition_ms','first_packet_ms','engine','status','schema_repairs'}
    with patch.object(lookup.Lookup,'start',return_value=1),patch.object(lookup.Lookup,'cancel'):
        panel=LookupPanel(None)
        panel.resize(500,900)
        panel.show()
        rev=panel.diagram_revision
        panel._on_diagram(rev,figures['p-2023-b-08'])
        assert panel.diagram_view is not None
        app.processEvents()
        panel.grab().save(str(out/'lookup-inline.png'))
        panel._reset()
        panel._on_diagram(rev,figures['p-2023-b-08'])
        assert panel.diagram_view is None
        panel.close_panel()
        panel._on_diagram(panel.diagram_revision-1,f)
        assert panel.diagram_view is None
        panel.close()
    for concept in ('光合作用','细胞器','全反射'):
        figure=resolve(concept)
        view=FigureView(figure)
        assert not view.image().isNull()
        view.close()
    assert resolve('未知题目') is None
    tokens.set_theme('day')
    print('STAGE6 OK six signed bank diagrams/day-night, hover export invariance, two shared clocks, full-text local lookup and stale tickets, allowlisted timing; no network',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
