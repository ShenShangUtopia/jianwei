"""题型图解的外框与画笔（由 gewu/viz.js 改写）：640×360 的虚拟画布，等比缩放，分步翻页，昼夜跟随。"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QFontMetricsF, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout, QWidget

from ..design.tokens import T, alpha, font, qc
from . import solver as Solver

W, H = 640, 360
SUBS, SUPS = "₀₁₂₃₄₅₆₇₈₉", "⁰¹²³⁴⁵⁶⁷⁸⁹"


def N(v, d=4):
    if v is None or not isinstance(v, (int, float)) or not math.isfinite(v):
        return "—"
    s = f"{float(f'{v:.{d}g}'):.12g}"
    return s


def X(v):
    return (math.isfinite(v) and Solver.exact(v)) or N(v)


def nice(r):
    p = 10 ** math.floor(math.log10(r or 1))
    m = r / p
    return (1 if m < 1.5 else 2 if m < 3.5 else 5 if m < 7.5 else 10) * p


def PAL(n):
    return [T.c1, T.c2, T.c3, T.c4, T.c5, T.c6][n % 6]


def sub_n(n):
    return "".join(SUBS[int(c)] for c in str(n))


def sup_n(n):
    return "".join(SUPS[int(c)] for c in str(n))


def cap_of(t, i):
    rows = t["rows"]
    return f"{rows[i]['prompt']}：{rows[i]['text']}" if i < len(rows) else ""


# 样式名 → (颜色, 线宽, 虚线)；颜色在绘制时才取，昼夜切换立刻生效
def _style(cls):
    return {
        "grid": (T.grid2, 1, None), "axis": (T.axis, 1.2, None), "curve": (T.fg, 2.2, None), "up": (T.ok, 2.4, None), "down": (T.bad, 2.4, None), "faint": (alpha(qc(T.muted), 0.6), 1.2, None),
        "hl1": (T.accent, 2, None), "hl2": (T.c2, 2, None), "hl3": (T.c3, 1.6, None), "thick1": (T.accent, 3, None), "thick2": (T.c2, 3, None), "thick3": (T.c3, 3, None), "dash": (T.muted, 1, [4, 4]), "hl3dash": (T.c3, 1.2, [4, 4]),
        "edge": (T.fg, 1.6, None), "hidden": (alpha(qc(T.muted), 0.7), 1.1, [4, 4]), "hbond": (T.muted, 1, None), "flow": (T.muted, 1.4, None), "on": (T.accent, 2.6, None), "off": (alpha(qc(T.muted), 0.3), 1.2, None), "codon": (T.muted, 1.2, None),
    }.get(cls, (T.fg, 1.2, None))


class Pen2:
    """虚拟画布上的画笔：所有坐标都按 640×360 写。"""

    def __init__(self, p: QPainter):
        self.p = p

    def path_stroke(self, path, cls="curve", color=None, width=None):
        col, w, dash = _style(cls)
        pen = QPen(qc(color if color is not None else col), width or w)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        if dash:
            pen.setDashPattern([v / max(0.5, pen.widthF()) for v in dash])
        self.p.strokePath(path, pen)

    def line(self, x1, y1, x2, y2, cls="grid", color=None):
        path = QPainterPath(QPointF(x1, y1))
        path.lineTo(x2, y2)
        self.path_stroke(path, cls, color)

    def poly_line(self, pts, cls="curve", color=None, width=None):
        path = QPainterPath()
        pen = False
        for q in pts:
            if q is None:
                pen = False
                continue
            if pen:
                path.lineTo(q[0], q[1])
            else:
                path.moveTo(q[0], q[1])
                pen = True
        self.path_stroke(path, cls, color, width)

    def fill_poly(self, pts, color, a=None):
        if not pts:
            return
        path = QPainterPath(QPointF(pts[0][0], pts[0][1]))
        for q in pts[1:]:
            path.lineTo(q[0], q[1])
        path.closeSubpath()
        col = qc(color)
        self.p.fillPath(path, alpha(col, a) if a is not None else col)

    def dot(self, x, y, color=None, r=4.5, ring=None):
        self.p.setPen(QPen(qc(ring), 1.4) if ring else Qt.PenStyle.NoPen)
        self.p.setBrush(qc(color or T.fg))
        self.p.drawEllipse(QPointF(x, y), r, r)

    def ring(self, x, y, r, color=None, width=1.8):
        self.p.setPen(QPen(qc(color or T.accent), width))
        self.p.setBrush(Qt.BrushStyle.NoBrush)
        self.p.drawEllipse(QPointF(x, y), r, r)

    def rect(self, x, y, w, h, fill=None, stroke=None, rx=0, a=None, lw=1):
        self.p.setPen(QPen(qc(stroke), lw) if stroke else Qt.PenStyle.NoPen)
        if fill is None:
            self.p.setBrush(Qt.BrushStyle.NoBrush)
        else:
            col = qc(fill)
            self.p.setBrush(alpha(col, a) if a is not None else col)
        self.p.drawRoundedRect(QRectF(x, y, max(0, w), max(0, h)), rx, rx)

    def txt(self, x, y, s, size=12, color=None, anchor="middle", bold=False, mono=False):
        """y 是基线（和 SVG text 一样）。"""
        s = str(s)
        f = font(size, 600 if bold else 400, "mono" if mono else "ui")
        tw = QFontMetricsF(f).horizontalAdvance(s)
        x0 = x - (tw / 2 if anchor == "middle" else tw if anchor == "end" else 0)
        self.p.setFont(f)
        self.p.setPen(qc(color or T.fg))
        self.p.drawText(QPointF(x0, y), s)

    def label(self, x, y, s, anchor="middle"):
        self.txt(x, y, s, 12, T.fg, anchor)

    def strong(self, x, y, s, anchor="middle"):
        self.txt(x, y, s, 12, T.fg, anchor, True)

    def small(self, x, y, s, anchor="middle"):
        self.txt(x, y, s, 11, T.muted, anchor)

    def tick(self, x, y, s, anchor="middle"):
        self.txt(x, y, s, 10, T.muted, anchor)

    def title(self, x, y, s):
        self.txt(x, y, s, 15, T.fg, "middle", True)

    def th(self, x, y, s, anchor="middle"):
        self.txt(x, y, s, 12, T.muted, anchor, True)


class Plot:
    """直角坐标系：映射函数 + 网格、坐标轴、刻度。"""

    def __init__(self, x0, x1, y0, y1, L=46, h=None, xstep=None, no_x=False, no_y_axis=False):
        self.x0, self.x1, self.y0, self.y1 = x0, x1, y0, y1
        self.L, self.T = L, 14
        self.w, self.h = W - L - 14, (h or H) - 14 - 26
        self.xs = xstep or nice((x1 - x0) / 8)
        self.ys = nice((y1 - y0) / 6)
        self.no_x, self.no_y_axis = no_x, no_y_axis

    def sx(self, x):
        return self.L + (x - self.x0) / (self.x1 - self.x0) * self.w

    def sy(self, y):
        return self.T + self.h - (y - self.y0) / (self.y1 - self.y0) * self.h

    def draw(self, P: Pen2):
        v = math.ceil(self.x0 / self.xs) * self.xs
        while v <= self.x1 + 1e-9:
            P.line(self.sx(v), self.T, self.sx(v), self.T + self.h, "grid")
            if not self.no_x:
                P.tick(self.sx(v), self.T + self.h + 16, N(v, 3))
            v += self.xs
        v = math.ceil(self.y0 / self.ys) * self.ys
        while v <= self.y1 + 1e-9:
            P.line(self.L, self.sy(v), self.L + self.w, self.sy(v), "grid")
            P.tick(self.L - 6, self.sy(v) + 4, N(v, 3), "end")
            v += self.ys
        if self.x0 <= 0 <= self.x1 and not self.no_y_axis:
            P.line(self.sx(0), self.T, self.sx(0), self.T + self.h, "axis")
        if self.y0 <= 0 <= self.y1:
            P.line(self.L, self.sy(0), self.L + self.w, self.sy(0), "axis")

    def clip(self, P: Pen2):
        P.p.setClipRect(QRectF(self.L, self.T, self.w, self.h))

    def unclip(self, P: Pen2):
        P.p.setClipping(False)


class VizCanvas(QWidget):
    def __init__(self, owner):
        super().__init__()
        self.owner = owner
        self.setMinimumHeight(230)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.err = None

    def sizeHint(self):  # noqa: N802
        from PySide6.QtCore import QSize
        return QSize(W, H)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        k = min(self.width() / W, self.height() / H)
        p.translate((self.width() - W * k) / 2, (self.height() - H * k) / 2)
        p.scale(k, k)
        try:
            self.owner.draw_fn(Pen2(p), self.owner.k)
        except Exception as exc:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            self.err = f"{type(exc).__name__}: {exc}"
            p.setClipping(False)
            p.setPen(qc(T.bad))
            p.drawText(QPointF(16, 30), f"图解出错：{self.err}")
        p.end()

    def mousePressEvent(self, e):  # noqa: N802
        if self.owner.drag_fn:
            self.owner.drag_fn("down", e.position().x(), e.position().y())

    def mouseMoveEvent(self, e):  # noqa: N802
        if self.owner.drag_fn and e.buttons():
            self.owner.drag_fn("move", e.position().x(), e.position().y())
            self.update()


class VizFrame(QWidget):
    """外框：标题、当前步说明、翻页。stages 是每步一句话。"""

    def __init__(self, title, stages, draw_fn, hint="", drag_fn=None, k0=0):
        super().__init__()
        self.stages, self.draw_fn, self.drag_fn = stages, draw_fn, drag_fn
        self.k = min(k0, len(stages) - 1)
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(4)
        top = QHBoxLayout()
        t = QLabel(f"<b>{title}</b>")
        top.addWidget(t)
        top.addStretch(1)
        self.prev, self.next_ = QPushButton("‹"), QPushButton("›")
        self.all_ = QPushButton("全部")
        self.info = QLabel()
        self.info.setObjectName("note")
        for b in (self.prev, self.next_):
            b.setFixedWidth(30)
        self.prev.clicked.connect(lambda: self.go(self.k - 1))
        self.next_.clicked.connect(lambda: self.go(self.k + 1))
        self.all_.clicked.connect(lambda: self.go(len(self.stages) - 1))
        for w in (self.prev, self.info, self.next_, self.all_):
            top.addWidget(w)
        v.addLayout(top)
        self.cap = QLabel()
        self.cap.setWordWrap(True)
        self.cap.setObjectName("note")
        v.addWidget(self.cap)
        self.canvas = VizCanvas(self)
        v.addWidget(self.canvas, 1)
        if hint:
            h = QLabel(hint)
            h.setObjectName("note")
            v.addWidget(h)
        self.go(self.k)

    def go(self, k):
        self.k = max(0, min(len(self.stages) - 1, k))
        self.cap.setText(self.stages[self.k])
        self.info.setText(f"{self.k + 1} / {len(self.stages)}")
        self.prev.setEnabled(self.k > 0)
        last = self.k < len(self.stages) - 1
        self.next_.setEnabled(last)
        self.all_.setEnabled(last)
        self.canvas.update()
