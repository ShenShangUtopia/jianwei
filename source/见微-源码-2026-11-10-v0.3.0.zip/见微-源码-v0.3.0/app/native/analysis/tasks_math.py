"""数学题型：函数分析、直线与曲线、立体几何（坐标法）、概率分布、数列。"""
from __future__ import annotations

import json
import math
import re

from . import solver as Solver
from .task_core import P, asks_of, fail, fmt_n, fmt_x, info_row, is_int, isf, need_num, num, num_row, reg, roots, with_exact

_DOC_FUNC = """{"kind":"func","f":"x^3-3*x","domain":[-3,3],"asks":[{"prompt":"极大值","what":"local_max","claimed":[2]}]}
  f 以 x 为自变量，语法同方程模型（ln、exp、sqrt、abs、sin…，乘号要写）；domain 为讨论区间（没有限制就省略，程序在 [-20,20] 内搜索）。
  what：value / derivative（在 "x" 处的函数值 / 导数值）、tangent（在 "x" 处的切线，claimed 写 "y=3x-2"）、zeros（全部零点，claimed 写数组）、local_max / local_min（全部极大值 / 极小值，数组）、max / min（domain 上的最大 / 最小值）、monotonic（单调区间，仅展示）、integral（"a" 到 "b" 的定积分）、range（domain 上的值域，仅展示）"""


@reg("func", "数学", "函数分析", _DOC_FUNC)
def run_func(s):
    try:
        f = Solver.fn(str(s.get("f") or ""), ["x"])
    except Solver.ExprError as e:
        fail(f"f「{s.get('f')}」：{e}")
    dom = s.get("domain")
    given = isinstance(dom, list) and len(dom) == 2
    a, b = (need_num(dom[0], "domain[0]"), need_num(dom[1], "domain[1]")) if given else (-20.0, 20.0)
    if not a < b:
        fail("domain 必须是 [左端点, 右端点]，且左 < 右")

    def d(x):
        h = 1e-5 * max(1, abs(x))
        return (f(x + h) - f(x - h)) / (2 * h)
    zs, cr = roots(f, a, b, 3000), roots(d, a, b, 3000)
    kinds = []
    for x in cr:
        h = 1e-4 * max(1, abs(x)) + 1e-6
        lv, rv = d(x - h), d(x + h)
        kinds.append("max" if lv > 0 and rv < 0 else "min" if lv < 0 and rv > 0 else "")
    ext = [dict(x=x, y=f(x), t=kinds[i]) for i, x in enumerate(cr) if kinds[i]]
    N = 4000
    samp = [(a + (b - a) * i / N, f(a + (b - a) * i / N)) for i in range(N + 1)]
    cand = [p for p in samp + [(e["x"], e["y"]) for e in ext] + [(a, f(a)), (b, f(b))] if isf(p[1])]

    def best(w):
        return (max if w == "max" else min)(cand, key=lambda p: p[1]) if cand else (a, math.nan)

    def at_edge(p):
        return not given and (abs(p[0] - a) < 1e-6 or abs(p[0] - b) < 1e-6)
    rows = []
    for q in asks_of(s, ["value", "derivative", "tangent", "zeros", "local_max", "local_min", "max", "min", "monotonic", "integral", "range"]):
        w = q["what"]

        def X():
            return need_num(q.get("x"), f"{w} 的 x")
        if w == "value":
            rows.append(num_row(q, f(X())))
        elif w == "derivative":
            rows.append(num_row(q, d(X())))
        elif w == "tangent":
            x0 = X()
            k = d(x0)
            bb = f(x0) - k * x0
            kk = 0 if abs(k) < 1e-10 else k
            text = f"y = {'' if kk == 0 else fmt_x(kk) + 'x'}{fmt_x(bb) if kk == 0 else '' if abs(bb) < 1e-12 else (' + ' if bb > 0 else ' - ') + fmt_x(abs(bb))}"
            rows.append(dict(prompt=P(q), kind="line", value=dict(k=kk, b=bb), text=text, claimed=q.get("claimed")))
        elif w == "zeros":
            rows.append(dict(prompt=P(q), kind="nums", value=zs, text="，".join(fmt_x(z) for z in zs) or "无零点", claimed=q.get("claimed")))
        elif w in ("local_max", "local_min"):
            v = [e for e in ext if e["t"] == w[6:]]
            rows.append(dict(prompt=P(q), kind="nums", value=[e["y"] for e in v], text="，".join(f"{fmt_x(e['y'])}（x = {fmt_x(e['x'])}）" for e in v) or "没有", claimed=q.get("claimed")))
        elif w in ("max", "min"):
            p = best(w)
            if at_edge(p):
                rows.append({**num_row(q, math.nan), "text": f"在搜索范围内没有{'最大' if w == 'max' else '最小'}值（趋向端点）"})
            else:
                rows.append({**num_row(q, p[1]), "text": f"{with_exact(p[1])}（x = {fmt_x(p[0])}）"})
        elif w == "monotonic":
            pts = [a] + [e["x"] for e in ext] + [b]
            inc, dec = [], []
            for i in range(len(pts) - 1):
                m = (pts[i] + pts[i + 1]) / 2
                iv = f"({fmt_x(pts[i]) if given or i else '-∞'}, {fmt_x(pts[i + 1]) if given or i + 2 < len(pts) else '+∞'})"
                (inc if d(m) > 0 else dec).append(iv)
            rows.append(info_row(q, f"增区间：{'、'.join(inc) or '无'}；减区间：{'、'.join(dec) or '无'}"))
        elif w == "integral":
            lo, hi = need_num(q.get("a"), "integral 的 a"), need_num(q.get("b"), "integral 的 b")
            n = 4000
            h = (hi - lo) / n
            total = f(lo) + f(hi) + sum((4 if i % 2 else 2) * f(lo + i * h) for i in range(1, n))
            rows.append(num_row(q, total * h / 3))
        else:
            lo, hi = best("min"), best("max")
            rows.append(info_row(q, f"[{fmt_x(lo[1])}, {fmt_x(hi[1])}]{'' if given else '（在 [-20,20] 内）'}"))
    asks = s["asks"]
    tang = []
    for q in asks:
        if q["what"] == "tangent":
            x0 = num(q.get("x"))
            k = d(x0)
            tang.append(dict(x0=x0, k=k, b=f(x0) - k * x0))
    ints = [dict(lo=num(q.get("a")), hi=num(q.get("b"))) for q in asks if q["what"] == "integral"]
    marks = [dict(x=num(q.get("x")), y=f(num(q.get("x")))) for q in asks if q["what"] in ("value", "derivative")]
    mm = []
    for q in asks:
        if q["what"] in ("max", "min"):
            p = best(q["what"])
            if not at_edge(p):
                mm.append(dict(x=p[0], y=p[1], t=q["what"]))
    stat = "，".join(f"x = {fmt_x(x)}{'（极大）' if kinds[i] == 'max' else '（极小）' if kinds[i] == 'min' else '（非极值）'}" for i, x in enumerate(cr))
    return dict(rows=rows, viz=dict(f=str(s["f"]), a=a, b=b, given=given, zeros=zs, ext=ext, tang=tang, ints=ints, marks=marks, mm=mm),
                detail=[f"f(x) = {s['f']}，讨论区间 {f'[{fmt_x(a)}, {fmt_x(b)}]' if given else '[-20, 20]（题目未限定）'}", f"零点：{'，'.join(fmt_x(z) for z in zs) or '无'}", f"驻点：{stat or '无'}"])


_DOC_CONIC = """{"kind":"conic","curve":"x^2/16+y^2/9=1","line":"y=x+1","point":[0,0],"asks":[{"prompt":"弦长|AB|","what":"chord","claimed":"24√2/25"}]}
  curve 是曲线方程（含 x、y，圆、椭圆、双曲线、抛物线都行），line 是直线方程（"y=kx+b"、"x=2"、"x-2y+1=0" 均可）。参数已知后代入具体数值；含参数的「取值范围」类问题不要用这个题型。
  what：intersections（交点坐标，claimed 写 [[x1,y1],[x2,y2]]）、count（交点个数）、chord（弦长）、midpoint（弦中点 [x,y]）、area（以 point 为顶点、弦为底的三角形面积，point 默认原点）、distance（point 到直线的距离）"""


def eq_fn(st, name):
    p = str("" if st is None else st).split("=")
    if len(p) != 2:
        fail(f"{name} 必须是含一个等号的方程（收到 {json.dumps(st, ensure_ascii=False)}）")
    try:
        return Solver.fn(f"({p[0]})-({p[1]})", ["x", "y"])
    except Solver.ExprError as e:
        fail(f"{name}「{st}」：{e}")


@reg("conic", "数学", "直线与曲线", _DOC_CONIC)
def run_conic(s):
    F, G = eq_fn(s.get("curve"), "curve"), eq_fn(s.get("line"), "line")
    C0 = G(0, 0)
    A, B = G(1, 0) - C0, G(0, 1) - C0
    if abs(G(2, 3) - (2 * A + 3 * B + C0)) > 1e-9 * (1 + abs(A) + abs(B) + abs(C0)) or (A == 0 and B == 0):
        fail(f"line「{s.get('line')}」不是直线方程")
    O = [need_num(v, f"point[{i}]") for i, v in enumerate(s["point"])] if isinstance(s.get("point"), list) else [0.0, 0.0]
    nrm = math.hypot(A, B)
    dx, dy = B / nrm, -A / nrm
    p0 = (0, -C0 / B) if abs(B) > abs(A) else (-C0 / A, 0)

    def H(t):
        return F(p0[0] + t * dx, p0[1] + t * dy)
    # 先粗扫（±500 太大的话细节会漏）：曲线在近处，分两段扫
    ts = roots(H, -60, 60, 12000)
    ts += [t for t in roots(H, -500, -60, 4000) + roots(H, 60, 500, 4000) if not any(abs(t - z) < 1e-6 for z in ts)]
    pts = [[0 if abs(v) < 1e-12 else v for v in (p0[0] + t * dx, p0[1] + t * dy)] for t in sorted(ts)]
    two = len(pts) == 2
    rows = []
    for q in asks_of(s, ["intersections", "count", "chord", "midpoint", "area", "distance"]):
        w = q["what"]
        if w == "intersections":
            rows.append(dict(prompt=P(q), kind="points", value=pts, text="、".join(f"({fmt_x(p[0])}, {fmt_x(p[1])})" for p in pts) or "没有交点", claimed=q.get("claimed")))
        elif w == "count":
            rows.append(num_row(q, len(pts)))
        elif w == "chord":
            rows.append(num_row(q, math.hypot(pts[0][0] - pts[1][0], pts[0][1] - pts[1][1])) if two else {**num_row(q, math.nan), "text": f"交点有 {len(pts)} 个，不构成弦"})
        elif w == "midpoint":
            if two:
                m = [(pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2]
                rows.append(dict(prompt=P(q), kind="point", value=m, text=f"({fmt_x(m[0])}, {fmt_x(m[1])})", claimed=q.get("claimed")))
            else:
                rows.append({**num_row(q, math.nan), "text": "交点不是两个"})
        elif w == "area":
            rows.append(num_row(q, abs((pts[0][0] - O[0]) * (pts[1][1] - O[1]) - (pts[1][0] - O[0]) * (pts[0][1] - O[1])) / 2) if two else {**num_row(q, math.nan), "text": "交点不是两个"})
        else:
            rows.append(num_row(q, abs(A * O[0] + B * O[1] + C0) / nrm))
    return dict(rows=rows, viz=dict(curve=str(s["curve"]), line=str(s["line"]), pts=pts, O=O, A=A, B=B, C=C0, whats=[q["what"] for q in s["asks"]]),
                detail=[f"曲线 {s['curve']}，直线 {s['line']}", f"交点：{'、'.join(f'({fmt_x(p[0])}, {fmt_x(p[1])})' for p in pts) or '无'}"])


_DOC_SOLID = """{"kind":"solid","points":{"A":[0,0,0],"B":[2,0,0],"C":[2,2,0],"A1":[0,0,2]},"given":[{"seg":["A","B"],"length":2},{"perp":[["A","B"],["A","A1"]]}],"asks":[{"what":"angle_line_plane","line":["A1","C"],"plane":["A","B","C"],"claimed":0.5774}]}
  先建立空间直角坐标系，把用到的点的坐标写进 points（点名照题目，A₁ 写 A1）；given 列出题目中可核对的条件（seg+length 棱长、perp 两线段垂直、parallel 两线段平行），程序会检查坐标是否满足，不满足会退回。
  what：distance（"between":[P,Q]）、angle_lines（"lines":[[P,Q],[R,S]]，两直线夹角）、angle_line_plane（"line":[P,Q]，"plane":[R,S,T]）、dihedral（二面角：给 "edge":[P,Q] 和 "faces":[R,S]（两个半平面上各一点）得到真实二面角；或给 "planes":[[…3点],[…3点]] 得到锐二面角）、distance_point_plane（"point":P，"plane":[R,S,T]）、volume（"points" 4 点为四面体；更多点时第一个为顶点、其余为底面多边形）、area（"points" 平面多边形）。
  角度类可加 "output"："cos"、"sin"、"tan"、"deg"（默认：线线、二面角给 cos，线面角给 sin）。"""


@reg("solid", "数学", "立体几何（坐标法）", _DOC_SOLID)
def run_solid(s):
    pts_raw = s.get("points")
    if not isinstance(pts_raw, dict) or not pts_raw:
        fail('points 必须是 {"点名":[x,y,z], …}')
    Pt = {}
    for k, v in pts_raw.items():
        if not isinstance(v, list) or len(v) != 3:
            fail(f"points.{k} 必须是 [x,y,z]")
        Pt[k] = [need_num(x, f"points.{k}[{i}]") for i, x in enumerate(v)]

    def get(n):
        if n not in Pt:
            fail(f"点「{n}」没有在 points 里给出坐标")
        return Pt[n]

    def sub(u, v):
        return [u[i] - v[i] for i in range(3)]

    def dot(u, v):
        return sum(u[i] * v[i] for i in range(3))

    def cross(u, v):
        return [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]

    def ln(u):
        return math.hypot(*u)

    def vec(pq, w):
        if not isinstance(pq, list) or len(pq) != 2:
            fail(f"{w} 必须是两个点名 [P,Q]")
        return sub(get(pq[1]), get(pq[0]))

    def normal(pl, w):
        if not isinstance(pl, list) or len(pl) != 3:
            fail(f"{w} 必须是平面上不共线的三个点名")
        n = cross(sub(get(pl[1]), get(pl[0])), sub(get(pl[2]), get(pl[0])))
        if ln(n) < 1e-12:
            fail(f"{w} 的三点共线，确定不了平面")
        return n
    bad = []
    given_list = s.get("given") if isinstance(s.get("given"), list) else []
    for i, g in enumerate(given_list):
        if not isinstance(g, dict):
            continue
        if g.get("seg") and g.get("length") is not None:
            L, want = ln(vec(g["seg"], f"given[{i}].seg")), num(g["length"])
            if isf(want) and not Solver.close(L, want):
                bad.append(f"|{''.join(g['seg'])}| 按坐标算是 {fmt_x(L)}，题目给的是 {g['length']}")
        if g.get("perp"):
            u, v = vec(g["perp"][0], f"given[{i}].perp[0]"), vec(g["perp"][1], f"given[{i}].perp[1]")
            if abs(dot(u, v)) > 1e-6 * ln(u) * ln(v):
                bad.append(f"{''.join(g['perp'][0])} 与 {''.join(g['perp'][1])} 按坐标并不垂直")
        if g.get("parallel"):
            u, v = vec(g["parallel"][0], f"given[{i}].parallel[0]"), vec(g["parallel"][1], f"given[{i}].parallel[1]")
            if ln(cross(u, v)) > 1e-6 * ln(u) * ln(v):
                bad.append(f"{''.join(g['parallel'][0])} 与 {''.join(g['parallel'][1])} 按坐标并不平行")
    if bad:
        fail(*[f"坐标与题目条件不符：{b}" for b in bad])

    def angle_out(q, c, default):
        o = q.get("output") or default
        th = math.acos(max(-1, min(1, c)))
        v = math.sin(th) if o == "sin" else math.tan(th) if o == "tan" else math.degrees(th) if o == "deg" else th if o == "rad" else math.cos(th)
        return {**num_row(q, v, "°" if o == "deg" else ""), "text": f"{with_exact(v)}{'°' if o == 'deg' else ''}（{'' if o == 'deg' else o + '，'}角 ≈ {fmt_n(math.degrees(th), 5)}°）"}

    def poly_area(names):
        p = [get(n) for n in names]
        n = [0.0, 0.0, 0.0]
        for i in range(1, len(p) - 1):
            c = cross(sub(p[i], p[0]), sub(p[i + 1], p[0]))
            n = [n[k] + c[k] for k in range(3)]
        return ln(n) / 2
    rows = []
    for q in asks_of(s, ["distance", "angle_lines", "angle_line_plane", "dihedral", "distance_point_plane", "volume", "area"]):
        w = q["what"]
        if w == "distance":
            rows.append(num_row(q, ln(vec(q.get("between"), "between"))))
        elif w == "angle_lines":
            ls = q.get("lines") or [None, None]
            u, v = vec(ls[0], "lines[0]"), vec(ls[1], "lines[1]")
            rows.append(angle_out(q, abs(dot(u, v)) / ln(u) / ln(v), "cos"))
        elif w == "angle_line_plane":
            u, n = vec(q.get("line"), "line"), normal(q.get("plane"), "plane")
            sn = abs(dot(u, n)) / ln(u) / ln(n)
            rows.append(angle_out(q, math.sqrt(max(0, 1 - sn * sn)), "sin"))
        elif w == "dihedral":
            if q.get("edge"):
                P0 = get(q["edge"][0])
                e = vec(q["edge"], "edge")
                ue = [x / ln(e) for x in e]

                def perp(n):
                    wv = sub(get(n), P0)
                    t = dot(wv, ue)
                    return sub(wv, [x * t for x in ue])
                faces = q.get("faces") or [None, None]
                u, v = perp(faces[0]), perp(faces[1])
                if ln(u) < 1e-12 or ln(v) < 1e-12:
                    fail("dihedral 的 faces 点不能在棱上")
                rows.append(angle_out(q, dot(u, v) / ln(u) / ln(v), "cos"))
            else:
                pl = q.get("planes") or [None, None]
                n1, n2 = normal(pl[0], "planes[0]"), normal(pl[1], "planes[1]")
                rows.append(angle_out(q, abs(dot(n1, n2)) / ln(n1) / ln(n2), "cos"))
        elif w == "distance_point_plane":
            n = normal(q.get("plane"), "plane")
            rows.append(num_row(q, abs(dot(sub(get(q.get("point")), get(q["plane"][0])), n)) / ln(n)))
        elif w == "volume":
            ps = q.get("points")
            if not isinstance(ps, list) or len(ps) < 4:
                fail("volume 的 points 至少 4 个点")
            if len(ps) == 4:
                a, b, c, d = [get(n) for n in ps]
                rows.append(num_row(q, abs(dot(sub(b, a), cross(sub(c, a), sub(d, a)))) / 6))
            else:
                base = ps[1:]
                n = normal(base[:3], "volume 的底面")
                h = abs(dot(sub(get(ps[0]), get(base[0])), n)) / ln(n)
                rows.append(num_row(q, poly_area(base) * h / 3))
        else:
            if not isinstance(q.get("points"), list) or len(q["points"]) < 3:
                fail("area 的 points 至少 3 个点")
            rows.append(num_row(q, poly_area(q["points"])))
    viz = dict(points=Pt, asks=[{k: q.get(k) for k in ("what", "between", "lines", "line", "plane", "edge", "faces", "planes", "point", "points")} for q in s["asks"]])
    return dict(rows=rows, viz=viz, detail=["坐标：" + "，".join(f"{k}({', '.join(fmt_x(x) for x in v)})" for k, v in Pt.items()), f"题目条件 {len(given_list)} 条，坐标全部满足" if given_list else "没有给出可核对的题目条件"])


def Phi(z):
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


def _C(n, k):
    n, k = round(n), round(k)
    return 0 if k < 0 or k > n else math.comb(n, k)


_DOC_PROB = """{"kind":"prob","dist":{"type":"binomial","n":5,"p":0.3},"asks":[{"what":"P","event":"X>=2","claimed":0.4718},{"what":"E"},{"what":"D"}]}
  dist.type：binomial（n, p）、hypergeometric（N 总数, M 其中“成功”的个数, n 抽取数）、normal（mu, sigma）、table（分布列："x":[…], "p":[…]，概率可写 "1/6"，和必须为 1）。
  what：P（"event" 写 "X=2"、"X>=2"、"X<3"、"1<=X<=3"）、E（期望）、D（方差）、pmf（分布列，仅展示）。计数问题（排列组合）请用方程模型，可用 comb(n,k)、perm(n,k)、fact(n)。"""


@reg("prob", "数学", "概率分布", _DOC_PROB)
def run_prob(s):
    D = s.get("dist")
    if not isinstance(D, dict):
        fail("dist 必须是对象，含 type")
    xs, ps, cdf = [], [], None
    ty = D.get("type")
    if ty == "binomial":
        n = int(need_num(D.get("n"), "dist.n", lambda x: x >= 1 and is_int(x) and x <= 500, "正整数"))
        p = need_num(D.get("p"), "dist.p", lambda x: 0 <= x <= 1, "0~1 之间的数")
        xs = list(range(n + 1))
        ps = [_C(n, k) * p ** k * (1 - p) ** (n - k) for k in xs]
        E, V, name = n * p, n * p * (1 - p), f"X ~ B({n}, {fmt_x(p)})"
    elif ty == "hypergeometric":
        N = int(need_num(D.get("N"), "dist.N", lambda x: is_int(x) and x >= 1, "正整数"))
        M = int(need_num(D.get("M"), "dist.M", lambda x: is_int(x) and 0 <= x <= N, "0~N 的整数"))
        n = int(need_num(D.get("n"), "dist.n", lambda x: is_int(x) and 1 <= x <= N, "1~N 的整数"))
        xs = list(range(max(0, n - (N - M)), min(n, M) + 1))
        ps = [_C(M, k) * _C(N - M, n - k) / _C(N, n) for k in xs]
        E = n * M / N
        V = n * (M / N) * (1 - M / N) * (N - n) / (N - 1) if N > 1 else 0
        name = f"X ~ H({N}, {M}, {n})"
    elif ty == "normal":
        mu = need_num(D.get("mu"), "dist.mu")
        sg = need_num(D.get("sigma"), "dist.sigma", lambda x: x > 0, "正数")
        cdf = lambda x: Phi((x - mu) / sg)   # noqa: E731
        E, V, name = mu, sg * sg, f"X ~ N({fmt_x(mu)}, {fmt_x(sg)}²)"
    elif ty == "table":
        if not isinstance(D.get("x"), list) or not isinstance(D.get("p"), list) or len(D["x"]) != len(D["p"]) or not D["x"]:
            fail('table 需要等长的 "x" 和 "p" 数组')
        xs = [need_num(v, f"dist.x[{i}]") for i, v in enumerate(D["x"])]
        ps = [need_num(v, f"dist.p[{i}]", lambda x: 0 <= x <= 1, "0~1 之间的数") for i, v in enumerate(D["p"])]
        if abs(sum(ps) - 1) > 1e-6:
            fail(f"分布列的概率之和是 {fmt_x(sum(ps))}，不等于 1")
        E = sum(x * ps[i] for i, x in enumerate(xs))
        V = sum((x - E) ** 2 * ps[i] for i, x in enumerate(xs))
        name = "分布列"
    else:
        fail("dist.type 只能是 binomial、hypergeometric、normal、table")
    last = {}

    def prob(ev):
        e = re.sub(r"\s", "", str("" if ev is None else ev)).replace("≥", ">=").replace("≤", "<=").replace("＝", "=")
        e = re.sub(r"ξ|η|Y", "X", e)
        lo, hi, lo_in, hi_in = -math.inf, math.inf, True, True
        m = re.match(r"^X(=|>=|<=|>|<)(.+)$", e)
        if m:
            v = Solver.eval_const(m.group(2))
            if not isf(v):
                fail(f"event「{ev}」读不懂")
            if m.group(1) == "=":
                lo = hi = v
            elif m.group(1)[0] == ">":
                lo, lo_in = v, m.group(1) == ">="
            else:
                hi, hi_in = v, m.group(1) == "<="
        else:
            m = re.match(r"^(.+?)(<=|<)X(<=|<)(.+)$", e)
            if not m:
                fail(f"event「{ev}」读不懂：请写成 X=2、X>=2、X<3、1<=X<=3 这样的形式")
            lo, hi = Solver.eval_const(m.group(1)), Solver.eval_const(m.group(4))
            lo_in, hi_in = m.group(2) == "<=", m.group(3) == "<="
            if not isf(lo) or not isf(hi):
                fail(f"event「{ev}」读不懂")
        last.update(lo=lo if isf(lo) else None, hi=hi if isf(hi) else None, lo_in=lo_in, hi_in=hi_in)
        if cdf:
            return (cdf(hi) if isf(hi) else 1) - (cdf(lo) if isf(lo) else 0)
        return sum(ps[i] for i, x in enumerate(xs) if (x > lo or (lo_in and abs(x - lo) < 1e-9)) and (x < hi or (hi_in and abs(x - hi) < 1e-9)))
    rows, evs = [], []
    for q in asks_of(s, ["P", "E", "D", "pmf"]):
        w = q["what"]
        ev = None
        if w == "P":
            rows.append(num_row(q, prob(q.get("event"))))
            ev = dict(last)
        elif w == "E":
            rows.append(num_row(q, E))
        elif w == "D":
            rows.append(num_row(q, V))
        else:
            rows.append(info_row(q, "连续分布没有分布列" if cdf else "；".join(f"P(X={fmt_x(x)}) = {fmt_x(ps[i])}" for i, x in enumerate(xs))))
        evs.append(ev)
    return dict(rows=rows, viz=dict(disc=not cdf, xs=xs, ps=ps, mu=E if cdf else None, sigma=math.sqrt(V) if cdf else None, E=E, V=V, name=name, whats=[q["what"] for q in s["asks"]], evs=evs), detail=[f"{name}，E(X) = {fmt_x(E)}，D(X) = {fmt_x(V)}"])


_DOC_SEQ = """{"kind":"seq","type":"recur","a1":1,"rule":"2*a+1","asks":[{"what":"term","n":10,"claimed":1023},{"what":"formula","formula":"2^n-1"}]}
  type：arith（"a1"、"d"）、geom（"a1"、"q"）、recur（"a1" 和递推 "rule"：用 a 表示 aₙ、n 表示项号，算出 aₙ₊₁；例如 aₙ₊₁ = 2aₙ + n 写 "2*a+n"）。已知条件需要先解出 a1、d 的，先算好再填。
  what：term（第 "n" 项）、sum（前 "n" 项和）、formula（检验你求出的通项公式 "formula"，含 n，程序逐项比对前 20 项）、sum_formula（检验前 n 项和公式）。"""


@reg("seq", "数学", "数列", _DOC_SEQ)
def run_seq(s):
    a1 = need_num(s.get("a1"), "a1")
    ty = s.get("type")
    if ty == "arith":
        d = need_num(s.get("d"), "d")
        nxt = lambda a, _n: a + d   # noqa: E731
    elif ty == "geom":
        q0 = need_num(s.get("q"), "q")
        nxt = lambda a, _n: a * q0   # noqa: E731
    elif ty == "recur":
        try:
            r = Solver.fn(str(s.get("rule") or ""), ["a", "n"])
        except Solver.ExprError as e:
            fail(f"rule「{s.get('rule')}」：{e}")
        nxt = r
    else:
        fail("type 只能是 arith、geom、recur")
    asks = asks_of(s, ["term", "sum", "formula", "sum_formula"])
    need = [int(need_num(q.get("n"), f"{q['what']} 的 n", lambda x: is_int(x) and 1 <= x <= 2000, "1~2000 的整数")) if q["what"] in ("term", "sum") else 20 for q in asks]
    N = max([20] + need)
    a, S = [math.nan, a1], [0.0, a1]
    for n in range(1, N):
        a.append(nxt(a[n], n))
        S.append(S[n] + a[n + 1])

    def check(q, arr, label):
        try:
            g = Solver.fn(str(q.get("formula") or ""), ["n"])
        except Solver.ExprError as e:
            fail(f"{q['what']} 的 formula「{q.get('formula')}」：{e}")
        for n in range(1, 21):
            v = g(n)
            if not isf(v) or not Solver.close(v, arr[n]):
                return dict(prompt=P(q), kind="check", ok=False, value=None, text=f"第 {n} 项不符：公式给 {fmt_x(v)}，{label}是 {fmt_x(arr[n])}", claimed=q.get("formula"))
        return dict(prompt=P(q), kind="check", ok=True, value=None, text=f"前 20 项都符合「{q.get('formula')}」", claimed=q.get("formula"))
    rows = []
    for i, q in enumerate(asks):
        if q["what"] == "term":
            rows.append(num_row(q, a[need[i]]))
        elif q["what"] == "sum":
            rows.append(num_row(q, S[need[i]]))
        else:
            rows.append(check(q, a if q["what"] == "formula" else S, "数列" if q["what"] == "formula" else "前 n 项和"))
    return dict(rows=rows, viz=dict(a=a[1:31], S=S[1:31], terms=[int(q["n"]) for q in asks if q["what"] == "term"], sums=[int(q["n"]) for q in asks if q["what"] == "sum"]), detail=[f"前 8 项：{'，'.join(fmt_x(x) for x in a[1:9])}"])
