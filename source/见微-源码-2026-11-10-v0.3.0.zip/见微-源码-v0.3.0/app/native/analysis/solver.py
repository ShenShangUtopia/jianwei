"""题目分析的程序复算（由 gewu/solver.js 改写）：单位换算 · 表达式 · 方程组求解 · 角度对齐 · 精确值识别。

思路参照 VeloΦ 的 AI 读题：AI 只负责读题、列式，数值一律由程序算。模型把题目写成「已知量 + 未知量 + 方程」，
这里用 Levenberg–Marquardt 解出来再和模型的答案对照；方程互相矛盾或条件不足时也能判断出来。
不用 eval：表达式由小解析器编译成闭包，只认 + - * / ^ ( ) 和白名单函数。
"""
from __future__ import annotations

import math
import re

U: dict = {}


def _def(dim, lst):
    for item in lst:
        names, f = item[0], item[1]
        off = item[2] if len(item) > 2 else 0
        for n in names.split(" "):
            U[n] = (f, dim, off)


_def("1", [("1 -", 1), ("% 百分之", 0.01), ("‰", 0.001)])
_def("m", [("m 米", 1), ("km 千米 公里", 1e3), ("dm 分米", 0.1), ("cm 厘米", 1e-2), ("mm 毫米", 1e-3), ("μm 微米", 1e-6), ("nm 纳米", 1e-9)])
_def("kg", [("kg 千克 公斤", 1), ("g 克", 1e-3), ("mg 毫克", 1e-6), ("t 吨", 1e3)])
_def("s", [("s 秒 秒钟", 1), ("ms 毫秒", 1e-3), ("μs 微秒", 1e-6), ("min 分钟", 60), ("h 小时", 3600), ("d 天", 86400)])
_def("m/s", [("m/s 米每秒", 1), ("km/h 千米每小时 公里每小时", 1 / 3.6), ("cm/s 厘米每秒", 0.01)])
_def("m/s²", [("m/s² 米每二次方秒 N/kg", 1), ("cm/s²", 0.01)])
_def("N", [("N 牛 牛顿", 1), ("kN 千牛", 1e3), ("mN 毫牛", 1e-3)])
_def("J", [("J 焦 焦耳", 1), ("kJ 千焦", 1e3), ("mJ", 1e-3), ("eV 电子伏", 1.602176634e-19), ("keV", 1.602176634e-16), ("MeV", 1.602176634e-13), ("kW·h 度电 千瓦时", 3.6e6), ("cal 卡", 4.184), ("kcal 千卡", 4184)])
_def("W", [("W 瓦 瓦特", 1), ("kW 千瓦", 1e3), ("mW 毫瓦", 1e-3), ("MW 兆瓦", 1e6)])
_def("rad", [("rad 弧度", 1), ("° 度", math.pi / 180)])
_def("rad/s", [("rad/s 弧度每秒", 1), ("r/s 转每秒", 2 * math.pi), ("r/min 转每分 rpm", math.pi / 30)])
_def("Hz", [("Hz 赫 赫兹", 1), ("kHz", 1e3), ("MHz", 1e6)])
_def("Pa", [("Pa 帕 帕斯卡", 1), ("kPa 千帕", 1e3), ("MPa 兆帕", 1e6), ("hPa", 100), ("atm 标准大气压", 101325), ("cmHg", 1333.22), ("mmHg", 133.322)])
_def("C", [("C 库 库仑", 1), ("mC 毫库", 1e-3), ("μC 微库", 1e-6), ("nC 纳库", 1e-9)])
_def("V", [("V 伏 伏特", 1), ("kV 千伏", 1e3), ("mV 毫伏", 1e-3)])
_def("A", [("A 安 安培", 1), ("mA 毫安", 1e-3), ("μA 微安", 1e-6)])
_def("Ω", [("Ω 欧 欧姆", 1), ("kΩ 千欧", 1e3), ("MΩ 兆欧", 1e6)])
_def("F", [("F 法 法拉", 1), ("μF 微法", 1e-6), ("nF", 1e-9), ("pF 皮法", 1e-12)])
_def("H", [("H 亨 亨利", 1), ("mH 毫亨", 1e-3)])
_def("T", [("T 特 特斯拉", 1), ("mT 毫特", 1e-3), ("Gs 高斯", 1e-4)])
_def("Wb", [("Wb 韦伯", 1)])
_def("V/m", [("V/m N/C 伏每米 牛每库", 1)])
_def("N/m", [("N/m 牛每米", 1), ("N/cm", 100)])
_def("kg/m³", [("kg/m³ 千克每立方米", 1), ("g/cm³ 克每立方厘米 g/mL", 1e3)])
_def("m²", [("m² 平方米", 1), ("dm²", 1e-2), ("cm² 平方厘米", 1e-4), ("mm²", 1e-6), ("km²", 1e6)])
_def("m³", [("m³ 立方米", 1), ("L 升 dm³", 1e-3), ("mL 毫升 cm³", 1e-6)])
_def("K", [("K 开 开尔文", 1), ("℃ 摄氏度", 1, 273.15)])
_def("mol", [("mol 摩 摩尔", 1), ("mmol 毫摩", 1e-3)])
_def("mol/L", [("mol/L 摩每升", 1), ("mmol/L", 1e-3)])
_def("g/mol", [("g/mol 克每摩", 1)])
_def("kg·m/s", [("kg·m/s N·s", 1)])
_def("J/(kg·℃)", [("J/(kg·℃) J/(kg·K)", 1)])


def norm_unit(u):
    s = re.sub(r"\s+", "", str("" if u is None else u).strip())
    s = re.sub(r"[µu](?=[mgsCAFVTlL])", "μ", s)
    s = re.sub(r"\^2|\*\*2", "²", s)
    s = re.sub(r"\^3|\*\*3", "³", s).replace("^-1", "⁻¹")
    s = re.sub(r"[*.⋅•]", "·", s)
    s = re.sub(r"^(deg|degrees?|º|˚)$", "°", s, flags=re.I)
    s = re.sub(r"^°C$", "℃", s, flags=re.I)
    s = re.sub(r"^(ohm|ohms)$", "Ω", s, flags=re.I)
    s = re.sub(r"^k(ohm|Ω)$", "kΩ", s, flags=re.I)
    s = re.sub(r"^m/s/s$|^m·s⁻²$", "m/s²", s)
    if s == "l":
        s = "L"
    s = re.sub(r"^ml$", "mL", s, flags=re.I)
    s = re.sub(r"^kwh$", "kW·h", s, flags=re.I)
    s = re.sub(r"^hz$", "Hz", s, flags=re.I)
    if s == "" or re.match(r"^(无|无单位|none|unitless)$", s, re.I):
        s = "1"
    return s


def unit_of(u):
    return U.get(norm_unit(u))


def isf(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def to_si(v, unit):
    u = unit_of(unit)
    return v * u[0] + u[2] if u and isf(v) else None


def from_si(v, unit):
    u = unit_of(unit)
    return (v - u[2]) / u[0] if u and isf(v) else None


def convert(v, unit, target):
    a, b = norm_unit(unit), norm_unit(target)
    if a == b:
        return dict(value=v)
    ua, ub = U.get(a), U.get(b)
    if not ua:
        return dict(error=f"不认识单位「{unit}」")
    if not ub:
        return dict(error=f"单位「{target}」无法换算，请直接给出以「{target}」为单位的数值")
    if ua[1] != ub[1]:
        return dict(error=f"「{unit}」与「{target}」不是同一种量")
    return dict(value=float(f"{((v * ua[0] + ua[2]) - ub[2]) / ub[0]:.12g}"))


# ---------------------------------------------------------------- 表达式
def _s(f):
    def g(*a):
        try:
            r = f(*a)
            return r if isinstance(r, (int, float)) else math.nan
        except (ValueError, ZeroDivisionError, OverflowError, TypeError):
            return math.nan
    return g


def _fact(n):
    n = round(n)
    return math.nan if n < 0 or n > 170 else float(math.factorial(n))


def _comb(n, k):
    n, k = round(n), round(k)
    return 0 if k < 0 or n < 0 or k > n else math.comb(n, k)


def _perm(n, k):
    n, k = round(n), round(k)
    return 0 if k < 0 or n < 0 or k > n else math.perm(n, k)


FN = {k: _s(v) for k, v in dict(sin=math.sin, cos=math.cos, tan=math.tan, asin=math.asin, acos=math.acos, atan=math.atan, atan2=math.atan2, arcsin=math.asin, arccos=math.acos, arctan=math.atan, sqrt=math.sqrt,
                                cbrt=lambda x: math.copysign(abs(x) ** (1 / 3), x), abs=abs, exp=math.exp, ln=math.log, lg=math.log10, log=lambda a, b=None: math.log10(a) if b is None else math.log(b) / math.log(a), log2=math.log2,
                                min=min, max=max, sinh=math.sinh, cosh=math.cosh, tanh=math.tanh, floor=math.floor, ceil=math.ceil, round=round, fact=_fact, comb=_comb, perm=_perm).items()}
CONST = dict(pi=math.pi, deg=math.pi / 180)


class ExprError(ValueError):
    pass


_NUM = re.compile(r"(\d+\.?\d*|\.\d+)(e[+-]?\d+)?", re.I)
_ID = re.compile(r"[A-Za-z_][A-Za-z_0-9]*")


def tokenize(src):
    s = re.sub(r"[−–—]", "-", str(src))
    s = re.sub(r"[×·⋅∙]", "*", s).replace("÷", "/").replace("π", " pi ").replace("（", "(").replace("）", ")").replace("，", ",").replace("²", "^2").replace("³", "^3").replace("**", "^").replace("°", "*deg")
    t, i = [], 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
            continue
        m = _NUM.match(s, i)
        if m:
            t.append(("n", float(m.group(0))))
            i = m.end()
            continue
        m = _ID.match(s, i)
        if m:
            t.append(("i", m.group(0)))
            i = m.end()
            continue
        if c in "+-*/^(),√":
            t.append((c, None))
            i += 1
            continue
        raise ExprError(f"不能识别的字符「{c}」")
    out = []   # 隐式乘法：2T、2(…)、(…)(…)、(…)x
    for k in t:
        p = out[-1] if out else None
        if p and (p[0] == "n" or p[0] == ")" or (p[0] == "i" and p[1] not in FN)) and k[0] in ("n", "i", "(", "√") and not (p[0] == "n" and k[0] == "n") and not (p[0] == "i" and k[0] == "n"):
            out.append(("*", None))
        out.append(k)
    return out


def parse(src):
    """解析成语法树：('n',v) ('v',name) ('neg',a) ('op',op,a,b) ('fn',name,args)。"""
    tk = tokenize(src)
    P = [0]

    def peek():
        return tk[P[0]] if P[0] < len(tk) else None

    def eat(k):
        if P[0] < len(tk) and tk[P[0]][0] == k:
            P[0] += 1
            return True
        return False

    def need(k):
        if not eat(k):
            raise ExprError(f"缺少「{k}」")

    def expr():
        a = term()
        while True:
            if eat("+"):
                a = ("op", "+", a, term())
            elif eat("-"):
                a = ("op", "-", a, term())
            else:
                return a

    def term():
        a = unary()
        while True:
            if eat("*"):
                a = ("op", "*", a, unary())
            elif eat("/"):
                a = ("op", "/", a, unary())
            else:
                return a

    def unary():
        if eat("-"):
            return ("neg", unary())
        if eat("+"):
            return unary()
        return power()

    def power():
        a = atom()
        return ("op", "^", a, unary()) if eat("^") else a

    def atom():
        k = peek()
        if not k:
            raise ExprError("表达式不完整")
        if eat("√"):
            return ("fn", "sqrt", [atom()])
        if k[0] == "n":
            P[0] += 1
            return ("n", k[1])
        if eat("("):
            e = expr()
            need(")")
            return e
        if k[0] == "i":
            P[0] += 1
            if k[1] in FN:
                if peek() and peek()[0] == "(":
                    P[0] += 1
                    args = []
                    if not eat(")"):
                        args.append(expr())
                        while eat(","):
                            args.append(expr())
                        need(")")
                    return ("fn", k[1], args)
                return ("fn", k[1], [power()])   # sin x、sqrt 3
            return ("v", k[1])
        raise ExprError(f"意外的「{k[0]}」")
    e = expr()
    if P[0] < len(tk):
        raise ExprError(f"多余的「{tk[P[0]][1] if tk[P[0]][1] is not None else tk[P[0]][0]}」")
    return e


def tree_vars(n, out=None):
    out = set() if out is None else out
    t = n[0]
    if t == "v":
        if n[1] not in CONST:
            out.add(n[1])
    elif t == "neg":
        tree_vars(n[1], out)
    elif t == "op":
        tree_vars(n[2], out)
        tree_vars(n[3], out)
    elif t == "fn":
        for a in n[2]:
            tree_vars(a, out)
    return out


def _div(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return math.inf if a > 0 else -math.inf if a < 0 else math.nan


def _pow(a, b):
    try:
        r = a ** b
        return math.nan if isinstance(r, complex) else r
    except (ZeroDivisionError, OverflowError, ValueError):
        return math.nan


def compile_tree(n, index, known):
    t = n[0]
    if t == "n":
        v = n[1]
        return lambda _x: v
    if t == "v":
        name = n[1]
        if name in CONST:
            v = CONST[name]
            return lambda _x: v
        if name in known:
            v = known[name]
            return lambda _x: v
        if name not in index:
            raise ExprError(f"未定义的名称 {name}")
        i = index[name]
        return lambda x: x[i]
    if t == "neg":
        a = compile_tree(n[1], index, known)
        return lambda x: -a(x)
    if t == "op":
        op = n[1]
        a, b = compile_tree(n[2], index, known), compile_tree(n[3], index, known)
        if op == "+":
            return lambda x: a(x) + b(x)
        if op == "-":
            return lambda x: a(x) - b(x)
        if op == "*":
            return lambda x: a(x) * b(x)
        if op == "/":
            return lambda x: _div(a(x), b(x))
        return lambda x: _pow(a(x), b(x))
    f = FN[n[1]]
    args = [compile_tree(a, index, known) for a in n[2]]
    return lambda x: f(*[g(x) for g in args])


def eval_const(s):
    """算不含未知量的式子（如「2√3」「48*sqrt(3)/25」「2.5 m/s」）；算不出返回 nan。"""
    if isinstance(s, bool):
        return math.nan
    if isinstance(s, (int, float)):
        return float(s)
    st = str("" if s is None else s).strip()
    m = re.match(r"^[-+−]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?\s*[^\d\s.+\-*/^()√]*$", st, re.I)
    if m:
        mm = re.match(r"[-+−]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?", st, re.I)
        return float(mm.group(0).replace("−", "-"))

    def tr(t):
        try:
            return compile_tree(parse(t), {}, {})([])
        except (ExprError, TypeError, ValueError, OverflowError):
            return math.nan
    v = tr(st)
    if not isf(v) and re.search(r"\s\S+$", st):
        v = tr(re.sub(r"\s\S+$", "", st))
    return v


def fn(src, names):
    """fn('x^2-3*x', ['x'])(2) = -2；用到 names 以外的名字时报错。"""
    n = parse(src)
    index = {v: i for i, v in enumerate(names)}
    for v in tree_vars(n):
        if v not in index:
            raise ExprError(f"「{src}」里的「{v}」没有定义（只能用 {'、'.join(names)}）")
    f = compile_tree(n, index, {})

    def call(*a):
        return f(a)
    return call


# ---------------------------------------------------------------- 方程组
def solve_linear(A, b):
    n = len(b)
    M = [list(r) + [b[i]] for i, r in enumerate(A)]
    for c in range(n):
        q = max(range(c, n), key=lambda r: abs(M[r][c]))
        if not abs(M[q][c]) > 1e-300:
            return None
        M[c], M[q] = M[q], M[c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            if f:
                for k in range(c, n + 1):
                    M[r][k] -= f * M[c][k]
    d = [0.0] * n
    for r in range(n - 1, -1, -1):
        s = M[r][n] - sum(M[r][k] * d[k] for k in range(r + 1, n))
        d[r] = s / M[r][r]
    return d


def svd(A, n):
    """奇异值与右奇异向量（单边 Jacobi），用来找方程「管不住」的方向。"""
    m = len(A)
    W = [list(r) for r in A]
    V = [[float(i == j) for j in range(n)] for i in range(n)]
    for _sweep in range(60):
        off = 0.0
        for p in range(n - 1):
            for q in range(p + 1, n):
                a = sum(W[i][p] ** 2 for i in range(m))
                b = sum(W[i][q] ** 2 for i in range(m))
                c = sum(W[i][p] * W[i][q] for i in range(m))
                if c == 0 or abs(c) <= 1e-15 * math.sqrt(a * b):
                    continue
                off = max(off, abs(c) / math.sqrt(a * b))
                z = (b - a) / (2 * c)
                t = (1 if z >= 0 else -1) / (abs(z) + math.sqrt(1 + z * z))
                cs = 1 / math.sqrt(1 + t * t)
                sn = cs * t
                for i in range(m):
                    u, v = W[i][p], W[i][q]
                    W[i][p], W[i][q] = cs * u - sn * v, sn * u + cs * v
                for i in range(n):
                    u, v = V[i][p], V[i][q]
                    V[i][p], V[i][q] = cs * u - sn * v, sn * u + cs * v
        if off < 1e-14:
            break
    return [math.sqrt(sum(r[j] ** 2 for r in W)) for j in range(n)], V


_NAME = re.compile(r"^[A-Za-z_][A-Za-z_0-9]{0,23}$")


def _n(v):
    if isinstance(v, bool):
        return math.nan
    if isinstance(v, (int, float)):
        return float(v)
    return eval_const(v) if isinstance(v, str) and v.strip() else math.nan


def stated_angles(text):
    """题目给的三角近似（sin37° = 0.6 → 36.87°）。"""
    out = {}
    for m in re.finditer(r"(sin|cos|tan)\s*(\d{1,2}(?:\.\d+)?)\s*[°º˚]\s*[=＝≈]\s*(\d+(?:\.\d+)?)(?:\s*[/／]\s*(\d+(?:\.\d+)?))?", str(text or ""), re.I):
        f, deg = m.group(1).lower(), float(m.group(2))
        v = float(m.group(3)) / float(m.group(4)) if m.group(4) else float(m.group(3))
        if f == "sin":
            r = math.asin(v) if v <= 1 else math.nan
        elif f == "cos":
            r = math.acos(v) if v <= 1 else math.nan
        else:
            r = math.atan(v)
        c = math.degrees(r)
        if not isf(c) or abs(c - deg) < 1e-6 or abs(c - deg) >= 0.5:
            continue   # 只处理教材式的近似（差半度以内）
        out.setdefault(deg, round(c, 4))
        out.setdefault(round(90 - deg, 4), round(90 - c, 4))
    return out


def build(raw, problem_text=""):
    """检查并整理方程模型。返回 {ok, model, errors, notes}；errors 用于让 AI 修正。"""
    errors, notes = [], []
    if not isinstance(raw, dict):
        return dict(ok=False, errors=["model 必须是含 knowns、unknowns、equations、asks 的对象"])

    def lst(k):
        v = raw.get(k) or []
        if not isinstance(v, list):
            errors.append(f"model.{k} 必须是数组")
            return []
        out = []
        for i, x in enumerate(v):
            if isinstance(x, dict):
                out.append(x)
            else:
                errors.append(f"model.{k}[{i}] 必须是对象")
        return out
    ang = stated_angles(problem_text)
    names = set()

    def name_ok(n, w):
        if not _NAME.match(n):
            errors.append(f"{w}.name「{n}」只能用英文字母、数字和下划线，且以字母开头（如 T1、v0、theta）")
            return False
        if n in CONST or n in FN:
            errors.append(f"{w}.name「{n}」是保留字（pi、deg 和函数名）")
            return False
        if n in names:
            errors.append(f"名称「{n}」重复定义")
            return False
        names.add(n)
        return True
    model = dict(knowns=[], unknowns=[], equations=[], asks=[])
    for i, k in enumerate(lst("knowns")):
        name = str(k.get("name") or "").strip()
        if not name_ok(name, f"model.knowns[{i}]"):
            continue
        v = _n(k.get("value"))
        unit = str(k.get("unit") or "").strip()
        if not isf(v):
            errors.append(f"model.knowns[{i}]（{name}）的 value 必须是数")
            continue
        if norm_unit(unit) == "°" and v in ang:
            notes.append(f"按题目给出的三角函数值，{v:g}° 取为 {ang[v]}°（与之一致），复算结果与按近似值手算的答案相同")
            v = ang[v]
        si = to_si(v, unit)
        if si is None:
            errors.append(f"model.knowns[{i}]（{name}）的单位「{unit}」无法识别；请换成常用单位，或先换算成国际单位再写")
            continue
        model["knowns"].append(dict(name=name, value=v, unit=unit, si=si, meaning=str(k.get("meaning") or "")))
    for i, u in enumerate(lst("unknowns")):
        name = str(u.get("name") or "").strip()
        if name_ok(name, f"model.unknowns[{i}]"):
            model["unknowns"].append(dict(name=name, unit=str(u.get("unit") or ""), meaning=str(u.get("meaning") or ""), guess=_n(u.get("guess")), min=_n(u.get("min")), max=_n(u.get("max"))))
    for i, e in enumerate(lst("equations")):
        text = str(e.get("eq") or e.get("equation") or "").strip()
        if not text:
            errors.append(f"model.equations[{i}].eq 是空的")
            continue
        parts = text.replace("==", "=").split("=")
        if len(parts) > 2:
            errors.append(f"model.equations[{i}]「{text}」只能有一个等号")
            continue
        try:
            model["equations"].append(dict(text=text, why=str(e.get("why") or ""), l=parse(parts[0]), r=parse(parts[1]) if len(parts) == 2 else ("n", 0.0)))
        except ExprError as x:
            errors.append(f"model.equations[{i}]「{text}」：{x}")
    for i, a in enumerate(lst("asks")):
        ex = str(a.get("expr") or "").strip()
        try:
            model["asks"].append(dict(prompt=str(a.get("prompt") or ex), expr=ex, unit=str(a.get("unit") or ""), node=parse(ex), claimed=a.get("claimed", a.get("value"))))
        except ExprError as x:
            errors.append(f"model.asks[{i}].expr「{ex}」：{x}")
    if not model["unknowns"] and not errors:
        errors.append("model.unknowns 至少要有一个未知量")
    if not model["equations"] and not errors:
        errors.append("model.equations 至少要有一条方程")
    if not model["asks"] and not errors:
        errors.append("model.asks 至少要有一个所求")
    used = set()
    for i, e in enumerate(model["equations"]):
        for v in tree_vars(e["l"]) | tree_vars(e["r"]):
            used.add(v)
            if v not in names:
                errors.append(f"model.equations[{i}]「{e['text']}」用到「{v}」，它既不是已知量也不是未知量")
    for i, a in enumerate(model["asks"]):
        for v in tree_vars(a["node"]):
            if v not in names:
                errors.append(f"model.asks[{i}].expr 用到「{v}」，它既不是已知量也不是未知量")
    for u in model["unknowns"]:
        if u["name"] not in used:
            errors.append(f"未知量「{u['name']}」没有出现在任何方程里")
    for i, a in enumerate(model["asks"]):
        if a["unit"] and not unit_of(a["unit"]):
            errors.append(f"model.asks[{i}] 的单位「{a['unit']}」无法识别")
    if len(model["unknowns"]) > 60:
        errors.append("未知量最多 60 个")
    return dict(ok=False, errors=errors) if errors else dict(ok=True, model=model, notes=notes)


def solve(m):
    """解方程模型：verdict = solved | inconsistent（互相矛盾）| underdetermined（条件不足）| failed。"""
    n = len(m["unknowns"])
    index = {u["name"]: i for i, u in enumerate(m["unknowns"])}
    known = {k["name"]: k["si"] for k in m["knowns"]}
    res = []
    for e in m["equations"]:
        lf, rf = compile_tree(e["l"], index, known), compile_tree(e["r"], index, known)
        res.append(lambda x, lf=lf, rf=rf: lf(x) - rf(x))
    ask_f = [compile_tree(a["node"], index, known) for a in m["asks"]]
    lo = [u["min"] if isf(u["min"]) else -math.inf for u in m["unknowns"]]
    hi = [u["max"] if isf(u["max"]) else math.inf for u in m["unknowns"]]

    def clamp_x(x):
        for i in range(n):
            x[i] = min(hi[i], max(lo[i], x[i]))

    def R(x):
        return [f(x) for f in res]

    def norm2(v):
        return sum(b * b if isf(b) and abs(b) < 1e150 else 1e300 for b in v)

    def jac(x, fns):
        J = [[0.0] * n for _f in fns]
        for j in range(n):
            h = 1e-6 * max(1, abs(x[j]))
            xp, xm = list(x), list(x)
            xp[j] += h
            xm[j] -= h
            for i, f in enumerate(fns):
                J[i][j] = (f(xp) - f(xm)) / (2 * h)
        return J

    def mag(nd, x):
        if nd[0] == "op" and nd[1] in "+-":
            return mag(nd[2], x) + mag(nd[3], x)
        if nd[0] == "neg":
            return mag(nd[1], x)
        try:
            v = abs(compile_tree(nd, index, known)(x))
            return v if isf(v) else 0
        except ExprError:
            return 0

    def rel(x):
        out = []
        for i, e in enumerate(m["equations"]):
            v = res[i](x)
            sc = mag(e["l"], x) + mag(e["r"], x)
            out.append(abs(v) / max(sc, 1e-12) if isf(v) else math.inf)
        return out

    def start(k):
        x = []
        for i, u in enumerate(m["unknowns"]):
            g = u["guess"] if isf(u["guess"]) else lo[i] + 1 if isf(lo[i]) and lo[i] > 0 else hi[i] - 1 if isf(hi[i]) and hi[i] < 0 else 1
            x.append(g if k == 0 else g * (1, 3, -2, 0.37, 10, -0.5, 0.1, 30)[k % 8] + k * 0.1)
        clamp_x(x)
        return x
    best = None
    for at in range(8):
        x = start(at)
        r = R(x)
        f = norm2(r)
        lam = 1e-3
        for _it in range(300):
            if not f > 0:
                break
            J = jac(x, res)
            JtJ = [[sum(row[a] * row[b] for row in J) for b in range(n)] for a in range(n)]
            g = [sum(row[a] * r[i] for i, row in enumerate(J)) for a in range(n)]
            improved = False
            for _t in range(12):
                A = [[v + lam * max(v, 1e-12) if a == b else v for b, v in enumerate(row)] for a, row in enumerate(JtJ)]
                try:
                    d = solve_linear(A, [-v for v in g])
                except (ZeroDivisionError, OverflowError):
                    d = None
                if not d or not all(isf(v) for v in d):
                    lam *= 10
                    continue
                xn = [v + d[i] for i, v in enumerate(x)]
                clamp_x(xn)
                rn = R(xn)
                fn_ = norm2(rn)
                if fn_ < f:
                    x = xn
                    r = rn
                    improved = f - fn_ > 1e-30 or any(abs(v) > 1e-15 for v in d)
                    f = fn_
                    lam = max(lam / 10, 1e-15)
                    break
                lam *= 10
            if not improved:
                break
        if best is None or f < best[1]:
            best = (list(x), f)
        if all(v <= 1e-7 for v in rel(best[0])):
            break
    x = best[0]
    values = {u["name"]: x[i] for i, u in enumerate(m["unknowns"])}

    def show(v, unit):
        c = from_si(v, unit) if unit else v
        return v if c is None else c
    if not all(isf(v) for v in x):
        return dict(verdict="failed", values=values, answers=[dict(prompt=a["prompt"], unit=a["unit"], value=None, claimed=a["claimed"]) for a in m["asks"]], conflicts=[], undetermined=[])
    conflicts = sorted([dict(index=i, residual=v) for i, v in enumerate(rel(x)) if v > 1e-7], key=lambda c: -c["residual"])[:6]
    J = jac(x, res)
    s, V = svd(J, n)
    smax = max(s + [0])
    tol = max(1e-9 * smax * max(n, len(J)), 1e-14)
    nulls = [[row[j] for row in V] for j in range(n) if s[j] <= tol]
    undetermined = [u["name"] for i, u in enumerate(m["unknowns"]) if any(abs(d[i]) > 1e-6 for d in nulls)]
    G = jac(x, ask_f)
    answers = []
    for k, a in enumerate(m["asks"]):
        g = G[k]
        gn = math.hypot(*g) if g else 0
        free = any(abs(sum(v * g[i] for i, v in enumerate(d))) > 1e-6 * max(gn, 1e-12) for d in nulls)
        v = ask_f[k](x)
        answers.append(dict(prompt=a["prompt"], unit=a["unit"], claimed=a["claimed"], value=None if free or not isf(v) else show(v, a["unit"])))
    verdict = "inconsistent" if conflicts else "underdetermined" if any(a["value"] is None for a in answers) else "solved"
    return dict(verdict=verdict, values=values, answers=answers, conflicts=conflicts, undetermined=undetermined)


VERDICT = dict(solved="已解出", inconsistent="方程互相矛盾（不存在同时满足全部方程的解）", underdetermined="条件不足（所求的量不能由这些方程确定）", failed="数值求解失败")


def close(a, b):
    """两个数是否「同一个答案」：相对 2% 或绝对 0.005 以内。"""
    return abs(a - b) <= max(0.02 * max(abs(a), abs(b)), 0.005)


# ---------------------------------------------------------------- 精确值识别：3.3255… → 48√3/25
def _sqfree(m):
    p = 2
    while p * p <= m:
        if m % (p * p) == 0:
            return False
        p += 1
    return m > 1


SQF = [m for m in range(300) if _sqfree(m)]


def rational(x, max_q=1000, tol=1e-12):
    for q in range(1, max_q + 1):
        p = round(x * q)
        if abs(p / q - x) < tol * max(1, abs(x)):
            return p, q
    return None


def _frac(p, q, tail=""):
    g = math.gcd(p, q) or 1
    p //= g
    q //= g
    a = abs(p)
    head = (("" if a == 1 else str(a)) + tail) if tail else str(a)
    return ("-" if p < 0 else "") + head + ("" if q == 1 else f"/{q}")


_FINITE_Q = {2, 4, 5, 8, 10, 20, 25, 40, 50, 100, 125, 200, 250, 500, 1000}


def exact(v):
    """认得出就给出 "48√3/25"、"(-16+12√6)/25"、"2π/3"、"7/4"；认不出返回 ''。整数与有限小数（≤3 位）不必写。"""
    if not isf(v) or abs(v) > 1e7 or abs(v) < 1e-12:
        return ""
    r = rational(v)
    if r:
        if r[1] == 1 or (r[1] in _FINITE_Q and abs(v * 1000 - round(v * 1000)) < 1e-9):
            return ""
        return _frac(r[0], r[1])
    for m in SQF:
        if m >= 100:
            break
        q = rational(v / math.sqrt(m), 100)
        if q and abs(q[0]) <= 2000:
            return _frac(q[0], q[1], f"√{m}")
    pi_ = rational(v / math.pi, 60)
    if pi_ and abs(pi_[0]) <= 200:
        return _frac(pi_[0], pi_[1], "π")
    for m in SQF[:10]:
        for q in range(1, 31):
            for b in range(-24, 25):
                if not b:
                    continue
                a = v * q - b * math.sqrt(m)
                if abs(a - round(a)) < 1e-13 * max(1, abs(v * q)) and abs(round(a)) <= 200:
                    A = round(a)
                    g = math.gcd(math.gcd(A, b), q) or 1
                    A2, b2, q2 = A // g, b // g, q // g
                    surd = ("" if abs(b2) == 1 else str(abs(b2))) + f"√{m}"
                    body = ("-" if b2 < 0 else "") + surd if A2 == 0 else f"{A2}{'-' if b2 < 0 else '+'}{surd}"
                    return body if q2 == 1 else f"({body})/{q2}"
    return ""
