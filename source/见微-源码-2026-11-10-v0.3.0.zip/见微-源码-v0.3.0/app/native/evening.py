"""暮省全屏播放（原生）：5 幅夜景 × 4 种封面版式，全部 QPainter 现画，不需要浏览器，也不用图片素材。

五幅夜景：观澜（潮线）、远山（月下层峦）、观星（星图）、灯下（一盏灯）、月白（信笺）。
山形、潮线、星位都由日期算出来，所以每晚不一样，同一天重播又是同一幅。
晚上看的东西：整屏偏暗、对比够读就好；月白是唯一的浅底，也压低了亮度。

deck 是 guanlan/core/evening.py 生成的纯数据（JSON 可存）。尺寸都按屏幕宽度算（对应旧 CSS 的 clamp(min, vw, max)）；
一页内容放不下时整页字号按比例缩小，不会出现被截断的文字。

操作：空格暂停、← → 翻页、Esc 退出、F11 切窗口；静候封面上按 →、空格或单击直接开始。
"""
from __future__ import annotations

import math
import random
import sys
import time
import zlib

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetricsF, QGuiApplication, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QRadialGradient, QTextLayout, QTextOption, QTransform)
from PySide6.QtWidgets import QApplication, QMessageBox, QWidget

SERIF = ["Source Han Serif SC", "Noto Serif SC", "Songti SC", "STSong", "SimSun", "serif"]
SANS = ["Noto Sans SC", "Microsoft YaHei UI", "Microsoft YaHei", "DengXian", "sans-serif"]
MONO = ["Georgia", "Times New Roman", "Microsoft YaHei UI", "serif"]
COVER_MS = 180000

THEMES = dict(
    tide=dict(name="观澜", dark=True, bg="#061318", bg2="#0A2026", ink="#E9F1EE", soft="#C5D5D1", muted="#93AAA8", dim="#6C8585", accent="#7CC6BC", accent2="#E9DCBB", accent3="#4F8691", line=(124, 198, 188, 0.22), mark2="accent2", date="accent2", rule="top"),
    ridge=dict(name="远山", dark=True, bg="#0A1312", bg2="#121D1B", ink="#ECEFE6", soft="#CCD3C6", muted="#9DA99B", dim="#74806F", accent="#BCCBA6", accent2="#EDE4C8", accent3="#7E9483", line=(188, 203, 166, 0.20), mark2="accent2", date="accent2", rule="top"),
    stars=dict(name="观星", dark=True, bg="#060A1A", bg2="#0E1430", ink="#EDEEF6", soft="#CDD0E3", muted="#9CA2C2", dim="#6F7596", accent="#AEB6E6", accent2="#EADBAE", accent3="#6F79B4", line=(174, 182, 230, 0.22), mark2="accent2", date="accent2", rule="top"),
    lamp=dict(name="灯下", dark=True, bg="#0E0A07", bg2="#1A120C", ink="#F4E9D8", soft="#DCCAB2", muted="#B5A38D", dim="#887662", accent="#DDA463", accent2="#F3D3A0", accent3="#8E7A5E", line=(221, 164, 99, 0.22), mark2="accent2", date="accent2", rule="none"),
    moon=dict(name="月白", dark=False, seal=True, bg="#B7B1A2", bg2="#C5BFAF", ink="#14110D", soft="#2A2620", muted="#4A4336", dim="#5F5748", accent="#86281E", accent2="#6E241B", accent3="#3E5A60", line=(70, 54, 38, 0.26), mark2="accent", date="accent", rule="bottom"),
)
LEGACY = dict(midnight="stars", rice="moon", jade="ridge", amber="lamp")   # 旧版存下来的往期
MARK_SIZE = (130, 20, 290)


def rgba(c, a=None):
    if isinstance(c, tuple):
        q = QColor(c[0], c[1], c[2])
        q.setAlphaF(c[3] if a is None else a)
        return q
    q = QColor(c)
    if a is not None:
        q.setAlphaF(a)
    return q


def ease(t):
    """cubic-bezier(.2,.7,.2,1) 的近似：快起慢收。"""
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def make_font(families, px, weight=400, spacing=0.0):
    f = QFont()
    f.setFamilies(families)
    f.setPixelSize(max(6, int(round(px))))
    f.setWeight(QFont.Weight(weight))
    f.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return f


class Text:
    """一段排好版的文字：知道自己多高，可以画到任意位置。"""

    def __init__(self, text, font, color, width, lh=1.5, justify=False, align="left", max_lines=0, balance=False):
        self.text, self.font, self.color, self.width = str(text or ""), font, color, max(10.0, width)
        self.lh = font.pixelSize() * lh
        self.justify, self.align, self.max_lines = justify, align, max_lines
        self.clipped = False
        self.lines = self._layout(self.width)
        if balance and self.lines > 1:   # 标题各行尽量等长（对应 text-wrap: balance）
            lo, hi, n = self.width * 0.45, self.width, self.lines
            for _i in range(8):
                mid = (lo + hi) / 2
                if self._layout(mid) <= n:
                    hi = mid
                else:
                    lo = mid
            self.lines = self._layout(hi)
        self.h = self.lines * self.lh if self.text else 0.0

    def _layout(self, w):
        lay = QTextLayout(self.text, self.font)
        opt = QTextOption()
        opt.setWrapMode(QTextOption.WrapMode.WordWrap)
        opt.setAlignment({"center": Qt.AlignmentFlag.AlignHCenter, "right": Qt.AlignmentFlag.AlignRight}.get(self.align, Qt.AlignmentFlag.AlignJustify if self.justify else Qt.AlignmentFlag.AlignLeft))
        lay.setTextOption(opt)
        lay.beginLayout()
        n = 0
        self.clipped = False
        while True:
            ln = lay.createLine()
            if not ln.isValid():
                break
            if self.max_lines and n >= self.max_lines:
                self.clipped = True
                ln.setLineWidth(-1)
                break
            ln.setLineWidth(w)
            ln.setPosition(QPointF(0, n * self.lh + (self.lh - ln.height()) / 2))
            n += 1
        lay.endLayout()
        self.layout = lay
        self.lay_w = w
        return n

    def draw(self, p, x, y):
        if not self.text:
            return
        dx = (self.width - self.lay_w) if self.align == "right" else (self.width - self.lay_w) / 2 if self.align == "center" else 0
        p.setPen(self.color)
        self.layout.draw(p, QPointF(x + dx, y))

    def natural_width(self):
        return QFontMetricsF(self.font).horizontalAdvance(self.text)


def stack_h(items):
    return sum(m + (it.h if it else 0) for it, m in items)


def stack(p, x, y, items):
    for it, m in items:
        y += m
        if it:
            it.draw(p, x, y)
            y += it.h
    return y


class Rule:
    """一条线也可以排进 stack。"""

    def __init__(self, w, color, thick=1.0):
        self.w, self.color, self.h = w, color, thick

    def draw(self, p, x, y):
        p.fillRect(QRectF(x, y, self.w, self.h), self.color)


class Painter:
    """按当前窗口尺寸和主题画封面、HUD、各页内容。"""

    def __init__(self, deck, w, h, texture=None, dpr=1.0):
        self.deck, self.W, self.H, self.dpr = deck, w, h, dpr
        theme = LEGACY.get(deck.get("theme"), deck.get("theme"))
        self.theme = theme if theme in THEMES else "tide"
        self.cover_kind = deck.get("cover") if deck.get("cover") in ("left", "center", "offset", "stack") else "left"
        self.t = THEMES[self.theme]
        self.seed = zlib.crc32(f"{deck.get('date', '')}{self.theme}".encode("utf-8"))
        self.line = rgba(self.t["line"])
        self.fit = {}

    # ---- 尺寸
    def c(self, lo, vw, hi):
        return max(lo, min(hi, self.W * vw / 100))

    def col(self, k, a=None):
        return rgba(self.t[k], a)

    def pix(self):
        pm = QPixmap(int(self.W * self.dpr), int(self.H * self.dpr))
        pm.setDevicePixelRatio(self.dpr)
        pm.fill(Qt.GlobalColor.transparent)
        return pm

    @staticmethod
    def begin(pm):
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        return p

    # ---- 夜景底板
    def _glow(self, p, cx, cy, rx, ry, color, stop=1.0):
        """一团柔光：中心 color，到 stop 处完全透明。"""
        g = QRadialGradient(QPointF(0, 0), 1)
        c1 = QColor(color)
        c1.setAlpha(0)
        g.setColorAt(0, color)
        g.setColorAt(stop, c1)
        g.setColorAt(1, c1)
        b = QBrush(g)
        b.setTransform(QTransform().translate(cx, cy).scale(rx, ry))
        p.fillRect(QRectF(0, 0, self.W, self.H), b)

    def plate(self, cover):
        """cover=True 是封面，夜景完整；内容页把夜景压暗，只留气氛，不和文字抢。"""
        pm = self.pix()
        p = self.begin(pm)
        W, H = self.W, self.H
        g = QLinearGradient(0, 0, W * .35, H)
        g.setColorAt(0, QColor(self.t["bg"]))
        g.setColorAt(1, QColor(self.t["bg2"]))
        p.fillRect(QRectF(0, 0, W, H), g)
        rng = random.Random(self.seed)
        getattr(self, "_scene_" + self.theme)(p, rng, 1.0 if cover else 0.42)
        if self.t["dark"]:   # 四角压暗：视线落在中间
            v = QColor(0, 0, 0, 96 if cover else 70)
            self._vignette(p, v)
        p.end()
        return pm

    def _vignette(self, p, color):
        W, H = self.W, self.H
        g = QRadialGradient(QPointF(0, 0), 1)
        c0 = QColor(color)
        c0.setAlpha(0)
        g.setColorAt(0.62, c0)
        g.setColorAt(1, color)
        b = QBrush(g)
        b.setTransform(QTransform().translate(W / 2, H / 2).scale(W * .74, H * .86))
        p.fillRect(QRectF(0, 0, W, H), b)

    def _moon_disc(self, p, cx, cy, r, color, k):
        c = QColor(color)
        c.setAlphaF(.10 * k)
        self._glow(p, cx, cy, r * 4.2, r * 4.2, c, .96)
        if k >= 1:   # 内容页只留月晕：实心的月亮会压到标题
            c.setAlphaF(.82)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(c)
            p.drawEllipse(QPointF(cx, cy), r, r)

    @staticmethod
    def _ridge_line(rng, W, base, amp, rough):
        """由几组正弦叠出的一条山脊（或潮线）：返回函数 x → y。"""
        waves = [(rng.uniform(.6, 1.4) * (2 ** i) * math.tau / W, rng.uniform(0, math.tau), amp / (1.6 ** i) * rng.uniform(.7, 1.2)) for i in range(rough)]
        return lambda x: base + sum(a * math.sin(f * x + ph) for f, ph, a in waves)

    def _scene_tide(self, p, rng, k):
        """观澜：一层层潮线从下面涌上来，月光在水面碎成几道。"""
        W, H = self.W, self.H
        mx, my = W * rng.uniform(.68, .84), H * rng.uniform(.14, .24)
        self._moon_disc(p, mx, my, self.c(20, 2.1, 38), QColor("#E9DCBB"), k)
        top = H * .60
        layers = 9
        for i in range(layers):
            t = i / (layers - 1)
            base = top + (H - top) * (t ** 1.35) * .96
            f = self._ridge_line(rng, W, base, H * (.010 + .018 * t), 3)
            path = QPainterPath(QPointF(0, f(0)))
            for x in range(0, int(W) + 24, 24):
                path.lineTo(x, f(x))
            fill = QPainterPath(path)
            fill.lineTo(W, H)
            fill.lineTo(0, H)
            fill.closeSubpath()
            c = QColor(10 + int(6 * t), 42 + int(20 * t), 50 + int(22 * t))
            c.setAlphaF((.16 + .10 * t) * k)
            p.fillPath(fill, c)
            p.setPen(QPen(rgba((124, 198, 188, (.16 + .26 * (1 - t)) * k)), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
        # 月光碎影：越靠近岸越宽、越淡
        for i in range(14):
            t = i / 13
            y = top + (H - top) * .9 * t + rng.uniform(-4, 4)
            w = self.c(30, 3, 60) * (1 + 3.4 * t) * rng.uniform(.6, 1.2)
            x = mx - w / 2 + rng.uniform(-20, 20) * (1 + t)
            p.fillRect(QRectF(x, y, w, 1.4), rgba((233, 220, 187, (.34 - .24 * t) * k)))

    def _scene_ridge(self, p, rng, k):
        """远山：月亮 + 四层山，越远越淡，山脚起雾。"""
        W, H = self.W, self.H
        # 左版式的文字靠右，月亮就放左边；其他版式放右边，都不和大字相撞
        mx = rng.uniform(.14, .30) if self.cover_kind == "left" else rng.uniform(.70, .84)
        self._moon_disc(p, W * mx, H * rng.uniform(.20, .27), self.c(26, 2.8, 50), QColor("#EDE4C8"), k)
        cols = (((34, 46, 44), .55), ((26, 38, 35), .72), ((18, 28, 26), .88), ((11, 18, 17), 1.0))
        for i, (rgb, a) in enumerate(cols):
            base = H * (.56 + .105 * i)
            f = self._ridge_line(rng, W, base, H * (.070 - .010 * i), 5)
            path = QPainterPath(QPointF(0, f(0)))
            for x in range(0, int(W) + 10, 10):
                path.lineTo(x, f(x))
            path.lineTo(W, H)
            path.lineTo(0, H)
            path.closeSubpath()
            p.fillPath(path, rgba((*rgb, a * k)))
            mist = QLinearGradient(0, base - H * .02, 0, base + H * .13)
            mist.setColorAt(0, rgba((188, 203, 186, 0)))
            mist.setColorAt(.6, rgba((188, 203, 186, .055 * k)))
            mist.setColorAt(1, rgba((188, 203, 186, 0)))
            p.fillRect(QRectF(0, base - H * .02, W, H * .15), mist)

    def _scene_stars(self, p, rng, k):
        """观星：一幅星图：同心圆、刻度、散星和两组连线。"""
        W, H = self.W, self.H
        cx, cy = W * rng.uniform(.70, .82), H * rng.uniform(.46, .56)
        R = min(W, H) * .56
        line = (174, 182, 230)
        p.setBrush(Qt.BrushStyle.NoBrush)
        for i in range(1, 6):
            p.setPen(QPen(rgba((*line, .13 * k)), 1))
            p.drawEllipse(QPointF(cx, cy), R * i / 5, R * i / 5)
        for i in range(0, 12):
            a = math.tau * i / 12
            p.setPen(QPen(rgba((*line, .08 * k)), 1))
            p.drawLine(QPointF(cx + math.cos(a) * R * .2, cy + math.sin(a) * R * .2), QPointF(cx + math.cos(a) * R, cy + math.sin(a) * R))
        for i in range(0, 120):   # 外圈刻度
            a = math.tau * i / 120
            n = 10 if i % 10 == 0 else 5
            p.setPen(QPen(rgba((*line, (.34 if i % 10 == 0 else .16) * k)), 1))
            p.drawLine(QPointF(cx + math.cos(a) * R, cy + math.sin(a) * R), QPointF(cx + math.cos(a) * (R + n), cy + math.sin(a) * (R + n)))
        p.setPen(Qt.PenStyle.NoPen)
        for _i in range(int(W * H / 5200)):
            x, y = rng.uniform(0, W), rng.uniform(0, H)
            big = rng.random() < .08
            p.setBrush(rgba((230, 232, 250, rng.uniform(.34, .86 if big else .55) * k)))
            r = rng.uniform(1.0, 1.8) if big else rng.uniform(.4, .9)
            p.drawEllipse(QPointF(x, y), r, r)
        for _c in range(2):
            a0, d0 = rng.uniform(0, math.tau), rng.uniform(.3, .8) * R
            pts = []
            for _j in range(rng.randint(5, 7)):
                pts.append(QPointF(cx + math.cos(a0) * d0, cy + math.sin(a0) * d0))
                a0 += rng.uniform(.14, .34)
                d0 = max(R * .2, min(R * .95, d0 + rng.uniform(-.12, .12) * R))
            p.setPen(QPen(rgba((234, 219, 174, .34 * k)), 1))
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(rgba((234, 219, 174, .9 * k)))
            for pt in pts:
                p.drawEllipse(pt, 2.1, 2.1)

    def _scene_lamp(self, p, rng, k):
        """灯下：角上一盏灯的暖光落在桌面上，光里飘着一点尘。"""
        W, H = self.W, self.H
        lx, ly = W * .80, H * .04
        self._glow(p, lx, ly, W * .62, H * .92, rgba((221, 164, 99, .24 * k)), .98)
        self._glow(p, lx, ly, W * .20, H * .34, rgba((243, 211, 160, .20 * k)), .98)
        desk = H * .86
        g = QLinearGradient(0, desk, 0, H)
        g.setColorAt(0, rgba((70, 44, 24, .50 * k)))
        g.setColorAt(1, rgba((30, 19, 11, .72 * k)))
        p.fillRect(QRectF(0, desk, W, H - desk), g)
        edge = QLinearGradient(0, 0, W, 0)
        edge.setColorAt(0, rgba((221, 164, 99, 0)))
        edge.setColorAt(.8, rgba((243, 211, 160, .48 * k)))
        edge.setColorAt(1, rgba((221, 164, 99, .1 * k)))
        p.fillRect(QRectF(0, desk, W, 1), edge)
        self._glow(p, lx, desk, W * .42, H * .10, rgba((243, 211, 160, .15 * k)), .98)
        p.setPen(Qt.PenStyle.NoPen)
        for _i in range(46):
            a, d = rng.uniform(1.6, 3.0), rng.uniform(.1, .9)
            x, y = lx + math.cos(a) * W * .5 * d, ly + math.sin(a) * H * .9 * d
            p.setBrush(rgba((243, 211, 160, rng.uniform(.10, .42) * (1 - d * .6) * k)))
            r = rng.uniform(.6, 1.7)
            p.drawEllipse(QPointF(x, y), r, r)

    def _scene_moon(self, p, rng, k):
        """月白：一张压低了亮度的信笺：乌丝栏、纸纤维、一轮淡月。"""
        W, H = self.W, self.H
        step = self.c(46, 4.6, 88)
        for i, x in enumerate(range(int(step), int(W), int(step))):
            p.fillRect(QRectF(x, 0, 1, H), rgba((147, 54, 42, .085 * (0.6 + .4 * k))))
        p.setPen(Qt.PenStyle.NoPen)
        for _i in range(int(W * H / 2600)):
            x, y = rng.uniform(0, W), rng.uniform(0, H)
            a = rng.uniform(0, math.tau)
            ln = rng.uniform(5, 26)
            p.setPen(QPen(rgba((70, 54, 38, rng.uniform(.02, .07)), None), .7))
            p.drawLine(QPointF(x, y), QPointF(x + math.cos(a) * ln, y + math.sin(a) * ln))
        p.setPen(Qt.PenStyle.NoPen)
        cx, cy, r = W * rng.uniform(.70, .80), H * rng.uniform(.42, .48), min(W, H) * .24
        p.setBrush(rgba((226, 220, 204, .50 * k)))
        p.drawEllipse(QPointF(cx, cy), r, r)
        p.setPen(QPen(rgba((147, 54, 42, .22 * k)), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx, cy), r * 1.05, r * 1.05)

    # ---- 封面（动态部分由 alpha 控制）
    def cover_static(self):
        """封面上不动的文字；暮、省二字和短线单独画，好做入场动画。返回 (pixmap, 动态元素的位置)。"""
        pm = self.pix()
        p = self.begin(pm)
        W, H, d, k = self.W, self.H, self.deck, self.cover_kind
        padx, pady = self.c(30, 6, 112), self.c(26, 4.2, 66)
        bot = self.c(24, 3.2, 48)
        hud_f = make_font(MONO, self.c(10, 0.78, 13), 400, self.c(10, 0.78, 13) * 0.18)
        brand_f = make_font(MONO, self.c(10, 0.78, 13), 400, self.c(10, 0.78, 13) * 0.26)
        Text("观澜 · 晚间副刊", make_font(SANS, self.c(11, 0.86, 14), 400, 3), self.col("accent"), W).draw(p, padx, pady)
        no = Text(f"第 {d.get('issue', '')} 期", make_font(SANS, self.c(11, 0.86, 14), 400, 1), self.col("muted"), 420, align="right")
        no.draw(p, W - padx - 108 - 420, pady)
        Text("把今天放下，再睡", make_font(SANS, self.c(11, 0.86, 14), 400, 2), self.col("dim"), W).draw(p, padx, H - bot - self.c(11, 0.86, 14) * 1.5)
        mark_size = self.c(*MARK_SIZE)
        if k == "offset":
            mark_size = self.c(140, 19, 272)
        elif k == "stack":
            mark_size = self.c(104, 13, 180)
        # 矮屏幕别让大字把封面撑破
        mark_size = min(mark_size, H * (0.30 if k == "stack" else 0.42))
        ey_f = make_font(SANS, self.c(10, 0.78, 13), 400, self.c(10, 0.78, 13) * 0.52)
        ki_f = make_font(SERIF, self.c(15, 1.2, 20), 400, self.c(15, 1.2, 20) * 0.18)
        da_f = make_font(SERIF, self.c(23, 2.3, 38), 400, self.c(23, 2.3, 38) * 0.08)
        me_f = make_font(MONO, self.c(11, 0.95, 15), 400, self.c(11, 0.95, 15) * 0.18)
        meta = f"今日 {d.get('count', 0)} 则 · 约 {d.get('minutes', 15)} 分钟"
        ey, ki, da = f"今夜 · {self.t['name']}", "先静三分钟", d.get("date_long", "")
        line_w = self.c(100, 10, 170)
        anim = dict(mark_size=mark_size, line_w=line_w)
        area_top, area_bot = pady + 30, H - bot - 30
        if k == "offset":
            lw = min(W - 2 * padx, 1540)
            x0 = (W - lw) / 2 if lw < W - 2 * padx else padx
            gap = self.c(30, 5, 88)
            lcol = (lw - gap) * 0.82 / 2.0
            items = [(Text(ey, ey_f, self.col("accent"), lcol), 0), (Text(ki, ki_f, self.col("soft"), lcol, lh=1.6), self.c(10, 1.2, 18)),
                     (Text(da, da_f, self.col(self.t["date"]), lcol, lh=1.3), self.c(28, 4, 58))]
            h1 = stack_h(items)
            lmargin = self.c(14, 1.8, 24)
            metat = Text(meta, me_f, self.col("muted"), lcol, lh=1.5)
            total = h1 + lmargin * 2 + 1 + metat.h
            y0 = (area_top + area_bot - total) / 2
            y = stack(p, x0, y0, items)
            anim.update(line_x=x0, line_y=y + lmargin, line_grad="left")
            metat.draw(p, x0, y + lmargin * 2 + 1)
            anim.update(mark_x=x0 + lw - mark_size * 2.1, mark_y=(area_top + area_bot) / 2 - mark_size * 0.5, mark_stack=False)
        else:
            center = k == "center"
            flip = k == "left" and self.theme == "ridge"   # 远山的月亮常在左上，文字靠右让开
            main_w = min(W - 2 * padx, 1120 if center else 920 if k == "stack" else 1180)
            x0 = (W - main_w) / 2 if center else (W - padx - main_w) if flip else padx
            align = "center" if center else "right" if flip else "left"
            mark_h = mark_size * (1.96 if k == "stack" else 0.92)
            e_m, k_m = self.c(28, 4, 58), self.c(30, 3.4, 54)
            d_m = self.c(26, 2.4, 38) if k == "stack" else self.c(22, 2.2, 32)
            l_m = self.c(20, 2.2, 30)
            te, tk = Text(ey, ey_f, self.col("accent"), main_w, align=align), Text(ki, ki_f, self.col("soft"), main_w, lh=1.6, align=align)
            td, tm = Text(da, da_f, self.col(self.t["date"]), main_w, lh=1.3, align=align), Text(meta, me_f, self.col("muted"), main_w, lh=1.5, align=align)
            total = te.h + e_m + tk.h + k_m + mark_h + d_m + td.h + l_m * 2 + 1 + tm.h
            if total > area_bot - area_top:   # 矮屏幕压缩留白
                shrink = max(0.25, 1 - (total - (area_bot - area_top)) / max(1, e_m + k_m + d_m + 2 * l_m))
                e_m, k_m, d_m, l_m = e_m * shrink, k_m * shrink, d_m * shrink, l_m * shrink
                total = te.h + e_m + tk.h + k_m + mark_h + d_m + td.h + l_m * 2 + 1 + tm.h
            y = (area_top + area_bot - total) / 2
            te.draw(p, x0, y)
            y += te.h + e_m
            tk.draw(p, x0, y)
            y += tk.h + k_m
            mw = mark_size * 2.09
            anim.update(mark_x=(W - mw) / 2 if center else (W - padx - mw) if flip else x0, mark_y=y, mark_stack=k == "stack")
            y += mark_h + d_m
            td.draw(p, x0, y)
            y += td.h + l_m
            anim.update(line_x=(W - line_w) / 2 if center else (W - padx - line_w) if flip else x0, line_y=y, line_grad="center" if center else "left")
            y += 1 + l_m
            tm.draw(p, x0, y)
        p.end()
        anim.update(padx=padx, bot=bot)
        return pm, anim

    # ---- 页眉
    def hud(self):
        pm = self.pix()
        p = self.begin(pm)
        W, d = self.W, self.deck
        padx, top = self.c(28, 5, 88), self.c(22, 3, 46)
        fs = self.c(11, 0.86, 14)
        brand = Text("暮省", make_font(SERIF, self.c(17, 1.5, 23), 400, self.c(17, 1.5, 23) * 0.22), self.col("accent"), 200)
        brand.draw(p, padx, top)
        Text(d.get("date_short", ""), make_font(MONO, fs, 400, fs * 0.14), self.col("muted"), 500).draw(p, padx + brand.natural_width() + 18, top + (brand.h - fs * 1.5) / 2)
        pad_b = self.c(12, 1.4, 20)
        y = top + brand.h + pad_b
        p.fillRect(QRectF(padx, y, W - 2 * padx, 1), self.line)
        p.end()
        return pm, dict(padx=padx, top=top, hud_h=brand.h, rule_y=y, fs=fs)

    def hud_right(self, p, section, count, geo):
        W = self.W
        fs = geo["fs"]
        f = make_font(MONO, fs, 400, fs * 0.14)
        fm = QFontMetricsF(f)
        x = W - geo["padx"] - 108
        y = geo["top"] + (geo["hud_h"] - fs * 1.5) / 2
        for text, key in ((count, "muted"), (section, "accent2"), (f"第 {self.deck.get('issue', '')} 期", "muted")):
            w = fm.horizontalAdvance(text) + 2
            x -= w
            Text(text, f, self.col(key), w + 6).draw(p, x, y)
            x -= 24

    # ---- 一页内容
    def slide_area(self, geo):
        padx = geo["padx"]
        bot = self.c(18, 2.4, 34) + self.c(10, 1.2, 16) + 1
        pad_y = self.c(26, 4, 64)
        return padx, geo["rule_y"] + 1 + pad_y, self.W - 2 * padx, self.H - bot - pad_y - geo["rule_y"] - 1 - pad_y

    def slide(self, s, geo):
        """把一页画成透明 pixmap；放不下时整页缩小。"""
        pm = self.pix()
        p = self.begin(pm)
        x, y, w, h = self.slide_area(geo)
        kind = s.get("kind")
        if kind != "end":
            gap = self.c(30, 5, 88)
            rail_w = max(80, (w - gap) * 0.23 / 1.23)
            self._rail(p, s, x, y, rail_w, h)
            bx, bw = x + rail_w + gap, w - rail_w - gap
        else:
            bx, bw = x, w
        fn = getattr(self, "_s_" + str(kind), None)
        scale = 1.0
        if fn:
            while True:
                body_h, draw = fn(s, bw, scale)
                if body_h <= h or scale <= 0.55:
                    break
                scale -= 0.04
            self.fit[id(s)] = (scale, body_h, h)
            draw(p, bx, y + (h - body_h) / 2)
        p.end()
        return pm

    def _rail(self, p, s, x, y, w, h):
        pad = self.c(8, 1.4, 20)
        right = x + w
        p.fillRect(QRectF(right, y, 1, h), self.line)
        idx = make_font(SERIF, self.c(24, 2.8, 48))
        Text(f"{int(s.get('rail_index') or 0):02d}", idx, self.col("accent"), w).draw(p, x, y + pad)
        size = self.c(10, 0.78, 13)
        f = make_font(SANS, size)
        step = size * 1.5
        label = str(s.get("rail_label") or "")
        lx = right - self.c(16, 2, 28) - size
        seal = self.t.get("seal", False)
        by = y + h - pad - (self.c(62, 6, 82) if seal else 0)
        ly = by - len(label) * step
        p.setPen(self.col("muted"))
        p.setFont(f)
        for i, ch in enumerate(label):
            p.drawText(QRectF(lx - size / 2, ly + i * step, size * 2, step), Qt.AlignmentFlag.AlignCenter, ch)
        if seal:   # 宣纸版的朱印
            sz = self.c(36, 3.2, 46)
            sx, sy = right - sz, y + h - sz
            p.setPen(QPen(self.col("accent", 0.62), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(QRectF(sx, sy, sz, sz))
            p.setPen(self.col("accent", 0.85))
            p.setFont(make_font(SERIF, self.c(18, 1.7, 24)))
            p.drawText(QRectF(sx, sy, sz, sz), Qt.AlignmentFlag.AlignCenter, "观")

    def _h2(self, text, w, px, scale=1.0, balance=True):
        """标题 + 各材质的装饰线，返回 stack 项。"""
        t = Text(text, make_font(SERIF, px * scale, 500), self.col("ink"), w, lh=1.22, balance=balance)
        pad = self.c(12, 1.4, 18)
        items = []
        rule = self.t.get("rule")
        if rule == "top":
            items += [(Rule(w, self.line), 0), (None, pad)]
        items.append((t, 0))
        if rule == "bottom":
            items += [(None, self.c(10, 1.2, 16)), (Rule(w, self.col("accent", 0.3)), 0)]
        return items

    def _meta(self, s, w, scale=1.0):
        fs = self.c(14, 1, 16) * max(scale, 0.8)
        return Text(s.get("meta", ""), make_font(MONO + SANS, fs, 400, fs * 0.06), self.col("muted"), w)

    def _s_lead(self, s, w, scale):
        w = min(w, 1220, self.W * 0.88)
        items = self._h2(s.get("title"), w, self.c(40, 5.1, 86), scale)
        items.append((None, self.c(18, 2.2, 30) * scale))
        q = s.get("question")
        qt = None
        if q:
            pad = self.c(16, 1.6, 22)
            qw = min(w, 980) - pad
            e = Text("留一个问题", make_font(SANS, 12, 400, 2.2), self.col("muted"), qw, lh=1.6)
            body = Text(q, make_font(SERIF, self.c(18, 1.45, 24) * scale), self.col("accent2"), qw, lh=1.7)
            qt = _Quote(e, body, pad, self.col("accent"))
            items += [(qt, 0), (None, self.c(22, 2.6, 34) * scale)]
        items.append((Text(s.get("summary"), make_font(SANS, self.c(18, 1.5, 25) * scale), self.col("soft"), min(w, 980), lh=1.9 if scale > 0.8 else 1.7, justify=True), 0))
        items.append((self._meta(s, w, scale), self.c(22, 2.5, 36) * scale))
        return stack_h(items), lambda p, x, y: stack(p, x, y, items)

    def _s_story(self, s, w, scale):
        w = min(w, 1160, self.W * 0.88)
        items = []
        if s.get("tags"):
            items += [(_Pills(s["tags"], self), 0), (None, 20 * scale)]
        items += self._h2(s.get("title"), w, self.c(34, 4.2, 72), scale, balance=False)
        items.append((None, self.c(18, 2.2, 30) * scale))
        items.append((Text(s.get("summary"), make_font(SANS, self.c(17, 1.35, 22) * scale), self.col("soft"), min(w, 980), lh=1.9 if scale > 0.8 else 1.7, justify=True), 0))
        items.append((self._meta(s, w, scale), self.c(22, 2.5, 36) * scale))
        return stack_h(items), lambda p, x, y: stack(p, x, y, items)

    def _seal(self, p, cx, cy, r, ch, inner=True):
        p.setPen(QPen(self.col("accent"), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx, cy), r, r)
        if inner:
            p.setPen(QPen(self.line, 1))
            p.drawEllipse(QPointF(cx, cy), r - 14, r - 14)
        p.setPen(self.col("accent2"))
        p.setFont(make_font(SERIF, r * 0.84))
        p.drawText(QRectF(cx - r, cy - r, 2 * r, 2 * r), Qt.AlignmentFlag.AlignCenter, str(ch)[:2])

    def _s_person(self, s, w, scale):
        w = min(w, 1160, self.W * 0.88)
        seal = self.c(150, 14, 240) * scale
        gap = self.c(34, 5, 78)
        rw = w - seal - gap
        n = Text(s.get("name"), make_font(SERIF, self.c(42, 4.6, 78) * scale, 500), self.col("ink"), rw, lh=1.1)
        lat = Text(s.get("latin"), make_font(MONO, self.c(10, 0.8, 13), 400, 2), self.col("accent"), rw)
        ide = Text(s.get("identity"), make_font(SANS, self.c(16, 1.2, 20) * scale), self.col("muted"), rw)
        hd = Text(s.get("headline"), make_font(SERIF, self.c(20, 1.8, 30) * scale), self.col("accent2"), rw, lh=1.6)
        st = Text(s.get("story"), make_font(SANS, self.c(15, 1.1, 18) * scale), self.col("soft"), rw, lh=1.85, justify=True)
        items = [(n, 0), (lat, 10), (ide, 12), (hd, 20 * scale), (st, 16 * scale)]
        moments = s.get("moments") or []
        if moments:
            items += [(None, self.c(20, 2.4, 32) * scale), (Rule(rw, self.line), 0), (None, self.c(14, 1.8, 24) * scale), (_Moments(moments, rw, self, scale), 0)]
        H = stack_h(items)

        def draw(p, x, y):
            self._seal(p, x + seal / 2, y + H / 2, seal / 2, s.get("monogram", ""))
            stack(p, x + seal + gap, y, items)
        return max(H, seal), draw

    def _s_people(self, s, w, scale):
        w = min(w, 1540, self.W * 0.94)
        h2 = Text(s.get("title", "今夜三个人"), make_font(SERIF, self.c(32, 3.4, 54) * scale, 500), self.col("ink"), w * 0.6, lh=1.15)
        sub = Text(s.get("sub", ""), make_font(SERIF, self.c(15, 1.15, 19) * scale, 400, 1), self.col("muted"), w * 0.4, align="right")
        pb = self.c(14, 1.6, 20)
        head_h = h2.h + pb + 1
        cards = s.get("cards") or []
        n = max(1, len(cards))
        gap = self.c(22, 3, 44)
        cw = (w - gap * (n - 1)) / n
        built = [self._card(c, cw, scale) for c in cards]
        ch = max([b[0] for b in built] + [0])
        vg = self.c(24, 3, 42) * scale

        def draw(p, x, y):
            h2.draw(p, x, y)
            sub.draw(p, x + w * 0.6, y + h2.h - sub.h)
            p.fillRect(QRectF(x, y + h2.h + pb, w, 1), self.line)
            yy = y + head_h + vg
            for i, b in enumerate(built):
                b[1](p, x + i * (cw + gap), yy, ch)
        return head_h + vg + ch, draw

    def _card(self, c, w, scale):
        size = self.c(44, 4, 58) * scale
        top_x = size + 14
        name = Text(c.get("name"), make_font(SERIF, self.c(28, 2.8, 42) * scale), self.col("ink"), w - top_x, lh=1.1)
        lat = Text(" · ".join(x for x in (c.get("latin"), c.get("years")) if x), make_font(MONO, 9, 400, 1.2), self.col("accent"), w - top_x)
        top_h = max(size, name.h + 5 + lat.h)
        ide = Text(c.get("identity"), make_font(SANS, self.c(12, 0.92, 15) * scale), self.col("muted"), w, lh=1.6)
        hl = Text(c.get("headline"), make_font(SERIF, self.c(17, 1.35, 22) * scale), self.col("accent2"), w, lh=1.65)
        st = Text(c.get("story"), make_font(SANS, self.c(13, 0.95, 16) * scale), self.col("soft"), w, lh=1.85)
        items = [(ide, 8), (hl, 12), (st, 12)]
        mo = c.get("moment")
        if mo:
            items.append((_MomentBar(mo, w, self, scale), 16))
        q = c.get("quote")
        qt = Text(f"“{q}”", make_font(SERIF, self.c(12, 0.9, 15) * scale), self.col("muted"), w, lh=1.65) if q else None
        pt = self.c(16, 1.7, 22)
        body = top_h + 14 + stack_h(items)
        qh = (16 + 16 + qt.h) if qt else 0
        H = 1 + pt + body + qh

        def draw(p, x, y, full):
            p.fillRect(QRectF(x, y, w, 1), self.col("accent"))
            yy = y + 1 + pt
            cy = yy + top_h / 2
            self._seal(p, x + size / 2, cy, size / 2, c.get("monogram", ""), inner=False)
            name.draw(p, x + top_x, cy - (name.h + 5 + lat.h) / 2)
            lat.draw(p, x + top_x, cy - (name.h + 5 + lat.h) / 2 + name.h + 5)
            stack(p, x, yy + top_h + 14, items)
            if qt:   # 金句贴底
                qy = y + full - qt.h
                p.fillRect(QRectF(x, qy - 16, w, 1), self.line)
                qt.draw(p, x, qy)
        return H, draw

    def _s_quotes(self, s, w, scale):
        h2 = self._h2(s.get("title", "把一句话，带到明天"), w, self.c(34, 4.2, 72), scale, balance=False)
        cards = s.get("cards") or []
        n = max(1, len(cards))
        gap = self.c(18, 2.5, 34)
        cw = (w - gap * (n - 1)) / n
        built = []
        pt = self.c(20, 2.4, 34) * scale
        for c in cards:
            bq = Text(c.get("text"), make_font(SERIF, self.c(20, 1.65, 28) * scale), self.col("ink"), cw, lh=1.72)
            au = Text(c.get("author"), make_font(MONO + SANS, self.c(10, 0.8, 12), 400, 1.2), self.col("accent2"), cw, lh=1.5)
            us = Text(c.get("use"), make_font(SANS, self.c(12, 0.9, 14) * scale), self.col("muted"), cw, lh=1.65)
            built.append((bq, au, us))
        tail = max([b[1].h + 12 + b[2].h for b in built] + [0])
        top = max([b[0].h for b in built] + [0])
        ch = max(1 + pt + top + 22 + tail, self.H * 0.26 * scale)
        h2h = stack_h(h2)
        m = self.c(18, 2.2, 30) * scale + 6

        def draw(p, x, y):
            yy = stack(p, x, y, h2) + m
            for i, (bq, au, us) in enumerate(built):
                cx = x + i * (cw + gap)
                p.fillRect(QRectF(cx, yy, cw, 1), self.col("accent"))
                bq.draw(p, cx, yy + 1 + pt)
                bottom = yy + ch
                us.draw(p, cx, bottom - us.h)
                au.draw(p, cx, bottom - us.h - 12 - au.h)
        return h2h + m + ch, draw

    def _s_term(self, s, w, scale):
        gap = self.c(34, 5, 84)
        lw = (w - gap) * 1.05 / 2
        rw = (w - gap) * 0.95 / 2
        word = Text(s.get("term"), make_font(SERIF, self.c(56, 7, 118) * scale), self.col("ink"), lw, lh=1.1)
        en = Text(s.get("en"), make_font(MONO, self.c(10, 0.8, 13), 400, 2), self.col("accent"), lw)
        de = Text(s.get("definition"), make_font(SANS, self.c(17, 1.35, 22) * scale), self.col("soft"), lw, lh=1.85, justify=True)
        left = [(word, 0), (en, 14), (de, self.c(22, 2.6, 36) * scale)]
        pad = self.c(20, 3, 44)
        tw = rw - pad
        right = []
        for i, (k, v) in enumerate(s.get("side") or []):
            right.append((Text(k, make_font(SANS, self.c(13, 1, 16) * scale, 400, 1.5), self.col("accent2"), tw), 16 if i else 0))
            right.append((Text(v, make_font(SANS, self.c(13, 1, 16) * scale), self.col("muted"), tw, lh=1.8), 4))
        lh, rh = stack_h(left), stack_h(right)
        H = max(lh, rh)

        def draw(p, x, y):
            stack(p, x, y + (H - lh) / 2, left)
            rx = x + lw + gap
            p.fillRect(QRectF(rx, y + (H - rh) / 2, 1, rh), self.line)
            stack(p, rx + pad, y + (H - rh) / 2, right)
        return H, draw

    def _s_end(self, s, w, scale):
        mk = Text("今夜已尽", make_font(SERIF, self.c(62, 9, 148) * scale, 400, self.c(62, 9, 148) * 0.08 * scale), self.col("ink"), w, lh=1.2, align="center")
        sub = Text(s.get("sub", ""), make_font(SERIF, self.c(17, 1.4, 24) * scale), self.col("muted"), w, align="center")
        hint = Text("Esc 退出  ·  空格重播  ·  ← 回到上一页", make_font(SANS, self.c(11, 0.85, 13), 400, 1.5), self.col("muted"), w, align="center")
        items = [(mk, 0), (sub, 22), (hint, 48)]
        return stack_h(items), lambda p, x, y: stack(p, x, y, items)


class _Quote:
    """左边一条竖线的「留一个问题」。"""

    def __init__(self, e, body, pad, color):
        self.e, self.body, self.pad, self.color = e, body, pad, color
        self.h = e.h + 8 + body.h

    def draw(self, p, x, y):
        p.fillRect(QRectF(x, y, 2, self.h), self.color)
        self.e.draw(p, x + self.pad, y)
        self.body.draw(p, x + self.pad, y + self.e.h + 8)


class _Pills:
    def __init__(self, tags, P):
        self.P = P
        self.fs = P.c(9, 0.72, 11)
        self.f = make_font(MONO + SANS, self.fs, 400, self.fs * 0.12)
        self.tags = [str(t) for t in tags]
        self.h = self.fs * 1.5 + 10

    def draw(self, p, x, y):
        fm = QFontMetricsF(self.f)
        for t in self.tags:
            w = fm.horizontalAdvance(t) + 22
            p.setPen(QPen(self.P.line, 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(QRectF(x, y, w, self.h), self.h / 2, self.h / 2)
            p.setFont(self.f)
            p.setPen(self.P.col("muted"))
            p.drawText(QRectF(x, y, w, self.h), Qt.AlignmentFlag.AlignCenter, t)
            x += w + 10


class _Moments:
    def __init__(self, moments, w, P, scale):
        gap = P.c(14, 2, 26)
        self.cw = (w - gap * 2) / 3
        self.gap = gap
        fs = P.c(12, 0.9, 15) * scale
        self.cols = [(Text(m.get("year"), make_font(MONO, fs, 400, fs * 0.14), P.col("accent"), self.cw), Text(m.get("text"), make_font(SANS, fs), P.col("muted"), self.cw, lh=1.55)) for m in moments[:3]]
        self.h = max([a.h + 7 + b.h for a, b in self.cols] + [0])

    def draw(self, p, x, y):
        for i, (a, b) in enumerate(self.cols):
            cx = x + i * (self.cw + self.gap)
            a.draw(p, cx, y)
            b.draw(p, cx, y + a.h + 7)


class _MomentBar:
    def __init__(self, m, w, P, scale):
        fs = P.c(11, 0.82, 13) * scale
        self.a = Text(m.get("year"), make_font(MONO, fs, 400, fs * 0.1), P.col("accent2"), w - 12, lh=1.65)
        self.b = Text(m.get("text"), make_font(SANS, fs), P.col("muted"), w - 12, lh=1.65)
        self.color = P.col("accent")
        self.h = self.a.h + self.b.h

    def draw(self, p, x, y):
        p.fillRect(QRectF(x, y, 2, self.h), self.color)
        self.a.draw(p, x + 12, y)
        self.b.draw(p, x + 12, y + self.a.h)


class EveningWindow(QWidget):
    def __init__(self, deck, texture=None, cover_ms=COVER_MS):
        super().__init__()
        self.deck, self.texture = deck, texture
        self.cover_ms = cover_ms
        self.slides = deck.get("slides") or []
        self.setWindowTitle(deck.get("title") or "暮省")
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.phase = "cover"
        self.t0 = time.perf_counter()
        self.cur = 0
        self.prev_i = None
        self.slide_t = 0.0
        self.paused, self.ended = False, False
        self.total, self.remaining, self.started = 1.0, 1.0, 0.0
        self.controls_until = time.perf_counter() + 3.2
        self.hits = []
        self.P = None
        self.cache = {}
        self.exit_hover = False
        self.tick = QTimer(self)
        self.tick.setTimerType(Qt.TimerType.PreciseTimer)
        self.tick.timeout.connect(self._tick)
        self.tick.start(16)
        self._last_soft = 0.0
        self.preload = QTimer(self)
        self.preload.setSingleShot(True)
        self.preload.timeout.connect(self._preload_next)

    # ---- 素材
    def _prepare(self):
        w, h = self.width(), self.height()
        key = (w, h, self.devicePixelRatioF())
        if self.P and self.P_key == key:
            return
        self.P_key = key
        self.P = Painter(self.deck, w, h, self.texture, self.devicePixelRatioF())
        self.cache = {}
        self.plate_cover = self.P.plate(True)
        self.plate_deck = self.P.plate(False)
        self.cover_pm, self.cover_anim = self.P.cover_static()
        self.hud_pm, self.geo = self.P.hud()

    def _slide_pm(self, i):
        if i not in self.cache:
            self.cache[i] = self.P.slide(self.slides[i], self.geo)
        return self.cache[i]

    def _preload_next(self):
        if self.P and self.cur + 1 < len(self.slides):
            self._slide_pm(self.cur + 1)

    # ---- 状态
    def skip_cover(self):
        if self.phase == "cover":
            self.phase = "leaving"
            self.t0 = time.perf_counter()
            self.update()

    def show_slide(self, i, animate=True):
        if not self.slides:
            return
        i = max(0, min(len(self.slides) - 1, i))
        self.prev_i = self.cur if animate and i != self.cur else None
        self.cur = i
        self.ended = False
        self.paused = False
        d = max(6.0, float(self.slides[i].get("duration") or 20))
        self.total = self.remaining = d
        self.started = self.slide_t = time.perf_counter()
        self.preload.start(1000)   # 等这页的入场动画走完再排下一页
        self.wake()
        self.update()

    def next_slide(self):
        if self.ended:
            return
        if self.cur >= len(self.slides) - 1:
            self.finish()
        else:
            self.show_slide(self.cur + 1)

    def finish(self):
        self.ended, self.paused = True, False
        self.controls_until = math.inf
        self.update()

    def toggle_pause(self):
        if self.ended:
            self.controls_until = 0
            self.show_slide(0)
            return
        now = time.perf_counter()
        if not self.paused:
            self.paused = True
            self.remaining = max(0.6, self.remaining - (now - self.started))
        else:
            self.paused = False
            self.started = now
        self.wake()
        self.update()

    def go(self, delta):
        if self.phase == "cover":
            self.skip_cover()
            return
        if self.phase != "deck":
            return
        if delta > 0 and self.cur >= len(self.slides) - 1:
            self.finish()
            return
        if self.ended:
            self.controls_until = 0
        self.show_slide(self.cur + delta)

    def wake(self):
        if not self.ended:
            self.controls_until = time.perf_counter() + 3.2
        self.setCursor(Qt.CursorShape.ArrowCursor)

    def bar_ratio(self):
        if self.ended:
            return 1.0
        left = self.remaining if self.paused else self.remaining - (time.perf_counter() - self.started)
        return max(0.0, min(1.0, 1 - left / self.total))

    # ---- 节拍：动画时全屏重绘，静止时只刷进度条
    def _tick(self):
        now = time.perf_counter()
        el = now - self.t0
        if self.phase == "cover":
            if el * 1000 >= self.cover_ms:
                self.skip_cover()
            elif el < 2.0:
                self.update()
            elif now - self._last_soft > 0.25:
                self._last_soft = now
                self.update()
            return
        if self.phase == "leaving":
            if el >= 0.9:
                self.phase = "deck"
                self.t0 = now
                self.prev_i = None
                self.cur = 0
                self.show_slide(0, animate=False)
            self.update()
            return
        if self.phase != "deck":
            return
        if not self.paused and not self.ended and now - self.started >= self.remaining:
            self.next_slide()
        if el < 0.9 or now - self.slide_t < 0.85:
            self.update()
        elif now - self._last_soft > 0.1:
            self._last_soft = now
            if self.controls_until != math.inf and now > self.controls_until:
                if self.cursor().shape() != Qt.CursorShape.BlankCursor:
                    self.setCursor(Qt.CursorShape.BlankCursor)
                    self.update()
            self.update(0, self.height() - 120, self.width(), 120)   # 进度条与控制条都在底部

    # ---- 绘制
    def paintEvent(self, _e):
        self._prepare()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self.hits = []
        now = time.perf_counter()
        if self.phase in ("cover", "leaving"):
            if self.phase == "leaving":
                k = min(1.0, (now - self.t0) / 0.9)
                p.drawPixmap(0, 0, self.plate_deck)
                p.setOpacity(1 - k)
                s = 1 + 0.025 * ease(k)
                p.translate(self.width() / 2, self.height() / 2)
                p.scale(s, s)
                p.translate(-self.width() / 2, -self.height() / 2)
                self._paint_cover(p, 9.0)
                p.resetTransform()
                p.setOpacity(1)
            else:
                self._paint_cover(p, now - self.t0)
        else:
            self._paint_deck(p, now)
        self._paint_exit(p)
        p.end()

    def _paint_cover(self, p, el):
        P, W, H = self.P, self.width(), self.height()
        p.drawPixmap(0, 0, self.plate_cover)
        p.save()
        p.setOpacity(p.opacity() * ease(el / 1.15))
        p.drawPixmap(0, 0, self.cover_pm)
        p.restore()
        a = self.cover_anim
        # 暮省二字：上浮淡入
        k = ease((el - 0.08) / 1.5)
        size = a["mark_size"]
        f = make_font(SERIF, size, 500)
        p.save()
        p.setOpacity(p.opacity() * k)
        p.setFont(f)
        dy = 18 * (1 - k)
        x, y = a["mark_x"], a["mark_y"] + dy
        fm = QFontMetricsF(f)
        base = y + fm.ascent() - (fm.height() - size * 0.92) / 2
        step = size * 1.045
        mark2 = P.col(P.t["mark2"])
        for shadow in (True, False):
            for i, ch in enumerate("暮省"):
                if a["mark_stack"]:
                    cx, cy = x + (size * 0.5 if i else 0), base + i * size * 0.98
                else:
                    cx, cy = x + i * step, base
                if shadow:
                    if P.t["dark"]:
                        p.setPen(QColor(0, 0, 0, 60))
                        p.drawText(QPointF(cx, cy + size * 0.05), ch)
                else:
                    p.setPen(mark2 if i else P.col("ink"))
                    p.drawText(QPointF(cx, cy), ch)
        p.restore()
        # 短线：展开
        k = ease((el - 0.38) / 1.2)
        lw, lx, ly = a["line_w"], a["line_x"], a["line_y"]
        g = QLinearGradient(lx, 0, lx + lw, 0)
        if a["line_grad"] == "center":
            c0 = QColor(P.t["accent"])
            c0.setAlpha(0)
            g.setColorAt(0, c0)
            g.setColorAt(0.5, QColor(P.t["accent"]))
            g.setColorAt(1, c0)
            draw_x = lx + lw * (1 - k) / 2
        else:
            c0 = QColor(P.t["accent"])
            c0.setAlpha(0)
            g.setColorAt(0, QColor(P.t["accent"]))
            g.setColorAt(0.6, QColor(P.t["accent3"]))
            g.setColorAt(1, c0)
            draw_x = lx
        p.fillRect(QRectF(draw_x, ly, lw * k, 1), g)
        # 倒计时与进度
        left = max(0.0, self.cover_ms / 1000 - el)
        s = math.ceil(left)
        fs = P.c(10, 0.78, 13)
        foot_y = H - a["bot"] - fs * 1.5
        cd = Text(f"{s // 60:02d}:{s % 60:02d}", make_font(MONO, fs, 400, fs * 0.2), P.col("accent2"), fs * 6, align="right")
        cd.draw(p, W - a["padx"] - 108 - fs * 6, foot_y)
        lb = Text("静候  ·  按 → 开始", make_font(SANS, fs, 400, 1), P.col("muted"), 220, align="right")
        lb.draw(p, W - a["padx"] - 108 - fs * 6 - 8 - 220, foot_y + 1)
        ratio = min(1.0, el * 1000 / self.cover_ms)
        p.fillRect(QRectF(0, H - 2, W, 2), QColor(255, 255, 255, 13) if P.t["dark"] else QColor(0, 0, 0, 20))
        bar = QLinearGradient(0, 0, W, 0)
        bar.setColorAt(0, QColor(P.t["accent"]))
        bar.setColorAt(1, QColor(P.t["accent2"]))
        p.fillRect(QRectF(0, H - 2, W * ratio, 2), bar)

    def _paint_deck(self, p, now):
        P, W, H = self.P, self.width(), self.height()
        p.drawPixmap(0, 0, self.plate_deck)
        p.setOpacity(ease((now - self.t0) / 0.9))
        p.drawPixmap(0, 0, self.hud_pm)
        s = self.slides[self.cur] if self.slides else {}
        P.hud_right(p, s.get("section", "暮省"), f"{self.cur + 1:02d} / {len(self.slides):02d}", self.geo)
        base = p.opacity()
        e = now - self.slide_t
        if self.prev_i is not None and e < 0.65:
            p.setOpacity(base * (1 - min(1, e / 0.65)))
            p.drawPixmap(0, 0, self._slide_pm(self.prev_i))
        if self.slides:
            k = min(1.0, e / 0.65)
            dy = 28 * (1 - ease(e / 0.8))
            p.setOpacity(base * k)
            p.drawPixmap(QPointF(0, dy), self._slide_pm(self.cur))
        p.setOpacity(1)
        # 进度条
        padx, by = self.geo["padx"], H - P.c(18, 2.4, 34) - 1
        bw = W - 2 * padx
        p.fillRect(QRectF(padx, by, bw, 1), QColor(255, 255, 255, 18) if P.t["dark"] else QColor(0, 0, 0, 24))
        g = QLinearGradient(padx, 0, padx + bw, 0)
        g.setColorAt(0, QColor(P.t["accent"]))
        g.setColorAt(1, QColor(P.t["accent2"]))
        p.fillRect(QRectF(padx, by, bw * self.bar_ratio(), 1), g)
        if now < self.controls_until:
            self._paint_controls(p, by)

    def _paint_controls(self, p, by):
        P, W = self.P, self.width()
        fs = P.c(11, 0.8, 13)
        f = make_font(SANS, fs)
        fm = QFontMetricsF(f)
        hint = "空格暂停 · ← → 翻页 · Esc 退出"
        h_f = make_font(SANS, 10, 400, 0.8)
        h_w = QFontMetricsF(h_f).horizontalAdvance(hint) + 18
        pause = "重播" if self.ended else ("继续" if self.paused else "暂停")
        btns = [("←", "prev"), (pause, "pause"), ("→", "next")]
        tail = ("关闭", "close")
        widths = [fm.horizontalAdvance(t) + 22 for t, _k in btns]
        cw = fm.horizontalAdvance(tail[0]) + 22
        total = sum(widths) + h_w + cw + 6 * 6
        H_ = fs * 1.5 + 14 + 12
        x, y = W - self.geo["padx"] - total, by - 16 - H_
        light = not P.t["dark"]
        p.setPen(QPen(P.line, 1))
        p.setBrush(QColor(232, 227, 214, 235) if light else QColor(8, 12, 14, 190))
        p.drawRoundedRect(QRectF(x, y, total, H_), 10, 10)
        cx = x + 6
        p.setFont(f)
        for (t, k), w in zip(btns, widths):
            r = QRectF(cx, y + 6, w, H_ - 12)
            self.hits.append((r, k))
            p.setFont(f)
            p.setPen(P.col("muted"))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, t)
            cx += w + 6
        p.setFont(h_f)
        p.setPen(P.col("dim"))
        p.drawText(QRectF(cx, y + 6, h_w, H_ - 12), Qt.AlignmentFlag.AlignCenter, hint)
        cx += h_w + 6
        r = QRectF(cx, y + 6, cw, H_ - 12)
        self.hits.append((r, "close"))
        p.setFont(f)
        p.setPen(P.col("muted"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, tail[0])

    def _paint_exit(self, p):
        P = self.P
        m = P.c(12, 1.5, 20)
        fs = P.c(10, 0.72, 11)
        f = make_font(SANS, fs, 400, fs * 0.18)
        text = "退出"
        w = QFontMetricsF(f).horizontalAdvance(text) + 26
        h = fs * 1.5 + 14
        r = QRectF(self.width() - m - w, m, w, h)
        self.hits.append((r, "close"))
        light = not P.t["dark"]
        p.setPen(QPen(P.col("accent") if self.exit_hover else P.line, 1))
        p.setBrush(QColor(214, 208, 192, 240) if light else QColor(8, 12, 14, 200 if self.exit_hover else 97))
        p.drawRoundedRect(r, h / 2, h / 2)
        p.setFont(f)
        p.setPen(QColor("#332e26") if light else P.col("ink" if self.exit_hover else "soft"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, text)

    # ---- 操作
    def _act(self, k):
        if k == "close":
            self.close()
        elif k == "pause":
            self.toggle_pause()
        elif k == "next":
            self.go(1)
        elif k == "prev":
            self.go(-1)

    def keyPressEvent(self, e):
        k = e.key()
        if k == Qt.Key.Key_Escape:
            self.close()
        elif k == Qt.Key.Key_Space:
            self.skip_cover() if self.phase == "cover" else self.toggle_pause() if self.phase == "deck" else None
        elif k in (Qt.Key.Key_Right, Qt.Key.Key_PageDown, Qt.Key.Key_Down):
            self.go(1)
        elif k in (Qt.Key.Key_Left, Qt.Key.Key_PageUp, Qt.Key.Key_Up):
            self.go(-1)
        elif k == Qt.Key.Key_F11:
            self.showNormal() if self.isFullScreen() else self.showFullScreen()
        else:
            super().keyPressEvent(e)

    def mouseMoveEvent(self, e):
        self.wake()
        pos = e.position()
        hover = any(r.contains(pos) and k == "close" and r.top() < 80 for r, k in self.hits)
        if hover != self.exit_hover:
            self.exit_hover = hover
        self.update()

    def mousePressEvent(self, e):
        pos = e.position()
        for r, k in self.hits:
            if r.contains(pos):
                self._act(k)
                return
        if self.phase == "cover":
            self.skip_cover()

    def closeEvent(self, e):
        self.tick.stop()
        super().closeEvent(e)


def play(deck, texture=None) -> int:
    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("见微暮省")
    win = EveningWindow(deck, texture)
    win.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
    screen = QGuiApplication.primaryScreen()
    if screen is not None:
        win.setGeometry(screen.geometry())
    win.showFullScreen()
    win.raise_()
    win.activateWindow()
    return app.exec()


def notify_failure(message) -> int:
    """没有内容可播时给个交代（8 秒后自己消失，不挡夜里的自动触发）。"""
    app = QApplication.instance() or QApplication(sys.argv[:1])
    box = QMessageBox(QMessageBox.Icon.Information, "暮省", message)
    QTimer.singleShot(8000, box.close)
    box.show()
    box.finished.connect(lambda _r: app.quit())
    QTimer.singleShot(8200, app.quit)
    return app.exec()

