"""Explicit maintenance handoff: graceful exit, exclusive operation, normal restart."""
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QThread, Qt
from PySide6.QtWidgets import QFileDialog, QMessageBox, QPushButton, QProgressDialog

from . import backup
from .design.widgets import qss


def command(*args):
    prefix = [sys.executable] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).parents[1]/'main.py')]
    return prefix+list(args)


def launch(ctx, action, path):
    try:
        subprocess.Popen(command('--data-'+action,str(path)),creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
    except OSError:
        QMessageBox.warning(ctx,'无法开始','维护进程未能启动，尚未退出或修改数据。')
        return
    ctx.quit_app()


class Inspection(QThread):
    def __init__(self,path,version,parent):
        super().__init__(parent)
        self.path,self.version=path,version
        self.result,self.error=None,None

    def run(self):
        try:
            self.result=backup.inspect(self.path,self.version)
        except Exception:
            self.error='备份损坏、来自不支持的版本或无法读取；当前数据未改动。'


def controls(ctx, layout):
    import store
    save = QPushButton('退出后备份数据')
    load = QPushButton('从备份恢复数据')
    for b in (save,load):
        b.setStyleSheet(qss())
        layout.addWidget(b)
    def choose_save():
        path,_=QFileDialog.getSaveFileName(ctx,'备份数据',str(Path.home()/('见微-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.jwbackup')),'见微备份 (*.jwbackup)')
        if path:
            if Path(path).exists():
                QMessageBox.warning(ctx,'请换文件名','目标已存在；备份不会覆盖旧文件。')
                return
            launch(ctx,'backup',path)
    def choose_restore():
        path,_=QFileDialog.getOpenFileName(ctx,'选择备份','','见微备份 (*.jwbackup)')
        if not path:
            return
        progress=QProgressDialog('正在完整校验备份；当前数据未改动。', '',0,0,ctx)
        progress.setCancelButton(None)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.show()
        worker=Inspection(path,store.VERSION,ctx)
        ctx._backup_inspector=worker
        def ready(info):
            progress.close()
            text=(f"备份版本：{info['app_version']}\n文件数：{len(info['files'])}\n\n"
                  '继续后见微会正常退出，等待后台任务结束，再自动备份当前数据并恢复。\n'
                  '现有学习数据将替换为备份内容；密钥、缓存和日志留在本机。\n完成后重新打开见微。')
            if QMessageBox.question(ctx,'确认恢复',text,QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes:
                launch(ctx,'restore',path)
        def failed(message):
            progress.close()
            QMessageBox.warning(ctx,'无法恢复',message)
        worker.finished.connect(lambda:failed(worker.error) if worker.error else ready(worker.result))
        worker.finished.connect(worker.deleteLater)
        worker.start()
    save.clicked.connect(choose_save)
    load.clicked.connect(choose_restore)


def maintain(root, action, path, version):
    """No data-writing UI exists while the exclusive lease is held."""
    from PySide6.QtWidgets import QApplication
    application=QApplication.instance() or QApplication([])
    ok=False
    lease=backup.DataLease(root,exclusive=True)
    try:
        lease.acquire(timeout=30)
        # Old versions do not hold a data lease; refuse a live legacy main window.
        from PySide6.QtNetwork import QLocalSocket
        socket=QLocalSocket()
        socket.connectToServer('Jianwei-Suite-Local')
        if socket.waitForConnected(200):
            socket.disconnectFromServer()
            raise backup.BackupError('仍有见微主窗口运行，请正常关闭旧版本后重试。')
        backup.recover(root)
        if action=='backup':
            result=backup.create(root,path,version)
            text=f"备份完成：{len(result['files'])} 个文件。\n{path}\n密钥、缓存和日志未打包。"
        else:
            result=backup.restore(root,path,version)
            text=f"恢复完成：{result['files']} 个文件。\n恢复前备份：{result['before']}"
        ok=True
    except backup.BackupError as exc:
        text=str(exc)
    except Exception:
        text='维护未完成，请检查磁盘空间和权限。保留恢复事务记录与原数据目录后重试。'
    finally:
        lease.close()
    box=QMessageBox()
    box.setWindowTitle('见微 · 数据维护')
    box.setText(text)
    box.setStyleSheet(qss())
    box.exec()
    application.processEvents()
    # Startup will recover an interrupted swap before loading any user state.
    subprocess.Popen(command(),creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0)
    return 0 if ok else 1
