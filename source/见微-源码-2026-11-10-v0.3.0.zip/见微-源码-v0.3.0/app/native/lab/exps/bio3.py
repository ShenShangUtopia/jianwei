"""生物 · 选择性必修1 稳态与调节（由 gewu/bio.js 改写）：动作电位、血糖调节。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab


@lab.reg(id="b-neuron", subj="bio", book=2, unit="神经调节", title="神经纤维上的动作电位", kw="静息电位 动作电位 钠离子 钾离子 通道 阈值 全或无 兴奋 去极化 复极化",
         info="<p>采用 Hodgkin−Huxley 模型计算膜电位（膜内相对膜外）。</p>"
              "<p class='fb'>静息电位：K⁺ 外流，外正内负（约 −65 ~ −70 mV）<br>动作电位：受刺激后 Na⁺ 通道打开，Na⁺ 内流，膜电位变为外负内正<br>"
              "恢复：Na⁺ 通道失活、K⁺ 通道打开，K⁺ 外流使膜电位恢复；钠钾泵维持离子浓度差</p>"
              "<p>刺激强度达到阈值才能产生动作电位，且动作电位的幅度不随刺激强度增大而增大（全或无）。降低膜外 Na⁺ 浓度，动作电位峰值降低；升高膜外 K⁺ 浓度，静息电位绝对值减小。</p>",
         tasks=["从小到大逐渐增加刺激强度，找出产生动作电位的阈值。", "把刺激强度加倍，动作电位的峰值变大吗？", "降低膜外 Na⁺ 浓度到 0.5 倍，峰值如何变化？阻断 Na⁺ 通道呢？"])
def b_neuron(L):
    c = L.canvas()
    p = L.params({"I": ["刺激强度", 0, 40, 0.5, 10, "μA/cm²"], "dur": ["刺激时长", 0.2, 5, 0.1, 1, "ms"], "na": ["膜外 Na⁺ 浓度（相对）", 0.2, 1.5, 0.05, 1],
                  "k": ["膜外 K⁺ 浓度（相对）", 0.5, 4, 0.1, 1]})
    ttx = L.check("阻断 Na⁺ 通道（如河豚毒素）", False)
    s = {"t": 0.0, "V": -65.0, "m": 0.053, "h": 0.596, "n": 0.318, "gNa": 0.0, "gK": 0.0, "Ist": 0.0}
    S = {"stim_end": -1.0, "rep": False, "last": 0.0, "peak": -65.0}
    hist: list = []

    def stim(_b):
        S["stim_end"] = s["t"] + p.dur

    def rep(b):
        S["rep"] = not S["rep"]
        b.setText("停止连续刺激" if S["rep"] else "连续刺激")
    L.button("给予刺激", stim, True)
    L.button("连续刺激", rep)
    out = L.out()

    def step(dt):
        V = s["V"]
        an = 0.1 if abs(V + 55) < 1e-6 else 0.01 * (V + 55) / (1 - math.exp(-(V + 55) / 10))
        bn = 0.125 * math.exp(-(V + 65) / 80)
        am = 1.0 if abs(V + 40) < 1e-6 else 0.1 * (V + 40) / (1 - math.exp(-(V + 40) / 10))
        bm = 4 * math.exp(-(V + 65) / 18)
        ah = 0.07 * math.exp(-(V + 65) / 20)
        bh = 1 / (1 + math.exp(-(V + 35) / 10))
        s["m"] += dt * (am * (1 - s["m"]) - bm * s["m"])
        s["h"] += dt * (ah * (1 - s["h"]) - bh * s["h"])
        s["n"] += dt * (an * (1 - s["n"]) - bn * s["n"])
        ENa = 50 + 25.7 * math.log(p.na)
        EK = -77 + 25.7 * math.log(p.k)
        gNa = 0 if ttx.v else 120 * s["m"] ** 3 * s["h"]
        gK = 36 * s["n"] ** 4
        Ist = p.I if s["t"] < S["stim_end"] else 0
        s["V"] = V + dt * (Ist - gNa * (V - ENa) - gK * (V - EK) - 0.3 * (V + 54.387))
        s["t"] += dt
        s["gNa"], s["gK"], s["Ist"] = gNa, gK, Ist

    def tick(dt):
        for _ in range(int(dt * 10 / 0.01)):
            step(0.01)
        if S["rep"] and s["t"] - S["last"] > 15:
            S["stim_end"] = s["t"] + p.dur
            S["last"] = s["t"]
        hist.append((s["t"], s["V"], s["gNa"], s["gK"], s["Ist"]))
        while hist and hist[0][0] < s["t"] - 50:
            hist.pop(0)
        S["peak"] = max(q[1] for q in hist)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        gw, gh = c.w - 80, (c.h - 150) * 0.62
        t0 = hist[0][0] if hist else 0
        t1 = max(t0 + 50, s["t"])
        ch = D.chart(g, 50, 24, gw, gh, [{"pts": [(q[0], q[1]) for q in hist], "color": T.c2, "w": 2.2}], title="膜电位 V（mV）", xl="t / ms", xmin=t0, xmax=t1, ymin=-90, ymax=60)
        D.line(g, 50, ch["Y"](0), 50 + gw, ch["Y"](0), T.grid2, 1, [3, 3])
        D.text(g, "0 mV", 46, ch["Y"](0), T.muted, size=10, align="right")
        for q in hist:
            if q[4] > 0:
                D.line(g, ch["X"](q[0]), 24 + gh - 6, ch["X"](q[0]), 24 + gh, T.c4, 2)
        y2, gh2 = 40 + gh, (c.h - 150) * 0.38
        D.chart(g, 50, y2, gw, gh2, [{"pts": [(q[0], q[2]) for q in hist], "color": T.c1, "w": 1.8}, {"pts": [(q[0], q[3]) for q in hist], "color": T.c3, "w": 1.8}],
                title="离子通道电导：蓝 Na⁺，绿 K⁺", xmin=t0, xmax=t1, ymin=0, ymax=40)
        my, mx0 = c.h - 60, 50
        D.rect(g, mx0, my - 8, gw, 16, alpha("#d9a441", 0.35))
        D.text(g, "膜外 − − − −" if s["V"] > 0 else "膜外 + + + +", mx0, my - 22, T.muted, size=11)
        D.text(g, "膜内 + + + +" if s["V"] > 0 else "膜内 − − − −", mx0, my + 22, T.muted, size=11)
        naO, kO = clamp(s["gNa"] / 30, 0, 1), clamp(s["gK"] / 25, 0, 1)
        for i in range(4):
            x = mx0 + 160 + i * 120
            if x + 80 > mx0 + gw:
                break
            D.rect(g, x, my - 10, 22, 20, alpha(T.c1, 0.3 + naO * 0.6))
            D.text(g, "Na⁺", x + 11, my, T.fg, align="center", size=9)
            if naO > 0.2:
                D.arrow(g, x + 11, my - 30, x + 11, my + 30, T.c1, 1 + naO * 3)
            x2 = x + 50
            D.rect(g, x2, my - 10, 22, 20, alpha(T.c3, 0.3 + kO * 0.6))
            D.text(g, "K⁺", x2 + 11, my, T.fg, align="center", size=9)
            if kO > 0.2:
                D.arrow(g, x2 + 11, my + 30, x2 + 11, my - 30, T.c3, 1 + kO * 3)
        dV = hist[-1][1] - hist[-3][1] if len(hist) > 2 else 0
        V = s["V"]
        if V < -60 and abs(dV) < 0.2:
            phase = "静息电位"
        elif dV > 0 and V > -60:
            phase = "去极化（Na⁺ 内流）"
        elif dV < 0 and V > -70:
            phase = "复极化（K⁺ 外流）"
        elif V < -66:
            phase = "超极化"
        else:
            phase = "恢复中"
        out.set([["膜电位", fmt(V, 1) + " mV"], ["所处阶段", phase], ["近 50 ms 峰值", fmt(S["peak"], 1) + " mV"],
                 ["Na⁺ 平衡电位", fmt(50 + 25.7 * math.log(p.na), 1) + " mV"], ["K⁺ 平衡电位", fmt(-77 + 25.7 * math.log(p.k), 1) + " mV"]])
    L.on_draw(draw)


@lab.reg(id="b-glucose", subj="bio", book=2, unit="体液调节", title="血糖平衡的调节", kw="血糖 胰岛素 胰高血糖素 胰岛 B 细胞 A 细胞 糖尿病 反馈调节",
         info="<p class='fb'>血糖正常范围：3.9 ~ 6.1 mmol/L（空腹）<br>胰岛素（胰岛 B 细胞分泌）：促进组织细胞摄取、利用和储存葡萄糖，抑制肝糖原分解和非糖物质转化 —— 唯一降血糖的激素<br>"
              "胰高血糖素（胰岛 A 细胞分泌）：促进肝糖原分解和非糖物质转化为葡萄糖 —— 升血糖</p>"
              "<p>血糖升高 → 胰岛素分泌增加 → 血糖下降，这是<b>负反馈调节</b>。1 型糖尿病主要因胰岛 B 细胞受损、胰岛素分泌不足；2 型糖尿病主要因靶细胞对胰岛素不敏感（胰岛素抵抗）。</p>",
         tasks=["正常人进食后，血糖与胰岛素的峰值哪个先出现？", "切换到 1 型糖尿病，进食后血糖如何变化？注射胰岛素有效吗？", "2 型糖尿病患者体内胰岛素水平一定低吗？"])
def b_glucose(L):
    c = L.canvas()
    who = L.select("个体", [["n", "健康人"], ["t1", "1 型糖尿病（胰岛 B 细胞受损）"], ["t2", "2 型糖尿病（胰岛素抵抗）"]], "n")
    s = {"t": 0.0, "G": 5.0, "I": 1.0, "Gn": 0.5}
    S = {"ex": -1.0, "fast": False}
    meals: list = []
    hist: list = []

    def fast(b):
        S["fast"] = not S["fast"]
        b.setText("结束饥饿" if S["fast"] else "长时间饥饿")
    L.button("进食", lambda _b: meals.append(s["t"]), True)
    L.button("运动 1 小时", lambda _b: S.__setitem__("ex", s["t"] + 60))
    L.button("注射胰岛素", lambda _b: s.__setitem__("I", s["I"] + 4))
    L.button("长时间饥饿", fast)
    out = L.out()

    def tick(dt):
        sim = dt * 8   # 1 秒 = 8 分钟
        h = sim / 20
        beta = 0.08 if who.v == "t1" else 1
        Si = 0.004 if who.v == "t2" else 0.01
        for _ in range(20):
            exer = 1 if s["t"] < S["ex"] else 0
            Ra = 0.0
            if not S["fast"]:
                for t0 in meals:
                    u = s["t"] - t0
                    if 0 < u < 400:
                        Ra += 25 * u / 900 * math.exp(-u / 30)
            EGP = 0.05 * (1 + 2 * s["Gn"]) * (0.9 if S["fast"] else 1)
            dG = Ra + EGP - (0.01 + Si * s["I"] * (1 + exer) + 0.01 * exer) * s["G"]
            dI = beta * 0.1 * max(0.0, (s["G"] - 3.5) / 1.5) * (1.8 if who.v == "t2" else 1) - 0.1 * s["I"]
            dGn = 0.05 * max(0.0, (7 - s["G"]) / 4) * (1 / (1 + s["I"] * 0.2)) * 1.3 - 0.05 * s["Gn"]
            s["G"] = max(0.5, s["G"] + dG * h)
            s["I"] = max(0.0, s["I"] + dI * h)
            s["Gn"] = max(0.0, s["Gn"] + dGn * h)
            s["t"] += h
        hist.append((s["t"] / 60, s["G"], s["I"], s["Gn"]))
        while hist and hist[0][0] < s["t"] / 60 - 8:
            hist.pop(0)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        gw, gh = c.w - 80, (c.h - 90) * 0.55
        t0 = hist[0][0] if hist else 0
        t1 = max(t0 + 8, s["t"] / 60)
        ch = D.chart(g, 50, 24, gw, gh, [{"pts": [(q[0], q[1]) for q in hist], "color": T.c2, "w": 2.4}], title="血糖浓度（mmol/L）", xl="时间 / h",
                     xmin=t0, xmax=t1, ymin=0, ymax=max([14] + [q[1] for q in hist]))
        D.rect(g, 50, ch["Y"](6.1), gw, ch["Y"](3.9) - ch["Y"](6.1), alpha(T.ok, 0.1))
        D.text(g, "正常范围", 54, ch["Y"](6.1) + 10, T.ok, size=10)
        for m in meals:
            x = ch["X"](m / 60)
            if 50 < x < 50 + gw:
                D.line(g, x, 24, x, 24 + gh, alpha(T.c4, 0.6), 1, [3, 3])
                D.text(g, "进食", x + 3, 34, T.c4, size=10)
        D.chart(g, 50, 50 + gh, gw, (c.h - 90) * 0.45, [{"pts": [(q[0], q[2]) for q in hist], "color": T.c1, "w": 2}, {"pts": [(q[0], q[3] * 4) for q in hist], "color": T.c4, "w": 2}],
                title="激素水平（相对）：蓝 胰岛素，黄 胰高血糖素", xl="时间 / h", xmin=t0, xmax=t1, ymin=0)
        G = s["G"]
        out.set([["血糖", fmt(G, 2) + " mmol/L"], ["状态", "低血糖" if G < 3.9 else "明显高血糖（糖尿）" if G > 11.1 else "偏高" if G > 6.1 else "正常"],
                 ["胰岛素（相对）", fmt(s["I"], 2)], ["胰高血糖素（相对）", fmt(s["Gn"], 2)], ["饥饿", "是" if S["fast"] else "否"], ["运动", "进行中" if s["t"] < S["ex"] else "否"]])
    L.on_draw(draw)
