"""物理 · 必修第三册（由 gewu/phys.js 改写）：静电场、电容器、闭合电路。"""
from __future__ import annotations

import math
import random

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QImage

from ...design.tokens import T, alpha, qc
from ...kit.core import PI, TAU, clamp, fmt, sci
from ...kit.draw import D
from ...kit.registry import lab
from .phys1 import battery, flow_dots, meter, resistor, wire


# ---------------------------------------------------------------- 点电荷的电场线与等势线
@lab.reg(id="p-field", subj="phys", book=2, unit="静电场及其应用 · 静电场中的能量", title="点电荷的电场线与等势线",
         kw="电场强度 电场线 等势面 电势 库仑定律 叠加",
         info="<p class='fb'>库仑定律 F = kq₁q₂/r²　点电荷场强 E = kQ/r²<br>点电荷电势 φ = kQ/r（取无穷远为零）　多个电荷：场强矢量叠加、电势代数相加<br>"
              "电场线从正电荷出发终止于负电荷；等势线处处与电场线垂直；沿电场线方向电势降低</p>"
              "<p>背景颜色表示电势：偏红为正，偏蓝为负。鼠标悬停处显示该点的场强方向与相对大小（取 k = 1 的相对单位）。</p>",
         tasks=["放一正一负等量电荷，观察两电荷连线中垂线上的电势。", "放两个等量正电荷，找出场强为零的点。", "把一个电荷的电量改为另一个的 2 倍，场强为零的点向哪里移动？"])
def p_field(L):
    c = L.canvas()
    S = {"Q": [{"x": 0.35, "y": 0.5, "q": 1}, {"x": 0.65, "y": 0.5, "q": -1}], "hover": None}
    L.group("电荷")
    qv = L.select("新电荷电量", [["1", "+q"], ["2", "+2q"], ["-1", "−q"], ["-2", "−2q"]], "1")

    def add(_b):
        S["Q"].append({"x": random.uniform(0.3, 0.7), "y": random.uniform(0.3, 0.7), "q": int(qv.v)})
        L.draw()

    def preset(q2):
        S["Q"] = [{"x": 0.35, "y": 0.5, "q": 1}, {"x": 0.65, "y": 0.5, "q": q2}]
        L.draw()
    L.button("添加电荷", add, True)
    L.button("等量异种", lambda _b: preset(-1))
    L.button("等量同种", lambda _b: preset(1))
    L.button("清空", lambda _b: (S.__setitem__("Q", []), L.draw()))
    L.group("显示")
    fl, eq, bg = L.check("电场线", True), L.check("等势线", True), L.check("电势着色", True)
    out = L.out()
    L.note("拖动电荷移动它；双击电荷删除。")

    def hit(x, y):
        return next((o for o in S["Q"] if math.hypot(o["x"] * c.w - x, o["y"] * c.h - y) < 14), None)

    def drag(o, x, y, _dx, _dy):
        o["x"], o["y"] = clamp(x / c.w, 0.02, 0.98), clamp(y / c.h, 0.02, 0.98)

    def hover(x, y):
        S["hover"] = (x, y)
        L.draw()

    def dbl(x, y):
        S["Q"] = [o for o in S["Q"] if math.hypot(o["x"] * c.w - x, o["y"] * c.h - y) > 14]

    def leave():
        S["hover"] = None
        L.draw()
    L.interact(c, hit=hit, drag=drag, hover=hover, dbl=dbl, leave=leave)
    sc = 120.0   # 相对单位：像素 / sc 作为距离

    def field(x, y):
        ex = ey = ph = 0.0
        for o in S["Q"]:
            dx, dy = (x - o["x"] * c.w) / sc, (y - o["y"] * c.h) / sc
            r2 = dx * dx + dy * dy + 1e-6
            r = math.sqrt(r2)
            ex += o["q"] * dx / (r2 * r)
            ey += o["q"] * dy / (r2 * r)
            ph += o["q"] / r
        return ex, ey, ph

    def base():
        g = c.g
        Q = S["Q"]
        W, H, step = c.w, c.h, 6
        nx, ny = math.ceil(W / step) + 1, math.ceil(H / step) + 1
        P = [[field(i * step, j * step)[2] for i in range(nx)] for j in range(ny)]
        c.clear()
        if bg.v and Q:
            img = QImage(nx, ny, QImage.Format.Format_RGB32)
            cp, cn, b0 = qc(T.c2), qc(T.c1), qc(T.stage)
            for j in range(ny):
                row = P[j]
                for i in range(nx):
                    t = math.tanh(row[i] / 3)
                    col = cp if t > 0 else cn
                    a = abs(t) * 0.55
                    img.setPixel(i, j, (0xFF << 24) | (int(b0.red() + (col.red() - b0.red()) * a) << 16)
                                 | (int(b0.green() + (col.green() - b0.green()) * a) << 8) | int(b0.blue() + (col.blue() - b0.blue()) * a))
            g.p.setRenderHint(g.p.RenderHint.SmoothPixmapTransform, True)
            g.p.drawImage(QRectF(0, 0, nx * step, ny * step), img)
        if eq.v and Q:
            levels = [-8, -4, -2, -1, -0.5, -0.25, 0.25, 0.5, 1, 2, 4, 8]
            if any(o["q"] > 0 for o in Q) and any(o["q"] < 0 for o in Q):
                levels.append(0)
            g.stroke_style, g.line_width = alpha(T.fg, 0.45), 1
            g.begin_path()
            for lv in levels:
                for j in range(ny - 1):
                    r0, r1 = P[j], P[j + 1]
                    for i in range(nx - 1):
                        a, b, cc, d = r0[i] - lv, r0[i + 1] - lv, r1[i + 1] - lv, r1[i] - lv
                        if (a > 0) == (b > 0) == (cc > 0) == (d > 0):
                            continue
                        pts, x0, y0 = [], i * step, j * step
                        if a * b < 0:
                            pts.append((x0 + step * a / (a - b), y0))
                        if b * cc < 0:
                            pts.append((x0 + step, y0 + step * b / (b - cc)))
                        if cc * d < 0:
                            pts.append((x0 + step * (1 - cc / (cc - d)), y0 + step))
                        if d * a < 0:
                            pts.append((x0, y0 + step * (1 - d / (d - a))))
                        if len(pts) >= 2:
                            g.move_to(*pts[0])
                            g.line_to(*pts[1])
                        if len(pts) == 4:
                            g.move_to(*pts[2])
                            g.line_to(*pts[3])
            g.stroke()
        if fl.v and Q:
            pos = [o for o in Q if o["q"] > 0]
            src, sgn = (pos, 1) if pos else (Q, -1)
            for o in src:
                n = 12 * abs(o["q"])
                for k in range(n):
                    x = o["x"] * c.w + 9 * math.cos(TAU * k / n)
                    y = o["y"] * c.h + 9 * math.sin(TAU * k / n)
                    pts, mid = [(x, y)], None
                    for s in range(900):
                        ex, ey, _ = field(x, y)
                        m = math.hypot(ex, ey)
                        if m < 1e-9:
                            break
                        hx, hy = x + sgn * 2 * ex / m, y + sgn * 2 * ey / m
                        ex2, ey2, _ = field(hx, hy)
                        m2 = math.hypot(ex2, ey2) or 1
                        x += sgn * 4 * (ex / m + ex2 / m2) / 2
                        y += sgn * 4 * (ey / m + ey2 / m2) / 2
                        pts.append((x, y))
                        if s == 40:
                            mid = (x, y, sgn * ex / m, sgn * ey / m)
                        if x < -20 or y < -20 or x > W + 20 or y > H + 20:
                            break
                        if any(q2 is not o and math.hypot(q2["x"] * c.w - x, q2["y"] * c.h - y) < 7 for q2 in Q):
                            break
                    D.poly(g, pts, None, T.fg, 1.2, False)
                    if mid:
                        mx, my, ux, uy = mid
                        D.poly(g, [(mx + ux * 5, my + uy * 5), (mx - ux * 4 - uy * 4, my - uy * 4 + ux * 4), (mx - ux * 4 + uy * 4, my - uy * 4 - ux * 4)], T.fg)
        for o in Q:
            D.circle(g, o["x"] * c.w, o["y"] * c.h, 11 + abs(o["q"]) * 1.5, T.c2 if o["q"] > 0 else T.c1, T.stage, 2)
            D.text(g, "+" if o["q"] > 0 else "−", o["x"] * c.w, o["y"] * c.h + 1, "#ffffff", align="center", bold=True, size=16)

    def draw():
        key = (tuple((round(o["x"], 4), round(o["y"], 4), o["q"]) for o in S["Q"]), fl.v, eq.v, bg.v)
        L.cached(key, base)
        g, hv, Q = c.g, S["hover"], S["Q"]
        if hv:
            ex, ey, ph = field(*hv)
            m = math.hypot(ex, ey)
            L2 = min(40, 10 + m * 20)
            if m > 1e-9:
                D.arrow(g, hv[0], hv[1], hv[0] + ex / m * L2, hv[1] + ey / m * L2, T.c4, 2.4)
            out.set([["探测点电势 φ", fmt(ph, 3)], ["场强大小 |E|", fmt(m, 3)], ["场强方向", fmt(-math.atan2(ey, ex) * 180 / PI, 1) + "°"],
                     ["电荷数", str(len(Q))]])
        else:
            out.set([["电荷数", str(len(Q))], ["提示", "把鼠标移到画布上测量"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 平行板电容器
@lab.reg(id="p-cap", subj="phys", book=2, unit="静电场中的能量", title="平行板电容器的动态分析", kw="电容 电荷量 电压 场强 介电常数 静电计",
         info="<p class='fb'>C = Q/U　C = εᵣS/(4πkd)　E = U/d<br>保持与电源相连：U 不变，Q = CU 随 C 变化<br>充电后断开电源：Q 不变，U = Q/C，E = 4πkQ/(εᵣS) 与 d 无关</p>"
              "<p>右侧的静电计指针偏角反映两板间电压 U。极板上的「+ −」个数代表电荷量，板间电场线的疏密代表场强。</p>",
         tasks=["连着电源，增大 d，Q、E 怎样变化？", "断开电源后再增大 d，静电计偏角怎样变化？E 变不变？", "断开电源后插入电介质（增大 εᵣ），U 如何变化？"])
def p_cap(L):
    c = L.canvas()
    e0, U0 = 8.854e-12, 12.0
    S = {"conn": True, "Q": 0.0}
    p = L.params({"d": ["板间距 d", 1, 10, 0.1, 4, "mm"], "S": ["正对面积 S", 20, 200, 1, 100, "cm²"], "er": ["相对介电常数 εᵣ", 1, 8, 0.1, 1]},
                 lambda _k, _v: update())
    L.group("电源")

    def C():
        return p.er * e0 * p.S * 1e-4 / (p.d * 1e-3)

    def update():
        if S["conn"]:
            S["Q"] = C() * U0
        L.draw()

    def sw(vv):
        S["conn"] = vv == "1"
        update()
    L.seg("", [["1", "保持连接电源（U 不变）"], ["0", "断开电源（Q 不变）"]], "1", sw)
    out = L.out()
    update()

    def draw():
        c.clear()
        g = c.g
        Cv = C()
        Q = S["Q"]
        U = Q / Cv
        E = U / (p.d * 1e-3)
        cx, cy = c.w * 0.42, c.h / 2
        pw, gap = 60 + p.S * 1.4, 14 + p.d * 16
        top, bot = cy - gap / 2, cy + gap / 2
        if p.er > 1:
            D.rect(g, cx - pw / 2, top, pw, gap, alpha(T.c4, 0.12 + p.er * 0.03))
        D.rect(g, cx - pw / 2, top - 8, pw, 8, T.c2)
        D.rect(g, cx - pw / 2, bot, pw, 8, T.c1)
        nq = max(1, round(Q / 2.5e-10 * 6))
        m = min(nq, 40)
        for i in range(m):
            x = cx - pw / 2 + (i + 0.5) * pw / m
            D.text(g, "+", x, top - 16, T.c2, align="center", bold=True)
            D.text(g, "−", x, bot + 18, T.c1, align="center", bold=True)
        nE = min(max(1, round(E / 6e3 * pw / 120)), 40)
        for i in range(nE):
            x = cx - pw / 2 + (i + 0.5) * pw / nE
            D.arrow(g, x, top + 2, x, bot - 2, alpha(T.fg, 0.55), 1, 6)
        lx = cx - pw / 2 - 70
        wire(g, [(cx, top - 8), (cx, top - 40), (lx, top - 40), (lx, cy - 16)])
        wire(g, [(cx, bot + 8), (cx, bot + 40), (lx, bot + 40), (lx, cy + 16)])
        if S["conn"]:
            battery(g, lx, cy, True, f"{U0:g} V")
        else:
            D.line(g, lx, cy - 16, lx + 14, cy - 34, T.fg, 2)
            D.text(g, "开关断开", lx + 18, cy, T.muted, size=12)
            D.circle(g, lx, cy + 16, 3, T.fg)
        ex, ey = cx + pw / 2 + 90, cy + 30
        wire(g, [(cx + pw / 2, top - 4), (ex, top - 4), (ex, ey - 60)])
        wire(g, [(cx + pw / 2, bot + 4), (ex + 40, bot + 4), (ex + 40, ey + 40), (ex, ey + 40)])
        D.circle(g, ex, ey, 40, None, T.fg, 1.5)
        D.line(g, ex, ey - 60, ex, ey + 10, T.fg, 2)
        ang = min(80, U / 40 * 80) * PI / 180
        D.line(g, ex, ey - 10, ex + math.sin(ang) * 34, ey - 10 - math.cos(ang) * 34, T.c3, 3)
        D.text(g, "静电计", ex, ey + 54, T.muted, align="center", size=11)
        out.set([["电容 C", fmt(Cv * 1e12, 2) + " pF"], ["电荷量 Q", sci(Q, 3) + " C"], ["电压 U", fmt(U, 2) + " V"], ["板间场强 E", fmt(E, 0) + " V/m"],
                 ["储存能量 ½CU²", sci(0.5 * Cv * U * U, 3) + " J"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 闭合电路
@lab.reg(id="p-circuit", subj="phys", book=2, unit="电路及其应用 · 电能 能量守恒定律", title="闭合电路欧姆定律与滑动变阻器",
         kw="电动势 内阻 路端电压 输出功率 限流 分压 欧姆定律",
         info="<p class='fb'>I = E/(R + r)　路端电压 U = E − Ir<br>输出功率 P 出 = I²R = E²R/(R + r)²，当 R = r 时最大，P max = E²/4r<br>电源效率 η = U/E = R/(R + r)</p>"
              "<p><b>限流式</b>接法：负载电压调节范围 ERₓ/(Rₓ + R₀) ~ E，耗能少。<b>分压式</b>接法：负载电压可从 0 调到 E，调节范围大，要求电压从零开始时必须用分压式。</p>",
         tasks=["调节 R，验证 U-I 图像是一条直线，纵截距和斜率分别代表什么？", "找出输出功率最大的 R，此时效率是多少？", "比较限流与分压两种接法下，负载电压随滑片位置的变化曲线。"])
def p_circuit(L):
    c = L.canvas()
    L.group("电路")
    mode = L.seg("", [["closed", "闭合电路"], ["lim", "限流式"], ["div", "分压式"]], "closed", lambda _m: (sync(), L.draw()))
    p = L.params({"E": ["电动势 E", 1, 12, 0.5, 6, "V"], "r": ["内阻 r", 0, 5, 0.1, 1, "Ω"], "R": ["外电阻 R", 0, 30, 0.1, 4, "Ω"],
                  "R0": ["变阻器总阻值 R₀", 5, 100, 1, 20, "Ω"], "Rx": ["负载 Rₓ", 1, 50, 1, 10, "Ω"], "k": ["滑片位置", 0, 1, 0.01, 0.5]})
    out = L.out()

    def sync():
        m = mode.v
        p.s("R").el.setVisible(m == "closed")
        for key in ("R0", "Rx", "k"):
            p.s(key).el.setVisible(m != "closed")
    sync()
    S = {"ph": 0.0}

    def tick(dt):
        S["ph"] += dt * 60
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        E, r = p.E, p.r
        narrow = c.w < 640
        half = c.w if narrow else c.w * 0.5
        x0, x1, y0 = 40, half - 40, 50
        y1 = min(c.h - 50, c.h * 0.45 if narrow else c.h - 60)
        xm = (x0 + x1) / 2
        if mode.v == "closed":
            R = p.R
            I = E / ((R + r) or 1e-9)
            U = I * R
            path = [(xm, y1), (x0, y1), (x0, y0), (x1, y0), (x1, y1), (xm, y1)]
            wire(g, path)
            flow_dots(g, path, -S["ph"] * min(I, 6) * 0.6, T.c4)
            D.rect(g, xm - 50, y1 - 26, 100, 52, T.stage)
            battery(g, xm - 24, y1, False, f"E={E:g}V")
            resistor(g, xm, y1, xm + 50, y1, f"r={r:g}Ω")
            D.line(g, xm - 50, y1, xm - 28, y1, T.fg, 1.8)
            D.line(g, xm - 20, y1, xm, y1, T.fg, 1.8)
            ym = (y0 + y1) / 2
            D.rect(g, x1 - 20, ym - 30, 40, 60, T.stage)
            resistor(g, x1, ym - 30, x1, ym + 30, f"R={fmt(R, 1)}Ω", T.c1)
            D.circle(g, xm, y0, 16, T.stage)
            meter(g, xm, y0, "A", fmt(I, 3) + " A")
            wire(g, [(x0, y0 + 30), (x0 + 60, y0 + 30), (x0 + 60, y1 - 50), (x0, y1 - 50)], T.muted, 1.2)
            D.circle(g, x0 + 60, ym - 10, 16, T.stage)
            meter(g, x0 + 60, ym - 10, "V", fmt(U, 3) + " V")
            gx = 40 if narrow else half + 20
            gw = c.w - gx - 30
            gy = y1 + 50 if narrow else 30
            gh = ((c.h - gy - 20) if narrow else c.h - 60) / 2 - 20
            Im = E / r if r > 0 else E / 0.1
            ch1 = D.chart(g, gx, gy, gw, gh, [{"pts": [(0, E), (Im, E - Im * r)], "color": T.c1, "w": 2.2}], title="U − I 图像", xl="I / A",
                          xmin=0, xmax=Im * 1.05, ymin=0, ymax=E * 1.1)
            D.circle(g, ch1["X"](I), ch1["Y"](U), 5, T.c2)

            def Pout(R2):
                return E * E * R2 / (R2 + r) ** 2 if R2 + r else 0
            Pm = E * E / 4 / r if r > 0 else Pout(30)
            ch2 = D.chart(g, gx, gy + gh + 30, gw, gh, [{"pts": [(i / 4, Pout(i / 4)) for i in range(121)], "color": T.c3, "w": 2.2}],
                          title="输出功率 P − R", xl="R / Ω", xmin=0, xmax=30, ymin=0, ymax=max(Pm, Pout(30)) * 1.15)
            D.circle(g, ch2["X"](R), ch2["Y"](Pout(R)), 5, T.c2)
            if r > 0:
                D.line(g, ch2["X"](r), gy + gh + 30, ch2["X"](r), gy + 2 * gh + 30, T.muted, 1, [4, 4])
            rows = [["电流 I", fmt(I, 4) + " A"], ["路端电压 U", fmt(U, 4) + " V"], ["内电压 Ir", fmt(I * r, 4) + " V"], ["输出功率 P 出", fmt(I * U, 4) + " W"],
                    ["总功率 EI", fmt(E * I, 4) + " W"], ["效率 η", fmt(U / E * 100, 2) + " %"], ["P 出最大值（R = r）", fmt(E * E / 4 / r, 3) + " W" if r > 0 else "—"]]
        else:
            R0, Rx, k = p.R0, p.Rx, p.k
            lim = mode.v == "lim"

            def u_lim(kk):
                return E / (Rx + kk * R0 + r) * Rx

            def u_div(kk):
                a = kk * R0
                par = a * Rx / (a + Rx) if a > 1e-9 else 0
                return E / ((1 - kk) * R0 + par + r) * par
            Ux, other = (u_lim, u_div) if lim else (u_div, u_lim)
            U = Ux(k)
            I = U / Rx
            rx0, rx1 = x0 + 30, x1 - 30
            ry = (y0 + y1) / 2 + 20
            D.rect(g, rx0, ry - 9, rx1 - rx0, 18, T.stage, T.fg, 1.8)
            D.text(g, "R₀", rx0 - 18, ry, T.fg)
            sx = rx0 + (rx1 - rx0) * k
            D.arrow(g, sx, ry - 34, sx, ry - 10, T.c2, 2.4)
            battery(g, xm, y1, False, f"E={E:g}V")
            if lim:
                wire(g, [(rx0, ry), (x0, ry), (x0, y1), (xm - 4, y1)])
                wire(g, [(xm + 4, y1), (x1, y1), (x1, y0), (sx, y0), (sx, ry - 34)])
                D.rect(g, xm + 30, y0 - 16, 60, 32, T.stage)
                resistor(g, xm + 30, y0, xm + 90, y0, "Rₓ", T.c1)
                D.text(g, "只用 R₀ 的左段（滑片左侧）", rx0, ry + 28, T.muted, size=11)
            else:
                wire(g, [(rx0, ry), (x0, ry), (x0, y1), (xm - 4, y1)])
                wire(g, [(xm + 4, y1), (x1, y1), (x1, ry), (rx1, ry)])
                wire(g, [(sx, ry - 34), (sx, y0), (xm + 40, y0)])
                wire(g, [(xm - 40, y0), (x0 + 10, y0), (x0 + 10, ry)])
                resistor(g, xm - 40, y0, xm + 40, y0, "Rₓ", T.c1)
                D.text(g, "Rₓ 并联在 R₀ 左段两端", rx0, ry + 28, T.muted, size=11)
            gx = 40 if narrow else half + 20
            gw = c.w - gx - 30
            gy = y1 + 50 if narrow else 40
            gh = c.h - gy - 30 if narrow else c.h - 90
            ks = [i / 100 for i in range(101)]
            ch = D.chart(g, gx, gy, gw, gh, [{"pts": [(kk, other(kk)) for kk in ks], "color": T.grid2, "w": 1.5, "dash": [5, 4]},
                                            {"pts": [(kk, Ux(kk)) for kk in ks], "color": T.c1, "w": 2.4}],
                         title=f"负载电压 Uₓ − 滑片位置（虚线为{'分压' if lim else '限流'}式）", xl="滑片位置", xmin=0, xmax=1, ymin=0, ymax=E * 1.1)
            D.circle(g, ch["X"](k), ch["Y"](U), 5, T.c2)
            vals = [Ux(kk) for kk in ks]
            rows = [["负载电压 Uₓ", fmt(U, 3) + " V"], ["负载电流", fmt(I, 4) + " A"], ["Uₓ 调节范围", f"{fmt(min(vals), 2)} ~ {fmt(max(vals), 2)} V"]]
        out.set(rows)
    L.on_draw(draw)


def _unused():
    _ = Qt
