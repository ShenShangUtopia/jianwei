"""化学 · 必修第二册（由 gewu/chem.js 改写）：反应速率与有效碰撞。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha
from ...kit.core import PI, TAU, clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab


@lab.reg(id="c-rate", subj="chem", book=1, unit="化学反应的速率与限度", title="反应速率与有效碰撞", kw="反应速率 活化能 活化分子 有效碰撞 催化剂 温度 浓度 能量图",
         info="<p>蓝色 A 与红色 B 相撞时，只有碰撞能量超过活化能 Eₐ 才能变成绿色产物 C（有效碰撞）。</p>"
              "<p class='fb'>v = Δc/Δt　增大浓度：单位体积活化分子数增多<br>升高温度：活化分子百分数增大（右下能量分布曲线阴影面积变大）<br>"
              "催化剂：改变反应历程，降低活化能，正逆反应速率同等程度增大，ΔH 不变</p>",
         tasks=["只升高温度，观察能量分布曲线的阴影面积和反应速率怎样变化。", "加入催化剂，Eₐ 线向哪边移动？反应热 ΔH 变了吗？", "只增加 A 的数目，单位时间内有效碰撞次数如何变化？"])
def c_rate(L):
    c = L.canvas()
    Ea0, EaC = 3.0, 1.6
    S = {"ps": [], "t": 0.0, "hist": [], "events": []}

    def kT():
        return p.T / 200

    def spd():
        return math.sqrt(2 * kT() * -math.log(random.random() or 1e-9))

    def mk(tp):
        s = spd() * 40
        a = random.uniform(0, TAU)
        return {"type": tp, "x": random.uniform(0.05, 0.95), "y": random.uniform(0.05, 0.95), "vx": s * math.cos(a), "vy": s * math.sin(a)}

    def reset(*_):
        S["ps"] = [mk("A") for _ in range(int(p.nA))] + [mk("B") for _ in range(int(p.nB))]
        S.update(t=0.0, hist=[(0.0, p.nA)], events=[])
        L.draw()

    def retemp():
        ps = S["ps"]
        if not ps:
            return
        target = math.sqrt(2 * kT()) * 40
        cur = math.sqrt(sum(q["vx"] ** 2 + q["vy"] ** 2 for q in ps) / len(ps)) or 1
        for q in ps:
            q["vx"] *= target / cur
            q["vy"] *= target / cur
    p = L.params({"nA": ["A 的数目", 5, 80, 1, 40], "nB": ["B 的数目", 5, 80, 1, 40], "T": ["温度", 200, 800, 10, 400, "K"]},
                 lambda k, _v: retemp() if k == "T" else reset())
    cat = L.check("加入催化剂", False)
    L.button("重新开始", reset, True)
    out = L.out()
    reset()

    def tick(dt):
        bw, bh = c.w * 0.55, c.h - 40
        Ea = EaC if cat.v else Ea0
        S["t"] += dt
        t, ps = S["t"], S["ps"]
        for q in ps:
            q["x"] += q["vx"] * dt / bw
            q["y"] += q["vy"] * dt / bh
            if q["x"] < 0 or q["x"] > 1:
                q["vx"] *= -1
                q["x"] = clamp(q["x"], 0, 1)
            if q["y"] < 0 or q["y"] > 1:
                q["vy"] *= -1
                q["y"] = clamp(q["y"], 0, 1)
        n = len(ps)
        for i in range(n):
            a = ps[i]
            for j in range(i + 1, n):
                b = ps[j]
                dx, dy = (a["x"] - b["x"]) * bw, (a["y"] - b["y"]) * bh
                if abs(dx) >= 10 or abs(dy) >= 10:
                    continue
                d = math.hypot(dx, dy)
                if 0 < d < 10:
                    nx, ny = dx / d, dy / d
                    rv = (a["vx"] - b["vx"]) * nx + (a["vy"] - b["vy"]) * ny
                    if rv >= 0:
                        continue
                    E = 0.25 * rv * rv / 1600
                    if {a["type"], b["type"]} == {"A", "B"} and E > Ea:
                        a["type"] = b["type"] = "C"
                        S["events"].append(t)
                    a["vx"] -= rv * nx
                    a["vy"] -= rv * ny
                    b["vx"] += rv * nx
                    b["vy"] += rv * ny
        S["hist"].append((t, sum(1 for q in ps if q["type"] == "A")))
        if len(S["hist"]) > 1200:
            S["hist"] = S["hist"][::2]
        S["events"] = [e for e in S["events"] if e > t - 2]
        retemp()
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        bw, bh = c.w * 0.55, c.h - 40
        ox = oy = 20
        D.rect(g, ox, oy, bw, bh, None, T.fg, 1.5)
        for q in S["ps"]:
            D.circle(g, ox + q["x"] * bw, oy + q["y"] * bh, 5, T.c1 if q["type"] == "A" else T.c2 if q["type"] == "B" else T.c3)
        gx = ox + bw + 30
        gw, gh = c.w - gx - 15, (c.h - 60) / 3
        kt = kT()
        Ea = EaC if cat.v else Ea0
        if gw > 100:
            D.chart(g, gx, oy, gw, gh, [{"pts": S["hist"], "color": T.c1, "w": 2}], title="A 的数目 − t", xl="t", xmin=0, xmax=max(5, S["t"]), ymin=0, ymax=max(p.nA, 1))

            def f(E):
                return math.sqrt(E) * math.exp(-E / kt)
            Es = [i * 0.05 for i in range(121)]
            ch = D.chart(g, gx, oy + gh + 24, gw, gh, [{"pts": [(E, f(E)) for E in Es], "color": T.c4, "w": 2}], title="分子能量分布", xl="E",
                         xmin=0, xmax=6, ymin=0, ymax=0.9, yticks=False)
            D.poly(g, [(ch["X"](Ea), ch["Y"](0))] + [(ch["X"](E), ch["Y"](f(E))) for E in Es if E >= Ea] + [(ch["X"](6), ch["Y"](0))], alpha(T.c2, 0.35))
            D.line(g, ch["X"](Ea), ch["Y"](0), ch["X"](Ea), ch["Y"](0.85), T.c2, 1.5, [4, 3])
            D.text(g, "Eₐ", ch["X"](Ea) + 4, ch["Y"](0.8), T.c2)
            y0 = oy + 2 * gh + 48
            ch3 = D.chart(g, gx, y0, gw, gh, [], title="反应历程（放热反应）", xmin=0, xmax=1, ymin=0, ymax=5, yticks=False)

            def prof(h):
                return [(i / 60, 2 - 1.2 * i / 60 + h * math.exp(-((i / 60 - 0.5) ** 2) / 0.02)) for i in range(61)]
            D.poly(g, [(ch3["X"](x), ch3["Y"](y)) for x, y in prof(Ea0)], None, T.muted, 2, False)
            if cat.v:
                D.poly(g, [(ch3["X"](x), ch3["Y"](y)) for x, y in prof(EaC)], None, T.c3, 2, False)
            D.text(g, "反应物", ch3["X"](0.02), ch3["Y"](2) - 10, T.muted, size=10)
            D.text(g, "生成物", ch3["X"](0.98), ch3["Y"](0.8) - 10, T.muted, size=10, align="right")
        part = sum(math.sqrt((i + 0.5) * Ea / 400) * math.exp(-(i + 0.5) * Ea / 400 / kt) * Ea / 400 for i in range(400))
        frac = 1 - part / (math.sqrt(PI) / 2 * kt ** 1.5)
        ps = S["ps"]
        out.set([["剩余 A", str(sum(1 for q in ps if q["type"] == "A"))], ["生成 C", str(sum(1 for q in ps if q["type"] == "C"))],
                 ["近 2 秒有效碰撞", f"{len(S['events'])} 次"], ["活化能 Eₐ（相对）", fmt(Ea, 2) + ("（有催化剂）" if cat.v else "")],
                 ["活化分子百分数", fmt(frac * 100, 2) + " %"]])
    L.on_draw(draw)
