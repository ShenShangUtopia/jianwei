"""生物 · 选择性必修2 生物与环境（由 gewu/bio.js 改写）：种群增长与标记重捕、捕食关系、能量流动。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha
from ...kit.core import clamp, fmt, rnd
from ...kit.draw import D
from ...kit.registry import lab


@lab.reg(id="b-pop", subj="bio", book=3, unit="种群及其动态", title="种群增长曲线与标记重捕法", kw="J 形曲线 S 形曲线 环境容纳量 K 值 K/2 增长速率 种群密度 标记重捕法 捕捞",
         info="<p class='fb'>“J”形增长：Nₜ = N₀λᵗ（理想条件：食物空间充裕、气候适宜、没有天敌）<br>“S”形增长：dN/dt = rN(1 − N/K)，K 为环境容纳量<br>"
              "N = K/2 时种群增长速率最大，捕捞后剩余量保持在 K/2 左右可持续获得最大产量</p>"
              "<p><b>标记重捕法</b>（适用于活动能力强、活动范围大的动物）：第一次捕获 M 只并标记放回，第二次捕获 n 只，其中有标记的 m 只，则估算 N ≈ Mn/m。</p>",
         tasks=["观察 S 形曲线中增长速率最大时对应的种群数量。", "加入捕捞，捕捞率为多少时种群仍能维持且年产量最大？", "标记重捕：若标记物易脱落，估算值偏大还是偏小？用模拟验证。"])
def b_pop(L):
    c = L.canvas()

    def on_mode(v):
        G1.setVisible(v == "g")
        G2.setVisible(v == "m")
        L.draw()
    L.group("模式")
    mode = L.seg("", [["g", "增长曲线"], ["m", "标记重捕法"]], "g", on_mode)
    G1 = L.group("参数")
    p = L.params({"r": ["内禀增长率 r", 0.1, 1.5, 0.05, 0.6, "/年"], "K": ["环境容纳量 K", 100, 2000, 50, 1000], "N0": ["初始数量 N₀", 2, 200, 1, 10],
                  "E": ["捕捞率", 0, 1, 0.01, 0, "/年"], "Tm": ["时间", 10, 60, 1, 30, "年"]})
    out = L.out()
    G2 = L.group("标记重捕")
    G2.setVisible(False)
    M = L.slider("第一次捕获并标记 M", 10, 200, 5, 60)
    nn = L.slider("第二次捕获 n", 10, 200, 5, 80)
    loss = L.slider("标记脱落率", 0, 0.5, 0.05, 0)
    S = {"fish": [], "phase": 0, "res": None, "trueN": 0}

    def pond(*_):
        S["trueN"] = round(rnd(300, 900))
        S["fish"] = [{"x": rnd(0, 1), "y": rnd(0, 1), "vx": rnd(-1, 1), "vy": rnd(-1, 1), "mk": False, "cap": False} for _ in range(S["trueN"])]
        S["phase"], S["res"] = 0, None
        L.draw()

    def mark(*_):
        fish = S["fish"]
        for f in fish:
            f["mk"] = f["cap"] = False
        for f in random.sample(fish, min(len(fish), int(M.v))):
            f["mk"] = random.random() >= loss.v
        S["phase"], S["res"] = 1, None
        L.draw()

    def recap(*_):
        if S["phase"] < 1:
            return
        fish = S["fish"]
        for f in fish:
            f["cap"] = False
        s2 = random.sample(fish, min(len(fish), int(nn.v)))
        for f in s2:
            f["cap"] = True
        m = sum(1 for f in s2 if f["mk"])
        S["res"] = {"m": m, "est": M.v * nn.v / m if m else math.inf}
        S["phase"] = 2
        L.draw()
    L.button("第一次捕获并标记", mark, True)
    L.button("第二次捕获", recap, True)
    L.button("换一个池塘", pond)
    out2 = L.out()
    pond()

    def tick(dt):
        if mode.v != "m":
            return
        for f in S["fish"]:
            f["x"] += f["vx"] * dt * 0.05
            f["y"] += f["vy"] * dt * 0.05
            if f["x"] < 0 or f["x"] > 1:
                f["vx"] *= -1
            if f["y"] < 0 or f["y"] > 1:
                f["vy"] *= -1
            f["x"], f["y"] = clamp(f["x"], 0, 1), clamp(f["y"], 0, 1)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        if mode.v == "g":
            r, K, N0, E, Tm = p.r, p.K, p.N0, p.E, p.Tm
            n = 600
            dt = Tm / n
            N = J = N0
            Sp, Jp, R = [(0, N)], [(0, J)], [(0, r * N * (1 - N / K) - E * N)]
            for i in range(1, n + 1):
                N = max(0.0, N + (r * N * (1 - N / K) - E * N) * dt)
                J = J * math.exp(r * dt)
                Sp.append((i * dt, N))
                Jp.append((i * dt, J))
                R.append((i * dt, r * N * (1 - N / K)))
            gh = (c.h - 80) * 0.6
            ch = D.chart(g, 50, 24, c.w - 80, gh, [{"pts": [q for q in Jp if q[1] < K * 1.6], "color": alpha(T.muted, 0.8), "w": 1.6, "dash": [5, 4]},
                                                   {"pts": Sp, "color": T.c3, "w": 2.4}], title="种群数量 N − t（虚线为 J 形）", xl="t / 年", xmin=0, xmax=Tm, ymin=0, ymax=K * 1.5)
            D.line(g, 50, ch["Y"](K), c.w - 30, ch["Y"](K), T.c2, 1, [4, 4])
            D.text(g, "K", c.w - 36, ch["Y"](K) - 8, T.c2)
            D.line(g, 50, ch["Y"](K / 2), c.w - 30, ch["Y"](K / 2), T.grid2, 1, [2, 4])
            D.text(g, "K/2", c.w - 44, ch["Y"](K / 2) - 8, T.muted)
            ch2 = D.chart(g, 50, 50 + gh, c.w - 80, (c.h - 80) * 0.4, [{"pts": R, "color": T.c1, "w": 2}], title="增长速率 dN/dt − t", xl="t / 年", xmin=0, xmax=Tm, ymin=0)
            im = max(range(len(R)), key=lambda i: R[i][1])
            D.circle(g, ch2["X"](R[im][0]), ch2["Y"](R[im][1]), 4, T.c2)
            Neq = K * (1 - E / r) if E < r else 0
            out.set([["K/2", fmt(K / 2, 0)], ["增长速率最大时", f"t ≈ {fmt(R[im][0], 1)} 年"], ["最终数量", fmt(Sp[-1][1], 0)], ["有捕捞时的平衡数量", fmt(Neq, 0)],
                     ["年捕捞量（平衡时）", fmt(E * Neq, 1)], ["最大持续产量 rK/4", f"{fmt(r * K / 4, 1)}（捕捞率 {fmt(r / 2, 2)}）"]])
        else:
            ox = oy = 20
            W, H = c.w - 40, c.h - 40
            g.fill_style = alpha(T.c1, 0.1)
            g.begin_path()
            g.ellipse(ox + W / 2, oy + H / 2, W / 2, H / 2)
            g.fill()
            for f in S["fish"]:
                x = ox + W / 2 + (f["x"] - 0.5) * W * 0.9 * math.sqrt(max(0.0, 1 - ((f["y"] - 0.5) * 1.8) ** 2 * 0.5))
                y = oy + H / 2 + (f["y"] - 0.5) * H * 0.85
                D.circle(g, x, y, 4 if f["cap"] else 2.6, T.c2 if f["mk"] else alpha(T.fg, 0.4), T.c4 if f["cap"] else None, 1.5)
            res, ph = S["res"], S["phase"]
            est = "—"
            if res:
                est = fmt(res["est"], 0) if math.isfinite(res["est"]) else "无法估算（m = 0）"
            out2.set([["标记个体", sum(1 for f in S["fish"] if f["mk"])], ["第二次捕获", int(nn.v) if ph >= 2 else "—"], ["其中有标记 m", res["m"] if res else "—"],
                      ["估算 N = Mn/m", est], ["真实数量", S["trueN"] if ph >= 2 else "（第二次捕获后揭晓）"],
                      ["相对误差", fmt((res["est"] / S["trueN"] - 1) * 100, 1) + " %" if res and math.isfinite(res["est"]) else "—"]])
    L.on_draw(draw)


@lab.reg(id="b-lv", subj="bio", book=3, unit="群落及其演替", title="捕食者与被捕食者的数量变化", kw="捕食 种间关系 周期性波动 Lotka-Volterra 负反馈 猞猁 雪兔",
         info="<p>以雪兔（被捕食者）和猞猁（捕食者）为例：</p><p class='fb'>dx/dt = ax(1 − x/K) − bxy　（被捕食者：繁殖 − 被捕食）<br>dy/dt = cbxy − dy　（捕食者：捕食获得的增长 − 死亡）</p>"
              "<p>被捕食者增多 → 捕食者食物充足而增多 → 被捕食者减少 → 捕食者减少，两者数量呈周期性波动，且捕食者的峰值滞后于被捕食者。右侧相图中曲线绕平衡点旋转。</p>",
         tasks=["在时间图上判断哪条曲线代表捕食者，依据是什么？", "增大被捕食者的环境容纳量 K，波动会怎样变化？", "把捕食者死亡率 d 调得很大，会发生什么？"])
def b_lv(L):
    c = L.canvas()
    p = L.params({"a": ["被捕食者增长率 a", 0.2, 2, 0.05, 1], "K": ["被捕食者容纳量 K", 50, 1000, 10, 400], "b": ["捕食率 b", 0.002, 0.05, 0.001, 0.02, "", 3],
                  "cc": ["转化效率 c", 0.05, 1, 0.05, 0.3], "d": ["捕食者死亡率 d", 0.05, 1.5, 0.05, 0.6], "x0": ["雪兔初始", 5, 300, 5, 100],
                  "y0": ["猞猁初始", 1, 100, 1, 15], "Tm": ["时间", 20, 200, 10, 80]})
    out = L.out()

    def draw():
        c.clear()
        g = c.g
        a, K, b, cc, d, Tm = p.a, p.K, p.b, p.cc, p.d, p.Tm
        n = 4000
        h = Tm / n
        x, y = p.x0, p.y0
        Xs, Ys, PH = [(0, x)], [(0, y)], [(x, y)]

        def f(x, y):
            return a * x * (1 - x / K) - b * x * y, cc * b * x * y - d * y
        for i in range(1, n + 1):
            k1 = f(x, y)
            k2 = f(x + k1[0] * h / 2, y + k1[1] * h / 2)
            k3 = f(x + k2[0] * h / 2, y + k2[1] * h / 2)
            k4 = f(x + k3[0] * h, y + k3[1] * h)
            x = max(0.0, x + (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]) * h / 6)
            y = max(0.0, y + (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]) * h / 6)
            if i % 4 == 0:
                Xs.append((i * h, x))
                Ys.append((i * h, y))
                PH.append((x, y))
        wide = c.w > 640
        gw = c.w * 0.58 if wide else c.w - 80
        gh = c.h - 60 if wide else (c.h - 80) / 2
        ymax = max(max(q[1] for q in Xs), max(q[1] for q in Ys)) * 1.1 or 1
        D.chart(g, 50, 24, gw, gh, [{"pts": Xs, "color": T.c3, "w": 2.2}, {"pts": Ys, "color": T.c2, "w": 2.2}], title="数量 − 时间：绿 雪兔，橙 猞猁", xl="t",
                xmin=0, xmax=Tm, ymin=0, ymax=ymax)
        px = 80 + gw if wide else 50
        py = 24 if wide else 54 + gh
        pw = c.w - px - 20 if wide else c.w - 80
        ch = D.chart(g, px, py, pw, gh, [{"pts": PH, "color": T.c5, "w": 1.6}], title="相图：猞猁 − 雪兔", xl="雪兔", xmin=0,
                     xmax=max(q[0] for q in PH) * 1.1 or 1, ymin=0, ymax=max(q[1] for q in PH) * 1.1 or 1)
        xe = d / (cc * b)
        ye = a / b * (1 - xe / K)
        if ye > 0:
            D.circle(g, ch["X"](xe), ch["Y"](ye), 4, T.fg)
        out.set([["平衡点 雪兔", fmt(xe, 1) if ye > 0 else "—"], ["平衡点 猞猁", fmt(ye, 1) if ye > 0 else "捕食者无法维持"], ["最终 雪兔 / 猞猁", f"{fmt(x, 1)} / {fmt(y, 1)}"]])
    L.on_draw(draw)


@lab.reg(id="b-energy", subj="bio", book=3, unit="生态系统及其稳定性", title="生态系统的能量流动", kw="能量流动 能量金字塔 传递效率 同化量 呼吸作用 分解者 营养级 单向流动 逐级递减",
         info="<p class='fb'>某营养级同化量 = 呼吸作用散失 + 用于自身生长、发育和繁殖<br>用于生长发育繁殖的能量 = 流入下一营养级 + 流向分解者 + 未被利用<br>"
              "相邻营养级传递效率 = 下一营养级同化量 / 上一营养级同化量 ×100%，一般为 10% ~ 20%</p><p>能量流动的特点：<b>单向流动、逐级递减</b>。因此食物链一般不超过 5 个营养级。</p>",
         tasks=["生产者固定 10000 kJ，传递效率 10%，三级消费者能得到多少能量？", "增大呼吸散失比例，最多能维持几个营养级？", "为什么能量金字塔不可能倒置，而数量金字塔可以？"])
def b_energy(L):
    c = L.canvas()
    p = L.params({"E": ["生产者固定的太阳能", 1000, 50000, 500, 10000, "kJ"], "eff": ["传递效率", 5, 25, 1, 10, "%"], "resp": ["呼吸散失占同化量", 30, 80, 1, 55, "%"],
                  "lv": ["营养级数", 2, 5, 1, 4]})
    out = L.out()
    names = ["生产者", "初级消费者", "次级消费者", "三级消费者", "四级消费者"]

    def draw():
        c.clear()
        g = c.g
        E, eff, resp, lv = p.E, p.eff, p.resp, int(p.lv)
        A = [E]
        for i in range(1, lv):
            A.append(A[i - 1] * min(eff / 100, 1 - resp / 100))
        pw = c.w * 0.45
        ph = (c.h - 40) / lv
        cx = 20 + pw / 2
        for i, a in enumerate(A):
            w = max(20, pw * math.sqrt(a / E))
            y = c.h - 20 - (i + 1) * ph
            D.rect(g, cx - w / 2, y + 2, w, ph - 4, alpha(T.c[(i + 2) % 6], 0.65))
            D.text(g, f"{names[i]}  {fmt(a, 1)} kJ", cx, y + ph / 2, T.fg, align="center", size=12, bold=True)
        fx = 40 + pw
        fw = c.w - fx - 20
        if fw > 200:
            for i, a in enumerate(A):
                y = 30 + i * ((c.h - 60) / lv)
                R = a * resp / 100
                nxt = A[i + 1] if i + 1 < len(A) else 0
                rest = a - R - nxt
                D.text(g, names[i], fx, y, T.fg, bold=True, size=12)
                parts = [["呼吸散失", R, T.c2], ["流向下一营养级", nxt, T.c3], ["流向分解者", rest * 0.6, T.c4], ["未利用", rest * 0.4, T.muted]]
                x = fx
                for _n, v, col in parts:
                    w = v / a * fw
                    D.rect(g, x, y + 10, w, 16, alpha(col, 0.7))
                    x += w
                D.text(g, "｜".join(f"{n2} {fmt(v, 1)}" for n2, v, _c in parts[:2]), fx, y + 38, T.muted, size=10.5)
                D.text(g, "｜".join(f"{n2} {fmt(v, 1)}" for n2, v, _c in parts[2:]), fx, y + 52, T.muted, size=10.5)
        out.set([[names[i] + " 同化量", fmt(a, 2) + " kJ"] for i, a in enumerate(A)] +
                [["最高营养级占生产者", fmt(A[-1] / E * 100, 4) + " %"], ["实际传递效率", fmt(min(eff, 100 - resp), 1) + " %"]])
    L.on_draw(draw)
