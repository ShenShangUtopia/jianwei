"""数学 · 选择性必修第三册（由 gewu/math.js、math2.js 改写）：计数原理、随机变量及其分布、成对数据、条件概率。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha
from ...kit.core import TAU, Phi, clamp, comb, fmt, perm, sci
from ...kit.draw import D
from ...kit.registry import lab
from ...kit.view import View

_SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


def sup(k) -> str:
    return str(k).translate(_SUP)


def big(v) -> str:
    return f"{v:,}" if v < 1e15 else sci(float(v), 3)


# ---------------------------------------------------------------- 杨辉三角
@lab.reg(id="m-pascal", subj="math", book=4, unit="计数原理", title="杨辉三角与二项式定理", kw="排列 组合 二项式 系数",
         info="<p class='fb'>Aₙᵐ = n!/(n−m)!　Cₙᵐ = n!/[m!(n−m)!]<br>Cₙᵐ = Cₙⁿ⁻ᵐ　Cₙ₊₁ᵐ = Cₙᵐ + Cₙᵐ⁻¹<br>(a + b)ⁿ = Σ Cₙᵏ aⁿ⁻ᵏ bᵏ，二项式系数之和 = 2ⁿ</p>"
              "<p>杨辉三角第 n 行（从 0 数起）就是 (a+b)ⁿ 的二项式系数，每个数等于肩上两数之和。按奇偶染色会出现谢尔宾斯基三角形。</p>",
         tasks=["验证第 n 行各数之和为 2ⁿ，奇数项系数和等于偶数项系数和。", "把染色改成「被 3 整除」，图案有什么变化？", "计算 (2x − 1)⁶ 展开式中 x³ 的系数。"])
def m_pascal(L):
    c = L.canvas()
    p = L.params({"n": ["行数 n", 1, 32, 1, 10], "k": ["高亮第 k 项", 0, 32, 1, 3]})
    col = L.select("染色", [["none", "不染色"], ["2", "奇偶（mod 2）"], ["3", "被 3 整除（mod 3）"], ["5", "被 5 整除（mod 5）"]], "none")
    L.group("计算器")
    q = L.params({"N": ["n", 0, 30, 1, 6], "M": ["m", 0, 30, 1, 2]})
    out = L.out()

    def draw():
        c.clear()
        g = c.g
        n = int(p.n)
        k = min(int(p.k), n)
        rows = n + 1
        cell = min((c.w - 20) / rows, (c.h - 40) / rows * 1.15)
        hh = cell / 1.15
        for i in range(n + 1):
            for j in range(i + 1):
                x = c.w / 2 + (j - i / 2) * cell
                y = 20 + i * hh + hh / 2
                val = comb(i, j)
                fill = alpha(T.c1, 0.08)
                if col.v != "none":
                    fill = alpha(T.c1, 0.75) if val % int(col.v) else alpha(T.muted, 0.08)
                if i == n:
                    fill = T.c2 if j == k else alpha(T.c2, 0.25)
                D.rrect(g, x - cell / 2 + 1, y - hh / 2 + 1, cell - 2, hh - 2, 3, fill)
                if cell > 22:
                    s = f"{val:.1e}".replace("e+", "e") if val > 99999 else str(val)
                    D.text(g, s, x, y, T.fg, size=min(13, cell / (len(str(val)) * 0.62 + 0.5)), align="center", mono=True)
        terms = []
        for j in range(min(n, 6) + 1):
            cf = comb(n, j)
            terms.append(f"{cf if cf > 1 else ''}{'a' + (sup(n - j) if n - j > 1 else '') if n - j else ''}{'b' + (sup(j) if j > 1 else '') if j else ''}")
        N, M = int(q.N), int(q.M)
        out.set([["(a+b)ⁿ 展开", " + ".join(terms) + (" + …" if n > 6 else "")],
                 [f"第 {k + 1} 项 Tₖ₊₁", f"C({n},{k}) a{sup(n - k)}b{sup(k)} = {comb(n, k)}·a{sup(n - k)}b{sup(k)}"],
                 ["系数和 2ⁿ", str(2 ** n)], [f"A({N},{M})", big(perm(N, M)) if M <= N else "—"],
                 [f"C({N},{M})", big(comb(N, M)) if M <= N else "—"], [f"{N}!", big(perm(N, N))]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 概率分布
@lab.reg(id="m-dist", subj="math", book=4, unit="随机变量及其分布", title="二项、超几何与正态分布", kw="分布列 期望 方差 正态 3σ 原则",
         info="<p class='fb'>二项分布 X ~ B(n, p)：P(X=k) = Cₙᵏpᵏ(1−p)ⁿ⁻ᵏ，E(X)=np，D(X)=np(1−p)<br>超几何分布：N 件中有 M 件次品，抽 n 件，"
              "P(X=k) = C(M,k)C(N−M,n−k)/C(N,n)，E(X)=nM/N<br>正态分布 X ~ N(μ, σ²)：f(x) = 1/(σ√2π)·e^(−(x−μ)²/2σ²)</p>"
              "<p><b>3σ 原则</b>：P(μ−σ ≤ X ≤ μ+σ) ≈ 0.6827，P(μ−2σ ≤ X ≤ μ+2σ) ≈ 0.9545，P(μ−3σ ≤ X ≤ μ+3σ) ≈ 0.9973。</p>",
         tasks=["二项分布中，n 固定时 p 取何值方差最大？", "比较 N 很大时的超几何分布与二项分布 B(n, M/N)，两者有什么关系？",
                "正态分布中把区间设为 [μ−2σ, μ+2σ]，验证概率约为 0.9545。"])
def m_dist(L):
    c = L.canvas()
    L.group("分布")
    kind = L.seg("", [["bin", "二项"], ["hyp", "超几何"], ["nor", "正态"]], "bin", lambda _k: (sync(), L.draw()))
    p = L.params({"n": ["n（试验/抽取次数）", 1, 40, 1, 10], "p": ["p", 0.01, 0.99, 0.01, 0.4], "N": ["总数 N", 5, 100, 1, 30],
                  "M": ["次品数 M", 1, 100, 1, 8], "mu": ["μ", -5, 5, 0.1, 0], "sg": ["σ", 0.2, 3, 0.05, 1]})
    L.group("区间概率 P(a ≤ X ≤ b)")
    q = L.params({"a": ["a", -10, 40, 0.1, 2], "b": ["b", -10, 40, 0.1, 5]})

    def set_ab(k):
        q.s("a").set(p.mu - k * p.sg, True)
        q.s("b").set(p.mu + k * p.sg)
    L.button("μ ± σ", lambda _b: set_ab(1))
    L.button("μ ± 2σ", lambda _b: set_ab(2))
    L.button("μ ± 3σ", lambda _b: set_ab(3))
    cmp = L.check("超几何同时画二项 B(n, M/N) 比较", True)
    out = L.out()

    def sync():
        k = kind.v
        p.s("n").el.setVisible(k != "nor")
        p.s("p").el.setVisible(k == "bin")
        for key in ("N", "M"):
            p.s(key).el.setVisible(k == "hyp")
        for key in ("mu", "sg"):
            p.s(key).el.setVisible(k == "nor")
    sync()

    def draw():
        c.clear()
        g = c.g
        k, a, b = kind.v, q.a, q.b
        v = View(c, 0, 1, 0, 1, pad=(46, 16, 20, 30))
        if k == "nor":
            mu, sg = p.mu, p.sg

            def f(x):
                return math.exp(-((x - mu) ** 2) / (2 * sg * sg)) / (sg * math.sqrt(TAU))
            v.r = [mu - 4.2 * sg, mu + 4.2 * sg, 0, f(mu) * 1.15]
            v.fit()
            v.grid(yl="f(x)")
            lo, hi = max(a, v.x0), min(b, v.x1)
            if hi > lo:
                g.fill_style = alpha(T.c2, 0.3)
                g.begin_path()
                g.move_to(v.X(lo), v.Y(0))
                for i in range(101):
                    x = lo + (hi - lo) * i / 100
                    g.line_to(v.X(x), v.Y(f(x)))
                g.line_to(v.X(hi), v.Y(0))
                g.fill()
            v.plot(f, T.c1, 2.4)
            v.seg(mu, 0, mu, f(mu), T.muted, 1, [4, 3])
            for z in (-3, -2, -1, 1, 2, 3):
                v.seg(mu + z * sg, 0, mu + z * sg, f(mu + z * sg), T.grid2, 1)
            P = Phi((b - mu) / sg) - Phi((a - mu) / sg)
            out.set([["E(X) = μ", fmt(mu, 3)], ["D(X) = σ²", fmt(sg * sg, 4)], ["P(a ≤ X ≤ b)", fmt(max(0, P), 5)],
                     ["最高点", f"({fmt(mu, 2)}, {fmt(f(mu), 4)})"]])
            return
        NN = int(p.N)
        n = min(int(p.n), NN) if k == "hyp" else int(p.n)
        M = min(int(p.M), NN)
        if k == "bin":
            pmf = [comb(n, j) * p.p ** j * (1 - p.p) ** (n - j) for j in range(n + 1)]
        else:
            pmf = [comb(M, j) * comb(NN - M, n - j) / comb(NN, n) for j in range(n + 1)]
        bpm = [comb(n, j) * (M / NN) ** j * (1 - M / NN) ** (n - j) for j in range(n + 1)] if k == "hyp" and cmp.v else None
        v.r = [-0.8, n + 0.8, 0, max(pmf + (bpm or [0])) * 1.15]
        v.fit()
        v.grid(xl="k", yl="P(X=k)", xstep=5 if n > 20 else 2 if n > 10 else 1)
        bw = min(30, v.sx * 0.7)
        P = E = E2 = 0.0
        for j, pr in enumerate(pmf):
            inside = a - 1e-9 <= j <= b + 1e-9
            if inside:
                P += pr
            E += j * pr
            E2 += j * j * pr
            D.rect(g, v.X(j) - bw / 2, v.Y(pr), bw, v.Y(0) - v.Y(pr), alpha(T.c2, 0.8) if inside else alpha(T.c1, 0.55))
        if bpm:
            g.stroke_style, g.line_width = T.c4, 2
            g.begin_path()
            for j, pr in enumerate(bpm):
                (g.line_to if j else g.move_to)(v.X(j), v.Y(pr))
            g.stroke()
        rows = [["E(X)", fmt(E, 4)], ["D(X)", fmt(E2 - E * E, 4)], ["P(a ≤ X ≤ b)", fmt(P, 5)], ["最可能取值", str(pmf.index(max(pmf)))]]
        if k == "bin":
            rows.append(["公式 np , np(1−p)", f"{fmt(n * p.p, 3)} , {fmt(n * p.p * (1 - p.p), 3)}"])
        else:
            rows.append(["公式 nM/N", fmt(n * M / NN, 4)])
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 回归与独立性检验
@lab.reg(id="m-reg", subj="math", book=4, unit="成对数据的统计分析", title="一元线性回归与独立性检验", kw="最小二乘 相关系数 残差 决定系数 卡方 列联表",
         info="<p class='fb'>b̂ = Σ(xᵢ−x̄)(yᵢ−ȳ) / Σ(xᵢ−x̄)²，â = ȳ − b̂x̄，回归直线必过样本中心 (x̄, ȳ)<br>"
              "r = Σ(xᵢ−x̄)(yᵢ−ȳ) / √[Σ(xᵢ−x̄)²·Σ(yᵢ−ȳ)²]，|r| 越接近 1 线性相关越强<br>R² = 1 − Σ(yᵢ−ŷᵢ)² / Σ(yᵢ−ȳ)²</p>"
              "<p><b>独立性检验</b>：χ² = n(ad − bc)² / [(a+b)(c+d)(a+c)(b+d)]。临界值：α=0.1 → 2.706，0.05 → 3.841，0.01 → 6.635，"
              "0.005 → 7.879，0.001 → 10.828。</p>",
         tasks=["点击画布添加点，拖动一个点远离直线（离群点），看 r 和回归直线如何变化。", "把所有点排成一条直线，r 等于多少？",
                "独立性检验：改变 a、d 让 ad 与 bc 接近，χ² 如何变化？"])
def m_reg(L):
    c = L.canvas()
    v = View(c, 0, 10, 0, 10, pad=(36, 14, 14, 30))
    S = {"pts": [[1, 2.1], [2, 2.9], [3, 3.2], [4, 4.8], [5, 5.1], [6, 5.9], [7, 7.4], [8, 7.6], [9, 8.9]]}

    def set_mode(m):
        G1.setVisible(m == "r")
        G2.setVisible(m == "x")
        L.draw()
    L.group("模式")
    mode = L.seg("", [["r", "线性回归"], ["x", "独立性检验"]], "r", set_mode)
    G1 = L.group("回归")
    res = L.check("画残差", True)

    def gen(_b):
        k, b0, s = random.uniform(-1, 1.2), random.uniform(1, 4), random.uniform(0.3, 1.8)
        pts = []
        for _i in range(14):
            x = random.uniform(0.5, 9.5)
            pts.append([x, clamp(b0 + k * x * 0.7 + s * random.gauss(0, 1), 0.2, 9.8)])
        S["pts"] = pts
        L.draw()

    def pop(_b):
        if S["pts"]:
            S["pts"].pop()
        L.draw()
    L.button("随机生成", gen)
    L.button("删最后一个点", pop)
    L.button("清空", lambda _b: (S.__setitem__("pts", []), L.draw()))
    L.note("点击空白处添加点，拖动已有点。")
    out = L.out()
    G2 = L.group("2×2 列联表")
    G2.setVisible(False)
    L.note("例：是否吸烟与是否患病")
    t = L.params({"a": ["a 吸烟·患病", 0, 200, 1, 60], "b": ["b 吸烟·未患病", 0, 200, 1, 40], "c": ["c 不吸烟·患病", 0, 200, 1, 30],
                  "d": ["d 不吸烟·未患病", 0, 200, 1, 70]})
    out2 = L.out()

    def hit(x, y):
        if mode.v != "r":
            return None
        i = next((i for i, q in enumerate(S["pts"]) if math.hypot(v.X(q[0]) - x, v.Y(q[1]) - y) < 10), -1)
        return {"i": i} if i >= 0 else None

    def drag(o, x, y, _dx, _dy):
        S["pts"][o["i"]] = [clamp(v.ix(x), 0, 10), clamp(v.iy(y), 0, 10)]

    def click(x, y, o):
        if mode.v == "r" and not o:
            S["pts"].append([clamp(v.ix(x), 0, 10), clamp(v.iy(y), 0, 10)])
    L.interact(c, hit=hit, drag=drag, click=click)

    def draw():
        c.clear()
        g = c.g
        if mode.v == "r":
            v.fit()
            v.grid()
            pts = S["pts"]
            n = len(pts)
            rows = [["点数", str(n)]]
            if n >= 2:
                mx = sum(q[0] for q in pts) / n
                my = sum(q[1] for q in pts) / n
                sxy = sum((x - mx) * (y - my) for x, y in pts)
                sxx = sum((x - mx) ** 2 for x, _ in pts)
                syy = sum((y - my) ** 2 for _, y in pts)
                b = sxy / sxx if sxx else 0
                a = my - b * mx
                r = sxy / math.sqrt(sxx * syy) if sxx and syy else 0
                sse = sum((y - a - b * x) ** 2 for x, y in pts)
                R2 = 1 - sse / syy if syy else 1
                if res.v:
                    for x, y in pts:
                        v.seg(x, y, x, a + b * x, T.c2, 1.2)
                v.plot(lambda x: a + b * x, T.c1, 2.4)
                v.dot(mx, my, T.c4, 6, True)
                v.label("(x̄, ȳ)", mx, my, T.c4)
                rel = ("强正相关" if r > 0 else "强负相关") if abs(r) > 0.75 else ("正相关" if r > 0 else "负相关") if abs(r) > 0.3 else "相关性弱"
                rows += [["回归方程", f"ŷ = {fmt(b, 3)}x {'+' if a >= 0 else '−'} {fmt(abs(a), 3)}"], ["x̄ , ȳ", f"{fmt(mx, 3)} , {fmt(my, 3)}"],
                         ["相关系数 r", fmt(r, 4)], ["相关性", rel], ["残差平方和", fmt(sse, 4)], ["决定系数 R²", fmt(R2, 4)]]
            for x, y in pts:
                v.dot(x, y, T.fg, 4.5, True)
            out.set(rows)
        else:
            a, b, cc, d = t.a, t.b, t.c, t.d
            n = a + b + cc + d
            den = (a + b) * (cc + d) * (a + cc) * (b + d)
            chi = n * (a * d - b * cc) ** 2 / den if den else 0
            crit = [(0.1, 2.706), (0.05, 3.841), (0.01, 6.635), (0.005, 7.879), (0.001, 10.828)]
            ok = [x for x in crit if chi >= x[1]]
            W = min(c.w - 80, 420)
            x0, y0, H = (c.w - W) / 2, 50, c.h - 120
            bw = W / 2 - 40
            for i, (p1, p2, lab_) in enumerate(((a, b, "吸烟"), (cc, d, "不吸烟"))):
                s = (p1 + p2) or 1
                x = x0 + i * (W / 2) + 20
                D.rect(g, x, y0, bw, H * p1 / s, alpha(T.c2, 0.75))
                D.rect(g, x, y0 + H * p1 / s, bw, H * p2 / s, alpha(T.c1, 0.5))
                D.text(g, f"患病 {fmt(p1 / s * 100, 1)}%", x + bw / 2, y0 + H * p1 / s / 2, T.fg, align="center")
                D.text(g, lab_, x + bw / 2, y0 + H + 16, T.fg, align="center", bold=True)
            D.text(g, "等高堆积条形图：两组中「患病」所占比例差别越大，越可能有关联", c.w / 2, 24, T.muted, align="center")
            out2.set([["n", fmt(n, 0)], ["ad − bc", fmt(a * d - b * cc, 0)], ["χ²", fmt(chi, 4)],
                      ["结论", f"在 α = {ok[-1][0]} 水平下认为两者有关联" if ok else "没有充分证据认为有关联（α = 0.1）"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 条件概率与全概率公式
@lab.reg(id="m-condprob", subj="math", book=4, unit="随机变量及其分布 · 条件概率", title="条件概率、全概率与贝叶斯公式",
         kw="条件概率 乘法公式 全概率公式 贝叶斯公式 树状图 独立事件 假阳性",
         info="<p class='fb'>条件概率 P(B|A) = P(AB)/P(A)　乘法公式 P(AB) = P(A)P(B|A)<br>全概率公式：P(B) = Σ P(Aᵢ)P(B|Aᵢ)（A₁, A₂, … 构成样本空间的一个划分）<br>"
              "贝叶斯公式：P(Aᵢ|B) = P(Aᵢ)P(B|Aᵢ) / P(B)</p><p>左边是树状图，右边是面积图：每一列宽度为 P(Aᵢ)，阴影高度为 P(B|Aᵢ)，阴影总面积就是 P(B)；"
              "已知 B 发生时，某一列阴影占总阴影的比例就是 P(Aᵢ|B)。</p>",
         tasks=["「三家工厂」情境：随机取一件是次品的概率是多少？这件次品来自甲厂的概率呢？", "「疾病检测」情境：患病率 1%，检测阳性者真正患病的概率是多少？为什么这么低？",
                "把患病率改为 20%，阳性者患病的概率怎样变化？"])
def m_condprob(L):
    import copy
    c = L.canvas()
    PRE = {
        "fac": {"n": 3, "A": ["甲厂", "乙厂", "丙厂"], "B": "次品", "pa": [0.25, 0.35, 0.4], "pb": [0.05, 0.04, 0.02]},
        "med": {"n": 2, "A": ["患病", "未患病"], "B": "检测阳性", "pa": [0.01, 0.99], "pb": [0.99, 0.05]},
        "ball": {"n": 2, "A": ["第一次摸到红球", "第一次摸到白球"], "B": "第二次摸到红球", "pa": [0.6, 0.4], "pb": [5 / 9, 6 / 9]},
    }
    S = {"sc": copy.deepcopy(PRE["fac"]), "sim": None}

    def pick(k):
        S["sc"] = copy.deepcopy(PRE[k])
        load()
    L.group("情境")
    L.select("", [["fac", "三家工厂生产同一种产品"], ["med", "疾病检测（假阳性）"], ["ball", "袋中 6 红 4 白，不放回摸两次"]], "fac", pick)
    L.group("概率")
    q = L.params({"a1": ["P(A₁)", 0, 1, 0.01, 0.25], "a2": ["P(A₂)", 0, 1, 0.01, 0.35], "b1": ["P(B|A₁)", 0, 1, 0.005, 0.05],
                  "b2": ["P(B|A₂)", 0, 1, 0.005, 0.04], "b3": ["P(B|A₃)", 0, 1, 0.005, 0.02]},
                 lambda _k, _v: (S.__setitem__("sim", None), L.draw()))

    def probs():
        n = S["sc"]["n"]
        return [q.a1, q.a2, max(0.0, 1 - q.a1 - q.a2)] if n == 3 else [q.a1, 1 - q.a1]

    def pb():
        return [q.b1, q.b2, q.b3][:S["sc"]["n"]]

    def simulate(_b):
        pa, pbv, n = probs(), pb(), S["sc"]["n"]
        N, cnt, cb = 10000, [0] * n, [0] * n
        for _i in range(N):
            r, k = random.random(), 0
            while k < n - 1:
                r -= pa[k]
                if r <= 0:
                    break
                k += 1
            cnt[k] += 1
            if random.random() < pbv[k]:
                cb[k] += 1
        S["sim"] = {"N": N, "cnt": cnt, "cb": cb}
        L.draw()
    L.button("随机模拟 10000 次", simulate, True)
    out = L.out()

    def load():
        sc = S["sc"]
        q.s("a1").set(sc["pa"][0], True)
        q.s("a2").set(sc["pa"][1], True)
        q.s("b1").set(sc["pb"][0], True)
        q.s("b2").set(sc["pb"][1], True)
        q.s("b3").set(sc["pb"][2] if len(sc["pb"]) > 2 else 0, True)
        q.s("a2").el.setVisible(sc["n"] >= 3)
        q.s("b3").el.setVisible(sc["n"] >= 3)
        S["sim"] = None
        L.draw()
    load()

    def draw():
        c.clear()
        g = c.g
        sc = S["sc"]
        pa, pbv = probs(), pb()
        joint = [x * pbv[i] for i, x in enumerate(pa)]
        PB = sum(joint)
        tw = c.w * 0.48
        x0 = 30
        xm, x1 = x0 + tw * 0.42, x0 + tw * 0.92
        H = c.h - 40
        n = sc["n"]
        D.circle(g, x0, c.h / 2, 5, T.fg)
        for i, p1 in enumerate(pa):
            y = 20 + (i + 0.5) * H / n
            D.line(g, x0, c.h / 2, xm, y, T.c[i], 2)
            D.text(g, fmt(p1, 3), (x0 + xm) / 2 - 10, (c.h / 2 + y) / 2 - 10, T.c[i], size=12, mono=True)
            D.text(g, sc["A"][i], xm + 4, y - 12, T.fg, size=12, bold=True)
            for p2, nm, sd in ((pbv[i], sc["B"], -1), (1 - pbv[i], "非" + sc["B"], 1)):
                yy = y + sd * H / n * 0.22
                D.line(g, xm, y, x1, yy, T.c2 if sd < 0 else T.grid2, 2 if sd < 0 else 1.4)
                D.text(g, fmt(p2, 3), (xm + x1) / 2, (y + yy) / 2 - 9, T.muted, size=11, mono=True, align="center")
                D.text(g, nm, x1 + 4, yy, T.c2 if sd < 0 else T.muted, size=11)
                if sd < 0:
                    D.text(g, "= " + fmt(p1 * p2, 4), x1 + 4, yy + 14, T.c2, size=11, mono=True)
        ax = c.w * 0.55
        aw, ay, ah = c.w - ax - 20, 30, c.h - 70
        xx = ax
        for i, p1 in enumerate(pa):
            w = p1 * aw
            D.rect(g, xx, ay, w, ah, alpha(T.c[i], 0.12), T.line, 1)
            D.rect(g, xx, ay + ah * (1 - pbv[i]), w, ah * pbv[i], alpha(T.c2, 0.55))
            if w > 30:
                D.text(g, sc["A"][i], xx + w / 2, ay + ah + 14, T.c[i], align="center", size=11)
            xx += w
        D.text(g, f"阴影总面积 = P({sc['B']}) = {fmt(PB, 4)}", ax, 16, T.c2, size=12)
        rows = [[f"P({sc['B']})（全概率）", " + ".join(fmt(x, 4) for x in joint) + f" = {fmt(PB, 4)}"]]
        for i in range(n):
            rows.append([f"P({sc['A'][i]}|{sc['B']})", f"{fmt(joint[i], 4)} / {fmt(PB, 4)} = {fmt(joint[i] / PB, 4)}" if PB else "—"])
        sim = S["sim"]
        if sim:
            tb = sum(sim["cb"])
            rows += [["<i>模拟 10000 次</i>", ""], [f"{sc['B']} 的频率", fmt(tb / sim["N"], 4)]]
            for i, x in enumerate(sim["cb"]):
                rows.append([f"{sc['B']}中来自「{sc['A'][i]}」", fmt(x / tb, 4) if tb else "—"])
        out.set(rows)
    L.on_draw(draw)
