"""物理 · 必修第一册（由 gewu/phys.js 改写）。"""
from __future__ import annotations

import math

from PySide6.QtCore import Qt

from ...design.tokens import T, alpha
from ...kit.core import fmt, lerp
from ...kit.draw import D
from ...kit.registry import lab


# ---------------------------------------------------------------- 电路小图元（多个实验共用）
def flow_dots(g, path, phase, color, gap=22):
    """沿折线移动的电流点。"""
    segs, total = [], 0.0
    for (x1, y1), (x2, y2) in zip(path, path[1:]):
        L = math.hypot(x2 - x1, y2 - y1)
        segs.append((x1, y1, x2, y2, L, total))
        total += L
    s = ((phase % gap) + gap) % gap
    while s < total:
        sg = next((q for q in segs if q[5] <= s <= q[5] + q[4]), None)
        if sg and sg[4] > 0:
            t = (s - sg[5]) / sg[4]
            D.circle(g, lerp(sg[0], sg[2], t), lerp(sg[1], sg[3], t), 2.6, color)
        s += gap


def wire(g, pts, c=None, w=1.8):
    D.poly(g, pts, None, c or T.fg, w, False)


def resistor(g, x1, y1, x2, y2, label, c=None):
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    L2, W2 = 22, 8
    if abs(x2 - x1) > abs(y2 - y1):
        D.line(g, x1, y1, mx - L2, my, T.fg, 1.8)
        D.line(g, mx + L2, my, x2, y2, T.fg, 1.8)
        D.rect(g, mx - L2, my - W2, 2 * L2, 2 * W2, T.stage, c or T.fg, 1.8)
        D.text(g, label, mx, my - W2 - 10, T.fg, align="center", size=12)
    else:
        D.line(g, x1, y1, mx, my - L2, T.fg, 1.8)
        D.line(g, mx, my + L2, x2, y2, T.fg, 1.8)
        D.rect(g, mx - W2, my - L2, 2 * W2, 2 * L2, T.stage, c or T.fg, 1.8)
        D.text(g, label, mx + W2 + 6, my, T.fg, size=12)


def meter(g, x, y, letter, val=None):
    D.circle(g, x, y, 14, T.stage, T.fg, 1.8)
    D.text(g, letter, x, y + 1, T.fg, align="center", bold=True, size=13)
    if val:
        D.text(g, val, x, y + 26, T.accent, align="center", size=11.5, mono=True)


def battery(g, x, y, vertical, label=None, flip=False):
    s = -1 if flip else 1
    if vertical:
        D.line(g, x - 14, y - 4 * s, x + 14, y - 4 * s, T.fg, 2)
        D.line(g, x - 7, y + 4 * s, x + 7, y + 4 * s, T.fg, 4)
    else:
        D.line(g, x - 4 * s, y - 14, x - 4 * s, y + 14, T.fg, 2)
        D.line(g, x + 4 * s, y - 7, x + 4 * s, y + 7, T.fg, 4)
    if label:
        D.text(g, label, x + (20 if vertical else 0), y + (0 if vertical else -24), T.fg,
               align="left" if vertical else "center", size=12)


# ---------------------------------------------------------------- 匀变速直线运动
@lab.reg(id="p-kin", subj="phys", book=0, unit="匀变速直线运动的研究", title="匀变速直线运动与打点纸带",
         kw="位移 速度 加速度 x-t v-t 图像 自由落体 逐差法",
         info="<p class='fb'>v = v₀ + at　x = v₀t + ½at²　v² − v₀² = 2ax<br>连续相等时间 T 内的位移差 Δx = aT²（逐差法求加速度）<br>"
              "某段时间中间时刻的瞬时速度 = 该段平均速度</p><p>纸带上每 0.1 s 打一个计数点。v-t 图像与时间轴围成的面积等于位移，图像斜率等于加速度；"
              "x-t 图像切线斜率等于瞬时速度。自由落体是 v₀ = 0、a = g 的匀加速直线运动。</p>",
         tasks=["选「匀减速」，观察 v-t 图像穿过时间轴时小车怎样运动，x-t 图像此时有什么特点？",
                "读出纸带上相邻计数点的间距，用逐差法求 a，再与设定值比较。",
                "自由落体中，前 1 s、前 2 s、前 3 s 内的位移之比是多少？"])
def p_kin(L):
    c = L.canvas()
    st = {"t": 0.0}

    def changed(_k, _v):
        st["t"] = 0.0
        L.draw()
    p = L.params({"v0": ["初速度 v₀", -10, 10, 0.5, 1, "m/s"], "a": ["加速度 a", -5, 10, 0.1, 2, "m/s²"],
                  "T": ["总时长", 1, 8, 0.5, 4, "s"]}, changed)

    def preset(v0, a):
        p.s("v0").set(v0, True)
        p.a = a
    L.button("匀速", lambda _b: preset(3, 0))
    L.button("匀加速", lambda _b: preset(1, 2))
    L.button("匀减速", lambda _b: preset(8, -3))
    L.button("自由落体", lambda _b: preset(0, 9.8))
    L.group("运行")

    def tick(dt):
        st["t"] += dt
        if st["t"] >= p.T:
            st["t"] = p.T
            run.pause()
        L.draw()
    run = L.loop(tick, False)

    def start(_b):
        if st["t"] >= p.T:
            st["t"] = 0.0
        run.toggle()

    def reset(_b):
        st["t"] = 0.0
        run.pause()
        L.draw()
    L.button("开始 / 暂停", start, True)
    L.button("重置", reset)
    out = L.out()

    def draw():
        c.clear()
        g, v0, a, Tm, t = c.g, p.v0, p.a, p.T, st["t"]

        def X(tt):
            return v0 * tt + a * tt * tt / 2

        def V(tt):
            return v0 + a * tt
        samples = [X(Tm * i / 100) for i in range(101)]
        xmin, xmax = min(0, *samples), max(0.5, *samples)
        pad = 40
        W = c.w - 2 * pad
        sx = W / (xmax - xmin or 1)

        def PX(x):
            return pad + (x - xmin) * sx
        # 轨道与小车
        ty = 60
        D.line(g, pad - 10, ty + 14, c.w - pad + 10, ty + 14, T.axis, 2)
        step = max(1, round(60 / sx))
        m = math.ceil(xmin)
        while m <= xmax:
            D.line(g, PX(m), ty + 14, PX(m), ty + 20, T.axis, 1)
            D.text(g, f"{m} m", PX(m), ty + 30, T.muted, align="center", size=10, mono=True)
            m += step
        cx = PX(X(t))
        D.rrect(g, cx - 18, ty - 8, 36, 20, 4, T.c1)
        D.circle(g, cx - 10, ty + 12, 4, T.fg)
        D.circle(g, cx + 10, ty + 12, 4, T.fg)
        D.arrow(g, cx, ty - 18, cx + V(t) * 6, ty - 18, T.c2, 2.4)
        D.text(g, "v", cx + V(t) * 6 + (6 if V(t) >= 0 else -12), ty - 18, T.c2)
        # 纸带
        py = 108
        D.rect(g, pad - 10, py - 12, W + 20, 24, alpha(T.c4, 0.18), T.line, 1)
        last, gaps, k = None, [], 0
        while k * 0.1 <= t + 1e-9:
            x = PX(X(k * 0.1))
            D.circle(g, x, py, 2.6, T.fg)
            if last is not None:
                gaps.append(X(k * 0.1) - last)
            last = X(k * 0.1)
            k += 1
        D.text(g, "纸带（每 0.1 s 一个计数点）", pad - 6, py + 22, T.muted, size=11)
        # 图像
        gy = 150
        gh = c.h - gy - 30
        gw = (c.w - 3 * pad) / 2
        ts = [Tm * i / 120 for i in range(121)]
        cur = [x for x in ts if x <= t] + [t]
        xc = D.chart(g, pad, gy, gw, gh, [{"pts": [(x, X(x)) for x in ts], "color": T.grid2, "dash": [4, 4]},
                                         {"pts": [(x, X(x)) for x in cur], "color": T.c1, "w": 2.4}],
                     title="x − t 图像（m）", xl="t / s", xmin=0, xmax=Tm)
        vmin, vmax = min(0, V(0), V(Tm)), max(0.5, V(0), V(Tm))
        vc = D.chart(g, 2 * pad + gw, gy, gw, gh, [{"pts": [(x, V(x)) for x in ts], "color": T.grid2, "dash": [4, 4]},
                                                  {"pts": [(x, V(x)) for x in cur], "color": T.c2, "w": 2.4}],
                     title="v − t 图像（m/s）", xl="t / s", xmin=0, xmax=Tm, ymin=vmin * 1.1, ymax=vmax * 1.1)
        g.fill_style = alpha(T.c2, 0.15)
        g.begin_path()
        g.move_to(vc["X"](0), vc["Y"](0))
        for x in cur:
            g.line_to(vc["X"](x), vc["Y"](V(x)))
        g.line_to(vc["X"](t), vc["Y"](0))
        g.fill()
        D.circle(g, xc["X"](t), xc["Y"](X(t)), 4, T.c1)
        D.circle(g, vc["X"](t), vc["Y"](V(t)), 4, T.c2)
        dd = [b - a2 for a2, b in zip(gaps, gaps[1:])]
        out.set([["t", fmt(t, 2) + " s"], ["位移 x", fmt(X(t), 3) + " m"], ["速度 v", fmt(V(t), 3) + " m/s"],
                 ["相邻计数点间距", ", ".join(fmt(x * 100, 1) for x in gaps[-3:]) + " cm"],
                 ["相邻间距之差 Δx", fmt(dd[-1] * 100, 2) + " cm" if dd else "—"],
                 ["aT² 理论值", fmt(a * 0.01 * 100, 2) + " cm"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 力的合成与分解
@lab.reg(id="p-force", subj="phys", book=0, unit="相互作用——力", title="力的合成与分解", kw="平行四边形定则 合力 分力 正交分解",
         info="<p><b>平行四边形定则</b>：以两个分力为邻边作平行四边形，对角线就是合力。</p><p class='fb'>F = √(F₁² + F₂² + 2F₁F₂cos θ)<br>|F₁ − F₂| ≤ F ≤ F₁ + F₂</p>"
              "<p>力的分解是合成的逆运算：给定两个分力的方向，分解结果是唯一的。正交分解把力沿互相垂直的 x、y 轴分解：Fₓ = F cos α，F_y = F sin α。</p>",
         tasks=["保持两个分力大小不变，增大夹角，合力如何变化？", "两个 6 N 的力合力为 6 N，夹角是多少？", "分解模式：保持 F 不变，让两个方向夹角变小，两个分力怎样变化？"])
def p_force(L):
    from ...kit.view import View
    PI = math.pi
    c = L.canvas()
    v = View(c, -12, 12, -9, 9, equal=True)
    P = {"F1": [6.0, 2.0], "F2": [2.0, 5.0], "F": [7.0, 4.0]}
    L.group("模式")
    mode = L.seg("", [["add", "合成"], ["dec", "分解"]], "add", lambda m: (gd.setVisible(m == "dec"), L.draw()))
    ring = L.check("显示合力范围圆环", True)
    gd = L.group("分解方向")
    gd.setVisible(False)
    q = L.params({"a1": ["方向 1 与 x 轴夹角", -90, 180, 1, 0, "°"], "a2": ["方向 2 与 x 轴夹角", -90, 180, 1, 90, "°"]})

    def ortho(_b):
        q.s("a1").set(0, True)
        q.a2 = 90
    L.button("正交分解", ortho)
    out = L.out()
    L.note("拖动箭头端点改变力的大小与方向。网格每格 1 N。")

    def hit(x, y):
        keys = ("F1", "F2") if mode.v == "add" else ("F",)
        return next((k for k in keys if math.hypot(v.X(P[k][0]) - x, v.Y(P[k][1]) - y) < 14), None)

    def drag(k, x, y, _dx, _dy):
        P[k] = [round(v.ix(x) * 2) / 2, round(v.iy(y) * 2) / 2]
    L.interact(c, hit=hit, drag=drag)

    def mag(p):
        return math.hypot(p[0], p[1])

    def ang(p):
        return math.atan2(p[1], p[0]) * 180 / PI

    def draw():
        v.begin(xl="x", yl="y")
        g = c.g
        if mode.v == "add":
            a, b = P["F1"], P["F2"]
            R = [a[0] + b[0], a[1] + b[1]]
            m1, m2 = mag(a), mag(b)
            if ring.v:
                g.fill_style = alpha(T.c3, 0.08)
                g.begin_path()
                g.ellipse(v.X(0), v.Y(0), (m1 + m2) * v.sx, (m1 + m2) * v.sx)
                g.ellipse(v.X(0), v.Y(0), abs(m1 - m2) * v.sx, abs(m1 - m2) * v.sx)
                g.path.setFillRule(Qt.FillRule.OddEvenFill)
                g.fill()
            v.seg(a[0], a[1], R[0], R[1], T.muted, 1, [4, 3])
            v.seg(b[0], b[1], R[0], R[1], T.muted, 1, [4, 3])
            v.vec(0, 0, *R, T.c3, 3.2)
            v.vec(0, 0, *a, T.c1, 2.6)
            v.vec(0, 0, *b, T.c2, 2.6)
            v.label("F₁", *a, T.c1, bold=True, size=13)
            v.label("F₂", *b, T.c2, bold=True, size=13)
            v.label("F 合", *R, T.c3, bold=True, size=13)
            v.dot(*a, T.c1, 6, True)
            v.dot(*b, T.c2, 6, True)
            th = abs(ang(a) - ang(b))
            if th > 180:
                th = 360 - th
            out.set([["F₁", fmt(m1, 2) + " N"], ["F₂", fmt(m2, 2) + " N"], ["夹角 θ", fmt(th, 1) + "°"], ["合力 F", fmt(mag(R), 3) + " N"],
                     ["合力方向", fmt(ang(R), 1) + "°"], ["范围", f"{fmt(abs(m1 - m2), 2)} ~ {fmt(m1 + m2, 2)} N"]])
        else:
            F = P["F"]
            u1 = [math.cos(q.a1 * PI / 180), math.sin(q.a1 * PI / 180)]
            u2 = [math.cos(q.a2 * PI / 180), math.sin(q.a2 * PI / 180)]
            det = u1[0] * u2[1] - u1[1] * u2[0]
            v.seg(-u1[0] * 20, -u1[1] * 20, u1[0] * 20, u1[1] * 20, T.c1, 1, [2, 4])
            v.seg(-u2[0] * 20, -u2[1] * 20, u2[0] * 20, u2[1] * 20, T.c2, 1, [2, 4])
            rows = [["F", fmt(mag(F), 3) + " N"]]
            if abs(det) > 1e-6:
                k1 = (F[0] * u2[1] - F[1] * u2[0]) / det
                k2 = (u1[0] * F[1] - u1[1] * F[0]) / det
                A, B = [k1 * u1[0], k1 * u1[1]], [k2 * u2[0], k2 * u2[1]]
                v.seg(*A, *F, T.muted, 1, [4, 3])
                v.seg(*B, *F, T.muted, 1, [4, 3])
                v.vec(0, 0, *A, T.c1, 2.6)
                v.vec(0, 0, *B, T.c2, 2.6)
                v.label("F₁", *A, T.c1, bold=True)
                v.label("F₂", *B, T.c2, bold=True)
                rows += [["分力 1（沿方向 1）", fmt(k1, 3) + " N"], ["分力 2（沿方向 2）", fmt(k2, 3) + " N"]]
            else:
                rows.append(["提示", "两方向共线，无法分解"])
            v.vec(0, 0, *F, T.c3, 3.2)
            v.dot(*F, T.c3, 6, True)
            v.label("F", *F, T.c3, bold=True, size=13)
            out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 斜面上的物块
@lab.reg(id="p-incline", subj="phys", book=0, unit="运动和力的关系", title="斜面上的物块与牛顿第二定律", kw="受力分析 摩擦力 静摩擦 滑动摩擦 牛顿第二定律",
         info="<p>物块受重力 G、支持力 N、摩擦力 f 及沿斜面的外力 F（向上为正）。</p><p class='fb'>N = mg cos θ　G 沿斜面分力 = mg sin θ<br>"
              "滑动摩擦 f = μN，方向与相对运动方向相反<br>静止时为静摩擦，大小由平衡条件决定，最大值近似取 μN<br>F 合 = ma</p>"
              "<p>不受外力时物块能静止的条件是 tan θ ≤ μ。θ 增大到 arctan μ 时物块恰好开始下滑。</p>",
         tasks=["F = 0、μ = 0.5，缓慢增大 θ，物块在约多少度时开始下滑？与 arctan 0.5 比较。",
                "让物块静止，逐渐增大 F，观察静摩擦力的大小和方向如何变化。", "无摩擦时，加速度与质量有关吗？为什么？"])
def p_incline(L):
    PI = math.pi
    c = L.canvas()
    Lg = 6
    S = {"s": 3.0, "vel": 0.0}
    p = L.params({"th": ["倾角 θ", 0, 60, 1, 30, "°"], "m": ["质量 m", 0.5, 10, 0.5, 2, "kg"], "mu": ["动摩擦因数 μ", 0, 1, 0.01, 0.3],
                  "F": ["沿斜面外力 F（向上为正）", -40, 40, 0.5, 0, "N"]})
    L.group("运行")

    def forces():
        g0 = 9.8
        th = p.th * PI / 180
        N = p.m * g0 * math.cos(th)
        Gp = p.m * g0 * math.sin(th)
        drive = p.F - Gp
        if abs(S["vel"]) < 1e-4:
            if abs(drive) <= p.mu * N + 1e-9:
                f, a, kind = -drive, 0.0, "静摩擦"
            else:
                f = -math.copysign(p.mu * N, drive)
                a, kind = (drive + f) / p.m, "滑动摩擦"
        else:
            f = -math.copysign(p.mu * N, S["vel"])
            a, kind = (drive + f) / p.m, "滑动摩擦"
        return {"N": N, "Gp": Gp, "f": f, "a": a, "kind": kind, "G": p.m * g0, "th": th}

    def step(dt):
        st = forces()
        vel = S["vel"]
        nv = vel + st["a"] * dt
        if vel != 0 and (nv > 0) != (vel > 0) and abs(st["f"]) > 0 and (st["f"] > 0) != (nv > 0):
            vel = 0.0
        else:
            vel = nv
        if abs(vel) < 1e-4 and st["kind"] == "静摩擦":
            vel = 0.0
        s = S["s"] + vel * dt
        if s < 0.4:
            s, vel = 0.4, 0.0
        if s > Lg - 0.4:
            s, vel = Lg - 0.4, 0.0
        S["s"], S["vel"] = s, vel

    def tick(dt):
        step(dt)
        L.draw()
    run = L.loop(tick)

    def home(_b):
        S["s"], S["vel"] = 3.0, 0.0
        L.draw()
    L.button("暂停 / 继续", lambda _b: run.toggle())
    L.button("放回中点", home, True)
    out = L.out()

    def draw():
        c.clear()
        g = c.g
        st = forces()
        th = st["th"]
        sc = min((c.w - 80) / (Lg * math.cos(th) + 0.5), (c.h - 80) / (Lg * math.sin(th) + 1.5), 110)
        ox, oy = 40, c.h - 40
        B = (ox + Lg * math.cos(th) * sc, oy)
        Tp = (ox + Lg * math.cos(th) * sc, oy - Lg * math.sin(th) * sc)
        D.poly(g, [(ox, oy), B, Tp], alpha(T.muted, 0.12), T.fg, 1.8)
        D.line(g, 10, oy, c.w - 10, oy, T.axis, 1.5)
        g.stroke_style = T.muted
        g.begin_path()
        g.arc(ox, oy, 36, -th, 0)
        g.stroke()
        D.text(g, "θ", ox + 44, oy - 10, T.muted)
        ux, uy = math.cos(th), -math.sin(th)
        nx, ny = math.sin(th), math.cos(th)
        s = S["s"]
        bx, by = ox + s * sc * math.cos(th), oy - s * sc * math.sin(th)
        bw, bh = 0.8 * sc, 0.5 * sc
        cx, cy = bx - nx * bh / 2, by - ny * bh / 2
        g.save()
        g.translate(cx, cy)
        g.rotate(-th)
        D.rrect(g, -bw / 2, -bh / 2, bw, bh, 3, alpha(T.c1, 0.85), T.fg, 1.2)
        g.restore()
        k = min(60 / max(st["G"], 1), 4)
        D.arrow(g, cx, cy, cx, cy + st["G"] * k, T.fg, 2.4)
        D.text(g, "G", cx + 6, cy + st["G"] * k, T.fg, bold=True)
        D.arrow(g, cx, cy, cx - nx * st["N"] * k, cy - ny * st["N"] * k, T.c3, 2.4)
        D.text(g, "N", cx - nx * st["N"] * k - 14, cy - ny * st["N"] * k, T.c3, bold=True)
        f = st["f"]
        if abs(f) > 1e-6:
            D.arrow(g, bx, by, bx + ux * f * k, by + uy * f * k, T.c2, 2.4)
            D.text(g, "f", bx + ux * f * k + 4, by + uy * f * k - 8, T.c2, bold=True)
        if abs(p.F) > 1e-6:
            D.arrow(g, cx, cy, cx + ux * p.F * k, cy + uy * p.F * k, T.c5, 2.4)
            D.text(g, "F", cx + ux * p.F * k + 4, cy + uy * p.F * k - 8, T.c5, bold=True)
        dirn = "沿斜面向上" if f > 1e-6 else "沿斜面向下" if f < -1e-6 else "为零"
        out.set([["重力 G", fmt(st["G"], 2) + " N"], ["G 沿斜面分力", fmt(st["Gp"], 2) + " N"], ["支持力 N", fmt(st["N"], 2) + " N"],
                 ["摩擦力", f"{fmt(abs(f), 2)} N（{st['kind']}，{dirn}）"], ["加速度 a", fmt(st["a"], 3) + " m/s²"], ["速度 v", fmt(S["vel"], 3) + " m/s"],
                 ["tan θ 与 μ", f"{fmt(math.tan(th), 3)} {'≤' if math.tan(th) <= p.mu else '>'} {fmt(p.mu, 2)}"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 超重与失重
@lab.reg(id="p-elev", subj="phys", book=0, unit="运动和力的关系", title="电梯里的超重与失重", kw="超重 失重 完全失重 视重",
         info="<p>人站在电梯里的体重秤上，秤的示数等于秤对人的支持力 N（视重）。取竖直向上为正：</p><p class='fb'>N − mg = ma ⇒ N = m(g + a)</p>"
              "<p>a 向上（加速上升或减速下降）时 N &gt; mg，<b>超重</b>；a 向下（加速下降或减速上升）时 N &lt; mg，<b>失重</b>；a = −g 时 N = 0，<b>完全失重</b>。"
              "超重失重只与加速度方向有关，与速度方向无关。</p>",
         tasks=["比较「加速上升」与「减速下降」两种情况的示数。", "选「自由下落」，示数为多少？此时人对秤还有压力吗？"])
def p_elev(L):
    c = L.canvas()
    S = {"a": 0.0, "v": 0.0, "y": 0.0, "hist": [], "t": 0.0}
    m = L.slider("人的质量 m", 30, 90, 1, 60, None, "kg")
    L.group("电梯状态")

    def pick(k):
        S["a"] = float(k.rstrip("d"))
        if k == "-2d" and S["v"] > 0:
            S["v"] = 0.0
        if k == "2d" and S["v"] >= 0:
            S["v"] = -3.0
        if k == "2" and S["v"] < 0:
            S["v"] = 0.0
        if k == "-2" and S["v"] <= 0:
            S["v"] = 3.0
    st = L.seg("", [["0", "静止/匀速"], ["2", "加速上升"], ["-2", "减速上升"], ["-2d", "加速下降"], ["2d", "减速下降"], ["-9.8", "自由下落"]], "0", pick)
    out = L.out()

    def tick(dt):
        S["t"] += dt
        S["v"] += S["a"] * dt
        if (st.v == "2d" and S["v"] >= 0) or (st.v == "-2" and S["v"] <= 0):
            S["v"], S["a"] = 0.0, 0.0
            st.set("0", True)
        S["y"] += S["v"] * dt
        S["hist"].append((S["t"], m.v * (9.8 + S["a"])))
        if len(S["hist"]) > 400:
            S["hist"].pop(0)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        a, vv, y, hist, t = S["a"], S["v"], S["y"], S["hist"], S["t"]
        ex, ew, eh = 60, 140, 200
        ey = c.h / 2 - eh / 2
        for k in range(-2, 12):
            yy = ((k * 60 + y * 30) % (c.h + 120) + c.h + 120) % (c.h + 120) - 60
            D.line(g, ex - 20, yy, ex - 8, yy, T.grid2, 2)
            D.line(g, ex + ew + 8, yy, ex + ew + 20, yy, T.grid2, 2)
        D.rect(g, ex, ey, ew, eh, alpha(T.muted, 0.08), T.fg, 2)
        D.rect(g, ex + 40, ey + eh - 16, 60, 10, T.c4)
        N = m.v * (9.8 + a)
        D.text(g, fmt(N / 9.8, 1) + " kg", ex + 70, ey + eh + 14, T.c4, align="center", mono=True, bold=True)
        px, py = ex + 70, ey + eh - 16
        D.circle(g, px, py - 92, 12, None, T.fg, 2)
        D.line(g, px, py - 80, px, py - 40, T.fg, 2)
        D.line(g, px, py - 40, px - 12, py, T.fg, 2)
        D.line(g, px, py - 40, px + 12, py, T.fg, 2)
        D.line(g, px - 18, py - 66, px + 18, py - 66, T.fg, 2)
        D.arrow(g, ex + ew + 40, c.h / 2, ex + ew + 40, c.h / 2 - vv * 18, T.c2, 2.6)
        D.text(g, "v", ex + ew + 48, c.h / 2 - vv * 18, T.c2)
        D.arrow(g, ex + ew + 70, c.h / 2, ex + ew + 70, c.h / 2 - a * 8, T.c3, 2.6)
        D.text(g, "a", ex + ew + 78, c.h / 2 - a * 8, T.c3)
        cx0 = ex + ew + 110
        if c.w - cx0 > 120:
            ch = D.chart(g, cx0, 30, c.w - cx0 - 20, c.h - 70, [{"pts": hist, "color": T.c1, "w": 2}], title="体重秤示数 N（牛）", xl="t",
                         ymin=0, ymax=m.v * 9.8 * 2, xmin=hist[0][0] if hist else 0, xmax=max(t, (hist[0][0] if hist else 0) + 1e-6))
            yg = ch["Y"](m.v * 9.8)
            D.line(g, cx0, yg, c.w - 20, yg, T.muted, 1, [5, 4])
            D.text(g, "mg", c.w - 24, yg - 8, T.muted, align="right")
        s = "完全失重" if abs(a + 9.8) < 1e-6 else "超重" if a > 1e-6 else "失重" if a < -1e-6 else "正常"
        out.set([["加速度 a", fmt(a, 2) + " m/s²"], ["速度 v", fmt(vv, 2) + " m/s"], ["重力 mg", fmt(m.v * 9.8, 1) + " N"],
                 ["支持力 N（视重）", fmt(N, 1) + " N"], ["状态", s]])
    L.on_draw(draw)
