"""化学 · 必修第一册（由 gewu/chem.js 改写）：周期表、方程式配平、焰色试验、溶液导电性。"""
from __future__ import annotations

import math
import re

from ...design.tokens import T, alpha
from ...kit.chem import BY, CAT, EL, GROUPS, FormulaError, balance, block_of, el_cat, el_config, el_pos, molar_mass, pretty, supn
from ...kit.core import PI, clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab
from .phys1 import battery, wire


# ---------------------------------------------------------------- 元素周期表与原子结构
@lab.reg(id="c-ptable", subj="chem", book=0, unit="物质结构 元素周期律", title="元素周期表与原子结构",
         kw="元素周期律 电子排布 轨道表示式 原子结构示意图 电负性 电离能 构造原理 价电子",
         info="<p>点击任一元素，下方显示它的原子结构示意图、电子排布式和（前 36 号元素的）轨道表示式。切换着色方式观察元素性质的周期性变化。</p>"
              "<p class='fb'>构造原理：1s 2s 2p 3s 3p 4s 3d 4p 5s 4d 5p 6s 4f 5d 6p …<br>泡利原理：一个轨道最多容纳 2 个自旋相反的电子　洪特规则：电子优先分占不同轨道且自旋平行<br>"
              "半满、全满更稳定：Cr 3d⁵4s¹，Cu 3d¹⁰4s¹</p><p><b>周期律</b>：同周期从左到右，原子半径减小，金属性减弱、非金属性增强，电负性增大；第一电离能总体增大，"
              "但 ⅡA &gt; ⅢA、ⅤA &gt; ⅥA（如 Be &gt; B，N &gt; O）。同主族从上到下，金属性增强，电负性和第一电离能减小。</p>",
         tasks=["用「第一电离能」着色，找出第二、三周期中两处「反常」，并用电子排布解释。", "比较 K（19）与 Cr（24）、Cu（29）的电子排布，哪两个不符合构造原理的简单填充？",
                "用「电负性」着色，找出电负性最大的元素和最小的（非放射性）元素。"])
def c_ptable(L):
    c = L.canvas()
    L.tall()
    S = {"sel": 26, "cells": []}
    color = L.select("着色方式", [["cat", "元素分类"], ["en", "电负性"], ["ie", "第一电离能（1~56 号）"], ["m", "相对原子质量"], ["blk", "分区（s p d f）"]], "cat")
    L.legend([[T[v[1]], v[0]] for k, v in CAT.items() if k != "nonmetal"])
    out = L.out()

    def click(x, y, _o):
        h = next((q for q in S["cells"] if q[1] <= x < q[1] + q[3] and q[2] <= y < q[2] + q[3]), None)
        if h:
            S["sel"] = h[0]
    L.interact(c, click=click)

    def draw():
        c.clear()
        g = c.g
        cell = min((c.w - 30) / 18.3, (c.h * 0.6) / 10.4)
        ox, oy = (c.w - cell * 18) / 2 + 6, 18
        cells = S["cells"] = []
        mode, sel = color.v, S["sel"]
        for e in EL:
            r, col = el_pos(e.z)
            x = ox + col * cell
            y = oy + r * cell + (cell * 0.35 if r >= 8 else 0)
            if mode == "cat":
                k = el_cat(e.z)
                fill = alpha(T[CAT[k][1]], 0.18 if k == "nonmetal" else 0.45)
            elif mode == "en":
                fill = alpha(T.c2, 0.08 + (e.en - 0.7) / 3.3 * 0.85) if e.en else alpha(T.muted, 0.08)
            elif mode == "ie":
                fill = alpha(T.c1, 0.08 + (e.ie - 370) / 2000 * 0.9) if e.ie else alpha(T.muted, 0.06)
            elif mode == "m":
                fill = alpha(T.c3, 0.08 + e.m / 300 * 0.85)
            else:
                fill = alpha(T[{"s": "c2", "p": "c4", "d": "c1", "f": "c3"}[block_of(e.z)]], 0.4)
            D.rect(g, x + 1, y + 1, cell - 2, cell - 2, fill, T.fg if e.z == sel else None, 2)
            if cell > 22:
                D.text(g, e.z, x + 3, y + 7, T.muted, size=max(7, cell * 0.2), mono=True)
                D.text(g, e.s, x + cell / 2, y + cell * 0.5, T.fg, align="center", bold=True, size=cell * 0.34)
                if cell > 34:
                    D.text(g, e.n, x + cell / 2, y + cell * 0.8, T.muted, align="center", size=cell * 0.2)
            else:
                D.text(g, e.s, x + cell / 2, y + cell / 2, T.fg, align="center", size=cell * 0.4)
            cells.append((e.z, x, y, cell))
        for r, t in ((5, "57-71"), (6, "89-103")):
            x, y = ox + 2 * cell, oy + r * cell
            D.rect(g, x + 1, y + 1, cell - 2, cell - 2, alpha(T.muted, 0.1))
            D.text(g, t, x + cell / 2, y + cell / 2, T.muted, align="center", size=max(7, cell * 0.2))
        if cell > 18:
            for i, gn in enumerate(GROUPS):
                D.text(g, gn, ox + i * cell + cell / 2, oy - 8, T.muted, align="center", size=max(8, cell * 0.22))
            for r in range(7):
                D.text(g, r + 1, ox - 8, oy + r * cell + cell / 2, T.muted, align="center", size=10)
        D.text(g, "镧系", ox + 1.6 * cell, oy + 8.35 * cell + cell / 2, T.muted, align="right", size=10)
        D.text(g, "锕系", ox + 1.6 * cell, oy + 9.35 * cell + cell / 2, T.muted, align="right", size=10)
        e = EL[sel - 1]
        cfg = el_config(sel)
        r, col = el_pos(sel)
        period = r - 2 if r >= 8 else r + 1
        shells: list = []
        for k, v in cfg:
            n = int(k[0])
            while len(shells) < n:
                shells.append(0)
            shells[n - 1] += v
        by0 = oy + 10.6 * cell + 10
        bh = c.h - by0 - 10
        cfg_str = "".join(k + supn(v) for k, v in cfg)
        if bh > 80:
            R0 = min(26, bh * 0.2)
            cx, cy = 30 + R0, by0 + bh / 2
            D.circle(g, cx, cy, R0, alpha(T.c2, 0.15), T.fg, 1.5)
            D.text(g, f"+{sel}", cx, cy, T.fg, align="center", bold=True, size=13)
            for i, n in enumerate(shells):
                x = cx + R0 + 22 + i * 30
                g.stroke_style, g.line_width = T.fg, 1.4
                g.begin_path()
                g.arc(x - 40, cy, 44, -0.45, 0.45)
                g.stroke()
                D.text(g, n, x + 6, cy, T.fg, align="center", size=13, mono=True)
            D.text(g, "原子结构示意图", 20, by0 + 8, T.muted, size=11)
            ox2 = cx + R0 + 40 + len(shells) * 30 + 20
            if sel <= 36 and c.w - ox2 > 200:
                D.text(g, "轨道表示式", ox2, by0 + 8, T.muted, size=11)
                x = ox2
                bs = min(20, (c.w - ox2 - 20) / 26)
                yb = cy - bs / 2
                for k, v in cfg:
                    nb = 2 * "spdf".index(k[1]) + 1
                    for b in range(nb):
                        D.rect(g, x + b * bs, yb, bs, bs, None, T.fg, 1)
                        if v > b:
                            D.arrow(g, x + b * bs + bs * 0.35, yb + bs - 3, x + b * bs + bs * 0.35, yb + 3, T.c2, 1.4, 5)
                        if v > nb + b:
                            D.arrow(g, x + b * bs + bs * 0.65, yb + 3, x + b * bs + bs * 0.65, yb + bs - 3, T.c1, 1.4, 5)
                    D.text(g, k, x + nb * bs / 2, yb + bs + 12, T.muted, align="center", size=11)
                    x += nb * bs + 8
            else:
                D.text(g, cfg_str, ox2, cy, T.fg, size=14, mono=True)
        nobles = [n for n in (2, 10, 18, 36, 54, 86) if n < sel]
        noble = nobles[-1] if nobles else None
        if noble:
            core_cfg = dict(el_config(noble))
            short = f"[{EL[noble - 1].s}]" + "".join(k + supn(v) for k, v in cfg if core_cfg.get(k) != v)
        else:
            short = cfg_str
        grp = ("ⅢB（" + ("镧系" if r == 8 else "锕系") + "）") if r >= 8 else GROUPS[col]
        mass = f"({e.m})" if sel in (43, 61) or sel >= 84 else f"{e.m}"
        out.set([[f"{e.n} {e.s}", f"Z = {sel}"], ["相对原子质量", mass], ["位置", f"第 {period} 周期 {grp} 族"], ["分区", block_of(sel) + " 区"],
                 ["类别", CAT[el_cat(sel)][0]], ["电子排布式", cfg_str], ["简化排布式", short], ["各层电子数", ", ".join(str(x) for x in shells)],
                 ["电负性", f"{e.en}" if e.en else "—"], ["第一电离能", f"{e.ie} kJ/mol" if e.ie else "—"]])
    L.on_draw(draw)


def split_plus(side: str) -> list[str]:
    """「+」既是分隔符也可能是离子电荷；带 ^ 的电荷不拆。"""
    out, cur = [], ""
    for i, ch in enumerate(side):
        if ch == "+" and (i == 0 or side[i - 1] != "^") and not re.search(r"\^\d*$", cur.strip()):
            if cur.strip():
                out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def is_electron(f: str) -> bool:
    return bool(re.fullmatch(r"e\^?-?", f))


# ---------------------------------------------------------------- 方程式配平与计量计算
@lab.reg(id="c-eq", subj="chem", book=0, unit="物质的量 · 化学方程式", title="化学方程式配平与计量计算", kw="配平 摩尔质量 物质的量 质量守恒 离子方程式 化学计量数",
         info="<p>用 <span class='f'>=</span> 或 <span class='f'>-&gt;</span> 分隔反应物和生成物，用 <span class='f'>+</span> 分隔各物质。支持括号 <span class='f'>Ca(OH)2</span>、"
              "结晶水 <span class='f'>CuSO4·5H2O</span>（也可写 <span class='f'>CuSO4.5H2O</span>）以及离子 <span class='f'>Fe^3+</span>、<span class='f'>MnO4^-</span>、电子 <span class='f'>e</span>。</p>"
              "<p class='fb'>配平依据：反应前后各元素原子个数守恒（离子方程式还要电荷守恒）<br>n = m/M　N = n·N_A　V = n·V_m（标准状况 V_m = 22.4 L/mol）<br>各物质的物质的量之比 = 化学计量数之比</p>",
         tasks=["配平 KMnO4 + HCl = KCl + MnCl2 + Cl2 + H2O，并计算 15.8 g KMnO4 能生成多少升 Cl₂（标况）。",
                "写出离子方程式 MnO4^- + Fe^2+ + H^+ = Mn^2+ + Fe^3+ + H2O 并配平。", "1 mol CuSO4·5H2O 的质量是多少？其中结晶水的质量分数是多少？"])
def c_eq(L):
    c = L.canvas()
    L.group("化学方程式")
    S = {"res": None, "err": ""}

    def run(s, o=None):
        try:
            parts = re.split(r"=+|->|→|⟶", s)
            if len(parts) != 2:
                raise FormulaError("需要一个「=」或「->」分隔两边")
            lhs, rhs = split_plus(parts[0]), split_plus(parts[1])
            res = balance(lhs, rhs)
            res.update(lhs=lhs, rhs=rhs)
            S["res"], S["err"] = res, ""
            (o or inp).err("")
            who.set_options([[str(i), f] for i, f in enumerate(lhs + rhs) if not is_electron(f)], "0")
        except FormulaError as exc:
            S["res"], S["err"] = None, str(exc)
            (o or inp).err(str(exc))
        L.draw()
    inp = L.input("", "Fe2O3 + CO = Fe + CO2", run, ph="例：Al + O2 = Al2O3")
    L.select("示例", ["Fe2O3 + CO = Fe + CO2", "KMnO4 + HCl = KCl + MnCl2 + Cl2 + H2O", "Cu + HNO3 = Cu(NO3)2 + NO + H2O", "C6H12O6 + O2 = CO2 + H2O",
                     "MnO4^- + Fe^2+ + H^+ = Mn^2+ + Fe^3+ + H2O", "Na2O2 + H2O = NaOH + O2", "NH3 + O2 = NO + H2O", "Ca(OH)2 + NH4Cl = CaCl2 + NH3 + H2O",
                     "CuSO4.5H2O = CuSO4 + H2O"], "Fe2O3 + CO = Fe + CO2", lambda s: inp.set(s))
    L.group("计量计算")
    who = L.select("已知物质", [["0", "—"]], "0")
    amt = L.slider("已知质量", 0.1, 500, 0.1, 16, None, "g")
    out = L.out()
    run(inp.v)

    def draw():
        c.clear()
        g = c.g
        res = S["res"]
        if not res:
            D.text(g, S["err"] or "请输入方程式", c.w / 2, c.h / 2, T.bad, align="center", size=15)
            out.set([])
            return
        coef, sp, lhs, rhs = res["coef"], res["sp"], res["lhs"], res["rhs"]
        names = lhs + rhs
        n = len(sp)
        W = c.w - 40
        colW, top = W / n, 30
        D.text(g, "反应物", 20, 14, T.muted, size=12)
        D.text(g, "生成物", 20 + colW * len(lhs) + 4, 14, T.muted, size=12)
        for i, s in enumerate(sp):
            x = 20 + i * colW
            D.text(g, (f"{coef[i]} " if coef[i] > 1 else "") + pretty(names[i]), x + colW / 2, top + 6, T.c1 if i < len(lhs) else T.c2, align="center", bold=True, size=13)
            y = top + 30
            atoms = [a for a, m in s["el"].items() for _ in range(min(m, 12))]
            for _k in range(min(coef[i], 8)):
                xx = x + 10
                for j, a in enumerate(atoms):
                    col = T.c[BY[a].z % 6]
                    D.circle(g, xx + (j % 8) * 13, y + (j // 8) * 13, 6, alpha(col, 0.8))
                    if len(atoms) < 10:
                        D.text(g, a, xx + (j % 8) * 13, y + (j // 8) * 13, T.fg, align="center", size=7.5)
                y += 16 + max(0, (len(atoms) - 1) // 8) * 13 + 6
                if y > c.h * 0.62:
                    break
            if coef[i] > 8:
                D.text(g, "…", x + colW / 2, y, T.muted, align="center")
            if i == len(lhs) - 1:
                D.text(g, "→", x + colW, top + 6, T.fg, align="center", size=18)
        ty = c.h * 0.68
        D.line(g, 20, ty - 12, c.w - 20, ty - 12, T.line, 1)
        D.text(g, "原子守恒核对：", 20, ty, T.muted, size=12)
        for i, k in enumerate(res["keys"]):
            def amount(q):
                return q["charge"] if k == "电荷" else q["el"].get(k, 0)
            lsum = sum(coef[j] * amount(q) for j, q in enumerate(sp) if j < len(lhs))
            rsum = sum(coef[j] * amount(q) for j, q in enumerate(sp) if j >= len(lhs))
            D.text(g, f"{k}: {lsum} = {rsum}", 20 + (i % 6) * 110, ty + 22 + (i // 6) * 20, T.ok if lsum == rsum else T.bad, mono=True, size=12)

        def term(i):
            return (str(coef[i]) if coef[i] > 1 else "") + pretty(names[i], html=True)
        eq = " + ".join(term(i) for i in range(len(lhs))) + " ══ " + " + ".join(term(i + len(lhs)) for i in range(len(rhs)))
        k0 = int(who.v or 0)
        M0 = molar_mass(sp[k0]["el"])
        n0 = amt.v / M0 if M0 else 0
        rows = [f"<span style='font-size:15px;color:{T.fg}'>{eq}</span>"]
        for i, f in enumerate(names):
            if is_electron(f):
                continue
            M = molar_mass(sp[i]["el"])
            ni = n0 * coef[i] / coef[k0]
            rows.append([f"{pretty(f, html=True)}　M = {fmt(M, 2)}", f"{fmt(ni, 4)} mol · {fmt(ni * M, 3)} g"])
        rows.append(["标况下气体体积 = n × 22.4", "对气体适用"])
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 焰色试验
@lab.reg(id="c-flame", subj="chem", book=0, unit="海水中的重要元素——钠和氯", title="焰色试验", kw="焰色反应 钠 钾 钴玻璃 金属元素 物理变化",
         info="<p><b>操作</b>：将铂丝（或光洁无锈的铁丝）用盐酸洗净，在外焰上灼烧至与原火焰颜色相同；蘸取试样在外焰上灼烧，观察火焰颜色；每次实验后都要用盐酸洗净铂丝。</p>"
              "<p>焰色试验是元素的性质，属于<b>物理变化</b>：金属原子的电子吸收能量跃迁到高能级，回到低能级时以特定波长的光放出。"
              "观察钾的焰色要透过<b>蓝色钴玻璃</b>，以滤去钠元素杂质的黄光。</p>",
         tasks=["依次观察钠、钾的焰色。为什么观察钾时要用钴玻璃？", "同一种金属的单质和化合物焰色相同吗？", "节日的烟花利用了哪些金属的焰色？"])
def c_flame(L):
    c = L.canvas()
    S = {"none": ["（无试样）", "#7fb3ff", 0], "Li": ["氯化锂 LiCl", "#e8263f", 671], "Na": ["氯化钠 NaCl", "#ffc21a", 589], "K": ["氯化钾 KCl", "#b06cff", 404],
         "Ca": ["氯化钙 CaCl₂", "#ff6a2a", 622], "Sr": ["氯化锶 SrCl₂", "#ff2050", 650], "Ba": ["氯化钡 BaCl₂", "#a6e84a", 524], "Cu": ["氯化铜 CuCl₂", "#2ce39a", 515],
         "KNa": ["含少量 Na 的 KCl", "#ffb84d", 589]}
    s = L.select("试样", [[k, v[0]] for k, v in S.items()], "Na")
    co = L.check("透过蓝色钴玻璃观察", False)
    out = L.out()
    st = {"t": 0.0}

    def tick(dt):
        st["t"] += dt
        L.draw()
    L.loop(tick)
    NAMES = {"none": "淡蓝色（酒精灯/燃气本身）", "Li": "紫红色", "Na": "黄色", "K": "紫色（透过钴玻璃）", "Ca": "砖红色", "Sr": "洋红色", "Ba": "黄绿色", "Cu": "绿色"}

    def draw():
        c.clear()
        g = c.g
        t = st["t"]
        cx, by = c.w / 2, c.h - 60
        D.rect(g, cx - 40, by, 80, 40, alpha(T.muted, 0.4), T.fg, 1.5)
        D.rect(g, cx - 10, by - 30, 20, 30, T.muted)
        col = S[s.v][1]
        if co.v:
            col = "#9a5cff" if s.v in ("K", "KNa") else "#3a3f8a" if s.v == "Na" else "#5a6ad0"

        def flame(sc, cc, a):
            h, w = 220 * sc, 46 * sc
            pts = [(cx - w, by - 30)]
            for i in range(21):
                pts.append((cx - w * math.sin(PI * (1 - i / 20) * 0.9 + 0.1) * (1 + 0.08 * math.sin(t * 9 + i)), by - 30 - h * i / 20))
            for i in range(20, -1, -1):
                pts.append((cx + w * math.sin(PI * (1 - i / 20) * 0.9 + 0.1) * (1 + 0.08 * math.cos(t * 8 + i)), by - 30 - h * i / 20))
            D.poly(g, pts, alpha(cc, a))
        flame(1.0, col, 0.55)
        flame(0.7, col, 0.6)
        flame(0.35, "#a8d0ff", 0.7)
        D.line(g, cx + 140, by - 160, cx + 16, by - 150, T.muted, 2)
        D.circle(g, cx + 14, by - 150, 4, T.fg)
        if co.v:
            D.rect(g, 30, 30, c.w - 60, c.h - 60, "rgba(40,60,200,0.18)", "#3050c0", 2)
            D.text(g, "蓝色钴玻璃", 40, 44, "#3050c0", size=12)
        nm = S[s.v][2]
        name = NAMES.get(s.v) or ("紫色（钠的黄光被滤去）" if co.v else "黄色（钠掩盖了钾的紫色）")
        out.set([["试样", S[s.v][0]], ["焰色", name], ["特征谱线", f"{nm} nm" if nm else "—"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 电解质溶液的导电性
LAMBDA = {"H+": 350, "OH-": 199, "Na+": 50, "Cl-": 76, "K+": 74, "NH4+": 74, "CH3COO-": 41, "Ba2+": 127, "SO42-": 160, "NO3-": 71, "Ag+": 62}


@lab.reg(id="c-conduct", subj="chem", book=0, unit="离子反应", title="电解质溶液的导电性与离子反应", kw="电解质 强电解质 弱电解质 电离 导电能力 离子反应 硫酸 氢氧化钡",
         info="<p>溶液的导电能力取决于自由移动离子的浓度和所带电荷数。相同浓度时，强电解质完全电离，导电能力强；弱电解质（如 CH₃COOH、NH₃·H₂O）部分电离，导电能力弱。</p>"
              "<p class='fb'>Ba²⁺ + 2OH⁻ + 2H⁺ + SO₄²⁻ ══ BaSO₄↓ + 2H₂O</p><p>向 Ba(OH)₂ 溶液中滴加稀硫酸，离子不断结合成沉淀和水，灯泡逐渐变暗，恰好完全反应时几乎熄灭；"
              "继续滴加，H⁺ 和 SO₄²⁻ 过量，灯泡又变亮。</p>",
         tasks=["比较 0.1 mol/L 的盐酸与醋酸，灯泡亮度有何不同？为什么？", "滴定模式下，灯泡最暗时加入了多少毫升硫酸？写出离子方程式。", "把醋酸与氨水混合，导电能力为什么会增强？"])
def c_conduct(L):
    c = L.canvas()
    L.group("模式")
    mode = L.seg("", [["cmp", "比较导电性"], ["tit", "Ba(OH)₂ + H₂SO₄"]], "cmp", lambda m: (G1.setVisible(m == "cmp"), G2.setVisible(m == "tit"), L.draw()))
    G1 = L.group("溶液")
    sols = {"HCl": ["盐酸 HCl", [["H+", 1], ["Cl-", 1]], 1], "HAc": ["醋酸 CH₃COOH", [["H+", 1], ["CH3COO-", 1]], 1.75e-5],
            "NaCl": ["氯化钠 NaCl", [["Na+", 1], ["Cl-", 1]], 1], "NaOH": ["氢氧化钠 NaOH", [["Na+", 1], ["OH-", 1]], 1],
            "NH3": ["氨水 NH₃·H₂O", [["NH4+", 1], ["OH-", 1]], 1.8e-5], "NH4Ac": ["醋酸铵（醋酸与氨水混合）", [["NH4+", 1], ["CH3COO-", 1]], 1],
            "sugar": ["蔗糖溶液", [], 0], "water": ["蒸馏水", [], 0]}
    sol = L.select("", [[k, v[0]] for k, v in sols.items()], "HCl")
    conc = L.slider("浓度", 0.001, 1, 0.001, 0.1, None, "mol/L")
    G2 = L.group("滴定")
    G2.setVisible(False)
    vol = L.slider("加入 0.1 mol/L H₂SO₄ 的体积", 0, 40, 0.1, 0, None, "mL")
    L.note("烧杯中为 20 mL 0.1 mol/L Ba(OH)₂ 溶液。")
    out = L.out()
    st = {"t": 0.0}

    def tick(dt):
        st["t"] += dt
        L.draw()
    L.loop(tick)

    def tit_k(v):
        nB, nA = 0.002, v * 1e-4
        Vt = (20 + v) / 1000
        ex = nB - nA
        if ex > 0:
            return (LAMBDA["Ba2+"] * ex + LAMBDA["OH-"] * 2 * ex) / Vt
        return (LAMBDA["H+"] * -2 * ex + LAMBDA["SO42-"] * -ex) / Vt

    def cond():
        if mode.v == "cmp":
            Sv, cc = sols[sol.v], conc.v
            if not Sv[1]:
                return {"k": 0.0005, "ions": [], "alpha": 0, "ppt": 0}
            Ka = Sv[2]
            a = 1 if Ka >= 1 else (-Ka + math.sqrt(Ka * Ka + 4 * Ka * cc)) / (2 * cc)
            return {"k": sum(LAMBDA[ion] * z * a * cc for ion, z in Sv[1]), "ions": [q[0] for q in Sv[1]], "alpha": a, "ppt": 0}
        nB, nA = 0.002, vol.v * 1e-4
        ex = nB - nA
        ions = ["Ba2+", "OH-"] if ex > 0 else ["H+", "SO42-"]
        return {"k": tit_k(vol.v) + 0.0005, "ions": ions, "alpha": 1, "ppt": min(nA, nB)}

    def draw():
        c.clear()
        g = c.g
        r = cond()
        br = clamp(r["k"] / 40, 0, 1)
        cx, top = c.w * 0.45, 50
        bx, bw = cx - 110, 220
        by, bh = c.h * 0.42, c.h * 0.48
        D.rect(g, bx, by + 20, bw, bh - 20, alpha(T.c1, 0.12))
        D.poly(g, [(bx, by), (bx, by + bh), (bx + bw, by + bh), (bx + bw, by)], None, T.fg, 2, False)
        if r["ppt"]:
            h = r["ppt"] / 0.002 * 30
            D.rect(g, bx + 2, by + bh - h - 2, bw - 4, h, alpha(T.muted, 0.6))
        D.rect(g, bx + 40, by - 20, 10, bh - 10, T.fg)
        D.rect(g, bx + bw - 50, by - 20, 10, bh - 10, T.fg)
        wire(g, [(bx + 45, by - 20), (bx + 45, top), (cx - 20, top)])
        wire(g, [(cx + 20, top), (bx + bw - 45, top), (bx + bw - 45, by - 20)])
        D.circle(g, cx, top, 30 + br * 20, f"rgba(255,210,60,{0.1 + br * 0.6:.3f})")
        D.circle(g, cx, top, 16, f"rgba(255,220,90,{0.25 + br * 0.75:.3f})", T.fg, 1.5)
        battery(g, bx - 40, c.h * 0.3, True, "")
        wire(g, [(bx - 40, c.h * 0.3 - 4), (bx - 40, top), (bx + 45, top)], T.muted, 1)
        ions, t = r["ions"], st["t"]
        if ions:
            for i in range(round(clamp(r["k"], 0, 60))):
                ion = ions[i % len(ions)]
                pos = "+" in ion
                x = bx + 20 + ((i * 53.7 + (1 if pos else -1) * t * 20) % (bw - 40))
                y = by + 40 + (i * 37.3) % (bh - 70)
                D.circle(g, x, y, 6, alpha(T.c2 if pos else T.c1, 0.75))
                D.text(g, "+" if pos else "−", x, y, "#ffffff", align="center", size=9, bold=True)
        if mode.v == "tit" and c.w - (bx + bw) > 200:
            gx = bx + bw + 40
            ch = D.chart(g, gx, 40, c.w - gx - 20, c.h - 100, [{"pts": [(i / 2, tit_k(i / 2)) for i in range(81)], "color": T.c1, "w": 2}], title="导电能力（相对）",
                         xl="V(H₂SO₄) / mL", xmin=0, xmax=40, ymin=0)
            D.circle(g, ch["X"](vol.v), ch["Y"](tit_k(vol.v)), 5, T.c2)
        lamp = "几乎不亮" if br < 0.03 else "较暗" if br < 0.3 else "较亮" if br < 0.7 else "很亮"
        last = ["电离程度 α", fmt(r["alpha"] * 100, 2) + " %"] if mode.v == "cmp" else ["BaSO₄ 沉淀", fmt(r["ppt"] * 233.4 * 1000, 1) + " mg"]
        out.set([["导电能力（相对）", fmt(r["k"], 2)], ["灯泡", lamp], ["自由离子", "、".join(ions) if ions else "几乎没有"], last])
    L.on_draw(draw)
