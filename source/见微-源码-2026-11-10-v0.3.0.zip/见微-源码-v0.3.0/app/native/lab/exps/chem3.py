"""化学 · 选择性必修1 化学反应原理（由 gewu/chem.js 改写）：化学平衡、中和滴定、电离与水解、原电池与电解池。"""
from __future__ import annotations

import math
import time

from ...design.tokens import T, alpha
from ...kit.chem import solve_ph
from ...kit.core import clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab
from .phys1 import battery, flow_dots, wire


# ---------------------------------------------------------------- 化学平衡移动
@lab.reg(id="c-equil", subj="chem", book=2, unit="化学反应速率与化学平衡", title="化学平衡移动（勒夏特列原理）", kw="化学平衡 平衡常数 浓度商 勒夏特列 温度 压强 催化剂 v-t 图",
         info="<p class='fb'>K = Πc(生成物)^ν / Πc(反应物)^ν（纯固体、纯液体不写入，稀溶液中的水也不写入）<br>Q &lt; K 正向移动，Q = K 平衡，Q &gt; K 逆向移动<br>"
              "K 只与温度有关：放热反应升温 K 减小，吸热反应升温 K 增大</p><p><b>勒夏特列原理</b>：改变影响平衡的一个条件（浓度、压强、温度），平衡向能够减弱这种改变的方向移动。"
              "催化剂同等程度地加快正、逆反应，不影响平衡。</p><p>上方图像为各物质浓度随时间的变化，下方为正逆反应速率随时间的变化（v − t 图）。</p>",
         tasks=["合成氨反应中「压缩体积」，正逆反应速率如何突变？平衡向哪个方向移动？", "2NO₂ ⇌ N₂O₄：升温后颜色如何变化？说明该反应是放热还是吸热。",
                "H₂ + I₂ ⇌ 2HI：压缩体积后颜色变深，平衡移动了吗？", "FeCl₃ + KSCN：加入 KSCN 后颜色怎样变化？"])
def c_equil(L):
    c = L.canvas()
    R = {
        "nh3": {"name": "N₂ + 3H₂ ⇌ 2NH₃　ΔH = −92.4 kJ/mol", "sp": [["N₂", -1, 1, None], ["H₂", -3, 3, None], ["NH₃", 2, 0, None]], "gas": True, "dH": -92.4, "K0": 0.05, "T0": 500, "k0": 0.25},
        "no2": {"name": "2NO₂(红棕) ⇌ N₂O₄(无色)　ΔH = −57 kJ/mol", "sp": [["NO₂", -2, 1.2, "#b5501d"], ["N₂O₄", 1, 0.2, None]], "gas": True, "dH": -57, "K0": 2, "T0": 330, "k0": 1.2},
        "hi": {"name": "H₂ + I₂(紫) ⇌ 2HI　ΔH = −9.4 kJ/mol", "sp": [["H₂", -1, 1, None], ["I₂", -1, 1, "#7a2fb0"], ["HI", 2, 0, None]], "gas": True, "dH": -9.4, "K0": 50, "T0": 700, "k0": 0.4},
        "fe": {"name": "Fe³⁺ + 3SCN⁻ ⇌ Fe(SCN)₃(红色)", "sp": [["Fe³⁺", -1, 0.5, "#d8a23a"], ["SCN⁻", -3, 1.0, None], ["Fe(SCN)₃", 1, 0, "#b0101a"]], "gas": False, "dH": 0, "K0": 4, "T0": 298, "k0": 0.6},
        "cr": {"name": "Cr₂O₇²⁻(橙) + H₂O ⇌ 2CrO₄²⁻(黄) + 2H⁺", "sp": [["Cr₂O₇²⁻", -1, 0.3, "#e46b10"], ["CrO₄²⁻", 2, 0.1, "#e8d020"], ["H⁺", 2, 0.1, None]], "gas": False, "dH": 13, "K0": 0.02, "T0": 298, "k0": 1},
    }
    S = {"rx": R["nh3"], "conc": [], "T": 500.0, "hist": [], "vh": [], "t": 0.0, "cat": False}

    def pick(k):
        S["rx"] = R[k]
        reset()
        build()
    L.select("反应", [[k, v["name"]] for k, v in R.items()], "nh3", pick)
    L.group("改变条件")
    sT = L.slider("温度 T", 250, 900, 5, 500, lambda v: S.__setitem__("T", v), "K")
    row = L.button_row()
    L.group("")
    L.check("加入催化剂", False, lambda v: S.__setitem__("cat", v))
    L.button("重新开始", lambda _b: reset(), True)
    out = L.out()

    def build():
        rx = S["rx"]
        row.clear()
        for i, s in enumerate(rx["sp"]):
            def inc(i=i):
                S["conc"][i] += max(0.3, S["conc"][i] * 0.5)
            row.add(f"增大 c({s[0]})", inc)
        for i, s in enumerate(rx["sp"]):
            def dec(i=i):
                S["conc"][i] *= 0.5
            row.add(f"减小 c({s[0]})", dec)
        if rx["gas"]:
            row.add("压缩体积（加压）", lambda: S.__setitem__("conc", [x * 2 for x in S["conc"]]))
            row.add("扩大体积（减压）", lambda: S.__setitem__("conc", [x / 2 for x in S["conc"]]))
        else:
            row.add("加水稀释", lambda: S.__setitem__("conc", [x / 2 for x in S["conc"]]))
        sT.set(rx["T0"], True)
        S["T"] = rx["T0"]

    def reset():
        S.update(conc=[s[2] for s in S["rx"]["sp"]], t=0.0, hist=[], vh=[])

    def K():
        rx = S["rx"]
        return rx["K0"] * math.exp(-rx["dH"] * 1000 / 8.314 * (1 / S["T"] - 1 / rx["T0"]))

    def kf():
        rx = S["rx"]
        return rx["k0"] * math.exp(-50000 / 8.314 * (1 / S["T"] - 1 / rx["T0"])) * (5 if S["cat"] else 1)

    def rates(cc):
        f = kf()
        r = f / K()
        for i, s in enumerate(S["rx"]["sp"]):
            if s[1] < 0:
                f *= max(0.0, cc[i]) ** -s[1]
            else:
                r *= max(0.0, cc[i]) ** s[1]
        return f, r

    def Qc():
        q = 1.0
        for i, s in enumerate(S["rx"]["sp"]):
            q *= max(1e-12, S["conc"][i]) ** s[1]
        return q
    reset()
    build()

    def tick(dt):
        n = 200
        h = dt / n
        sp = S["rx"]["sp"]
        conc = S["conc"]
        for _i in range(n):
            f, r = rates(conc)
            d = (f - r) * h
            for j, s in enumerate(sp):
                if s[1] < 0:
                    d = min(d, conc[j] / -s[1] * 0.5)
                else:
                    d = max(d, -conc[j] / s[1] * 0.5)
            conc = [x + sp[j][1] * d for j, x in enumerate(conc)]
        S["conc"] = conc
        S["t"] += dt
        f, r = rates(conc)
        S["hist"].append((S["t"], *conc))
        S["vh"].append((S["t"], f, r))
        if len(S["hist"]) > 900:
            S["hist"].pop(0)
            S["vh"].pop(0)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        rx, conc, hist, vh, t = S["rx"], S["conc"], S["hist"], S["vh"], S["t"]
        vw = min(200, c.w * 0.3)
        vx, vy, vhh = 20, 40, c.h - 90
        rr = gg = bb = aa = 0.0
        for i, s in enumerate(rx["sp"]):
            if not s[3]:
                continue
            n2 = int(s[3][1:], 16)
            w = clamp(conc[i] / 1.5, 0, 1)
            rr += (n2 >> 16 & 255) * w
            gg += (n2 >> 8 & 255) * w
            bb += (n2 & 255) * w
            aa += w
        fill = f"rgba({int(rr / aa)},{int(gg / aa)},{int(bb / aa)},{clamp(aa, 0, 0.9):.3f})" if aa else alpha(T.c1, 0.05)
        if rx["gas"]:
            D.rect(g, vx, vy, vw, vhh, fill, T.fg, 2)
            D.rect(g, vx, vy - 12, vw, 12, T.muted)
            D.text(g, "密闭容器", vx + vw / 2, vy + vhh + 18, T.muted, align="center", size=12)
        else:
            D.rect(g, vx, vy + 30, vw, vhh - 30, fill)
            D.poly(g, [(vx, vy), (vx, vy + vhh), (vx + vw, vy + vhh), (vx + vw, vy)], None, T.fg, 2, False)
            D.text(g, "试管 / 烧杯", vx + vw / 2, vy + vhh + 18, T.muted, align="center", size=12)
        gx = vx + vw + 50
        gw, gh = c.w - gx - 20, (c.h - 80) / 2
        if gw > 100 and len(hist) > 1:
            ser = [{"pts": [(q[0], q[i + 1]) for q in hist], "color": T.c[i], "w": 2} for i in range(len(rx["sp"]))]
            ymax = max(x for q in hist for x in q[1:]) * 1.1 or 1
            D.chart(g, gx, 30, gw, gh, ser, title="浓度 c − t（mol/L）", xmin=hist[0][0], xmax=t, ymin=0, ymax=ymax)
            for i, s in enumerate(rx["sp"]):
                D.text(g, "■ " + s[0], gx + 8 + i * 80, 30 + gh + 12, T.c[i], size=11)
            vmax = max(max(q[1], q[2]) for q in vh) * 1.1 or 1
            D.chart(g, gx, 60 + gh, gw, gh - 20, [{"pts": [(q[0], q[1]) for q in vh], "color": T.c2, "w": 2}, {"pts": [(q[0], q[2]) for q in vh], "color": T.c1, "w": 2, "dash": [5, 3]}],
                    title="v − t：实线 v 正，虚线 v 逆", xl="t", xmin=vh[0][0], xmax=t, ymin=0, ymax=vmax)
        Q, Kv = Qc(), K()
        st = "已达平衡（Q ≈ K）" if abs(math.log(Q / Kv)) < 0.02 else "Q < K，平衡正向移动" if Q < Kv else "Q > K，平衡逆向移动"
        out.set([["温度", f"{fmt(S['T'], 0)} K"], ["平衡常数 K", fmt(Kv, 4)], ["浓度商 Q", fmt(Q, 4)], ["状态", st]]
                + [[f"c({s[0]})", fmt(conc[i], 4) + " mol/L"] for i, s in enumerate(rx["sp"])])
    L.on_draw(draw)


# ---------------------------------------------------------------- 酸碱中和滴定曲线
@lab.reg(id="c-titr", subj="chem", book=2, unit="水溶液中的离子反应与平衡", title="酸碱中和滴定曲线", kw="中和滴定 pH 突跃 指示剂 酚酞 甲基橙 弱酸 等当点",
         info="<p>pH 由电荷守恒精确求解（考虑水的电离与弱电解质的电离平衡）。</p><p class='fb'>恰好中和：c(酸)V(酸) = c(碱)V(碱)（一元酸碱）<br>"
              "滴定终点附近（±0.1% 即 ±0.02 mL）pH 发生突跃<br>指示剂变色范围：甲基橙 3.1~4.4（红→黄），酚酞 8.2~10.0（无色→粉红），石蕊 5.0~8.0</p>"
              "<p>强碱滴定弱酸，等当点溶液呈碱性，应选酚酞；强酸滴定弱碱，等当点呈酸性，应选甲基橙。石蕊变色不明显，一般不作滴定指示剂。</p>",
         tasks=["NaOH 滴定 HCl，记录 19.98 mL 和 20.02 mL 时的 pH，算出突跃范围。", "换成滴定醋酸，突跃范围怎样变化？等当点 pH 是多少？为什么选酚酞？",
                "把浓度都降为 0.01 mol/L，突跃范围如何变化？"])
def c_titr(L):
    c = L.canvas()
    sys_ = L.select("体系", [["sa", "NaOH 滴定 HCl（强碱滴强酸）"], ["wa", "NaOH 滴定 CH₃COOH（强碱滴弱酸）"], ["sb", "HCl 滴定 NaOH（强酸滴强碱）"],
                           ["wb", "HCl 滴定 NH₃·H₂O（强酸滴弱碱）"]], "sa")
    p = L.params({"ca": ["待测液浓度", 0.01, 0.5, 0.01, 0.1, "mol/L"], "va": ["待测液体积", 10, 40, 1, 20, "mL"], "cb": ["标准液浓度", 0.01, 0.5, 0.01, 0.1, "mol/L"],
                  "V": ["已滴入体积", 0, 50, 0.01, 0, "mL"]})
    ind = L.select("指示剂", [["pp", "酚酞 8.2~10.0"], ["mo", "甲基橙 3.1~4.4"], ["lt", "石蕊 5.0~8.0"]], "pp")
    S = {"auto": False}

    def auto(b):
        S["auto"] = not S["auto"]
        b.setCheckable(True)
        b.setChecked(S["auto"])
    L.button("自动滴定", auto, True)
    L.button("倒回 0", lambda _b: setattr(p, "V", 0))
    out = L.out()
    Kw = 1e-14

    def pH(V):
        ca, va, cb, s = p.ca, p.va, p.cb, sys_.v
        Vt = va + V
        CT, CX = ca * va / Vt, cb * V / Vt
        if s in ("sa", "wa"):
            Ka = 1e8 if s == "sa" else 1.75e-5
            return solve_ph(lambda h: h + CX - Kw / h - CT * Ka / (Ka + h))
        Ka2 = 1e-30 if s == "sb" else Kw / 1.8e-5
        return solve_ph(lambda h: h + CT * h / (h + Ka2) - Kw / h - CX)

    def tick(dt):
        if S["auto"]:
            Veq = p.ca * p.va / p.cb
            sp = 0.6 if abs(p.V - Veq) < 1.5 else 4
            p.s("V").set(min(50, p.V + sp * dt))
            if p.V >= 50:
                S["auto"] = False
    L.loop(tick)

    def ind_color(ph):
        k = ind.v
        if k == "pp":
            return "rgba(255,255,255,0.08)" if ph < 8.2 else f"rgba(230,40,140,{clamp((ph - 8.2) / 1.8, 0, 1) * 0.65:.3f})"
        if k == "mo":
            return "rgba(220,40,40,0.65)" if ph < 3.1 else "rgba(240,190,30,0.6)" if ph > 4.4 else "rgba(240,120,40,0.6)"
        return "rgba(220,40,40,0.55)" if ph < 5 else "rgba(40,80,220,0.55)" if ph > 8 else "rgba(140,60,170,0.55)"

    def draw():
        c.clear()
        g = c.g
        ph = pH(p.V)
        Veq = p.ca * p.va / p.cb
        Vmax = max(40, Veq * 2)
        bx, top = 60, 20
        H5 = c.h * 0.5
        D.rect(g, bx - 8, top, 16, H5, alpha(T.c1, 0.1), T.fg, 1.5)
        lv = clamp(p.V / 50, 0, 1)
        D.rect(g, bx - 7, top + 1 + lv * (H5 - 2), 14, (1 - lv) * (H5 - 2), alpha(T.c1, 0.3))
        for k in range(0, 51, 10):
            D.text(g, k, bx + 12, top + k / 50 * H5, T.muted, size=9, mono=True)
        D.line(g, bx, top + H5, bx, top + H5 + 20, T.fg, 2)
        if S["auto"]:
            D.circle(g, bx, top + H5 + 26 + (time.perf_counter() * 125 % 30), 3, alpha(T.c1, 0.8))
        fy = c.h * 0.62 + 20
        D.poly(g, [(bx - 10, fy), (bx - 10, fy + 30), (bx - 55, c.h - 30), (bx + 55, c.h - 30), (bx + 10, fy + 30), (bx + 10, fy)], None, T.fg, 1.8, False)
        D.poly(g, [(bx - 34, c.h - 70), (bx - 55, c.h - 30), (bx + 55, c.h - 30), (bx + 34, c.h - 70)], ind_color(ph))
        gx = 170
        gw = c.w - gx - 20
        Vs = sorted({Vmax * i / 400 for i in range(401)} | {Veq - 0.4 + i * 0.01 for i in range(81)})
        pts = [(v, pH(v)) for v in Vs if 0 <= v <= Vmax]
        ch = D.chart(g, gx, 20, gw, c.h - 50, [{"pts": pts, "color": T.c1, "w": 2.2}], title="pH − V 曲线", xl="V(标准液) / mL", xmin=0, xmax=Vmax, ymin=0, ymax=14)
        band = {"pp": (8.2, 10, "rgba(230,40,140,0.12)"), "mo": (3.1, 4.4, "rgba(240,120,40,0.15)"), "lt": (5, 8, "rgba(140,60,170,0.12)")}[ind.v]
        D.rect(g, gx, ch["Y"](band[1]), gw, ch["Y"](band[0]) - ch["Y"](band[1]), band[2])
        D.line(g, gx, ch["Y"](7), gx + gw, ch["Y"](7), T.grid2, 1, [3, 3])
        for y in range(2, 13, 2):
            D.text(g, y, gx - 4, ch["Y"](y), T.muted, align="right", size=10, mono=True)
        D.line(g, ch["X"](Veq), 20, ch["X"](Veq), c.h - 30, T.muted, 1, [4, 4])
        D.text(g, "等当点", ch["X"](Veq) + 4, 36, T.muted, size=11)
        D.circle(g, ch["X"](min(p.V, Vmax)), ch["Y"](ph), 5.5, T.c2, T.stage, 1.5)
        lo, hi, pe = pH(Veq * 0.999), pH(Veq * 1.001), pH(Veq)
        ok = band[0] < hi and band[1] > lo
        out.set([["当前 pH", fmt(ph, 2)], ["等当点体积", fmt(Veq, 2) + " mL"], ["等当点 pH", fmt(pe, 2)], ["突跃范围（±0.1%）", f"{fmt(lo, 2)} ~ {fmt(hi, 2)}"],
                 ["指示剂变色是否落在突跃内", "是，适用" if ok else "否，误差较大"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 弱电解质电离与盐类水解
@lab.reg(id="c-ion", subj="chem", book=2, unit="水溶液中的离子反应与平衡", title="弱电解质电离与盐类水解", kw="电离平衡 电离常数 分布系数 盐类水解 pH 缓冲 多元弱酸 电离度",
         info="<p>分布系数 δ 表示某种型体占该物质总浓度的比例。对一元弱酸：</p><p class='fb'>δ(HA) = c(H⁺)/[c(H⁺) + Kₐ]，δ(A⁻) = Kₐ/[c(H⁺) + Kₐ]<br>pH = pKₐ 时 c(HA) = c(A⁻)<br>"
              "弱酸溶液近似 c(H⁺) ≈ √(Kₐc)；稀释促进电离，电离度增大</p><p>强碱弱酸盐（如 CH₃COONa、Na₂CO₃）水解显碱性，强酸弱碱盐（如 NH₄Cl）水解显酸性。"
              "「越弱越水解」：Na₂CO₃ 的碱性强于 NaHCO₃。</p>",
         tasks=["在 CH₃COOH 的分布图中，找到 δ(HA) = δ(A⁻) 的点，对应 pH 等于多少？", "把醋酸浓度从 0.1 降到 0.001 mol/L，pH 和电离度怎样变化？",
                "比较 0.1 mol/L 的 Na₂CO₃ 和 CH₃COONa 溶液 pH，哪个大？用 Kₐ 解释。"])
def c_ion(L):
    c = L.canvas()
    A = {
        "ac": ["醋酸 CH₃COOH", [1.75e-5], ["CH₃COOH", "CH₃COO⁻"], 0, ["CH₃COOH 溶液", "CH₃COONa 溶液"]],
        "co3": ["碳酸 H₂CO₃", [4.5e-7, 4.7e-11], ["H₂CO₃", "HCO₃⁻", "CO₃²⁻"], 0, ["H₂CO₃ 溶液", "Na₂CO₃ 溶液"]],
        "ox": ["草酸 H₂C₂O₄", [5.6e-2, 1.5e-4], ["H₂C₂O₄", "HC₂O₄⁻", "C₂O₄²⁻"], 0, ["H₂C₂O₄ 溶液", "Na₂C₂O₄ 溶液"]],
        "po4": ["磷酸 H₃PO₄", [6.9e-3, 6.2e-8, 4.8e-13], ["H₃PO₄", "H₂PO₄⁻", "HPO₄²⁻", "PO₄³⁻"], 0, ["H₃PO₄ 溶液", "Na₃PO₄ 溶液"]],
        "nh4": ["铵根 NH₄⁺", [5.6e-10], ["NH₄⁺", "NH₃·H₂O"], 1, ["NH₄Cl 溶液", "NH₃·H₂O 溶液"]],
    }
    sel = L.select("弱电解质", [[k, v[0]] for k, v in A.items()], "ac", lambda _v: (sync(), L.draw()))
    form = L.seg("溶质", [["acid", "酸式"], ["salt", "盐 / 碱式"]], "acid")
    lc = L.slider("浓度 lg c", -4, 0, 0.05, -1, None, lambda v: f"{fmt(10 ** v, 4)} mol/L")
    pH0 = L.slider("观察 pH（竖线）", 0, 14, 0.05, 4.76)
    out = L.out()

    def sync():
        a = A[sel.v]
        form.btns["acid"].setText(a[4][0])
        form.btns["salt"].setText(a[4][1])
    sync()

    def delta(h, Ks):
        n = len(Ks)
        terms, prod = [], 1.0
        for i in range(n + 1):
            terms.append(h ** (n - i) * prod)
            prod *= Ks[i] if i < n else 1
        s = sum(terms)
        return [x / s for x in terms]

    def draw():
        c.clear()
        g = c.g
        a = A[sel.v]
        Ks, names, z0 = a[1], a[2], a[3]
        n = len(Ks)
        cc = 10 ** lc.v
        counter = -z0 * cc if form.v == "acid" else (n - z0) * cc
        ph = solve_ph(lambda h: h + counter + sum(cc * x * (z0 - i) for i, x in enumerate(delta(h, Ks))) - 1e-14 / h)
        ser = [{"pts": [(k / 20, delta(10 ** -(k / 20), Ks)[i]) for k in range(281)], "color": T.c[i], "w": 2.4} for i in range(len(names))]
        ch = D.chart(g, 50, 24, c.w - 80, c.h - 120, ser, title="分布系数 δ − pH", xl="pH", xmin=0, xmax=14, ymin=0, ymax=1.05)
        for k in range(0, 15, 2):
            D.text(g, k, ch["X"](k), c.h - 92, T.muted, align="center", size=10, mono=True)
        for K in Ks:
            pk = -math.log10(K)
            D.line(g, ch["X"](pk), ch["Y"](0), ch["X"](pk), ch["Y"](0.5), T.grid2, 1, [3, 3])
            D.text(g, "pKₐ=" + fmt(pk, 2), ch["X"](pk) + 3, ch["Y"](0.52), T.muted, size=10)
        D.line(g, ch["X"](pH0.v), 24, ch["X"](pH0.v), c.h - 96, T.fg, 1.4)
        D.line(g, ch["X"](ph), 24, ch["X"](ph), c.h - 96, T.c2, 2, [6, 3])
        D.text(g, "溶液 pH", ch["X"](ph) + 4, 40, T.c2, size=11)
        for i, nm in enumerate(names):
            D.text(g, "■ " + nm, 54 + i * 110, c.h - 70, T.c[i], size=12)
        d0, ds = delta(10 ** -pH0.v, Ks), delta(10 ** -ph, Ks)
        rows = [["溶液", a[4][0 if form.v == "acid" else 1] + f"（{fmt(cc, 4)} mol/L）"], ["计算 pH", fmt(ph, 3)],
                ["溶液酸碱性", "酸性" if ph < 6.95 else "碱性" if ph > 7.05 else "中性"]]
        if n == 1 and form.v == "acid":
            rows.append(["电离度 α", fmt(ds[1] * 100, 3) + " %"])
        if n == 1 and form.v == "salt":
            rows.append(["水解程度", fmt(ds[0] * 100, 3) + " %"])
        rows += [[f"pH={fmt(pH0.v, 2)} 时 δ({nm})", fmt(d0[i], 4)] for i, nm in enumerate(names)]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 原电池与电解池
@lab.reg(id="c-cell", subj="chem", book=2, unit="化学反应与电能", title="原电池与电解池", kw="原电池 盐桥 电极反应 电解 氯碱工业 电镀 精炼 金属腐蚀 燃料电池 能斯特",
         info="<p><b>原电池</b>：化学能 → 电能。负极发生氧化反应，失电子；电子经外电路流向正极；溶液中阳离子移向正极，阴离子移向负极。</p>"
              "<p><b>电解池</b>：电能 → 化学能。与电源正极相连的是阳极（氧化反应），与负极相连的是阴极（还原反应）；阳离子移向阴极，阴离子移向阳极。</p>"
              "<p class='fb'>铜锌原电池电动势（298 K）：E = 1.10 V − (0.0592/2) lg[c(Zn²⁺)/c(Cu²⁺)]</p>",
         tasks=["铜锌原电池中，盐桥里的 K⁺ 和 Cl⁻ 分别移向哪边？撤去盐桥会怎样？", "电解饱和食盐水时，为什么阴极附近滴入酚酞变红？", "电镀铜时，阳极和阴极分别用什么材料？电解液浓度变化吗？"])
def c_cell(L):
    C = {
        "zncu": {"t": "gal", "name": "铜锌原电池（盐桥）", "two": True, "L": ["Zn", "#9aa3ad", "负极"], "R": ["Cu", "#c87533", "正极"], "solL": ["ZnSO₄", "rgba(200,200,210,0.15)"],
                 "solR": ["CuSO₄", "rgba(40,120,230,0.3)"], "rl": "Zn − 2e⁻ ══ Zn²⁺", "rr": "Cu²⁺ + 2e⁻ ══ Cu", "tot": "Zn + Cu²⁺ ══ Zn²⁺ + Cu",
                 "ionsR": [["Cu²⁺", 1], ["SO₄²⁻", 0]]},
        "fuel": {"t": "gal", "name": "氢氧燃料电池（酸性电解质）", "L": ["H₂ 极", "#8a8a96", "负极"], "R": ["O₂ 极", "#8a8a96", "正极"], "sol": ["稀 H₂SO₄", "rgba(120,200,255,0.15)"],
                 "rl": "2H₂ − 4e⁻ ══ 4H⁺", "rr": "O₂ + 4H⁺ + 4e⁻ ══ 2H₂O", "tot": "2H₂ + O₂ ══ 2H₂O", "ions": [["H⁺", 1]], "gasL": True, "gasR": True, "E": 1.23},
        "rust": {"t": "gal", "name": "钢铁的吸氧腐蚀", "L": ["Fe", "#7a7f86", "负极"], "R": ["C", "#333333", "正极"], "sol": ["中性水膜（溶有 O₂）", "rgba(120,200,255,0.12)"],
                 "rl": "2Fe − 4e⁻ ══ 2Fe²⁺", "rr": "O₂ + 2H₂O + 4e⁻ ══ 4OH⁻", "tot": "2Fe + O₂ + 2H₂O ══ 2Fe(OH)₂", "ions": [["Fe²⁺", 1], ["OH⁻", -1]], "E": 0.85},
        "cucl2": {"t": "ely", "name": "电解 CuCl₂ 溶液（石墨电极）", "L": ["阴极 C", "#333333", "阴极"], "R": ["阳极 C", "#333333", "阳极"], "sol": ["CuCl₂ 溶液", "rgba(40,140,200,0.3)"],
                  "rl": "Cu²⁺ + 2e⁻ ══ Cu", "rr": "2Cl⁻ − 2e⁻ ══ Cl₂↑", "tot": "CuCl₂ ══(电解) Cu + Cl₂↑", "ions": [["Cu²⁺", -1], ["Cl⁻", 1]], "gasR": True, "plateL": "#c87533"},
        "nacl": {"t": "ely", "name": "电解饱和食盐水（氯碱工业）", "L": ["阴极 Fe", "#7a7f86", "阴极"], "R": ["阳极 C", "#333333", "阳极"], "sol": ["饱和 NaCl 溶液（滴有酚酞）", "rgba(200,220,240,0.15)"],
                 "rl": "2H₂O + 2e⁻ ══ H₂↑ + 2OH⁻", "rr": "2Cl⁻ − 2e⁻ ══ Cl₂↑", "tot": "2NaCl + 2H₂O ══(电解) 2NaOH + H₂↑ + Cl₂↑", "ions": [["Na⁺", -1], ["Cl⁻", 1]],
                 "gasL": True, "gasR": True, "pink": True},
        "plate": {"t": "ely", "name": "电镀铜（铁件镀铜）", "L": ["阴极 铁件", "#7a7f86", "阴极"], "R": ["阳极 Cu", "#c87533", "阳极"], "sol": ["CuSO₄ 溶液", "rgba(40,120,230,0.3)"],
                  "rl": "Cu²⁺ + 2e⁻ ══ Cu", "rr": "Cu − 2e⁻ ══ Cu²⁺", "tot": "阳极铜溶解，阴极析出铜，c(Cu²⁺) 基本不变", "ions": [["Cu²⁺", -1], ["SO₄²⁻", 1]], "plateL": "#c87533"},
    }
    c = L.canvas()
    S = {"cf": C["zncu"], "t": 0.0}

    def pick(k):
        S["cf"] = C[k]
        sync()
        L.draw()
    L.select("装置", [[k, v["name"]] for k, v in C.items()], "zncu", pick)
    p = L.params({"zn": ["c(Zn²⁺)", 0.001, 2, 0.001, 1, "mol/L"], "cu": ["c(Cu²⁺)", 0.001, 2, 0.001, 1, "mol/L"], "U": ["外加电压", 1, 12, 0.5, 6, "V"]})
    out = L.out()

    def sync():
        cf = S["cf"]
        for k in ("zn", "cu"):
            p.s(k).el.setVisible(cf is C["zncu"])
        p.s("U").el.setVisible(cf["t"] == "ely")
    sync()

    def tick(dt):
        S["t"] += dt
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        cf, t = S["cf"], S["t"]
        W, top = c.w, 60
        bh = min(c.h - top - 40, 260)
        by = c.h - bh - 30
        E = 1.10 - 0.0296 * math.log10(p.zn / p.cu) if cf is C["zncu"] else cf.get("E") or p.U
        sp = clamp(abs(E) / 1.1, 0.2, 2)
        ew, eh = 16, bh * 0.75
        if cf.get("two"):
            w, gap = min(220, W * 0.32), min(120, W * 0.15)
            x1, x2 = W / 2 - gap / 2 - w, W / 2 + gap / 2
            for x, s in ((x1, cf["solL"]), (x2, cf["solR"])):
                D.rect(g, x, by + 30, w, bh - 30, s[1])
                D.poly(g, [(x, by), (x, by + bh), (x + w, by + bh), (x + w, by)], None, T.fg, 2, False)
                D.text(g, s[0], x + w / 2, by + bh + 16, T.muted, align="center", size=12)
            D.poly(g, [(x1 + w - 30, by + 70), (x1 + w - 30, by + 10), (x2 + 30, by + 10), (x2 + 30, by + 70)], None, T.c4, 14, False)
            D.text(g, "盐桥（KCl）", W / 2, by - 2, T.muted, align="center", size=11)
            k = (t * 30) % (x2 - x1 - w + 60)
            D.text(g, "K⁺→", x1 + w - 30 + k, by + 10, T.c2, size=10, bold=True)
            D.text(g, "←Cl⁻", x2 + 30 - k - 24, by + 10, T.c1, size=10, bold=True)
            lx, rx = x1 + w * 0.35, x2 + w * 0.65
        else:
            w = min(420, W * 0.6)
            x = W / 2 - w / 2
            D.rect(g, x, by + 30, w, bh - 30, cf["sol"][1])
            D.poly(g, [(x, by), (x, by + bh), (x + w, by + bh), (x + w, by)], None, T.fg, 2, False)
            D.text(g, cf["sol"][0], W / 2, by + bh + 16, T.muted, align="center", size=12)
            lx, rx = x + w * 0.25, x + w * 0.75
            if cf.get("pink"):
                grad = g.radial_gradient(lx, by + bh * 0.6, w * 0.25, [(0, "rgba(235,60,150,0.5)"), (1, "rgba(235,60,150,0)")])
                g.fill_style = grad
                g.fill_rect(x, by + 30, w / 2, bh - 30)
            for i, (nm, dirn) in enumerate(cf["ions"]):
                for k in range(6):
                    ph2 = (t * 22 * (dirn or 0.3) + k * 37 + i * 15) % (rx - lx)
                    xx = lx + ph2 if dirn >= 0 else rx - ph2
                    D.text(g, nm, xx, by + 60 + ((k * 41 + i * 27) % (bh - 90)), T.c2 if "+" in nm else T.c1, align="center", size=11, bold=True)
        for x, e, plate in ((lx, cf["L"], cf.get("plateL")), (rx, cf["R"], None)):
            D.rect(g, x - ew / 2, by + bh - eh - 10, ew, eh, e[1])
            if plate:
                D.rect(g, x - ew / 2 - 2, by + bh * 0.45, ew + 4, eh * 0.55, plate)
            D.text(g, e[0], x, by + bh - eh - 22, T.fg, align="center", bold=True, size=12)
            D.text(g, e[2], x, by + bh - eh - 38, T.c1 if ("负" in e[2] or e[2] == "阴极") else T.c2, align="center", size=12)
        if cf.get("gasL"):
            for k in range(8):
                D.circle(g, lx + math.sin(k * 3 + t * 3) * 6, by + bh - 20 - ((t * 50 + k * 30) % (bh - 50)), 3, None, T.muted, 1)
        if cf.get("gasR"):
            for k in range(8):
                D.circle(g, rx + math.sin(k * 2 + t * 3) * 6, by + bh - 20 - ((t * 50 + k * 30) % (bh - 50)), 3, None,
                         T.muted if cf is C["fuel"] else "rgba(170,200,60,0.9)", 1.2)
        wy = 30
        path = [(lx, by + bh - eh - 10), (lx, wy), (rx, wy), (rx, by + bh - eh - 10)]
        wire(g, path)
        mx = (lx + rx) / 2
        gal = cf["t"] == "gal"
        if gal:
            D.circle(g, mx, wy, 16, T.stage, T.fg, 1.5)
            D.text(g, "V", mx, wy, T.fg, align="center", bold=True)
            D.text(g, fmt(E, 3) + " V", mx, wy + 28, T.accent, align="center", mono=True)
        else:
            D.rect(g, mx - 30, wy - 14, 60, 28, T.stage)
            battery(g, mx, wy, False, "", True)
            D.text(g, "−", mx - 16, wy - 18, T.c1, align="center", bold=True)
            D.text(g, "+", mx + 16, wy - 18, T.c2, align="center", bold=True)
            D.text(g, f"电源 {fmt(p.U, 1)} V", mx, wy + 26, T.muted, align="center", size=11)
        flow_dots(g, path if gal else path[::-1], t * 40 * sp, T.c4, 26)
        D.text(g, "e⁻", lx + 20 if gal else rx - 30, wy - 14, T.c4, bold=True)
        if cf.get("two"):
            for i, (nm, _d) in enumerate(cf["ionsR"]):
                for k in range(4):
                    D.text(g, nm, rx - 40 - ((t * 15 + k * 30 + i * 10) % 60), by + 70 + k * 35 + i * 15, T.c2 if "+" in nm else T.c1, size=10, align="center")
        out.set([["装置类型", "原电池（化学能→电能）" if gal else "电解池（电能→化学能）"], [f"{cf['L'][2]}（{cf['L'][0]}）", cf["rl"]],
                 [f"{cf['R'][2]}（{cf['R'][0]}）", cf["rr"]], ["总反应", cf["tot"]], ["电动势", fmt(E, 3) + " V"] if gal else ["外加电压", f"{fmt(p.U, 1)} V"],
                 ["电子流向", f"{cf['L'][2]} → 外电路 → {cf['R'][2]}" if gal else "电源负极 → 阴极；阳极 → 电源正极"]])
    L.on_draw(draw)
