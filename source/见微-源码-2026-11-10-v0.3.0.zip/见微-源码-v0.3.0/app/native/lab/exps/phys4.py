"""物理 · 选择性必修第一册（由 gewu/phys2.js 改写）：动量、机械振动、机械波、光。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha, qc
from ...kit.core import PI, TAU, clamp, fmt
from ...kit.draw import D, draw_image, rgb_image, wave_css, wave_rgb
from ...kit.registry import lab


# ---------------------------------------------------------------- 一维碰撞
@lab.reg(id="p-collide", subj="phys", book=3, unit="动量守恒定律", title="一维碰撞与动量守恒", kw="动量 冲量 弹性碰撞 非弹性碰撞 恢复系数",
         info="<p class='fb'>p = mv　动量守恒：m₁v₁ + m₂v₂ = m₁v₁′ + m₂v₂′<br>恢复系数 e = (v₂′ − v₁′)/(v₁ − v₂)<br>"
              "弹性碰撞 e = 1，动能守恒：v₁′ = [(m₁−m₂)v₁ + 2m₂v₂]/(m₁+m₂)<br>完全非弹性碰撞 e = 0，碰后共速，动能损失最大</p>",
         tasks=["m₁ = m₂、弹性碰撞、B 静止：碰后两车速度如何？", "大质量车撞小质量静止车（弹性），小车速度最多接近多少？",
                "完全非弹性碰撞中，动能损失占初动能的比例与质量比有什么关系？"])
def p_collide(L):
    c = L.canvas()
    S = {}
    p = L.params({"m1": ["A 质量 m₁", 0.5, 5, 0.1, 2, "kg"], "m2": ["B 质量 m₂", 0.5, 5, 0.1, 1, "kg"], "v1": ["A 初速度 v₁", -4, 6, 0.1, 3, "m/s"],
                  "v2": ["B 初速度 v₂", -4, 4, 0.1, 0, "m/s"], "e": ["恢复系数 e", 0, 1, 0.05, 1]}, lambda _k, _v: reset())

    def setter(e):
        return lambda _b: setattr(p, "e", e)
    L.button("弹性", setter(1))
    L.button("非弹性 e=0.5", setter(0.5))
    L.button("完全非弹性", setter(0))
    L.group("运行")

    def w(m):
        return 0.35 + m ** (1 / 3) * 0.35

    def step(dt):
        s = S
        s["t"] += dt
        s["x1"] += s["u1"] * dt
        s["x2"] += s["u2"] * dt
        if not s["hit"] and s["x2"] - s["x1"] <= (w(p.m1) + w(p.m2)) / 2 and s["u1"] > s["u2"]:
            m1, m2, e = p.m1, p.m2, p.e
            P = m1 * s["u1"] + m2 * s["u2"]
            d = s["u1"] - s["u2"]
            s["u1"], s["u2"] = (P - m2 * e * d) / (m1 + m2), (P + m1 * e * d) / (m1 + m2)
            s["hit"] = True
        if abs(s["x1"]) > 9 and abs(s["x2"]) > 9:
            run.pause()

    def tick(dt):
        step(dt)
        L.draw()
    run = L.loop(tick, False)

    def reset(*_):
        S.update(x1=-2.5, x2=1.0, u1=p.v1, u2=p.v2, hit=False, t=0.0)
        L.draw()
    L.button("开始 / 暂停", lambda _b: run.toggle(), True)
    L.button("重置", lambda _b: (reset(), run.pause()))
    out = L.out()
    reset()

    def draw():
        c.clear()
        g = c.g
        s = S
        sc, cx, ty = c.w / 14, c.w / 2, c.h * 0.32
        D.line(g, 0, ty + 2, c.w, ty + 2, T.axis, 2)
        for x, m, col, n, u in ((s["x1"], p.m1, T.c1, "A", s["u1"]), (s["x2"], p.m2, T.c2, "B", s["u2"])):
            ww = w(m) * sc
            hh = ww * 0.6
            X = cx + x * sc
            D.rrect(g, X - ww / 2, ty - hh, ww, hh, 4, col)
            D.text(g, f"{n}  {fmt(m, 1)}kg", X, ty - hh / 2, "#ffffff", align="center", bold=True, size=12)
            D.arrow(g, X, ty - hh - 14, X + u * 18, ty - hh - 14, col, 2.4)
        m1, m2 = p.m1, p.m2
        pb, pa = [m1 * p.v1, m2 * p.v2], [m1 * s["u1"], m2 * s["u2"]]
        kb, ka = [0.5 * m1 * p.v1 ** 2, 0.5 * m2 * p.v2 ** 2], [0.5 * m1 * s["u1"] ** 2, 0.5 * m2 * s["u2"] ** 2]
        by, bh, bw = c.h * 0.55, c.h * 0.38, 28
        pm = max([1, abs(pb[0] + pb[1])] + [abs(x) for x in pb + pa])
        km = max(1, kb[0] + kb[1])
        for gi, (title, b, a) in enumerate((("动量 p（kg·m/s）", pb, pa), ("动能 Eₖ（J）", kb, ka))):
            gx = c.w * (0.56 if gi else 0.08)
            mx = km if gi else pm
            zero = by + bh if gi else by + bh / 2
            sclv = (bh if gi else bh / 2) / mx * 0.9
            D.text(g, title, gx, by - 10, T.muted, size=12)
            D.line(g, gx - 6, zero, gx + 7 * (bw + 6), zero, T.axis, 1)
            for k, (arr, lb) in enumerate(((b, "碰前"), (a, "碰后"))):
                x0 = gx + k * 3.6 * (bw + 6)
                for j, (val, col) in enumerate(((arr[0], T.c1), (arr[1], T.c2), (arr[0] + arr[1], T.c3))):
                    h = val * sclv
                    D.rect(g, x0 + j * (bw + 4), min(zero, zero - h), bw, abs(h), col)
                D.text(g, lb, x0 + 1.5 * bw, by + bh + 14, T.muted, align="center", size=11)
        D.text(g, "■ A  ■ B  ■ 合计", 12, c.h - 10, T.muted, size=11)
        hit = s["hit"]
        out.set([["碰前总动量", fmt(pb[0] + pb[1], 3)], ["碰后总动量", fmt(pa[0] + pa[1], 3) if hit else "尚未碰撞"],
                 ["碰后 v₁′ , v₂′", f"{fmt(s['u1'], 3)} , {fmt(s['u2'], 3)} m/s" if hit else "—"], ["碰前总动能", fmt(kb[0] + kb[1], 3) + " J"],
                 ["碰后总动能", fmt(ka[0] + ka[1], 3) + " J" if hit else "—"], ["动能损失", fmt(kb[0] + kb[1] - ka[0] - ka[1], 3) + " J" if hit else "—"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 简谐运动、单摆与受迫振动
@lab.reg(id="p-shm", subj="phys", book=3, unit="机械振动", title="简谐运动、单摆与受迫振动", kw="弹簧振子 周期 单摆 阻尼 共振 振动图像",
         info="<p class='fb'>简谐运动 F = −kx，x = A sin(ωt + φ)，弹簧振子 T = 2π√(m/k)<br>单摆（小角度）T = 2π√(l/g)，与振幅、摆球质量无关<br>"
              "受迫振动的频率等于驱动力频率；驱动频率等于固有频率时振幅最大，称为共振</p>"
              "<p>单摆模式按精确方程 θ″ = −(g/l)sin θ 积分，摆角大时实测周期会略大于小角度公式。</p>",
         tasks=["弹簧振子：振幅加倍，周期变吗？质量变为 4 倍呢？", "单摆从 5° 和 60° 释放，比较实测周期与公式值。",
                "受迫振动：慢慢调节驱动频率，在共振曲线上找到峰值；加大阻尼，峰会怎样变化？"])
def p_shm(L):
    c = L.canvas()
    S = {}
    L.group("模式")
    mode = L.seg("", [["spr", "弹簧振子"], ["pen", "单摆"], ["frc", "受迫振动"]], "spr", lambda _m: (sync(), reset()))
    p = L.params({"k": ["劲度系数 k", 5, 100, 1, 20, "N/m"], "m": ["质量 m", 0.1, 4, 0.1, 1, "kg"], "A": ["初始位移 A", 0.05, 0.5, 0.01, 0.3, "m"],
                  "b": ["阻尼系数 b", 0, 3, 0.05, 0, "kg/s"], "l": ["摆长 l", 0.2, 3, 0.05, 1, "m"], "th": ["摆角 θ₀", 1, 80, 1, 10, "°"],
                  "fd": ["驱动频率 f", 0.1, 2, 0.01, 0.5, "Hz"], "F0": ["驱动力幅值 F₀", 0.5, 5, 0.1, 1, "N"]},
                 lambda k, _v: reset() if k not in ("fd", "F0", "b") else L.draw())
    L.button("重新开始", lambda _b: reset(), True)
    out = L.out()

    def sync():
        m = mode.v
        for k in ("k", "m"):
            p.s(k).el.setVisible(m != "pen")
        p.s("A").el.setVisible(m == "spr")
        p.s("l").el.setVisible(m == "pen")
        p.s("th").el.setVisible(m == "pen")
        p.s("fd").el.setVisible(m == "frc")
        p.s("F0").el.setVisible(m == "frc")
        p.s("b").el.setVisible(m != "pen")

    def reset(*_):
        m = mode.v
        S.update(x=p.th * PI / 180 if m == "pen" else p.A if m == "spr" else 0.0, v=0.0, t=0.0, hist=[], cross=[])
        L.draw()
    sync()
    reset()

    def acc(x, v, t):
        m = mode.v
        if m == "pen":
            return -9.8 / p.l * math.sin(x)
        a = (-p.k * x - p.b * v) / p.m
        if m == "frc":
            a += p.F0 / p.m * math.cos(TAU * p.fd * t)
        return a

    def tick(dt):
        n = 20
        h = dt / n
        for _i in range(n):
            x, v, t = S["x"], S["v"], S["t"]
            k1v, k1x = acc(x, v, t), v
            k2v, k2x = acc(x + k1x * h / 2, v + k1v * h / 2, t + h / 2), v + k1v * h / 2
            k3v, k3x = acc(x + k2x * h / 2, v + k2v * h / 2, t + h / 2), v + k2v * h / 2
            k4v, k4x = acc(x + k3x * h, v + k3v * h, t + h), v + k3v * h
            nx = x + (k1x + 2 * k2x + 2 * k3x + k4x) * h / 6
            S["v"] = v + (k1v + 2 * k2v + 2 * k3v + k4v) * h / 6
            if x < 0 <= nx:
                S["cross"].append(t)
            S["x"], S["t"] = nx, t + h
        S["hist"].append((S["t"], S["x"]))
        if len(S["hist"]) > 600:
            S["hist"].pop(0)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        m = mode.v
        top = c.h * 0.48
        s = S
        if m == "pen":
            px, py = c.w / 2, 24
            Lp = min(top - 50, 60 + p.l * 50)
            bx, by = px + Lp * math.sin(s["x"]), py + Lp * math.cos(s["x"])
            D.line(g, px - 50, py, px + 50, py, T.fg, 3)
            D.line(g, px, py, px, py + Lp + 10, T.grid2, 1, [3, 4])
            D.line(g, px, py, bx, by, T.fg, 1.5)
            D.circle(g, bx, by, 12, T.c1, T.fg, 1.2)
            T0 = TAU * math.sqrt(p.l / 9.8)
            cr = s["cross"]
            Tm = (cr[-1] - cr[0]) / (len(cr) - 1) if len(cr) > 1 else math.nan
            ok = math.isfinite(Tm)
            rows = [["摆角 θ", fmt(s["x"] * 180 / PI, 2) + "°"], ["小角度公式 T = 2π√(l/g)", fmt(T0, 4) + " s"],
                    ["实测周期", fmt(Tm, 4) + " s" if ok else "测量中…"], ["偏差", fmt((Tm / T0 - 1) * 100, 2) + " %" if ok else "—"]]
        else:
            wx, cx = 40, c.w / 2
            sc = (c.w / 2 - 80) / 0.6
            bx, by = cx + s["x"] * sc, top * 0.6
            D.rect(g, wx - 10, by - 40, 10, 60, alpha(T.muted, 0.4))
            D.line(g, wx, by + 22, c.w - 20, by + 22, T.axis, 1.5)
            D.spring(g, wx, by, bx - 22, by, 14, 10, T.fg, 1.5)
            D.rrect(g, bx - 22, by - 20, 44, 40, 4, T.c1)
            D.line(g, cx, by - 30, cx, by + 30, T.grid2, 1, [3, 3])
            D.text(g, "O", cx, by + 38, T.muted, align="center")
            if m == "frc":
                F = p.F0 * math.cos(TAU * p.fd * s["t"])
                D.arrow(g, bx, by - 30, bx + F * 20, by - 30, T.c2, 2.2)
                D.text(g, "驱动力", bx + 26, by - 42, T.c2, size=11)
            w0 = math.sqrt(p.k / p.m)
            T0 = TAU / w0
            rows = [["位移 x", fmt(s["x"], 3) + " m"], ["速度 v", fmt(s["v"], 3) + " m/s"], ["回复力 −kx", fmt(-p.k * s["x"], 3) + " N"],
                    ["固有周期 2π√(m/k)", fmt(T0, 4) + " s"], ["固有频率", fmt(1 / T0, 4) + " Hz"],
                    ["机械能", fmt(0.5 * p.k * s["x"] ** 2 + 0.5 * p.m * s["v"] ** 2, 4) + " J"]]
            if m == "frc":
                def amp(f):
                    ww = TAU * f
                    return p.F0 / p.m / math.sqrt((w0 * w0 - ww * ww) ** 2 + (p.b * ww / p.m) ** 2 + 1e-12)
                fs = [0.1 + i * 0.0095 for i in range(200)]
                ch = D.chart(g, c.w / 2 + 30, top + 20, c.w / 2 - 50, c.h - top - 50, [{"pts": [(f, min(amp(f), 2)) for f in fs], "color": T.c3, "w": 2}],
                             title="共振曲线 A − f", xl="f / Hz", xmin=0.1, xmax=2, ymin=0)
                D.circle(g, ch["X"](p.fd), ch["Y"](min(amp(p.fd), 2)), 5, T.c2)
                D.line(g, ch["X"](1 / T0), top + 20, ch["X"](1 / T0), c.h - 30, T.muted, 1, [4, 4])
                rows += [["驱动频率", fmt(p.fd, 3) + " Hz"], ["稳态振幅（理论）", fmt(amp(p.fd), 4) + " m"]]
        hw = c.w / 2 - 50 if m == "frc" else c.w - 70
        hist = s["hist"]
        if len(hist) > 1:
            ym = max(max(abs(q[1]) for q in hist), 0.01) * 1.1
            D.chart(g, 40, top + 20, hw, c.h - top - 50, [{"pts": hist, "color": T.c1, "w": 2}], title="振动图像 θ − t（rad）" if m == "pen" else "振动图像 x − t（m）",
                    xl="t / s", xmin=hist[0][0], xmax=max(hist[0][0] + 1, s["t"]), ymin=-ym, ymax=ym)
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 机械波
@lab.reg(id="p-wave", subj="phys", book=3, unit="机械波", title="机械波：传播、干涉与多普勒效应", kw="横波 波长 频率 波速 驻波 干涉 多普勒 波动图像 振动图像",
         info="<p class='fb'>v = λf = λ/T　质点只在平衡位置附近振动，不随波迁移<br>两列相干波叠加：路程差 Δr = nλ 处振动加强，Δr = (n+½)λ 处减弱<br>"
              "多普勒效应：波源靠近观察者时接收频率 f′ = fv/(v − vₛ) 变高，远离时变低</p>"
              "<p>横波模式中，红点是选中的质点，下方是它的振动图像（y − t），上方是某一时刻的波动图像（y − x）。注意区分这两种图像。</p>",
         tasks=["横波模式：用「同侧法」判断选中质点此刻的速度方向，再观察验证。", "驻波模式：相邻两个波节之间的距离是多少个波长？",
                "干涉模式：增大两波源间距，减弱区（暗线）条数如何变化？", "多普勒模式：让波源速度超过波速，会出现什么？"])
def p_wave(L):
    c = L.canvas()
    S = {"t": 0.0, "fronts": [], "hist": [], "last": 0.0}

    def restart(*_):
        S.update(t=0.0, fronts=[], hist=[], last=0.0)
        L.draw()
    L.group("模式")
    mode = L.seg("", [["tr", "横波"], ["st", "驻波"], ["in", "干涉"], ["dp", "多普勒"]], "tr", lambda _m: (sync(), restart()))
    p = L.params({"A": ["振幅 A", 5, 40, 1, 20, "cm"], "lam": ["波长 λ", 40, 300, 5, 160, "px"], "f": ["频率 f", 0.1, 2, 0.05, 0.5, "Hz"],
                  "idx": ["选中质点位置", 0, 1, 0.01, 0.35], "d": ["两波源间距", 20, 300, 5, 120, "px"], "vs": ["波源速度 / 波速", 0, 1.5, 0.05, 0.5]})

    def tick(dt):
        S["t"] += dt
        L.draw()
    run = L.loop(tick)
    L.button("暂停 / 继续", lambda _b: run.toggle())
    L.button("从头开始", restart)
    out = L.out()

    def sync():
        m = mode.v
        p.s("idx").el.setVisible(m == "tr")
        p.s("d").el.setVisible(m == "in")
        p.s("vs").el.setVisible(m == "dp")
        p.s("A").el.setVisible(m not in ("in", "dp"))
    sync()

    def draw():
        c.clear()
        g = c.g
        m, t = mode.v, S["t"]
        w, k = TAU * p.f, TAU / p.lam
        v, A = p.lam * p.f, p.A
        rows = [["波长 λ", f"{fmt(p.lam, 0)} px"], ["周期 T", fmt(1 / p.f, 3) + " s"], ["波速 v = λf", fmt(v, 1) + " px/s"]]
        if m in ("tr", "st"):
            y0, x0, x1 = c.h * 0.36, 30, c.w - 30
            n = int((x1 - x0) // 8)
            D.line(g, x0, y0, x1, y0, T.grid2, 1, [4, 4])

            def Y(x, tt=t):
                xx = x - x0
                if m == "tr":
                    return 0.0 if xx > v * tt else A * math.sin(w * tt - k * xx)
                return 2 * A * math.sin(k * xx) * math.cos(w * tt)
            xs = [x0 + i * 2 for i in range(int((x1 - x0) // 2) + 1)]
            if m == "st":
                for sg in (1, -1):
                    D.poly(g, [(x, y0 - sg * 2 * A * math.sin(k * (x - x0))) for x in xs], None, alpha(T.c3, 0.5), 1, False)
            D.poly(g, [(x, y0 - Y(x)) for x in xs], None, T.c1, 2, False)
            for i in range(n + 1):
                x = x0 + i * 8
                D.circle(g, x, y0 - Y(x), 2.4, T.fg)
            if m == "tr":
                sx = x0 + p.idx * (x1 - x0)
                sy = Y(sx)
                vy = (sy - Y(sx, t - 0.01)) / 0.01
                D.circle(g, sx, y0 - sy, 6, T.c2, T.stage, 2)
                if abs(vy) > 1:
                    D.arrow(g, sx + 14, y0 - sy, sx + 14, y0 - sy - math.copysign(22, vy), T.c2, 2)
                D.arrow(g, x1 - 80, y0 - A - 30, x1 - 20, y0 - A - 30, T.muted, 1.6)
                D.text(g, "传播方向", x1 - 80, y0 - A - 44, T.muted, size=11)
                hist = S["hist"]
                hist.append((t, sy))
                while hist and hist[0][0] < t - 3 / p.f:
                    hist.pop(0)
                D.chart(g, 40, c.h * 0.62, c.w - 80, c.h * 0.32, [{"pts": hist, "color": T.c2, "w": 2}], title="选中质点的振动图像 y − t", xl="t / s",
                        xmin=max(0, t - 3 / p.f), xmax=max(t, 3 / p.f), ymin=-A * 1.2, ymax=A * 1.2)
                rows += [["选中质点位移", fmt(sy, 1) + " cm"], ["速度方向", "静止 / 最大位移处" if abs(vy) < 1 else "向上" if vy > 0 else "向下"],
                         ["波已传到", fmt(min(v * t, x1 - x0), 0) + " px"]]
            else:
                x = float(x0)
                while x <= x1:
                    D.text(g, "N", x, y0 + 2 * A + 20, T.c3, align="center", bold=True, size=11)
                    D.line(g, x, y0 - 4, x, y0 + 4, T.c3, 2)
                    x += p.lam / 2
                rows += [["波节间距", f"λ/2 = {fmt(p.lam / 2, 1)} px"], ["波腹振幅", f"2A = {fmt(2 * A, 0)} cm"]]
        elif m == "in":
            res = 5
            nx, ny = math.ceil(c.w / res), math.ceil(c.h / res)
            s1, s2 = (c.w * 0.18, c.h / 2 - p.d / 2), (c.w * 0.18, c.h / 2 + p.d / 2)
            b0, hi = qc(T.stage), qc(T.c1)
            base = (b0.red(), b0.green(), b0.blue())
            dif = (hi.red() - base[0], hi.green() - base[1], hi.blue() - base[2])
            buf = bytearray(nx * ny * 3)
            vt, o = v * t, 0
            for j in range(ny):
                y = j * res
                dy1, dy2 = (y - s1[1]) ** 2, (y - s2[1]) ** 2
                for i in range(nx):
                    x = i * res
                    dx = (x - s1[0]) ** 2
                    r1, r2 = math.sqrt(dx + dy1), math.sqrt(dx + dy2)
                    a1 = math.sin(w * t - k * r1) / math.sqrt(1 + r1 / 80) if r1 < vt else 0.0
                    a2 = math.sin(w * t - k * r2) / math.sqrt(1 + r2 / 80) if r2 < vt else 0.0
                    q = (clamp((a1 + a2) * 0.5, -1, 1) + 1) / 2
                    buf[o] = int(base[0] + dif[0] * q)
                    buf[o + 1] = int(base[1] + dif[1] * q)
                    buf[o + 2] = int(base[2] + dif[2] * q)
                    o += 3
            draw_image(g, rgb_image(nx, ny, buf), 0, 0, nx * res, ny * res)
            for s in (s1, s2):
                D.circle(g, s[0], s[1], 5, T.c2, T.stage, 2)
            rows += [["波源间距 d", f"{fmt(p.d, 0)} px = {fmt(p.d / p.lam, 2)}λ"], ["减弱线条数（理论）", str(int(p.d / p.lam + 0.5) * 2)],
                     ["中垂线上", "路程差 0，振动加强"]]
        else:
            vsrc = p.vs * v
            sx = c.w * 0.15 + ((vsrc * t) % (c.w * 0.7))
            sy = c.h / 2
            if t - S["last"] >= 1 / p.f or t < S["last"]:
                S["fronts"].append((sx, sy, t))
                S["last"] = t
            S["fronts"] = [f2 for f2 in S["fronts"] if v * (t - f2[2]) < c.w * 1.5]
            for f2 in S["fronts"]:
                D.circle(g, f2[0], f2[1], v * (t - f2[2]), None, alpha(T.c1, 0.7), 1.4)
            D.circle(g, sx, sy, 7, T.c2, T.stage, 2)
            D.arrow(g, sx, sy - 18, sx + 30, sy - 18, T.c2, 1.8)
            D.text(g, "前方观察者", c.w - 90, sy - 30, T.muted, size=11)
            D.circle(g, c.w - 60, sy, 6, T.c3)
            ff = p.f / (1 - p.vs) if p.vs < 1 else math.inf
            rows += [["波源频率 f", fmt(p.f, 3) + " Hz"], ["前方接收频率", fmt(ff, 3) + " Hz" if math.isfinite(ff) else "超过波速，形成激波"],
                     ["后方接收频率", fmt(p.f / (1 + p.vs), 3) + " Hz"]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 光的折射与全反射
@lab.reg(id="p-refract", subj="phys", book=3, unit="光", title="光的折射与全反射", kw="折射定律 折射率 临界角 全反射 光密 光疏",
         info="<p class='fb'>折射定律 n₁ sin θ₁ = n₂ sin θ₂　n = c/v<br>光从光密介质射向光疏介质（n₁ &gt; n₂），入射角 ≥ 临界角 C 时发生全反射，sin C = n₂/n₁</p>"
              "<p>光线粗细表示能量占比（按菲涅耳公式估算）：入射角越大，反射光越强、折射光越弱；接近临界角时折射光几乎消失。拖动光源可改变入射角。</p>",
         tasks=["从水射向空气，找出临界角，并与 arcsin(1/1.33) 比较。", "从空气射入玻璃，入射角从 0° 增加到 90°，折射角最大能到多少？", "为什么光纤要用折射率较大的内芯？"])
def p_refract(L):
    c = L.canvas()
    media = [["1.00", "空气 1.00"], ["1.33", "水 1.33"], ["1.50", "玻璃 1.50"], ["2.42", "金刚石 2.42"]]
    n1s = L.select("上方介质 n₁（入射）", media, "1.50")
    n2s = L.select("下方介质 n₂", media, "1.00")

    def swap(_b):
        a, b = n1s.v, n2s.v
        n1s.set(b, True)
        n2s.set(a)
    L.button("交换介质", swap)
    th = L.slider("入射角 θ₁", 0, 89, 0.5, 35, None, "°")
    out = L.out()
    L.note("也可以直接拖动光源。")

    def hit(x, y):
        R = min(c.w, c.h) * 0.42
        a = th.v * PI / 180
        return 1 if math.hypot(c.w / 2 - R * math.sin(a) - x, c.h / 2 - R * math.cos(a) - y) < 20 else None

    def drag(_o, x, y, _dx, _dy):
        th.set(clamp(math.atan2(c.w / 2 - x, c.h / 2 - y) * 180 / PI, 0, 89))
    L.interact(c, hit=hit, drag=drag)

    def draw():
        c.clear()
        g = c.g
        cx, cy = c.w / 2, c.h / 2
        R = min(c.w, c.h) * 0.42
        n1, n2 = float(n1s.v), float(n2s.v)
        a = th.v * PI / 180
        D.rect(g, 0, cy, c.w, c.h - cy, alpha(T.c1, 0.06 + (n2 - 1) * 0.1))
        D.rect(g, 0, 0, c.w, cy, alpha(T.c1, 0.06 + (n1 - 1) * 0.1))
        D.line(g, 0, cy, c.w, cy, T.axis, 1.5)
        D.line(g, cx, cy - R - 10, cx, cy + R + 10, T.muted, 1, [5, 4])
        D.text(g, f"n₁ = {n1:g}", 14, 18, T.fg)
        D.text(g, f"n₂ = {n2:g}", 14, cy + 18, T.fg)
        sin2 = n1 * math.sin(a) / n2
        tir = sin2 > 1
        b = None if tir else math.asin(sin2)
        Rf = 1.0
        if not tir:
            ci, ct = math.cos(a), math.cos(b)
            rs = ((n1 * ci - n2 * ct) / (n1 * ci + n2 * ct)) ** 2
            rp = ((n1 * ct - n2 * ci) / (n1 * ct + n2 * ci)) ** 2
            Rf = (rs + rp) / 2
        sx, sy = cx - R * math.sin(a), cy - R * math.cos(a)

        def beam(x1, y1, x2, y2, I):
            D.line(g, x1, y1, x2, y2, alpha(T.c2, 0.25 + 0.75 * I), 1 + 5 * I)
            D.arrow(g, x1 * 0.45 + x2 * 0.55, y1 * 0.45 + y2 * 0.55, x1 * 0.4 + x2 * 0.6, y1 * 0.4 + y2 * 0.6, alpha(T.c2, 0.4 + 0.6 * I), 2, 10)
        beam(sx, sy, cx, cy, 1)
        beam(cx, cy, cx + R * math.sin(a), cy - R * math.cos(a), Rf)
        if not tir:
            beam(cx, cy, cx + R * math.sin(b), cy + R * math.cos(b), 1 - Rf)
        D.circle(g, sx, sy, 9, T.c4, T.fg, 1.2)
        g.stroke_style, g.line_width = T.fg, 1
        g.begin_path()
        g.arc(cx, cy, 40, -PI / 2, -PI / 2 - a, True)
        g.stroke()
        D.text(g, "θ₁", cx - 30 * math.sin(a / 2) - 14, cy - 54, T.fg)
        if not tir:
            g.begin_path()
            g.arc(cx, cy, 40, PI / 2, PI / 2 - b, True)
            g.stroke()
            D.text(g, "θ₂", cx + 30 * math.sin(b / 2) + 4, cy + 56, T.fg)
        C = math.asin(n2 / n1) * 180 / PI if n1 > n2 else None
        out.set([["入射角 θ₁", fmt(th.v, 1) + "°"], ["折射角 θ₂", "无（全反射）" if tir else fmt(b * 180 / PI, 2) + "°"],
                 ["临界角 C", fmt(C, 2) + "°" if C else "光疏→光密，不会全反射"], ["反射光能量占比", fmt(Rf * 100, 1) + " %"],
                 ["介质 1 中光速", fmt(3 / n1, 3) + "×10⁸ m/s"], ["现象", "全反射" if tir else "反射 + 折射"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 双缝干涉与单缝衍射
@lab.reg(id="p-young", subj="phys", book=3, unit="光", title="双缝干涉与单缝衍射", kw="杨氏双缝 条纹间距 衍射 波长 白光",
         info="<p class='fb'>双缝干涉相邻亮（暗）条纹间距 Δx = Lλ/d<br>屏上某点到两缝的路程差 Δr = nλ 为亮纹，(n + ½)λ 为暗纹<br>单缝衍射中央亮纹宽度 ≈ 2Lλ/a，缝越窄衍射越明显</p>"
              "<p>白光模式按 400~700 nm 的各色光叠加：中央亮纹为白色，两侧出现彩色条纹，红光条纹间距最大。</p>",
         tasks=["把波长从紫光调到红光，条纹间距如何变化？", "双缝间距 d 减半，Δx 变为原来几倍？", "单缝模式减小缝宽 a，中央亮纹如何变化？"])
def p_young(L):
    c = L.canvas()
    L.group("模式")
    mode = L.seg("", [["ds", "双缝干涉"], ["ss", "单缝衍射"]], "ds", lambda m: (p.s("d").el.setVisible(m == "ds"), L.draw()))
    p = L.params({"lam": ["波长 λ", 380, 750, 5, 550, "nm"], "d": ["双缝间距 d", 0.1, 1, 0.01, 0.3, "mm"], "a": ["缝宽 a", 0.02, 0.3, 0.005, 0.06, "mm"],
                  "Lm": ["缝到屏距离 L", 0.3, 2, 0.05, 1, "m"]})
    white = L.check("白光", False)
    out = L.out()

    def sinc(u):
        return 1.0 if abs(u) < 1e-9 else math.sin(u) / u
    WHITE = [(nm, wave_rgb(nm)) for nm in range(400, 701, 10)]

    def draw():
        c.clear()
        g = c.g
        ds = mode.v == "ds"
        lam, d, a, Lm = p.lam, p.d, p.a, p.Lm
        span = 20

        def I(x, nm):
            s = x * 1e-3 / Lm
            ll = nm * 1e-9
            beta = PI * a * 1e-3 * s / ll
            env = sinc(beta) ** 2
            return env * math.cos(PI * d * 1e-3 * s / ll) ** 2 if ds else env
        sx, sw, top = c.w * 0.42, 46, 20
        H = int(c.h - 40)
        mx, my = 30, c.h / 2
        D.circle(g, mx, my, 9, "#ffffff" if white.v else wave_css(lam), T.fg, 1)
        D.line(g, mx + 50, top + 20, mx + 50, my - 4, T.fg, 3)
        D.line(g, mx + 50, my + 4, mx + 50, top + H - 20, T.fg, 3)
        bx = mx + 120
        if ds:
            D.line(g, bx, top + 20, bx, my - 14, T.fg, 3)
            D.line(g, bx, my - 8, bx, my + 8, T.fg, 3)
            D.line(g, bx, my + 14, bx, top + H - 20, T.fg, 3)
        D.text(g, "单缝", mx + 50, top + 10, T.muted, align="center", size=11)
        if ds:
            D.text(g, "双缝", bx, top + 10, T.muted, align="center", size=11)
        D.line(g, bx + 8, my, sx - 6, my, T.grid2, 1, [4, 4])
        D.text(g, "L", (bx + sx) / 2, my - 10, T.muted)
        # 屏：一列像素，纵向拉满
        rgb = wave_rgb(lam)
        buf = bytearray(H * 3)
        curve = []
        for j in range(H):
            x = (j / H - 0.5) * 2 * span
            if white.v:
                r = gg = b = 0.0
                qs = 0.0
                for nm, (rr, g2, b2) in WHITE:
                    q = I(x, nm)
                    r, gg, b = r + rr * q, gg + g2 * q, b + b2 * q
                    qs += q
                n = len(WHITE)
                r, gg, b = r / n * 2.6, gg / n * 2.6, b / n * 2.6
                curve.append(qs / n)
            else:
                q = I(x, lam)
                r, gg, b = rgb[0] * q, rgb[1] * q, rgb[2] * q
                curve.append(q)
            buf[j * 3], buf[j * 3 + 1], buf[j * 3 + 2] = int(clamp(r, 0, 1) * 255), int(clamp(gg, 0, 1) * 255), int(clamp(b, 0, 1) * 255)
        draw_image(g, rgb_image(1, H, buf), sx, top, sw, H, smooth=False)
        D.rect(g, sx, top, sw, H, None, T.line, 1)
        gx = sx + sw + 30
        gw = c.w - gx - 20
        D.poly(g, [(gx + q * gw, top + j) for j, q in enumerate(curve)], None, T.fg if white.v else wave_css(lam), 2, False)
        D.line(g, gx, top, gx, top + H, T.axis, 1)
        D.text(g, "光强", gx + gw - 30, top + 10, T.muted, size=11)
        for mm in range(-span, span + 1, 5):
            y = top + (mm / span / 2 + 0.5) * H
            D.line(g, sx - 6, y, sx, y, T.axis, 1)
            D.text(g, str(mm), sx - 8, y, T.muted, align="right", size=10, mono=True)
        D.text(g, "mm", sx - 8, top + H + 12, T.muted, align="right", size=10)
        dx = Lm * lam * 1e-9 / (d * 1e-3) * 1e3
        w0 = 2 * Lm * lam * 1e-9 / (a * 1e-3) * 1e3
        color = "白光" if white.v else "紫" if lam < 450 else "蓝" if lam < 495 else "绿" if lam < 570 else "黄" if lam < 590 else "橙" if lam < 620 else "红"
        if ds:
            out.set([["条纹间距 Δx = Lλ/d", fmt(dx, 3) + " mm"], ["屏上 ±20 mm 内亮纹数", str(2 * int(20 / dx) + 1)],
                     ["单缝包络中央宽度", fmt(w0, 2) + " mm"], ["光的颜色", color]])
        else:
            out.set([["中央亮纹宽度 ≈ 2Lλ/a", fmt(w0, 3) + " mm"], ["缝宽 a / 波长", fmt(a * 1e-3 / (lam * 1e-9), 1)]])
    L.on_draw(draw)
