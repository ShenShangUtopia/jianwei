"""化学 · 选择性必修2 物质结构与性质（由 gewu/chem.js 改写）：价层电子对互斥模型、晶胞与均摊法。"""
from __future__ import annotations

from ...design.tokens import T, alpha
from ...kit.core import fmt
from ...kit.draw import D
from ...kit.mol import CPK, MOLS, mol_viewer
from ...kit.registry import lab
from ...kit.view import Cam3, v3


@lab.reg(id="c-vsepr", subj="chem", book=3, unit="分子结构与性质", title="价层电子对互斥模型与杂化", kw="VSEPR 杂化轨道 sp sp2 sp3 孤电子对 键角 分子极性 空间结构",
         info="<p class='fb'>价层电子对数 = σ 键电子对数 + 中心原子上的孤电子对数<br>孤电子对数 = ½(a − xb)　a：中心原子价电子数（离子要加减电荷），x：配位原子数，"
              "b：配位原子最多能接受的电子数（H 为 1，其余为 8 − 价电子数）</p><p>价层电子对数 2、3、4 对应 VSEPR 模型直线形、平面三角形、四面体形，"
              "中心原子杂化分别为 sp、sp²、sp³。略去孤电子对得到分子的空间结构。孤电子对排斥力较大，使键角减小：CH₄ 109°28′ &gt; NH₃ 107° &gt; H₂O 104.5°。</p>",
         tasks=["依次查看 CH₄、NH₃、H₂O，解释键角为什么依次减小。", "为什么 CO₂ 是非极性分子而 SO₂ 是极性分子？", "计算 NH₄⁺ 和 H₃O⁺ 的孤电子对数，比较它们与 NH₃、H₂O 的结构。"])
def c_vsepr(L):
    mol_viewer(L, MOLS, "h2o")


@lab.reg(id="c-crystal", subj="chem", book=3, unit="晶体结构与性质", title="晶胞与均摊法",
         kw="晶胞 均摊法 配位数 空间利用率 密度 NaCl CsCl 金刚石 干冰 金属晶体 体心立方 面心立方",
         info="<p><b>均摊法</b>：立方晶胞中，顶点原子为 8 个晶胞共有，计 1/8；棱上 1/4；面上 1/2；体内 1。</p>"
              "<p class='fb'>晶体密度 ρ = N·M / (N_A·a³)　N 为晶胞中粒子（或「化学式」）数<br>简单立方：配位数 6，空间利用率 52%<br>体心立方：配位数 8，68%　面心立方（最密堆积）：配位数 12，74%</p>"
              "<p>颜色区分位置：顶点、棱心、面心、体内。勾选「2×2×2」可以看到晶胞如何在空间无隙并置。</p>",
         tasks=["数一数 NaCl 晶胞中 Na⁺ 和 Cl⁻ 各有几个，与化学式比较。", "金刚石晶胞中有几个碳原子？每个碳原子的配位数是多少？", "已知铜的晶胞参数 a = 361.5 pm，验证密度约为 8.93 g/cm³。"])
def c_crystal(L):
    c = L.canvas()
    cam = Cam3(yaw=-0.55, pitch=0.4, persp=0.06)
    L.orbit(c, cam)
    X = {
        "sc": {"name": "简单立方（钋 Po）", "a": 336, "M": 209, "sites": [["Po", "corner"]], "cn": 6, "pf": "52%", "f": "Po"},
        "bcc": {"name": "体心立方（Na、K、Fe）", "a": 286.6, "M": 55.85, "sites": [["Fe", "corner"], ["Fe", "body"]], "cn": 8, "pf": "68%", "f": "Fe"},
        "fcc": {"name": "面心立方（Cu、Al、Au）", "a": 361.5, "M": 63.55, "sites": [["Cu", "corner"], ["Cu", "face"]], "cn": 12, "pf": "74%", "f": "Cu"},
        "nacl": {"name": "氯化钠 NaCl", "a": 564, "M": 58.44, "sites": [["Cl", "corner"], ["Cl", "face"], ["Na", "edge"], ["Na", "body"]], "cn": 6, "f": "NaCl"},
        "cscl": {"name": "氯化铯 CsCl", "a": 412, "M": 168.36, "sites": [["Cl", "corner"], ["Cs", "body"]], "cn": 8, "f": "CsCl"},
        "dia": {"name": "金刚石 C", "a": 356.7, "M": 12.01, "sites": [["C", "corner"], ["C", "face"], ["C", "tet"]], "cn": 4, "f": "C"},
        "co2": {"name": "干冰 CO₂（分子晶体）", "a": 562, "M": 44.01, "sites": [["C", "corner"], ["C", "face"]], "cn": 12, "f": "CO₂", "mol": True},
    }
    sel = L.select("晶体", [[k, v["name"]] for k, v in X.items()], "nacl")
    big = L.check("显示 2×2×2 晶胞", False)
    lab_ = L.check("按位置着色（顶点/棱/面/体）", True)
    out = L.out()
    POS = {
        "corner": [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1]],
        "body": [[0.5, 0.5, 0.5]],
        "face": [[0.5, 0.5, 0], [0.5, 0.5, 1], [0.5, 0, 0.5], [0.5, 1, 0.5], [0, 0.5, 0.5], [1, 0.5, 0.5]],
        "edge": [[0.5, 0, 0], [0.5, 1, 0], [0.5, 0, 1], [0.5, 1, 1], [0, 0.5, 0], [1, 0.5, 0], [0, 0.5, 1], [1, 0.5, 1], [0, 0, 0.5], [1, 0, 0.5], [0, 1, 0.5], [1, 1, 0.5]],
        "tet": [[0.25, 0.25, 0.25], [0.75, 0.75, 0.25], [0.75, 0.25, 0.75], [0.25, 0.75, 0.75]],
    }
    WT = {"corner": 1 / 8, "edge": 1 / 4, "face": 1 / 2, "body": 1, "tet": 1}
    WN = {"corner": "顶点 ×1/8", "edge": "棱心 ×1/4", "face": "面心 ×1/2", "body": "体心 ×1", "tet": "体内 ×1"}

    def site_col(w):
        return {"corner": T.c1, "edge": T.c4, "face": T.c2, "body": T.c3, "tet": T.c3}[w]

    def draw():
        c.clear()
        g = c.g
        x = X[sel.v]
        n = 2 if big.v else 1
        s = min(c.w, c.h) / (2.4 * n)
        atoms, seen, bonds = [], set(), []
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    for e, where in x["sites"]:
                        for q in POS[where]:
                            p = (q[0] + i, q[1] + j, q[2] + k)
                            key = tuple(round(v, 3) for v in p)
                            if key in seen:
                                continue
                            seen.add(key)
                            atoms.append({"e": e, "p": [v - n / 2 for v in p], "where": where})
        P = [cam.proj(a["p"], c, s) for a in atoms]
        for i in range(n + 1):
            for j in range(n + 1):
                for a, b in (([i, j, 0], [i, j, n]), ([i, 0, j], [i, n, j]), ([0, i, j], [n, i, j])):
                    A, B = cam.proj([v - n / 2 for v in a], c, s), cam.proj([v - n / 2 for v in b], c, s)
                    D.line(g, A[0], A[1], B[0], B[1], alpha(T.fg, 0.35), 1.2)
        if sel.v == "dia":
            for i, a in enumerate(atoms):
                if a["where"] != "tet":
                    continue
                for j, b in enumerate(atoms):
                    if i != j and v3.len(v3.sub(a["p"], b["p"])) < 0.45:
                        bonds.append((i, j))
        if sel.v in ("nacl", "cscl"):
            lim = 0.51 if sel.v == "nacl" else 0.87
            for i, a in enumerate(atoms):
                for j in range(i + 1, len(atoms)):
                    b = atoms[j]
                    if a["e"] != b["e"] and v3.len(v3.sub(a["p"], b["p"])) < lim:
                        bonds.append((i, j))
        for i, j in bonds:
            D.line(g, P[i][0], P[i][1], P[j][0], P[j][1], alpha(T.muted, 0.7), 2)
        for i in sorted(range(len(atoms)), key=lambda i: P[i][2]):
            a = atoms[i]
            size = 0.17 if a["e"] == "Cl" else 0.2 if a["e"] == "Cs" else 0.11 if a["e"] == "Na" else 0.08 if x.get("mol") else 0.12
            r = size * s * cam.scale * P[i][3]
            px, py = P[i][0], P[i][1]
            col = site_col(a["where"]) if lab_.v else CPK.get(a["e"], ("#999999",))[0]
            if x.get("mol"):
                d = [0.12 * (1.6 if k == i % 3 else 0.2) for k in range(3)]
                A, B = cam.proj(v3.add(a["p"], d), c, s), cam.proj(v3.sub(a["p"], d), c, s)
                D.line(g, A[0], A[1], B[0], B[1], T.c2, 3)
                D.circle(g, A[0], A[1], r * 0.8, CPK["O"][0])
                D.circle(g, B[0], B[1], r * 0.8, CPK["O"][0])
            D.ball(g, px, py, r, col, alpha(T.fg, 0.3))
        counts: dict = {}
        for e, w in x["sites"]:
            counts.setdefault(e, []).append((w, len(POS[w])))

        def frac(w):
            return "1" if WT[w] == 1 else f"1/{int(round(1 / WT[w]))}"
        rows = [[f"{e} 的个数", " + ".join(f"{k}×{frac(w)}" for w, k in arr) + f" = {fmt(sum(k * WT[w] for w, k in arr), 2)}"] for e, arr in counts.items()]
        N = 4 if sel.v == "nacl" else 1 if sel.v == "cscl" else sum(k * WT[w] for w, k in next(iter(counts.values())))
        rho = N * x["M"] / (6.022e23 * (x["a"] * 1e-10) ** 3)
        rows += [[f"每个晶胞含「{x['f']}」", fmt(N, 2)], ["配位数", str(x["cn"])]]
        if x.get("pf"):
            rows.append(["空间利用率", x["pf"]])
        rows += [["晶胞参数 a", f"{fmt(x['a'], 1)} pm"], ["密度 ρ = NM/(N_A a³)", fmt(rho, 3) + " g/cm³"]]
        out.set(rows)
        if lab_.v:
            yy = 18
            for w, t2 in WN.items():
                if not any(q[1] == w for q in x["sites"]):
                    continue
                D.circle(g, 16, yy, 5, site_col(w))
                D.text(g, t2, 26, yy, T.muted, size=11)
                yy += 18
    L.on_draw(draw)
