"""数学 · 必修第二册（由 gewu/math.js 改写）：平面向量、复数、立体几何初步。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import PI, TAU, clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab
from ...kit.solid import draw_mesh, edges, mesh_box, mesh_prism
from ...kit.view import Cam3, View, v3

_SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


def _n(v):
    """坐标显示：整数不带小数点。"""
    return str(int(v)) if float(v).is_integer() else fmt(v, 2)


# ---------------------------------------------------------------- 平面向量
@lab.reg(id="m-vec", subj="math", book=1, unit="平面向量及其应用", title="平面向量运算", kw="向量 加法 减法 数量积 投影 夹角",
         info="<p>拖动向量 <b>a</b>、<b>b</b> 的箭头端点。</p><p class='fb'>a + b：平行四边形法则 / 三角形法则<br>"
              "a·b = |a||b|cos θ = x₁x₂ + y₁y₂<br>a 在 b 上的投影向量 = (a·b / |b|²) b<br>a ⊥ b ⇔ x₁x₂ + y₁y₂ = 0；a ∥ b ⇔ x₁y₂ − x₂y₁ = 0</p>",
         tasks=["拖动使 a·b = 0，此时夹角是多少？", "让 a、b 共线，观察平行四边形退化，并验证 x₁y₂ − x₂y₁ = 0。", "打开数乘，令 λ 取负值，看 λa 的方向。"])
def m_vec(L):
    c = L.canvas()
    v = View(c, -7, 7, -5, 5, equal=True)
    P = {"a": [3.0, 1.0], "b": [1.0, 3.0]}
    L.group("显示")
    sm = L.check("a + b（平行四边形）", True)
    df = L.check("a − b", False)
    pr = L.check("a 在 b 上的投影", True)
    sc = L.check("数乘 λa", False)
    lam = L.slider("λ", -3, 3, 0.1, 1.5)
    out = L.out()

    def hit(x, y):
        return next((k for k in ("a", "b") if math.hypot(v.X(P[k][0]) - x, v.Y(P[k][1]) - y) < 14), None)

    def drag(k, x, y, _dx, _dy):
        P[k] = [round(v.ix(x) * 2) / 2, round(v.iy(y) * 2) / 2]
    L.interact(c, hit=hit, drag=drag)

    def draw():
        v.begin()
        (ax, ay), (bx, by) = P["a"], P["b"]
        dot = ax * bx + ay * by
        la, lb = math.hypot(ax, ay), math.hypot(bx, by)
        if sm.v:
            v.seg(ax, ay, ax + bx, ay + by, T.muted, 1, [4, 3])
            v.seg(bx, by, ax + bx, ay + by, T.muted, 1, [4, 3])
            v.vec(0, 0, ax + bx, ay + by, T.c3, 2.6)
            v.label("a+b", ax + bx, ay + by, T.c3)
        if df.v:
            v.vec(bx, by, ax, ay, T.c4, 2.6)
            v.label("a−b", (ax + bx) / 2, (ay + by) / 2, T.c4)
        if sc.v:
            v.vec(0, 0, lam.v * ax, lam.v * ay, T.c5, 4)
            v.label("λa", lam.v * ax, lam.v * ay, T.c5)
        if pr.v and lb > 0:
            k = dot / (lb * lb)
            v.seg(ax, ay, k * bx, k * by, T.muted, 1, [3, 3])
            v.vec(0, 0, k * bx, k * by, T.c6, 4)
        v.vec(0, 0, ax, ay, T.c1, 2.8)
        v.vec(0, 0, bx, by, T.c2, 2.8)
        v.label("a", ax, ay, T.c1, bold=True, size=14)
        v.label("b", bx, by, T.c2, bold=True, size=14)
        v.dot(ax, ay, T.c1, 6, True)
        v.dot(bx, by, T.c2, 6, True)
        th = math.acos(clamp(dot / la / lb, -1, 1)) if la and lb else math.nan
        g = c.g
        if math.isfinite(th):
            a1, a2 = math.atan2(ay, ax), math.atan2(by, bx)
            d = a2 - a1
            while d > PI:
                d -= TAU
            while d < -PI:
                d += TAU
            g.stroke_style, g.line_width = T.muted, 1.2
            g.begin_path()
            g.arc(v.X(0), v.Y(0), 26, -a1, -(a1 + d), d > 0)
            g.stroke()
        cr = ax * by - ay * bx
        out.set([["a", f"({_n(ax)}, {_n(ay)})"], ["b", f"({_n(bx)}, {_n(by)})"], ["|a| , |b|", f"{fmt(la, 3)} , {fmt(lb, 3)}"],
                 ["a + b", f"({_n(ax + bx)}, {_n(ay + by)})"], ["a − b", f"({_n(ax - bx)}, {_n(ay - by)})"], ["a·b", fmt(dot, 3)],
                 ["夹角 θ", f"{fmt(th * 180 / PI, 2)}°" if math.isfinite(th) else "—"],
                 ["投影向量", f"({fmt(dot / lb / lb * bx, 3)}, {fmt(dot / lb / lb * by, 3)})" if lb else "—"],
                 ["位置关系", "a ⊥ b" if abs(dot) < 1e-9 else "a ∥ b" if abs(cr) < 1e-9 else "一般"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 复数
@lab.reg(id="m-cplx", subj="math", book=1, unit="复数", title="复平面上的复数运算", kw="复数 模 辐角 共轭 三角形式",
         info="<p>复数 z = a + bi 与复平面上的点 Z(a, b)、向量 OZ 一一对应。</p><p class='fb'>|z| = √(a²+b²)　共轭 z̄ = a − bi<br>"
              "z = r(cos θ + i sin θ)<br>z₁z₂ = r₁r₂[cos(θ₁+θ₂) + i sin(θ₁+θ₂)]　模相乘，辐角相加<br>z₁/z₂ = (r₁/r₂)[cos(θ₁−θ₂) + i sin(θ₁−θ₂)]</p>"
              "<p>乘方模式画出 z, z², z³ …，|z|=1 时它们落在单位圆上，体现「乘以单位复数就是旋转」。</p>",
         tasks=["把 z₂ 拖到 i（0,1），观察 z₁·i 相当于把 z₁ 逆时针旋转 90°。", "乘方模式下把 z₁ 拖到单位圆上 72° 处，z⁵ 等于多少？", "验证 z·z̄ = |z|²。"])
def m_cplx(L):
    c = L.canvas()
    v = View(c, -4, 4, -3, 3, equal=True)
    Z = {"z1": [1.5, 1.0], "z2": [0.5, 1.2]}
    L.group("运算")
    op = L.seg("", [["add", "加法"], ["sub", "减法"], ["mul", "乘法"], ["div", "除法"], ["conj", "共轭"], ["pow", "乘方"]], "mul")
    n = L.slider("乘方次数 n", 2, 12, 1, 6)
    snap = L.check("吸附到 0.1 网格", True)
    out = L.out()

    def hit(x, y):
        return next((k for k in ("z1", "z2") if math.hypot(v.X(Z[k][0]) - x, v.Y(Z[k][1]) - y) < 14), None)

    def drag(k, x, y, _dx, _dy):
        a, b = v.ix(x), v.iy(y)
        if snap.v:
            a, b = round(a * 10) / 10, round(b * 10) / 10
        Z[k] = [a, b]
    L.interact(c, hit=hit, drag=drag)

    def S(a, b):
        return f"{fmt(a, 3)} {'−' if b < 0 else '+'} {fmt(abs(b), 3)}i"

    def deg(y, x):
        return math.atan2(y, x) * 180 / PI

    def draw():
        v.begin(xl="实轴", yl="虚轴")
        g = c.g
        D.circle(g, v.X(0), v.Y(0), v.sx, None, T.grid2, 1)
        (a, b), (cc, d) = Z["z1"], Z["z2"]
        m, r, rows = op.v, None, []
        if m == "add":
            r = [a + cc, b + d]
            v.seg(a, b, r[0], r[1], T.muted, 1, [4, 3])
            v.seg(cc, d, r[0], r[1], T.muted, 1, [4, 3])
        elif m == "sub":
            r = [a - cc, b - d]
        elif m == "mul":
            r = [a * cc - b * d, a * d + b * cc]
        elif m == "div":
            q = cc * cc + d * d
            r = [(a * cc + b * d) / q, (b * cc - a * d) / q] if q else None
        elif m == "conj":
            r = [a, -b]
            v.seg(a, b, a, -b, T.muted, 1, [4, 3])
        elif m == "pow":
            x, y = 1.0, 0.0
            pts = [(1.0, 0.0)]
            for _k in range(int(n.v)):
                x, y = x * a - y * b, x * b + y * a
                pts.append((x, y))
            g.stroke_style, g.line_width = T.c3, 1.4
            g.begin_path()
            for i, (px, py) in enumerate(pts):
                (g.line_to if i else g.move_to)(v.X(px), v.Y(py))
            g.stroke()
            for i, (px, py) in enumerate(pts[1:]):
                v.dot(px, py, T.c3, 4)
                v.label("z" + (str(i + 1).translate(_SUP) if i + 1 > 1 else ""), px, py, T.c3, size=11)
            r = list(pts[-1])
            nn = int(n.v)
            rows = [["z", S(a, b)], ["|z| , arg z", f"{fmt(math.hypot(a, b), 4)} , {fmt(deg(b, a), 2)}°"], [f"zⁿ (n={nn})", S(r[0], r[1])],
                    ["|zⁿ| = |z|ⁿ", fmt(math.hypot(a, b) ** nn, 4)], ["arg zⁿ = n·arg z", fmt(nn * deg(b, a), 2) + "°"]]
        v.vec(0, 0, a, b, T.c1, 2.6)
        v.dot(a, b, T.c1, 6, True)
        v.label("z₁", a, b, T.c1, bold=True, size=13)
        if m not in ("conj", "pow"):
            v.vec(0, 0, cc, d, T.c2, 2.6)
            v.dot(cc, d, T.c2, 6, True)
            v.label("z₂", cc, d, T.c2, bold=True, size=13)
        if r and m != "pow":
            v.vec(0, 0, r[0], r[1], T.c3, 3)
            v.label("结果", r[0], r[1], T.c3, bold=True)
        if m != "pow":
            sym = {"add": "z₁ + z₂", "sub": "z₁ − z₂", "mul": "z₁ · z₂", "div": "z₁ / z₂", "conj": "z̄₁"}[m]
            rows = [["z₁", S(a, b)], ["z₂", S(cc, d)], [sym, S(r[0], r[1]) if r else "除数为 0"],
                    ["|z₁| , arg z₁", f"{fmt(math.hypot(a, b), 3)} , {fmt(deg(b, a), 1)}°"],
                    ["|z₂| , arg z₂", f"{fmt(math.hypot(cc, d), 3)} , {fmt(deg(d, cc), 1)}°"]]
            if r:
                rows.append(["结果的模 , 辐角", f"{fmt(math.hypot(r[0], r[1]), 3)} , {fmt(deg(r[1], r[0]), 1)}°"])
            if m == "mul":
                rows.append(["检验", "模相乘、辐角相加"])
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 立体几何
@lab.reg(id="m-solid", subj="math", book=1, unit="立体几何初步", title="空间几何体与正方体截面",
         kw="棱柱 棱锥 圆柱 圆锥 圆台 球 体积 表面积 截面 直观图",
         info="<p>拖动画布旋转，滚轮缩放。看不见的棱按教材惯例画成虚线。</p><p class='fb'>柱体 V = Sh　锥体 V = ⅓Sh　台体 V = ⅓(S′ + √(S′S) + S)h<br>"
              "球 V = ⁴⁄₃πR³，S = 4πR²<br>圆柱侧面积 2πrh　圆锥侧面积 πrl　圆台侧面积 π(r + r′)l</p>"
              "<p><b>正方体截面</b>：平面与正方体相交，截面可能是三角形、四边形、五边形或六边形，但不可能是七边形及以上（正方体只有 6 个面）。"
              "法向量取 (1,1,1) 且过中心时得到正六边形。</p>",
         tasks=["在截面模式下，调节偏移量从 −1 到 1，截面依次经历哪些形状？", "能否截出正五边形？为什么不能？", "比较同底等高的圆柱与圆锥体积之比。"])
def m_solid(L):
    c = L.canvas()
    cam = Cam3(yaw=-0.7, pitch=0.42, persp=0.06)
    L.orbit(c, cam)
    L.group("几何体")
    kind = L.select("", [["cube", "正方体（截面）"], ["box", "长方体"], ["prism", "正棱柱"], ["pyr", "正棱锥"], ["frus", "正棱台"],
                         ["cyl", "圆柱"], ["cone", "圆锥"], ["ftc", "圆台"], ["sph", "球"]], "cube", lambda _v: (sync(), L.draw()))
    p = L.params({"n": ["底面边数 n", 3, 8, 1, 4], "a": ["棱长 / 底边 a", 0.5, 4, 0.1, 2], "b": ["宽 b", 0.5, 4, 0.1, 1.5],
                  "r": ["半径 r", 0.3, 2.5, 0.05, 1.2], "r2": ["上底半径 r′", 0.1, 2.4, 0.05, 0.6], "h": ["高 h", 0.5, 4, 0.1, 2]})
    gs = L.group("截面（正方体）")
    q = L.params({"th": ["法向量 θ（与竖直方向夹角）", 0, 90, 1, 54.7, "°"], "ph": ["法向量 φ（水平方位）", 0, 360, 1, 45, "°"],
                  "d": ["偏移量（−1 到 1）", -1, 1, 0.01, 0]})

    def preset(th, ph, d):
        q.s("th").set(th, True)
        q.s("ph").set(ph, True)
        q.d = d
    L.button("正六边形", lambda _b: preset(54.7, 45, 0))
    L.button("正三角形", lambda _b: preset(54.7, 45, 0.6))
    L.button("矩形", lambda _b: preset(45, 0, 0.2))
    L.group("度量")
    out = L.out()

    def sync():
        k = kind.v
        show = {"n": ["prism", "pyr", "frus"], "a": ["cube", "box", "prism", "pyr", "frus"], "b": ["box"], "r": ["cyl", "cone", "ftc", "sph"],
                "r2": ["ftc", "frus"], "h": ["box", "prism", "pyr", "frus", "cyl", "cone", "ftc"]}
        for key, ks in show.items():
            p.s(key).el.setVisible(k in ks)
        gs.setVisible(k == "cube")
    sync()

    def draw():
        c.clear()
        g = c.g
        k = kind.v
        n, a, b, r, r2, h = int(p.n), p.a, p.b, p.r, p.r2, p.h
        s = min(c.w, c.h) / 6.2
        col = T.accent
        Rn = a / (2 * math.sin(PI / n))
        S = n * a * a / (4 * math.tan(PI / n))
        M, rows = None, []
        if k == "cube":
            M = mesh_box(a, a, a)
        elif k == "box":
            M = mesh_box(a, h, b)
        elif k == "prism":
            M = mesh_prism(n, Rn, Rn, h, PI / 2 + PI / n)
        elif k == "pyr":
            M = mesh_prism(n, Rn, 0, h, PI / 2 + PI / n)
        elif k == "frus":
            M = mesh_prism(n, Rn, Rn * min(0.95, r2 / 2.4), h, PI / 2 + PI / n)
        elif k == "cyl":
            M = mesh_prism(64, r, r, h, 0, True)
        elif k == "cone":
            M = mesh_prism(64, r, 0, h, 0, True)
        elif k == "ftc":
            M = mesh_prism(64, r, min(r2, r * 0.98), h, 0, True)
        elif k == "sph":
            cx, cy = cam.proj([0, 0, 0], c, s)[:2]
            D.circle(g, cx, cy, r * s * cam.scale, alpha(col, 0.07), T.fg, 1.8)
            eq = [[r * math.cos(TAU * i / 96), 0, r * math.sin(TAU * i / 96)] for i in range(97)]
            for i in range(96):
                A, B = cam.proj(eq[i], c, s), cam.proj(eq[i + 1], c, s)
                if A[2] + B[2] > 0:
                    D.line(g, A[0], A[1], B[0], B[1], T.fg, 1.4)
                else:
                    D.line(g, A[0], A[1], B[0], B[1], T.muted, 1, [5, 4])
            O, E = cam.proj([0, 0, 0], c, s), cam.proj([r, 0, 0], c, s)
            D.circle(g, O[0], O[1], 3, T.fg)
            D.line(g, O[0], O[1], E[0], E[1], T.c2, 1.6)
            D.text(g, "R", (O[0] + E[0]) / 2, (O[1] + E[1]) / 2 - 10, T.c2)
            rows = [["体积 ⁴⁄₃πR³", fmt(4 / 3 * PI * r ** 3, 4)], ["表面积 4πR²", fmt(4 * PI * r * r, 4)]]
        if M:
            draw_mesh(c, cam, M, s, col)
        if k == "cube":
            th, ph = q.th * PI / 180, q.ph * PI / 180
            nv = [math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph)]
            dd = q.d * a / 2 * (abs(nv[0]) + abs(nv[1]) + abs(nv[2]))
            pts = []
            for i, j in edges(M):
                A, B = M["V"][i], M["V"][j]
                sa, sb = v3.dot(nv, A) - dd, v3.dot(nv, B) - dd
                if sa * sb < 0 or abs(sa) < 1e-9:
                    t = 0 if abs(sa) < 1e-9 else sa / ((sa - sb) or 1)
                    X = v3.add(A, v3.mul(v3.sub(B, A), t))
                    if not any(v3.len(v3.sub(p2, X)) < 1e-6 for p2 in pts):
                        pts.append(X)
            name, area = "无交", 0.0
            if len(pts) >= 3:
                C = [sum(p2[i] for p2 in pts) / len(pts) for i in range(3)]
                u = v3.cross(nv, [0, 1, 0] if abs(nv[1]) < 0.9 else [1, 0, 0])
                u = v3.mul(u, 1 / v3.len(u))
                w = v3.cross(nv, u)
                pts.sort(key=lambda P1: math.atan2(v3.dot(v3.sub(P1, C), w), v3.dot(v3.sub(P1, C), u)))
                uv = [(v3.dot(v3.sub(P1, C), u), v3.dot(v3.sub(P1, C), w)) for P1 in pts]
                area = abs(sum(uv[i][0] * uv[(i + 1) % len(uv)][1] - uv[i][1] * uv[(i + 1) % len(uv)][0] for i in range(len(uv)))) / 2
                D.poly(g, [cam.proj(P1, c, s)[:2] for P1 in pts], alpha(T.c2, 0.35), T.c2, 2.2)
                sides = [v3.len(v3.sub(pts[(i + 1) % len(pts)], P1)) for i, P1 in enumerate(pts)]
                eqS = all(abs(x - sides[0]) < 1e-3 * a for x in sides)

                def right(i):
                    A, B, C2 = pts[(i - 1) % len(pts)], pts[i], pts[(i + 1) % len(pts)]
                    return abs(v3.dot(v3.sub(A, B), v3.sub(C2, B))) < 1e-4 * a * a
                m = len(pts)
                if m == 3:
                    iso = abs(sides[0] - sides[1]) < 1e-3 or abs(sides[1] - sides[2]) < 1e-3 or abs(sides[0] - sides[2]) < 1e-3
                    name = "正三角形" if eqS else "等腰三角形" if iso else "三角形"
                elif m == 4:
                    rt = all(right(i) for i in range(4))
                    par = abs(sides[0] - sides[2]) < 1e-3 and abs(sides[1] - sides[3]) < 1e-3
                    name = ("正方形" if eqS else "矩形") if rt else "菱形" if eqS else "平行四边形" if par else "梯形"
                else:
                    name = ("正" if eqS else "") + {5: "五边形", 6: "六边形"}.get(m, f"{m} 边形")
            rows = [["正方体体积 a³", fmt(a ** 3, 4)], ["表面积 6a²", fmt(6 * a * a, 4)], ["截面形状", name],
                    ["截面边数", str(len(pts) if len(pts) >= 3 else 0)], ["截面面积", fmt(area, 4)]]
        elif k == "box":
            rows = [["体积 abh", fmt(a * b * h, 4)], ["表面积", fmt(2 * (a * b + a * h + b * h), 4)], ["体对角线", fmt(math.hypot(a, b, h), 4)]]
        elif k == "prism":
            rows = [["底面积 S", fmt(S, 4)], ["体积 Sh", fmt(S * h, 4)], ["表面积", fmt(2 * S + n * a * h, 4)]]
        elif k == "pyr":
            ap = math.hypot(h, a / (2 * math.tan(PI / n)))
            rows = [["底面积 S", fmt(S, 4)], ["体积 ⅓Sh", fmt(S * h / 3, 4)], ["斜高", fmt(ap, 4)], ["表面积", fmt(S + n * a * ap / 2, 4)]]
        elif k == "frus":
            ratio = min(0.95, r2 / 2.4)
            S2 = S * ratio * ratio
            rows = [["下底面积 S", fmt(S, 4)], ["上底面积 S′", fmt(S2, 4)], ["体积 ⅓(S′+√(S′S)+S)h", fmt((S2 + math.sqrt(S * S2) + S) * h / 3, 4)]]
        elif k == "cyl":
            rows = [["体积 πr²h", fmt(PI * r * r * h, 4)], ["侧面积 2πrh", fmt(TAU * r * h, 4)], ["表面积", fmt(TAU * r * h + TAU * r * r, 4)]]
        elif k == "cone":
            ll = math.hypot(r, h)
            rows = [["母线 l", fmt(ll, 4)], ["体积 ⅓πr²h", fmt(PI * r * r * h / 3, 4)], ["侧面积 πrl", fmt(PI * r * ll, 4)],
                    ["侧面展开扇形圆心角", fmt(360 * r / ll, 2) + "°"], ["表面积", fmt(PI * r * ll + PI * r * r, 4)]]
        elif k == "ftc":
            r3 = min(r2, r * 0.98)
            ll = math.hypot(r - r3, h)
            rows = [["母线 l", fmt(ll, 4)], ["体积", fmt(PI * h * (r * r + r * r3 + r3 * r3) / 3, 4)], ["侧面积 π(r+r′)l", fmt(PI * (r + r3) * ll, 4)]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 高尔顿板与频率稳定性
@lab.reg(id="m-galton", subj="math", book=1, unit="概率 · 频率的稳定性", title="高尔顿板与频率稳定性", kw="随机事件 频率 概率 二项分布 正态分布 大数定律",
         info="<p><b>高尔顿板</b>：小球每遇到一个钉子，以概率 p 向右、1−p 向左。经过 n 排钉子后落入第 k 个槽的概率为二项分布 "
              "<span class='f'>P(X=k) = Cₙᵏ pᵏ(1−p)ⁿ⁻ᵏ</span>。球数很多时，直方图接近正态曲线。</p>"
              "<p><b>频率的稳定性</b>：在大量重复试验中，事件 A 发生的频率 fₙ(A) 会逐渐稳定在概率 P(A) 附近。试验次数越多，偏离越小，但每次具体结果仍随机。</p>",
         tasks=["p=0.5、10 排钉子，落入中间槽的理论概率是多少？放 500 个球后比较频率。", "改变 p 为 0.3，分布的峰值向哪边移动？均值 np 是多少？",
                "频率模式下连续做 10 次「抛 100 次」，记录频率的波动范围；再试「抛 10000 次」。"])
def m_galton(L):
    import random
    c = L.canvas()
    S = {"balls": [], "bins": [], "total": 0, "auto": False, "hist": [], "acc": 0.0}

    def set_mode(m):
        G1.setVisible(m == "g")
        G2.setVisible(m == "f")
        L.draw()
    L.group("模式")
    mode = L.seg("", [["g", "高尔顿板"], ["f", "频率稳定性"]], "g", set_mode)
    G1 = L.group("高尔顿板")
    p = L.params({"n": ["钉子排数 n", 4, 16, 1, 10], "p": ["向右概率 p", 0.1, 0.9, 0.05, 0.5], "sp": ["速度", 1, 10, 1, 4]},
                 lambda k, _v: reset() if k != "sp" else None)
    theo = L.check("显示理论分布", True)

    def reset(*_):
        S.update(balls=[], bins=[0] * (int(p.n) + 1), total=0)
        L.draw()

    def drop():
        k = sum(1 for _i in range(int(p.n)) if random.random() < p.p)
        S["bins"][k] += 1
        S["total"] += 1

    def spawn(m):
        for i in range(m):
            S["balls"].append({"row": 0, "col": 0, "t": -i * 0.4, "path": [1 if random.random() < p.p else 0 for _ in range(int(p.n))]})

    def toggle_auto(b):
        S["auto"] = not S["auto"]
        b.setCheckable(True)
        b.setChecked(S["auto"])

    def many(_b):
        for _i in range(500):
            drop()
        L.draw()
    L.button("放 1 个球", lambda _b: spawn(1))
    L.button("连续放球", toggle_auto)
    L.button("一次 500 个", many)
    L.button("清空", reset)
    out = L.out()
    G2 = L.group("频率稳定性")
    G2.setVisible(False)
    ev = L.select("事件", [["0.5", "抛硬币，正面朝上（P=1/2）"], ["0.16667", "掷骰子，点数为 6（P=1/6）"],
                         ["0.16667b", "掷两枚骰子，点数和为 7（P=1/6）"], ["0.25", "抽扑克，抽到红桃（P=1/4）"]], "0.5",
                  lambda _v: (S.__setitem__("hist", []), L.draw()))

    def trials(m):
        pr = float(ev.v.rstrip("b"))
        two = ev.v.endswith("b")
        h = S["hist"][-1] if S["hist"] else (0, 0)
        for _i in range(m):
            hit = (random.randint(1, 6) + random.randint(1, 6) == 7) if two else random.random() < pr
            h = (h[0] + 1, h[1] + (1 if hit else 0))
            if h[0] <= 200 or h[0] % math.ceil(h[0] / 400) == 0:
                S["hist"].append(h)
        S["hist"].append(h)
        L.draw()
    L.button("做 100 次", lambda _b: trials(100))
    L.button("做 1000 次", lambda _b: trials(1000))
    L.button("做 10000 次", lambda _b: trials(10000))
    L.button("清空", lambda _b: (S.__setitem__("hist", []), L.draw()))
    out2 = L.out()
    reset()

    def tick(dt):
        if mode.v != "g":
            return
        if S["auto"]:
            S["acc"] += dt * p.sp * 3
            while S["acc"] > 1:
                spawn(1)
                S["acc"] -= 1
        n = int(p.n)
        for b in S["balls"]:
            b["t"] += dt * p.sp * 2.5
            while b["t"] >= 1 and b["row"] < n:
                b["col"] += b["path"][b["row"]]
                b["row"] += 1
                b["t"] -= 1
        keep = []
        for b in S["balls"]:
            if b["row"] >= n and b["t"] >= 1:
                S["bins"][b["col"]] += 1
                S["total"] += 1
            else:
                keep.append(b)
        S["balls"] = keep
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        if mode.v == "g":
            n = int(p.n)
            top, bottom = 30, c.h * 0.42
            dx = min(c.w / (n + 3), 46)
            dy = (bottom - top) / n
            cx = c.w / 2
            for i in range(n):
                for j in range(i + 1):
                    D.circle(g, cx + (j - i / 2) * dx, top + i * dy + dy / 2, 3, T.muted)
            for b in S["balls"]:
                if b["t"] < 0:
                    continue
                nc = b["col"] + (b["path"][b["row"]] if b["row"] < n else 0)
                t = min(1, b["t"])
                x0 = cx + (b["col"] - b["row"] / 2) * dx
                x1 = cx + (nc - (b["row"] + 1) / 2) * dx
                D.circle(g, x0 + (x1 - x0) * t, top + (b["row"] + t) * dy - math.sin(t * PI) * dy * 0.25, 4.5, T.c2)
            by = c.h - 30
            bh = by - bottom - 30
            bins, total = S["bins"], S["total"]
            pr = [math.comb(n, k) * p.p ** k * (1 - p.p) ** (n - k) for k in range(n + 1)]
            scale = max(max(bins + [1]), total * max(pr)) or 1
            for k in range(n + 1):
                x = cx + (k - n / 2) * dx
                D.line(g, x - dx / 2, by, x - dx / 2, bottom + 10, T.grid2, 1)
                hh = bins[k] / scale * bh
                D.rect(g, x - dx / 2 + 2, by - hh, dx - 4, hh, alpha(T.c1, 0.75))
                D.text(g, k, x, by + 12, T.muted, align="center", size=11, mono=True)
            D.line(g, cx - (n / 2 + 0.5) * dx, by, cx + (n / 2 + 0.5) * dx, by, T.axis, 1.2)
            if theo.v and total > 0:
                g.stroke_style, g.line_width = T.c2, 2
                g.begin_path()
                for k, q in enumerate(pr):
                    (g.line_to if k else g.move_to)(cx + (k - n / 2) * dx, by - q * total / scale * bh)
                g.stroke()
            mean = sum(b * k for k, b in enumerate(bins)) / total if total else 0
            vr = sum(b * (k - mean) ** 2 for k, b in enumerate(bins)) / total if total else 0
            out.set([["已落球数", str(total)], ["样本均值", fmt(mean, 3)], ["理论均值 np", fmt(n * p.p, 3)], ["样本方差", fmt(vr, 3)],
                     ["理论方差 np(1−p)", fmt(n * p.p * (1 - p.p), 3)], ["中间槽理论概率", fmt(pr[round(n * p.p)], 4)]])
        else:
            pr = float(ev.v.rstrip("b"))
            v = View(c, 0, 1, 0, 1, pad=(50, 20, 20, 36))
            hist = S["hist"]
            N = hist[-1][0] if hist else 100
            v.r = [0, N, max(0, pr - 0.5), min(1, pr + 0.5)]
            v.fit()
            v.grid(xl="试验次数 n", yl="频率")
            v.seg(0, pr, N, pr, T.c2, 1.6, [6, 4])
            v.label("P = " + fmt(pr, 4), N, pr, T.c2, align="right", dx=-4)
            g.stroke_style, g.line_width = T.c1, 1.8
            g.begin_path()
            for i, h in enumerate(hist):
                (g.line_to if i else g.move_to)(v.X(h[0]), v.Y(h[1] / h[0]))
            g.stroke()
            last = hist[-1] if hist else None
            out2.set([["试验次数", str(last[0])], ["事件发生次数", str(last[1])], ["频率", fmt(last[1] / last[0], 4)],
                      ["与概率之差", fmt(last[1] / last[0] - pr, 4)]] if last else [["提示", "点击上方按钮开始试验"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 统计：直方图
@lab.reg(id="m-stat", subj="math", book=1, unit="统计", title="样本数据与频率分布直方图", kw="平均数 中位数 众数 方差 标准差 百分位数 组距",
         info="<p>纵轴是 <b>频率/组距</b>，所以每个小矩形的面积等于该组频率，所有矩形面积之和为 1。</p>"
              "<p class='fb'>用直方图估计：平均数 ≈ Σ(组中值 × 频率)；中位数是使左右两侧面积都为 0.5 的横坐标；众数取最高矩形的组中值<br>"
              "方差 s² = (1/n)Σ(xᵢ − x̄)²<br>第 p 百分位数：计算 i = n·p%，i 非整数则取第 ⌈i⌉ 项，i 为整数则取第 i 项与第 i+1 项的平均</p>",
         tasks=["用右偏分布抽样，比较平均数与中位数的大小。", "改变组距，直方图形状与估计值如何变化？", "求第 25、75 百分位数，它们之间包含了多少比例的数据？"])
def m_stat(L):
    import random
    c = L.canvas()
    S = {"data": []}

    def sample(*_):
        data = []
        for _i in range(int(n.v)):
            k = dist.v
            if k == "n":
                x = 165 + 7 * random.gauss(0, 1)
            elif k == "r":
                x = 140 + math.exp(3 + 0.6 * random.gauss(0, 1))
            elif k == "u":
                x = random.uniform(140, 190)
            else:
                x = 155 + 5 * random.gauss(0, 1) if random.random() < 0.5 else 178 + 5 * random.gauss(0, 1)
            data.append(round(x * 10) / 10)
        S["data"] = sorted(data)
        L.draw()
    L.group("抽样")
    dist = L.select("总体分布", [["n", "近似正态（如身高）"], ["r", "右偏（如收入）"], ["u", "均匀"], ["b", "双峰"]], "n", sample)
    n = L.slider("样本量 n", 20, 2000, 10, 200, sample)
    L.button("重新抽样", sample, True)
    L.group("直方图")
    w = L.slider("组距", 1, 20, 0.5, 5)
    pc = L.slider("百分位 p", 1, 99, 1, 75, None, "%")
    out = L.out()
    sample()

    def draw():
        c.clear()
        g = c.g
        data = S["data"]
        N, W = len(data), w.v
        lo = math.floor(data[0] / W) * W
        hi = math.ceil((data[-1] + 1e-9) / W) * W
        K = max(1, round((hi - lo) / W))
        cnt = [0] * K
        for x in data:
            cnt[min(K - 1, int((x - lo) // W))] += 1
        den = [k / N / W for k in cnt]
        v = View(c, lo, hi, 0, max(den) * 1.18, pad=(52, 16, 18, 30))
        v.fit()
        v.grid(xl="数据", yl="频率/组距", xstep=W * max(1, round(60 / (W * v.sx))))
        for i, d in enumerate(den):
            D.rect(g, v.X(lo + i * W), v.Y(d), W * v.sx, v.Y(0) - v.Y(d), alpha(T.c1, 0.6), T.c1, 1)
        mean = sum(data) / N
        med = data[(N - 1) // 2] if N % 2 else (data[N // 2 - 1] + data[N // 2]) / 2
        vr = sum((x - mean) ** 2 for x in data) / N
        h_mean = sum((lo + (i + 0.5) * W) * k / N for i, k in enumerate(cnt))
        acc, h_med = 0.0, lo
        for i in range(K):
            f = cnt[i] / N
            if acc + f >= 0.5:
                h_med = lo + i * W + (0.5 - acc) / f * W
                break
            acc += f
        h_mode = lo + (cnt.index(max(cnt)) + 0.5) * W
        ii = N * pc.v / 100
        pv = (data[int(ii) - 1] + data[min(N - 1, int(ii))]) / 2 if float(ii).is_integer() else data[math.ceil(ii) - 1]

        def mark(x, col, t, row):
            v.seg(x, 0, x, v.y1, col, 1.8, [6, 3])
            D.text(g, t, v.X(x) + 4, v.oy + 12 + row * 15, col, size=11.5)
        mark(mean, T.c2, "平均数", 0)
        mark(med, T.c3, "中位数", 1)
        mark(h_mode, T.c4, "众数", 2)
        mark(pv, T.c5, f"P{int(pc.v)}", 3)
        out.set([["样本量", str(N)], ["平均数 x̄", fmt(mean, 2)], ["中位数", fmt(med, 2)], ["方差 s²", fmt(vr, 2)], ["标准差 s", fmt(math.sqrt(vr), 2)],
                 [f"第 {int(pc.v)} 百分位数", fmt(pv, 2)], ["极差", fmt(data[-1] - data[0], 1)], ["<i>由直方图估计</i>", ""],
                 ["平均数", fmt(h_mean, 2)], ["中位数", fmt(h_med, 2)], ["众数", fmt(h_mode, 2)]])
    L.on_draw(draw)
