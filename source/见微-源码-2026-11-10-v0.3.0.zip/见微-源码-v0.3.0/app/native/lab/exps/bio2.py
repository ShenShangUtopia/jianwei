"""生物 · 必修2 遗传与进化（由 gewu/bio.js 改写）：减数分裂、孟德尔遗传、中心法则与基因突变、基因频率与进化。"""
from __future__ import annotations

import math
import random
import re

from ...design.tokens import T, alpha
from ...kit.core import clamp, fmt, gauss
from ...kit.draw import D
from ...kit.registry import lab
from .bio1 import cell_division


@lab.reg(id="b-meiosis", subj="bio", book=1, unit="基因和染色体的关系", title="减数分裂与配子形成", kw="减数分裂 联会 四分体 交叉互换 同源染色体分离 自由组合 精子 卵细胞",
         info="<p>减数分裂中染色体只复制一次，而细胞连续分裂两次，结果子细胞中染色体数目减半。</p>"
              "<p class='fb'>减Ⅰ：同源染色体联会 → 四分体 → 同源染色体分离、非同源染色体自由组合（染色体数目减半发生在减Ⅰ）<br>减Ⅱ：着丝粒分裂，姐妹染色单体分开（类似有丝分裂）</p>"
              "<p>点击「换一种非同源染色体组合」观察减Ⅰ 中期的不同排列方式：含 n 对同源染色体的个体，理论上可产生 2ⁿ 种配子；但一个精原细胞只能产生 4 个、2 种精细胞（不考虑交叉互换）。"
              "勾选交叉互换后，同一个精原细胞可以产生 4 种精细胞。</p>",
         tasks=["同源染色体在哪个时期分离？着丝粒在哪个时期分裂？", "2n = 4 的个体，不考虑交叉互换能产生几种配子？", "勾选交叉互换后，减Ⅱ 末期 4 个精细胞的染色体组成有何不同？"])
def b_meiosis(L):
    cell_division(L, "mei")


# ---------------------------------------------------------------- 孟德尔遗传
GENES = [["Y", "y", "黄色", "绿色", "子叶"], ["R", "r", "圆粒", "皱粒", "种子"], ["D", "d", "高茎", "矮茎", "茎"]]


@lab.reg(id="b-mendel", subj="bio", book=1, unit="遗传因子的发现 · 伴性遗传", title="分离定律、自由组合定律与伴性遗传",
         kw="孟德尔 分离定律 自由组合定律 棋盘法 基因型 表型 性状分离比 伴X隐性 色盲",
         info="<p class='fb'>分离定律：Aa × Aa → AA : Aa : aa = 1 : 2 : 1，显性 : 隐性 = 3 : 1<br>自由组合定律：YyRr × YyRr → 9 : 3 : 3 : 1；测交 YyRr × yyrr → 1 : 1 : 1 : 1<br>"
              "伴 X 隐性遗传（红绿色盲）：男性患者多于女性；女病父子病；交叉遗传</p><p>棋盘中每格是一种受精组合，颜色表示表型。点「随机产生后代」可以看到实际统计数与理论比例的偏差。</p>",
         tasks=["设两对基因均为杂合（YyRr × YyRr），验证 9 : 3 : 3 : 1。", "做测交：YyRr × yyrr，比例是多少？", "伴性遗传：携带者母亲 × 正常父亲，儿子患病的概率是多少？"])
def b_mendel(L):
    c = L.canvas()
    L.tall()
    S = {"sim": None}

    def changed(*_):
        S["sim"] = None
        sync()
        L.draw()
    L.group("遗传方式")
    mode = L.seg("", [["auto", "常染色体"], ["x", "伴 X 隐性（色盲）"]], "auto", changed)
    G = L.group("亲本基因型")
    n = L.slider("相对性状对数", 1, 3, 1, 2, changed)
    pm, pf = [], []
    for i, (A, a, *_r) in enumerate(GENES):
        pm.append(L.select(f"♀ 第 {i + 1} 对", [A + A, A + a, a + a], A + a, changed))
        pf.append(L.select(f"♂ 第 {i + 1} 对", [A + A, A + a, a + a], A + a, changed))
    GX = L.group("伴 X 遗传")
    xm = L.select("♀ 母亲", [["BB", "XᴮXᴮ 正常"], ["Bb", "XᴮXᵇ 携带者"], ["bb", "XᵇXᵇ 色盲"]], "Bb", changed)
    xf = L.select("♂ 父亲", [["B", "XᴮY 正常"], ["b", "XᵇY 色盲"]], "B", changed)
    L.group("统计")
    L.button("随机产生 100 个后代", lambda _b: simulate(100), True)
    L.button("1000 个", lambda _b: simulate(1000))
    out = L.out()

    def sync():
        x = mode.v == "x"
        G.setVisible(not x)
        GX.setVisible(x)
        for i, s in enumerate(pm):
            s.box.setVisible(i < n.v)
            pf[i].box.setVisible(i < n.v)

    def gametes(sels):
        gs = [""]
        for s in sels[:int(n.v)]:
            al = [s.v[0]] if s.v[0] == s.v[1] else list(s.v)
            gs = [gm + x for gm in gs for x in al]
        acc: dict = {}
        for x in gs:
            acc[x] = acc.get(x, 0) + 1 / len(gs)
        return list(acc.items())

    def cross():
        if mode.v == "x":
            mg = [("Xᴮ", 1)] if xm.v == "BB" else [("Xᵇ", 1)] if xm.v == "bb" else [("Xᴮ", 0.5), ("Xᵇ", 0.5)]
            fg = [("Xᴮ" if xf.v == "B" else "Xᵇ", 0.5), ("Y", 0.5)]

            def ph(a, b):
                if b == "Y":
                    return "色盲男性" if a == "Xᵇ" else "正常男性"
                return "色盲女性" if a == "Xᵇ" and b == "Xᵇ" else "携带者女性" if "Xᵇ" in (a, b) else "正常女性"

            def geno(a, b):
                return a + "Y" if b == "Y" else "".join(sorted([a, b]))
            return mg, fg, geno, ph
        mg, fg = gametes(pm), gametes(pf)

        def geno(a, b):
            return "".join("".join(sorted([x, b[i]], key=lambda u: 0 if u.isupper() else 1)) for i, x in enumerate(a))

        def ph(a, b):
            return "".join(GENES[i][2] if (x.isupper() or b[i].isupper()) else GENES[i][3] for i, x in enumerate(a))
        return mg, fg, geno, ph

    def simulate(N):
        mg, fg, _geno, ph = cross()

        def pick(arr):
            r = random.random()
            for x, p in arr:
                r -= p
                if r <= 0:
                    return x
            return arr[-1][0]
        cnt: dict = {}
        for _ in range(N):
            k = ph(pick(mg), pick(fg))
            cnt[k] = cnt.get(k, 0) + 1
        S["sim"] = {"N": N, "cnt": cnt}
        L.draw()
    sync()

    def draw():
        c.clear()
        g = c.g
        mg, fg, geno, ph = cross()
        phs, gts = {}, {}
        for a, pa in mg:
            for b, pb in fg:
                k, gt = ph(a, b), geno(a, b)
                phs[k] = phs.get(k, 0) + pa * pb
                gts[gt] = gts.get(gt, 0) + pa * pb
        keys = sorted(phs, key=lambda k: -phs[k])

        def col_of(k):
            return T.c[keys.index(k) % 6]
        m, f = len(mg), len(fg)
        size = min((c.w * 0.62 - 60) / (f + 1), (c.h - 60) / (m + 1), 90)
        ox = oy = 20
        D.text(g, "♀ \\ ♂", ox + size / 2, oy + size / 2, T.muted, align="center", size=12)
        for j, (b, _p) in enumerate(fg):
            D.text(g, b, ox + (j + 1.5) * size, oy + size / 2, T.c2, align="center", bold=True, size=min(16, size * 0.3))
        for i, (a, _p) in enumerate(mg):
            D.text(g, a, ox + size / 2, oy + (i + 1.5) * size, T.c1, align="center", bold=True, size=min(16, size * 0.3))
            for j, (b, _q) in enumerate(fg):
                x, y = ox + (j + 1) * size, oy + (i + 1) * size
                D.rect(g, x + 1, y + 1, size - 2, size - 2, alpha(col_of(ph(a, b)), 0.35), T.line, 1)
                D.text(g, geno(a, b), x + size / 2, y + size / 2, T.fg, align="center", size=min(14, size * 0.24), mono=True)
        gx = c.w * 0.64
        gw = c.w - gx - 20
        den = min(phs.values())
        y = 30
        D.text(g, "表型比例", gx, y, T.muted, size=12)
        y += 22
        sim = S["sim"]
        for k in keys:
            D.rect(g, gx, y - 9, phs[k] * gw, 18, alpha(col_of(k), 0.6))
            D.text(g, f"{k}  {fmt(phs[k] / den, 2)}（{fmt(phs[k] * 100, 2)}%）", gx + 4, y, T.fg, size=12)
            if sim:
                D.text(g, f"实际 {sim['cnt'].get(k, 0)}/{sim['N']}", gx + gw, y + 14, T.muted, size=11, align="right", mono=True)
            y += 32 if sim else 26
        out.set([["♀ 配子种类", f"{m} 种"], ["♂ 配子种类", f"{f} 种"], ["受精组合", f"{m * f} 种"], ["基因型种类", len(gts)], ["表型种类", len(keys)],
                 ["表型比", " : ".join(fmt(phs[k] / den, 2) for k in keys)]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 中心法则
CODON = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
AA = {"F": "苯丙", "L": "亮", "I": "异亮", "M": "甲硫", "V": "缬", "S": "丝", "P": "脯", "T": "苏", "A": "丙", "Y": "酪", "H": "组", "Q": "谷酰胺", "N": "天冬酰胺",
      "K": "赖", "D": "天冬", "E": "谷", "C": "半胱", "W": "色", "R": "精", "G": "甘"}


def aa_name(a):
    return AA[a] + ("" if a in "QN" else "氨酸")


def translate(mrna):
    st = mrna.find("AUG")
    if st < 0:
        return {"start": -1, "aa": [], "stop": False, "end": -1}
    aa, stop, i = [], False, st
    while i + 3 <= len(mrna):
        cd = mrna[i:i + 3]
        a = CODON["UCAG".index(cd[0]) * 16 + "UCAG".index(cd[1]) * 4 + "UCAG".index(cd[2])]
        if a == "*":
            stop = True
            break
        aa.append(a)
        i += 3
    return {"start": st, "aa": aa, "stop": stop, "end": i}


@lab.reg(id="b-dogma", subj="bio", book=1, unit="基因的表达 · 基因突变", title="转录、翻译与基因突变",
         kw="中心法则 转录 翻译 mRNA tRNA 密码子 反密码子 核糖体 基因突变 替换 插入 缺失 移码",
         info="<p>输入 DNA 的<b>编码链</b>（非模板链，5′→3′）。以另一条<b>模板链</b>为模板，按碱基互补配对原则（A−U、T−A、G−C、C−G）转录出 mRNA；"
              "mRNA 上每 3 个相邻碱基构成一个密码子，从起始密码子 AUG 开始翻译，到终止密码子（UAA、UAG、UGA）结束。</p>"
              "<p class='fb'>DNA → RNA → 蛋白质　碱基数 : 氨基酸数 = 6 : 3 : 1（不考虑终止密码子）</p>"
              "<p><b>基因突变</b>：碱基替换可能不改变氨基酸（密码子简并性），也可能改变一个氨基酸或提前出现终止密码子；插入或缺失一个碱基会造成移码，影响其后所有氨基酸。</p>",
         tasks=["把第 6 位的 T 替换为 C，氨基酸序列变了吗？为什么？", "在第 4 位插入一个碱基，比较突变前后的蛋白质。", "找到一处替换，使蛋白质提前终止（无义突变）。"])
def b_dogma(L):
    c = L.canvas()
    S = {"dna0": "ATGGCTAGCAAAGAATTCCTGTGGTAA", "rib": 0.0}
    S["dna"] = S["dna0"]

    def on_input(s, val):
        v = re.sub(r"[^ATCG]", "", s.upper())
        if not v:
            val.err("只能输入 A T C G")
            return
        val.err("")
        S["dna0"] = S["dna"] = v
        pos.set_range(1, len(v))
        S["rib"] = 0.0
        L.draw()
    L.group("DNA 编码链（5′→3′）")
    L.input("", S["dna0"], on_input)
    L.group("基因突变")
    pos = L.slider("位置", 1, len(S["dna0"]), 1, 6)
    typ = L.select("类型", [["sub", "替换"], ["ins", "插入"], ["del", "缺失"]], "sub")
    base = L.select("碱基", ["A", "T", "C", "G"], "C")

    def mutate(_b):
        i, d = int(pos.v) - 1, S["dna"]
        S["dna"] = d[:i] + base.v + d[i + 1:] if typ.v == "sub" else d[:i] + base.v + d[i:] if typ.v == "ins" else d[:i] + d[i + 1:]
        S["rib"] = 0.0
        L.draw()
    L.button("施加突变", mutate, True)
    L.button("恢复原序列", lambda _b: (S.update(dna=S["dna0"], rib=0.0), L.draw()))
    out = L.out()

    def tick(dt):
        S["rib"] += dt * 1.2
        L.draw()
    L.loop(tick)
    comp = {"A": "T", "T": "A", "C": "G", "G": "C"}

    def col_b(b):
        return {"A": T.c2, "T": T.c4, "U": T.c5, "C": T.c1, "G": T.c3}[b]

    def draw():
        c.clear()
        g = c.g
        dna, dna0 = S["dna"], S["dna0"]
        n = len(dna)
        bw = min(26, (c.w - 90) / max(n, 1))
        x0 = 70
        tmpl = "".join(comp[b] for b in dna)
        mrna = dna.replace("T", "U")

        def row(s, y, lab_, sub=None):
            D.text(g, lab_, 8, y + bw / 2, T.muted, size=11)
            if sub:
                D.text(g, sub, 8, y + bw / 2 + 13, T.muted, size=9.5)
            for i, b in enumerate(s):
                D.rect(g, x0 + i * bw + 1, y, bw - 2, bw, alpha(col_b(b), 0.55))
                if bw > 11:
                    D.text(g, b, x0 + i * bw + bw / 2, y + bw / 2, T.fg, align="center", bold=True, size=min(13, bw * 0.55), mono=True)
        row(dna, 20, "编码链", "5′→3′")
        row(tmpl, 22 + bw, "模板链", "3′→5′")
        for i in range(n):
            D.line(g, x0 + i * bw + bw / 2, 20 + bw, x0 + i * bw + bw / 2, 22 + bw, T.muted, 1)
        if dna != dna0:
            i = int(pos.v) - 1
            D.rect(g, x0 + i * bw, 17, bw, 2 * bw + 8, None, T.bad, 2)
        my = 50 + 3 * bw
        D.arrow(g, 30, 30 + 2 * bw, 30, my - 4, T.muted, 1.4)
        D.text(g, "转录", 36, (30 + 2 * bw + my) / 2, T.muted, size=11)
        row(mrna, my, "mRNA", "5′→3′")
        tr = translate(mrna)
        if tr["start"] >= 0:
            na = len(tr["aa"])
            n_cod = na + (1 if tr["stop"] else 0)
            k = int(S["rib"] % (n_cod + 3))
            shown = min(k, na)
            for j in range(n_cod):
                x = x0 + (tr["start"] + 3 * j) * bw
                D.line(g, x, my + bw + 2, x + 3 * bw - 2, my + bw + 2, T.bad if j == na else T.c5, 2)
            if k < n_cod:
                rx, ry = x0 + (tr["start"] + 3 * k) * bw - 8, my - 16
                D.rrect(g, rx, ry, 3 * bw + 16, bw + 34, 14, alpha(T.c4, 0.25), T.c4, 1.5)
                if k < na:
                    cd = mrna[tr["start"] + 3 * k:tr["start"] + 3 * k + 3]
                    anti = "".join({"A": "U", "U": "A", "C": "G", "G": "C"}[b] for b in cd)
                    D.text(g, "tRNA 反密码子 " + anti, rx + 4, my + bw + 30, T.muted, size=11)
            py = my + bw + 60
            for j in range(shown):
                x, y = x0 + 20 + j * 46, py + 20
                if x > c.w - 20:
                    break
                if j:
                    D.line(g, x - 46, y, x, y, T.muted, 2)
                D.circle(g, x, y, 17, alpha(T.c["FLIMVSPTAYHQNKDECWRG".index(tr["aa"][j]) % 6], 0.6), T.fg, 1)
                D.text(g, AA[tr["aa"][j]][:2], x, y, T.fg, align="center", size=11)
            D.text(g, "肽链：", 8, py + 20, T.muted, size=11)
        else:
            D.text(g, "没有找到起始密码子 AUG", x0, my + bw + 40, T.bad)
        t0 = translate(dna0.replace("T", "U"))

        def seq(a):
            return "—".join(aa_name(x) for x in a) or "（无）"
        kind = "无突变"
        if dna != dna0:
            if len(dna) != len(dna0):
                kind = ("移码突变：" if abs(len(dna) - len(dna0)) % 3 else "插入/缺失 3 的倍数个碱基：") + "影响之后的氨基酸序列"
            elif tr["aa"] == t0["aa"]:
                kind = "同义突变：氨基酸序列不变（密码子简并性）"
            elif len(tr["aa"]) < len(t0["aa"]) and tr["stop"] and t0["aa"][:len(tr["aa"])] == tr["aa"]:
                kind = "无义突变：提前出现终止密码子，肽链变短"
            else:
                kind = "错义突变：改变了氨基酸"
        if tr["start"] >= 0:
            cs = mrna[tr["start"]:tr["end"] + (3 if tr["stop"] else 0)]
            codons = " ".join(cs[i:i + 3] for i in range(0, len(cs), 3))
        else:
            codons = "—"
        out.set([["mRNA", ""], f"<span style='font-family:monospace'>{mrna}</span>", ["密码子", ""], f"<span style='font-family:monospace'>{codons}</span>",
                 ["氨基酸数", len(tr["aa"])], ["原蛋白质", ""], seq(t0["aa"]), ["当前蛋白质", ""], seq(tr["aa"]), ["突变类型", ""], kind])
    L.on_draw(draw)


# ---------------------------------------------------------------- 基因频率与进化
@lab.reg(id="b-hw", subj="bio", book=1, unit="生物的进化", title="自然选择与遗传漂变", kw="基因频率 基因型频率 遗传平衡 哈迪-温伯格 自然选择 遗传漂变 种群 适应 进化",
         info="<p class='fb'>基因频率 p + q = 1；遗传平衡时基因型频率 AA : Aa : aa = p² : 2pq : q²<br>遗传平衡条件：种群足够大、随机交配、没有迁入迁出、没有自然选择、没有突变</p>"
              "<p><b>生物进化的实质是种群基因频率的改变</b>。自然选择使有利基因频率定向升高；种群很小时，偶然因素造成的遗传漂变会使基因频率随机波动，甚至使某个基因丢失或固定。</p>"
              "<p>每条曲线是一个独立的种群，采用 Wright−Fisher 模型逐代随机抽样。</p>",
         tasks=["三种基因型适合度都为 1，种群大小 N = 5000，p 会变化吗？把 N 改为 20 再看。", "让 aa 的适合度为 0.5（不利于隐性纯合子），q 的下降速度如何？为什么很难彻底淘汰 a？",
                "模拟桦尺蠖：设黑色（A_）适合度为 1，浅色（aa）为 0.7，观察 A 频率的变化。"])
def b_hw(L):
    c = L.canvas()
    S = {"runs": [], "shown": 0.0}
    p = L.params({"p0": ["初始 A 基因频率 p₀", 0.01, 0.99, 0.01, 0.5], "N": ["种群个体数 N", 10, 5000, 10, 500], "wAA": ["AA 适合度", 0, 1, 0.05, 1],
                  "wAa": ["Aa 适合度", 0, 1, 0.05, 1], "waa": ["aa 适合度", 0, 1, 0.05, 1], "G": ["代数", 20, 300, 10, 150], "R": ["种群数（重复）", 1, 8, 1, 5]},
                 lambda _k, _v: run())
    L.button("重新模拟", lambda _b: run(), True)

    def moth(_b):
        for k, v in (("p0", 0.05), ("wAA", 1), ("wAa", 1), ("waa", 0.7)):
            p.s(k).set(v, True)
        p.N = 1000
    L.button("桦尺蠖情境", moth)
    out = L.out()

    def binom(n, q):
        if n < 120:
            return sum(1 for _ in range(n) if random.random() < q)
        return clamp(round(n * q + math.sqrt(max(0.0, n * q * (1 - q))) * gauss()), 0, n)

    def run():
        runs = []
        N2 = int(2 * p.N)
        for _ in range(int(p.R)):
            x = p.p0
            tr = [(0, x)]
            for gg in range(1, int(p.G) + 1):
                y = 1 - x
                wb = x * x * p.wAA + 2 * x * y * p.wAa + y * y * p.waa
                xs = (x * x * p.wAA + x * y * p.wAa) / wb if wb > 0 else x
                x = binom(N2, xs) / N2
                tr.append((gg, x))
            runs.append(tr)
        S["runs"], S["shown"] = runs, 0.0
        L.draw()
    run()

    def tick(dt):
        if S["shown"] < p.G:
            S["shown"] = min(p.G, S["shown"] + dt * 60)
            L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        runs = S["runs"]
        k = int(S["shown"])
        gh = c.h - 120
        D.chart(g, 50, 24, c.w - 80, gh, [{"pts": tr[:k + 1], "color": T.c[i % 6], "w": 1.8} for i, tr in enumerate(runs)],
                title="A 基因频率 p − 代数", xl="代数", xmin=0, xmax=p.G, ymin=0, ymax=1)
        tr0 = runs[0]
        pr = tr0[clamp(k, 0, len(tr0) - 1)][1]
        q = 1 - pr
        by, bw = c.h - 70, (c.w - 100) / 3
        for i, (n2, f) in enumerate((("AA", pr * pr), ("Aa", 2 * pr * q), ("aa", q * q))):
            x = 50 + i * (bw + 10)
            D.rect(g, x, by, bw, 18, alpha(T.muted, 0.12))
            D.rect(g, x, by, bw * f, 18, alpha(T.c[i], 0.7))
            D.text(g, f"{n2} {fmt(f, 3)}", x + 4, by + 9, T.fg, size=12)
        D.text(g, "种群 1 当前的遗传平衡基因型频率（p²、2pq、q²）", 50, by - 12, T.muted, size=11)
        fin = [tr[clamp(k, 0, len(tr) - 1)][1] for tr in runs]
        out.set([["当前代数", k], ["各种群 p", ", ".join(fmt(x, 2) for x in fin)], ["A 被固定", f"{sum(1 for x in fin if x == 1)} 个种群"],
                 ["A 丢失", f"{sum(1 for x in fin if x == 0)} 个种群"], ["平均适合度 w̄（种群 1）", fmt(pr * pr * p.wAA + 2 * pr * q * p.wAa + q * q * p.waa, 3)]])
    L.on_draw(draw)
