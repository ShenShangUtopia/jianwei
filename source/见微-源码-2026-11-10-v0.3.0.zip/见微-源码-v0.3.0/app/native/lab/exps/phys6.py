"""物理 · 选择性必修第三册（由 gewu/phys2.js 改写）：气体、光电效应、氢原子能级、放射性衰变。"""
from __future__ import annotations

import math
import random
import time

from ...design.tokens import T, alpha
from ...kit.core import TAU, comb, fmt
from ...kit.draw import D, wave_css
from ...kit.registry import lab


# ---------------------------------------------------------------- 气体实验定律与分子运动
@lab.reg(id="p-gas", subj="phys", book=5, unit="气体、固体和液体", title="气体实验定律与分子运动",
         kw="玻意耳定律 查理定律 盖-吕萨克定律 理想气体状态方程 等温 等压 等容 p-V 图",
         info="<p class='fb'>玻意耳定律（等温）pV = C　查理定律（等容）p/T = C　盖-吕萨克定律（等压）V/T = C<br>理想气体状态方程 pV/T = C</p>"
              "<p>微观解释：温度越高分子平均动能越大，撞击器壁越猛烈；体积越小单位体积分子数越多，单位时间撞击次数越多。两者都会使压强增大。</p>"
              "<p>p − V 图中的虚线是不同温度的等温线（双曲线），温度越高越远离原点。</p>",
         tasks=["等温压缩到一半体积，压强变为多少？分子运动快慢变吗？", "等容加热从 27 ℃ 到 127 ℃，压强变为原来的几倍？", "在 p − V 图上依次做等压膨胀、等容降温，画出一个循环。"])
def p_gas(L):
    c = L.canvas()
    N, nR = 70, 1 / 300   # p(atm)·V(L)/T(K)
    S = {"st": {"V": 1.0, "T": 300.0, "p": 1.0}, "trace": [(1.0, 1.0)], "parts": []}

    def push():
        st = S["st"]
        S["trace"].append((st["V"], st["p"]))
        if len(S["trace"]) > 2000:
            S["trace"].pop(0)
        L.draw()
    L.group("过程")

    def set_mode(_m):
        st = S["st"]
        S["trace"] = [(st["V"], st["p"])]
        sync()
        L.draw()
    mode = L.seg("", [["T", "等温"], ["p", "等压"], ["V", "等容"]], "T", set_mode)

    def on_v(v):
        st = S["st"]
        if mode.v == "T":
            st["V"] = v
            st["p"] = nR * st["T"] / v
        push()

    def on_t(v):
        st = S["st"]
        r = math.sqrt(v / st["T"])
        for q in S["parts"]:
            q["vx"] *= r
            q["vy"] *= r
        st["T"] = v
        if mode.v == "p":
            st["V"] = nR * v / st["p"]
            sV.set(st["V"], True)
        else:
            st["p"] = nR * v / st["V"]
        push()
    sV = L.slider("体积 V", 0.3, 3, 0.01, 1, on_v, "L")
    sT = L.slider("温度 T", 100, 900, 1, 300, on_t, lambda v: f"{int(v)} K（{int(v) - 273} ℃）")

    def init_parts():
        T0 = S["st"]["T"]
        parts = []
        for _i in range(N):
            sp = math.sqrt(T0 / 300) * 120 * math.sqrt(-2 * math.log(random.random() or 1e-9)) * 0.8
            a = random.uniform(0, TAU)
            parts.append({"x": random.random(), "y": random.random(), "vx": sp * math.cos(a), "vy": sp * math.sin(a)})
        S["parts"] = parts

    def restore(_b):
        S["st"] = {"V": 1.0, "T": 300.0, "p": 1.0}
        sV.set(1, True)
        sT.set(300, True)
        init_parts()
        S["trace"] = [(1.0, 1.0)]
        L.draw()
    L.button("清除轨迹", lambda _b: (S.__setitem__("trace", [(S["st"]["V"], S["st"]["p"])]), L.draw()))
    L.button("恢复初态", restore)
    out = L.out()

    def sync():
        sV.el.setVisible(mode.v == "T")
        sT.el.setVisible(mode.v != "T")
    sync()
    init_parts()

    def tick(dt):
        bw = 160
        bh = S["st"]["V"] / 3 * (c.h - 80)
        for q in S["parts"]:
            q["x"] += q["vx"] * dt / bw
            q["y"] += q["vy"] * dt / bh
            if q["x"] < 0:
                q["x"], q["vx"] = -q["x"], -q["vx"]
            if q["x"] > 1:
                q["x"], q["vx"] = 2 - q["x"], -q["vx"]
            if q["y"] < 0:
                q["y"], q["vy"] = -q["y"], -q["vy"]
            if q["y"] > 1:
                q["y"], q["vy"] = 2 - q["y"], -q["vy"]
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        st = S["st"]
        bx, bw, by = 40, 160, c.h - 40
        bh = st["V"] / 3 * (c.h - 80)
        D.rect(g, bx - 4, 30, bw + 8, by - 30 + 4, None, T.fg, 2)
        D.rect(g, bx, by - bh - 14, bw, 14, T.muted)
        D.rect(g, bx + bw / 2 - 5, 30, 10, max(0, by - bh - 44), T.muted)
        D.rect(g, bx, by - bh, bw, bh, alpha(T.c2, min(0.25, (st["T"] - 100) / 3200)))
        for q in S["parts"]:
            D.circle(g, bx + q["x"] * bw, by - q["y"] * bh, 3, T.c1)
        gx = bx + bw + 60
        gw = c.w - gx - 20
        if gw > 120:
            iso = mode.v == "T"
            gh = (c.h - 80) / (1 if iso else 2) - (0 if iso else 20)
            ch = D.chart(g, gx, 30, gw, gh, [], title="p − V 图（atm, L）", xl="V", xmin=0, xmax=3.2, ymin=0, ymax=4)
            for TT in (200, 300, 450, 600, 900):
                pts = []
                V = 0.15
                while V <= 3.2:
                    pp = nR * TT / V
                    if pp <= 4:
                        pts.append((ch["X"](V), ch["Y"](pp)))
                    V += 0.02
                D.poly(g, pts, None, alpha(T.muted, 0.5), 1, False)
                D.text(g, f"{TT}K", ch["X"](3.1), ch["Y"](nR * TT / 3.1), T.muted, size=10)
            D.poly(g, [(ch["X"](q[0]), ch["Y"](min(q[1], 4))) for q in S["trace"]], None, T.c2, 2.2, False)
            D.circle(g, ch["X"](st["V"]), ch["Y"](min(st["p"], 4)), 5, T.c2)
            if not iso:
                isP = mode.v == "p"
                yv, mx = (st["V"], 3.2) if isP else (st["p"], 4)
                ch2 = D.chart(g, gx, 30 + gh + 40, gw, gh, [{"pts": [(-273, 0), (627, nR * 900 / (st["p"] if isP else st["V"]))], "color": alpha(T.muted, 0.7),
                                                           "dash": [4, 4], "w": 1.2}],
                              title="V − t 图（L, ℃）" if isP else "p − t 图（atm, ℃）", xl="t / ℃", xmin=-273, xmax=627, ymin=0, ymax=mx)
                D.circle(g, ch2["X"](st["T"] - 273), ch2["Y"](min(yv, mx)), 5, T.c2)
                D.text(g, "−273 ℃", ch2["X"](-273) + 2, ch2["Y"](0) - 10, T.muted, size=10)
        out.set([["压强 p", fmt(st["p"], 4) + " atm"], ["体积 V", fmt(st["V"], 4) + " L"], ["温度 T", f"{fmt(st['T'], 0)} K"],
                 ["pV/T", fmt(st["p"] * st["V"] / st["T"] * 300, 4) + " / 300"], ["分子平均速率（相对 300 K）", fmt(math.sqrt(st["T"] / 300), 3)],
                 ["单位体积分子数（相对）", fmt(1 / st["V"], 3)]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 光电效应
@lab.reg(id="p-photo", subj="phys", book=5, unit="原子结构和波粒二象性", title="光电效应", kw="光电效应 逸出功 截止频率 遏止电压 饱和电流 爱因斯坦光电效应方程 光子",
         info="<p class='fb'>光子能量 ε = hν　h = 6.63×10⁻³⁴ J·s<br>爱因斯坦光电效应方程 Eₖ = hν − W₀<br>遏止电压 eU_c = Eₖ　截止频率 ν_c = W₀/h</p>"
              "<p>能否发生光电效应只取决于光的频率，与光强无关；光强只决定单位时间内逸出的光电子数，也就是饱和电流的大小。"
              "Eₖ − ν 图像是一条斜率为 h 的直线，横截距是截止频率。</p>",
         tasks=["用钠做阴极，从红光开始减小波长，在多少纳米时开始有光电子？", "保持频率不变，只增大光强，遏止电压变吗？饱和电流呢？", "比较不同金属的 Eₖ − ν 图线，它们的斜率有什么共同点？"])
def p_photo(L):
    c = L.canvas()
    metals = [["2.13", "铷 Rb 2.13 eV"], ["2.25", "钾 K 2.25 eV"], ["2.29", "钠 Na 2.29 eV"], ["3.20", "钙 Ca 3.20 eV"], ["4.54", "钨 W 4.54 eV"]]
    mt = L.select("阴极金属（逸出功）", metals, "2.29")
    p = L.params({"lam": ["入射光波长 λ", 200, 700, 1, 400, "nm"], "I": ["光强", 0, 100, 1, 60, "%"], "U": ["两极电压 U（阳极 − 阴极）", -4, 4, 0.05, 1, "V"]})
    out = L.out()
    S = {"els": [], "acc": 0.0}

    def tick(dt):
        W = float(mt.v)
        Ek = 1240 / p.lam - W
        S["acc"] += dt * p.I * 0.6
        while S["acc"] > 1:
            S["acc"] -= 1
            if Ek > 0:
                e = Ek * random.random()
                S["els"].append({"x": 0.0, "y": random.uniform(0.15, 0.85), "v": math.sqrt(e) * 1.2 + 0.05, "vy": random.uniform(-0.1, 0.1)})
        for e in S["els"]:
            e["v"] += p.U * 0.5 * dt
            e["x"] += e["v"] * dt * 0.8
            e["y"] += e["vy"] * dt
        S["els"] = [e for e in S["els"] if 0 <= e["x"] <= 1 and 0 < e["y"] < 1]
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        W = float(mt.v)
        E = 1240 / p.lam
        Ek = E - W
        Uc, Isat = max(0, Ek), p.I / 100 * 10

        def cur(U):
            if Ek <= 0:
                return 0.0
            if U >= 0:
                return Isat * (1 - 0.3 * math.exp(-3 * U))
            return 0.0 if U <= -Uc else Isat * 0.7 * (1 - (-U) / Uc) ** 1.5
        tx, ty = 40, 40
        tw, th = min(c.w * 0.45, 360), c.h * 0.42
        D.rrect(g, tx, ty, tw, th, 40, alpha(T.muted, 0.06), T.fg, 1.5)
        cx, ax = tx + 40, tx + tw - 40
        D.rect(g, cx - 6, ty + 20, 10, th - 40, T.c1)
        D.rect(g, ax - 4, ty + 20, 10, th - 40, T.c2)
        D.text(g, "K 阴极", cx, ty + th + 14, T.c1, align="center", size=11)
        D.text(g, "A 阳极", ax, ty + th + 14, T.c2, align="center", size=11)
        col = wave_css(p.lam, 0.9)
        for k in range(round(p.I / 20)):
            y = ty + 30 + k * 20
            D.poly(g, [(cx - 80 + x + 6, y - 30 + x * 0.5 + math.sin(x * 0.6) * 3) for x in range(0, 70, 2)], None, col, 1.6, False)
        if p.lam < 380:
            D.text(g, "紫外线", cx - 70, ty + 12, T.muted, size=11)
        for e in S["els"]:
            D.circle(g, cx + e["x"] * (ax - cx), ty + 20 + e["y"] * (th - 40), 2.5, T.c3)
        gx = tx + tw + 50
        gw = c.w - gx - 20
        if gw > 140:
            Us = [-4 + i * 0.05 for i in range(161)]
            ch = D.chart(g, gx, 30, gw, c.h * 0.42 - 20, [{"pts": [(u, cur(u)) for u in Us], "color": T.c1, "w": 2.2}], title="I − U 曲线（相对）", xl="U / V",
                         xmin=-4, xmax=4, ymin=0, ymax=11)
            D.circle(g, ch["X"](p.U), ch["Y"](cur(p.U)), 5, T.c2)
            D.line(g, ch["X"](0), 30, ch["X"](0), 30 + c.h * 0.42 - 20, T.grid2, 1)
        series = [{"pts": [(n, max(-5, 4.1357 * n / 10 - float(w2))) for n in (0, 15)], "color": T.c2 if float(w2) == W else alpha(T.muted, 0.6),
                   "w": 2.4 if float(w2) == W else 1.2} for w2, _ in metals]
        ch2 = D.chart(g, 40, c.h * 0.58, c.w - 80, c.h * 0.38, series, title="Eₖ − ν 图像（eV，×10¹⁴ Hz）", xl="ν", xmin=0, xmax=15, ymin=-5, ymax=4)
        nu = 3e8 / (p.lam * 1e-9) / 1e14
        D.circle(g, ch2["X"](nu), ch2["Y"](max(-5, Ek)), 5, T.c2)
        out.set([["光子能量 hν", fmt(E, 3) + " eV"], ["频率 ν", fmt(nu, 3) + "×10¹⁴ Hz"], ["截止频率 ν_c", fmt(W / 4.1357 * 10, 3) + "×10¹⁴ Hz"],
                 ["截止波长", fmt(1240 / W, 1) + " nm"], ["最大初动能 Eₖ", fmt(Ek, 3) + " eV" if Ek > 0 else "不发生光电效应"],
                 ["遏止电压 U_c", fmt(Uc, 3) + " V" if Ek > 0 else "—"], ["当前光电流（相对）", fmt(cur(p.U), 3)]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 氢原子能级跃迁与光谱
@lab.reg(id="p-bohr", subj="phys", book=5, unit="原子结构和波粒二象性", title="氢原子能级跃迁与光谱", kw="玻尔模型 能级 跃迁 光谱 巴耳末系 电离 光子",
         info="<p class='fb'>Eₙ = E₁/n²，E₁ = −13.6 eV　轨道半径 rₙ = n²r₁<br>跃迁放出（吸收）光子：hν = E_m − E_n　λ = hc/ΔE ≈ 1240/ΔE（nm，ΔE 以 eV 为单位）<br>"
              "一群处于第 n 能级的氢原子向低能级跃迁，最多可发出 Cₙ² 种频率的光</p>"
              "<p>跃迁到 n = 1 的谱线属于赖曼系（紫外），到 n = 2 的属于巴耳末系（其中 4 条在可见光区），到 n = 3 的属于帕邢系（红外）。</p>",
         tasks=["从 n = 3 跃迁到 n = 2，放出光子的波长是多少？是什么颜色？", "一群处于 n = 4 的原子，最多能发出几种光？其中能量最大的是哪一条？",
                "用 12.09 eV 的光子照射基态氢原子，它能跃迁到第几能级？"])
def p_bohr(L):
    c = L.canvas()
    S = {"t0": time.perf_counter()}

    def E(n):
        return -13.6 / (n * n)

    def on_param(_k, _v):
        if p.lo >= p.hi:
            p.s("lo").set(p.hi - 1, True)
        S["t0"] = time.perf_counter()
        L.draw()
    p = L.params({"hi": ["初态 n（高能级）", 2, 7, 1, 3], "lo": ["末态 n（低能级）", 1, 6, 1, 2]}, on_param)
    allv = L.check("显示一群原子的全部谱线", False)
    out = L.out()
    L.loop(lambda _dt: L.draw())

    def vis(nm):
        return 380 <= nm <= 750

    def draw():
        c.clear()
        g = c.g
        hi, lo = int(p.hi), int(p.lo)
        lx, top = 50, 30
        lw, H = min(c.w * 0.45, 360), c.h - 140

        def YY(e):
            return top + H - (e + 13.6) / 13.6 * H
        for n in range(1, 8):
            y = YY(E(n))
            on = n in (hi, lo)
            D.line(g, lx, y, lx + lw, y, T.fg if on else T.grid2, 2 if on else 1.2)
            D.text(g, f"n={n}", lx - 6, y, T.muted, align="right", size=11)
            D.text(g, fmt(E(n), 2) + " eV", lx + lw + 6, y, T.muted, size=10.5, mono=True)
        D.line(g, lx, YY(0), lx + lw, YY(0), T.muted, 1, [4, 3])
        D.text(g, "n=∞  0 eV", lx + lw + 6, YY(0) - 10, T.muted, size=10.5)
        lines = [(a, b) for a in range(2, hi + 1) for b in range(1, a)] if allv.v else [(hi, lo)]
        for i, (a, b) in enumerate(lines):
            nm = 1240 / (E(a) - E(b))
            x = lx + 30 + (i + 0.5) * (lw - 60) / len(lines)
            D.arrow(g, x, YY(E(a)), x, YY(E(b)), wave_css(nm) if vis(nm) else T.muted, 2.2)
        sy, sx0 = c.h - 80, 40
        sw = c.w - 80

        def X(nm):
            return sx0 + (nm - 90) / (1900 - 90) * sw
        for nm in range(380, 751, 2):
            D.rect(g, X(nm), sy, X(nm + 2) - X(nm) + 0.5, 28, wave_css(nm, 0.25))
        D.rect(g, sx0, sy, sw, 28, None, T.line, 1)
        for a in range(2, 8):
            for b in range(1, a):
                nm = 1240 / (E(a) - E(b))
                if nm > 1900:
                    continue
                on = (a, b) in lines
                D.line(g, X(nm), sy, X(nm), sy + 28, (wave_css(nm) if vis(nm) else T.fg) if on else alpha(T.muted, 0.35), 3 if on else 1)
        for nm, t in ((100, "赖曼系（紫外）"), (420, "巴耳末系"), (1000, "帕邢系（红外）")):
            D.text(g, t, X(nm), sy + 42, T.muted, size=11)
        for nm in (100, 400, 700, 1000, 1500, 1875):
            D.text(g, f"{nm}nm", X(nm), sy - 8, T.muted, size=10, align="center", mono=True)
        ox, oy = lx + lw + 130, top + H / 2
        if c.w - ox > 120:
            rmax = min(c.w - ox - 20, H / 2)
            for n in range(1, 8):
                D.circle(g, ox, oy, rmax * n * n / 49, None, T.fg if n in (hi, lo) else T.grid2, 1)
            D.circle(g, ox, oy, 5, T.c2)
            tt = time.perf_counter() - S["t0"]
            n = hi if tt % 3 < 1.5 else lo
            r = rmax * n * n / 49
            D.circle(g, ox + r * math.cos(tt * 2), oy + r * math.sin(tt * 2), 4, T.c1)
        dE = E(hi) - E(lo)
        nm = 1240 / dE
        series = ["赖曼系", "巴耳末系", "帕邢系", "布拉开系", "普丰德系", "汉弗莱系"][lo - 1]
        out.set([["跃迁", f"n={hi} → n={lo}"], ["光子能量 ΔE", fmt(dE, 3) + " eV"], ["波长 λ", fmt(nm, 1) + " nm"], ["频率 ν", fmt(3e8 / (nm * 1e-9) / 1e14, 3) + "×10¹⁴ Hz"],
                 ["所属谱系", series], ["区域", "紫外" if nm < 380 else "红外" if nm > 750 else "可见光"], [f"n={hi} 一群原子谱线数 C({hi},2)", str(comb(hi, 2))],
                 ["基态电离能", "13.6 eV"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 放射性衰变与半衰期
@lab.reg(id="p-decay", subj="phys", book=5, unit="原子核", title="放射性衰变与半衰期", kw="半衰期 α衰变 β衰变 统计规律 核反应方程 质量数 电荷数",
         info="<p class='fb'>剩余原子核数 N = N₀(1/2)^(t/T½)<br>α 衰变：质量数减 4，电荷数减 2　β 衰变：质量数不变，电荷数加 1<br>衰变方程遵循质量数守恒和电荷数守恒</p>"
              "<p>半衰期是大量原子核衰变的统计规律，由原子核内部决定，与温度、压强、化学状态无关；对少数几个原子核没有意义。可以把原子核数改为 10 个，多做几次观察。</p>",
         tasks=["经过 3 个半衰期，剩余原子核占多少？与模拟比较。", "把原子核数设为 16，重复几次，每次到第一个半衰期时剩下的个数都是 8 吗？",
                "写出铀-238 经过一次 α 衰变和两次 β 衰变后的产物。"])
def p_decay(L):
    c = L.canvas()
    iso = {"c14": ["碳-14", "β", "5730 年", "¹⁴₆C → ¹⁴₇N + ⁰₋₁e"], "u238": ["铀-238", "α", "4.47×10⁹ 年", "²³⁸₉₂U → ²³⁴₉₀Th + ⁴₂He"],
           "i131": ["碘-131", "β", "8.02 天", "¹³¹₅₃I → ¹³¹₅₄Xe + ⁰₋₁e"], "rn222": ["氡-222", "α", "3.8 天", "²²²₈₆Rn → ²¹⁸₈₄Po + ⁴₂He"],
           "po210": ["钋-210", "α", "138 天", "²¹⁰₈₄Po → ²⁰⁶₈₂Pb + ⁴₂He"]}
    S = {"nuc": [], "t": 0.0, "hist": []}

    def reset(*_):
        S["nuc"] = [True] * int(n0.v)
        S["t"] = 0.0
        S["hist"] = [(0.0, len(S["nuc"]))]
        L.draw()
    is_ = L.select("同位素", [[k, f"{v[0]}（{v[1]} 衰变，T½ = {v[2]}）"] for k, v in iso.items()], "c14", reset)
    n0 = L.select("原子核数", [["400", "400"], ["100", "100"], ["16", "16"], ["10", "10"]], "400", reset)
    Th = L.slider("模拟中的半衰期", 1, 10, 0.5, 3, lambda _v: L.draw(), "s")

    def tick(dt):
        pr = 1 - 0.5 ** (dt / Th.v)
        nuc = S["nuc"]
        for i in range(len(nuc)):
            if nuc[i] and random.random() < pr:
                nuc[i] = False
        S["t"] += dt
        S["hist"].append((S["t"], sum(nuc)))
        if len(S["hist"]) > 1500:
            S["hist"] = S["hist"][::2]
        L.draw()
    run = L.loop(tick, False)
    L.button("开始 / 暂停", lambda _b: run.toggle(), True)
    L.button("重置", reset)
    out = L.out()
    reset()

    def draw():
        c.clear()
        g = c.g
        nuc, t = S["nuc"], S["t"]
        N = len(nuc)
        side = math.ceil(math.sqrt(N))
        box = min(c.w * 0.42, c.h - 60)
        cell = box / side
        ox = oy = 30
        for i, a in enumerate(nuc):
            D.circle(g, ox + (i % side + 0.5) * cell, oy + (i // side + 0.5) * cell, cell * 0.38, T.c2 if a else alpha(T.muted, 0.25))
        left = sum(nuc)
        gx = ox + box + 40
        gw = c.w - gx - 20
        if gw > 120:
            tm = max(Th.v * 5, t)
            ts = [tm * i / 100 for i in range(101)]
            ch = D.chart(g, gx, oy, gw, c.h - 2 * oy - 20, [{"pts": [(x, N * 0.5 ** (x / Th.v)) for x in ts], "color": T.muted, "dash": [5, 4], "w": 1.5},
                                                          {"pts": S["hist"], "color": T.c2, "w": 2.2}],
                         title="剩余原子核数 N − t", xl="t / s", xmin=0, xmax=tm, ymin=0, ymax=N * 1.05)
            k = 1
            while k * Th.v <= tm:
                x = ch["X"](k * Th.v)
                D.line(g, x, ch["Y"](0), x, ch["Y"](N * 0.5 ** k), T.grid2, 1, [2, 3])
                D.text(g, f"{k}T½", x, ch["Y"](0) + 12, T.muted, align="center", size=10)
                k += 1
        I = iso[is_.v]
        out.set([["衰变方程", I[3]], ["衰变类型", I[1] + " 衰变"], ["真实半衰期", I[2]], ["经过时间", fmt(t / Th.v, 2) + " 个半衰期"],
                 ["剩余（模拟）", f"{left} / {N}"], ["剩余（理论）", fmt(N * 0.5 ** (t / Th.v), 1)]])
    L.on_draw(draw)
