"""数学 · 选择性必修第二册（由 gewu/math.js 改写）：数列、导数。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import fmt
from ...kit.draw import D
from ...kit.expr import ExprError, compile_expr
from ...kit.registry import lab
from ...kit.view import View


def _ok(x) -> bool:
    return isinstance(x, (int, float)) and math.isfinite(x)


# ---------------------------------------------------------------- 数列
@lab.reg(id="m-seq", subj="math", book=3, unit="数列", title="数列与前 n 项和", kw="等差数列 等比数列 递推 蛛网图 求和",
         info="<p class='fb'>等差：aₙ = a₁ + (n−1)d，Sₙ = n(a₁ + aₙ)/2 = na₁ + n(n−1)d/2<br>等比：aₙ = a₁qⁿ⁻¹，Sₙ = a₁(1 − qⁿ)/(1 − q)（q ≠ 1）<br>"
              "|q| &lt; 1 时 Sₙ → a₁/(1 − q)</p><p>等差数列的点 (n, aₙ) 在一条直线上，Sₙ 是关于 n 的二次函数（d≠0）；等比数列的点在指数型曲线 y = (a₁/q)·qˣ 上。"
              "递推模式用「蛛网图」展示 aₙ₊₁ = f(aₙ) 的迭代是否收敛到不动点。</p>",
         tasks=["等差数列中让 d < 0，Sₙ 在第几项取最大值？与 aₙ 何时变号对照。", "等比数列取 q = −0.5，观察摆动收敛；取 q = 1.1 观察发散。",
                "递推模式输入 a/2 + 1/a（求 √2 的牛顿迭代），观察收敛速度。"])
def m_seq(L):
    c = L.canvas()
    v = View(c, 0, 21, -10, 30)
    vw = View(c, -1, 4, -1, 4, equal=True)
    S = {"F": compile_expr("a/2+1/a", ["a"])}
    L.group("数列类型")
    kind = L.seg("", [["ari", "等差"], ["geo", "等比"], ["rec", "递推"]], "ari", lambda _k: (sync(), L.draw()))
    p = L.params({"a1": ["首项 a₁", -10, 10, 0.5, 2], "d": ["公差 d", -3, 3, 0.1, 1.5], "q": ["公比 q", -2, 2, 0.05, 0.8], "n": ["项数 n", 1, 40, 1, 12]})

    def fin_cb(s, o):
        try:
            S["F"] = compile_expr(s, ["a"])
            o.err("")
        except ExprError as exc:
            S["F"] = None
            o.err(str(exc))
        L.draw()
    fin = L.input("aₙ₊₁ = f(a)，用 a 表示 aₙ", "a/2+1/a", fin_cb)
    out = L.out()

    def sync():
        k = kind.v
        p.s("d").el.setVisible(k == "ari")
        p.s("q").el.setVisible(k == "geo")
        fin.box.setVisible(k == "rec")
    sync()

    def draw():
        a1, d, q, n, k = p.a1, p.d, p.q, int(p.n), kind.v
        F = S["F"]
        c.clear()
        g = c.g
        terms = []
        for i in range(1, n + 1):
            if k == "ari":
                terms.append(a1 + (i - 1) * d)
            elif k == "geo":
                terms.append(a1 * q ** (i - 1))
            else:
                terms.append(a1 if i == 1 else (F(terms[-1]) if F and _ok(terms[-1]) else math.nan))
        Ss, acc = [], 0.0
        for x in terms:
            acc += x
            Ss.append(acc)
        fin2 = [x for x in terms if _ok(x)]
        if k == "rec":
            lo = min([0] + fin2) - 1
            hi = max([4] + [min(x, 1e3) for x in fin2]) + 1
            vw.r = [lo, hi, lo, hi]
            vw.pad = (0, c.w * 0.45, 0, 0)
            v.pad = (c.w * 0.58, 10, 20, 20)
            vw.fit()
            vw.grid(xl="aₙ", yl="aₙ₊₁")
            vw.plot(lambda x: x, T.muted, 1.2, [5, 4])
            if F:
                vw.plot(F, T.c1, 2.2)
            g.stroke_style, g.line_width = T.c2, 1.4
            g.begin_path()
            g.move_to(vw.X(terms[0]), vw.Y(0))
            for i in range(len(terms) - 1):
                if not _ok(terms[i + 1]):
                    break
                g.line_to(vw.X(terms[i]), vw.Y(terms[i + 1]))
                g.line_to(vw.X(terms[i + 1]), vw.Y(terms[i + 1]))
            g.stroke()
        else:
            v.pad = (40, 16, 20, 30)
        extra = Ss if k != "rec" else []
        vals = fin2 + [x for x in extra if _ok(x)]
        ymin, ymax = min([0] + vals), max([1] + vals)
        span = ymax - ymin
        v.r = [0, n + 1, ymin - span * 0.08, ymax + span * 0.08]
        v.fit()
        v.grid(xl="n", yl="")
        bw = max(2, min(18, v.sx * 0.5))
        for i, x in enumerate(terms):
            if not _ok(x):
                continue
            X = v.X(i + 1)
            D.rect(g, X - bw / 2, min(v.Y(0), v.Y(x)), bw, abs(v.Y(x) - v.Y(0)), alpha(T.c1, 0.7))
        if k != "rec":
            g.stroke_style, g.line_width = T.c2, 2
            g.begin_path()
            for i, s in enumerate(Ss):
                (g.line_to if i else g.move_to)(v.X(i + 1), v.Y(s))
            g.stroke()
            for i, s in enumerate(Ss):
                v.dot(i + 1, s, T.c2, 3)
        D.text(g, "■ aₙ", v.ox + 8, v.oy + 10, T.c1)
        if k != "rec":
            D.text(g, "● Sₙ", v.ox + 60, v.oy + 10, T.c2)
        an, Sn = terms[n - 1], Ss[n - 1]
        rows = [[f"aₙ（n={n}）", fmt(an, 4)]]
        if k == "ari":
            ext = (max(Ss) if d < 0 else min(Ss)) if d else None
            rows += [["通项", f"aₙ = {fmt(a1, 2)} + (n−1)·{fmt(d, 2)}"], ["Sₙ", fmt(Sn, 4)],
                     ["Sₙ 最值", "—" if d == 0 else ("最大值 " if d < 0 else "最小值 ") + fmt(ext, 3)]]
        elif k == "geo":
            rows += [["通项", f"aₙ = {fmt(a1, 2)}·{fmt(q, 2)}ⁿ⁻¹"], ["Sₙ", fmt(Sn, 4)],
                     ["极限 a₁/(1−q)", fmt(a1 / (1 - q), 4) if abs(q) < 1 else "|q| ≥ 1，不收敛"]]
        else:
            conv = n >= 2 and _ok(terms[n - 1]) and _ok(terms[n - 2]) and abs(terms[n - 1] - terms[n - 2]) < 1e-6
            rows += [["前几项", ", ".join(fmt(x, 4) for x in terms[:6])], ["收敛判断", "已收敛于 " + fmt(terms[n - 1], 6) if conv else "未收敛"]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 导数：割线到切线
@lab.reg(id="m-deriv", subj="math", book=3, unit="一元函数的导数及其应用", title="割线逼近切线与单调性", kw="导数 瞬时变化率 平均变化率 切线 单调区间 极值",
         info="<p><b>平均变化率</b> Δy/Δx = [f(x₀+Δx) − f(x₀)]/Δx 是割线斜率。当 Δx → 0 时它的极限就是导数 f′(x₀)，割线趋于切线。</p>"
              "<p class='fb'>f′(x) &gt; 0 的区间上 f(x) 单调递增；f′(x) &lt; 0 的区间上单调递减<br>f′(x₀) = 0 且两侧异号 ⇒ x₀ 为极值点</p>"
              "<p>下方小图是导函数 f′(x)，上方 x 轴上的色带表示单调性（绿：增，红：减）。</p>",
         tasks=["点「让 Δx → 0」，记录割线斜率的变化，看它趋于多少。", "对 x³ 在 x₀=0 处观察：f′(0)=0 但 0 不是极值点，为什么？",
                "比较 sin x 与它的导函数 cos x 的图像关系。"])
def m_deriv(L):
    c = L.canvas()
    v = View(c, -4, 4, -4, 4)
    v2 = View(c, -4, 4, -4, 4)
    S = {"F": compile_expr("x^3-3x"), "tw": False}
    L.group("函数")

    def fin_cb(s, o):
        try:
            S["F"] = compile_expr(s)
            o.err("")
        except ExprError as exc:
            S["F"] = None
            o.err(str(exc))
        L.draw()
    fin = L.input("f(x) =", "x^3-3x", fin_cb)
    L.select("预设", ["x^3-3x", "x^2", "x^3", "sin(x)", "e^x", "ln(x)", "1/x", "x*e^(-x)"], "x^3-3x", lambda s: fin.set(s))
    p = L.params({"x0": ["x₀", -3.5, 3.5, 0.05, 0.8], "h": ["Δx", -2.5, 2.5, 0.01, 1.5]})

    def restore(_b):
        S["tw"] = False
        p.h = 1.5
    L.button("让 Δx → 0", lambda _b: S.__setitem__("tw", True), True)
    L.button("Δx 复原", restore)
    mono = L.check("显示单调性色带", True)
    out = L.out()

    def tick(dt):
        if not S["tw"]:
            return
        nh = p.h * 0.25 ** dt
        if abs(nh) < 0.001:
            S["tw"] = False
            p.s("h").set(math.copysign(0.001, p.h))
        else:
            p.s("h").set(nh)
    L.loop(tick)

    def draw():
        c.clear()
        H = c.h
        v.pad = (0, 0, 0, H * 0.34)
        v2.pad = (0, 0, H * 0.7, 0)
        v.fit()
        v.grid()
        F = S["F"]
        if not F:
            return

        def d(x):
            return (F(x + 1e-5) - F(x - 1e-5)) / 2e-5
        x0, h = p.x0, p.h
        y0, y1 = F(x0), F(x0 + h)
        k = (y1 - y0) / h
        kt = d(x0)
        g = c.g
        if mono.v:
            px = 0
            while px < c.w:
                dd = d(v.ix(px))
                if _ok(dd):
                    D.rect(g, px, v.oy + v.H - 6, 3, 6, alpha(T.ok if dd > 0 else T.bad, 0.55))
                px += 3
        v.plot(F, T.c1, 2.4)
        v.plot(lambda x: y0 + k * (x - x0), T.c2, 1.6)
        v.plot(lambda x: y0 + kt * (x - x0), T.c3, 1.6, [6, 4])
        v.seg(x0, y0, x0 + h, y0, T.muted, 1.2, [3, 3])
        v.seg(x0 + h, y0, x0 + h, y1, T.muted, 1.2, [3, 3])
        v.label("Δx", x0 + h / 2, y0, T.muted, dy=12)
        v.label("Δy", x0 + h, (y0 + y1) / 2, T.muted)
        v.dot(x0, y0, T.c1, 5, True)
        v.dot(x0 + h, y1, T.c2, 5, True)
        D.line(g, 0, v2.oy - 8, c.w, v2.oy - 8, T.line, 1)
        v2.r = [v.r[0], v.r[1], -6, 6]
        v2.fit()
        v2.grid(yl="f′(x)")
        v2.plot(d, T.c3, 2)
        v2.dot(x0, kt, T.c3, 4.5, True)
        out.set([["f(x₀)", fmt(y0, 4)], ["割线斜率 Δy/Δx", fmt(k, 5)], ["切线斜率 f′(x₀)", fmt(kt, 5)], ["两者之差", fmt(k - kt, 5)],
                 ["x₀ 处单调性", "递增" if kt > 1e-6 else "递减" if kt < -1e-6 else "导数为 0"]])
        D.text(g, "— 割线", 10, 16, T.c2)
        D.text(g, "- - 切线", 70, 16, T.c3)
    L.on_draw(draw)
