"""物理 · 选择性必修第二册（由 gewu/phys2.js 改写）：电磁感应、交变电流、带电粒子在电磁场中的运动。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import PI, TAU, fmt, sci
from ...kit.draw import D
from ...kit.registry import lab
from .phys1 import resistor, wire


# ---------------------------------------------------------------- 导轨上的导体棒
@lab.reg(id="p-induct", subj="phys", book=4, unit="电磁感应", title="导轨上的导体棒（电磁感应）", kw="感应电动势 楞次定律 右手定则 安培力 收尾速度 能量转化",
         info="<p>磁场垂直纸面向里（×），导体棒在恒力 F 作用下沿光滑导轨运动，左端接电阻 R。</p>"
              "<p class='fb'>E = BLv　I = E/R = BLv/R　安培力 F 安 = BIL = B²L²v/R（阻碍相对运动）<br>a = (F − B²L²v/R)/m，速度增大时加速度减小，最终匀速：v_m = FR/(B²L²)<br>"
              "匀速时外力的功率全部转化为电阻上的焦耳热：Fv_m = I²R</p>",
         tasks=["F = 0，给棒一个初速度，它最终停下来时，动能去哪里了？", "加倍 B，收尾速度变为原来的几倍？", "用右手定则判断棒中电流方向，与图中箭头比较。"])
def p_induct(L):
    c = L.canvas()
    S = {}
    p = L.params({"B": ["磁感应强度 B", 0.1, 2, 0.05, 1, "T"], "Lr": ["导轨间距 L", 0.2, 1, 0.05, 0.5, "m"], "R": ["电阻 R", 0.2, 5, 0.1, 1, "Ω"],
                  "m": ["棒的质量 m", 0.05, 1, 0.05, 0.2, "kg"], "F": ["外力 F", 0, 3, 0.05, 1, "N"], "v0": ["初速度 v₀", 0, 10, 0.5, 0, "m/s"]},
                 lambda k, _v: reset() if k == "v0" else L.draw())

    def reset(*_):
        S.update(x=0.0, v=p.v0, t=0.0, hist=[(0.0, p.v0)], Q=0.0, W=0.0)
        L.draw()

    def tick(dt):
        n = 10
        h = dt / n
        for _i in range(n):
            Fa = p.B ** 2 * p.Lr ** 2 * S["v"] / p.R
            a = (p.F - Fa) / p.m
            S["Q"] += Fa * S["v"] * h
            S["W"] += p.F * S["v"] * h
            S["v"] += a * h
            S["x"] += S["v"] * h
            S["t"] += h
        S["hist"].append((S["t"], S["v"]))
        if len(S["hist"]) > 800:
            S["hist"].pop(0)
        L.draw()
    L.button("重新开始", reset, True)
    run = L.loop(tick)
    L.button("暂停 / 继续", lambda _b: run.toggle())
    out = L.out()
    reset()

    def draw():
        c.clear()
        g = c.g
        s = S
        top = 30
        H = c.h * 0.42
        y1, y2 = top + 20, top + H - 20
        x = 30
        while x < c.w:
            y = top + 6
            while y < top + H:
                D.text(g, "×", x, y, alpha(T.muted, 0.7), align="center", size=13)
                y += 34
            x += 34
        D.line(g, 50, y1, c.w - 10, y1, T.fg, 3)
        D.line(g, 50, y2, c.w - 10, y2, T.fg, 3)
        resistor(g, 50, y1, 50, y2, "R", T.c4)
        span = c.w - 180
        rx = 120 + ((s["x"] * 60) % span + span) % span
        D.rect(g, rx - 5, y1 - 8, 10, y2 - y1 + 16, T.c1)
        E = p.B * p.Lr * s["v"]
        I = E / p.R
        Fa = p.B * I * p.Lr
        if abs(I) > 1e-3:
            up = s["v"] > 0
            D.arrow(g, rx + 18, y2 - 20 if up else y1 + 20, rx + 18, y1 + 20 if up else y2 - 20, T.c2, 2.4)
            D.text(g, "I", rx + 26, (y1 + y2) / 2, T.c2, bold=True)
        fy = (y1 + y2) / 2 + 30
        if p.F > 0:
            D.arrow(g, rx, fy, rx + p.F * 30, fy, T.c3, 2.4)
            D.text(g, "F", rx + p.F * 30 + 4, fy - 10, T.c3, bold=True)
        if abs(Fa) > 1e-3:
            D.arrow(g, rx, fy + 22, rx - Fa * 30, fy + 22, T.c5, 2.4)
            D.text(g, "F 安", rx - Fa * 30 - 30, fy + 12, T.c5, bold=True)
        D.arrow(g, rx, top + 12, rx + s["v"] * 8, top + 12, T.fg, 2)
        D.text(g, "v", rx + s["v"] * 8 + 4, top + 4, T.fg)
        vm = p.F * p.R / (p.B * p.Lr) ** 2
        ch = D.chart(g, 50, top + H + 30, c.w - 80, c.h - top - H - 60, [{"pts": s["hist"], "color": T.c1, "w": 2.2}], title="v − t 图像（m/s）", xl="t / s",
                     xmin=s["hist"][0][0], xmax=max(1, s["t"]), ymin=0, ymax=max(vm, p.v0, 0.5) * 1.15)
        if p.F > 0:
            D.line(g, 50, ch["Y"](vm), c.w - 30, ch["Y"](vm), T.muted, 1, [5, 4])
            D.text(g, "收尾速度", c.w - 34, ch["Y"](vm) - 8, T.muted, align="right", size=11)
        out.set([["速度 v", fmt(s["v"], 3) + " m/s"], ["感应电动势 BLv", fmt(E, 3) + " V"], ["感应电流 I", fmt(I, 3) + " A"], ["安培力 BIL", fmt(Fa, 3) + " N"],
                 ["加速度", fmt((p.F - Fa) / p.m, 3) + " m/s²"], ["收尾速度 FR/(B²L²)", fmt(vm, 3) + " m/s" if p.F > 0 else "0（最终停下）"],
                 ["焦耳热 Q", fmt(s["Q"], 3) + " J"], ["外力做功 W", fmt(s["W"], 3) + " J"], ["W − Q = ΔEₖ", fmt(s["W"] - s["Q"], 3) + " J"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 交变电流与变压器
@lab.reg(id="p-ac", subj="phys", book=4, unit="交变电流", title="交流发电机、变压器与远距离输电", kw="交变电流 中性面 峰值 有效值 变压器 匝数比 输电损耗",
         info="<p class='fb'>从中性面开始计时：e = Eₘ sin ωt，Eₘ = NBSω<br>正弦交流有效值 E = Eₘ/√2，T = 2π/ω<br>理想变压器：U₁/U₂ = n₁/n₂，I₁/I₂ = n₂/n₁，P₁ = P₂<br>"
              "输电线损耗 P 损 = I²r = (P/U)²r，电压提高到 k 倍，损耗降为 1/k²</p>"
              "<p>线圈平面与磁感线垂直时为中性面：磁通量最大，感应电动势为零；线圈平面与磁感线平行时磁通量为零，电动势最大。</p>",
         tasks=["在发电机模式暂停在中性面位置，读出 Φ 和 e。", "变压器：n₁ = 1100、n₂ = 55、U₁ = 220 V，副线圈电压是多少？负载变小时原线圈电流如何变化？",
                "输电：把输电电压从 10 kV 提到 100 kV，损耗变为原来的多少？"])
def p_ac(L):
    c = L.canvas()
    S = {"t": 0.0}
    L.group("模式")
    mode = L.seg("", [["gen", "发电机"], ["tr", "变压器"], ["tx", "远距离输电"]], "gen", lambda _m: (sync(), L.draw()))
    p = L.params({"N": ["线圈匝数 N", 10, 200, 10, 100], "B": ["B", 0.05, 1, 0.05, 0.2, "T"], "S": ["线圈面积 S", 0.01, 0.1, 0.005, 0.05, "m²"],
                  "f": ["转速（频率）", 0.1, 2, 0.05, 0.5, "Hz"], "n1": ["原线圈匝数 n₁", 100, 2000, 50, 1100], "n2": ["副线圈匝数 n₂", 10, 2000, 5, 55],
                  "U1": ["原线圈电压 U₁", 10, 400, 10, 220, "V"], "RL": ["负载电阻 R", 1, 100, 1, 10, "Ω"], "P": ["输送功率 P", 10, 1000, 10, 200, "kW"],
                  "Ut": ["输电电压 U", 1, 500, 1, 10, "kV"], "r": ["输电线电阻 r", 1, 50, 1, 10, "Ω"]})

    def tick(dt):
        S["t"] += dt
        L.draw()
    run = L.loop(tick)
    L.button("暂停 / 继续", lambda _b: run.toggle())
    out = L.out()

    def sync():
        show = {"gen": ["N", "B", "S", "f"], "tr": ["n1", "n2", "U1", "RL"], "tx": ["P", "Ut", "r"]}[mode.v]
        for k in p.keys():
            p.s(k).el.setVisible(k in show)
    sync()

    def draw():
        c.clear()
        g = c.g
        m, t = mode.v, S["t"]
        rows = []
        if m == "gen":
            w = TAU * p.f
            th = w * t
            Em = p.N * p.B * p.S * w
            cx, cy = c.w * 0.25, c.h * 0.32
            R = min(c.w * 0.18, c.h * 0.22)
            D.rect(g, cx - R - 50, cy - R - 10, 30, 2 * R + 20, alpha(T.c2, 0.8))
            D.text(g, "N", cx - R - 35, cy, "#ffffff", align="center", bold=True)
            D.rect(g, cx + R + 20, cy - R - 10, 30, 2 * R + 20, alpha(T.c1, 0.8))
            D.text(g, "S", cx + R + 35, cy, "#ffffff", align="center", bold=True)
            for k in range(-3, 4):
                D.arrow(g, cx - R - 20, cy + k * R / 3.4, cx + R + 18, cy + k * R / 3.4, alpha(T.muted, 0.45), 1, 6)
            ex = R * math.sin(th)
            D.line(g, cx - ex * 0.9, cy - R * 0.8, cx + ex * 0.9, cy - R * 0.8, T.fg, 1)
            D.poly(g, [(cx - ex, cy - R * 0.75), (cx + ex, cy - R * 0.75), (cx + ex, cy + R * 0.75), (cx - ex, cy + R * 0.75)], alpha(T.c4, 0.25), T.c4, 3)
            D.line(g, cx, cy - R - 20, cx, cy + R + 20, T.muted, 1, [4, 4])
            D.text(g, "线圈（正视，绕虚线转动）", cx, cy + R + 34, T.muted, align="center", size=11)
            Phi = p.B * p.S * math.cos(th)
            e = Em * math.sin(th)
            ts = [t - 2 / p.f + i * (2 / p.f) / 199 for i in range(200)]
            gx = c.w * 0.52
            gw, gh = c.w - gx - 20, c.h * 0.4 - 30
            D.chart(g, gx, 20, gw, gh, [{"pts": [(x, p.B * p.S * math.cos(w * x)) for x in ts], "color": T.c3, "w": 2}], title="磁通量 Φ − t（Wb）",
                    xmin=ts[0], xmax=t, ymin=-p.B * p.S * 1.2, ymax=p.B * p.S * 1.2)
            D.chart(g, gx, gh + 50, gw, gh, [{"pts": [(x, Em * math.sin(w * x)) for x in ts], "color": T.c2, "w": 2}], title="电动势 e − t（V）", xl="t / s",
                    xmin=ts[0], xmax=t, ymin=-Em * 1.2, ymax=Em * 1.2)
            ph = th % TAU
            pos = "中性面附近" if abs(math.sin(ph)) < 0.08 else "与磁感线平行" if abs(math.cos(ph)) < 0.08 else "—"
            rows = [["峰值 Eₘ = NBSω", fmt(Em, 3) + " V"], ["有效值 Eₘ/√2", fmt(Em / math.sqrt(2), 3) + " V"], ["周期 T", fmt(1 / p.f, 3) + " s"],
                    ["瞬时 Φ", fmt(Phi, 4) + " Wb"], ["瞬时 e", fmt(e, 3) + " V"], ["位置", pos]]
            D.text(g, f"e = {fmt(Em, 2)} sin({fmt(w, 2)}t) V", 16, c.h - 16, T.fg, mono=True)
        elif m == "tr":
            U2 = p.U1 * p.n2 / p.n1
            I2 = U2 / p.RL
            I1 = I2 * p.n2 / p.n1
            cx, cy = c.w / 2, c.h * 0.42
            cw, chh = min(260, c.w * 0.4), min(200, c.h * 0.5)
            D.rect(g, cx - cw / 2, cy - chh / 2, cw, chh, None, T.muted, 22)

            def coil(x, n, col):
                k = max(3, min(24, round(n / 60)))
                for i in range(k):
                    y = cy - chh * 0.35 + i * chh * 0.7 / ((k - 1) or 1)
                    D.line(g, x - 18, y, x + 18, y + 3, col, 2.2)
            coil(cx - cw / 2, p.n1, T.c1)
            coil(cx + cw / 2, p.n2, T.c2)
            wire(g, [(cx - cw / 2 - 18, cy - chh * 0.35), (cx - cw / 2 - 80, cy - chh * 0.35), (cx - cw / 2 - 80, cy + chh * 0.35), (cx - cw / 2 - 18, cy + chh * 0.35)])
            D.circle(g, cx - cw / 2 - 80, cy, 14, T.stage, T.fg)
            D.text(g, "~", cx - cw / 2 - 80, cy, T.fg, align="center", size=18)
            wire(g, [(cx + cw / 2 + 18, cy - chh * 0.35), (cx + cw / 2 + 80, cy - chh * 0.35), (cx + cw / 2 + 80, cy + chh * 0.35), (cx + cw / 2 + 18, cy + chh * 0.35)])
            D.rect(g, cx + cw / 2 + 70, cy - 22, 20, 44, T.stage, T.c4, 2)
            D.text(g, "R", cx + cw / 2 + 96, cy, T.fg)
            D.text(g, f"n₁ = {int(p.n1)}", cx - cw / 2, cy + chh / 2 + 26, T.c1, align="center")
            D.text(g, f"n₂ = {int(p.n2)}", cx + cw / 2, cy + chh / 2 + 26, T.c2, align="center")
            kind = "升压变压器" if p.n2 > p.n1 else "降压变压器" if p.n2 < p.n1 else "1 : 1"
            rows = [["变压比 n₁ : n₂", f"{int(p.n1)} : {int(p.n2)}"], ["类型", kind], ["副线圈电压 U₂", fmt(U2, 3) + " V"], ["副线圈电流 I₂", fmt(I2, 3) + " A"],
                    ["原线圈电流 I₁", fmt(I1, 4) + " A"], ["输入功率 = 输出功率", fmt(U2 * I2, 3) + " W"]]
        else:
            P, U = p.P * 1e3, p.Ut * 1e3
            I = P / U
            loss = I * I * p.r
            eta = 1 - loss / P
            Us = [1 + i * 5 for i in range(100)]
            chh = D.chart(g, 60, 40, c.w - 100, c.h - 100, [{"pts": [(u, min(100, (P / (u * 1e3)) ** 2 * p.r / P * 100)) for u in Us], "color": T.c2, "w": 2.2}],
                          title="损耗占输送功率的百分比（%）", xl="输电电压 / kV", xmin=1, xmax=500, ymin=0, ymax=100)
            D.circle(g, chh["X"](p.Ut), chh["Y"](min(100, loss / P * 100)), 6, T.c1)
            rows = [["输电电流 I = P/U", fmt(I, 3) + " A"], ["线路损耗 I²r", fmt(loss / 1e3, 4) + " kW"], ["线路压降 Ir", fmt(I * p.r, 2) + " V"],
                    ["输电效率", fmt(eta * 100, 3) + " %" if eta > 0 else "损耗超过输送功率"], ["电压升高 10 倍后损耗", fmt(loss / 100 / 1e3, 5) + " kW"]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 带电粒子在电场和磁场中的运动
@lab.reg(id="p-charge", subj="phys", book=4, unit="安培力与洛伦兹力", title="带电粒子在电场和磁场中的运动",
         kw="洛伦兹力 示波管 偏转 圆周运动 速度选择器 质谱仪 回旋加速器 加速电场",
         info="<p class='fb'>电场中偏转（类平抛）：a = qU/(md)，飞出时偏移 y = qUL²/(2mdv₀²)<br>洛伦兹力 F = qvB，匀强磁场中做匀速圆周运动：r = mv/(qB)，T = 2πm/(qB)（与速度无关）<br>"
              "速度选择器：qE = qvB，只有 v = E/B 的粒子沿直线通过<br>质谱仪：先经电压 U 加速，r = (1/B)√(2mU/q)，不同质量落点不同<br>"
              "回旋加速器：交变电压频率 f = qB/(2πm)，最大动能 Eₖ = q²B²R²/(2m)，与加速电压无关</p>",
         tasks=["偏转模式：找出电子恰好打在极板边缘时的偏转电压。", "磁场模式：只改变速度，粒子在磁场中运动的时间变吗？",
                "速度选择器：让 E 加倍，要让同一粒子仍直线通过，B 应怎样调？", "回旋加速器：减小加速电压，粒子最终动能变吗？加速次数呢？"])
def p_charge(L):
    c = L.canvas()
    qe, me, u = 1.602e-19, 9.109e-31, 1.6605e-27
    S = {"path": [], "t": 0.0, "extra": {}}
    L.group("模式")
    mode = L.select("", [["def", "电场中的加速与偏转"], ["mag", "匀强磁场中的圆周运动"], ["sel", "速度选择器"], ["ms", "质谱仪"], ["cyc", "回旋加速器"]], "def",
                    lambda _v: (sync(), reset()))
    p = L.params({"U": ["偏转电压 U", 0, 400, 5, 120, "V"], "v0": ["入射速度 v₀", 0.5, 4, 0.05, 1.5, "×10⁷ m/s"], "B": ["磁感应强度 B", 0.2, 5, 0.05, 1.5, "mT"],
                  "th": ["入射方向与边界夹角", 10, 170, 1, 90, "°"], "sg": ["粒子电性", -1, 1, 2, -1, "", 0], "E": ["电场强度 E", 1, 40, 0.5, 15, "×10³ V/m"],
                  "Bs": ["B（选择器）", 0.5, 5, 0.05, 1, "mT"], "Ua": ["加速电压 U", 100, 2000, 50, 1000, "V"], "Bm": ["B（质谱仪）", 0.05, 0.5, 0.01, 0.2, "T"],
                  "Uc": ["D 形盒间电压", 0.2, 3, 0.1, 1, "×相对"], "Rc": ["D 形盒半径", 0.5, 1, 0.05, 0.9, "×相对"]}, lambda _k, _v: reset())
    out = L.out()

    def sync():
        show = {"def": ["U", "v0"], "mag": ["B", "v0", "th", "sg"], "sel": ["E", "Bs"], "ms": ["Ua", "Bm"], "cyc": ["Uc", "Rc"]}[mode.v]
        for k in p.keys():
            p.s(k).el.setVisible(k in show)

    def compute():
        m = mode.v
        path, ex = [], {}
        if m == "def":
            Lp, d, Ls = 0.05, 0.02, 0.10
            v0 = p.v0 * 1e7
            a = qe * p.U / (me * d)
            tL = Lp / v0
            hit = None
            for i in range(61):
                t = tL * i / 60
                y = 0.5 * a * t * t
                if y > d / 2:
                    hit = (v0 * t, d / 2)
                    break
                path.append((v0 * t, y))
            if not hit:
                y1, vy = 0.5 * a * tL * tL, a * tL
                for i in range(1, 41):
                    t = Ls / v0 * i / 40
                    path.append((Lp + v0 * t, y1 + vy * t))
                ex = {"y1": y1, "Y": y1 + vy * Ls / v0, "ang": math.atan(vy / v0)}
            else:
                path.append(hit)
                ex = {"hit": True}
            ex.update(Lp=Lp, d=d, Ls=Ls)
        elif m == "mag":
            q = p.sg * qe
            v, B = p.v0 * 1e7, p.B * 1e-3
            r = me * v / (abs(q) * B)
            ang = p.th * PI / 180
            x = y = 0.0
            vx, vy = v * math.sin(ang), v * math.cos(ang)
            dt = 2 * PI * me / (abs(q) * B) / 400
            path.append((x, y))
            for _i in range(800):
                ax, ay = q / me * (vy * -B), q / me * (-vx * -B)
                vx += ax * dt
                vy += ay * dt
                n = math.hypot(vx, vy)
                vx, vy = vx * v / n, vy * v / n
                x += vx * dt
                y += vy * dt
                path.append((x, y))
                if x < 0:
                    break
            ex = {"r": r, "T": 2 * PI * me / (abs(q) * B), "frac": (len(path) - 1) / 400}
        elif m == "sel":
            ex = {"v0": p.E * 1e3 / (p.Bs * 1e-3)}
        elif m == "ms":
            ions = []
            for A in (12, 13, 14):
                mm = A * u
                vv = math.sqrt(2 * qe * p.Ua / mm)
                ions.append({"A": A, "r": mm * vv / (qe * p.Bm), "v": vv})
            ex = {"ions": ions}
        else:
            R, dU = p.Rc, p.Uc * 0.004
            vv, x, y, dirn, k = 0.02, 0.0, 0.0, 1, 0
            path.append((0.0, 0.0))
            while k < 400:
                r = vv
                cx, cy = x, y + dirn * r
                for i in range(1, 31):
                    a = PI * i / 30
                    path.append((cx + dirn * r * math.sin(a), cy - dirn * r * math.cos(a)))
                x, y = path[-1]
                if r >= R:
                    break
                vv = math.sqrt(vv * vv + 2 * dU)
                dirn = -dirn
                k += 1
            ex = {"passes": k, "R": R}
        S["path"], S["extra"] = path, ex

    def reset(*_):
        S["t"] = 0.0
        compute()
        L.draw()
    sync()
    compute()

    def tick(dt):
        S["t"] += dt
        L.draw()
    L.loop(tick)
    SUP = ["²", "³", "⁴"]

    def draw():
        c.clear()
        g = c.g
        m, path, ex, tA = mode.v, S["path"], S["extra"], S["t"]
        rows = []

        def along(P, X, Y, col, speed=60):
            n = min(len(P), int(tA * speed) + 1)
            D.poly(g, [(X(q[0]), Y(q[1])) for q in P[:n]], None, col, 2, False)
            if n:
                e = P[n - 1]
                D.circle(g, X(e[0]), Y(e[1]), 5, col, T.stage, 1.5)
        if m == "def":
            Lp, d, Ls = ex["Lp"], ex["d"], ex["Ls"]
            sc = (c.w - 80) / (Lp + Ls)

            def X(x):
                return 40 + x * sc

            def Y(y):
                return c.h / 2 - y * sc
            D.rect(g, X(0), Y(d / 2) - 8, Lp * sc, 8, T.c2)
            D.rect(g, X(0), Y(-d / 2), Lp * sc, 8, T.c1)
            D.text(g, "+", X(Lp / 2), Y(d / 2) - 18, T.c2, align="center", bold=True)
            D.text(g, "−", X(Lp / 2), Y(-d / 2) + 20, T.c1, align="center", bold=True)
            D.line(g, X(Lp + Ls), 20, X(Lp + Ls), c.h - 20, T.fg, 4)
            D.text(g, "荧光屏", X(Lp + Ls) - 8, 20, T.muted, align="right", size=11)
            D.line(g, X(0) - 30, Y(0), X(Lp + Ls), Y(0), T.grid2, 1, [4, 4])
            along(path, X, Y, T.c3, 40)
            hit = ex.get("hit")
            rows = [["粒子", "电子（向正极板偏转）"], ["极板长 / 间距", "5 cm / 2 cm"], ["飞出偏移 y", "打在极板上" if hit else fmt(ex["y1"] * 100, 3) + " cm"],
                    ["偏转角", "—" if hit else fmt(ex["ang"] * 180 / PI, 2) + "°"], ["屏上偏移", "—" if hit else fmt(ex["Y"] * 100, 3) + " cm"],
                    ["恰好飞出的电压", fmt(me * (p.v0 * 1e7) ** 2 * d * d / (qe * Lp * Lp), 1) + " V"]]
        elif m == "mag":
            r = ex["r"]
            sc = min((c.w - 80) / (2.4 * r), (c.h - 40) / (2.4 * r))
            ys = [q[1] for q in path]
            yc = (min(ys) + max(ys)) / 2

            def X(x):
                return 40 + x * sc

            def Y(y):
                return c.h / 2 - (y - yc) * sc
            D.rect(g, X(0), 0, c.w - X(0), c.h, alpha(T.c1, 0.06))
            x = X(0) + 20
            while x < c.w:
                y = 16
                while y < c.h:
                    D.text(g, "×", x, y, alpha(T.muted, 0.6), align="center")
                    y += 32
                x += 32
            D.line(g, X(0), 0, X(0), c.h, T.fg, 1.5)
            along(path, X, Y, T.c2 if p.sg > 0 else T.c3, 120)
            chord = math.hypot(*path[-1]) if len(path) > 1 else 0
            rows = [["粒子", "正电子（+e）" if p.sg > 0 else "电子（−e）"], ["半径 r = mv/(qB)", fmt(r * 100, 3) + " cm"], ["周期 T = 2πm/(qB)", sci(ex["T"], 3) + " s"],
                    ["在磁场中转过", fmt(ex["frac"] * 360, 1) + "°"], ["在磁场中的时间", sci(ex["frac"] * ex["T"], 3) + " s"], ["出射点与入射点距离", fmt(chord * 100, 3) + " cm"]]
        elif m == "sel":
            x0, x1 = 40, c.w - 40
            yt, yb = c.h / 2 - 50, c.h / 2 + 50
            D.rect(g, x0 + 60, yt - 8, x1 - x0 - 120, 8, T.c2)
            D.rect(g, x0 + 60, yb, x1 - x0 - 120, 8, T.c1)
            x = x0 + 80
            while x < x1 - 60:
                D.text(g, "×", x, c.h / 2 - 25, alpha(T.muted, 0.7), align="center")
                D.text(g, "×", x, c.h / 2 + 25, alpha(T.muted, 0.7), align="center")
                x += 32
            D.rect(g, x1 - 50, c.h / 2 - 50, 6, 44, T.fg)
            D.rect(g, x1 - 50, c.h / 2 + 6, 6, 44, T.fg)
            for i, k in enumerate((0.6, 0.8, 1, 1.25, 1.6)):
                K, sc = 0.8, x1 - x0 - 120
                pts = []
                x = y = 0.0
                vx, vy = k, 0.0
                dt = 1 / k / 300
                for _j in range(600):
                    if x >= 1:
                        break
                    ax, ay = -K * vy, -K + K * vx
                    vx += ax * dt
                    vy += ay * dt
                    x += vx * dt
                    y += vy * dt
                    pts.append((x0 + 60 + x * sc, c.h / 2 - y * sc))
                    if abs(y * sc) > 50:
                        break
                D.poly(g, [(x0, c.h / 2)] + pts, None, T.c[i], 2.6 if k == 1 else 1.4, False)
                e = pts[-1]
                D.text(g, f"{k:g}v₀", e[0] + 6, e[1], T.c[i], size=11)
            rows = [["粒子", "质子（多种速度）"], ["可通过的速度 v = E/B", sci(ex["v0"], 3) + " m/s"], ["电场力方向", "向下"], ["洛伦兹力方向（v 向右）", "向上"],
                    ["说明", "速度大于 E/B 的向洛伦兹力方向偏，小于的向电场力方向偏"]]
        elif m == "ms":
            ions = ex["ions"]
            rmax = max(i["r"] for i in ions)
            sc = min((c.w - 120) / (2 * rmax), (c.h - 120) / rmax)
            ox, oy = 60, 60
            D.rect(g, 0, oy, c.w, c.h - oy, alpha(T.c1, 0.06))
            D.line(g, 0, oy, c.w, oy, T.fg, 3)
            D.text(g, f"加速电场 U = {fmt(p.Ua, 0)} V", ox + 10, 24, T.muted, size=12)
            D.line(g, ox - 10, 8, ox - 10, oy - 6, T.fg, 2)
            D.line(g, ox + 10, 8, ox + 10, oy - 6, T.fg, 2)
            for i, ion in enumerate(ions):
                pts = [(ox + ion["r"] * sc * (1 - math.cos(PI * k / 60)), oy + ion["r"] * sc * math.sin(PI * k / 60)) for k in range(61)]
                n = min(61, int(tA * 30) + 1)
                D.poly(g, pts[:n], None, T.c[i + 1], 2, False)
                D.circle(g, ox + 2 * ion["r"] * sc, oy, 4, T.c[i + 1])
                D.text(g, f"¹{SUP[i]}C⁺", ox + 2 * ion["r"] * sc, oy - 14, T.c[i + 1], align="center", size=12)
            rows = [[f"¹{SUP[i['A'] - 12]}C⁺ 半径", fmt(i["r"] * 100, 3) + " cm"] for i in ions]
            rows += [["落点间距（12→13）", fmt(2 * (ions[1]["r"] - ions[0]["r"]) * 100, 3) + " cm"], ["规律", "r ∝ √m，质量越大半径越大"]]
        else:
            sc = min(c.w, c.h) * 0.45
            cx, cy = c.w / 2, c.h / 2
            R, gap = ex["R"] * sc, 6
            for sgn, a0 in ((-1, PI / 2), (1, -PI / 2)):
                g.fill_style = alpha(T.c1, 0.12)
                g.begin_path()
                g.arc(cx + sgn * gap, cy, R, a0, a0 + PI)
                g.close_path()
                g.fill()
                g.stroke_style, g.line_width = T.fg, 1.5
                g.stroke()
            ys = [q[1] for q in path]
            yc = (min(ys) + max(ys)) / 2
            along(path, lambda x: cx + x * sc, lambda y: cy + (y - yc) * sc, T.c2, 240)
            rows = [["加速次数（过缝）", str(ex["passes"])], ["交变电压频率", "f = qB/(2πm)，与回旋频率相同"], ["最大动能", "Eₖ = q²B²R²/(2m)"],
                    ["现象", "电压越小，加速次数越多，但最终动能不变"]]
        out.set(rows)
    L.on_draw(draw)
