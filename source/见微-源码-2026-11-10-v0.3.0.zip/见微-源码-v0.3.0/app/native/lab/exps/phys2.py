"""物理 · 必修第二册（由 gewu/phys.js 改写）：抛体、圆周运动、万有引力、机械能。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import PI, TAU, clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab
from ...kit.view import View


# ---------------------------------------------------------------- 平抛与斜抛
@lab.reg(id="p-proj", subj="phys", book=1, unit="抛体运动", title="平抛与斜抛运动", kw="运动的合成与分解 平抛 斜抛 射程 空气阻力",
         info="<p>抛体运动可分解为水平方向的匀速直线运动和竖直方向的匀变速直线运动。</p><p class='fb'>平抛：x = v₀t，y = ½gt²，落地时间 t = √(2h/g)<br>"
              "斜抛：vₓ = v₀cos θ，v_y = v₀sin θ − gt<br>地面斜抛射程 R = v₀² sin 2θ / g，θ = 45° 时最大</p>"
              "<p>勾选空气阻力后，阻力 f = kv² 与速度反向，轨迹不再对称，最大射程角小于 45°。</p>",
         tasks=["h = 0 时依次发射 30° 与 60°，两者射程有什么关系？", "平抛时改变 v₀，落地时间变吗？", "打开空气阻力，找出射程最远的抛射角。"])
def p_proj(L):
    c = L.canvas()
    v = View(c, -2, 40, -2, 20, equal=True, pad=(10, 10, 10, 10))
    S = {"trails": [], "cur": None}

    def on_param(_k, _v):
        if not S["cur"]:
            fit_view()
        L.draw()
    p = L.params({"v0": ["初速度 v₀", 1, 30, 0.5, 15, "m/s"], "th": ["抛射角 θ", -30, 90, 1, 45, "°"], "h": ["抛出高度 h", 0, 30, 0.5, 0, "m"],
                  "g": ["重力加速度 g", 1, 20, 0.1, 9.8, "m/s²"], "k": ["阻力系数 k/m", 0, 0.1, 0.002, 0.02]}, on_param)
    drag = L.check("考虑空气阻力", False, lambda _v: (fit_view(), L.draw()))

    def fit_view():
        th = p.th * PI / 180
        vx, vy = p.v0 * math.cos(th), p.v0 * math.sin(th)
        tf = (vy + math.sqrt(vy * vy + 2 * p.g * p.h)) / p.g
        R, Hh = vx * tf, p.h + max(0, vy * vy / (2 * p.g))
        v.r = [-2, max(10, R * 1.1), -1, max(6, Hh * 1.2)]
        v.home = list(v.r)

    def launch(*_):
        th = p.th * PI / 180
        cur = {"pts": [(0, p.h)], "x": 0.0, "y": p.h, "vx": p.v0 * math.cos(th), "vy": p.v0 * math.sin(th), "t": 0.0, "maxH": p.h,
               "drag": drag.v, "k": p.k, "g": p.g}
        S["cur"] = cur
        S["trails"].append(cur)
        if len(S["trails"]) > 6:
            S["trails"].pop(0)

    def flat(_b):
        p.s("th").set(0, True)
        p.h = 20

    def deg45(_b):
        p.s("h").set(0, True)
        p.th = 45
    L.button("发射", launch, True)
    L.button("清除轨迹", lambda _b: (S.__setitem__("trails", []), L.draw()))
    L.button("平抛", flat)
    L.button("45°", deg45)
    comp = L.check("显示速度分量", True)
    out = L.out()
    fit_view()
    L.interact(c, view=v)

    def tick(dt):
        cur = S["cur"]
        if not cur:
            return
        sub = 20
        h = dt / sub
        for _i in range(sub):
            sp = math.hypot(cur["vx"], cur["vy"])
            ax = -cur["k"] * sp * cur["vx"] if cur["drag"] else 0.0
            ay = -cur["g"] - (cur["k"] * sp * cur["vy"] if cur["drag"] else 0.0)
            cur["vx"] += ax * h
            cur["vy"] += ay * h
            cur["x"] += cur["vx"] * h
            cur["y"] += cur["vy"] * h
            cur["t"] += h
            cur["maxH"] = max(cur["maxH"], cur["y"])
            if cur["y"] <= 0 and cur["t"] > 0.01:
                lx, ly = cur["pts"][-1]
                f = cur["y"] / ((cur["y"] - ly) or 1)
                cur["x"] -= (cur["x"] - lx) * f
                cur["y"] = 0.0
                cur["pts"].append((cur["x"], 0.0))
                S["cur"] = None
                break
        if S["cur"]:
            cur["pts"].append((cur["x"], cur["y"]))
        L.draw()
    L.loop(tick)

    def draw():
        v.begin(xl="x / m", yl="y / m")
        g = c.g
        D.rect(g, 0, v.Y(0), c.w, c.h - v.Y(0), alpha(T.c4, 0.1))
        if p.h > 0:
            D.rect(g, v.X(-1.5), v.Y(p.h), v.X(0) - v.X(-1.5), v.Y(0) - v.Y(p.h), alpha(T.muted, 0.2), T.muted, 1)
        th = p.th * PI / 180
        v.vec(0, p.h, math.cos(th) * 3, p.h + math.sin(th) * 3, T.muted, 1.5)
        cur = S["cur"]
        for i, tr in enumerate(S["trails"]):
            col = T.c[i % 6]
            D.poly(g, [v.P(*q) for q in tr["pts"]], None, col, 2.4 if tr is cur else 1.6, False)
            e = tr["pts"][-1]
            v.dot(e[0], e[1], col, 6 if tr is cur else 3.5, tr is cur)
            if tr is cur and comp.v:
                s = 0.25
                v.vec(e[0], e[1], e[0] + tr["vx"] * s, e[1], T.c2, 2)
                v.vec(e[0], e[1], e[0], e[1] + tr["vy"] * s, T.c3, 2)
                v.vec(e[0], e[1], e[0] + tr["vx"] * s, e[1] + tr["vy"] * s, T.fg, 2)
        vx, vy = p.v0 * math.cos(th), p.v0 * math.sin(th)
        tf = (vy + math.sqrt(vy * vy + 2 * p.g * p.h)) / p.g
        last = S["trails"][-1] if S["trails"] else None
        rows = [["理论飞行时间", fmt(tf, 3) + " s"], ["理论射程", fmt(vx * tf, 3) + " m"], ["理论最大高度", fmt(p.h + max(0, vy * vy / 2 / p.g), 3) + " m"]]
        if last:
            rows += [["本次 t", fmt(last["t"], 2) + " s"], ["本次水平位移", fmt(last["x"], 2) + " m"], ["本次最大高度", fmt(last["maxH"], 2) + " m"],
                     ["速度 (vₓ, v_y)", f"({fmt(last['vx'], 2)}, {fmt(last['vy'], 2)}) m/s"]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 竖直面内的圆周运动
@lab.reg(id="p-circle", subj="phys", book=1, unit="圆周运动", title="竖直面内的圆周运动", kw="向心力 向心加速度 绳模型 杆模型 临界速度",
         info="<p class='fb'>v = ωr　aₙ = v²/r = ω²r　Fₙ = mv²/r<br>小球在最低点速度为 v₀，由机械能守恒：v² = v₀² − 2gR(1 − cos φ)（φ 从最低点算起）</p>"
              "<p><b>绳模型</b>（或轨道内侧）：绳只能拉不能推，T = mv²/R + mg cos φ。最高点临界速度 v = √(gR)，对应最低点 v₀ = √(5gR)。"
              "若 T 减为 0，小球脱离圆周做斜抛运动。</p><p><b>杆模型</b>（或圆管）：杆可拉可推，最高点速度可为 0，对应最低点 v₀ = 2√(gR)。"
              "最高点 v &lt; √(gR) 时杆对球是支持力。</p>",
         tasks=["绳模型 R=1 m，求恰好过最高点的 v₀，再用滑块验证。", "让 v₀ 略小于临界值，观察小球在哪里脱离圆周。", "杆模型下，让最高点速度为 √(gR)，杆对球的作用力是多少？"])
def p_circle(L):
    c = L.canvas()
    g0 = 9.8
    S = {}
    L.group("模型")
    mode = L.seg("", [["rope", "绳模型（轨道内侧）"], ["rod", "杆模型（圆管）"]], "rope", lambda _m: reset())
    p = L.params({"R": ["半径 R", 0.5, 2, 0.05, 1, "m"], "v0": ["最低点速度 v₀", 0, 12, 0.05, 7.2, "m/s"], "m": ["质量 m", 0.1, 2, 0.1, 0.5, "kg"]},
                 lambda _k, _v: reset())

    def reset(*_):
        S.clear()
        S.update(phi=0.0, w=p.v0 / p.R, free=False, x=0.0, y=-p.R, vx=p.v0, vy=0.0, trace=[], t=0.0)
        L.draw()

    def crit(_b):
        p.v0 = math.sqrt(5 * g0 * p.R) if mode.v == "rope" else 2 * math.sqrt(g0 * p.R)
    L.button("重新释放", reset, True)
    L.button("设为临界速度", crit)
    out = L.out()
    reset()

    def tick(dt):
        R, sub = p.R, 40
        h = dt / sub
        s = S
        for _i in range(sub):
            s["t"] += h
            if not s["free"]:
                s["w"] += -(g0 / R) * math.sin(s["phi"]) * h
                s["phi"] += s["w"] * h
                vv = s["w"] * R
                Tn = p.m * vv * vv / R + p.m * g0 * math.cos(s["phi"])
                if mode.v == "rope" and Tn < 0:
                    s["free"] = True
                    s["x"], s["y"] = R * math.sin(s["phi"]), -R * math.cos(s["phi"])
                    s["vx"], s["vy"] = R * s["w"] * math.cos(s["phi"]), R * s["w"] * math.sin(s["phi"])
                    s["trace"] = [(s["x"], s["y"])]
            else:
                s["vy"] -= g0 * h
                s["x"] += s["vx"] * h
                s["y"] += s["vy"] * h
                if math.hypot(s["x"], s["y"]) >= R:
                    ph = math.atan2(s["x"], -s["y"])
                    s["phi"] = ph
                    s["w"] = (s["vx"] * math.cos(ph) + s["vy"] * math.sin(ph)) / R
                    s["free"] = False
        if s["free"]:
            s["trace"].append((s["x"], s["y"]))
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        s, R = S, p.R
        sc = min(c.w, c.h) * 0.36 / R
        cx, cy = c.w / 2, c.h / 2

        def X(x):
            return cx + x * sc

        def Y(y):
            return cy - y * sc
        rod = mode.v == "rod"
        D.circle(g, cx, cy, R * sc, None, T.muted if rod else T.grid2, 10 if rod else 1.5)
        if rod:
            D.circle(g, cx, cy, R * sc, None, T.stage, 6)
        D.circle(g, cx, cy, 3, T.fg)
        bx = s["x"] if s["free"] else R * math.sin(s["phi"])
        by = s["y"] if s["free"] else -R * math.cos(s["phi"])
        if len(s["trace"]) > 1:
            D.poly(g, [(X(q[0]), Y(q[1])) for q in s["trace"]], None, T.c2, 1.5, False)
        if not s["free"]:
            D.line(g, cx, cy, X(bx), Y(by), T.fg, 4 if rod else 1.5)
        else:
            D.line(g, cx, cy, X(bx), Y(by), T.grid2, 1, [3, 4])
        D.circle(g, X(bx), Y(by), 10, T.c1, T.fg, 1.5)
        vx = s["vx"] if s["free"] else R * s["w"] * math.cos(s["phi"])
        vy = s["vy"] if s["free"] else R * s["w"] * math.sin(s["phi"])
        vv = math.hypot(vx, vy)
        D.arrow(g, X(bx), Y(by), X(bx) + vx * 8, Y(by) - vy * 8, T.c2, 2.2)
        Tn = 0 if s["free"] else p.m * vv * vv / R + p.m * g0 * math.cos(s["phi"])
        kf = 6 / max(p.m, 0.2)
        D.arrow(g, X(bx), Y(by), X(bx), Y(by) + p.m * g0 * kf, T.fg, 2)
        D.text(g, "mg", X(bx) + 6, Y(by) + p.m * g0 * kf, T.fg, size=11)
        if not s["free"]:
            ux, uy = -bx / R, -by / R
            D.arrow(g, X(bx), Y(by), X(bx) + ux * Tn * kf, Y(by) - uy * Tn * kf, T.c3, 2.2)
        vtop = math.sqrt(max(0, p.v0 ** 2 - 4 * g0 * R))
        force = "0（已脱离圆周）" if s["free"] else f"{fmt(abs(Tn), 3)} N" + (("（拉力）" if Tn >= 0 else "（支持力）") if rod else "")
        out.set([["当前速度 v", fmt(vv, 3) + " m/s"], ["角度 φ（从最低点）", fmt(((s["phi"] * 180 / PI) % 360 + 360) % 360, 1) + "°"],
                 ["杆的作用力" if rod else "绳拉力 T", force], ["向心加速度 v²/R", fmt(vv * vv / R, 3) + " m/s²"],
                 ["最低点临界 v₀", fmt(2 * math.sqrt(g0 * R) if rod else math.sqrt(5 * g0 * R), 3) + " m/s"],
                 ["理论最高点速度", fmt(vtop, 3) + " m/s" if p.v0 ** 2 >= 4 * g0 * R else "到不了最高点"],
                 ["状态", "脱离圆周，做抛体运动" if s["free"] else "沿圆周运动"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 人造卫星与宇宙速度
@lab.reg(id="p-grav", subj="phys", book=1, unit="万有引力与宇宙航行", title="人造卫星与宇宙速度",
         kw="万有引力 开普勒定律 第一宇宙速度 第二宇宙速度 同步卫星 椭圆轨道",
         info="<p class='fb'>F = GMm/r²　GM = gR²（黄金代换）<br>圆轨道：v = √(GM/r)，T = 2π√(r³/GM)，轨道越高 v 越小、T 越大<br>"
              "第一宇宙速度 7.9 km/s，第二宇宙速度 11.2 km/s<br>开普勒第三定律：a³/T² = GM/4π²</p>"
              "<p>从高度 h 处水平发射卫星：速度等于圆轨道速度时做圆周运动；稍大则为椭圆轨道（发射点为近地点）；稍小则发射点为远地点；达到 √2 倍时逃逸。"
              "勾选「面积定律」可看到相等时间扫过的面积相等。</p>",
         tasks=["点「第一宇宙速度」发射，测周期，与 T = 2π√(R³/GM) ≈ 84 min 比较。", "把速度调到 9 km/s 发射，记录远地点高度；再试 11.2 km/s。",
                "打开面积定律，观察卫星在近地点与远地点附近的速度快慢。"])
def p_grav(L):
    c = L.canvas()
    GM, R = 398600.0, 6371.0
    v = View(c, -4 * R, 4 * R, -3 * R, 3 * R, equal=True)
    S = {"sats": []}
    p = L.params({"h": ["发射高度 h", 100, 40000, 100, 500, "km"], "v": ["发射速度 v（水平）", 3, 12, 0.01, 7.61, "km/s"],
                  "w": ["时间倍率", 100, 6000, 100, 1200, "×"]})

    def launch(*_):
        r0 = R + p.h
        vv = p.v
        E = vv * vv / 2 - GM / r0
        a = -GM / (2 * E) if E < 0 else math.inf
        Tp = TAU * math.sqrt(a ** 3 / GM) if E < 0 else math.inf
        S["sats"].append({"x": 0.0, "y": r0, "vx": vv, "vy": 0.0, "t": 0.0, "trail": [(0.0, r0)], "dead": None, "T": Tp, "E": E, "a": a,
                          "marks": [(0.0, r0)], "next": Tp / 12, "rmin": r0, "rmax": r0})
        if len(S["sats"]) > 4:
            S["sats"].pop(0)
        ext = max(2 * a - r0, r0) * 1.25 if math.isfinite(a) else r0 * 3
        if ext > v.r[1]:
            v.r = [-ext, ext, -ext * 0.75, ext * 0.75]

    def first(_b):
        p.s("h").set(100, True)
        p.s("v").set(7.85, True)
        launch()

    def circ(_b):
        p.s("v").set(math.sqrt(GM / (R + p.h)), True)
        launch()

    def second(_b):
        p.s("v").set(math.sqrt(2 * GM / (R + p.h)), True)
        launch()

    def geo(_b):
        p.s("h").set(35786, True)
        p.s("v").set(3.075, True)
        v.r = [-8 * R, 8 * R, -6 * R, 6 * R]
        launch()
    L.button("发射", launch, True)
    L.button("清除", lambda _b: (S.__setitem__("sats", []), L.draw()))
    L.button("第一宇宙速度", first)
    L.button("圆轨道速度", circ)
    L.button("第二宇宙速度", second)
    L.button("同步卫星", geo)
    kep = L.check("显示面积定律（等时扇形）", True)
    out = L.out()
    L.note("滚轮缩放视野，拖动平移。")
    L.interact(c, view=v)

    def tick(dt):
        for s in S["sats"]:
            if s["dead"]:
                continue
            left = dt * p.w
            while left > 0:
                r = math.hypot(s["x"], s["y"])
                h = min(left, 0.02 * r ** 1.5 / math.sqrt(GM))
                left -= h
                s["vx"] += -GM * s["x"] / r ** 3 * h / 2
                s["vy"] += -GM * s["y"] / r ** 3 * h / 2
                s["x"] += s["vx"] * h
                s["y"] += s["vy"] * h
                r2 = math.hypot(s["x"], s["y"])
                s["vx"] += -GM * s["x"] / r2 ** 3 * h / 2
                s["vy"] += -GM * s["y"] / r2 ** 3 * h / 2
                s["t"] += h
                s["rmin"], s["rmax"] = min(s["rmin"], r2), max(s["rmax"], r2)
                if r2 < R:
                    s["dead"] = "撞击地面"
                    break
                if r2 > 60 * R:
                    s["dead"] = "飞离地球"
                    break
                if math.isfinite(s["T"]) and s["t"] >= s["next"]:
                    s["marks"].append((s["x"], s["y"]))
                    s["next"] += s["T"] / 12
            s["trail"].append((s["x"], s["y"]))
            if len(s["trail"]) > 3000:
                s["trail"].pop(0)
        L.draw()
    L.loop(tick)

    def draw():
        v.begin(grid=False)
        g = c.g
        D.circle(g, v.X(0), v.Y(0), R * v.sx, alpha(T.c1, 0.35), T.c1, 1.5)
        D.text(g, "地球", v.X(0), v.Y(0), T.fg, align="center", size=12)
        if p.h > 30000:
            D.circle(g, v.X(0), v.Y(0), (R + 35786) * v.sx, None, T.grid2, 1)
        for i, s in enumerate(S["sats"]):
            col = T.c[(i + 1) % 6]
            if kep.v and len(s["marks"]) > 1:
                for k in range(0, min(len(s["marks"]) - 1, 12), 2):
                    a, b = s["marks"][k], s["marks"][k + 1]
                    D.poly(g, [(v.X(0), v.Y(0)), v.P(*a), v.P(*b)], alpha(col, 0.15))
            D.poly(g, [v.P(*q) for q in s["trail"]], None, col, 1.8, False)
            v.dot(s["x"], s["y"], col, 5, True)
        rv = R + p.h
        rows = [["该高度圆轨道速度", fmt(math.sqrt(GM / rv), 3) + " km/s"], ["该高度逃逸速度", fmt(math.sqrt(2 * GM / rv), 3) + " km/s"],
                ["该高度圆轨道周期", fmt(TAU * math.sqrt(rv ** 3 / GM) / 60, 1) + " min"]]
        if S["sats"]:
            s = S["sats"][-1]
            r = math.hypot(s["x"], s["y"])
            kind = s["dead"] or ("逃逸（抛物/双曲线）" if s["E"] >= 0 else "圆" if abs(s["rmax"] - s["rmin"]) < 5 else "椭圆")
            rows += [["当前高度", fmt(r - R, 0) + " km"], ["当前速率", fmt(math.hypot(s["vx"], s["vy"]), 3) + " km/s"], ["已飞行", fmt(s["t"] / 60, 1) + " min"],
                     ["轨道类型", kind], ["理论周期", fmt(s["T"] / 60, 1) + " min" if math.isfinite(s["T"]) else "—"],
                     ["近地点 / 远地点高度", f"{fmt(s['rmin'] - R, 0)} / {fmt(max(s['rmax'], 2 * s['a'] - s['rmin']) - R, 0)} km" if math.isfinite(s["a"]) else "—"]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 机械能守恒
@lab.reg(id="p-energy", subj="phys", book=1, unit="机械能守恒定律", title="轨道上的机械能守恒", kw="动能 重力势能 机械能 动能定理 摩擦生热",
         info="<p class='fb'>Eₖ = ½mv²　Eₚ = mgh　只有重力做功时 Eₖ + Eₚ = 恒量<br>动能定理：W 合 = ΔEₖ　摩擦产生的热量 Q = 机械能的减少量</p>"
              "<p>小球沿光滑轨道运动时，动能和势能相互转化，总机械能不变；它最多能回到释放时的高度。加入摩擦后，机械能逐渐转化为内能。</p>",
         tasks=["从「过山车」左侧释放，小球能越过中间的山峰吗？用机械能判断再验证。", "加摩擦 μ = 0.05，记录小球每次到达右侧的最高点高度。", "改变质量 m，小球的运动快慢会变吗？"])
def p_energy(L):
    c = L.canvas()
    v = View(c, -6, 6, -0.5, 6, equal=True, pad=(10, 120, 10, 10))
    tracks = {
        "U 形槽": lambda x: 0.18 * x * x,
        "过山车": lambda x: 0.11 * x * x + 1.1 * math.cos(1.5 * x) + 1.2,
        "斜面接平面": lambda x: 0.45 * (-x + math.sqrt(x * x + 0.4)) + 0.05 * max(0, x - 4) ** 2,
        "双峰": lambda x: 3.4 * math.exp(-((x + 2.2) ** 2) * 0.8) + 2.2 * math.exp(-((x - 1.8) ** 2) * 0.9) + 0.15 * x * x,
    }
    g0 = 9.8
    S = {"f": tracks["过山车"], "x": -5.0, "u": 0.0, "E0": 0.0, "Q": 0.0}

    def pick(k):
        S["f"] = tracks[k]
        reset()
    L.select("轨道形状", list(tracks), "过山车", pick)
    p = L.params({"x0": ["释放位置 x", -5.8, 5.8, 0.05, -5], "m": ["质量 m", 0.2, 5, 0.1, 1, "kg"], "mu": ["摩擦因数 μ", 0, 0.2, 0.005, 0]},
                 lambda k, _v: reset() if k == "x0" else L.draw())

    def sl(x):
        f = S["f"]
        return (f(x + 1e-4) - f(x - 1e-4)) / 2e-4

    def reset(*_):
        S["x"], S["u"], S["Q"] = p.x0, 0.0, 0.0
        S["E0"] = p.m * g0 * S["f"](S["x"])
        L.draw()

    def step(dt):
        sub = 40
        h = dt / sub
        x, u, f = S["x"], S["u"], S["f"]
        for _i in range(sub):
            s = sl(x)
            ca = 1 / math.sqrt(1 + s * s)
            sa = s * ca
            a = -g0 * sa
            if p.mu > 0:
                if abs(u) > 1e-3:
                    a -= math.copysign(1, u) * p.mu * g0 * ca
                elif abs(sa / ca) <= p.mu:
                    u = 0.0
                    continue
                else:
                    a -= math.copysign(1, a) * p.mu * g0 * ca
            nu = u + a * h
            u = 0.0 if p.mu > 0 and u != 0 and (nu > 0) != (u > 0) else nu
            x += u * ca * h
            if x < -5.95:
                x, u = -5.95, 0.0
            if x > 5.95:
                x, u = 5.95, 0.0
        S["x"], S["u"] = x, u
        S["Q"] = max(0.0, S["E0"] - (0.5 * p.m * u * u + p.m * g0 * f(x)))

    def tick(dt):
        step(dt)
        L.draw()
    run = L.loop(tick)
    L.button("暂停 / 继续", lambda _b: run.toggle())
    L.button("重新释放", reset, True)
    out = L.out()
    reset()

    def hit(px, py):
        return "ball" if math.hypot(v.X(S["x"]) - px, v.Y(S["f"](S["x"])) - py) < 16 else None

    def drag(_o, px, _py, _dx, _dy):
        p.s("x0").set(clamp(v.ix(px), -5.8, 5.8))
    L.interact(c, hit=hit, drag=drag)

    def draw():
        v.begin(grid=False)
        g = c.g
        f, x, u = S["f"], S["x"], S["u"]
        pts = [(v.X(-6), v.Y(-0.5))]
        xx = -6.0
        while xx <= 6.001:
            pts.append(v.P(xx, f(xx)))
            xx += 0.05
        pts.append((v.X(6), v.Y(-0.5)))
        D.poly(g, pts, alpha(T.muted, 0.12))
        v.plot(f, T.fg, 2.2)
        v.seg(-6, f(p.x0), 6, f(p.x0), T.c4, 1, [5, 5])
        v.label("释放高度", 5.9, f(p.x0), T.c4, align="right", dx=0)
        s = sl(x)
        nx, ny = -s / math.sqrt(1 + s * s), 1 / math.sqrt(1 + s * s)
        r = 0.22
        D.circle(g, v.X(x + nx * r), v.Y(f(x) + ny * r), r * v.sx, T.c1, T.fg, 1.2)
        Ek, Ep = 0.5 * p.m * u * u, p.m * g0 * f(x)
        E, Q = Ek + Ep, S["Q"]
        Emax = max(S["E0"], 1e-6)
        bx, bh, by = c.w - 110, c.h - 60, 30
        for i, (val, col, lb) in enumerate(((Ek, T.c2, "Eₖ"), (Ep, T.c1, "Eₚ"), (Q, T.c4, "Q 热"), (E, T.c3, "E 机械"))):
            hh = val / Emax * bh * 0.9
            D.rect(g, bx + i * 26, by + bh - hh, 20, hh, col)
            D.text(g, lb, bx + i * 26 + 10, by + bh + 12, T.fg, align="center", size=11)
        D.line(g, bx - 4, by + bh, bx + 104, by + bh, T.axis, 1)
        out.set([["高度 h", fmt(f(x), 3) + " m"], ["速率 v", fmt(abs(u), 3) + " m/s"], ["动能 Eₖ", fmt(Ek, 3) + " J"], ["势能 Eₚ", fmt(Ep, 3) + " J"],
                 ["机械能 E", fmt(E, 3) + " J"], ["摩擦生热 Q", fmt(Q, 3) + " J"], ["E + Q", fmt(E + Q, 3) + " J"]])
    L.on_draw(draw)
