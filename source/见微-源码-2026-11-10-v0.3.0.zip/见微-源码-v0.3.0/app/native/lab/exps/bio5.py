"""生物 · 选择性必修3 生物技术与工程（由 gewu/bio.js 改写）：PCR、稀释涂布平板法。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha
from ...kit.core import TAU, fmt, gauss, rnd, sci
from ...kit.draw import D
from ...kit.registry import lab

SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


@lab.reg(id="b-pcr", subj="bio", book=4, unit="基因工程", title="PCR 扩增 DNA", kw="PCR 聚合酶链式反应 变性 复性 延伸 引物 耐高温 DNA 聚合酶 Taq 指数增长",
         info="<p>每个循环分三步：</p><p class='fb'>变性 90~95 ℃：DNA 双链解开<br>复性 50~60 ℃：两种引物与两条单链互补结合<br>延伸 72 ℃：耐高温的 DNA 聚合酶从引物 3′ 端开始合成子链</p>"
              "<p>理论上 n 次循环后 DNA 分子数为 2ⁿ（从 1 个模板开始）。第 3 次循环才首次出现两条链等长、只含目标片段的 DNA，其数目为 2ⁿ − 2n。"
              "实际上随引物、原料消耗和酶活性下降，扩增最终进入平台期。</p>",
         tasks=["经过 3 次循环，共有几个 DNA 分子？其中有几个是等长的目标 DNA？", "为什么 PCR 需要两种不同的引物？", "勾选「考虑原料消耗」，在第几轮后进入平台期？"])
def b_pcr(L):
    c = L.canvas()
    n = L.slider("循环次数", 0, 35, 1, 3)
    lim = L.check("考虑原料消耗（平台期）", False)
    lg = L.check("纵轴取对数", False)
    S = {"tt": 0.0}

    def tick(dt):
        S["tt"] += dt
        if S["tt"] > 6:
            run.pause()
            n.set(min(35, n.v + 1))
        L.draw()
    run = L.loop(tick, False)

    def play(_b):
        S["tt"] = 0.0
        run.play()
    L.button("播放一个循环的温度变化", play, True)
    out = L.out()

    def amount(k):
        return 1e9 / (1 + (1e9 - 1) * 2 ** -k) if lim.v else 2 ** k
    prog = [(0, 25), (0.5, 95), (1.8, 95), (2.3, 55), (3.4, 55), (3.8, 72), (5.5, 72), (6, 95)]

    def draw():
        c.clear()
        g = c.g
        k = int(n.v)
        half = c.h * 0.42
        ch = D.chart(g, 50, 20, c.w * 0.45 - 60, half - 30, [{"pts": prog, "color": T.c2, "w": 2.2}], title="温度（℃）", xl="一个循环", xmin=0, xmax=6, ymin=20, ymax=100)
        for t2, x, y in (("变性", 1.1, 95), ("复性", 2.9, 55), ("延伸", 4.6, 72)):
            D.text(g, t2, ch["X"](x), ch["Y"](y) - 12, T.muted, align="center", size=11)
        if run.running:
            tt = S["tt"]
            T2 = 95
            for i in range(1, len(prog)):
                if tt <= prog[i][0]:
                    (x1, y1), (x2, y2) = prog[i - 1], prog[i]
                    T2 = y1 + (y2 - y1) * (tt - x1) / (x2 - x1)
                    break
            D.circle(g, ch["X"](min(tt, 6)), ch["Y"](T2), 6, T.c4)
        sx = c.w * 0.5
        sw = c.w - sx - 20
        mols = min(2 ** min(k, 4), 16)
        lh = min(16, (half - 30) / mols)
        D.text(g, f"第 {k} 轮后的 DNA（最多画 16 个）", sx, 16, T.muted, size=11)
        for i in range(mols):
            y = 30 + i * lh
            orig = i == 0
            D.line(g, sx, y, sx + sw * (1 if orig else 0.7), y, T.c1 if orig else T.c3, 3)
            D.line(g, sx + sw * 0.15, y + 4, sx + sw * (1 if orig else 0.7), y + 4, T.c1 if orig else T.c2, 3)
        D.line(g, sx + sw * 0.15, 24, sx + sw * 0.15, 30 + mols * lh, alpha(T.c4, 0.7), 1, [3, 3])
        D.line(g, sx + sw * 0.7, 24, sx + sw * 0.7, 30 + mols * lh, alpha(T.c4, 0.7), 1, [3, 3])
        D.text(g, "目标片段（两引物之间）", sx + sw * 0.42, 30 + mols * lh + 12, T.c4, align="center", size=11)

        def yv(q):
            return math.log10(q) if lg.v else q
        ch2 = D.chart(g, 50, half + 30, c.w - 80, c.h - half - 60, [{"pts": [(i, yv(amount(i))) for i in range(36)], "color": T.c1, "w": 2.2}],
                      title="DNA 分子数（lg）" if lg.v else "DNA 分子数", xl="循环次数", xmin=0, xmax=35, ymin=0)
        D.circle(g, ch2["X"](k), ch2["Y"](yv(amount(k))), 5, T.c2)
        out.set([["循环次数 n", k], ["DNA 分子总数 2ⁿ", fmt(2 ** k, 0) if k < 25 else sci(2 ** k, 3)], ["等长目标 DNA 2ⁿ − 2n", (fmt(2 ** k - 2 * k, 0) if k < 25 else sci(2 ** k - 2 * k, 3)) if k >= 3 else 0],
                 ["含原始模板链的 DNA", 2 if k else 1], ["消耗引物数 2ⁿ⁺¹ − 2", fmt(2 ** (k + 1) - 2, 0) if k < 25 else sci(2 ** (k + 1) - 2, 3)],
                 ["考虑消耗后的分子数", sci(amount(k), 3)] if lim.v else None])
    L.on_draw(draw)


@lab.reg(id="b-plate", subj="bio", book=4, unit="发酵工程", title="稀释涂布平板法计数", kw="微生物 培养基 稀释涂布平板 梯度稀释 菌落 计数 30-300 无菌操作",
         info="<p>将菌液进行一系列梯度稀释（每次 1 mL 加入 9 mL 无菌水，稀释 10 倍），取 0.1 mL 涂布到平板上，培养后计数菌落。</p>"
              "<p class='fb'>每毫升样品中的菌数 = (C ÷ V) × M<br>C：某稀释度下平板上的平均菌落数　V：涂布体积（mL）　M：稀释倍数</p>"
              "<p>应选择菌落数在 <b>30~300</b> 之间的平板计数；每个稀释度至少涂布 3 个平板取平均值。因为两个或多个细胞连在一起时只长成一个菌落，统计值往往比实际值<b>偏小</b>。</p>",
         tasks=["先估计哪个稀释度的平板菌落数会落在 30~300 之间，再涂布验证。", "用符合要求的平板计算原菌液浓度，与真实值比较。", "为什么菌落数太多或太少的平板都不适合用来计数？"])
def b_plate(L):
    c = L.canvas()
    S = {"C0": 3.6e7, "plates": [], "reveal": False}
    dil = L.slider("涂布的稀释度 10⁻ᵏ", 1, 8, 1, 5, None, lambda v: "10⁻" + str(int(v)).translate(SUP))

    def pois(lam):
        if lam > 400:
            return max(0, round(lam + math.sqrt(lam) * gauss()))
        Lm, k, p = math.exp(-lam), 0, 1.0
        while True:
            k += 1
            p *= random.random()
            if p <= Lm:
                return k - 1

    def spread(_b):
        k = int(dil.v)
        lam = S["C0"] * 10 ** -k * 0.1
        ps = []
        for _ in range(3):
            nc = pois(lam)
            pts, grid = [], {}
            # 相距 < 0.025 的菌落长成一个（网格查邻格，不随菌落数平方增长）
            for _i in range(min(nc, 1500)):
                r, a = math.sqrt(random.random()) * 0.93, rnd(0, TAU)
                q = (r * math.cos(a), r * math.sin(a))
                gx, gy = int((q[0] + 1) / 0.025), int((q[1] + 1) / 0.025)
                near = any(math.hypot(o[0] - q[0], o[1] - q[1]) < 0.025
                           for dx in (-1, 0, 1) for dy in (-1, 0, 1) for o in grid.get((gx + dx, gy + dy), ()))
                if near:
                    continue
                grid.setdefault((gx, gy), []).append(q)
                pts.append(q)
            ps.append({"k": k, "pts": pts, "raw": nc})
        S["plates"] = [q for q in S["plates"] if q["k"] != k] + ps
        L.draw()

    def new_sample(_b):
        S["C0"] = round(rnd(1, 9.9) * 10) / 10 * 10 ** math.floor(rnd(6, 9))
        S["plates"], S["reveal"] = [], False
        L.draw()
    L.button("涂布 3 个平板并培养", spread, True)
    L.button("换一份菌液", new_sample)
    L.button("揭晓真实浓度", lambda _b: (S.__setitem__("reveal", True), L.draw()))
    out = L.out()

    def draw():
        c.clear()
        g = c.g
        tubes = 8
        tw = min(42, (c.w - 40) / tubes)
        for i in range(tubes + 1):
            x = 20 + i * tw * 1.1
            a = 0.75 * max(0.05, 1 - i / 8.5)
            D.rrect(g, x, 20, tw * 0.7, 70, 8, f"rgba(200,170,90,{a:.3f})", T.fg, 1.2)
            D.text(g, "10⁻" + str(i).translate(SUP) if i else "原液", x + tw * 0.35, 102,
                   T.c2 if i == dil.v else T.muted, align="center", size=10.5)
        plates = S["plates"]
        ks = sorted({q["k"] for q in plates})
        R = min(70, (c.w - 60) / 7, (c.h - 160) / (2 * max(1, len(ks))) - 10)
        sup = SUP
        for row, k in enumerate(ks):
            for j, pl in enumerate([q for q in plates if q["k"] == k]):
                cx, cy = 40 + R + j * (2 * R + 24), 140 + R + row * (2 * R + 30)
                D.circle(g, cx, cy, R, alpha("#e8d9a8", 0.15 if T.dark else 0.6), T.fg, 1.5)
                rr = max(1.2, R * 0.022)
                for q in pl["pts"]:
                    D.circle(g, cx + q[0] * R, cy + q[1] * R, rr, "#f1efe2", "#b8a46a", 0.6)
                cnt = len(pl["pts"])
                ok = 30 <= cnt <= 300
                D.text(g, "多到无法计数" if cnt > 500 else f"{cnt} 个", cx, cy + R + 12, T.ok if ok else T.muted, align="center", size=11, bold=ok)
                if j == 0:
                    D.text(g, "10⁻" + str(k).translate(sup), 4, cy, T.muted, size=11)
        good = [k for k in ks if all(30 <= len(q["pts"]) <= 300 for q in plates if q["k"] == k)]
        rows = [["涂布体积", "0.1 mL"]]
        for k in good:
            ps = [q for q in plates if q["k"] == k]
            avg = sum(len(q["pts"]) for q in ps) / len(ps)
            rows.append([f"10⁻{str(k).translate(sup)} 平均 {fmt(avg, 1)} 个", sci(avg / 0.1 * 10 ** k, 2) + " 个/mL"])
        rows += [["可用于计数的稀释度", "、".join("10⁻" + str(k).translate(sup) for k in good) if good else "暂无（需 30~300 个菌落）"],
                 ["真实浓度", sci(S["C0"], 2) + " 个/mL" if S["reveal"] else "（点击揭晓）"]]
        out.set(rows)
    L.on_draw(draw)
