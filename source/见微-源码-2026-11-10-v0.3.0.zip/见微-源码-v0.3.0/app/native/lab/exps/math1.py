"""数学 · 必修第一册（由 gewu/math.js 改写）。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import fmt
from ...kit.draw import D
from ...kit.expr import ExprError, compile_expr
from ...kit.registry import lab
from ...kit.view import View


def bisect(F, a, b, n=50):
    fa = F(a)
    for _ in range(n):
        m = (a + b) / 2
        fm = F(m)
        if fa * fm <= 0:
            b = m
        else:
            a, fa = m, fm
    return (a + b) / 2


def ok(v) -> bool:
    return isinstance(v, float) and math.isfinite(v)


# ---------------------------------------------------------------- 函数图像实验室
@lab.reg(id="m-func", subj="math", book=0, unit="函数的概念与性质 · 幂指对函数", title="函数图像实验室",
         kw="函数 图像 切线 零点 极值 反函数",
         info="<p>输入最多三个函数，用参数 <span class='f'>a b c</span> 实时变形图像。支持 <span class='f'>+ - * / ^ ( ) |x|</span>，"
              "函数 <span class='f'>sin cos tan sqrt abs exp ln lg log(a,x) arcsin</span> 等，常数 <span class='f'>pi e</span>；"
              "<span class='f'>2x</span>、<span class='f'>ax</span> 这类省略乘号的写法也能识别。</p>"
              "<p>导数按中心差商 <span class='f'>f′(x)≈[f(x+h)−f(x−h)]/2h</span> 计算；零点、极值点由扫描变号后用二分法细化得到。</p>"
              "<p class='fb'>切线方程：y − f(x₀) = f′(x₀)(x − x₀)</p>",
         tasks=["选「指数与对数」预设，改变 a，观察 y=aˣ 与 y=logₐx 关于 y=x 对称，以及 0<a<1 与 a>1 的区别。",
                "在「幂函数」预设里让 a 取 −1、0.5、1、2、3，比较图像过的定点与单调性。",
                "选「切线放缩」，把 x₀ 拖到 0，验证 eˣ ≥ x+1 在 x=0 处取等号。",
                "自行输入 x^3-3*a*x，调 a 的正负，看极值点何时出现。"])
def m_func(L):
    c = L.canvas()
    v = View(c, -8, 8, -5, 5, equal=True)
    VARS = ("x", "a", "b", "c")
    fs = [None, None, None]
    L.group("函数表达式")

    def make(i):
        def cb(val, s):
            try:
                fs[i] = compile_expr(val, VARS) if val.strip() else None
                s.err("")
            except ExprError as exc:
                fs[i] = None
                s.err(str(exc))
            L.draw()
        return cb
    ins = []
    for i, n in enumerate(["f(x) =", "g(x) =", "h(x) ="]):
        s = L.input(n, "", make(i))
        s.el.setStyleSheet(f"border-left:4px solid {T.c[i]};")
        ins.append(s)
    presets = {
        "一次与二次函数": ["a*x+b", "a*x^2+b*x+c", "", 1, 1, -2],
        "幂函数 y=xᵃ": ["x^a", "x", "", 0.5, 1, 0],
        "指数与对数（互为反函数）": ["a^x", "log(a,x)", "x", 2, 1, 0],
        "三角函数": ["sin(x)", "cos(x)", "tan(x)", 1, 1, 0],
        "y = a·sin(bx + c)": ["a*sin(b*x+c)", "sin(x)", "", 2, 2, 1],
        "对勾函数 y = x + a/x": ["x+a/x", "", "", 1, 1, 0],
        "绝对值函数": ["|x-a|+|x+b|", "", "", 1, 2, 0],
        "函数零点 ln x + 2x − 6": ["ln(x)+2x-6", "", "", 1, 1, 0],
        "三次函数的极值": ["x^3-3a*x+b", "", "", 1, 0, 0],
        "切线放缩 eˣ 与 ln x": ["e^x", "x+1", "ln(x)", 1, 1, 0],
    }
    box = {}

    def pick(k):
        f, g2, h, a, b, cc = presets[k]
        ins[0].set(f)
        ins[1].set(g2)
        ins[2].set(h)
        p = box["p"]
        p.s("a").set(a, True)
        p.s("b").set(b, True)
        p.s("c").set(cc, True)
        L.draw()
    L.select("预设", list(presets), "一次与二次函数", pick)
    L.group("参数")
    p = box["p"] = L.params({"a": ["a", -5, 5, 0.1, 1], "b": ["b", -5, 5, 0.1, 1], "c": ["c", -5, 5, 0.1, -2]})
    L.group("分析 f(x)")
    tan = L.check("画 x₀ 处的切线", True)
    der = L.check("画导函数 f′(x)（虚线）", False)
    crit = L.check("标出零点和极值点", True)
    x0 = L.slider("x₀", -8, 8, 0.05, 1)
    out = L.out()
    L.note("拖动画布平移，滚轮缩放，双击复位。")
    L.interact(c, view=v)
    ins[0].set("a*x+b")
    ins[1].set("a*x^2+b*x+c")

    def draw():
        v.begin()
        A, B, C = p.a, p.b, p.c
        for i, f in enumerate(fs):
            if f:
                v.plot(lambda x, f=f: f(x, A, B, C), T.c[i], 2.2)
        f = fs[0]
        if not f:
            out.set([["f(x)", "未输入"]])
            return

        def F(x):
            return f(x, A, B, C)

        def d(x):
            return (F(x + 1e-5) - F(x - 1e-5)) / 2e-5
        if der.v:
            v.plot(d, T.c[0], 1.4, [6, 4])
        zs, mx, mn = [], [], []
        if crit.v:
            N = 800
            dx = (v.x1 - v.x0) / N
            xa = v.x0
            fa, da = F(xa), d(xa)
            for k in range(1, N + 1):
                xb = v.x0 + k * dx
                fb, db = F(xb), d(xb)
                if ok(fa) and ok(fb) and fa * fb <= 0 and fa != fb:
                    r = bisect(F, xa, xb)
                    fr = F(r)
                    if ok(fr) and abs(fr) < 1e-6 and len(zs) < 8 and not any(abs(z - r) < 1e-6 for z in zs):
                        zs.append(r)
                if ok(da) and ok(db) and da * db < 0:
                    r = bisect(d, xa, xb)
                    y = F(r)
                    if ok(y) and abs(y) < 1e6:
                        (mx if da > 0 else mn).append(r)
                xa, fa, da = xb, fb, db
            for z in zs:
                v.dot(z, 0, T.c[0], 4, True)
            for z in mx:
                v.dot(z, F(z), T.bad, 4.5, True)
                v.label("极大", z, F(z), T.bad, size=11, dx=-10, dy=-14)
            for z in mn:
                v.dot(z, F(z), T.ok, 4.5, True)
                v.label("极小", z, F(z), T.ok, size=11, dx=-10, dy=16)
        X = x0.v
        Y, k = F(X), d(X)
        if tan.v and ok(Y) and ok(k):
            v.plot(lambda x: Y + k * (x - X), T.muted, 1.3, [4, 3])
            v.dot(X, Y, T.c[0], 5, True)

        def lst(a):
            return ", ".join(fmt(z, 3) for z in a[:4]) + (" …" if len(a) > 4 else "") if a else "无"
        b0 = Y - k * X if ok(Y) and ok(k) else math.nan
        out.set([["f(x₀)", fmt(Y, 4)], ["f′(x₀)", fmt(k, 4)],
                 ["切线", f"y = {fmt(k, 3)}x {'+' if b0 >= 0 else '−'} {fmt(abs(b0), 3)}" if ok(k) else "—"],
                 ["零点（视野内）", lst(zs)], ["极大值点", lst(mx)], ["极小值点", lst(mn)]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 二分法
@lab.reg(id="m-bisect", subj="math", book=0, unit="函数的应用 · 二分法", title="二分法求方程近似解", kw="零点存在定理 近似解",
         info="<p><b>函数零点存在定理</b>：若 f(x) 在 [a,b] 上图像连续，且 f(a)·f(b) &lt; 0，则 f(x) 在 (a,b) 内至少有一个零点。</p>"
              "<p>二分法每一步取中点 m=(a+b)/2，根据 f(a)·f(m) 的符号保留含零点的一半区间。区间长度每步减半，n 步后为 (b−a)/2ⁿ。"
              "当区间长度小于精度 ε 时，区间内任一点都可作为近似解。</p>",
         tasks=["对 f(x)=ln x+2x−6 在 [2,3] 上二分，精确到 0.01 需要几步？与公式 n > log₂((b−a)/ε) 对照。",
                "把区间改成 f(a)、f(b) 同号的区间，观察二分法为何无法开始。"])
def m_bisect(L):
    c = L.canvas()
    v = View(c, 0, 5, -6, 6)
    S = {"F": compile_expr("ln(x)+2x-6"), "st": None}

    def reset(*_):
        F = S["F"]
        S["st"] = {"a": pa.v, "b": pb.v, "rows": [], "ok": F(pa.v) * F(pb.v) < 0} if F else None
        L.draw()

    def fin_cb(val, s):
        try:
            S["F"] = compile_expr(val)
            s.err("")
        except ExprError as exc:
            S["F"] = None
            s.err(str(exc))
        if "pb" in S:
            reset()
    L.group("函数与区间")
    L.input("f(x) =", "ln(x)+2x-6", fin_cb)
    pa = L.slider("a", -5, 5, 0.1, 2, reset)
    pb = L.slider("b", -5, 8, 0.1, 3, reset)
    S["pb"] = pb
    eps = L.select("精度 ε", ["0.1", "0.01", "0.001", "0.0001"], "0.01", lambda _v: L.draw())

    def step(*_):
        st, F = S["st"], S["F"]
        if not st or not st["ok"] or st["b"] - st["a"] < float(eps.v):
            return
        m = (st["a"] + st["b"]) / 2
        fm = F(m)
        st["rows"].append((st["a"], st["b"], m, fm))
        if F(st["a"]) * fm <= 0:
            st["b"] = m
        else:
            st["a"] = m
        L.draw()

    def run_all(*_):
        for _i in range(60):
            st = S["st"]
            if not (st and st["ok"] and st["b"] - st["a"] >= float(eps.v)):
                break
            step()
    L.group("操作")
    L.button("二分一步", step, True)
    L.button("一直到满足精度", run_all)
    L.button("重置", reset)
    out = L.out()
    L.group("迭代记录")
    log = L.out()
    reset()
    L.interact(c, view=v)

    def draw():
        v.begin()
        F, st = S["F"], S["st"]
        if not F:
            return
        g = c.g
        if st:
            D.rect(g, v.X(st["a"]), v.oy, v.X(st["b"]) - v.X(st["a"]), v.H, alpha(T.accent, 0.12))
            v.seg(st["a"], v.y0, st["a"], v.y1, T.c2, 1.2, [4, 3])
            v.seg(st["b"], v.y0, st["b"], v.y1, T.c2, 1.2, [4, 3])
            for r in st["rows"]:
                v.dot(r[2], r[3], T.muted, 3)
        v.plot(F, T.c1, 2.4)
        if not st:
            return
        v.dot(st["a"], F(st["a"]), T.c2, 5, True)
        v.dot(st["b"], F(st["b"]), T.c2, 5, True)
        v.label("a", st["a"], 0, T.c2, dy=14)
        v.label("b", st["b"], 0, T.c2, dy=14)
        ln = st["b"] - st["a"]
        done = ln < float(eps.v)
        out.set([["f(a)·f(b)", "< 0，可以二分" if st["ok"] else "≥ 0，换一个区间"], ["当前区间", f"[{fmt(st['a'], 5)}, {fmt(st['b'], 5)}]"],
                 ["区间长度", fmt(ln, 6)], ["已迭代", f"{len(st['rows'])} 次"],
                 ["结论", f"近似解 x ≈ {fmt((st['a'] + st['b']) / 2, 4)}" if done else "尚未达到精度"]])
        rows, n0 = st["rows"][-10:], max(0, len(st["rows"]) - 10)
        log.set([["n　中点 m", "f(m)"]] + [[f"{n0 + i + 1}　{fmt(r[2], 5)}", fmt(r[3], 4)] for i, r in enumerate(rows)])
    L.on_draw(draw)


# ---------------------------------------------------------------- 基本不等式
@lab.reg(id="m-ineq", subj="math", book=0, unit="一元二次函数、方程和不等式", title="基本不等式的几何解释", kw="均值不等式 算术平均 几何平均",
         info="<p>以 AB = a + b 为直径作半圆，C 在 AB 上且 AC=a，CB=b。过 C 作垂线交半圆于 D，由射影定理 <span class='f'>CD² = AC·CB</span>，"
              "所以 CD = √(ab)，而半径 = (a+b)/2。</p><p class='fb'>√(ab) ≤ (a+b)/2，当且仅当 a = b 时取等号</p>"
              "<p>图中还画出了调和平均 2ab/(a+b) 与平方平均 √((a²+b²)/2)，得到完整的不等式链：调和 ≤ 几何 ≤ 算术 ≤ 平方。</p>",
         tasks=["拖动滑块使 a=b，四条线段长度有什么关系？", "固定 a+b=10（和定），ab 何时最大？固定 ab=16（积定），a+b 何时最小？"])
def m_ineq(L):
    c = L.canvas()
    v = View(c, -1, 13, -2, 7.5, equal=True)
    p = L.params({"a": ["a", 0.2, 10, 0.1, 7], "b": ["b", 0.2, 10, 0.1, 3]})
    out = L.out()
    L.legend([[T.c1, "几何平均 √ab"], [T.c2, "算术平均 (a+b)/2"], [T.c3, "调和平均"], [T.c4, "平方平均"]])

    def draw():
        v.begin(grid=False)
        a, b = p.a, p.b
        R = (a + b) / 2
        O, Cx, Dd = R, a, math.sqrt(a * b)
        g = c.g
        g.stroke_style, g.line_width = T.fg, 1.6
        g.begin_path()
        g.arc(v.X(O), v.Y(0), R * v.sx, math.pi, 0)
        g.stroke()
        v.seg(0, 0, a + b, 0, T.fg, 1.6)
        v.seg(Cx, 0, Cx, Dd, T.c1, 3)
        v.seg(O, 0, Cx, Dd, T.c2, 3)
        ux, uy = (Cx - O) / R, Dd / R
        Hm = 2 * a * b / (a + b)
        Ex, Ey = O + ux * (R - Hm), uy * (R - Hm)
        v.seg(Cx, 0, Ex, Ey, T.muted, 1, [3, 3])
        v.seg(Ex, Ey, Cx, Dd, T.c3, 3)
        v.seg(O, 0, O, R, T.muted, 1, [3, 3])
        v.seg(Cx, 0, O, R, T.c4, 3)
        for n, x, y in (("A", 0, 0), ("B", a + b, 0), ("C", Cx, 0), ("O", O, 0), ("D", Cx, Dd), ("F", O, R)):
            v.dot(x, y, T.fg, 3)
            v.label(n, x, y, T.fg, dy=-12 if y else 14, dx=-4)
        v.label("a", a / 2, 0, T.muted, dy=14)
        v.label("b", a + b / 2, 0, T.muted, dy=14)
        out.set([["调和平均 2ab/(a+b)", fmt(Hm, 4)], ["几何平均 √(ab)", fmt(Dd, 4)], ["算术平均 (a+b)/2", fmt(R, 4)],
                 ["平方平均 √((a²+b²)/2)", fmt(math.sqrt((a * a + b * b) / 2), 4)], ["是否取等", "是（a = b）" if abs(a - b) < 1e-9 else "否"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 三角函数
@lab.reg(id="m-trig", subj="math", book=0, unit="三角函数", title="单位圆与正弦型函数", kw="三角函数 单位圆 周期 振幅 相位 五点作图",
         info="<p><b>单位圆定义</b>：角 α 的终边与单位圆交于 P(x, y)，则 <span class='f'>sin α = y，cos α = x，tan α = y/x</span>。"
              "把 P 的纵坐标随 α 展开，就得到正弦曲线。</p><p><b>y = A sin(ωx + φ) + B</b>：振幅 |A|，周期 <span class='f'>T = 2π/|ω|</span>，"
              "初相 φ，频率 f = 1/T。由 y = sin x 得到它的一种变换顺序：</p><ol><li>向左（φ&gt;0）平移 |φ| 个单位：y = sin(x + φ)</li>"
              "<li>横坐标变为原来的 1/ω：y = sin(ωx + φ)</li><li>纵坐标变为原来的 A 倍，再上移 B：y = A sin(ωx+φ)+B</li></ol>"
              "<p>五点作图法取 ωx + φ = 0, π/2, π, 3π/2, 2π。</p>",
         tasks=["在单位圆模式播放动画，观察 α 每增加 2π，sin α 重复一次。",
                "打开「显示变换过程」，比较先平移后伸缩与先伸缩后平移（平移量 φ/ω）的区别。",
                "令 A=2, ω=2, φ=π/3，写出对称轴方程，再用图像验证。"])
def m_trig(L):
    PI, TAU = math.pi, 2 * math.pi
    c = L.canvas()
    vc = View(c, -1.6, 1.6, -1.6, 1.6, equal=True)
    vg = View(c, -0.3, 4 * PI, -1.6, 1.6)
    S = {"mode": "circle"}

    def set_mode(m):
        S["mode"] = m
        g1.setVisible(m == "circle")
        g2.setVisible(m == "trans")
        L.draw()
    L.group("模式")
    L.seg("", [["circle", "单位圆"], ["trans", "图像变换"]], "circle", set_mode)
    g1 = L.group("角 α")
    al = L.slider("α", 0, 4 * PI, 0.01, PI / 3, None, lambda x: f"{fmt(x, 3)} rad = {fmt(x * 180 / PI, 1)}°")
    cos_on = L.check("同时画余弦 cos x", False)
    tan_on = L.check("画正切线", True)
    L.button("播放 / 暂停", lambda _b: anim.toggle())
    o1 = L.out()
    g2 = L.group("y = A sin(ωx + φ) + B")
    g2.setVisible(False)
    p = L.params({"A": ["A", -3, 3, 0.1, 2], "w": ["ω", 0.2, 4, 0.1, 2], "ph": ["φ", -PI, PI, PI / 12, PI / 3, "", 3], "B": ["B", -2, 2, 0.1, 0]})
    steps = L.check("显示变换过程", False)
    five = L.check("标出五点作图的点", True)
    o2 = L.out()
    anim = L.loop(lambda dt: al.set((al.v + dt * 0.8) % (4 * PI)), False)

    def draw():
        c.clear()
        g = c.g
        if S["mode"] == "circle":
            side = min(c.w * 0.42, c.h)
            vc.pad = (0, c.w - side, (c.h - side) / 2, (c.h - side) / 2)
            vg.pad = (side + 10, 10, (c.h - side) / 2, (c.h - side) / 2)
            vg.r = [-0.3, 4 * PI + 0.2, -1.6, 1.6]
            vc.fit()
            vg.fit()
            vc.grid(ticks=False)
            vg.grid(piX=True)
            a = al.v
            x, y = math.cos(a), math.sin(a)
            D.circle(g, vc.X(0), vc.Y(0), vc.sx, None, T.fg, 1.5)
            g.stroke_style, g.line_width = T.c4, 2
            g.begin_path()
            g.arc(vc.X(0), vc.Y(0), 0.3 * vc.sx, 0, -(a % TAU), True)
            g.stroke()
            vc.seg(0, 0, x, y, T.fg, 1.8)
            vc.seg(x, 0, x, y, T.c1, 3)
            vc.seg(0, 0, x, 0, T.c2, 3)
            if tan_on.v and abs(x) > 0.05:
                t = y / x
                if abs(t) < 3:
                    vc.seg(1, 0, 1, t, T.c3, 3)
                    vc.seg(0, 0, 1, t, T.c3, 1, [3, 3])
            vc.dot(x, y, T.fg, 4.5, True)
            vc.label("P", x, y, T.fg)
            vg.plot(math.sin, T.c1, 2.2)
            if cos_on.v:
                vg.plot(math.cos, T.c2, 2)
            vg.dot(a, y, T.c1, 5, True)
            D.line(g, vc.X(x), vc.Y(y), vg.X(a), vg.Y(y), T.c1, 1, [4, 4])
            if cos_on.v:
                vg.dot(a, x, T.c2, 4.5, True)
            tn = "不存在" if abs(x) < 1e-9 else fmt(y / x, 4)
            q = ["第一象限", "第二象限", "第三象限", "第四象限"][int((a % TAU) // (PI / 2)) % 4]
            o1.set([["sin α", fmt(y, 4)], ["cos α", fmt(x, 4)], ["tan α", tn], ["sin²α + cos²α", fmt(x * x + y * y, 4)],
                    ["终边位置", "坐标轴上" if abs(a % (PI / 2)) < 1e-6 else q]])
            D.text(g, "正弦线", 12, 20, T.c1, size=12)
            D.text(g, "余弦线", 62, 20, T.c2, size=12)
            if tan_on.v:
                D.text(g, "正切线", 112, 20, T.c3, size=12)
        else:
            vg.pad = (0, 0, 0, 0)
            ym = max(3.2, abs(p.A) + abs(p.B) + 0.6)
            vg.r = [-PI, 3 * PI, -ym, ym]
            vg.fit()
            vg.grid(piX=True)
            A, w, ph, B = p.A, p.w, p.ph, p.B
            vg.plot(math.sin, T.muted, 1.4, [5, 4])
            if steps.v:
                vg.plot(lambda x: math.sin(x + ph), T.c3, 1.5, [2, 3])
                vg.plot(lambda x: math.sin(w * x + ph), T.c4, 1.5, [2, 3])
            vg.plot(lambda x: A * math.sin(w * x + ph) + B, T.c1, 2.6)
            if five.v:
                for u in (0, PI / 2, PI, 1.5 * PI, 2 * PI):
                    vg.dot((u - ph) / w, A * math.sin(u) + B, T.c2, 4.5, True)
            Tp = TAU / w
            o2.set([["振幅", fmt(abs(A), 3)], ["周期 T = 2π/ω", fmt(Tp, 4)], ["频率 f", fmt(1 / Tp, 4)], ["初相 φ", fmt(ph, 4)],
                    ["最大值 / 最小值", f"{fmt(B + abs(A), 3)} / {fmt(B - abs(A), 3)}"], ["对称轴", "x = (kπ + π/2 − φ)/ω"],
                    ["对称中心", f"((kπ − φ)/ω, {fmt(B, 2)})"]])
            if steps.v:
                D.text(g, "sin(x+φ)", 12, 18, T.c3)
                D.text(g, "sin(ωx+φ)", 90, 18, T.c4)
    L.on_draw(draw)
