"""数学 · 选择性必修第一册（由 gewu/math.js、math2.js 改写）：圆锥曲线、空间向量。"""
from __future__ import annotations

import math

from ...design.tokens import T, alpha
from ...kit.core import PI, TAU, clamp, fmt
from ...kit.draw import D
from ...kit.registry import lab
from ...kit.solid import draw_mesh, mesh_box
from ...kit.view import Cam3, View, v3


def quad(A, B, C):
    """Ax² + Bx + C = 0 的实根和判别式（A=0 时退化为一次方程，判别式记为 nan）。"""
    if abs(A) < 1e-9:
        return ([] if abs(B) < 1e-9 else [-C / B]), math.nan
    d = B * B - 4 * A * C
    if d < -1e-9:
        return [], d
    if d < 1e-9:
        return [-B / 2 / A], d
    s = math.sqrt(d)
    return [(-B - s) / 2 / A, (-B + s) / 2 / A], d


# ---------------------------------------------------------------- 圆锥曲线与直线
@lab.reg(id="m-conic", subj="math", book=2, unit="直线和圆的方程 · 圆锥曲线的方程", title="圆锥曲线与直线",
         kw="椭圆 双曲线 抛物线 离心率 焦点 准线 渐近线 弦长 直线与圆",
         info="<p>动点 P 沿曲线移动，实时显示定义中的距离关系。</p><p class='fb'>椭圆 x²/a² + y²/b² = 1：|PF₁| + |PF₂| = 2a，c² = a² − b²<br>"
              "双曲线 x²/a² − y²/b² = 1：||PF₁| − |PF₂|| = 2a，c² = a² + b²，渐近线 y = ±(b/a)x<br>抛物线 y² = 2px：|PF| = P 到准线 x = −p/2 的距离<br>"
              "离心率 e = c/a；圆锥曲线统一定义：|PF| / d = e</p><p>直线 y = kx + m 与曲线联立消元，得一元二次方程，用判别式 Δ 判断交点个数，"
              "弦长 |AB| = √(1+k²)·|x₁ − x₂|。</p>",
         tasks=["固定 a，让 b 逐渐接近 a，椭圆离心率如何变化？形状如何变化？", "双曲线中，让直线斜率 k 等于 b/a，交点个数会怎样？",
                "在抛物线上让 P 移动，验证 |PF| 等于到准线的距离。", "圆模式中调 m，观察 d 与 r 比较时的三种位置关系。"])
def m_conic(L):
    c = L.canvas()
    v = View(c, -8, 8, -6, 6, equal=True)
    L.group("曲线")
    kind = L.seg("", [["ell", "椭圆"], ["hyp", "双曲线"], ["par", "抛物线"], ["cir", "圆"]], "ell", lambda _k: (sync(), L.draw()))
    p = L.params({"a": ["a", 0.5, 6, 0.1, 4], "b": ["b", 0.5, 6, 0.1, 2.5], "p": ["p", 0.2, 6, 0.1, 2], "x0": ["圆心 x₀", -4, 4, 0.1, 0],
                  "y0": ["圆心 y₀", -4, 4, 0.1, 0], "r": ["半径 r", 0.5, 5, 0.1, 3]})
    t = L.slider("动点 P 的参数 t", 0, TAU, 0.01, 1)
    L.button("P 沿曲线运动", lambda _b: anim.toggle())
    L.group("直线 y = kx + m")
    ln = L.check("显示直线", True)
    q = L.params({"k": ["k", -4, 4, 0.05, 0.5], "m": ["m", -6, 6, 0.1, 1]})
    L.group("数据")
    out = L.out()
    L.interact(c, view=v)

    def sync():
        k = kind.v
        for key in ("a", "b"):
            p.s(key).el.setVisible(k in ("ell", "hyp"))
        p.s("p").el.setVisible(k == "par")
        for key in ("x0", "y0", "r"):
            p.s(key).el.setVisible(k == "cir")
    sync()
    anim = L.loop(lambda dt: t.set((t.v + dt * 0.7) % TAU), False)

    def draw():
        v.begin()
        a, b, x0, y0, r, pp = p.a, p.b, p.x0, p.y0, p.r, p.p
        K, tt, k, m = kind.v, t.v, q.k, q.m
        rows, xs, disc = [], [], math.nan

        def foci(F1, F2):
            for i, F in enumerate((F1, F2)):
                v.dot(*F, T.fg, 4)
                v.label("F" + "₁₂"[i], *F, T.fg, dy=14)
        if K == "ell":
            A = max(a, b)
            long_x = a >= b
            cc = math.sqrt(abs(a * a - b * b))
            e = cc / A
            v.curve(lambda u: a * math.cos(u), lambda u: b * math.sin(u), 0, TAU, 300, T.c1, 2.4)
            F1, F2 = ((-cc, 0), (cc, 0)) if long_x else ((0, -cc), (0, cc))
            P = (a * math.cos(tt), b * math.sin(tt))
            v.seg(*F1, *P, T.c2, 1.6)
            v.seg(*F2, *P, T.c3, 1.6)
            d1, d2 = math.hypot(P[0] - F1[0], P[1] - F1[1]), math.hypot(P[0] - F2[0], P[1] - F2[1])
            if e > 0:
                dx = A * A / cc
                if long_x:
                    v.seg(dx, v.y0, dx, v.y1, T.muted, 1, [5, 4])
                    v.seg(-dx, v.y0, -dx, v.y1, T.muted, 1, [5, 4])
                else:
                    v.seg(v.x0, dx, v.x1, dx, T.muted, 1, [5, 4])
                    v.seg(v.x0, -dx, v.x1, -dx, T.muted, 1, [5, 4])
            foci(F1, F2)
            v.dot(*P, T.c1, 6, True)
            v.label("P", *P, T.c1)
            xs, disc = quad(b * b + a * a * k * k, 2 * a * a * k * m, a * a * (m * m - b * b))
            rows = [["方程", f"x²/{fmt(a * a, 2)} + y²/{fmt(b * b, 2)} = 1"], ["焦点在", "x 轴" if long_x else "y 轴"], ["c", fmt(cc, 4)],
                    ["离心率 e", fmt(e, 4)], ["|PF₁|", fmt(d1, 3)], ["|PF₂|", fmt(d2, 3)], ["|PF₁| + |PF₂|", f"{fmt(d1 + d2, 4)}（= 2·{fmt(A, 2)}）"]]
        elif K == "hyp":
            cc = math.hypot(a, b)
            e = cc / a
            v.curve(lambda u: a / math.cos(u), lambda u: b * math.tan(u), -1.45, 1.45, 300, T.c1, 2.4)
            v.curve(lambda u: -a / math.cos(u), lambda u: b * math.tan(u), -1.45, 1.45, 300, T.c1, 2.4)
            v.plot(lambda x: b / a * x, T.muted, 1, [6, 4])
            v.plot(lambda x: -b / a * x, T.muted, 1, [6, 4])
            dx = a * a / cc
            v.seg(dx, v.y0, dx, v.y1, T.grid2, 1, [3, 4])
            v.seg(-dx, v.y0, -dx, v.y1, T.grid2, 1, [3, 4])
            u = (tt / TAU) * 2.8 - 1.4
            P = (a / math.cos(u), b * math.tan(u))
            F1, F2 = (-cc, 0), (cc, 0)
            d1, d2 = math.hypot(P[0] + cc, P[1]), math.hypot(P[0] - cc, P[1])
            v.seg(*F1, *P, T.c2, 1.6)
            v.seg(*F2, *P, T.c3, 1.6)
            foci(F1, F2)
            v.dot(*P, T.c1, 6, True)
            v.label("P", *P, T.c1)
            xs, disc = quad(b * b - a * a * k * k, -2 * a * a * k * m, -a * a * (m * m + b * b))
            rows = [["方程", f"x²/{fmt(a * a, 2)} − y²/{fmt(b * b, 2)} = 1"], ["c", fmt(cc, 4)], ["离心率 e", fmt(e, 4)],
                    ["渐近线", f"y = ±{fmt(b / a, 3)}x"], ["|PF₁| − |PF₂|", f"{fmt(d1 - d2, 4)}（= 2·{fmt(a, 2)}）"]]
        elif K == "par":
            v.curve(lambda u: u * u / (2 * pp), lambda u: u, -10, 10, 300, T.c1, 2.4)
            v.seg(-pp / 2, v.y0, -pp / 2, v.y1, T.muted, 1.2, [5, 4])
            v.label("准线", -pp / 2, v.y1 - 0.3, T.muted, dy=0)
            yy = (tt / TAU) * 12 - 6
            P, F = (yy * yy / (2 * pp), yy), (pp / 2, 0)
            v.seg(*F, *P, T.c2, 1.6)
            v.seg(-pp / 2, yy, *P, T.c3, 1.6)
            v.dot(*F, T.fg, 4)
            v.label("F", *F, T.fg, dy=14)
            v.dot(*P, T.c1, 6, True)
            v.label("P", *P, T.c1)
            xs, disc = quad(k * k, 2 * k * m - 2 * pp, m * m)
            rows = [["方程", f"y² = {fmt(2 * pp, 2)}x"], ["焦点", f"({fmt(pp / 2, 3)}, 0)"], ["准线", f"x = {fmt(-pp / 2, 3)}"], ["离心率 e", "1"],
                    ["|PF|", fmt(math.hypot(P[0] - F[0], P[1]), 4)], ["P 到准线距离", fmt(P[0] + pp / 2, 4)]]
        else:
            v.curve(lambda u: x0 + r * math.cos(u), lambda u: y0 + r * math.sin(u), 0, TAU, 200, T.c1, 2.4)
            v.dot(x0, y0, T.fg, 4)
            v.label("C", x0, y0, T.fg)
            d = abs(k * x0 - y0 + m) / math.hypot(k, 1)
            if ln.v:
                fx = (k * (y0 - m) + x0) / (k * k + 1)
                v.seg(x0, y0, fx, k * fx + m, T.c3, 1.4, [4, 3])
            xs, disc = quad(1 + k * k, 2 * (k * (m - y0) - x0), x0 * x0 + (m - y0) ** 2 - r * r)
            rows = [["方程", f"(x−{fmt(x0, 2)})² + (y−{fmt(y0, 2)})² = {fmt(r * r, 2)}"], ["圆心到直线距离 d", fmt(d, 4)],
                    ["位置关系", "相切 d = r" if abs(d - r) < 0.02 else "相交 d < r" if d < r else "相离 d > r"]]
        if ln.v:
            v.plot(lambda x: k * x + m, T.c4, 2)
            for x in xs:
                v.dot(x, k * x + m, T.c4, 5, True)
            rows += [["联立后 Δ", fmt(disc, 3) if math.isfinite(disc) else "一次方程"], ["交点个数", str(len(xs))]]
            if len(xs) == 2:
                rows += [["弦长 |AB|", fmt(math.sqrt(1 + k * k) * abs(xs[0] - xs[1]), 4)],
                         ["弦中点", f"({fmt((xs[0] + xs[1]) / 2, 3)}, {fmt(k * (xs[0] + xs[1]) / 2 + m, 3)})"]]
        out.set(rows)
    L.on_draw(draw)


# ---------------------------------------------------------------- 空间向量求角与距离
@lab.reg(id="m-spacevec", subj="math", book=2, unit="空间向量与立体几何", title="空间向量求角与距离",
         kw="空间直角坐标系 法向量 异面直线所成角 线面角 二面角 点到平面距离 长方体 正方体",
         info="<p>以 D 为原点，DA、DC、DD₁ 分别为 x、y、z 轴建立空间直角坐标系。选择点构成直线和平面，右侧给出完整的向量计算过程。</p>"
              "<p class='fb'>异面直线所成角：cos θ = |u·v| / (|u||v|)，θ ∈ (0, π/2]<br>直线与平面所成角：sin θ = |u·n| / (|u||n|)<br>"
              "二面角：cos⟨n₁, n₂⟩ = n₁·n₂ / (|n₁||n₂|)，二面角为 ⟨n₁,n₂⟩ 或 π − ⟨n₁,n₂⟩（结合图形判断锐钝）<br>点 P 到平面距离：d = |AP·n| / |n|</p>"
              "<p>平面的法向量 n 由平面内两个不共线向量的叉积求得，也可以设 n = (x, y, z) 列方程组求解。</p>",
         tasks=["正方体中求异面直线 A₁B 与 B₁C 所成的角。", "求直线 A₁C 与平面 ABCD 所成角的正弦值。", "求点 A 到平面 A₁BD 的距离（棱长为 2）。",
                "把正方体改成长方体，重新计算上一题。"])
def m_spacevec(L):
    import re
    c = L.canvas()
    cam = Cam3(yaw=-0.5, pitch=0.38, persp=0.06)
    L.orbit(c, cam)
    p = L.params({"a": ["DA 长 a（x 方向）", 1, 4, 0.5, 2], "b": ["DC 长 b（y 方向）", 1, 4, 0.5, 2], "cc": ["DD₁ 长 c（z 方向）", 1, 4, 0.5, 2]})
    V0 = {"A": [1, 0, 0], "B": [1, 1, 0], "C": [0, 1, 0], "D": [0, 0, 0], "A₁": [1, 0, 1], "B₁": [1, 1, 1], "C₁": [0, 1, 1], "D₁": [0, 0, 1]}
    E = [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A"), ("A₁", "B₁"), ("B₁", "C₁"), ("C₁", "D₁"), ("D₁", "A₁"),
         ("A", "A₁"), ("B", "B₁"), ("C", "C₁"), ("D", "D₁")]
    PT = dict(V0)
    for u, w in E:
        PT[u + w + "中点"] = [(x + V0[w][i]) / 2 for i, x in enumerate(V0[u])]
    PT["中心 O"] = [0.5, 0.5, 0.5]
    for f in ("ABCD", "A₁B₁C₁D₁", "ABB₁A₁", "DCC₁D₁", "ADD₁A₁", "BCC₁B₁"):
        ks = re.findall(r"[A-D]₁?", f)
        PT["面" + f + "中心"] = [sum(V0[k][i] for k in ks) / 4 for i in range(3)]
    names = list(PT)
    L.group("问题类型")
    kind = L.select("", [["ll", "异面直线所成角"], ["lp", "直线与平面所成角"], ["pp", "二面角（两平面法向量夹角）"], ["dist", "点到平面的距离"]],
                    "lp", lambda _v: (sync(), L.draw()))
    L.group("选点")
    s1, s2 = L.select("直线 1 起点", names, "A₁"), L.select("直线 1 终点", names, "C")
    s3, s4 = L.select("直线 2 起点", names, "B₁"), L.select("直线 2 终点", names, "C")
    pa, pb, pc = L.select("平面 α 点 1", names, "A"), L.select("平面 α 点 2", names, "B"), L.select("平面 α 点 3", names, "C")
    qa, qb, qc = L.select("平面 β 点 1", names, "A₁"), L.select("平面 β 点 2", names, "B"), L.select("平面 β 点 3", names, "D")
    sp = L.select("点 P", names, "A")
    out = L.out()

    def sync():
        k = kind.v
        for s in (s1, s2):
            s.box.setVisible(k in ("ll", "lp"))
        for s in (s3, s4):
            s.box.setVisible(k == "ll")
        for s in (pa, pb, pc):
            s.box.setVisible(k != "ll")
        for s in (qa, qb, qc):
            s.box.setVisible(k == "pp")
        sp.box.setVisible(k == "dist")
    sync()

    def S(vv):
        return "(" + ", ".join(fmt(x, 3) for x in vv) + ")"

    def ang(x):
        return fmt(x * 180 / PI, 2) + "°"

    def draw():
        c.clear()
        g = c.g
        a, b, cc = p.a, p.b, p.cc

        def P(k):
            return [PT[k][0] * a, PT[k][1] * b, PT[k][2] * cc]

        def to_cam(q):
            return [q[1] - b / 2, q[2] - cc / 2, q[0] - a / 2]
        s = min(c.w, c.h) / (1.9 * max(a, b, cc))
        draw_mesh(c, cam, mesh_box(b, cc, a), s, T.c1)

        def pr(q):
            return cam.proj(to_cam(q), c, s)
        O = pr([0, 0, 0])
        for x, y, z, nm in ((a + 0.8, 0, 0, "x"), (0, b + 0.8, 0, "y"), (0, 0, cc + 0.8, "z")):
            qq = pr([x, y, z])
            D.arrow(g, O[0], O[1], qq[0], qq[1], alpha(T.muted, 0.7), 1.2, 7)
            D.text(g, nm, qq[0] + 4, qq[1], T.muted, size=12)

        def plane(ks, col):
            D.poly(g, [pr(P(k))[:2] for k in ks], alpha(col, 0.22), col, 1.6)

        def seg(k1, k2, col):
            A1, B1 = pr(P(k1)), pr(P(k2))
            D.line(g, A1[0], A1[1], B1[0], B1[1], col, 3)

        def nrm(x, y, z):
            return v3.cross(v3.sub(P(y), P(x)), v3.sub(P(z), P(x)))

        def simp(n):
            mx = max(abs(x) for x in n) or 1
            return [x / mx for x in n]
        k, rows = kind.v, []
        if k == "ll":
            seg(s1.v, s2.v, T.c2)
            seg(s3.v, s4.v, T.c3)
            u, w = v3.sub(P(s2.v), P(s1.v)), v3.sub(P(s4.v), P(s3.v))
            cs = abs(v3.dot(u, w)) / ((v3.len(u) * v3.len(w)) or 1)
            rows += [[f"u = {s1.v}{s2.v}", S(u)], [f"v = {s3.v}{s4.v}", S(w)], ["u·v", fmt(v3.dot(u, w), 4)],
                     ["|u| , |v|", f"{fmt(v3.len(u), 4)} , {fmt(v3.len(w), 4)}"], ["cos θ = |u·v|/(|u||v|)", fmt(cs, 4)],
                     ["所成角 θ", ang(math.acos(clamp(cs, 0, 1)))]]
        if k in ("lp", "dist", "pp"):
            plane([pa.v, pb.v, pc.v], T.c4)
        if k == "pp":
            plane([qa.v, qb.v, qc.v], T.c5)
        n1 = nrm(pa.v, pb.v, pc.v)
        if k == "lp":
            seg(s1.v, s2.v, T.c2)
            u = v3.sub(P(s2.v), P(s1.v))
            sn = abs(v3.dot(u, n1)) / ((v3.len(u) * v3.len(n1)) or 1)
            rows += [[f"方向向量 u = {s1.v}{s2.v}", S(u)], ["平面 α 法向量 n", S(simp(n1))], ["sin θ = |u·n|/(|u||n|)", fmt(sn, 4)],
                     ["线面角 θ", ang(math.asin(clamp(sn, 0, 1))) if v3.len(n1) else "三点共线，不能确定平面"]]
        if k == "pp":
            n2 = nrm(qa.v, qb.v, qc.v)
            cs = v3.dot(n1, n2) / ((v3.len(n1) * v3.len(n2)) or 1)
            th = math.acos(clamp(cs, -1, 1))
            rows += [["n₁（平面 α）", S(simp(n1))], ["n₂（平面 β）", S(simp(n2))], ["cos⟨n₁,n₂⟩", fmt(cs, 4)], ["⟨n₁,n₂⟩", ang(th)],
                     ["二面角", f"{ang(th)} 或 {ang(PI - th)}（结合图形判断）"]]
        if k == "dist":
            qq = pr(P(sp.v))
            D.circle(g, qq[0], qq[1], 6, T.c2, T.stage, 2)
            ap = v3.sub(P(sp.v), P(pa.v))
            d = abs(v3.dot(ap, n1)) / (v3.len(n1) or 1)
            foot = v3.sub(P(sp.v), v3.mul(n1, v3.dot(ap, n1) / (v3.dot(n1, n1) or 1)))
            f = pr(foot)
            D.line(g, qq[0], qq[1], f[0], f[1], T.c2, 2, [5, 3])
            D.circle(g, f[0], f[1], 4, T.c2)
            rows += [["平面 α 法向量 n", S(simp(n1))], [f"向量 {pa.v}P", S(ap)], ["d = |AP·n| / |n|", fmt(d, 4)], ["垂足坐标", S(foot)]]
        for kk in V0:
            qq = pr(P(kk))
            D.circle(g, qq[0], qq[1], 3, T.fg)
            D.text(g, kk, qq[0] + 6, qq[1] - 8, T.fg, size=13, bold=True)
        for sl in (s1, s2, s3, s4, pa, pb, pc, qa, qb, qc, sp):
            if sl.box.isHidden() or sl.v in V0:
                continue
            qq = pr(P(sl.v))
            D.circle(g, qq[0], qq[1], 3.5, T.c2)
            D.text(g, sl.v.replace("中点", "中").replace("面", "").replace("中心", "心"), qq[0] + 6, qq[1] + 10, T.c2, size=11)
        rows.insert(0, ["坐标", f"A({fmt(a)},0,0) C(0,{fmt(b)},0) D₁(0,0,{fmt(cc)})"])
        out.set(rows)
    L.on_draw(draw)
