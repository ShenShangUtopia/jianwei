"""Measurements of actual simulated positions, not preset answers."""
import math


def reset(q):
    q.update(samples=[],next_sample=None,last_time=None,entry=None,gate_time=None,gate_speed=None)


def update(q,previous,current,t0,t1):
    if t1<=t0:
        return
    if q.get('last_time') is not None and t0<q['last_time']-1e-10:
        reset(q)
    q['last_time']=t1
    x0,x1=previous[0],current[0]
    if q['mode']=='ticker':
        period=1/q['frequency']
        next_t=q.get('next_sample')
        if next_t is None:
            next_t=t0
        count=0
        while next_t<=t1+1e-12 and count<100:
            u=max(0,min(1,(next_t-t0)/(t1-t0)))
            q['samples'].append([next_t,x0+(x1-x0)*u])
            next_t+=period
            count+=1
        q['samples']=q['samples'][-240:]
        q['next_sample']=next_t
    elif abs(x1-x0)>1e-15:
        direction=1 if x1>x0 else -1
        edges=[q['x']-q['flag_width']/2,q['x']+q['flag_width']/2]
        events=sorted(((edge-x0)/(x1-x0),edge) for edge in edges if 0<(edge-x0)/(x1-x0)<=1)
        for fraction,edge in events:
            when=t0+(t1-t0)*fraction
            if math.isclose(edge,q['x']-direction*q['flag_width']/2,abs_tol=1e-12):
                q['entry']=when
            elif q.get('entry') is not None and when>q['entry']:
                q['gate_time']=when-q['entry']
                q['gate_speed']=q['flag_width']/q['gate_time']
                q['entry']=None


def readings(q):
    if q['mode']=='gate':
        return [['遮光时间','尚未完整通过' if q.get('gate_time') is None else f"{q['gate_time']:.6g} s"],['遮光区平均速率','尚未给出' if q.get('gate_speed') is None else f"{q['gate_speed']:.6g} m/s"]]
    points=q['samples']
    rows=[['纸带点数',str(len(points))],['时间间隔',f"{1/q['frequency']:.5g} s"]]
    if len(points)>=2:
        rows.append(['末段位移',f"{points[-1][1]-points[-2][1]:.6g} m"])
    if len(points)>=3:
        a,b,c=points[-3:]
        period=1/q['frequency']
        rows += [['中点速度',f"{(c[1]-a[1])/(2*period):.6g} m/s"],['二阶差分加速度',f"{(c[1]-2*b[1]+a[1])/period**2:.6g} m/s²"]]
    return rows


def draw(q,g,P,selected=False):
    from ...kit.draw import D
    from ...design.tokens import T
    x,y=P(q['x'],q['y'])
    col=T.accent if selected else T.fg
    if q['mode']=='gate':
        D.rect(g,x-15,y-18,30,36,None,col,2)
        D.line(g,x,y-15,x,y+15,T.c2,1.5)
    else:
        D.rect(g,x-22,y-12,44,24,T.surface,col,2)
        points=q['samples'][-12:]
        if points:
            lo=min(p[1] for p in points)
            span=max(p[1] for p in points)-lo
            for point in points:
                D.circle(g,x-20+(point[1]-lo)/span*40 if span else x,y,1.4,T.c1)
    D.text(g,q['name'],x,y+34,col,size=12,align='center')
