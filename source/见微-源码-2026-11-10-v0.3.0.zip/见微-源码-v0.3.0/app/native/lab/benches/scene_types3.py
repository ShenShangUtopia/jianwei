"""场景扩展：光、波、理想气体和近代物理的明确解析模型。"""
import math
from .scene_core import C,E,define,line_w,circle_w,rect_w,txt
from .scene_types1 import bounds


def measurements(kind,p):
    if kind=="prism":
        a=math.radians(p.A)
        q=p.n*math.sin(a/2)
        return [["最小偏向角",f"{math.degrees(2*math.asin(q)-a):.3f}" if q<=1 else "无对称出射解","°"],["模型","空气中，对称最小偏向位置",""]]
    if kind=="concavemirror":
        v=1/(1/p.f-1/p.u) if abs(p.u-p.f)>1e-8 else math.inf
        return [["像距",f"{v:.3g}" if math.isfinite(v) else "无穷远","m"],["像的放大率",f"{-v/p.u:.3g}",""],["模型","近轴球面镜，凹面镜f>0",""]]
    if kind=="standingwave":
        return [["波长",f"{2*p.L/p.mode:.3g}","m"],["波腹数",str(int(p.mode)),""],["模型","两端固定弦；模式为整数",""]]
    if kind=="doubleslit":
        return [["条纹间距",f"{p.lam*1e-9*p.L/(p.d*1e-3)*1000:.3g}","mm"],["模型","单色、相干、近轴远场；忽略衍射包络",""]]
    if kind=="gas_piston":
        pressure=p.n*8.314462618*(p.T+273.15)/p.V
        return [["压强",f"{pressure:.4g}","kPa"],["PV / nT", "8.31446","J/(mol·K)"],["模型","封闭理想气体，不计活塞摩擦",""]]
    if kind=="photoelectric":
        energy=4.135667696e-15*p.frequency*1e14-p.work
        return [["最大初动能",f"{max(0,energy):.4g}","eV"],["遏止电压",f"{max(0,energy):.4g}" if energy>0 else "无光电子","V"],["截止频率",f"{p.work/4.135667696e-15/1e14:.4g}","×10¹⁴ Hz"]]
    if kind=="levels":
        energy=13.6*(1/p.low**2-1/p.high**2)
        return [["发射光子能量",f"{energy:.4g}" if energy>0 else "需高能级跃迁至低能级","eV"],["波长",f"{1239.841984/energy:.4g}" if energy>0 else "—","nm"],["模型","氢原子玻尔能级近似",""]]
    if kind=="doppler":
        return [["接收频率",f"{p.f*p.speed/(p.speed-p.source):.3g}","Hz"],["模型","静止观察者；声源速度正值表示接近",""]]
    raise ValueError(kind)


def draw(o):
    kind=o.type
    x,y=o.x,o.y
    p=o.p
    if kind=="prism":
        line_w([(x-1,y-.7),(x,y+1),(x+1,y-.7),(x-1,y-.7)],C.ink2,2)
        line_w([(x-2,y),(x-.55,y),(x+.55,y-.2),(x+2,y-.8)],C.accent,2)
    elif kind=="concavemirror":
        points=[(x+.2*math.cos(a),y+math.sin(a)) for a in [i*math.pi/40-math.pi/2 for i in range(41)]]
        line_w(points,C.ink2,3)
        line_w([(x-2,y+.6),(x,y+.6),(x-2,y-.4)],C.accent,1.8)
    elif kind=="standingwave":
        points=[(x+p.L*i/160,y+2*p.A*math.sin(p.mode*math.pi*i/160)*math.cos(2*math.pi*p.f*E.S.t)) for i in range(161)]
        line_w(points,C.accent,2)
        circle_w(x,y,.06,C.ink)
        circle_w(x+p.L,y,.06,C.ink)
    elif kind=="doubleslit":
        line_w([(x,y-1),(x,y+1)],C.ink,2)
        for yy in (-.2,.2):
            line_w([(x,y+yy),(x+2,y-.7),(x+2,y+.7)],C.faint,1)
        for i in range(-5,6):
            line_w([(x+2,y+i*.14-.025),(x+2,y+i*.14+.025)],C.accent,3)
    elif kind=="gas_piston":
        height=.5+p.V/10
        rect_w(x-.6,y,1.2,2,None,C.ink,2)
        rect_w(x-.55,y,1.1,min(1.8,height),C.line)
        line_w([(x-.6,y+min(1.8,height)),(x+.6,y+min(1.8,height))],C.accent,4)
    elif kind=="photoelectric":
        rect_w(x-.8,y-.8,.1,1.6,C.ink2)
        for i in range(3):
            line_w([(x-2,y+i*.2-.2),(x-.8,y+i*.2-.2)],C.gold,2)
        if p.frequency*1e14*4.135667696e-15>p.work:
            for i in range(4):
                circle_w(x+((E.S.t+i*.3)%1.5),y,.035,C.accent)
    elif kind=="levels":
        for n in range(1,7):
            yy=y+(1-1/n**2)*2
            line_w([(x-1,yy),(x+1,yy)],C.ink2,1.2)
        if p.high>p.low:
            line_w([(x,y+(1-1/p.high**2)*2),(x,y+(1-1/p.low**2)*2)],C.accent,3)
    elif kind=="doppler":
        circle_w(x,y,.12,C.accent)
        for i in range(1,5):
            circle_w(x-p.source/p.speed*i*.4,y,i*.4,None,C.faint,1)
    txt(x,y-1.1,measurements(kind,p)[0][0]+" "+measurements(kind,p)[0][1],align="center",size=11,color=C.ink2)


SPECS=[("prism","棱镜","optics",[("A","顶角","°",20,80,1,60,0),("n","折射率","",1.1,1.8,.01,1.5,2)]),
       ("concavemirror","凹面镜","optics",[("f","焦距","m",.2,3,.05,1,2),("u","物距","m",.1,6,.05,3,2)]),
       ("standingwave","驻波","wave",[("L","弦长","m",1,6,.1,4,1),("mode","波腹数","",1,6,1,2,0),("A","行波振幅","m",.05,.4,.01,.2,2),("f","振动频率","Hz",.2,3,.1,1,1)]),
       ("doubleslit","双缝干涉","wave",[("lam","波长","nm",380,750,1,550,0),("d","双缝距离","mm",.1,2,.01,.5,2),("L","屏距","m",.5,5,.1,2,1)]),
       ("gas_piston","气缸活塞","thermal",[("n","物质的量","mol",.01,2,.01,.1,2),("T","温度","°C",-100,200,1,25,0),("V","体积","L",.1,10,.1,2,1)]),
       ("photoelectric","光电效应","atomic",[("frequency","入射光频率","×10¹⁴ Hz",1,20,.1,8,1),("work","逸出功","eV",1,5,.1,2.3,1)]),
       ("levels","氢原子能级跃迁","atomic",[("high","初态主量子数","",1,6,1,3,0),("low","末态主量子数","",1,6,1,2,0)]),
       ("doppler","多普勒效应","wave",[("f","声源频率","Hz",100,2000,10,500,0),("speed","声速","m/s",300,360,1,340,0),("source","接近速度","m/s",-150,150,1,30,0)])]
for _kind,_name,_group,_params in SPECS:
    define(_kind,_name,_group,2,.6,"解析教学模型；参数、假设与读数见调整栏",_params,None,None,draw,lambda o:measurements(o.type,o.p),lambda o:bounds(o.x-2.2,o.x+4,o.y-1.3,o.y+2.2))
