"""场景搭建的物体类型（二）：带电粒子、电场、光学、波（由 legacy/lab-phys.js 改写）。"""
from __future__ import annotations

import math

from ...kit.core import PI, TAU, clamp
from .scene_core import (C, E, NS, arrow_p, arrow_w, circle_p, circle_w, deg, define, draw_trail, fmt, half_h, half_w, line_w, push_trail, px, py, rad, rect_w, sp, txt,
                         txt_p, vel_arrow, with_alpha)
from .scene_types1 import LB, b_at, bounds, e_at


# ---------------------------------------------------------------- 带电粒子
def _pt_init(o, *_):
    a = rad(o.p.th)
    o.s.update(rx=0.0, ry=0.0, vx=o.p.v0 * math.cos(a), vy=o.p.v0 * math.sin(a))
    o.trail, o._tt = [], 0


def _pt_step(o, dt):
    s = o.s
    if abs(o.p.q) < 1e-6:
        s.rx += s.vx * dt
        s.ry += s.vy * dt
        return
    x, y = o.x + s.rx, o.y + s.ry
    Ef, Bz = e_at(x, y), b_at(x, y)
    ratio = o.p.q / o.p.m   # (μC / mg) = C/kg 的等价比
    ax, ay = ratio * (Ef.Ex + s.vy * Bz), ratio * (Ef.Ey - s.vx * Bz)
    s.vx += ax * dt
    s.vy += ay * dt
    s.rx += s.vx * dt
    s.ry += s.vy * dt
    push_trail(o, o.x + s.rx, o.y + s.ry, dt, 0.02)


def _pt_draw(o):
    s = o.s
    x, y = o.x + s.rx, o.y + s.ry
    draw_trail(o, C.accent, 0.55)
    pos = o.p.q >= 0
    circle_w(x, y, 0.14, with_alpha(C.accent if pos else C.ink2, 0.85), C.ink, 1.2)
    line_w([(x - 0.075, y), (x + 0.075, y)], E.S.bg, 1.4)
    if pos:
        line_w([(x, y - 0.075), (x, y + 0.075)], E.S.bg, 1.4)
    if E.S.show.vectors:
        v = math.hypot(s.vx, s.vy)
        if v > 1e-6:
            vel_arrow(x, y, s.vx / v * min(0.9, v * 0.4), s.vy / v * min(0.9, v * 0.4), "v")
        Ef, Bz = e_at(x, y), b_at(x, y)
        fx, fy = o.p.q * (Ef.Ex + s.vy * Bz), o.p.q * (Ef.Ey - s.vx * Bz)
        fm = math.hypot(fx, fy)
        if fm > 1e-9:
            arrow_w(x, y, fx / fm * 0.5, fy / fm * 0.5, C.jade, 1.5, 7, "")
    lx, ly, align = x + 0.28, y - 0.44, "left"
    for pl in E.S.objects:
        if pl.visible and pl.type == "plates" and abs(x - pl.x) <= pl.p.len / 2 and abs(y - pl.y) <= pl.p.d / 2:
            lx, ly, align = x, pl.y - pl.p.d / 2 - 0.34, "center"
            break
    txt(lx, ly, f"带电粒子 q={fmt(o.p.q, 1)} μC", align=align, size=10.5, color=C.ink2)


def _pt_read(o):
    s = o.s
    x, y = o.x + s.rx, o.y + s.ry
    Ef, Bz = e_at(x, y), b_at(x, y)
    v = math.hypot(s.vx, s.vy)
    ratio = o.p.q / o.p.m
    a = math.hypot(ratio * (Ef.Ex + s.vy * Bz), ratio * (Ef.Ey - s.vx * Bz))
    rows = [["速度 v", fmt(v, 2), "m/s"], ["加速度 a", fmt(a, 2), "m/s²"], ["电场 E", fmt(math.hypot(Ef.Ex, Ef.Ey), 1), "V/m"], ["磁感强度 B", fmt(Bz, 2), "T"]]
    if abs(Bz) > 1e-6 and abs(o.p.q) > 1e-6:
        k = abs(o.p.m / o.p.q) / abs(Bz)
        rows += [["回旋半径 R", fmt(k * v, 2), "m"], ["回旋周期 T", fmt(TAU * k, 2), "s"]]
    if abs(Ef.phi) > 1e-6:
        rows.append(["电势能 Ep", fmt(o.p.q * Ef.phi, 2), "μJ"])
    return rows


define("particle", "带电粒子", "mag", 5, 0.3, "受电场力与洛伦兹力，轨迹可留影",
       [("q", "电荷量 q", "μC", -3, 3, 0.1, 1, 1), ("m", "质量 m", "mg", 0.2, 5, 0.1, 1, 1), ("v0", "初速 v₀", "m/s", 0, 5, 0.1, 1.2, 1), ("th", "入射角 θ", "°", -180, 180, 5, 0, 0)],
       _pt_init, _pt_step, _pt_draw, _pt_read, lambda o: bounds(o.x + o.s.rx - 0.3, o.x + o.s.rx + 0.3, o.y + o.s.ry - 0.3, o.y + o.s.ry + 0.3), _pt_init)


# ---------------------------------------------------------------- 电场
def _pc_draw(o):
    pos = o.p.Q >= 0
    if E.S.show.field:
        Rmax = 2.4
        for i in range(18):
            a = i / 18 * TAU
            cs, sn = math.cos(a), math.sin(a)
            line_w([(o.x + cs * 0.2, o.y + sn * 0.2), (o.x + cs * Rmax, o.y + sn * Rmax)], with_alpha(C.ink2, 0.17), 1)
            if i % 2 == 0:
                r, d = (1.1, 1) if pos else (0.5, -1)
                arrow_w(o.x + cs * r, o.y + sn * r, cs * 0.18 * d, sn * 0.18 * d, with_alpha(C.ink2, 0.7), 1.1, 5, "")
        for k in (1, 2, 3):
            circle_w(o.x, o.y, 0.45 * k, None, with_alpha(C.jade, 0.28), 1, [3, 5])
        txt(o.x + 1.55, o.y + 0.12, "等势线", size=9.5, color=with_alpha(C.jade, 0.85))
    circle_w(o.x, o.y, 0.17, with_alpha(C.accent if pos else C.ink2, 0.9), C.ink, 1.3)
    txt(o.x, o.y, "+" if pos else "−", align="center", size=13, weight=700, color=E.S.bg, halo=False)
    txt(o.x, o.y + 0.42, f"点电荷 Q={'+' if pos else ''}{fmt(o.p.Q, 1)} nC", color=C.ink2, **LB)


define("pointcharge", "点电荷", "efield", 1, 0.4, "点电荷：电场线与等势线", [("Q", "电荷量 Q", "nC", -10, 10, 0.5, 2, 1)], None, None, _pc_draw,
       lambda o: [["电荷量 Q", fmt(o.p.Q, 1), "nC"], ["1 m 处场强", fmt(8.99 * abs(o.p.Q), 1), "V/m"], ["符号", "正电荷" if o.p.Q >= 0 else "负电荷", ""]])


def _pl_draw(o):
    d, ln = o.p.d, o.p.len
    xL, xR, yT, yB = o.x - ln / 2, o.x + ln / 2, o.y + d / 2, o.y - d / 2
    line_w([(xL, yT), (xR, yT)], C.ink, 2.6)
    line_w([(xL, yB), (xR, yB)], C.ink, 2.6)
    up = o.p.pol > 0
    txt(xL - 0.16, yT, "+" if up else "−", align="right", size=13, weight=700, color=C.accent if up else C.ink2)
    txt(xL - 0.16, yB, "−" if up else "+", align="right", size=13, weight=700, color=C.ink2 if up else C.accent)
    if E.S.show.field and o.p.U > 0:
        for i in range(4):
            X = xL + ln * (i + 0.5) / 4
            if up:
                arrow_w(X, yT - 0.02, 0, -d + 0.04, with_alpha(C.ink2, 0.55), 1.1, 5, "")
            else:
                arrow_w(X, yB + 0.02, 0, d - 0.04, with_alpha(C.ink2, 0.55), 1.1, 5, "")
    txt(o.x, yT + 0.28, f"平行板 U={fmt(o.p.U, 1)} V · E={fmt(o.p.U / max(0.01, d), 1)} V/m", color=C.ink2, **LB)


define("plates", "平行板电容器", "efield", 1, 0.55, "板间匀强电场，可调电压与板距",
       [("U", "电压 U", "V", 0, 40, 1, 10, 1), ("d", "板距 d", "m", 0.2, 1.2, 0.05, 0.5, 2), ("len", "板长 L", "m", 0.4, 2.4, 0.1, 1.2, 1),
        NS(k="pol", label="上板极性", unit="", kind="enum", options=[NS(v=1, label="上正下负"), NS(v=-1, label="上负下正")], **{"def": 1})],
       None, None, _pl_draw,
       lambda o: [["电压 U", fmt(o.p.U, 1), "V"], ["板距 d", fmt(o.p.d, 2), "m"], ["场强 E=U/d", fmt(o.p.U / max(0.01, o.p.d), 1), "V/m"], ["方向", "上板 → 下板" if o.p.pol > 0 else "下板 → 上板", ""]],
       lambda o: bounds(o.x - o.p.len / 2, o.x + o.p.len / 2, o.y - o.p.d / 2 - 0.2, o.y + o.p.d / 2 + 0.2))


# ---------------------------------------------------------------- 光学
def _find(*types):
    for o in E.S.objects:
        if o.visible and o.type in types:
            return o
    return None


def obj_height(src):
    return 0.5 if src.p.h is None else src.p.h


def tip_of(src):
    return src.x, src.y + obj_height(src)


def ray_to_edge(x, y, dx, dy, color, dash=None):
    ln = math.hypot(dx, dy)
    if ln < 1e-9:
        return
    dx, dy = dx / ln, dy / ln
    t = 1e9
    hw, hh = half_w(), half_h()
    cam = E.cam
    if abs(dx) > 1e-9:
        for t1 in ((cam.x + hw - x) / dx, (cam.x - hw - x) / dx):
            if t1 > 0:
                t = min(t, t1)
    if abs(dy) > 1e-9:
        for t1 in ((cam.y + hh - y) / dy, (cam.y - hh - y) / dy):
            if t1 > 0:
                t = min(t, t1)
    if not math.isfinite(t) or t > 1e6:
        t = hw * 2
    line_w([(x, y), (x + dx * t, y + dy * t)], color, 1.3, dash)


def optics_info():
    src, lens = _find("lightsrc"), _find("convex", "concave")
    if not src or not lens:
        return None
    f = lens.p.f if lens.type == "convex" else -abs(lens.p.f)
    u = lens.x - src.x
    if u <= 0.02:
        return None
    den = 1 / f - 1 / u
    v = 1 / den if abs(den) > 1e-12 else math.inf
    m = -v / u
    return NS(src=src, lens=lens, f=f, u=u, v=v, m=m, tip=tip_of(src), H=0.92, img=NS(x=lens.x + v, y=lens.y + m * obj_height(src)))


def _ls_draw(o):
    h, x, y = obj_height(o), o.x, o.y
    circle_w(x, y, 0.08, with_alpha(C.accent, 0.9), C.ink, 1.2)
    line_w([(x, y), (x, y + h)], C.accent, 2)
    arrow_p(px(x), py(y + h) + 7, px(x), py(y + h), C.accent, 2, 8)
    for i in range(8):
        a = i / 8 * TAU
        line_w([(x + math.cos(a) * 0.14, y + math.sin(a) * 0.14), (x + math.cos(a) * 0.22, y + math.sin(a) * 0.22)], with_alpha(C.accent, 0.55), 1)
    txt(x, y - 0.28, "光源", color=C.ink2, **LB)


define("lightsrc", "光源", "optics", 3, 0.4, "点光源 + 物高箭头，供透镜/平面镜成像", [("h", "物高 h", "m", 0.1, 0.9, 0.05, 0.5, 2)], None, None, _ls_draw,
       lambda o: [["物高 h", fmt(obj_height(o), 2), "m"], ["位置 x", fmt(o.x, 2), "m"]], lambda o: bounds(o.x - 0.25, o.x + 0.25, o.y - 0.1, o.y + obj_height(o) + 0.25))


def _lens_body(o, convex):
    g = E.g
    X, Yt, Yb, Ym = px(o.x), py(o.y + 0.92), py(o.y - 0.92), py(o.y)
    b = sp(0.17 if convex else 0.13)
    g.begin_path()
    if convex:
        g.move_to(X, Yt)
        g.quad_to(X + b * 1.7, Ym, X, Yb)
        g.quad_to(X - b * 1.7, Ym, X, Yt)
    else:
        g.move_to(X - b, Yt)
        g.line_to(X + b, Yt)
        g.quad_to(X - b * 0.3, Ym, X + b, Yb)
        g.line_to(X - b, Yb)
        g.quad_to(X + b * 0.3, Ym, X - b, Yt)
    g.close_path()
    g.fill_style = with_alpha(C.ink2, 0.12)
    g.fill()
    g.stroke_style, g.line_width = C.ink2, 1.4
    g.stroke()
    line_w([(o.x - 2.6, o.y), (o.x + 2.6, o.y)], with_alpha(C.ink2, 0.35), 1, [4, 5])
    f = abs(o.p.f)
    for s in (-1, 1):
        fx = o.x + s * f
        line_w([(fx, o.y - 0.1), (fx, o.y + 0.1)], with_alpha(C.accent, 0.9), 1.6)
        txt(fx, o.y - 0.24, "F′" if s > 0 else "F", align="center", size=9.5, color=C.accent)
    circle_w(o.x, o.y, 0.035, C.ink2)


def _lens_rays(lens):
    info = optics_info()
    if not info or info.lens is not lens or not math.isfinite(info.v):
        return
    lx, ly, H = lens.x, lens.y, info.H
    tip, I = info.tip, info.img
    rays = []
    if abs(tip[1] - ly) < H * 1.1:   # ① 平行于主光轴
        dx, dy = I.x - lx, I.y - tip[1]
        if info.v < 0:
            dx, dy = -dx, -dy
        rays.append((tip, (lx, tip[1]), (dx, dy)))
    rays.append((tip, (lx, ly), (lx - tip[0], ly - tip[1])))   # ② 过光心
    fx = lx - info.f   # ③ 过焦点
    if abs(fx - tip[0]) > 1e-3:
        yl = tip[1] + (lx - tip[0]) / (fx - tip[0]) * (ly - tip[1])
        if abs(yl - ly) < H * 1.15:
            rays.append((tip, (lx, yl), (1, 0)))
    for i, (frm, at, d) in enumerate(rays):
        col = C.accent if i == 0 else C.ink2 if i == 1 else C.jade
        line_w([frm, at], with_alpha(col, 0.9), 1.3)
        if math.hypot(*d) > 1e-9:
            ray_to_edge(at[0], at[1], d[0], d[1], with_alpha(col, 0.62))
    if math.isfinite(I.x) and math.isfinite(I.y):
        real = info.v > 0
        col = C.accent if real else C.ink2
        line_w([(I.x, ly), (I.x, I.y)], with_alpha(col, 0.9), 1.6, None if real else [4, 4])
        circle_p(px(I.x), py(I.y), 2.6, col)
        txt(I.x, I.y + (0.26 if I.y > ly else -0.26), "实像" if real else "虚像", align="center", size=9.5, color=col)
        scr = _find("screen")
        if scr and real and abs(scr.x - I.x) < 0.12:
            circle_p(px(scr.x), py(I.y), 5, with_alpha(C.accent, 0.35))
            circle_p(px(scr.x), py(I.y), 2.4, C.accent)
            txt(scr.x, I.y + 0.3, "屏上成像", align="center", size=9.5, color=C.accent)


def _convex_draw(o):
    if E.S.show.rays:
        _lens_rays(o)
    _lens_body(o, True)
    txt(o.x, o.y + 1.22, f"凸透镜 f={fmt(o.p.f, 2)} m", color=C.ink2, **LB)


def _concave_draw(o):
    if E.S.show.rays:
        _lens_rays(o)
    _lens_body(o, False)
    txt(o.x, o.y + 1.22, f"凹透镜 |f|={fmt(o.p.f, 2)} m", color=C.ink2, **LB)


def _convex_read(o):
    i = optics_info()
    if not i:
        return [["焦距 f", fmt(o.p.f, 2), "m"], ["需要", "光源 + 凸透镜", ""]]
    return [["焦距 f", fmt(o.p.f, 2), "m"], ["物距 u", fmt(i.u, 2), "m"], ["像距 v", fmt(i.v, 2), "m"], ["放大率 m", fmt(i.m, 2), ""],
            ["像", "实像（倒立）" if i.v > 0 else "虚像（正立）", ""]]


def _concave_read(o):
    i = optics_info()
    if not i:
        return [["焦距 |f|", fmt(o.p.f, 2), "m"], ["需要", "光源 + 凹透镜", ""]]
    return [["焦距 |f|", fmt(o.p.f, 2), "m"], ["物距 u", fmt(i.u, 2), "m"], ["像距 v", fmt(i.v, 2), "m"], ["放大率 m", fmt(i.m, 2), ""], ["像", "虚像（正立缩小）", ""]]


define("convex", "凸透镜", "optics", 2, 0.5, "凸透镜成像，三条特殊光线", [("f", "焦距 f", "m", 0.3, 3, 0.05, 0.9, 2)], None, None, _convex_draw, _convex_read,
       lambda o: bounds(o.x - 0.3, o.x + 0.3, o.y - 1.05, o.y + 1.05))
define("concave", "凹透镜", "optics", 2, 0.5, "凹透镜，成正立缩小虚像", [("f", "焦距 |f|", "m", 0.3, 3, 0.05, 0.8, 2)], None, None, _concave_draw, _concave_read,
       lambda o: bounds(o.x - 0.3, o.x + 0.3, o.y - 1.05, o.y + 1.05))


def _mir_draw(o):
    a, L = rad(o.p.ang), o.p.L
    u, n = (math.sin(a), math.cos(a)), (math.cos(a), -math.sin(a))
    p1, p2 = (o.x - u[0] * L / 2, o.y - u[1] * L / 2), (o.x + u[0] * L / 2, o.y + u[1] * L / 2)
    for i in range(1, 10):
        f = i / 10
        x0, y0 = p1[0] + (p2[0] - p1[0]) * f, p1[1] + (p2[1] - p1[1]) * f
        line_w([(x0, y0), (x0 - n[0] * 0.16, y0 - n[1] * 0.16)], with_alpha(C.ink2, 0.45), 1)
    line_w([p1, p2], C.ink, 2.2)
    src = _find("lightsrc")
    if E.S.show.rays and src:
        tip = tip_of(src)
        d = (tip[0] - o.x) * n[0] + (tip[1] - o.y) * n[1]
        virt = (tip[0] - 2 * d * n[0], tip[1] - 2 * d * n[1])
        for f in (-0.26, 0.16):
            hp = (o.x + u[0] * L * f, o.y + u[1] * L * f)
            line_w([tip, hp], with_alpha(C.ink2, 0.55), 1.1)
            vx, vy = hp[0] - tip[0], hp[1] - tip[1]
            dd = vx * n[0] + vy * n[1]
            ray_to_edge(hp[0], hp[1], vx - 2 * dd * n[0], vy - 2 * dd * n[1], with_alpha(C.accent, 0.55))
            line_w([virt, hp], with_alpha(C.ink2, 0.2), 1, [3, 5])
        top = src.y + obj_height(src)
        arrow_p(px(virt[0]), py(src.y), px(virt[0]), py(top), with_alpha(C.ink2, 0.8), 1.4, 7)
        txt(virt[0], top + 0.24, "虚像", align="center", size=9.5, color=C.ink2)
    txt(o.x, o.y + L / 2 + 0.3, f"平面镜 L={fmt(o.p.L, 1)} m", color=C.ink2, **LB)


def _mir_read(o):
    src = _find("lightsrc")
    if not src:
        return [["镜长 L", fmt(o.p.L, 2), "m"], ["像", "需要光源", ""]]
    a = rad(o.p.ang)
    tip = tip_of(src)
    d = abs((tip[0] - o.x) * math.cos(a) - (tip[1] - o.y) * math.sin(a))
    return [["物距 u", fmt(d, 2), "m"], ["像距 v", fmt(d, 2), "m"], ["像高", fmt(obj_height(src), 2), "m"], ["放大率", "1.00", ""]]


def _mir_bounds(o):
    a = rad(o.p.ang)
    ex, ey = abs(math.sin(a)) * o.p.L / 2, abs(math.cos(a)) * o.p.L / 2
    return bounds(o.x - ex - 0.28, o.x + ex + 0.28, o.y - ey - 0.2, o.y + ey + 0.2)


define("mirror", "平面镜", "optics", 2, 0.55, "平面镜反射，等距等大虚像", [("L", "镜长 L", "m", 0.8, 3, 0.1, 2, 1), ("ang", "倾角 φ", "°", 0, 180, 5, 0, 0)], None, None, _mir_draw, _mir_read, _mir_bounds)


def _scr_draw(o):
    L = o.p.L
    line_w([(o.x, o.y - L / 2), (o.x, o.y + L / 2)], C.ink, 2.2)
    for i in range(12):
        yy = o.y - L / 2 + L * i / 11
        line_w([(o.x, yy), (o.x - 0.1, yy + 0.06)], with_alpha(C.ink2, 0.5), 1)
    txt(o.x - 0.12, o.y + L / 2 + 0.22, "光屏", align="right", size=10.5, color=C.ink2)


def _scr_read(o):
    i = optics_info()
    if not i:
        return [["屏高 L", fmt(o.p.L, 2), "m"], ["像距", "—", ""]]
    return [["屏高 L", fmt(o.p.L, 2), "m"], ["与透镜距离", fmt(abs(o.x - i.lens.x), 2), "m"], ["是否成像", "是" if i.v > 0 and abs(o.x - i.img.x) < 0.12 else "否", ""]]


define("screen", "光屏", "optics", 1, 0.4, "承接实像的光屏", [("L", "屏高 L", "m", 0.4, 2, 0.1, 1.2, 1)], None, None, _scr_draw, _scr_read,
       lambda o: bounds(o.x - 0.2, o.x + 0.2, o.y - o.p.L / 2, o.y + o.p.L / 2))


def _gl_draw(o):
    w, h, n, th1 = o.p.w, o.p.h, o.p.n, rad(o.p.th)
    x0, x1, y0 = o.x - w / 2, o.x + w / 2, o.y - h / 2
    rect_w(x0, y0, w, h, with_alpha(C.ink2, 0.08), with_alpha(C.ink2, 0.7), 1.4)
    txt(o.x, o.y - h / 2 - 0.22, f"玻璃砖 n={fmt(n, 2)}", color=C.ink2, **LB)
    if not E.S.show.rays:
        return
    yin = o.y + 0.18
    d = (math.cos(th1), -math.sin(th1))
    P0 = (x0, yin)
    st = (P0[0] - d[0] * 1.4, P0[1] - d[1] * 1.4)
    line_w([st, P0], with_alpha(C.ink, 0.7), 1.2)
    line_w([(x0 - 0.5, yin), (x0 + 0.5, yin)], with_alpha(C.ink2, 0.35), 1, [3, 4])
    th2 = math.asin(clamp(math.sin(th1) / n, -1, 1))
    d2 = (math.cos(th2), -math.sin(th2))
    t_in = w / max(0.05, d2[0])
    P1 = (P0[0] + d2[0] * t_in, P0[1] + d2[1] * t_in)
    line_w([P0, P1], with_alpha(C.accent, 0.85), 1.3)
    line_w([(x1 - 0.5, P1[1]), (x1 + 0.5, P1[1])], with_alpha(C.ink2, 0.35), 1, [3, 4])
    ray_to_edge(P1[0], P1[1], d[0], d[1], with_alpha(C.accent, 0.6), [5, 4])
    txt(st[0] + 0.1, st[1] + 0.2, f"入射 θ₁={fmt(o.p.th, 0)}°", size=9.5, color=C.ink2)
    txt(P0[0] + 0.16, P0[1] - 0.24, f"折射 θ₂={fmt(deg(th2), 1)}°", size=9.5, color=C.accent)


def _gl_read(o):
    th1 = rad(o.p.th)
    th2 = math.asin(clamp(math.sin(th1) / o.p.n, -1, 1))
    return [["折射率 n", fmt(o.p.n, 2), ""], ["入射角 θ₁", fmt(o.p.th, 0), "°"], ["折射角 θ₂", fmt(deg(th2), 1), "°"], ["侧移 Δ", fmt(abs(o.p.h / math.cos(th2) * math.sin(th1 - th2)), 2), "m"]]


define("glass", "玻璃砖", "optics", 2, 0.5, "矩形玻璃砖，斯涅尔定律折射",
       [("n", "折射率 n", "", 1.05, 2, 0.01, 1.5, 2), ("w", "宽 w", "m", 0.4, 1.6, 0.05, 1, 2), ("h", "高 h", "m", 0.6, 2.4, 0.1, 1.6, 1), ("th", "入射角 θ₁", "°", 0, 70, 1, 40, 0)],
       None, None, _gl_draw, _gl_read, lambda o: bounds(o.x - o.p.w / 2 - 0.05, o.x + o.p.w / 2 + 0.05, o.y - o.p.h / 2 - 0.05, o.y + o.p.h / 2 + 0.05))


# ---------------------------------------------------------------- 波
def _ws_draw(o):
    S = E.S
    yv = o.y + o.p.A * math.sin(TAU * o.p.f * S.t)
    line_w([(o.x, o.y - 0.44), (o.x, yv)], C.ink2, 1.6)
    circle_w(o.x, yv, 0.09, with_alpha(C.accent, 0.9), C.ink, 1.2)
    line_w([(o.x, o.y - 0.44), (o.x, o.y - 0.54)], C.ink2, 2)
    line_w([(o.x - 0.28, o.y - 0.54), (o.x + 0.28, o.y - 0.54)], C.ink, 2.2)
    if S.show.vectors:
        arrow_w(o.x + 0.2, yv, 0, -o.p.A, with_alpha(C.accent, 0.85), 1.2, 6, "A")
    txt(o.x, o.y + 0.56, f"波源 f={fmt(o.p.f, 1)} Hz", color=C.ink2, **LB)


define("wavesrc", "波源", "wave", 3, 0.35, "上下振动产生横波，给绳/弦供波", [("f", "频率 f", "Hz", 0.2, 3, 0.1, 1.2, 1), ("A", "振幅 A", "m", 0.05, 0.5, 0.01, 0.3, 2)], None, None, _ws_draw,
       lambda o: [["频率 f", fmt(o.p.f, 2), "Hz"], ["周期 T", fmt(1 / o.p.f, 2), "s"], ["振幅 A", fmt(o.p.A, 2), "m"]], lambda o: bounds(o.x - 0.32, o.x + 0.32, o.y - 0.6, o.y + 0.55))


def _str_draw(o):
    S = E.S
    L, lam = o.p.L, o.p.lam
    src, bd = None, math.inf
    for s in S.objects:
        if s.type == "wavesrc" and s.visible:
            d = math.hypot(s.x - o.x, s.y - o.y)
            if d < bd:
                bd, src = d, s
    use = bool(src) and bd < 1.6
    f, A = (src.p.f, src.p.A) if use else (1.2, 0.2)
    v = lam * f
    front = min(L, v * S.t)
    if use and front > 0.01:
        n = max(40, round(front / lam * 90))
        pts = [(o.x + front * i / n, o.y + A * math.sin(TAU * (f * S.t - front * i / n / lam))) for i in range(n + 1)]
    else:
        pts = [(o.x, o.y), (o.x + L, o.y)]
    line_w([(o.x, o.y), (o.x + L, o.y)], with_alpha(C.ink2, 0.28), 1, [3, 5])
    line_w(pts, C.ink2, 1.8)
    circle_w(o.x, o.y, 0.05, C.ink2)
    circle_w(o.x + L, o.y, 0.05, C.ink2)
    if use and 0.02 < front < L:
        line_w([(o.x + front, o.y - 0.5), (o.x + front, o.y + 0.5)], with_alpha(C.accent, 0.75), 1.3, [4, 4])
        txt(o.x + front + 0.08, o.y + 0.58, "波前", align="left", size=9.5, color=C.accent)
        arrow_w(o.x + front - 0.05, o.y + 0.3, 0.4, 0, with_alpha(C.ink2, 0.55), 1.2, 6, "")
    if use:
        txt(o.x + 0.08, o.y + 0.86, f"绳波 λ={fmt(lam, 2)} m · v=λf={fmt(v, 2)} m/s", align="left", size=10.5, color=C.ink2)
    else:
        txt(o.x + L / 2, o.y + 0.55, "需要波源（放在绳左端）", color=C.faint, **LB)


def _str_read(o):
    src = _find("wavesrc")
    f = src.p.f if src else 1.2
    v = o.p.lam * f
    return [["波长 λ", fmt(o.p.lam, 2), "m"], ["频率 f", fmt(f, 2), "Hz"], ["波速 v=λf", fmt(v, 2), "m/s"], ["波前位置", fmt(min(o.p.L, v * E.S.t), 2), "m"]]


define("string", "绳 / 弦", "wave", 2, 0.4, "横波沿绳传播，显示波前", [("L", "绳长 L", "m", 1, 8, 0.1, 5, 1), ("lam", "波长 λ", "m", 0.3, 2.4, 0.05, 1.1, 2)], None, None, _str_draw, _str_read,
       lambda o: bounds(o.x - 0.15, o.x + o.p.L + 0.15, o.y - 0.52, o.y + 0.52))


def _unused():
    _ = (PI, txt_p)
