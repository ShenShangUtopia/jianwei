"""Bounded analytical models, explicit assumptions; not a new general engine."""
import math
from ...design.tokens import T
from .scene_core import C,E,define,line_w,circle_w,rect_w,txt
from .scene_types1 import bounds


def values(kind,p,t=0.):
    if kind=='fiber':
        valid=p.core>p.clad
        critical=math.degrees(math.asin(p.clad/p.core)) if valid else None
        incidence=90-p.angle
        return dict(critical=critical,reflected=valid and incidence>=critical,incidence=incidence,aperture=math.sqrt(max(0,p.core**2-p.clad**2)))
    if kind=='conical':
        angle=math.radians(p.angle)
        omega=math.sqrt(p.g/(p.L*math.cos(angle)))
        return dict(radius=p.L*math.sin(angle),tension=p.m*p.g/math.cos(angle),period=2*math.pi/omega,omega=omega)
    if kind=='cyclotron':
        q=p.charge*1e-19
        mass=p.mass*1e-27
        speed=q*p.B*p.radius/mass
        return dict(frequency=q*p.B/(2*math.pi*mass),speed=speed,energy=.5*mass*speed**2,valid=speed<.1*299792458)
    if kind=='selector':
        drift=p.E/p.B
        omega=p.charge*1e-19*p.B/(p.mass*1e-27)
        v0=p.speed*1e5
        # Exact crossed-field trajectory for initial velocity along x.
        time=p.flight*1e-9
        delta=v0-drift
        x=drift*time+delta*math.sin(omega*time)/omega
        y=delta*(math.cos(omega*time)-1)/omega
        return dict(selected=drift,x=x,y=y,omega=omega,valid=max(v0,drift)<.1*299792458)
    if kind=='induction_rail':
        damping=p.B**2*p.length**2/p.R
        tau=p.m/damping
        terminal=p.force/damping
        delta=p.v0-terminal
        exp=math.exp(-max(0,t)/tau)
        speed=terminal+delta*exp
        distance=terminal*t+delta*tau*(1-exp)
        current=p.B*p.length*speed/p.R
        joule=damping*(terminal**2*t+2*terminal*delta*tau*(1-exp)+delta**2*tau/2*(1-exp**2))
        return dict(speed=speed,distance=distance,current=current,brake=p.B*p.length*current,tau=tau,joule=max(0,joule))
    raise ValueError(kind)


def readings(o):
    p=o.p
    v=values(o.type,p,E.S.t)
    if o.type=='fiber':
        return [['临界角',f"{v['critical']:.4g}" if v['critical'] is not None else '芯层折射率须更大','°'],['界面入射角',f"{v['incidence']:.4g}",'°'],['状态','全反射' if v['reflected'] else '存在折射泄漏',''],['模型','平直阶跃光纤、几何光学；角度从轴线量起，忽略弯曲损耗与波动模态','']]
    if o.type=='conical':
        return [['轨道半径',f"{v['radius']:.4g}",'m'],['绳张力',f"{v['tension']:.4g}",'N'],['周期',f"{v['period']:.4g}",'s'],['模型','理想轻绳、稳定圆锥摆、点质量；不模拟启动和空气阻力','']]
    if o.type=='cyclotron':
        return [['回旋频率',f"{v['frequency']:.5g}",'Hz'],['最大出射速率',f"{v['speed']:.5g}" if v['valid'] else '超出非相对论适用范围','m/s'],['最大动能',f"{v['energy']:.5g}" if v['valid'] else '不提供','J'],['模型','理想匀强磁场、瞬时跨缝加速；画面按周期慢放，不代表实际时间；速率须低于0.1c','']]
    if o.type=='selector':
        return [['直行选定速率 E/B',f"{v['selected']:.5g}",'m/s'],['指定时刻侧移',f"{v['y']:.5g}" if v['valid'] else '超出适用范围','m'],['指定时刻水平位置',f"{v['x']:.5g}" if v['valid'] else '不提供','m'],['模型','无限均匀正交E/B场精确轨迹、初速度沿x；不模拟极板碰撞或出场后的运动','']]
    return [['速率',f"{v['speed']:.5g}",'m/s'],['电流',f"{v['current']:.5g}",'A'],['磁阻力',f"{v['brake']:.5g}",'N'],['焦耳热',f"{v['joule']:.5g}",'J'],['模型','理想无限长导轨、恒力、恒B、总电阻R；不计自感、摩擦与接触电阻；位置只作示意','']]


def draw(o):
    p=o.p
    x,y=o.x,o.y
    v=values(o.type,p,E.S.t)
    if o.type=='fiber':
        rect_w(x-2,y-.55,4,1.1,None,C.ink2,2)
        theta=math.radians(p.angle)
        points=[(x-2,y)]
        xx,yy=x-2,y
        dy=1
        if abs(math.tan(theta))<1e-8:
            points.append((x+2,y))
        else:
            for _ in range(12):
                target=y+.55*dy
                end=xx+abs(target-yy)/math.tan(theta)
                if end>x+2:
                    points.append((x+2,yy+dy*(x+2-xx)*math.tan(theta)))
                    break
                points.append((end,target))
                if not v['reflected']:
                    refracted=math.asin(min(1,p.core/p.clad*math.cos(theta)))
                    points.append((end+.8*math.sin(refracted),target+dy*.8*math.cos(refracted)))
                    break
                xx,yy=end,target
                dy=-dy
        line_w(points,C.accent if v['reflected'] else T.bad,2)
    elif o.type=='conical':
        angle=v['omega']*E.S.t
        bx=x+v['radius']*math.cos(angle)
        by=y-p.L*math.cos(math.radians(p.angle))
        line_w([(x,y),(bx,by)],C.ink2,2)
        circle_w(x,y,.06,C.ink)
        circle_w(bx,by,.14,C.accent)
        txt(x,y+.3,'稳定圆锥摆侧投影',align='center',size=12,color=C.ink2)
    elif o.type=='cyclotron':
        circle_w(x,y,1.3,None,C.ink2,2)
        line_w([(x,y-1.4),(x,y+1.4)],C.faint,1)
        if v['valid']:
            # Exact half-circles between ideal instantaneous accelerating gaps.
            qcharge=p.charge*1e-19
            mass=p.mass*1e-27
            maximum=min(60,max(1,math.ceil(v['energy']/(qcharge*p.voltage))))
            phase=E.S.t%maximum
            points=[]
            gap_y=0.
            for half in range(math.floor(phase)+1):
                radius=min(p.radius,math.sqrt(2*mass*(half+1)*qcharge*p.voltage)/(qcharge*p.B))
                fraction=min(1,max(0,phase-half))
                side=1 if half%2==0 else -1
                for i in range(31):
                    angle=math.pi*fraction*i/30
                    xx=side*radius*math.sin(angle)
                    yy=gap_y-side*radius*(1-math.cos(angle))
                    points.append((x+xx/p.radius,y+yy/p.radius))
                gap_y-=side*2*radius
            line_w(points,C.accent,2)
        txt(x,y-1.7,'按周期慢放的轨道示意',align='center',size=12,color=C.ink2)
    elif o.type=='selector':
        line_w([(x-2,y+.7),(x+2,y+.7)],C.ink2,2)
        line_w([(x-2,y-.7),(x+2,y-.7)],C.ink2,2)
        if v['valid']:
            phase=v['omega']*p.flight*1e-9
            if abs(phase)<=32*math.pi:
                count=min(1024,max(160,math.ceil(abs(phase)*20)))
                delta=p.speed*1e5-v['selected']
                world=[]
                for i in range(count+1):
                    t=p.flight*1e-9*i/count
                    world.append((v['selected']*t+delta*math.sin(v['omega']*t)/v['omega'],delta*(math.cos(v['omega']*t)-1)/v['omega']))
                xmin,xmax=min(v[0] for v in world),max(v[0] for v in world)
                ymin,ymax=min(v[1] for v in world),max(v[1] for v in world)
                span=max(xmax-xmin,ymax-ymin,.01)
                line_w([(x-1.5+3*(xx-xmin)/span,y+3*(yy-(ymin+ymax)/2)/span) for xx,yy in world],C.accent,2)
            else:
                txt(x,y,'周期过多，保留解析读数而不绘制欠采样轨迹',align='center',size=12,color=C.ink2)
        txt(x,y-1,'坐标按同一比例缩放，极板只示方向',align='center',size=12,color=C.ink2)
    else:
        rod=x-1.5+min(3,max(0,v['distance']))
        line_w([(x-1.5,y+.6),(x+1.7,y+.6)],C.ink2,2)
        line_w([(x-1.5,y-.6),(x+1.7,y-.6)],C.ink2,2)
        line_w([(x-1.5,y+.6),(x-1.5,y-.6)],C.ink2,2)
        line_w([(rod,y-.6),(rod,y+.6)],C.accent,5)
    rows=readings(o)
    txt(x,y+1.7,rows[0][0]+' '+rows[0][1]+' '+rows[0][2],align='center',size=12,color=C.ink2)


SPECS=[
    ('fiber','光纤全反射','optics',[('core','芯层折射率','',1.1,2,.01,1.5,2),('clad','包层折射率','',1,1.9,.01,1.45,2),('angle','光线与轴线夹角','°',0,60,1,10,0)]),
    ('conical','圆锥摆','kin',[('L','绳长','m',.2,3,.1,1,1),('m','质量','kg',.1,5,.1,1,1),('angle','绳与竖直夹角','°',5,75,1,30,0),('g','重力加速度','m/s²',1,20,.1,9.8,1)]),
    ('cyclotron','回旋加速器','mag',[('charge','正电荷量','×10⁻¹⁹ C',.1,10,.1,1.6,1),('mass','质量','×10⁻²⁷ kg',.1,100,.1,1.67,2),('B','磁感应强度','T',.1,2,.1,.5,1),('radius','最大轨道半径','m',.02,.5,.01,.1,2),('voltage','加速缝电压','V',100,10000,100,1000,0)]),
    ('selector','速度选择器','efield',[('charge','正电荷量','×10⁻¹⁹ C',.1,10,.1,1.6,1),('mass','质量','×10⁻²⁷ kg',.1,100,.1,1.67,2),('E','场强','V/m',100,100000,100,10000,0),('B','磁感应强度','T',.01,1,.01,.1,2),('speed','初速','×10⁵ m/s',.1,20,.1,1,1),('flight','观察时刻','ns',1,2000,1,500,0)]),
    ('induction_rail','导轨与导体棒','elec',[('B','磁感应强度','T',.1,2,.1,1,1),('length','棒长','m',.2,2,.1,1,1),('R','总电阻','Ω',.1,10,.1,1,1),('m','质量','kg',.1,5,.1,1,1),('force','恒定拉力','N',0,5,.1,0,1),('v0','初速','m/s',0,10,.1,3,1)]),
]
for kind,name,group,params in SPECS:
    define(kind,name,group,2,.7,'适用条件和读数见调整栏；均为明确的解析模型',params,None,None,draw,readings,lambda o:bounds(o.x-2.3,o.x+2.5,o.y-2,o.y+2.3))
