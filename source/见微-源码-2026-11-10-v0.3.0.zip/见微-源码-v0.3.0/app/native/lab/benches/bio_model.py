"""生物工作台的教学近似；模型假设与读数一起返回。"""
import itertools
import math

NAMES={"microscope":"显微镜","plant":"植物细胞","animal":"动物细胞","mitosis":"有丝分裂","meiosis":"减数分裂","cross":"单基因杂交","enzyme":"酶活性","photosynthesis":"光合与呼吸","population":"种群增长","foodweb":"能量流动"}
DEFAULT=dict(temperature=25,pH=7,light=500,co2=.04,time=5,rate=.3,initial=20,capacity=200,magnification=100,efficiency=.15,energy=1000,stage=0,father="Aa",mother="Aa")
NAMES['energy_network']='食物网能量分配'
DEFAULT.update(split=.5,eat_rabbit=.5,eat_mouse=.5)


def calculate(kind,p):
    p={**DEFAULT,**p}
    if kind=='energy_network':
        if not all(0<=p[k]<=1 for k in ('split','eat_rabbit','eat_mouse','efficiency')) or p['energy']<0:
            raise ValueError('能量和分配比例超出模型范围')
        rabbit=p['energy']*p['split']*p['efficiency']
        mouse=p['energy']*(1-p['split'])*p['efficiency']
        hawk=(rabbit*p['eat_rabbit']+mouse*p['eat_mouse'])*p['efficiency']
        remaining_rabbit=rabbit*(1-p['eat_rabbit'])
        remaining_mouse=mouse*(1-p['eat_mouse'])
        lost=max(0.,p['energy']-remaining_rabbit-remaining_mouse-hawk)
        return dict(rows=[['草的输入能量',f"{p['energy']:.5g} kJ"],['鹰获得的能量',f'{hawk:.5g} kJ'],['兔环节净转移能量',f'{rabbit:.5g} kJ'],['鼠环节净转移能量',f'{mouse:.5g} kJ'],['兔剩余',f'{remaining_rabbit:.5g} kJ'],['鼠剩余',f'{remaining_mouse:.5g} kJ'],['未保留在三类消费者的能量',f'{lost:.5g} kJ']],
                    network=[p['energy'],rabbit,mouse,hawk],stocks=[remaining_rabbit,remaining_mouse,hawk],lost=lost,
                    note='草→兔/鼠→鹰的分支食物网，箭头表示能量流向。单次封闭分配：草输入全部按比例分给兔/鼠，每级净转移效率恒定，再按摄取比例分给鹰；剩余计入相应环节存量，其余作为损耗。不含种群动态、分解者或能量再循环，不能反推真实生态系统。')
    if kind=="microscope":
        return dict(rows=[["总放大倍数",f"{p['magnification']:g} ×"],["视野直径",f"{1.8*100/p['magnification']:.3g} mm"]],note="假定100倍时校准视野直径1.8 mm；放大倍数不等于分辨率。")
    if kind in ("plant","animal"):
        names=["细胞膜","细胞质","细胞核","线粒体"]+(["细胞壁","叶绿体","液泡"] if kind=="plant" else ["中心体"])
        return dict(rows=[["结构",name] for name in names],note="结构示意，不按真实大小绘制；植物细胞示意选用叶肉细胞。")
    if kind in ("mitosis","meiosis"):
        stage=int(p["stage"])
        if kind=="mitosis":
            phase=["前期","中期","后期","末期（每个子细胞）"][stage]
            chromosomes=[4,4,8,4][stage]
            dna=[8,8,8,4][stage]
        else:
            phase=["减Ⅰ前期","减Ⅰ后期（分裂前整细胞）","减Ⅱ中期（每个细胞）","减Ⅱ完成（每个细胞）"][stage]
            chromosomes=[4,4,2,2][stage]
            dna=[8,8,4,2][stage]
        return dict(rows=[["时期",phase],["染色体数",str(chromosomes)],["核DNA分子数",str(dna)]],note="假设2n=4，复制完成后进入分裂；按着丝粒计数。阶段图是计数模型，不模拟全部纺锤体过程。")
    if kind=="cross":
        counts={"AA":0,"Aa":0,"aa":0}
        for a,b in itertools.product(p["father"],p["mother"]):
            key="".join(sorted((a,b)))
            counts[key]+=1
        return dict(rows=[[key,f"{value}/4"] for key,value in counts.items()],values=[counts[k]/4 for k in ("AA","Aa","aa")],note="单基因、常染色体、完全显性；配子等概率，无致死或选择。")
    if kind=="enzyme":
        relative=math.exp(-((p["temperature"]-37)/20)**2-((p["pH"]-7)/2)**2)
        curve=[math.exp(-((t-37)/20)**2-((p["pH"]-7)/2)**2) for t in range(0,81)]
        return dict(rows=[["相对活性",f"{relative:.4f}"]],values=curve,note="经验钟形曲线，假定最适37°C和pH7；不代表所有酶，不模拟不可逆变性。")
    if kind=="photosynthesis":
        gross=20*p["light"]/(p["light"]+200)*p["co2"]/(p["co2"]+.02)
        return dict(rows=[["相对总光合",f"{gross:.3f}"],["相对呼吸", "2.000"],["相对净光合",f"{gross-2:.3f}"]],values=[20*i/(i+200)*p["co2"]/(p["co2"]+.02)-2 for i in range(0,2001,25)],note="光和CO₂双饱和经验模型，相对速率；假定呼吸恒定，不由曲线反推真实生理参数。")
    if kind=="population":
        def number(t):
            return p["capacity"]/(1+(p["capacity"]-p["initial"])/p["initial"]*math.exp(-p["rate"]*t))
        return dict(rows=[["种群数量",f"{number(p['time']):.2f}"],["环境容纳量",f"{p['capacity']:g}"]],values=[number(i*.25) for i in range(81)],note="连续Logistic模型；封闭种群、环境容纳量和内禀增长率恒定。")
    if kind=="foodweb":
        energies=[p["energy"]*p["efficiency"]**i for i in range(3)]
        return dict(rows=[[f"第{i+1}营养级",f"{value:.3g}"] for i,value in enumerate(energies)],values=energies,note="简化为单条三营养级链，每级同一效率；非完整食物网，不计杂食和分解者通路。")
    raise ValueError("未知生物模型")
