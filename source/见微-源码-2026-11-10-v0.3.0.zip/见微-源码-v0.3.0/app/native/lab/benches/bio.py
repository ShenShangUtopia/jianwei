"""生物自由工作台：可并置、移动、调参、对比与保存的教学模型。"""
import copy
from PySide6.QtCore import QPointF,QRectF,Qt
from PySide6.QtGui import QPainterPath,QPen
from ...design.tokens import T,font,qc
from ...design.icons import bench_object_svg
from ...kit.bench import bench
from .bio_model import DEFAULT,NAMES,calculate

ART='<svg viewBox="0 0 160 110"><ellipse cx="80" cy="55" rx="65" ry="40" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="80" cy="55" r="15" fill="none" stroke="currentColor" stroke-width="2"/></svg>'


@bench.reg(id="bio",subj="bio",short="生物",title="生物工作台",sub="细胞 · 分裂 · 遗传 · 生理与生态模型",desc="并置多个生物教学模型，调参对比、观察读数；每个模型明确显示假设与近似。",art=ART)
def bio(B):
    L=B.L
    c=L.canvas()
    state=dict(v=1,objects=[],selected=None,seq=0)
    undo=[]
    dragging=[None]
    def snapshot():
        return copy.deepcopy(state)
    def remember():
        undo.append(snapshot())
        del undo[:-30]
    def chosen():
        return next((o for o in state["objects"] if o["id"]==state["selected"]),None)
    def panel():
        B.clear_panel()
        o=chosen()
        if not o:
            L.group("生物模型")
            L.note("从左侧放入模型；拖动模型卡片可并置比较。右键素材可收藏。")
            B.show_panel()
            return
        L.group(NAMES[o["kind"]])
        readout=[None]
        def setvalue(key,value):
            remember()
            o["p"][key]=value
            if key=='stage' and o['p'].get('chromosomes',{}).get('v')==1:
                o['p'].pop('chromosomes',None)
            if readout[0] is not None:
                readout[0].set(calculate(o["kind"],o["p"])["rows"])
            L.draw()
        params={"microscope":[("magnification","总放大倍数",40,1000,10)],"enzyme":[("temperature","温度 / °C",0,80,1),("pH","pH",0,14,.1)],"photosynthesis":[("light","相对光强",0,2000,10),("co2","CO₂ / %",.01,.1,.001)],"population":[("time","时间",0,20,.1),("rate","内禀增长率",.01,1,.01),("initial","初始数量",1,100,1),("capacity","环境容纳量",100,1000,10)],"foodweb":[("energy","生产者能量",10,10000,10),("efficiency","传递效率",.1,.2,.01)]}
        for key,label,lo,hi,step in params.get(o["kind"],[]):
            L.slider(label,lo,hi,step,o["p"][key],lambda value,k=key:setvalue(k,value))
        if o['kind']=='energy_network':
            for key,label,lo,hi,step in [('energy','草输入能量 / kJ',10,10000,10),('efficiency','每级净转移效率',.1,.2,.01),('split','草分给兔的比例',0,1,.05),('eat_rabbit','鹰摄取兔环节的比例',0,1,.05),('eat_mouse','鹰摄取鼠环节的比例',0,1,.05)]:
                L.slider(label,lo,hi,step,o['p'][key],lambda value,k=key:setvalue(k,value))
        if o["kind"] in ("mitosis","meiosis"):
            L.select("分裂阶段",[(str(i),str(i+1)) for i in range(4)],str(o["p"]["stage"]),lambda value:setvalue("stage",int(value)))
        if o["kind"]=="cross":
            for key,label in (("father","父本"),("mother","母本")):
                L.select(label,["AA","Aa","aa"],o["p"][key],lambda value,k=key:setvalue(k,value))
        result=calculate(o["kind"],o["p"])
        readout[0]=L.out()
        readout[0].set(result["rows"])
        L.note(result["note"])
        if o['kind'] in ('plant','animal','mitosis','meiosis'):
            def detail(_):
                from .cell_detail import Chromosomes,Organelles
                try:
                    dialog=Chromosomes(o['kind'],o['p'],remember,L.stage.window()) if o['kind'] in ('mitosis','meiosis') else Organelles(o['kind'],o['p'],remember,L.stage.window())
                except ValueError as exc:
                    B.toast(str(exc))
                    return
                dialog.exec()
                panel()
                L.draw()
            L.button('逐条拖动并核对染色体' if o['kind'] in ('mitosis','meiosis') else '点选细胞结构',detail)
        def remove(_):
            remember()
            state["objects"].remove(o)
            state["selected"]=None
            panel()
            L.draw()
        L.button("删除模型",remove)
        B.show_panel()
    def add(kind,x=None,y=None):
        if len(state["objects"])>=12:
            B.toast("最多并置12个模型")
            return
        remember()
        left,top,right,bottom=B.safe()
        state["seq"]+=1
        index=len(state["objects"])
        o=dict(id=state["seq"],kind=kind,p=dict(DEFAULT),x=x if x is not None else left+20+(index%2)*300,y=y if y is not None else top+25+(index//2)*205)
        o["x"]=min(max(left+10,o["x"]),max(left+10,c.w-right-280))
        o["y"]=min(max(top+10,o["y"]),max(top+10,c.h-bottom-190))
        state["objects"].append(o)
        state["selected"]=o["id"]
        panel()
        L.draw()
    def draw():
        c.clear()
        p=c.g.p
        for o in state["objects"]:
            r=QRectF(o["x"],o["y"],280,185)
            p.save()
            p.setPen(QPen(qc(T.accent if o["id"]==state["selected"] else T.line),2))
            p.setBrush(qc(T.raised))
            p.drawRoundedRect(r,10,10)
            p.setFont(font(14,600))
            p.setPen(qc(T.fg))
            p.drawText(r.adjusted(10,4,-10,-150),int(Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter),NAMES[o["kind"]])
            result=calculate(o["kind"],o["p"])
            if result.get('network'):
                nodes=[(140,48),(60,88),(220,88),(140,125)]
                for a,b in ((0,1),(0,2),(1,3),(2,3)):
                    ax,ay=nodes[a];bx,by=nodes[b]
                    path=QPainterPath(QPointF(r.x()+ax,r.y()+ay))
                    path.lineTo(r.x()+bx,r.y()+by)
                    p.setPen(QPen(qc(T.c1),2))
                    p.drawPath(path)
                    dx,dy=bx-ax,by-ay
                    length=(dx*dx+dy*dy)**.5
                    ux,uy=dx/length,dy/length
                    tip=QPointF(r.x()+bx-ux*13,r.y()+by-uy*13)
                    p.drawLine(tip,QPointF(tip.x()-ux*6+uy*4,tip.y()-uy*6-ux*4))
                    p.drawLine(tip,QPointF(tip.x()-ux*6-uy*4,tip.y()-uy*6+ux*4))
                p.setFont(font(12))
                for (x,y),name,value in zip(nodes,['草','兔','鼠','鹰'],result['network']):
                    p.setBrush(qc(T.surface))
                    p.setPen(QPen(qc(T.c1),1.5))
                    p.drawEllipse(QPointF(r.x()+x,r.y()+y),14,12)
                    p.setPen(qc(T.fg))
                    p.drawText(QRectF(r.x()+x-15,r.y()+y-10,30,20),int(Qt.AlignmentFlag.AlignCenter),name)
                    p.drawText(QRectF(r.x()+x-42,r.y()+y-30,84,18),int(Qt.AlignmentFlag.AlignCenter),f'{value:.3g}')
            elif result.get("values"):
                values=result["values"]
                mi=min([0]+values)
                mx=max([1]+values)
                path=QPainterPath()
                for i,value in enumerate(values):
                    x=r.x()+15+i/max(1,len(values)-1)*250
                    y=r.y()+125-(value-mi)/max(1e-9,mx-mi)*75
                    path.moveTo(x,y) if not i else path.lineTo(x,y)
                p.setPen(QPen(qc(T.c1),2))
                p.drawPath(path)
            else:
                p.setBrush(Qt.BrushStyle.NoBrush)
                cell=QRectF(r.x()+80,r.y()+45,120,75)
                if o["kind"]=="plant":
                    p.drawRoundedRect(cell,8,8)
                    p.drawRoundedRect(cell.adjusted(4,4,-4,-4),6,6)
                    p.drawEllipse(QRectF(r.x()+120,r.y()+58,55,50))
                    p.setPen(QPen(qc(T.bio),2))
                    for yy in (58,103):
                        for xx in (100,180):
                            p.drawEllipse(QPointF(r.x()+xx,r.y()+yy),8,4)
                    p.setPen(QPen(qc(T.fg),2))
                elif o["kind"]=="microscope":
                    p.save()
                    cell=QRectF(r.x()+95,r.y()+38,95,95)
                    p.drawEllipse(cell)
                    clip=QPainterPath()
                    clip.addEllipse(cell)
                    p.setClipPath(clip)
                    radius=18*o["p"]["magnification"]/100
                    p.drawEllipse(cell.center(),radius,radius*.7)
                    p.restore()
                else:
                    p.drawEllipse(cell)
                if o["kind"] in ("mitosis","meiosis"):
                    n=int(result["rows"][1][1])
                    replicated=int(result["rows"][2][1])==2*n
                    for i in range(n):
                        x=r.x()+100+i%4*22
                        y=r.y()+65+i//4*25
                        if replicated:
                            p.drawLine(QPointF(x-4,y-7),QPointF(x+4,y+7))
                            p.drawLine(QPointF(x-4,y+7),QPointF(x+4,y-7))
                        else:
                            p.drawLine(QPointF(x,y-7),QPointF(x,y+7))
                elif o["kind"]!="microscope":
                    p.drawEllipse(QPointF(r.x()+105 if o["kind"]=="plant" else r.center().x(),r.y()+82),12 if o["kind"]=="plant" else 17,17)
            p.setPen(qc(T.muted))
            p.setFont(font(11))
            label="　".join(str(a)+"："+str(b) for a,b in result["rows"][:2])
            p.drawText(r.adjusted(10,135,-10,-8),int(Qt.TextFlag.TextWordWrap),label)
            p.restore()
    def mouse(kind,event):
        if not hasattr(event,'position'):
            return
        point=event.position()
        x,y=point.x(),point.y()
        if kind=="down":
            o=next((o for o in reversed(state["objects"]) if QRectF(o["x"],o["y"],280,185).contains(point)),None)
            if o:
                remember()
                state["selected"]=o["id"]
                dragging[:]=[(o,x-o["x"],y-o["y"])]
                panel()
        elif kind=="move" and dragging[0]:
            o,dx,dy=dragging[0]
            left,top,right,bottom=B.safe()
            o["x"]=min(max(left+4,x-dx),max(left+4,c.w-right-284))
            o["y"]=min(max(top+4,y-dy),max(top+4,c.h-bottom-189))
        elif kind=="up":
            dragging[0]=None
        L.draw()
    def restore(value):
        if value.get("v")!=1 or not isinstance(value.get("objects"),list) or len(value["objects"])>12:
            raise ValueError("生物工作台存档版本或格式无效")
        for o in value["objects"]:
            if o.get("kind") not in NAMES:
                raise ValueError("生物模型类型无效")
        state.clear()
        state.update(copy.deepcopy(value))
        for o in state["objects"]:
            o["p"]={**DEFAULT,**o.get("p",{})}
        panel()
        L.draw()
    def undo_once():
        if undo:
            restore(undo.pop())
    B.palette([dict(title="细胞与显微观察",tab="item",items=[dict(id="bio-"+k,icon=bench_object_svg(k,NAMES[k],ART),label=NAMES[k],sub="可放置、调参和比较",click=lambda k=k:add(k),drop=lambda x,y,k=k:add(k,x,y)) for k in ("microscope","plant","animal","mitosis","meiosis")]),dict(title="遗传、生理与生态",tab="item",items=[dict(id="bio-"+k,icon=bench_object_svg(k,NAMES[k],ART),label=NAMES[k],sub="程序计算与假设说明",click=lambda k=k:add(k),drop=lambda x,y,k=k:add(k,x,y)) for k in ("cross","enzyme","photosynthesis","population","foodweb","energy_network")]),dict(title="操作",tab="item",items=[dict(label="撤销",icon=ART,click=undo_once)])],labels={"item":"模型"})
    L.on_draw(draw)
    L.stage.mouse=mouse
    B.transfer(snapshot,restore,state)
    B.tips([("模型边界",["所有读数来自本地模型。显微镜只演示视野关系，细胞与分裂使用计数示意；未模拟完整三维细胞。","酶和光合曲线是明确参数的教学近似，不代表具体物种。"] )])
    panel()
