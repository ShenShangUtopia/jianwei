"""扩展器材的可测试数据模型；mmol、mL、°C，气体按1 atm理想气体。"""
import math

GAS_MASS={"H2":2.016,"O2":31.998,"CO2":44.01,"NH3":17.031,"NO":30.006}


def gas_volume(mmol,temperature=25):
    return max(0,float(mmol))*0.082057*(temperature+273.15)


def route_gas(source,nodes,kind,amount):
    """单路串联导管；不产生气体，只转移原反应实际产生的量。"""
    by_id={node["id"]:node for node in nodes}
    current=source
    left=max(0,float(amount))
    visited={source["id"]}
    while left>1e-12:
        dest=by_id.get(current.get("gas_to"))
        if dest is None or dest["id"] in visited:
            break
        visited.add(dest["id"])
        mode=dest.get("collection","up")
        valid=(mode=="water" and kind in ("H2","O2")) or (mode=="up" and GAS_MASS.get(kind,29)>29) or (mode=="down" and GAS_MASS.get(kind,29)<29) or mode=="wash"
        if not valid:
            dest["gas_note"]="收集方法与气体性质不匹配，未计入收集量"
            break
        dest.pop("gas_note",None)
        if mode=="wash":
            # Limewater absorbs CO2, including excess CO2 -> bicarbonate.
            tot=dest.setdefault("tot",{})
            capacity=max(0,2*tot.get("Ca",0)-tot.get("C",0)) if dest.get("V",0)>0 else 0
            caught=min(left,capacity) if kind=="CO2" else 0
            tot["C"]=tot.get("C",0)+caught
        else:
            collected=dest.setdefault("collected",{})
            used=sum(gas_volume(n,dest.get("T",25)) for n in collected.values())
            cap=dest.get("gas_capacity",250)
            caught=min(left,max(0,cap-used)/gas_volume(1,dest.get("T",25)))
            collected[kind]=collected.get(kind,0)+caught
        left-=caught
        current=dest
    return max(0,amount-left),left


def titration(acid_ml=25,acid_molar=.1,base_molar=.1,added_ml=0):
    """强酸 HCl–强碱 NaOH，pH由现有电荷/平衡模型计算。"""
    from .chem_model import eqm
    total=max(1e-6,acid_ml+added_ml)
    result=eqm({"Cl":acid_ml*acid_molar,"Na":added_ml*base_molar},total)
    return dict(pH=result["pH"],equivalence_ml=acid_ml*acid_molar/max(1e-9,base_molar))


def resistance(q):
    kind=q.get("instrument")
    if kind=="ntc":
        return q.get("R0",1000)*math.exp(3500*(1/(q.get("temperature",25)+273.15)-1/298.15))
    if kind=="ldr":
        return max(1,min(1e7,q.get("R0",1000)*(100/max(1,q.get("lux",100)))**.7))
    if kind=="fuse" and q.get("tripped"):
        return 1e10
    if kind=="fuse":
        return .05
    return max(.01,q.get("R",10))
