"""Conservative separation stations with declared samples, ports and assumptions."""
import math

NAMES={'filter':'过滤装置','distill':'蒸馏装置','extract':'萃取分液装置'}


def create(kind):
    base=dict(v=1,kind=kind,note='尚未操作',outlet='receiver')
    if kind=='filter':
        base.update(feed_ml=100.,feed_solute=10.,feed_solid=2.,filtrate_ml=0.,filtrate_solute=0.,filtrate_solid=0.,retained=0.,paper=True,dose=20.)
    elif kind=='distill':
        base.update(n=[.5,.5],collected=[0.,0.],lost=[0.,0.],boiling=[70.,110.],latent=30000.,T=20.,power=100.,vapor_to='condenser',water='bottom_up',bulb='sidearm',clock=0.,vapor=False)
    elif kind=='extract':
        base.update(water_ml=100.,organic_ml=50.,water_n=10.,organic_n=0.,K=4.,density=.8,drained_ml=0.,drained_n=0.,equilibrated=False,dose=20.)
    else:
        raise ValueError('未知分离装置')
    return base


def bubble(q):
    total=sum(q['n'])
    if total<=1e-12:
        return q['T'],[0.,0.]
    xs=[n/total for n in q['n']]
    def pressure(T,i):
        return math.exp(q['latent']/8.314462618*(1/(q['boiling'][i]+273.15)-1/(T+273.15)))
    lo,hi=min(q['boiling']),max(q['boiling'])
    for _ in range(60):
        mid=(lo+hi)/2
        if sum(xs[i]*pressure(mid,i) for i in range(2))>1:
            hi=mid
        else:
            lo=mid
    T=(lo+hi)/2
    ys=[xs[i]*pressure(T,i) for i in range(2)]
    total_y=sum(ys)
    return T,[y/total_y for y in ys]


def operate(q,action):
    if q['outlet']!='receiver':
        q['note']='出口尚未连接接收容器，未转移样品。'
        return
    kind=q['kind']
    if kind=='filter':
        if q['feed_ml']<=1e-12:
            q['note']='样品已过滤完。'
            return
        dose=min(q['dose'],q['feed_ml'])
        part=dose/q['feed_ml']
        dissolved=q['feed_solute']*part
        solid=q['feed_solid']*part
        q['feed_ml']-=dose
        q['feed_solute']-=dissolved
        q['feed_solid']-=solid
        q['filtrate_ml']+=dose
        q['filtrate_solute']+=dissolved
        if q['paper']:
            q['retained']+=solid
        else:
            q['filtrate_solid']+=solid
        q['note']='滤液中的溶质随液体通过；粗颗粒留在滤纸。' if q['paper'] else '未装滤纸：不溶固体也进入接收容器，未完成过滤。'
    elif kind=='distill':
        if q['vapor_to']!='condenser' or q['water']!='bottom_up':
            q['note']='请将蒸气出口接冷凝管，冷却水下进上出；当前接法不在可运行模型内。'
            return
        if sum(q['n'])<=1e-10:
            q['note']='已无液体，停止加热。'
            return
        q['clock']+=10.
        target,ys=bubble(q)
        energy=q['power']*10
        capacity=sum(q['n'])*200. # declared constant molar heat capacity, J/(mol K)
        warming=max(0.,target-q['T'])*capacity
        if energy<warming:
            q['T']+=energy/capacity
            q['vapor']=False
        else:
            q['T']=target
            available=energy-warming
            q['vapor']=False
            for _ in range(256):
                if available<=1e-12 or sum(q['n'])<=1e-10:
                    break
                target,ys=bubble(q)
                capacity=sum(q['n'])*200.
                warming=max(0.,target-q['T'])*capacity
                if available<warming:
                    q['T']+=available/capacity
                    break
                available-=warming
                q['T']=target
                amount=min(available/q['latent'],.002,sum(q['n']))
                # Stop before any component can become negative.
                amount=min([amount]+[q['n'][i]/ys[i] for i in range(2) if ys[i]>1e-15])
                if amount<=1e-15:
                    break
                for i in range(2):
                    moved=amount*ys[i]
                    q['n'][i]=max(0,q['n'][i]-moved)
                    q['collected'][i]+=moved
                available-=amount*q['latent']
                q['vapor']=True
        q['note']='冷凝液相对富集低沸点组分；剩余液逐渐富集高沸点组分。' if q['vapor'] else '正在升温，尚无冷凝液。'
        if q['bulb']!='sidearm':
            q['note']+=' 温度计球部应在蒸馏支管口，当前读数是液体温度。'
    else:
        if action=='shake':
            total=q['water_n']+q['organic_n']
            denominator=q['water_ml']+q['K']*q['organic_ml']
            q['organic_n']=total*q['K']*q['organic_ml']/denominator if denominator else 0.
            q['water_n']=total-q['organic_n']
            q['equilibrated']=True
            q['note']='振荡后按分配系数达到平衡；已静置分层。'
        else:
            phase='organic' if q['density']>1 else 'water'
            # If the lower phase has emptied, the remaining upper phase is next.
            if q[phase+'_ml']<=1e-12:
                phase='water' if phase=='organic' else 'organic'
            volume=q[phase+'_ml']
            if volume<=1e-12:
                q['note']='已放空。'
                return
            amount=min(volume,q['dose'])
            solute=q[phase+'_n']*amount/volume
            q[phase+'_ml']-=amount
            q[phase+'_n']-=solute
            q['drained_ml']+=amount
            q['drained_n']+=solute
            q['note']=('有机层' if phase=='organic' else '水层')+'从下口放出；请及时更换接收容器，防止两层混收。'


def readings(q):
    if q['kind']=='filter':
        return [['滤液',f"{q['filtrate_ml']:.4g} mL"],['滤液溶质',f"{q['filtrate_solute']:.4g} mmol"],['滤纸截留固体',f"{q['retained']:.4g} g"],['进入滤液的固体',f"{q['filtrate_solid']:.4g} g"]]
    if q['kind']=='distill':
        read=q['T'] if q['bulb']=='liquid' or q['vapor'] else 20.
        total=sum(q['collected'])
        return [['温度计',f'{read:.4g} °C'],['残液',f"甲 {q['n'][0]:.4g}、乙 {q['n'][1]:.4g} mol"],['冷凝收集',f'{total:.4g} mol'],['馏出液甲摩尔分数',f"{q['collected'][0]/total:.4g}" if total else '尚无馏出液']]
    return [['下层','有机层' if q['density']>1 else '水层'],['水层',f"{q['water_ml']:.4g} mL；溶质 {q['water_n']:.4g} mmol"],['有机层',f"{q['organic_ml']:.4g} mL；溶质 {q['organic_n']:.4g} mmol"],['接收液',f"{q['drained_ml']:.4g} mL；溶质 {q['drained_n']:.4g} mmol"]]


def inspector(q,L,redraw):
    L.group(NAMES[q['kind']])
    L.note('本装置使用独立的理想过程样品；不与酸碱台面的任意试剂混算。端口接法与参数实际影响转移和读数。')
    L.select('液体出口',[('receiver','接收容器'),('closed','关闭 / 未连接')],q['outlet'],lambda v:q.__setitem__('outlet',v))
    if q['kind']=='filter':
        L.check('安装滤纸',q['paper'],lambda v:q.__setitem__('paper',v))
        L.slider('每次倾入',1,100,1,q['dose'],lambda v:q.__setitem__('dose',v),'mL')
        L.note('初始100mL水溶液含10mmol可溶物与2g粗粒不溶固体。理想滤纸完全截留粗颗粒，不截留溶解物；忽略吸附和滤纸持液，不用于胶体/微粒过滤。')
    elif q['kind']=='distill':
        L.select('蒸气出口',[('condenser','冷凝管'),('open','未连接')],q['vapor_to'],lambda v:q.__setitem__('vapor_to',v))
        L.select('冷却水',[('bottom_up','下进上出'),('top_down','上进下出'),('off','未接水')],q['water'],lambda v:q.__setitem__('water',v))
        L.select('温度计球部',[('sidearm','支管口'),('liquid','浸在液体中')],q['bulb'],lambda v:q.__setitem__('bulb',v))
        L.slider('加热功率',10,200,10,q['power'],lambda v:q.__setitem__('power',v),'W')
        L.note('虚拟理想二元液体，甲/乙纯物质沸点70/110°C，均为0.5mol；恒定汽化焓30kJ/mol、摩尔热容200J/(mol·K)。1atm、Raoult定律与Clausius–Clapeyron蒸气压，忽略热损耗、混合热、共沸和分馏；不能直接套用乙醇—水等真实混合物。')
    else:
        L.slider('分配系数 K',.1,10,.1,q['K'],lambda v:q.__setitem__('K',v))
        def density(v):
            q['density']=float(v)
            redraw()
        L.select('有机溶剂密度',[('.8','0.8（水层在下）'),('1.6','1.6（有机层在下）')],str(q['density']),density)
        L.slider('每次放液',1,100,1,q['dose'],lambda v:q.__setitem__('dose',v),'mL')
        L.note('两溶剂完全不互溶、体积可加，稀溶质分配系数恒定；初始水层100mL含10mmol溶质，有机相50mL。忽略乳化、化学反应和互溶损失；密度等于水的情况不开放。')
    out=L.out()
    status=L.out()
    def update():
        out.set(readings(q))
        status.set(q['note'])
        redraw()
    def action(kind):
        operate(q,kind)
        update()
    if q['kind']=='extract':
        L.button('振荡后静置分层',lambda _b:action('shake'))
        L.button('开启下口放液',lambda _b:action('drain'))
    else:
        L.button('加热10秒' if q['kind']=='distill' else '倾入并过滤一次',lambda _b:action('run'))
    update()


def draw(q,c,B):
    from ...kit.draw import D
    from ...design.tokens import T
    g=c.g
    left,top,right,_=B.safe()
    w=min(480,max(160,c.w-left-right-30))
    x,y=left+15,top+18
    D.rect(g,x,y,w,215,T.raised,T.line,1)
    D.text(g,NAMES[q['kind']],x+12,y+22,T.fg,size=13,bold=True)
    middle=x+w*.5
    if q['kind']=='filter':
        D.line(g,middle-50,y+60,middle,y+120,T.fg,2)
        D.line(g,middle+50,y+60,middle,y+120,T.fg,2)
        D.line(g,middle,y+120,middle,y+145,T.fg,2)
        if q['paper']:
            D.line(g,middle-35,y+65,middle,y+105,T.c1,3)
            D.line(g,middle+35,y+65,middle,y+105,T.c1,3)
        for px in (-16,0,16):
            D.circle(g,middle+px,y+80,3,T.c2)
        D.rect(g,middle-35,y+150,70,38,T.stage,T.fg,2)
        fill=min(32,q['filtrate_ml']/100*32)
        if fill:
            D.rect(g,middle-32,y+185-fill,64,fill,T.c1)
        if q['filtrate_solid']:
            D.circle(g,middle,y+182,3,T.c2)
    elif q['kind']=='distill':
        D.circle(g,x+65,y+137,30,T.stage,T.fg,2)
        D.line(g,x+57,y+108,x+57,y+55,T.fg,2)
        D.line(g,x+73,y+108,x+73,y+55,T.fg,2)
        D.line(g,x+73,y+73,x+w-60,y+132,T.c1 if q['vapor_to']=='condenser' else T.bad,3)
        D.line(g,x+130,y+77,x+w-80,y+112,T.fg,2)
        D.line(g,x+125,y+100,x+w-85,y+134,T.fg,2)
        D.arrow(g,x+w-125,y+132,x+150,y+104,T.c3,2,7)
        D.rect(g,x+w-75,y+143,55,40,T.stage,T.fg,2)
        fill=min(35,sum(q['collected'])*35)
        if fill:
            D.rect(g,x+w-72,y+180-fill,49,fill,T.c1)
        ty=y+80 if q['bulb']=='sidearm' else y+142
        D.line(g,x+65,y+42,x+65,ty,T.c2,2)
        D.circle(g,x+65,ty,4,T.c2)
    else:
        D.line(g,middle-45,y+60,middle-30,y+130,T.fg,2)
        D.line(g,middle+45,y+60,middle+30,y+130,T.fg,2)
        D.line(g,middle-30,y+130,middle,y+165,T.fg,2)
        D.line(g,middle+30,y+130,middle,y+165,T.fg,2)
        lower='organic' if q['density']>1 else 'water'
        upper='water' if lower=='organic' else 'organic'
        hl=q[lower+'_ml']/150*40
        hu=q[upper+'_ml']/150*40
        if hl:
            D.rect(g,middle-26,y+128-hl,52,hl,T.c1 if lower=='water' else T.c3)
        if hu:
            D.rect(g,middle-26,y+128-hl-hu,52,hu,T.c1 if upper=='water' else T.c3)
        D.line(g,middle,y+165,middle,y+188,T.fg,2)
        D.line(g,middle-12,y+175,middle+12,y+175,T.fg,3)
        D.text(g,'下层：'+('有机层' if q['density']>1 else '水层'),x+12,y+202,T.muted,size=12)
