"""Two-terminal teaching devices: Norton stamps and explicit stored state."""
import math

DEVICES={
    'motor':('电动机',dict(R=2.,motor_k=.1,J=.02,drag=.02,load=0.,omega=0.)),
    'inductor':('自感线圈',dict(R=2.,L=1.,bleed=1000.,coil_i=0.)),
    'galvanometer':('灵敏电流计',dict(R=1000.,range=.001)),
    'multimeter':('多用电表',dict(R=1e7,mode='voltage',range=20.)),
    'scope':('示波器',dict(R=1e7,trace=[],clock=0.)),
}


def stamp(q,dt):
    kind=q.get('instrument')
    if kind=='motor':
        return 1/q['R'],-q['motor_k']*q['omega']/q['R']
    if kind=='inductor':
        g=1/(q['R']+q['L']/dt)
        return g+1/q['bleed'],q['L']/dt*g*q['coil_i']
    if kind=='multimeter':
        if q['mode']=='current':
            return 1/.05,0.
        # Resistance mode is an internal 1.5V source + 1kΩ, not a magic reading.
        if q['mode']=='resistance' and not q.get('powered'):
            return .001,-.0015
        return 1e-7,0.
    return 1/q['R'],0.


def powered(q,comps):
    seen={tuple(q['a']),tuple(q['b'])}
    others=[c for c in comps if c is not q and not (c['t']=='sw' and not c['on'])]
    for _ in range(len(others)+1):
        before=len(seen)
        for c in others:
            if tuple(c['a']) in seen or tuple(c['b']) in seen:
                seen.update((tuple(c['a']),tuple(c['b'])))
        if len(seen)==before:
            break
    return any((c['t']=='bat' and abs(c.get('E',0))>1e-9 or c['t']=='cap' and abs(c.get('v',0))>1e-6 or c.get('instrument')=='motor' and abs(c.get('omega',0))>1e-6) and (tuple(c['a']) in seen or tuple(c['b']) in seen) for c in others)


def advance(q,u,i,dt):
    kind=q['instrument']
    if kind=='motor':
        q['back_emf']=q['motor_k']*q['omega']
        # Viscous bearing friction; constant load opposes nonnegative rotation.
        drive=q['motor_k']*i
        old=q['omega']
        torque=drive-q['load']*(1 if old>0 else -1 if old<0 else 1 if drive>=0 else -1)
        new=(old+dt*torque/q['J'])/(1+dt*q['drag']/q['J'])
        q['omega']=0. if (old==0 or old*new<0) and abs(drive)<=q['load'] else new
        q['mechanical_power']=q['back_emf']*i
    elif kind=='inductor':
        old=q['coil_i']
        q['coil_i']=(u+q['L']/dt*old)/(q['R']+q['L']/dt)
        q['magnetic_energy']=q['L']*q['coil_i']**2/2
        q['coil_voltage']=u-q['R']*q['coil_i']
    elif kind=='scope':
        q['clock']+=dt
        q['trace'].append([q['clock'],u])
        q['trace']=q['trace'][-400:]
    elif kind=='multimeter':
        q['warning']=''
        if q['mode']=='resistance':
            if q.get('powered'):
                q['reading']=None
                q['warning']='电阻档不能测带电网络，已禁用内部电池与电阻读数。'
            elif abs(i)<1e-12:
                q['reading']=None
                q['warning']='开路或超出测量范围'
            else:
                q['reading']=max(0.,u/(-i))
                if q['reading']>q['range']:
                    q['reading']=None
                    q['warning']='电阻超过当前量程，请换档。'
        else:
            q['reading']=u if q['mode']=='voltage' else i
            if abs(q['reading'])>q['range']:
                q['warning']='超量程，请切换合适的档位。电流档为低阻支路，应串联使用。'
                q['reading']=None


def readings(q):
    kind=q['instrument']
    if kind=='motor':
        return [['转速',f"{q['omega']*60/(2*math.pi):.3g} r/min"],['反电动势',f"{q.get('back_emf',0):.4g} V"],['铜损',f"{q.get('I',0)**2*q['R']:.4g} W"]]
    if kind=='inductor':
        return [['线圈电流',f"{q['coil_i']:.4g} A"],['自感电压',f"{q.get('coil_voltage',0):.4g} V"],['磁场能',f"{q.get('magnetic_energy',0):.4g} J"]]
    if kind=='galvanometer':
        return [['有向电流',f"{q.get('I',0):.4g} A"],['满偏比例',f"{q.get('I',0)/q['range']:.3g}"]]
    if kind=='multimeter':
        unit={'voltage':'V','current':'A','resistance':'Ω'}[q['mode']]
        return [['读数','未给出' if q.get('reading') is None else f"{q['reading']:.5g} {unit}"],['状态','请核对接法' if q.get('warning') else '未超量程']]
    return [['采样数',str(len(q['trace']))],['输入阻抗','10 MΩ']]


def inspector(q,L,edit,rebuild):
    kind=q.get('instrument')
    if kind=='motor':
        L.slider('线圈电阻',.1,100,.1,q['R'],edit(lambda v:q.__setitem__('R',v)),'Ω')
        L.slider('负载转矩',0,1,.01,q['load'],edit(lambda v:q.__setitem__('load',v)),'N·m')
        L.slider('电机常数',.01,1,.01,q['motor_k'],edit(lambda v:q.__setitem__('motor_k',v)))
        L.note('直流永磁电机：U=IR+kω，转矩=kI；有转动惯量和黏性阻尼。忽略磁饱和、电刷及换向纹波。负载为恒定反向转矩。')
    elif kind=='inductor':
        L.slider('电感',.01,10,.01,q['L'],edit(lambda v:q.__setitem__('L',v)),'H')
        L.slider('线圈电阻',.1,100,.1,q['R'],edit(lambda v:q.__setitem__('R',v)),'Ω')
        L.note('RL后向欧拉伴随模型；内置1000Ω并联泄放电阻，断电能量有明确去路。忽略寄生电容、电弧和磁饱和；短暂峰值受仿真步长影响，不据此推断绝缘击穿。')
    elif kind=='multimeter':
        def mode(value):
            q.update(mode=value,range={'voltage':20.,'current':.2,'resistance':10000.}[value])
            from PySide6.QtCore import QTimer
            QTimer.singleShot(0,rebuild)
        L.select('测量档', [('voltage','直流电压'),('current','直流电流'),('resistance','电阻（先断开所有电源）')],q['mode'],edit(mode))
        L.slider('量程',.01,10000,.01,q['range'],edit(lambda v:q.__setitem__('range',v)))
        L.note('电压档10MΩ、电流档0.05Ω；电阻档内部1.5V与1kΩ。检测到外部电源时禁用电阻测量；不能测交流或带电电阻。量程只改变显示范围，不模拟电表损坏。')
    elif kind=='galvanometer':
        L.slider('满偏电流',.0001,.01,.0001,q['range'],edit(lambda v:q.__setitem__('range',v)),'A')
        L.note('内阻1000Ω的有向电流计，满偏比例可正可负；忽略指针机械惯性，超出满偏不模拟烧毁。')
    elif kind=='scope':
        L.note('两端电压随时间记录；10MΩ输入电阻真实加载网络。用于本工作台RC/RL低频暂态，采样不等于实体示波器带宽。')
    return kind in DEVICES


def paint(g,q):
    from ...kit.draw import D
    from ...design.tokens import T
    kind=q['instrument']
    if kind=='motor':
        D.circle(g,0,0,13,T.stage,T.fg,2)
        D.text(g,'M',0,5,T.fg,size=13,bold=True,align='center')
    elif kind=='inductor':
        for x in (-12,-4,4,12):
            D.circle(g,x,0,4,T.stage,T.fg,1.7)
    else:
        D.rect(g,-17,-11,34,22,T.stage,T.fg,2)
        if kind=='scope':
            D.line(g,-12,6,-5,6,T.c1,1.5)
            D.line(g,-5,6,3,-6,T.c1,1.5)
            D.line(g,3,-6,12,-6,T.c1,1.5)
        else:
            value=q.get('I',0)/max(q.get('range',1),1e-12)
            angle=max(-1,min(1,value))*1.1
            D.line(g,0,7,10*math.sin(angle),7-14*math.cos(angle),T.c1,1.6)


def draw_scope(g,q,canvas,bench):
    points=q.get('trace',[])
    if len(points)<2:
        return
    from ...kit.draw import D
    from ...design.tokens import T
    left,top,right,_=bench.safe()
    x,y=left+18,top+18
    w=min(380,max(120,canvas.w-left-right-36))
    h=140
    lo=min(0,min(p[1] for p in points))
    hi=max(0,max(p[1] for p in points))
    span=max(hi-lo,.1)
    t0,t1=points[0][0],points[-1][0]
    D.rect(g,x,y,w,h,T.raised,T.line,1)
    D.text(g,f"电压—时间：{t0:.2f} 至 {t1:.2f} s",x+8,y+18,T.fg,size=12)
    D.text(g,f"{lo:.3g} 至 {hi:.3g} V",x+8,y+35,T.muted,size=12)
    for a,b in zip(points,points[1:]):
        ax=x+8+(a[0]-t0)/(t1-t0)*(w-16)
        bx=x+8+(b[0]-t0)/(t1-t0)*(w-16)
        ay=y+h-8-(a[1]-lo)/span*(h-54)
        by=y+h-8-(b[1]-lo)/span*(h-54)
        D.line(g,ax,ay,bx,by,T.c1,1.7)
