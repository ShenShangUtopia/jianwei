"""依赖点构造：纯解析几何，随定义点移动，旧点格式不变。"""
import math

TOOLS={"midpoint":("中点",2),"perpendicular":("过点垂线",3),"parallel":("过点平行线",3),"bisector":("角平分线",3),"perpbisector":("垂直平分线",2),"tangent":("圆的切线",3)}


def resolve(mode,points,sign=1):
    a,b=points[:2]
    dx,dy=b[0]-a[0],b[1]-a[1]
    if mode=="midpoint":
        return ((a[0]+b[0])/2,(a[1]+b[1])/2)
    if mode=="perpbisector":
        return ((a[0]+b[0])/2-dy,(a[1]+b[1])/2+dx)
    if len(points)<3:
        return None
    c=points[2]
    if mode=="parallel":
        return (c[0]+dx,c[1]+dy)
    if mode=="perpendicular":
        return (c[0]-dy,c[1]+dx)
    if mode=="bisector":
        u=(a[0]-b[0],a[1]-b[1])
        v=(c[0]-b[0],c[1]-b[1])
        nu,nv=math.hypot(*u),math.hypot(*v)
        if min(nu,nv)<1e-9:
            return None
        return (b[0]+u[0]/nu+v[0]/nv,b[1]+u[1]/nu+v[1]/nv)
    if mode=="tangent":
        # a=center, b=radius point, c=external point.
        radius=math.hypot(dx,dy)
        vx,vy=c[0]-a[0],c[1]-a[1]
        d2=vx*vx+vy*vy
        if radius<=1e-9 or d2<radius*radius or d2<1e-9:
            return None
        f=radius*radius/d2
        g=sign*radius*math.sqrt(max(0,d2-radius*radius))/d2
        return (a[0]+f*vx-g*vy,a[1]+f*vy+g*vx)
    return None


def install(board):
    original=board.on_down
    pending=dict(kind=None,ids=[])
    old_set_tool=board.set_tool
    def set_tool(tool):
        pending.update(kind=None,ids=[])
        return old_set_tool(tool)
    board.set_tool=set_tool
    def begin(kind):
        old_set_tool("select")
        pending.update(kind=kind,ids=[])
        board.toast(TOOLS[kind][0]+"：依次点击定义点；空白处会创建点。切线按圆心、圆上点、外点。")
    def down(event,lx,ly,world,shift):
        kind=pending["kind"]
        if not kind:
            return original(event,lx,ly,world,shift)
        from PySide6.QtCore import Qt
        if event.button()!=Qt.MouseButton.LeftButton:
            pending["kind"]=None
            return
        hit=board.hit_test(lx,ly)
        if not pending["ids"]:
            board.push_history()
        point=hit if hit and hit.get("type")=="point" else board.create_point(*world)
        if point["id"] not in pending["ids"]:
            pending["ids"].append(point["id"])
        if len(pending["ids"])<TOOLS[kind][1]:
            board.render()
            return
        ids=list(pending["ids"])
        coords=[board.cur_of_id(i) for i in ids]
        def dependent(mode,sign=1):
            value=resolve(mode,coords,sign)
            if value is None:
                return None
            item=board.create_point(*value,aux=True)
            item["construction"]=dict(mode=mode,parents=ids,sign=sign)
            return item
        if kind=="midpoint":
            item=dependent(kind)
            if item:
                item["aux"]=False
        elif kind=="perpbisector":
            middle=dependent("midpoint")
            direction=dependent(kind)
            board.create_shape("line",dict(a=middle["id"],b=direction["id"]))
        else:
            for sign in ((-1,1) if kind=="tangent" else (1,)):
                direction=dependent(kind,sign)
                if direction:
                    anchor=ids[1] if kind=="bisector" else ids[2]
                    board.create_shape("line",dict(a=anchor,b=direction["id"]))
                else:
                    board.toast("该定义下构造不存在（检查重合点或圆内点）")
        pending.update(kind=None,ids=[])
        board.refresh_all()
        board.schedule_save()
    board.on_down=down
    return begin
