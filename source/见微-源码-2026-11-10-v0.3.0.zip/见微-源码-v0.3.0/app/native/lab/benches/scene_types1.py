"""场景搭建的物体类型（一）：运动学、力学、万有引力、电学、磁场（由 legacy/lab-phys.js 改写）。"""
from __future__ import annotations

import math

from ...kit.core import PI, TAU, clamp
from ...kit.draw import D
from .scene_core import (C, E, NS, ORBIT_SCALE, ORBIT_UNIT, arc_w, arrow_p, arrow_w, circle_p, circle_w, deg, define, draw_trail, fmt, force_arrow, line_w,
                         poly_w, push_trail, px, py, rad, rect_w, rot_rect_p, round_rect_p, sign, sp, tag_p, txt, vel_arrow, with_alpha)


def bounds(x0, x1, y0, y1):
    return NS(x0=x0, x1=x1, y0=y0, y1=y1)


LB = dict(align="center", size=10.5)


# ---------------------------------------------------------------- 运动学
def _car_init(o):
    o.s.rx, o.s.v = 0.0, o.p.v0
    o.trail, o._tt = [], 0


def _car_param(o, k):
    if k == "v0":
        o.s.v = o.p.v0


def _car_step(o, dt):
    v = o.s.v
    if abs(v) > 1e-3:
        nv = v - sign(v) * o.p.mu * E.S.g * dt
        v = 0.0 if sign(nv) != sign(v) else nv
    o.s.v = v
    o.s.rx += v * dt
    push_trail(o, o.x + o.s.rx, o.y + 0.3, dt, 0.06)


def _car_draw(o):
    x, y = o.x + o.s.rx, o.y
    draw_trail(o, C.ink2, 0.3)
    round_rect_p(px(x) - sp(0.45), py(y + 0.48), sp(0.9), sp(0.3), 5, with_alpha(C.ink2, 0.2), C.ink, 1.4)
    round_rect_p(px(x) - sp(0.2), py(y + 0.62), sp(0.34), sp(0.14), 4, with_alpha(C.accent, 0.22), with_alpha(C.accent, 0.7), 1.1)
    for dx in (-0.27, 0.27):
        circle_w(x + dx, y + 0.13, 0.11, with_alpha(C.ink, 0.18), C.ink, 1.3)
        circle_w(x + dx, y + 0.13, 0.04, C.ink)
    if E.S.show.vectors:
        vel_arrow(x, y + 0.42, o.s.v, 0, "v")
        if abs(o.s.v) > 0.05:
            force_arrow(x, y + 0.2, -sign(o.s.v) * o.p.mu * E.S.g, 0, "f")
    txt(x, y + 0.92, f"小车 m={fmt(o.p.m, 1)} kg", color=C.ink2, **LB)


def _car_read(o):
    a = -sign(o.s.v) * o.p.mu * E.S.g if abs(o.s.v) > 1e-3 else 0
    return [["速度 v", fmt(o.s.v, 2), "m/s"], ["加速度 a", fmt(a, 2), "m/s²"], ["位移 x", fmt(o.s.rx, 2), "m"], ["动能 Ek", fmt(0.5 * o.p.m * o.s.v ** 2, 2), "J"]]


define("car", "小车", "kin", 3, 0.6, "地面上的小车，受动摩擦减速",
       [("m", "质量 m", "kg", 0.2, 10, 0.1, 1, 1), ("v0", "初速 v₀", "m/s", -8, 8, 0.1, 2, 1), ("mu", "动摩擦 μ", "", 0, 0.8, 0.01, 0.12, 2)],
       _car_init, _car_step, _car_draw, _car_read, lambda o: bounds(o.x + o.s.rx - 0.62, o.x + o.s.rx + 0.62, o.y - 0.06, o.y + 0.8), _car_param, snap_y=0)


def _proj_init(o, *_):
    a = rad(o.p.th)
    o.s.update(rx=0.0, ry=0.0, landed=False, vx=o.p.v0 * math.cos(a), vy=o.p.v0 * math.sin(a))
    o.trail, o._tt = [], 0


def _proj_step(o, dt):
    s = o.s
    if s.landed:
        return
    s.vy -= E.S.g * dt
    s.rx += s.vx * dt
    s.ry += s.vy * dt
    if E.S.show.ground and o.y + s.ry < 0.16:
        s.ry = 0.16 - o.y
        s.vy = -s.vy * 0.55
        s.vx *= 0.92
        if abs(s.vy) < 0.7:
            s.vy, s.landed = 0.0, True
    push_trail(o, o.x + s.rx, o.y + s.ry, dt, 0.035)


def _proj_draw(o):
    s = o.s
    x, y = o.x + s.rx, o.y + s.ry
    draw_trail(o, C.accent, 0.45)
    circle_w(x, y, 0.155, with_alpha(C.accent, 0.85), C.ink, 1.2)
    circle_w(x - 0.045, y + 0.045, 0.04, with_alpha("#FFFFFF", 0.45))
    if E.S.show.vectors and not s.landed:
        k = 0.16
        line_w([(x, y), (x + s.vx * k, y)], with_alpha(C.ink2, 0.45), 1, [3, 4])
        line_w([(x + s.vx * k, y), (x + s.vx * k, y + s.vy * k)], with_alpha(C.ink2, 0.45), 1, [3, 4])
        vel_arrow(x, y, s.vx, s.vy, "v", C.accent, k)
        force_arrow(x, y, 0, -E.S.g * o.p.m, "mg")
    txt(x + 0.24, y + 0.58, f"抛体 v₀={fmt(o.p.v0, 1)} m/s", align="left", size=10.5, color=C.ink2)


define("projectile", "抛体小球", "kin", 4, 0.32, "斜抛 / 平抛小球，落地会反弹",
       [("m", "质量 m", "kg", 0.1, 5, 0.1, 1, 2), ("v0", "初速 v₀", "m/s", 0, 20, 0.5, 8, 1), ("th", "抛射角 θ", "°", 0, 90, 1, 45, 0)],
       _proj_init, _proj_step, _proj_draw,
       lambda o: [["速度 v", fmt(math.hypot(o.s.vx, o.s.vy), 2), "m/s"], ["水平分量 vx", fmt(o.s.vx, 2), "m/s"], ["竖直分量 vy", fmt(o.s.vy, 2), "m/s"],
                  ["高度 y", fmt(o.y + o.s.ry, 2), "m"], ["加速度 a", fmt(E.S.g, 2), "m/s²"]],
       lambda o: bounds(o.x + o.s.rx - 0.3, o.x + o.s.rx + 0.3, o.y + o.s.ry - 0.3, o.y + o.s.ry + 0.3), _proj_init)


def _circ_init(o):
    o.s.th = 0.0
    o.trail, o._tt = [], 0


def _circ_param(o, k):
    if k == "R":
        o.s.th = 0.0


def _circ_step(o, dt):
    o.s.th += o.p.v / max(0.05, o.p.R) * dt
    push_trail(o, o.x + o.p.R * math.cos(o.s.th), o.y + o.p.R * math.sin(o.s.th), dt, 0.05)


def _circ_draw(o):
    R, th = o.p.R, o.s.th
    circle_w(o.x, o.y, R, None, with_alpha(C.ink2, 0.55), 1.3, [5, 5])
    circle_w(o.x, o.y, 0.05, C.ink)
    x, y = o.x + R * math.cos(th), o.y + R * math.sin(th)
    draw_trail(o, C.jade, 0.5)
    line_w([(o.x, o.y), (x, y)], with_alpha(C.ink2, 0.4), 1, [3, 4])
    circle_w(x, y, 0.15, with_alpha(C.accent, 0.85), C.ink, 1.2)
    if E.S.show.vectors:
        vel_arrow(x, y, -math.sin(th) * o.p.v, math.cos(th) * o.p.v, "v")
        force_arrow(x, y, -math.cos(th) * o.p.v ** 2 / R * 0.25, -math.sin(th) * o.p.v ** 2 / R * 0.25, "a向心")
    txt(o.x, o.y + R + 0.45, f"圆周 R={fmt(R, 2)} m", color=C.ink2, **LB)


def _circ_read(o):
    R, v = o.p.R, o.p.v
    w = v / R
    return [["线速度 v", fmt(v, 2), "m/s"], ["角速度 ω", fmt(w, 2), "rad/s"], ["向心加速度", fmt(v * v / R, 2), "m/s²"], ["周期 T", fmt(TAU / w, 2), "s"],
            ["向心力 F", fmt(o.p.m * v * v / R, 2), "N"]]


define("circular", "圆周运动小球", "kin", 4, 0.4, "匀速圆周运动，向心加速度可读",
       [("m", "质量 m", "kg", 0.1, 5, 0.1, 0.5, 2), ("v", "线速度 v", "m/s", 0.4, 8, 0.1, 2.4, 1), ("R", "半径 R", "m", 0.4, 3, 0.05, 1.2, 2)],
       _circ_init, _circ_step, _circ_draw, _circ_read, lambda o: bounds(o.x - o.p.R - 0.3, o.x + o.p.R + 0.3, o.y - o.p.R - 0.3, o.y + o.p.R + 0.3), _circ_param,
       sel_ring=lambda o: o.p.R + 0.16)


def _belt_draw(o):
    L, y = o.p.L, o.y
    x0, x1 = o.x + 0.26, o.x + L
    for xx in (x0, x1):
        circle_w(xx, y, 0.22, with_alpha(C.ink2, 0.12), C.ink2, 1.3)
        circle_w(xx, y, 0.05, C.ink)
    line_w([(x0, y + 0.22), (x1, y + 0.22)], C.ink, 2)
    line_w([(x0, y - 0.22), (x1, y - 0.22)], C.ink, 2)
    for i in range(12):
        f = (i / 12 + o.s.phase) % 1
        X = px(x0) + f * sp(L - 0.26)
        if px(x0) + 2 < X < px(x1) - 2:
            Y = py(y + 0.22)
            D.poly(E.g, [(X - 3, Y - 5), (X + 2, Y), (X - 3, Y + 5)], None, with_alpha(C.accent, 0.75), 1.6, close=False)
    if E.S.show.vectors:
        vel_arrow(o.x + 0.7, y + 0.42, o.p.v, 0, "v带")
    txt(o.x + L / 2, y + 0.62, f"传送带 v={fmt(o.p.v, 1)} m/s", color=C.ink2, **LB)


def _belt_step(o, dt):
    o.s.phase = (o.s.phase + o.p.v * dt / max(0.2, o.p.L)) % 1


def _belt_read(o):
    Tp = o.p.L / o.p.v if o.p.v > 0.01 else math.inf
    return [["带速 v", fmt(o.p.v, 2), "m/s"], ["长度 L", fmt(o.p.L, 2), "m"], ["周期 T", fmt(Tp, 2), "s"], ["带面摩擦 μ", fmt(o.p.mu, 2), ""]]


define("belt", "传送带", "kin", 2, 0.45, "匀速传送带，表面速度可调",
       [("v", "带速 v", "m/s", 0, 4, 0.1, 1.6, 1), ("L", "长度 L", "m", 1, 6, 0.1, 3.6, 1), ("mu", "带面 μ", "", 0, 0.9, 0.01, 0.3, 2)],
       lambda o: o.s.update(phase=0.0), _belt_step, _belt_draw, _belt_read, lambda o: bounds(o.x - 0.35, o.x + o.p.L + 0.35, o.y - 0.45, o.y + 0.45), snap_y=0.24)


# ---------------------------------------------------------------- 力学
def _inc_reset(o, *_):
    o.s.s, o.s.v = 0.0, o.p.v0


def _inc_step(o, dt):
    th, L = rad(o.p.th), o.p.L
    a = E.S.g * (math.sin(th) - o.p.mu * math.cos(th))
    if abs(o.s.v) < 1e-3 and math.tan(th) <= o.p.mu:
        a = 0
    v = max(0.0, o.s.v + a * dt)
    o.s.v = v
    o.s.s += v * dt
    if o.s.s > L - 0.3:
        o.s.s, o.s.v = L - 0.3, 0.0


def _inc_draw(o):
    th, L = rad(o.p.th), o.p.L
    A, B, Cc = (o.x, o.y), (o.x + L * math.cos(th), o.y), (o.x, o.y + L * math.sin(th))
    poly_w([A, B, Cc], with_alpha(C.ink2, 0.1), C.ink, 1.6)
    line_w([Cc, B], C.ink, 2)
    arc_w(B[0], B[1], 0.72, PI - th, PI, with_alpha(C.accent, 0.8), 1.3)
    along = o.s.s + 0.16
    P = (Cc[0] + along * math.cos(th), Cc[1] - along * math.sin(th))
    nx, ny = math.sin(th), math.cos(th)
    bc = (P[0] + nx * 0.17, P[1] + ny * 0.17)
    rot_rect_p(px(bc[0]), py(bc[1]), th, -sp(0.26), -sp(0.17), sp(0.52), sp(0.34), 4, with_alpha(C.accent, 0.75), C.ink, 1.2)
    if E.S.show.vectors and o.s.v > 0.01:
        vel_arrow(bc[0], bc[1], o.s.v * math.cos(th) * 0.24, -o.s.v * math.sin(th) * 0.24, "v")
        force_arrow(bc[0], bc[1] - 0.1, 0, -o.p.m * E.S.g, "mg")
    txt(o.x + L * math.cos(th) * 0.5, o.y + L * math.sin(th) + 0.34, f"斜面 θ={fmt(o.p.th, 0)}° μ={fmt(o.p.mu, 2)}", color=C.ink2, **LB)


def _inc_read(o):
    th = rad(o.p.th)
    g = E.S.g
    return [["加速度 a", fmt(g * (math.sin(th) - o.p.mu * math.cos(th)), 2), "m/s²"], ["速度 v", fmt(o.s.v, 2), "m/s"], ["下滑位移 s", fmt(o.s.s, 2), "m"],
            ["支持力 N", fmt(o.p.m * g * math.cos(th), 2), "N"], ["摩擦力 f", fmt(o.p.mu * o.p.m * g * math.cos(th), 2), "N"]]


define("incline", "斜面", "mech", 2, 0.8, "斜面 + 滑块，含摩擦与倾角",
       [("th", "倾角 θ", "°", 5, 70, 1, 30, 0), ("mu", "动摩擦 μ", "", 0, 0.9, 0.01, 0.2, 2), ("m", "滑块质量 m", "kg", 0.2, 5, 0.1, 1, 2), ("L", "斜面长 L", "m", 1, 5, 0.1, 3, 1),
        ("v0", "初速 v₀", "m/s", 0, 4, 0.1, 0, 1)],
       _inc_reset, _inc_step, _inc_draw, _inc_read,
       lambda o: bounds(o.x - 0.2, o.x + o.p.L * math.cos(rad(o.p.th)) + 0.25, o.y - 0.15, o.y + o.p.L * math.sin(rad(o.p.th)) + 0.35), _inc_reset, snap_y=0)


def _spr_init(o, *_):
    o.s.x, o.s.v = o.p.A, 0.0
    o.trail, o._tt = [], 0


def _spr_step(o, dt):
    o.s.v += -o.p.k / o.p.m * o.s.x * dt
    o.s.x += o.s.v * dt
    push_trail(o, o.x + o.s.x, o.y + 0.22, dt, 0.04)


def _spr_draw(o):
    base_y, wall = o.y + 0.2, o.x - 1.25
    line_w([(wall, base_y - 0.3), (wall, base_y + 0.45)], C.ink, 3)
    for i in range(5):
        line_w([(wall, base_y - 0.3 + i * 0.16), (wall - 0.14, base_y - 0.4 + i * 0.16)], with_alpha(C.ink2, 0.5), 1)
    line_w([(wall, o.y), (o.x + 0.7, o.y)], with_alpha(C.ink2, 0.35), 1.2)
    bx = o.x + o.s.x
    left = bx - 0.24
    X0, X1, Y = px(wall), px(left), py(base_y)
    n, span = 9, X1 - X0
    pts = [(X0, Y)] + [(X0 + span * (i + 0.5) / (n + 1), Y + (-8 if i % 2 else 8)) for i in range(n + 1)] + [(X1, Y)]
    D.poly(E.g, pts, None, C.ink2, 1.5, close=False)
    line_w([(o.x, o.y), (o.x, base_y + 0.42)], with_alpha(C.accent, 0.5), 1, [4, 4])
    round_rect_p(px(left), py(o.y + 0.44), sp(0.48), sp(0.44), 4, with_alpha(C.accent, 0.65), C.ink, 1.2)
    draw_trail(o, C.jade, 0.35)
    if E.S.show.vectors:
        vel_arrow(bx, base_y + 0.28, o.s.v * 0.5, 0, "v")
        force_arrow(bx, base_y + 0.28, -o.p.k * o.s.x, 0, "F")
    txt(o.x, o.y + 0.9, f"弹簧 k={fmt(o.p.k, 0)} N/m", color=C.ink2, **LB)


def _spr_read(o):
    w = math.sqrt(o.p.k / o.p.m)
    return [["位移 x", fmt(o.s.x, 2), "m"], ["速度 v", fmt(o.s.v, 2), "m/s"], ["加速度 a", fmt(-o.p.k / o.p.m * o.s.x, 2), "m/s²"], ["周期 T", fmt(TAU / w, 2), "s"],
            ["总能量 E", fmt(0.5 * o.p.k * o.p.A ** 2, 2), "J"]]


define("spring", "弹簧振子", "mech", 3, 0.7, "水平弹簧振子，简谐振动",
       [("k", "劲度 k", "N/m", 2, 80, 1, 20, 1), ("m", "质量 m", "kg", 0.2, 3, 0.1, 0.5, 2), ("A", "振幅 A", "m", 0.1, 0.9, 0.05, 0.45, 2)],
       _spr_init, _spr_step, _spr_draw, _spr_read, lambda o: bounds(o.x - 1.4, o.x + 0.55, o.y - 0.15, o.y + 0.7), _spr_init, snap_y=0)


def _pen_init(o):
    o.s.th, o.s.w = rad(o.p.th0), 0.0
    o.trail, o._tt = [], 0


def _pen_param(o, _k):
    o.s.th, o.s.w = rad(o.p.th0), 0.0


def _pen_step(o, dt):
    o.s.w += (-(E.S.g / o.p.L) * math.sin(o.s.th) - o.p.damp * o.s.w) * dt
    o.s.th += o.s.w * dt
    push_trail(o, o.x + o.p.L * math.sin(o.s.th), o.y - o.p.L * math.cos(o.s.th), dt, 0.035)


def _pen_draw(o):
    L, th = o.p.L, o.s.th
    bx, by = o.x + L * math.sin(th), o.y - L * math.cos(th)
    line_w([(o.x - 0.35, o.y + 0.04), (o.x + 0.35, o.y + 0.04)], C.ink, 2.4)
    for i in range(5):
        line_w([(o.x - 0.32 + i * 0.16, o.y + 0.04), (o.x - 0.4 + i * 0.16, o.y + 0.14)], with_alpha(C.ink2, 0.5), 1)
    arc_w(o.x, o.y, L, -PI / 2 - rad(o.p.th0), -PI / 2 + rad(o.p.th0), with_alpha(C.ink2, 0.3), 1, [3, 5])
    line_w([(o.x, o.y), (bx, by)], with_alpha(C.ink, 0.65), 1.4)
    draw_trail(o, C.accent, 0.4)
    circle_w(bx, by, 0.13, with_alpha(C.accent, 0.85), C.ink, 1.2)
    if abs(th) > 0.03:
        arc_w(o.x, o.y, 0.32, -PI / 2, -PI / 2 + th, with_alpha(C.accent, 0.8), 1.2)
    if E.S.show.vectors:
        vel_arrow(bx, by, L * o.s.w * math.cos(th) * 1.2, L * o.s.w * math.sin(th) * 1.2, "v")
        force_arrow(bx, by, 0, -o.p.m * E.S.g, "mg")
    txt(bx, by + 0.42, f"单摆 L={fmt(L, 2)} m", color=C.ink2, **LB)


def _pen_read(o):
    th, L = o.s.th, o.p.L
    g = E.S.g
    return [["摆角 θ", fmt(deg(th), 1), "°"], ["角速度 ω", fmt(o.s.w, 2), "rad/s"], ["线速度 v", fmt(L * o.s.w, 2), "m/s"], ["周期 T", fmt(TAU * math.sqrt(L / g), 2), "s"],
            ["回复力 F", fmt(-o.p.m * g * math.sin(th), 2), "N"]]


def _pen_bounds(o):
    bx = o.x + o.p.L * math.sin(o.s.th)
    return bounds(min(o.x, bx) - 0.32, max(o.x, bx) + 0.32, o.y - o.p.L - 0.28, o.y + 0.24)


define("pendulum", "单摆", "mech", 4, 0.6, "单摆，小角度近简谐，可加阻尼",
       [("L", "摆长 L", "m", 0.4, 2.4, 0.05, 1.2, 2), ("m", "摆球质量 m", "kg", 0.1, 3, 0.1, 0.5, 2), ("th0", "初始摆角 θ₀", "°", 5, 75, 1, 35, 0), ("damp", "阻尼 ζ", "", 0, 0.12, 0.005, 0.015, 3)],
       _pen_init, _pen_step, _pen_draw, _pen_read, _pen_bounds, _pen_param)


def _col_init(o, *_):
    o.s.update(x1=-0.62, x2=0.62, v1=o.p.v1, v2=o.p.v2)


def _col_step(o, dt):
    s = o.s
    R2 = 0.56
    s.x1 += s.v1 * dt
    s.x2 += s.v2 * dt
    if s.x2 - s.x1 < R2:
        m1, m2, e = o.p.m1, o.p.m2, o.p.e
        u1, u2 = s.v1, s.v2
        s.v1 = ((m1 - e * m2) * u1 + (1 + e) * m2 * u2) / (m1 + m2)
        s.v2 = ((m2 - e * m1) * u2 + (1 + e) * m1 * u1) / (m1 + m2)
        over = R2 - (s.x2 - s.x1)
        s.x1 -= over / 2 + 1e-3
        s.x2 += over / 2 + 1e-3


def _col_draw(o):
    y, R = o.y, 0.28
    x1, x2 = o.x + o.s.x1, o.x + o.s.x2
    line_w([(o.x - 1.2, y - R - 0.12), (o.x + 1.2, y - R - 0.12)], with_alpha(C.ink2, 0.45), 1.2)
    circle_w(x1, y, R, with_alpha(C.ink2, 0.25), C.ink, 1.5)
    circle_w(x2, y, R, with_alpha(C.accent, 0.28), C.accent, 1.5)
    txt(x1, y, "m₁", align="center", size=11, weight=700, color=C.ink)
    txt(x2, y, "m₂", align="center", size=11, weight=700, color=C.accent)
    if E.S.show.vectors:
        vel_arrow(x1, y + 0.42, o.s.v1 * 0.3, 0, "v₁", C.ink2)
        vel_arrow(x2, y + 0.42, o.s.v2 * 0.3, 0, "v₂", C.accent)
    txt(o.x, y + 0.78, f"碰撞 e={fmt(o.p.e, 2)}", color=C.ink2, **LB)


define("collision", "两个碰撞球", "mech", 4, 0.7, "一维碰撞，恢复系数可调",
       [("m1", "左球质量 m₁", "kg", 0.2, 5, 0.1, 2, 1), ("m2", "右球质量 m₂", "kg", 0.2, 5, 0.1, 1, 1), ("v1", "左球初速 v₁", "m/s", -6, 6, 0.1, 2.2, 1), ("v2", "右球初速 v₂", "m/s", -6, 6, 0.1, -1.2, 1),
        ("e", "恢复系数 e", "", 0, 1, 0.01, 0.9, 2)],
       _col_init, _col_step, _col_draw,
       lambda o: [["左球 v₁", fmt(o.s.v1, 2), "m/s"], ["右球 v₂", fmt(o.s.v2, 2), "m/s"], ["总动量 p", fmt(o.p.m1 * o.s.v1 + o.p.m2 * o.s.v2, 2), "kg·m/s"],
                  ["总动能 Ek", fmt(0.5 * o.p.m1 * o.s.v1 ** 2 + 0.5 * o.p.m2 * o.s.v2 ** 2, 2), "J"]],
       lambda o: bounds(o.x - 1.35, o.x + 1.35, o.y - 0.45, o.y + 0.55), _col_init, snap_y=0.3)


def _atw_reset(o, *_):
    o.s.s, o.s.v = 0.0, 0.0


def _atw_step(o, dt):
    m1, m2 = o.p.m1, o.p.m2
    o.s.v += E.S.g * (m2 - m1) / (m1 + m2) * dt
    o.s.s += o.s.v * dt
    if abs(o.s.s) > 0.62:
        o.s.s, o.s.v = sign(o.s.s) * 0.62, 0.0


def _atw_draw(o):
    R, y, s = 0.3, o.y, o.s.s
    y1, y2 = y - 1.15 + s, y - 1.15 - s
    circle_w(o.x, y, R, with_alpha(C.ink2, 0.1), C.ink, 1.8)
    circle_w(o.x, y, 0.04, C.ink)
    line_w([(o.x - R, y), (o.x - R, y1 + 0.16)], C.ink2, 1.4)
    line_w([(o.x + R, y), (o.x + R, y2 + 0.16)], C.ink2, 1.4)
    arc_w(o.x, y, R, 0, PI, C.ink2, 1.4)
    line_w([(o.x, y + R), (o.x, y + 0.55)], C.ink, 2)
    line_w([(o.x - 0.34, y + 0.55), (o.x + 0.34, y + 0.55)], C.ink, 2)
    round_rect_p(px(o.x - R) - sp(0.16), py(y1 + 0.16), sp(0.32), sp(0.32), 4, with_alpha(C.ink2, 0.18), C.ink, 1.3)
    round_rect_p(px(o.x + R) - sp(0.16), py(y2 + 0.16), sp(0.32), sp(0.32), 4, with_alpha(C.accent, 0.22), C.accent, 1.3)
    txt(o.x - R, y1, "m₁", align="center", size=10, color=C.ink)
    txt(o.x + R, y2, "m₂", align="center", size=10, color=C.accent)
    if E.S.show.vectors:
        vel_arrow(o.x - R, y1 - 0.3, 0, o.s.v * 0.4, "", C.ink2)
        vel_arrow(o.x + R, y2 - 0.3, 0, -o.s.v * 0.4, "", C.accent)
    txt(o.x, y + 0.78, f"连接体 m₁={fmt(o.p.m1, 1)} m₂={fmt(o.p.m2, 1)}", color=C.ink2, **LB)


def _atw_read(o):
    m1, m2, g = o.p.m1, o.p.m2, E.S.g
    return [["加速度 a", fmt(g * (m2 - m1) / (m1 + m2), 2), "m/s²"], ["速度 v", fmt(o.s.v, 2), "m/s"], ["绳张力 T", fmt(2 * m1 * m2 * g / (m1 + m2), 2), "N"], ["位移 s", fmt(o.s.s, 2), "m"]]


define("atwood", "连接体（滑轮）", "mech", 3, 0.8, "定滑轮连接两物块，绳不可伸长",
       [("m1", "左物块 m₁", "kg", 0.2, 5, 0.1, 1, 2), ("m2", "右物块 m₂", "kg", 0.2, 5, 0.1, 1.6, 2)],
       _atw_reset, _atw_step, _atw_draw, _atw_read, lambda o: bounds(o.x - 0.55, o.x + 0.55, o.y - 1.85, o.y + 0.65), _atw_reset)


# ---------------------------------------------------------------- 万有引力
def mu_units(b):
    M = 1
    if b and b.p and b.p.M is not None:
        M = b.p.M
    elif E.S:
        for o in E.S.objects:
            if o.type == "body" and o.visible:
                M = o.p.M
                break
    return 3.986e14 / ORBIT_UNIT ** 3 * M   # 地球 μ = 3.986e14 m³/s²，换算到 (10^7 m, s)


def center_body(o):
    best, bd = None, math.inf
    for b in E.S.objects:
        if b.type != "body" or not b.visible:
            continue
        d = math.hypot(b.x - o.x, b.y - o.y)
        if d < bd:
            bd, best = d, b
    return best


def _body_draw(o):
    R = 0.42
    circle_w(o.x, o.y, R + 0.18, with_alpha(C.gold, 0.08))
    circle_w(o.x, o.y, R, with_alpha(C.ink2, 0.35), C.ink, 1.6)
    circle_w(o.x, o.y, R * 0.66, None, with_alpha(C.ink, 0.25), 1)
    circle_w(o.x, o.y, R * 0.33, None, with_alpha(C.ink, 0.16), 1)
    circle_w(o.x - R * 0.3, o.y + R * 0.32, R * 0.16, with_alpha(C.ink2, 0.4))
    txt(o.x, o.y - R - 0.32, f"中心天体 M={fmt(o.p.M, 2)} M⊕", color=C.ink2, **LB)


define("body", "中心天体", "grav", 2, 0.5, "引力中心，质量以地球质量为单位", [("M", "质量 M", "M⊕", 0.2, 8, 0.1, 1, 2)], None, None, _body_draw,
       lambda o: [["质量 M", fmt(o.p.M, 2), "M⊕"], ["引力参数 GM", f"{3.986e14 * o.p.M:.3g}", "m³/s²"]])


def _sat_init(o, *_):
    b = center_body(o)
    cx, cy = (b.x, b.y) if b else (o.x - 1.6, o.y)
    dx, dy = o.x - cx, o.y - cy
    r = max(0.25, math.hypot(dx, dy))
    vc = math.sqrt(mu_units(b) / r)
    v = o.p.v * 1000 / ORBIT_UNIT if o.p.v > 0 else vc
    o.s.update(rx=0.0, ry=0.0, vx=-dy / r * v, vy=dx / r * v)
    o.trail, o._tt = [], 0


def _sat_step(o, dt):
    b = center_body(o)
    if not b:
        return
    s = o.s
    x, y = o.x + s.rx - b.x, o.y + s.ry - b.y
    r2 = max(1e-6, x * x + y * y)
    r = math.sqrt(r2)
    a = -mu_units(b) / (r2 * r)
    dte = dt * ORBIT_SCALE
    s.vx += a * x * dte
    s.vy += a * y * dte
    s.rx += s.vx * dte
    s.ry += s.vy * dte
    if math.hypot(s.rx + o.x - b.x, s.ry + o.y - b.y) < 0.5:   # 撞上天体：停在表面，避免数值穿透
        s.rx = (o.x + s.rx - b.x) / r * 0.5 - o.x + b.x
        s.ry = (o.y + s.ry - b.y) / r * 0.5 - o.y + b.y
        s.vx, s.vy = 0.0, 0.0
    push_trail(o, o.x + s.rx, o.y + s.ry, dt, 0.05)


def _sat_draw(o):
    b = center_body(o)
    s = o.s
    x, y = o.x + s.rx, o.y + s.ry
    if b:
        r = math.hypot(x - b.x, y - b.y)
        circle_w(b.x, b.y, r, None, with_alpha(C.ink2, 0.28), 1, [4, 6])
        v = math.hypot(s.vx, s.vy)
        if E.S.show.vectors and v > 1e-8:
            arrow_w(x, y, s.vx / v * max(0.25, r * 0.3), s.vy / v * max(0.25, r * 0.3), C.accent, 1.7, 8, "v")
            if r > 1e-6:
                arrow_w(x, y, (b.x - x) / r * 0.45, (b.y - y) / r * 0.45, C.jade, 1.4, 6, "")
    draw_trail(o, C.ink2, 0.45)
    circle_w(x, y, 0.12, with_alpha(C.accent, 0.9), C.ink, 1.2)
    panel = with_alpha(C.ink, 0.6)
    line_w([(x - 0.5, y), (x - 0.12, y)], panel, 1.2)
    line_w([(x + 0.12, y), (x + 0.5, y)], panel, 1.2)
    line_w([(x - 0.5, y - 0.1), (x - 0.5, y + 0.1)], panel, 2)
    line_w([(x + 0.5, y - 0.1), (x + 0.5, y + 0.1)], panel, 2)
    txt(x, y - 0.46, f"卫星 {fmt(math.hypot(s.vx, s.vy) * ORBIT_UNIT / 1000, 1)} km/s", color=C.ink2, **LB)


def _sat_read(o):
    b = center_body(o)
    x, y = o.x + o.s.rx - (b.x if b else 0), o.y + o.s.ry - (b.y if b else 0)
    r = math.hypot(x, y)
    v = math.hypot(o.s.vx, o.s.vy)
    Tp = TAU * r / v if r > 1e-6 and v > 0 else math.inf
    return [["轨道半径 r", fmt(r, 2), "×10⁷ m"], ["速度 v", fmt(v * ORBIT_UNIT / 1000, 2), "km/s"], ["周期 T", fmt(Tp / 3600, 2), "h"],
            ["向心加速度", fmt(mu_units(b) / max(1e-9, r * r) * ORBIT_UNIT, 2), "m/s²"], ["演示时间倍率", f"×{ORBIT_SCALE}", ""]]


define("satellite", "卫星 / 行星", "grav", 4, 0.32, "绕中心天体运行，自动圆轨道速度", [("v", "初速 v（0=圆轨道）", "km/s", 0, 7, 0.1, 0, 1)],
       _sat_init, _sat_step, _sat_draw, _sat_read, lambda o: bounds(o.x + o.s.rx - 0.28, o.x + o.s.rx + 0.28, o.y + o.s.ry - 0.28, o.y + o.s.ry + 0.28), _sat_init)


# ---------------------------------------------------------------- 电学
def circuit_info():
    bat, rs, sws = None, [], []
    for o in E.S.objects:
        if not o.visible:
            continue
        if o.type == "battery" and not bat:
            bat = o
        elif o.type == "resistor":
            rs.append(o)
        elif o.type == "switch":
            sws.append(o)
    if not bat:
        return NS(I=0.0, closed=False, R=math.inf, U=0)
    closed = all(s.p.closed for s in sws)
    R = bat.p.r + sum(r.p.R for r in rs)
    return NS(I=bat.p.U / R if closed and rs else 0.0, closed=closed, R=R, U=bat.p.U, hasRes=bool(rs))


def _bat_draw(o):
    x, y = o.x, o.y
    round_rect_p(px(x) - sp(0.36), py(y + 0.26), sp(0.72), sp(0.52), 6, with_alpha(C.ink2, 0.14), C.ink, 1.5)
    line_w([(x - 0.5, y), (x - 0.36, y)], C.ink, 2)
    line_w([(x + 0.36, y), (x + 0.5, y)], C.ink, 2)
    line_w([(x - 0.12, y - 0.16), (x - 0.12, y + 0.16)], C.ink, 1.6)
    line_w([(x + 0.1, y - 0.09), (x + 0.1, y + 0.09)], C.ink, 1.6)
    txt(x + 0.2, y - 0.18, "+", size=11, weight=700, color=C.accent)
    txt(x - 0.22, y - 0.18, "−", size=12, weight=700, color=C.ink2)
    txt(x, y + 0.47, f"电源 E={fmt(o.p.U, 1)} V", color=C.ink2, **LB)


define("battery", "电源", "elec", 2, 0.5, "直流电源：电动势与内阻", [("U", "电动势 E", "V", 1, 24, 0.5, 6, 1), ("r", "内阻 r", "Ω", 0.1, 5, 0.1, 0.5, 1)], None, None, _bat_draw,
       lambda o: [["电动势 E", fmt(o.p.U, 2), "V"], ["内阻 r", fmt(o.p.r, 2), "Ω"], ["回路电流 I", fmt(circuit_info().I, 3), "A"]],
       lambda o: bounds(o.x - 0.55, o.x + 0.55, o.y - 0.32, o.y + 0.32))


def _res_draw(o):
    x, y = o.x, o.y
    line_w([(x - 0.62, y), (x - 0.4, y)], C.ink2, 1.8)
    line_w([(x + 0.4, y), (x + 0.62, y)], C.ink2, 1.8)
    rect_w(x - 0.4, y - 0.17, 0.8, 0.34, with_alpha(C.ink2, 0.1), C.ink, 1.5)
    for i, col in enumerate((C.ink, C.accent, C.ink2)):   # 色环
        line_w([(x - 0.22 + i * 0.14, y - 0.16), (x - 0.22 + i * 0.14, y + 0.16)], col, 2.4)
    txt(x, y + 0.43, f"R={fmt(o.p.R, 0)} Ω", color=C.ink2, **LB)


def _res_read(o):
    i = circuit_info().I
    return [["阻值 R", fmt(o.p.R, 0), "Ω"], ["电流 I", fmt(i, 3), "A"], ["电压 U=IR", fmt(i * o.p.R, 2), "V"], ["功率 P", fmt(i * i * o.p.R, 2), "W"]]


define("resistor", "电阻", "elec", 2, 0.45, "定值电阻，串联回路读数", [("R", "阻值 R", "Ω", 1, 100, 1, 10, 0)], None, None, _res_draw, _res_read,
       lambda o: bounds(o.x - 0.64, o.x + 0.64, o.y - 0.22, o.y + 0.22))


def _wire_end(o):
    a = rad(o.p.ang)
    return o.x + o.p.L * math.cos(a), o.y + o.p.L * math.sin(a)


def _wire_draw(o):
    x2, y2 = _wire_end(o)
    line_w([(o.x, o.y), (x2, y2)], C.ink, 2.2)
    circle_w(o.x, o.y, 0.045, C.ink2)
    circle_w(x2, y2, 0.045, C.ink2)
    i = circuit_info().I
    if i > 0.001:
        txt((o.x + x2) / 2, (o.y + y2) / 2 + 0.18, f"I={fmt(i, 2)} A", align="center", size=9.5, color=C.accent)


def _wire_bounds(o):
    x2, y2 = _wire_end(o)
    return bounds(min(o.x, x2) - 0.1, max(o.x, x2) + 0.1, min(o.y, y2) - 0.1, max(o.y, y2) + 0.1)


define("wire", "导线", "elec", 1, 0.35, "理想导线，可旋转摆放", [("L", "长度 L", "m", 0.4, 4, 0.1, 1.2, 1), ("ang", "方向 φ", "°", 0, 360, 5, 0, 0)], None, None, _wire_draw,
       lambda o: [["长度 L", fmt(o.p.L, 2), "m"], ["电流 I", fmt(circuit_info().I, 3), "A"], ["电阻", "≈0", "Ω"]], _wire_bounds)


def _amm_draw(o):
    x, y, R = o.x, o.y, 0.34
    i = circuit_info().I
    circle_w(x, y, R, with_alpha(C.ink2, 0.08), C.ink, 1.6)
    a = -PI / 2 + clamp(i / max(0.1, o.p.scale), 0, 1) * 1.25
    arrow_p(px(x), py(y), px(x) + sp(R - 0.06) * math.cos(a), py(y) - sp(R - 0.06) * math.sin(a), C.accent, 1.6, 6)
    txt(x, y - R - 0.2, "A", align="center", size=11, weight=700, color=C.ink2)
    txt(x, y + R + 0.24, f"I={fmt(i, 2)} A", color=C.ink2, **LB)


define("ammeter", "电流表", "elec", 3, 0.42, "串联电流表，指针随电流偏转", [("scale", "量程", "A", 0.2, 5, 0.1, 3, 1)], None, None, _amm_draw,
       lambda o: [["电流 I", fmt(circuit_info().I, 3), "A"], ["量程", fmt(o.p.scale, 1), "A"], ["指针位置", fmt(clamp(circuit_info().I / max(0.1, o.p.scale), 0, 1) * 100, 0), "%"]],
       lambda o: bounds(o.x - 0.4, o.x + 0.4, o.y - 0.4, o.y + 0.4))


def _sw_draw(o):
    x, y, on = o.x, o.y, o.p.closed
    line_w([(x - 0.6, y), (x - 0.28, y)], C.ink, 2)
    line_w([(x + 0.28, y), (x + 0.6, y)], C.ink, 2)
    circle_w(x - 0.28, y, 0.05, C.ink)
    circle_w(x + 0.28, y, 0.05, C.ink)
    line_w([(x - 0.28, y), (x + (0.3 if on else 0.34), y + (0 if on else 0.34))], C.accent if on else C.ink, 2.4)
    txt(x, y + 0.55, "开关 · 闭合" if on else "开关 · 断开", color=C.accent if on else C.ink2, **LB)


define("switch", "开关", "elec", 2, 0.38, "单刀开关，闭合后回路导通", [NS(k="closed", label="闭合", unit="", kind="bool", **{"def": False})], None, None, _sw_draw,
       lambda o: [["状态", "闭合" if o.p.closed else "断开", ""], ["回路电流 I", fmt(circuit_info().I, 3), "A"]], lambda o: bounds(o.x - 0.62, o.x + 0.62, o.y - 0.12, o.y + 0.42))


def _cap_draw(o):
    x, y, d, h = o.x, o.y, o.p.d, 0.34
    line_w([(x - 0.85, y), (x - d / 2, y)], C.ink, 2)
    line_w([(x + d / 2, y), (x + 0.85, y)], C.ink, 2)
    line_w([(x - d / 2, y - h), (x - d / 2, y + h)], C.ink, 2.6)
    line_w([(x + d / 2, y - h), (x + d / 2, y + h)], C.ink, 2.6)
    if E.S.show.field:
        for i in (-1, 0, 1):
            arrow_w(x - d / 2 + 0.02, y + i * 0.16, d - 0.04, 0, with_alpha(C.accent, 0.65), 1.1, 5, "")
    txt(x, y + 0.55, f"C={fmt(o.p.C, 0)} μF · U={fmt(o.p.U, 1)} V", color=C.ink2, **LB)


define("capacitor", "电容器", "elec", 2, 0.4, "平行板电容器：Q、E、储能", [("C", "电容 C", "μF", 10, 500, 10, 100, 0), ("U", "电压 U", "V", 2, 30, 1, 6, 1), ("d", "板距 d", "m", 0.05, 0.4, 0.01, 0.2, 2)],
       None, None, _cap_draw,
       lambda o: [["电压 U", fmt(o.p.U, 1), "V"], ["电荷量 Q=CU", fmt(o.p.C * o.p.U, 1), "μC"], ["场强 E=U/d", fmt(o.p.U / max(0.01, o.p.d), 1), "V/m"],
                  ["储能 W", fmt(0.5 * o.p.C * o.p.U ** 2, 2), "μJ"]],
       lambda o: bounds(o.x - 0.88, o.x + 0.88, o.y - 0.38, o.y + 0.38))


# ---------------------------------------------------------------- 磁场
def _bf_draw(o):
    w, h = o.p.w, o.p.h
    x0, y0 = o.x - w / 2, o.y - h / 2
    rect_w(x0, y0, w, h, with_alpha(C.ink2, 0.05), with_alpha(C.ink2, 0.55), 1.3, [6, 5])
    if E.S.show.field:
        step = max(0.35, 42 / E.cam.scale)
        cols, rows = int(w // step), int(h // step)
        ox, oy = x0 + (w - (cols - 1) * step) / 2, y0 + (h - (rows - 1) * step) / 2
        for i in range(cols):
            for j in range(rows):
                X, Y = px(ox + i * step), py(oy + j * step)
                if o.p.dir > 0:
                    circle_p(X, Y, 2, C.ink2)
                    circle_p(X, Y, 4.2, None, with_alpha(C.ink2, 0.55), 1)
                else:
                    col, r = with_alpha(C.ink2, 0.75), 4
                    D.line(E.g, X - r, Y - r, X + r, Y + r, col, 1.3)
                    D.line(E.g, X + r, Y - r, X - r, Y + r, col, 1.3)
    tag_p(px(x0) + 2, py(y0 + h) - 11, f"B={fmt(o.p.B, 2)} T · {'垂直纸面向外' if o.p.dir > 0 else '垂直纸面向里'}", C.ink2)


define("bfield", "匀强磁场区", "mag", 1, 0.6, "矩形区域的匀强磁场，可换方向",
       [("B", "磁感应强度 B", "T", 0, 2, 0.05, 0.8, 2), NS(k="dir", label="方向", unit="", kind="enum", options=[NS(v=1, label="向外"), NS(v=-1, label="向里")], **{"def": 1}),
        ("w", "宽 w", "m", 0.8, 6, 0.1, 3.2, 1), ("h", "高 h", "m", 0.8, 4, 0.1, 2.6, 1)],
       None, None, _bf_draw,
       lambda o: [["磁感应强度 B", fmt(o.p.B, 2), "T"], ["方向", "垂直纸面向外" if o.p.dir > 0 else "垂直纸面向里", ""], ["区域", f"{fmt(o.p.w, 1)} × {fmt(o.p.h, 1)}", "m"]],
       lambda o: bounds(o.x - o.p.w / 2, o.x + o.p.w / 2, o.y - o.p.h / 2, o.y + o.p.h / 2))


def _mag_draw(o):
    L, h = o.p.L, 0.34
    x0 = o.x - L / 2
    rect_w(x0, o.y - h / 2, L / 2, h, with_alpha(C.ink2, 0.28), C.ink, 1.2)
    rect_w(o.x, o.y - h / 2, L / 2, h, with_alpha(C.accent, 0.3), C.accent, 1.2)
    txt(x0 + L * 0.25, o.y, "S", align="center", size=12, weight=700, color=C.ink)
    txt(x0 + L * 0.75, o.y, "N", align="center", size=12, weight=700, color=C.accent)
    if E.S.show.field:
        g = E.g
        Nx, Sx = x0 + L * 0.95, x0 + L * 0.05
        for k in range(1, 5):
            lift, bend = 0.34 + k * 0.3, L * 0.5 + k * 0.22
            g.stroke_style, g.line_width = with_alpha(C.ink2, 0.45 - k * 0.06), 1.2
            for sgn in (1, -1):
                yb = o.y + sgn * h / 2
                g.begin_path()
                g.move_to(px(Nx), py(yb))
                g.bezier_to(px(Nx + bend * 0.5), py(yb + sgn * lift), px(Sx - bend * 0.5), py(yb + sgn * lift), px(Sx), py(yb))
                g.stroke()
        arrow_w(o.x + L * 0.34, o.y + h / 2 + 0.62, -0.42, 0, with_alpha(C.ink2, 0.7), 1.2, 5, "")
        arrow_w(o.x + L * 0.34, o.y - h / 2 - 0.62, -0.42, 0, with_alpha(C.ink2, 0.7), 1.2, 5, "")
    txt(o.x, o.y + 0.75, f"磁体 B={fmt(o.p.B, 2)} T", color=C.ink2, **LB)


define("magnet", "磁体", "mag", 2, 0.5, "条形磁体，N/S 极与磁感线", [("B", "磁感应强度 B", "T", 0.05, 1, 0.05, 0.4, 2), ("L", "长度 L", "m", 0.6, 2.4, 0.1, 1.2, 1)], None, None, _mag_draw,
       lambda o: [["磁场 B", fmt(o.p.B, 2), "T"], ["极距", fmt(o.p.L, 2), "m"], ["磁极", "N → S（外部）", ""]],
       lambda o: bounds(o.x - o.p.L / 2 - 0.12, o.x + o.p.L / 2 + 0.12, o.y - 0.3, o.y + 0.3))


def b_at(x, y):
    bz = 0.0
    for o in E.S.objects:
        if o.visible and o.type == "bfield" and abs(x - o.x) <= o.p.w / 2 and abs(y - o.y) <= o.p.h / 2:
            bz += o.p.B * o.p.dir
    return bz


def e_at(x, y):
    Ex = Ey = phi = 0.0
    k = 8.99e9
    for o in E.S.objects:
        if not o.visible:
            continue
        if o.type == "pointcharge":
            dx, dy = x - o.x, y - o.y
            r2 = max(0.004, dx * dx + dy * dy)
            r = math.sqrt(r2)
            Ef = k * o.p.Q * 1e-9 / r2
            Ex += Ef * dx / r
            Ey += Ef * dy / r
            phi += k * o.p.Q * 1e-9 / r
        elif o.type == "plates":
            ln, d = o.p.len, o.p.d
            if abs(x - o.x) <= ln / 2 and abs(y - o.y) <= d / 2:
                Ef = o.p.U / d
                Ey += -Ef * o.p.pol
                phi += -Ef * (y - o.y) * o.p.pol
    return NS(Ex=Ex, Ey=Ey, phi=phi)
