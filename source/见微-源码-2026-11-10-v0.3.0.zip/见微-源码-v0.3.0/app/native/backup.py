"""Versioned byte-preserving backups. Called under an exclusive process lease.

No credentials are read. Restore swaps sibling directories with a recovery journal;
excluded paths move unchanged. All archive validation precedes touching live data.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import time
import uuid
import zipfile
import zlib
from pathlib import Path, PurePosixPath

FORMAT = 1
MAX_FILES = 100000
MAX_BYTES = 8 * 1024**3
MAX_MANIFEST = 16 * 1024**2
SKIP_DIRS = {'cache', 'caches', 'logs', 'backups', '__pycache__', '.git'}


class BackupError(Exception):
    pass


class DataLease:
    """Shared for all app/CLI writers, exclusive for maintenance. Outside data root."""
    def __init__(self, root, exclusive=False):
        root = Path(root).absolute()
        root.parent.mkdir(parents=True, exist_ok=True)
        self.file = open(root.parent / ('.'+root.name+'-data.lock'), 'a+b')
        if self.file.tell() == 0:
            self.file.write(b'0')
            self.file.flush()
        self.exclusive = exclusive

    def acquire(self, timeout=0):
        deadline = time.monotonic()+timeout
        while True:
            try:
                self.file.seek(0)
                if os.name == 'nt':
                    import ctypes
                    from ctypes import wintypes
                    import msvcrt
                    class Overlapped(ctypes.Structure):
                        _fields_ = [('Internal',ctypes.c_size_t),('InternalHigh',ctypes.c_size_t),('Offset',wintypes.DWORD),('OffsetHigh',wintypes.DWORD),('hEvent',wintypes.HANDLE)]
                    self._overlapped = Overlapped()
                    kernel = ctypes.WinDLL('kernel32',use_last_error=True)
                    lock = kernel.LockFileEx
                    lock.argtypes = [wintypes.HANDLE,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.POINTER(Overlapped)]
                    lock.restype = wintypes.BOOL
                    if not lock(msvcrt.get_osfhandle(self.file.fileno()),1 | (2 if self.exclusive else 0),0,1,0,ctypes.byref(self._overlapped)):
                        raise ctypes.WinError(ctypes.get_last_error())
                else:
                    import fcntl
                    fcntl.flock(self.file, (fcntl.LOCK_EX if self.exclusive else fcntl.LOCK_SH)|fcntl.LOCK_NB)
                return self
            except OSError:
                if time.monotonic() >= deadline:
                    self.close()
                    raise BackupError('数据仍在使用中。请正常关闭其他见微窗口或等待后台任务完成后重试。') from None
                time.sleep(.1)

    def close(self):
        self.file.close()

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *_):
        self.close()


def excluded(name):
    parts = PurePosixPath(name).parts
    return any(p.lower() in SKIP_DIRS or '.env' in p.lower() or p.lower().endswith(('.key','.pfx','.pem','.tmp','.lock')) for p in parts)


def safe_name(name):
    if not isinstance(name, str) or not name or len(name)>1000 or '\\' in name or ':' in name or re.search(r'[<>"|?*\x00-\x1f]',name):
        raise BackupError('备份文件路径无效')
    parts = PurePosixPath(name).parts
    if name.startswith('/') or '/'.join(parts) != name or any(p in ('.','..') or p.endswith((' ','.')) or re.fullmatch(r'(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',p) for p in parts):
        raise BackupError('备份含不安全的路径')
    return name


def _plain(path):
    s = path.lstat()
    if path.is_symlink() or getattr(s, 'st_file_attributes', 0) & 0x400:
        raise BackupError('数据含符号链接或目录联接，请移除链接后备份')
    return s


def inventory(root, include_excluded=False):
    result = []
    if not root.exists():
        return result
    _plain(root)
    def walk(folder):
        for p in sorted(folder.iterdir()):
            name = p.relative_to(root).as_posix()
            safe_name(name)
            # Do not even open excluded credential files.
            if excluded(name):
                if include_excluded:
                    _plain(p)
                    result.append(name)
                continue
            s = _plain(p)
            if stat.S_ISDIR(s.st_mode):
                walk(p)
            elif stat.S_ISREG(s.st_mode):
                result.append(name)
            else:
                raise BackupError('数据含不支持的文件类型')
    walk(root)
    return result


def _version(v):
    """版本号 → 可比较的四元组。

    2026-11-09 起改了命名：原来的 1.x / 2.x 改叫 0.1.x / 0.2.x（2.12.2 → 0.2.12.2），整合 OpenMAIC 后是 0.3.x。
    旧备份里记的还是 2.12.2 这样的老号，按 (0, 2, 12, 2) 比较，才不会被当成「比现在新」而拒绝恢复。
    """
    if not isinstance(v,str) or not re.fullmatch(r'\d+\.\d+\.\d+(\.\d+)?',v):
        raise BackupError('备份版本信息无效')
    parts = tuple(map(int,v.split('.')))
    if parts[0] in (1,2) and len(parts) == 3:   # 老命名
        return (0,)+parts
    return (parts+(0,0,0,0))[:4]


def _hash_stream(stream, output=None):
    digest = hashlib.sha256()
    size = 0
    while True:
        chunk = stream.read(1024*1024)
        if not chunk:
            break
        size += len(chunk)
        if size > MAX_BYTES:
            raise BackupError('备份数据超出容量限制')
        digest.update(chunk)
        if output:
            output.write(chunk)
    return size, digest.hexdigest()


def create(root, destination, version):
    root, destination = Path(root).absolute(), Path(destination).absolute()
    _version(version)
    if destination.resolve().is_relative_to(root.resolve()):
        raise BackupError('请选择数据目录以外的位置保存备份')
    if destination.exists():
        raise BackupError('目标文件已存在，请换一个文件名')
    names = inventory(root)
    if len(names)>MAX_FILES:
        raise BackupError('数据文件数量超出限制')
    destination.parent.mkdir(parents=True,exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.jianwei-backup-',suffix='.tmp',dir=destination.parent)
    os.close(fd)
    try:
        manifest = dict(format=FORMAT,app='Jianwei',app_version=version,created=time.time(),files=[])
        total = 0
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as archive:
            for name in names:
                p = root/name
                before = _plain(p)
                with p.open('rb') as source, archive.open('files/'+name,'w',force_zip64=True) as target:
                    size, sha = _hash_stream(source,target)
                after = _plain(p)
                if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                    raise BackupError('备份时数据发生变化，未生成备份，请稍后重试')
                total += size
                if total>MAX_BYTES:
                    raise BackupError('备份数据超过8 GiB限制')
                manifest['files'].append(dict(path=name,size=size,sha256=sha))
            if names != inventory(root):
                raise BackupError('备份时文件清单发生变化')
            raw = json.dumps(manifest,ensure_ascii=False,allow_nan=False).encode('utf-8')
            if len(raw)>MAX_MANIFEST:
                raise BackupError('备份清单过大')
            archive.writestr('manifest.json',raw)
        inspect(temporary,version)
        # Atomic no-overwrite publication on Windows; link also avoids TOCTOU elsewhere.
        os.link(temporary,destination)
        return manifest
    except (OSError,ValueError,zipfile.BadZipFile) as exc:
        raise BackupError('备份未完成，原数据未改动。请检查磁盘空间与文件权限。') from exc
    finally:
        Path(temporary).unlink(missing_ok=True)


def inspect(path, version, stage=None):
    """Validate every byte, optionally extracting only into a fresh staging directory."""
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries)>MAX_FILES+1 or sum(e.file_size for e in entries)>MAX_BYTES+MAX_MANIFEST:
                raise BackupError('备份超过文件数量或容量限制')
            names = [e.filename for e in entries]
            if len(set(n.casefold() for n in names))!=len(names):
                raise BackupError('备份含重复路径')
            for e in entries:
                safe_name(e.filename)
                mode = e.external_attr>>16
                if e.is_dir() or stat.S_IFMT(mode) not in (0,stat.S_IFREG) or e.flag_bits&1:
                    raise BackupError('备份含不支持的链接、目录或加密条目')
            info = archive.getinfo('manifest.json')
            if info.file_size>MAX_MANIFEST:
                raise BackupError('备份清单过大')
            manifest = json.loads(archive.read(info))
            if not isinstance(manifest,dict) or manifest.get('app')!='Jianwei' or type(manifest.get('format')) is not int or manifest['format']!=FORMAT:
                raise BackupError('备份格式不支持，请使用相应版本的见微')
            if _version(manifest.get('app_version'))>_version(version):
                raise BackupError('备份来自更高版本，请升级见微后恢复')
            files = manifest.get('files')
            if not isinstance(files,list) or len(files)>MAX_FILES:
                raise BackupError('备份文件清单无效')
            wanted = {'manifest.json'}
            for f in files:
                if not isinstance(f,dict):
                    raise BackupError('备份文件条目无效')
                name = safe_name(f.get('path'))
                member = 'files/'+name
                if excluded(name) or member in wanted or type(f.get('size')) is not int or f['size']<0 or not re.fullmatch(r'[a-f0-9]{64}',str(f.get('sha256'))):
                    raise BackupError('备份含排除项或无效条目')
                wanted.add(member)
                entry = archive.getinfo(member)
                if entry.file_size!=f['size']:
                    raise BackupError('备份文件大小不符')
                if stage:
                    target = stage/name
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with archive.open(entry) as src, target.open('xb') as dst:
                        size, sha = _hash_stream(src,dst)
                else:
                    with archive.open(entry) as src:
                        size, sha = _hash_stream(src)
                if (size,sha)!=(f['size'],f['sha256']):
                    raise BackupError('备份文件校验失败，未恢复')
            if set(names)!=wanted:
                raise BackupError('备份含未登记的文件')
            return manifest
    except BackupError:
        raise
    except (OSError,ValueError,KeyError,RuntimeError,TypeError,zipfile.BadZipFile,EOFError,zlib.error,RecursionError) as exc:
        raise BackupError('备份损坏、无法读取或磁盘空间不足，未恢复') from exc


def journal_path(root):
    return root.parent/('.'+root.name+'-restore.json')


def _atomic_json(path, data):
    tmp = path.with_suffix('.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        json.dump(data,f,ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp,path)


def _transaction_paths(root, token):
    if not re.fullmatch(r'[a-f0-9]{32}',str(token)):
        raise BackupError('恢复事务记录无效，请保留数据目录并联系维护者')
    parent = root.parent.resolve()
    stage = parent/('.'+root.name+'-restore-'+token)
    old = parent/('.'+root.name+'-previous-'+token)
    for p in (stage,old):
        if p.exists():
            _plain(p)
        if p.resolve().parent != parent:
            raise BackupError('恢复事务路径无效')
    return stage, old


def recover(root):
    """Roll back interrupted swaps before any app writer starts; safe to call again."""
    root = Path(root).absolute()
    if root.exists():
        _plain(root)
    journal = journal_path(root)
    if not journal.exists():
        return
    try:
        data = json.loads(journal.read_text(encoding='utf-8'))
        if data.get('v')!=1:
            raise BackupError('恢复事务版本不支持')
        stage,old = _transaction_paths(root,data.get('token'))
        preserved = data['preserved']
        if not isinstance(preserved,list) or any(not excluded(safe_name(n)) for n in preserved):
            raise BackupError('恢复事务排除项无效')
        if data.get('committed'):
            if not root.is_dir():
                raise BackupError('恢复提交记录与数据目录不符，请保留事务目录')
            journal.unlink()
            return
        if old.exists():
            source = root if root.exists() else stage
            for name in preserved:
                p = source/name
                if p.exists():
                    target = old/name
                    if target.exists():
                        raise BackupError('恢复回滚存在冲突，已保留全部目录，请联系维护者')
                    target.parent.mkdir(parents=True,exist_ok=True)
                    os.replace(p,target)
            if root.exists():
                if stage.exists():
                    raise BackupError('恢复回滚存在多个暂存目录，请联系维护者')
                os.replace(root,stage)
            os.replace(old,root)
        journal.unlink()
    except BackupError:
        raise
    except (OSError,ValueError,KeyError,TypeError) as exc:
        raise BackupError('恢复回滚未完成，请保留数据目录并重试') from exc


def restore(root, archive, version):
    root = Path(root).absolute()
    recover(root)
    manifest = inspect(archive,version)
    total = sum(f['size'] for f in manifest['files'])
    current_size = sum((root/n).stat().st_size for n in inventory(root))
    if shutil.disk_usage(root.parent).free < total+current_size+16*1024**2:
        raise BackupError('磁盘空间不足，尚未修改数据')
    token = uuid.uuid4().hex
    stage,old = _transaction_paths(root,token)
    stage.mkdir()
    try:
        inspect(archive,version,stage)
        backups = root.parent/(root.name+'-backups')
        before = backups/('恢复前-'+time.strftime('%Y%m%d-%H%M%S')+'-'+token[:8]+'.jwbackup')
        create(root,before,version)
        preserved = [n for n in inventory(root,True) if excluded(n)]
        record = dict(v=1,token=token,preserved=preserved,committed=False)
        _atomic_json(journal_path(root),record)
        if root.exists():
            os.replace(root,old)
        for name in preserved:
            target = stage/name
            target.parent.mkdir(parents=True,exist_ok=True)
            os.replace(old/name,target)
        os.replace(stage,root)
        record['committed'] = True
        _atomic_json(journal_path(root),record)
        journal_path(root).unlink()
        # Retain previous managed data as a second recovery copy; never auto-delete it.
        return dict(files=len(manifest['files']),before=str(before),previous=str(old))
    except BaseException:
        if journal_path(root).exists():
            recover(root)
        raise
    finally:
        if stage.exists():
            # Only our verified UUID staging directory, never a computed user path.
            _transaction_paths(root,token)
            shutil.rmtree(stage)
