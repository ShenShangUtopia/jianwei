"""Isolated maintenance tests: byte fidelity, validation, ENOSPC, rollback and locks."""
from .kit import test_runtime
test_runtime.configure()
import copy
import errno
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from unittest.mock import patch


def main(output=None):
    from . import backup as b
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    root=out/'data'
    root.mkdir(exist_ok=True)
    expected={
        'config.json': b'\xef\xbb\xbf{"unknown":7}',
        'stars.json':b'["p-1"]',
        'learning.json':b'{"v":1,"items":{},"events":[]}',
        'attempts.json':b'{"v":1,"items":[]}',
        'clips/abc/drawing.svg':b'<svg/>',
        'workbench-state/bio.json':b'{"v":1,"x":[1,2]}',
        'guanlan/data/history.json':b'{"read":[1]}',
        'lecture/book/source.pptx':bytes(range(256))*10,
        'unknown-extension/data.bin':b'\x00\xff\x01'}
    for name,raw in expected.items():
        p=root/name
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(raw)
    # Synthetic sentinel only. Never inspect real credential storage.
    (root/'deepseek.env').write_bytes(b'SYNTHETIC-SECRET-NOT-A-KEY')
    (root/'logs').mkdir(exist_ok=True)
    (root/'logs/test.log').write_bytes(b'keep-local')
    version='2.9.0'
    archive=out/'roundtrip.jwbackup'
    b.create(root,archive,version)
    # 改名：老号 2.x 等于新号 0.2.x，老备份在新版本里不能被当成「更新的版本」
    V=b._version
    assert V('1.7.0')<V('2.16.0')<V('0.2.17')<V('0.2.17.1')<V('0.3.0')<V('99.0.0') and V('2.12.2')==V('0.2.12.2')
    assert b.inspect(archive,'0.2.17')['app_version']=='2.9.0'
    with zipfile.ZipFile(archive) as z:
        assert not any('.env' in n or '/logs/' in n for n in z.namelist())
        assert b'SYNTHETIC-SECRET' not in b''.join(z.read(n) for n in z.namelist())
    def snapshot():
        return {p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
    def unchanged(operation):
        old=snapshot()
        try:
            operation()
        except (b.BackupError,OSError):
            pass
        else:
            raise AssertionError('Expected rejection')
        assert snapshot()==old
    # Emulate emptied managed data, retaining local excluded credentials and logs.
    for name in expected:
        (root/name).unlink()
    (root/'new-after-backup.json').write_bytes(b'new')
    result=b.restore(root,archive,version)
    assert all((root/n).read_bytes()==raw for n,raw in expected.items())
    assert not (root/'new-after-backup.json').exists()
    assert (root/'deepseek.env').read_bytes()==b'SYNTHETIC-SECRET-NOT-A-KEY'
    assert (root/'logs/test.log').read_bytes()==b'keep-local'
    assert Path(result['before']).exists()
    before=b.inspect(result['before'],version)
    assert any(f['path']=='new-after-backup.json' for f in before['files'])
    unchanged(lambda:b.create(root,archive,version))
    unchanged(lambda:b.create(root,root/'invalid.jwbackup',version))
    bad=out/'bad.jwbackup'
    bad.write_bytes(b'not zip')
    unchanged(lambda:b.restore(root,bad,version))
    with zipfile.ZipFile(archive) as z:
        members={n:z.read(n) for n in z.namelist()}
    def altered(name,edit):
        entries=copy.deepcopy(members)
        manifest=json.loads(entries['manifest.json'])
        edit(entries,manifest)
        entries['manifest.json']=json.dumps(manifest).encode()
        path=out/(name+'.jwbackup')
        with zipfile.ZipFile(path,'w') as z:
            for n,raw in entries.items():
                z.writestr(n,raw)
        return path
    for name,edit in [
        ('future',lambda e,m:m.update(app_version='99.0.0')),
        ('format',lambda e,m:m.update(format=99)),
        ('hash',lambda e,m:m['files'][0].update(sha256='0'*64)),
        ('traversal',lambda e,m:e.update({'files/../escape':b'bad'})),
        ('extra',lambda e,m:e.update({'unregistered':b'bad'})),
        ('credential',lambda e,m:m['files'][0].update(path='deepseek.env')),
        ('windows',lambda e,m:e.update({'files/NUL.txt':b'bad'}))]:
        bad=altered(name,edit)
        unchanged(lambda:b.restore(root,bad,version))
    with patch.object(b.shutil,'disk_usage',return_value=shutil._ntuple_diskusage(100,100,0)):
        unchanged(lambda:b.restore(root,archive,version))
    real_hash=b._hash_stream
    def no_space(stream,output=None):
        if output:
            raise OSError(errno.ENOSPC,'synthetic disk full')
        return real_hash(stream)
    with patch.object(b,'_hash_stream',side_effect=no_space):
        unchanged(lambda:b.create(root,out/'full.jwbackup',version))
        unchanged(lambda:b.restore(root,archive,version))
    assert not (out/'full.jwbackup').exists()
    # Inject failures at each destructive rename and check exact rollback.
    real_replace=os.replace
    for fail_index in range(1,5):
        count=[0]
        def replace(src,dst):
            # Ignore journal commits; fail one directory/file move exactly once.
            if str(src).endswith('-restore.tmp'):
                return real_replace(src,dst)
            count[0]+=1
            if count[0]==fail_index:
                raise OSError(errno.ENOSPC,'synthetic swap failure')
            return real_replace(src,dst)
        with patch.object(b.os,'replace',side_effect=replace):
            unchanged(lambda:b.restore(root,archive,version))
        assert not b.journal_path(root).exists()
    # Emulate an interrupted process after both swaps but before commit.
    token='a'*32
    stage,old=b._transaction_paths(root,token)
    os.replace(root,old)
    stage.mkdir()
    (stage/'stars.json').write_bytes(b'changed')
    os.replace(old/'deepseek.env',stage/'deepseek.env')
    os.replace(stage,root)
    b._atomic_json(b.journal_path(root),dict(v=1,token=token,preserved=['deepseek.env'],committed=False))
    b.recover(root)
    assert all((root/n).read_bytes()==raw for n,raw in expected.items())
    assert (root/'deepseek.env').read_bytes()==b'SYNTHETIC-SECRET-NOT-A-KEY'
    b.recover(root)
    with b.DataLease(root):
        with b.DataLease(root):
            try:
                b.DataLease(root,exclusive=True).acquire()
            except b.BackupError:
                pass
            else:
                raise AssertionError('Exclusive maintenance must reject active writers')
    with b.DataLease(root,exclusive=True):
        try:
            b.DataLease(root).acquire()
        except b.BackupError:
            pass
        else:
            raise AssertionError('Writer must reject active maintenance')
    if not getattr(sys,'frozen',False):
        script="from native.kit import test_runtime; test_runtime.configure(); from native.backup import DataLease; import sys; lease=DataLease(sys.argv[1]).acquire(); print('READY',flush=True); sys.stdin.readline(); lease.close()"
        child=subprocess.Popen([sys.executable,'-c',script,str(root)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,
                               cwd=Path(__file__).parents[1],creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        try:
            assert child.stdout.readline().strip()=='READY'
            with b.DataLease(root):
                try:
                    b.DataLease(root,exclusive=True).acquire()
                except b.BackupError:
                    pass
                else:
                    raise AssertionError('Cross-process writer not protected')
        finally:
            child.communicate('\n')  # orderly release, never terminate/kill
        assert child.returncode==0
    # Screenshot only functional additions, using existing styles.
    app=test_runtime.application()
    from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel
    from .backup_ui import controls
    from .design.widgets import qss
    widget=QWidget()
    widget.setObjectName('jw2')
    widget.setStyleSheet(qss())
    layout=QVBoxLayout(widget)
    layout.addWidget(QLabel('数据备份与恢复'))
    row=QHBoxLayout()
    controls(widget,row)
    layout.addLayout(row)
    layout.addWidget(QLabel('正常退出后操作，避免写入冲突。恢复前自动备份；密钥不打包。'))
    widget.resize(700,170)
    widget.show()
    app.processEvents()
    widget.grab().save(str(out/'backup-controls.png'))
    widget.close()
    report=dict(result='OK',managed_files=len(expected),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),real_user_data=False,checks=['byte-roundtrip','credentials-excluded-preserved','auto-backup','bad-zip','future-version','hash','paths','disk-full','rename-rollback','crash-recovery','leases'])
    (out/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('BACKUP OK roundtrip, validation, ENOSPC, rollback, crash recovery, leases; temporary data only',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
