"""Classroom UI contracts: fake service only, no server, browser, network or real keys."""
import os
from pathlib import Path
import sys
import threading
import time

from ..kit import test_runtime

test_runtime.configure()


def main(target):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    os.environ.setdefault('QT_QPA_FONTDIR',r'C:\Windows\Fonts')
    app = test_runtime.application([])
    from PySide6.QtCore import QCoreApplication, QEvent
    from PySide6.QtGui import QShortcut
    from PySide6.QtWidgets import QPushButton
    from .fake_service import FakeService
    from .page import ClassroomPage
    from .window import ClassroomWindow, edge_arguments, find_edge, checked_url
    from ..design import tokens
    from ..main_win import NativeWindow, MODES
    from ..kit.quick_open import SHORTCUTS
    out = Path(target)
    out.mkdir(parents=True,exist_ok=True)
    runtime = out/'runtime'
    runtime.mkdir(exist_ok=True)
    (runtime/'LICENSE').write_text('MIT license test fixture',encoding='utf-8')
    checks = []
    def check(name, condition):
        assert condition,name
        checks.append(name)
    def spin():
        for _ in range(4):
            app.processEvents()
            time.sleep(.005)
    class Launcher:
        def __init__(self):self.opens=[];self.stops=0
        def open(self,url):self.opens.append(url);return '课堂窗口已打开'
        def shutdown(self):self.stops+=1
    service = FakeService(runtime)
    launcher = Launcher()
    page = ClassroomPage(service=service,launcher=launcher)
    page.resize(1000,700)
    page.show()
    states = (
        ('stopped',True,'启动课堂',True),('starting',True,'正在启动…',False),
        ('ready',True,'打开课堂',True),('error',True,'重试',True),
        ('absent',True,'启动课堂',False),('stopped',False,'先设置 DeepSeek 密钥',True),
        ('stopping',True,'正在关闭…',False))
    for theme in ('day','night'):
        tokens.set_theme(theme)
        page.apply_theme()
        for state,key,text,enabled in states:
            service.emit(state=state,key_ok=key,message='这个版本没有课堂组件。' if state=='absent' else
                '初始化数据库可能需要一些时间。' if state=='starting' else '课堂测试状态说明。',
                rss_mb=512 if state=='ready' else 0,url='http://127.0.0.1:18765' if state=='ready' else '')
            spin()
            name=state if key else 'missing-key'
            if state=='absent':
                check(theme+' absent controls hidden',page.primary.isHidden() and page.stop_button.isHidden())
            else:
                check(theme+' '+name+' action',page.primary.text()==text and page.primary.isEnabled()==enabled)
            check(theme+' '+name+' progress',page.progress.isVisible()==(state in ('starting','stopping')))
            check(theme+' '+name+' stop',page.stop_button.isEnabled()==(state=='ready'))
            check(theme+' '+name+' memory',('512' in page.memory.text())==(state=='ready'))
            check(theme+' '+name+' no overflow',page.primary.geometry().right()<page.card.width())
            page.grab().save(str(out/(theme+'-'+name+'.png')))
    worker=threading.Thread(target=lambda:service.emit(state='ready',key_ok=True,
        message='来自后台线程的状态',url='http://127.0.0.1:18765',rss_mb=621))
    worker.start();worker.join()
    spin()
    check('thread delivery',page.message.text()=='来自后台线程的状态' and '621' in page.memory.text())
    service.emit(state='stopped');spin()
    page.primary.click();spin()
    check('asynchronous start',service.starts==1 and not page.primary.isEnabled())
    service.emit(state='ready',url='http://127.0.0.1:18765');spin()
    check('open when ready',launcher.opens==['http://127.0.0.1:18765/'])
    # Losing the key during startup must not open a browser on a late ready event.
    service.emit(state='stopped');spin()
    page.primary.click();spin()
    count=len(launcher.opens)
    service.emit(state='ready',key_ok=False,url='http://127.0.0.1:18765');spin()
    check('missing key blocks delayed open',len(launcher.opens)==count)
    service.emit(key_ok=True);spin()
    saved_clipboard=app.clipboard().text()
    try:
        page.make_lesson('原题：平抛运动，初速度 10 m/s')
        check('copy original question',app.clipboard().text().startswith('原题：平抛') and '题目已复制' in page.notice.text())
    finally:
        app.clipboard().setText(saved_clipboard)
    page.stop_button.click();spin()
    check('stop action',service.stops==1 and not page.pending_open)
    runtime.joinpath('LICENSE').unlink()
    page.refresh()
    check('missing license hidden',page.license.isHidden())
    old_callbacks=list(service.subs)
    page.shutdown();page.shutdown()
    check('unsubscribe and idempotent cleanup',not service.subs and launcher.stops==1)
    page.deleteLater()
    QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
    for callback in old_callbacks:callback(service.status())
    spin()  # A callback already in flight must not touch a deleted Qt object.

    executable='C:/Program Files/Microsoft/Edge/Application/msedge.exe'
    check('registry Edge preferred',find_edge({},lambda:executable,lambda p:str(p)==str(Path(executable)))==executable)
    candidate=Path('C:/Programs')/'Microsoft/Edge/Application/msedge.exe'
    check('Edge install fallback',find_edge({'ProgramFiles':'C:/Programs'},lambda:'',lambda p:p==candidate)==str(candidate))
    check('Edge missing',find_edge({},lambda:'',lambda p:False)=='')
    args=edge_arguments(executable,'http://127.0.0.1:18765/',out)
    check('private profile and limits','--user-data-dir='+str(out.resolve()/'classroom-edge') in args and
          '--renderer-process-limit=3' in args and '--app=http://127.0.0.1:18765/' in args)
    for bad in ('https://example.com/','file:///x','http://127.0.0.1/','http://evil@127.0.0.1:12/'):
        try:checked_url(bad)
        except ValueError:pass
        else:raise AssertionError('non-local URL accepted')
    class Process:
        code=None
        def poll(self):return self.code
    process=Process()
    spawned=[]
    clock=[0]
    window_service=FakeService()
    def spawn(args,**kwargs):spawned.append(args);return process
    window=ClassroomWindow(window_service,finder=lambda:executable,spawn=spawn,clock=lambda:clock[0])
    window.open('http://127.0.0.1:18765/')
    window.open('http://127.0.0.1:18765/')
    check('no duplicate browser',len(spawned)==1)
    clock[0]=61;window._tick()
    check('heartbeat while alive',window_service.touches==3)
    process.code=0;clock[0]=122;window._tick()
    check('closed window no heartbeat',window_service.touches==3 and not window.timer.isActive())
    window.shutdown();window.shutdown()
    check('stop without killing browser',window_service.stops==1)
    guarded=ClassroomWindow(window_service)
    try:guarded.open('http://127.0.0.1:18765/')
    except OSError:pass
    else:raise AssertionError('selftest could start a real browser')
    guarded.shutdown();guarded.deleteLater()
    check('real browser blocked in tests',True)
    browser=[]
    fallback=ClassroomWindow(window_service,finder=lambda:'',browser=lambda url:browser.append(url.toString()) or True)
    fallback.open('http://127.0.0.1:18765/')
    check('default browser fallback',len(browser)==1 and not fallback.timer.isActive())
    fallback.shutdown()
    fallback.deleteLater();window.deleteLater()

    native_service=FakeService(runtime)
    native_launcher=Launcher()
    native=NativeWindow(classroom_service=native_service,classroom_launcher=native_launcher)
    check('sixth lazy mode',MODES[-1]==('classroom','课堂') and 'classroom' not in native.pages)
    shortcut=next(s for s in native.findChildren(QShortcut) if s.key().toString()=='Ctrl+6')
    shortcut.activated.emit()
    check('Ctrl6 loads classroom',native.mode=='classroom' and isinstance(native.pages['classroom'],ClassroomPage))
    native.resize(1000,620)
    native.show()
    for theme in ('day','night'):
        native.set_theme(theme)
        spin()
        check(theme+' narrow rail classroom visible',native.btns['classroom'].isVisible() and
              native.rail.rect().contains(native.btns['classroom'].geometry().center()))
        native.grab().save(str(out/('native-classroom-'+theme+'.png')))

    check('quick open help','课堂' in str(SHORTCUTS) and 'Ctrl+1 … 6' in str(SHORTCUTS))
    analysis=native.goto('analysis')
    edits=[]
    analysis.edit_key=lambda:edits.append(True)
    native_service.emit(state='stopped',key_ok=False);spin()
    classroom=native.goto('classroom')
    classroom.primary.click();spin()
    check('key settings navigation',native.mode=='analysis' and edits==[True])
    native_service.emit(state='ready',key_ok=True,url='http://127.0.0.1:18765');spin()
    analysis.L=dict(problem='原题内容',answer='10 m',topic='平抛',subject='物理',steps=[])
    analysis._fill_answer(analysis.L)
    button=next(b for b in analysis.answer_card.findChildren(QPushButton) if b.text()=='做成一堂课')
    saved_clipboard=app.clipboard().text()
    try:
        button.click();spin()
        check('analysis to classroom',native.mode=='classroom' and app.clipboard().text()=='原题内容')
    finally:
        app.clipboard().setText(saved_clipboard)
    native.shutdown();native.close();native.deleteLater()
    spin()
    (out/'result.txt').write_text('OK\n'+str(len(checks))+' checks; no browser/server/network/real keys',encoding='utf-8')
    print('CLASSROOM_UI OK',len(checks),'checks; fake service only; no real Edge/runtime verification',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(lambda:main(sys.argv[1])))
