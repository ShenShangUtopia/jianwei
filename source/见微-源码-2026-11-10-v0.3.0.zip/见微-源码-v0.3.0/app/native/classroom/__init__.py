"""课堂：本机运行的 OpenMAIC 互动课堂（服务见 service.py，页面见 page.py）。"""
