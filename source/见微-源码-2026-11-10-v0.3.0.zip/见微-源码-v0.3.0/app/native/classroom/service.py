"""课堂服务：在本机跑 OpenMAIC（清华 THU-MAIC 开源的多智能体互动课堂，MIT 许可）。

组成（绿色版里放在 Jianwei.exe 旁边的 classroom\\ 目录，开发时用 F:\\space for Claude\\openmaic\\runtime-dist）：
    node\\node.exe        Node.js 运行时
    pg\\bin|lib|share     便携 PostgreSQL 16（只取运行需要的部分）
    server\\server.js     OpenMAIC 的 Next.js standalone 产物
    LICENSE              OpenMAIC 的 MIT 许可

数据放在见微数据目录下的 classroom\\：pgdata（数据库）、secret.json（数据库口令、会话密钥）、logs、openmaic.yml（按见微设置生成）。

为了在 4GB 内存的电脑上能用：
- 只在用到时启动；10 分钟没人用（页面没 touch）自动关。
- PostgreSQL 用小内存设置（shared_buffers 24MB、最多 20 个连接）。
- Node 限制堆内存（--max-old-space-size），关掉视频、生图、沙箱这些吃资源的功能。
- 只听 127.0.0.1，单用户模式。

密钥只从见微自己的 deepseek.env 读，传给子进程的环境变量；不写进日志、不写进任何文件。

接口（课堂页只用这些，见 PROMPT-课堂页-给GPT.md）：
    available() status() start() stop() touch() subscribe(fn) url(path) runtime_dir()
"""
from __future__ import annotations

import ctypes
import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from ctypes import wintypes
from pathlib import Path

STATES = ("absent", "stopped", "starting", "ready", "stopping", "error")
IDLE_SECONDS = 600
NODE_HEAP_MB = 640
NO_WINDOW = 0x08000000           # CREATE_NO_WINDOW
NEW_GROUP = 0x00000200           # CREATE_NEW_PROCESS_GROUP（关服务时能发 Ctrl+Break 让它自己退出）
PG_CONF = """
# ---- 见微课堂：给 4GB 内存的电脑用的小内存设置 ----
listen_addresses = '127.0.0.1'
port = {port}
max_connections = 20
shared_buffers = 24MB
work_mem = 2MB
maintenance_work_mem = 16MB
effective_cache_size = 128MB
wal_buffers = 1MB
max_wal_size = 256MB
logging_collector = on
log_directory = 'log'
log_filename = 'pg-%a.log'
log_truncate_on_rotation = on
timezone = 'Asia/Shanghai'
log_timezone = 'Asia/Shanghai'
"""


# ---------------------------------------------------------------- 路径
def runtime_dir() -> Path:
    env = os.environ.get("JIANWEI_CLASSROOM_RUNTIME")
    if env:
        return Path(env)
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "classroom"
    return Path(__file__).resolve().parents[5] / "openmaic" / "runtime-dist"


def data_dir() -> Path:
    from ..kit.home import home
    p = home() / "classroom"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _exe(*parts) -> Path:
    return runtime_dir().joinpath(*parts)


def available() -> bool:
    return all(p.is_file() for p in (_exe("node", "node.exe"), _exe("pg", "bin", "postgres.exe"), _exe("server", "server.js")))


# ---------------------------------------------------------------- 状态
class _State:
    def __init__(self):
        self.lock = threading.RLock()
        self.state = "stopped"
        self.message = ""
        self.port = 0
        self.pg_port = 0
        self.node = None          # subprocess.Popen
        self.pg = None            # subprocess.Popen（postmaster）
        self.last_touch = 0.0
        self.subs = []
        self.worker = None
        self.idle = None


S = _State()


def _key():
    """见微设置的 DeepSeek 密钥；没有返回 ""。"""
    try:
        from ..analysis.llm import settings
        return (settings().get("key") or "").strip()
    except Exception:  # noqa: BLE001
        return ""


def status() -> dict:
    with S.lock:
        state = S.state if available() else "absent"
        return dict(state=state, message=S.message if available() else "这个版本没有带课堂组件。",
                    url=f"http://127.0.0.1:{S.port}" if state == "ready" else "",
                    rss_mb=_rss_mb() if state in ("ready", "starting", "stopping") else 0,
                    key_ok=bool(_key()))


def _set(state, message=""):
    with S.lock:
        S.state, S.message = state, message
        subs = list(S.subs)
    st = status()
    for fn in subs:
        try:
            fn(st)
        except Exception:  # noqa: BLE001  订阅者出错不影响服务
            pass
    _log(f"[{state}] {message}")


def subscribe(fn):
    with S.lock:
        S.subs.append(fn)

    def cancel():
        with S.lock:
            if fn in S.subs:
                S.subs.remove(fn)
    return cancel


def url(path: str = "") -> str:
    with S.lock:
        if S.state != "ready":
            return ""
        return f"http://127.0.0.1:{S.port}" + (path if path.startswith("/") else "/" + path if path else "/")


def touch() -> None:
    S.last_touch = time.time()


# ---------------------------------------------------------------- 日志
def _log(line):
    try:
        d = data_dir() / "logs"
        d.mkdir(exist_ok=True)
        with (d / "service.log").open("a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + line + "\n")
    except OSError:
        pass


# ---------------------------------------------------------------- 启动
def start() -> None:
    with S.lock:
        if S.state in ("starting", "ready") or not available():
            return
        if not _key():
            _set("error", "还没有设置 DeepSeek 密钥。")
            return
        S.last_touch = time.time()
        S.state = "starting"
        S.worker = threading.Thread(target=_start_worker, name="classroom-start", daemon=True)
        S.worker.start()


def _start_worker():
    try:
        sec = _secrets()
        _set("starting", "正在启动数据库…")
        _start_pg(sec)
        _set("starting", "正在启动课堂服务…")
        _start_node(sec)
        _set("ready", "课堂已就绪。")
        _ensure_idle_watch()
    except Exception as e:  # noqa: BLE001
        _log("start failed: " + repr(e))
        _shutdown()
        _set("error", f"课堂没能启动：{e}")


def _secrets():
    """数据库口令和会话密钥：第一次生成，之后一直用同一份。"""
    p = data_dir() / "secret.json"
    try:
        sec = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        sec = {}
    changed = False
    for k, n in (("db_password", 24), ("app_secret", 32)):
        if not sec.get(k):
            sec[k] = secrets.token_hex(n)
            changed = True
    if changed:
        p.write_text(json.dumps(sec), encoding="utf-8")
    return sec


def _free_port(prefer):
    for port in (prefer, 0):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", port))
                return s.getsockname()[1]
            except OSError:
                continue
    raise RuntimeError("找不到可用端口")


def _run(args, timeout=120, env=None):
    r = subprocess.run([str(a) for a in args], capture_output=True, text=True, encoding="utf-8", errors="replace",
                       timeout=timeout, creationflags=NO_WINDOW, env=env)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def _ascii(p: Path) -> Path:
    """PostgreSQL 在 Windows 上打不开含中文的路径（用户名是中文时数据目录就在这种路径下）。
    先用 8.3 短路径；系统没开短名时返回 None，由调用方换到纯英文目录。"""
    s = str(p)
    if s.isascii():
        return p
    p.mkdir(parents=True, exist_ok=True) if not p.suffix else None
    buf = ctypes.create_unicode_buffer(32768)
    n = ctypes.windll.kernel32.GetShortPathNameW(s, buf, len(buf))
    return Path(buf.value) if n and buf.value.isascii() else None


def pg_bin() -> Path:
    b = _ascii(_exe("pg", "bin"))
    if b is None:
        raise RuntimeError("见微所在的文件夹路径里有中文且系统没开短文件名，数据库启动不了：请把见微放到纯英文路径下")
    return b


def pg_data() -> Path:
    """数据库目录：通常在见微数据目录下；路径转不成纯英文时放到 %PUBLIC%\\Jianwei\\pg-<用户标识>。"""
    d = _ascii(data_dir() / "pgdata")
    if d is not None:
        return d
    import hashlib
    tag = hashlib.sha1(str(data_dir()).encode("utf-8")).hexdigest()[:10]
    base = Path(os.environ.get("PUBLIC") or r"C:\Users\Public") / "Jianwei" / f"pg-{tag}"
    if not str(base).isascii():
        raise RuntimeError("找不到纯英文路径存放课堂数据库")
    return base


def _start_pg(sec):
    bin_ = pg_bin()
    data = pg_data()
    S.pg_port = _free_port(54329)
    if not (data / "PG_VERSION").is_file():
        _set("starting", "第一次使用：正在建数据库（约半分钟）…")
        data.mkdir(parents=True, exist_ok=True)
        pw = data.parent / "pw.tmp"     # initdb 要求数据目录是空的
        pw.write_text(sec["db_password"], encoding="ascii")
        try:
            code, out = _run([bin_ / "initdb.exe", "-D", data, "-U", "openmaic", f"--pwfile={pw}", "-A", "scram-sha-256", "-E", "UTF8", "--locale=C"], timeout=600)
        finally:
            pw.unlink(missing_ok=True)
        if code:
            raise RuntimeError("建数据库失败：" + out.strip().splitlines()[-1] if out.strip() else "建数据库失败")
    conf = data / "postgresql.auto.conf"
    # 端口每次可能不同：写进 auto.conf（PostgreSQL 自己管这个文件，后写的覆盖前面的）
    body = PG_CONF.format(port=S.pg_port)
    conf.write_text("# 由见微课堂生成，每次启动重写\n" + body, encoding="utf-8")
    (data / "postmaster.pid").exists() and _stale_pid(data)
    log = (data_dir() / "logs")
    log.mkdir(exist_ok=True)
    S.pg = subprocess.Popen([str(bin_ / "postgres.exe"), "-D", str(data)], creationflags=NO_WINDOW,
                            stdout=subprocess.DEVNULL, stderr=open(log / "postgres-boot.log", "w", encoding="utf-8"))
    deadline = time.time() + 120
    env = dict(os.environ, PGPASSWORD=sec["db_password"], PGCONNECT_TIMEOUT="30")
    while time.time() < deadline:
        if S.pg.poll() is not None:
            raise RuntimeError("数据库进程退出了，见 logs\\postgres-boot.log")
        code, _ = _run([bin_ / "pg_isready.exe", "-h", "127.0.0.1", "-p", S.pg_port, "-U", "openmaic"], timeout=30, env=env)
        if code == 0:
            break
        time.sleep(0.5)
    else:
        raise RuntimeError("数据库两分钟内没有就绪")
    code, out = _run([bin_ / "psql.exe", "-h", "127.0.0.1", "-p", S.pg_port, "-U", "openmaic", "-d", "postgres", "-tAc",
                      "SELECT 1 FROM pg_database WHERE datname='openmaic'"], timeout=90, env=env)
    if code:
        raise RuntimeError("连不上数据库")
    if out.strip() != "1":
        code, out = _run([bin_ / "psql.exe", "-h", "127.0.0.1", "-p", S.pg_port, "-U", "openmaic", "-d", "postgres", "-c", "CREATE DATABASE openmaic"], timeout=90, env=env)
        if code:
            raise RuntimeError("建库失败")


def _stale_pid(data):
    """上次没正常关（断电、见微崩溃）留下的 postmaster.pid：对应进程不在了就删掉，在的话交给 PostgreSQL 自己判断。"""
    try:
        pid = int((data / "postmaster.pid").read_text(encoding="ascii").splitlines()[0])
    except (OSError, ValueError, IndexError):
        return
    if not _alive(pid):
        (data / "postmaster.pid").unlink(missing_ok=True)


def _config(sec):
    """按见微设置生成 openmaic.yml：只接 DeepSeek，关掉视频 / 生图 / 沙箱这些吃资源或要另外付费的功能。"""
    p = data_dir() / "openmaic.yml"
    p.write_text("""# 由见微课堂生成，每次启动重写；改了也会被覆盖。
providers:
  deepseek:
    preset: deepseek
    apiKey: ${DEEPSEEK_API_KEY}
    models: [deepseek-flash, deepseek-v4-pro]
  voice:
    preset: browser-native-tts
  ears:
    preset: browser-native
slots:
  llm: deepseek:deepseek-flash
  tts: voice
  asr: ears
  video: null
  image: null
lock: [video, image]
allowUserKeys: true
""", encoding="utf-8")
    return p


def _fake_ip(host):
    try:
        addrs = {a[4][0] for a in socket.getaddrinfo(host, 443, socket.AF_INET)}
    except OSError:
        return False
    return any(a.startswith(("198.18.", "198.19.")) for a in addrs)


def fix_links(srv: Path) -> int:
    """按 server\\links.json 重建 node_modules 的目录链接（junction）。

    OpenMAIC 用 pnpm，依赖靠目录链接串起来；junction 只能存绝对路径，见微被挪到别处后会失效，
    所以每次启动前按当前位置核对一遍。返回新建的数量。"""
    manifest = srv / "links.json"
    if not manifest.is_file():
        return 0
    import _winapi
    made = 0
    for link, target in json.loads(manifest.read_text(encoding="utf-8")):
        lp, tp = srv / link, srv / target
        if lp.is_junction():
            if os.path.realpath(lp) == os.path.realpath(tp):
                continue
            os.rmdir(lp)          # 只删链接本身，不碰目标
        elif lp.exists():
            continue
        lp.parent.mkdir(parents=True, exist_ok=True)
        _winapi.CreateJunction(str(tp), str(lp))
        made += 1
    return made


def _start_node(sec):
    S.port = _free_port(38765)
    srv = _exe("server")
    fix_links(srv)
    env = {k: v for k, v in os.environ.items() if not k.upper().endswith(("_API_KEY", "PROXY")) and k.upper() not in ("NODE_OPTIONS",)}
    env.update(
        PORT=str(S.port), HOSTNAME="127.0.0.1", NODE_ENV="production", NEXT_TELEMETRY_DISABLED="1",
        NODE_OPTIONS=f"--max-old-space-size={NODE_HEAP_MB}",
        DATABASE_URL=f"postgres://openmaic:{sec['db_password']}@127.0.0.1:{S.pg_port}/openmaic",
        OPENMAIC_CONFIG=str(_config(sec)), OPENMAIC_SECRET_KEY=sec["app_secret"],
        OWNER_SINGLE_USER="true", DEEPSEEK_API_KEY=_key(),
        # 4GB 机器：同一时间只跑一件生成任务，材料解析也一次一个
        OPENMAIC_GENERATION_RUN_MAX_CONCURRENT="1", OPENMAIC_AGENT_RUNTIME_MAX_CONCURRENT="1",
        OPENMAIC_MAX_ACTIVE_RUNS_PER_OWNER="1", OPENMAIC_MATERIAL_EXTRACTION_CONCURRENCY="1",
        OPENMAIC_MATERIAL_EXTRACTION_PER_OWNER="1", PARALLEL_SCENE_CONCURRENCY="0",
        # 朗读用浏览器（Edge）自带的语音，不另外付费
        TTS_BROWSER_NATIVE_ENABLED="true",
    )
    if _fake_ip("api.deepseek.com"):
        # Clash 之类的 fake-ip 代理会把 api.deepseek.com 解析成 198.18.x.x，OpenMAIC 的地址检查会把它当内网拦掉
        env["ALLOW_LOCAL_NETWORKS"] = "true"
    log = data_dir() / "logs"
    out = open(log / "server.log", "w", encoding="utf-8")
    S.node = subprocess.Popen([str(_exe("node", "node.exe")), "server.js"], cwd=str(srv), env=env,
                              creationflags=NO_WINDOW | NEW_GROUP, stdout=out, stderr=subprocess.STDOUT)
    deadline = time.time() + 180
    while time.time() < deadline:
        if S.node.poll() is not None:
            raise RuntimeError("课堂服务退出了，见 logs\\server.log")
        try:
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(f"http://127.0.0.1:{S.port}/", timeout=5) as r:
                if r.status < 500:
                    return
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.7)
    raise RuntimeError("课堂服务三分钟内没有就绪")


# ---------------------------------------------------------------- 关闭
def stop() -> None:
    with S.lock:
        if S.state in ("stopped", "stopping") or (S.node is None and S.pg is None):
            if S.state != "stopping":
                S.state = "stopped"
            return
        S.state = "stopping"
    threading.Thread(target=lambda: (_shutdown(), _set("stopped", "课堂服务已关闭。")), name="classroom-stop", daemon=True).start()


def stop_and_wait(timeout=8.0) -> None:
    """见微退出时用：同步关，最多等 timeout 秒。"""
    t = threading.Thread(target=_shutdown, daemon=True)
    t.start()
    t.join(timeout)
    with S.lock:
        S.state = "stopped"


def _shutdown():
    node, pg = S.node, S.pg
    S.node = S.pg = None
    if node is not None and node.poll() is None:
        try:   # 先让 Node 自己退（Ctrl+Break）；它是我们自己起的子进程，等不到再结束它
            os.kill(node.pid, getattr(__import__("signal"), "CTRL_BREAK_EVENT", 1))
            node.wait(6)
        except Exception:  # noqa: BLE001
            try:
                node.terminate()
                node.wait(3)
            except Exception:  # noqa: BLE001
                pass
    if pg is not None and pg.poll() is None:
        code, _ = _run([pg_bin() / "pg_ctl.exe", "-D", pg_data(),"-m", "fast", "-w", "-t", "20", "stop"], timeout=30)
        if code:
            try:
                pg.wait(5)
            except Exception:  # noqa: BLE001
                pass


def _ensure_idle_watch():
    if S.idle and S.idle.is_alive():
        return

    def watch():
        while True:
            time.sleep(15)
            with S.lock:
                if S.state != "ready":
                    return
                idle = time.time() - S.last_touch
            if idle > IDLE_SECONDS:
                _log(f"idle {int(idle)}s, stopping")
                stop()
                return
    S.idle = threading.Thread(target=watch, name="classroom-idle", daemon=True)
    S.idle.start()


# ---------------------------------------------------------------- 内存（不依赖 psutil）
class _PE(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD),
                ("szExeFile", ctypes.c_wchar * 260)]


class _PMC(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD), ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t), ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


def _children_map():
    k32 = ctypes.windll.kernel32
    snap = k32.CreateToolhelp32Snapshot(0x2, 0)
    kids = {}
    try:
        e = _PE()
        e.dwSize = ctypes.sizeof(_PE)
        ok = k32.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            kids.setdefault(e.th32ParentProcessID, []).append(e.th32ProcessID)
            ok = k32.Process32NextW(snap, ctypes.byref(e))
    finally:
        k32.CloseHandle(snap)
    return kids


def _ws_mb(pid):
    k32, psapi = ctypes.windll.kernel32, ctypes.windll.psapi
    h = k32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return 0.0
    try:
        c = _PMC()
        c.cb = ctypes.sizeof(_PMC)
        if psapi.GetProcessMemoryInfo(h, ctypes.byref(c), c.cb):
            return c.WorkingSetSize / 1048576
        return 0.0
    finally:
        k32.CloseHandle(h)


def _alive(pid):
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, pid)
    if not h:
        return False
    try:
        code = wintypes.DWORD()
        return bool(k32.GetExitCodeProcess(h, ctypes.byref(code))) and code.value == 259   # STILL_ACTIVE
    finally:
        k32.CloseHandle(h)


def tree_pids():
    roots = [p.pid for p in (S.node, S.pg) if p is not None and p.poll() is None]
    if not roots:
        return []
    kids, seen, todo = _children_map(), [], list(roots)
    while todo:
        pid = todo.pop()
        if pid in seen:
            continue
        seen.append(pid)
        todo.extend(kids.get(pid, []))
    return seen


def _rss_mb() -> int:
    try:
        return int(sum(_ws_mb(p) for p in tree_pids()))
    except Exception:  # noqa: BLE001
        return 0
