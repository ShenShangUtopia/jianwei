"""Manually driven classroom service for UI tests; never reads keys or starts servers."""
from pathlib import Path
import threading

STATES = ('absent', 'stopped', 'starting', 'ready', 'stopping', 'error')


class FakeService:
    def __init__(self, runtime=None):
        self.snapshot = dict(state='stopped',message='课堂在使用时启动，空闲后自动关闭。',
                             url='',rss_mb=0,key_ok=True)
        self.runtime = Path(runtime or '.')
        self.subs = []
        self.lock = threading.RLock()
        self.starts = self.stops = self.touches = 0

    def available(self):
        return self.snapshot['state'] != 'absent'

    def runtime_dir(self):
        return self.runtime

    def status(self):
        with self.lock:
            return dict(self.snapshot)

    def emit(self, **values):
        with self.lock:
            self.snapshot.update(values)
            if self.snapshot['state'] != 'ready':
                self.snapshot['url'] = ''
            snapshot, callbacks = dict(self.snapshot), list(self.subs)
        for fn in callbacks:
            fn(dict(snapshot))

    def subscribe(self, fn):
        with self.lock:
            self.subs.append(fn)
        def cancel():
            with self.lock:
                if fn in self.subs:
                    self.subs.remove(fn)
        return cancel

    def start(self):
        self.starts += 1
        self.emit(state='starting',message='正在初始化课堂，请稍候…')

    def stop(self):
        self.stops += 1
        self.emit(state='stopped',message='课堂服务已关闭。')

    def touch(self):
        self.touches += 1

    def url(self, path=''):
        base = self.snapshot['url']
        return base.rstrip('/') + '/' + path.lstrip('/') if self.snapshot['state']=='ready' and base else ''


_default = FakeService()
available = _default.available
runtime_dir = _default.runtime_dir
status = _default.status
subscribe = _default.subscribe
start = _default.start
stop = _default.stop
touch = _default.touch
url = _default.url
