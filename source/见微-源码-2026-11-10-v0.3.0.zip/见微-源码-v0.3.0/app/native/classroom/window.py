"""Independent classroom app window; never embed or terminate a browser."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time
from urllib.parse import urlsplit

from PySide6.QtCore import QObject, QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QApplication


def registry_edge():
    if os.name != 'nt':
        return ''
    import winreg
    for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                    r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
                    0, winreg.KEY_READ | view) as key:
                return str(winreg.QueryValue(key, None)).strip('"')
        except OSError:
            continue
    return ''


def find_edge(env=None, registry=None, exists=None):
    env = os.environ if env is None else env
    exists = Path.is_file if exists is None else exists
    candidates = [(registry or registry_edge)()]
    for name in ('ProgramFiles(x86)', 'ProgramFiles'):
        if env.get(name):
            candidates.append(str(Path(env[name]) / 'Microsoft/Edge/Application/msedge.exe'))
    return next((str(p) for p in candidates if p and exists(Path(p))), '')


def checked_url(url):
    parsed = urlsplit(str(url))
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1' or
            parsed.username or parsed.password or not parsed.port):
        raise ValueError('课堂尚未提供有效的本机地址')
    return str(url)


def edge_arguments(executable, url, data_home):
    return [str(executable), '--app=' + checked_url(url),
            '--user-data-dir=' + str(Path(data_home).resolve() / 'classroom-edge'),
            '--no-first-run', '--no-default-browser-check',
            '--disable-features=Translate,msEdgeSidebarV2',
            '--renderer-process-limit=3', '--window-size=1400,900']


class ClassroomWindow(QObject):
    def __init__(self, service, parent=None, finder=None, spawn=None, browser=None, clock=None):
        super().__init__(parent)
        self.service = service
        self.real_browser = spawn is None and browser is None
        self.finder = finder or find_edge
        self.spawn = spawn or subprocess.Popen
        self.browser = browser or QDesktopServices.openUrl
        self.clock = clock or time.monotonic
        self.process = None
        self.last_touch = 0
        self.stopped = False
        self.timer = QTimer(self)
        self.timer.setInterval(2000)
        self.timer.timeout.connect(self._tick)
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self.shutdown)

    def running(self):
        return self.process is not None and self.process.poll() is None

    def open(self, url):
        if self.real_browser and os.environ.get('JIANWEI_SELFTEST')=='1':
            raise OSError('自测中不打开真实浏览器')
        url = checked_url(url)
        if self.running():
            self.service.touch()
            return '课堂窗口已打开'
        self.stopped = False
        executable = self.finder()
        if not executable:
            if not self.browser(QUrl(url)):
                raise OSError('无法打开浏览器，请检查默认浏览器设置')
            self.service.touch()
            return '已在默认浏览器打开；不用时可在这里关闭服务'
        from ..kit.home import home
        self.process = self.spawn(edge_arguments(executable, url, home()),
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        self.last_touch = self.clock()
        self.service.touch()
        self.timer.start()
        return '课堂窗口已打开'

    def _tick(self):
        if not self.running():
            self.process = None
            self.timer.stop()
            return
        if self.clock() - self.last_touch >= 60:
            self.last_touch = self.clock()
            self.service.touch()

    def shutdown(self):
        if self.stopped:
            return
        self.stopped = True
        self.timer.stop()
        self.service.stop()  # Asynchronous; no waiting and no browser termination.
