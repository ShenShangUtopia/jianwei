"""Native classroom entry, driven only by the service's public status contract."""
from __future__ import annotations

import os
import weakref

from PySide6.QtCore import QObject, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QProgressBar, QPushButton, QScrollArea, QVBoxLayout, QWidget)

from ..design.tokens import T, font, qc
from ..design.widgets import qss
from ..design.icons import draw_icon
from .window import ClassroomWindow


def default_service():
    if os.environ.get('JIANWEI_SELFTEST') == '1':
        from . import fake_service as service
    else:
        from . import service
    return service


class _Bridge(QObject):
    changed = Signal(object)


class _Card(QFrame):
    def paintEvent(self, event):  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(qc(T.line2), 1))
        painter.setBrush(qc(T.raised))
        painter.drawRoundedRect(QRectF(self.rect()).adjusted(.5,.5,-.5,-.5), 10, 10)
        painter.end()


class _Board(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(130)

    def paintEvent(self, event):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        board = QRectF(0, 8, self.width(), 105)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qc(T.rail))
        p.drawRoundedRect(board, 10, 10)
        draw_icon(p, 'classroom', QRectF(25,32,52,52), qc(T.railon), 2)
        p.setFont(font(20,700))
        p.setPen(qc(T.railon))
        p.drawText(QRectF(98,24,self.width()-120,32), '从一个问题，开始一堂课')
        p.setFont(font(12))
        p.setPen(qc(T.railfg))
        p.drawText(QRectF(98,62,self.width()-120,25), 'AI 老师 · AI 同学 · 一起讨论与练习')
        p.end()


class ClassroomPage(QWidget):
    def __init__(self, main_win=None, service=None, launcher=None):
        super().__init__()
        self.setObjectName('jw2')
        self.main_win = main_win
        self.service = service or default_service()
        self.launcher = launcher or ClassroomWindow(self.service,self)
        self.pending_open = False
        self.pending_text = ''
        self.disposed = False
        self.bridge = _Bridge(self)
        self.bridge.changed.connect(self._service_changed, Qt.ConnectionType.QueuedConnection)
        root = QVBoxLayout(self)
        root.setContentsMargins(0,0,0,0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        root.addWidget(scroll)
        body = QWidget()
        row = QHBoxLayout(body)
        row.setContentsMargins(32,24,32,24)
        row.addStretch(1)
        content = QWidget()
        content.setMaximumWidth(880)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(15)
        layout.addStretch(1)
        eyebrow = QLabel('OPENMAIC  /  互动课堂')
        eyebrow.setObjectName('grpTitle')
        layout.addWidget(eyebrow)
        title = QLabel('课堂')
        title.setFont(font(30,700))
        layout.addWidget(title)
        description = QLabel('输入一个主题或上传资料，AI 老师和同学给你上一堂课：幻灯片、测验、互动演示、白板讲解。')
        description.setWordWrap(True)
        description.setFont(font(14))
        layout.addWidget(description)
        self.board = _Board()
        layout.addWidget(self.board)
        self.card = _Card()
        card = QVBoxLayout(self.card)
        card.setContentsMargins(24,21,24,21)
        card.setSpacing(12)
        self.state_label = QLabel('')
        self.state_label.setFont(font(18,700))
        card.addWidget(self.state_label)
        self.message = QLabel('')
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        self.message.setWordWrap(True)
        card.addWidget(self.message)
        self.memory = QLabel('')
        self.memory.setObjectName('ctlValue')
        card.addWidget(self.memory)
        self.progress = QProgressBar()
        self.progress.setRange(0,0)
        self.progress.setTextVisible(False)
        card.addWidget(self.progress)
        buttons = QHBoxLayout()
        self.primary = QPushButton('启动课堂')
        self.primary.setObjectName('pri')
        self.primary.setMinimumHeight(38)
        self.primary.clicked.connect(self._primary)
        buttons.addWidget(self.primary)
        self.stop_button = QPushButton('关闭服务')
        self.stop_button.setMinimumHeight(38)
        self.stop_button.clicked.connect(self._stop)
        buttons.addWidget(self.stop_button)
        buttons.addStretch(1)
        card.addLayout(buttons)
        layout.addWidget(self.card)
        self.notice = QLabel('')
        self.notice.setObjectName('note')
        self.notice.setTextFormat(Qt.TextFormat.PlainText)
        self.notice.setWordWrap(True)
        layout.addWidget(self.notice)
        self.idle_note = QLabel('按需启动，闲置自动关闭。课堂在独立窗口中打开。首次启动需要初始化，请稍候。')
        self.idle_note.setObjectName('note')
        self.idle_note.setWordWrap(True)
        layout.addWidget(self.idle_note)
        layout.addStretch(2)
        credit = QLabel('课堂组件来自开源项目 OpenMAIC（清华大学 THU-MAIC，MIT 许可）')
        credit.setObjectName('note')
        credit.setWordWrap(True)
        layout.addWidget(credit)
        self.license = QPushButton('许可')
        self.license.setObjectName('ghost')
        self.license.setFlat(True)
        self.license.setCursor(Qt.CursorShape.PointingHandCursor)
        self.license.clicked.connect(self._license)
        layout.addWidget(self.license,0,Qt.AlignmentFlag.AlignLeft)
        row.addWidget(content, 10)
        row.addStretch(1)
        scroll.setWidget(body)
        self.apply_theme()
        ref = weakref.ref(self.bridge)
        def changed(snapshot):
            bridge = ref()
            if bridge is not None:
                try:
                    bridge.changed.emit(dict(snapshot))
                except RuntimeError:
                    pass
        self.unsubscribe = self.service.subscribe(changed)
        unsubscribe = self.unsubscribe
        self.destroyed.connect(lambda: unsubscribe())
        self.timer = QTimer(self)
        self.timer.setInterval(3000)
        self.timer.timeout.connect(self.refresh)
        self._render(self.service.status())

    def apply_theme(self):
        self.setStyleSheet(qss())
        self.board.update()
        self.card.update()

    def showEvent(self, event):  # noqa: N802
        super().showEvent(event)
        if not self.disposed:
            self.refresh()
            self.timer.start()

    def hideEvent(self, event):  # noqa: N802
        self.timer.stop()
        super().hideEvent(event)

    def refresh(self):
        if not self.disposed:
            self._render(self.service.status())

    def _service_changed(self, _snapshot):
        self.refresh()

    def _render(self, snapshot):
        if self.disposed:
            return
        self.snapshot = dict(snapshot)
        state = snapshot.get('state','error')
        self.state_label.setText(dict(absent='未安装课堂组件',stopped='课堂尚未启动',
            starting='课堂正在启动',ready='课堂已就绪',stopping='正在关闭课堂',error='课堂启动未完成').get(state,'课堂状态未知'))
        self.message.setText(str(snapshot.get('message') or {
            'stopped':'使用时启动，关闭后保留课堂数据。','absent':'这个版本没有课堂组件。'
        }.get(state,'')))
        ready = state == 'ready'
        busy = state in ('starting','stopping')
        present = state != 'absent'
        key_ok = bool(snapshot.get('key_ok'))
        self.memory.setVisible(ready)
        self.memory.setText('约 '+str(max(0,int(snapshot.get('rss_mb') or 0)))+' MB' if ready else '')
        self.progress.setVisible(busy)
        self.primary.setVisible(present)
        self.stop_button.setVisible(present)
        self.stop_button.setEnabled(ready)
        self.primary.setEnabled(present and not busy)
        self.primary.setText('正在启动…' if state=='starting' else '正在关闭…' if state=='stopping'
            else '先设置 DeepSeek 密钥' if not key_ok else '打开课堂' if ready else '重试' if state=='error' else '启动课堂')
        self.idle_note.setVisible(present)
        self.license.setVisible((self.service.runtime_dir()/'LICENSE').is_file())
        if present and not key_ok and not busy:
            self.message.setText('请前往析题页右上角“DeepSeek 密钥…”设置，然后回到课堂。')
        if state in ('absent','error','stopped','stopping') and self.pending_open:
            self.pending_open = False
        if ready and self.pending_open:
            self.pending_open = False
            if key_ok:
                self._open()

    def _primary(self):
        was_pending = self.pending_open
        self.refresh()
        if was_pending and not self.pending_open and self.snapshot.get("state")=="ready" and self.snapshot.get("key_ok"):
            return
        if not self.snapshot.get('key_ok'):
            if self.main_win is not None:
                page = self.main_win.goto('analysis')
                QTimer.singleShot(0,page,page.edit_key)
            return
        if self.snapshot['state']=='ready':
            self._open()
        elif self.snapshot['state'] in ('stopped','error'):
            self.pending_open = True
            self.notice.setText('启动完成后将打开课堂窗口。')
            self.service.start()
            self.refresh()

    def make_lesson(self, text):
        self.pending_text = str(text or '').strip()
        if not self.pending_text:
            self.notice.setText('请先准备题目文字。')
            return
        self._primary()

    def _open(self):
        try:
            message = self.launcher.open(self.service.url('/'))
        except (OSError,ValueError) as exc:
            self.notice.setText(str(exc))
            return
        if self.pending_text:
            QApplication.clipboard().setText(self.pending_text)
            self.pending_text = ''
            message = '题目已复制，在课堂里粘贴就能生成。'
        self.notice.setText(message)

    def _stop(self):
        self.pending_open = False
        self.pending_text = ''
        self.service.stop()
        self.refresh()

    def _license(self, _link):
        path = self.service.runtime_dir()/'LICENSE'
        if path.is_file():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.resolve())))

    def shutdown(self):
        if self.disposed:
            return
        self.disposed = True
        self.pending_open = False
        self.pending_text = ''
        self.timer.stop()
        self.unsubscribe()
        self.launcher.shutdown()
