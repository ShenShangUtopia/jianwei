"""课堂服务自测：真的起数据库和 OpenMAIC 服务端（隔离数据目录、假密钥、不联网调模型）。

    python -m native.classroom.runtime_selftest <输出目录>

检查：没有运行时 → absent；缺密钥 → error 并说明；启动 → ready、首页能打开、量内存；
关闭 → stopped、子进程全部退出；再启动一次（已有数据库）更快；闲置计时到点会自己关。
没带课堂运行时的版本跳过（打印 SKIP），不算失败。
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.request
from pathlib import Path


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    out = Path(argv[0] if argv else "classroom-selftest")
    out.mkdir(parents=True, exist_ok=True)
    home = Path(os.environ.get("JIANWEI_HOME") or "")
    if not os.environ.get("JIANWEI_HOME") or ("AppData" in str(home) and home.name == "Jianwei"):
        print("拒绝运行：要先把 JIANWEI_HOME 指到临时目录", flush=True)
        return 2
    from . import service as S
    report = dict(result="FAIL", checks=[])

    def check(name, ok, detail=""):
        report["checks"].append(dict(name=name, ok=bool(ok), detail=str(detail)[:300]))
        print(("ok   " if ok else "FAIL ") + name, detail if not ok else "", flush=True)
        if not ok:
            raise AssertionError(name)

    def wait(states, limit):
        t0 = time.time()
        while time.time() - t0 < limit:
            st = S.status()
            if st["state"] in states:
                return st, time.time() - t0
            time.sleep(0.3)
        return S.status(), time.time() - t0

    try:
        if not S.available():
            print("SKIP 没有课堂运行时：", S.runtime_dir(), flush=True)
            report.update(result="SKIP")
            return 0
        events = []
        cancel = S.subscribe(lambda st: events.append(st["state"]))
        (home / "deepseek.env").unlink(missing_ok=True)
        S.start()
        st, _ = wait(("error",), 5)
        check("缺密钥时不启动，说明原因", st["state"] == "error" and "密钥" in st["message"] and not st["key_ok"], st)
        (home / "deepseek.env").write_text("DEEPSEEK_API_KEY=sk-selftest-not-a-real-key\n", encoding="utf-8")
        S.start()
        st, first = wait(("ready", "error"), 600)
        check("第一次启动（建数据库）到 ready", st["state"] == "ready", st)
        report["first_start_s"] = round(first, 1)
        page = urllib.request.build_opener(urllib.request.ProxyHandler({})).open(S.url("/"), timeout=60)
        body = page.read(200000).decode("utf-8", "replace")
        check("首页能打开", page.status == 200 and "<html" in body.lower(), page.status)
        time.sleep(5)
        report["rss_idle_mb"] = S.status()["rss_mb"]
        check("量得到内存", report["rss_idle_mb"] > 50, report["rss_idle_mb"])
        pids = S.tree_pids()
        check("状态事件经过 starting 到 ready", "starting" in events and "ready" in events, events)
        S.stop()
        st, _ = wait(("stopped",), 60)
        time.sleep(1)
        check("关闭后 stopped，子进程全部退出", st["state"] == "stopped" and not any(S._alive(p) for p in pids), [p for p in pids if S._alive(p)])
        S.start()
        st, second = wait(("ready", "error"), 300)
        check("再启动（已有数据库）", st["state"] == "ready", st)
        report["second_start_s"] = round(second, 1)
        S.IDLE_SECONDS = 1
        S.S.last_touch = 0
        st, _ = wait(("stopped",), 90)
        check("闲置到点自己关", st["state"] == "stopped", st)
        cancel()
        log = (S.data_dir() / "logs" / "service.log").read_text(encoding="utf-8")
        check("日志里没有密钥", "sk-selftest" not in log and "sk-selftest" not in (S.data_dir() / "openmaic.yml").read_text(encoding="utf-8"))
        report["result"] = "OK"
        print("CLASSROOM RUNTIME OK", json.dumps({k: v for k, v in report.items() if k != "checks"}, ensure_ascii=False), flush=True)
        return 0
    except AssertionError:
        return 1
    finally:
        try:
            S.stop_and_wait(15)
        finally:
            (out / "classroom-runtime.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
