"""课件播放窗口：左边课件、右边黑板（可分屏、可只看一边、黑板可成独立窗口），底部工具条。

快捷键：← → / 空格 / PgUp PgDn / 滚轮 翻页；打页码再按 Enter 跳页；V 指针 P 笔 H 荧光笔 E 橡皮 S 框选；B 黑板；G 目录；
Ctrl+Z 撤销；F11 全屏；Esc 一层层退出。只看黑板时：PgUp PgDn 换板，F 看全。
放映时 3 秒不动，放映条和鼠标都收起来；一动就回来。
"""
from __future__ import annotations

import os
import time

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QIcon, QImage, QPainter, QPixmap
from PySide6.QtPdf import QPdfDocument
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSplitter, QVBoxLayout, QWidget

from . import library, lookup
from .board import Board
from .panel import LookupPanel
from .pageview import PageView
from ..kit.pen_store import PenStore
from ..kit.pen_bar import PenBar, ToolKey
from .frames import FrameSource
from .live import LiveController, round_mask
from ..kit.home import load_json, save_json
from ..design.icons import draw_icon
from ..design.tokens import T
from .transfer import LectureTransfer

ICON_NAMES = dict(prev="chevron_l", next="chevron_r", slide="lecture", split="side")
COLORS = ["#E5484D", "#2F6FED", "#16A34A", "#F59E0B", "#111418"]
WIDTHS = [("细", 2.0), ("中", 3.5), ("粗", 6.0)]


def svg_icon(name, color="#DCE5E0", size=20) -> QIcon:
    """放映条的图标（和全局图标同一套）。"""
    icon = QIcon()
    for k in (1, 2):
        pm = QPixmap(size * k, size * k)
        pm.setDevicePixelRatio(k)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        draw_icon(p, ICON_NAMES.get(name, name), QRectF(0, 0, size, size), QColor(color))
        p.end()
        icon.addPixmap(pm)
    return icon


# 放映时背景永远是深色：放映条用固定的墨绿仪表色，不跟昼夜主题走
BAR_QSS = """
QFrame#bar { background:rgba(13,21,18,0.96); border:1px solid #2E3F39; border-radius:10px; }
QFrame#bar QPushButton#num { background:transparent; border:none; border-radius:5px; color:#E6EEE9; font-size:13px; font-family:'Bahnschrift','Microsoft YaHei UI'; padding:0 8px; min-height:0; }
QFrame#bar QPushButton#num:hover { background:#22332E; }
QFrame#seg { background:#0A110F; border:1px solid #22302B; border-radius:7px; }
QFrame#sep { background:transparent; border:none; border-left:1px solid #2E3F39; margin-left:4px; }
QFrame#acts { background:rgba(13,21,18,0.98); border:1px solid #3A4C45; border-radius:8px; }
QFrame#acts QPushButton { background:#1B2925; color:#E6EEE9; border:1px solid #2E3F39; border-bottom:2px solid #0A100E; border-radius:5px; padding:5px 12px 4px 12px; font-size:12.5px; font-family:'Microsoft YaHei UI'; }
QFrame#acts QPushButton:hover { background:#263732; }
QFrame#acts QPushButton:pressed { border-bottom:1px solid #0A100E; margin-top:1px; }
QFrame#acts QPushButton#pri { background:#C8402A; border-color:#7E2616; color:white; font-weight:600; }
QFrame#acts QPushButton#pri:hover { background:#DA5238; }
QLabel#toast { background:rgba(13,21,18,0.97); color:#F2F6F4; border:1px solid #3A4C45; border-left:3px solid #C8402A; border-radius:4px; padding:8px 14px; font-size:13px; font-family:'Microsoft YaHei UI'; }
QListWidget#grid { background:rgba(10,15,13,0.97); border:none; color:#DCE5E0; font-family:'Microsoft YaHei UI'; outline:0; }
QListWidget#grid::item { padding:6px; border-radius:5px; }
QListWidget#grid::item:selected, QListWidget#grid::item:hover { background:#22332E; color:white; }
"""


class PlayBar(QFrame):
    """放映条：深色浮条，底边一道细线表示放到第几个画面了。"""
    on_dark = True

    def __init__(self, parent=None):
        super().__init__(parent)
        self.progress = 0.0
        self.show_progress = True

    def set_progress(self, v: float):
        v = max(0.0, min(1.0, v))
        if abs(v - self.progress) > 1e-4:
            self.progress = v
            self.update()

    def paintEvent(self, e):  # noqa: N802
        super().paintEvent(e)
        if not self.show_progress:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(10, 0, -10, 0)
        y = self.height() - 3.5
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#22332E"))
        p.drawRoundedRect(QRectF(r.x(), y, r.width(), 2), 1, 1)
        if self.progress > 0:
            p.setBrush(QColor("#C8402A"))
            p.drawRoundedRect(QRectF(r.x(), y, max(2.0, r.width() * self.progress), 2), 1, 1)
        p.end()


class BoardWindow(QWidget):
    """独立的黑板窗口：放回时把黑板还给播放器。"""

    def __init__(self, player):
        super().__init__(player, Qt.WindowType.Window)
        self.player = player
        self.setWindowTitle("见微 · 黑板")
        self.setLayout(QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.setObjectName("boardWin")
        self.setStyleSheet("QWidget#boardWin { background:#101A17; }")   # 不带选择器会刷到黑板条的每个子控件上

    def closeEvent(self, e):  # noqa: N802
        if not self.player.closing:
            QTimer.singleShot(0, self.player, self.player.reattach_board)
        e.accept()


class LecturePlayer(LectureTransfer,QWidget):
    def __init__(self, meta: dict, start_view: str = "slide", bus=None):
        super().__init__()
        self.meta = meta
        self.closing = False
        toolbar_settings=load_json('lecture-toolbar.json',{})
        self.bar_pinned=isinstance(toolbar_settings,dict) and toolbar_settings.get('pinned') is True
        self.cursor_hidden = False
        self.jump_buf = ""
        self.jump_timer = QTimer(self)
        self.jump_timer.setSingleShot(True)
        self.jump_timer.timeout.connect(lambda: setattr(self, "jump_buf", ""))
        self.dir = library.folder(meta["id"])
        self.setWindowTitle(f"{meta.get('title', '')} - 见微")
        self.setObjectName("player")
        self.setStyleSheet("QWidget#player { background:#0A0F0D; }" + BAR_QSS)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.base_doc = QPdfDocument(self)
        self.base_doc.load(str(self.dir / "doc.pdf"))
        self.prepare_transfer(bus)
        self.ink_store = PenStore(self.dir / "ink.json", "ink")
        strokes = dict(self.ink_store.data["pages"])
        if meta.get("clip_id"):
            self.seed_ink[0] = self.clip_bus.store.load(meta["clip_id"]).get("ink",[])
        for key,seed in self.seed_ink.items():
            strokes.setdefault(str(key),seed)
        self.view = PageView(self.doc, meta.get("kind", "slides"), strokes, self.projected_timeline)
        if self.base_doc.pageCount() > 0:
            self.view.use_frames(FrameSource(self.dir / "doc.pdf", self.base_doc.pageCount()), self.base_doc)
        self.live = LiveController(self)
        self.view.live_nav = self.live.nav
        self.board = Board(self.dir / "board")
        self.board.detach_toggled.connect(self.toggle_detach)
        self.detached = None
        self.ocr = lookup.Ocr()
        self.ocr.start()
        lookup.warm()
        library.resume_text_layer(self.dir, meta)   # 导入后没等文字层做完就关了：打开时在后台补做
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setHandleWidth(5)
        self.split.setStyleSheet("QSplitter::handle { background:#22332E; } QSplitter::handle:hover { background:#C8402A; }")
        self.split.addWidget(self.view)
        self.split.addWidget(self.board)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.storage_notice = QLabel()
        self.storage_notice.setWordWrap(True)
        self.storage_notice.setStyleSheet(f"background:{T.surface};color:{T.bad};padding:8px 14px;border-bottom:1px solid {T.line};")
        self.storage_notice.hide()
        root.addWidget(self.storage_notice)
        h = QHBoxLayout()
        root.addLayout(h, 1)
        h.setContentsMargins(0, 0, 0, 0)
        self.body = h   # 查询面板开着时右边留出面板的宽度，课件整页缩进剩下的地方，不被面板盖住
        h.addWidget(self.split)
        self.panel = LookupPanel(self.ocr)
        self.panel.setParent(self)
        self.panel.hide()
        self.panel.to_board.connect(self.text_to_board)
        self.panel.image_to_board.connect(self.image_to_board)
        self.panel.closed.connect(self.setFocus)
        self.panel.closed.connect(lambda: QTimer.singleShot(0, self, self._place))   # 面板关了，课件回到整宽
        self.panel.open_question.connect(self.open_question)
        self.panel.analyze.connect(self.analyze_text)
        self.text_doc = None
        self.view.text_lookup = self._text_lookup
        self.toast_label = QLabel(self)
        self.toast_label.setObjectName("toast")
        self.toast_label.hide()
        self.toast_timer = QTimer(self)
        self.toast_timer.setSingleShot(True)
        self.toast_timer.timeout.connect(self.toast_label.hide)
        self.board.canvas.storage_error.connect(self.show_storage_error)
        protected = [s.error for s in (self.ink_store, self.board.canvas.store) if s.error]
        if protected:
            QTimer.singleShot(0, self, lambda: self.show_storage_error("；".join(protected)))
        self._build_bar()
        self._build_actions()
        self.bind_transfer()
        self.grid = None
        self.view.page_changed.connect(self._on_page)
        self.view.frame_changed.connect(self._sync_num)
        self.view.frame_changed.connect(self.live.frame_changed)
        self.live.changed.connect(self._sync_live_key)
        if self.live.available() and load_json("lecture-live.json", {}).get("on") and not os.environ.get("JIANWEI_NO_LIVE"):
            QTimer.singleShot(500, self, self.live.start)   # 上次用的是原生放映：这次接着用
        self.view.selected.connect(self._on_selected)
        self.view.ink_changed.connect(self._schedule_save)
        self.view.activity.connect(self._wake)
        self.saver = QTimer(self)
        self.saver.setSingleShot(True)
        self.saver.timeout.connect(self.save)
        self.idle = QTimer(self)
        self.idle.setSingleShot(True)
        self.idle.timeout.connect(self._maybe_hide_bar)
        self.view_mode = "slide"
        self.set_view(start_view)
        start = max(0, min(self.view.pages - 1, int(meta.get("page") or 0)))
        self.view.page, self.view.frame = start, self.view.slides[start]["first"]
        self._on_page(start)
        QTimer.singleShot(300, self.view, self.view.start)
        self.set_tool("pointer")
        library.update(meta["id"], opened=time.time())
        self.resize(1280, 760)

    # ---- 工具条
    def _tbtn(self, icon, tip, fn, check=False):
        """放映条上的一颗键：和画笔组同一套（32×32、选中填色、按下下沉）。"""
        b = ToolKey(self.bar, ICON_NAMES.get(icon, icon), tip)
        b.setCheckable(check)
        b.clicked.connect(lambda _c=False: fn())
        return b

    @staticmethod
    def _sep():
        s = QFrame()
        s.setObjectName("sep")
        s.setFixedSize(9, 20)
        return s

    def _build_bar(self):
        bar = PlayBar(self)
        bar.setObjectName("bar")
        self.bar = bar
        outer=QVBoxLayout(bar)
        outer.setContentsMargins(6,4,6,6)
        outer.setSpacing(2)
        h = QHBoxLayout()
        self.bar_flow=h
        h.setContentsMargins(0,0,0,0)
        outer.addLayout(h)
        h.setSpacing(1)
        self.nav_group = []
        add = lambda w, grp=None: (h.addWidget(w), grp.append(w) if grp is not None else None)
        add(self._tbtn("prev", "上一步（← / PgUp / 右键）", self.view.prev), self.nav_group)
        self.num_btn = QPushButton("1 / 1")
        self.num_btn.setObjectName("num")
        self.num_btn.setFixedHeight(32)
        self.num_btn.setToolTip("目录（G）；也可以直接打页码再按 Enter 跳过去")
        self.num_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.num_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.num_btn.clicked.connect(self.toggle_grid)
        add(self.num_btn, self.nav_group)
        add(self._tbtn("next", "下一步（→ / 空格 / 单击）", self.view.next), self.nav_group)
        add(self._sep(), self.nav_group)
        # 分屏时课件那一半放不下整排画笔：收成一颗「画笔」键，点开再展开
        self.pen_open = False
        self.pen_toggle = self._tbtn("pen", "课件画笔：展开 / 收起", self.toggle_pen_group, True)
        h.addWidget(self.pen_toggle)
        self._pen_at=h.count()
        self._pen_wrapped=False
        self.pen_group = []
        self.pen_bar = PenBar(self.view,self.view.pen_session,on_dark=True)
        add(self.pen_bar,self.pen_group)
        add(self._tbtn("trash", "清除这一页的笔迹", self.view.clear_page), self.pen_group)
        add(self._sep(), self.pen_group)
        seg = QFrame()
        seg.setObjectName("seg")
        sh = QHBoxLayout(seg)
        sh.setContentsMargins(2, 0, 2, 0)
        sh.setSpacing(0)
        self.views = {}
        for key, icon, tip in (("slide", "slide", "只看课件"), ("split", "split", "课件和黑板分屏"), ("board", "board", "只看黑板（B）")):
            b = self._tbtn(icon, tip, lambda k=key: self.set_view(k), True)
            self.views[key] = b
            sh.addWidget(b)
        h.addWidget(seg)
        # 原生放映开关：只有装了 WPS / PowerPoint、而且是幻灯片课件时才出现
        self.live_key = self._tbtn("play", "原生放映：让 WPS / PowerPoint 自己放（动画、视频都是它放的）；拿笔或框选时换成同一画面的图", self.toggle_live, True)
        self.live_key.setVisible(self.live.available())
        h.addWidget(self.live_key)
        self.share_at = h.count()
        self.pin_key=self._tbtn('locate','固定工具栏：不再自动收起',self.toggle_bar_pin,True)
        self.pin_key.setChecked(self.bar_pinned)
        h.addWidget(self.pin_key)
        from ..kit.desktop_tools import toggle_desktop_tools
        h.addWidget(self._tbtn('detach','桌面悬浮批注：可在见微之外画笔、荧光笔与指示',toggle_desktop_tools))
        self.close_sep = self._sep()
        h.addWidget(self.close_sep)
        h.addWidget(self._tbtn("close", "退出放映（Esc）", self.close))
        self.pen_row=QWidget(bar)
        self.pen_row_layout=QHBoxLayout(self.pen_row)
        self.pen_row_layout.setContentsMargins(0,0,0,0)
        self.pen_row_layout.setSpacing(1)
        self.pen_row_layout.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        outer.addWidget(self.pen_row)
        self.pen_row.hide()
        self.set_color(COLORS[0], False)
        self.set_width(WIDTHS[1][1])

    # ---- 原生放映
    def toggle_live(self):
        if self.live.running:
            self.live.stop()
            self.toast("回到见微放映")
            on = False
        else:
            on = self.live.start()
        try:
            save_json("lecture-live.json", dict(on=on))
        except OSError:
            pass
        self._sync_live_key()

    def _sync_live_key(self):
        self.live_key.setChecked(self.live.running)
        self.live_key.setToolTip((f"{self.live.label()} 原生放映中：点一下回到见微放映" if self.live.running else
                                  f"原生放映：让 {self.live.label()} 自己放（动画、视频都是它放的）；拿笔或框选时换成同一画面的图"))

    def go_native_overlays(self):
        """原生放映窗口是真正的子窗口：放映条、提示条、面板也要变成原生子窗口，才能排在它上面。"""
        for w in (self.bar, self.acts, self.toast_label, self.panel, self.grid):
            if w is not None and not w.testAttribute(Qt.WidgetAttribute.WA_NativeWindow):
                w.setAttribute(Qt.WidgetAttribute.WA_NativeWindow, True)
        self._masks()
        self.raise_overlays()

    def _masks(self):
        bar = getattr(self, "bar", None)
        if bar is not None and bar.testAttribute(Qt.WidgetAttribute.WA_NativeWindow):
            round_mask(self.bar, 10)
            round_mask(self.acts, 8)
            round_mask(self.toast_label, 4)

    def raise_overlays(self):
        for w in (self.bar, self.acts, self.toast_label, self.panel, self.grid):
            if w is not None and w.isVisible():
                w.raise_()

    def reclaim_focus(self):
        """在原生放映画面上点过以后，键盘焦点在演示软件里：拿回来，快捷键照常用。"""
        self.activateWindow()
        self.setFocus()
        try:
            from .live import u32
            u32.SetFocus(int(self.winId()))
        except (ImportError, OSError, AttributeError):
            pass

    def add_share_key(self, fn):
        """互通键（由互通层加上）：放在视图切换和退出之间。"""
        k = self._tbtn("share", "互通：把这一页或选区送到黑板、工作台、素材篮", fn)
        self.bar_flow.insertWidget(self.bar_flow.indexOf(self.pin_key), k)
        return k

    def _build_actions(self):
        f = QFrame(self)
        f.setObjectName("acts")
        h = QHBoxLayout(f)
        h.setContentsMargins(5, 5, 5, 5)
        h.setSpacing(3)
        for label, fn, pri, tip in (("带入黑板", self.selection_to_board, True, "把这块放到独立的黑板区域（Enter）"), ("搜题", self.selection_question, True, "在题库里找这道题，或送去析题（T）"), ("上网查询", self.selection_search, False, "取出这块的文字上网查（Q）"), ("复制", self.selection_copy, False, "复制截图到剪贴板"), ("取消", self.view.clear_selection, False, "")):
            b = QPushButton(label)
            if pri:
                b.setObjectName("pri")
            b.setToolTip(tip)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(fn)
            h.addWidget(b)
        f.hide()
        self.acts = f

    # ---- 布局
    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        self._place()

    def _place(self):
        W, H = self.width(), self.height()
        pw = min(450, max(320, W // 3)) if self.panel.isVisible() else 0
        room = W - pw   # 查询面板开着时，工具条只在剩下的地方居中，不被挡住
        self.pen_bar.set_compact(room<1000)
        inline_width=self.bar_flow.sizeHint().width()+12
        if self._pen_wrapped:
            inline_width+=sum(w.sizeHint().width()+self.bar_flow.spacing() for w in self.pen_group if not w.isHidden())
        wrap=self.view_mode!='board' and self.pen_open and inline_width>room-16
        if wrap!=self._pen_wrapped:
            for i,widget in enumerate(self.pen_group):
                if wrap:
                    self.bar_flow.removeWidget(widget)
                    self.pen_row_layout.addWidget(widget)
                else:
                    self.pen_row_layout.removeWidget(widget)
                    self.bar_flow.insertWidget(self._pen_at+i,widget)
            self._pen_wrapped=wrap
        self.pen_row.setVisible(wrap)
        self.bar.adjustSize()
        if self.body.contentsMargins().right() != pw:
            self.body.setContentsMargins(0, 0, pw, 0)
        bw = min(self.bar.sizeHint().width(), room - 16)
        bh = self.bar.sizeHint().height()
        x0, x1 = self._bar_zone(room, bw)
        x = room - bw - 16 if self.view_mode == "board" else x0 + (x1 - x0 - bw) // 2
        self.bar.setGeometry(max(8, x), H - bh - 12, bw, bh)
        self.bar.raise_()
        if pw:
            self.panel.setGeometry(W - pw, 0, pw, H)
            self.panel.raise_()
        if self.grid is not None and self.grid.isVisible():
            self.grid.setGeometry(self.rect())
            self.grid.raise_()
        self._place_actions()
        self._masks()

    def _place_actions(self):
        if self.view.sel is None or self.view_mode == "board":
            self.acts.hide()
            return
        v = self.view.view_rect(self.view.sel)
        o = self.view.mapTo(self, QPointF(0, 0).toPoint())
        self.acts.adjustSize()
        aw, ah = self.acts.width(), self.acts.height()
        x = o.x() + v.right() - aw
        y = o.y() + v.bottom() + 8
        bar_top = self.bar.y() if self.bar.isVisible() else self.height()
        if y + ah > bar_top - 4:
            y = o.y() + v.top() - ah - 8
        if y < 4:
            y = o.y() + v.bottom() - ah - 8
        x = max(6, min(self.width() - aw - 6, x))
        self.acts.move(int(x), int(y))
        self.acts.show()
        self.acts.raise_()

    def _bar_zone(self, room, bw):
        """放映条在哪段横向范围里居中：分屏时放在课件那一半下面（放得下的话），不压黑板。"""
        if self.view_mode == "split" and self.view.isVisible():
            x0 = self.view.mapTo(self, QPointF(0, 0).toPoint()).x()
            x1 = min(room, x0 + self.view.width())
            if x1 - x0 >= bw + 16:
                return x0, x1
        return 0, room

    def toast(self, text, ms=2200):
        """提示条：贴在放映条上方，和放映条同一列，不挡黑板的工具条。"""
        self.toast_label.setText(text)
        self.toast_label.adjustSize()
        tw, th = self.toast_label.width(), self.toast_label.height()
        if self.bar.isVisible():
            cx = self.bar.geometry().center().x()
            y = self.bar.y() - th - 10
        else:
            cx = self.width() // 2
            y = self.height() - th - 28
        self.toast_label.move(max(8, min(self.width() - tw - 8, cx - tw // 2)), y)
        self._masks()
        self.toast_label.show()
        self.toast_label.raise_()
        self.toast_timer.start(ms)

    # ---- 状态
    def set_tool(self, k):
        self.view.set_tool(k)
        self.pen_bar.sync()
        if k != "pointer" and self.view_mode == "split" and not self.pen_open:
            self.pen_open = True   # 用快捷键拿了笔：把画笔组展开，看得见在用什么
            self._apply_bar()
        self._wake()

    def set_color(self, c, switch=True):
        self.view.color = c
        self.pen_bar.sync()
        if switch and self.view.tool not in ("pen", "marker"):
            self.set_tool("pen")

    def set_width(self, w):
        self.view.width_px = w
        self.pen_bar.sync()

    def set_view(self, mode):
        if self.detached is not None and mode != "slide":
            self.toast("黑板在独立窗口里")
            mode = "slide"
        self.view_mode = mode
        if mode == "split" and self.view.tool != "pointer":
            self.pen_open = True
        self.view.setVisible(mode in ("slide", "split"))
        self.board.setVisible(mode in ("split", "board") or self.detached is not None)
        if self.detached is None:
            self.board.setVisible(mode in ("split", "board"))
        if mode == "split":
            total = max(2, self.split.width())
            self.split.setSizes([total // 2, total - total // 2])
        for key, b in self.views.items():
            b.setChecked(key == mode)
        self._apply_bar()
        self._wake()
        QTimer.singleShot(0, self, self._place)

    def _apply_bar(self):
        """按视图决定放映条上露哪些键：只看黑板时只留视图切换和退出；分屏时画笔收成一颗键。"""
        mode = self.view_mode
        for w in self.nav_group:
            w.setVisible(mode != "board")
        self.pen_toggle.setVisible(mode == "split")
        self.pen_toggle.setChecked(self.pen_open)
        for w in self.pen_group:
            w.setVisible(mode == "slide" or (mode == "split" and self.pen_open))
        if getattr(self, "share_btn", None) is not None:
            self.share_btn.setVisible(mode != "board")   # 只看黑板时用黑板条上的互通
        self.bar.show_progress = mode != "board"
        self.bar.adjustSize()
        self._place()

    def toggle_pen_group(self):
        self.pen_open = not self.pen_open
        if not self.pen_open and self.view.tool not in ("pointer",):
            self.set_tool("pointer")
        self._apply_bar()

    def toggle_detach(self):
        if self.detached is None:
            self.detach_board()
        else:
            self.reattach_board()

    def detach_board(self):
        w = BoardWindow(self)
        self.board.setParent(None)
        w.layout().addWidget(self.board)
        self.board.show()
        self.detached = w
        self.board.set_detached(True)
        screens = QGuiApplication.screens()
        mine = self.screen()
        other = next((s for s in screens if s is not mine), None)
        if other is not None:
            w.setGeometry(other.geometry())
            w.showFullScreen()
        else:
            r = self.screen().availableGeometry()
            w.setGeometry(r.x() + r.width() // 5, r.y() + r.height() // 8, r.width() * 3 // 5, r.height() * 3 // 4)
            w.show()
        w.raise_()
        self.set_view("slide")

    def reattach_board(self):
        w, self.detached = self.detached, None
        if w is None:
            return
        self.board.setParent(None)
        self.split.addWidget(self.board)
        self.board.set_detached(False)
        w.close()
        w.deleteLater()
        self.set_view("split")

    def _sync_num(self):
        v = self.view
        sl = v.slides[v.page]
        steps = sl["last"] - sl["first"]
        extra = f"  ·  动画 {v.frame - sl['first']}/{steps}" if steps else ""
        self.num_btn.setText(f"{v.page + 1} / {v.pages}{extra}")
        self.bar.set_progress((v.frame + 1) / max(1, len(v.frames)))
        self.bar.adjustSize()
        self._place()

    def _on_page(self, i):
        self._sync_num()
        library.update(self.meta["id"], page=i)
        self.acts.hide()
        self._wake()

    def _on_selected(self, rect):
        if rect.isEmpty():
            self.acts.hide()
        else:
            self._place_actions()

    def _wake(self):
        if not self.bar.isVisible():
            self.bar.show()
            self._place()
        if self.cursor_hidden:
            self.cursor_hidden = False
            self.view._apply_cursor()
        if not self.bar_pinned and self.view_mode == "slide" and self.view.tool == "pointer" and self.detached is None:
            self.idle.start(3000)
        else:
            self.idle.stop()

    def _maybe_hide_bar(self):
        """放映时 3 秒不动：收起放映条，鼠标也藏起来（和 PPT 放映一样），一动就回来。"""
        if not self.bar_pinned and self.view_mode == "slide" and self.view.tool == "pointer" and not self.bar.underMouse() and not self.acts.isVisible():
            self.bar.hide()
            if self.view.underMouse() and not self.panel.isVisible() and not self.live.visible:
                self.cursor_hidden = True
                self.view.setCursor(Qt.CursorShape.BlankCursor)

    def toggle_bar_pin(self):
        self.bar_pinned=not self.bar_pinned
        self.pin_key.setChecked(self.bar_pinned)
        self.pin_key.setToolTip('已固定工具栏：点此恢复自动收起' if self.bar_pinned else '固定工具栏：不再自动收起')
        config=load_json('lecture-toolbar.json',{})
        if isinstance(config,dict):
            try:
                save_json('lecture-toolbar.json',dict(config,pinned=self.bar_pinned))
            except OSError:
                pass
        self._wake()

    # ---- 打页码跳页（和 PPT 放映一样：打 12 再按 Enter）
    def _jump_digit(self, d):
        self.jump_buf = (self.jump_buf + str(d))[-4:]
        self.jump_timer.start(2600)
        n = int(self.jump_buf)
        ok = 1 <= n <= self.view.pages
        self.toast(f"跳到第 {n} 页 · 按 Enter" if ok else f"没有第 {n} 页（共 {self.view.pages} 页）", 2600)

    def _jump_go(self):
        n = int(self.jump_buf or 0)
        self.jump_buf = ""
        self.jump_timer.stop()
        if 1 <= n <= self.view.pages:
            self.view.go(n - 1)
            self.toast_label.hide()
            return True
        return False

    # ---- 截取之后
    def _capture(self):
        r = self.view.sel
        return (self.view.capture(r), r) if r is not None else (None, None)

    def selection_to_board(self):
        if self.view.sel is None:
            return
        self.clip_bus.send(self.lecture_clip(),"board",self)
        self.view.clear_selection()

    def image_to_board(self, im):
        clip = self.clip_bus.store.create(image=im)
        self.clip_bus.send(clip,"board",self)

    def text_to_board(self, text):
        if not text.strip():
            return
        self.clip_bus.send(self.clip_bus.store.create(text=text.strip()),"board",self)

    def _show_board(self):
        if self.detached is not None:
            self.detached.raise_()
        elif self.view_mode == "slide":
            self.set_view("split")

    def selection_search(self):
        im, r = self._capture()
        if im is None:
            return
        text = self.view.selection_text(r)
        hint = lookup.make_query(self.doc.getAllText(self.view.pdf).text().split("\n")[0], 20)
        self.panel.show()
        self._place()
        self.panel.start(im, text, hint)
        self.view.clear_selection()

    def selection_question(self):
        """搜题：框里的文字先去题库找，找不到或想细看就送去析题。"""
        im, r = self._capture()
        if im is None:
            return
        text = self.view.selection_text(r)
        self.panel.show()
        self._place()
        self.panel.start(im, text, "", mode="question")
        self.view.clear_selection()

    def open_question(self, qid):
        win = self.window()
        if hasattr(win, "goto"):
            win.goto("desk", qid)
            if hasattr(win, "present"):
                win.present()

    def analyze_text(self, text, image):
        clip = self.clip_bus.store.create(image=image, text=text or "")
        self.clip_bus.send(clip, "analysis", self)

    def _text_lookup(self, pdf_page):
        """放映页 → 文字层 PDF 的第几页（同一张幻灯片的各个动画画面共用一页文字）。"""
        path = self.dir / "text.pdf"
        if not path.is_file():
            return None
        if getattr(self, "text_doc", None) is None:
            from PySide6.QtPdf import QPdfDocument
            self.text_doc = QPdfDocument(self)
            self.text_doc.load(str(path))
        frames = (self.base_timeline or {}).get("frames") or []
        if not 0 <= pdf_page < len(frames):
            return None
        slide = frames[pdf_page]["slide"]
        return (self.text_doc, slide) if slide < self.text_doc.pageCount() else None

    def selection_copy(self):
        if self.view.sel is not None:
            QApplication.clipboard().setMimeData(self.clip_bus.store.mime(self.lecture_clip()))
            self.toast("截图已复制")
            self.view.clear_selection()

    # ---- 目录
    def toggle_grid(self):
        if self.grid is not None and self.grid.isVisible():
            self.grid.hide()
            self.setFocus()
            return
        if self.grid is None:
            g = QListWidget(self)
            g.setObjectName("grid")
            g.setViewMode(QListWidget.ViewMode.IconMode)
            g.setResizeMode(QListWidget.ResizeMode.Adjust)
            g.setMovement(QListWidget.Movement.Static)
            g.setIconSize(QSize(240, 240))
            g.setSpacing(10)
            g.setUniformItemSizes(True)
            g.itemClicked.connect(self._grid_pick)
            for i in range(self.view.pages):
                it = QListWidgetItem(str(i + 1))
                it.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
                it.setSizeHint(QSize(262, 262 if self.view.kind == "doc" else 190))
                g.addItem(it)
            self.grid = g
            if self.live.embedded:
                g.setAttribute(Qt.WidgetAttribute.WA_NativeWindow, True)   # 要盖在原生放映窗口上面
            self._grid_next = 0
            self.grid_timer = QTimer(self)
            self.grid_timer.timeout.connect(self._grid_thumb)
        self.grid.setCurrentRow(self.view.page)
        self.grid.setGeometry(self.rect())
        self.grid.show()
        self.grid.raise_()
        self.grid.setFocus()
        self.grid.scrollToItem(self.grid.item(self.view.page))
        if self._grid_next < self.view.pages:
            self.grid_timer.start(10)

    def _grid_thumb(self):
        i = self._grid_next
        if i >= self.view.pages or self.grid is None or not self.grid.isVisible():
            self.grid_timer.stop()
            return
        pw, ph = self.view.page_size(i)
        k = 240 / max(pw, ph)
        self.grid.item(i).setIcon(QIcon(QPixmap.fromImage(self.view.page_image(self.view.final_pdf(i), int(pw * k), int(ph * k)))))
        self._grid_next = i + 1

    def _grid_pick(self, it):
        self.view.go(self.grid.row(it))
        self.grid.hide()
        self.setFocus()

    # ---- 按键
    def keyPressEvent(self, e):  # noqa: N802
        k, mod = e.key(), e.modifiers()
        ctrl = bool(mod & Qt.KeyboardModifier.ControlModifier)
        board_only = self.view_mode == "board"
        session = self.board.canvas.pen_session if board_only else self.view.pen_session
        if session.ids and k in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace):
            session.selection_action("delete")
            return
        if self.grid is not None and self.grid.isVisible():
            if k in (Qt.Key.Key_Escape, Qt.Key.Key_G):
                self.grid.hide()
                self.setFocus()
            elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._grid_pick(self.grid.currentItem())
            return
        if not board_only and not ctrl and Qt.Key.Key_0 <= k <= Qt.Key.Key_9:
            self._jump_digit(k - Qt.Key.Key_0)
            return
        if self.jump_buf and k in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._jump_go()
            return
        if self.jump_buf and k == Qt.Key.Key_Escape:
            self.jump_buf = ""
            self.toast_label.hide()
            return
        if ctrl and k == Qt.Key.Key_Z:
            self.board.canvas.undo() if board_only else self.view.undo()
        elif ctrl and k == Qt.Key.Key_Y:
            self.board.canvas.redo() if board_only else self.view.redo()
        elif k == Qt.Key.Key_Escape:
            self._escape()
        elif k == Qt.Key.Key_F11:
            self.showNormal() if self.isFullScreen() else self.showFullScreen()
        elif k == Qt.Key.Key_B:
            self.set_view("slide" if board_only else "board")
        elif board_only:
            mapped = {Qt.Key.Key_V: "move", Qt.Key.Key_P: "pen", Qt.Key.Key_H: "marker", Qt.Key.Key_L: "laser", Qt.Key.Key_E: "eraser", Qt.Key.Key_T: "text"}.get(k)
            if mapped:
                self.board.canvas.set_tool(mapped)
            elif k in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
                self.board.canvas.delete_selected()
            elif k in (Qt.Key.Key_PageUp, Qt.Key.Key_PageDown):
                self.board.canvas.go_board(-1 if k == Qt.Key.Key_PageUp else 1)
            elif k == Qt.Key.Key_F:
                self.board.canvas.fit_content()
        elif k in (Qt.Key.Key_Right, Qt.Key.Key_PageDown, Qt.Key.Key_Space, Qt.Key.Key_Down):
            self.view.next()
        elif k in (Qt.Key.Key_Left, Qt.Key.Key_PageUp, Qt.Key.Key_Up):
            self.view.prev()
        elif k == Qt.Key.Key_Home:
            self.view.go(0)
        elif k == Qt.Key.Key_End:
            self.view.go(self.view.pages - 1)
        elif k == Qt.Key.Key_G:
            self.toggle_grid()
        elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.view.sel is not None:
            self.selection_to_board()
        elif k == Qt.Key.Key_Q and self.view.sel is not None:
            self.selection_search()
        elif k == Qt.Key.Key_T and self.view.sel is not None:
            self.selection_question()
        elif k in (Qt.Key.Key_V, Qt.Key.Key_P, Qt.Key.Key_H, Qt.Key.Key_E, Qt.Key.Key_S, Qt.Key.Key_L):
            self.set_tool({Qt.Key.Key_V: "pointer", Qt.Key.Key_P: "pen", Qt.Key.Key_H: "marker", Qt.Key.Key_E: "eraser", Qt.Key.Key_S: "select",Qt.Key.Key_L:"laser"}[k])
        else:
            super().keyPressEvent(e)

    def _escape(self):
        """Esc 一层层退：选区 → 查询 → 工具 → 黑板 → 退出。"""
        if self.view.sel is not None or self.view.sel_drag is not None:
            self.view.clear_selection()
        elif self.panel.isVisible():
            self.panel.close_panel()
        elif self.view_mode == "board":
            self.set_view("slide")
        elif self.view.tool != "pointer":
            self.set_tool("pointer")
        else:
            self.close()

    def mouseMoveEvent(self, e):  # noqa: N802
        self._wake()
        super().mouseMoveEvent(e)

    # ---- 保存
    def show_storage_error(self, text):
        self.storage_notice.setText("笔迹保存提示：" + text)
        self.storage_notice.show()

    def _schedule_save(self):
        self.saver.start(600)

    def save(self):
        try:
            self.ink_store.save(dict(self.ink_store.data, pages=self.view.ink_data()))
        except (OSError, ValueError) as exc:
            self.show_storage_error(str(exc))
        self.board.canvas.commit_editor()
        self.board.canvas.save()

    def closeEvent(self, e):  # noqa: N802
        self.closing = True
        self.save()
        self.ocr.stop()
        self.panel.engine.cancel()
        if self.view.fast is not None:
            self.view.fast.close()
        self.live.stop()   # 让演示软件自己退出放映、关掉临时副本（不强杀）
        if self.detached is not None:
            self.detached.close()
        e.accept()


def open_player(meta, parent_window=None, bus=None) -> LecturePlayer:
    p = LecturePlayer(meta,bus=bus)
    p.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
    if parent_window is not None and parent_window.screen() is not None:
        p.setGeometry(parent_window.screen().geometry())
    p.showFullScreen()
    p.raise_()
    p.activateWindow()
    p.setFocus()
    return p


_ = (QColor, QImage, QMessageBox)
