"""WPS / PowerPoint 原生放映：让演示软件自己放（动画、切换、视频都是它放的），放映窗口嵌在见微的课件区里。

做法（2.12 实测于 WPS 演示，本机没有 Microsoft Office）：
- 一个常驻的 PowerShell 进程用 COM 打开课件、全屏放映，从标准输入读命令（next / prev / goto 张 次 / state / quit），
  每次回一行状态「S 张 第几次单击 共几次 状态」。
- WPS 不支持窗口放映、也不给放映窗口的句柄：按窗口标题找到放映窗口，SetParent 成见微课件区里的子窗口，
  见微的放映条、提示条都是原生子窗口，排在它上面。
- 见微原来的放映（PageView）一直在下面跟着同步到同一个画面。拿笔、框选、放大，或者这一页已经写了字，
  就把原生窗口收起来，露出同一画面的图（这些图本来就是演示软件导出的），笔迹、框选、黑板照旧可用；
  笔迹清掉或翻到没写字的页，再回到原生放映。
- 演示软件崩溃、放映被关掉，自动回到见微自己的放映。

注意：PowerShell 从 QProcess 读标准输入会整段缓冲，所以这里用 subprocess 的匿名管道。
"""
from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QCursor, QPainterPath, QRegion
from PySide6.QtWidgets import QWidget

NO_WINDOW = 0x08000000
LIVE_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$src = $env:JW_SRC; $engine = $env:JW_ENGINE
$proc = @{ 'PowerPoint.Application'='POWERPNT'; 'KWPP.Application'='wpp' }[$engine]
$running = @(Get-Process $proc -ErrorAction SilentlyContinue).Count -gt 0
$stdin = New-Object IO.StreamReader([Console]::OpenStandardInput(), [Text.Encoding]::UTF8)
$app = $null; $doc = $null; $win = $null
function Say($s) { [Console]::Out.WriteLine($s); [Console]::Out.Flush() }
function State {
  $idx = -1; $clk = -1; $cnt = -1; $st = -1
  try { $st = [int]$win.View.State } catch { Say 'GONE'; return $false }
  try { $idx = [int]$win.View.Slide.SlideIndex } catch {}
  try { $clk = [int]$win.View.GetClickIndex() } catch {}
  try { $cnt = [int]$win.View.GetClickCount() } catch {}
  Say "S $idx $clk $cnt $st"
  return $true
}
try {
  $app = New-Object -ComObject $engine
  try { $app.DisplayAlerts = 0 } catch {}
  $doc = $app.Presentations.Open($src, -1, 0, -1)
  $hid = @()
  for ($i = 1; $i -le $doc.Slides.Count; $i++) { try { if ($doc.Slides.Item($i).SlideShowTransition.Hidden -ne 0) { $hid += $i } } catch {} }
  Say ("OPEN " + $doc.Slides.Count + " " + ($hid -join ','))
  try { $app.Visible = -1 } catch {}
  $ss = $doc.SlideShowSettings
  try { $ss.ShowType = 1 } catch {}
  try { $ss.ShowWithAnimation = -1 } catch {}
  try { $ss.LoopUntilStopped = 0 } catch {}
  try { $win = $ss.Run() } catch {}
  $t0 = Get-Date
  while (-not $win -and ((Get-Date) - $t0).TotalSeconds -lt 12) {
    Start-Sleep -Milliseconds 100
    try { if ($app.SlideShowWindows.Count -gt 0) { $win = $app.SlideShowWindows.Item(1) } } catch {}
  }
  if (-not $win) { Say 'FAIL 演示软件没有开始放映'; exit 1 }
  # 全屏放映先挪到屏幕外，等见微把它嵌进来，免得整屏闪一下
  try { $win.Left = -30000 } catch {}
  $h = 0; try { $h = [int64]$win.HWND } catch {}
  Say "SHOW $h"
  try { $doc.Windows.Item(1).WindowState = 2 } catch {}
  [void](State)
  while ($true) {
    $line = $stdin.ReadLine()
    if ($null -eq $line -or $line -eq 'quit') { break }
    $p = $line.Split(' ')
    try {
      switch ($p[0]) {
        'next' { $win.View.Next() }
        'prev' { $win.View.Previous() }
        'goto' {
          # WPS 的 GotoClick 不生效：同一张往后就只点几下；否则从这张开头点过去
          $want = [int]$p[1]; $k = [int]$p[2]
          $cur = -1; $clk = 0
          try { $cur = [int]$win.View.Slide.SlideIndex; $clk = [int]$win.View.GetClickIndex() } catch {}
          if ($cur -ne $want -or $clk -gt $k) { $win.View.GotoSlide($want); $clk = 0 }
          for ($j = $clk; $j -lt $k; $j++) { $win.View.Next() }
        }
      }
    } catch { Say "ERR $($_.Exception.Message)" }
    if (-not (State)) { break }
  }
} catch {
  Say "FAIL $($_.Exception.Message)"
} finally {
  try { if ($win) { $win.View.Exit() } } catch {}
  try { if ($doc) { $doc.Saved = -1; $doc.Close() } } catch {}
  try { if ($app -and -not $running -and $app.Presentations.Count -eq 0) { $app.Quit() } } catch {}
  try { if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) } } catch {}
  [GC]::Collect()
  Say 'BYE'
}
"""
SHOW_TITLES = ("slide show", "幻灯片放映", "放映")
OFFICE_EXE = ("wpp.exe", "wps.exe", "powerpnt.exe")
PP_DONE = 5   # ppSlideShowDone：放完后的黑屏


# ---------------------------------------------------------------- Win32
if sys.platform == "win32":
    import ctypes.wintypes as wt
    u32 = ctypes.windll.user32
    k32 = ctypes.windll.kernel32
    u32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    u32.GetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int]
    u32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
    u32.SetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_ssize_t]
    u32.SetParent.argtypes = [wt.HWND, wt.HWND]
    u32.SetParent.restype = wt.HWND
    u32.MoveWindow.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.BOOL]
    u32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
    u32.IsWindow.argtypes = [wt.HWND]
    u32.IsWindowVisible.argtypes = [wt.HWND]
    u32.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
    u32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
    u32.SetFocus.argtypes = [wt.HWND]
    u32.RedrawWindow.argtypes = [wt.HWND, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint]
    u32.GetFocus.restype = wt.HWND


def _exe_of(pid: int) -> str:
    h = k32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(520)
        n = wt.DWORD(520)
        if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
            return os.path.basename(buf.value).lower()
        return ""
    finally:
        k32.CloseHandle(h)


def top_windows():
    """[(hwnd, pid, 标题, 可见)]：所有顶层窗口。"""
    out = []
    PROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)

    def cb(h, _):
        pid = wt.DWORD()
        u32.GetWindowThreadProcessId(h, ctypes.byref(pid))
        title = ctypes.create_unicode_buffer(300)
        u32.GetWindowTextW(h, title, 300)
        out.append((int(h or 0), pid.value, title.value, bool(u32.IsWindowVisible(h))))
        return True
    u32.EnumWindows(PROC(cb), 0)
    return out


def find_show_window(stem: str) -> int:
    """按标题找放映窗口：标题里有「放映 / Slide Show」和我们给的文件名。"""
    stem = stem.lower()
    for h, _pid, title, _vis in top_windows():
        t = title.lower()
        if stem in t and any(k in t for k in SHOW_TITLES):
            return h
    return 0


def office_windows_visible():
    """演示软件进程现在可见的顶层窗口（用来收起放映时它自己弹出来的主页窗口）。"""
    exe = {}
    out = set()
    for h, pid, _t, vis in top_windows():
        if not vis:
            continue
        if pid not in exe:
            exe[pid] = _exe_of(pid)
        if exe[pid] in OFFICE_EXE:
            out.add(h)
    return out


# ---------------------------------------------------------------- 驱动
class LiveShow(QObject):
    """一个演示软件放映进程。信号都在主线程里发。"""
    opened = Signal(int, list)          # 幻灯片总数，隐藏的幻灯片（从 1 数）
    shown = Signal(int)                 # 放映窗口句柄（0 表示演示软件不给，要按标题找）
    state = Signal(int, int, int, int)  # 第几张（从 1 数）、第几次单击、共几次、放映状态
    failed = Signal(str)
    ended = Signal()
    _line = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.proc = None
        self.pending = 0
        self.sent = []          # 发出去还没回的命令（按顺序回）
        self.answered = ""      # 刚收到的这行状态是回哪条命令的
        self.alive = False
        self._line.connect(self._on_line)

    def start(self, src: Path, engine: str) -> None:
        tmp = Path(os.environ.get("TEMP") or os.environ.get("TMP") or ".") / "jianwei-live"
        tmp.mkdir(parents=True, exist_ok=True)
        script = tmp / "live.ps1"
        script.write_bytes(b"\xef\xbb\xbf" + LIVE_SCRIPT.encode("utf-8"))
        env = dict(os.environ, JW_SRC=str(src), JW_ENGINE=engine)
        env.pop("QT_QPA_PLATFORM", None)
        self.proc = subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, bufsize=0,
                                     creationflags=NO_WINDOW)
        self.alive = True
        threading.Thread(target=self._read, daemon=True, name="lecture-live").start()

    def _read(self):
        proc = self.proc
        try:
            for raw in proc.stdout:
                self._line.emit(raw.decode("utf-8", "replace").strip())
        except (OSError, ValueError, RuntimeError):
            pass
        try:
            self._line.emit("EOF")
        except RuntimeError:
            pass

    def _on_line(self, line: str):
        head, _, rest = line.partition(" ")
        if head == "S":   # 每条命令最后都回一行 S（出错时先多一行 ERR）
            self.answered = self.sent.pop(0) if self.sent else "start"
        if head == "S":
            self.pending = max(0, self.pending - 1)
            try:
                a, b, c, d = (int(x) for x in rest.split())
            except ValueError:
                return
            self.state.emit(a, b, c, d)
        elif head == "OPEN":
            parts = rest.split(" ")
            hidden = [int(x) for x in (parts[1].split(",") if len(parts) > 1 and parts[1] else [])]
            self.opened.emit(int(parts[0]), hidden)
        elif head == "SHOW":
            self.shown.emit(int(rest or 0))
        elif head == "FAIL":
            self.failed.emit(rest)
        elif head in ("GONE", "BYE", "EOF"):
            if self.alive:
                self.alive = False
                self.ended.emit()

    def send(self, cmd: str) -> bool:
        if not self.alive or self.proc is None or self.proc.poll() is not None:
            return False
        try:
            self.proc.stdin.write((cmd + "\n").encode("utf-8"))
            self.proc.stdin.flush()
        except (OSError, ValueError):
            return False
        self.pending += 1
        self.sent.append(cmd.split(" ")[0])
        return True

    def stop(self, wait: float = 0.0) -> None:
        """让驱动自己退出放映、关课件（不强杀进程）。"""
        self.alive = False
        proc = self.proc
        if proc is None or proc.poll() is not None:
            return
        try:
            proc.stdin.write(b"quit\n")
            proc.stdin.flush()
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        if wait:
            try:
                proc.wait(wait)
            except subprocess.TimeoutExpired:
                pass


# ---------------------------------------------------------------- 和播放器对接
def source_of(folder: Path):
    for ext in (".pptx", ".pptm", ".ppsx", ".ppsm", ".ppt", ".pps", ".dps"):
        f = folder / ("source" + ext)
        if f.is_file():
            return f
    return None


def engine_for_live():
    from . import convert
    names = convert.engines_for(".pptx") if sys.platform == "win32" else []
    return names[0] if names else None


def round_mask(w: QWidget, r: float) -> None:
    """原生子窗口没有透明边：圆角放映条用遮罩切出圆角，不露出方角。"""
    path = QPainterPath()
    path.addRoundedRect(QRectF(w.rect()), r, r)
    w.setMask(QRegion(path.toFillPolygon().toPolygon()))


class LiveController(QObject):
    """把演示软件的放映和见微的放映器对上。"""
    changed = Signal()   # 开 / 关 / 能不能用变了

    def __init__(self, player):
        super().__init__(player)
        self.p = player
        self.view = player.view
        self.show = None
        self.hwnd = 0
        self.running = False      # 放映进程活着
        self.embedded = False
        self.visible = False
        self.base_orig = None     # 原课件第 i 张（不含隐藏）→ 演示软件里第几张
        self.stem = ""
        self.syncing = False
        self.want_show = False
        self.last_state = None
        self.last_cursor = None
        self.before_windows = set()
        self.started_at = 0.0
        self.engine = None
        self.box = None   # 嵌放映窗口的原生容器：真用到时才建（建了课件区就成了原生窗口）
        self.view.installEventFilter(self)
        self.tick = QTimer(self)
        self.tick.timeout.connect(self._tick)
        self.poll = QTimer(self)
        self.poll.timeout.connect(self._poll)
        self.finder = QTimer(self)
        self.finder.timeout.connect(self._find)
        self.push = QTimer(self)
        self.push.setSingleShot(True)
        self.push.timeout.connect(self._push_frame)

    # ---- 能不能用
    def available(self) -> bool:
        if sys.platform != "win32" or self.view.kind != "slides":
            return False
        if source_of(self.p.dir) is None:
            return False
        if self.engine is None:
            self.engine = engine_for_live() or ""
        return bool(self.engine)

    def label(self) -> str:
        from . import convert
        return convert.label(self.engine) if self.engine else "演示软件"

    # ---- 开关
    def start(self) -> bool:
        if self.running or not self.available():
            return False
        src = source_of(self.p.dir)
        live_dir = self.p.dir / "live"
        live_dir.mkdir(exist_ok=True)
        self.stem = f"见微放映-{self.p.meta['id']}"
        copy = live_dir / (self.stem + src.suffix.lower())
        try:
            shutil.copyfile(src, copy)
        except OSError as exc:   # 上次的还开着（文件被占用）就直接用
            if not copy.is_file():
                self.p.toast(f"打不开原课件：{exc}")
                return False
        self.before_windows = office_windows_visible()
        self.show = LiveShow(self)
        self.show.opened.connect(self._opened)
        self.show.shown.connect(self._shown)
        self.show.state.connect(self._state)
        self.show.failed.connect(lambda why: self._fallback(f"{self.label()}没能放映：{why}"))
        self.show.ended.connect(lambda: self._fallback(f"{self.label()} 放映已结束，回到见微放映"))
        self.running = True
        self.started_at = time.time()
        self.show.start(copy, self.engine)
        self.p.toast(f"正在用 {self.label()} 打开放映…", 6000)
        self.tick.start(100)
        self.changed.emit()
        return True

    def stop(self, wait: float = 0.0) -> None:
        if self.show is not None:
            self.show.stop(wait)
        self._teardown()

    def _teardown(self):
        self.running = self.embedded = self.visible = False
        self.want_show = False
        self.hwnd = 0
        self._size = None
        self.last_state = None
        self.base_orig = None
        for t in (self.tick, self.poll, self.finder, self.push):
            t.stop()
        if self.box is not None:
            self.box.hide()
        self.view.update()
        self.changed.emit()

    def _fallback(self, why: str):
        if not self.running:
            return
        self.stop()
        self.p.toast(why, 3500)

    # ---- 驱动回来的消息
    def _opened(self, count, hidden):
        visible = [i for i in range(1, count + 1) if i not in set(hidden)]
        base = (self.p.base_timeline or {}).get("slides")
        n = len(base) if base else self.p.base_doc.pageCount()
        if len(visible) != n:
            self._fallback(f"{self.label()} 里的幻灯片张数和见微转换的对不上（{len(visible)} / {n}），先用见微放映")
            return
        self.base_orig = visible

    def _shown(self, hwnd):
        self.hwnd = hwnd if hwnd and u32.IsWindow(hwnd) else 0
        if self.hwnd:
            self._embed()
        else:
            self.finder.start(30)
            self._find_deadline = time.time() + 8

    def _find(self):
        h = find_show_window(self.stem)
        if h:
            self.finder.stop()
            self.hwnd = h
            self._embed()
        elif time.time() > self._find_deadline:
            self.finder.stop()
            self._fallback("没找到放映窗口，先用见微放映")

    def _embed(self):
        if self.box is None:
            self.box = QWidget(self.view)
            self.box.setAttribute(Qt.WidgetAttribute.WA_NativeWindow, True)
            self.box.setStyleSheet("background:#000;")
            self.box.hide()
        h = self.hwnd
        style = u32.GetWindowLongPtrW(h, -16)
        style = (style & ~(0x80000000 | 0x00C00000 | 0x00040000)) | 0x40000000   # 去掉 POPUP/CAPTION/THICKFRAME，加 CHILD
        u32.SetWindowLongPtrW(h, -16, style)
        u32.SetParent(h, int(self.box.winId()))
        self.embedded = True
        self.p.go_native_overlays()
        self._place()
        u32.ShowWindow(h, 5)
        QTimer.singleShot(400, self._hide_popups)
        QTimer.singleShot(1500, self._hide_popups)
        self.p.toast(f"{self.label()} 原生放映 · 拿笔或框选时换成同一画面的图", 2600)
        self.poll.start(450)
        self._push_frame()   # 跳到见微当前的页
        self.changed.emit()

    def _hide_popups(self):
        """放映时演示软件会把自己的主页窗口也弹出来：只收起这次新冒出来的。"""
        if not self.running:
            return
        for h in office_windows_visible() - self.before_windows:
            if h != self.hwnd:
                u32.ShowWindow(h, 0)
        self.p.window().activateWindow()

    def _state(self, idx, click, count, st):
        if not self.running or self.sender() is not self.show:
            return   # 已经关掉的那一次放映，晚到的消息不管
        if st == PP_DONE:   # 放到最后又点了一下：退回最后一页，别让它结束
            self.show.send("prev")
            return
        # 回的是「state」询问、画面却变了：是有人直接在放映画面上点的
        changed_by_show = self.show.answered == "state" and self.last_state is not None and (idx, click) != self.last_state[:2]
        self.last_state = (idx, click, count)
        frame = self._frame_for(idx, click)
        if frame is None:
            return
        # 只有原生放映正显示着（或刚跳过去、等它跟上）才让见微跟着它走；
        # 收起时是见微自己在放，演示软件的位置不算数，稍后由 _push_frame 拉过去
        follow = self.visible or (self.want_show and (frame == self.view.frame or self.show.answered == "goto"))
        if follow and frame != self.view.frame:
            self.syncing = True
            try:
                self.view.sync_frame(frame)
            finally:
                self.syncing = False
        if changed_by_show and self.visible:   # 是在放映画面上点的：把键盘拿回来，快捷键照常
            self.p.reclaim_focus()
        if self.want_show and follow:
            self.want_show = False
            self._apply(True)

    # ---- 张、步 对照
    def _base_frames(self, i):
        tl = self.p.base_timeline
        if not tl:
            return [dict(auto=False)]
        return [f for f in tl["frames"] if f["slide"] == i]

    def _frame_for(self, idx, click):
        if not self.base_orig or idx not in self.base_orig:
            return None
        bi = self.base_orig.index(idx)
        slides = self.view.slides
        j = next((k for k, s in enumerate(slides) if s.get("key", f"s:{k}") == f"s:{bi}"), None)
        if j is None:
            return None
        frames = self._base_frames(bi)
        step, clicks = 0, 0
        for s in range(1, len(frames)):
            if not frames[s].get("auto"):
                clicks += 1
                if clicks > max(0, click):
                    break
            step = s
        sl = slides[j]
        return min(sl["first"] + step, sl["last"])

    def _target(self):
        """见微当前画面 → (演示软件第几张, 第几次单击)；插进来的页没有对应，返回 None。"""
        if not self.base_orig:
            return None
        sl = self.view.slides[self.view.page]
        key = sl.get("key", f"s:{self.view.page}")
        if not key.startswith("s:"):
            return None
        bi = int(key[2:])
        if bi >= len(self.base_orig):
            return None
        frames = self._base_frames(bi)
        step = self.view.frame - sl["first"]
        clicks = sum(1 for s in range(1, min(step, len(frames) - 1) + 1) if not frames[s].get("auto"))
        return self.base_orig[bi], clicks

    def _push_frame(self):
        t = self._target()
        if t is not None and self.running and self.embedded:
            if self.last_state is None or self.last_state[:2] != t:
                self.show.send(f"goto {t[0]} {t[1]}")

    # ---- 放映器那边的事
    def nav(self, kind, arg=None) -> bool:
        """PageView 翻页前先问这里：原生放映正显示着，就交给演示软件。"""
        if not self.visible:
            return False
        if kind == "next":
            self.show.send("next")
        elif kind == "prev":
            self.show.send("prev")
        elif kind == "go":
            sl = self.view.slides[max(0, min(len(self.view.slides) - 1, arg))]
            key = sl.get("key", f"s:{arg}")
            if not key.startswith("s:") or not self.base_orig:
                return False
            self.show.send(f"goto {self.base_orig[int(key[2:])]} 0")
        elif kind == "auto":
            pass   # 自动接续的动画由演示软件自己放
        return True

    def frame_changed(self):
        """见微自己翻了页（原生放映没显示的时候）：演示软件稍后跟过来。"""
        if self.running and self.embedded and not self.syncing and not self.visible:
            self.push.start(160)

    def should_show(self) -> bool:
        v, p = self.view, self.p
        if not (self.running and self.embedded and self.hwnd):
            return False
        if p.view_mode == "board" or not v.isVisible() or v.tool != "pointer" or v.zoom != 1.0:
            return False
        if v.sel is not None or v.sel_drag is not None or v.history().strokes or v.active is not None:
            return False
        return self._target() is not None

    def _apply(self, on):
        self.visible = on
        if self.box is None:
            self.visible = False
            return
        if on:
            self._place()
            self.box.show()
            self.box.raise_()
            self.p.raise_overlays()
        else:
            self.box.hide()
        self.view.update()

    def _tick(self):
        if not self.running:
            return
        if self.show is not None and self.show.proc is not None and self.show.proc.poll() is not None and self.show.alive:
            self.show.alive = False
            self._fallback(f"{self.label()} 放映进程退出了，回到见微放映")
            return
        want = self.should_show()
        if want and not self.visible and not self.want_show:
            t = self._target()
            if self.last_state is not None and self.last_state[:2] == t:
                self._apply(True)
            else:
                self.want_show = True
                self._push_frame()
        elif not want:
            self.want_show = False
            if self.visible:
                self._apply(False)
        if self.visible:
            pos = QCursor.pos()
            if self.last_cursor is not None and pos != self.last_cursor and self.box.geometry().contains(self.box.parentWidget().mapFromGlobal(pos)):
                self.p._wake()
            self.last_cursor = pos

    def _poll(self):
        if self.running and self.embedded and self.show.pending == 0:
            self.show.send("state")

    def _place(self):
        if not self.hwnd or self.box is None:
            return
        r = self.view.page_rect().toAlignedRect() if self.view.pages else self.view.rect()
        self.box.setGeometry(r)
        d = self.box.devicePixelRatioF()
        size = (max(1, int(r.width() * d)), max(1, int(r.height() * d)))
        if size != getattr(self, "_size", None):
            self._size = size
            u32.MoveWindow(self.hwnd, 0, 0, size[0], size[1], True)
            # 演示软件换了尺寸不一定马上重画：催它一下（隐藏时尺寸没变，不用催）
            u32.RedrawWindow(self.hwnd, None, None, 0x0001 | 0x0004 | 0x0080 | 0x0100)   # INVALIDATE|ERASE|ALLCHILDREN|UPDATENOW
            QTimer.singleShot(250, lambda: self.hwnd and u32.RedrawWindow(self.hwnd, None, None, 0x0001 | 0x0080 | 0x0100))

    def eventFilter(self, obj, e):  # noqa: N802
        if obj is self.view and e.type() in (QEvent.Type.Resize, QEvent.Type.Show) and self.embedded:
            QTimer.singleShot(0, self._place)
        return False
