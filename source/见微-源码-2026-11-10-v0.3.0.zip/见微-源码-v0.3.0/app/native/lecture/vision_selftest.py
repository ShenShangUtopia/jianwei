"""Vision transport and selection lifecycle; fake API only, no credentials/network."""
import json
import os
import time
from pathlib import Path
from ..kit import test_runtime

test_runtime.configure()


def main(target):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    app = test_runtime.application([])
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage
    from .vision import Reader, VisionError
    from .panel import LookupPanel
    out = Path(target)
    out.mkdir(parents=True,exist_ok=True)
    calls = []
    state = dict(status=200,text='Br₂ 与 C=O',query='溴 碳氧双键',uncertainty='')
    class Response:
        closed = False
        @property
        def status_code(self):
            return state['status']
        def json(self):
            return dict(choices=[dict(message=dict(content=json.dumps({k:state[k] for k in ('text','query','uncertainty')},ensure_ascii=False)))])
        def close(self):
            self.closed = True
    replies = []
    def post(url,**kwargs):
        calls.append((url,kwargs))
        reply=Response()
        replies.append(reply)
        return reply
    ds = dict(key='FAKE_TEST_TOKEN',base='https://example.invalid',model='deepseek-chat')
    reader = Reader(lambda:ds,post)
    image = QImage(400,120,QImage.Format.Format_ARGB32)
    image.fill(Qt.GlobalColor.white)
    result = reader.read(image)
    assert result['text']=='Br₂ 与 C=O'
    payload = calls[-1][1]['json']
    assert payload['model']=='deepseek-flash'
    assert payload['thinking']=={'type':'disabled'}
    content=payload['messages'][1]['content']
    assert content[1]['image_url']['url'].startswith('data:image/png;base64,')
    assert replies[-1].closed
    assert reader.read(image)['cached'] and len(calls)==1
    for i in range(14):
        reader.read(image,str(i))
    assert len(reader.cache)==12
    for status in (400,401,429,500):
        state['status']=status
        try:
            reader.read(image,str(status))
            raise AssertionError('HTTP failure accepted')
        except VisionError as exc:
            assert 'FAKE_TEST_TOKEN' not in str(exc)
    state['status']=200
    try:
        reader.read(image,cancel=lambda:True)
        raise AssertionError('cancel ignored')
    except VisionError:
        pass
    import requests
    def timed_out(*args,**kwargs):raise requests.Timeout('test')
    try:
        Reader(lambda:ds,timed_out).read(image)
        raise AssertionError('timeout accepted')
    except VisionError:
        pass
    state['text']=[]
    try:
        reader.read(image,'invalid-json-fields')
        raise AssertionError('invalid text accepted')
    except VisionError:
        pass
    state['text']='Br₂ 与 C=O'
    class Ocr:
        status='ready'
        def read(self,_image):return '本机识别回退'
        def problem(self):return ''
    panel=LookupPanel(Ocr())
    panel.vision=reader
    queries=[]
    panel._go=lambda query:queries.append(query)
    panel._local_diagram=lambda text:None
    def spin_until(check):
        until=time.monotonic()+4
        while not check() and time.monotonic()<until:
            app.processEvents()
            time.sleep(.005)
        assert check()
    panel.start(image,'')
    spin_until(lambda:bool(queries))
    assert queries[-1]=='溴碳氧双键' and panel.text=='Br₂ 与 C=O'
    assert panel.transcript_btn.isEnabled()
    state['uncertainty']='双键右侧标签模糊'
    panel.vision=Reader(lambda:ds,post)
    queries.clear()
    panel.recognize_image()
    spin_until(lambda:'需核对' in panel.recognition_note.text())
    assert not queries and '标签模糊' in panel.recognition_note.text()
    state['status']=400
    panel.recognize_image()
    spin_until(lambda:bool(queries))
    assert queries[-1]=='本机识别回退' and '回退' in panel.recognition_note.text()
    old=panel.ticket
    panel.close_panel()
    panel._on_recognized(old,dict(text='过期内容',query='错误查询'))
    assert panel.text!='过期内容'
    # A new/manual query invalidates a delayed image result.
    panel.start(image,'现有文字快速查询')
    old=panel.ticket
    panel.edit.setText('手动修改查询')
    panel.search_now()
    panel._on_recognized(old,dict(text='旧截图结果',query='旧结果'))
    assert queries[-1]=='手动修改查询'
    panel.resize(470,720)
    panel.show()
    app.processEvents()
    panel.grab().save(str(out/'vision-panel.png'))
    panel.close_panel()
    panel.deleteLater()
    print('VISION OK image transport, model, cache bounds, HTTP failures, uncertainty review, OCR fallback, stale and manual query protection; no network',flush=True)
    return 0
