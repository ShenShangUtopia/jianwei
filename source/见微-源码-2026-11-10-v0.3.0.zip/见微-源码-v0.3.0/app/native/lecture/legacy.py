"""没有 Office / WPS 时读旧格式：.ppt、.doc（二进制）、.rtf。

能取到文字、位置和图片，排成简化版可放映的页面；字体、配色和动画取不到，按默认样式显示。
Office 或 WPS 在的时候不走这里。
"""
from __future__ import annotations

import re
import struct
import zlib
from pathlib import Path

from PySide6.QtCore import QMarginsF, QRectF, QSizeF, Qt
from PySide6.QtGui import QColor, QFont, QImage, QPageLayout, QPageSize, QPainter, QPdfWriter, QTextDocument, QTextCursor, QTextImageFormat, QTextOption

FREE = {0xFFFFFFFF, 0xFFFFFFFE}


class Cfb:
    """OLE 复合文档（旧版 Office 文件的外壳）。"""

    def __init__(self, data: bytes):
        if data[:8] != b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            raise ValueError("不是旧版 Office 文件")
        self.d = data
        self.ss = 1 << struct.unpack_from("<H", data, 30)[0]
        self.ms = 1 << struct.unpack_from("<H", data, 32)[0]
        nfat, dirs, _, self.cut, minifat, nmini, difat, ndifat = struct.unpack_from("<IIIIIIII", data, 44)
        ids = list(struct.unpack_from("<109I", data, 76))
        s = difat
        for _ in range(ndifat):
            if s in FREE:
                break
            vals = struct.unpack_from(f"<{self.ss // 4}I", self.sector(s))
            ids.extend(vals[:-1])
            s = vals[-1]
        self.fat = []
        for i in ids[:nfat] if nfat <= len(ids) else ids:
            if i not in FREE:
                self.fat.extend(struct.unpack_from(f"<{self.ss // 4}I", self.sector(i)))
        raw = self.chain(dirs)
        self.entries = {}
        root_start, root_size = 0, 0
        for o in range(0, len(raw) - 127, 128):
            n = struct.unpack_from("<H", raw, o + 64)[0]
            if n < 2:
                continue
            name = raw[o:o + n - 2].decode("utf-16-le", "replace")
            kind = raw[o + 66]
            start, size = struct.unpack_from("<II", raw, o + 116)
            if kind == 5:
                root_start, root_size = start, size
            elif kind == 2:
                self.entries.setdefault(name, (start, size))
        self.mini = self.chain(root_start)[:root_size] if root_size else b""
        self.minifat = []
        if nmini and minifat not in FREE:
            m = self.chain(minifat)
            self.minifat = list(struct.unpack(f"<{len(m) // 4}I", m[:len(m) // 4 * 4]))

    def sector(self, i):
        o = (i + 1) * self.ss
        return self.d[o:o + self.ss]

    def chain(self, s):
        out, seen = [], set()
        while s not in FREE and s < len(self.fat) and s not in seen:
            seen.add(s)
            out.append(self.sector(s))
            s = self.fat[s]
        return b"".join(out)

    def stream(self, name) -> bytes:
        if name not in self.entries:
            return b""
        s, size = self.entries[name]
        if size < self.cut:
            out, seen = [], set()
            while s not in FREE and s < len(self.minifat) and s not in seen:
                seen.add(s)
                out.append(self.mini[s * self.ms:(s + 1) * self.ms])
                s = self.minifat[s]
            return b"".join(out)[:size]
        return self.chain(s)[:size]


# ================================================================ .ppt
CONTAINER = 0xF


def _records(buf, start=0, end=None):
    o, end = start, len(buf) if end is None else end
    while o + 8 <= end:
        vi, typ, ln = struct.unpack_from("<HHI", buf, o)
        if ln > end - o - 8:
            ln = end - o - 8
        yield vi, typ, o + 8, ln
        o += 8 + ln


def _find(buf, start, end, want):
    for vi, typ, o, ln in _records(buf, start, end):
        if typ == want:
            yield vi, o, ln
        elif vi & 0xF == CONTAINER:
            yield from _find(buf, o, o + ln, want)


def _clean_ppt(s):
    return s.replace("\r", "\n").replace("\x0b", "\n").replace("\x00", "").strip()


def _persist(cfb, doc):
    """最新的「对象号 → 偏移」表；快速保存的文件里同一张幻灯片可能有多个版本。"""
    cur = cfb.stream("Current User")
    table = {}
    if len(cur) < 24:
        return table
    edit = struct.unpack_from("<I", cur, 16)[0]
    seen = set()
    while edit and edit not in seen and edit + 28 <= len(doc):
        seen.add(edit)
        if struct.unpack_from("<H", doc, edit + 2)[0] != 0x0FF5:
            break
        last, pdir = struct.unpack_from("<II", doc, edit + 16)
        ln = struct.unpack_from("<I", doc, pdir + 4)[0]
        o, end = pdir + 8, pdir + 8 + ln
        while o + 4 <= end:
            v = struct.unpack_from("<I", doc, o)[0]
            pid, cnt = v & 0xFFFFF, v >> 20
            o += 4
            for k in range(cnt):
                table.setdefault(pid + k, struct.unpack_from("<I", doc, o)[0])
                o += 4
        edit = last
    return table


def _pictures(cfb, doc):
    """图片库：BSE 序号 → 图片字节。"""
    pics = cfb.stream("Pictures")
    out = {}
    index = 0
    for _vi, o, ln in _find(doc, 0, len(doc), 0xF001):
        for vi, typ, ro, rl in _records(doc, o, o + ln):
            if typ != 0xF007:
                continue
            index += 1
            if rl < 36:
                continue
            delay = struct.unpack_from("<I", doc, ro + 28)[0]
            if delay + 8 > len(pics):
                continue
            _bv, btype, blen = struct.unpack_from("<HHI", pics, delay)
            body = pics[delay + 8:delay + 8 + blen]
            if btype in (0xF01D, 0xF02A, 0xF01E):
                for sig in (b"\xff\xd8\xff", b"\x89PNG"):
                    p = body[:80].find(sig)
                    if p >= 0:
                        out[index] = body[p:]
                        break
            elif btype in (0xF01A, 0xF01B):   # EMF / WMF：压缩存放，头部 16+34 字节
                for skip in (50, 66):
                    try:
                        raw = zlib.decompress(body[skip:])
                    except zlib.error:
                        continue
                    out[index] = ("emf" if btype == 0xF01A else "wmf", raw)
                    break
            elif btype == 0xF01F:             # DIB：补一个 BMP 头
                dib = body[17:]
                if len(dib) > 40:
                    bits = struct.unpack_from("<H", dib, 14)[0]
                    used = struct.unpack_from("<I", dib, 32)[0]
                    offset = 14 + 40 + (used or (1 << bits if bits <= 8 else 0)) * 4
                    out[index] = b"BM" + struct.pack("<IHHI", 14 + len(dib), 0, 0, offset) + dib
    return out


def _shapes(doc, o, ln, outline):
    """一张幻灯片里的形状：(位置, 文字, 文字类型, 图片号)。"""
    out = []
    for _v, so, sl in _find(doc, o, o + ln, 0xF004):
        anchor, text, ttype, pib = None, "", None, None
        for vi, typ, ro, rl in _records(doc, so, so + sl):
            if typ == 0xF010 and rl >= 8:
                top, left, right, bottom = struct.unpack_from("<hhhh", doc, ro)
                anchor = (left, top, right - left, bottom - top)
            elif typ == 0xF00B:
                count = vi >> 4
                for i in range(count):
                    if ro + 6 * i + 6 > ro + rl:
                        break
                    pid, val = struct.unpack_from("<HI", doc, ro + i * 6)
                    if pid & 0x3FFF == 0x0104:
                        pib = val
            elif typ == 0xF00D:
                for _vv, t, a, l in _records(doc, ro, ro + rl):
                    if t == 0x0F9F and l >= 4:
                        ttype = struct.unpack_from("<I", doc, a)[0]
                    elif t == 0x0FA0:
                        text += doc[a:a + l].decode("utf-16-le", "replace")
                    elif t == 0x0FA8:
                        text += doc[a:a + l].decode("cp1252", "replace")
                    elif t == 0x0F9E and l >= 4:
                        n = struct.unpack_from("<I", doc, a)[0]
                        if n < len(outline):
                            ttype, text = outline[n]
        if anchor is not None and anchor[2] > 0 and anchor[3] > 0 and (text.strip() or pib):
            out.append(dict(rect=anchor, text=_clean_ppt(text), type=ttype, pib=pib))
    return out


def ppt_to_pdf(src, out):
    cfb = Cfb(Path(src).read_bytes())
    doc = cfb.stream("PowerPoint Document")
    if not doc:
        raise ValueError("文件里没有幻灯片")
    w, h = 5760, 4320
    for _v, o, ln in _find(doc, 0, len(doc), 0x03E9):
        if ln >= 8:
            w, h = struct.unpack_from("<ii", doc, o)
        break
    table = _persist(cfb, doc)
    pics = _pictures(cfb, doc)
    order = []      # [(persist 引用, [(类型, 文字)...])]
    for vi, typ, o, ln in _records(doc):
        if typ != 0x03E8:
            continue
        for v2, t2, o2, l2 in _records(doc, o, o + ln):
            if t2 != 0x0FF0 or v2 >> 4 != 0:
                continue
            cur = None
            ttype = 1
            for _v3, t3, o3, l3 in _records(doc, o2, o2 + l2):
                if t3 == 0x03F3:
                    cur = [struct.unpack_from("<I", doc, o3)[0], []]
                    order.append(cur)
                elif t3 == 0x0F9F and l3 >= 4:
                    ttype = struct.unpack_from("<I", doc, o3)[0]
                elif cur is not None and t3 == 0x0FA0:
                    cur[1].append((ttype, doc[o3:o3 + l3].decode("utf-16-le", "replace")))
                elif cur is not None and t3 == 0x0FA8:
                    cur[1].append((ttype, doc[o3:o3 + l3].decode("cp1252", "replace")))
        break
    slides = []
    for ref, outline in order:
        off = table.get(ref)
        shapes = []
        if off is not None and off + 8 <= len(doc):
            ln = struct.unpack_from("<I", doc, off + 4)[0]
            shapes = _shapes(doc, off + 8, ln, outline)
        if not shapes:   # 取不到位置时，至少按大纲把字排出来
            y = h * 0.08
            for tt, tx in outline:
                ht = h * (0.16 if tt in (0, 6) else 0.6)
                shapes.append(dict(rect=(int(w * 0.07), int(y), int(w * 0.86), int(ht)), text=_clean_ppt(tx), type=tt, pib=None))
                y += ht
        slides.append(shapes)
    if not slides:
        raise ValueError("文件里没有幻灯片")
    from .builtin import metafiles_to_png
    meta = {k: v for k, v in pics.items() if isinstance(v, tuple)}
    if meta:
        conv = metafiles_to_png(list(meta.values()))
        for k, png in zip(meta, conv):
            pics[k] = png
    pw, ph = w / 8.0, h / 8.0   # 主单位 576 / 英寸，换成磅
    wr = QPdfWriter(str(out))
    wr.setResolution(720)
    wr.setPageLayout(QPageLayout(QPageSize(QSizeF(pw, ph), QPageSize.Unit.Point, "slide", QPageSize.SizeMatchPolicy.ExactMatch), QPageLayout.Orientation.Portrait, QMarginsF(0, 0, 0, 0)))
    p = QPainter(wr)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    k = 10 / 8.0
    for i, shapes in enumerate(slides):
        if i:
            wr.newPage()
        p.fillRect(QRectF(0, 0, pw * 10, ph * 10), QColor("white"))
        for s in shapes:
            r = QRectF(s["rect"][0] * k, s["rect"][1] * k, s["rect"][2] * k, s["rect"][3] * k)
            data = pics.get(s["pib"]) if s["pib"] else None
            if isinstance(data, bytes):
                im = QImage.fromData(data)
                if not im.isNull():
                    p.drawImage(r, im)
            if s["text"]:
                title = s["type"] in (0, 6)
                f = QFont()
                f.setFamilies(["Microsoft YaHei", "SimSun"])
                f.setBold(title)
                size = 32 if title else 20
                lines = s["text"].count("\n") + 1
                while size > 10:   # 放不下就缩小
                    f.setPixelSize(int(size * 10))
                    p.setFont(f)
                    b = p.boundingRect(r.adjusted(60, 40, -60, -40), int(Qt.TextFlag.TextWordWrap), s["text"])
                    if b.height() <= r.height() - 40 + 20 or lines > 30:
                        break
                    size -= 2
                p.setPen(QColor("#111111"))
                op = QTextOption(Qt.AlignmentFlag.AlignHCenter if s["type"] == 6 else Qt.AlignmentFlag.AlignLeft)
                op.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
                p.drawText(r.adjusted(60, 40, -60, -40), s["text"], op)
    p.end()


# ================================================================ .doc
def doc_text(cfb) -> str:
    wd = cfb.stream("WordDocument")
    if len(wd) < 0x01AA:
        raise ValueError("不是 Word 文档")
    flags = struct.unpack_from("<H", wd, 0x0A)[0]
    tbl = cfb.stream("1Table" if flags & 0x0200 else "0Table")
    fc, lcb = struct.unpack_from("<II", wd, 0x01A2)
    clx = tbl[fc:fc + lcb]
    i = 0
    while i < len(clx) and clx[i] == 1:
        i += 3 + struct.unpack_from("<H", clx, i + 1)[0]
    if i >= len(clx) or clx[i] != 2:
        raise ValueError("读不到正文")
    n = struct.unpack_from("<I", clx, i + 1)[0]
    plc = clx[i + 5:i + 5 + n]
    count = (n - 4) // 12
    cps = struct.unpack_from(f"<{count + 1}I", plc, 0)
    out = []
    for k in range(count):
        pos = 4 * (count + 1) + 8 * k
        fcv = struct.unpack_from("<I", plc, pos + 2)[0]
        length = cps[k + 1] - cps[k]
        if fcv & 0x40000000:
            start = (fcv & 0x3FFFFFFF) // 2
            out.append(wd[start:start + length].decode("cp1252", "replace"))
        else:
            out.append(wd[fcv:fcv + length * 2].decode("utf-16-le", "replace"))
    return "".join(out)


def _doc_clean(text):
    # 域：\x13 指令 \x14 结果 \x15，只留结果
    text = re.sub(r"\x13[^\x14\x15]*\x14", "", text)
    text = re.sub(r"\x13[^\x15]*\x15", "", text).replace("\x15", "")
    text = text.replace("\x07\x07", "\n").replace("\x07", "\t").replace("\x0b", "\n")
    return re.sub(r"[\x00\x02-\x06\x08\x0e-\x1f]", "", text)


def _doc_images(cfb):
    """Data 流里的图片，按出现顺序对应正文里的图片占位符。"""
    data = cfb.stream("Data")
    out, o = [], 0
    while True:
        a, b = data.find(b"\xff\xd8\xff", o), data.find(b"\x89PNG\r\n\x1a\n", o)
        c = min(x for x in (a, b, len(data)) if x >= 0)
        if c >= len(data):
            return out
        im = QImage.fromData(data[c:c + 20_000_000])
        out.append(im)
        o = c + 8


def _write_paragraphs(paras, images, out):
    q = QTextDocument()
    q.setDocumentMargin(72)
    q.setUseDesignMetrics(True)
    cur = QTextCursor(q)
    fmt = cur.charFormat()
    fmt.setFontFamilies(["Calibri", "Microsoft YaHei", "SimSun"])
    fmt.setFontPointSize(11)
    cur.setCharFormat(fmt)
    img = iter(images)
    n = 0
    for i, para in enumerate(paras):
        if i:
            cur.insertBlock()
        bf = cur.blockFormat()
        bf.setBottomMargin(6)
        bf.setLineHeight(120, 1)
        cur.setBlockFormat(bf)
        parts = para.split("\x01")
        for j, part in enumerate(parts):
            if j:
                im = next(img, None)
                if im is not None and not im.isNull():
                    n += 1
                    q.addResource(QTextDocument.ResourceType.ImageResource.value, f"i{n}", im)
                    f = QTextImageFormat()
                    f.setName(f"i{n}")
                    k = min(1.0, 440 / max(1, im.width() * 0.75))
                    f.setWidth(im.width() * 0.75 * k)
                    f.setHeight(im.height() * 0.75 * k)
                    cur.insertImage(f)
            if part:
                cur.insertText(part, fmt)
    w = QPdfWriter(str(out))
    w.setPageLayout(QPageLayout(QPageSize(QPageSize.PageSizeId.A4), QPageLayout.Orientation.Portrait, QMarginsF(0, 0, 0, 0)))
    w.setResolution(1200)
    q.print_(w)


def doc_to_pdf(src, out):
    cfb = Cfb(Path(src).read_bytes())
    text = _doc_clean(doc_text(cfb))
    paras = re.split(r"[\r\x0c]", text)
    while paras and not paras[-1].strip():
        paras.pop()
    if not paras:
        raise ValueError("文档是空的")
    _write_paragraphs(paras, _doc_images(cfb), out)


# ================================================================ .rtf
def rtf_to_text(raw: bytes) -> str:
    s = raw.decode("latin-1")
    enc = "gbk"
    m = re.search(r"\\ansicpg(\d+)", s)
    if m:
        enc = "cp" + m.group(1)
    if "\\fcharset134" in s:   # 声明了 GB2312 字体：\\'hh 是中文编码，不管文件头写的代码页
        enc = "gbk"
    out, stack, skip, i, buf = [], [], 0, 0, bytearray()

    def flush():
        if buf:
            out.append(buf.decode(enc, "replace"))
            buf.clear()
    drop = {"fonttbl", "colortbl", "stylesheet", "info", "pict", "header", "footer", "object", "themedata", "datastore", "latentstyles", "listtable", "listoverridetable", "rsidtbl", "generator"}
    n = len(s)
    while i < n:
        c = s[i]
        if c == "{":
            stack.append(skip)
            i += 1
        elif c == "}":
            flush()
            skip = stack.pop() if stack else 0
            i += 1
        elif c == "\\":
            m = re.match(r"\\([a-zA-Z]+)(-?\d+)? ?|\\'([0-9a-fA-F]{2})|\\(.)", s[i:], re.S)
            if not m:
                i += 1
                continue
            i += m.end()
            word, arg, hexv, sym = m.groups()
            if hexv and not skip:
                buf.append(int(hexv, 16))
            elif sym and not skip:
                if sym == "*":
                    skip = 1
                elif sym in "\\{}":
                    flush()
                    out.append(sym)
            elif word:
                if word in drop:
                    skip = 1
                elif skip:
                    pass
                elif word in ("par", "line", "row", "sect", "page"):
                    flush()
                    out.append("\n")
                elif word in ("tab", "cell"):
                    flush()
                    out.append("\t")
                elif word == "u" and arg:
                    flush()
                    v = int(arg)
                    out.append(chr(v + 65536 if v < 0 else v))
                    if i < n and s[i] == "?":
                        i += 1
                    elif s[i:i + 2] == "\\'":
                        i += 4
        else:
            if not skip and c not in "\r\n":
                buf.append(ord(c) & 255)
            i += 1
    flush()
    return "".join(out)


def rtf_to_pdf(src, out):
    text = rtf_to_text(Path(src).read_bytes()).strip()
    if not text:
        raise ValueError("文档是空的")
    _write_paragraphs(text.split("\n"), [], out)
