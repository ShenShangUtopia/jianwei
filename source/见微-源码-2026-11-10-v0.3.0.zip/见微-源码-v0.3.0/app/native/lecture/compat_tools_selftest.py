"""Scientific OOXML and desktop annotation contracts; isolated, no COM/network."""
import json
import sys
import time
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from ..kit import test_runtime
test_runtime.configure()


def fixtures(out):
    from .selftest import make_pptx,make_docx
    from .builtin import A,P,W,M
    ppt=out/'scientific.pptx'
    make_pptx(ppt,n=1)
    with zipfile.ZipFile(ppt) as z:
        data={name:z.read(name) for name in z.namelist()}
    root=ET.fromstring(data['ppt/slides/slide1.xml'])
    sp=root.find('.//'+P+'sp')
    body=sp.find(P+'txBody')
    body.clear()
    ET.SubElement(body,A+'bodyPr',lIns='0',tIns='0',rIns='0',bIns='0')
    ET.SubElement(body,A+'lstStyle')
    paragraphs=[
        [('H',0,'Calibri'),('2',-25000,'Calibri'),('O',0,'Calibri')],
        [('SO',0,'Calibri'),('4',-25000,'Calibri'),('2−',30000,'Calibri')],
        [('abgDW',0,'Symbol')],
        [('⇌ → ± × ≤ ≥ ∑ ∫ ∞ √ 𝑥',0,'Cambria Math')],
    ]
    for parts in paragraphs:
        p=ET.SubElement(body,A+'p')
        pr=ET.SubElement(p,A+'pPr')
        ET.SubElement(pr,A+'defRPr',sz='2800')
        for text,baseline,family in parts:
            r=ET.SubElement(p,A+'r')
            rp=ET.SubElement(r,A+'rPr',baseline=str(baseline))
            ET.SubElement(rp,A+'latin',typeface=family)
            ET.SubElement(r,A+'t').text=text
    p=ET.SubElement(body,A+'p')
    math=ET.SubElement(p,M+'oMath')
    f=ET.SubElement(math,M+'f')
    for name,text in (('num','1'),('den','2')):
        part=ET.SubElement(f,M+name)
        ET.SubElement(ET.SubElement(part,M+'r'),M+'t').text=text
    # Avoid extra original body content; give scientific sample sufficient room.
    xfrm=sp.find(P+'spPr/'+A+'xfrm')
    xfrm.find(A+'ext').set('cy','5200000')
    tree=root.find(P+'cSld/'+P+'spTree')
    for other in list(tree):
        if other.tag==P+'sp' and other is not sp:
            tree.remove(other)
    data['ppt/slides/slide1.xml']=ET.tostring(root,encoding='utf-8')
    with zipfile.ZipFile(ppt,'w') as z:
        for name,raw in data.items():
            z.writestr(name,raw)
    docx=out/'scientific.docx'
    make_docx(docx)
    with zipfile.ZipFile(docx) as z:
        data={name:z.read(name) for name in z.namelist()}
    doc=ET.Element(W+'document')
    body=ET.SubElement(doc,W+'body')
    p=ET.SubElement(body,W+'p')
    for text,vertical in [('H',None),('2','subscript'),('O x',None),('2','superscript')]:
        r=ET.SubElement(p,W+'r')
        pr=ET.SubElement(r,W+'rPr')
        ET.SubElement(pr,W+'sz',{W+'val':'44'})
        if vertical:
            ET.SubElement(pr,W+'vertAlign',{W+'val':vertical})
        ET.SubElement(r,W+'t').text=text
    r=ET.SubElement(p,W+'r')
    ET.SubElement(r,W+'sym',{W+'font':'Symbol',W+'char':'F061'})
    p.append(ET.fromstring(ET.tostring(math)))
    data['word/document.xml']=ET.tostring(doc,encoding='utf-8')
    with zipfile.ZipFile(docx,'w') as z:
        for name,raw in data.items():
            z.writestr(name,raw)
    return ppt,docx


def main(output=None):
    app=test_runtime.application()
    from PySide6.QtCore import QPointF,QRectF,Qt,QCoreApplication,QEvent
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtPdf import QPdfDocument
    from . import builtin,library
    from .rich_symbols import symbol_text,math_text
    from ..kit.desktop_tools import DesktopToolbar,toggle_desktop_tools
    from ..kit.home import home
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    ppt,docx=fixtures(out)
    assert symbol_text('abgDW','Symbol')=='αβγΔΩ'
    assert symbol_text('H2O','Calibri')=='H2O'
    assert math_text(ET.fromstring('<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:f><m:num><m:r><m:t>1</m:t></m:r></m:num><m:den><m:r><m:t>2</m:t></m:r></m:den></m:f></m:oMath>'))=='(1)/(2)'
    deck=builtin.Deck(ppt)
    image=QImage(10,10,QImage.Format.Format_RGB32)
    image.fill(Qt.GlobalColor.white)
    painter=QPainter(image)
    try:
        renderer=builtin.SlidePainter(deck,painter)
        body=deck.part(deck.slides[0]).find('.//'+builtin.P+'txBody')
        area,anchor,layouts,total=renderer._layout_text(body,QRectF(300,300,6500,4600),None,[],dict(master=None,layout=None))
        assert layouts[0][1]['fmts'][1].format.baselineOffset()==-25
        assert layouts[1][1]['fmts'][2].format.baselineOffset()==30
        assert layouts[0][1]['fmts'][0].format.font().pixelSize()==280
        assert layouts[2][1]['text']=='αβγΔΩ'
    finally:
        painter.end()
    for src,convert in ((ppt,builtin.pptx_to_pdf),(docx,builtin.docx_to_pdf)):
        target=out/(src.suffix[1:]+'.pdf')
        convert(src,target)
        doc=QPdfDocument()
        doc.load(str(target))
        assert doc.pageCount()==1
        text=doc.getAllText(0).text()
        assert 'H' in text and '2' in text and 'O' in text and 'α' in text
        assert '(1)/(2)' in text.replace(' ','').replace('\n','')
        from .pageview import render_page
        render_page(doc,0,1440,1080).save(str(out/(src.suffix[1:]+'.png')))
        doc.close()
    first=library.import_file(ppt,use_com=False)
    folder=library.folder(first['id'])
    sentinel=b'{"version":1,"pages":{"0":[]},"synthetic":"keep original ink"}'
    (folder/'ink.json').write_bytes(sentinel)
    copy=library.import_file(ppt,use_com=False,new_copy=True)
    assert copy['id']!=first['id'] and (folder/'ink.json').read_bytes()==sentinel
    from .page import LecturePage
    page=LecturePage()
    page.import_copy(first,False)
    while page.worker is not None:
        app.processEvents()
        if page.worker is not None:
            page.worker.wait(10)
    assert not page.failures and page.last_meta['id']!=first['id']
    assert '重新生成' in page.last_meta['title'] and (folder/'ink.json').read_bytes()==sentinel
    page.resize(1280,850)
    page.show()
    app.processEvents()
    page.grab().save(str(out/'import-modes.png'))
    page.shutdown()
    page.close()
    page.deleteLater()
    QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
    # Delayed status/panel callbacks must not touch destroyed child labels.
    deadline=time.perf_counter()+4.1
    while time.perf_counter()<deadline:
        app.processEvents()
        time.sleep(.005)
    bar=DesktopToolbar()
    bar.open()
    app.processEvents()
    assert bar.isWindow() and bar.parent() is None and bar.isVisible()
    overlay=bar.overlay
    assert overlay.windowFlags() & Qt.WindowType.WindowTransparentForInput
    overlay.set_tool('pen')
    assert not overlay.windowFlags() & Qt.WindowType.WindowTransparentForInput
    overlay._press(QPointF(50,60))
    overlay._move(QPointF(200,160))
    overlay._release()
    assert len(overlay.history().strokes)==1
    overlay.undo()
    assert not overlay.history().strokes
    overlay.redo()
    assert len(overlay.history().strokes)==1
    assert overlay.image().pixelColor(0,0).alpha()==0
    overlay.set_tool('line')
    session=overlay.pen_session
    session._press(QPointF(200,200))
    session._move(QPointF(400,280))
    session._release()
    assert len(overlay.history().strokes)==2
    overlay.clear()
    assert not overlay.history().strokes
    overlay.undo()
    assert len(overlay.history().strokes)==2
    overlay.set_tool('pointer')
    assert overlay.windowFlags() & Qt.WindowType.WindowTransparentForInput
    bar.toggle_ink()
    assert not overlay.isVisible()
    bar.toggle_ink()
    assert overlay.isVisible()
    bar.toggle_ink()
    overlay.set_tool('pen')
    assert overlay.isVisible() and bar.hidden_key.text()=='隐藏笔迹'
    bar.collapse()
    assert not bar.pen_bar.isVisible()
    bar.collapse()
    assert bar.pen_bar.isVisible()
    bar.move(-100000,-100000)
    bar.clamp()
    assert QApplication_available(bar,app)
    bar.grab().save(str(out/'desktop-toolbar.png'))
    overlay.image().save(str(out/'desktop-ink.png'))
    bar.close()
    assert not overlay.isVisible() and not session.fade.isActive()
    bar.open()
    assert overlay.isVisible() and bar.hidden_key.text()=='隐藏笔迹'
    bar.close()
    global_bar=toggle_desktop_tools()
    assert global_bar.isVisible()
    assert toggle_desktop_tools() is global_bar and not global_bar.isVisible()
    future=home()/'desktop-toolbar.json'
    future.write_text('{"v":99,"unknown":"preserve"}',encoding='utf-8')
    before=future.read_bytes()
    future_bar=DesktopToolbar()
    future_bar.close()
    assert future.read_bytes()==before
    from .player import LecturePlayer
    player=LecturePlayer(first)
    player.resize(1024,700)
    player.show()
    player.toggle_bar_pin()
    player._maybe_hide_bar()
    assert player.bar.isVisible() and player.bar_pinned
    player.toggle_pen_group()
    app.processEvents()
    assert player.bar.width()<=player.width()-16
    player.grab().save(str(out/'compact-playbar.png'))
    player.panel.show()
    player._place()
    app.processEvents()
    assert player._pen_wrapped and player.bar.width()<player.width()-player.panel.width()
    for key in (player.pin_key,player.pen_bar.more,player.pen_bar.keys['pen']):
        assert player.bar.rect().contains(key.mapTo(player.bar,key.rect().center()))
    player.grab().save(str(out/'wrapped-playbar.png'))
    player.close()
    report=dict(scientific_formats=True,word_symbol=True,omml_linear=True,original_ink_preserved=True,desktop_flags=True,history=True,transparent_export=True,safe_close=True,toolbar_pinning=True,network=False,office=False,real_external_apps=False)
    (out/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('COMPAT_TOOLS OK scientific formats/PDF glyphs, linear math, copy preserves ink, desktop flags/history/screens/clamp/close, pinned toolbar; no COM/network',flush=True)
    return 0


def QApplication_available(bar,app):
    return any(screen.availableGeometry().contains(bar.frameGeometry().topLeft()) for screen in app.screens())


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
