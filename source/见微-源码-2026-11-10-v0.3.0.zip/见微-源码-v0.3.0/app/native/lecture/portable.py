"""无需 Office 的文本与图片课件转换。"""
from pathlib import Path

from PySide6.QtCore import QMarginsF, QRectF, QSizeF
from PySide6.QtGui import QImageReader, QPageLayout, QPageSize, QPainter, QPdfWriter


def text_to_pdf(src, out):
    from .legacy import _write_paragraphs
    path = Path(src)
    if path.stat().st_size > 20 * 1024 * 1024:
        raise ValueError("文本超过 20 MB，请拆分后导入")
    raw = path.read_bytes()
    encodings = ["utf-16"] if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else ["utf-8-sig", "gb18030"]
    text = None
    for encoding in encodings:
        try:
            text = raw.decode(encoding)
            break
        except UnicodeError:
            pass
    if text is None:
        raise ValueError("无法识别文字编码，请另存为 UTF-8 文本后导入")
    if not text.strip() or "\x00" in text:
        raise ValueError("文件没有可显示的文字，或不是纯文本")
    _write_paragraphs(text.splitlines(), [], out)


def image_to_pdf(src, out):
    reader = QImageReader(str(src))
    reader.setAutoTransform(True)  # 手机照片按 EXIF 方向显示
    writer = QPdfWriter(str(out))
    writer.setResolution(144)
    painter = QPainter()
    count = 0
    try:
        while True:
            image = reader.read()
            if image.isNull():
                raise ValueError("图片无法解码：" + reader.errorString())
            # 按像素比例保留页面形状，同时限制 PDF 物理尺寸。
            scale = 720 / max(image.width(), image.height())
            size = QSizeF(max(1, image.width() * scale), max(1, image.height() * scale))
            writer.setPageLayout(QPageLayout(QPageSize(size, QPageSize.Unit.Point, "image"), QPageLayout.Orientation.Portrait, QMarginsF()))
            if count:
                if not writer.newPage():
                    raise ValueError("无法创建图片页面")
            elif not painter.begin(writer):
                raise ValueError("无法创建 PDF")
            painter.drawImage(QRectF(0, 0, writer.width(), writer.height()), image)
            count += 1
            if not reader.jumpToNextImage():
                break
            if count >= 500:
                raise ValueError("图片超过 500 帧，请拆分后导入")
    finally:
        if painter.isActive():
            painter.end()
