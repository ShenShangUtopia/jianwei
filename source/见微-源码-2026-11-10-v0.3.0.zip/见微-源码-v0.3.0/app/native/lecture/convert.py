"""把 Word / PPT 转成 PDF。本机有 Office 或 WPS 就用（版式最准），没有就用内置排版，都能放。

统一转成 PDF：翻页快、缩放清晰，还保留文字层——框选后可以直接取到文字，不必识别图片。
PPT 的每个动画步骤是 PDF 的一页（见 anim.py），放映时比较前后两页来做效果。
转换在隔离的 PowerShell 进程里跑，超时只放弃不硬杀 Office；打开文件时禁用宏，原文件不改动。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

from ..kit.home import home

SLIDES = {".pptx", ".ppt", ".pptm", ".ppsx", ".ppsm", ".pps", ".dps"}
DOCS = {".docx", ".doc", ".docm", ".rtf", ".wps"}
TEXTS = {".txt", ".md"}
IMAGES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
SUPPORTED = SLIDES | DOCS | TEXTS | IMAGES | {".pdf"}
ZIP_SLIDES = {".pptx", ".pptm", ".ppsx", ".ppsm"}
FILTER = "课件 (" + " ".join("*" + ext for ext in sorted(SUPPORTED)) + ");;所有文件 (*)"
TIMEOUT = 120
NO_WINDOW = 0x08000000
PLAIN_ENGINES = ("内置排版", "简化显示")

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$src = $env:JW_SRC; $out = $env:JW_PDF; $engine = $env:JW_ENGINE; $mode = $env:JW_MODE; $planFile = $env:JW_PLAN
$proc = @{ 'PowerPoint.Application'='POWERPNT'; 'KWPP.Application'='wpp'; 'Word.Application'='WINWORD'; 'KWPS.Application'='wps' }[$engine]
$isPres = $engine -in 'PowerPoint.Application', 'KWPP.Application'
$running = @(Get-Process $proc -ErrorAction SilentlyContinue).Count -gt 0
$app = $null; $doc = $null; $code = 1

function Find-Shape($slide, $id, $name) {
  foreach ($s in $slide.Shapes) { if ($s.Id -eq $id) { return $s } }
  foreach ($s in $slide.Shapes) { if ($name -and $s.Name -eq $name) { return $s } }
  foreach ($s in $slide.Shapes) {
    if ($s.Type -eq 6) { foreach ($g in $s.GroupItems) { if ($g.Id -eq $id -or ($name -and $g.Name -eq $name)) { return $g } } }
  }
  return $null
}
function Apply-Frame($slide, $frame) {
  foreach ($h in @($frame.shapes)) { $s = Find-Shape $slide $h.id $h.name; if ($s) { $s.Visible = 0 } }
  foreach ($h in @($frame.paras)) {
    $s = Find-Shape $slide $h.id $h.name
    if ($s) {
      foreach ($n in @($h.n)) {
        # 段落设成全透明而不是删掉：版面不变，后面的文字不会往上跑
        try { $s.TextFrame2.TextRange.Paragraphs($n + 1).Font.Fill.Transparency = 1 }
        catch { $s.TextFrame.TextRange.Paragraphs($n + 1).Font.Color.RGB = $slide.Background.Fill.ForeColor.RGB }
      }
    }
  }
}
try {
  $app = New-Object -ComObject $engine
  try { $app.DisplayAlerts = 0 } catch {}
  try { $app.AutomationSecurity = 3 } catch {}
  if ($isPres) {
    $doc = $app.Presentations.Open($src, -1, 0, 0)
    if ($mode -eq 'pptx') {
      $doc.SaveCopyAs($out, 24)
    } else {
      if ($planFile) {
        $plan = [IO.File]::ReadAllText($planFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        $items = @($plan.slides) | Sort-Object { $_.index } -Descending
        $all = @(@($items | ForEach-Object { @{ i = $_.index; s = $_ } }) + @(@($plan.delete) | Where-Object { $_ } | ForEach-Object { @{ i = $_; s = $null } })) | Sort-Object { $_.i } -Descending
        foreach ($e in $all) {
          $slide = $doc.Slides.Item($e.i)
          if ($null -eq $e.s) { $slide.Delete(); continue }
          $frames = @($e.s.frames)
          for ($k = $frames.Count - 1; $k -ge 1; $k--) {
            $d = $slide.Duplicate()
            Apply-Frame $d.Item(1) $frames[$k]
          }
          Apply-Frame $slide $frames[0]
        }
      }
      $doc.SaveAs($out, 32)
    }
  } else {
    try { $app.Visible = $false } catch {}
    $doc = $app.Documents.Open($src, $false, $true, $false, '')
    $doc.ExportAsFixedFormat($out, 17)
  }
  $code = 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
} finally {
  try { if ($doc) { if ($isPres) { $doc.Saved = -1; $doc.Close() } else { $doc.Close(0) } } } catch {}
  try {
    $open = if ($isPres) { $app.Presentations.Count } else { $app.Documents.Count }
    # 只收拾自己启动的实例：用户本来就开着、或还有别的文档时不退出
    if ($app -and -not $running -and $open -eq 0) { $app.Quit() }
  } catch {}
  try { if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) } } catch {}
  [GC]::Collect()
}
exit $code
"""


# 逐画面出图：每个动画画面就是演示软件自己画出来的一张 PNG。
# 不复制幻灯片、不导出 PDF——只在原幻灯片上切换「这一步哪些看不见」，再让演示软件导出这一页。
# 这样放映时的字体、颜色、位置和在 WPS / PowerPoint 里放映完全一致（PDF 里字体会被替换，字会变细、发灰）。
FRAMES_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$src = $env:JW_SRC; $dir = $env:JW_DIR; $engine = $env:JW_ENGINE
$OutW = [int]$env:JW_W; $OutH = [int]$env:JW_H   # PowerShell 不分大小写：别和下面的 $h 撞名
$proc = @{ 'PowerPoint.Application'='POWERPNT'; 'KWPP.Application'='wpp' }[$engine]
$running = @(Get-Process $proc -ErrorAction SilentlyContinue).Count -gt 0
$app = $null; $doc = $null; $code = 1
function Shape-Map($slide) {
  $m = @{}
  foreach ($s in $slide.Shapes) {
    $m[[int]$s.Id] = $s
    if ($s.Type -eq 6) { foreach ($g in $s.GroupItems) { $m[[int]$g.Id] = $g } }
  }
  return $m
}
function Find-In($map, $slide, $id, $name) {
  if ($map.ContainsKey([int]$id)) { return $map[[int]$id] }
  if ($name) { foreach ($s in $slide.Shapes) { if ($s.Name -eq $name) { return $s } } }
  return $null
}
function Para-Hide($s, $n, $hide, $orig) {
  $key = "$($s.Id):$n"
  try {
    $f = $s.TextFrame2.TextRange.Paragraphs($n + 1).Font.Fill
    if (-not $orig.ContainsKey($key)) { $orig[$key] = $f.Transparency }
    $f.Transparency = $(if ($hide) { 1 } else { $orig[$key] })
  } catch {
    $c = $s.TextFrame.TextRange.Paragraphs($n + 1).Font.Color
    if (-not $orig.ContainsKey($key)) { $orig[$key] = $c.RGB }
    $c.RGB = $(if ($hide) { $s.Parent.Background.Fill.ForeColor.RGB } else { $orig[$key] })
  }
}
try {
  $plan = [IO.File]::ReadAllText($env:JW_PLAN, [Text.Encoding]::UTF8) | ConvertFrom-Json
  $app = New-Object -ComObject $engine
  try { $app.DisplayAlerts = 0 } catch {}
  try { $app.AutomationSecurity = 3 } catch {}
  $doc = $app.Presentations.Open($src, -1, 0, 0)
  [Console]::Out.WriteLine('OPEN'); [Console]::Out.Flush()
  $page = 0
  foreach ($e in @($plan.slides)) {
    $slide = $doc.Slides.Item([int]$e.index)
    $map = Shape-Map $slide
    $hiddenShapes = @{}; $hiddenParas = @{}; $orig = @{}; $vis = @{}; $moved = @{}; $origPos = @{}
    foreach ($f in @($e.frames)) {
      $wantShapes = @{}; foreach ($h in @($f.shapes)) { if ($h) { $wantShapes["$($h.id)"] = $h } }
      $wantParas = @{}; foreach ($h in @($f.paras)) { if ($h) { foreach ($n in @($h.n)) { $wantParas["$($h.id):$n"] = $h } } }
      # 只改和上一步不同的地方：COM 调用很慢
      foreach ($k in @($hiddenShapes.Keys)) { if (-not $wantShapes.ContainsKey($k)) { $s = Find-In $map $slide $k $hiddenShapes[$k].name; if ($s) { $s.Visible = $vis[$k] }; $hiddenShapes.Remove($k) } }
      foreach ($k in @($wantShapes.Keys)) { if (-not $hiddenShapes.ContainsKey($k)) { $s = Find-In $map $slide $k $wantShapes[$k].name; if ($s) { if (-not $vis.ContainsKey($k)) { $vis[$k] = $s.Visible }; $s.Visible = 0 }; $hiddenShapes[$k] = $wantShapes[$k] } }
      foreach ($k in @($hiddenParas.Keys)) { if (-not $wantParas.ContainsKey($k)) { $h = $hiddenParas[$k]; $s = Find-In $map $slide $h.id $h.name; if ($s) { Para-Hide $s ([int]$k.Split(':')[1]) $false $orig }; $hiddenParas.Remove($k) } }
      foreach ($k in @($wantParas.Keys)) { if (-not $hiddenParas.ContainsKey($k)) { $h = $wantParas[$k]; $s = Find-In $map $slide $h.id $h.name; if ($s) { Para-Hide $s ([int]$k.Split(':')[1]) $true $orig }; $hiddenParas[$k] = $h } }
      # 动作路径走完后形状停在终点：按累计位移挪过去（相对原位置，换画面时先还原）
      $wantMoves = @{}; foreach ($x in @($f.moves)) { if ($x) { $wantMoves["$($x.id)"] = $x } }
      foreach ($k in @($moved.Keys)) { if (-not $wantMoves.ContainsKey($k)) { $s = Find-In $map $slide $k ''; if ($s) { $s.Left = $origPos[$k][0]; $s.Top = $origPos[$k][1] }; $moved.Remove($k) } }
      foreach ($k in @($wantMoves.Keys)) { $x = $wantMoves[$k]; $s = Find-In $map $slide $k $x.name; if ($s) { if (-not $origPos.ContainsKey($k)) { $origPos[$k] = @($s.Left, $s.Top) }; $s.Left = $origPos[$k][0] + [double]$x.dx; $s.Top = $origPos[$k][1] + [double]$x.dy; $moved[$k] = $x } }
      $slide.Export((Join-Path $dir ('{0:D4}.png' -f $page)), 'PNG', $OutW, $OutH)
      [Console]::Out.WriteLine("F $page"); [Console]::Out.Flush()
      $page++
    }
  }
  $code = 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
} finally {
  try { if ($doc) { $doc.Saved = -1; $doc.Close() } } catch {}
  try { if ($app -and -not $running -and $app.Presentations.Count -eq 0) { $app.Quit() } } catch {}
  try { if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) } } catch {}
  [GC]::Collect()
}
exit $code
"""

EXPORT_LONG = 2560   # 导出图的长边：投影、放大看都够清楚


class ConvertError(Exception):
    pass


def kind_of(path) -> str:
    ext = Path(path).suffix.lower()
    return "slides" if ext in SLIDES | IMAGES else "doc" if ext in DOCS | TEXTS else "pdf"


def com_server(progid: str) -> str:
    """这个 COM 名字背后真正启动的程序（小写路径）；没注册返回空串。"""
    if sys.platform != "win32":
        return ""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid + "\\CLSID") as k:
            clsid = winreg.QueryValue(k, None)
    except OSError:
        return ""
    for base in ("CLSID\\", "WOW6432Node\\CLSID\\"):
        try:
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, base + clsid + "\\LocalServer32") as k:
                path = winreg.QueryValue(k, None)
                if path:
                    return path.lower()
        except OSError:
            continue
    return ""


def has_com(progid: str) -> bool:
    return bool(com_server(progid))


def is_wps_shim(progid: str) -> bool:
    """装了 WPS、没装 Office 时，「PowerPoint.Application」其实指向 WPS 演示。"""
    server = com_server(progid)
    return progid.startswith(("PowerPoint", "Word")) and ("wpp.exe" in server or "wps.exe" in server or "kingsoft" in server)


def _prefs_file() -> Path:
    return home() / "lecture-engines.json"


def engines_for(ext: str) -> list:
    """先试上次成功的那个：某个 Office 打不开文件时，不用每次都等它失败。"""
    # Word 排在 WPS 后面：装了但没激活的 Word 打开文件会失败，还会留下一个退不掉的后台进程
    names = ["PowerPoint.Application", "KWPP.Application"] if ext in SLIDES else ["KWPS.Application", "Word.Application"]
    names = [n for n in names if has_com(n)]
    if "KWPP.Application" in names and "PowerPoint.Application" in names and is_wps_shim("PowerPoint.Application"):
        names.remove("PowerPoint.Application")   # 同一个 WPS，别试两遍
    if "KWPS.Application" in names and "Word.Application" in names and is_wps_shim("Word.Application"):
        names.remove("Word.Application")
    try:
        last = json.loads(_prefs_file().read_text(encoding="utf-8")).get("slides" if ext in SLIDES else "doc")
    except (OSError, ValueError):
        last = None
    if last in names:
        names.remove(last)
        names.insert(0, last)
    return names


def _remember(ext: str, engine: str) -> None:
    key = "slides" if ext in SLIDES else "doc"
    try:
        data = json.loads(_prefs_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    data[key] = engine
    try:
        _prefs_file().write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


def _com(src: Path, out: Path, engine: str, timeout: int, mode: str = "pdf", plan=None) -> str:
    """跑一次转换；成功返回空串，失败返回原因。"""
    tmp = Path(tempfile.mkdtemp(prefix="jw-conv-"))
    try:
        script = tmp / "convert.ps1"
        script.write_bytes(b"\xef\xbb\xbf" + SCRIPT.encode("utf-8"))
        env = dict(os.environ, JW_SRC=str(src), JW_PDF=str(out), JW_ENGINE=engine, JW_MODE=mode, JW_PLAN="")
        if plan is not None:
            pf = tmp / "plan.json"
            pf.write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
            env["JW_PLAN"] = str(pf)
        env.pop("QT_QPA_PLATFORM", None)
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                               env=env, capture_output=True, timeout=timeout, creationflags=NO_WINDOW if sys.platform == "win32" else 0)
        except subprocess.TimeoutExpired:
            return f"超过 {timeout} 秒没有完成（文件可能设了密码，或者 Office 弹出了对话框）"
        except OSError as e:
            return str(e)
        if out.is_file() and out.stat().st_size > 200:
            return ""
        return r.stderr.decode("utf-8", "replace").strip()[:200] or f"退出码 {r.returncode}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


LABEL = {"PowerPoint.Application": "PowerPoint", "KWPP.Application": "WPS 演示", "Word.Application": "Word", "KWPS.Application": "WPS 文字"}


def label(engine: str) -> str:
    if is_wps_shim(engine):
        return "WPS 演示" if engine.startswith("PowerPoint") else "WPS 文字"
    return LABEL[engine]


def _frames(src: Path, pdf: Path, engine: str, plan, timeout: int, say) -> str:
    """每个画面让演示软件导出一张图，再拼成只有图的 PDF。成功返回空串，失败返回原因。"""
    from . import anim
    frames = anim.frame_count(plan)
    ratio = plan["h"] / max(1, plan["w"])
    W = EXPORT_LONG if ratio <= 1 else int(EXPORT_LONG / ratio)
    H = int(round(W * ratio))
    tmp = Path(tempfile.mkdtemp(prefix="jw-frames-"))
    try:
        script = tmp / "frames.ps1"
        script.write_bytes(b"\xef\xbb\xbf" + FRAMES_SCRIPT.encode("utf-8"))
        pf = tmp / "plan.json"
        pf.write_text(json.dumps(anim.com_plan(plan), ensure_ascii=False), encoding="utf-8")
        out = tmp / "png"
        out.mkdir()
        env = dict(os.environ, JW_SRC=str(src), JW_DIR=str(out), JW_ENGINE=engine, JW_PLAN=str(pf), JW_W=str(W), JW_H=str(H))
        env.pop("QT_QPA_PLATFORM", None)
        t0 = time.perf_counter()
        try:
            proc = subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                                    env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    creationflags=NO_WINDOW if sys.platform == "win32" else 0)
        except OSError as e:
            return str(e)
        done = 0
        from concurrent.futures import ThreadPoolExecutor
        pool = ThreadPoolExecutor(max_workers=min(6, os.cpu_count() or 2))
        futures = {}
        # 超时按画面数放宽：每个画面最多再给 3 秒
        limit = timeout + 3 * frames
        import threading
        expired = threading.Event()

        def stop():
            expired.set()
            try:
                proc.kill()   # 只结束我们自己的 PowerShell，不碰 WPS / Office 本身
            except OSError:
                pass
        killer = threading.Timer(limit, stop)
        killer.start()
        try:
            for raw in proc.stdout:
                line = raw.decode("utf-8", "replace").strip()
                if line.startswith("F "):
                    done += 1
                    n = int(line[2:])
                    futures[n] = pool.submit(_encode_frame, out / f"{n:04d}.png")   # 边出图边压缩，不用等全部导完
                    if done == 1 or done % 3 == 0 or done == frames:
                        say(f"正在用 {label(engine)} 出图 {done} / {frames}…")
            proc.wait()
        finally:
            killer.cancel()
            pool.shutdown(wait=not expired.is_set())
        if expired.is_set():
            return f"超过 {limit} 秒没有完成（文件可能设了密码，或者弹出了对话框）"
        files = sorted(out.glob("*.png"))
        if proc.returncode != 0 or len(files) != frames:
            err = proc.stderr.read().decode("utf-8", "replace").strip()[:200] if proc.stderr else ""
            return err or f"只导出了 {len(files)} / {frames} 张"
        say(f"正在整理画面（{time.perf_counter() - t0:.1f} 秒出图）…")
        encoded = [futures[i].result() if i in futures else _encode_frame(f) for i, f in enumerate(files)]
        _images_to_pdf(files, pdf, plan, encoded)
        return ""
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _encode_frame(f):
    """一张导出图 → (宽, 高, JPEG 字节)。透明的地方垫白，和演示软件放映时一样。"""
    from PySide6.QtCore import QBuffer, QIODevice
    from PySide6.QtGui import QImage, QPainter
    img = QImage(str(f))
    if img.hasAlphaChannel():
        base = QImage(img.size(), QImage.Format.Format_RGB32)
        base.fill(0xFFFFFF)
        p = QPainter(base)
        p.drawImage(0, 0, img)
        p.end()
        img = base
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    img.save(buf, "JPG", 93)
    return img.width(), img.height(), bytes(buf.data())


def _images_to_pdf(files, pdf: Path, plan, encoded=None) -> None:
    """把导出的图按幻灯片原尺寸（磅）拼成 PDF：放映器、目录、互通都照旧读这个 PDF。

    自己写 PDF，图片以 JPEG（质量 93）直接嵌入：QPdfWriter 重新压缩大图要好几秒，放映时解 JPEG 也比解 Flate 快。
    encoded 是已经压好的结果（边出图边压缩时传进来）。"""
    w_pt = plan["w"] * 72 / 914400 if plan["w"] > 100000 else plan["w"]
    h_pt = plan["h"] * 72 / 914400 if plan["h"] > 100000 else plan["h"]
    if encoded is None:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(6, os.cpu_count() or 2)) as pool:   # 解 PNG、压 JPEG 都在 Qt 里，能并行
            encoded = list(pool.map(_encode_frame, files))
    objs: list[bytes] = []

    def add(body: bytes) -> int:
        objs.append(body)
        return len(objs)
    pages = []
    for width, height, data in encoded:
        im = add(b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n" % (width, height, len(data)) + data + b"\nendstream")
        content = b"q %.4f 0 0 %.4f 0 0 cm /Im0 Do Q" % (w_pt, h_pt)
        ct = add(b"<< /Length %d >>\nstream\n" % len(content) + content + b"\nendstream")
        pages.append((im, ct))
    kids_at = len(objs) + 1 + len(pages)
    page_ids = []
    for im, ct in pages:
        page_ids.append(add(b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.4f %.4f] /Resources << /XObject << /Im0 %d 0 R >> >> /Contents %d 0 R >>" % (kids_at, w_pt, h_pt, im, ct)))
    root_pages = add(b"<< /Type /Pages /Kids [" + b" ".join(b"%d 0 R" % i for i in page_ids) + b"] /Count %d >>" % len(page_ids))
    catalog = add(b"<< /Type /Catalog /Pages %d 0 R >>" % root_pages)
    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = []
    for i, body in enumerate(objs, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + body + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for o in offsets:
        out += b"%010d 00000 n \n" % o
    out += b"trailer\n<< /Size %d /Root %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, catalog, xref)
    tmp = pdf.with_suffix(".tmp.pdf")
    tmp.write_bytes(bytes(out))
    os.replace(tmp, pdf)


def text_layer(src, out_pdf, engine=None, timeout: int = TIMEOUT) -> bool:
    """在后台再导出一份带文字的 PDF：只用来框选取字，不用来显示。隐藏的幻灯片先删掉，页码和放映对齐。"""
    src, out_pdf = Path(src), Path(out_pdf)
    plan = _parse_plan(src) if src.suffix.lower() in ZIP_SLIDES else None
    if plan is None:
        return False
    for eng in ([engine] if engine else engines_for(src.suffix.lower())):
        tmp = out_pdf.with_suffix(".tmp.pdf")
        tmp.unlink(missing_ok=True)
        if not _com(src, tmp, eng, timeout, "pdf", dict(delete=plan["hidden"], slides=[])):
            try:
                if pdf_pages(tmp) == len(plan["slides"]):
                    os.replace(tmp, out_pdf)
                    return True
            finally:
                tmp.unlink(missing_ok=True)
    return False


def pdf_pages(path) -> int:
    from PySide6.QtPdf import QPdfDocument
    d = QPdfDocument()
    d.load(str(path))
    n = d.pageCount()
    d.close()
    return n


def _save_timeline(pdf: Path, plan) -> None:
    from . import anim
    target = pdf.parent / "anim.json"
    if plan is not None and anim.has_motion(plan):
        target.write_text(json.dumps(anim.timeline(plan), ensure_ascii=False), encoding="utf-8")
    else:
        target.unlink(missing_ok=True)


def _parse_plan(path):
    from . import anim
    try:
        return anim.parse(path)
    except Exception:  # noqa: BLE001  动画读不懂也要能放，只是没有动画
        return None


def _slides(src: Path, pdf: Path, say, timeout, use_com, errors) -> str:
    from . import anim
    ext = src.suffix.lower()
    plan = _parse_plan(src) if ext in ZIP_SLIDES else None
    for engine in (engines_for(ext) if use_com else []):
        t = time.perf_counter()
        work, tmp, eng_plan = src, None, plan
        try:
            if ext not in ZIP_SLIDES:   # 旧格式先转存成 pptx，才读得到动画
                say(f"正在用 {label(engine)} 读取旧格式…")
                tmp = Path(tempfile.mkdtemp(prefix="jw-ppt-"))
                work = tmp / "deck.pptx"
                why = _com(src, work, engine, timeout, "pptx")
                if why:
                    errors.append(f"{label(engine)}：{why}")
                    continue
                eng_plan = _parse_plan(work)
            if eng_plan is not None and eng_plan["slides"]:
                say(f"正在用 {label(engine)} 出图（{anim.frame_count(eng_plan)} 个画面）…")
                pdf.unlink(missing_ok=True)
                why = _frames(work, pdf, engine, eng_plan, timeout, say)
                if not why and pdf_pages(pdf) == anim.frame_count(eng_plan):
                    _remember(ext, engine)
                    _save_timeline(pdf, eng_plan)
                    if tmp is not None:   # 旧格式：留一份 pptx，后台取文字层要用
                        shutil.copyfile(work, pdf.parent / "work.pptx")
                    say(f"{label(engine)} 出图完成（{time.perf_counter() - t:.1f} 秒）")
                    return label(engine) + " 原样出图"
                errors.append(f"{label(engine)} 出图：{why or '页数不对'}")
            steps = eng_plan is not None and anim.needs_steps(eng_plan)
            say(f"正在用 {label(engine)} 转换" + ("（含动画，每一步都要出图）…" if steps else "…"))
            pdf.unlink(missing_ok=True)
            why = _com(work, pdf, engine, timeout, "pdf", anim.com_plan(eng_plan) if steps else None)
            if not why:
                pages = pdf_pages(pdf)
                if eng_plan is not None and pages != anim.frame_count(eng_plan):
                    why = f"页数不对（{pages} / {anim.frame_count(eng_plan)}）"
            if not why:
                _remember(ext, engine)
                _save_timeline(pdf, eng_plan)
                say(f"{label(engine)} 转换完成（{time.perf_counter() - t:.1f} 秒）")
                return label(engine)
            errors.append(f"{label(engine)}：{why}")
        finally:
            if tmp is not None:
                shutil.rmtree(tmp, ignore_errors=True)
    if ext in ZIP_SLIDES:
        say("正在用内置排版转换…")
        from . import builtin
        pdf.unlink(missing_ok=True)
        builtin.pptx_to_pdf(src, pdf, plan)
        _save_timeline(pdf, plan)
        return "内置排版"
    say("没有 Office / WPS，正在按简化方式读取旧格式…")
    from . import legacy
    pdf.unlink(missing_ok=True)
    legacy.ppt_to_pdf(src, pdf)
    return "简化显示"


def _docs(src: Path, pdf: Path, say, timeout, use_com, errors) -> str:
    ext = src.suffix.lower()
    for engine in (engines_for(ext) if use_com else []):
        say(f"正在用 {label(engine)} 转换…")
        t = time.perf_counter()
        pdf.unlink(missing_ok=True)
        why = _com(src, pdf, engine, timeout)
        if not why:
            _remember(ext, engine)
            say(f"{label(engine)} 转换完成（{time.perf_counter() - t:.1f} 秒）")
            return label(engine)
        errors.append(f"{label(engine)}：{why}")
    pdf.unlink(missing_ok=True)
    if ext in (".docx", ".docm"):
        say("正在用内置排版转换…")
        from . import builtin
        builtin.docx_to_pdf(src, pdf)
        return "内置排版"
    say("没有 Office / WPS，正在按简化方式读取…")
    from . import legacy
    (legacy.rtf_to_pdf if ext == ".rtf" else legacy.doc_to_pdf)(src, pdf)
    return "简化显示"


def to_pdf(src, pdf, status=None, timeout: int = TIMEOUT, use_com: bool = True) -> str:
    """src → pdf，返回所用引擎的名字；失败抛 ConvertError。"""
    src, pdf = Path(src), Path(pdf)
    ext = src.suffix.lower()
    if ext not in SUPPORTED:
        raise ConvertError(f"不支持 {ext or '这种'} 文件。可以导入 PPT、Word 和 PDF。")
    say = status or (lambda _s: None)
    # 某些 WPS/旧后缀文件实际保存为 OOXML 或 RTF，按内容识别。
    if ext in {".wps", ".dps", ".doc", ".ppt"}:
        normalized = None
        if zipfile.is_zipfile(src):
            with zipfile.ZipFile(src) as package:
                names = set(package.namelist())
            normalized = ".pptx" if "ppt/presentation.xml" in names else ".docx" if "word/document.xml" in names else None
        else:
            with src.open("rb") as stream:
                if stream.read(16).lstrip().startswith(b"{\\rtf"):
                    normalized = ".rtf"
        if normalized:
            say("已识别文件内部格式，正在兼容转换…")
            with tempfile.TemporaryDirectory(prefix="jw-format-") as directory:
                work = Path(directory) / ("source" + normalized)
                shutil.copyfile(src, work)
                return to_pdf(work, pdf, say, timeout, use_com)
    if ext == ".pdf":
        shutil.copyfile(src, pdf)
        return "PDF"
    errors = []
    try:
        if ext in TEXTS | IMAGES:
            from . import portable
            say("正在排版文字…" if ext in TEXTS else "正在读取图片…")
            (portable.text_to_pdf if ext in TEXTS else portable.image_to_pdf)(src, pdf)
            return "文本排版" if ext in TEXTS else "图片"
        return (_slides if ext in SLIDES else _docs)(src, pdf, say, timeout, use_com, errors)
    except Exception as e:  # noqa: BLE001  坏文件什么异常都可能有，要给人读得懂的原因
        errors.append(f"读取：{e}")
    raise ConvertError("这个文件打不开，可能已损坏或设了密码。（" + "；".join(errors) + "）")
