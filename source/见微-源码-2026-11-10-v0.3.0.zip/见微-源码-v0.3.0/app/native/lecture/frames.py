"""原样出图的课件：直接从 doc.pdf 里取每一页的 JPEG 解码，比让 PDF 渲染器整页重画快两三倍，而且能在后台线程里提前解好。

只认见微自己写的 PDF（convert._images_to_pdf：每页一张 DCTDecode 图，按页序排列）。认不出来时返回 None，放映照旧走 QtPdf。
"""
from __future__ import annotations

import re
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QSize
from PySide6.QtGui import QImage, QImageReader

HEAD = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
IMAGE = re.compile(rb"/Subtype /Image /Width (\d+) /Height (\d+) /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length (\d+) >>\nstream\n")


def scan(path: Path, pages: int):
    """返回每页图片在文件里的 (位置, 长度)；不是见微写的 PDF、或页数对不上时返回 None。"""
    try:
        data = Path(path).read_bytes()
    except OSError:
        return None
    if not data.startswith(HEAD) or b"/Im0" not in data:
        return None
    found = [(m.end(), int(m.group(3))) for m in IMAGE.finditer(data)]
    if len(found) != pages or any(o + n > len(data) for o, n in found):
        return None
    return found


def decode(path: Path, spot, w: int, h: int) -> QImage:
    o, n = spot
    with open(path, "rb") as f:
        f.seek(o)
        raw = f.read(n)
    buf = QBuffer()
    buf.setData(QByteArray(raw))
    buf.open(QIODevice.OpenModeFlag.ReadOnly)
    r = QImageReader(buf, b"jpeg")
    r.setScaledSize(QSize(max(1, w), max(1, h)))
    im = r.read()
    buf.close()
    return im


class FrameSource:
    """一份课件的取图器。spots 在后台线程里扫出来，扫完之前 ready 为 False。"""

    def __init__(self, path, pages: int):
        self.path = Path(path)
        self.pages = pages
        self.spots = None
        self.ready = False
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="jw-frames")
        self.pending = {}
        self._lock = threading.Lock()
        self.pool.submit(self._scan)

    def _scan(self):
        spots = scan(self.path, self.pages)
        with self._lock:
            self.spots = spots
            self.ready = True

    @property
    def usable(self) -> bool:
        return self.ready and self.spots is not None

    def image(self, page: int, w: int, h: int):
        """同步取一张（后台已解好就直接用）。取不到返回 None。"""
        if not self.usable or not 0 <= page < len(self.spots):
            return None
        fut = self.pending.pop((page, w, h), None)
        if fut is not None:
            try:
                im = fut.result(timeout=2)
            except Exception:   # noqa: BLE001 - 后台解码失败就当场再解一次
                im = None
            if im is not None and not im.isNull():
                return im
        im = decode(self.path, self.spots[page], w, h)
        return None if im.isNull() else im

    def request(self, page: int, w: int, h: int) -> None:
        """在后台先解好一张。"""
        if not self.usable or not 0 <= page < len(self.spots) or (page, w, h) in self.pending:
            return
        if len(self.pending) > 8:
            for k in list(self.pending)[:-6]:
                self.pending.pop(k).cancel()
        self.pending[(page, w, h)] = self.pool.submit(decode, self.path, self.spots[page], w, h)

    def done(self):
        """已经在后台解好的 [(page, w, h, QImage)]，取出后从待办里拿掉。"""
        out = []
        for k, fut in list(self.pending.items()):
            if fut.done():
                self.pending.pop(k)
                try:
                    im = fut.result()
                except Exception:   # noqa: BLE001
                    continue
                if im is not None and not im.isNull():
                    out.append((*k, im))
        return out

    def close(self):
        for fut in self.pending.values():
            fut.cancel()
        self.pending.clear()
        self.pool.shutdown(wait=False, cancel_futures=True)
