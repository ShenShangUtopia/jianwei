"""旧导入路径兼容层；新代码使用 native.kit.pen。

保留 new_stroke 的 pts 访问方式；两个键引用同一列表，落盘时只保存 points。
绘制、命中、History 等均接受旧 pts 字典。
"""
from ..kit.pen import (
    VERSION as VERSION, MARKER_ALPHA as MARKER_ALPHA,
    PenDataError as PenDataError, History as History,
    migrate_stroke as migrate_stroke, migrate_strokes as migrate_strokes,
    points_of as points_of, add_point as add_point, path_of as path_of,
    chalk_brush as chalk_brush, pen_for as pen_for, draw as draw,
    bounds as bounds, hit as hit,
)
from ..kit.pen import new_stroke as _new_stroke

__all__ = ["VERSION", "MARKER_ALPHA", "PenDataError", "History", "migrate_stroke",
           "migrate_strokes", "points_of", "new_stroke", "add_point", "path_of",
           "chalk_brush", "pen_for", "draw", "bounds", "hit"]


def new_stroke(tool, color, width, pressure=False):
    stroke = _new_stroke(tool, color, width, pressure)
    stroke["pts"] = stroke["points"]
    return stroke
