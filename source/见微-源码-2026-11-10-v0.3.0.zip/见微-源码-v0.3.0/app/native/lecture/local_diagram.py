"""Local exact bank diagrams; no search truncation, network, or fuzzy constants."""
from ..analysis.realtime import exact_figure


def resolve(text):
    if not isinstance(text,str):
        return None
    exact=exact_figure(text)
    if exact:
        return exact
    # Concept-only sketches never borrow numerical conditions from bank questions.
    concept=text.strip().rstrip('。.!！?？')
    if concept not in ('光合作用','细胞器','全反射'):
        return None
    layers=[]
    def add(id,type,**kw):
        layers.append(dict(id=id,type=type,**kw))
    add('title','text',x=35,y=25,w=920,h=65,text=concept+' · 定性结构示意',color='accent')
    if concept=='光合作用':
        add('cell','cell',x=360,y=170,w=280,h=240,color='c3')
        add('input','arrow',x=80,y=260,x2=350,y2=260,color='c1')
        add('output','arrow',x=650,y=260,x2=900,y2=260,color='c2')
        add('left','text',x=45,y=140,w=290,h=100,text='CO₂ + H₂O\n光能输入',color='c1')
        add('right','text',x=675,y=140,w=280,h=100,text='有机物 + O₂\n光能转为化学能',color='c2')
        add('note','text',x=80,y=455,w=850,h=100,text='这是叶肉细胞的定性概览，不是配平的化学方程式。光反应与碳同化相互依赖；速率题还需具体条件。')
    elif concept=='细胞器':
        add('cell','cell',x=110,y=140,w=420,h=310,color='c3')
        add('note','text',x=580,y=140,w=370,h=350,text='线粒体：有氧呼吸的重要场所\n核糖体：合成蛋白质\n内质网和高尔基体：加工、运输与分选\n叶绿体：光合作用（植物相关细胞）\n示意不代表所有细胞同时具有全部结构。')
    else:
        add('interface','line',x=80,y=330,x2=920,y2=330,color='muted')
        add('normal','line',x=500,y=100,x2=500,y2=550,color='muted')
        add('in','arrow',x=180,y=500,x2=500,y2=330,color='c1')
        add('reflect','arrow',x=500,y=330,x2=820,y2=500,color='c2')
        add('note','text',x=75,y=85,w=390,h=180,text='上方 n₂，下方 n₁；n₁>n₂\n从光密到光疏，入射角大于临界角\nsin C = n₂/n₁\n角度由法线量起；此图不按实际角度缩放。')
    return dict(v=1,specific=True,title=concept+'（定性）',layers=layers,steps=[dict(say='观察结构与适用条件；本地图不替代具体题目的求解。',show=[l['id'] for l in layers],highlight=[])])
