"""PPT 动画转换缓存：输出等价、调用次数与冷/热耗时验证；不调用 Office。"""
from __future__ import annotations

import json
import sys
import time
import zipfile
from pathlib import Path
from unittest.mock import patch

from ..kit import test_runtime

test_runtime.configure()


def main(output=None):
    test_runtime.application()
    from PySide6.QtCore import QBuffer, QIODevice, QSize
    from PySide6.QtGui import QColor, QImage, QPainter
    from PySide6.QtPdf import QPdfDocument
    from . import builtin
    from .selftest import make_pptx
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    src = out / "repeated-media.pptx"
    make_pptx(src, n=4)
    image = QImage(1800, 1000, QImage.Format.Format_RGB32)
    image.fill(QColor("#e6f0ff"))
    painter = QPainter(image)
    for x in range(0, 1800, 3):
        painter.setPen(QColor(x % 255, (x * 17) % 255, (x * 31) % 255))
        painter.drawLine(x, 0, 1799-x, 999)
    painter.end()
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(buf, "PNG")
    pic = ('<p:pic><p:nvPicPr><p:cNvPr id="4" name="image"/></p:nvPicPr>'
           '<p:blipFill><a:blip r:embed="image1"/></p:blipFill><p:spPr>'
           '<a:xfrm><a:off x="7000000" y="3500000"/><a:ext cx="1500000" cy="1000000"/>'
           '</a:xfrm></p:spPr></p:pic>')
    with zipfile.ZipFile(src) as z:
        files = {name:z.read(name) for name in z.namelist()}
    for i in range(1, 5):
        name = f"ppt/slides/slide{i}.xml"
        files[name] = files[name].replace(b"</p:spTree>", (pic+"</p:spTree>").encode())
        files[f"ppt/slides/_rels/slide{i}.xml.rels"] = (
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="image1" Target="../media/common.png"/></Relationships>').encode()
    files["ppt/media/common.png"] = bytes(buf.data())
    with zipfile.ZipFile(src, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    plan = dict(slides=[dict(index=i, frames=[dict(hide=[(3,0)] if step%2==0 else [],effects=[],auto=False) for step in range(10)]) for i in range(1, 5)])
    calls = {}
    layout = builtin.SlidePainter._layout_text
    decode = builtin.QImage.fromData
    class NoReuse(dict):
        def __contains__(self, key):
            return False
    original_init = builtin.SlidePainter.__init__
    original_image = builtin.Package.image
    def run(cached):
        counter = dict(layouts=0, decodes=0)
        def counted_layout(self,*args,**kw):
            counter["layouts"] += 1
            return layout(self,*args,**kw)
        def counted_decode(*args,**kw):
            counter["decodes"] += 1
            return decode(*args,**kw)
        def init(self,*args):
            original_init(self,*args)
            if not cached:
                self._text_layouts = NoReuse()
        def get_image(self,name):
            if not cached:
                self._images.clear()
                self._image_bytes = 0
            return original_image(self,name)
        target = out / ("cached.pdf" if cached else "uncached.pdf")
        started = time.perf_counter()
        with patch.object(builtin.SlidePainter,"__init__",init), patch.object(builtin.SlidePainter,"_layout_text",counted_layout), patch.object(builtin.Package,"image",get_image), patch.object(builtin.QImage,"fromData",counted_decode):
            builtin.pptx_to_pdf(src,target,plan)
        counter["seconds"] = round(time.perf_counter()-started,4)
        calls["cached" if cached else "uncached"] = counter
        doc = QPdfDocument()
        doc.load(str(target))
        assert doc.pageCount()==40
        pages = []
        for i in range(40):
            rendered = doc.render(i,QSize(640,360))
            assert not rendered.isNull()
            pages.append((bytes(rendered.constBits()),doc.getAllText(i).text()))
        doc.close()
        return pages
    # Warm the font/PDF infrastructure before timing either implementation.
    builtin.pptx_to_pdf(src,out/"warmup.pdf",dict(slides=[dict(index=1,frames=[dict(hide=[])])]))
    before = run(False)
    after = run(True)
    assert before==after, "缓存改变了页面像素或文字层"
    assert calls["cached"]["layouts"]==8 and calls["uncached"]["layouts"]==80
    assert calls["cached"]["decodes"]==1 and calls["uncached"]["decodes"]==40
    pk = builtin.Package(src)
    a = pk.image("ppt/media/common.png")
    a.fill(QColor("red"))
    assert pk.image("ppt/media/common.png").pixelColor(0,0)!=QColor("red")
    pk.image_budget=1
    pk._images.clear()
    pk._image_bytes=0
    assert not pk.image("ppt/media/common.png").isNull() and not pk._images
    pk.z.close()
    calls["speedup"] = round(calls["uncached"]["seconds"]/calls["cached"]["seconds"],2)
    (out/"benchmark.json").write_text(json.dumps(calls,indent=2),encoding="utf-8")
    print("PPT_SPEED_OK",json.dumps(calls),flush=True)


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
