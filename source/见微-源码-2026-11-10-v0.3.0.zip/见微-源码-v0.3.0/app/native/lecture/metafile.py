"""Windows metafile playback into memory; no Office, shell, or object activation."""
import ctypes
import gzip
import io
import math
import struct
import sys
from functools import lru_cache
from ctypes import wintypes as wt
from PySide6.QtCore import QBuffer,QIODevice
from PySide6.QtGui import QImage,QPainter


class _Info(ctypes.Structure):
    _fields_=[('size',wt.DWORD),('width',wt.LONG),('height',wt.LONG),('planes',wt.WORD),
              ('bits',wt.WORD),('compression',wt.DWORD),('image_size',wt.DWORD),
              ('xppm',wt.LONG),('yppm',wt.LONG),('used',wt.DWORD),('important',wt.DWORD)]


class _MetaPicture(ctypes.Structure):
    _fields_=[('mode',wt.LONG),('x',wt.LONG),('y',wt.LONG),('handle',wt.HANDLE)]


@lru_cache(maxsize=1)
def _gdi():
    g=ctypes.WinDLL('gdi32',use_last_error=True)
    def bind(name,args,result):
        fn=getattr(g,name)
        fn.argtypes=args
        fn.restype=result
    bind('CreateCompatibleDC',[wt.HDC],wt.HDC)
    bind('DeleteDC',[wt.HDC],wt.BOOL)
    bind('SetEnhMetaFileBits',[wt.UINT,ctypes.c_void_p],wt.HANDLE)
    bind('SetWinMetaFileBits',[wt.UINT,ctypes.c_void_p,wt.HDC,ctypes.POINTER(_MetaPicture)],wt.HANDLE)
    bind('GetEnhMetaFileHeader',[wt.HANDLE,wt.UINT,ctypes.c_void_p],wt.UINT)
    bind('DeleteEnhMetaFile',[wt.HANDLE],wt.BOOL)
    bind('CreateDIBSection',[wt.HDC,ctypes.POINTER(_Info),wt.UINT,ctypes.POINTER(ctypes.c_void_p),wt.HANDLE,wt.DWORD],wt.HANDLE)
    bind('SelectObject',[wt.HDC,wt.HANDLE],wt.HANDLE)
    bind('DeleteObject',[wt.HANDLE],wt.BOOL)
    bind('PlayEnhMetaFile',[wt.HDC,wt.HANDLE,ctypes.POINTER(wt.RECT)],wt.BOOL)
    bind('GdiFlush',[],wt.BOOL)
    return g


def _pass(g,handle,w,h,background):
    dc=g.CreateCompatibleDC(None)
    if not dc:
        return QImage()
    bitmap=previous=None
    try:
        info=_Info(ctypes.sizeof(_Info),w,-h,1,32,0,w*h*4,0,0,0,0)
        address=ctypes.c_void_p()
        bitmap=g.CreateDIBSection(dc,ctypes.byref(info),0,ctypes.byref(address),None,0)
        if not bitmap or not address.value:
            return QImage()
        previous=g.SelectObject(dc,bitmap)
        ctypes.memset(address,background,w*h*4)
        if not g.PlayEnhMetaFile(dc,handle,ctypes.byref(wt.RECT(0,0,w,h))):
            return QImage()
        g.GdiFlush()
        raw=ctypes.string_at(address,w*h*4)
        return QImage(raw,w,h,w*4,QImage.Format.Format_RGB32).copy()
    finally:
        if previous:
            g.SelectObject(dc,previous)
        if bitmap:
            g.DeleteObject(bitmap)
        g.DeleteDC(dc)


def render(ext,data):
    """Recover an embedded EMF/WMF preview with bounded raster size and alpha."""
    if sys.platform!='win32' or not data or len(data)>64*1024*1024:
        return QImage()
    if data[:2]==b'\x1f\x8b':
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
                data=stream.read(64*1024*1024+1)
        except (OSError,EOFError):
            return QImage()
        if len(data)>64*1024*1024:
            return QImage()
    emf=len(data)>=88 and data[:4]==b'\x01\x00\x00\x00' and data[40:44]==b' EMF'
    placeable=len(data)>=22 and data[:4]==b'\xd7\xcd\xc6\x9a'
    wmf=placeable or (len(data)>=18 and data[:2] in (b'\x01\x00',b'\x02\x00') and data[2:4]==b'\x09\x00')
    if not emf and not wmf:
        return QImage()
    g=_gdi()
    ref=g.CreateCompatibleDC(None)
    handle=None
    try:
        if emf:
            raw=ctypes.create_string_buffer(data)
            handle=g.SetEnhMetaFileBits(len(data),raw)
        else:
            x=y=2540
            if placeable:
                left,top,right,bottom,inch=struct.unpack_from('<hhhhH',data,6)
                if inch and right>left and bottom>top:
                    x=max(1,round((right-left)*2540/inch))
                    y=max(1,round((bottom-top)*2540/inch))
                data=data[22:]
            raw=ctypes.create_string_buffer(data)
            picture=_MetaPicture(8,x,y,None)
            handle=g.SetWinMetaFileBits(len(data),raw,ref,ctypes.byref(picture))
        if not handle:
            return QImage()
        header=ctypes.create_string_buffer(108)
        if g.GetEnhMetaFileHeader(handle,len(header),header)<88:
            return QImage()
        left,top,right,bottom=struct.unpack_from('<iiii',header.raw,24)
        pw,ph=(right-left)*72/2540,(bottom-top)*72/2540
        if pw<=0 or ph<=0:
            left,top,right,bottom=struct.unpack_from('<iiii',header.raw,8)
            pw,ph=right-left,bottom-top
        if not all(math.isfinite(v) and v>0 for v in (pw,ph)):
            return QImage()
        factor=min(4.0,2048/max(pw,ph))
        w=max(4,(math.ceil(pw*factor)+3)//4*4)
        h=max(1,math.ceil(ph*factor))
        white,black=_pass(g,handle,w,h,255),_pass(g,handle,w,h,0)
        if white.isNull() or black.isNull():
            return QImage()
        # Two backgrounds distinguish transparent paper from opaque white objects.
        difference=white.copy()
        p=QPainter(difference)
        try:
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Difference)
            p.drawImage(0,0,black)
        finally:
            p.end()
        difference.invertPixels()
        alpha=difference.convertToFormat(QImage.Format.Format_Grayscale8)
        result=black.convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
        # Width is a multiple of four, so the grayscale rows contain no padding.
        result.bits()[3::4]=bytes(alpha.constBits())
        return result
    finally:
        if handle:
            g.DeleteEnhMetaFile(handle)
        if ref:
            g.DeleteDC(ref)


def to_png(items):
    out=[]
    for ext,data in items:
        image=render(ext,data)
        if image.isNull():
            out.append(None)
            continue
        buffer=QBuffer()
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        out.append(bytes(buffer.data()) if image.save(buffer,'PNG') else None)
    return out
