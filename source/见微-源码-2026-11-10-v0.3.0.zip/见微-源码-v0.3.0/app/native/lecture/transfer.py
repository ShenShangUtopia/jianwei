"""课件与黑板互通界面；通过注入的 ClipBus 路由到其他模块。"""
from __future__ import annotations

from PySide6.QtCore import QRectF, QTimer
from PySide6.QtWidgets import QApplication, QMenu

from ..kit.clip import ClipBus
from ..kit import pen
from .board_transfer import crop_ink
from . import inserts


class LectureTransfer:
    def prepare_transfer(self,bus):
        self.clip_bus = bus or ClipBus(self)
        self.include_transfer_ink = True
        self.base_timeline = self._read_timeline()
        self.insert_error = ""
        try:
            self.doc,self.projected_timeline,self.seed_ink = inserts.project(self.base_doc,self.base_timeline,self.dir,self.clip_bus.store)
        except (OSError,ValueError,TypeError,KeyError) as exc:
            self.doc,self.projected_timeline,self.seed_ink = self.base_doc,self.base_timeline,{}
            self.insert_error = str(exc)
        if bus is None:
            self.clip_bus.sent.connect(self._local_route)
            self.clip_bus.origin_requested.connect(self.show_origin)

    def _read_timeline(self):
        from . import library
        return library.read_json(self.dir/"anim.json")

    def bind_transfer(self):
        canvas = self.board.canvas
        canvas.clip_store = self.clip_bus.store
        canvas.lecture_id = self.meta["id"]
        canvas.origin_requested.connect(self.clip_bus.origin_requested)
        self.clip_bus.error.connect(self.toast)
        self.view.persistent_empty = set(self.seed_ink)
        if self.meta.get("clip_id"):
            self.view.slides[0]["clip_id"] = self.meta["clip_id"]
        from ..kit.clip_ui import ClipInteraction
        self.transfer_bindings = [
            ClipInteraction(self.view,self.clip_bus,self.lecture_clip,lambda c:self.clip_bus.send(c,"lecture",self),self),
            ClipInteraction(canvas,self.clip_bus,canvas.export_clip,lambda c:self.clip_bus.send(c,"board",self),self,
                            origin=lambda:canvas.sel.get("origin",{}) if canvas.sel else {}),
            ClipInteraction(self,self.clip_bus,lambda:canvas.export_clip() if self.view_mode=="board" else self.lecture_clip(),
                            lambda c:self.clip_bus.send(c,"board" if self.view_mode=="board" else "lecture",self),self)]
        self.share_btn = self.add_share_key(lambda:self.transfer_menu(anchor=self.share_btn))
        self.board.add_share(lambda:self.transfer_menu(board=True,anchor=self.board.share_key))
        if self.insert_error:
            self.show_storage_error("插页已保护："+self.insert_error)

    def lecture_clip(self,ink_only=False):
        rect = self.view.sel or QRectF(0,0,*self.view.page_size())
        slide = self.view.slides[self.view.page]
        ref = dict(lecture_id=self.meta["id"],page_key=slide.get("key",f"s:{self.view.page}"),
                   slide=slide.get("source_slide",self.view.page),frame=self.view.frame-slide["first"])
        origin = dict(type="lecture",ref=ref,rect=[rect.x(),rect.y(),rect.width(),rect.height()])
        return self.clip_bus.store.create(image=None if ink_only else self.view.capture(rect,include_ink=False),
              ink=crop_ink(self.view.history().strokes,rect) if self.include_transfer_ink or ink_only else [],
              text="" if ink_only else self.view.selection_text(rect),origin=origin,width=rect.width(),height=rect.height())

    def _local_route(self,clip,target,context):
        if context is not None and context is not self:
            return
        if target == "board":
            self.receive_board(clip)
        elif target == "lecture":
            self.insert_clip(clip)
        elif target == "basket":
            self.toast("已放入素材篮")
        else:
            self.toast("请从见微主窗口打开课件以使用工作台互通")

    def receive_board(self,clip):
        self._show_board()
        QTimer.singleShot(30,self.board.canvas,lambda:self.board.canvas.receive_clip(clip))
        self.toast("已带入黑板，笔迹可编辑；选中素材可回到来源")

    def insert_clip(self,clip):
        if self.insert_error:
            self.show_storage_error(self.insert_error)
            return
        try:
            self.save()
            anchor = self.view.slides[self.view.page].get("key",f"s:{self.view.page}")
            key = inserts.add(self.dir,anchor,clip)
            doc,timeline,seeds = inserts.project(self.base_doc,self.base_timeline,self.dir,self.clip_bus.store)
            view = self.view
            view.pen_session.reset()
            view._stop_run()
            if view.active is not None:
                view._finish_stroke()
            view.doc = self.doc = doc
            view.frames,view.slides = timeline["frames"],timeline["slides"]
            if self.meta.get("clip_id"):
                view.slides[0]["clip_id"] = self.meta["clip_id"]
            view.pages = len(view.slides)
            view.persistent_empty = set(seeds) | ({0} if self.meta.get("clip_id") else set())
            for history_id,strokes in seeds.items():
                if history_id not in view.histories:
                    view.histories[history_id] = pen.History(strokes)
            view.cache,view.cache_order,view._ink_cache = {},[],{}
            index = next(i for i,s in enumerate(view.slides) if s["key"]==key)
            view.page,view.frame = index,view.slides[index]["first"]
            view.ox,view.oy,view.zoom = 0,0,1
            if self.grid is not None:
                self.grid_timer.stop()
                self.grid.hide()
                self.grid.deleteLater()
                self.grid = None
            self._on_page(index)
            from . import library
            added = len(inserts.manifest(self.dir)["items"])
            library.update(self.meta["id"],display_pages=view.pages,insert_pages=added)
            view.update()
            self.save()
            self.toast("已在当前页后添加插页，原文件未改动")
        except (OSError,ValueError,KeyError,TypeError) as exc:
            self.show_storage_error(str(exc))

    def show_origin(self,origin):
        ref = origin.get("ref",{})
        if ref.get("lecture_id") != self.meta["id"]:
            return False
        if origin.get("type")=="board":
            index = next((i for i,b in enumerate(self.board.canvas.boards) if b.get("id")==ref.get("board_id")),None)
            if index is None:
                self.toast("来源黑板已不存在")
                return False
            self._show_board()
            canvas = self.board.canvas
            canvas.go_board(index-canvas.cur)
            canvas.export_rect = QRectF(*origin.get("rect",[0,0,1,1]))
            canvas.update()
        else:
            key = ref.get("page_key",f"s:{ref.get('slide',0)}")
            index = next((i for i,s in enumerate(self.view.slides) if s.get("key",f"s:{i}")==key),None)
            if index is None:
                self.toast("来源页面已不存在")
                return False
            self.set_view("slide")
            self.view.go(index)
            self.view._stop_run()
            slide = self.view.slides[index]
            self.view.frame = min(slide["last"],slide["first"]+max(0,int(ref.get("frame",0))))
            self.view.highlight_source(QRectF(*origin.get("rect",[0,0,*self.view.page_size()])))
            self._sync_num()
        self.show()
        self.raise_()
        self.activateWindow()
        return True

    def transfer_menu(self,_checked=False,board=False,anchor=None):
        from ..kit.pen_bar import menu_style
        menu = QMenu(self)
        menu.setStyleSheet(menu_style())
        flag = menu.addAction("附带可编辑笔迹")
        flag.setCheckable(True)
        flag.setChecked(self.include_transfer_ink)
        flag.triggered.connect(lambda on:setattr(self,"include_transfer_ink",on))
        maker = self.board.canvas.export_clip if board else self.lecture_clip
        def send(target,ink_only=False):
            self.clip_bus.send(maker(ink_only=ink_only),target,self)
        menu.addAction("整页 / 当前选区带入黑板",lambda:send("board"))
        menu.addAction("仅发送笔迹到黑板",lambda:send("board",True))
        menu.addAction("作为插页放进课件",lambda:send("lecture"))
        menu.addAction("放入素材篮",lambda:send("basket"))
        bench = menu.addMenu("作为底图送到工作台")
        for bid,name in (("draw","几何画板"),("scene","场景搭建"),("circ","电路"),("phys","力学"),("chem","化学")):
            bench.addAction(name,lambda _=False,k=bid:send("bench:"+k))
        menu.addAction("作为题目分析并打开工作台",lambda:send("analysis"))
        menu.addSeparator()
        menu.addAction("复制素材（含来源和矢量笔迹）",lambda:QApplication.clipboard().setMimeData(self.clip_bus.store.mime(maker())))
        menu.addAction("粘贴到黑板",lambda:self.clip_bus.send(self.clip_bus.store.from_mime(QApplication.clipboard().mimeData()),"board",self))
        if board:
            menu.addAction("框选黑板区域",lambda:self.board.canvas.set_tool("region"))
            menu.addAction("整块黑板导出到课件库",lambda:self.export_board_library())
        else:
            slide = self.view.slides[self.view.page]
            if slide.get("clip_id"):
                clip = self.clip_bus.store.load(slide["clip_id"])
                menu.addAction("回到插页来源",lambda:self.clip_bus.origin_requested.emit(clip.get("origin",{})))
        if anchor is not None and anchor.isVisible():
            # 贴着按钮弹：放映条在底部时往上弹，黑板条在顶部时往下弹
            top = anchor.mapToGlobal(anchor.rect().topLeft())
            below = anchor.mapToGlobal(anchor.rect().bottomLeft())
            h = menu.sizeHint().height()
            screen = anchor.screen().availableGeometry() if anchor.screen() else None
            at = below if screen is None or below.y() + h <= screen.bottom() else top - type(top)(0, h)
            menu.exec(at)
        else:
            menu.exec(self.mapToGlobal(self.rect().center()))

    def export_board_library(self):
        from . import library
        meta = library.from_clip(self.board.canvas.export_clip(),self.clip_bus.store,"黑板导出")
        self.toast("已存入课件库："+meta["title"])
