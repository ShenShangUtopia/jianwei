"""课件插页：虚拟 PDF 页面与播放投影；不修改原 PDF 或动画步骤。"""
from __future__ import annotations

import copy
import uuid

from PySide6.QtCore import QLockFile, QRectF, QSizeF, Qt
from PySide6.QtGui import QImage, QPainter

from ..kit.clip import read_json, write_json
from . import anim


class Selection:
    def __init__(self,text,rect):
        self.value,self.rect = text,rect

    def text(self):
        return self.value

    def boundingRectangle(self):  # noqa: N802
        return self.rect


class Document:
    def __init__(self,base,records,store):
        self.base,self.records,self.store = base,records,store
        self.clips = [store.load(row["clip_id"]) for row in records]

    def pageCount(self):  # noqa: N802
        return self.base.pageCount()+len(self.clips)

    def pagePointSize(self,index):  # noqa: N802
        if index < self.base.pageCount():
            return self.base.pagePointSize(index)
        space = self.clips[index-self.base.pageCount()]["space"]
        return QSizeF(space["width"],space["height"])

    def render(self,index,size):
        if index < self.base.pageCount():
            return self.base.render(index,size)
        clip = self.clips[index-self.base.pageCount()]
        image = QImage(size,QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.white)
        painter = QPainter(image)
        painter.drawImage(0,0,self.store.render(clip,size,include_ink=False))
        painter.end()
        return image

    def getAllText(self,index):  # noqa: N802
        if index < self.base.pageCount():
            return self.base.getAllText(index)
        return Selection(self.clips[index-self.base.pageCount()].get("text",""),QRectF(QSizeF(self.pagePointSize(index)).width()/2,0,1,1))

    def getSelectionAtIndex(self,index,start,count):  # noqa: N802
        if index < self.base.pageCount():
            return self.base.getSelectionAtIndex(index,start,count)
        clip = self.clips[index-self.base.pageCount()]
        return Selection(clip.get("text","")[start:start+count],QRectF(0,0,clip["space"]["width"],clip["space"]["height"]))


def manifest(folder):
    value = read_json(folder/"inserts.json",dict(version=1,items=[]))
    if not isinstance(value,dict) or value.get("version") != 1 or not isinstance(value.get("items"),list):
        raise ValueError("插页存档损坏或来自更新版本，已保留原文件")
    return value


def project(base,timeline,folder,store):
    value = manifest(folder)
    rows = value["items"]
    for row in rows:
        if (not isinstance(row,dict) or not isinstance(row.get("id"),str) or
            type(row.get("history_id")) is not int or row["history_id"] < 1_000_000_000):
            raise ValueError("插页记录无效，已保留原文件")
    if len({row["history_id"] for row in rows}) != len(rows):
        raise ValueError("插页笔迹编号重复，已保留原文件")
    tl = copy.deepcopy(timeline or anim.identity(base.pageCount()))
    doc = Document(base,rows,store)
    source_slides = tl["slides"]
    anchors = {f"s:{i}" for i in range(len(source_slides))}
    keys = ["i:"+r["id"] for r in rows]
    if len(set(keys)) != len(keys):
        raise ValueError("插页编号重复，已保留原文件")
    anchors.update(keys)
    if any(r.get("after") not in anchors for r in rows):
        raise ValueError("插页来源页不存在，已保留原文件")
    frames,slides,seeds,visited = [],[],{},set()

    def append(source,key,history_id,clip=None):
        if key in visited:
            raise ValueError("插页关系循环")
        visited.add(key)
        record = copy.deepcopy(source)
        record.update(first=len(frames),key=key,history_id=history_id)
        source_frames = source["_frames"]
        record.pop("_frames",None)
        for frame in source_frames:
            frame = copy.deepcopy(frame)
            frame["slide"] = len(slides)
            frames.append(frame)
        record["last"] = len(frames)-1
        if clip is not None:
            record["clip_id"] = clip["id"]
            seeds[history_id] = clip.get("ink",[])
        slides.append(record)
        for index,row in enumerate(rows):
            if row["after"] == key:
                append(dict(transition=None,adv=None,_frames=[dict(page=base.pageCount()+index,effects=[],auto=False)]),
                       "i:"+row["id"],row["history_id"],doc.clips[index])

    for index,slide in enumerate(source_slides):
        source = dict(slide,_frames=tl["frames"][slide["first"]:slide["last"]+1])
        source["source_slide"] = index
        append(source,f"s:{index}",index)
    if len(visited) != len(source_slides)+len(rows):
        raise ValueError("插页关系循环，已保留原文件")
    return doc,dict(frames=frames,slides=slides),seeds


def add(folder,after,clip):
    lock = QLockFile(str(folder/"inserts.lock"))
    if not lock.tryLock(0):
        raise ValueError("另一窗口正在添加插页，请稍后重试")
    try:
        value = manifest(folder)
        row = dict(id=uuid.uuid4().hex,after=after,clip_id=clip["id"],history_id=1_000_000_000+int(uuid.uuid4().hex[:12],16))
        value["items"].append(row)
        write_json(folder/"inserts.json",value)
        return "i:"+row["id"]
    finally:
        lock.unlock()
