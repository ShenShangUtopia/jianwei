"""放映效果：比较前后两页，取出变化的部分，做淡入、飞入、擦除、缩放、切换。"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QImage, QPainter, QPixmap

# 差异值 → 透明度：小于 6 当没变（渲染误差），到 30 算完全不透明，边缘的抗锯齿能保留下来
_RAMP = bytes(0 if i < 6 else 255 if i >= 30 else int((i - 6) * 255 / 24) for i in range(256))


def ease(t):
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def changed_mask(a: QImage, b: QImage) -> QImage:
    """a、b 不同的地方不透明。全用 Qt 和 bytes.translate，1080p 也只要几毫秒。"""
    d = a.convertToFormat(QImage.Format.Format_RGB32)
    p = QPainter(d)
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Difference)
    p.drawImage(0, 0, b)
    p.end()
    gray = d.convertToFormat(QImage.Format.Format_Grayscale8)
    raw = bytes(gray.constBits()).translate(_RAMP)
    return QImage(raw, gray.width(), gray.height(), gray.bytesPerLine(), QImage.Format.Format_Alpha8).copy()


def cutout(src: QImage, mask, rect: QRectF) -> QPixmap:
    """src 在 rect 里、且 mask 不透明的部分。mask 为 None 时整块都要。"""
    out = QImage(src.size(), QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setClipRect(rect)
    p.drawImage(0, 0, src)
    if mask is not None:
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
        p.drawImage(0, 0, mask)
    p.end()
    return QPixmap.fromImage(out)


def _rect_px(fr, w, h):
    if not fr:
        return QRectF(0, 0, w, h)
    m = 3
    return QRectF(fr[0] * w - m, fr[1] * h - m, fr[2] * w + 2 * m, fr[3] * h + 2 * m).intersected(QRectF(0, 0, w, h))


class Run:
    """一次动画：前一页 → 后一页，中间若干图层。"""

    def __init__(self, a: QPixmap, b: QPixmap, effects, transition=None):
        self.a, self.b = a, b
        self.layers = []
        self.transition = transition
        self.base_b = False
        self.total = 0.0
        w, h = a.width(), a.height()
        if transition:
            self.total = 0 if transition["kind"] == "cut" else transition["dur"] / 1000
            return
        ia, ib = a.toImage().convertToFormat(QImage.Format.Format_RGB32), b.toImage().convertToFormat(QImage.Format.Format_RGB32)
        mask = changed_mask(ia, ib) if effects else None
        for e in effects:
            r = _rect_px(e.get("rect"), w, h)
            dur = e["dur"] / 1000
            delay = e.get("delay", 0) / 1000
            layer = dict(effect=e["effect"], dir=e["dir"], kind=e["kind"], dur=dur, delay=delay, rect=r)
            if e.get("effect") == "path" and e.get("path"):
                # 动作路径：前一页里形状原来那块沿路径移动；后一页里它的终点先用前一页盖住，走到了再露出
                pts = e["path"]
                end = pts[-1]
                r_end = r.translated(end[0] * w, end[1] * h).intersected(QRectF(0, 0, w, h))
                layer["pm"] = cutout(ia, mask, r)
                layer["cover"] = cutout(ia, mask, r_end)
                layer["path"] = [(x * w, y * h) for x, y in pts]
                self.base_b = True
            elif e["kind"] == "in":
                layer["pm"] = cutout(ib, mask, r)
            elif e["kind"] == "out":
                layer["pm"] = cutout(ia, mask, r)
                layer["under"] = cutout(ib, mask, r)   # 飞走之后露出来的东西
            else:
                layer["pm"] = cutout(ia, None, r)
                dur = max(dur, 0.5)
                layer["dur"] = dur
            self.layers.append(layer)
            self.total = max(self.total, delay + dur)
        self.total = min(self.total, 8.0)

    def paint(self, p: QPainter, t: float) -> None:
        """p 的坐标是渲染像素，原点在页面左上角。"""
        p.save()
        try:
            self._paint(p, t)
        finally:
            p.restore()

    def _paint(self, p: QPainter, t: float) -> None:
        w, h = self.a.width(), self.a.height()
        p.setClipRect(QRectF(0, 0, w, h), Qt.ClipOperation.IntersectClip)
        if t >= self.total:
            p.drawPixmap(0, 0, self.b)
            return
        if self.transition:
            self._transition(p, t, w, h)
            return
        p.drawPixmap(0, 0, self.b if self.base_b else self.a)
        if self.base_b:
            for L in self.layers:
                if "cover" in L and t - L["delay"] < L["dur"]:
                    p.drawPixmap(0, 0, L["cover"])
        for L in self.layers:
            q = (t - L["delay"]) / max(0.001, L["dur"])
            if L["kind"] == "out":
                p.drawPixmap(0, 0, L["under"])
            if L["kind"] == "in" and q <= 0:
                continue
            self._layer(p, L, max(0.0, min(1.0, q)), w, h)

    def _transition(self, p, t, w, h):
        tr = self.transition
        e = ease(t / max(0.001, self.total)) if self.total else 1.0
        kind, d = tr["kind"], tr.get("dir", "l")
        p.drawPixmap(0, 0, self.a)
        if kind == "fade" or kind == "cut":
            p.setOpacity(e)
            p.drawPixmap(0, 0, self.b)
        elif kind in ("push", "cover"):
            dx = {"l": w, "r": -w}.get(d, 0) * (1 - e)
            dy = {"u": h, "d": -h}.get(d, 0) * (1 - e)
            if kind == "push":
                p.fillRect(QRectF(0, 0, w, h), Qt.GlobalColor.black)
                ax = dx - (w if d == "l" else -w if d == "r" else 0)
                ay = dy - (h if d == "u" else -h if d == "d" else 0)
                p.drawPixmap(QPointF(ax, ay), self.a)
            p.drawPixmap(QPointF(dx, dy), self.b)
        else:   # wipe
            clip = {"l": QRectF(w * (1 - e), 0, w * e, h), "r": QRectF(0, 0, w * e, h), "u": QRectF(0, h * (1 - e), w, h * e), "d": QRectF(0, 0, w, h * e)}.get(d, QRectF(0, 0, w * e, h))
            p.setClipRect(clip, Qt.ClipOperation.IntersectClip)
            p.drawPixmap(0, 0, self.b)

    @staticmethod
    def _layer(p, L, q, w, h):
        """q 是这层动画的进度。退出的效果就是进入倒着放。"""
        e = ease(q)
        if L["kind"] == "out":
            v = 1 - q * q
        else:
            v = e
        name, r = L["effect"], L["rect"]
        p.save()
        c = r.center()
        if name == "fade":
            p.setOpacity(v)
        elif name == "appear":
            p.setOpacity(1 if (q >= 1 or L["kind"] != "out") and (q > 0 or L["kind"] == "out") else 0)
            if L["kind"] == "out" and q >= 1:
                p.setOpacity(0)
        elif name == "wipe":
            d = L["dir"]
            clip = {"l": QRectF(r.x(), r.y(), r.width() * v, r.height()), "r": QRectF(r.right() - r.width() * v, r.y(), r.width() * v, r.height()),
                    "t": QRectF(r.x(), r.y(), r.width(), r.height() * v), "b": QRectF(r.x(), r.bottom() - r.height() * v, r.width(), r.height() * v)}.get(d, QRectF(r.x(), r.y(), r.width() * v, r.height()))
            p.setClipRect(clip, Qt.ClipOperation.IntersectClip)
        elif name == "fly":
            far = {"l": QPointF(-r.right(), 0), "r": QPointF(w - r.x(), 0), "t": QPointF(0, -r.bottom()), "b": QPointF(0, h - r.y())}.get(L["dir"], QPointF(0, h - r.y()))
            p.translate(far * (1 - v))
        elif name == "float":
            off = {"l": QPointF(-40, 0), "r": QPointF(40, 0), "t": QPointF(0, -40), "b": QPointF(0, 40)}.get(L["dir"], QPointF(0, 40))
            p.translate(off * (1 - v))
            p.setOpacity(v)
        elif name == "zoom":
            s = 0.3 + 0.7 * v
            p.translate(c)
            p.scale(s, s)
            p.translate(-c)
            p.setOpacity(v)
        elif name == "spin":
            p.translate(c)
            p.rotate(360 * (1 - v))
            s = max(0.05, v)
            p.scale(s, s)
            p.translate(-c)
            p.setOpacity(v)
        elif name == "path":
            pts = L["path"]
            seg = e * (len(pts) - 1)
            i = min(len(pts) - 2, int(seg)) if len(pts) > 1 else 0
            f = seg - i
            x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f if len(pts) > 1 else 0
            y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f if len(pts) > 1 else 0
            p.translate(x, y)
        elif name == "pulse":
            s = 1 + 0.07 * math.sin(math.pi * q)
            p.translate(c)
            p.scale(s, s)
            p.translate(-c)
        p.drawPixmap(0, 0, L["pm"])
        p.restore()
