import sys,os,ctypes,gzip
from pathlib import Path
from native.kit import test_runtime
test_runtime.configure()
def main(target):
 os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
 from .rich_symbols import symbol_text
 assert symbol_text('\uf032\uf03d','Symbol')=='2='
 assert symbol_text('\uf061','Symbol')=='α'
 assert symbol_text('\uf032','Arial')=='\uf032'
 from ctypes import wintypes as w
 from native.lecture.metafile import _gdi,render
 from native.lecture.builtin import SlidePainter,P,A
 from xml.etree import ElementTree as ET
 from PySide6.QtGui import QImage,QPainter
 from PySide6.QtCore import Qt
 test_runtime.application([])
 out=Path(target);out.mkdir(parents=True,exist_ok=True)
 g=_gdi()
 for name,args,result in [('CreateEnhMetaFileW',[w.HDC,w.LPCWSTR,ctypes.POINTER(w.RECT),w.LPCWSTR],w.HDC),('CloseEnhMetaFile',[w.HDC],w.HANDLE),('GetEnhMetaFileBits',[w.HANDLE,w.UINT,ctypes.c_void_p],w.UINT),('MoveToEx',[w.HDC,ctypes.c_int,ctypes.c_int,ctypes.c_void_p],w.BOOL),('LineTo',[w.HDC,ctypes.c_int,ctypes.c_int],w.BOOL),('TextOutW',[w.HDC,ctypes.c_int,ctypes.c_int,w.LPCWSTR,ctypes.c_int],w.BOOL)]:
  fn=getattr(g,name);fn.argtypes=args;fn.restype=result
 dc=g.CreateEnhMetaFileW(None,None,ctypes.byref(w.RECT(0,0,3000,1500)),None)
 assert dc
 g.GetStockObject.argtypes=[ctypes.c_int];g.GetStockObject.restype=w.HANDLE
 g.SelectObject(dc,g.GetStockObject(17))
 g.TextOutW(dc,5,5,'Br2    C=O',10)
 for y in (40,46):g.MoveToEx(dc,5,y,None);g.LineTo(dc,100,y)
 handle=g.CloseEnhMetaFile(dc)
 try:
  n=g.GetEnhMetaFileBits(handle,0,None);buf=ctypes.create_string_buffer(n);assert g.GetEnhMetaFileBits(handle,n,buf)==n
  raw=buf.raw
 finally:g.DeleteEnhMetaFile(handle)
 (out/'sample.emf').write_bytes(raw)
 for ext,data in [('emf',raw),('emz',gzip.compress(raw))]:
  image=render(ext,data);assert not image.isNull();assert image.save(str(out/(ext+'.png')))
  assert any(image.pixelColor(x,y).alpha()>0 for y in range(image.height()) for x in range(image.width()))
 assert render('emf',b'bad').isNull()
 class Deck:
  theme={}
  def color(self,node):return None
 for cmpd,expected in [('dbl',2),('sng',1)]:
  image=QImage(300,140,QImage.Format.Format_RGB32);image.fill(Qt.GlobalColor.white)
  p=QPainter(image)
  renderer=SlidePainter(Deck(),p)
  el=ET.fromstring(f'<p:cxnSp xmlns:p="{P[1:-1]}" xmlns:a="{A[1:-1]}"><p:spPr><a:xfrm><a:off x="12700" y="88900"/><a:ext cx="330200" cy="0"/></a:xfrm><a:prstGeom prst="line"/><a:ln w="22860" cmpd="{cmpd}"/></p:spPr></p:cxnSp>')
  renderer.sp(el,{},dict(layout=None,master=None));p.end()
  bands=0;inside=False
  for y in range(140):
   dark=image.pixelColor(140,y).lightness()<128
   if dark and not inside:bands+=1
   inside=dark
  assert bands==expected,(cmpd,bands)
  image.save(str(out/(cmpd+'.png')))

 # Legacy WMF conversion and compressed WMZ use the same in-memory path.
 g.GetWinMetaFileBits.argtypes=[w.HANDLE,w.UINT,ctypes.c_void_p,ctypes.c_int,w.HDC];g.GetWinMetaFileBits.restype=w.UINT
 buf=ctypes.create_string_buffer(raw);handle=g.SetEnhMetaFileBits(len(raw),buf);ref=g.CreateCompatibleDC(None)
 try:
  n=g.GetWinMetaFileBits(handle,0,None,8,ref);assert n
  buf=ctypes.create_string_buffer(n);assert g.GetWinMetaFileBits(handle,n,buf,8,ref)==n
  assert not render('wmf',buf.raw).isNull()
  assert not render('wmz',gzip.compress(buf.raw)).isNull()
 finally:g.DeleteEnhMetaFile(handle);g.DeleteDC(ref)
 from native.lecture.builtin import docx_to_pdf,pptx_to_pdf,R,W,V
 from native.lecture.selftest import make_pptx
 import zipfile
 from PySide6.QtPdf import QPdfDocument
 from PySide6.QtCore import QSize
 # VML equation previews retain their actual image, never activate OLE objects.
 word=out/'vml.docx'
 xml=f'<w:document xmlns:w="{W[1:-1]}" xmlns:v="{V[1:-1]}" xmlns:r="{R[1:-1]}"><w:body>'
 for tag in ('pict','object'):
  xml+=f'<w:p><w:r><w:{tag}><v:shape style="width:280pt;height:84pt"><v:imagedata r:id="preview"/></v:shape></w:{tag}></w:r></w:p>'
 xml+='<w:p><w:r><w:t>Br</w:t></w:r><w:r><w:rPr><w:vertAlign w:val="subscript"/></w:rPr><w:sym w:font="Symbol" w:char="F032"/></w:r><w:r><w:t> C</w:t></w:r><w:r><w:sym w:font="Symbol" w:char="F03D"/></w:r><w:r><w:t>O</w:t></w:r></w:p></w:body></w:document>'
 rel='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="preview" Target="media/chem.emf"/></Relationships>'
 with zipfile.ZipFile(word,'w') as z:
  z.writestr('word/document.xml',xml);z.writestr('word/_rels/document.xml.rels',rel);z.writestr('word/media/chem.emf',raw)
 docx_to_pdf(word,out/'vml.pdf')
 pdf=QPdfDocument();assert pdf.load(str(out/'vml.pdf'))==QPdfDocument.Error.None_
 text=pdf.getAllText(0).text()
 assert '2' in text and '=' in text and 'Br' in text
 image=pdf.render(0,QSize(595,842));assert not image.isNull()
 paper=QImage(image.size(),QImage.Format.Format_RGB32);paper.fill(Qt.GlobalColor.white);paint=QPainter(paper);paint.drawImage(0,0,image);paint.end();paper.save(str(out/'vml.png'));pdf.close()
 assert sum(paper.pixelColor(x,y).lightness()<128 for y in range(65,250) for x in range(65,360))>30
 # OLE preview nested inside a graphic frame, including no picture transform.
 ppt=out/'ole.pptx'
 ole='<p:graphicFrame><p:xfrm><a:off x="914400" y="914400"/><a:ext cx="3556000" cy="1066800"/></p:xfrm><a:graphic><a:graphicData><p:oleObj><p:pic><p:blipFill><a:blip r:embed="preview"/></p:blipFill></p:pic></p:oleObj></a:graphicData></a:graphic></p:graphicFrame>'
 make_pptx(ppt,n=1,extras={1:(ole,'')})
 with zipfile.ZipFile(ppt,'a') as z:
  z.writestr('ppt/slides/_rels/slide1.xml.rels',rel.replace('media/chem.emf','../media/chem.emf'));z.writestr('ppt/media/chem.emf',raw)
 pptx_to_pdf(ppt,out/'ole.pdf')
 pdf=QPdfDocument();assert pdf.load(str(out/'ole.pdf'))==QPdfDocument.Error.None_
 image=pdf.render(0,QSize(720,405));image.save(str(out/'ole.png'));pdf.close()
 assert not image.isNull()
 print('CHEMICAL OK EMF/EMZ, invalid preview, compound double bond raster bands, Word VML pict/object, PPT OLE preview')
 return 0
if __name__=='__main__':
 raise SystemExit(test_runtime.run(lambda: main(sys.argv[1])))
