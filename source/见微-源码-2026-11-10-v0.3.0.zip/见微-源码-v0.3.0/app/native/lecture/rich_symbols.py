"""OOXML scientific text: explicit font fallbacks and readable equation fallback."""
M='{http://schemas.openxmlformats.org/officeDocument/2006/math}'
_GREEK=dict(zip('ABGDEZHQIKLMNXOPRSTUFCYWabgdezhqiklmnxoprstufcyw',
                'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψω'))
_SYMBOL={**_GREEK,'J':'ϑ','j':'ϕ','V':'ς','v':'ϖ','D':'Δ','W':'Ω',
         '\u00b1':'±','\u00a3':'≤','\u00b3':'≥','\u00b9':'≠','\u00a5':'∞',
         '\u00ae':'→','\u00ab':'↔','\u00b4':'×','\u00b8':'÷','\u00d6':'√',
         '\u00e5':'∑','\u00d5':'∏','\u00f2':'∫'}
# Encoding values checked against Unicode's Adobe Symbol mapping:
# https://www.unicode.org/Public/MAPPINGS/VENDORS/ADOBE/symbol.txt
_SYMBOL.update({chr(k):v for k,v in {0x22:'∀',0x24:'∃',0x27:'∋',0x2a:'∗',0x2d:'−',
    0x40:'≅',0x5c:'∴',0x5e:'⊥',0x7e:'∼',0xa2:'′',0xac:'←',0xad:'↑',0xaf:'↓',
    0xb0:'°',0xb2:'″',0xb5:'∝',0xb6:'∂',0xba:'≡',0xbb:'≈',0xc6:'∅',0xc7:'∩',0xc8:'∪',
    0xc9:'⊃',0xca:'⊇',0xcb:'⊄',0xcc:'⊂',0xcd:'⊆',0xce:'∈',0xcf:'∉',0xd0:'∠',0xd1:'∇'}.items()})


def symbol_text(text,family):
    if str(family).casefold()!='symbol':
        return text
    def decode(ch):
        value = chr(ord(ch)-0xf000) if 0xf020<=ord(ch)<=0xf0ff else ch
        # Symbol keeps ASCII digits and ordinary punctuation at their original slots.
        # Unknown high-byte slots stay untouched rather than inventing a glyph.
        return _SYMBOL.get(value, value if ' '<=value<='~' else ch)
    return ''.join(decode(ch) for ch in text)


def families(*names):
    # Keep an explicitly requested font first; Qt can choose a fallback per glyph.
    return list(dict.fromkeys([str(n) for n in names if n and not str(n).startswith('+')]+
                             ['Cambria Math','Segoe UI Symbol','Microsoft YaHei','SimSun']))


def math_text(node,depth=0):
    """Readable linear equation, not a promise of full Office Math typesetting."""
    if node is None or depth>32:
        return ''
    tag=node.tag.rsplit('}',1)[-1]
    def part(name):
        return math_text(node.find(M+name),depth+1)
    if tag.endswith('Pr'):
        return ''
    if tag=='t':
        return (node.text or '')[:8000]
    if tag=='f':
        return '('+part('num')+')/('+part('den')+')'
    if tag in ('sSup','sSub','sSubSup'):
        out=part('e')
        if tag in ('sSub','sSubSup'):
            out+=' _('+part('sub')+')'
        if tag in ('sSup','sSubSup'):
            out+=' ^('+part('sup')+')'
        return out
    if tag=='rad':
        degree=part('deg')
        return ('√' if not degree else 'root['+degree+']')+'('+part('e')+')'
    if tag in ('limLow','limUpp'):
        return part('e')+(' _(' if tag=='limLow' else ' ^(')+part('lim')+')'
    if tag=='acc':
        char=node.find(M+'accPr/'+M+'chr')
        accent=char.get(M+'val','̂') if char is not None else '̂'
        base=part('e')
        return base+accent if len(base)==1 else 'accent['+accent+']('+base+')'
    if tag=='bar':
        position=node.find(M+'barPr/'+M+'pos')
        where=position.get(M+'val','top') if position is not None else 'top'
        return ('underline' if where=='bot' else 'overline')+'('+part('e')+')'
    if node.tag==M+'m':
        return '['+'; '.join(', '.join(math_text(c,depth+1) for c in row if c.tag==M+'e') for row in node if row.tag==M+'mr')+']'
    if tag=='eqArr':
        return '; '.join(math_text(c,depth+1) for c in node if c.tag==M+'e')
    if tag=='nary':
        c=node.find(M+'naryPr/'+M+'chr')
        op=c.get(M+'val','∫') if c is not None else '∫'
        return op+' _('+part('sub')+') ^('+part('sup')+') '+part('e')
    if tag=='d':
        return '('+'; '.join(math_text(c,depth+1) for c in node if c.tag==M+'e')+')'
    return ''.join(math_text(c,depth+1) for c in node)[:8000]


def paragraph_nodes(node):
    for child in node:
        if child.tag in (M+'oMath',M+'oMathPara') or child.tag.endswith('}r'):
            yield child
        else:
            yield from paragraph_nodes(child)
