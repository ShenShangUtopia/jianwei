"""黑板内容包适配：底图与矢量笔迹分开，移动图片时同步其笔迹组。"""
from __future__ import annotations

import copy
import uuid

from PySide6.QtCore import QPointF, QRectF, QSize
from PySide6.QtGui import QColor, QImage, QPainter

from ..kit.clip import ClipStore
from ..kit import pen, pen_tools


def crop_ink(strokes,rect):
    result = []
    for stroke in strokes:
        pts = pen.points_of(stroke)
        if not pts or not pen.bounds(stroke).intersects(rect):
            continue
        if all(rect.contains(QPointF(*p[:2])) for p in pts):
            result.extend(pen_tools.transform([stroke],-rect.x(),-rect.y()))
            continue
        chunks,chunk = [],[]
        for a,b in zip(pts,pts[1:]):
            dx,dy = b[0]-a[0],b[1]-a[1]
            lo,hi,valid = 0.,1.,True
            for p,q in ((-dx,a[0]-rect.left()),(dx,rect.right()-a[0]),(-dy,a[1]-rect.top()),(dy,rect.bottom()-a[1])):
                if abs(p)<1e-12:
                    if q<0:
                        valid = False
                        break
                elif p<0:
                    lo = max(lo,q/p)
                else:
                    hi = min(hi,q/p)
            if valid and lo<=hi:
                start = [a[j]+(b[j]-a[j])*lo for j in range(3)]
                end = [a[j]+(b[j]-a[j])*hi for j in range(3)]
                if chunk and (abs(chunk[-1][0]-start[0])+abs(chunk[-1][1]-start[1]))>1e-6:
                    chunks.append(chunk)
                    chunk = []
                if not chunk:
                    chunk.append(start)
                chunk.append(end)
            elif chunk:
                chunks.append(chunk)
                chunk = []
        if chunk:
            chunks.append(chunk)
        for points in chunks:
            part = copy.deepcopy(stroke)
            part.update(id=uuid.uuid4().hex,points=points,shape=dict(kind="polyline"))
            result.extend(pen_tools.transform([part],-rect.x(),-rect.y()))
    return result


class BoardTransfer:
    def transfer_store(self):
        return getattr(self,"clip_store",None) or ClipStore()

    def clip_origin(self,rect):
        return dict(type="board",ref=dict(lecture_id=getattr(self,"lecture_id",""),board_id=self.board.get("id",str(self.cur))),
                    rect=[rect.x(),rect.y(),rect.width(),rect.height()])

    def export_clip(self,rect=None,ink_only=False):
        if rect is None:
            rect = getattr(self,"export_rect",None)
        if rect is None and self.sel is not None:
            rect = QRectF(self.sel["x"],self.sel["y"],self.sel["w"],self.sel["h"])
        rect = QRectF(rect) if rect is not None else self.content_bounds()
        if rect.isEmpty():
            rect = QRectF(0,0,800,450)
        scale = min(2,2400/max(rect.width(),rect.height()))
        image = None
        if not ink_only:
            image = QImage(max(1,int(rect.width()*scale)),max(1,int(rect.height()*scale)),QImage.Format.Format_ARGB32_Premultiplied)
            image.fill(QColor(getattr(self,"clip_background","#1E3B31")))
            painter = QPainter(image)
            painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            painter.scale(scale,scale)
            painter.translate(-rect.topLeft())
            for item in self.board["items"]:
                self._draw_item(painter,item)
            painter.end()
        strokes = crop_ink(self.board["strokes"],rect)
        return self.transfer_store().create(image=image,ink=strokes,origin=self.clip_origin(rect),width=rect.width(),height=rect.height())

    def receive_clip(self,clip,at=None):
        self.snapshot()
        self.set_tool("move")
        w,h = clip["space"]["width"],clip["space"]["height"]
        k = min(max(200,self.width())/self.scale*.65/w,max(200,self.height())/self.scale*.65/h,1)
        center = at or self.view_center()
        item = dict(id=uuid.uuid4().hex,type="clip",clip_id=clip["id"],origin=copy.deepcopy(clip.get("origin",{})),
                    x=center.x()-w*k/2,y=center.y()-h*k/2,w=w*k,h=h*k)
        self.board["items"].append(item)
        for stroke in pen_tools.transform(clip.get("ink",[]),item["x"],item["y"],k,duplicate=True):
            stroke.update(group_id=item["id"],origin=copy.deepcopy(clip.get("origin",{})))
            self.board["strokes"].append(stroke)
        self.sel = item
        self._touch()
        self.selection_changed.emit()
        return item

    def paint_clip_item(self,p,item):
        store = self.transfer_store()
        if not hasattr(self,"clip_metadata"):
            self.clip_metadata = {}
        cid = item["clip_id"]
        if cid not in self.clip_metadata:
            self.clip_metadata[cid] = store.load(cid)
        clip = self.clip_metadata[cid]
        rect = QRectF(item["x"],item["y"],item["w"],item["h"])
        p.save()
        p.setOpacity(float(item.get("opacity",1)))
        if clip.get("svg"):
            from PySide6.QtSvg import QSvgRenderer
            if not hasattr(self,"clip_renderers"):
                self.clip_renderers = {}
            if cid not in self.clip_renderers:
                self.clip_renderers[cid] = QSvgRenderer(str(store.asset(clip,"svg")))
            self.clip_renderers[cid].render(p,rect)
        else:
            if not hasattr(self,"clip_images"):
                self.clip_images = {}
            cid = clip["id"]
            if cid not in self.clip_images:
                w,h = clip["space"]["width"],clip["space"]["height"]
                self.clip_images[cid] = store.render(clip,QSize(1600,max(1,int(1600*h/w))),include_ink=False)
            p.drawImage(rect,self.clip_images[cid])
        p.restore()

    def move_group(self,item,old):
        if not old[2] or not any(s.get("group_id")==item["id"] for s in self.board["strokes"]):
            return
        factor = item["w"]/old[2]
        origin = QPointF(old[0],old[1])
        self.board["strokes"] = [pen_tools.transform([s],item["x"]-old[0],item["y"]-old[1],factor,origin)[0]
                                  if s.get("group_id")==item["id"] else s for s in self.board["strokes"]]
        self.version += 1
