"""暮省验收：5 幅夜景 × 4 种封面 × 3 种屏幕都放得下、对比够读、夜里不刺眼；旧记录能接上。不联网。"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path


def _lum(c) -> float:
    def f(v):
        return v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4
    return .2126 * f(c.redF()) + .7152 * f(c.greenF()) + .0722 * f(c.blueF())


def _contrast(a, b) -> float:
    la, lb = _lum(a), _lum(b)
    return (max(la, lb) + .05) / (min(la, lb) + .05)


def _mean_lum(pm) -> float:
    img = pm.toImage().scaled(32, 18)
    return sum(_lum(img.pixelColor(x, y)) for x in range(32) for y in range(18)) / (32 * 18)


def sample_edition(date="2026-11-07", long=False) -> dict:
    body = "十一月三日，亚太经合组织第三十七届外交和贸易双部长会议以视频方式举行，各成员就开放、创新、合作交换意见。"
    x = 6 if long else 1
    story = dict(title="亚太经合组织召开第37届外交和贸易双部长会议" + ("，并就全球供应链与能源通道的长期安排发表共同声明" if long else ""),
                 summary=body * x, question="共同利益足够大时，分歧能被搁置多久？", source="新华网", published_display="11-04 12:00",
                 region="亚太", lens="规则", read_minutes=3, section_label="世界脉络")
    person = dict(name="约翰·梅纳德·凯恩斯", latin="JOHN MAYNARD KEYNES", years="1883—1946", identity="经济学家", monogram="凯",
                  headline="他让“政府该不该出手”成为现代经济学绕不开的问题。", story=body * x,
                  moments=[dict(year="1919", text="退出巴黎和会"), dict(year="1936", text="《通论》出版"), dict(year="1944", text="参与设计布雷顿森林体系")],
                  quote=dict(text="困难不在于接受新观念，而在于摆脱旧观念。"))
    return dict(date=date, date_label=date.replace("-", "."), weekday="周六", edition=9, read_count=7, reading_minutes=15, lead=story,
                stories=[dict(story, title=f"第 {i} 条：{story['title']}") for i in range(1, 7)], person=person,
                person_alternates=[dict(person, name="阿马蒂亚·森", monogram="森"), dict(person, name="屠呦呦", monogram="屠")],
                quotes=[dict(text="不要因为走得太远，而忘记为什么出发。" * (2 if long else 1), author="某人", source="某书", use="写坚持")] * 3,
                term=dict(term="布雷顿森林体系", en="Bretton Woods", definition=body * x, why=body, exam=body, misread=body))


def main(root=None) -> int:
    root = Path(root or tempfile.mkdtemp(prefix="jw-evening-"))
    root.mkdir(parents=True, exist_ok=True)
    from .kit import test_runtime
    app = test_runtime.application(sys.argv[:1])
    from PySide6.QtGui import QColor
    guanlan = str(Path(__file__).resolve().parents[1] / "guanlan")
    if guanlan not in sys.path:
        sys.path.insert(0, guanlan)
    os.environ.setdefault("JIANWEI_GUANLAN_HOME", str(root / "guanlan"))
    from core import evening as ev  # type: ignore
    from .evening import LEGACY, THEMES, EveningWindow, Painter

    failures: list[str] = []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        if not ok:
            failures.append(name)

    check("播放和生成的主题一致", set(ev.THEME_NAMES) == set(THEMES), (set(ev.THEME_NAMES), set(THEMES)))
    for key, t in THEMES.items():
        bg = QColor(t["bg"])
        bg2 = QColor(t["bg2"])
        for name, need in (("ink", 9 if t["dark"] else 8), ("soft", 6.5), ("muted", 4.2), ("accent", 3.6)):
            worst = min(_contrast(QColor(t[name]), bg), _contrast(QColor(t[name]), bg2))
            check(f"{t['name']} {name} 对比度 ≥ {need}", worst >= need, f"{worst:.2f}")
        check(f"{t['name']} 底色够暗", _lum(bg2) < (.56 if not t["dark"] else .03), _lum(bg2))

    sizes = ((1920, 1080), (1366, 768), (1024, 640))
    plain, heavy = sample_edition(), sample_edition(long=True)
    for theme in THEMES:
        for cover, _n in ev.COVER_LAYOUTS:
            for w, h in sizes:
                deck = ev.build_deck(plain, theme, cover)
                P = Painter(deck, w, h)
                t0 = time.perf_counter()
                plate = P.plate(True)
                P.plate(False)
                pm, anim = P.cover_static()
                ms = (time.perf_counter() - t0) * 1000
                size = anim["mark_size"]
                mw = size * (2.09 if not anim.get("mark_stack") else 1.5)
                inside = anim["mark_x"] >= 0 and anim["mark_x"] + mw <= w + 1 and anim["mark_y"] >= 0 and anim["mark_y"] + size <= h
                check(f"{theme}/{cover} {w}×{h} 封面放得下", inside, (anim["mark_x"], anim["mark_y"], size))
                check(f"{theme}/{cover} {w}×{h} 底板够快", ms < 2500, f"{ms:.0f}ms")
                if cover == "left" and w == 1920:
                    limit = .56 if not THEMES[theme]["dark"] else .10
                    lum = _mean_lum(plate)
                    check(f"{theme} 封面夜里不刺眼", lum < limit, f"{lum:.3f}")
                    _ = pm
    for theme in THEMES:
        for w, h in sizes:
            deck = ev.build_deck(heavy, theme, "left")
            P = Painter(deck, w, h)
            _pm, geo = P.hud()
            bad = []
            for s in deck["slides"]:
                P.slide(s, geo)
                if id(s) in P.fit:
                    scale, body, room = P.fit[id(s)]
                    if body > room + 1:
                        bad.append((s.get("kind"), round(scale, 2), round(body), round(room)))
            # 1024×640 是下限：极长内容允许缩小，但不能超出
            check(f"{theme} {w}×{h} 超长内容不越界", not bad, bad)

    # 同一天同一幅、换一天换一幅
    d1, d2 = ev.build_deck(plain, "ridge", "left"), ev.build_deck(sample_edition("2026-11-08"), "ridge", "left")
    a = Painter(d1, 800, 450).plate(True).toImage()
    b = Painter(d1, 800, 450).plate(True).toImage()
    c = Painter(d2, 800, 450).plate(True).toImage()
    check("同一天重播是同一幅", a == b)
    check("换一天山形不一样", a != c)

    # 旧记录
    for old, new in LEGACY.items():
        deck = dict(ev.build_deck(plain, new, "left"), theme=old)
        check(f"旧往期 {old} 能播（换成 {new}）", Painter(deck, 800, 450).theme == new)
    check("生成时旧主题名也认", ev.build_deck(plain, "jade", "left")["theme"] == "ridge")
    ev.HISTORY_PATH = root / "history.json"
    ev.HISTORY_PATH.write_text(json.dumps([dict(date="2026-11-07", theme="rice", cover="left")]), encoding="utf-8")
    check("今天已定的旧记录继续生效", ev._select_design(today="2026-11-07") == ("moon", "left"))
    ev.HISTORY_PATH.write_text("[]", encoding="utf-8")
    seen = []
    for day in range(20):
        seen.append(ev._select_design(today=f"2027-01-{day + 1:02d}"))
    check("20 晚不重复", len(set(seen)) == 20, len(set(seen)))
    check("连续两晚夜景不同", all(x[0] != y[0] for x, y in zip(seen, seen[1:])))
    check("指定夜景优先", ev._select_design("lamp", today="2027-02-01")[0] == "lamp")

    # 真的跑一遍窗口：封面 → 内容 → 结尾
    for theme in THEMES:
        win = EveningWindow(ev.build_deck(plain, theme, "center"), cover_ms=400)
        win.resize(1280, 720)
        win.show()
        app.processEvents()
        win.repaint()
        win.go(1)
        for _ in range(4):
            win.t0 -= 1
            win._tick()
            app.processEvents()
        check(f"{theme} 能从封面进内容", win.phase == "deck")
        for i in range(len(win.slides)):
            win.show_slide(i, animate=False)
            win.repaint()
        win.finish()
        win.repaint()
        check(f"{theme} 放到结尾", win.ended)
        win.close()
    print("EVENING", "OK" if not failures else "FAIL " + ",".join(failures[:12]), flush=True)
    return int(bool(failures))


if __name__ == "__main__":
    from .kit import test_runtime
    test_runtime.configure()
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    target = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix="jw-evening-")
    os.environ["JIANWEI_HOME"] = str(Path(target) / "home")
    os.environ["LOCALAPPDATA"] = str(Path(target) / "local")
    os.environ["JIANWEI_GUANLAN_HOME"] = str(Path(target) / "guanlan")
    raise SystemExit(test_runtime.run(lambda: main(target)))
