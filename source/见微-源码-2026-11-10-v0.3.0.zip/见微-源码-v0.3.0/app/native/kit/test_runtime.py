"""开发自测的静默运行与 Qt 清理；不影响正常启动或系统全局设置。"""
from __future__ import annotations

import os
import sys
import tempfile
import traceback
from contextlib import contextmanager
from pathlib import Path

_APP = None


@contextmanager
def isolated_data(root):
    root = Path(root)
    previous = {key:os.environ.get(key) for key in ("JIANWEI_HOME","LOCALAPPDATA")}
    os.environ["JIANWEI_HOME"] = str(root/"home")
    os.environ["LOCALAPPDATA"] = str(root/"local")
    try:
        yield
    finally:
        for key,value in previous.items():
            if value is None:
                os.environ.pop(key,None)
            else:
                os.environ[key] = value


def configure():
    """在加载 Qt 前关闭本测试进程的系统错误弹窗，错误仍保留在输出中。"""
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetErrorMode.argtypes = []
        kernel.GetErrorMode.restype = wintypes.UINT
        kernel.SetErrorMode.argtypes = [wintypes.UINT]
        kernel.SetErrorMode.restype = wintypes.UINT
        # SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX
        kernel.SetErrorMode(kernel.GetErrorMode() | 0x0001 | 0x0002 | 0x8000)
    for stream in (sys.stdout,sys.stderr):
        if stream is not None and hasattr(stream,"reconfigure"):
            stream.reconfigure(encoding="utf-8",errors="replace")


def application(argv=None):
    global _APP
    configure()
    os.environ["JIANWEI_SELFTEST"] = "1"
    from PySide6.QtWidgets import QApplication
    _APP = QApplication.instance() or QApplication(argv or [])
    _APP.setQuitOnLastWindowClosed(False)
    return _APP


def cleanup(delete_application=True):
    """先停止页面工作和计时器，销毁窗口，再销毁 QApplication。"""
    global _APP
    from PySide6.QtCore import QCoreApplication, QEvent, QTimer
    from PySide6.QtWidgets import QApplication
    from shiboken6 import delete, isValid
    app = QApplication.instance()
    if app is None:
        return
    widgets = list(app.topLevelWidgets())
    for widget in widgets:
        if not isValid(widget):
            continue
        shutdown = getattr(widget,"shutdown",None)
        if callable(shutdown):
            shutdown()
        ctx = getattr(widget,"ctx",None)
        if ctx is not None and callable(getattr(ctx,"dispose",None)):
            ctx.dispose()
        for timer in widget.findChildren(QTimer):
            timer.stop()
        widget.close()
    for widget in widgets:
        if isValid(widget):
            widget.deleteLater()
    QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
    app.processEvents()
    if delete_application:
        delete(app)
        _APP = None


def run(fn):
    configure()
    previous_test_flag = os.environ.get("JIANWEI_SELFTEST")
    os.environ["JIANWEI_SELFTEST"] = "1"
    if not os.environ.get("JIANWEI_HOME") or not os.environ.get("LOCALAPPDATA"):
        base = Path(tempfile.mkdtemp(prefix="jianwei-test-"))
        os.environ.setdefault("JIANWEI_HOME",str(base/"home"))
        os.environ.setdefault("LOCALAPPDATA",str(base/"local"))
    code = 1
    qt_errors = []
    previous_hook = sys.excepthook
    def record_error(kind,value,tb):
        qt_errors.append(str(value))
        traceback.print_exception(kind,value,tb)
    sys.excepthook = record_error
    try:
        result = fn()
        code = int(result or 0)
    except Exception:
        traceback.print_exc()
    finally:
        try:
            cleanup()
        except Exception:
            traceback.print_exc()
            code = 1
        sys.excepthook = previous_hook
        if previous_test_flag is None:
            os.environ.pop("JIANWEI_SELFTEST",None)
        else:
            os.environ["JIANWEI_SELFTEST"] = previous_test_flag
        if qt_errors:
            code = 1
    print(f"TEST_PROCESS_EXIT {code}",flush=True)
    return code
