"""阶段 2：几何、交互、工具条、预设和数据回归（隔离用户目录）。"""
from __future__ import annotations

from . import test_runtime

test_runtime.configure()

import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

from PySide6.QtCore import QCoreApplication, QEvent, QPointF, Qt
from PySide6.QtGui import QColor, QImage, QMouseEvent, QPainter
from PySide6.QtWidgets import QApplication

from . import pen, pen_tools
from .pen_bar import PenBar


class ToolTests(unittest.TestCase):
    def setUp(self):
        from ..lecture.board import BoardCanvas
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.board = BoardCanvas(Path(self.tmp.name))
        self.board.resize(800,450)
        self.session = self.board.pen_session

    def tearDown(self):
        self.session.reset()
        self.board.saver.stop()
        self.board.deleteLater()
        QApplication.processEvents()
        self.tmp.cleanup()

    def send(self, kind, pos, buttons=Qt.MouseButton.LeftButton):
        button = Qt.MouseButton.NoButton if kind == QEvent.Type.MouseMove else Qt.MouseButton.LeftButton
        e = QMouseEvent(kind,pos,pos,button,buttons,Qt.KeyboardModifier.NoModifier)
        QCoreApplication.sendEvent(self.board,e)

    def drag(self,a,b):
        self.send(QEvent.Type.MouseButtonPress,a)
        self.send(QEvent.Type.MouseMove,b)
        self.send(QEvent.Type.MouseButtonRelease,b,Qt.MouseButton.NoButton)

    def test_shapes_dispatch_undo_save(self):
        for tool in pen_tools.SHAPES:
            self.board.set_tool(tool)
            self.drag(QPointF(50,60),QPointF(170,130))
            self.assertEqual(self.board.board["strokes"][-1]["shape"]["kind"],tool)
        self.board.undo()
        self.assertEqual(len(self.board.board["strokes"]),4)
        self.board.redo()
        self.assertEqual(len(self.board.board["strokes"]),5)
        self.assertTrue(self.board.save())
        from .pen_store import PenStore
        reopened = PenStore(Path(self.tmp.name)/"board.json","board")
        self.assertFalse(reopened.readonly)
        self.assertEqual(len(reopened.data["boards"][0]["strokes"]),5)

    def test_pressure_chalk_enabled(self):
        self.board.set_tool("chalk")
        self.board._press(QPointF(20,30),.2,True)
        self.board._move(QPointF(70,30),.9)
        self.board._release()
        self.assertTrue(self.board.board["strokes"][0]["pressure"])
        self.assertEqual(self.board.board["strokes"][0]["points"][0][2],.2)

    def test_partial_eraser_is_one_undo_step(self):
        stroke = pen_tools.shape("line",QPointF(20,100),QPointF(200,100),"red",4)
        self.board.board["strokes"] = [stroke]
        self.board.set_tool("eraser")
        self.session.eraser_mode = "pixel"
        self.drag(QPointF(100,100),QPointF(110,100))
        pieces = self.board.board["strokes"]
        self.assertEqual(len(pieces),2)
        self.assertLess(pieces[0]["points"][-1][0],100)
        self.assertGreater(pieces[1]["points"][0][0],110)
        self.board.undo()
        self.assertEqual(self.board.board["strokes"],[stroke])
        self.board.redo()
        self.assertEqual(self.board.board["strokes"],pieces)

    def test_eraser_misses_leave_stroke_unchanged(self):
        s = pen_tools.shape("ellipse",QPointF(20,20),QPointF(120,120),"blue",2)
        self.assertEqual(pen_tools.erase([s],QPointF(400,400),10),[s])
        self.assertEqual(pen_tools.erase([s],QPointF(70,70),2),[s])

    def test_lasso_move_scale_copy_delete(self):
        s = pen_tools.shape("line",QPointF(50,60),QPointF(120,90),"blue",3)
        self.board.board["strokes"] = [s]
        self.board.set_tool("lasso")
        self.send(QEvent.Type.MouseButtonPress,QPointF(30,40))
        for p in (QPointF(150,40),QPointF(150,120),QPointF(30,120),QPointF(30,40)):
            self.send(QEvent.Type.MouseMove,p)
        self.send(QEvent.Type.MouseButtonRelease,QPointF(30,40),Qt.MouseButton.NoButton)
        self.assertEqual(self.session.ids,[s["id"]])
        self.drag(QPointF(80,75),QPointF(100,95))
        self.assertEqual(self.board.board["strokes"][0]["points"][0][:2],[70,80])
        self.session.selection_action("larger")
        self.assertAlmostEqual(self.board.board["strokes"][0]["width"],3.6)
        self.session.selection_action("copy")
        self.assertEqual(len(self.board.board["strokes"]),2)
        self.assertNotEqual(*[s["id"] for s in self.board.board["strokes"]])
        self.session.selection_action("delete")
        self.assertEqual(len(self.board.board["strokes"]),1)
        self.board.undo()
        self.assertEqual(len(self.board.board["strokes"]),2)

    def test_cancel_live_operation_restores_original(self):
        s = pen_tools.shape("line",QPointF(20,100),QPointF(200,100),"red",4)
        self.board.board["strokes"] = [s]
        self.board.set_tool("eraser")
        self.session.eraser_mode = "pixel"
        self.send(QEvent.Type.MouseButtonPress,QPointF(100,100))
        self.assertEqual(len(self.board.board["strokes"]),2)
        self.session.reset()
        self.assertEqual(self.board.board["strokes"],[s])

    def test_laser_never_saved_and_fades(self):
        self.board.set_tool("laser")
        self.drag(QPointF(50,60),QPointF(170,130))
        self.assertTrue(self.session.laser)
        self.assertFalse(self.board.board["strokes"])
        self.assertFalse(self.board.undo_stack)
        self.session.laser = [(p,t-2) for p,t in self.session.laser]
        self.session._fade()
        self.assertFalse(self.session.laser)
        self.assertFalse(self.session.fade.isActive())

    def test_snap_and_resume_freehand(self):
        self.board.set_tool("pen")
        self.board._press(QPointF(20,50))
        for x in range(30,151,10):
            self.board._move(QPointF(x,50+(x%3)*.1))
        self.session._snap()
        self.assertEqual(self.board.active["shape"]["kind"],"line")
        self.session._watch_move()
        self.assertNotIn("shape",self.board.active)
        self.session.snap_enabled = False
        self.session._snap()
        self.assertNotIn("shape",self.board.active)
        self.board._release()

    def test_snap_rejects_scribbles(self):
        s = pen.new_stroke("pen","red",2)
        for p in ((0,0),(80,80),(0,80),(80,0),(30,50),(90,40)):
            pen.add_point(s,*p)
        self.assertIsNone(pen_tools.snap(s))

    def test_highlighter_keeps_black_text_black(self):
        image = QImage(120,60,QImage.Format.Format_RGB32)
        image.fill(Qt.GlobalColor.white)
        p = QPainter(image)
        p.fillRect(40,10,20,40,Qt.GlobalColor.black)
        s = pen.new_stroke("marker","yellow",20)
        pen.add_point(s,10,30)
        pen.add_point(s,100,30)
        pen.draw(p,s)
        self.assertEqual(p.compositionMode(),QPainter.CompositionMode.CompositionMode_SourceOver)
        p.end()
        self.assertEqual(image.pixelColor(50,30),QColor("black"))
        self.assertNotEqual(image.pixelColor(20,30),QColor("white"))

    def test_presets_shared_and_orientation(self):
        from ..lecture.board import BoardCanvas
        bar = PenBar(self.board,self.session,board=True)
        self.board.color,self.board.width_px = "#102030",5.5
        self.board.set_tool("rect")
        bar.save_slot(0)
        other = BoardCanvas(Path(self.tmp.name)/"other")
        other_bar = PenBar(other,other.pen_session,board=True,vertical=True)
        other_bar.use_slot(0)
        self.assertEqual((other.tool,other.color,other.width_px),("rect","#102030",5.5))
        other.saver.stop()
        other.deleteLater()
        other_bar.deleteLater()
        bar.deleteLater()

    def test_zoom_anchor_preserved(self):
        q = self.board.to_board(QPointF(100,100))
        self.session._zoom(2,QPointF(100,100),QPointF(130,140))
        self.assertEqual(self.board.to_board(QPointF(130,140)),q)

    def test_pageview_shape_isolation_and_laser(self):
        from PySide6.QtGui import QPdfWriter
        from PySide6.QtPdf import QPdfDocument
        from ..lecture.pageview import PageView
        path = str(Path(self.tmp.name)/"pages.pdf")
        writer = QPdfWriter(path)
        painter = QPainter(writer)
        painter.fillRect(0,0,writer.width(),writer.height(),Qt.GlobalColor.white)
        writer.newPage()
        painter.fillRect(0,0,writer.width(),writer.height(),Qt.GlobalColor.white)
        painter.end()
        del painter, writer
        doc = QPdfDocument()
        doc.load(path)
        view = PageView(doc)
        view.resize(800,450)
        view.set_tool("arrow")
        view.pen_session._press(QPointF(320,120))
        view.pen_session._move(QPointF(460,250))
        view.pen_session._release()
        self.assertEqual(view.history(0).strokes[0]["shape"]["kind"],"arrow")
        view.go(1)
        self.assertFalse(view.history().strokes)
        view.go(0)
        self.assertEqual(len(view.history().strokes),1)
        view.undo()
        self.assertFalse(view.history().strokes)
        view.set_tool("laser")
        view.pen_session._press(QPointF(400,200))
        view.pen_session._release()
        self.assertFalse(view.ink_data())
        view.pen_session.reset()
        view.preload.stop()
        view.auto_timer.stop()
        from shiboken6 import delete
        delete(view)
        doc.close()
        delete(doc)

    def test_synthetic_touch_and_palm_suppression(self):
        from PySide6.QtGui import QEventPoint
        class Point:
            def __init__(self,pos):
                self.pos = pos
            def state(self):
                return QEventPoint.State.Updated
            def position(self):
                return self.pos
        class Touch:
            def __init__(self,positions):
                self.positions = positions
            def points(self):
                return [Point(p) for p in self.positions]
            def accept(self):
                pass
        self.board.set_tool("line")
        self.session.tablet_down = True
        self.session._touch(Touch([QPointF(10,10)]))
        self.assertIsNone(self.session.mode)
        self.session.tablet_down = False
        self.session._touch(Touch([QPointF(10,10)]))
        self.session._touch(Touch([QPointF(100,100)]))
        self.session._touch(Touch([]))
        self.assertEqual(len(self.board.board["strokes"]),1)
        self.session._touch(Touch([QPointF(10,10),QPointF(110,10)]))
        self.session._touch(Touch([QPointF(10,10),QPointF(210,10)]))
        self.assertAlmostEqual(self.board.scale,2)
        self.session._touch(Touch([]))

    def test_repeated_cached_paint(self):
        self.board.board["strokes"] = [pen_tools.shape("line",QPointF(20,i),QPointF(500,i),"red",2) for i in range(200)]
        self.board.show()
        QApplication.processEvents()
        self.board.grab()
        start = time.perf_counter()
        for _ in range(20):
            self.board.repaint()
        elapsed = (time.perf_counter()-start)*1000/20
        print(f"CACHED_PAINT {elapsed:.2f} ms/frame",flush=True)
        self.assertIsNotNone(getattr(self.board,"_ink_cache",None))


def main(root=None):
    global ROOT
    ROOT = Path(root or tempfile.mkdtemp(prefix="jw-pen-tools-"))
    ROOT.mkdir(parents=True,exist_ok=True)
    previous = {k:os.environ.get(k) for k in ("JIANWEI_HOME","LOCALAPPDATA")}
    try:
        os.environ["JIANWEI_HOME"] = str(ROOT/"home")
        os.environ["LOCALAPPDATA"] = str(ROOT/"local")
        app = test_runtime.application([])
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(ToolTests)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        app.processEvents()
    finally:
        for k,v in previous.items():
            if v is None:
                os.environ.pop(k,None)
            else:
                os.environ[k] = v
    print("PEN_PHASE2","OK" if result.wasSuccessful() else "FAIL",result.testsRun,flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(lambda:main(sys.argv[1] if len(sys.argv)>1 else None)))
