"""Quantitative motion/scene/bio references and synthetic native interaction."""
from . import test_runtime
test_runtime.configure()
import copy
import json
import math
import sys
from pathlib import Path
from types import SimpleNamespace as NS


def main(output=None):
    app=test_runtime.application()
    from PySide6.QtCore import QEvent,QPointF,Qt
    from PySide6.QtGui import QMouseEvent
    from ..lab.benches import measurements as m,scene_types4 as sc
    from ..lab.benches.cell_detail import fresh,check,Chromosomes,Organelles
    from ..lab.benches.bio_model import calculate
    from ..lab.benches.scene_core import E
    from ..lab.studio import Studio
    from .ctx import Loop
    from . import state_graph
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    ticker=dict(mode='ticker',frequency=50.,samples=[])
    for i in range(1000):
        t0=i*.001;t1=(i+1)*.001
        m.update(ticker,(t0*t0,0),(t1*t1,0),t0,t1)
    a,b,c=ticker['samples'][-3:]
    assert abs((c[1]-2*b[1]+a[1])/.02**2-2)<1e-7
    gate=dict(mode='gate',x=1.,flag_width=.1)
    for i in range(300):
        m.update(gate,(i*.005,0),((i+1)*.005,0),i*.001,(i+1)*.001)
    assert abs(gate['gate_speed']-5)<1e-10
    gate=dict(mode='gate',x=1.,flag_width=.2)
    for i in range(300):
        m.update(gate,(i*.005,0),((i+1)*.005,0),i*.001,(i+1)*.001)
    assert abs(gate['gate_time']-.04)<1e-10
    fiber=NS(core=1.5,clad=1.45,angle=10)
    assert sc.values('fiber',fiber)['reflected']
    fiber.angle=40
    assert not sc.values('fiber',fiber)['reflected']
    conical=NS(m=2,L=1,angle=60,g=10)
    cv=sc.values('conical',conical)
    assert abs(cv['tension']-40)<1e-10
    assert abs(cv['period']-2*math.pi*math.sqrt(.05))<1e-10
    cyc=NS(charge=1.6,mass=1.67,B=.5,radius=.1,voltage=1000)
    cv=sc.values('cyclotron',cyc)
    assert abs(cv['frequency']-(1.6e-19*.5/(2*math.pi*1.67e-27)))<1e-6
    selector=NS(charge=1.6,mass=1.67,E=10000,B=.1,speed=1,flight=500)
    assert sc.values('selector',selector)['y']==0
    selector.speed=2
    assert sc.values('selector',selector)['y']<0
    rod=NS(B=1,length=1,R=2,m=1,force=0,v0=4)
    rv=sc.values('induction_rail',rod,2)
    assert abs(rv['speed']-4/math.e)<1e-12
    assert abs(rv['joule']-(.5*rod.m*rod.v0**2-.5*rod.m*rv['speed']**2))<1e-10
    rod.force=2
    rv=sc.values('induction_rail',rod,3)
    assert abs(rv['joule']-(rod.force*rv['distance']+.5*rod.m*(rod.v0**2-rv['speed']**2)))<1e-10
    net=calculate('energy_network',dict(energy=1000,efficiency=.1,split=.3,eat_rabbit=.5,eat_mouse=1))
    assert net['network']==[1000,30,70,8.5]
    assert abs(sum(net['stocks'])+net['lost']-1000)<1e-10
    assert calculate('foodweb',{})['values']==[1000,150,22.5] # old chain unchanged
    for mode in ('mitosis','meiosis'):
        for stage in range(4):
            state=fresh(mode,stage)
            assert not check(state)[0]
            for t in state['tokens']:
                if mode=='mitosis':
                    t['bin']=0 if stage<2 else t['sister']
                elif stage==0:
                    t.update(bin=0,x=.25+(t['h']//2)*.35+(t['h']%2)*.05,y=.35)
                elif stage in (1,2):
                    t['bin']=t['h']%2
                else:
                    t['bin']=(t['h']%2)*2+t['sister']
            assert check(state)[0],(mode,stage,check(state))
            state['tokens'][0]['bin']=-1
            assert not check(state)[0]
    parameters=dict(stage=2,custom='preserve')
    remember=[]
    dialog=Chromosomes('mitosis',parameters,lambda:remember.append(True))
    dialog.show();app.processEvents()
    board=dialog.board
    def mouse(widget,kind,point,button=Qt.MouseButton.LeftButton):
        buttons=Qt.MouseButton.LeftButton if kind!=QEvent.Type.MouseButtonRelease else Qt.MouseButton.NoButton
        event=QMouseEvent(kind,point,widget.mapToGlobal(point.toPoint()),button,buttons,Qt.KeyboardModifier.NoModifier)
        app.sendEvent(widget,event)
    for token in board.state['tokens']:
        source=QPointF(token['x']*board.width(),token['y']*board.height())
        r=board.regions()[token['sister']]
        target=QPointF(r.center().x(),r.top()+45+token['h']*35)
        mouse(board,QEvent.Type.MouseButtonPress,source)
        mouse(board,QEvent.Type.MouseMove,target,Qt.MouseButton.NoButton)
        mouse(board,QEvent.Type.MouseButtonRelease,target)
    assert check(board.state)[0] and len(remember)==8 and parameters['custom']=='preserve'
    dialog.grab().save(str(out/'chromosome-drag.png'))
    dialog.close()
    future=dict(stage=0,chromosomes=dict(v=99))
    try:
        Chromosomes('mitosis',future,lambda:None)
    except ValueError:
        pass
    else:
        raise AssertionError('future chromosome record overwritten')
    assert future['chromosomes']['v']==99
    cell_params={}
    cell=Organelles('plant',cell_params,lambda:None)
    cell.show();app.processEvents()
    target=QPointF(cell.cell.width()*.25,cell.cell.height()*.35)
    mouse(cell.cell,QEvent.Type.MouseButtonPress,target)
    assert cell_params['selected_organelle']=='叶绿体' and '不是' not in cell.info.text()
    cell.grab().save(str(out/'organelle-select.png'))
    cell.close()
    studio=Studio('day')
    studio.resize(1440,900)
    studio.show()
    studio.open_bench('phys');app.processEvents()
    B=studio.B
    initial=B.transfer_snapshot()
    for label in ('打点计时器','光电门','弹簧测力计'):
        B.transfer_restore(initial)
        item=next(i.it for i in B.pal.all if i.it.get('label')==label)
        item['click']();item['drop'](750,450)
        app.processEvents()
        assert not studio.ctx.stage.error,label
        saved=B.transfer_snapshot()
        B.transfer_restore(saved)
        assert not studio.ctx.stage.error,label
    B.transfer_restore(initial)
    next(i.it for i in B.pal.all if i.it.get('label')=='打点计时器')['drop'](750,450)
    data=state_graph.decode(B.transfer_snapshot())
    body=next(o for o in data['S']['objs'] if o['kind']=='body')
    body.update(x=0.,y=3.,vx=0.,vy=0.,q=1.,m=1.)
    sensor=next(o for o in data['S']['objs'] if o['kind']=='sensor')
    sensor.update(target=body['id'],mode='ticker',frequency=50.)
    m.reset(sensor)
    field=dict(kind='ef',id=999,name='测试电场',x=-100.,y=-100.,w=200.,h=200.,E=2.,dir=0)
    data['S'].update(objs=[body,field,sensor],sel=sensor,simT=0.,snap=None)
    data['env'].update(grav=False,ground=False,air=0.)
    B.transfer_restore(state_graph.encode(data))
    next(c for c in studio.ctx.ctrls if c['kind']=='button' and c['name']=='播放')['press']()
    loop=next(t for t in studio.ctx.timers if isinstance(t,Loop));loop.pause()
    for _ in range(1000):
        loop.fn(.001)
    result=state_graph.decode(B.transfer_snapshot())
    got=next(o for o in result['S']['objs'] if o['kind']=='sensor')
    a,b,c=got['samples'][-3:]
    assert abs((c[1]-2*b[1]+a[1])/.02**2-2)<.01
    before=copy.deepcopy(got)
    B.transfer_restore(B.transfer_snapshot())
    after=next(o for o in state_graph.decode(B.transfer_snapshot())['S']['objs'] if o['kind']=='sensor')
    assert before['samples']==after['samples'] and before['next_sample']==after['next_sample']
    studio.ctx.stage.repaint()
    assert not studio.ctx.stage.error
    studio.grab().save(str(out/'ticker-actual-motion.png'))
    B.transfer_restore(initial)
    next(i.it for i in B.pal.all if i.it.get('label')=='弹簧测力计')['click']()
    data=state_graph.decode(B.transfer_snapshot())
    body=next(o for o in data['S']['objs'] if o['kind']=='body')
    link=next(o for o in data['S']['objs'] if o.get('instrument')=='dynamometer')
    body.update(x=2.,y=3.,m=1.,vx=0.,vy=0.)
    link.update(a=None,b=body['id'],ax=0.,ay=3.,k=5.,L0=1.,damp=0.)
    data['S'].update(objs=[body,link],sel=link,simT=0.,snap=None)
    data['env'].update(grav=False,ground=False,air=0.)
    B.transfer_restore(state_graph.encode(data))
    next(c for c in studio.ctx.ctrls if c['kind']=='button' and c['name']=='播放')['press']()
    loop=next(t for t in studio.ctx.timers if isinstance(t,Loop));loop.pause()
    loop.fn(.001)
    got=next(o for o in state_graph.decode(B.transfer_snapshot())['S']['objs'] if o['kind']=='body')
    assert abs(got['vx']/.001+5)<.01
    studio.open_bench('scene');app.processEvents()
    B=studio.B
    initial=B.transfer_snapshot()
    for kind,name,group,params in sc.SPECS:
        B.transfer_restore(initial)
        E.S.objects=[]
        item=B.pal.items['scene-'+kind].it
        item['click']();item['drop'](720,450)
        app.processEvents()
        obj=E.S.objects[-1]
        before=sc.values(kind,obj.p,1.)
        first=params[0]
        obj.p[first[0]]=first[4]
        assert sc.values(kind,obj.p,1.)!=before or kind=='selector'
        saved=B.transfer_snapshot()
        B.transfer_restore(saved)
        studio.ctx.stage.repaint()
        assert not studio.ctx.stage.error,kind
        studio.grab().save(str(out/('scene-'+kind+'.png')))
    studio.open_bench('bio');app.processEvents()
    app.sendEvent(studio.ctx.stage,QEvent(QEvent.Type.Leave))
    B=studio.B
    B.pal.items['bio-energy_network'].it['click']()
    saved=B.transfer_snapshot()
    assert any(o['kind']=='energy_network' for o in saved['objects'])
    B.transfer_restore(saved)
    studio.ctx.stage.repaint()
    assert not studio.ctx.stage.error
    studio.grab().save(str(out/'foodweb.png'))
    studio.go_home();studio.close()
    (out/'coverage.json').write_text(json.dumps(dict(measurements=3,scenes=5,bio='4-period identity checks, organelle hit, branched energy',hardware=False),ensure_ascii=False),encoding='utf-8')
    print('MODELS29B OK motion/scene references, actual ticker, chromosome drag/period checks, organelle hit, foodweb conservation, state restore',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
