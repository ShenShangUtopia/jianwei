"""Guanlan text materials enter the existing version-1 Clip store, pinned by default."""
import os
from pathlib import Path


def text(payload):
    if not isinstance(payload,dict) or payload.get('kind') not in ('quote','person','term') or not isinstance(payload.get('data'),dict):
        raise ValueError('素材内容无效')
    data=payload['data']
    titles={'quote':'金句','person':'人物','term':'词条'}
    labels={'text':'内容','author':'作者','source':'出处','use':'使用方向','name':'姓名','term':'词条','definition':'释义','exam':'高考连接','role':'身份','title':'标题','url':'来源链接'}
    lines=[titles[payload['kind']]]
    def walk(value,key='',depth=0):
        if depth>6:
            return
        if isinstance(value,str) and value.strip() and key not in ('image','photo','avatar','monogram','en'):
            lines.append((labels[key]+'：' if key in labels else '')+value.strip())
        elif isinstance(value,list):
            for v in value[:50]:
                walk(v,'',depth+1)
        elif isinstance(value,dict):
            for k,v in value.items():
                walk(v,k,depth+1)
    walk(data)
    result='\n'.join(lines)
    if len(result)>30000 or len(lines)<2:
        raise ValueError('素材文字为空或过长')
    return result


def collect(bus,payload):
    content=text(payload)
    for row in bus.recent():
        summary=bus.store.summary(row['id'])
        if summary.get('text')==content and summary.get('origin',{}).get('category')=='作文素材':
            clip=bus.store.load(row['id'])
            bus.remember(clip)
            bus.pin(clip['id'],True)
            return clip
    clip=bus.store.create(text=content,origin=dict(type='guanlan',category='作文素材',ref=dict(kind=payload['kind'])))
    bus.remember(clip)
    bus.pin(clip['id'],True)
    return clip


def export(store,ids,destination):
    target=Path(destination)
    pieces=['# 作文素材\n']
    for index,cid in enumerate(ids,1):
        clip=store.load(cid)
        pieces.append(f'\n## {index}\n\n'+clip.get('text','（此项为图像或笔迹，请在见微打开）')+'\n')
    temporary=target.with_name(target.name+'.tmp')
    try:
        temporary.write_text('\n'.join(pieces),encoding='utf-8')
        os.replace(temporary,target)
    finally:
        temporary.unlink(missing_ok=True)
