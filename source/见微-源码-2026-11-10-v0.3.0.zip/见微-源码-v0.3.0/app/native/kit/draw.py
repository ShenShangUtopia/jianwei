"""画布：G 是 QPainter 上一层薄薄的「Canvas 2D 风格」接口，D 是常用图元（对应旧 core.js 的 D）。

实验代码统一写 `D.line(g, ...)`、`D.text(g, ...)`；需要自由路径时用 `g.begin_path()/move_to()/line_to()/stroke()`。
颜色参数接受 '#rrggbb'、'rgba(...)' 或 QColor；None 表示不画。
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFontMetricsF, QPainter, QPainterPath, QPen, QPolygonF

from ..design.tokens import T, font, qc
from .core import TAU


class G:
    """画笔状态 + 当前路径。只在 Stage.paintEvent 期间有效。"""

    def __init__(self, p: QPainter):
        self.p = p
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        self.path = QPainterPath()
        self.stroke_style = T.fg
        self.fill_style = T.fg
        self.line_width = 1.0
        self.dash: list[float] = []
        self.line_cap = "butt"
        self.line_join = "miter"
        self.global_alpha = 1.0
        self._stack: list = []

    # ---- 状态
    def save(self) -> None:
        self._stack.append((self.stroke_style, self.fill_style, self.line_width, list(self.dash),
                            self.line_cap, self.line_join, self.global_alpha))
        self.p.save()

    def restore(self) -> None:
        if self._stack:
            (self.stroke_style, self.fill_style, self.line_width, self.dash,
             self.line_cap, self.line_join, self.global_alpha) = self._stack.pop()
        self.p.restore()

    def translate(self, x, y) -> None:
        self.p.translate(x, y)

    def rotate(self, a) -> None:
        self.p.rotate(math.degrees(a))

    def scale(self, sx, sy=None) -> None:
        self.p.scale(sx, sx if sy is None else sy)

    def clip_rect(self, x, y, w, h) -> None:
        self.p.setClipRect(QRectF(x, y, w, h))

    def clip_path(self) -> None:
        self.p.setClipPath(self.path)

    # ---- 路径
    def begin_path(self) -> None:
        self.path = QPainterPath()

    def move_to(self, x, y) -> None:
        self.path.moveTo(x, y)

    def line_to(self, x, y) -> None:
        if self.path.elementCount() == 0:
            self.path.moveTo(x, y)
        else:
            self.path.lineTo(x, y)

    def close_path(self) -> None:
        self.path.closeSubpath()

    def quad_to(self, cx, cy, x, y) -> None:
        self.path.quadTo(cx, cy, x, y)

    def bezier_to(self, c1x, c1y, c2x, c2y, x, y) -> None:
        self.path.cubicTo(c1x, c1y, c2x, c2y, x, y)

    def arc(self, x, y, r, a0, a1, ccw=False) -> None:
        """与 Canvas 的 arc 一致：角度弧度制、y 向下、默认顺时针。"""
        r = max(0.0, r)
        sweep = a1 - a0
        if ccw:
            if sweep > 0:
                sweep -= TAU * math.ceil(sweep / TAU) if sweep >= TAU else TAU
            sweep = max(sweep, -TAU)
        else:
            if sweep < 0:
                sweep += TAU * math.ceil(-sweep / TAU)
            sweep = min(sweep, TAU)
        rect = QRectF(x - r, y - r, 2 * r, 2 * r)
        start = QPointF(x + r * math.cos(a0), y + r * math.sin(a0))
        if self.path.elementCount() == 0:
            self.path.moveTo(start)
        else:
            self.path.lineTo(start)
        # Qt 角度：逆时针为正、y 向上 → 取负
        self.path.arcTo(rect, -math.degrees(a0), -math.degrees(sweep))

    def rect(self, x, y, w, h) -> None:
        self.path.addRect(QRectF(x, y, w, h))

    def round_rect(self, x, y, w, h, r) -> None:
        self.path.addRoundedRect(QRectF(x, y, w, h), r, r)

    def ellipse(self, x, y, rx, ry, rot=0.0) -> None:
        if rot:
            path = QPainterPath()
            path.addEllipse(QPointF(0, 0), rx, ry)
            from PySide6.QtGui import QTransform
            self.path.addPath(QTransform().translate(x, y).rotateRadians(rot).map(path))
        else:
            self.path.addEllipse(QPointF(x, y), rx, ry)

    # ---- 着色
    def _pen(self, color=None, width=None, dash=None) -> QPen:
        col = qc(color if color is not None else self.stroke_style)
        if self.global_alpha < 1:
            col.setAlphaF(col.alphaF() * self.global_alpha)
        pen = QPen(col, width if width is not None else self.line_width)
        d = self.dash if dash is None else dash
        w = max(0.5, pen.widthF())
        if d:
            pen.setDashPattern([max(0.1, v / w) for v in d])
        pen.setCapStyle({"round": Qt.PenCapStyle.RoundCap, "square": Qt.PenCapStyle.SquareCap}.get(self.line_cap, Qt.PenCapStyle.FlatCap))
        pen.setJoinStyle({"round": Qt.PenJoinStyle.RoundJoin, "bevel": Qt.PenJoinStyle.BevelJoin}.get(self.line_join, Qt.PenJoinStyle.MiterJoin))
        return pen

    def _brush(self, color=None) -> QBrush:
        c = color if color is not None else self.fill_style
        if isinstance(c, (QBrush,)):
            return c
        if hasattr(c, "brush"):   # Gradient 包装
            return c.brush()
        col = qc(c)
        if self.global_alpha < 1:
            col.setAlphaF(col.alphaF() * self.global_alpha)
        return QBrush(col)

    def stroke(self) -> None:
        self.p.strokePath(self.path, self._pen())

    def fill(self) -> None:
        self.p.fillPath(self.path, self._brush())

    def fill_rect(self, x, y, w, h) -> None:
        self.p.fillRect(QRectF(x, y, w, h), self._brush())

    def stroke_rect(self, x, y, w, h) -> None:
        self.p.setPen(self._pen())
        self.p.setBrush(Qt.BrushStyle.NoBrush)
        self.p.drawRect(QRectF(x, y, w, h))

    def linear_gradient(self, x0, y0, x1, y1, stops) -> "Gradient":
        return Gradient("linear", (x0, y0, x1, y1), stops)

    def radial_gradient(self, x, y, r, stops) -> "Gradient":
        return Gradient("radial", (x, y, r), stops)


class Gradient:
    def __init__(self, kind, args, stops):
        self.kind, self.args, self.stops = kind, args, stops

    def brush(self) -> QBrush:
        from PySide6.QtGui import QLinearGradient, QRadialGradient
        g = QLinearGradient(*self.args) if self.kind == "linear" else QRadialGradient(*self.args)
        for t, c in self.stops:
            g.setColorAt(t, qc(c))
        return QBrush(g)


_ALIGN = {"left": 0, "center": 0.5, "right": 1}


def rgb_image(nx: int, ny: int, buf: bytearray):
    """把 nx×ny 的 RGB 字节（每像素 3 字节，逐行）做成 QImage（拷贝一份，不依赖 buf 的生命周期）。"""
    from PySide6.QtGui import QImage
    return QImage(bytes(buf), nx, ny, nx * 3, QImage.Format.Format_RGB888).copy()


def draw_image(g: "G", img, x, y, w, h, smooth=True) -> None:
    g.p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, smooth)
    g.p.drawImage(QRectF(x, y, w, h), img)


def wave_rgb(nm: float) -> tuple[float, float, float]:
    """可见光波长（nm）→ (r, g, b)，各 0..1；可见光以外为 0。"""
    r = g = b = 0.0
    if 380 <= nm < 440:
        r, b = -(nm - 440) / 60, 1.0
    elif 440 <= nm < 490:
        g, b = (nm - 440) / 50, 1.0
    elif 490 <= nm < 510:
        g, b = 1.0, -(nm - 510) / 20
    elif 510 <= nm < 580:
        r, g = (nm - 510) / 70, 1.0
    elif 580 <= nm < 645:
        r, g = 1.0, -(nm - 645) / 65
    elif 645 <= nm <= 780:
        r = 1.0
    f = 0.0 if nm < 380 or nm > 780 else 0.3 + 0.7 * (nm - 380) / 40 if nm < 420 else 0.3 + 0.7 * (780 - nm) / 80 if nm > 700 else 1.0
    return r * f, g * f, b * f


def wave_css(nm: float, a: float = 1.0) -> str:
    r, g, b = wave_rgb(nm)
    if r + g + b == 0:
        return f"rgba(150,150,170,{a})"
    return f"rgba({int(r * 255)},{int(g * 255)},{int(b * 255)},{a})"


class D:
    @staticmethod
    def line(g: G, x1, y1, x2, y2, c, w=1.5, dash=None) -> None:
        g.p.setPen(g._pen(c, w, dash or []))
        g.p.drawLine(QPointF(x1, y1), QPointF(x2, y2))

    @staticmethod
    def circle(g: G, x, y, r, fill=None, stroke=None, w=1.5) -> None:
        r = max(0.0, r)
        g.p.setPen(g._pen(stroke, w, []) if stroke else Qt.PenStyle.NoPen)
        g.p.setBrush(g._brush(fill) if fill else Qt.BrushStyle.NoBrush)
        g.p.drawEllipse(QPointF(x, y), r, r)

    @staticmethod
    def rect(g: G, x, y, w, h, fill=None, stroke=None, lw=1.5) -> None:
        r = QRectF(x, y, w, h)
        if fill:
            g.p.fillRect(r, g._brush(fill))
        if stroke:
            g.p.setPen(g._pen(stroke, lw, []))
            g.p.setBrush(Qt.BrushStyle.NoBrush)
            g.p.drawRect(r)

    @staticmethod
    def rrect(g: G, x, y, w, h, r, fill=None, stroke=None, lw=1.5) -> None:
        g.p.setPen(g._pen(stroke, lw, []) if stroke else Qt.PenStyle.NoPen)
        g.p.setBrush(g._brush(fill) if fill else Qt.BrushStyle.NoBrush)
        g.p.drawRoundedRect(QRectF(x, y, w, h), r, r)

    @staticmethod
    def poly(g: G, pts, fill=None, stroke=None, w=1.5, close=True) -> None:
        if not pts:
            return
        path = QPainterPath(QPointF(pts[0][0], pts[0][1]))
        for x, y in pts[1:]:
            path.lineTo(x, y)
        if close:
            path.closeSubpath()
        if fill:
            g.p.fillPath(path, g._brush(fill))
        if stroke:
            pen = g._pen(stroke, w, [])
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            g.p.strokePath(path, pen)

    @staticmethod
    def text(g: G, s, x, y, c=None, size=12, bold=False, mono=False, align="left", base="middle", serif=False) -> float:
        """返回文字宽度。base: middle / top / bottom / alphabetic。"""
        s = str(s)
        f = font(size, 600 if bold else 400, "mono" if mono else ("num" if serif else "ui"))
        fm = QFontMetricsF(f)
        w = fm.horizontalAdvance(s)
        x0 = x - w * _ALIGN.get(align, 0)
        if base == "middle":
            y0 = y + (fm.ascent() - fm.descent()) / 2
        elif base == "top":
            y0 = y + fm.ascent()
        elif base == "bottom":
            y0 = y - fm.descent()
        else:
            y0 = y
        g.p.setFont(f)
        col = qc(c or T.fg)
        if g.global_alpha < 1:
            col.setAlphaF(col.alphaF() * g.global_alpha)
        g.p.setPen(col)
        g.p.drawText(QPointF(x0, y0), s)
        return w

    @staticmethod
    def ball(g: G, x, y, r, col, edge=None) -> None:
        """带高光的立体小球（分子模型、晶胞用）。"""
        if r <= 0.3:
            return
        from PySide6.QtGui import QRadialGradient
        grad = QRadialGradient(QPointF(x, y), r, QPointF(x - r * 0.35, y - r * 0.35))
        base = qc(col)
        grad.setColorAt(0.0, QColor(255, 255, 255))
        grad.setColorAt(0.4, base)
        grad.setColorAt(1.0, base.darker(135))
        g.p.setPen(g._pen(edge, 1, []) if edge else Qt.PenStyle.NoPen)
        g.p.setBrush(QBrush(grad))
        g.p.drawEllipse(QPointF(x, y), r, r)

    @staticmethod
    def measure(s, size=12, bold=False, mono=False) -> float:
        return QFontMetricsF(font(size, 600 if bold else 400, "mono" if mono else "ui")).horizontalAdvance(str(s))

    @staticmethod
    def arrow(g: G, x1, y1, x2, y2, c, w=2, head=9) -> None:
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        if L < 0.5:
            return
        ux, uy = dx / L, dy / L
        h = min(head, L * 0.6)
        D.line(g, x1, y1, x2 - ux * h * 0.7, y2 - uy * h * 0.7, c, w)
        tri = QPolygonF([QPointF(x2, y2),
                         QPointF(x2 - ux * h - uy * h * 0.45, y2 - uy * h + ux * h * 0.45),
                         QPointF(x2 - ux * h + uy * h * 0.45, y2 - uy * h - ux * h * 0.45)])
        g.p.setPen(Qt.PenStyle.NoPen)
        g.p.setBrush(g._brush(c))
        g.p.drawPolygon(tri)

    @staticmethod
    def spring(g: G, x1, y1, x2, y2, coils, amp, c, w=1.5) -> None:
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy) or 1e-9
        ux, uy = dx / L, dy / L
        n, lead = coils * 2, L * 0.08
        pts = [(x1, y1), (x1 + ux * lead, y1 + uy * lead)]
        for i in range(1, n):
            t = lead + (L - 2 * lead) * i / n
            s = (1 if i % 2 else -1) * amp
            pts.append((x1 + ux * t - uy * s, y1 + uy * t + ux * s))
        pts += [(x2 - ux * lead, y2 - uy * lead), (x2, y2)]
        D.poly(g, pts, None, c, w, False)

    @staticmethod
    def chart(g: G, x, y, w, h, series, title=None, xl=None, yl=None, xmin=None, xmax=None,
              ymin=None, ymax=None, bg=None, marks=None, yticks=True) -> dict:
        """曲线面板：series = [{'pts': [(x, y)...], 'color': ..., 'w': 1.8, 'dash': [...]}]。返回坐标换算。"""
        D.rect(g, x, y, w, h, bg, T.line, 1)
        allp = [p for s in series for p in s["pts"] if math.isfinite(p[0]) and math.isfinite(p[1])]
        if xmin is None:
            xmin = min([p[0] for p in allp] + [0])
        if xmax is None:
            xmax = max([p[0] for p in allp] + [1])
        if ymin is None:
            ymin = min([p[1] for p in allp] + [0])
        if ymax is None:
            ymax = max([p[1] for p in allp] + [1e-9]) * 1.1
        if xmax == xmin:
            xmax = xmin + 1
        if ymax == ymin:
            ymax = ymin + 1

        def X(v):
            return x + (v - xmin) / (xmax - xmin) * w

        def Y(v):
            return y + h - (v - ymin) / (ymax - ymin) * h

        if ymin < 0 < ymax:
            D.line(g, x, Y(0), x + w, Y(0), T.grid2, 1)
        g.p.save()
        g.p.setClipRect(QRectF(x, y, w, h))
        for s in series:
            pts = [p for p in s["pts"] if math.isfinite(p[1])]
            if len(pts) < 2:
                continue
            path = QPainterPath(QPointF(X(pts[0][0]), Y(pts[0][1])))
            for px, py in pts[1:]:
                path.lineTo(X(px), Y(py))
            g.p.strokePath(path, g._pen(s.get("color", T.c1), s.get("w", 1.8), s.get("dash") or []))
        g.p.restore()
        if title:
            D.text(g, title, x + 6, y + 10, T.muted, size=11)
        if xl:
            D.text(g, xl, x + w - 4, y + h - 8, T.muted, size=10.5, align="right")
        if yl:
            D.text(g, yl, x + 6, y + 24, T.muted, size=10.5)
        from .core import fmt
        if yticks:
            D.text(g, fmt(ymax, 3), x - 4, y + 4, T.muted, size=10, align="right", mono=True)
            D.text(g, fmt(ymin, 3), x - 4, y + h - 4, T.muted, size=10, align="right", mono=True)
        D.text(g, fmt(xmax, 3), x + w, y + h + 10, T.muted, size=10, align="right", mono=True)
        return {"X": X, "Y": Y, "xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax}
