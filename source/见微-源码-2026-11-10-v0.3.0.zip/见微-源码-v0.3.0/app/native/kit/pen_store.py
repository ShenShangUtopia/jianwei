"""笔迹/黑板存档边界：迁移副本、旧文件备份、版本与并发写保护。"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

from PySide6.QtCore import QLockFile, QSaveFile, QIODevice

from .pen import PenDataError, migrate_strokes

VERSION = 1


def _version(data):
    if not isinstance(data, dict):
        raise PenDataError("存档根节点无效")
    version = data.get("version", 0)
    if type(version) is not int or version not in (0, VERSION):
        raise PenDataError(f"不支持的存档版本 {version}，请使用新版见微打开")
    return version


def migrate_ink(data):
    version = _version(data)
    pages = data.get("pages") if version else data
    if not isinstance(pages, dict):
        raise PenDataError("课件笔迹页面无效")
    result = copy.deepcopy(data) if version else {}
    normalized = {}
    for key, strokes in pages.items():
        if not isinstance(key, str) or not key.isascii() or not key.isdigit():
            raise PenDataError("笔迹幻灯片编号无效")
        canonical = str(int(key))
        if canonical in normalized:
            raise PenDataError("笔迹幻灯片编号重复")
        normalized[canonical] = migrate_strokes(strokes)
    result.update(version=VERSION, pages=normalized)
    return result


def migrate_board(data):
    _version(data)
    result = copy.deepcopy(data)
    boards = result.get("boards")
    if not isinstance(boards, list) or not boards:
        raise PenDataError("黑板列表无效")
    for board in boards:
        if not isinstance(board, dict) or not isinstance(board.get("items"), list):
            raise PenDataError("黑板条目列表无效")
        if not all(isinstance(item, dict) for item in board["items"]):
            raise PenDataError("黑板条目无效")
        board["strokes"] = migrate_strokes(board.get("strokes", []))
    cur = result.get("cur", 0)
    if type(cur) is not int:
        raise PenDataError("黑板编号无效")
    result.update(version=VERSION, cur=cur)
    return result


class PenStore:
    """有问题的文件保留原字节并只读；并发修改须重新打开后才能保存。"""

    def __init__(self, path, kind):
        if kind not in ("ink", "board"):
            raise ValueError(kind)
        self.path = Path(path)
        self.normalize = migrate_ink if kind == "ink" else migrate_board
        self.data = (dict(version=VERSION, pages={}) if kind == "ink" else
                     dict(version=VERSION, boards=[dict(items=[], strokes=[])], cur=0))
        self.error = ""
        self.readonly = False
        self.legacy = False
        self._raw = None
        try:
            self._raw = self.path.read_bytes()
        except FileNotFoundError:
            return
        except OSError as exc:
            self._protect(str(exc))
            return
        try:
            data = json.loads(self._raw.decode("utf-8-sig"))
            self.data = self.normalize(data)
            self.legacy = self.data != data
        except (ValueError, TypeError, RecursionError) as exc:
            self._protect(str(exc))

    def _protect(self, why):
        self.readonly = True
        self.error = f"{self.path.name} 已保护，未覆盖原文件：{why}"

    def save(self, data):
        if self.readonly:
            raise PenDataError(self.error)
        normalized = self.normalize(data)
        raw = json.dumps(normalized, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        lock = QLockFile(str(self.path) + ".lock")
        if not lock.tryLock(0):
            raise PenDataError(f"{self.path.name} 正在被另一个窗口保存，请稍后重试")
        try:
            try:
                current = self.path.read_bytes()
            except FileNotFoundError:
                current = None
            if current != self._raw:
                self._protect("文件已被其他窗口修改，请重新打开后继续")
                raise PenDataError(self.error)
            if self.legacy and current is not None:
                digest = hashlib.sha256(current).hexdigest()[:16]
                backup = self.path.with_name(self.path.name + f".legacy-{digest}.bak")
                try:
                    with backup.open("xb") as stream:
                        stream.write(current)
                except FileExistsError:
                    if backup.read_bytes() != current:
                        raise PenDataError("旧存档备份校验失败，未保存")
            if raw != current:
                target = QSaveFile(str(self.path))
                target.setDirectWriteFallback(False)
                if not target.open(QIODevice.OpenModeFlag.WriteOnly):
                    raise OSError(target.errorString())
                if target.write(raw) != len(raw):
                    target.cancelWriting()
                    raise OSError(target.errorString())
                if not target.commit():
                    raise OSError(target.errorString())
            self._raw, self.data, self.legacy = raw, normalized, False
        finally:
            lock.unlock()
