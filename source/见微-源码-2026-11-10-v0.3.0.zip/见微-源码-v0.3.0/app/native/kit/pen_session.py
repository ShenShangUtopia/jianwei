"""共享画笔交互层：不介入课件页映射或黑板条目，只操作笔画列表。"""
from __future__ import annotations

import math
import time

from PySide6.QtCore import QEvent, QObject, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QEventPoint, QPainterPath, QPen

from . import pen, pen_tools


class PenSession(QObject):
    def __init__(self, host, get_strokes, live, commit, to_local, to_view, scale):
        super().__init__(host)
        self.host, self.get, self.live, self.commit = host, get_strokes, live, commit
        self.local, self.view, self.scale = to_local, to_view, scale
        self.mode = None
        self.preview = None
        self.ids, self.polygon, self.laser = [], [], []
        self.before, self.start = None, None
        self.eraser_mode = "stroke"
        self.snap_enabled = True
        self.tablet_down = False
        self.suppress_mouse_until = 0
        self.touching = False
        self.gesture = None
        self.snap_original = None
        self.hold = QTimer(self)
        self.hold.setSingleShot(True)
        self.hold.setInterval(500)
        self.hold.timeout.connect(self._snap)
        self.fade = QTimer(self)
        self.fade.setInterval(16)
        self.fade.timeout.connect(self._fade)
        host.setAttribute(Qt.WidgetAttribute.WA_AcceptTouchEvents, True)
        host.installEventFilter(self)

    def reset(self):
        self.hold.stop()
        if self.before is not None:
            self.live(self.before)
        self.mode = self.before = self.preview = self.snap_original = None
        self.ids, self.polygon, self.laser = [], [], []
        self.fade.stop()
        self.tablet_down = self.touching = False
        self.gesture = None
        self.host.update()

    def selection_rect(self):
        rect = QRectF()
        if not self.ids:
            return rect
        for s in self.get():
            if s["id"] in self.ids:
                rect = rect.united(pen.bounds(s))
        return rect

    def _press(self, pos, eraser=False):
        q, tool = self.local(pos), self.host.tool
        if tool == "eraser" or eraser:
            self.before = list(self.get())
            self.mode = "erase"
            self._move(pos)
        elif tool in pen_tools.SHAPES:
            self.start, self.mode = q, "shape"
            self._move(pos)
        elif tool == "laser":
            self.mode = "laser"
            self._move(pos)
        elif tool == "lasso":
            rect = self.selection_rect()
            handle = self.view(rect.bottomRight()) if not rect.isEmpty() else None
            if handle is not None and math.hypot(pos.x()-handle.x(), pos.y()-handle.y()) < 13:
                self.mode = "resize"
            elif not rect.isEmpty() and rect.contains(q):
                self.mode = "move"
            else:
                self.ids = []
                self.polygon = [q]
                self.mode = "lasso"
            self.before, self.start, self.original_rect = list(self.get()), q, rect
        else:
            return False
        self.host.update()
        return True

    def _move(self, pos):
        q = self.local(pos)
        if self.mode == "shape":
            self.preview = pen_tools.shape(self.host.tool, self.start, q, self.host.color, self.host.width_px/self.scale())
        elif self.mode == "laser":
            self.laser.append((q, time.perf_counter()))
            self.laser = self.laser[-512:]
            if not self.fade.isActive():
                self.fade.start()
        elif self.mode == "erase":
            radius = 10/self.scale()
            if self.eraser_mode == "pixel":
                self.live(pen_tools.erase(self.get(), q, radius))
            else:
                self.live([s for s in self.get() if not pen.hit(s,q.x(),q.y(),radius)])
        elif self.mode == "lasso":
            if (q-self.polygon[-1]).manhattanLength() > 1/self.scale():
                self.polygon.append(q)
        elif self.mode in ("move", "resize"):
            strokes = [s for s in self.before if s["id"] in self.ids]
            if self.mode == "move":
                converted = pen_tools.transform(strokes, q.x()-self.start.x(), q.y()-self.start.y())
            else:
                anchor = self.original_rect.topLeft()
                old = max(.001, math.hypot(self.start.x()-anchor.x(),self.start.y()-anchor.y()))
                new = math.hypot(q.x()-anchor.x(),q.y()-anchor.y())
                converted = pen_tools.transform(strokes, scale=max(.1,min(10,new/old)), anchor=anchor)
            mapping = {s["id"]:s for s in converted}
            self.live([mapping.get(s["id"],s) for s in self.before])
        self.host.update()

    def _release(self):
        if self.mode == "shape" and self.preview is not None:
            before = list(self.get())
            self.commit(before, before+[self.preview])
        elif self.mode in ("erase", "move", "resize"):
            self.commit(self.before, list(self.get()))
        elif self.mode == "lasso":
            self.ids = pen_tools.selected(self.get(), self.polygon)
        self.mode = self.preview = self.before = None
        self.polygon = []
        self.host.update()

    def selection_action(self, action):
        before = list(self.get())
        picked = [s for s in before if s["id"] in self.ids]
        if not picked:
            return
        if action == "delete":
            after = [s for s in before if s["id"] not in self.ids]
            self.ids = []
        elif action == "copy":
            copies = pen_tools.transform(picked, 18/self.scale(),18/self.scale(),duplicate=True)
            after = before+copies
            self.ids = [s["id"] for s in copies]
        else:
            scale = 1.2 if action == "larger" else 1/1.2
            mapping = {s["id"]:s for s in pen_tools.transform(picked,scale=scale,anchor=self.selection_rect().center())}
            after = [mapping.get(s["id"],s) for s in before]
        self.commit(before, after)
        self.host.update()

    def _snap(self):
        active = getattr(self.host, "active", None)
        if not self.snap_enabled or active is None or active["tool"] not in ("pen", "chalk"):
            return
        result = pen_tools.snap(active)
        if result is not None:
            self.snap_original = active
            self.host.active = result
            self.host.update()

    def _watch_move(self):
        if self.snap_original is not None:
            self.host.active = self.snap_original
            self.snap_original = None
            self.host.update()
        if self.snap_enabled and getattr(self.host, "active", None) is not None:
            self.hold.start()

    def _fade(self):
        now = time.perf_counter()
        self.laser = [(p,t) for p,t in self.laser if now-t < 1]
        if not self.laser:
            self.fade.stop()
        self.host.update()

    def paint(self, painter):
        painter.save()
        if self.preview is not None:
            # 预览使用画布的线性坐标变换。
            origin, k = self.view(QPointF()), self.scale()
            painter.translate(origin)
            painter.scale(k,k)
            pen.draw(painter,self.preview)
            painter.restore()
            painter.save()
        painter.setBrush(Qt.BrushStyle.NoBrush)
        if self.polygon:
            path = QPainterPath(self.view(self.polygon[0]))
            for q in self.polygon[1:]:
                path.lineTo(self.view(q))
            painter.setPen(QPen(QColor("#5799E5"),1.5,Qt.PenStyle.DashLine))
            painter.drawPath(path)
        rect = self.selection_rect()
        if not rect.isEmpty():
            r = QRectF(self.view(rect.topLeft()), self.view(rect.bottomRight()))
            painter.setPen(QPen(QColor("#5799E5"),1.5,Qt.PenStyle.DashLine))
            painter.drawRect(r)
            painter.drawRect(QRectF(r.right()-5,r.bottom()-5,10,10))
        now = time.perf_counter()
        for index,(q,t) in enumerate(self.laser):
            c = QColor("#FF453A")
            c.setAlphaF(max(0,min(1,1-(now-t))))
            painter.setPen(QPen(c,3,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap))
            if index:
                painter.drawLine(self.view(self.laser[index-1][0]),self.view(q))
            else:
                painter.drawEllipse(self.view(q),2,2)
        painter.restore()

    def _zoom(self, factor, old_center, new_center):
        h = self.host
        callback = getattr(h,"transfer_zoom",None)
        if callback and callback(factor,old_center,new_center):
            return
        q = self.local(old_center)
        if callable(getattr(h,"scale",None)):
            h.set_zoom(h.zoom*factor,old_center)
            h.ox += new_center.x()-old_center.x()
            h.oy += new_center.y()-old_center.y()
        else:
            h.scale = max(.2,min(4,h.scale*factor))
            h.dx,h.dy = new_center.x()-q.x()*h.scale,new_center.y()-q.y()*h.scale
        h.update()

    def view_action(self,action):
        center = QPointF(self.host.width()/2,self.host.height()/2)
        if action == "reset":
            callback = getattr(self.host,"transfer_reset",None)
            if callback and callback():
                return
            if callable(getattr(self.host,"scale",None)):
                self.host.set_zoom(1,center)
                self.host.ox = self.host.oy = 0
            else:
                self.host.scale,self.host.dx,self.host.dy = 1,0,0
            self.host.update()
        else:
            self._zoom(1.25 if action == "in" else .8,center,center)

    def _touch(self,event):
        if self.tablet_down or time.perf_counter() < self.suppress_mouse_until:
            event.accept()
            return True
        points = [p.position() for p in event.points() if p.state() != QEventPoint.State.Released]
        if len(points) >= 2:
            if self.touching:
                self.hold.stop()
                if self.mode:
                    self._release()
                elif getattr(self.host,"active",None) is not None:
                    self.host._release(*([points[0]] if callable(getattr(self.host,"scale",None)) else []))
                else:
                    # 从单指过渡到双指时取消点击，避免误翻页。
                    self.host.pan_from = None
                    if hasattr(self.host,"drag"):
                        self.host.drag = None
                self.touching = False
            a,b = points[:2]
            center = (a+b)/2
            distance = math.hypot(a.x()-b.x(),a.y()-b.y())
            if distance < 2:
                event.accept()
                return True
            if self.gesture:
                previous, old_center = self.gesture
                self._zoom(distance/max(1,previous),old_center,center)
            self.gesture = distance,center
        elif self.gesture:
            if not points:
                self.gesture = None
        elif points:
            q = points[0]
            if not self.touching:
                self.touching = True
                if not self._press(q):
                    self.host._press(q)
            elif self.mode:
                self._move(q)
            else:
                self._watch_move()
                self.host._move(q)
        elif self.touching:
            self.hold.stop()
            if self.mode:
                if event.points():
                    self._move(event.points()[0].position())
                self._release()
            else:
                pos = event.points()[0].position() if event.points() else QPointF()
                self.host._release(*([pos] if callable(getattr(self.host,"scale",None)) else []))
            self.touching = False
        event.accept()
        return True

    def eventFilter(self, watched, event):  # noqa: N802
        kind = event.type()
        if kind == QEvent.Type.KeyPress:
            key = event.key()
            if self.ids and key in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace):
                self.selection_action("delete")
                return True
            if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
                if key in (Qt.Key.Key_Z,Qt.Key.Key_Y):
                    self.reset()
                    self.host.undo() if key == Qt.Key.Key_Z else self.host.redo()
                    return True
            elif key in (Qt.Key.Key_V,Qt.Key.Key_P,Qt.Key.Key_H,Qt.Key.Key_E,Qt.Key.Key_L):
                tool = {Qt.Key.Key_V:"move" if not callable(getattr(self.host,"scale",None)) else "pointer",
                        Qt.Key.Key_P:"pen",Qt.Key.Key_H:"marker",Qt.Key.Key_E:"eraser",Qt.Key.Key_L:"laser"}[key]
                self.host.set_tool(tool)
                return True
        if kind in (QEvent.Type.TouchBegin,QEvent.Type.TouchUpdate,QEvent.Type.TouchEnd,QEvent.Type.TouchCancel):
            if kind == QEvent.Type.TouchCancel:
                self.reset()
                self.host.active = None
                event.accept()
                return True
            return self._touch(event)
        tablet = kind in (QEvent.Type.TabletPress,QEvent.Type.TabletMove,QEvent.Type.TabletRelease)
        mouse = kind in (QEvent.Type.MouseButtonPress,QEvent.Type.MouseMove,QEvent.Type.MouseButtonRelease)
        if not tablet and not mouse:
            return False
        if mouse and (self.tablet_down or time.perf_counter() < self.suppress_mouse_until):
            return True
        if mouse and kind != QEvent.Type.MouseMove and event.button() != Qt.MouseButton.LeftButton:
            return False
        if kind in (QEvent.Type.TabletPress,QEvent.Type.MouseButtonPress):
            if tablet:
                self.tablet_down = True
            self.snap_original = None
            from PySide6.QtGui import QPointingDevice
            eraser = tablet and event.pointerType() == QPointingDevice.PointerType.Eraser
            return self._press(event.position(),eraser)
        if kind in (QEvent.Type.TabletMove,QEvent.Type.MouseMove):
            if self.mode:
                self._move(event.position())
                return True
            if tablet or event.buttons() & Qt.MouseButton.LeftButton:
                self._watch_move()
        else:
            self.hold.stop()
            self.snap_original = None
            if tablet:
                self.tablet_down = False
                self.suppress_mouse_until = time.perf_counter()+.08
            if self.mode:
                self._move(event.position())
                self._release()
                return True
        return False
