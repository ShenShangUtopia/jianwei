"""主窗口持有的内容路由；独立窗口复用同一总线。"""
from __future__ import annotations

import threading

from PySide6.QtCore import QObject, Signal



class TransferRouter(QObject):
    ocr_done = Signal(object,str)

    def __init__(self,window,bus):
        super().__init__(window)
        self.window,self.bus = window,bus
        self.pending = None
        self.ocr_token = None
        self.closing = False
        bus.sent.connect(self.route)
        bus.origin_requested.connect(self.origin)
        self.ocr_done.connect(self._ocr_done)

    def player(self,context=None,clip=None):
        from ..lecture.player import LecturePlayer
        if isinstance(context,LecturePlayer) and not context.closing:
            return context
        page = self.window.page("lecture")
        alive = [p for p in page.players if not p.closing]
        if alive:
            return alive[-1]
        from ..lecture import library
        meta = library.from_clip(clip,self.bus.store,"素材工作簿")
        return page.play(meta)

    def route(self,clip,target,context):
        try:
            if target=="basket":
                return
            if target in ("board","lecture"):
                # 新建工作簿已用 clip 作为首页，避免重复加同一插页。
                page = self.window.page("lecture")
                existing = any(not p.closing for p in page.players)
                player = self.player(context,clip)
                if target=="board":
                    player.receive_board(clip)
                elif existing or context is player:
                    player.insert_clip(clip)
                player.show()
                player.raise_()
                player.activateWindow()
            elif target.startswith("bench:"):
                studio = self.window.goto("bench",target.split(":",1)[1])
                studio.clip_transfer.receive(clip)
                self.window.present()
            elif target=="analysis":
                self.analyze(clip)
        except (OSError,ValueError,KeyError,TypeError,RuntimeError) as exc:
            self.bus.error.emit(str(exc))

    def origin(self,origin):
        try:
            kind,ref = origin.get("type",""),origin.get("ref",{})
            if kind in ("lecture","board"):
                from ..lecture import library
                meta = library.read_json(library.folder(ref.get("lecture_id",""))/"meta.json")
                if not meta:
                    raise ValueError("来源课件已不存在")
                page = self.window.page("lecture")
                player = next((p for p in page.players if not p.closing and p.meta["id"]==meta["id"]),None)
                if player is None:
                    player = page.play(meta)
                player.show_origin(origin)
            elif kind.startswith("bench:"):
                bid = ref.get("bench_id") or kind.split(":",1)[1]
                studio = self.window.goto("bench",bid)
                if ref.get("clip_id"):
                    studio.clip_transfer.restore(self.bus.store.load(ref["clip_id"]))
                self.window.present()
            elif kind=="analysis":
                page = self.window.goto("analysis")
                if ref.get("clip_id"):
                    page.text.setPlainText(self.bus.store.load(ref["clip_id"]).get("text",""))
                if ref.get("lesson_id"):
                    from ..analysis import lesson
                    value = next((v for v in lesson.history() if v.get("ticket",{}).get("id")==ref["lesson_id"]),None)
                    if value:
                        page.rev += 1
                        if page.worker:
                            page.worker.cancelled = True
                        page.L = value
                        page.text.setPlainText(value.get("problem",""))
                        page.render(value)
                        page.visuals(value)
                        from PySide6.QtWidgets import QTabWidget
                        tabs=page.right.currentWidget()
                        if isinstance(tabs,QTabWidget):
                            tabs.setCurrentIndex(max(0,min(tabs.count()-1,int(ref.get("tab",0)))))
                        page.go_step(max(0,min(63,int(ref.get("step",0)))))
                        if isinstance(tabs,QTabWidget):
                            active=tabs.currentWidget()
                            if callable(getattr(active,"go",None)):
                                active.go(max(0,min(63,int(ref.get("step",0)))))
                        parameters=ref.get("parameters") or {}
                        if not isinstance(parameters,dict):
                            raise ValueError("图形参数来源格式无效")
                        for name,value in parameters.items():
                            page.figure_view.set_parameter(name,value)
                self.window.present()
        except (OSError,ValueError,KeyError,TypeError) as exc:
            self.bus.error.emit(str(exc))

    def bind_analysis(self,page):
        page.lesson_ready.connect(self.analysis_ready)
        from PySide6.QtWidgets import QPushButton
        for label,target in (("在工作台继续","bench"),("送图解到黑板","board"),("插入课件","lecture")):
            button = QPushButton(label)
            button.clicked.connect(lambda _=False,t=target:self.export_analysis(page,t))
            page.action_row.addWidget(button,1)
        page.sync_actions()

    def export_analysis(self,page,target):
        if not page.L:
            page.status_l.setText("请先完成题目分析")
            return
        widget = page.right.currentWidget()
        from PySide6.QtWidgets import QTabWidget
        tab=widget.currentIndex() if isinstance(widget,QTabWidget) else 0
        diagram=widget.currentWidget() if isinstance(widget,QTabWidget) else widget
        from ..analysis.figure.view import FigureView
        svg=diagram.svg() if isinstance(diagram,FigureView) else None
        image=diagram.image() if isinstance(diagram,FigureView) else diagram.grab().toImage()
        step=getattr(diagram,"k",getattr(getattr(page,"figure_view",None),"k",0))
        clip = self.bus.store.create(image=image,svg=svg,text=page.L.get("problem",""),
                    origin=dict(type="analysis",ref=dict(lesson_id=page.L.get("ticket",{}).get("id"),step=step,tab=tab,parameters=dict(diagram.parameters) if isinstance(diagram,FigureView) else {})))
        if target=="bench":
            self.bus.remember(clip)
            self.pending = clip,page.rev
            self.analysis_ready(page.L)
        else:
            self.bus.send(clip,target)

    def analyze(self,clip):
        page = self.window.goto("analysis")
        self.window.present()
        text = clip.get("text","").strip()
        if text:
            page.text.setPlainText(text)
            page.go(text)
            self.pending = clip,page.rev
            return
        page.status_l.setText("正在识别素材中的题目…")
        token = object()
        self.ocr_token = token
        self.pending = clip,page.rev
        image = self.bus.store.render(clip)
        def work():
            from ..lecture.lookup import Ocr
            ocr = Ocr()
            text = ""
            try:
                ocr.start()
                text = ocr.read(image,wait=12)
                why = ocr.problem()
            finally:
                ocr.stop()
            if not self.closing:
                try:
                    self.ocr_done.emit(token,text or ("\0"+why if why else ""))
                except RuntimeError:
                    pass
        threading.Thread(target=work,daemon=True).start()

    def _ocr_done(self,token,text):
        if token is not self.ocr_token or not self.pending:
            return
        page = self.window.page("analysis")
        clip,rev = self.pending
        if page.rev!=rev:
            return
        if not text or text.startswith("\0"):
            self.pending = None
            why = text[1:] if text else ""
            page.status_l.setText(f"{why}请手动粘贴文字后点分析" if why else "未识别到题目，请手动粘贴文字后点分析")
            return
        page.text.setPlainText(text)
        page.go(text)
        self.pending = clip,page.rev

    def analysis_ready(self,lesson):
        if not self.pending:
            return
        page = self.window.page("analysis")
        clip,rev = self.pending
        if page.rev!=rev:
            self.pending = None
            return
        self.pending = None
        from . import problem_transfer
        bid = problem_transfer.destination(lesson)
        if not bid:
            page.status_l.setText("已保留分步图解；没有匹配的自由工作台，可将图解送到黑板")
            return
        try:
            studio = self.window.goto("bench",bid)
            studio.clip_transfer.receive(clip)
            message = problem_transfer.apply(studio,lesson)
            studio.B.toast(message,ms=6000)
            self.window.present()
        except (OSError,ValueError,KeyError,TypeError,RuntimeError) as exc:
            self.bus.error.emit("题目已分析，工作台配置未完成："+str(exc))
