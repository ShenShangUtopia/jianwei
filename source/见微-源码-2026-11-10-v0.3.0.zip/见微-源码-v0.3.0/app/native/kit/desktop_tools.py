"""Optional desktop annotation. One selected screen, no hooks or input injection."""
import json
from PySide6.QtCore import QPointF, Qt, Signal, QSaveFile, QIODevice
from PySide6.QtGui import QColor, QImage, QPainter, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QWidget, QFrame, QVBoxLayout, QHBoxLayout,
                               QLabel, QPushButton, QComboBox, QFileDialog)
from . import pen
from .pen_session import PenSession
from .pen_bar import PenBar
from .home import load_json,home


class DesktopInk(QWidget):
    desktop_ink=True
    activity=Signal()
    tool_changed=Signal(str)

    def __init__(self):
        super().__init__(None,Qt.WindowType.Tool|Qt.WindowType.FramelessWindowHint|Qt.WindowType.WindowStaysOnTopHint)
        self.setWindowTitle('见微 · 桌面批注层')
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.tool='pointer'
        self.color,self.width_px='#E5484D',3.5
        self.active=None
        self.histories={}
        self.screen_key=''
        self.pen_session=PenSession(self,lambda:self.history().strokes,self._live,self._commit,
                                    lambda p:QPointF(p),lambda p:QPointF(p),lambda:1.0)
        QShortcut(QKeySequence('Escape'),self,activated=lambda:self.set_tool('pointer'))
        self.setWindowFlag(Qt.WindowType.WindowTransparentForInput,True)

    def history(self):
        return self.histories.setdefault(self.screen_key,pen.History())

    def use_screen(self,screen):
        self.set_tool('pointer')
        self.screen_key=screen.name()
        self.setGeometry(screen.geometry())
        self.update()

    def scale(self):
        return 1.0

    def transfer_zoom(self,*args):
        return True  # Desktop coordinates stay fixed; do not move others' windows.

    def transfer_reset(self):
        return True

    def _live(self,strokes):
        h=self.history()
        h.strokes=list(strokes)
        h._bump()
        self.update()

    def _commit(self,before,after):
        self.history().replace(after,before)
        self.update()

    def set_tool(self,tool):
        self.pen_session.reset()
        if self.active is not None:
            self.history().add(self.active)
            self.active=None
        self.tool=tool
        shown=self.isVisible()
        self.setWindowFlag(Qt.WindowType.WindowTransparentForInput,tool=='pointer')
        self.setCursor(Qt.CursorShape.ArrowCursor if tool=='pointer' else Qt.CursorShape.CrossCursor)
        if shown:
            self.show()
        if shown and tool!='pointer':
            self.activateWindow()
            self.setFocus()
        self.tool_changed.emit(tool)
        self.update()

    def _press(self,pos,pr=1.0,pressure=False,eraser=False):
        if self.tool not in ('pen','marker','chalk'):
            return
        width=self.width_px*(4.5 if self.tool=='marker' else 1)
        self.active=pen.new_stroke(self.tool,self.color,width,pressure)
        pen.add_point(self.active,pos.x(),pos.y(),pr)
        self.update()

    def _move(self,pos,pr=1.0):
        if self.active is not None:
            pen.add_point(self.active,pos.x(),pos.y(),pr,.6)
            self.update()

    def _release(self,pos=None):
        if self.active is not None:
            self.history().add(self.active)
            self.active=None
            self.update()

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.RightButton:
            self.set_tool('pointer')
        elif event.button()==Qt.MouseButton.LeftButton:
            self._press(event.position())

    def mouseMoveEvent(self,event):
        if event.buttons() & Qt.MouseButton.LeftButton:
            self._move(event.position())

    def mouseReleaseEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            self._release(event.position())

    def tabletEvent(self,event):
        if event.type()==event.Type.TabletPress:
            self._press(event.position(),event.pressure(),True)
        elif event.type()==event.Type.TabletMove:
            self._move(event.position(),event.pressure())
        elif event.type()==event.Type.TabletRelease:
            self._release(event.position())
        event.accept()

    def undo(self):
        self.pen_session.reset()
        self.history().undo()
        self.update()

    def redo(self):
        self.pen_session.reset()
        self.history().redo()
        self.update()

    def clear(self):
        self.pen_session.reset()
        self.active=None
        self.history().clear()
        self.update()

    def paint_ink(self,painter):
        for stroke in self.history().strokes:
            pen.draw(painter,stroke)
        if self.active is not None:
            pen.draw(painter,self.active)

    def paintEvent(self,event):
        p=QPainter(self)
        try:
            # Non-zero alpha across the input surface is needed for Windows hit testing.
            if self.tool!='pointer':
                p.fillRect(self.rect(),QColor(0,0,0,1))
            self.paint_ink(p)
            self.pen_session.paint(p)
        finally:
            p.end()

    def image(self):
        ratio=self.devicePixelRatioF()
        image=QImage(round(self.width()*ratio),round(self.height()*ratio),QImage.Format.Format_ARGB32_Premultiplied)
        image.setDevicePixelRatio(ratio)
        image.fill(Qt.GlobalColor.transparent)
        p=QPainter(image)
        try:
            self.paint_ink(p)
        finally:
            p.end()
        return image


class _Grip(QLabel):
    def __init__(self,owner):
        super().__init__('⠿ 桌面批注')
        self.owner=owner
        self.offset=None
        self.setCursor(Qt.CursorShape.SizeAllCursor)
        self.setToolTip('拖动工具栏；指针模式可正常操作其他应用。笔迹只暂存在本次运行中。')

    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:
            self.offset=e.globalPosition().toPoint()-self.owner.pos()

    def mouseMoveEvent(self,e):
        if self.offset is not None and e.buttons() & Qt.MouseButton.LeftButton:
            self.owner.move(e.globalPosition().toPoint()-self.offset)

    def mouseReleaseEvent(self,e):
        self.offset=None
        self.owner.clamp()


class DesktopToolbar(QFrame):
    def __init__(self):
        super().__init__(None,Qt.WindowType.Tool|Qt.WindowType.FramelessWindowHint|Qt.WindowType.WindowStaysOnTopHint|Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setWindowTitle('见微 · 悬浮工具栏')
        self.setObjectName('desktopTools')
        self.setStyleSheet('QFrame#desktopTools{background:#111A17;border:1px solid #34463F;border-radius:9px;} QLabel{color:#DCE5E0;font-size:13px;} QPushButton,QComboBox{background:#22332E;color:#DCE5E0;border:1px solid #34463F;border-radius:4px;padding:5px;font-size:12px;} QPushButton:checked{background:#C8402A;color:white;}')
        self.overlay=DesktopInk()
        self.active_screen=None
        self._closing=False
        self.settings_path=home()/'desktop-toolbar.json'
        self.preferences=load_json('desktop-toolbar.json',None)
        self.settings_writable=(self.preferences is None and not self.settings_path.exists()) or (isinstance(self.preferences,dict) and self.preferences.get('v',1)==1)
        if self.preferences is None:
            self.preferences={}
        if not self.settings_writable:
            self.preferences={}
        lay=QVBoxLayout(self)
        lay.setContentsMargins(8,5,8,7)
        lay.setSpacing(4)
        row=QHBoxLayout()
        row.addWidget(_Grip(self))
        self.mode=QLabel('操作其他应用')
        row.addWidget(self.mode,1)
        self.screens=QComboBox()
        self.screens.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.screens.setMaximumWidth(135)
        self.screens.setMinimumWidth(110)
        row.addWidget(self.screens)
        self.fold=self.button('收起',self.collapse)
        row.addWidget(self.fold)
        row.addWidget(self.button('关闭',self.close))
        lay.addLayout(row)
        self.pen_bar=PenBar(self.overlay,self.overlay.pen_session,on_dark=True)
        # A desktop screenshot rectangle is deliberately not exposed as a pen tool.
        self.pen_bar.keys['select'].hide()
        lay.addWidget(self.pen_bar)
        self.footer=QWidget()
        foot=QHBoxLayout(self.footer)
        foot.setContentsMargins(0,0,0,0)
        foot.addWidget(self.button('操作其他应用',lambda:self.overlay.set_tool('pointer')))
        foot.addWidget(self.button('清除本屏',self.overlay.clear))
        foot.addWidget(self.button('导出透明批注',self.export))
        self.hidden_key=self.button('隐藏笔迹',self.toggle_ink)
        foot.addWidget(self.hidden_key)
        lay.addWidget(self.footer)
        self.overlay.tool_changed.connect(self.sync)
        self.screens.currentIndexChanged.connect(self.change_screen)
        app=QApplication.instance()
        app.screenAdded.connect(self.refresh_screens)
        app.screenRemoved.connect(self.refresh_screens)
        app.aboutToQuit.connect(self.shutdown)
        self.refresh_screens()
        self.adjustSize()
        def position(name):
            value=self.preferences.get(name,80)
            return int(value) if type(value) in (float,int) and -100000<=value<=100000 else 80
        self.move(position('x'),position('y'))
        self.clamp()

    @staticmethod
    def button(text,callback):
        b=QPushButton(text)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.clicked.connect(callback)
        return b

    def refresh_screens(self,*args):
        current=self.active_screen
        self.screens.blockSignals(True)
        self.screens.clear()
        for i,screen in enumerate(QApplication.screens()):
            self.screens.addItem(f'屏幕 {i+1}'+(' · 主' if screen==QApplication.primaryScreen() else ''),screen)
        index=next((i for i in range(self.screens.count()) if self.screens.itemData(i)==current),0)
        self.screens.setCurrentIndex(index)
        self.screens.blockSignals(False)
        if self.screens.count():
            self.change_screen(index)

    def change_screen(self,index):
        screen=self.screens.itemData(index)
        if screen is None:
            return
        if self.active_screen is not None:
            try:
                self.active_screen.geometryChanged.disconnect(self.screen_geometry)
            except (RuntimeError,TypeError):
                pass
        self.active_screen=screen
        screen.geometryChanged.connect(self.screen_geometry)
        self.overlay.use_screen(screen)
        if self.isVisible():
            self.show_ink()
        self.pen_bar.sync()
        self.clamp()

    def screen_geometry(self,*args):
        if self.active_screen is not None:
            self.overlay.use_screen(self.active_screen)
            self.clamp()

    def clamp(self):
        screen=QApplication.screenAt(self.frameGeometry().center()) or self.active_screen or QApplication.primaryScreen()
        if screen:
            r=screen.availableGeometry()
            self.move(max(r.left(),min(self.x(),r.right()-self.width()+1)),max(r.top(),min(self.y(),r.bottom()-self.height()+1)))

    def sync(self,tool):
        self.mode.setText('操作其他应用' if tool=='pointer' else '批注中 · 右键 / Esc 返回操作')
        self.pen_bar.sync()
        if tool!='pointer':
            self.show_ink()
        self.raise_()

    def show_ink(self):
        self.overlay.show()
        self.hidden_key.setText('隐藏笔迹')

    def collapse(self):
        on=not self.pen_bar.isVisible()
        self.pen_bar.setVisible(on)
        self.footer.setVisible(on)
        self.fold.setText('收起' if on else '展开')
        self.adjustSize()
        self.clamp()

    def toggle_ink(self):
        self.overlay.set_tool('pointer')
        on=not self.overlay.isVisible()
        self.overlay.setVisible(on)
        self.hidden_key.setText('隐藏笔迹' if on else '显示笔迹')

    def export(self):
        self.overlay.set_tool('pointer')
        path,_=QFileDialog.getSaveFileName(self,'导出透明批注（不含其他应用画面）','','PNG 图片 (*.png)')
        if path:
            if not path.lower().endswith('.png'):
                path+='.png'
            self.mode.setText('已导出透明批注' if self.overlay.image().save(path) else '导出失败，请换一个目录')

    def open(self):
        self._closing=False
        self.refresh_screens()
        self.overlay.set_tool('pointer')
        self.show_ink()
        self.show()
        self.raise_()
        self.clamp()

    def shutdown(self):
        self._closing=True
        self.overlay.set_tool('pointer')
        self.overlay.pen_session.reset()
        self.overlay.hide()
        self.hide()

    def closeEvent(self,event):
        self.shutdown()
        if self.settings_writable:
            try:
                current=json.loads(self.settings_path.read_text(encoding='utf-8')) if self.settings_path.exists() else {}
                if isinstance(current,dict) and current.get('v',1)==1:
                    writer=QSaveFile(str(self.settings_path))
                    payload=json.dumps(dict(current,v=1,x=self.x(),y=self.y()),ensure_ascii=False).encode('utf-8')
                    if writer.open(QIODevice.OpenModeFlag.WriteOnly):
                        if writer.write(payload)==len(payload):
                            writer.commit()
                        else:
                            writer.cancelWriting()
            except (OSError,ValueError):
                pass
        event.accept()


def toggle_desktop_tools():
    app=QApplication.instance()
    toolbar=getattr(app,'_jianwei_desktop_toolbar',None)
    from shiboken6 import isValid
    if toolbar is None or not isValid(toolbar):
        toolbar=DesktopToolbar()
        app._jianwei_desktop_toolbar=toolbar
    if toolbar.isVisible():
        toolbar.close()
    else:
        toolbar.open()
    return toolbar
