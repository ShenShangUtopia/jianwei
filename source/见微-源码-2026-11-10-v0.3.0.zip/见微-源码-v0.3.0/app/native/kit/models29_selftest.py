"""New separation/electrical models: independent numbers + real placement/snapshots."""
from . import test_runtime
test_runtime.configure()
import copy
import math
import sys
from pathlib import Path


def main(output=None):
    app=test_runtime.application()
    from ..lab.benches import separation as s,circuit_devices as d
    from ..lab.studio import Studio
    from . import state_graph
    from .ctx import Loop
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    q=s.create('filter')
    for _ in range(5):
        s.operate(q,'run')
    assert q['filtrate_ml']==100 and q['filtrate_solute']==10 and abs(q['retained']-2)<1e-12
    assert q['filtrate_solid']==0
    q=s.create('filter');q['paper']=False
    s.operate(q,'run')
    assert q['retained']==0 and abs(q['filtrate_solid']-.4)<1e-12
    q=s.create('filter');q['outlet']='closed'
    s.operate(q,'run')
    assert q['filtrate_ml']==0
    q=s.create('extract')
    s.operate(q,'shake')
    assert abs(q['organic_n']-20/3)<1e-10
    s.operate(q,'drain')
    assert abs(q['drained_n']-2/3)<1e-10
    assert abs(q['water_n']+q['organic_n']+q['drained_n']-10)<1e-10
    q=s.create('extract');q['density']=1.6
    s.operate(q,'shake');s.operate(q,'drain')
    assert abs(q['drained_n']-8/3)<1e-10
    q=s.create('distill')
    T,ys=s.bubble(q)
    pressure=sum(.5*math.exp(30000/8.314462618*(1/(bp+273.15)-1/(T+273.15))) for bp in (70,110))
    assert abs(pressure-1)<1e-10 and ys[0]>.5 and 70<T<110
    first=None
    for _ in range(100):
        s.operate(q,'heat')
        total=sum(q['collected'])
        if total and first is None:
            first=q['collected'][0]/total
        assert all(n>=0 for n in q['n'])
        assert abs(sum(q['n'])+total-1)<1e-9
    assert first>.5 and q['collected'][0]/sum(q['collected'])<first
    q=s.create('distill');q['water']='off'
    s.operate(q,'heat')
    assert sum(q['collected'])==0 and q['T']==20
    def device(kind):
        return dict(instrument=kind,**copy.deepcopy(d.DEVICES[kind][1]))
    motor=device('motor')
    g,j=d.stamp(motor,.001)
    assert g*6+j==3 # stalled E/R
    for _ in range(10000):
        g,j=d.stamp(motor,.001)
        current=g*6+j
        d.advance(motor,6,current,.001)
    target=.1*6/(2*.02+.1**2)
    assert abs(motor['omega']-target)<.001
    assert abs(6*current-(current**2*2+motor['back_emf']*current))<1e-8
    coil=device('inductor')
    for _ in range(10000):
        g,j=d.stamp(coil,.001)
        d.advance(coil,6,g*6+j,.001)
    assert abs(coil['coil_i']-3)<1e-6
    energy=coil['magnetic_energy']
    for _ in range(20):
        g,j=d.stamp(coil,.001)
        voltage=-j/g # disconnect source: total branch current=0
        d.advance(coil,voltage,0,.001)
        assert coil['magnetic_energy']<=energy
        energy=coil['magnetic_energy']
    assert energy<1e-9 and voltage<0
    meter=device('multimeter');meter.update(mode='resistance',range=10000,powered=False)
    g,j=d.stamp(meter,.01)
    u=-j/(g+1/5000)
    d.advance(meter,u,g*u+j,.01)
    assert abs(meter['reading']-5000)<1e-6
    meter['powered']=True
    d.advance(meter,6,0,.01)
    assert meter['reading'] is None and '带电' in meter['warning']
    meter.update(mode='current',range=.2)
    d.advance(meter,1,20,.01)
    assert meter['reading'] is None and '超量程' in meter['warning']
    studio=Studio('day')
    studio.resize(1440,900)
    studio.show()
    for bid,ids in [('chem',['process-'+k for k in s.NAMES]),('circ',['tool-'+k for k in d.DEVICES])]:
        studio.open_bench(bid)
        app.processEvents()
        B=studio.B
        initial=B.transfer_snapshot()
        for ident in ids:
            B.transfer_restore(initial)
            item=B.pal.items[ident].it
            item['click']()
            item['drop'](700,600)
            app.processEvents()
            data=state_graph.decode(B.transfer_snapshot())
            if bid=='chem':
                obj=next(v for v in data['objs'] if v.get('process'))
                s.operate(obj['process'],'shake' if obj['process']['kind']=='extract' else 'run')
                data['W']['sel']=obj
                B.transfer_restore(state_graph.encode(data))
                after=state_graph.decode(B.transfer_snapshot())
                assert next(v['process'] for v in after['objs'] if v.get('process'))==obj['process']
            else:
                obj=next(q for q in data['S']['comps'] if q.get('instrument')==ident[5:])
                obj.update(a=[2,0],b=[0,0])
                bat=dict(t='bat',a=[0,0],b=[2,0],E=6.,r=.5,id=999,name='测试电源',I=0.,U=0.,P=0.,ph=0.,v=0.)
                data['S'].update(comps=[bat,obj],sel=obj,sig='')
                B.transfer_restore(state_graph.encode(data))
                after=state_graph.decode(B.transfer_snapshot())
                got=after['S']['comps'][1]
                if ident=='tool-motor':
                    assert abs(got['I']-6/2.5)<1e-7
                    obj['R']=4.
                    B.transfer_restore(state_graph.encode(data))
                    got=state_graph.decode(B.transfer_snapshot())['S']['comps'][1]
                    assert abs(got['I']-6/4.5)<1e-7
                assert got['instrument']==obj['instrument']
            studio.ctx.stage.repaint()
            assert not studio.ctx.stage.error,ident
            studio.grab().save(str(out/(ident+'.png')))
        if bid=='circ':
            # Deterministic RC charging through the actual nodal solver + loaded scope.
            snap=state_graph.decode(B.transfer_snapshot())
            scope=copy.deepcopy(next(q for q in snap['S']['comps'] if q.get('instrument')=='scope'))
            bat.update(a=[2,10],b=[2,6])
            scope.update(a=[9,6],b=[9,10],trace=[],clock=0.)
            resistor=dict(t='res',a=[2,6],b=[7,6],R=1000.,id=997,name='串联电阻',I=0.,U=0.,P=0.,ph=0.,v=0.)
            capacitor=dict(t='cap',a=[7,6],b=[7,10],C=1000.,id=998,name='电容',I=0.,U=0.,P=0.,ph=0.,v=0.)
            wires=[dict(t='wire',a=a,b=b,id=990+i,name='导线',I=0.,U=0.,P=0.,ph=0.,v=0.) for i,(a,b) in enumerate([([7,10],[2,10]),([7,6],[9,6]),([7,10],[9,10])])]
            snap['S'].update(comps=[bat,resistor,capacitor,*wires,scope],sel=scope,sig='')
            B.transfer_restore(state_graph.encode(snap))
            loop=next(t for t in studio.ctx.timers if isinstance(t,Loop))
            loop.pause()
            for _ in range(1000):
                loop.fn(.001)
            actual=state_graph.decode(B.transfer_snapshot())['S']['comps'][-1]
            tau=(1/(1/1000.5+1/1e7))*.001
            steady=6*1e7/(1e7+1000.5)
            expected=steady*(1-math.exp(-1/tau))
            assert abs(actual['trace'][-1][1]-expected)<.005,(actual['trace'][-1],expected)
            assert len(actual['trace'])==400
            for timer in studio.ctx.timers:
                if not isinstance(timer,Loop):
                    timer.timeout.emit()
            studio.ctx.stage.repaint()
            assert not studio.ctx.stage.error
            studio.grab().save(str(out/'scope-rc.png'))
    studio.go_home()
    studio.close()
    print('MODELS29 OK 3 separation stations + 5 circuit devices; conservation, motor/RL/RC references, placement, state restore',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
