"""二维坐标视图（网格、坐标轴、函数图像）与三维相机（对应旧 core.js 的 View / Cam3 / v3）。"""
from __future__ import annotations

import math

from PySide6.QtGui import QPainter, QPainterPath

from ..design.tokens import T
from .core import PI, clamp, fmt, nice_step
from .draw import D


def pi_label(v: float) -> str:
    k = round(v / (PI / 2))
    if not k:
        return "0"
    n, d = (k // 2, "") if k % 2 == 0 else (k, "/2")
    s = "π" if n == 1 else "-π" if n == -1 else f"{n}π"
    return s + d


class View:
    def __init__(self, c, xmin, xmax, ymin, ymax, equal=False, pad=(0, 0, 0, 0)):
        self.c = c
        self.home = [xmin, xmax, ymin, ymax]
        self.r = [xmin, xmax, ymin, ymax]
        self.equal = equal
        self.pad = pad
        self.fit()

    def reset(self) -> None:
        self.r = list(self.home)

    def fit(self) -> None:
        pl, pr, pt, pb = self.pad
        W = max(10, self.c.w - pl - pr)
        H = max(10, self.c.h - pt - pb)
        x0, x1, y0, y1 = self.r
        if self.equal:
            s = min(W / (x1 - x0), H / (y1 - y0))
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
            x0, x1 = cx - W / s / 2, cx + W / s / 2
            y0, y1 = cy - H / s / 2, cy + H / s / 2
        self.x0, self.x1, self.y0, self.y1 = x0, x1, y0, y1
        self.W, self.H, self.ox, self.oy = W, H, pl, pt
        self.sx, self.sy = W / (x1 - x0), H / (y1 - y0)

    def X(self, x):
        return self.ox + (x - self.x0) * self.sx

    def Y(self, y):
        return self.oy + (self.y1 - y) * self.sy

    def P(self, x, y):
        return self.X(x), self.Y(y)

    def ix(self, px):
        return self.x0 + (px - self.ox) / self.sx

    def iy(self, py):
        return self.y1 - (py - self.oy) / self.sy

    def begin(self, grid=True, **o):
        self.fit()
        self.c.clear()
        if grid:
            self.grid(**o)
        return self.c.g

    def grid(self, xstep=None, ystep=None, piX=False, axes=True, ticks=True, xl="x", yl="y"):
        g = self.c.g
        x0, x1, y0, y1 = self.x0, self.x1, self.y0, self.y1
        sx = xstep or ((PI / 2) * max(1, round(nice_step(80 / self.sx) / (PI / 2))) if piX else nice_step(80 / self.sx))
        sy = ystep or nice_step(60 / self.sy)
        # 细格、粗格各攒成一条路径一次描完（逐条 drawLine 在大画布上要十几毫秒）
        minor, major = QPainterPath(), QPainterPath()
        for k in range(math.ceil(x0 / sx * 5), math.floor(x1 / sx * 5) + 1):
            x = round(self.X(k * sx / 5)) + 0.5
            pth = minor if k % 5 else major
            pth.moveTo(x, self.oy)
            pth.lineTo(x, self.oy + self.H)
        for k in range(math.ceil(y0 / sy * 5), math.floor(y1 / sy * 5) + 1):
            y = round(self.Y(k * sy / 5)) + 0.5
            pth = minor if k % 5 else major
            pth.moveTo(self.ox, y)
            pth.lineTo(self.ox + self.W, y)
        aa = g.p.testRenderHint(QPainter.RenderHint.Antialiasing)
        g.p.setRenderHint(QPainter.RenderHint.Antialiasing, False)   # 对齐到像素的直线不需要抗锯齿
        g.p.strokePath(minor, g._pen(T.grid, 1, []))
        g.p.strokePath(major, g._pen(T.grid2, 1, []))
        g.p.setRenderHint(QPainter.RenderHint.Antialiasing, aa)
        if not axes:
            return
        ax = clamp(self.Y(0), self.oy, self.oy + self.H)
        ay = clamp(self.X(0), self.ox, self.ox + self.W)
        D.arrow(g, self.ox, ax, self.ox + self.W, ax, T.axis, 1.2, 7)
        D.arrow(g, ay, self.oy + self.H, ay, self.oy, T.axis, 1.2, 7)
        D.text(g, xl, self.ox + self.W - 4, ax - 10, T.muted, size=12, align="right")
        D.text(g, yl, ay + 8, self.oy + 8, T.muted, size=12)
        if not ticks:
            return
        for k in range(math.ceil(x0 / sx), math.floor(x1 / sx) + 1):
            if not k:
                continue
            x = self.X(k * sx)
            D.line(g, x, ax - 3, x, ax + 3, T.axis, 1)
            D.text(g, pi_label(k * sx) if piX else fmt(k * sx, 3), x, ax + 12, T.muted, size=10.5, align="center", mono=not piX)
        for k in range(math.ceil(y0 / sy), math.floor(y1 / sy) + 1):
            if not k:
                continue
            y = self.Y(k * sy)
            D.line(g, ay - 3, y, ay + 3, y, T.axis, 1)
            D.text(g, fmt(k * sy, 3), ay - 6, y, T.muted, size=10.5, align="right", mono=True)
        D.text(g, "O", ay - 5, ax + 10, T.muted, size=11, align="right")

    def plot(self, f, color, w=2, dash=None) -> None:
        """逐像素采样 y=f(x)；断点（tan、1/x）自动抬笔。"""
        g = self.c.g
        path, pen, py = QPainterPath(), False, 0.0
        px, end = self.ox, self.ox + self.W
        while px <= end:
            try:
                y = f(self.ix(px))
                sy = self.Y(y)
            except (ValueError, ZeroDivisionError, OverflowError, TypeError):
                sy = math.nan
            if not math.isfinite(sy) or abs(sy) > 1e5:
                pen = False
            else:
                if pen and abs(sy - py) > self.H * 1.5:
                    pen = False
                if pen:
                    path.lineTo(px, sy)
                else:
                    path.moveTo(px, sy)
                pen, py = True, sy
            px += 1
        g.p.strokePath(path, g._pen(color, w, dash or []))

    def curve(self, fx, fy, t0, t1, n, color, w=2, dash=None) -> None:
        g = self.c.g
        path, pen = QPainterPath(), False
        for i in range(n + 1):
            t = t0 + (t1 - t0) * i / n
            try:
                x, y = self.X(fx(t)), self.Y(fy(t))
            except (ValueError, ZeroDivisionError, OverflowError):
                pen = False
                continue
            if not (math.isfinite(x) and math.isfinite(y)) or abs(x) > 1e5 or abs(y) > 1e5:
                pen = False
                continue
            if pen:
                path.lineTo(x, y)
            else:
                path.moveTo(x, y)
            pen = True
        g.p.strokePath(path, g._pen(color, w, dash or []))

    def seg(self, x1, y1, x2, y2, c, w=1.5, dash=None) -> None:
        D.line(self.c.g, self.X(x1), self.Y(y1), self.X(x2), self.Y(y2), c, w, dash)

    def vec(self, x1, y1, x2, y2, c, w=2.2) -> None:
        D.arrow(self.c.g, self.X(x1), self.Y(y1), self.X(x2), self.Y(y2), c, w, 10)

    def dot(self, x, y, c, r=4.5, ring=False) -> None:
        D.circle(self.c.g, self.X(x), self.Y(y), r, c, T.stage if ring else None, 2)

    def label(self, s, x, y, c, dx=6, dy=-10, **o) -> None:
        D.text(self.c.g, s, self.X(x) + dx, self.Y(y) + dy, c, **o)

    def fill_between(self, f, g2, a, b, color, n=200) -> None:
        """f 与 g2 在 [a, b] 之间着色（定积分、面积题用）。"""
        pts = []
        for i in range(n + 1):
            x = a + (b - a) * i / n
            pts.append(self.P(x, f(x)))
        for i in range(n, -1, -1):
            x = a + (b - a) * i / n
            pts.append(self.P(x, g2(x)))
        D.poly(self.c.g, pts, color, None)


class v3:
    @staticmethod
    def sub(a, b):
        return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]

    @staticmethod
    def add(a, b):
        return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]

    @staticmethod
    def mul(a, k):
        return [a[0] * k, a[1] * k, a[2] * k]

    @staticmethod
    def dot(a, b):
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

    @staticmethod
    def cross(a, b):
        return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]

    @staticmethod
    def len(a):
        return math.hypot(*a)


class Cam3:
    """正交 + 轻透视相机。proj 返回 (屏幕 x, 屏幕 y, 深度 z, 缩放因子)。"""

    def __init__(self, yaw=-0.6, pitch=0.35, scale=1.0, persp=0.08):
        self.yaw, self.pitch, self.scale, self.persp = yaw, pitch, scale, persp

    def rot(self, p):
        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        cp, sp = math.cos(self.pitch), math.sin(self.pitch)
        x = p[0] * cy + p[2] * sy
        z = -p[0] * sy + p[2] * cy
        y = p[1]
        return [x, y * cp - z * sp, y * sp + z * cp]

    def proj(self, p, c, s):
        x, y, z = self.rot(p)
        f = 1 / (1 - z * self.persp)
        return [c.w / 2 + x * s * self.scale * f, c.h / 2 - y * s * self.scale * f, z, f]
