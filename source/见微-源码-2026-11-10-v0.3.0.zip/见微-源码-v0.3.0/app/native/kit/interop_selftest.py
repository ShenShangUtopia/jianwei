"""主窗口总线、独立窗口、剪贴板/拖放、素材篮与题目→工作台整合测试。"""
from __future__ import annotations

from . import test_runtime
test_runtime.configure()

import hashlib
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QDropEvent

from . import pen
from .clip import MIME


def main(root=None):
    root = Path(root or tempfile.mkdtemp(prefix="jw-interop-"))
    root.mkdir(parents=True,exist_ok=True)
    os.environ["JIANWEI_HOME"] = str(root/"home")
    os.environ["LOCALAPPDATA"] = str(root/"local")
    app = test_runtime.application()
    from ..main_win import NativeWindow
    errors,failures = [],[]
    def check(name,value):
        print("ok  " if value else "FAIL",name,flush=True)
        if not value:
            failures.append(name)
    def spin_until(fn,timeout=4):
        end = time.perf_counter()+timeout
        while not fn() and time.perf_counter()<end:
            app.processEvents()
            time.sleep(.01)
        return bool(fn())
    window = NativeWindow()
    window.resize(1440,900)
    window.show()
    window.clip_bus.error.connect(errors.append)
    studio = window.goto("bench","draw")
    app.processEvents()
    notes = studio.clip_transfer.notes
    s = pen.new_stroke("pen","red",3,True)
    pen.add_point(s,100,100,.25)
    pen.add_point(s,250,180,.85)
    notes.board["strokes"].append(s)
    notes._touch()
    clip = studio.clip_transfer.snapshot(vector=True)
    with patch("native.lecture.lookup.Ocr.start"),patch("native.lecture.lookup.warm"):
        window.clip_bus.send(clip,"board",studio.clip_transfer)
    page = window.page("lecture")
    player = page.players[-1]
    check("工作台送黑板自动建立工作簿",spin_until(lambda:bool(player.board.canvas.board["items"])))
    check("三方共用主窗口总线",player.clip_bus is window.clip_bus and studio.clip_bus is window.clip_bus)
    board = player.board.canvas
    check("笔迹仍是矢量层",bool(board.board["strokes"]) and board.board["strokes"][0]["pressure"])
    origin = board.board["items"][0]["origin"]
    check("来源工作台快照存在",origin["ref"]["clip_id"]==clip["id"])
    pdf_hash = hashlib.sha256((player.dir/"doc.pdf").read_bytes()).hexdigest()
    board_clip = board.export_clip()
    window.clip_bus.send(board_clip,"lecture",player)
    check("黑板素材成为课件插页",player.view.pages==2)
    check("原 PDF 未修改",hashlib.sha256((player.dir/"doc.pdf").read_bytes()).hexdigest()==pdf_hash)
    window.clip_bus.origin_requested.emit(origin)
    studio = window.page("bench")
    check("回到工作台恢复笔迹",studio.cur_bench.id=="draw" and studio.clip_transfer.notes.board["strokes"][0]["id"]==s["id"])
    mime = window.clip_bus.store.mime(clip)
    metadata = json.loads(bytes(mime.data(MIME)))
    check("MIME 携带来源与矢量笔迹",metadata["origin"]==clip["origin"] and metadata["ink"]==clip["ink"])
    interaction = studio.clip_transfer.interactions[0]
    old_count = len(studio.clip_transfer.notes.board["items"])
    event = QDropEvent(QPointF(20,20),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    check("拖放接收已处理",interaction.eventFilter(studio.B.stage,event) and event.isAccepted())
    check("拖入素材成为参考图",len(studio.clip_transfer.notes.board["items"])==old_count+1)
    player.detach_board()
    app.processEvents()
    check("黑板独立窗口保留互通",player.board.window() is player.detached and player.clip_bus is window.clip_bus)
    player.reattach_board()
    window.show_materials()
    app.processEvents()
    basket = window.material_basket
    check("素材篮显示历史",basket.isVisible() and basket.list.count()>=2)
    basket.list.setCurrentRow(0)
    cid = basket.selected()["id"]
    basket.pin()
    check("素材可固定",any(v["id"]==cid and v.get("pinned") for v in window.clip_bus.recent()))
    window.grab().save(str(root/"basket.png"))
    basket.hide()
    analysis = window.page("analysis")
    analysis.engine_box.setCurrentIndex(1)
    problem = "从 20 m 高处以 15 m/s 的速度水平抛出一个小球，g 取 10 m/s²，求落地时间和水平位移。"
    question = window.clip_bus.store.create(text=problem)
    window.clip_bus.send(question,"analysis")
    completed = spin_until(lambda:analysis.L is not None and window.mode=="bench" and studio.cur_bench.id=="scene",timeout=10)
    check("题目分析后直接打开匹配工作台",completed)
    if completed:
        from ..lab.benches.scene_core import E
        obj = next(o for o in E.S.objects if o.type=="projectile")
        check("程序参数准确载入",obj.p.v0==15 and obj.y==20 and E.S.g==10 and not E.S.playing)
        window.grab().save(str(root/"problem-workbench.png"))
    check("正常互通无错误",not errors)
    errors.clear()
    window.clip_bus.origin_requested.emit(dict(type="lecture",ref=dict(lecture_id="../outside")))
    check("不接受越界来源路径",bool(errors))
    window.shutdown()
    window.close()
    print("INTEROP_PHASE5","OK" if not failures else "FAIL "+repr(failures),flush=True)
    return int(bool(failures))


if __name__=="__main__":
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(lambda:main(sys.argv[1] if len(sys.argv)>1 else None)))
