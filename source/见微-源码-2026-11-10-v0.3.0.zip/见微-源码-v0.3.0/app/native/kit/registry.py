"""实验注册表：学科、册次与全部实验（对应旧 core.js 的 Lab）。

    from ..kit.registry import lab

    @lab.reg(id="p-kin", subj="phys", book=0, unit="…", title="…", kw="…", info="…", tasks=[...])
    def init(L): ...
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

SUBJECTS = {
    "math": {"name": "数学", "books": ["必修第一册", "必修第二册", "选择性必修第一册", "选择性必修第二册", "选择性必修第三册"]},
    "phys": {"name": "物理", "books": ["必修第一册", "必修第二册", "必修第三册", "选择性必修第一册", "选择性必修第二册", "选择性必修第三册"]},
    "chem": {"name": "化学", "books": ["必修第一册", "必修第二册", "选择性必修1 化学反应原理", "选择性必修2 物质结构与性质", "选择性必修3 有机化学基础"]},
    "bio": {"name": "生物", "books": ["必修1 分子与细胞", "必修2 遗传与进化", "选择性必修1 稳态与调节", "选择性必修2 生物与环境", "选择性必修3 生物技术与工程"]},
}


@dataclass
class Experiment:
    id: str
    subj: str
    book: int
    unit: str
    title: str
    init: Callable
    kw: str = ""
    info: str = ""
    tasks: list = field(default_factory=list)

    def matches(self, q: str) -> bool:
        return q in (self.title + self.unit + self.kw + SUBJECTS[self.subj]["name"])


class _Lab:
    S = SUBJECTS

    def __init__(self):
        self.list: list[Experiment] = []
        self.by_id: dict[str, Experiment] = {}
        self._loaded = False

    def reg(self, **meta):
        def deco(fn):
            e = Experiment(init=fn, **meta)
            if e.id in self.by_id:
                raise ValueError(f"实验 id 重复：{e.id}")
            self.list.append(e)
            self.by_id[e.id] = e
            return fn
        return deco

    def load(self) -> "_Lab":
        """导入 exps/ 下所有模块（每个模块在导入时注册自己的实验）。"""
        if not self._loaded:
            self._loaded = True
            from ..lab import all_modules  # noqa: F401  显式导入，打包后也找得到
        return self

    def of(self, subj: str) -> list[Experiment]:
        return [e for e in self.list if e.subj == subj]


lab = _Lab()
