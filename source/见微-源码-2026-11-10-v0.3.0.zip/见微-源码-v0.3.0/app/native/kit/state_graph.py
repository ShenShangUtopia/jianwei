"""只含白名单数据的状态快照，保留容器间共享引用/循环；不用 pickle/eval。"""
from __future__ import annotations

import math


def encode(value):
    nodes,seen = [],{}
    def visit(item):
        if item is None or type(item) in (str,bool,int):
            return item
        if type(item) is float:
            return item if math.isfinite(item) else {"float":str(item)}
        if isinstance(item,tuple):
            return {"tuple":[visit(v) for v in item]}
        if isinstance(item,frozenset):
            return {"frozenset":[visit(v) for v in sorted(item,key=repr)]}
        if isinstance(item,(dict,list,set)):
            key = id(item)
            if key in seen:
                return {"ref":seen[key]}
            index = len(nodes)
            seen[key] = index
            node = dict(kind="dict" if isinstance(item,dict) else "set" if isinstance(item,set) else "list",value=[])
            nodes.append(node)
            node["value"] = [[visit(k),visit(v)] for k,v in item.items()] if isinstance(item,dict) else [visit(v) for v in (sorted(item,key=repr) if isinstance(item,set) else item)]
            return {"ref":index}
        if type(item).__name__ in ("QPointF","QPoint"):
            return {"point":[item.x(),item.y()]}
        raise ValueError(f"状态含不支持的数据 {type(item).__name__}")
    root = visit(value)
    return dict(version=1,root=root,nodes=nodes)


def decode(value,dict_factory=dict):
    if not isinstance(value,dict) or value.get("version") != 1 or not isinstance(value.get("nodes"),list):
        raise ValueError("工作台快照版本不支持")
    nodes = value["nodes"]
    if len(nodes)>100000:
        raise ValueError("工作台快照过大")
    objects = [dict_factory() if node["kind"]=="dict" else set() if node["kind"]=="set" else [] for node in nodes]
    def read(item):
        if not isinstance(item,dict):
            if item is None or type(item) in (str,bool,int,float):
                return item
            raise ValueError("快照值无效")
        if set(item)=={"ref"} and type(item["ref"]) is int and 0<=item["ref"]<len(objects):
            return objects[item["ref"]]
        if set(item)=={"float"} and item["float"] in ("nan","inf","-inf"):
            return float(item["float"])
        if set(item)=={"point"} and isinstance(item["point"],list) and len(item["point"])==2:
            from PySide6.QtCore import QPointF
            return QPointF(*item["point"])
        if set(item)=={"tuple"} and isinstance(item["tuple"],list):
            return tuple(read(v) for v in item["tuple"])
        if set(item)=={"frozenset"} and isinstance(item["frozenset"],list):
            return frozenset(read(v) for v in item["frozenset"])
        raise ValueError("快照引用无效")
    for node,obj in zip(nodes,objects):
        if node["kind"]=="dict":
            for key,data in node["value"]:
                obj[read(key)] = read(data)
        elif node["kind"]=="list":
            obj.extend(read(v) for v in node["value"])
        elif node["kind"]=="set":
            obj.update(read(v) for v in node["value"])
        else:
            raise ValueError("快照容器无效")
    return read(value["root"])
