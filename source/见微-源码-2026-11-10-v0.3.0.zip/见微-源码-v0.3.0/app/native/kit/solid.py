"""立体几何网格：棱柱 / 棱锥 / 台 / 长方体，以及带虚线（被挡住的棱）的绘制。"""
from __future__ import annotations

import math

from ..design.tokens import T, alpha
from .core import TAU
from .draw import D
from .view import v3


def mesh_prism(n, r1, r2, h, rot=0.0, smooth=False):
    """底面半径 r1，顶面半径 r2（0 为棱锥）。"""
    V, F, lat = [], [], set()
    for i in range(n):
        t = rot + TAU * i / n
        V.append([r1 * math.cos(t), -h / 2, r1 * math.sin(t)])
    if r2 > 0:
        for i in range(n):
            t = rot + TAU * i / n
            V.append([r2 * math.cos(t), h / 2, r2 * math.sin(t)])
    else:
        V.append([0, h / 2, 0])
    F.append(list(range(n)))
    if r2 > 0:
        F.append([n + i for i in range(n)])
        for i in range(n):
            lat.add(len(F))
            F.append([i, (i + 1) % n, n + (i + 1) % n, n + i])
    else:
        for i in range(n):
            lat.add(len(F))
            F.append([i, (i + 1) % n, n])
    return {"V": V, "F": F, "lat": lat, "smooth": smooth}


def mesh_box(a, b, c):
    V = [[x * a / 2, y * b / 2, z * c / 2] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
    F = [[0, 1, 3, 2], [4, 5, 7, 6], [0, 1, 5, 4], [2, 3, 7, 6], [0, 2, 6, 4], [1, 3, 7, 5]]
    return {"V": V, "F": F, "lat": set(), "smooth": False}


def edges(M) -> set:
    E = set()
    for f in M["F"]:
        for j, i in enumerate(f):
            k = f[(j + 1) % len(f)]
            E.add((min(i, k), max(i, k)))
    return E


def draw_mesh(c, cam, M, s, col):
    g, Vs = c.g, M["V"]
    P = [cam.proj(p, c, s) for p in Vs]
    cen = [sum(p[i] for p in Vs) / len(Vs) for i in range(3)]
    front = []
    for f in M["F"]:
        n = [0.0, 0.0, 0.0]
        for i in range(len(f)):
            a, b = Vs[f[i]], Vs[f[(i + 1) % len(f)]]
            n = v3.add(n, [(a[1] - b[1]) * (a[2] + b[2]), (a[2] - b[2]) * (a[0] + b[0]), (a[0] - b[0]) * (a[1] + b[1])])
        fc = [sum(Vs[i][k] for i in f) / len(f) for k in range(3)]
        if v3.dot(n, v3.sub(fc, cen)) < 0:
            n = v3.mul(n, -1)
        front.append(cam.rot(n)[2] > 0)
    for i, f in enumerate(M["F"]):
        if front[i]:
            D.poly(g, [P[k][:2] for k in f], alpha(col, 0.07))
    E: dict = {}
    for fi, f in enumerate(M["F"]):
        for i, a in enumerate(f):
            b = f[(i + 1) % len(f)]
            E.setdefault((min(a, b), max(a, b)), []).append(fi)
    for (a, b), fs in E.items():
        nf = sum(1 for i in fs if front[i])
        if M["smooth"] and all(i in M["lat"] for i in fs):
            if nf == 1:
                D.line(g, P[a][0], P[a][1], P[b][0], P[b][1], T.fg, 1.8)
            continue
        if nf > 0:
            D.line(g, P[a][0], P[a][1], P[b][0], P[b][1], T.fg, 1.8)
        else:
            D.line(g, P[a][0], P[a][1], P[b][0], P[b][1], T.muted, 1.2, [5, 4])
    return P
