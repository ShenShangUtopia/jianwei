"""共享画笔模型。坐标/宽度使用画布逻辑单位；旧 pts 格式仅在边界迁移。"""
from __future__ import annotations

import math
import random
import copy
import hashlib
import json
import time
import uuid

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QImage, QPainter, QPainterPath, QPen

MARKER_ALPHA = 0.36
VERSION = 1
__all__ = ["VERSION", "MARKER_ALPHA", "PenDataError", "migrate_stroke", "migrate_strokes", "points_of", "new_stroke", "add_point", "path_of", "chalk_brush", "pen_for", "draw", "bounds", "hit", "History"]


class PenDataError(ValueError):
    """不支持或损坏的笔迹；调用者须保留源存档，不能按空数据覆盖。"""


def _number(value):
    try:
        return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)
    except OverflowError:
        return False


def points_of(s):
    return s["points"] if "points" in s else s["pts"]


def migrate_stroke(source) -> dict:
    """返回独立的 v1 副本，不截断坐标/压力，不丢未知扩展字段。"""
    if not isinstance(source, dict):
        raise PenDataError("笔画不是对象")
    version = source.get("v", 0)
    if type(version) is not int or version not in (0, VERSION):
        raise PenDataError(f"不支持的笔画版本 {version}，请使用新版见微打开")
    pts = source.get("points", source.get("pts"))
    if "points" in source and "pts" in source and source["points"] != source["pts"]:
        raise PenDataError("笔画包含互不一致的两份点列")
    if not isinstance(pts, list):
        raise PenDataError("笔画点列缺失")
    for point in pts:
        if not isinstance(point, (list, tuple)) or len(point) != 3 or not all(_number(v) for v in point):
            raise PenDataError("笔画坐标或压力无效")
    if not _number(source.get("width")) or source["width"] <= 0:
        raise PenDataError("笔画宽度无效")
    if source.get("tool") not in ("pen", "marker", "chalk"):
        raise PenDataError("不支持的画笔工具")
    if not isinstance(source.get("color"), str) or not QColor(source["color"]).isValid():
        raise PenDataError("笔画颜色无效")
    timestamp = source.get("t")
    if timestamp is not None and not _number(timestamp):
        raise PenDataError("笔画时间无效")
    if "pressure" in source and not isinstance(source["pressure"], bool):
        raise PenDataError("笔画压感开关无效")
    if "id" in source and (not isinstance(source["id"], str) or not source["id"]):
        raise PenDataError("笔画标识无效")
    s = copy.deepcopy(source)
    s.pop("pts", None)
    s.update(v=VERSION, points=[list(p) for p in pts], pressure=source.get("pressure", False), t=timestamp)
    if "id" not in s:
        raw = json.dumps(source, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")
        s["id"] = "legacy-" + hashlib.sha256(raw).hexdigest()[:24]
    return s


def migrate_strokes(strokes):
    if not isinstance(strokes, list):
        raise PenDataError("笔迹列表无效")
    result, used = [], set()
    for source in strokes:
        stroke = migrate_stroke(source)
        if "id" not in source:
            base, count = stroke["id"], 1
            while stroke["id"] in used:
                count += 1
                stroke["id"] = f"{base}-{count}"
        used.add(stroke["id"])
        result.append(stroke)
    return result


def new_stroke(tool, color, width, pressure=False) -> dict:
    return migrate_stroke(dict(v=VERSION, id=uuid.uuid4().hex, tool=tool, color=color,
                               width=round(float(width), 3), points=[], pressure=bool(pressure), t=time.time()))


def add_point(s, x, y, pr=1.0, min_dist=0.0) -> bool:
    """加一个点；离上一点太近就跳过。返回是否真的加了。"""
    pts = points_of(s)
    if not all(_number(v) for v in (x, y, pr)):
        return False
    if pts and min_dist and math.hypot(x - pts[-1][0], y - pts[-1][1]) < min_dist:
        return False
    pts.append([round(x, 2), round(y, 2), round(pr, 2)])
    return True


def path_of(pts) -> QPainterPath:
    """过各点中点的二次曲线：手写抖动被抹平，折线也不会有棱角。"""
    path = QPainterPath()
    if not pts:
        return path
    path.moveTo(pts[0][0], pts[0][1])
    if len(pts) == 1:
        path.lineTo(pts[0][0] + 0.01, pts[0][1])
        return path
    for i in range(1, len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        path.quadTo(a[0], a[1], (a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    path.lineTo(pts[-1][0], pts[-1][1])
    return path


_chalk = {}


def chalk_brush(color: str) -> QBrush:
    """粉笔的颗粒感：带随机透明度的小纹理当画笔。"""
    if color not in _chalk:
        c = QColor(color)
        rnd = random.Random(7)
        im = QImage(96, 96, QImage.Format.Format_ARGB32_Premultiplied)
        im.fill(Qt.GlobalColor.transparent)
        for y in range(96):
            for x in range(96):
                a = 0 if rnd.random() < 0.07 else rnd.randint(165, 255)
                q = QColor(c)
                q.setAlpha(a)
                im.setPixelColor(x, y, q)
        _chalk[color] = QBrush(im)
    return _chalk[color]


def pen_for(s, width=None) -> QPen:
    w = s["width"] if width is None else width
    if s["tool"] == "chalk":
        pen = QPen(chalk_brush(s["color"]), w)
    elif s["tool"] == "marker":
        c = QColor(s["color"])
        c.setAlphaF(MARKER_ALPHA)
        pen = QPen(c, w)
    else:
        pen = QPen(QColor(s["color"]), w)
    pen.setCapStyle(Qt.PenCapStyle.FlatCap if s["tool"] == "marker" else Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    return pen


def draw(p: QPainter, s) -> None:
    """p 已经变换到页面坐标。"""
    p.save()
    try:
        if s["tool"] == "marker":
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
        _draw(p,s)
    finally:
        p.restore()


def _draw(p, s):
    pts = points_of(s)
    if not pts:
        return
    p.setBrush(Qt.BrushStyle.NoBrush)
    if s.get("shape"):
        p.setPen(pen_for(s))
        path = QPainterPath(QPointF(*pts[0][:2]))
        for point in pts[1:]:
            path.lineTo(QPointF(*point[:2]))
        p.drawPath(path)
        return
    if s.get("pressure") and s["tool"] in ("pen", "chalk") and len(pts) > 1:
        for index, (a, b) in enumerate(zip(pts, pts[1:])):
            p.setPen(pen_for(s, s["width"] * (0.35 + 1.1 * (a[2] + b[2]) / 2)))
            start = a[:2] if index == 0 else [(pts[index-1][j]+a[j])/2 for j in range(2)]
            end = b[:2] if index == len(pts)-2 else [(a[j]+b[j])/2 for j in range(2)]
            path = QPainterPath(QPointF(*start))
            path.quadTo(QPointF(*a[:2]),QPointF(*end))
            p.drawPath(path)
        return
    p.setPen(pen_for(s))
    p.drawPath(path_of(pts))


def bounds(s) -> QRectF:
    pts = points_of(s)
    if not pts:
        return QRectF()
    xs, ys = [q[0] for q in pts], [q[1] for q in pts]
    m = s["width"] * 1.6 + 1
    return QRectF(min(xs) - m, min(ys) - m, max(xs) - min(xs) + 2 * m, max(ys) - min(ys) + 2 * m)


def _dist(px, py, a, b) -> float:
    dx, dy = b[0] - a[0], b[1] - a[1]
    d2 = dx * dx + dy * dy
    t = 0.0 if d2 == 0 else max(0.0, min(1.0, ((px - a[0]) * dx + (py - a[1]) * dy) / d2))
    return math.hypot(px - (a[0] + t * dx), py - (a[1] + t * dy))


def hit(s, x, y, r) -> bool:
    pts = points_of(s)
    reach = r + s["width"] / 2
    if len(pts) == 1:
        return math.hypot(x - pts[0][0], y - pts[0][1]) <= reach
    return any(_dist(x, y, a, b) <= reach for a, b in zip(pts, pts[1:]))


class History:
    """一页的笔迹和撤销栈：记录「加了哪一笔 / 擦了哪些」。"""

    def __init__(self, strokes=None):
        self.strokes = migrate_strokes(strokes if strokes is not None else [])
        self.undo_stack, self.redo_stack = [], []
        self.version = 0

    def _bump(self):
        self.version += 1

    def add(self, s):
        self.strokes.append(s)
        self.undo_stack.append(("add", [s], None))
        self.redo_stack.clear()
        self._bump()

    def remove(self, items):
        if not items:
            return
        before = list(self.strokes)
        self.strokes = [s for s in self.strokes if not any(s is r for r in items)]
        self.undo_stack.append(("set", before, None))
        self.redo_stack.clear()
        self._bump()

    def clear(self):
        if self.strokes:
            self.remove(list(self.strokes))

    def replace(self, strokes, before=None):
        old = list(self.strokes if before is None else before)
        if old == strokes:
            return False
        self.strokes = list(strokes)
        self.undo_stack.append(("set", old, None))
        self.redo_stack.clear()
        self._bump()
        return True

    def undo(self) -> bool:
        if not self.undo_stack:
            return False
        kind, data, _ = self.undo_stack.pop()
        if kind == "add":
            self.strokes = [s for s in self.strokes if not any(s is r for r in data)]
            self.redo_stack.append(("add", data, None))
        else:
            self.redo_stack.append(("set", list(self.strokes), None))
            self.strokes = list(data)
        self._bump()
        return True

    def redo(self) -> bool:
        if not self.redo_stack:
            return False
        kind, data, _ = self.redo_stack.pop()
        if kind == "add":
            self.strokes.extend(data)
            self.undo_stack.append(("add", data, None))
        else:
            self.undo_stack.append(("set", list(self.strokes), None))
            self.strokes = list(data)
        self._bump()
        return True
