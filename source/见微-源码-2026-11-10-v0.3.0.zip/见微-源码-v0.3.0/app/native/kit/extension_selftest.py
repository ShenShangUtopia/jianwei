"""2.6 新工作台、几何构造、场景解析模型和素材偏好。"""
import math
import sys
from pathlib import Path
from . import test_runtime

test_runtime.configure()


def main(output=None):
    app=test_runtime.application()
    from ..lab.studio import Studio
    from ..lab.benches.bio_model import calculate,NAMES
    from ..lab.benches.geo_construct import resolve
    from ..lab.benches.geo_core import GeoCore
    from ..lab.benches.scene import spawn
    from ..lab.benches.scene_core import TYPES,NS,E
    from ..lab.benches.scene_types3 import SPECS,measurements
    from .home import load_json,save_json
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    assert resolve("midpoint",[(0,0),(4,2)])==(2,1)
    perp=resolve("perpendicular",[(0,0),(4,2),(1,1)])
    assert abs((perp[0]-1)*4+(perp[1]-1)*2)<1e-9
    touch=resolve("tangent",[(0,0),(1,0),(2,0)])
    assert abs(math.hypot(*touch)-1)<1e-9
    assert abs((touch[0]-2)*touch[0]+touch[1]**2)<1e-9
    core=GeoCore()
    a=core.create_point(0,0)
    b=core.create_point(4,2)
    mid=core.create_point(2,1)
    mid["construction"]=dict(mode="midpoint",parents=[a["id"],b["id"]])
    assert core.cur_of_point(mid)==(2,1)
    b["x"]=8
    assert core.cur_of_point(mid)==(4,1)
    saved=core.snapshot()
    core.restore_snapshot(saved)
    assert core.cur_of_id(mid["id"])==(4,1)
    assert calculate("cross",dict(father="Aa",mother="Aa"))["values"]==[.25,.5,.25]
    assert float(calculate("photosynthesis",dict(light=0))["rows"][2][1])<0
    assert float(calculate("enzyme",dict(temperature=37,pH=7))["rows"][0][1])==1
    studio=Studio("day")
    studio.resize(1500,900)
    studio.show()
    studio.open_bench("bio")
    app.processEvents()
    B=studio.B
    for i,kind in enumerate(NAMES):
        initial=B.transfer_snapshot()
        B.pal.items["bio-"+kind].it["drop"](500,300)
        state=B.transfer_snapshot()
        assert len(state["objects"])==len(initial["objects"])+1
        chosen=state["objects"][-1]
        assert calculate(kind,chosen["p"])["rows"]
        B.transfer_restore(state)
        studio.ctx.stage.repaint()
        assert not studio.ctx.stage.error,kind
        B.transfer_restore(initial)
    B.pal.items["bio-population"].it["click"]()
    studio.grab().save(str(out/"bio-workbench.png"))
    save_json("workbench-ui.json",{**load_json("workbench-ui.json",{}),"keep_custom":"preserve"})
    item=B.pal.items["bio-population"].it
    B.pal.remember(item)
    B.pal.toggle_favorite(item)
    assert B.pal.is_favorite(item) and B.pal.recent()[0]=="bio-population"
    studio.chrome._save()
    assert load_json("workbench-ui.json",{})["keep_custom"]=="preserve"
    assert load_json("workbench-ui.json",{})["materials"]["bio"]["favorites"]==["bio-population"]
    studio.open_bench("scene")
    for kind,_name,_group,params in SPECS:
        E.S.objects=[]
        obj=spawn(kind,1,1)
        assert obj is not None and TYPES[kind].read(obj)
        before=measurements(kind,obj.p)
        param=params[0]
        obj.p[param[0]]=param[4]
        after=measurements(kind,obj.p)
        assert before!=after,(kind,before,after)
        studio.ctx.stage.repaint()
        assert not studio.ctx.stage.error,kind
    # Paired known limits anchor numeric correctness.
    assert abs(float(measurements("gas_piston",NS(n=1,T=0,V=22.414))[0][1])-101.325)<.1
    assert abs(float(measurements("doubleslit",NS(lam=500,L=2,d=.5))[0][1])-2)<1e-6
    studio.grab().save(str(out/"scene-models.png"))
    studio.go_home()
    studio.close()
    print("EXTENSIONS OK bio10, geometry6, scene8, preferences preserved",flush=True)
    return 0


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
