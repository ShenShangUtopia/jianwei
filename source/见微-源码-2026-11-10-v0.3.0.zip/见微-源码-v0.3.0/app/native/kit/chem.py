"""化学基础数据与算法（由 gewu/chem.js 开头部分改写）：元素表、电子排布、化学式解析、方程式配平。

实验、化学工作台和题目分析都用这里的实现，保证同一个化学式在各处算出同一个结果。
"""
from __future__ import annotations

import re
from fractions import Fraction
from math import gcd

_SYM = ("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag "
        "Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np "
        "Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og").split()
_NAME = list("氢氦锂铍硼碳氮氧氟氖钠镁铝硅磷硫氯氩钾钙钪钛钒铬锰铁钴镍铜锌镓锗砷硒溴氪铷锶钇锆铌钼锝钌铑钯银镉铟锡锑碲碘氙铯钡镧铈镨钕钷钐铕钆铽镝钬铒铥镱镥"
             "铪钽钨铼锇铱铂金汞铊铅铋钋砹氡钫镭锕钍镤铀镎钚镅锔锫锎锿镄钔锘铹𬬻𬭊𬭳𬭛𬭶鿏𫟼𬬭鿔鿭𫓧镆𫟷鿬鿫")
_MASS = [1.008, 4.003, 6.941, 9.012, 10.81, 12.01, 14.01, 16.00, 19.00, 20.18, 22.99, 24.31, 26.98, 28.09, 30.97, 32.06, 35.45, 39.95, 39.10,
         40.08, 44.96, 47.87, 50.94, 52.00, 54.94, 55.85, 58.93, 58.69, 63.55, 65.38, 69.72, 72.63, 74.92, 78.97, 79.90, 83.80, 85.47, 87.62, 88.91,
         91.22, 92.91, 95.95, 98, 101.1, 102.9, 106.4, 107.9, 112.4, 114.8, 118.7, 121.8, 127.6, 126.9, 131.3, 132.9, 137.3, 138.9, 140.1, 140.9,
         144.2, 145, 150.4, 152.0, 157.3, 158.9, 162.5, 164.9, 167.3, 168.9, 173.0, 175.0, 178.5, 180.9, 183.8, 186.2, 190.2, 192.2, 195.1, 197.0,
         200.6, 204.4, 207.2, 209.0, 209, 210, 222, 223, 226, 227, 232.0, 231.0, 238.0, 237, 244, 243, 247, 247, 251, 252, 257, 258, 259, 262, 267,
         268, 269, 270, 277, 278, 281, 282, 285, 286, 289, 290, 293, 294, 294]
_EN = ("2.20,,0.98,1.57,2.04,2.55,3.04,3.44,3.98,,0.93,1.31,1.61,1.90,2.19,2.58,3.16,,0.82,1.00,1.36,1.54,1.63,1.66,1.55,1.83,1.88,1.91,1.90,1.65,"
       "1.81,2.01,2.18,2.55,2.96,3.00,0.82,0.95,1.22,1.33,1.6,2.16,1.9,2.2,2.28,2.20,1.93,1.69,1.78,1.96,2.05,2.1,2.66,2.6,0.79,0.89,1.10,1.12,1.13,"
       "1.14,,1.17,,1.20,,1.22,1.23,1.24,1.25,,1.27,1.3,1.5,2.36,1.9,2.2,2.20,2.28,2.54,2.00,1.62,2.33,2.02,2.0,2.2,,0.7,0.9,1.1,1.3,1.5,1.38,1.36,"
       "1.28,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3").split(",")
_IE = [1312, 2372, 520, 900, 801, 1086, 1402, 1314, 1681, 2081, 496, 738, 578, 787, 1012, 1000, 1251, 1521, 419, 590, 633, 659, 651, 653, 717, 762,
       760, 737, 746, 906, 579, 762, 947, 941, 1140, 1351, 403, 550, 600, 640, 652, 684, 702, 710, 720, 804, 731, 868, 558, 709, 834, 869, 1008, 1170,
       376, 503]


class Element(dict):
    def __getattr__(self, k):
        return self[k]


EL = [Element(z=i + 1, s=s, n=_NAME[i], m=_MASS[i], en=float(_EN[i]) if i < len(_EN) and _EN[i] else None, ie=_IE[i] if i < len(_IE) else None)
      for i, s in enumerate(_SYM)]
BY = {e.s: e for e in EL}


def el_cat(z: int) -> str:
    if z in (2, 10, 18, 36, 54, 86, 118):
        return "noble"
    if z in (9, 17, 35, 53, 85, 117):
        return "halogen"
    if z in (3, 11, 19, 37, 55, 87):
        return "alkali"
    if z in (4, 12, 20, 38, 56, 88):
        return "alkaline"
    if 57 <= z <= 71:
        return "lan"
    if 89 <= z <= 103:
        return "act"
    if z in (5, 14, 32, 33, 51, 52):
        return "metalloid"
    if z in (1, 6, 7, 8, 15, 16, 34):
        return "nonmetal"
    if z in (13, 31, 49, 50, 81, 82, 83, 84, 113, 114, 115, 116):
        return "post"
    return "trans"


CAT = {"alkali": ("碱金属", "c2"), "alkaline": ("碱土金属", "c4"), "trans": ("过渡金属", "c1"), "post": ("其他金属", "c5"), "metalloid": ("类金属", "c3"),
       "nonmetal": ("非金属", "c3"), "halogen": ("卤素", "c6"), "noble": ("稀有气体", "c5"), "lan": ("镧系", "c4"), "act": ("锕系", "c2")}
GROUPS = ["ⅠA", "ⅡA", "ⅢB", "ⅣB", "ⅤB", "ⅥB", "ⅦB", "Ⅷ", "Ⅷ", "Ⅷ", "ⅠB", "ⅡB", "ⅢA", "ⅣA", "ⅤA", "ⅥA", "ⅦA", "0"]


def el_pos(z: int) -> tuple[int, int]:
    """(行, 列)，行 0..6 为周期 1..7，行 8、9 为镧系、锕系。"""
    if z == 1:
        return 0, 0
    if z == 2:
        return 0, 17
    if z <= 18:
        p = 1 if z <= 10 else 2
        i = z - (2 if p == 1 else 10)
        return p, (i - 1 if i <= 2 else i + 9)
    if z <= 54:
        p = 3 if z <= 36 else 4
        return p, z - (18 if p == 3 else 36) - 1
    p = 5 if z <= 86 else 6
    i = z - (54 if p == 5 else 86)
    if i <= 2:
        return p, i - 1
    if i <= 17:
        return (8 if p == 5 else 9), i - 1
    return p, i - 15


def block_of(z: int) -> str:
    if 57 <= z <= 71 or 89 <= z <= 103:
        return "f"
    col = el_pos(z)[1]
    return "s" if col <= 1 or z == 2 else "p" if col >= 12 else "d"


SUBSH = [(s - l, l) for s in range(1, 9) for l in range(min(3, s - 1), -1, -1) if s - l > l and s - l <= 7 and s <= 8]
EXC = {24: [("4s", -1), ("3d", 1)], 29: [("4s", -1), ("3d", 1)], 41: [("5s", -1), ("4d", 1)], 42: [("5s", -1), ("4d", 1)], 44: [("5s", -1), ("4d", 1)],
       45: [("5s", -1), ("4d", 1)], 46: [("5s", -2), ("4d", 2)], 47: [("5s", -1), ("4d", 1)], 57: [("4f", -1), ("5d", 1)], 58: [("4f", -1), ("5d", 1)],
       64: [("4f", -1), ("5d", 1)], 78: [("6s", -1), ("5d", 1)], 79: [("6s", -1), ("5d", 1)], 89: [("5f", -1), ("6d", 1)], 90: [("5f", -2), ("6d", 2)],
       91: [("5f", -1), ("6d", 1)], 92: [("5f", -1), ("6d", 1)], 93: [("5f", -1), ("6d", 1)], 96: [("5f", -1), ("6d", 1)]}


def el_config(z: int) -> list[tuple[str, int]]:
    """电子排布：按构造原理填充，再按 EXC 修正（Cr、Cu 等）；按能层、能级排序。"""
    Ls, cfg, left = "spdf", {}, z
    for n, l in SUBSH:
        if left <= 0:
            break
        k = min(left, 2 * (2 * l + 1))
        cfg[f"{n}{Ls[l]}"] = k
        left -= k
    for k, d in EXC.get(z, []):
        cfg[k] = cfg.get(k, 0) + d
        if not cfg[k]:
            del cfg[k]
    return sorted(cfg.items(), key=lambda kv: (int(kv[0][0]), Ls.index(kv[0][1])))


_SUPN = str.maketrans("0123456789+-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻")
_SUBN = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")


def supn(n) -> str:
    return str(n).translate(_SUPN)


def subn(n) -> str:
    return str(n).translate(_SUBN)


# ---------------------------------------------------------------- 化学式
class FormulaError(ValueError):
    pass


def parse_formula(s: str) -> dict:
    """'Fe2(SO4)3'、'CuSO4·5H2O'、'Fe^3+'、'SO4^2-'、'e-' → {'el': {元素: 个数}, 'charge': 电荷}。"""
    s = s.strip()
    if s in ("e", "e-", "e^-"):
        return {"el": {}, "charge": -1}
    charge = 0
    cm = re.search(r"\^?\(?(\d*)([+-])\)?$", s)
    if cm and "^" in s:
        charge = (1 if cm.group(2) == "+" else -1) * (int(cm.group(1)) if cm.group(1) else 1)
        s = s[:cm.start()]
    s = s.rstrip("^")
    total: dict = {}
    for part in re.split(r"[·.*]", s):
        p, mult = part, 1
        lead = re.match(r"^(\d+)", p)
        if lead:
            mult = int(lead.group(1))
            p = p[len(lead.group(1)):]
        pos = 0

        def num():
            nonlocal pos
            t = ""
            while pos < len(p) and p[pos].isdigit():
                t += p[pos]
                pos += 1
            return int(t) if t else 1

        def group():
            nonlocal pos
            r: dict = {}
            while pos < len(p):
                ch = p[pos]
                if ch in "([":
                    pos += 1
                    inner = group()
                    if pos >= len(p) or p[pos] not in ")]":
                        raise FormulaError("括号不匹配：" + part)
                    pos += 1
                    n = num()
                    for k, v in inner.items():
                        r[k] = r.get(k, 0) + v * n
                elif ch in ")]":
                    return r
                elif ch.isupper():
                    sy = ch
                    pos += 1
                    while pos < len(p) and p[pos].islower():
                        sy += p[pos]
                        pos += 1
                    if sy not in BY:
                        raise FormulaError("未知元素：" + sy)
                    n = num()
                    r[sy] = r.get(sy, 0) + n
                else:
                    raise FormulaError(f"无法识别「{ch}」")
            return r
        r = group()
        if pos < len(p):
            raise FormulaError("括号不匹配：" + part)
        for k, v in r.items():
            total[k] = total.get(k, 0) + v * mult
    return {"el": total, "charge": charge}


def molar_mass(el: dict) -> float:
    return sum(BY[k].m * v for k, v in el.items())


def pretty(s: str, html: bool = False) -> str:
    """化学式排版：下标数字、电荷上标、结晶水点。html=True 用 <sub>/<sup>（富文本），否则用 Unicode 上下标（画布）。"""
    s = s.strip()
    if re.fullmatch(r"e\^?-?", s):
        return "e⁻"
    charge = ""
    cm = re.search(r"\^\(?(\d*)([+-])\)?$", s)
    if cm:
        charge = (cm.group(1) or "") + cm.group(2)
        s = s[:cm.start()]
    if html:
        body = re.sub(r"([A-Za-z)\]])(\d+)", lambda m: m.group(1) + f"<sub>{m.group(2)}</sub>", s)
        return re.sub(r"[.*]", "·", body) + (f"<sup>{charge.replace('-', '−')}</sup>" if charge else "")
    body = re.sub(r"([A-Za-z)\]])(\d+)", lambda m: m.group(1) + subn(m.group(2)), s)
    return re.sub(r"[.*]", "·", body) + (supn(charge) if charge else "")


def balance(lhs: list[str], rhs: list[str]) -> dict:
    """有理数高斯消元配平（含离子电荷守恒）。返回 {'coef': [...], 'sp': [...], 'keys': [...]}。"""
    sp = [parse_formula(x) for x in lhs + rhs]
    keys = list(dict.fromkeys(k for s in sp for k in s["el"]))
    if any(s["charge"] for s in sp):
        keys.append("电荷")
    nl = len(lhs)
    M = [[Fraction((s["charge"] if k == "电荷" else s["el"].get(k, 0)) * (1 if j < nl else -1)) for j, s in enumerate(sp)] for k in keys]
    n = len(sp)
    piv, r = [], 0
    for col in range(n):
        if r >= len(M):
            break
        k = next((i for i in range(r, len(M)) if M[i][col] != 0), -1)
        if k < 0:
            continue
        M[r], M[k] = M[k], M[r]
        pv = M[r][col]
        M[r] = [x / pv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][col] != 0:
                f = M[i][col]
                M[i] = [x - f * M[r][j] for j, x in enumerate(M[i])]
        piv.append(col)
        r += 1
    free = [j for j in range(n) if j not in piv]
    if not free:
        raise FormulaError("无法配平：请检查化学式是否正确")
    if len(free) > 1:
        raise FormulaError("配平结果不唯一（可能是几个反应的组合），请检查")
    f = free[0]
    x = [Fraction(0)] * n
    x[f] = Fraction(1)
    for i, col in enumerate(piv):
        x[col] = -M[i][f]
    lcm = 1
    for q in x:
        lcm = lcm * q.denominator // gcd(lcm, q.denominator)
    ints = [int(q * lcm) for q in x]
    g0 = 0
    for v in ints:
        g0 = gcd(g0, abs(v))
    ints = [v // (g0 or 1) for v in ints]
    if any(v < 0 for v in ints):
        ints = [-v for v in ints]
    if any(v <= 0 for v in ints):
        raise FormulaError("无法得到全为正的系数，请检查反应物与生成物")
    return {"coef": ints, "sp": sp, "keys": keys}


def solve_ph(f) -> float:
    """电荷守恒式 f(c(H⁺)) = 0 的对数二分：f 随 c(H⁺) 单调增。返回 pH。"""
    lo, hi = -15.0, 1.0
    for _ in range(80):
        m = (lo + hi) / 2
        if f(10 ** m) > 0:
            hi = m
        else:
            lo = m
    return -(lo + hi) / 2
