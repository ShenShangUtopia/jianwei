"""将已经校验的析题数据映射到匹配工作台；不凭空填补未知参数。"""
from __future__ import annotations

import math


def destination(lesson):
    for task in lesson.get("taskRes") or []:
        if (task.get("viz") or {}).get("scene",{}).get("kind")=="circuit":
            return "circ"
        if (task.get("viz") or {}).get("scene"):
            return "scene"
    return {"数学":"draw","物理":"scene","化学":"chem","生物":"bio"}.get(lesson.get("subject"))


def apply(studio,lesson):
    B = studio.B
    bid = studio.cur_bench.id
    tasks = lesson.get("taskRes") or []
    if bid=="bio":
        for task in tasks:
            if task.get("kind")=="cross":
                spec=lesson.get("task",{})
                spec=next((s for s in spec if s.get("kind")=="cross"),{}) if isinstance(spec,list) else spec
                parents=spec.get("parents",[])
                if len(parents)==2 and all(p in ("AA","Aa","aa") for p in parents):
                    B.pal.items["bio-cross"].it["click"]()
                    snapshot=B.transfer_snapshot()
                    snapshot["objects"][-1]["p"].update(father=parents[0],mother=parents[1])
                    B.transfer_restore(snapshot)
                    return "单基因亲本已载入生物工作台；其余复杂遗传题保留原图解"
        return "题目已作为参考带入生物工作台；当前模型未覆盖该题全部条件，未自动填入参数"
    if bid == "draw":
        model = B.transfer_model
        task = next((t for t in tasks if t["kind"]=="func"),None)
        if task:
            model.objects,model.selection,model.preset = [],[],""
            model.add_function(task["viz"]["f"])
            model.refresh_all()
            model.fit_view()
            model.schedule_save()
            return "函数表达式已载入可编辑图形"
    scene = next(((t.get("viz") or {}).get("scene") for t in tasks if (t.get("viz") or {}).get("scene")),None)
    if bid=="circ" and scene and scene["kind"]=="circuit":
        params = scene["params"]
        source = lesson.get("task") or {}
        if isinstance(source,list):
            source = next((t for t in source if t.get("kind")=="circuit"),{})
        E,r,R1,R2 = (float(source.get(k,params.get(k,default))) for k,default in (("E",3),("r",.5),("R1",10),("R2",10)))
        R3 = float(source.get("R3",0))
        wire = lambda a,b,c,d:["wire",a,b,c,d]
        if source.get("mode")=="parallel":
            rows = [["bat",2,8,2,2,dict(E=E,r=r)],["res",2,2,5,2,dict(R=R3)] if R3 else wire(2,2,5,2),["res",5,2,5,8,dict(R=R1)],
                    wire(5,8,2,8),wire(5,2,10,2),["res",10,2,10,8,dict(R=R2)],wire(10,8,5,8)]
        else:
            rows = [["bat",2,8,2,2,dict(E=E,r=r)],["res",2,2,6,2,dict(R=R1)],
                    ["res",6,2,10,2,dict(R=R2)],["res",10,2,10,8,dict(R=R3)] if R3 else wire(10,2,10,8),wire(10,8,2,8)]
        B.transfer_problem(rows)
        return "电源、内阻和电阻参数已载入电路"
    if bid=="scene" and scene:
        from ..lab.benches.scene import reinit
        from ..lab.benches.scene_core import E
        kind,params = scene["kind"],scene.get("params",{})
        preset = dict(projectile="projectile",incline="incline",collision="collision",lens="lens").get(kind)
        if preset:
            B.transfer_model.load_preset(preset,False)
            E.S.g = params.get("g",9.8)
            if kind=="projectile":
                obj = next(o for o in E.S.objects if o.type=="projectile")
                obj.x,obj.y = 0,params.get("h0",0)
                obj.p.v0,obj.p.th = params.get("v0",0),params.get("angle",0)
                vy = obj.p.v0*math.sin(math.radians(obj.p.th))
                duration = (vy+math.sqrt(vy*vy+2*E.S.g*max(0,obj.y)))/E.S.g
                distance = max(2,abs(obj.p.v0*math.cos(math.radians(obj.p.th))*duration))
                height = max(2,obj.y+max(0,vy)**2/(2*E.S.g))
                E.cam.update(x=distance/2,y=height/2,scale=min((B.stage.width()-60)/distance,(B.stage.height()-60)/height))
            elif kind=="incline":
                obj = next(o for o in E.S.objects if o.type=="incline")
                for key,source in (("th","angle"),("mu","mu"),("m","m"),("L","L")):
                    if source in params:
                        obj.p[key]=params[source]
            elif kind=="collision":
                obj = next(o for o in E.S.objects if o.type=="collision")
                obj.p.update(params)
                spec = lesson.get("task") or {}
                if isinstance(spec,list):
                    spec = next((s for s in spec if s.get("kind")=="collision"),{})
                obj.p.e=spec.get("e",1)
            else:
                obj = next(o for o in E.S.objects if o.type=="convex")
                obj.p.f=params.get("f",obj.p.f)
                light = next(o for o in E.S.objects if o.type=="lightsrc")
                light.x=obj.x-params.get("u",1)
                light.p.h=params.get("h",.5)
            for obj in E.S.objects:
                reinit(obj)
            B.transfer_model.refresh_all()
            B.L.draw()
            return "已将程序题型参数载入场景，当前暂停供检查"
    return "题目与讲解已带入；当前题型未自动匹配器材，保留为参考材料"
