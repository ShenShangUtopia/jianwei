"""画笔几何操作：规整形状、吸附、矢量变换与局部擦除。"""
from __future__ import annotations

import copy
import math
import uuid

from PySide6.QtCore import QPointF, QRectF
from PySide6.QtGui import QPainterPath, QPainterPathStroker

from . import pen

SHAPES = ("line", "rect", "ellipse", "arrow", "axes")


def shape(kind, a, b, color, width):
    s = pen.new_stroke("pen", color, width)
    x, y, xx, yy = a.x(), a.y(), b.x(), b.y()
    if kind == "ellipse":
        pts = [[(x+xx)/2 + abs(xx-x)/2*math.cos(i*math.tau/96),
                (y+yy)/2 + abs(yy-y)/2*math.sin(i*math.tau/96), 1] for i in range(97)]
    elif kind == "rect":
        pts = [[x,y,1],[xx,y,1],[xx,yy,1],[x,yy,1],[x,y,1]]
    elif kind == "arrow":
        d = math.atan2(yy-y, xx-x)
        head = min(math.hypot(xx-x, yy-y)*.3, max(width*4, 12))
        pts = [[x,y,1],[xx,yy,1],
               [xx-head*math.cos(d-.5), yy-head*math.sin(d-.5),1], [xx,yy,1],
               [xx-head*math.cos(d+.5), yy-head*math.sin(d+.5),1]]
    elif kind == "axes":
        cx, cy = (x+xx)/2, (y+yy)/2
        # 用原点连接各段；所有连线都在坐标轴上。
        pts = [[x,cy,1],[xx,cy,1],[cx,cy,1],[cx,y,1],[cx,yy,1]]
    else:
        pts = [[x,y,1],[xx,yy,1]]
    s.update(points=pts, shape={"kind": kind})
    return s


def snap(stroke):
    pts = pen.points_of(stroke)
    if len(pts) < 5:
        return None
    a, b = QPointF(*pts[0][:2]), QPointF(*pts[-1][:2])
    length = sum(math.hypot(q[0]-p[0], q[1]-p[1]) for p,q in zip(pts, pts[1:]))
    span = math.hypot(b.x()-a.x(), b.y()-a.y())
    if span > stroke["width"]*5 and length < span*1.08:
        if abs(b.x()-a.x()) < span*.08:
            b.setX(a.x())
        elif abs(b.y()-a.y()) < span*.08:
            b.setY(a.y())
        result = shape("line", a, b, stroke["color"], stroke["width"])
    else:
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        r = QRectF(min(xs), min(ys), max(xs)-min(xs), max(ys)-min(ys))
        if min(r.width(), r.height()) < stroke["width"]*5 or span > max(r.width(),r.height())*.2:
            return None
        edge = sum(min(abs(p[0]-r.left()),abs(p[0]-r.right()),abs(p[1]-r.top()),abs(p[1]-r.bottom()))
                   for p in pts)/len(pts)
        ellipse_error = sum(abs(((p[0]-r.center().x())/(r.width()/2))**2 +
                                ((p[1]-r.center().y())/(r.height()/2))**2 - 1) for p in pts)/len(pts)
        if edge < min(r.width(),r.height())*.06:
            kind = "rect"
        elif ellipse_error < .22:
            kind = "ellipse"
        else:
            return None
        result = shape(kind, r.topLeft(), r.bottomRight(), stroke["color"], stroke["width"])
    result["id"], result["t"] = stroke["id"], stroke["t"]
    return result


def transform(strokes, dx=0, dy=0, scale=1, anchor=None, duplicate=False):
    anchor = anchor or QPointF()
    result = copy.deepcopy(strokes)
    for s in result:
        s["points"] = [[anchor.x()+(p[0]-anchor.x())*scale+dx,
                        anchor.y()+(p[1]-anchor.y())*scale+dy, p[2]] for p in pen.points_of(s)]
        s.pop("pts", None)
        s["width"] *= abs(scale)
        if duplicate:
            s["id"] = uuid.uuid4().hex
    return result


def selected(strokes, polygon):
    if len(polygon) < 3:
        return []
    region = QPainterPath(polygon[0])
    for p in polygon[1:]:
        region.lineTo(p)
    region.closeSubpath()
    result = []
    for s in strokes:
        pts = pen.points_of(s)
        if not pts:
            continue
        path = QPainterPath(QPointF(*pts[0][:2]))
        for p in pts[1:]:
            path.lineTo(QPointF(*p[:2]))
        brush = QPainterPathStroker()
        brush.setWidth(max(s["width"], .1))
        if region.contains(QPointF(*pts[0][:2])) or region.intersects(brush.createStroke(path)):
            result.append(s["id"])
    return result


def erase(strokes, center, radius):
    """从线段精确裁去圆形橡皮覆盖部分，保留可编辑的剩余笔画与压力。"""
    result = []
    for s in strokes:
        if not pen.hit(s, center.x(), center.y(), radius):
            result.append(s)
            continue
        pts, chunks, chunk = pen.points_of(s), [], []
        reach = radius+s["width"]/2
        for a,b in zip(pts, pts[1:]):
            dx,dy = b[0]-a[0],b[1]-a[1]
            ax,ay = a[0]-center.x(),a[1]-center.y()
            aa = dx*dx+dy*dy
            bb = 2*(ax*dx+ay*dy)
            cc = ax*ax+ay*ay-reach*reach
            cuts = [0.,1.]
            disc = bb*bb-4*aa*cc
            if aa > 1e-20 and disc > 0:
                cuts += [t for t in ((-bb-math.sqrt(disc))/(2*aa),(-bb+math.sqrt(disc))/(2*aa)) if 0<t<1]
            cuts.sort()
            for lo,hi in zip(cuts,cuts[1:]):
                mid = (lo+hi)/2
                if (ax+mid*dx)**2+(ay+mid*dy)**2 >= reach*reach:
                    start = [a[i]+(b[i]-a[i])*lo for i in range(3)]
                    end = [a[i]+(b[i]-a[i])*hi for i in range(3)]
                    if not chunk:
                        chunk.append(start)
                    chunk.append(end)
                elif chunk:
                    chunks.append(chunk)
                    chunk = []
        if chunk:
            chunks.append(chunk)
        for index, points in enumerate(chunks):
            part = copy.deepcopy(s)
            part.pop("shape", None)
            part.pop("pts", None)
            part.update(points=points, id=s["id"] if not index else uuid.uuid4().hex)
            # 擦除后的几何折线不能被曲线平滑重新跨过被擦掉的区域。
            part["shape"] = {"kind": "polyline"}
            result.append(part)
    return result
