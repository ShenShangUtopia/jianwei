"""框出来的一道题 → 在题库里找同一道或最像的题。只比较文字，不联网，题库 200 来道题一次几毫秒。

做法：去掉空白和标点，按「相邻两个字」切成片段，比较两边片段的重合程度（余弦相似度）。
数字和字母都保留：同一道题的数值一样，换了数的「同型题」分数会低一些，界面上照实写「相似」而不是「就是这道」。
"""
from __future__ import annotations

import math
import re
from collections import Counter

_DROP = re.compile(r"[\s　，。、；：？！,.;:?!“”‘’\"'（）()《》【】\[\]{}<>…—\-·•●▪◆■□►▶（）　_=+*/\\|~`^$#@%&]+")
SAME = 0.82        # 以上当作「就是这道题」
SIMILAR = 0.34     # 以上才列出来


def _grams(text: str) -> Counter:
    s = _DROP.sub("", str(text or "")).lower()
    if len(s) < 2:
        return Counter([s]) if s else Counter()
    return Counter(s[i:i + 2] for i in range(len(s) - 1))


def score(a: str, b: str) -> float:
    ga, gb = _grams(a), _grams(b)
    if not ga or not gb:
        return 0.0
    dot = sum(v * gb.get(k, 0) for k, v in ga.items())
    return dot / math.sqrt(sum(v * v for v in ga.values()) * sum(v * v for v in gb.values()))


def similar(text: str, questions, k: int = 3) -> list[dict]:
    """返回 [{q, score, same}]，分数从高到低；太短或都不像时返回空列表。"""
    if len(_DROP.sub("", str(text or ""))) < 6:
        return []
    out = []
    for q in questions:
        body = f"{q.get('stem') or ''}"
        s = score(text, body)
        if q.get("title"):   # 框选可能只框到题目开头：和标题也比一次
            s = max(s, score(text, q["title"]) * 0.9)
        if s >= SIMILAR:
            out.append(dict(q=q, score=s, same=s >= SAME))
    out.sort(key=lambda r: -r["score"])
    return out[:k]
