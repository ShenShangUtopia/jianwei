"""自由工作台的外壳：画布铺满窗口，操作都浮在上面。

  ┌─────────────────────────────────────────────────────────────┐
  │ 印  ┌ 试剂 / 物品 / 实验 ┐   ┌ 顶条 ┐   ┌ 调整 / 说明 ┐  调 │
  │ 试  │ 搜索              │                │ 选中物体的参数 │  说 │
  │ 物  │ 素材方格          │     画 布      │ 读数           │     │
  │ 实  └───────────────────┘                └────────────────┘     │
  └─────────────────────────────────────────────────────────────┘

两侧各有一条常驻的小键栏：点一个键展开对应的浮窗，再点一次（或点浮窗右上角）收起。
浮窗用不透明的切角面，遮住的那块画布不必重画，也不会在实验动画时逐帧重绘浮窗内容。
"""
from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QEvent, QObject, QPoint, QPointF, QPropertyAnimation, QRect, QRectF, Qt, Signal
from PySide6.QtGui import QPainter, QPen, QPolygon, QPolygonF, QRegion
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMenu, QPushButton, QScrollArea, QStackedWidget,
                               QTextBrowser, QVBoxLayout, QWidget)

from ..design.icons import draw_icon
from ..design.tokens import T, font, qc
from ..design.widgets import IconButton, draw_key, paint_seal
from .bench import TABS, Palette
from .home import load_json, save_json

M = 10           # 浮层到窗口边的距离
RAIL_W = 50
GAP = 6
LEFT_W = 288
RIGHT_W = 324
TOP_H = 62       # 顶条占掉的高度
CUT = 5          # 切角
ANIM_MS = 150
UI_FILE = "workbench-ui.json"


def _chamfer(w: int, h: int, c: int = CUT) -> list[tuple[int, int]]:
    return [(c, 0), (w - c, 0), (w, c), (w, h - c), (w - c, h), (c, h), (0, h - c), (0, c)]


class FloatFrame(QFrame):
    """不透明的切角面。遮罩 + 不透明绘制：底下的画布重画时不会带着它一起重画。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.floating = True

    def set_floating(self, on: bool) -> None:
        self.floating = on
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, on)
        if not on:
            self.clearMask()
        self._mask()

    def _mask(self) -> None:
        if self.floating and self.width() > 0:
            pts = _chamfer(self.width(), self.height())
            self.setMask(QRegion(QPolygon([QPoint(x, y) for x, y in pts])))

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        self._mask()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.fillRect(self.rect(), qc(T.surface))
        if self.floating:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            w, h = self.width() - 1, self.height() - 1
            p.setPen(QPen(qc(T.line2), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPolygon(QPolygonF([QPointF(x + .5 if x < w / 2 else x - .5, y + .5 if y < h / 2 else y - .5) for x, y in _chamfer(w + 1, h + 1)]))
        p.end()


class DockKey(QPushButton):
    """键栏上的一颗键：图标 + 两个字。展开时填色。"""

    def __init__(self, icon: str, text: str):
        super().__init__()
        self.icon, self.label = icon, text
        self._hover = False
        self.setCheckable(True)
        self.setFixedSize(RAIL_W - 8, 48)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setAccessibleName(text)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self, _e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        on, down = self.isChecked(), self.isDown()
        r = QRectF(self.rect())
        if on:
            draw_key(p, r, T.accent, 4, edge=qc(T.accent).darker(140), sunk=down)
        elif down or self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.press if down else T.hover))
            p.drawRoundedRect(r, 4, 4)
        col = qc(T.stage if on else T.soft)
        dy = 1 if down else 0
        draw_icon(p, self.icon, QRectF((self.width() - 19) / 2, 6 + dy, 19, 19), col, 1.5)
        p.setPen(col)
        p.setFont(font(11, 700 if on else 500))
        p.drawText(QRect(0, 27 + dy, self.width(), 17), int(Qt.AlignmentFlag.AlignCenter), self.label)
        p.end()


class SealKey(QPushButton):
    """朱砂印：点开是模式菜单（画布铺满后，窄栏收进这里）。"""

    def __init__(self):
        super().__init__()
        self.setFixedSize(RAIL_W - 8, 40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setToolTip("切换模式、昼夜、素材篮")
        self.setStyleSheet("background:transparent;border:none;")

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        paint_seal(p, QRectF((self.width() - 32) / 2, (self.height() - 32) / 2 + (1 if self.isDown() else 0), 32, 32))
        p.end()


class BenchName(QPushButton):
    """顶条上的工作台名：一颗带下拉箭头的键。"""

    def paintEvent(self, e):  # noqa: N802
        super().paintEvent(e)
        p = QPainter(self)
        draw_icon(p, "chevron_d", QRectF(self.width() - 22, (self.height() - 14) / 2, 14, 14), qc(T.soft), 1.5)
        p.end()


class FlyPanel(FloatFrame):
    """一个浮窗：标题 + 收起键 + 内容堆叠。"""
    closed = Signal()

    def __init__(self, parent, side: str, width: int):
        super().__init__(parent)
        self.side, self.w_open = side, width
        self.setFixedWidth(width)
        v = QVBoxLayout(self)
        v.setContentsMargins(1, 8, 1, 3)
        v.setSpacing(6)
        head = QHBoxLayout()
        head.setContentsMargins(13, 0, 6, 0)
        self.title = QLabel()
        self.title.setObjectName("flyTitle")
        head.addWidget(self.title, 1)
        self.close_btn = IconButton("chevron_l" if side == "left" else "chevron_r", "收起", 26)
        self.close_btn.clicked.connect(self.closed)
        head.addWidget(self.close_btn)
        v.addLayout(head)
        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)


class BenchChrome(QObject):
    """管理键栏、浮窗和顶条的摆放；不碰工作台内部逻辑。"""

    def __init__(self, studio):
        super().__init__(studio)
        self.studio = studio
        self.host: QWidget = studio.exp_page
        self.anim_ms = ANIM_MS
        self.active = False
        self.pal: Palette | None = None
        self.kit = None
        self.bar = None
        self._anims: dict = {}
        self._suppressed = False
        self.B = None
        saved = load_json(UI_FILE, {})
        saved = saved if isinstance(saved, dict) else {}
        self.state = dict(left=saved.get("left", True), right=saved.get("right", True),
                          rtab=saved.get("rtab", "tune"), tabs=saved.get("tabs") if isinstance(saved.get("tabs"), dict) else {})
        self._build()
        self.host.installEventFilter(self)
        self.show_all(False)

    # ---- 结构
    def _build(self) -> None:
        h = self.host
        self.lrail = FloatFrame(h)
        self.lrail.setFixedWidth(RAIL_W)
        lv = QVBoxLayout(self.lrail)
        lv.setContentsMargins(4, 5, 4, 6)
        lv.setSpacing(3)
        self.seal = SealKey()
        self.seal.clicked.connect(self.mode_menu)
        lv.addWidget(self.seal)
        self.lkeys: dict[str, DockKey] = {}
        for k, (text, icon) in TABS.items():
            b = DockKey(icon, text)
            b.clicked.connect(lambda _c=False, t=k: self.toggle_left(t))
            lv.addWidget(b)
            self.lkeys[k] = b
        self.lpanel = FlyPanel(h, "left", LEFT_W)
        self.lpanel.closed.connect(lambda: self.set_left(False))

        self.rrail = FloatFrame(h)
        self.rrail.setFixedWidth(RAIL_W)
        rv = QVBoxLayout(self.rrail)
        rv.setContentsMargins(4, 6, 4, 6)
        rv.setSpacing(3)
        self.rkeys: dict[str, DockKey] = {}
        self.rpanel = FlyPanel(h, "right", RIGHT_W)
        self.rpanel.closed.connect(lambda: self.set_right(False))
        self.adjust = QScrollArea()
        self.adjust.setWidgetResizable(True)
        self.adjust.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.adjust.setFrameShape(QFrame.Shape.NoFrame)
        self.rpanel.stack.addWidget(self.adjust)
        self.info = QTextBrowser()
        self.info.setOpenExternalLinks(False)
        self.info.setFrameShape(QFrame.Shape.NoFrame)
        self.info.document().setDocumentMargin(14)
        self.rpanel.stack.addWidget(self.info)
        for k, text, icon in (("tune", "调整", "tune"), ("note", "说明", "note")):
            b = DockKey(icon, text)
            b.clicked.connect(lambda _c=False, t=k: self.toggle_right(t))
            rv.addWidget(b)
            self.rkeys[k] = b

        self.detached = QLabel("画布在独立窗口里。\n这里的素材和调整仍然可用；关掉那个窗口，画布会回到这里。", h)
        self.detached.setObjectName("note")
        self.detached.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.detached.hide()

        self.bench_btn = BenchName()
        self.bench_btn.setObjectName("benchName")
        self.bench_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.bench_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.bench_btn.setToolTip("换一个工作台")
        self.bench_btn.clicked.connect(self.bench_menu)
        self.tool_btns = []
        for icon, tip, fn in (("reset", "复位视图（双击画布同效）", self.studio.reset_view),
                              ("camera", "把画面存成图片", self.studio.snapshot),
                              ("full", "全屏（F11）", self.studio.toggle_full)):
            b = IconButton(icon, tip, 30)
            b.clicked.connect(fn)
            self.tool_btns.append(b)

    def show_all(self, on: bool) -> None:
        for w in (self.lrail, self.rrail):
            w.setVisible(on)
        self.lpanel.setVisible(on and self.state["left"])
        self.rpanel.setVisible(on and self.state["right"])

    def eventFilter(self, watched, event):  # noqa: N802
        if watched is self.host and event.type() == QEvent.Type.Resize and self.active:
            self._fit_width()
            self.relayout()
        return False

    # ---- 进入 / 离开一个工作台
    def enter(self, kit, B, adjust_panel: QWidget, pal: Palette) -> None:
        self.kit, self.B, self.pal = kit, B, pal
        self.active = True
        self.adjust.setWidget(adjust_panel)
        self.lpanel.stack.addWidget(pal)
        self.lpanel.stack.setCurrentWidget(pal)
        pal.tabs_changed.connect(self.sync_tabs)
        pal.tab_picked.connect(self._picked)
        pal.drag_state.connect(self.dragging)
        self.bench_btn.setText(kit.title)
        self.bench_btn.setToolTip(f"{kit.sub}\n点击换一个工作台")
        self.show_all(True)
        self._fit_width()
        self.relayout()
        self.raise_all()

    def leave(self) -> None:
        self.active = False
        self._save()
        self.show_all(False)
        self.detached.hide()
        if self.pal is not None:
            self.lpanel.stack.removeWidget(self.pal)
            self.pal.deleteLater()
            self.pal = None
        old = self.adjust.takeWidget()
        if old is not None:
            old.deleteLater()
        self.bar = None
        self.B = self.kit = None
        for b in (self.bench_btn, *self.tool_btns):   # 它们挂在顶条上，顶条要销毁了
            b.setParent(self.host)
            b.hide()

    def sync_tabs(self) -> None:
        """素材定下来以后：决定显示哪些键，打开上次用过的那一页。"""
        if self.pal is None:
            return
        have = self.pal.tabs()
        for k, b in self.lkeys.items():
            b.setVisible(k in have)
            b.label = self.pal.labels.get(k, b.label)
        want = self.state["tabs"].get(self.kit.id) if self.kit else None
        if want not in have:
            want = "reagent" if "reagent" in have else self.pal.first_tab()
        self._show_left_tab(want)
        self._show_right_tab(self.state["rtab"] if self.state["rtab"] in self.rkeys else "tune")
        self.relayout()

    def _picked(self, tab: str) -> None:
        self._show_left_tab(tab)

    def _show_left_tab(self, tab: str) -> None:
        if self.pal is None or not tab:
            return
        self.pal.show_tab(tab)
        self.lpanel.title.setText(self.pal.labels.get(tab, ""))
        if self.kit:
            self.state["tabs"][self.kit.id] = tab
        self._sync_keys()

    def _show_right_tab(self, tab: str) -> None:
        self.state["rtab"] = tab
        self.rpanel.stack.setCurrentIndex(0 if tab == "tune" else 1)
        self.rpanel.title.setText("调整" if tab == "tune" else "说明与记录")
        self._sync_keys()

    def _sync_keys(self) -> None:
        cur = self.pal.cur if self.pal else ""
        for k, b in self.lkeys.items():
            b.setChecked(self.state["left"] and k == cur)
            b.update()
        for k, b in self.rkeys.items():
            b.setChecked(self.state["right"] and k == self.state["rtab"])

    # ---- 开合
    def toggle_left(self, tab: str) -> None:
        if self.state["left"] and self.pal and self.pal.cur == tab:
            self.set_left(False)
        else:
            self._show_left_tab(tab)
            self.set_left(True)

    def toggle_right(self, tab: str) -> None:
        if self.state["right"] and self.state["rtab"] == tab:
            self.set_right(False)
        else:
            self._show_right_tab(tab)
            self.set_right(True)

    def set_left(self, on: bool) -> None:
        self._set("left", on)

    def set_right(self, on: bool) -> None:
        self._set("right", on)

    def _both_fit(self) -> bool:
        return self.host.width() >= 2 * (M + RAIL_W + GAP) + LEFT_W + RIGHT_W + 360

    def _fit_width(self) -> None:
        """窗口太窄放不下两个浮窗时，只留左边。"""
        if self.state["left"] and self.state["right"] and not self._both_fit():
            self.state["right"] = False
            self.rpanel.hide()
            self._sync_keys()

    def _set(self, side: str, on: bool) -> None:
        if on and self.state[side]:
            self.relayout()
            return
        other = "right" if side == "left" else "left"
        if on and self.state[other] and not self._both_fit():
            self.state[other] = False
            (self.rpanel if other == "right" else self.lpanel).hide()
        changed = self.state[side] != on
        self.state[side] = on
        self._sync_keys()
        self._save()
        panel = self.lpanel if side == "left" else self.rpanel
        target = self._panel_rect(side)
        self.relayout(skip=panel)
        if not changed:
            return
        off_x = -panel.width() if side == "left" else self.host.width()
        anim = self._anims.pop(side, None)
        if anim:
            anim.stop()
        if self.anim_ms <= 0 or not self.host.isVisible():
            panel.setGeometry(target)
            panel.setVisible(on)
            return
        panel.setGeometry(target if on else panel.geometry())
        panel.show()
        panel.raise_()
        (self.lrail if side == "left" else self.rrail).raise_()
        anim = QPropertyAnimation(panel, b"pos", self)
        anim.setDuration(self.anim_ms)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.setStartValue(QPoint(off_x, target.y()) if on else panel.pos())
        anim.setEndValue(target.topLeft() if on else QPoint(off_x, target.y()))
        if not on:
            anim.finished.connect(lambda p=panel, s=side: p.setVisible(self.state[s]))
        self._anims[side] = anim
        anim.start()

    def dragging(self, on: bool) -> None:
        """拖素材时两个浮窗让开，松手后回来；独立画布时不用让。"""
        if self.studio.clip_transfer.window is not None:
            return
        self._suppressed = on
        self.lpanel.setVisible(not on and self.state["left"])
        self.rpanel.setVisible(not on and self.state["right"])

    # ---- 摆放
    def insets(self) -> tuple:
        if self.studio.clip_transfer.window is not None:
            return (0, 0, 0, 0)   # 画布不在这个窗口，不被遮挡
        left = M + RAIL_W + (GAP + LEFT_W if self.state["left"] else 0) + GAP
        right = M + RAIL_W + (GAP + RIGHT_W if self.state["right"] else 0) + GAP
        return (left, TOP_H if self.bar is not None else M, right, 0)

    def _panel_rect(self, side: str) -> QRect:
        W, H = self.host.width(), self.host.height()
        if side == "left":
            return QRect(M + RAIL_W + GAP, M, LEFT_W, H - 2 * M)
        return QRect(W - M - RAIL_W - GAP - RIGHT_W, M, RIGHT_W, H - 2 * M)

    def relayout(self, skip=None) -> None:
        if not self.active:
            return
        W, H = self.host.width(), self.host.height()
        self.lrail.adjustSize()
        self.rrail.adjustSize()
        self.lrail.setGeometry(M, M, RAIL_W, self.lrail.sizeHint().height())
        self.rrail.setGeometry(W - M - RAIL_W, M, RAIL_W, self.rrail.sizeHint().height())
        for side, panel in (("left", self.lpanel), ("right", self.rpanel)):
            if panel is not skip and side not in self._anims_running():
                panel.setGeometry(self._panel_rect(side))
        self.place_bar()
        self._publish()
        if self.detached.isVisible():
            self.detached.setGeometry(0, 0, W, H)

    def _anims_running(self) -> set:
        return {s for s, a in self._anims.items() if a.state() == QPropertyAnimation.State.Running}

    def place_bar(self) -> None:
        if self.bar is None or not self.bar.floating:
            return
        W = self.host.width()
        left, _t, right, _b = self.insets() if self.studio.clip_transfer.window is None else (0, 0, 0, 0)
        hint = self.bar.sizeHint()
        room = W - left - right
        x = left + max(0, (room - hint.width()) // 2)
        self.bar.setGeometry(min(x, max(M, W - hint.width() - M)), M, hint.width(), hint.height())

    def _publish(self) -> None:
        B = self.B
        if B is None:
            return
        new = self.insets()
        old = B.L.stage.safe
        if new != old:
            B.L.stage.safe = new
            B.safe_changed(old, new)

    def raise_all(self) -> None:
        for w in (self.lpanel, self.rpanel, self.lrail, self.rrail):
            w.raise_()
        if self.bar is not None and self.bar.floating:
            self.bar.raise_()

    # ---- 顶条（由互通层建好交过来）
    def fill_bar(self, row: QHBoxLayout) -> None:
        """把工作台名和复位 / 截图 / 全屏放进顶条的第一排。"""
        row.insertWidget(0, self.bench_btn)
        self.bench_btn.show()
        for b in self.tool_btns:
            row.addWidget(b)
            b.show()

    def attach_bar(self, bar) -> None:
        self.bar = bar
        bar.setParent(self.host)
        bar.set_floating(True)
        bar.show()
        self.detached.hide()
        self.relayout()
        self.raise_all()

    def release_bar(self, bar) -> None:
        """顶条和画布一起进独立窗口：这边只留提示。"""
        bar.set_floating(False)
        self.detached.setGeometry(self.host.rect())
        self.detached.show()
        self.detached.lower()
        self.relayout()

    # ---- 菜单
    def mode_menu(self) -> None:
        win = self.studio.window()
        menu = QMenu(self.studio)
        if hasattr(win, "goto"):
            from ..main_win import MODES
            for key, text in MODES:
                act = menu.addAction(text, lambda _=False, k=key: win.goto(k))
                act.setCheckable(True)
                act.setChecked(key == "bench")
            menu.addSeparator()
            menu.addAction("素材篮", win.show_materials)
        else:
            menu.addAction("回到实验首页", self.studio.go_home)
        menu.addAction("切换昼 / 夜", self.studio.toggle_theme)
        menu.exec(self.seal.mapToGlobal(QPoint(self.seal.width() + 4, 0)))

    def bench_menu(self) -> None:
        from .bench import bench
        menu = QMenu(self.studio)
        for k in bench.list:
            act = menu.addAction(k.title, lambda _=False, i=k.id: self.studio.open_bench(i))
            act.setCheckable(True)
            act.setChecked(self.kit is not None and k.id == self.kit.id)
        menu.exec(self.bench_btn.mapToGlobal(self.bench_btn.rect().bottomLeft()))

    # ---- 其他
    def focus_search(self) -> None:
        self.set_left(True)
        if self.pal is not None:
            self.pal.search.setFocus()
            self.pal.search.selectAll()

    def apply_theme(self) -> None:
        for w in (self.lrail, self.rrail, self.lpanel, self.rpanel):
            w.update()
        if self.bar is not None:
            self.bar.update()

    def _save(self) -> None:
        try:
            current=load_json(UI_FILE,{})
            current=current if isinstance(current,dict) else {}
            current.update(self.state)
            save_json(UI_FILE, current)
        except OSError:
            pass   # 只是界面偏好，存不下不影响使用
