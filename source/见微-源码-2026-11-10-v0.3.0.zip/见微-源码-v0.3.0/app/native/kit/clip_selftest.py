"""内容互通回归；所有数据隔离，不调用 Office 或真实网络。"""
from __future__ import annotations

from . import test_runtime
test_runtime.configure()

import hashlib
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PySide6.QtCore import QPointF, QRectF, QSize
from PySide6.QtGui import QImage, QColor
from PySide6.QtWidgets import QApplication

from .clip import ClipStore, ClipBus, write_json
from . import pen


class ClipTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.root = Path(self.tmp.name)
        self.previous = {k:os.environ.get(k) for k in ("JIANWEI_HOME","LOCALAPPDATA")}
        os.environ["JIANWEI_HOME"] = str(self.root)
        os.environ["LOCALAPPDATA"] = str(self.root/"local")
        self.store = ClipStore()
        self.bus = ClipBus(store=self.store)
        self.widgets = []

    def tearDown(self):
        from shiboken6 import delete,isValid
        for widget in self.widgets:
            if isValid(widget):
                widget.close()
                delete(widget)
        QApplication.processEvents()
        for k,v in self.previous.items():
            if v is None:
                os.environ.pop(k,None)
            else:
                os.environ[k] = v
        self.tmp.cleanup()

    def clip(self):
        image = QImage(600,400,QImage.Format.Format_RGB32)
        image.fill(QColor("white"))
        stroke = pen.new_stroke("pen","red",3)
        pen.add_point(stroke,20,20,.3)
        pen.add_point(stroke,150,80,.9)
        return self.store.create(image=image,ink=[stroke],text="题目文本",origin=dict(type="lecture",ref=dict(lecture_id="fixture",slide=0),rect=[0,0,600,400]))

    def player(self):
        from ..lecture import library
        from ..lecture.player import LecturePlayer
        meta = library.from_clip(self.clip(),self.store,"测试课件")
        with patch("native.lecture.lookup.Ocr.start"),patch("native.lecture.lookup.warm"):
            player = LecturePlayer(meta)
        self.widgets.append(player)
        return player

    def test_clip_roundtrip_and_mime(self):
        clip = self.clip()
        result = self.store.from_mime(self.store.mime(clip))
        self.assertEqual(result,clip)
        self.assertEqual(result["ink"][0]["points"][-1][2],.9)

    def test_paths_and_foreign_ids_rejected(self):
        for cid in ("../outside","C:\\secret","",None):
            with self.assertRaises(ValueError):
                self.store.load(cid)
        clip = self.clip()
        clip["image"] = "../outside.png"
        with self.assertRaises(ValueError):
            self.store.asset(clip,"image")

    def test_mime_fallback_preserves_vectors_in_another_store(self):
        clip = self.clip()
        other = ClipStore(self.root/"other-clips")
        received = other.from_mime(self.store.mime(clip))
        self.assertNotEqual(received["id"],clip["id"])
        self.assertEqual(received["origin"],clip["origin"])
        self.assertEqual(received["ink"],clip["ink"])
        self.assertTrue(other.asset(received,"image").is_file())

    def test_basket_pins_and_recent_limit(self):
        first = self.clip()
        self.bus.remember(first)
        self.bus.pin(first["id"],True)
        for _ in range(32):
            self.bus.remember(self.store.create(text="素材"))
        rows = self.bus.recent()
        self.assertEqual(len(rows),31)
        self.assertTrue(rows[0]["pinned"])
        self.assertEqual(self.store.load(first["id"]),first)

    def test_crop_has_no_outside_points(self):
        from ..lecture.board_transfer import crop_ink
        stroke = pen.new_stroke("pen","red",2)
        pen.add_point(stroke,-10,20,.2)
        pen.add_point(stroke,110,20,.9)
        clipped = crop_ink([stroke],QRectF(0,0,100,40))
        self.assertEqual(len(clipped),1)
        self.assertEqual(clipped[0]["points"][0][0],0)
        self.assertEqual(clipped[0]["points"][-1][0],100)
        self.assertAlmostEqual(clipped[0]["points"][0][2],.2+.7/12)

    def test_board_group_move_undo_and_reopen(self):
        from ..lecture.board import BoardCanvas
        board = BoardCanvas(self.root/"board")
        self.widgets.append(board)
        board.resize(1000,700)
        board.clip_store = self.store
        clip = self.clip()
        item = board.receive_clip(clip)
        old_x = board.board["strokes"][0]["points"][0][0]
        center = board.to_view_rect(QRectF(item["x"],item["y"],item["w"],item["h"])).center()
        board._press(center)
        board._move(center+QPointF(40,20))
        board._release()
        self.assertAlmostEqual(board.board["strokes"][0]["points"][0][0],old_x+40)
        board.undo()
        self.assertAlmostEqual(board.board["strokes"][0]["points"][0][0],old_x)
        self.assertTrue(board.save())
        reopened = BoardCanvas(self.root/"board")
        self.widgets.append(reopened)
        self.assertEqual(reopened.board["items"][0]["origin"],clip["origin"])
        self.assertEqual(reopened.board["strokes"],board.board["strokes"])

    def test_insert_original_unchanged_and_ink_clear_persists(self):
        player = self.player()
        original = hashlib.sha256((player.dir/"doc.pdf").read_bytes()).digest()
        player.insert_clip(self.clip())
        self.assertEqual(player.view.pages,2)
        self.assertEqual(player.view.page,1)
        self.assertEqual(len(player.view.history().strokes),1)
        self.assertEqual(hashlib.sha256((player.dir/"doc.pdf").read_bytes()).digest(),original)
        player.view.clear_page()
        player.save()
        key = player.view.slides[1]["history_id"]
        self.assertEqual(player.ink_store.data["pages"][str(key)],[])
        player.close()
        from ..lecture.player import LecturePlayer
        with patch("native.lecture.lookup.Ocr.start"),patch("native.lecture.lookup.warm"):
            reopened = LecturePlayer(player.meta)
        self.widgets.append(reopened)
        self.assertEqual(reopened.view.pages,2)
        self.assertFalse(reopened.view.history(1).strokes)

    def test_origin_return_highlights_exact_source(self):
        player = self.player()
        clip = player.lecture_clip()
        player.insert_clip(clip)
        self.assertTrue(player.show_origin(clip["origin"]))
        self.assertEqual(player.view.page,0)
        self.assertEqual(player.view.source_rect,QRectF(*clip["origin"]["rect"]))

    def test_manifest_future_protected(self):
        player = self.player()
        future = dict(version=99,items=[])
        write_json(player.dir/"inserts.json",future)
        before = (player.dir/"inserts.json").read_bytes()
        from ..lecture import inserts
        with self.assertRaises(ValueError):
            inserts.add(player.dir,"s:0",self.clip())
        self.assertEqual((player.dir/"inserts.json").read_bytes(),before)

    def test_insert_projection_keeps_animation_frames_and_source_ids(self):
        from PySide6.QtGui import QPainter, QPdfWriter
        from PySide6.QtPdf import QPdfDocument
        from shiboken6 import delete
        from ..lecture import inserts
        folder = self.root/"animated"
        folder.mkdir()
        writer = QPdfWriter(str(folder/"base.pdf"))
        painter = QPainter(writer)
        for index in range(4):
            if index:
                writer.newPage()
            painter.fillRect(0,0,writer.width(),writer.height(),QColor("white"))
        painter.end()
        del painter,writer
        doc = QPdfDocument()
        doc.load(str(folder/"base.pdf"))
        frames = [dict(page=i,slide=0 if i<3 else 1,effects=[],auto=i==2) for i in range(4)]
        timeline = dict(frames=frames,slides=[dict(first=0,last=2,transition=None,adv=None),dict(first=3,last=3,transition=None,adv=None)])
        inserts.add(folder,"s:0",self.clip())
        virtual,projected,seeds = inserts.project(doc,timeline,folder,self.store)
        self.assertEqual([frame["page"] for frame in projected["frames"]],[0,1,2,4,3])
        self.assertEqual([slide["history_id"] for slide in projected["slides"]][::2],[0,1])
        self.assertTrue(projected["frames"][2]["auto"])
        self.assertEqual(virtual.pageCount(),5)
        self.assertEqual(len(seeds),1)
        doc.close()
        delete(doc)

    def test_vector_layer_is_not_baked(self):
        clip = self.clip()
        plain = self.store.render(clip,QSize(600,400),include_ink=False)
        composed = self.store.render(clip,QSize(600,400))
        self.assertEqual(plain.pixelColor(20,20),QColor("white"))
        self.assertNotEqual(plain,composed)


def main(root=None):
    global ROOT
    ROOT = Path(root or tempfile.mkdtemp(prefix="jw-clips-test-"))
    ROOT.mkdir(parents=True,exist_ok=True)
    app = test_runtime.application()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ClipTests))
    app.processEvents()
    print("CLIP_PHASE3","OK" if result.wasSuccessful() else "FAIL",result.testsRun,flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(lambda:main(sys.argv[1] if len(sys.argv)>1 else None)))
