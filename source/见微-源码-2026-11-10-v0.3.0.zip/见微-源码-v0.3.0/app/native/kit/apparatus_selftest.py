"""新增器材/元件的模型、放置与存档回归。"""
import sys
from pathlib import Path
from . import test_runtime

test_runtime.configure()


def main(output=None):
    app=test_runtime.application()
    from ..lab.benches.apparatus_model import route_gas,gas_volume,titration,resistance
    from ..lab.benches.chem_model import VT,eqm
    from ..lab.studio import Studio
    from . import state_graph
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    src=dict(id=1,gas_to=2)
    wash=dict(id=2,gas_to=3,collection="wash",V=50,tot={"Ca":1})
    dest=dict(id=3,collection="up",gas_capacity=250)
    caught,lost=route_gas(src,[src,wash,dest],"CO2",3)
    assert abs(caught-3)<1e-8 and lost==0 and wash["tot"]["C"]==2 and dest["collected"]["CO2"]==1
    assert eqm(wash["tot"],50)["pH"]<12
    assert abs(gas_volume(1)-24.465)<.01
    dest["collection"]="water"
    caught,lost=route_gas(src,[src,wash,dest],"CO2",1)
    assert caught==0 and lost==1 and dest.get("gas_note")
    dest.update(collection="water",collected={},gas_to=1)
    caught,lost=route_gas(src,[src,wash,dest],"O2",1)
    assert caught==1 and lost==0
    assert abs(titration(25,.1,.1,25)["pH"]-7)<.1
    assert titration(25,.1,.1,24)["pH"]<4 and titration(25,.1,.1,26)["pH"]>10
    assert resistance(dict(instrument="ntc",temperature=60))<resistance(dict(instrument="ntc",temperature=20))
    assert resistance(dict(instrument="ldr",lux=1000))<resistance(dict(instrument="ldr",lux=10))
    assert resistance(dict(instrument="fuse",tripped=True))>1e9
    for key in ("cylinder","burette","gasjar","dish","bottle","volumetric","roundflask"):
        assert VT[key].lvl(VT[key].cap)>VT[key].lvl(VT[key].cap/2)>0
    studio=Studio("day")
    studio.resize(1440,900)
    studio.show()
    count=0
    for bid,ids in (("chem",["vessel-"+k for k in VT if k not in ("tube","beaker","flask")]),("circ",["tool-"+k for k in ("box","ntc","ldr","fuse")])):
        studio.open_bench(bid)
        app.processEvents()
        B=studio.B
        initial=B.transfer_snapshot()
        for ident in ids:
            B.transfer_restore(initial)
            item=B.pal.items[ident].it
            item["drop"](700,600)
            app.processEvents()
            data=state_graph.decode(B.transfer_snapshot())
            objects=data["objs"] if bid=="chem" else data["S"]["comps"]
            assert objects and not studio.ctx.stage.error,ident
            saved=B.transfer_snapshot()
            B.transfer_restore(saved)
            studio.ctx.stage.repaint()
            assert not studio.ctx.stage.error
            count+=1
        studio.grab().save(str(out/(bid+"-items.png")))
    studio.go_home()
    studio.close()
    print("APPARATUS_CORE OK",count,"items; gas conservation, collection, titration, sensors, snapshots",flush=True)
    return 0


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
