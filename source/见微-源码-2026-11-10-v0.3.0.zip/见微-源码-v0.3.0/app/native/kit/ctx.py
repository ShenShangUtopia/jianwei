"""实验上下文 Ctx：一块画布（Stage）+ 右侧控件面板。每次打开实验新建一个，关闭时 dispose()。

和旧 gewu/core.js 的 Ctx 一一对应，只是名字改成 Python 风格：
  L.canvas()  L.params({...}, cb)  L.slider()  L.select()  L.input()  L.button()  L.toggle()  L.seg()
  L.check()   L.out()  L.note()  L.legend()  L.group()  L.loop()  L.every()  L.on_draw()  L.draw()
  L.interact(c, hit=, drag=, click=, hover=, view=)  L.orbit(c, cam)
控件都登记在 L.ctrls 里（名称、类型、取值 / 设值函数），题目分析按名称读写。
"""
from __future__ import annotations

import math
import time
import traceback

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (QCheckBox, QComboBox, QHBoxLayout, QLabel, QLayout, QLineEdit, QPlainTextEdit,
                               QPushButton, QSizePolicy, QSlider, QVBoxLayout, QWidget)

from ..design.tokens import T, family, qc
from ..design.widgets import FlowLayout
from .core import clamp, fmt
from .draw import D, G


# ---------------------------------------------------------------- 画布
class Canvas:
    """实验代码看到的画布：c.w / c.h / c.g / c.clear()。"""

    def __init__(self, stage: "Stage"):
        self.stage = stage
        self.w = max(10, stage.width())
        self.h = max(10, stage.height())
        self.g: G | None = None

    def clear(self) -> None:
        if self.g is not None:
            self.g.p.fillRect(QRectF(0, 0, self.w, self.h), qc(T.stage))


class Stage(QWidget):
    def __init__(self, ctx: "Ctx", parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.c = Canvas(self)
        self.setMinimumSize(320, 260)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.mouse = None        # 交互回调（interact / orbit）
        self.key_fn = None       # 键盘回调 fn(key: str, e) -> bool（返回 True 表示已处理）
        self.drop_fn = None      # 素材栏拖放 fn(x, y)
        self.error: str | None = None
        self.overlays: list = []  # 画完以后叠加的绘制（悬停读数等）
        self.safe = (0, 0, 0, 0)  # 被工作台浮窗盖住的边距（左, 上, 右, 下）
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)

    def paintEvent(self, _e):  # noqa: N802
        c = self.c
        c.w, c.h = max(10, self.width()), max(10, self.height())
        p = QPainter(self)
        g = G(p)
        c.g = g
        try:
            p.fillRect(self.rect(), qc(T.stage))
            if self.ctx.draw_fn and not self.error:
                self.ctx.draw_fn()
            for f in self.overlays:
                f(g)
        except Exception as exc:  # noqa: BLE001  实验画错了不让窗口崩：把错误写在画布上
            self.error = f"{type(exc).__name__}: {exc}"
            traceback.print_exc()
        if self.error:
            p.resetTransform()
            p.fillRect(self.rect(), qc(T.stage))
            D.text(g, "实验绘制出错：" + self.error, 20, 30, T.bad, size=13)
        c.g = None
        p.end()

    # 鼠标交给 ctx 登记的交互
    def mousePressEvent(self, e):  # noqa: N802
        if self.mouse:
            self.mouse("down", e)

    def mouseMoveEvent(self, e):  # noqa: N802
        if self.mouse:
            self.mouse("move", e)

    def mouseReleaseEvent(self, e):  # noqa: N802
        if self.mouse:
            self.mouse("up", e)

    def mouseDoubleClickEvent(self, e):  # noqa: N802
        if self.mouse:
            self.mouse("dbl", e)

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        fn = getattr(self, "resize_fn", None)
        if fn:
            fn()

    def wheelEvent(self, e):  # noqa: N802
        if self.mouse:
            self.mouse("wheel", e)

    def leaveEvent(self, e):  # noqa: N802
        if self.mouse:
            self.mouse("leave", e)

    # 键盘（工作台：Esc / Delete / R 等）
    def keyPressEvent(self, e):  # noqa: N802
        if self.key_fn:
            k = e.key()
            name = {Qt.Key.Key_Escape: "Escape", Qt.Key.Key_Delete: "Delete", Qt.Key.Key_Backspace: "Backspace",
                    Qt.Key.Key_Space: " ", Qt.Key.Key_Left: "ArrowLeft", Qt.Key.Key_Right: "ArrowRight",
                    Qt.Key.Key_Up: "ArrowUp", Qt.Key.Key_Down: "ArrowDown", Qt.Key.Key_Return: "Enter"}.get(k) or e.text()
            if name and self.key_fn(name, e):
                e.accept()
                self.update()
                return
        super().keyPressEvent(e)

    # 素材栏拖放
    def dragEnterEvent(self, e):  # noqa: N802
        if self.drop_fn and e.mimeData().hasFormat("application/x-jw-palette"):
            e.acceptProposedAction()

    dragMoveEvent = dragEnterEvent

    def dropEvent(self, e):  # noqa: N802
        if self.drop_fn:
            p = e.position()
            e.acceptProposedAction()
            self.drop_fn(p.x(), p.y())


# ---------------------------------------------------------------- 控件返回值
class _ValueLabel(QLabel):
    """滑块的读数：点一下变成输入框，可以键入精确值（比如 m = 2.5）。"""

    def __init__(self, slider: "Slider"):
        super().__init__()
        self.slider = slider
        self.setCursor(Qt.CursorShape.IBeamCursor)
        self.setToolTip("点一下直接输入数值；双击滑块回到初始值")
        self.editor: QLineEdit | None = None

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self.begin_edit()

    def begin_edit(self) -> None:
        if self.editor is not None:
            return
        ed = QLineEdit(fmt(self.slider.v, max(self.slider.dg, 2)).rstrip("0").rstrip(".") if "." in fmt(self.slider.v, max(self.slider.dg, 2)) else fmt(self.slider.v, self.slider.dg), self.parentWidget())
        ed.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        ed.setAlignment(Qt.AlignmentFlag.AlignRight)
        ed.setFixedWidth(max(84, self.width()))
        ed.setFixedHeight(max(24, self.height() + 4))
        ed.move(self.geometry().right() - ed.width() + 1, self.y() - 2)
        ed.installEventFilter(self)
        ed.show()
        ed.raise_()
        ed.setFocus()
        ed.selectAll()
        self.editor = ed

    def finish_edit(self, commit: bool) -> None:
        ed, self.editor = self.editor, None
        if ed is None:
            return
        text = ed.text().strip()
        ed.hide()
        ed.deleteLater()
        if not commit:
            return
        try:
            value = float(text)
        except ValueError:
            return
        if math.isfinite(value):
            self.slider.set(value)

    def eventFilter(self, obj, e):  # noqa: N802
        if obj is self.editor:
            kind = e.type()
            if kind == QEvent.Type.ShortcutOverride and e.key() == Qt.Key.Key_Escape:
                e.accept()    # 别让窗口的 Esc 快捷键抢走
                return True
            if kind == QEvent.Type.KeyPress:
                if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                    self.finish_edit(True)
                    return True
                if e.key() == Qt.Key.Key_Escape:
                    self.finish_edit(False)
                    return True
            elif kind == QEvent.Type.FocusOut:
                self.finish_edit(True)
                return False
        return False


class Slider:
    def __init__(self, ctx, label, mn, mx, step, value, cb, unit, digits):
        self.ctx, self.cb, self.unit = ctx, cb, unit
        self.min, self.max, self.step = float(mn), float(mx), float(step)
        self.v = float(value)
        self.dg = digits if digits is not None else max(0, min(4, -math.floor(math.log10(step) + 1e-9)))
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 2, 0, 2)
        lay.setSpacing(2)
        top = QHBoxLayout()
        top.setSpacing(6)
        self.lab = QLabel(label)
        self.lab.setObjectName("ctlLabel")
        self.lab.setWordWrap(True)   # 长标题折行，不能把面板撑宽
        self.val = _ValueLabel(self)
        self.val.setObjectName("ctlValue")
        self.val.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        top.addWidget(self.lab, 1)
        top.addWidget(self.val)
        lay.addLayout(top)
        self.sl = QSlider(Qt.Orientation.Horizontal)
        self.sl.setCursor(Qt.CursorShape.PointingHandCursor)
        self._ranges()
        self.sl.setValue(self._i(self.v))
        self.sl.setProperty("jw_default", self._i(self.v))   # 双击回到这里（见 design/ux.py）
        self.sl.valueChanged.connect(self._moved)
        lay.addWidget(self.sl)
        self.el = box
        self._show()

    def _ranges(self):
        self.n = max(1, int(round((self.max - self.min) / self.step)))
        self.sl.blockSignals(True)
        self.sl.setRange(0, self.n)
        self.sl.blockSignals(False)

    def _i(self, v):
        return int(round((clamp(v, self.min, self.max) - self.min) / self.step))

    def _show(self):
        u = self.unit
        self.val.setText(u(self.v) if callable(u) else fmt(self.v, self.dg) + (" " + u if u else ""))

    def _moved(self, i):
        self.v = round(self.min + i * self.step, 10)
        self._show()
        self.cb(self.v) if self.cb else self.ctx.draw()

    def set(self, v, silent=False):
        self.v = clamp(float(v), self.min, self.max)
        self.sl.blockSignals(True)
        self.sl.setValue(self._i(self.v))
        self.sl.blockSignals(False)
        self._show()
        if not silent:
            self.cb(self.v) if self.cb else self.ctx.draw()

    def set_range(self, a, b):
        self.min, self.max = float(a), float(b)
        self._ranges()
        self.set(clamp(self.v, self.min, self.max), True)


class Params:
    """p.a 读写参数值；p.s('a') 取滑块对象（相当于旧版的 p.$a）。"""

    def __init__(self):
        object.__setattr__(self, "_s", {})

    def __getattr__(self, k):
        s = object.__getattribute__(self, "_s")
        if k in s:
            return s[k].v
        raise AttributeError(k)

    def __setattr__(self, k, v):
        self._s[k].set(v)

    def s(self, k) -> Slider:
        return self._s[k]

    def keys(self):
        return list(self._s)


class Value:
    """通用的 {v, set()} 返回值（select / seg / check / toggle / input）。"""

    def __init__(self, getter, setter, el=None):
        self._get, self._set, self.el = getter, setter, el

    @property
    def v(self):
        return self._get()

    def set(self, v, silent=False):
        self._set(v, silent)


class ButtonRow:
    def __init__(self, holder: QWidget):
        self.holder = holder
        self.lay = FlowLayout(holder, 6)
        self.btns: list[QPushButton] = []

    def add(self, text: str, cb) -> QPushButton:
        b = QPushButton(text, self.holder)
        b.setObjectName("btn")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda _=False: cb())
        self.lay.addWidget(b)
        b.show()
        self.btns.append(b)
        return b

    def clear(self) -> None:
        for b in self.btns:
            self.lay.removeWidget(b)
            b.deleteLater()
        self.btns.clear()


class Out:
    def __init__(self, label: QLabel):
        self.el = label

    def set(self, rows) -> None:
        if isinstance(rows, str):
            self.el.setText(rows)
            return
        mono = family("mono")
        html = ["<table width='100%' cellspacing='0' cellpadding='2'>"]
        for r in rows:
            if r is None:
                continue
            if isinstance(r, (list, tuple)):
                html.append(f"<tr><td style='color:{T.muted}'>{r[0]}</td>"
                            f"<td align='right' style='color:{T.fg};font-family:\"{mono}\";font-weight:600;white-space:nowrap'>{r[1]}</td></tr>")
            else:
                html.append(f"<tr><td colspan='2' style='color:{T.soft}'>{r}</td></tr>")
        html.append("</table>")
        self.el.setText("".join(html))


class Loop:
    def __init__(self, ctx, fn, autoplay):
        self.fn, self.run = fn, autoplay
        self.last = time.perf_counter()
        self.t = QTimer(ctx.stage)
        self.t.setTimerType(Qt.TimerType.PreciseTimer)
        self.t.timeout.connect(self._step)
        self.t.start(16)

    def _step(self):
        now = time.perf_counter()
        dt = clamp(now - self.last, 0, 0.05)
        self.last = now
        if self.run:
            self.fn(dt)

    @property
    def running(self):
        return self.run

    def pause(self):
        self.run = False

    def play(self):
        self.run = True
        self.last = time.perf_counter()

    def toggle(self):
        self.pause() if self.run else self.play()
        return self.run

    def stop(self):
        self.t.stop()


# ---------------------------------------------------------------- 上下文
class Ctx:
    def __init__(self, stage_host: QWidget, panel: QWidget):
        self.stage = Stage(self, stage_host)
        self.panel = panel
        self.panel_lay: QVBoxLayout = panel.layout()
        self.panel_lay.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.box: QVBoxLayout | None = None
        self._row: FlowLayout | None = None
        self.draw_fn = None
        self.timers: list = []
        self.ctrls: list[dict] = []
        self._gt = ""
        self._c: Canvas | None = None

    # ---- 登记（题目分析按名称读写控件）
    def reg(self, kind, label, **o) -> dict:
        import re
        name = re.sub(r"<[^>]+>", "", label or self._gt or kind).strip()
        base, k = name, 2
        while any(c["name"] == name for c in self.ctrls):
            name = f"{base} #{k}"
            k += 1
        c = {"kind": kind, "name": name, "group": self._gt, **o}
        self.ctrls.append(c)
        return c

    # ---- 画布与绘制
    def canvas(self) -> Canvas:
        self._c = self.stage.c
        return self._c

    def tall(self) -> None:
        self.stage.setMinimumHeight(560)

    def on_draw(self, fn) -> None:
        self.draw_fn = fn

    def on_key(self, fn) -> None:
        """fn(key, e) -> bool；key 用浏览器的名字（Escape、Delete、ArrowLeft、普通字符…）。"""
        self.stage.key_fn = fn

    def cached(self, key, fn) -> None:
        """画一层「只有 key 变了才重画」的底图（电势图、场线这类逐点计算的大图）。

        fn() 照常往 c.g 上画；结果缓存成一张图，之后同一个 key 只贴图。悬停读数等叠加层写在 cached 之后。"""
        from PySide6.QtGui import QPixmap
        c = self._c or self.stage.c
        dpr = self.stage.devicePixelRatioF()
        full = (key, c.w, c.h, round(dpr, 3), T.dark)
        if getattr(self, "_cache_key", None) != full:
            pm = QPixmap(max(1, round(c.w * dpr)), max(1, round(c.h * dpr)))
            pm.setDevicePixelRatio(dpr)
            pm.fill(Qt.GlobalColor.transparent)
            p = QPainter(pm)
            outer, c.g = c.g, G(p)
            try:
                fn()
            finally:
                p.end()
                c.g = outer
            self._cache_pm, self._cache_key = pm, full
        c.g.p.drawPixmap(0, 0, self._cache_pm)

    def draw(self) -> None:
        self.stage.update()

    draw_now = draw

    def loop(self, fn, autoplay=True) -> Loop:
        lp = Loop(self, fn, autoplay)
        self.timers.append(lp)
        return lp

    def every(self, ms, fn):
        t = QTimer(self.stage)
        t.timeout.connect(fn)
        t.start(int(ms))
        self.timers.append(t)
        return t

    def dispose(self) -> None:
        for t in self.timers:
            try:
                t.stop()
            except Exception:  # noqa: BLE001
                pass
        self.timers.clear()
        self.draw_fn = None
        self.stage.mouse = None
        self.stage.key_fn = None
        self.stage.drop_fn = None
        self.stage.resize_fn = None

    # ---- 面板
    def group(self, title: str = "") -> QWidget:
        """新开一组控件；返回这一组的容器（可 setVisible 整组显隐）。"""
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        lay.setContentsMargins(0, 4, 0, 8)
        lay.setSpacing(7)
        if title:
            h = QLabel(title.upper() if title.isascii() else title)
            h.setObjectName("grpTitle")
            lay.addWidget(h)
        self.panel_lay.addWidget(w)
        self.box, self._row, self._gt = lay, None, title or ""
        return w

    def _box(self) -> QVBoxLayout:
        if self.box is None:
            self.group()
        return self.box

    def log_rows(self, head, rows) -> list:
        """迭代记录这类表：首行是表头。返回给 out.set() 的行。"""
        return [head, *rows]

    def _add(self, w: QWidget) -> None:
        self._row = None
        self._box().addWidget(w)

    def slider(self, label, mn, mx, step, value, cb=None, unit="", digits=None) -> Slider:
        s = Slider(self, label, mn, mx, step, value, cb, unit, digits)
        self._add(s.el)
        self.reg("slider", label, min=float(mn), max=float(mx), step=float(step), unit=unit if isinstance(unit, str) else "",
                 get=lambda: s.v, set=lambda v: s.set(float(v)), el=s.el, minF=lambda: s.min, maxF=lambda: s.max)
        return s

    def params(self, spec: dict, cb=None) -> Params:
        p = Params()
        for k, row in spec.items():
            label, mn, mx, step, val, *rest = row
            unit = rest[0] if rest else ""
            dg = rest[1] if len(rest) > 1 else None
            p._s[k] = self.slider(label, mn, mx, step, val, (lambda v, k=k: cb(k, v)) if cb else None, unit, dg)
        return p

    def select(self, label, opts, value, cb=None) -> Value:
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        if label:
            lb = QLabel(label)
            lb.setObjectName("ctlLabel")
            lb.setWordWrap(True)
            lay.addWidget(lb)
        cb_ = QComboBox()
        cb_.setMinimumContentsLength(4)   # 下拉框也不按最长选项撑宽面板
        cb_.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        vals = []
        for o in opts:
            v, t = (o[0], o[1]) if isinstance(o, (list, tuple)) else (o, o)
            vals.append(str(v))
            cb_.addItem(str(t), str(v))
        lay.addWidget(cb_)
        self._add(box)

        def get():
            return cb_.currentData()

        def fire():
            cb(get()) if cb else self.draw()

        def set_(v, silent=False):
            i = cb_.findData(str(v))
            if i >= 0:
                cb_.blockSignals(True)
                cb_.setCurrentIndex(i)
                cb_.blockSignals(False)
            if not silent:
                fire()
        set_(value, True)
        cb_.currentIndexChanged.connect(lambda _i: fire())
        val = Value(get, set_, cb_)
        val.box = box

        def set_options(new_opts, value=None):
            """换一组选项（不触发回调），尽量保留原来选中的值。"""
            keep = value if value is not None else get()
            cb_.blockSignals(True)
            cb_.clear()
            for o in new_opts:
                v, t = (o[0], o[1]) if isinstance(o, (list, tuple)) else (o, o)
                cb_.addItem(str(t), str(v))
            i = cb_.findData(str(keep))
            cb_.setCurrentIndex(i if i >= 0 else 0)
            cb_.blockSignals(False)
        val.set_options = set_options
        self.reg("select", label, options=lambda: [{"value": cb_.itemData(i), "text": cb_.itemText(i)} for i in range(cb_.count())],
                 get=get, set=lambda v: set_(v), el=box)
        return val

    def input(self, label, value, cb, area=False, ph=None, rows=3) -> Value:
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        if label:
            lb = QLabel(label)
            lb.setObjectName("ctlLabel")
            lay.addWidget(lb)
        ed = QPlainTextEdit() if area else QLineEdit()
        if area:
            ed.setFixedHeight(22 * rows + 12)
        if ph:
            ed.setPlaceholderText(ph)
        msg = QLabel("")
        msg.setObjectName("err")
        msg.setWordWrap(True)
        msg.hide()
        lay.addWidget(ed)
        lay.addWidget(msg)
        self._add(box)
        get = (lambda: ed.toPlainText()) if area else (lambda: ed.text())
        t = QTimer(ed)   # 防抖计时器随输入框一起销毁：关掉实验后不会再回调到已删除的控件
        t.setSingleShot(True)
        self.timers.append(t)
        val = Value(get, None, ed)
        val.box = box

        def err(m=""):
            msg.setText(m or "")
            msg.setVisible(bool(m))
        val.err = err
        t.timeout.connect(lambda: cb(get(), val))

        def set_(v, silent=False):
            ed.blockSignals(True)
            ed.setPlainText(str(v)) if area else ed.setText(str(v))
            ed.blockSignals(False)
            cb(get(), val)
        val._set = set_
        (ed.textChanged).connect(lambda *_: t.start(120))
        if value:
            ed.setPlainText(str(value)) if area else ed.setText(str(value))
        self.reg("text", label, get=get, set=lambda v: set_(str(v)), el=box)
        return val

    def button(self, label, cb, pri=False) -> QPushButton:
        if self._row is None:
            holder = QWidget()
            self._row = FlowLayout(holder, 6)
            self._box().addWidget(holder)
        b = QPushButton(label)
        b.setObjectName("pri" if pri else "btn")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda _=False: cb(b))
        self._row.addWidget(b)
        self.reg("button", label, press=b.click, el=b)
        return b

    def button_row(self) -> "ButtonRow":
        """一排可清空重建的按钮（随所选反应、模式变化的操作按钮用）。"""
        holder = QWidget()
        row = ButtonRow(holder)
        self._add(holder)
        return row

    def toggle(self, label, on, cb=None) -> Value:
        st = {"v": bool(on)}

        def click(b):
            st["v"] = not st["v"]
            b.setChecked(st["v"])
            cb(st["v"]) if cb else self.draw()
        b = self.button(label, click)
        b.setCheckable(True)
        b.setChecked(st["v"])
        b.clicked.disconnect()
        b.clicked.connect(lambda _=False: click(b))

        def set_(v, silent=False):
            st["v"] = bool(v)
            b.setChecked(st["v"])
            if not silent:
                cb(st["v"]) if cb else self.draw()
        return Value(lambda: st["v"], set_, b)

    def seg(self, label, opts, value, cb=None) -> Value:
        if label:
            n = QLabel(label)
            n.setObjectName("note")
            self._add(n)
        holder = QWidget()
        row = FlowLayout(holder, 4)
        self._add(holder)
        st = {"v": value}
        btns = {}

        def set_(v, silent=False):
            st["v"] = v
            for k, b in btns.items():
                b.setChecked(k == v)
            if not silent:
                cb(v) if cb else self.draw()
        for o in opts:
            v, t = (o[0], o[1]) if isinstance(o, (list, tuple)) else (o, o)
            b = QPushButton(str(t))
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, v=v: set_(v))
            row.addWidget(b)
            btns[v] = b
        set_(value, True)
        self.reg("choice", label, options=lambda: [{"value": k, "text": b.text()} for k, b in btns.items()],
                 get=lambda: st["v"], set=lambda v: set_(v), el=holder)
        val = Value(lambda: st["v"], set_, holder)
        val.btns = btns
        return val

    def check(self, label, value, cb=None) -> Value:
        ck = QCheckBox(label)
        ck.setChecked(bool(value))
        ck.setCursor(Qt.CursorShape.PointingHandCursor)
        self._add(ck)
        ck.toggled.connect(lambda v: cb(v) if cb else self.draw())

        def set_(v, silent=False):
            v = v is True or v in ("true", 1, "是", "1")
            if silent:
                ck.blockSignals(True)
            ck.setChecked(v)
            ck.blockSignals(False)
        self.reg("check", label, get=ck.isChecked, set=lambda v: set_(v), el=ck)
        return Value(ck.isChecked, set_, ck)

    def out(self) -> Out:
        lb = QLabel()
        lb.setObjectName("out")
        lb.setTextFormat(Qt.TextFormat.RichText)
        lb.setWordWrap(True)
        lb.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._add(lb)
        return Out(lb)

    def note(self, html: str) -> QLabel:
        n = QLabel(html)
        n.setObjectName("note")
        n.setWordWrap(True)
        n.setTextFormat(Qt.TextFormat.RichText)
        self._add(n)
        return n

    def legend(self, items) -> QLabel:
        html = "　".join(f"<span style='color:{qc(c).name()}'>■</span> {t}" for c, t in items)
        return self.note(html)

    # ---- 交互
    def interact(self, c: Canvas, hit=None, drag=None, click=None, hover=None, down=None, up=None, view=None, pan=None,
                 dbl=None, leave=None, wheel=None) -> None:
        """wheel(x, y, steps) 返回 True 表示滚轮已被占用（不再缩放视图）；steps 向上滚为正。"""
        st = {"cur": None, "last": None, "moved": False}
        stage = self.stage

        def pos(e):
            p = e.position()
            return p.x(), p.y()

        def handler(kind, e):
            if kind == "down":
                x, y = pos(e)
                cur = hit(x, y) if hit else None
                st.update(last=(x, y), moved=False)
                if not cur and view is not None:
                    cur = "__pan"
                st["cur"] = cur
                if not cur and not click:
                    st["last"] = None
                    return
                if down:
                    down(x, y, cur)
            elif kind == "move":
                x, y = pos(e)
                if st["last"] is None:
                    if hover:
                        hover(x, y)
                    if hit:
                        stage.setCursor(Qt.CursorShape.OpenHandCursor if hit(x, y) else
                                        (Qt.CursorShape.SizeAllCursor if view is not None else Qt.CursorShape.ArrowCursor))
                    return
                dx, dy = x - st["last"][0], y - st["last"][1]
                if abs(dx) + abs(dy) > 1:
                    st["moved"] = True
                st["last"] = (x, y)
                if st["cur"] == "__pan":
                    kx, ky = dx / view.sx, dy / view.sy
                    view.r[0] -= kx
                    view.r[1] -= kx
                    view.r[2] += ky
                    view.r[3] += ky
                    self.draw()
                    if pan:
                        pan()
                elif st["cur"]:
                    if drag:
                        drag(st["cur"], x, y, dx, dy)
                    self.draw()
            elif kind == "up":
                if st["last"] is None:
                    return
                x, y = pos(e)
                if not st["moved"] and click:
                    click(x, y, st["cur"])
                if up:
                    up(st["cur"])
                st.update(cur=None, last=None)
                self.draw()
            elif kind == "wheel" and wheel and wheel(e.position().x(), e.position().y(), e.angleDelta().y() / 120):
                self.draw()
            elif kind == "wheel" and view is not None:
                p = e.position()
                wx, wy = view.ix(p.x()), view.iy(p.y())
                k = math.exp(-e.angleDelta().y() * 0.0012)
                r = view.r
                view.r = [wx + (r[0] - wx) * k, wx + (r[1] - wx) * k, wy + (r[2] - wy) * k, wy + (r[3] - wy) * k]
                self.draw()
                if pan:
                    pan()
            elif kind == "leave" and leave:
                leave()
            elif kind == "dbl" and dbl:
                p = e.position()
                dbl(p.x(), p.y())
                self.draw()
            elif kind == "dbl" and view is not None:
                view.reset()
                self.draw()
                if pan:
                    pan()
        stage.mouse = handler

    def orbit(self, c: Canvas, cam) -> None:
        st = {"last": None}
        self.stage.setCursor(Qt.CursorShape.OpenHandCursor)

        def handler(kind, e):
            if kind == "down":
                p = e.position()
                st["last"] = (p.x(), p.y())
            elif kind == "move" and st["last"] is not None:
                p = e.position()
                cam.yaw += (p.x() - st["last"][0]) * 0.01
                cam.pitch = clamp(cam.pitch + (p.y() - st["last"][1]) * 0.01, -1.5, 1.5)
                st["last"] = (p.x(), p.y())
                self.draw()
            elif kind == "up":
                st["last"] = None
            elif kind == "wheel":
                cam.scale = clamp(cam.scale * math.exp(e.angleDelta().y() * 0.001), 0.3, 4)
                self.draw()
        self.stage.mouse = handler


def _unused():
    _ = (QColor, QPointF)
