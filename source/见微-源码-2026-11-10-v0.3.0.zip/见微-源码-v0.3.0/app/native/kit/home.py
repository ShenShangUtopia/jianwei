"""见微的数据目录（配置、画板存档、错题本……）。测试时用 JIANWEI_HOME 指向临时目录。"""
from __future__ import annotations

import json
import os
from pathlib import Path


def home() -> Path:
    p = Path(os.environ.get("JIANWEI_HOME") or (Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "Jianwei"))
    p.mkdir(parents=True, exist_ok=True)
    return p


def load_json(name: str, default=None):
    try:
        return json.loads((home() / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def save_json(name: str, data) -> None:
    """先写临时文件再替换，避免写到一半崩溃留下坏文件。"""
    path = home() / name
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)
