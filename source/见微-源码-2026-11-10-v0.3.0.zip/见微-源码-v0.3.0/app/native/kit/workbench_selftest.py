"""五个工作台状态、参考图/批注和跨窗口传输验收。"""
from __future__ import annotations

from . import test_runtime
test_runtime.configure()

import json
import os
import sys
import tempfile
from unittest.mock import patch
from pathlib import Path

from PySide6.QtGui import QImage, QColor

from .clip import ClipBus
from . import state_graph, pen


def main(root=None):
    root = Path(root or tempfile.mkdtemp(prefix="jw-work-transfer-"))
    root.mkdir(parents=True,exist_ok=True)
    os.environ["JIANWEI_HOME"] = str(root/"home")
    os.environ["LOCALAPPDATA"] = str(root/"local")
    app = test_runtime.application()
    from ..lab.studio import Studio
    from ..lecture.board import BoardCanvas
    errors = []
    bus = ClipBus()
    bus.error.connect(errors.append)
    studio = Studio("day",bus)
    studio.resize(1440,900)
    studio.show()
    app.processEvents()
    failures = []
    def check(name,value):
        print("ok  " if value else "FAIL",name,flush=True)
        if not value:
            failures.append(name)
    shared = {}
    graph = {"a":shared,"b":shared,"keyed":{(1,2):3},"set":{"a","b"}}
    shared["back"] = graph
    decoded = state_graph.decode(json.loads(json.dumps(state_graph.encode(graph))))
    check("状态共享引用与循环",decoded["a"] is decoded["b"] and decoded["a"]["back"] is decoded and decoded["keyed"][(1,2)]==3 and decoded["set"]=={"a","b"})
    image = QImage(600,400,QImage.Format.Format_RGB32)
    image.fill(QColor("#DCE8FF"))
    reference = bus.store.create(image=image,text="参考题目")
    for bid in ("draw","scene","circ","phys","chem"):
        print("MOUNT",bid,flush=True)
        studio.open_bench(bid)
        for timer in studio.ctx.timers:
            timer.stop()
        app.processEvents()
        B,transfer = studio.B,studio.clip_transfer
        check(bid+" 初始化",not studio.ctx.stage.error)
        try:
            original = B.transfer_snapshot()
            restored = json.loads(json.dumps(original,ensure_ascii=False,allow_nan=False))
            B.transfer_restore(restored)
            check(bid+" 状态可序列化并还原",True)
            transfer.receive(reference)
            notes = transfer.notes
            if bid=="draw":
                with patch("native.kit.bench_transfer.QInputDialog.getDouble",return_value=(10.,True)):
                    transfer.calibrate()
                app.processEvents()
                item = notes.board["items"][-1]
                check("底图宽度标定",abs(item["w"]*notes.scale/studio.B.transfer_model.view["scale"]-10)<1e-6)
                from PySide6.QtCore import QPointF
                transfer.zoom_geometry(1.3,QPointF(250,200),QPointF(280,210))
                app.processEvents()
                model = studio.B.transfer_model
                check("底图随几何视图缩放平移",abs(item["x"]*notes.scale+notes.dx-model.X(0))<1e-6)
            stroke = pen.new_stroke("pen","red",3,True)
            pen.add_point(stroke,20,20,.2)
            pen.add_point(stroke,120,100,.8)
            notes.board["strokes"].append(stroke)
            notes._touch()
            snapshot = transfer.snapshot(vector=bid in ("draw","scene"))
            check(bid+" 快照包含笔迹与状态",bool(snapshot["ink"]) and bool(snapshot.get("state")))
            check(bid+" 来源可定位",snapshot["origin"]["ref"].get("clip_id")==snapshot["id"])
            if bid in ("draw","scene"):
                check(bid+" SVG 矢量资产",bus.store.asset(snapshot,"svg").is_file())
            board = BoardCanvas(root/(bid+"-board"))
            board.resize(900,600)
            board.clip_store = bus.store
            board.receive_clip(snapshot)
            check(bid+" 送黑板笔迹可编辑",len(board.board["strokes"])==len(snapshot["ink"]))
            board.save()
            board.saver.stop()
            from shiboken6 import delete
            delete(board)
            notes.board["strokes"] = []
            transfer.restore(snapshot)
            check(bid+" 来源快照还原批注",bool(transfer.notes.board["strokes"]))
            transfer.detach()
            app.processEvents()
            check(bid+" 独立画布保留总线",transfer.window is not None and transfer.notes.clip_store is bus.store)
            transfer.reattach()
            app.processEvents()
            studio.grab().save(str(root/(bid+".png")))
            check(bid+" 重绘无错误",not studio.ctx.stage.error)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            check(bid+" 异常 "+str(exc),False)
    studio.go_home()
    studio.close()
    check("无传输错误",not errors)
    if errors:
        print(errors,flush=True)
    print("WORK_TRANSFER","OK" if not failures else "FAIL "+repr(failures),flush=True)
    return int(bool(failures))


if __name__=="__main__":
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(lambda:main(sys.argv[1] if len(sys.argv)>1 else None)))
