"""通用数学工具与数值格式（对应旧 gewu/core.js 开头部分）。"""
from __future__ import annotations

import math
import random

PI = math.pi
TAU = 2 * math.pi
INF = math.inf

_SUP = str.maketrans("0123456789-+", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺")


def clamp(v, a, b):
    return a if v < a else b if v > b else v


def lerp(a, b, t):
    return a + (b - a) * t


def rnd(a=0.0, b=1.0):
    return a + random.random() * (b - a)


def gauss() -> float:
    return random.gauss(0.0, 1.0)


def finite(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v)


def _num(v: float) -> str:
    s = repr(float(v))
    if "e" in s or "inf" in s or "nan" in s:
        return s
    if s.endswith(".0"):
        s = s[:-2]
    return "0" if s in ("-0", "") else s


def sci(v: float, d: int = 2) -> str:
    """科学计数法：1.23×10⁻⁵（纯文本，上标用 Unicode）。"""
    if v == 0:
        return "0"
    e = math.floor(math.log10(abs(v)))
    m = round(v / 10 ** e, d)
    if abs(m) >= 10:
        m = round(m / 10, d)
        e += 1
    return f"{_num(m)}×10{str(e).translate(_SUP)}"


def fmt(v, d: int = 2) -> str:
    """和旧版 fmt 一样：很大或很小用科学计数法，否则最多 d 位小数、去掉多余的 0。"""
    if v is None or not finite(v):
        return "—"
    a = abs(v)
    if a != 0 and (a >= 1e6 or a < 1e-3):
        return sci(v, d)
    r = round(v, d)
    if r == 0:
        r = 0.0
    return _num(r)


def gcd(a: int, b: int) -> int:
    return math.gcd(int(abs(a)), int(abs(b)))


def comb(n: int, k: int) -> int:
    if k < 0 or k > n:
        return 0
    return math.comb(int(n), int(k))


def perm(n: int, k: int) -> int:
    if k < 0 or k > n:
        return 0
    return math.perm(int(n), int(k))


def nice_step(raw: float) -> float:
    if not raw or not math.isfinite(raw) or raw <= 0:
        return 1.0
    e = 10 ** math.floor(math.log10(raw))
    f = raw / e
    return (1 if f < 1.5 else 2 if f < 3 else 5 if f < 7 else 10) * e


def linspace(a: float, b: float, n: int) -> list[float]:
    if n <= 1:
        return [a]
    return [a + (b - a) * i / (n - 1) for i in range(n)]


def erf(x: float) -> float:
    return math.erf(x)


def Phi(z: float) -> float:
    """标准正态分布函数。"""
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))
