"""共享画笔阶段 1 回归：python -m native.kit.pen_selftest <隔离目录>。"""
from __future__ import annotations

from . import test_runtime

test_runtime.configure()

import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PySide6.QtCore import QLockFile, Qt
from PySide6.QtGui import QImage, QPainter
from PySide6.QtWidgets import QApplication

from . import pen
from .pen_store import PenStore, migrate_board, migrate_ink


def legacy(tool="pen"):
    return dict(tool=tool, color="#315fab", width=3.5, pressure=True,
                pts=[[10.12345, 20.56789, 0.23456], [50, 40, 0.9], [70, 25, 0.8]],
                custom={"note": "保留扩展"})


class PenTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=TEST_ROOT)
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, data):
        path = self.root / name
        path.write_bytes(b"\xef\xbb\xbf" + json.dumps(data, ensure_ascii=False).encode("utf-8"))
        return path

    def test_migration_is_lossless_and_detached(self):
        old = legacy()
        snapshot = copy.deepcopy(old)
        new = pen.migrate_stroke(old)
        self.assertEqual(new["points"], old["pts"])
        self.assertEqual(new["custom"], old["custom"])
        self.assertEqual(new["v"], 1)
        self.assertIsNone(new["t"])
        self.assertNotIn("pts", new)
        self.assertEqual(new, pen.migrate_stroke(new))
        self.assertEqual(new["id"], pen.migrate_stroke(old)["id"])
        new["points"][0][0] = -1
        new["custom"]["note"] = "改动"
        self.assertEqual(old, snapshot)

    def test_new_strokes_and_legacy_api(self):
        from ..lecture import ink
        s = ink.new_stroke("pen", "red", 2, True)
        self.assertIs(s["pts"], s["points"])
        ink.add_point(s, 1, 2, .5)
        self.assertEqual(s["pts"], [[1, 2, .5]])
        self.assertEqual(len(s["id"]), 32)
        self.assertGreater(s["t"], 0)
        self.assertIs(ink.History, pen.History)
        self.assertNotIn("pts", pen.migrate_stroke(s))

    def test_identical_legacy_strokes_keep_distinct_ids(self):
        strokes = pen.migrate_strokes([legacy(), legacy()])
        self.assertNotEqual(strokes[0]["id"], strokes[1]["id"])
        self.assertEqual(strokes, pen.migrate_strokes(strokes))

    def test_invalid_or_future_strokes_rejected(self):
        for changes in ({"v": 2}, {"width": float("nan")}, {"width": 0}, {"width": 10**400},
                        {"pts": [[1, 2]]}, {"color": "invalid-color"},
                        {"points": [[0, 0, 1]]}, {"tool": "unknown"}):
            with self.subTest(changes=changes), self.assertRaises(pen.PenDataError):
                pen.migrate_stroke(dict(legacy(), **changes))

    def test_legacy_visuals_unchanged(self):
        for tool in ("pen", "marker", "chalk"):
            old = legacy(tool)
            images = []
            for stroke in (old, pen.migrate_stroke(old)):
                image = QImage(120, 80, QImage.Format.Format_ARGB32_Premultiplied)
                image.fill(Qt.GlobalColor.white)
                p = QPainter(image)
                p.setRenderHint(QPainter.RenderHint.Antialiasing)
                pen.draw(p, stroke)
                p.end()
                images.append(image)
            self.assertEqual(images[0], images[1])
            self.assertEqual(pen.bounds(old), pen.bounds(pen.migrate_stroke(old)))
            self.assertTrue(pen.hit(old, 50, 40, 2))

    def test_history_identity_undo_redo(self):
        h = pen.History([legacy()])
        first = h.strokes[0]
        extra = pen.new_stroke("pen", "red", 2)
        h.add(extra)
        h.remove([first])
        self.assertEqual(h.strokes, [extra])
        self.assertTrue(h.undo())
        self.assertIs(h.strokes[0], first)
        self.assertTrue(h.undo())
        self.assertEqual(h.strokes, [first])
        self.assertTrue(h.redo())
        self.assertTrue(h.redo())
        self.assertEqual(h.strokes, [extra])
        h.undo()
        h.add(pen.new_stroke("pen", "blue", 3))
        self.assertFalse(h.redo())

    def test_ink_backup_and_roundtrip(self):
        path = self.write("ink.json", {"0": [legacy()], "3": []})
        original = path.read_bytes()
        store = PenStore(path, "ink")
        self.assertEqual(path.read_bytes(), original)  # 只读不迁移落盘
        self.assertFalse(store.readonly)
        store.save(store.data)
        backups = list(self.root.glob("ink.json.legacy-*.bak"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), original)
        self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["version"], 1)
        self.assertEqual(PenStore(path, "ink").data, store.data)
        store.save(store.data)
        self.assertEqual(len(list(self.root.glob("*.bak"))), 1)

    def test_board_extensions_and_items_survive(self):
        data = dict(boards=[dict(items=[dict(type="text", text="旧文字", x=1, y=2, w=3, h=4)],
                                 strokes=[legacy("chalk")], extension=42)], cur=0, custom=["root"])
        path = self.write("board.json", data)
        store = PenStore(path, "board")
        store.save(store.data)
        result = PenStore(path, "board").data
        self.assertEqual(result["boards"][0]["items"], data["boards"][0]["items"])
        self.assertEqual(result["custom"], ["root"])
        self.assertEqual(result["boards"][0]["extension"], 42)
        self.assertEqual(result["boards"][0]["strokes"][0]["points"], data["boards"][0]["strokes"][0]["pts"])

    def test_readonly_future_and_corrupt_files(self):
        for data in (dict(version=99, pages={}), {"0": [dict(legacy(), v=2)]},
                     {"bad-page": []}, {"0": [None]}):
            path = self.write("ink.json", data)
            before = path.read_bytes()
            store = PenStore(path, "ink")
            self.assertTrue(store.readonly)
            with self.assertRaises(pen.PenDataError):
                store.save(dict(version=1, pages={}))
            self.assertEqual(path.read_bytes(), before)
        path.write_bytes(b"{broken")
        self.assertTrue(PenStore(path, "ink").readonly)
        self.assertEqual(path.read_bytes(), b"{broken")

    def test_new_version_extensions(self):
        data = dict(version=1, pages={"0": [legacy()]}, origin={"ref": "future metadata"})
        self.assertEqual(migrate_ink(data)["origin"], data["origin"])
        with self.assertRaises(pen.PenDataError):
            migrate_ink({"0": [], "00": []})
        with self.assertRaises(pen.PenDataError):
            migrate_board(dict(version=2, boards=[]))

    def test_concurrent_window_does_not_overwrite(self):
        path = self.root / "ink.json"
        first, second = PenStore(path, "ink"), PenStore(path, "ink")
        first.save(dict(version=1, pages={"0": [legacy()]}))
        saved = path.read_bytes()
        with self.assertRaises(pen.PenDataError):
            second.save(second.data)
        self.assertEqual(path.read_bytes(), saved)
        self.assertTrue(second.readonly)

    def test_failed_commit_preserves_original(self):
        path = self.write("ink.json", {"0": [legacy()]})
        store = PenStore(path, "ink")
        before = path.read_bytes()
        with patch("native.kit.pen_store.QSaveFile.commit", return_value=False):
            with self.assertRaises(OSError):
                store.save(store.data)
        self.assertEqual(path.read_bytes(), before)
        store.save(store.data)
        self.assertFalse(PenStore(path, "ink").readonly)

    def test_busy_lock_preserves_file(self):
        path = self.write("ink.json", {})
        before = path.read_bytes()
        store = PenStore(path, "ink")
        lock = QLockFile(str(path) + ".lock")
        self.assertTrue(lock.tryLock(0))
        try:
            with self.assertRaises(pen.PenDataError):
                store.save(store.data)
        finally:
            lock.unlock()
        self.assertEqual(path.read_bytes(), before)

    def test_board_widget_legacy_reopen_and_undo(self):
        from ..lecture.board import BoardCanvas
        path = self.write("board.json", dict(boards=[dict(items=[], strokes=[legacy("chalk")])], cur=0))
        original = path.read_bytes()
        widget = BoardCanvas(self.root)
        self.assertEqual(len(widget.board["strokes"]), 1)
        widget.snapshot()
        widget.board["strokes"] = []
        widget.undo()
        self.assertEqual(widget.board["strokes"][0]["points"], legacy()["pts"])
        self.assertTrue(widget.save())
        reopened = BoardCanvas(self.root)
        self.assertEqual(reopened.board["strokes"], widget.board["strokes"])
        self.assertEqual(next(self.root.glob("*.bak")).read_bytes(), original)
        widget.saver.stop()
        reopened.saver.stop()
        widget.deleteLater()
        reopened.deleteLater()
        QApplication.processEvents()


def main(root=None):
    global TEST_ROOT
    TEST_ROOT = Path(root or tempfile.mkdtemp(prefix="jw-pen-test-"))
    TEST_ROOT.mkdir(parents=True, exist_ok=True)
    previous = {key: os.environ.get(key) for key in ("JIANWEI_HOME", "LOCALAPPDATA")}
    try:
        os.environ["JIANWEI_HOME"] = str(TEST_ROOT / "home")
        os.environ["LOCALAPPDATA"] = str(TEST_ROOT / "local")
        app = test_runtime.application([])
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(PenTests)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        app.processEvents()
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
    print("PEN_PHASE1", "OK" if result.wasSuccessful() else "FAIL", result.testsRun, flush=True)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(lambda:main(sys.argv[1] if len(sys.argv) > 1 else None)))
