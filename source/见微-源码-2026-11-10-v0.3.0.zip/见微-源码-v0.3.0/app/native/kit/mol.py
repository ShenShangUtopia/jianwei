"""分子球棍模型：CPK 配色、按深度排序绘制原子 / 化学键 / 孤电子对，以及「选分子 + 旋转查看」的通用实验骨架。"""
from __future__ import annotations

import math

from ..design.tokens import T, alpha
from .core import PI, TAU
from .draw import D
from .view import Cam3, v3

CPK = {"H": ("#f0f0f0", 0.28), "C": ("#4a4a4a", 0.42), "N": ("#3a5cf0", 0.42), "O": ("#e8301e", 0.42), "F": ("#7fd34e", 0.38),
       "Cl": ("#30c030", 0.5), "S": ("#e8c020", 0.5), "P": ("#f08020", 0.5), "B": ("#f5a5a5", 0.4), "Xe": ("#5aa0c0", 0.5),
       "Na": ("#ab5cf2", 0.5), "Cs": ("#57178f", 0.5)}


def norm(a):
    ln = math.hypot(*a) or 1
    return [x / ln for x in a]


def bdir(r, th, ph, hint=(0, 0, 1)):
    """与方向 r 成 th 度、绕 r 转 ph 度的单位向量（构造四面体、交叉式构象用）。"""
    r = norm(r)
    u = v3.sub(list(hint), v3.mul(r, v3.dot(list(hint), r)))
    if v3.len(u) < 1e-6:
        u = v3.sub([0, 1, 0], v3.mul(r, v3.dot([0, 1, 0], r)))
    u = norm(u)
    w = v3.cross(r, u)
    th, ph = th * PI / 180, ph * PI / 180
    return v3.add(v3.mul(r, math.cos(th)), v3.add(v3.mul(u, math.sin(th) * math.cos(ph)), v3.mul(w, math.sin(th) * math.sin(ph))))


def mol_from(center, ligs, lps=None, **extra) -> dict:
    """中心原子 + 配体 [(元素, 方向, 键长, 键级)]，孤电子对方向列表。"""
    atoms = [{"e": center, "p": [0.0, 0.0, 0.0]}]
    bonds = []
    for lig in ligs:
        e, d, ln = lig[0], lig[1], lig[2]
        order = lig[3] if len(lig) > 3 else 1
        atoms.append({"e": e, "p": v3.mul(norm(d), ln)})
        bonds.append((0, len(atoms) - 1, order))
    return {"atoms": atoms, "bonds": bonds, "lps": [(0, norm(d)) for d in (lps or [])], **extra}


def mk(atoms, bonds, name, rows) -> dict:
    return {"atoms": [{"e": a[0], "p": a[1], "hl": len(a) > 2 and a[2]} for a in atoms], "bonds": bonds, "name": name, "rows": rows, "lps": []}


_T = 1.9106
TET = [[0, 1, 0]] + [[math.sin(_T) * math.cos(a * PI / 180), math.cos(_T), math.sin(_T) * math.sin(a * PI / 180)] for a in (0, 120, 240)]
TRI = [[math.cos((a + 90) * PI / 180), math.sin((a + 90) * PI / 180), 0] for a in (0, 120, 240)]


def draw_mol(c, cam: Cam3, M: dict, s: float, show_lp: bool) -> None:
    g = c.g
    P = [cam.proj(a["p"], c, s) for a in M["atoms"]]
    items = []
    for i, j, o in M["bonds"]:
        def bond(i=i, j=j, o=o):
            a, b = P[i], P[j]
            dx, dy = b[0] - a[0], b[1] - a[1]
            ln = math.hypot(dx, dy) or 1
            nx, ny = -dy / ln, dx / ln
            offs = [-3.5, 3.5] if o == 2 else [-5, 0, 5] if o == 3 else [0]
            for k in offs:
                D.line(g, a[0] + nx * k, a[1] + ny * k, b[0] + nx * k, b[1] + ny * k, T.muted, 4 if o == 1.5 else 3.2)
            if o == 1.5:
                D.line(g, a[0] + nx * 5, a[1] + ny * 5, b[0] + nx * 5, b[1] + ny * 5, T.muted, 1.4, [3, 3])
        items.append(((P[i][2] + P[j][2]) / 2 - 0.01, bond))
    if show_lp:
        for i, d in M.get("lps", []):
            tip = v3.add(M["atoms"][i]["p"], v3.mul(d, 0.75))
            q = cam.proj(tip, c, s)

            def lone(i=i, q=q):
                a = P[i]
                g.save()
                g.translate((a[0] + q[0]) / 2, (a[1] + q[1]) / 2)
                g.rotate(math.atan2(q[1] - a[1], q[0] - a[0]))
                g.begin_path()
                g.ellipse(0, 0, math.hypot(q[0] - a[0], q[1] - a[1]) / 2 + 6, 9 * q[3])
                g.fill_style = alpha(T.c5, 0.28)
                g.fill()
                g.stroke_style, g.line_width = alpha(T.c5, 0.6), 1
                g.stroke()
                D.circle(g, 2, -3, 1.8, T.c5)
                D.circle(g, 2, 3, 1.8, T.c5)
                g.restore()
            items.append((q[2], lone))
    for i, a in enumerate(M["atoms"]):
        def atom(i=i, a=a):
            col, r0 = CPK.get(a["e"], ("#999999", 0.4))
            r = r0 * s * cam.scale * P[i][3] * M.get("scale", 1)
            x, y = P[i][0], P[i][1]
            D.ball(g, x, y, r, col, alpha(T.fg, 0.35))
            if a.get("lab", True) and r > 9:
                dark = a["e"] in ("H", "S", "F", "B")
                D.text(g, a["e"], x, y, "#222222" if dark else "#ffffff", align="center", bold=True, size=min(13, r * 0.8))
            if a.get("hl"):
                D.circle(g, x, y, r + 4, None, T.c4, 2.4)
        items.append((P[i][2], atom))
    items.sort(key=lambda it: it[0])
    for _z, f in items:
        f()


def mol_viewer(L, mols: dict, first: str) -> None:
    """选一个分子、拖动旋转查看；右侧读数是分子自带的说明行。"""
    c = L.canvas()
    cam = Cam3(yaw=0.4, pitch=0.25, persp=0.05)
    L.orbit(c, cam)
    sel = L.select("分子", [[k, v["name"]] for k, v in mols.items()], first)
    lp = L.check("显示孤电子对", True)
    spin = L.check("自动旋转", True)
    out = L.out()
    L.note("拖动画布旋转，滚轮缩放。")

    def tick(dt):
        if spin.v:
            cam.yaw += dt * 0.5
            L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        M = mols[sel.v]
        ext = max(v3.len(a["p"]) for a in M["atoms"]) + 0.6
        draw_mol(c, cam, M, min(c.w, c.h) / (2.6 * ext), lp.v)
        out.set(M["rows"])
    L.on_draw(draw)


H = "H"
MOLS = {
    "co2": mol_from("C", [["O", [1, 0, 0], 1.16, 2], ["O", [-1, 0, 0], 1.16, 2]], [], name="CO₂ 二氧化碳",
                    rows=[["σ 键 + 孤电子对", "2 + 0 = 2"], ["VSEPR 模型", "直线形"], ["空间结构", "直线形"], ["中心原子杂化", "sp"], ["键角", "180°"], ["分子极性", "非极性分子"]]),
    "h2o": mol_from("O", [[H, [math.sin(0.912), -math.cos(0.912), 0], 0.96], [H, [-math.sin(0.912), -math.cos(0.912), 0], 0.96]], [[0, 0.58, 0.82], [0, 0.58, -0.82]],
                    name="H₂O 水", rows=[["σ 键 + 孤电子对", "2 + 2 = 4"], ["孤电子对数", "(6 − 2×1)/2 = 2"], ["VSEPR 模型", "四面体形"], ["空间结构", "V 形"],
                                       ["杂化", "sp³"], ["键角", "104.5°"], ["分子极性", "极性分子"]]),
    "nh3": mol_from("N", [[H, v3.add(d, [0, -0.05, 0]), 1.01] for d in TET[1:]], [[0, 1, 0]], name="NH₃ 氨",
                    rows=[["σ 键 + 孤电子对", "3 + 1 = 4"], ["孤电子对数", "(5 − 3×1)/2 = 1"], ["VSEPR 模型", "四面体形"], ["空间结构", "三角锥形"], ["杂化", "sp³"],
                          ["键角", "107°"], ["分子极性", "极性分子"]]),
    "ch4": mol_from("C", [[H, d, 1.09] for d in TET], [], name="CH₄ 甲烷",
                    rows=[["σ 键 + 孤电子对", "4 + 0 = 4"], ["VSEPR 模型", "正四面体形"], ["空间结构", "正四面体形"], ["杂化", "sp³"], ["键角", "109°28′"], ["分子极性", "非极性分子"]]),
    "nh4": mol_from("N", [[H, d, 1.03] for d in TET], [], name="NH₄⁺ 铵根离子",
                    rows=[["σ 键 + 孤电子对", "4 + 0 = 4"], ["孤电子对数", "(5 − 1 − 4×1)/2 = 0"], ["空间结构", "正四面体形"], ["杂化", "sp³"], ["说明", "N 提供孤电子对与 H⁺ 形成配位键"]]),
    "h3o": mol_from("O", [[H, v3.add(d, [0, -0.1, 0]), 0.98] for d in TET[1:]], [[0, 1, 0]], name="H₃O⁺ 水合氢离子",
                    rows=[["σ 键 + 孤电子对", "3 + 1 = 4"], ["孤电子对数", "(6 − 1 − 3×1)/2 = 1"], ["空间结构", "三角锥形"], ["杂化", "sp³"], ["说明", "含配位键"]]),
    "bf3": mol_from("B", [["F", d, 1.31] for d in TRI], [], name="BF₃ 三氟化硼",
                    rows=[["σ 键 + 孤电子对", "3 + 0 = 3"], ["孤电子对数", "(3 − 3×1)/2 = 0"], ["空间结构", "平面三角形"], ["杂化", "sp²"], ["键角", "120°"], ["分子极性", "非极性分子"]]),
    "so2": mol_from("S", [["O", [math.sin(1.04), -math.cos(1.04), 0], 1.43, 2], ["O", [-math.sin(1.04), -math.cos(1.04), 0], 1.43, 2]], [[0, 1, 0]], name="SO₂ 二氧化硫",
                    rows=[["σ 键 + 孤电子对", "2 + 1 = 3"], ["孤电子对数", "(6 − 2×2)/2 = 1"], ["VSEPR 模型", "平面三角形"], ["空间结构", "V 形"], ["杂化", "sp²"],
                          ["键角", "约 119°"], ["分子极性", "极性分子"]]),
    "so3": mol_from("S", [["O", d, 1.42, 2] for d in TRI], [], name="SO₃ 三氧化硫",
                    rows=[["σ 键 + 孤电子对", "3 + 0 = 3"], ["孤电子对数", "(6 − 3×2)/2 = 0"], ["空间结构", "平面三角形"], ["杂化", "sp²"], ["分子极性", "非极性分子"]]),
    "pcl5": mol_from("P", [["Cl", [0, 1, 0], 2.1], ["Cl", [0, -1, 0], 2.1]] + [["Cl", [math.cos(a * PI / 180), 0, math.sin(a * PI / 180)], 2.02] for a in (0, 120, 240)],
                     [], name="PCl₅ 五氯化磷", rows=[["价层电子对数", "5"], ["空间结构", "三角双锥形"], ["键角", "90°、120°"], ["说明", "中心原子价层超过 8 电子"]]),
    "sf6": mol_from("S", [["F", d, 1.56] for d in ([1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1])], [], name="SF₆ 六氟化硫",
                    rows=[["价层电子对数", "6"], ["空间结构", "正八面体形"], ["键角", "90°"], ["分子极性", "非极性分子"]]),
}


def _unused():
    _ = TAU
