"""共享内容包与显式注入的传输总线；所有持久资产留在用户 clips 目录。"""
from __future__ import annotations

import copy
import json
import math
import re
import time
import uuid
from pathlib import Path

from PySide6.QtCore import QByteArray, QBuffer, QIODevice, QMimeData, QObject, QRectF, QSize, Qt, QSaveFile, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QFont

from .home import home
from . import pen

MIME = "application/x-jianwei-clip"
TOKEN = re.compile(r"^[0-9a-f]{32}$")


def write_json(path,data):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    raw = json.dumps(data,ensure_ascii=False,allow_nan=False).encode("utf-8")
    target = QSaveFile(str(path))
    target.setDirectWriteFallback(False)
    if not target.open(QIODevice.OpenModeFlag.WriteOnly):
        raise OSError(target.errorString())
    if target.write(raw) != len(raw):
        target.cancelWriting()
        raise OSError(target.errorString())
    if not target.commit():
        raise OSError(target.errorString())


def read_json(path,default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return copy.deepcopy(default)


class ClipStore:
    def __init__(self,root=None):
        self.root = Path(root) if root else home()/"clips"
        self.root.mkdir(parents=True,exist_ok=True)
        self._summaries = {}

    def path(self,cid):
        if not isinstance(cid,str) or not TOKEN.fullmatch(cid):
            raise ValueError("素材编号无效")
        return self.root/cid

    def asset(self,clip,name):
        value = clip.get(name)
        if not isinstance(value,str) or Path(value).name != value or "/" in value or "\\" in value:
            raise ValueError("素材资产路径无效")
        return self.path(clip["id"])/value

    def load(self,cid):
        value = read_json(self.path(cid)/"clip.json")
        if not isinstance(value,dict) or value.get("v") != 1 or value.get("id") != cid:
            raise ValueError("素材已不存在或版本不支持")
        space = value.get("space") or {}
        if not all(isinstance(space.get(k),(int,float)) and math.isfinite(space[k]) and 0 < space[k] <= 50000 for k in ("width","height")):
            raise ValueError("素材尺寸无效")
        value["ink"] = pen.migrate_strokes(value.get("ink",[]))
        for name in ("image","svg","state"):
            if value.get(name):
                self.asset(value,name)
        self._summaries[cid] = {key:value.get(key) for key in ("text","origin","kind")}
        return value

    def summary(self,cid):
        if cid not in self._summaries:
            self.load(cid)
        return self._summaries[cid]

    def create(self,image=None,ink=None,text="",origin=None,width=None,height=None,svg=None,state=None):
        if origin is not None and (not isinstance(origin,dict) or not isinstance(origin.get("ref",{}),dict)):
            raise ValueError("素材来源无效")
        cid = uuid.uuid4().hex
        folder = self.path(cid)
        folder.mkdir()
        if image is not None and not image.isNull():
            width = width or image.width()
            height = height or image.height()
        width,height = float(width or 800),float(height or 450)
        if not all(math.isfinite(n) and 0 < n <= 50000 for n in (width,height)):
            raise ValueError("素材尺寸无效")
        strokes = pen.migrate_strokes(ink or [])
        clip = dict(v=1,id=cid,kind="bundle" if strokes and (image is not None or text) else
                    "ink" if strokes else "image" if image is not None else "text",
                    ink=strokes,text=str(text),origin=copy.deepcopy(origin or {}),created=time.time(),
                    space=dict(unit="logical",width=width,height=height))
        if image is not None and not image.isNull():
            if not image.save(str(folder/"image.png")):
                raise OSError("素材图片未能保存")
            clip["image"] = "image.png"
        if svg:
            (folder/"drawing.svg").write_bytes(bytes(svg))
            clip["svg"] = "drawing.svg"
        if state is not None:
            write_json(folder/"state.json",state)
            clip["state"] = "state.json"
        write_json(folder/"clip.json",clip)
        return clip

    def render(self,clip,size=None,include_ink=True):
        w,h = clip["space"]["width"],clip["space"]["height"]
        size = size or QSize(max(1,int(w)),max(1,int(h)))
        factor = min(1,6000/max(1,size.width(),size.height()),math.sqrt(16_000_000/max(1,size.width()*size.height())))
        if factor < 1:
            size = QSize(max(1,int(size.width()*factor)),max(1,int(size.height()*factor)))
        image = QImage(size,QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        p = QPainter(image)
        p.setRenderHints(QPainter.RenderHint.Antialiasing|QPainter.RenderHint.SmoothPixmapTransform)
        p.scale(size.width()/w,size.height()/h)
        rect = QRectF(0,0,w,h)
        p.setClipRect(rect)
        if clip.get("svg"):
            from PySide6.QtSvg import QSvgRenderer
            renderer = QSvgRenderer(str(self.asset(clip,"svg")))
            if renderer.isValid():
                renderer.render(p,rect)
        elif clip.get("image"):
            p.drawImage(rect,QImage(str(self.asset(clip,"image"))))
        elif clip.get("text"):
            p.fillRect(rect,QColor("#FFFDF9"))
            p.setPen(QColor("#0B1F4F"))
            font = QFont("Microsoft YaHei")
            font.setPixelSize(max(14,min(28,int(w/25))))
            p.setFont(font)
            p.drawText(rect.adjusted(20,20,-20,-20),int(Qt.TextFlag.TextWordWrap),clip["text"])
        if include_ink:
            for stroke in clip.get("ink",[]):
                pen.draw(p,stroke)
        p.end()
        return image

    def mime(self,clip):
        mime = QMimeData()
        # MIME 携带来源与矢量笔迹；本机编号提供不可变图像/SVG/状态资产。
        metadata = {key:clip.get(key) for key in ("v","id","kind","origin","ink","text","space","created")}
        mime.setData(MIME,QByteArray(json.dumps(metadata,ensure_ascii=False,allow_nan=False).encode("utf-8")))
        mime.setImageData(self.render(clip,QSize(1000,max(1,int(1000*clip["space"]["height"]/clip["space"]["width"])))))
        if clip.get("text"):
            mime.setText(clip["text"])
        return mime

    def from_mime(self,mime):
        if mime.hasFormat(MIME):
            raw = bytes(mime.data(MIME))
            if len(raw)>8*1024*1024:
                raise ValueError("素材信息过大")
            data = json.loads(raw)
            if not isinstance(data,dict) or data.get("v") != 1:
                raise ValueError("素材版本不支持")
            cid = data.get("id")
            if (self.path(cid)/"clip.json").is_file():
                return self.load(cid)
            if mime.hasImage():
                space = data.get("space") or {}
                return self.create(image=QImage(mime.imageData()),ink=data.get("ink",[]),origin=data.get("origin",{}),
                                   text=data.get("text",""),width=space.get("width"),height=space.get("height"))
            raise ValueError("素材原资产已不存在")
        if mime.hasImage():
            image = QImage(mime.imageData())
            if image.isNull() or image.width()*image.height()>40_000_000:
                raise ValueError("图片无效或过大")
            return self.create(image=image)
        if mime.hasText() and mime.text().strip():
            return self.create(text=mime.text()[:100000])
        raise ValueError("剪贴板没有可用的素材")


class ClipBus(QObject):
    sent = Signal(object,str,object)
    changed = Signal()
    origin_requested = Signal(object)
    error = Signal(str)
    basket_requested = Signal()

    def __init__(self,parent=None,store=None):
        super().__init__(parent)
        self.store = store or ClipStore()

    def recent(self):
        data = read_json(self.store.root/"basket.json",dict(v=1,items=[]))
        if not isinstance(data,dict) or data.get("v") != 1 or not isinstance(data.get("items"),list):
            raise ValueError("素材篮版本不支持，已保留原文件")
        return data["items"]

    def remember(self,clip):
        items = self.recent()
        previous = next((x for x in items if x["id"]==clip["id"]),{})
        items = [dict(id=clip["id"],pinned=previous.get("pinned",False),created=time.time())]+[x for x in items if x["id"]!=clip["id"]]
        pinned = [x for x in items if x.get("pinned")]
        normal = [x for x in items if not x.get("pinned")][:30]
        write_json(self.store.root/"basket.json",dict(v=1,items=pinned+normal))
        self.changed.emit()

    def pin(self,cid,on):
        items = self.recent()
        for item in items:
            if item["id"]==cid:
                item["pinned"] = on
        write_json(self.store.root/"basket.json",dict(v=1,items=items))
        self.changed.emit()

    def send(self,clip,target,context=None):
        try:
            clip = self.store.load(clip["id"])
            self.remember(clip)
            self.sent.emit(clip,target,context)
        except (OSError,ValueError,TypeError,KeyError) as exc:
            self.error.emit(str(exc))


def png_bytes(image):
    buffer = QBuffer()
    buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(buffer,"PNG")
    return bytes(buffer.data())
