"""工作台外壳验收：画布铺满、浮窗开合、分页与搜索、不遮挡、拖放让位、窄窗、独立画布、偏好保存。"""
from __future__ import annotations

from . import test_runtime
test_runtime.configure()

import os
import sys
import tempfile
import time
from pathlib import Path


def main(root=None):
    root = Path(root or tempfile.mkdtemp(prefix="jw-bench-ui-"))
    root.mkdir(parents=True, exist_ok=True)
    os.environ["JIANWEI_HOME"] = str(root / "home")
    os.environ["LOCALAPPDATA"] = str(root / "local")
    app = test_runtime.application()
    from PySide6.QtCore import QPointF, Qt
    from PySide6.QtGui import QDrag, QMouseEvent
    from ..main_win import NativeWindow
    from .bench import PalItem, Palette, TABS, bench
    from .bench_ui import LEFT_W, RAIL_W

    failures = []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        if not ok:
            failures.append(name)

    def spin(n=6):
        for _ in range(n):
            app.processEvents()
            time.sleep(.005)

    win = NativeWindow("day")
    win.resize(1440, 900)
    win.show()
    spin()

    # ---- 画布铺满
    studio = win.goto("bench", "chem")
    chrome = studio.chrome
    chrome.anim_ms = 0
    chrome.set_left(True)
    chrome.set_right(True)
    spin()
    stage = studio.ctx.stage
    check("窄栏收起", not win.rail.isVisible())
    check("顶栏、目录、标题条收起", not studio.topbar.isVisible() and not studio.drawer.isVisible() and not studio.head_row.isVisible())
    check("实验侧栏不显示", not studio.side.isVisible())
    check("画布等于整个窗口", stage.size() == win.size(), f"{stage.size()} vs {win.size()}")
    check("浮窗盖在画布上", chrome.lpanel.isVisible() and chrome.rpanel.isVisible() and chrome.lpanel.parent() is studio.exp_page)

    # ---- 分页
    pal = chrome.pal
    check("化学有试剂、物品、实验三页", pal.tabs() == list(TABS), pal.tabs())
    labels = {b.it["label"] for b in pal.all}
    check("试剂页含稀盐酸", any(b.it["label"].startswith("稀盐酸") and pal.pages["reagent"].body.isAncestorOf(b) for b in pal.all), sorted(labels)[:5])
    check("物品页含烧杯", any(b.it["label"] == "烧杯" and pal.pages["item"].body.isAncestorOf(b) for b in pal.all))
    check("实验页是单列", pal.pages["exp"].cols == 1 and pal.pages["item"].cols == 2)
    for bid, want in (("circ", ["item", "exp"]), ("phys", ["item", "exp"]), ("scene", ["item", "exp"]), ("draw", ["item", "exp"])):
        studio.open_bench(bid)
        spin()
        p = chrome.pal
        check(f"{bid} 的分页", p.tabs() == want, p.tabs())
        check(f"{bid} 没有试剂键", not chrome.lkeys["reagent"].isVisible() and chrome.lkeys["item"].isVisible())
        check(f"{bid} 每页都有内容", all(any(p.pages[t].body.isAncestorOf(b) for b in p.all) for t in want))
        check(f"{bid} 无绘制错误", not studio.ctx.stage.error, studio.ctx.stage.error)
        from PySide6.QtWidgets import QWidget
        adjust = chrome.adjust.widget()
        chrome.set_right(True)
        chrome._show_right_tab("tune")
        spin()
        from PySide6.QtCore import Qt as _Qt
        lost = [w for w in adjust.findChildren(QWidget) if w.isHidden() and not w.testAttribute(_Qt.WidgetAttribute.WA_WState_ExplicitShowHide)]
        shown = [w for w in adjust.findChildren(QWidget) if w.isVisible()]
        check(f"{bid} 调整页控件都显示出来", len(shown) > 3 and not lost, (len(shown), [type(w).__name__ for w in lost][:5]))
    check("电路的物品页叫元件", (studio.open_bench("circ"), chrome.pal.labels["item"])[1] == "元件")
    check("工作台名跟着换", chrome.bench_btn.text() == bench.by_id["circ"].title)
    studio.open_bench("chem")
    spin()
    pal = chrome.pal
    stage = studio.ctx.stage

    # ---- 开合
    chrome.lkeys["item"].click()
    spin()
    check("点键打开对应页", pal.cur == "item" and chrome.lpanel.isVisible() and chrome.lkeys["item"].isChecked())
    check("标题跟着换", chrome.lpanel.title.text() == "物品")
    wide = stage.safe[0]
    chrome.lkeys["item"].click()
    spin()
    check("再点一次收起", not chrome.lpanel.isVisible() and not chrome.lkeys["item"].isChecked())
    check("收起后键栏还在", chrome.lrail.isVisible())
    check("收起后避让范围变小", stage.safe[0] < wide and stage.safe[0] == 10 + RAIL_W + 6, stage.safe)
    chrome.lkeys["exp"].click()
    spin()
    check("收起时点别的键直接打开", chrome.lpanel.isVisible() and pal.cur == "exp")
    chrome.lpanel.close_btn.click()
    spin()
    check("浮窗上的收起键", not chrome.lpanel.isVisible())
    chrome.rkeys["note"].click()
    spin()
    check("右侧切到说明", chrome.rpanel.isVisible() and chrome.rpanel.stack.currentIndex() == 1 and chrome.rkeys["note"].isChecked())
    check("说明里有工作台介绍和试试看", "可以试试" in chrome.info.toPlainText())
    chrome.rkeys["tune"].click()
    spin()
    check("右侧切到调整", chrome.rpanel.stack.currentIndex() == 0)
    check("调整页就是检查器", chrome.adjust.widget() is not None and studio.ctx.panel_lay.count() > 0)
    chrome.toggle_left("reagent")
    spin()

    # ---- 搜索跨页
    pal.search.setText("烧杯")
    spin()
    check("搜索跳到有结果的页", pal.cur == "item" and chrome.lpanel.title.text() == "物品", pal.cur)
    shown = [b for b in pal.pages["item"].body.findChildren(PalItem) if not b.isHidden()]
    check("只留匹配的键", "烧杯" in [b.it["label"] for b in shown] and "试管" not in [b.it["label"] for b in shown], [b.it["label"] for b in shown])
    check("重排不留空洞", pal.pages["item"].groups[0][2].itemAtPosition(0, 0).widget() is shown[0])
    pal.search.setText("NaOH")
    spin()
    check("能搜化学式", pal.cur == "reagent" and any(b.it["label"].startswith("氢氧化钠") and not b.isHidden() for b in pal.all))
    pal.search.setText("没有这种东西")
    spin()
    check("没结果时给提示", pal.stack.currentWidget() is pal.empty)
    pal.search.clear()
    spin()
    check("清空后全部回来", all(not b.isHidden() for b in pal.pages["reagent"].body.findChildren(PalItem)))

    # ---- 不遮挡
    chrome.set_left(True)
    chrome.set_right(True)
    spin()
    left, top, right, _b = stage.safe
    check("避让范围覆盖浮窗", left >= chrome.lpanel.geometry().right() and stage.width() - right <= chrome.rpanel.geometry().left(), stage.safe)
    check("顶条在避让范围内", top >= chrome.bar.geometry().bottom() and chrome.bar.isVisible(), (top, chrome.bar.geometry()))
    check("顶条不压浮窗", chrome.bar.geometry().left() >= chrome.lpanel.geometry().right() and chrome.bar.geometry().right() <= chrome.rpanel.geometry().left())
    beaker = next(b.it for b in pal.all if b.it["label"] == "烧杯")
    clear = next(b.it for b in pal.all if b.it["label"] == "清空台面")
    clear["click"]()
    spin()
    beaker["click"]()
    spin()
    stage.repaint()
    check("点素材不出错", not stage.error, stage.error)
    pixel = stage.grab(chrome.lpanel.geometry()).toImage()
    check("画布上有内容", not pixel.isNull())

    # 化学：台面上的东西都在露出的范围内
    from PySide6.QtCore import QObject  # noqa: F401
    panel_cover = chrome.lpanel.geometry().united(chrome.rpanel.geometry())
    check("两侧浮窗中间留出画布", panel_cover.width() > 0 and chrome.rpanel.geometry().left() - chrome.lpanel.geometry().right() > 500)

    # 电路：板子跟着让位
    studio.open_bench("circ")
    spin()
    b = studio.B
    studio.ctx.stage.repaint()
    check("电路板从浮窗右边开始", studio.ctx.stage.safe[0] > 300 and not studio.ctx.stage.error)
    chrome.set_left(False)
    spin()
    studio.ctx.stage.repaint()
    check("收起后电路仍正常", not studio.ctx.stage.error and b.safe()[0] < 100)
    chrome.set_left(True)
    spin()

    # ---- 选中态 / Esc
    key = next(i for i in chrome.pal.all if i.it.get("id") == "tool-res")
    key.it["click"]()
    spin()
    check("选中工具时键高亮", key.on)
    studio._esc()
    spin()
    check("Esc 回到选择工具，不退出工作台", studio.cur_bench is not None and not key.on and chrome.pal.items["tool-select"].on)
    chrome.pal.search.setFocus()
    chrome.pal.search.setText("电")
    studio.ctx.stage.setFocus()
    chrome.pal.search.clear()

    # ---- 拖放让位（OLE 拖放离屏跑不了：替换 exec，在里面检查并投放）
    studio.open_bench("chem")
    spin()
    pal, stage = chrome.pal, studio.ctx.stage
    chrome.toggle_left("item") if pal.cur != "item" else None
    chrome.set_left(True)
    spin()
    pal.show_tab("item")
    tile = next(b for b in pal.all if b.it["label"] == "烧杯")
    seen, n_before = {}, None
    real_exec = QDrag.exec

    def fake_exec(self, *_a, **_k):
        seen["left"], seen["right"] = chrome.lpanel.isVisible(), chrome.rpanel.isVisible()
        seen["mime"] = self.mimeData().hasFormat("application/x-jw-palette")
        stage.drop_fn(chrome.lpanel.geometry().center().x(), 400)   # 正好落在浮窗原来盖住的地方
        return Qt.DropAction.CopyAction
    QDrag.exec = fake_exec
    try:
        # 打包版没有 QtTest：直接发鼠标事件
        def mouse(kind, x, y, button):
            pos = QPointF(x, y)
            tile.event(QMouseEvent(kind, pos, tile.mapToGlobal(pos), button, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier))
        mouse(QMouseEvent.Type.MouseButtonPress, 20, 20, Qt.MouseButton.LeftButton)
        mouse(QMouseEvent.Type.MouseMove, 60, 60, Qt.MouseButton.NoButton)
        spin()
    finally:
        QDrag.exec = real_exec
    check("拖动时浮窗让开", seen.get("left") is False and seen.get("right") is False, seen)
    check("拖放数据正确", seen.get("mime") is True)
    check("松手后浮窗回来", chrome.lpanel.isVisible() and chrome.rpanel.isVisible())
    check("拖放无错误", not stage.error, stage.error)
    check("拖放后 dragging 复位", Palette.dragging is None)

    # ---- 不随画布重绘（否则实验动画时每帧都重画几十颗键）
    painted = []
    orig = PalItem.paintEvent

    def counting(self, e):
        painted.append(1)
        orig(self, e)
    spin(20)
    PalItem.paintEvent = counting
    try:
        for _ in range(10):
            stage.repaint()
            app.processEvents()
    finally:
        PalItem.paintEvent = orig
    check("画布重绘不牵动浮窗内容", len(painted) == 0, len(painted))

    # ---- 窄窗
    win.resize(1000, 640)
    spin()
    check("窄窗只留左侧浮窗", chrome.lpanel.isVisible() and not chrome.rpanel.isVisible())
    chrome.rkeys["tune"].click()
    spin()
    check("窄窗开右侧时左侧让位", chrome.rpanel.isVisible() and not chrome.lpanel.isVisible())
    check("窄窗顶条不越界", chrome.bar.geometry().left() >= 0 and chrome.bar.geometry().right() <= win.width())
    win.resize(1440, 900)
    chrome.set_left(True)
    chrome.set_right(True)
    spin()

    # ---- 批注
    tr = studio.clip_transfer
    check("默认不显示画笔工具", not tr.pen_bar.isVisible())
    h0 = chrome.bar.height()
    tr.enabled.setChecked(True)
    spin()
    check("开批注露出画笔工具", tr.pen_bar.isVisible() and chrome.bar.height() > h0)
    check("开批注后鼠标进批注层", not tr.notes.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents))
    tr.enabled.setChecked(False)
    spin()
    check("关批注恢复", not tr.pen_bar.isVisible() and chrome.bar.height() == h0)

    # ---- 独立画布
    tr.detach()
    spin()
    check("独立时画布进新窗口", studio.stage_host.window() is tr.window)
    check("独立时素材和调整留在主窗口", chrome.lpanel.window() is win and chrome.rpanel.window() is win)
    check("独立时没有遮挡", stage.safe == (0, 0, 0, 0), stage.safe)
    check("独立时给出提示", chrome.detached.isVisible())
    tr.reattach()
    spin()
    check("收回后画布回来", studio.stage_host.window() is win and stage.size() == win.size())
    check("收回后恢复避让", stage.safe[0] > 300)
    check("收回后顶条浮在上面", chrome.bar.window() is win and chrome.bar.isVisible() and chrome.bar.floating)
    check("收回后提示消失", not chrome.detached.isVisible())

    # ---- 模式切换
    win.goto("desk")
    spin()
    check("去习题时窄栏回来", win.rail.isVisible())
    win.goto("bench", "chem")
    spin()
    check("回工作台窄栏再收起", not win.rail.isVisible())
    win.goto("lab")
    spin()
    check("去实验首页恢复原版面", win.rail.isVisible() and studio.topbar.isVisible() and studio.drawer.isVisible() and not chrome.lrail.isVisible())
    studio.open(next(iter(__import__("native.kit.registry", fromlist=["lab"]).lab.list)).id)
    spin()
    check("普通实验的版面不变", studio.side.isVisible() and studio.head_row.isVisible() and not studio.ctx.stage.error)
    check("普通实验不被避让", studio.ctx.stage.safe == (0, 0, 0, 0))
    studio.go_home()
    home_pick = studio.home.picked
    home_pick.emit("bench:circ")
    spin()
    check("从实验首页进工作台也铺满", not win.rail.isVisible() and studio.ctx.stage.size() == win.size(), (win.rail.isVisible(), studio.ctx.stage.size(), win.size()))
    win.goto("lab")
    spin()

    # ---- 主题和偏好
    win.goto("bench", "chem")
    chrome.anim_ms = 0
    spin()
    chrome.toggle_right("note")
    chrome.set_right(False)
    studio.toggle_theme()
    spin()
    check("换夜间不出错", not studio.ctx.stage.error)
    studio.toggle_theme()
    spin()
    win.goto("lab")
    spin()
    from .home import load_json
    saved = load_json("workbench-ui.json", {})
    check("开合状态写入偏好", saved.get("right") is False and saved.get("rtab") == "note", saved)
    check("上次用的页按工作台记住", isinstance(saved.get("tabs"), dict) and "chem" in saved["tabs"], saved)
    _ = (LEFT_W, QPointF)
    win.shutdown()
    win.close()
    print("BENCH_UI", "OK" if not failures else "FAIL " + ",".join(failures), flush=True)
    return int(bool(failures))


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(lambda: main(sys.argv[1] if len(sys.argv) > 1 else None)))
