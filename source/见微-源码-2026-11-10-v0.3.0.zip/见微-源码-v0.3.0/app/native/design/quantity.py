"""讲题时「同一个量同一种颜色」：步骤文字里的 v、a、N…… 和仿真图上的箭头、标注用同一套颜色。

只按物理量的符号认：速度蓝、加速度橙、重力红、支持力绿、摩擦力紫、长度金、时间天蓝。
颜色取自当前主题的数据色，昼夜自动跟着变。
"""
from __future__ import annotations

import re

from .tokens import T

LENGTH = set("RLHhxsdry")
SUBS = str.maketrans("₀₁₂₃ₓᵧ", "0123xy")


def family(sym: str) -> str | None:
    """符号 → 颜色组名；认不出返回 None（不上色）。"""
    s = str(sym or "").strip().translate(SUBS)
    s = re.sub(r"[_{}]", "", s)
    if not s:
        return None
    if s in ("mg", "G", "Fg"):
        return "G"
    if s.startswith("F合") or s in ("F", "Fnet"):
        return "F"
    head = s[0]
    if head == "v" or head == "u":
        return "v"
    if s == "a" or (head == "a" and len(s) <= 3 and s[1:].isdigit()):
        return "a"
    if s == "N" or s.startswith("FN"):
        return "N"
    if s == "f" or s.startswith("f") and s[1:].isdigit():
        return "f"
    if head in ("t", "T") and len(s) <= 3:
        return "t"
    if head in LENGTH and len(s) <= 3:
        return "len"
    return None


TOKEN = dict(v="c1", a="c2", G="bad", N="c3", f="c5", F="fg", len="c4", t="c6")


def color(sym: str):
    """符号 → 颜色字符串（当前主题），认不出返回 None。"""
    fam = family(sym)
    return T[TOKEN[fam]] if fam else None
