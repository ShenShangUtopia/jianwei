"""见微 2.0 通用控件与样式表（全部从 tokens 取色，切主题后调用 qss() 重新套用）。"""
from __future__ import annotations

from PySide6.QtCore import QPoint, QPointF, QRect, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QLayout, QPushButton, QSizePolicy, QWidget, QWidgetItem

from .tokens import RADIUS, T, css, family, font, qc


def qss() -> str:
    """全部学习界面共用的样式表：冷瓷面板、细线，按键带实体下沿，按下时整体下沉 1 像素。"""
    t = T
    ui, mono = family("ui"), family("mono")
    sm = RADIUS["sm"]
    ac = qc(t.accent)
    ac_edge = ac.darker(135 if not t.dark else 160).name()
    ac_hover = ac.lighter(110).name()
    bad_soft = css(t.bad, .12)
    return f"""
QWidget#jw2 {{ background:{t.bg}; color:{t.fg}; font-family:"{ui}"; font-size:13px; }}
QToolTip {{ background:{t.fg}; color:{t.bg}; border:none; padding:5px 8px; font-size:12px; }}
QFrame#panel, QWidget#panel {{ background:{t.surface}; }}
QLabel {{ background:transparent; color:{t.fg}; }}
QLabel#grpTitle {{ color:{t.muted}; font-size:11.5px; font-weight:700; letter-spacing:1.2px; padding:2px 0 0 0; }}
QLabel#ctlLabel {{ color:{t.soft}; font-size:12.5px; }}
QLabel#ctlValue {{ color:{t.accent}; font-family:"{mono}"; font-size:12.5px; }}
QLabel#note {{ color:{t.muted}; font-size:12px; }}
QLabel#err {{ color:{t.bad}; font-size:11.5px; }}
QLabel#out {{ background:{t.raised}; border:1px solid {t.line}; border-radius:{RADIUS['md']}px; padding:8px 10px; }}

QPushButton, QPushButton#btn, QPushButton#seg {{ background:{t.raised}; color:{t.fg}; border:1px solid {t.line2}; border-bottom:2px solid {t.edge};
  border-radius:{sm}px; padding:5px 11px 4px 11px; font-size:12.5px; }}
QPushButton:hover, QPushButton#btn:hover, QPushButton#seg:hover {{ background:{t.hover}; border-color:{t.edge}; }}
QPushButton:pressed, QPushButton#btn:pressed, QPushButton#seg:pressed {{ background:{t.press}; border-bottom:1px solid {t.edge}; margin-top:1px; }}
QPushButton:checked, QPushButton#btn:checked, QPushButton#seg:checked {{ background:{t.accent}; color:{t.stage}; border-color:{ac_edge}; }}
QPushButton:disabled, QPushButton#btn:disabled, QPushButton#pri:disabled {{ background:{t.surface}; color:{t.faint}; border-color:{t.line}; }}
QPushButton:focus {{ outline:none; }}
QPushButton#pri {{ background:{t.accent}; color:{t.stage}; border:1px solid {ac_edge}; border-bottom:2px solid {ac_edge};
  border-radius:{sm}px; padding:5px 13px 4px 13px; font-size:12.5px; font-weight:700; }}
QPushButton#pri:hover {{ background:{ac_hover}; }}
QPushButton#pri:pressed {{ background:{t.accent}; border-bottom:1px solid {ac_edge}; margin-top:1px; }}
QPushButton#ghost {{ background:transparent; color:{t.soft}; border:1px solid transparent; }}
QPushButton#ghost:hover {{ background:{t.hover}; color:{t.fg}; }}
QPushButton#danger {{ color:{t.bad}; }}
QPushButton#danger:hover {{ background:{bad_soft}; border-color:{t.bad}; }}

QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {{ background:{t.stage}; color:{t.fg}; border:1px solid {t.line2};
  border-radius:{sm}px; padding:4px 8px; selection-background-color:{t.accent}; selection-color:{t.stage}; font-size:12.5px; }}
QPlainTextEdit, QTextEdit {{ font-size:13px; }}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{ border-color:{t.accent}; }}
QComboBox::drop-down {{ border:none; width:18px; }}
QComboBox QAbstractItemView {{ background:{t.raised}; color:{t.fg}; border:1px solid {t.line2}; outline:none; selection-background-color:{t.hover}; selection-color:{t.fg}; }}
QCheckBox {{ color:{t.soft}; font-size:12.5px; spacing:7px; }}
QCheckBox::indicator {{ width:14px; height:14px; border:1px solid {t.faint}; border-radius:3px; background:{t.stage}; }}
QCheckBox::indicator:hover {{ border-color:{t.accent}; }}
QCheckBox::indicator:checked {{ background:{t.accent}; border-color:{t.accent}; }}
QSlider::groove:horizontal {{ height:3px; background:{t.line2}; border-radius:1px; }}
QSlider::sub-page:horizontal {{ height:3px; background:{t.accent}; border-radius:1px; }}
QSlider::handle:horizontal {{ width:8px; height:16px; margin:-7px 0; border-radius:2px; background:{t.raised}; border:1px solid {t.faint}; border-bottom:2px solid {t.faint}; }}
QSlider::handle:horizontal:hover {{ background:{t.accent}; border-color:{ac_edge}; }}
QProgressBar {{ background:{t.line}; color:{t.fg}; border:none; border-radius:2px; text-align:center; font-size:11.5px; min-height:18px; }}
QProgressBar::chunk {{ background:{css(t.accent, .45)}; border-radius:2px; }}
QListWidget {{ background:transparent; color:{t.fg}; border:1px solid {t.line}; border-radius:{sm}px; outline:none; font-size:12.5px; }}
QListWidget::item {{ padding:6px 8px; border-bottom:1px solid {t.line}; }}
QListWidget::item:hover {{ background:{t.hover}; }}
QListWidget::item:selected {{ background:{css(t.accent, .14)}; color:{t.fg}; }}
QTabWidget::pane {{ border:none; border-top:1px solid {t.line}; }}
QTabBar::tab {{ background:transparent; color:{t.muted}; padding:7px 14px; border:none; border-bottom:2px solid transparent; font-size:12.5px; }}
QTabBar::tab:hover {{ color:{t.fg}; }}
QTabBar::tab:selected {{ color:{t.fg}; font-weight:700; border-bottom:2px solid {t.accent}; }}
QSplitter::handle {{ background:{t.line}; }}
QSplitter::handle:hover {{ background:{t.accent}; }}
QSplitter::handle:horizontal {{ width:1px; }}
QSplitter::handle:vertical {{ height:1px; }}
QMenu {{ background:{t.raised}; color:{t.fg}; border:1px solid {t.line2}; padding:4px; font-size:12.5px; }}
QMenu::item {{ padding:6px 26px 6px 12px; border-radius:3px; }}
QMenu::item:selected {{ background:{t.hover}; }}
QMenu::item:disabled {{ color:{t.faint}; }}
QMenu::separator {{ height:1px; background:{t.line}; margin:4px 6px; }}
QMenu::indicator {{ width:13px; height:13px; left:4px; }}
QScrollArea {{ background:transparent; border:none; }}
QScrollArea > QWidget > QWidget {{ background:transparent; }}
QScrollBar:vertical {{ background:transparent; width:8px; margin:2px; }}
QScrollBar::handle:vertical {{ background:{t.line2}; border-radius:2px; min-height:30px; }}
QScrollBar::handle:vertical:hover {{ background:{t.faint}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ height:0; background:transparent; }}
QScrollBar:horizontal {{ height:0; }}
QTextBrowser {{ background:transparent; border:none; color:{t.soft}; font-size:13px; }}
"""


class FlowLayout(QLayout):
    """按钮自动换行。"""

    def __init__(self, parent=None, spacing: int = 6):
        super().__init__(parent)
        self._items: list = []
        self.setSpacing(spacing)
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):  # noqa: N802
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):  # noqa: N802
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):  # noqa: N802
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):  # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self):  # noqa: N802
        return True

    def heightForWidth(self, w):  # noqa: N802
        return self._layout(QRect(0, 0, w, 0), True)

    def setGeometry(self, r):  # noqa: N802
        super().setGeometry(r)
        self._layout(r, False)

    def sizeHint(self):  # noqa: N802
        return self.minimumSize()

    def minimumSize(self):  # noqa: N802
        s = QSize()
        for it in self._items:
            s = s.expandedTo(it.minimumSize())
        return s

    def _layout(self, rect, test):
        x, y, line = rect.x(), rect.y(), 0
        sp = self.spacing()
        for it in self._items:
            hint = it.sizeHint()
            nx = x + hint.width() + sp
            if nx - sp > rect.right() + 1 and line > 0:
                x, y = rect.x(), y + line + sp
                nx, line = x + hint.width() + sp, 0
            if not test:
                it.setGeometry(QRect(QPoint(x, y), hint))
            x, line = nx, max(line, hint.height())
        return y + line - rect.y()


class Segmented(QWidget):
    """顶栏的切换：一条凹槽，选中项是一颗凸起的按键。"""
    changed = Signal(str)
    PAD = 3

    def __init__(self, items: list[tuple[str, str]], value: str):
        super().__init__()
        self.items, self.value, self.hover = items, value, None
        self.setMouseTracking(True)
        self.setFixedHeight(32)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._f = font(12.5, 500)
        self._fb = font(12.5, 700)
        from PySide6.QtGui import QFontMetrics
        fm = QFontMetrics(self._fb)
        self._w = [fm.horizontalAdvance(t) + 24 for _, t in items]
        self.setFixedWidth(sum(self._w) + 2 * self.PAD)

    def _at(self, x):
        acc = self.PAD
        for (k, _), w in zip(self.items, self._w):
            if acc <= x < acc + w:
                return k
            acc += w
        return None

    def set_value(self, v: str) -> None:
        self.value = v
        self.update()

    def mouseMoveEvent(self, e):  # noqa: N802
        h = self._at(e.position().x())
        if h != self.hover:
            self.hover = h
            self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = None
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        k = self._at(e.position().x())
        if k and k != self.value:
            self.value = k
            self.update()
            self.changed.emit(k)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        h = self.height()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qc(T.fg, 0.07))
        p.drawRoundedRect(self.rect(), RADIUS["md"], RADIUS["md"])
        x = self.PAD
        for (k, t), w in zip(self.items, self._w):
            on = k == self.value
            if on:
                draw_key(p, QRectF(x, self.PAD, w, h - 2 * self.PAD), T.raised, 5)
            elif k == self.hover:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.fg, 0.07))
                p.drawRoundedRect(QRectF(x, self.PAD, w, h - 2 * self.PAD), 5, 5)
            p.setFont(self._fb if on else self._f)
            p.setPen(qc(T.accent if on else T.muted))
            p.drawText(QRect(x, 0, w, h - (1 if on else 0)), int(Qt.AlignmentFlag.AlignCenter), t)
            x += w
        p.end()


class TabBar(QWidget):
    """侧栏标签：参数 / 原理 / 讲题。"""
    changed = Signal(int)

    def __init__(self, labels: list[str]):
        super().__init__()
        self.labels, self.cur = labels, 0
        self.setFixedHeight(38)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_index(self, i: int) -> None:
        self.cur = i
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        i = int(e.position().x() / max(1, self.width()) * len(self.labels))
        i = max(0, min(len(self.labels) - 1, i))
        if i != self.cur:
            self.cur = i
            self.update()
            self.changed.emit(i)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w = self.width() / len(self.labels)
        for i, t in enumerate(self.labels):
            on = i == self.cur
            p.setFont(font(12.5, 700 if on else 500))
            p.setPen(qc(T.fg if on else T.muted))
            p.drawText(QRect(int(i * w), 0, int(w), self.height() - 2), int(Qt.AlignmentFlag.AlignCenter), t)
        p.setPen(QPen(qc(T.line), 1))
        p.drawLine(0, self.height() - 1, self.width(), self.height() - 1)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qc(T.accent))
        p.drawRect(QRectF(self.cur * w, self.height() - 2, w, 2))
        p.end()


def draw_key(p: QPainter, r: QRectF, fill, radius: float = 5, edge=None, sunk: bool = False) -> None:
    """一颗按键：面 + 细边 + 下沿。sunk=True 时下沉 1 像素、下沿收窄。"""
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    r = QRectF(r).adjusted(.5, .5, -.5, -.5)
    edge_c = qc(edge or T.edge)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(edge_c)
    p.drawRoundedRect(r, radius, radius)
    face = r.adjusted(0, 1 if sunk else 0, 0, -1)
    p.setBrush(qc(fill))
    p.setPen(QPen(qc(T.line2 if edge is None else edge), 1))
    p.drawRoundedRect(face, radius, radius)
    p.restore()


def paint_ticks(p: QPainter, x: float, y: float, w: float, color=None, step: float = 6, major: int = 5, h: float = 4) -> None:
    """刻度线：这套界面的装饰母题，只作分隔，不表示数据。"""
    p.save()
    p.setPen(QPen(qc(color or T.line2), 1))
    i, cx = 0, x
    while cx <= x + w:
        p.drawLine(QPointF(cx, y), QPointF(cx, y + (h * 1.75 if i % major == 0 else h)))
        cx += step
        i += 1
    p.restore()


def paint_seal(p: QPainter, r: QRectF, char: str = "见") -> None:
    """朱砂印：产品标识。"""
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(qc(T.brand))
    p.drawRoundedRect(r, r.width() * .16, r.width() * .16)
    p.setPen(qc("#FFFFFF"))
    p.setFont(font(r.width() * .62, 700, "serif"))
    p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), char)
    p.restore()


class IconButton(QPushButton):
    """线性图标按钮。选中时是一颗填色的键；solid=False 时只淡染底色（顶栏开关用）。"""

    def __init__(self, icon: str, tip: str = "", size: int = 30, checkable: bool = False, solid: bool = False):
        super().__init__()
        self.icon, self._hover, self.solid = icon, False, solid
        self.setFixedSize(size, size)
        self.setToolTip(tip)
        self.setCheckable(checkable)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFlat(True)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self, e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        from .icons import draw_icon
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        on, down = self.isChecked(), self.isDown()
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if on and self.solid:
            draw_key(p, r, T.accent, RADIUS["sm"], edge=qc(T.accent).darker(140), sunk=down)
        elif on:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.accent, 0.16))
            p.drawRoundedRect(r, RADIUS["sm"], RADIUS["sm"])
        elif down:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.press))
            p.drawRoundedRect(r, RADIUS["sm"], RADIUS["sm"])
        elif self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.hover))
            p.drawRoundedRect(r, RADIUS["sm"], RADIUS["sm"])
        if not self.isEnabled():
            col = qc(T.faint)
        elif on:
            col = qc(T.stage if self.solid else T.accent)
        else:
            col = qc(T.fg if self._hover else T.soft)
        m = int(self.width() * 0.22)
        draw_icon(p, self.icon, self.rect().adjusted(m, m + (1 if down else 0), -m, -m + (1 if down else 0)), col)
        p.end()


class RailButton(QPushButton):
    """墨绿窄栏上的模式键：compact 是上图标下文字（学习窗口），否则左图标右文字（主窗口）。"""

    def __init__(self, icon: str, text: str, compact: bool = True, height: int = 54):
        super().__init__()
        self.icon, self.label, self.compact, self._hover = icon, text, compact, False
        self.setCheckable(True)
        self.setFixedHeight(height)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFlat(True)
        self.setAccessibleName(text)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self, e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        from .icons import draw_icon
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        on = self.isChecked()
        w, h = self.width(), self.height()
        if on or self._hover or self.isDown():
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.rail2))
            p.drawRoundedRect(QRectF(0, 0, w, h), RADIUS["md"], RADIUS["md"])
        if on:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.brand))
            p.drawRoundedRect(QRectF(0, h * .24, 3, h * .52), 1.5, 1.5)
        col = qc(T.railon if on or self._hover else T.railfg)
        if self.compact:
            draw_icon(p, self.icon, QRectF((w - 20) / 2, 8, 20, 20), col, 1.6)
            p.setPen(col)
            p.setFont(font(11, 700 if on else 500))
            p.drawText(QRect(0, 31, w, h - 33), int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop), self.label)
        else:
            draw_icon(p, self.icon, QRectF(14, (h - 18) / 2, 18, 18), col, 1.6)
            p.setPen(col)
            p.setFont(font(13, 700 if on else 500))
            p.drawText(QRect(44, 0, w - 50, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.label)
        p.end()


def hline() -> QWidget:
    w = QWidget()
    w.setFixedHeight(1)
    w.setStyleSheet(f"background:{T.line};")
    return w


def _unused() -> None:  # 保持导入整洁
    _ = (QColor, QSizePolicy, QWidgetItem)
