"""1.x → 2.0 数据导入：1.7 把浏览器内核里的 localStorage 导出成 export-1x.json，这里转成 2.0 的存档。

只读导出文件，不改它；已有的 2.0 数据优先，合并时不覆盖。做过一次后记下标记，不再重复。
"""
from __future__ import annotations

import json
import time

from .kit.home import home, load_json, save_json

FLAG = "imported-1x.json"
SOURCE = "export-1x.json"


def _list(raw, key):
    try:
        v = json.loads(raw.get(key) or "[]")
    except ValueError:
        return []
    return v if isinstance(v, list) else []


def _sources():
    """1.7 的导出；没有的话退回 1.5 的一次性搬家文件。"""
    h = home()
    out = []
    for p in (h / SOURCE, h / "web" / "migrate-http.json", h / "web" / "migrate-file.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(d, dict):
            out.append(d)
    return out


def convert(raw):
    """返回 {stars, built, imported, lessons, math, graphplus} 里有内容的部分。"""
    out = {}
    stars = [x for x in _list(raw, "jw.stars") if isinstance(x, str) and x]
    if stars:
        out["stars"] = stars
    built = [q for q in _list(raw, "jw.built") if isinstance(q, dict) and q.get("id")]
    if built:
        out["built"] = built
    imported = [q for q in _list(raw, "jw.imported") if isinstance(q, dict) and q.get("id")]
    if imported:
        out["imported"] = imported
    lessons = []
    for i, x in enumerate(_list(raw, "lab-lessons")):
        if not isinstance(x, dict):
            continue
        x = dict(x)
        x.setdefault("ticket", dict(id=str(x.get("id") or f"1x-{i}"), revision=0, hash=""))
        x["engine"] = x.get("engine") or "1.x"
        lessons.append(x)
    if lessons:
        out["lessons"] = lessons
    try:
        m = json.loads(raw.get("jw.lab.math") or "null")
    except ValueError:
        m = None
    if isinstance(m, dict) and m.get("objects"):
        out["math"] = m
    try:
        g = json.loads(raw.get("jw.graphplus") or "null")
    except ValueError:
        g = None
    if isinstance(g, dict) and isinstance(g.get("show"), dict):
        out["graphplus"] = dict(show=g["show"])
    return out


def _merge_ids(name, new, limit):
    cur = load_json(name, [])
    cur = cur if isinstance(cur, list) else []
    seen = {q.get("id") for q in cur}
    add = [q for q in new if q.get("id") not in seen]
    if add:
        save_json(name, (cur + add)[-limit:])
    return len(add)


def run_once(force=False):
    """返回导入摘要（中文一句话）；没有可导入的或已经导入过返回空串。"""
    if load_json(FLAG) and not force:
        return ""
    srcs = _sources()
    if not srcs:
        return ""
    counts = dict(stars=0, built=0, imported=0, lessons=0, math=0)
    for raw in srcs:
        d = convert(raw)
        if d.get("stars"):
            cur = load_json("stars.json", [])
            cur = cur if isinstance(cur, list) else []
            add = [x for x in d["stars"] if x not in cur]
            if add:
                save_json("stars.json", cur + add)
                counts["stars"] += len(add)
        if d.get("built"):
            counts["built"] += _merge_ids("bank-built.json", d["built"], 100)
        if d.get("imported"):
            counts["imported"] += _merge_ids("bank-imported.json", d["imported"], 200)
        if d.get("lessons"):
            cur = load_json("lessons.json", [])
            cur = cur if isinstance(cur, list) else []
            seen = {x.get("ticket", {}).get("id") for x in cur}
            add = [x for x in d["lessons"] if x["ticket"]["id"] not in seen]
            if add:
                save_json("lessons.json", (cur + add)[:30])
                counts["lessons"] += len(add)
        if d.get("math") and load_json("lab-math.json") is None:
            save_json("lab-math.json", d["math"])
            counts["math"] = 1
        if d.get("graphplus") and load_json("graphplus.json") is None:
            save_json("graphplus.json", d["graphplus"])
    save_json(FLAG, dict(t=time.time(), counts=counts))
    parts = [f"错题 {counts['stars']} 道" if counts["stars"] else "", f"导入题 {counts['imported']} 道" if counts["imported"] else "", f"自建场景 {counts['built']} 个" if counts["built"] else "", f"讲题记录 {counts['lessons']} 条" if counts["lessons"] else "", "几何画板" if counts["math"] else ""]
    parts = [p for p in parts if p]
    return ("已从 1.x 导入：" + "、".join(parts)) if parts else ""
