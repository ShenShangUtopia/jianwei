"""subjects 引擎 · 生物模式（由 views/subjects.js 改写）：遗传图解、细胞结构、生态系统。"""
from __future__ import annotations

import math
import re

from ..kit.core import clamp, gcd
from .sb_core import C, mode, num


# ---------------------------------------------------------------- 遗传
def parse_genotype(st):
    mp, order = {}, []
    for ch in re.sub(r"[^A-Za-z]", "", str(st or "Aa")):
        k = ch.upper()
        if k not in mp:
            mp[k] = []
            order.append(k)
        mp[k].append(ch)
    out = []
    for k in order:
        arr = mp[k]
        dom, rec = k in arr, any(c.islower() for c in arr)
        pair = [k, k.lower()] if dom and rec else [k, k] if dom else [k.lower(), k.lower()]
        out.append({"key": k, "pair": pair, "gametes": [k, k.lower()] if dom and rec else [pair[0]]})
    return out


def cross_gametes(genes):
    out = [""]
    for gene in genes:
        out = [pre + a for pre in out for a in gene["gametes"]]
    return out


def pheno_of(geno):
    key, doms = "", []
    for i in range(0, len(geno), 2):
        a, b = geno[i], geno[i + 1]
        has_dom = a.isupper() or b.isupper()
        up = a if a.isupper() else b
        key += up + "_" if has_dom else a.lower() * 2
        if has_dom:
            doms.append(up)
    return {"key": key, "doms": doms}


@mode("genetics")
def mount_genetics(W):
    D_, P = W.D, W.P
    raw1, raw2 = "AaBb", "AaBb"
    cr = D_.get("cross") if D_.get("cross") is not None else P.get("cross")
    if isinstance(cr, str):
        parts = re.split(r"[×✕xX*]", cr)
        raw1 = parts[0] or raw1
        raw2 = (parts[1] if len(parts) > 1 else "") or raw1
    elif isinstance(cr, dict):
        raw1 = cr.get("p1") or cr.get("mother") or raw1
        raw2 = cr.get("p2") or cr.get("father") or raw1
    elif D_.get("p1") or D_.get("p2"):
        raw1 = D_.get("p1") or raw1
        raw2 = D_.get("p2") or raw1
    genes1, genes2 = parse_genotype(raw1), parse_genotype(raw2)
    gene_count = min(2, max(len(genes1), len(genes2)))
    S = {"pair": gene_count, "pick": -1, "model": None, "grid": None}

    def model():
        n = min(S["pair"], gene_count)
        g1, g2 = cross_gametes(genes1[:n]), cross_gametes(genes2[:n])
        cells, groups, order = [], {}, []
        for r, ga in enumerate(g1):
            for c, gb in enumerate(g2):
                geno = ""
                for i in range(min(n, len(ga), len(gb))):
                    ca, cb = ga[i], gb[i]
                    geno += ca + cb.lower() if ca.isupper() else cb + ca.lower()
                ph = pheno_of(geno)
                cell = {"r": r, "c": c, "geno": geno, "pheno": ph}
                cells.append(cell)
                if ph["key"] not in groups:
                    groups[ph["key"]] = {"key": ph["key"], "doms": ph["doms"], "n": 0}
                    order.append(ph["key"])
                groups[ph["key"]]["n"] += 1
        lst = sorted((groups[k] for k in order), key=lambda g: -g["n"])
        d = 0
        for it in lst:
            d = gcd(d, it["n"])
        d = d or 1
        for it in lst:
            it["ratio"] = it["n"] // d
        return {"g1": g1, "g2": g2, "cells": cells, "groups": lst, "gcd": d, "n": n}
    S["model"] = model()

    def group_label(gr):
        n = S["model"]["n"]
        if n == 1:
            return "显性" if gr["doms"] else "隐性"
        if not gr["doms"]:
            return "双隐"
        if len(gr["doms"]) == n:
            return "双显"
        return "单显 " + "".join(gr["doms"])
    SHADE = (0.10, 0.18, 0.27, 0.36)
    W.head_title("遗传图解", "亲本配子 · Punnett 棋盘 · 表现型比例")
    W.add_steps(["亲本", "配子", "子代", "比例"])
    W.sec("亲本与配子")
    kvP, kvG, kvN, kvR = W.kv("P"), W.kv("配子"), W.kv("组合数"), W.kv("表现型比")
    W.sec("表现型")
    legend = W.note("")
    pick_box = W.note("")
    if gene_count > 1:
        W.sec("等位基因")

        def set_pairs(v):
            S["pair"] = 1 if v == "一对" else 2
            S["pick"] = -1
            S["model"] = model()
            W.redraw()
        W.chips(["一对", "两对"], "两对", set_pairs)
    W.note("棋盘行列是双亲配子；格子内为子代基因型，底色按表现型分组。点格子可查看。")

    def rebuild_ctrl():
        M = S["model"]
        kvP.text(f"{raw1} × {raw2}")
        kvG.text(" / ".join(M["g1"]) + "  ·  " + " / ".join(M["g2"]))
        kvN.text(len(M["cells"]))
        kvR.text(" : ".join(str(g["ratio"]) for g in M["groups"]))
        legend.text("<br>".join(f"{group_label(g)}　{g['n']}/{len(M['cells'])}　({g['ratio']})" for g in M["groups"]))
        if 0 <= S["pick"] < len(M["cells"]):
            c = M["cells"][S["pick"]]
            gr = next((g for g in M["groups"] if g["key"] == c["pheno"]["key"]), {"doms": c["pheno"]["doms"]})
            pick_box.text(f"<b>{c['geno']}</b>　{group_label(gr)} · {c['pheno']['key']}　第 {c['r'] + 1} 行 {c['c'] + 1} 列")
        else:
            pick_box.text("点棋盘格读取基因型与表现型")

    def render(w, h):
        M = S["model"]
        step = W.step
        Pd, head_h, gw, gh = 20, 52, 62, 26
        cols, rows = len(M["g2"]), len(M["g1"])
        avail_w, avail_h = w - Pd * 2 - gw - 6, h - head_h - gh - 52
        size = max(26, min(avail_w / cols, avail_h / rows))
        x0, y0 = Pd + gw + 6 + max(0, (avail_w - cols * size) / 2), head_h + gh
        S["grid"] = (x0, y0, size, cols, rows)
        W.txt(Pd, 22, "Punnett 棋盘", size=12, weight=700)
        W.txt(w - Pd, 22, f"{raw1} × {raw2}", size=11, anchor="end", fill=C.soft)
        W.txt(Pd, head_h - 10, "配子", size=9.5, fill=C.faint)
        hop = 1 if step >= 1 else 0.45
        if step >= 3:
            for cell in M["cells"]:
                grp = next(i for i, g in enumerate(M["groups"]) if g["key"] == cell["pheno"]["key"])
                W.rect(x0 + cell["c"] * size, y0 + cell["r"] * size, size, size, fill=C.data[1], opacity=SHADE[grp % 4])
        for r in range(rows + 1):
            W.line(x0 - 2, y0 + r * size, x0 + cols * size, y0 + r * size, C.line)
        for c in range(cols + 1):
            W.line(x0 + c * size, y0 - 2, x0 + c * size, y0 + rows * size, C.line)
        for c, g in enumerate(M["g2"]):
            W.txt(x0 + c * size + size / 2, y0 - 14, g, size=11.5, anchor="middle", weight=700, opacity=hop)
        for r, g in enumerate(M["g1"]):
            W.txt(x0 - 12, y0 + r * size + size / 2, g, size=11.5, anchor="end", weight=700, opacity=hop)
        if step >= 2:
            for k, cell in enumerate(M["cells"]):
                r, c = cell["r"], cell["c"]
                if S["pick"] == k:
                    W.rect(x0 + c * size + 1, y0 + r * size + 1, size - 2, size - 2, stroke=C.accent, width=1.6)
                W.txt(x0 + c * size + size / 2, y0 + r * size + size / 2, cell["geno"], size=max(9.5, min(12, size * 0.25)), anchor="middle")
        W.txt(x0 + cols * size / 2, h - 22, f"P：{raw1}（♀）× {raw2}（♂）", size=10.5, anchor="middle", fill=C.soft)
        if step >= 3:
            bx = Pd
            by = y0 + rows * size + 24
            total = sum(g["n"] for g in M["groups"])
            for i, g in enumerate(M["groups"]):
                bw = g["n"] / total * (w - Pd * 2)
                W.rect(bx, by, bw, 5, fill=C.data[1], opacity=SHADE[i % 4])
                if bw > 34:
                    W.txt(bx + bw / 2, by + 15, g["n"] // M["gcd"], size=9.5, anchor="middle", fill=C.soft)
                bx += bw
            W.txt(Pd, by - 7, "表现型分离比 " + " : ".join(str(g["ratio"]) for g in M["groups"]), size=9.5, fill=C.faint)
        rebuild_ctrl()
    W.set(render)

    def click(px, py, _o):
        G = S["grid"]
        if not G:
            return
        x0, y0, size, cols, rows = G
        if x0 <= px <= x0 + cols * size and y0 <= py <= y0 + rows * size:
            k = int((py - y0) // size) * cols + int((px - x0) // size)
            if 0 <= k < len(S["model"]["cells"]):
                S["pick"] = -1 if S["pick"] == k else k
                W.redraw()
    W.L.interact(W.c, click=click)


# ---------------------------------------------------------------- 细胞
@mode("cell")
def mount_cell(W):
    plant = (W.D.get("type") or W.P.get("type") or "animal") == "plant"
    ORGS = [("membrane", "细胞膜", "磷脂双分子层，控制物质进出，进行细胞间的信息交流。"), ("nucleus", "细胞核", "遗传信息库，DNA 复制与转录的场所，控制细胞的代谢与遗传。"),
            ("mito", "线粒体", "有氧呼吸的主要场所，内膜折叠成嵴，为细胞提供 ATP。"), ("er", "内质网", "与核膜相连的膜性管网，负责蛋白质与脂质的合成、加工与运输。"),
            ("golgi", "高尔基体", "对来自内质网的蛋白质进行分类、包装与发送。"), ("ribo", "核糖体", "蛋白质合成的机器，游离或附着在内质网上。")]
    if plant:
        ORGS += [("wall", "细胞壁", "主要成分是纤维素，起支持和保护作用，全透性。"), ("chloro", "叶绿体", "光合作用的场所，含叶绿素，把光能转变成化学能。"),
                 ("vacuole", "液泡", "贮存细胞液，含糖类、色素等，维持细胞的渗透压。")]
    S = {"sel": "nucleus", "hits": []}
    STEP_SEL = ["", "nucleus", "mito", "membrane"]
    W.head_title("细胞结构", "植物细胞 · 点选结构看功能" if plant else "动物细胞 · 点选结构看功能")
    W.add_steps(["整体", "细胞核", "细胞器", "细胞膜"])
    W.sec("已选结构")
    detail = W.note("")
    W.sec("结构列表")
    sel_seg = W.L.seg("", [[k, n] for k, n, _d in ORGS], S["sel"], lambda k: select(k))
    W.note("点击图上任一结构或这里的列表，查看它的功能与位置。")

    def select(k):
        S["sel"] = k
        o = next((x for x in ORGS if x[0] == k), None)
        detail.text(f"<b>{o[1]}</b><br>{o[2]}" if o else "点选结构")
        sel_seg.set(k, True)
        W.redraw()

    def ellipse(cx, cy, rx, ry, fill=None, stroke=None, width=1, rot=0.0, opacity=None):
        def b(g):
            g.ellipse(cx, cy, rx, ry, rot)
        W.stroke_path(b, fill=fill, stroke=stroke, width=width, opacity=opacity)

    def render(w, h):
        cx, cy = w * 0.45, h * 0.52
        rx = min(w * 0.34, (h - 64) * 0.62)
        ry = rx * 0.66
        S["hits"] = []

        def st(k):
            return C.accent if S["sel"] == k else C.ink2

        def sw(k):
            return 1.9 if S["sel"] == k else 1.3

        def hit(k, x, y, r):
            S["hits"].append((k, x, y, r))

        def label(x, y, s, k, anchor="middle"):
            W.txt(clamp(x, 34, w - 34), clamp(y, 14, h - 12), s, size=10, fill=st(k), anchor=anchor, weight=600 if S["sel"] == k else 400)
        if plant:
            W.rect(cx - rx - 13, cy - ry - 13, (rx + 13) * 2, (ry + 13) * 2, rx=20, stroke=st("wall"), width=sw("wall") + 1.4)
            W.rect(cx - rx, cy - ry, rx * 2, ry * 2, rx=14, fill=C.data[4], stroke=st("membrane"), width=sw("membrane"))
            W.txt(cx - rx - 8, cy - ry - 22, "细胞壁", size=10, fill=st("wall"))
        else:
            ellipse(cx, cy, rx, ry, C.data[4], st("membrane"), sw("membrane"))
            W.line(cx, cy - ry, cx, cy - ry - 16, st("membrane"), 0.9)
            W.txt(cx + 4, cy - ry - 22, "细胞膜", size=10, fill=st("membrane"))
        nx, ny, nr = cx - rx * 0.26, cy - ry * 0.22, min(rx, ry) * 0.30
        W.circ(nx, ny, nr, fill=C.card, stroke=st("nucleus"), width=sw("nucleus"), opacity=0.95)
        W.circ(nx + nr * 0.18, ny - nr * 0.1, nr * 0.3, fill=C.data[4], stroke=C.data[1], width=0.9)
        hit("nucleus", nx, ny, nr)
        W.txt(nx, ny + nr + 13, "细胞核", size=10, anchor="middle", fill=st("nucleus"))
        ex, ey = cx - rx * 0.46, cy + ry * 0.05
        for k in range(3):
            x0, y0 = ex + k * 9, ey - 26 + k * 4

            def er(g, x0=x0, y0=y0):
                g.move_to(x0, y0)
                g.quad_to(x0 + 13, y0 + 9, x0, y0 + 18)
                g.quad_to(x0 - 11, y0 + 27, x0, y0 + 36)
            W.stroke_path(er, stroke=st("er"), width=sw("er"), opacity=0.85)
        hit("er", ex + 10, ey, 26)
        label(ex + 14, ey + 42, "内质网", "er")
        gx, gy = cx + rx * 0.16, cy + ry * 0.52
        for k in range(3):
            x0, y0, wd = gx - 24 + k * 3, gy - k * 7, 48 - k * 6

            def go(g, x0=x0, y0=y0, wd=wd):
                g.move_to(x0, y0)
                g.quad_to(x0 + wd / 2, y0 - 8, x0 + wd, y0)
            W.stroke_path(go, stroke=st("golgi"), width=sw("golgi"), opacity=0.9)
        hit("golgi", gx, gy - 6, 26)
        label(gx, gy + 18, "高尔基体", "golgi")

        def mito(x, y, rxx, ryy, rot):
            g = W.g
            g.save()
            g.translate(x, y)
            g.rotate(math.radians(rot))
            ellipse(0, 0, rxx, ryy, C.card, st("mito"), sw("mito"))

            def cr(gg):
                gg.move_to(-rxx * 0.62, 0)
                gg.quad_to(-rxx * 0.42, -ryy * 0.8, -rxx * 0.24, 0)
                gg.quad_to(-rxx * 0.04, ryy * 0.8, rxx * 0.14, 0)
            W.stroke_path(cr, stroke=st("mito"), width=0.9, opacity=0.8)
            g.restore()
            hit("mito", x, y, max(rxx, 14))
        mito(cx + rx * 0.5, cy - ry * 0.28, min(28, rx * 0.17), min(13, ry * 0.17), -18)
        label(cx + rx * 0.5, cy - ry * 0.28 - 22, "线粒体", "mito")
        mito(cx + rx * 0.1, cy - ry * 0.62, min(20, rx * 0.12), min(9, ry * 0.12), 12)
        for px_, py_ in ((0.62, 0.28), (0.7, 0.4), (0.58, 0.46), (0.76, 0.18), (0.5, 0.62), (0.32, 0.56)):
            X, Y = cx + rx * px_, cy + ry * py_
            W.circ(X, Y, 2.4, fill=st("ribo"))
            W.circ(X + 6, Y + 4, 2.4, fill=st("ribo"))
            hit("ribo", X + 3, Y + 2, 9)
        label(cx + rx * 0.66, cy + ry * 0.32, "核糖体", "ribo", "start")
        if plant:
            xc, yc = cx + rx * 0.2, cy - ry * 0.62
            rxx, ryy = min(28, rx * 0.18), min(13, ry * 0.17)
            g = W.g
            g.save()
            g.translate(xc, yc)
            g.rotate(math.radians(14))
            ellipse(0, 0, rxx, ryy, C.data[4], st("chloro"), sw("chloro"))
            for k in range(-2, 3):
                W.line(k * 6, -7, k * 6, 7, st("chloro"), 0.8, opacity=0.7)
            g.restore()
            hit("chloro", xc, yc, rxx)
            label(xc, yc - 20, "叶绿体", "chloro")
            vx, vy = cx + rx * 0.42, cy + ry * 0.1
            ellipse(vx, vy, rx * 0.26, ry * 0.3, C.card, st("vacuole"), sw("vacuole"), opacity=0.9)
            hit("vacuole", vx, vy, ry * 0.3)
            label(vx, vy + ry * 0.3 + 12, "液泡", "vacuole")
        W.txt(18, h - 16, "点选结构高亮，右侧看功能" if W.step >= 1 else "选择一种结构", size=9.5, fill=C.faint)
    W.set(render)

    def click(x, y, _o):
        best, bd = None, 1e9
        for k, hx, hy, r in reversed(S["hits"]):
            d = math.hypot(x - hx, y - hy)
            if d <= r and d < bd:
                best, bd = k, d
        if best:
            select(best)
    W.L.interact(W.c, click=click)
    base_apply = W.apply_step

    def apply_step(i):
        base_apply(i)
        key = STEP_SEL[min(W.step, len(STEP_SEL) - 1)]
        if key:
            S["sel"] = key
        select(S["sel"])
    W.apply_step = apply_step
    select("nucleus")


# ---------------------------------------------------------------- 生态
DEF_NODES = [("草", 0), ("兔", 1), ("鼠", 1), ("狐", 2), ("蛇", 2), ("鹰", 3)]
DEF_LINKS = [("草", "兔"), ("草", "鼠"), ("兔", "狐"), ("鼠", "蛇"), ("蛇", "鹰"), ("狐", "鹰")]


@mode("ecology")
def mount_ecology(W):
    D_ = W.D
    if D_.get("nodes"):
        nodes = [{"id": n.get("id") or n.get("label"), "label": n.get("label") or n.get("id"), "level": int(n.get("level") or 0)} for n in D_["nodes"]]
    else:
        nodes = [{"id": a, "label": a, "level": lv} for a, lv in DEF_NODES]
    if D_.get("links"):
        links = [(lk[0], lk[1]) if isinstance(lk, list) else (lk.get("from"), lk.get("to")) for lk in D_["links"]]
    else:
        links = DEF_LINKS
    by = {n["id"]: n for n in nodes}
    level_e = D_.get("energy") or [10000, 1000, 100, 10]
    S = {"sel": nodes[-1]["id"], "pos": {}}
    consumers: dict = {}
    for a, b in links:
        A, B = by.get(a), by.get(b)
        if A and B:
            lo, hi = (A, B) if A["level"] <= B["level"] else (B, A)
            consumers.setdefault(lo["id"], []).append(hi["id"])

    def reach(i):
        seen, q2, order = set(), [i], [i]
        while q2:
            for nxt in consumers.get(q2.pop(0), []):
                if nxt not in seen:
                    seen.add(nxt)
                    order.append(nxt)
                    q2.append(nxt)
        return order
    W.head_title("生态系统", "能量金字塔 · 食物网路径")
    W.add_steps(["金字塔", "10% 传递", "食物网", "路径"])
    W.sec("读数")
    vSel, vLvl, vEn = W.stat("选中"), W.stat("营养级"), W.stat("能量", None, "kJ")
    kvUp = W.kv("捕食者")
    W.kv("传递效率", "10%")
    W.note("能量沿食物链单向流动、逐级递减；点节点高亮它到顶级消费者的路径。")

    def render(w, h):
        step = W.step
        Pd = 18
        pw = min(w * 0.34, 250)
        px, base_y, top_y = Pd + pw * 0.45, h - 56, 62
        bh = (base_y - top_y) / 4
        max_w = pw * 0.72
        levels = ("生产者", "初级消费", "次级消费", "三级消费")
        W.txt(Pd, 22, "能量金字塔", size=12, weight=700)
        W.txt(Pd, 38, "宽度按能量对数示意", size=9.5, fill=C.faint)
        for k in range(4):
            wb, wt = max_w * (4 - k) / 4, max_w * (3 - k) / 4
            yt, yb = base_y - (k + 1) * bh, base_y - k * bh
            op = (0.34 if k == 0 else 0.24) if step >= 1 else 0.12
            W.poly([(px - wb / 2, yb), (px - wt / 2, yt), (px + wt / 2, yt), (px + wb / 2, yb)], fill=C.data[1], opacity=op)
            W.poly([(px - wb / 2, yb), (px - wt / 2, yt), (px + wt / 2, yt), (px + wb / 2, yb)], stroke=C.data[2], width=0.8, close=True, opacity=op + 0.3)
            my = (yt + yb) / 2
            W.txt(px, my - 6, levels[k], size=9.5, anchor="middle", opacity=0.9)
            W.txt(px, my + 8, level_e[k] if k < len(level_e) else 0, size=10.5, anchor="middle", weight=700)
            if k > 0:
                W.arrow(px + wb / 2 + 10, yb + 6, px + wb / 2 + 10, yb - 14, C.data[2], 1, 5, opacity=0.9 if step >= 1 else 0.25)
                W.txt(px + wb / 2 + 16, yb - 4, "10%", size=9, fill=C.soft, opacity=1 if step >= 1 else 0.3)
        W.txt(Pd, h - 26, "单位：kJ / (m²·a)", size=9, fill=C.faint)
        wx0, wx1, wy0, wy1 = Pd + pw + 30, w - 20, h - 56, 56
        W.txt(wx0, 22, "食物网", size=12, weight=700)
        by_level: dict = {}
        for n in nodes:
            by_level.setdefault(n["level"], []).append(n)
        pos = {}
        for lv, arr in by_level.items():
            for i, n in enumerate(arr):
                pos[n["id"]] = (wx0 + (0.5 if len(arr) == 1 else (i + 0.5) / len(arr)) * (wx1 - wx0), wy0 + (wy1 - wy0) * (clamp(lv, 0, 3) / 3))
        S["pos"] = pos
        path_nodes = reach(S["sel"]) if step >= 3 else []
        for a, b in links:
            A, B = pos.get(a), pos.get(b)
            if not A or not B:
                continue
            frm, to = (A, B) if by[a]["level"] <= by[b]["level"] else (B, A)
            lit = step >= 3 and a in path_nodes and b in path_nodes
            W.line(frm[0], frm[1] - 13, to[0], to[1] + 13, C.accent if lit else C.data[2], 1.8 if lit else 1, opacity=(1 if lit else 0.55) if step >= 2 else 0.2)
        for n in nodes:
            p = pos[n["id"]]
            lit = step >= 3 and n["id"] in path_nodes
            sel = n["id"] == S["sel"]
            W.circ(p[0], p[1], 14, fill=C.card if sel or lit else C.grid2, stroke=C.accent if sel or lit else C.ink2, width=1.8 if sel or lit else 1, opacity=1 if step >= 2 else 0.55)
            W.txt(p[0], p[1], n["label"], size=10.5, anchor="middle", weight=700 if sel else 500)
            W.txt(p[0], p[1] + 23, f"第{n['level'] + 1}营养级", size=8.5, anchor="middle", fill=C.faint, opacity=1 if step >= 2 else 0.3)
        s = by.get(S["sel"])
        if s:
            vSel.text(s["label"])
            vLvl.text(f"第 {s['level'] + 1} 营养级")
            vEn.text(level_e[s["level"]] if s["level"] < len(level_e) else 0)
            kvUp.text("、".join(by[i]["label"] for i in consumers.get(s["id"], []) if i in by) or "无（顶级）")
    W.set(render)

    def click(x, y, _o):
        best, bd = None, 1e9
        for i, p in S["pos"].items():
            d = math.hypot(x - p[0], y - p[1])
            if d < bd:
                best, bd = i, d
        if best and bd < 26:
            S["sel"] = best
            W.redraw()
    W.L.interact(W.c, click=click)


def _unused():
    _ = num
