"""题库：内置 questions.json（由 1.x 题库 JS 转换）+ 用户导入 / 自建的题。"""
from __future__ import annotations

import json
from pathlib import Path

from ..kit.home import load_json, save_json

SUBJECTS = ["全部", "数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理"]
IMPORTED = "bank-imported.json"


class Bank:
    def __init__(self):
        self.questions: list[dict] = []
        self.by_id: dict[str, dict] = {}
        self.loaded = False

    def load(self):
        if self.loaded:
            return self
        self.loaded = True
        raw = json.loads((Path(__file__).parent / "questions.json").read_text(encoding="utf-8"))
        for q in raw:
            self._add(q)
        for q in load_json(IMPORTED, []) or []:
            q["imported"] = True
            self._add(q)
        self.load_built()
        return self

    def load_built(self):
        """场景搭建器存的题：删掉的也要从列表里拿掉。"""
        keep = load_json("bank-built.json", []) or []
        ids = {q.get("id") for q in keep}
        for q in [x for x in self.questions if x.get("built") and x["id"] not in ids]:
            self.questions.remove(q)
            del self.by_id[q["id"]]
        for q in keep:
            q["built"] = True
            if q.get("id"):
                if not isinstance(q.get("year"), int):
                    q["year"] = 2026
                self._add(q)

    def _add(self, q):
        if not q or not q.get("id"):
            return
        q.setdefault("steps", [])
        if q["id"] in self.by_id:
            self.questions[self.questions.index(self.by_id[q["id"]])] = q
        else:
            self.questions.append(q)
        self.by_id[q["id"]] = q

    def add_imported(self, q):
        q["imported"] = True
        self._add(q)
        save_json(IMPORTED, [x for x in self.questions if x.get("imported")][-200:])

    def remove_imported(self, qid):
        q = self.by_id.get(qid)
        if q and q.get("imported"):
            self.questions.remove(q)
            del self.by_id[qid]
            save_json(IMPORTED, [x for x in self.questions if x.get("imported")])

    def related(self, q, n=3):
        """同一考点：知识点重合多的优先，其次同科目、同引擎；实在没有就给同科目的题。"""
        mine = [str(x) for x in q.get("points") or []]
        scored = []
        for x in self.questions:
            if x["id"] == q["id"]:
                continue
            ps = [str(p) for p in x.get("points") or []]
            s = sum(1 for p in ps if any(m == p or p in m or m in p for m in mine))
            if x.get("subject") == q.get("subject"):
                s += 0.4
            if (x.get("view") or {}).get("engine") == (q.get("view") or {}).get("engine"):
                s += 0.3
            if s >= 0.4:
                scored.append((s, x))
        scored.sort(key=lambda t: -t[0])
        return [x for _s, x in scored[:n]]

    def match(self, q, text):
        t = text.lower()
        hay = " ".join(str(q.get(k) or "") for k in ("title", "stem", "subject", "paper", "type", "year")) + " " + " ".join(str(p) for p in q.get("points") or [])
        return all(w in hay.lower() for w in t.split())


bank = Bank()


def compare_answer(mine, right):
    """答案对照：只比对数字与关键词，不做判卷。返回 (ok, 文案)。"""
    import re

    def norm(s):
        return re.sub(r"[\s，,。；;：:（）()]", "", str(s or "")).replace("M/s", "m/s").lower()
    a, b = norm(mine), norm(right)
    if not a:
        return False, "先写点什么再对照"

    def nums(x):
        return re.findall(r"-?\d+(?:\.\d+)?", str(x))
    na, nb = nums(mine), nums(right)
    hit = sum(1 for n in nb if any(abs(float(m) - float(n)) < 1e-6 for m in na))
    if a == b:
        return True, "完全一致"
    if nb and hit == len(nb):
        return True, f"关键数值都对（{len(nb)} 个）"
    if nb and hit > 0:
        return False, f"对 {hit}/{len(nb)} 个数值，再检查一下"
    if a in b:
        return True, "方向对了，答案更完整些"
    return False, "和参考答案不一致，点「显示答案」逐项比"
