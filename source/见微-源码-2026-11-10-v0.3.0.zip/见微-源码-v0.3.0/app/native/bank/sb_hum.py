"""subjects 引擎 · 文科模式（由 views/subjects.js 改写）：历史时间轴、地理简图（后面还有句法、诗歌、作文、流程、数据）。"""
from __future__ import annotations

import math

from ..kit.core import clamp
from .sb_core import C, mode, wrap_text

DEF_EVENTS = [(-221, "秦统一六国", "建立中央集权制度，统一文字、度量衡。"), (105, "蔡伦改进造纸术", "书写材料成本大幅下降，推动文化传播。"), (618, "唐朝建立", "制度完备、丝路畅通，形成开放的文化格局。"),
              (960, "北宋建立", "商品经济与市民文化兴起，科举规模扩大。"), (1405, "郑和下西洋", "远洋航行展示国力，促进中外交流。"), (1840, "鸦片战争", "国门被迫打开，中国近代史开端。"),
              (1911, "辛亥革命", "推翻君主专制，建立共和政体。"), (1949, "中华人民共和国成立", "民族独立与人民解放，进入新阶段。")]


def _year(t):
    return f"前{-t}" if t < 0 else str(t)


@mode("timeline")
def mount_timeline(W):
    D_ = W.D
    if D_.get("events"):
        evs = [{"t": float(e["t"] if e.get("t") is not None else e.get("year", 0)), "label": e.get("label") or e.get("title") or "", "desc": e.get("desc") or ""} for e in D_["events"]]
    else:
        evs = [{"t": t, "label": a, "desc": b} for t, a, b in DEF_EVENTS]
    evs.sort(key=lambda e: e["t"])
    for e in evs:
        e["t"] = int(e["t"])
    links = D_.get("links") or [[0, 1], [1, 2], [2, 3], [4, 5], [5, 6], [6, 7]]
    S = {"sel": 0, "xs": []}
    W.head_title("历史时间轴", "年代轴 · 事件卡 · 因果连线")
    W.add_steps(["年代轴", "事件", "因果", "定位"])
    W.sec("读数")
    vY, vE = W.stat("年代"), W.stat("定位事件")
    W.kv("跨度", f"{_year(evs[0]['t'])} — {evs[-1]['t']} 年")
    W.kv("因果链", f"{len(links)} 条")
    desc = W.note("")
    W.note("拖动轴上竖线定位事件；事件卡上下交错，虚线表示因果关联。")

    def render(w, h):
        step = W.step
        Pd, axis_y = 22, h * 0.52
        x0, x1 = Pd + 8, w - Pd - 8
        t0, t1 = evs[0]["t"], evs[-1]["t"]
        span = max(1, t1 - t0)

        def tx(t):
            return x0 + (t - t0) / span * (x1 - x0)
        card_w = clamp((x1 - x0) / len(evs) - 6, 62, 104)
        gap = card_w + 6
        cxs = []
        for i, e in enumerate(evs):
            x = tx(e["t"])
            if i:
                x = max(x, cxs[i - 1] + gap)
            cxs.append(x)
        shift = cxs[-1] - (x1 - card_w / 2)
        if shift > 0:
            cxs = [x - shift for x in cxs]
        S["xs"] = cxs
        W.txt(Pd, 22, "历史时间轴", size=12, weight=700)
        W.txt(w - Pd, 22, f"{t0} — {t1}", size=10, anchor="end", fill=C.soft)
        W.line(x0 - 10, axis_y, x1 + 10, axis_y, C.faint)
        W.head(x1 + 12, axis_y, 0, 5, C.faint)
        for k in range(6):
            t = round(t0 + span * k / 5)
            x = tx(t)
            W.line(x, axis_y - 4, x, axis_y + 4, C.faint)
            W.txt(x, axis_y + 17, _year(t), size=9, anchor="middle", fill=C.faint)
        if step >= 2:
            for a, b in links:
                if a >= len(evs) or b >= len(evs):
                    continue
                ax, bx = cxs[a], cxs[b]
                ay = axis_y - 68 if a % 2 == 0 else axis_y + 68
                by = axis_y - 68 if b % 2 == 0 else axis_y + 68

                def cv(g, ax=ax, ay=ay, bx=bx, by=by):
                    g.move_to(ax, ay)
                    g.bezier_to(ax + 20, (ay + by) / 2, bx - 20, (ay + by) / 2, bx, by)
                W.stroke_path(cv, stroke=C.data[2], width=1, dash="3 4", opacity=0.7)
                W.head(bx, by, math.atan2(by - ay, bx - ax), 5, C.data[2], 0.8)
        for i, e in enumerate(evs):
            cx = cxs[i]
            up = i % 2 == 0
            ch = 56
            cy = axis_y - 34 - ch if up else axis_y + 34
            active = i == S["sel"]
            if step >= 1:
                W.line(cx, cy + ch if up else cy, cx, axis_y, C.line)
                W.circ(cx, axis_y, 2.6, fill=C.accent if active else C.ink2)
                W.rect(cx - card_w / 2, cy, card_w, ch, rx=2, fill=C.card, stroke=C.accent if active else C.line, width=1.4 if active else 1)
                W.txt(cx - card_w / 2 + 7, cy + 13, _year(e["t"]), size=9.5, fill=C.accent if active else C.faint, weight=600)
                for k, ln in enumerate(wrap_text(e["label"], card_w - 14, 10.5)[:3]):
                    W.txt(cx - card_w / 2 + 7, cy + 28 + k * 13, ln, size=10.5)
            else:
                W.circ(cx, axis_y, 2.2, fill=C.ink2, opacity=0.5)
        cur = evs[S["sel"]]
        cp = cxs[S["sel"]]
        col = C.accent if step >= 3 else C.ink2
        W.line(cp, axis_y - 20, cp, axis_y + 20, col, 1.6 if step >= 3 else 1, opacity=1 if step >= 3 else 0.6)
        W.poly([(cp - 5, axis_y - 24), (cp + 5, axis_y - 24), (cp, axis_y - 18)], fill=col, opacity=0.9)
        vY.text(_year(cur["t"]) + " 年")
        vE.text(cur["label"])
        desc.text(f"<b>{cur['label']}</b><br>{cur['desc'] or '（暂无说明）'}")
    W.set(render)

    def pick(px):
        if S["xs"]:
            S["sel"] = min(range(len(S["xs"])), key=lambda i: abs(px - S["xs"][i]))
            W.redraw()
    W.L.interact(W.c, hit=lambda x, _y: (pick(x), {"t": 1})[1], drag=lambda _o, x, _y, _dx, _dy: pick(x))


LON0, LON1, LAT0, LAT1 = 73, 135, 54, 17
DEF_POINTS = [("北京", 116.4, 39.9), ("上海", 121.5, 31.2), ("广州", 113.3, 23.1), ("成都", 104.1, 30.6), ("武汉", 114.3, 30.6), ("西安", 108.9, 34.3), ("乌鲁木齐", 87.6, 43.8)]
OUTLINE = [(73.5, 39), (80, 45), (87, 49), (96, 49), (105, 47.5), (116, 49.5), (123, 53), (127, 50), (130, 48), (134, 48.5), (131, 45), (128, 42.5), (124, 40.5), (122, 39), (121.5, 37),
           (119, 35), (121, 31.5), (120, 27), (118, 24), (115, 22.5), (110, 21.5), (108, 18.5), (102, 22), (99, 24.5), (97, 28), (92, 28), (88, 27), (82, 30), (78, 33), (75, 37)]


@mode("map")
def mount_map(W):
    D_ = W.D
    if D_.get("points"):
        pts = [{"label": p.get("label") or p.get("name") or "", "lon": float(p.get("lon", 100)), "lat": float(p.get("lat", 30)), "note": p.get("note") or "", "nx": p.get("x"), "ny": p.get("y")} for p in D_["points"]]
    else:
        pts = [{"label": a, "lon": b, "lat": c, "note": "", "nx": None, "ny": None} for a, b, c in DEF_POINTS]

    def conv(a):
        if a.get("x1") is not None:
            return float(a["x1"]), float(a["y1"]), float(a["x2"]), float(a["y2"]), a.get("label") or ""
        if a.get("lon1") is not None:
            return ((a["lon1"] - LON0) / (LON1 - LON0), (LAT0 - a["lat1"]) / (LAT0 - LAT1), (a["lon2"] - LON0) / (LON1 - LON0), (LAT0 - a["lat2"]) / (LAT0 - LAT1), a.get("label") or "")
        x, y = float(a.get("x", 0.5)), float(a.get("y", 0.4))
        return x, y, float(a["x2"]) if a.get("x2") is not None else x + 0.12, float(a["y2"]) if a.get("y2") is not None else y - 0.12, a.get("label") or ""
    arrows = [conv(a) for a in (D_.get("arrows") or [{"x1": 0.78, "y1": 0.18, "x2": 0.55, "y2": 0.42, "label": "夏季风"}, {"x1": 0.72, "y1": 0.30, "x2": 0.50, "y2": 0.55, "label": "夏季风"},
                                                     {"x1": 0.82, "y1": 0.52, "x2": 0.74, "y2": 0.30, "label": "沿岸流"}])]
    S = {"sel": -1, "grid": True, "scr": []}
    W.head_title("区域地理简图", "经纬网 · 地形水系 · 风向洋流")
    W.add_steps(["轮廓", "城市", "地形", "气流"])
    W.sec("读数")
    W.stat("标记点", len(pts), "个")
    W.stat("箭头", len(arrows), "条")
    W.kv("经度范围", "73°E — 135°E")
    W.kv("纬度范围", "17°N — 54°N")
    detail = W.note("点城市标记可读取经纬度。")
    W.toggle("经纬网", True, lambda on: (S.__setitem__("grid", on), W.redraw()))
    W.note("轮廓为示意简图。")

    def render(w, h):
        M, Tm, Rm, Bm = 26, 30, w - 22, h - 34
        iw, ih = Rm - M, Bm - Tm

        def px(lon):
            return M + (lon - LON0) / (LON1 - LON0) * iw

        def py(lat):
            return Tm + (LAT0 - lat) / (LAT0 - LAT1) * ih

        def nx(v):
            return M + clamp(v, 0, 1) * iw

        def ny(v):
            return Tm + clamp(v, 0, 1) * ih
        step = W.step
        if S["grid"]:
            for lon in range(80, 131, 10):
                W.line(px(lon), Tm, px(lon), Bm, C.grid2)
                W.txt(px(lon), Tm - 10, f"{lon}°E", size=8.5, anchor="middle", fill=C.faint)
            for lat in range(20, 51, 10):
                W.line(M, py(lat), Rm, py(lat), C.grid2)
                W.txt(M - 6, py(lat), f"{lat}°N", size=8.5, anchor="end", fill=C.faint)
        scr = [(px(a), py(b)) for a, b in OUTLINE]
        W.poly(scr, fill=C.data[4], stroke=C.data[1], width=1.2, close=True, opacity=0.95)

        def ell(cx, cy, rx, ry):
            W.stroke_path(lambda g: g.ellipse(cx, cy, rx, ry), fill=C.data[4], stroke=C.data[1], width=0.9)
        ell(px(121.2), py(23.7), 5, 9)
        ell(px(110), py(19.4), 7, 4)
        W.txt(Rm + 4, Bm - 8, "海", size=9, fill=C.faint, anchor="end")
        if step >= 2:
            for lo, la in ((88, 34), (92, 36), (96, 37), (100, 35), (104, 33), (97, 32), (101, 30)):
                x, y = px(lo), py(la)
                W.poly([(x - 7, y + 4), (x, y - 5), (x + 7, y + 4)], stroke=C.data[2], width=0.9)
            W.txt(px(88), py(35) - 14, "青藏高原", size=9, fill=C.soft, anchor="middle")
            W.txt(px(105.5), py(29.5), "四川盆地", size=8.5, fill=C.soft, anchor="middle")
            W.txt(px(116.5), py(37.5), "华北平原", size=8.5, fill=C.soft, anchor="middle")

            def yangtze(g):
                g.move_to(px(91), py(33))
                g.bezier_to(px(100), py(31), px(108), py(30.5), px(115), py(30.5))
                g.bezier_to(px(119), py(31), px(120.5), py(31.5), px(121.8), py(31.4))

            def huang(g):
                g.move_to(px(96), py(35))
                g.bezier_to(px(103), py(33.5), px(108), py(37), px(114), py(35.5))
                g.bezier_to(px(117), py(35), px(118.5), py(36.5), px(119.2), py(37.6))
            W.stroke_path(yangtze, stroke=C.data[1], width=1.2)
            W.txt(px(112), py(29.2), "长江", size=8.5, fill=C.soft)
            W.stroke_path(huang, stroke=C.data[2], width=1)
            W.txt(px(104), py(32.2), "黄河", size=8.5, fill=C.soft)
        S["scr"] = []
        for i, p in enumerate(pts):
            x = nx(p["nx"]) if p["nx"] is not None else px(p["lon"])
            y = ny(p["ny"]) if p["ny"] is not None else py(p["lat"])
            S["scr"].append((x, y))
            if step >= 1:
                sel = i == S["sel"]
                W.circ(x, y, 4.4 if sel else 3.2, fill=C.accent if sel else C.ink, stroke=C.card, width=1.4 if sel else 0.8)
                W.txt(x + 7, y - 7, p["label"], size=10, fill=C.accent if sel else C.ink, weight=700 if sel else 500)
        if step >= 3:
            for x1, y1, x2, y2, lb in arrows:
                ax, ay, bx, by = nx(x1), ny(y1), nx(x2), ny(y2)
                mx, my = (ax + bx) / 2 + 10, (ay + by) / 2 - 12

                def q(g, ax=ax, ay=ay, mx=mx, my=my, bx=bx, by=by):
                    g.move_to(ax, ay)
                    g.quad_to(mx, my, bx, by)
                W.stroke_path(q, stroke=C.data[1], width=1.2)
                W.head(bx, by, math.atan2(by - my, bx - mx), 6, C.data[1])
                if lb:
                    W.txt(ax + 4, ay - 8, lb, size=9, fill=C.soft)
        lx, ly = M, h - 12
        W.line(lx, ly, lx + 14, ly, C.data[1])
        W.txt(lx + 19, ly, "轮廓", size=8.5, fill=C.faint)
        W.circ(lx + 62, ly, 2.6, fill=C.ink)
        W.txt(lx + 69, ly, "城市", size=8.5, fill=C.faint)
        W.line(lx + 108, ly, lx + 122, ly, C.data[2])
        W.txt(lx + 127, ly, "水系", size=8.5, fill=C.faint)
        W.arrow(lx + 164, ly, lx + 184, ly, C.data[1], 1, 4)
        W.txt(lx + 189, ly, "气流", size=8.5, fill=C.faint)
    W.set(render)

    def click(x, y, _o):
        best, bd = -1, 1e9
        for i, p in enumerate(S["scr"]):
            d = math.hypot(x - p[0], y - p[1])
            if d < bd:
                best, bd = i, d
        S["sel"] = best if bd < 14 else -1
        if S["sel"] >= 0:
            p = pts[S["sel"]]
            detail.text(f"<b>{p['label']}</b>　{p['lon']}°E，{p['lat']}°N" + (f"<br>{p['note']}" if p["note"] else ""))
        else:
            detail.text("点城市标记可读取经纬度。")
        W.redraw()
    W.L.interact(W.c, click=click)
