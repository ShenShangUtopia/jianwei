"""题目视图入口：按 q.view.engine / mode 挂载到一个 Ctx 上。"""
from __future__ import annotations

import traceback

from . import sb_bio, sb_chem, sb_hum, sb_text  # noqa: F401  注册 subjects 的各个模式
from .graph import mount_graph
from .physics import mount_physics
from .sb_core import MODES, Widget
from .sb_text import mount_flow
from .solid import mount_solid
from .figure_bridge import attach


def mount(L, q) -> Widget:
    """返回有 apply_step(i) 的视图；专属视图出错时退回通用解释卡，不让一道题打不开。"""
    view = (q or {}).get("view") or {}
    engine = view.get("engine")
    W = Widget(L, q)
    if engine == "subjects":
        m = str(view.get("mode") or "").lower()
        fn = MODES.get(m)
        if fn:
            fn(W)
        else:
            mount_flow(W, unknown=m or "（空）")
        return attach(W)
    if engine == "physics":
        mount_physics(W)
        return attach(W)
    if engine == "graph":
        mount_graph(W)
        return attach(W)
    if engine == "solid":
        mount_solid(W)
        return attach(W)
    mount_flow(W, unknown=f"{engine}（这个引擎还没有）")
    return attach(W)


def safe_mount(L, q):
    try:
        return mount(L, q), None
    except Exception as exc:  # noqa: BLE001
        traceback.print_exc()
        return None, f"{type(exc).__name__}: {exc}"
