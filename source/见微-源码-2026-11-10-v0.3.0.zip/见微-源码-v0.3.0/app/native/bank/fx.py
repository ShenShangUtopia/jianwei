"""题面里的轻量 TeX → Qt 富文本（对应旧 JW.fx）。Qt 富文本支持 sup / sub，分数写成 a/b 的上下标形式。"""
from __future__ import annotations

import html
import re

_SYMS = [(r"\pi", "π"), (r"\alpha", "α"), (r"\beta", "β"), (r"\theta", "θ"), (r"\omega", "ω"), (r"\varphi", "φ"), (r"\phi", "φ"), (r"\Delta", "Δ"), (r"\mu", "μ"), (r"\lambda", "λ"),
         (r"\times", "×"), (r"\cdot", "·"), (r"\pm", "±"), (r"\le", "≤"), (r"\ge", "≥"), (r"\neq", "≠"), (r"\Rightarrow", "⇒"), (r"\to", "→"), (r"\infty", "∞"), (r"\angle", "∠"),
         (r"\circ", "°"), (r"\left", ""), (r"\right", "")]


def fx(tex) -> str:
    s = html.escape(str("" if tex is None else tex), quote=False)
    s = re.sub(r"\\d?frac\{([^{}]*)\}\{([^{}]*)\}", r"<sup>\1</sup>⁄<sub>\2</sub>", s)
    s = re.sub(r"\\sqrt\{([^{}]*)\}", r"√(\1)", s)
    for a, b in _SYMS:
        s = s.replace(a, b)
    s = re.sub(r"\^(-?\d+|[^<\s])", r"<sup>\1</sup>", s)
    s = re.sub(r"_(\d+|[^<\s])", r"<sub>\1</sub>", s)
    return s
