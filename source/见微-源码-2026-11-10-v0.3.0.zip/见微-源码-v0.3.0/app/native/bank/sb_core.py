"""题目视图的公共底层（对应旧 views/subjects.js 的 SVG 基础与 Widget）。

旧版每次重绘都重建 SVG；这里每次 paint 直接用 QPainter 画，写法保持一致：
line / rect / circ / poly / txt / arrow 都接受 opacity、dash 等同名参数。
一个模式 = 函数 mount_xxx(W)，W.set(fn) 登记绘制函数 fn(w, h)，W.step 是当前解题步骤。
"""
from __future__ import annotations

import re

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QWidget

from ..design.tokens import T, alpha, family, qc
from ..kit.core import clamp
from ..kit.draw import D


class _C:
    """旧 JW.C 调色板映射到 2.0 令牌（昼夜跟随）。data[4] 原是极浅的填充色。"""
    ink = property(lambda s: T.fg)
    ink2 = property(lambda s: T.math)
    accent = property(lambda s: T.phys)
    jade = property(lambda s: T.chem)
    gold = property(lambda s: T.c4)
    soft = property(lambda s: T.muted)
    faint = property(lambda s: T.axis)
    card = property(lambda s: T.surface)
    paper = property(lambda s: T.stage)
    line = property(lambda s: T.line)
    line2 = property(lambda s: T.line2)
    grid = property(lambda s: T.grid)
    grid2 = property(lambda s: T.grid2)
    data = property(lambda s: [T.fg, T.math, T.c1, alpha(T.c1, 0.5), alpha(T.c1, 0.22)])


C = _C()


def num(v, d=2):
    if v is None:
        return "—"
    s = f"{float(v):.{max(0, d)}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def _col(c, opacity=None):
    if opacity is None or opacity >= 1:
        return c
    q = qc(c)
    return alpha(q, q.alphaF() * max(0.0, opacity))


def _dash(d):
    if not d:
        return None
    return [float(x) for x in d.split()] if isinstance(d, str) else list(d)


def tw(s, size):
    """文字宽度估算（和旧版一致，排版计算里用，不必真的量字）。"""
    w = 0.0
    for ch in str("" if s is None else s):
        c = ord(ch)
        w += 1 if c > 0x2e7f else 0.3 if c == 32 else 0.56
    return w * size


def wrap_text(s, max_w, size):
    st = str("" if s is None else s)
    out = []
    # 拉丁文按词折行，中文按字折行——否则英文会被拦腰截断
    if re.search(r"[A-Za-z]", st) and not re.search(r"[一-鿿]", st) and " " in st:
        cur = ""
        for word in st.split():
            nxt = f"{cur} {word}" if cur else word
            if cur and tw(nxt, size) > max_w:
                out.append(cur)
                cur = word
            else:
                cur = nxt
        if cur:
            out.append(cur)
        return out
    cur = ""
    for ch in st:
        if ch == "\n":
            out.append(cur)
            cur = ""
            continue
        if cur and tw(cur + ch, size) > max_w:
            out.append(cur)
            cur = ch
        else:
            cur += ch
    if cur:
        out.append(cur)
    return out


SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")


def sub_num(s):
    return str(s).translate(SUB)


class Reading:
    """检查器里的一个读数：r.text("…")、可选颜色。"""

    def __init__(self, label: QLabel):
        self.label = label
        self._last = None

    def text(self, s, color=None):
        key = (s, color)
        if key == self._last:
            return
        self._last = key
        try:
            self.label.setText(str(s))
            if color is not None:
                self.label.setStyleSheet(f"color:{qc(color).name()};")
        except RuntimeError:
            pass


class Widget:
    """一个题目视图：画布 + 检查器。"""

    def __init__(self, L, q):
        self.L = L
        self.q = q or {}
        self.c = L.canvas()
        self.view = self.q.get("view") or {}
        self.P = self.view.get("params") or {}
        self.D = {**self.view, **(self.view.get("data") or {})}
        self.step = 0
        self.w, self.h = 800, 440
        self.g = None
        self.render_fn = None
        self.step_label = None
        self.step_names = []
        L.on_draw(self._paint)

    def _paint(self):
        c = self.c
        c.clear()
        self.g = c.g
        self.w, self.h = c.w, c.h
        if self.render_fn:
            self.render_fn(c.w, c.h)

    def set(self, fn):
        self.render_fn = fn
        self.L.draw()

    def redraw(self):
        self.L.draw()

    def apply_step(self, i):
        self.step = max(0, round(i or 0))
        self._sync_steps()
        self.redraw()

    def destroy(self):
        pass

    # ---- 画笔
    def line(self, x1, y1, x2, y2, stroke=None, width=1, dash=None, opacity=None):
        g = self.g
        g.line_cap = "round"
        D.line(g, x1, y1, x2, y2, _col(stroke if stroke is not None else C.line, opacity), width, _dash(dash))
        g.line_cap = "butt"

    def rect(self, x, y, w, h, fill=None, stroke=None, width=1, rx=0, dash=None, opacity=None):
        w, h = max(0, w), max(0, h)
        g = self.g
        f = _col(fill, opacity) if fill is not None else None
        s = _col(stroke, opacity) if stroke is not None else None
        if dash and s is not None:
            if f is not None:
                D.rrect(g, x, y, w, h, rx, f)
            g.begin_path()
            g.round_rect(x, y, w, h, rx)
            g.stroke_style, g.line_width, g.dash = s, width, _dash(dash)
            g.stroke()
            g.dash = []
        elif rx:
            D.rrect(g, x, y, w, h, rx, f, s, width)
        else:
            D.rect(g, x, y, w, h, f, s, width)

    def circ(self, cx, cy, r, fill=None, stroke=None, width=1, dash=None, opacity=None):
        g = self.g
        f = _col(fill, opacity) if fill is not None else None
        s = _col(stroke, opacity) if stroke is not None else None
        if dash and s is not None:
            if f is not None:
                D.circle(g, cx, cy, r, f)
            g.begin_path()
            g.arc(cx, cy, max(0, r), 0, 6.283185)
            g.stroke_style, g.line_width, g.dash = s, width, _dash(dash)
            g.stroke()
            g.dash = []
        else:
            D.circle(g, cx, cy, r, f, s, width)

    def poly(self, pts, fill=None, stroke=None, width=1.2, close=False, dash=None, opacity=None):
        """折线 / 多边形（旧版 path 的直线段情形）。"""
        if len(pts) < 2:
            return
        g = self.g
        if fill is not None:
            D.poly(g, pts, _col(fill, opacity))
        if stroke is not None:
            g.begin_path()
            for i, p in enumerate(pts):
                (g.line_to if i else g.move_to)(p[0], p[1])
            if close:
                g.close_path()
            g.stroke_style, g.line_width, g.dash, g.line_cap, g.line_join = _col(stroke, opacity), width, _dash(dash) or [], "round", "round"
            g.stroke()
            g.dash, g.line_cap, g.line_join = [], "butt", "miter"

    def stroke_path(self, build, fill=None, stroke=None, width=1.2, dash=None, opacity=None):
        """任意路径：build(g) 里 move_to / quad_to / bezier_to。"""
        g = self.g
        g.begin_path()
        build(g)
        if fill is not None:
            g.fill_style = _col(fill, opacity)
            g.fill()
        if stroke is not None:
            g.stroke_style, g.line_width, g.dash, g.line_cap, g.line_join = _col(stroke, opacity), width, _dash(dash) or [], "round", "round"
            g.stroke()
            g.dash, g.line_cap, g.line_join = [], "butt", "miter"

    def txt(self, x, y, s, size=12, fill=None, anchor="start", weight=400, serif=False, mono=False, opacity=None):
        align = {"start": "left", "middle": "center", "end": "right"}.get(anchor, anchor)
        D.text(self.g, "" if s is None else str(s), x, y, _col(fill if fill is not None else C.ink, opacity), size=size, bold=weight >= 600, mono=mono, align=align, serif=serif)

    def arrow(self, x1, y1, x2, y2, stroke=None, width=1.3, size=7, dash=None, opacity=None):
        import math
        col = stroke if stroke is not None else C.ink2
        self.line(x1, y1, x2, y2, col, width, dash, opacity)
        a = math.atan2(y2 - y1, x2 - x1)
        self.head(x2, y2, a, size, col, opacity)

    def head(self, x, y, ang, size=7, color=None, opacity=None):
        import math
        col = _col(color if color is not None else C.ink2, opacity)
        D.poly(self.g, [(x, y), (x - size * math.cos(ang - 0.42), y - size * math.sin(ang - 0.42)), (x - size * math.cos(ang + 0.42), y - size * math.sin(ang + 0.42))], col)

    def text_block(self, x, y, s, max_w, size=12, lh=None, **o):
        """折行文字，返回下一行的 y。"""
        lh = lh or size * 1.5
        for ln in wrap_text(s, max_w, size):
            self.txt(x, y, ln, size=size, **o)
            y += lh
        return y

    # ---- 检查器
    def head_title(self, title, sub=""):
        self.L.group(title)
        if sub:
            self.L.note(sub)

    def sec(self, title):
        self.L.group(title)

    def add_steps(self, labels):
        self.step_names = list(labels)
        lb = QLabel()
        lb.setTextFormat(Qt.TextFormat.RichText)
        lb.setWordWrap(True)
        self.L._add(lb)
        self.step_label = lb
        self._sync_steps()

    def _sync_steps(self):
        if not self.step_label:
            return
        parts = []
        for k, n in enumerate(self.step_names):
            on = k <= self.step
            parts.append(f"<span style='color:{qc(T.accent if k == self.step else T.soft if on else T.faint).name()};{'font-weight:600' if k == self.step else ''}'>{n}</span>")
        try:
            self.step_label.setText(f"<span style='color:{qc(T.faint).name()}'> → </span>".join(parts))
        except RuntimeError:
            pass

    def kv(self, k, v=None, unit=""):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 1, 0, 1)
        h.setSpacing(8)
        a = QLabel(k)
        a.setObjectName("ctlLabel")
        a.setWordWrap(True)
        b = QLabel("—" if v is None else str(v))
        b.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        b.setWordWrap(True)
        b.setStyleSheet(f"color:{qc(T.fg).name()};font-weight:600;font-family:'{family('num')}';")
        h.addWidget(a, 0)
        h.addWidget(b, 1)
        if unit:
            u = QLabel(unit)
            u.setObjectName("ctlLabel")
            h.addWidget(u, 0)
        self.L._add(w)
        return Reading(b)

    stat = kv

    def note(self, html):
        lb = self.L.note(html)
        return Reading(lb)

    def legend(self, items):
        return self.L.legend([(it[0], it[1]) for it in items])

    def chips(self, items, cur, cb):
        return self.L.seg("", [[x, x] for x in items], cur, cb)

    def toggle(self, label, on, cb):
        return self.L.check(label, on, cb)

    def range(self, label, mn, mx, step, value, cb, dec=None, unit=""):
        return self.L.slider(label, mn, mx, step, value, cb, unit, dec)

    def button(self, label, cb, pri=False):
        return self.L.button(label, lambda _b: cb(), pri)


# 模式注册
MODES: dict = {}


def mode(name):
    def deco(fn):
        MODES[name] = fn
        return fn
    return deco


def _unused():
    _ = clamp
