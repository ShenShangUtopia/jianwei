"""物理过程视图的底层（由 views/physics.js 改写）：世界坐标画布 Cv、标注工具、Scene 基类。

一个场景 = Scene 的子类：
    P            参数（SimpleNamespace，题目 view.params 同名字段会注入）
    sliders      [(键, 标签, 最小, 最大, 步长, 小数位)]
    chips        [Chip(标签, 选项, 回调)]
    hints        解题三阶段的提示
    hot          每阶段高亮的读数下标
    one_shot     True = 走完停住；False = 循环
    duration() / draw(cv, t, lv) / readouts(t) / status(t) / aux(src) / drag(phase, x, y)
"""
from __future__ import annotations

import math
from types import SimpleNamespace

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QPainter, QPainterPath, QPen

from ..design.tokens import alpha, font, qc
from ..kit.core import clamp, nice_step
from ..kit.draw import D
from .sb_core import C

PI, TAU = math.pi, math.tau
sin, cos, sqrt, hypot, atan2 = math.sin, math.cos, math.sqrt, math.hypot, math.atan2
rad = math.radians
DT = 1 / 240
INF = math.inf

# ---------------------------------------------------------------- 讲题模式
# 析题页一步一步讲时，物理视图在 draw 之前把 LESSON 设成 {"focus": {...}}，画完设回 None。
# 箭头、尺寸线、标注按文字里的符号认出是哪个量：讲到的量加粗发光，其他箭头变淡；颜色统一用 design.quantity。
# 习题台等其他地方 LESSON 是 None，画法完全不变。
LESSON = None
_TAG = None


def tag_of(text):
    """'vx' → vx；'射程 R = 30 m' → R；'a = 4.0 m/s²' → a。"""
    global _TAG
    if _TAG is None:
        import re
        _TAG = re.compile(r"(?:^|[\s　：:])([A-Za-zα-ωΔ][A-Za-z0-9₀-₉ₓᵧ合]{0,3})\s*[=≈]")
    s = str(text or "").strip()
    if not s:
        return ""
    if len(s) <= 4 and " " not in s:
        return s if ("A" <= s[0] <= "z" or "α" <= s[0] <= "ω" or s[0] == "Δ") else ""
    m = _TAG.search(s)
    return m.group(1) if m else ""


def lesson_style(text, color, w):
    """讲题模式下这个元素的 (颜色, 线宽, 透明度, 是否讲到)；非讲题模式原样返回。"""
    if LESSON is None:
        return color, w, 1.0, False
    from ..design.quantity import color as qcolor
    tag = tag_of(text)
    col = qcolor(tag) or color if tag else color
    focus = LESSON.get("focus") or set()
    if not focus:
        return col, w, 1.0, False
    if tag and tag in focus:
        return col, w * 1.8, 1.0, True
    return col, w, 0.28, False


def _glow(g, path_fn, color, w):
    """讲到的元素底下垫一层宽而淡的同色描边。"""
    pen = QPen(alpha(qc(color), 0.22), w + 7)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    g.p.save()
    g.p.setPen(pen)
    path_fn(g.p)
    g.p.restore()


def fmt(v, d=2):
    """定点数：去掉尾零（和旧 JW.num 一致），不是有限数时给破折号。"""
    if v is None or not math.isfinite(v):
        return "—"
    s = f"{v:.{max(0, d)}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def wrap01(v):
    return v % 1.0


def nice(span):
    raw = max(1e-9, abs(span) / 7)
    mag = 10 ** math.floor(math.log10(raw))
    n = raw / mag
    return (1 if n < 1.5 else 2 if n < 3 else 5 if n < 7 else 10) * mag


class Cv:
    """一块世界坐标画布：px/py 世界 → 像素，dx/dy 像素 → 世界。g 是当帧画笔。"""

    def __init__(self, c):
        self.c = c
        self.xr, self.yr = [-6.0, 6.0], [-4.0, 4.0]

    @property
    def g(self):
        return self.c.g

    w = property(lambda s: s.c.w)
    h = property(lambda s: s.c.h)

    def set_range(self, xr, yr):
        self.xr, self.yr = list(xr), list(yr)

    def px(self, x):
        return (x - self.xr[0]) / (self.xr[1] - self.xr[0]) * self.w

    def py(self, y):
        return self.h - (y - self.yr[0]) / (self.yr[1] - self.yr[0]) * self.h

    def sx(self):
        return self.w / (self.xr[1] - self.xr[0])

    def sy(self):
        return self.h / (self.yr[1] - self.yr[0])

    def dx(self, px):
        return self.xr[0] + px / self.w * (self.xr[1] - self.xr[0])

    def dy(self, py):
        return self.yr[0] + (self.h - py) / self.h * (self.yr[1] - self.yr[0])

    def clear(self):
        self.c.clear()

    def line(self, x1, y1, x2, y2, color=None, width=1.0, dash=None):
        g = self.g
        g.line_cap = "round"
        D.line(g, self.px(x1), self.py(y1), self.px(x2), self.py(y2), color or C.ink, width, dash)
        g.line_cap = "butt"

    def arrow(self, x1, y1, x2, y2, color=None, width=1.6, head=8, dash=None):
        p_arrow(self, self.px(x1), self.py(y1), self.px(x2), self.py(y2), color or C.ink, width, head, dash)

    def grid(self, step, labels=False, grid=None):
        """细网格 + 过原点的坐标轴；网格线攒成一条路径，一次描完。"""
        g = self.g
        x0, x1, y0, y1 = self.xr[0], self.xr[1], self.yr[0], self.yr[1]
        n = (x1 - x0) / step + (y1 - y0) / step
        if not (0 < n < 240):
            step = nice(max(x1 - x0, y1 - y0))
        path = QPainterPath()
        for k in range(math.ceil(x0 / step), math.floor(x1 / step) + 1):
            x = round(self.px(k * step)) + 0.5
            path.moveTo(x, 0)
            path.lineTo(x, self.h)
        for k in range(math.ceil(y0 / step), math.floor(y1 / step) + 1):
            y = round(self.py(k * step)) + 0.5
            path.moveTo(0, y)
            path.lineTo(self.w, y)
        aa = g.p.testRenderHint(QPainter.RenderHint.Antialiasing)
        g.p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        g.p.strokePath(path, g._pen(grid or C.grid, 1, []))
        axes = QPainterPath()
        ay, ax = self.py(0), self.px(0)
        if 0 <= ay <= self.h:
            axes.moveTo(0, round(ay) + 0.5)
            axes.lineTo(self.w, round(ay) + 0.5)
        if 0 <= ax <= self.w:
            axes.moveTo(round(ax) + 0.5, 0)
            axes.lineTo(round(ax) + 0.5, self.h)
        g.p.strokePath(axes, g._pen(C.faint, 1, []))
        g.p.setRenderHint(QPainter.RenderHint.Antialiasing, aa)
        if labels:
            ly = clamp(ay + 10, 10, self.h - 12)
            lx = clamp(ax + 4, 4, self.w - 34)
            for k in range(math.ceil(x0 / step), math.floor(x1 / step) + 1):
                if k:
                    D.text(g, fmt(k * step, 3), self.px(k * step), ly, C.faint, size=9.5, align="center", mono=True)
            for k in range(math.ceil(y0 / step), math.floor(y1 / step) + 1):
                if k:
                    D.text(g, fmt(k * step, 3), lx, self.py(k * step), C.faint, size=9.5, mono=True)


def view_rect(cv, x0, x1, y0, y1, pad=0.03, uniform=False):
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    hw = max((x1 - x0) / 2, 1e-6) * (1 + pad * 2)
    hh = max((y1 - y0) / 2, 1e-6) * (1 + pad * 2)
    if uniform:
        ar = max(0.2, cv.w / max(1, cv.h))
        if hw / hh < ar:
            hw = hh * ar
        else:
            hh = hw / ar
    cv.set_range([cx - hw, cx + hw], [cy - hh, cy + hh])


def grid_of(cv, span, labels=True):
    cv.grid(nice(span), labels)


def plabel(cv, x, y, s, color=None, size=11, weight=600, align="left", base="middle", halo=True, mono=False, halo_color=None):
    """像素坐标的标注，默认带一圈底色描边，压在线上也读得清。"""
    g = cv.g
    s = str(s)
    if halo:
        f = font(size, 600 if weight >= 600 else 400, "mono" if mono else "ui")
        w = D.measure(s, size, weight >= 600, mono)
        k = {"left": 0, "center": 0.5, "right": 1}.get(align, 0)
        path = QPainterPath()
        path.addText(QPointF(x - w * k, y + size * 0.36), f, s)
        pen = QPen(qc(halo_color or C.paper), 3.4)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        g.p.strokePath(path, pen)
    D.text(g, s, x, y, color or C.ink, size=size, bold=weight >= 600, mono=mono, align=align, base=base)


def label(cv, x, y, s, color=None, size=11, ox=0, oy=0, **o):
    if LESSON is not None:
        col, _w, a, hot = lesson_style(s, color, 1)
        if a < 1 and tag_of(s):
            col = alpha(qc(col or C.ink), 0.45)
        color, size = col, (size + 2.5 if hot else size)
    plabel(cv, cv.px(x) + ox, cv.py(y) + oy, s, color, size, **o)


def polyline(cv, pts, color=None, w=1.6, dash=None, alpha_=None):
    """世界坐标折线。"""
    if not pts or len(pts) < 2:
        return
    g = cv.g
    path = QPainterPath(QPointF(cv.px(pts[0][0]), cv.py(pts[0][1])))
    for p in pts[1:]:
        path.lineTo(cv.px(p[0]), cv.py(p[1]))
    col = qc(color or C.ink)
    if alpha_ is not None:
        col = alpha(col, col.alphaF() * alpha_)
    pen = g._pen(col, w, dash or [])
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    g.p.strokePath(path, pen)


def shape(cv, pts, fill=None, stroke=None, width=1.4, alpha_=None, dash=None):
    if not pts or len(pts) < 2:
        return
    g = cv.g
    path = QPainterPath(QPointF(cv.px(pts[0][0]), cv.py(pts[0][1])))
    for p in pts[1:]:
        path.lineTo(cv.px(p[0]), cv.py(p[1]))
    path.closeSubpath()
    if fill:
        col = qc(fill)
        if alpha_ is not None:
            col = alpha(col, col.alphaF() * alpha_)
        g.p.fillPath(path, col)
    if stroke:
        g.p.strokePath(path, g._pen(stroke, width, dash or []))


def dot(cv, x, y, r, fill=None, stroke=None, lw=1.5):
    D.circle(cv.g, cv.px(x), cv.py(y), max(0.5, r), fill, stroke, lw)


def ring_world(cv, x, y, r, color, w=1.2, dash=None):
    g = cv.g
    g.p.setPen(g._pen(color, w, dash or []))
    g.p.setBrush(Qt.BrushStyle.NoBrush)
    rp = max(1, r * cv.sx())
    g.p.drawEllipse(QPointF(cv.px(x), cv.py(y)), rp, rp)


def vec(cv, x, y, dx, dy, color, w=1.7, text=None, size=10.5, head=8, dash=None):
    if abs(dx) < 1e-9 and abs(dy) < 1e-9:
        return
    hot = False
    if LESSON is not None:
        color, w, a, hot = lesson_style(text, color, w)
        if a < 1:
            color = alpha(qc(color), a)
        if hot:
            x1, y1, x2, y2 = cv.px(x), cv.py(y), cv.px(x + dx), cv.py(y + dy)
            _glow(cv.g, lambda p: p.drawLine(QPointF(x1, y1), QPointF(x2, y2)), color, w)
            head = head + 4
    cv.arrow(x, y, x + dx, y + dy, color, w, head, dash)
    if text:
        ax, ay = (-1 if dx < 0 else 1), (-1 if dy < 0 else 1)
        _ = ay
        plabel(cv, cv.px(x + dx) + (6 if dx == 0 else ax * 5), cv.py(y + dy) + (-9 if dy == 0 else (-9 if dy < 0 else 12)), text, color,
               size + (3 if hot else 0), weight=700, align="right" if dx < 0 else "left")


def dim_line(cv, a, b, text, color=None, dx=0, dy=13):
    g = cv.g
    col = color or C.ink2
    lw, hot = 1, False
    if LESSON is not None:
        col, lw, a_, hot = lesson_style(text, col, 1)
        if a_ < 1:
            col = alpha(qc(col), a_)
    ax, ay, bx, by = cv.px(a[0]), cv.py(a[1]), cv.px(b[0]), cv.py(b[1])
    if hot:
        _glow(g, lambda p: p.drawLine(QPointF(ax, ay), QPointF(bx, by)), col, lw)
    D.line(g, ax, ay, bx, by, col, lw, [4, 4] if not hot else [])
    ang = atan2(by - ay, bx - ax)
    nx, ny = cos(ang + PI / 2) * 4.5, sin(ang + PI / 2) * 4.5
    D.line(g, ax - nx, ay - ny, ax + nx, ay + ny, col, lw)
    D.line(g, bx - nx, by - ny, bx + nx, by + ny, col, lw)
    plabel(cv, (ax + bx) / 2 + dx, (ay + by) / 2 + dy, text, col, 10.5 + (3 if hot else 0), align="center")


def angle_arc(cv, cx, cy, r, a0, a1, color, text=None):
    pts = [(cx + r * cos(a0 + (a1 - a0) * i / 24), cy + r * sin(a0 + (a1 - a0) * i / 24)) for i in range(25)]
    polyline(cv, pts, color, 1.2)
    if text:
        am = (a0 + a1) / 2
        label(cv, cx + r * cos(am), cy + r * sin(am), text, color, 10.5, align="center", oy=-10 if sin(am) > 0 else 12)


def panel(cv, x, y, w, h):
    D.rect(cv.g, x + 0.5, y + 0.5, w, h, C.card, C.line2, 1)


def bars_panel(cv, x, y, w, rows, title=""):
    """rows: (标签, 读数, 比例, 颜色)。"""
    g = cv.g
    h = 24 + len(rows) * 26
    panel(cv, x, y, w, h)
    D.text(g, title, x + 10, y + 13, C.faint, size=9.5, bold=True)
    for i, (lb, text, frac, col) in enumerate(rows):
        yy = y + 31 + i * 26
        D.text(g, lb, x + 10, yy, C.soft, size=10.5)
        D.text(g, text, x + w - 10, yy, C.ink, size=10, bold=True, mono=True, align="right")
        g.p.fillRect(QRectF(x + 10, yy + 7, w - 20, 5), qc(C.line2))
        g.p.fillRect(QRectF(x + 10, yy + 7, (w - 20) * clamp(frac or 0, 0, 1), 5), qc(col))


def spring_coil(cv, x1, x2, y, coils, amp):
    X1, X2, Y = cv.px(x1), cv.px(x2), cv.py(y)
    span = X2 - X1
    if span < 6:
        return
    n = max(4, coils) * 2
    step = span / (n + 2)
    pts = [(X1, Y), (X1 + step, Y)]
    for i in range(n):
        pts.append((X1 + step * (i + 1.5), Y + (-amp if i % 2 else amp)))
    pts += [(X2 - step, Y), (X2, Y)]
    D.poly(cv.g, pts, None, C.ink2, 1.5, False)


def path_table(pts):
    tab = [0.0]
    for i in range(1, len(pts)):
        tab.append(tab[i - 1] + hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]))
    return tab


def path_point(pts, tab, f):
    if not pts:
        return (0, 0, 0)
    total = tab[-1] if tab else 0
    if len(pts) == 1 or total < 1e-9:
        return (pts[0][0], pts[0][1], 0)
    s = clamp(f, 0, 1) * total
    i = 1
    while i < len(tab) - 1 and tab[i] < s:
        i += 1
    a, b = pts[i - 1], pts[i]
    seg = (tab[i] - tab[i - 1]) or 1e-9
    k = clamp((s - tab[i - 1]) / seg, 0, 1)
    return (a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, atan2(b[1] - a[1], b[0] - a[0]))


def p_arrow(cv, x1, y1, x2, y2, color, w=1.6, head=7, dash=None):
    """像素坐标箭头。"""
    g = cv.g
    if abs(x2 - x1) + abs(y2 - y1) < 0.01:
        return
    ang = atan2(y2 - y1, x2 - x1)
    g.line_cap = "round"
    D.line(g, x1, y1, x2, y2, color, w, dash)
    g.line_cap = "butt"
    D.poly(g, [(x2, y2), (x2 - head * cos(ang - 0.42), y2 - head * sin(ang - 0.42)), (x2 - head * cos(ang + 0.42), y2 - head * sin(ang + 0.42))], color)


def p_flow(cv, pts, color=None, dash=None, offset=0, w=2, alpha_=None):
    """像素坐标的流动虚线：offset 让虚线沿路径走起来。"""
    if not pts or len(pts) < 2:
        return
    g = cv.g
    path = QPainterPath(QPointF(pts[0][0], pts[0][1]))
    for p in pts[1:]:
        path.lineTo(p[0], p[1])
    col = qc(color or C.ink2)
    if alpha_ is not None:
        col = alpha(col, col.alphaF() * alpha_)
    pen = QPen(col, w)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    if dash:
        pen.setDashPattern([max(0.1, v / max(0.5, w)) for v in dash])
        pen.setDashOffset(offset / max(0.5, w))
    g.p.strokePath(path, pen)


def is_light(col):
    q = qc(col)
    return 0.299 * q.red() + 0.587 * q.green() + 0.114 * q.blue() > 158


def on_color(col):
    return "#081F5C" if is_light(col) else "#FFFFFF"


def tag_box(cv, x, y, text, color=None, align="left"):
    g = cv.g
    w = D.measure(text, 10, True) + 14
    h = 18
    x0 = x - (w / 2 if align == "center" else w if align == "right" else 0)
    y0 = y - h / 2
    D.rrect(g, x0 + 0.5, y0 + 0.5, w, h, 2, C.card, C.line2, 1)
    D.text(g, text, x0 + w / 2, y0 + h / 2 + 0.5, color or C.ink2, size=10, bold=True, align="center")


def frame_panel(cv, x, y, w, h, title=""):
    panel(cv, x, y, w, h)
    if title:
        D.text(cv.g, title, x + 9, y + 11, C.faint, size=9, bold=True)
    return SimpleNamespace(x=x + 9, y=y + 19, w=w - 18, h=max(18, h - 27))


def fill_circle(cv, x, y, r, color, a=None):
    col = qc(color)
    if a is not None:
        col = alpha(col, col.alphaF() * a)
    D.circle(cv.g, x, y, r, col)


def stroke_arc(cv, x, y, r, a0, a1, color, w=1.2, a=None, dash=None):
    g = cv.g
    col = qc(color)
    if a is not None:
        col = alpha(col, col.alphaF() * a)
    g.begin_path()
    g.arc(x, y, r, a0, a1)
    g.p.strokePath(g.path, g._pen(col, w, dash or []))


def march_squares(fn, xr, yr, level, nx=54, ny=38):
    """等值线（marching squares），返回世界坐标线段。"""
    segs = []
    dx, dy = (xr[1] - xr[0]) / nx, (yr[1] - yr[0]) / ny
    val = [[fn(xr[0] + i * dx, yr[0] + j * dy) - level for i in range(nx + 1)] for j in range(ny + 1)]

    def ip(x1, y1, v1, x2, y2, v2):
        k = v1 / (v1 - v2)
        return (x1 + (x2 - x1) * k, y1 + (y2 - y1) * k)
    for j in range(ny):
        for i in range(nx):
            x0, y0 = xr[0] + i * dx, yr[0] + j * dy
            x1, y1 = x0 + dx, y0 + dy
            v00, v10, v11, v01 = val[j][i], val[j][i + 1], val[j + 1][i + 1], val[j + 1][i]
            pts = []
            if (v00 > 0) != (v10 > 0):
                pts.append(ip(x0, y0, v00, x1, y0, v10))
            if (v10 > 0) != (v11 > 0):
                pts.append(ip(x1, y0, v10, x1, y1, v11))
            if (v11 > 0) != (v01 > 0):
                pts.append(ip(x1, y1, v11, x0, y1, v01))
            if (v01 > 0) != (v00 > 0):
                pts.append(ip(x0, y1, v01, x0, y0, v00))
            if len(pts) == 2:
                segs.append((pts[0], pts[1]))
            elif len(pts) == 4:
                segs.append((pts[0], pts[1]))
                segs.append((pts[2], pts[3]))
    return segs


class Chip:
    def __init__(self, label, items, set_fn, index=0):
        self.label, self.items, self.set, self.index = label, items, set_fn, index


class Scene:
    one_shot = False
    sliders: list = []
    hints: list = []
    hot: list = []
    has_drag = False

    def __init__(self):
        self.P = SimpleNamespace(**self.defaults())
        self.sliders = [list(s) for s in type(self).sliders]
        self.chips = self.make_chips()

    def defaults(self) -> dict:
        return {}

    def make_chips(self) -> list:
        return []

    def aux(self, src):
        pass

    def duration(self):
        return 4

    def draw(self, cv, t, lv):
        pass

    def readouts(self, t):
        return []

    def status(self, t):
        return ""

    def drag(self, phase, x, y):
        pass


# 场景注册
SCENES: dict = {}


def scene(kind):
    def deco(cls):
        SCENES[kind] = cls
        return cls
    return deco


def _unused():
    _ = nice_step
