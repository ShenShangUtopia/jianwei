"""物理场景（一）：抛体、斜面、弹簧振子、匀速圆周、横波、半圆玻璃砖。"""
from __future__ import annotations

import math

from ..kit.core import clamp
from ..kit.draw import D
from .ph_core import (PI, TAU, Scene, angle_arc, bars_panel, cos, dim_line, dot, fill_circle, fmt, frame_panel, grid_of, label, plabel,
                      polyline, rad, ring_world, scene, shape, sin, spring_coil, sqrt, stroke_arc, tag_box, vec, view_rect)
from .sb_core import C


@scene("projectile")
class Projectile(Scene):
    one_shot = True
    sliders = [("v0", "初速 v₀", 5, 40, 1, 0), ("angle", "抛射角 θ", 0, 85, 1, 0), ("h0", "高度 h₀", 0, 20, 0.5, 1)]
    hints = ["场景与已知量：初速、抛射角、离地高度，g 取 10 m/s²。", "运动分解：水平匀速 v₀cosθ，竖直匀变速 v₀sinθ − gt。", "合成两个分量，得到射程、飞行时间与最大高度。"]
    hot = [[3], [3], [0, 1, 2, 4]]

    def defaults(self):
        return dict(v0=20, angle=45, h0=0, g=10)

    def met(self):
        P = self.P
        th = rad(P.angle)
        vx, vy = P.v0 * cos(th), P.v0 * sin(th)
        Tf = (vy + sqrt(vy * vy + 2 * P.g * P.h0)) / P.g
        return vx, vy, Tf, vx * Tf, P.h0 + vy * vy / (2 * P.g), vx * (vy / P.g)

    def duration(self):
        return max(0.5, self.met()[2])

    def draw(self, cv, t, lv):
        P = self.P
        vx, vy0, Tf, R, H, xp = self.met()
        g = P.g
        Tf, R, H = max(Tf, 0.25), max(R, 0.5), max(H, 0.5)
        tt = clamp(t, 0, Tf)
        x0, x1, y0, y1 = -0.05 * R, 1.05 * R, -0.12 * H, 1.18 * H
        view_rect(cv, x0, x1, y0, y1, 0.01, True)
        if (y1 - y0) / max(1e-6, cv.yr[1] - cv.yr[0]) < 0.42:
            view_rect(cv, x0, x1, y0, y1, 0.01, False)
            label(cv, cv.xr[0], cv.yr[0], "纵向放大显示", C.faint, 9.5, weight=500, ox=8, oy=-10)
        grid_of(cv, R * 1.1)
        cv.line(cv.xr[0], 0, cv.xr[1], 0, C.line, 2)
        label(cv, cv.xr[0], 0, "地面", C.faint, 9.5, ox=8, oy=11, weight=500)

        def pos(s):
            return vx * s, P.h0 + vy0 * s - 0.5 * g * s * s
        polyline(cv, [pos(Tf * i / 60) for i in range(61)], C.data[3], 1.2, [4, 4], 0.9)
        n = 48
        for i in range(n):
            px, py = pos(tt * i / n)
            dot(cv, px, py, 1.4 + 1.2 * i / n, C.ink2)
        polyline(cv, [pos(tt * i / n) for i in range(n + 1)], C.ink2, 1.9)
        bx, by = pos(tt)
        cv.g.begin_path()
        cv.g.ellipse(cv.px(bx), cv.py(0), 9, 3)
        cv.g.global_alpha = 0.5
        cv.g.fill_style = C.line
        cv.g.fill()
        cv.g.global_alpha = 1
        vy = vy0 - g * tt
        if lv >= 1:
            sc = 0.2 * (cv.xr[1] - cv.xr[0]) / max(P.v0, 1)
            cv.line(bx, by, bx + vx * sc, by, C.data[2], 1, [3, 3])
            cv.line(bx, by, bx, by + vy * sc, C.data[2], 1, [3, 3])
            vec(cv, bx, by, vx * sc, 0, C.jade, 1.5, "vx", 10)
            vec(cv, bx, by, 0, vy * sc, C.jade, 1.5, "vy", 10)
            vec(cv, bx, by, vx * sc, vy * sc, C.accent, 2, "v", 10.5)
            angle_arc(cv, 0, P.h0, max(0.06 * R, 0.3), 0, rad(P.angle), C.accent, "θ")
        dot(cv, bx, by, 5.5, C.ink, C.paper, 1.6)
        if lv >= 2:
            dim_line(cv, (0, -0.055 * H), (R, -0.055 * H), f"射程 R = {fmt(R, 1)} m", C.ink2, 0, 15)
            dim_line(cv, (xp, 0), (xp, H), f"H = {fmt(H, 1)} m", C.accent, 8, 0)
            ring_world(cv, R, 0, 0.014 * R, C.accent, 1.5, [3, 3])
            label(cv, R, 0, f"T = {fmt(Tf, 2)} s", C.accent, 10.5, ox=-6, oy=16, align="right")
        elif lv == 0:
            label(cv, 0, P.h0, f"v₀ = {fmt(P.v0, 0)} m/s", C.soft, 10.5, ox=12, oy=-14)
            label(cv, 0, P.h0, f"θ = {fmt(P.angle, 0)}°", C.soft, 10.5, ox=12)
            if P.h0 > 0.01:
                label(cv, 0, P.h0, f"h₀ = {fmt(P.h0, 1)} m", C.soft, 10.5, ox=12, oy=14)

    def vt(self):
        """讲题模式右上角的小图：竖直分速度随时间（向上为正）。"""
        _vx, vy0, Tf, *_r = self.met()
        return "vᵧ–t（向上为正）", max(Tf, 0.25), (lambda s: vy0 - self.P.g * s), "vy"

    def readouts(self, t):
        P = self.P
        vx, vy0, Tf, R, H, _ = self.met()
        Tf = max(Tf, 0.25)
        tt = clamp(t, 0, Tf)
        vy = vy0 - P.g * tt
        ve = vy0 - P.g * Tf
        return [("射程 R", fmt(max(R, 0), 1), "m"), ("飞行时间 T", fmt(Tf, 2), "s"), ("最大高度 H", fmt(max(H, 0), 1), "m"),
                ("当前速度", fmt(sqrt(vx * vx + vy * vy), 1), "m/s"), ("落地速度", fmt(sqrt(vx * vx + ve * ve), 1), "m/s")]

    def status(self, t):
        _, vy0, Tf, *_r = self.met()
        Tf = max(Tf, 0.25)
        if t >= Tf - 0.015:
            return "落地"
        vy = vy0 - self.P.g * t
        return "最高点" if abs(vy) < 0.3 else "上升" if vy > 0 else "下落"


@scene("incline")
class Incline(Scene):
    one_shot = True
    sliders = [("angle", "倾角 θ", 5, 60, 1, 0), ("mu", "摩擦系数 μ", 0, 0.6, 0.02, 2), ("m", "质量 m", 0.5, 5, 0.5, 1), ("L", "斜面长 L", 1.5, 5, 0.1, 1)]
    hints = ["先看受力：重力 mg、支持力 N、沿斜面的摩擦力 f。", "沿斜面方向列方程：mg sinθ − f = ma，f = μN。", "由加速度求出到低端的速度与下滑时间。"]
    hot = [[], [2, 3], [0, 1, 4]]

    def defaults(self):
        return dict(angle=30, mu=0.2, m=2, L=3, g=10)

    def aux(self, src):
        try:
            h = float(src.get("h"))
        except (TypeError, ValueError):
            return
        if h > 0 and src.get("L") is None:
            self.P.L = h / max(0.05, sin(rad(self.P.angle)))

    def dyn(self):
        P = self.P
        th = rad(P.angle)
        s, c = sin(th), cos(th)
        a_raw = P.g * (s - P.mu * c)
        moving = a_raw > 1e-6
        N = P.m * P.g * c
        return dict(th=th, s=s, c=c, moving=moving, a=max(a_raw, 0), N=N, f=P.mu * N if moving else P.m * P.g * s, T=sqrt(2 * P.L / max(a_raw, 1e-6)) if moving else 0)

    def duration(self):
        d = self.dyn()
        return max(0.6, d["T"]) if d["moving"] else 1.2

    def draw(self, cv, t, lv):
        P, d = self.P, self.dyn()
        s_, c_, moving = d["s"], d["c"], d["moving"]
        H, Bx = P.L * s_, P.L * c_
        vw = Bx + 0.9 if moving else max(2.6, min(Bx + 0.9, 3.6))   # 静止时裁到 3.6 m 内，免得方块缩成一个墨点
        vh = H + 0.7 if moving else max(H + 0.55, 1.05)
        view_rect(cv, -0.4, vw, -0.22, vh, 0.03, moving)
        grid_of(cv, max(Bx, H, 1) * 2.2)
        cv.line(cv.xr[0], 0, cv.xr[1], 0, C.line, 2)
        shape(cv, [(0, 0), (0, H), (Bx, 0)], C.grid2, C.ink2, 1.4)
        tt = clamp(t, 0, max(d["T"], 0.001))
        dist = min(0.5 * d["a"] * tt * tt, P.L - 0.36) if moving else 0.3
        sz = clamp(0.42 * cv.sx(), 18, 40)
        off = (sz / 2) / max(1e-6, cv.sx())
        cx, cy = dist * c_ + off * s_, H - dist * s_ + off * c_
        X, Y = cv.px(cx), cv.py(cy)
        g = cv.g
        if not moving:   # 静止也让画面活着：脉冲圈、「若无摩擦」对照块、计时表
            k = (sin(TAU * t / 1.2) + 1) / 2
            stroke_arc(cv, X, Y, sz * 0.82 + 9 * k, 0, TAU, C.accent, 1.4, 0.14 + 0.34 * (1 - k), [3, 4])
            if s_ > 0.02:
                u = t % 2.4
                gt = u if u < 1.2 else 2.4 - u
                gd = min(0.5 * P.g * s_ * gt * gt, P.L - 0.4)
                gx, gy = gd * c_ + off * s_, H - gd * s_ + off * c_
                g.save()
                g.translate(cv.px(gx), cv.py(gy))
                g.rotate(d["th"])
                g.stroke_style, g.global_alpha, g.line_width, g.dash = C.accent, 0.55, 1.2, [4, 4]
                g.begin_path()
                g.rect(-sz / 2, -sz / 2, sz, sz)
                g.stroke()
                g.restore()
                label(cv, gx, gy, "若无摩擦", C.accent, 9.5, align="center", oy=-20)
            ckx, cky, ckr = cv.w * 0.64, cv.h * 0.26, 32
            D.circle(g, ckx, cky, ckr, C.card, C.ink2, 1.4)
            for q in range(4):
                aa = -PI / 2 + q * PI / 2
                D.line(g, ckx + cos(aa) * (ckr - 6), cky + sin(aa) * (ckr - 6), ckx + cos(aa) * (ckr - 1), cky + sin(aa) * (ckr - 1), C.faint, 1)
            ha = -PI / 2 + TAU * ((t % 1.2) / 1.2)
            D.line(g, ckx, cky, ckx + cos(ha) * (ckr - 7), cky + sin(ha) * (ckr - 7), C.accent, 2)
            D.circle(g, ckx, cky, 2.2, C.ink)
            plabel(cv, ckx, cky + ckr + 13, f"计时 {fmt(t % 1.2, 2)} s", C.soft, 9.5, weight=500, align="center")
            pxx, pyy, pww = cv.w * 0.52, cv.h * 0.52, min(240, cv.w * 0.40)
            fp = frame_panel(cv, pxx, pyy, pww, 78, "静摩擦")
            plabel(cv, pxx + 10, fp.y + 3, f"μ = {fmt(P.mu, 2)}　tanθ = {fmt(s_ / max(c_, 1e-6), 2)}", C.ink, 10)
            plabel(cv, pxx + 10, fp.y + 21, "μ ≥ tanθ → 保持静止", C.accent, 10)
            plabel(cv, pxx + 10, fp.y + 39, f"f = mg sinθ = {fmt(P.m * P.g * s_, 1)} N", C.ink2, 10)
            plabel(cv, pxx + 10, fp.y + 56, "v = 0，位移保持为 0", C.soft, 9.5)
        g.save()
        g.translate(X, Y)
        g.rotate(d["th"])
        D.rect(g, -sz / 2, -sz / 2, sz, sz, C.ink, C.paper, 1.5)
        g.restore()
        Fg = P.m * P.g
        sc = 0.3 * max(H, 1.2) / max(Fg, 1)
        if lv >= 1:
            vec(cv, cx, cy, 0, -Fg * sc, C.accent, 2, "mg", 10)
            vec(cv, cx, cy, s_ * d["N"] * sc, c_ * d["N"] * sc, C.jade, 2, "N", 10)
            vec(cv, cx, cy, -c_ * d["f"] * sc, s_ * d["f"] * sc, C.gold, 2, "f", 10)
            if moving:
                net = P.m * d["a"]
                vec(cv, cx, cy, c_ * net * sc, -s_ * net * sc, C.ink2, 2.2, "F合", 10, dash=[5, 4])
            angle_arc(cv, 0, 0, max(0.4, Bx * 0.16), 0, d["th"], C.soft, "θ")
        if lv >= 2 and moving:
            v = d["a"] * tt
            vs = 0.4 / max(d["a"] * max(d["T"], 0.4), 0.05)
            vec(cv, cx, cy, c_ * v * vs, -s_ * v * vs, C.accent, 2, "v", 10)
            ox, oy = s_ * 0.32, c_ * 0.32
            dim_line(cv, (0.35 * c_ + ox, H - 0.35 * s_ + oy), ((P.L - 0.3) * c_ + ox, H - (P.L - 0.3) * s_ + oy), f"L = {fmt(P.L, 1)} m", C.jade, 0, 12)
            label(cv, Bx * 0.72, H * 0.3, f"a = {fmt(d['a'], 1)} m/s²", C.accent, 11, align="center")
            label(cv, Bx * 0.72, H * 0.3, f"t = {fmt(d['T'], 2)} s", C.accent, 11, align="center", oy=16)
        elif lv == 0:
            label(cv, cv.xr[0], cv.yr[0], f"θ = {fmt(P.angle, 0)}°  μ = {fmt(P.mu, 2)}  m = {fmt(P.m, 1)} kg", C.soft, 10.5, ox=8, oy=-12)

    def vt(self):
        """讲题模式右上角的小图：沿斜面向下的速度随时间。"""
        d = self.dyn()
        if not d["moving"]:
            return "v–t", 0, (lambda s: 0.0), "v"
        return "v–t（沿斜面向下）", d["T"], (lambda s: d["a"] * s), "v"

    def readouts(self, t):
        d = self.dyn()
        v = d["a"] * clamp(t, 0, max(d["T"], 0.001)) if d["moving"] else 0
        return [("加速度 a", fmt(d["a"], 2), "m/s²"), ("下滑速度", fmt(v, 2), "m/s"), ("支持力 N", fmt(d["N"], 1), "N"), ("摩擦力 f", fmt(d["f"], 1), "N"),
                ("下滑时间", fmt(d["T"], 2) if d["moving"] else "—", "s" if d["moving"] else "")]

    def status(self, t):
        d = self.dyn()
        if not d["moving"]:
            return "静止（μ ≥ tanθ）"
        return "到达底端" if t >= d["T"] - 0.01 else "加速下滑"


@scene("spring")
class Spring(Scene):
    sliders = [("m", "质量 m", 0.5, 5, 0.1, 1), ("k", "劲度系数 k", 20, 400, 5, 0), ("A", "振幅 A", 0.08, 0.8, 0.01, 2)]
    hints = ["弹簧振子：偏离平衡位置后，弹力 F = −kx 提供恢复力。", "动能与弹性势能互相转化，机械能 E = ½kA² 守恒。", "由 ω = √(k/m) 得周期 T = 2π√(m/k)。"]
    hot = [[3, 4], [0, 1, 2], [0, 1, 2, 3, 4]]

    def defaults(self):
        return dict(m=2, k=200, A=0.35)

    def om(self):
        return sqrt(self.P.k / max(self.P.m, 0.01))

    def duration(self):
        return TAU / self.om()

    def draw(self, cv, t, lv):
        P = self.P
        w = self.om()
        x, v = P.A * cos(w * t), -P.A * w * sin(w * t)
        KE, PE = 0.5 * P.m * v * v, 0.5 * P.k * x * x
        E = KE + PE
        wall = -0.95
        view_rect(cv, wall - 0.55, P.A + 0.85, -0.16, 1.1, 0.02, False)
        grid_of(cv, 1.1)
        cv.line(cv.xr[0], 0, cv.xr[1], 0, C.line, 2)
        g = cv.g
        D.rect(g, cv.px(wall - 0.16), cv.py(0.95), 0.16 * cv.sx(), 0.95 * cv.sy(), C.data[3], C.data[2], 1)
        cv.line(0, 0, 0, 0.95, C.data[3], 1, [4, 5])
        label(cv, 0, 0.95, "平衡位置", C.faint, 9.5, align="center", oy=-9, weight=500)
        half = 0.15
        spring_coil(cv, wall, x - half, 0.15, 13, 7)
        D.rect(g, cv.px(x - half), cv.py(0.15 + half), half * 2 * cv.sx(), half * 2 * cv.sy(), C.ink, C.paper, 1.4)
        if lv >= 1:
            sc = 0.62 / max(P.A * w, 0.05)
            vec(cv, x, 0.15, v * sc, 0, C.accent, 2, "v", 10)
            F, fsc = -P.k * x, 0.55 / max(P.k * P.A, 1)
            vec(cv, x, 0.5, F * fsc, 0, C.jade, 2, "F", 10)
        bars_panel(cv, cv.w - 168, 44, 152, [("动能", f"{fmt(KE, 2)} J", KE / E if E > 1e-9 else 0, C.ink), ("弹性势能", f"{fmt(PE, 2)} J", PE / E if E > 1e-9 else 0, C.data[2]),
                                             ("机械能", f"{fmt(E, 2)} J", 1, C.data[3])], "能量")
        if lv >= 2:
            label(cv, x, 0.15 + half, f"x = {fmt(x, 2)} m", C.accent, 10.5, align="center", oy=-34)

    def readouts(self, t):
        P = self.P
        w = self.om()
        Tp = TAU / w
        KE = 0.5 * P.m * (P.A * w * sin(w * t)) ** 2
        PE = 0.5 * P.k * (P.A * cos(w * t)) ** 2
        return [("周期 T", fmt(Tp, 2), "s"), ("频率 f", fmt(1 / Tp, 2), "Hz"), ("机械能 E", fmt(KE + PE, 2), "J"), ("位移 x", fmt(P.A * cos(w * t), 2), "m"), ("速度 v", fmt(-P.A * w * sin(w * t), 2), "m/s")]

    def status(self, t):
        P = self.P
        w = self.om()
        v, a = -P.A * w * sin(w * t), -w * w * P.A * cos(w * t)
        if abs(v) < 0.02:
            return "到达端点"
        return ("向右" if v > 0 else "向左") + (" · 加速" if v * a > 0 else " · 减速")


@scene("circular")
class Circular(Scene):
    sliders = [("r", "半径 r", 0.2, 1.2, 0.02, 2), ("v0", "线速度 v", 0.5, 6, 0.1, 1), ("m", "质量 m", 0.5, 3, 0.1, 1)]
    hints = ["匀速圆周运动：速度沿切线，方向时刻改变。", "向心加速度 a = v²/r，始终指向圆心。", "绳张力提供向心力，T = mv²/r = mω²r。"]
    hot = [[1], [2], [0, 2, 3]]

    def defaults(self):
        return dict(r=0.5, v0=2, m=1)

    def duration(self):
        return TAU * self.P.r / max(self.P.v0, 0.01)

    def draw(self, cv, t, lv):
        P = self.P
        r, w = P.r, P.v0 / P.r
        th = PI / 2 + w * t
        x, y = r * cos(th), r * sin(th)
        view_rect(cv, -r * 1.55, r * 1.55, -r * 1.55, r * 1.55, 0.02, True)
        grid_of(cv, r * 1.6, False)
        ring_world(cv, 0, 0, r, C.data[3], 1.2, [5, 5])
        dot(cv, 0, 0, 2.6, C.ink)
        cv.line(0, 0, x, y, C.gold, 2)
        vx, vy, nx, ny = -sin(th), cos(th), -x / r, -y / r
        if lv >= 1:
            vec(cv, x, y, vx * r * 0.52, vy * r * 0.52, C.accent, 2, "v")
            vec(cv, x, y, nx * r * 0.44, ny * r * 0.44, C.jade, 2, "a")
            if lv >= 2:
                vec(cv, x * 0.5, y * 0.5, nx * r * 0.3, ny * r * 0.3, C.gold, 2.4, "T")
            dot(cv, 0, 0, 3.2, C.ink, C.paper, 1.2)
        dot(cv, x, y, 8, C.ink, C.paper, 1.8)
        if lv >= 2:
            label(cv, r * 0.5, 0, f"r = {fmt(r, 2)} m", C.gold, 10.5, align="center", oy=-10)
            label(cv, 0, -r * 0.62, f"周期 T = {fmt(TAU * r / P.v0, 2)} s", C.ink2, 10.5, align="center", oy=14)
        elif lv == 0:
            label(cv, 0, -r * 1.2, f"r = {fmt(r, 2)} m   v = {fmt(P.v0, 1)} m/s", C.soft, 10.5, align="center")

    def readouts(self, t):
        P = self.P
        w = P.v0 / P.r
        return [("周期 T", fmt(TAU / w, 2), "s"), ("线速度 v", fmt(P.v0, 2), "m/s"), ("向心加速度", fmt(P.v0 ** 2 / P.r, 2), "m/s²"), ("绳张力 T", fmt(P.m * P.v0 ** 2 / P.r, 1), "N")]

    def status(self, t):
        d = (self.P.v0 / self.P.r * t / TAU) % 1
        return f"匀速圆周 · 转过 {fmt(d * 360, 0)}°"


@scene("wave")
class Wave(Scene):
    sliders = [("v0", "波速 v", 0.5, 4, 0.1, 1), ("f", "频率 f", 0.2, 3, 0.1, 1), ("A", "振幅 A", 0.1, 0.8, 0.01, 2)]
    hints = ["横波：质点上下振动，波形向右传播，两者方向垂直。", "波长、波速、周期满足 λ = vT = v / f。", "相邻质点的振动状态相差一个波长，波形重复。"]
    hot = [[0], [0, 1], [0, 1, 2]]

    def defaults(self):
        return dict(v0=2, f=1, A=0.35)

    def lam(self):
        return self.P.v0 / max(self.P.f, 0.01)

    def duration(self):
        return max(1, 2 / max(self.P.f, 0.01))

    def draw(self, cv, t, lv):
        P = self.P
        L, w = self.lam(), TAU * P.f
        k = TAU / L
        half_h = max(0.55, P.A * 2.4)
        half_w = half_h * (cv.w / max(1, cv.h))
        view_rect(cv, 0, half_w * 2, -half_h, half_h, 0.02, False)
        cv.grid(1)
        xL, xR = cv.xr
        n = max(120, min(760, round(cv.w)))

        def Y(x):
            return P.A * sin(k * x - w * t)
        polyline(cv, [(xL + (xR - xL) * i / n, Y(xL + (xR - xL) * i / n)) for i in range(n + 1)], C.ink2, 2)
        for i in range(1, 10):
            x = xL + (xR - xL) * i / 10
            y = Y(x)
            dot(cv, x, y, 2.4, C.data[2])
            cv.line(x, 0, x, y, C.line2, 1)
        xp = xL + (xR - xL) * 0.44
        yp = Y(xp)
        if lv >= 1:
            cv.line(xp, 0, xp, yp, C.data[3], 1, [3, 4])
            vec(cv, xp, 0, 0, yp, C.accent, 2.2, "y", 10)
            dot(cv, xp, yp, 5, C.ink, C.paper, 1.5)
        else:
            dot(cv, xp, yp, 4, C.ink, C.paper, 1.2)
        cv.arrow(xR - 1.5, half_h * 0.8, xR - 0.2, half_h * 0.8, C.accent, 2, 8)
        label(cv, xR - 0.85, half_h * 0.8, "传播方向", C.accent, 10, align="center", oy=-10)
        if lv >= 2:
            dim_line(cv, (xL + 0.5, half_h * 0.62), (xL + 0.5 + min(L, (xR - xL) * 0.72), half_h * 0.62), f"λ = {fmt(L, 2)} m", C.jade, 0, -13)
            dim_line(cv, (xR - 0.9, -P.A), (xR - 0.9, P.A), "A", C.gold, 14, 0)
            label(cv, xp, yp, "质点", C.ink, 10, ox=10, oy=-8)
        elif lv == 0:
            label(cv, xL + 0.5, -half_h * 0.72, f"v = {fmt(P.v0, 1)} m/s   f = {fmt(P.f, 1)} Hz", C.soft, 10.5)

    def readouts(self, t):
        P = self.P
        return [("波长 λ", fmt(self.lam(), 2), "m"), ("周期 T", fmt(1 / max(P.f, 0.01), 2), "s"), ("波速 v", fmt(P.v0, 2), "m/s"), ("频率 f", fmt(P.f, 2), "Hz")]

    def status(self, t):
        return "向右传播"


@scene("optics")
class Optics(Scene):
    sliders = [("angle", "入射角 θ₁", 0, 80, 1, 0), ("n", "折射率 n", 1.2, 2, 0.05, 2)]
    hints = ["光线沿半径进入曲面，不发生偏折，直射到平直界面。", "斯涅尔定律：n₁sinθ₁ = n₂sinθ₂，此处 n₁ = n，n₂ = 1。", "入射角超过临界角 arcsin(1/n) 时发生全反射。"]
    hot = [[0], [0, 1], [1, 2]]
    R = 1.2

    def defaults(self):
        return dict(angle=30, n=1.5)

    def opt(self):
        P = self.P
        th = rad(P.angle)
        s = sin(th)
        crit = math.asin(clamp(1 / P.n, -1, 1))
        tir = s > 1 / P.n + 1e-9
        return th, s, crit, tir, 0 if tir else math.asin(clamp(P.n * s, -1, 1))

    def duration(self):
        return 2.4

    def draw(self, cv, t, lv):
        P, R = self.P, self.R
        th, s, crit, tir, phi = self.opt()
        view_rect(cv, -R * 1.75, R * 1.75, -R * 1.45, R * 1.75, 0.02, True)
        cv.grid(R * 0.4)
        g = cv.g
        g.begin_path()
        g.arc(cv.px(0), cv.py(0), R * cv.sx(), 0, PI)
        g.close_path()
        g.global_alpha = 0.55
        g.fill_style = C.data[4]
        g.fill()
        g.global_alpha = 1
        g.stroke_style, g.line_width = C.data[2], 1.6
        g.stroke()
        cv.line(0, 0, 0, -R, C.data[2], 1.2, [4, 4])
        label(cv, 0, -R * 1.04, f"玻璃 n = {fmt(P.n, 2)}", C.data[2], 10, align="center", oy=10)
        Px, Py = -R * s, -R * cos(th)
        cv.arrow(Px, Py, 0, 0, C.accent, 2, 8)
        label(cv, Px, Py, "入射光线", C.accent, 10, align="right", ox=-8, oy=-8)
        cv.line(0, -R * 1.25, 0, R * 1.35, C.faint, 1, [4, 5])
        label(cv, 0, R * 1.3, "法线", C.faint, 9.5, align="center", oy=-10, weight=500)
        Lout = R * 1.2
        if not tir:
            ex, ey = Lout * sin(phi), Lout * cos(phi)
            cv.arrow(0, 0, ex, ey, C.jade, 2, 8)
            label(cv, ex, ey, "折射光线", C.jade, 10, ox=8, oy=-8)
            angle_arc(cv, 0, 0, R * 0.3, PI / 2 - phi, PI / 2, C.jade, "θ₂")
        else:
            qx, qy = R * s, -R * cos(th)
            cv.arrow(0, 0, qx, qy, C.gold, 2, 8, [5, 4])
            cv.arrow(qx, qy, qx + 0.52 * R * s, qy - 0.52 * R * cos(th), C.gold, 2, 8)
            label(cv, qx, qy, "全反射", C.gold, 10.5, ox=8, oy=14, weight=700)
        qx2, qy2 = R * sin(crit), -R * cos(crit)
        cv.line(0, 0, qx2 * 1.65, qy2 * 1.65, C.data[2], 1, [2, 5])
        label(cv, qx2 * 1.55, qy2 * 1.55, f"临界角 {fmt(math.degrees(crit), 1)}°", C.data[2], 9.5, ox=6, oy=7, weight=500)
        angle_arc(cv, 0, 0, R * 0.42, -PI / 2 - th, -PI / 2, C.accent, "θ₁")
        if tir:
            angle_arc(cv, 0, 0, R * 0.3, -PI / 2, th - PI / 2, C.gold, "θᵣ")
            label(cv, R * 0.45, R * 0.6, "无折射光线", C.faint, 9.5, align="center")
        L1, L2 = R, R * 1.6 if tir else Lout
        p = (t / 2.4) % 1
        now = p * (L1 + L2)
        if now <= L1:
            bx, by = Px - Px * (now / L1), Py - Py * (now / L1)
        else:
            d2 = now - L1
            bx, by = (d2 * s, -d2 * cos(th)) if tir else (d2 * sin(phi), d2 * cos(phi))
        fill_circle(cv, cv.px(bx), cv.py(by), 9, C.accent, 0.22)
        dot(cv, bx, by, 3.6, C.accent, C.paper, 1.2)
        if lv >= 1:
            tag_box(cv, cv.w * 0.5, 18, "θ₁ > C → 全反射" if tir else "n sinθ₁ = sinθ₂", C.ink2, "center")
        if lv >= 2:
            label(cv, R * 1.28, R * 0.98, "全反射条件" if tir else "斯涅尔定律", C.soft, 9.5, align="center")
            label(cv, R * 1.28, R * 0.86, "sinθ₁ > 1/n" if tir else "n sinθ₁ = sinθ₂", C.ink2, 10, align="center")
            label(cv, R * 1.28, R * 0.73, f"θ₁ = {fmt(P.angle, 0)}° > C" if tir else f"θ₂ = {fmt(math.degrees(phi), 1)}°", C.accent if tir else C.jade, 10.5, align="center")

    def readouts(self, t):
        P = self.P
        _, _, crit, tir, phi = self.opt()
        return [("入射角 θ₁", fmt(P.angle, 0), "°"), ("折射角 θ₂", "全反射" if tir else fmt(math.degrees(phi), 1), "" if tir else "°"), ("临界角 C", fmt(math.degrees(crit), 1), "°"), ("折射率 n", fmt(P.n, 2), "")]

    def status(self, t):
        return "发生全反射" if self.opt()[3] else "折射进入空气"
