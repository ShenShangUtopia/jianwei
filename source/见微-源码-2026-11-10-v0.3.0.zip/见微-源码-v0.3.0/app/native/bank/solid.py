"""solid 引擎：立体几何视图（由 views/solid.js 改写）。透视 / 正交投影 + 画家算法，棱按遮挡分实线与虚线。

解题四步：0 实体 → 1 辅助线 → 2 截面与角 → 3 结论。
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QPainterPath
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QWidget

from ..design.tokens import alpha, qc
from ..kit.draw import D
from .fx import fx
from .sb_core import C, num
from .solid_geom import (ALIAS, ASK_LABEL, DEG, PARAMS, PDEF, SHAPES, SIZE0, SNAME, STAG, TAU, add, ask_of, build, calc_dihedral, calc_line_plane, calc_skew, clamp, cross, dist, dot, fnum, mean, mid, mul, norm_name,
                         plane_of, poly_area3, poly_perim, rp, section_poly, sub, sub_txt, unit, vlen, vol_surf, vol_tex)

SEC_NAME = dict(none="无", three="三点", hex="体对角线", axis="轴截面", mid="棱中点", equator="中截面")


def section_from(v):
    if not v:
        return dict(mode="none")
    if isinstance(v.get("through"), list) and len(v["through"]) >= 3:
        return dict(mode="three", through=[norm_name(x) for x in v["through"][:3]])
    k = str(v.get("preset") or v.get("plane") or v.get("kind") or "").lower()
    for word, mode in (("hex", "hex"), ("diag", "hex"), ("mid-section", "equator"), ("equator", "equator"), ("mid", "mid"), ("axis", "axis")):
        if word in k:
            return dict(mode=mode)
    return dict(mode="none")


def mount_solid(W):
    L, c, view = W.L, W.c, W.view
    s0 = norm_name(view.get("shape"))
    shape = ALIAS.get(s0) or (s0 if s0 in SHAPES else "cube")

    def defaults(k):
        src = view.get("size") or {}
        return {p: fnum(src.get(p), SIZE0[k][p]) for p in PARAMS[k]}
    st = dict(shape=shape, size=defaults(shape), yaw=-0.64, pitch=0.34, zoom=1.0, persp=True, ask=ask_of(view.get("ask")), diag=True, step=0, section=section_from(view.get("section")), marks=[norm_name(m) for m in (view.get("marks") or [])[:10]])
    G = {}

    def rebuild():
        G.clear()
        G.update(build(st["shape"], st["size"]))
        R = 1e-6
        for p in G["pts"].values():
            R = max(R, vlen(p))
        for f in G["faces"]:
            for x in f["v"]:
                if isinstance(x, list):
                    R = max(R, vlen(x))
        for ch in G.get("chains") or []:
            for p in ch["pts"]:
                R = max(R, vlen(p))
        G["scale"] = R
        G["Rw"] = max(R, 0.5)
        G["circum"] = G["rel"]["circum"]
        vol = None
        if G["key"] == "sphere":
            vol = dict(base=G["chains"][0]["pts"], mid=[0, 0, 0], top=[0, R, 0])
        else:
            low, base, hi = 1e9, None, -1e9
            for f in G["faces"]:
                ps = [rp(G, x) for x in f["v"]]
                my = mean(ps)[1]
                if my < low:
                    low, base = my, ps
                hi = max(hi, *[q[1] for q in ps])
            if base:
                vol = dict(base=base, mid=[0, low, 0], top=[0, hi, 0])
        G["vol"] = vol
        if G.get("auto_edges"):
            seen, E = set(), []
            for f in G["faces"]:
                v = f["v"]
                for i, a in enumerate(v):
                    b = v[(i + 1) % len(v)]
                    k = tuple(sorted((str(a), str(b))))
                    if k not in seen:
                        seen.add(k)
                        E.append((a, b))
            G["edges"] = E
    rebuild()

    def sec_plane():
        m = st["section"]
        mode = m["mode"]
        if mode == "none":
            return None
        if mode == "three":
            ps = [G["pts"].get(norm_name(n)) for n in m.get("through") or []]
            ps = [p for p in ps if p]
            if len(ps) < 3 or vlen(cross(sub(ps[1], ps[0]), sub(ps[2], ps[0]))) < 1e-8:
                return None
            return plane_of(ps)
        if mode == "mid":
            E = G.get("mid_edges") or []
            ps = [mid(rp(G, e[0]), rp(G, e[1])) for e in E[:3]]
            return plane_of(ps) if len(ps) >= 3 else None
        if mode == "axis":
            return dict(n=[1, 0, 0], d=0)
        if mode == "equator":
            return dict(n=[0, 1, 0], d=0)
        a, cc = G["pts"].get("A"), G["pts"].get("C1")
        return dict(n=unit(sub(cc, a)), d=0) if a and cc else dict(n=[0, 1, 0], d=0)

    def def_through():
        out = [n for n in ("A", "C", "B1") if n in G["pts"]]
        return out if len(out) >= 3 else list(G["pts"])[:3]

    def aim_hex():
        if st["shape"] not in ("cube", "cuboid"):
            return
        a, cc = G["pts"].get("A"), G["pts"].get("C1")
        if a and cc:
            d = unit(sub(cc, a))
            phi = math.asin(clamp(d[1], -1, 1))
            cp = math.cos(phi)
            st["pitch"] = phi
            if cp > 1e-6:
                st["yaw"] = math.atan2(-d[0] / cp, d[2] / cp)

    # ---- 主绘制
    sec_cache = dict(poly=[], area=0, perim=0)

    def render(w, h):
        g = c.g
        cy_, sy_ = math.cos(st["yaw"]), math.sin(st["yaw"])
        cp_, sp_ = math.cos(st["pitch"]), math.sin(st["pitch"])

        def T(p):
            x1 = p[0] * cy_ + p[2] * sy_
            z1 = -p[0] * sy_ + p[2] * cy_
            return (x1, p[1] * cp_ - z1 * sp_, p[1] * sp_ + z1 * cp_)
        cam = [-cp_ * sy_, sp_, cp_ * cy_]
        Rw = G["Rw"]
        base = min(w, h) * 0.405 / Rw * st["zoom"]
        Dd = 10 * Rw
        cx, cyy = w * 0.5, h * 0.502
        persp = st["persp"]

        def pj(cc):
            k = base * Dd / max(Dd - cc[2], Dd * 0.22) if persp else base
            return (cx + cc[0] * k, cyy - cc[1] * k)

        def SC(p):
            return pj(T(p))
        CEN = SC([0, 0, 0])
        faces = []
        for f in G["faces"]:
            w3 = [rp(G, x) for x in f["v"]]
            c3 = [T(p) for p in w3]
            s2 = [pj(p) for p in c3]
            n0 = cross(sub(c3[1], c3[0]), sub(c3[2], c3[0]))
            nl = vlen(n0)
            if nl < 1e-9:
                continue
            cen = mean(c3)
            n = mul(n0, 1 / nl)
            if dot(n, cen) < 0:   # 凸体含原点：外法向必背离原点，与顶点绕序无关
                n = mul(n, -1)
            nn = cross(sub(w3[1], w3[0]), sub(w3[2], w3[0]))
            u = unit(nn)
            xs, ys = [p[0] for p in s2], [p[1] for p in s2]
            faces.append(dict(s2=s2, c0=c3[0], n=n, front=dot(n, sub([0, 0, Dd], cen)) > 0, z=cen[2], cull=f.get("cull"), up=(-u[1] if dot(u, mean(w3)) < 0 else u[1]), bbox=(min(xs), max(xs), min(ys), max(ys))))
        faces.sort(key=lambda f: f["z"])
        tint = qc(C.ink2)
        for f in faces:
            if f["cull"] and not f["front"]:
                continue
            a = (0.09 if f["front"] else 0.045) + max(0, f["up"]) * 0.03
            path = QPainterPath(QPointF(*f["s2"][0]))
            for p in f["s2"][1:]:
                path.lineTo(*p)
            path.closeSubpath()
            g.p.fillPath(path, alpha(tint, a))
        eps = Rw * 0.016
        front = [f for f in faces if f["front"]]

        def in_poly(x, y, P):
            ins = False
            j = len(P) - 1
            for i, pi in enumerate(P):
                pj_ = P[j]
                if (pi[1] > y) != (pj_[1] > y) and x < (pj_[0] - pi[0]) * (y - pi[1]) / ((pj_[1] - pi[1]) or 1e-9) + pi[0]:
                    ins = not ins
                j = i
            return ins

        def occ(p):
            cc = T(p)
            s = pj(cc)
            for f in front:
                b = f["bbox"]
                if s[0] < b[0] or s[0] > b[1] or s[1] < b[2] or s[1] > b[3] or not in_poly(s[0], s[1], f["s2"]):
                    continue
                if dot(f["n"], sub(cc, f["c0"])) < -eps:
                    return True
            return False
        vis_path, hid_path = QPainterPath(), QPainterPath()

        def collect(lst, closed=False, force=False, vis=None):
            n = len(lst) if closed else len(lst) - 1
            cur = None
            for i in range(n):
                a, b = lst[i], lst[(i + 1) % len(lst)]
                hid = False
                if not force:
                    m = mid(a, b)
                    hid = (not vis(m)) if vis else occ(m)
                pa, pb = SC(a), SC(b)
                path = hid_path if hid else vis_path
                if cur is not hid:
                    path.moveTo(*pa)
                path.lineTo(*pb)
                cur = hid
        for e in G.get("edges") or []:
            collect([rp(G, e[0]), rp(G, e[1])])
        for ch in G.get("chains") or []:
            vis = None
            if ch.get("surf") and G.get("surf"):
                sc = G["surf"]["c"]
                vis = lambda p, sc=sc: dot(sub(p, sc), sub(cam, p)) > 0   # noqa: E731
            collect(ch["pts"], ch.get("closed", True), False, vis)
        if G.get("sil"):
            for s in G["sil"](cam):
                if isinstance(s, dict):
                    collect(s["pts"], s.get("closed", False), True)
                else:
                    collect(s, False, True)
        pen_h = g._pen(alpha(qc(C.ink2), 0.55), 1.15, [4, 3.6])
        pen_h.setCapStyle(Qt.PenCapStyle.RoundCap)
        g.p.strokePath(hid_path, pen_h)
        pen_v = g._pen(C.ink, 1.45, [])
        pen_v.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen_v.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        g.p.strokePath(vis_path, pen_v)

        # ---- 叠加层的小工具
        def seg(a, b, color=None, width=1.3, dash=None, al=None):
            A, B = SC(a), SC(b)
            col = qc(color or C.ink2)
            if al is not None:
                col = alpha(col, col.alphaF() * al)
            g.line_cap = "round"
            D.line(g, A[0], A[1], B[0], B[1], col, width, dash)
            g.line_cap = "butt"

        def arrow(a, b, color, dash=None):
            A, B = SC(a), SC(b)
            D.line(g, A[0], A[1], B[0], B[1], color, 1.15, dash)
            ang = math.atan2(B[1] - A[1], B[0] - A[0])
            D.poly(g, [B, (B[0] - 6.5 * math.cos(ang - 0.42), B[1] - 6.5 * math.sin(ang - 0.42)), (B[0] - 6.5 * math.cos(ang + 0.42), B[1] - 6.5 * math.sin(ang + 0.42))], color)

        def chip(x, y, txt, color, size=11):
            tw = D.measure(txt, size, True) + 9
            hh = size + 6.5
            D.rrect(g, x - tw / 2, y - hh / 2, tw, hh, 2.5, alpha(qc(C.paper), 0.9))
            D.text(g, txt, x, y, color, size=size, bold=True, align="center")

        def text(x, y, s, size=11, color=None, align="center", halo=True):
            if halo:
                from .ph_core import Cv, plabel
                plabel(_cv, x, y, s, color or C.ink, size, align=align)
                _ = Cv
            else:
                D.text(g, s, x, y, color or C.ink, size=size, bold=True, align=align)

        def arc_of(cc, u1, wv, r0, th, n=24, color=None):
            pts = [SC(add(cc, add(mul(u1, r0 * math.cos(th * i / n)), mul(wv, r0 * math.sin(th * i / n))))) for i in range(n + 1)]
            D.poly(g, pts, None, color or C.accent, 1.9, False)

        step = st["step"]
        # ---- 辅助线
        if step >= 1:
            for d in G["dims"]:
                q = SC(mid(rp(G, d["a"]), rp(G, d["b"])))
                ux, uy = q[0] - CEN[0], q[1] - CEN[1]
                ln = math.hypot(ux, uy) or 1
                text(q[0] + ux / ln * 15, q[1] + uy / ln * 15, d["text"], 10, C.ink2)
            for a in G["aux"]:
                p, q = rp(G, a["a"]), rp(G, a["b"])
                seg(p, q, C.ink2, 1.1, [5, 4] if occ(mid(p, q)) else [6, 4])
                s = SC(add(p, mul(sub(q, p), 0.58)))
                text(s[0] + 12, s[1] - 8, a["text"], 10, C.ink2)
            if G.get("surf") and not (st["ask"] == "circum" and step >= 2):
                p = mul(unit(cam), G["surf"]["r"])
                seg(G["surf"]["c"], p, C.ink2, 1.2)
                seg(G["surf"]["c"], mul(p, -1), C.ink2, 1, [5, 4])
                mp = SC(mul(p, 0.58))
                text(mp[0] + 13, mp[1] - 8, f"r={num(G['surf']['r'], 1)}", 10, C.ink2)
            if st["diag"] and G.get("diag"):
                for kind, wd, dsh, dy in (("face", 1.2, [5, 4], 11), ("body", 1.4, [7, 4], -10)):
                    for e in G["diag"].get(kind) or []:
                        a, b = rp(G, e["a"]), rp(G, e["b"])
                        seg(a, b, C.jade, wd, dsh)
                        m = SC(mid(a, b))
                        text(m[0], m[1] + dy, f"{e['t']}={num(dist(a, b), 2)}", 10, C.jade)
        # ---- 截面
        key = (st["shape"], tuple(st["size"].items()), st["section"]["mode"], tuple(st["section"].get("through") or ()))
        if sec_cache.get("key") != key:   # 截面只随几何变，旋转时不必重算
            poly = section_poly(G, sec_plane())
            sec_cache.update(key=key, poly=poly, area=poly_area3(poly), perim=poly_perim(poly) if poly else 0)
        poly = sec_cache["poly"]
        sec_label = None
        if step >= 2 and len(poly) >= 3:
            pts = [SC(p) for p in poly]
            D.poly(g, pts, alpha(qc(C.jade), 0.16), C.jade, 1.7)
            if len(pts) <= 8:
                for p in pts:
                    D.circle(g, p[0], p[1], 2.1, C.jade)
            if step >= 3:
                sp = SC(mean(poly))
                sec_label = (sp[0], sp[1], f"S={num(sec_cache['area'], 2)}")
        # ---- 所求的角 / 距离
        rel = None
        if step >= 2:
            R = G["rel"]
            ask = st["ask"]
            if ask == "dihedral":
                m = calc_dihedral(G, R.get("dihedral"))
                if m:
                    rel = ("dihedral", m)
                    seg(m["E1"], m["E2"], C.ink, 2.1)
                    ln = 0.58 * Rw
                    seg(m["M"], add(m["M"], mul(m["u1"], ln)), C.ink2, 1, [3, 3], 0.55)
                    seg(m["M"], add(m["M"], mul(m["u2"], ln)), C.ink2, 1, [3, 3], 0.55)
                    arrow(m["M"], add(m["M"], mul(m["n1"], 0.40 * Rw)), C.ink2, [4, 3])
                    arrow(m["M"], add(m["M"], mul(m["n2"], 0.40 * Rw)), C.ink2, [4, 3])
                    wv = sub(m["u2"], mul(m["u1"], dot(m["u1"], m["u2"])))
                    if vlen(wv) < 1e-6:
                        wv = cross(m["n1"], m["u1"])
                    wv = unit(wv)
                    r0 = 0.27 * Rw
                    arc_of(m["M"], m["u1"], wv, r0, m["th"])
                    if step >= 3:
                        t = m["th"] / 2
                        sp = SC(add(m["M"], add(mul(m["u1"], r0 * 1.38 * math.cos(t)), mul(wv, r0 * 1.38 * math.sin(t)))))
                        chip(sp[0], sp[1], f"{num(m['deg'], 2)}°", C.accent, 12)
            elif ask == "linePlane":
                m = calc_line_plane(G, R.get("linePlane"))
                if m:
                    rel = ("linePlane", m)
                    seg(m["A"], m["B"], C.ink2, 1.8, [6, 4])
                    if dist(m["far"], m["foot"]) > 1e-6:
                        seg(m["far"], m["foot"], C.ink2, 1, [4, 4], 0.85)
                        seg(m["X"], m["foot"], C.ink2, 1.5, None, 0.8)
                    u1, u2 = m["u1"], m["u2"]
                    wv = sub(u2, mul(u1, dot(u1, u2)))
                    if vlen(wv) < 1e-6:
                        wv = cross(m["n"], u1)
                    wv = unit(wv)
                    r0 = 0.22 * Rw
                    if m["flat"]:   # 线面垂直：直角符号
                        a = r0 * 0.85
                        p1, p2, p3 = add(m["X"], mul(u1, a)), add(add(m["X"], mul(u1, a)), mul(u2, a)), add(m["X"], mul(u2, a))
                        seg(p1, p2, C.accent, 1.6)
                        seg(p2, p3, C.accent, 1.6)
                    else:
                        arc_of(m["X"], u1, wv, r0, m["th"], 20)
                    if step >= 3:
                        t = m["th"] / 2
                        lp = add(add(m["X"], mul(u1, r0 * 0.8)), mul(u2, r0 * 1.5)) if m["flat"] else add(m["X"], add(mul(u1, r0 * 1.55 * math.cos(t)), mul(wv, r0 * 1.55 * math.sin(t))))
                        sp = SC(lp)
                        chip(sp[0], sp[1], f"{num(m['deg'], 2)}°", C.accent, 12)
            elif ask == "skew":
                m = calc_skew(G, R.get("skew"))
                if m:
                    rel = ("skew", m)
                    seg(m["A1"], m["A2"], C.ink2, 1.4, [6, 4])
                    seg(m["B1"], m["B2"], C.ink2, 1.4, [6, 4])
                    seg(m["P"], m["Q"], C.accent, 2.1)
                    if step >= 3:
                        sp = SC(mid(m["P"], m["Q"]))
                        chip(sp[0], sp[1] - 13, f"d={num(m['dist'], 4)}", C.accent, 11.5)
            elif ask == "volume":
                vv = G.get("vol")
                if vv:
                    rel = ("volume", None)
                    s2 = [SC(rp(G, x)) for x in vv["base"]]
                    D.poly(g, s2, alpha(qc(C.jade), 0.14))
                    path = QPainterPath(QPointF(*s2[0]))
                    for p in s2[1:]:
                        path.lineTo(*p)
                    path.closeSubpath()
                    g.p.strokePath(path, g._pen(alpha(qc(C.jade), 0.72), 1.2, [5, 4]))
                    seg(vv["mid"], vv["top"], C.ink2, 1.5, [6, 4])
                    hh = abs(vv["top"][1] - vv["mid"][1])
                    mp = SC(add(vv["mid"], mul(sub(vv["top"], vv["mid"]), 0.62)))
                    chip(mp[0] + 34, mp[1], f"h={num(hh, 2)}", C.ink2, 11)
                    if step >= 3:
                        q = SC(add(vv["mid"], mul(sub(vv["top"], vv["mid"]), 0.3)))
                        chip(q[0] - 42, q[1], f"V={num(vol_surf(st['shape'], st['size'])[0], 3)}", C.accent, 12)
            else:
                cu = G["circum"]
                rel = ("circum", cu)
                d = unit(cam)
                u = cross(d, [0, 1, 0])
                if vlen(u) < 1e-6:
                    u = cross(d, [1, 0, 0])
                u = unit(u)
                v = unit(cross(d, u))
                ringp = [SC(add(cu["c"], add(mul(u, cu["R"] * math.cos(TAU * i / 72)), mul(v, cu["R"] * math.sin(TAU * i / 72))))) for i in range(73)]
                path = QPainterPath(QPointF(*ringp[0]))
                for p in ringp[1:]:
                    path.lineTo(*p)
                g.p.strokePath(path, g._pen(alpha(qc(C.ink2), 0.75), 1, [4, 4]))
                sp = SC(cu["c"])
                D.circle(g, sp[0], sp[1], 2.4, C.ink)
                seg(cu["c"], add(cu["c"], [0, cu["R"], 0]), C.accent, 1.9)
                if step >= 3:
                    mp = SC(add(cu["c"], [0, cu["R"] * 0.55, 0]))
                    chip(mp[0] + 34, mp[1], f"R={num(cu['R'], 4)}", C.accent, 11.5)
        if sec_label:
            chip(sec_label[0], sec_label[1], sec_label[2], C.jade, 11)
        # ---- 顶点标签（防压）
        items = []
        for lb in G.get("labels") or []:
            p = G["pts"].get(lb["name"])
            if not p:
                continue
            q = SC(p)
            ux, uy = q[0] - CEN[0], q[1] - CEN[1]
            if math.hypot(ux, uy) < 1:
                ux, uy = 0, -1
            d = math.hypot(ux, uy) or 1
            items.append(dict(x=q[0] + ux / d * 15, y=q[1] + uy / d * 15, text=lb["text"], w=D.measure(lb["text"], 11, True), mark=lb["name"] in st["marks"]))
        for _pass in range(4):
            for i, a in enumerate(items):
                for b in items[i + 1:]:
                    if abs(a["x"] - b["x"]) < (a["w"] + b["w"]) / 2 + 3 and abs(a["y"] - b["y"]) < 12:
                        dr = -1 if a["y"] <= b["y"] else 1
                        a["y"] += dr * 2.4
                        b["y"] -= dr * 2.4
        for it in items:
            x, y = clamp(it["x"], 12, w - 12), clamp(it["y"], 12, h - 12)
            if it["mark"]:
                D.circle(g, x, y, 2.4, C.accent)
            text(x, y, it["text"], 11, C.accent if it["mark"] else C.ink)
        # ---- 抬头、脚注、结论卡
        tags = {0: "实体", 1: "辅助线", 2: "截面 / 角", 3: "结论"}
        D.text(g, SNAME[st["shape"]], 14, 18, C.ink, size=13, bold=True)
        D.text(g, f"{STAG[st['shape']]} · {tags.get(step, '实体')}", 14 + D.measure(SNAME[st["shape"]], 13, True) + 8, 18, C.soft, size=11)
        D.text(g, "拖拽旋转 · 滚轮缩放 · 双击复位", w / 2, h - 12, C.faint, size=10.5, align="center")
        if step >= 3:
            rows = []
            if rel:
                kind, m = rel
                if kind == "dihedral":
                    rows.append((f"{num(m['deg'], 2)}°", f"二面角 {m['label']}"))
                elif kind == "linePlane":
                    rows.append((f"{num(m['deg'], 2)}°", f"线面角 {m['label']}"))
                elif kind == "skew":
                    rows.append((num(m["dist"], 4), "异面直线距离"))
                elif kind == "circum":
                    rows.append((num(m["R"], 4), "外接球半径 R"))
                else:
                    vs = vol_surf(st["shape"], st["size"])
                    rows += [(num(vs[0], 3), "体积 V"), (num(vs[1], 3), "表面积 S")]
            if len(poly) >= 3:
                rows.append((num(sec_cache["area"], 3), f"截面面积 · 周长 {num(sec_cache['perim'], 3)}"))
            if rows:
                bw = 190
                bx, by = w - bw - 12, 12
                D.rrect(g, bx, by, bw, 26 + len(rows) * 40, 6, alpha(qc(C.card), 0.92), C.line, 1)
                D.text(g, "结论", bx + 12, by + 14, C.soft, size=10.5)
                for i, (a, b) in enumerate(rows):
                    D.text(g, a, bx + 12, by + 36 + i * 40, C.accent, size=16, bold=True, serif=True)
                    D.text(g, b, bx + 12, by + 53 + i * 40, C.soft, size=10.5)
        view_label.text(f"偏转 {round(st['yaw'] * DEG)}° · 俯仰 {round(st['pitch'] * DEG)}°　{num(st['zoom'], 2)}×")

    from .ph_core import Cv
    _cv = Cv(c)

    # ---- 右栏
    def set_shape(name):
        k = next((x for x in SHAPES if SNAME[x] == name), None)
        if not k or k == st["shape"]:
            return
        st.update(shape=k, size=defaults(k), section=dict(mode="none"))
        rebuild()
        sync_dims()
        sync_sec()
        refresh()
    W.sec("形状")
    L.select("立体", [[SNAME[k], SNAME[k]] for k in SHAPES], SNAME[st["shape"]], set_shape)
    W.sec("尺寸")
    sliders = {}

    def on_size(k, v):
        if k in st["size"]:
            st["size"][k] = v
            rebuild()
            refresh()
    for k, (lb, mn, mx, stp) in PDEF.items():
        sliders[k] = L.slider(lb, mn, mx, stp, st["size"].get(k, mn), lambda v, k=k: on_size(k, v), "", 1)
    kv_v, kv_s = W.kv("体积 V"), W.kv("表面积 S")

    def sync_dims():
        for k, s in sliders.items():
            on = k in st["size"]
            s.el.setVisible(on)
            if on:
                s.set(st["size"][k], silent=True)
    W.sec("视角")
    row = L.button_row()
    persp_btn = row.add("透视", lambda: toggle_persp())
    row.add("复位", lambda: reset_view())
    view_label = W.note("")

    def toggle_persp():
        st["persp"] = not st["persp"]
        persp_btn.setText("透视" if st["persp"] else "正交")
        W.redraw()

    def reset_view():
        st.update(yaw=-0.64, pitch=0.34, zoom=1.0, persp=True)
        persp_btn.setText("透视")
        W.redraw()
    W.sec("关系")
    labels = list(ASK_LABEL.values())
    L.select("所求", [[x, x] for x in labels], ASK_LABEL[st["ask"]], lambda v: (st.update(ask=next(k for k, x in ASK_LABEL.items() if x == v)), refresh()))
    if view.get("cue"):
        L.note(str(view["cue"]))
    W.toggle("面对角线 / 体对角线", True, lambda v: (st.update(diag=bool(v)), W.redraw()))
    W.sec("截面")
    sec_val = None

    def sec_options():
        if G["curved"]:
            return ["无", "轴截面", "中截面", "三点"]
        return ["无", "体对角线", "棱中点", "三点"] if st["shape"] in ("cube", "cuboid") else ["无", "棱中点", "三点"]
    sec_combo = QComboBox()
    sec_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
    L._add(sec_combo)
    pick = QWidget()
    pickh = QHBoxLayout(pick)
    pickh.setContentsMargins(0, 0, 0, 0)
    pickh.setSpacing(3)
    combos = [QComboBox() for _i in range(3)]
    for cb in combos:
        cb.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        pickh.addWidget(cb)
    L._add(pick)
    syncing = [False]

    def on_sec(text):
        if syncing[0]:
            return
        mode = next((k for k, v in SEC_NAME.items() if v == text), "none")
        st["section"] = dict(mode="three", through=def_through()) if mode == "three" else dict(mode=mode)
        if mode in ("hex", "mid"):
            aim_hex()
        sync_sec()
        refresh()
    sec_combo.currentTextChanged.connect(on_sec)

    def on_pick(i, _idx=None):
        if not syncing[0] and st["section"]["mode"] == "three":
            st["section"]["through"][i] = combos[i].currentData()
            refresh()
    for i, cb in enumerate(combos):
        cb.currentIndexChanged.connect(lambda idx, i=i: on_pick(i, idx))

    def sync_sec():
        syncing[0] = True
        opts = sec_options()
        sec_combo.clear()
        sec_combo.addItems(opts)
        cur = SEC_NAME.get(st["section"]["mode"], "无")
        sec_combo.setCurrentText(cur if cur in opts else "无")
        three = st["section"]["mode"] == "three"
        pick.setVisible(three)
        if three:
            names = list(G["pts"])
            th = st["section"].get("through") or []
            if len(th) < 3 or not all(norm_name(n) in names for n in th):
                th = def_through()
            st["section"]["through"] = [norm_name(n) for n in th[:3]]
            for i, cb in enumerate(combos):
                cb.clear()
                for n in names:
                    cb.addItem(sub_txt(n), n)
                cb.setCurrentIndex(names.index(st["section"]["through"][i]))
        syncing[0] = False
    W.sec("公式")
    form = W.note("")
    L.legend([(C.accent, "所求"), (C.ink, "可见棱"), (C.ink2, "虚线：被遮挡")])
    _ = sec_val

    def refresh_formula():
        S3 = st["step"] >= 3
        ask = st["ask"]
        h = ""
        if ask == "dihedral":
            m = calc_dihedral(G, G["rel"].get("dihedral"))
            if m:
                h = f"<i>二面角 {m['label']}</i><br>{fx('cos\\theta=\\frac{u_1\\cdot u_2}{|u_1||u_2|}')}"
                if S3:
                    h += f"<br>= {num(m['cos'], 4)} ⇒ <b>{num(m['deg'], 2)}°</b>"
        elif ask == "linePlane":
            m = calc_line_plane(G, G["rel"].get("linePlane"))
            if m:
                h = f"<i>线面角 {m['label']}</i><br>{fx('sin\\theta=\\frac{|d\\cdot n|}{|d||n|}')}"
                if S3:
                    h += f"<br>= {num(m['sin'], 4)} ⇒ <b>{num(m['deg'], 2)}°</b>"
        elif ask == "skew":
            m = calc_skew(G, G["rel"].get("skew"))
            if m:
                sk = G["rel"]["skew"]
                h = f"<i>异面直线 {sk.get('n1', '')} 与 {sk.get('n2', '')}</i><br>d = |(P₂−P₁)·(d₁×d₂)| / |d₁×d₂|"
                if S3:
                    h += f"<br><b>d={num(m['dist'], 4)}</b>"
        elif ask == "volume":
            vt, vr = vol_tex(st["shape"], st["size"]), vol_surf(st["shape"], st["size"])
            h = f"<i>体积 V</i><br>{fx(vt[0])}"
            if S3:
                h += f"=<b>{num(vr[0], 3)}</b><br><i>表面积 S</i><br>{fx(vt[1])}=<b>{num(vr[1], 3)}</b>"
        else:
            cs = str(G["circum"]["tex"]).split("=")
            h = "<i>外接球半径 R</i><br>"
            h += (fx("=".join(cs[:-1])) + f"=<b>{num(G['circum']['R'], 4)}</b>") if S3 else fx(cs[0] + "=" + (cs[1] if len(cs) > 1 else ""))
        poly = section_poly(G, sec_plane())
        if len(poly) >= 3 and S3:
            h += f"<br><i>截面</i><br><b>S={num(poly_area3(poly), 3)}</b>，C={num(poly_perim(poly), 3)}"
        form.text(h or "<i>选择形状与关系</i>")

    def refresh():
        vs = vol_surf(st["shape"], st["size"])
        kv_v.text(num(vs[0], 3))
        kv_s.text(num(vs[1], 3))
        refresh_formula()
        W.redraw()

    # ---- 手势
    def drag(_cur, _x, _y, dx, dy):
        st["yaw"] += dx * 0.009
        st["pitch"] = clamp(st["pitch"] + dy * 0.007, -1.42, 1.42)

    def wheel(_x, _y, steps):
        st["zoom"] = clamp(st["zoom"] * math.exp(steps * 0.12), 0.55, 2.6)
        return True
    L.interact(c, hit=lambda _x, _y: "rot", drag=drag, wheel=wheel, dbl=lambda *_a: reset_view())

    def apply_step(i):
        st["step"] = int(clamp(round(i or 0), 0, 3))
        W.step = st["step"]
        refresh()
    W.apply_step = apply_step
    if st["section"]["mode"] in ("hex", "mid"):
        aim_hex()
    W.set(render)
    W.solid_state = st
    sync_dims()
    sync_sec()
    refresh()
