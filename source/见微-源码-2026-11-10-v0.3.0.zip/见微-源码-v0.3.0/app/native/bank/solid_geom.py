"""立体几何的纯几何部分（由 views/solid.js 改写）：八种立体、截面、二面角、线面角、异面距离、体积与外接球。"""
from __future__ import annotations

import math
import re

from .sb_core import num

TAU = math.tau
DEG = 180 / math.pi


def add(a, b):
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]


def sub(a, b):
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]


def mul(a, k):
    return [a[0] * k, a[1] * k, a[2] * k]


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def vlen(a):
    return math.sqrt(dot(a, a))


def unit(a):
    ln = vlen(a) or 1
    return [a[0] / ln, a[1] / ln, a[2] / ln]


def mid(a, b):
    return mul(add(a, b), 0.5)


def dist(a, b):
    return vlen(sub(a, b))


def mean(lst):
    s = [0, 0, 0]
    for p in lst:
        s = add(s, p)
    return mul(s, 1 / (len(lst) or 1))


def clamp(v, a, b):
    return a if v < a else b if v > b else v


_SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
_UNS = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")


def sub_txt(s):
    return str(s).translate(_SUB)


def norm_name(s):
    return str("" if s is None else s).strip().translate(_UNS)


SHAPES = ["cube", "cuboid", "prism", "pyramid", "cylinder", "cone", "sphere", "frustum"]
SNAME = dict(cube="正方体", cuboid="长方体", prism="正三棱柱", pyramid="正四棱锥", cylinder="圆柱", cone="圆锥", sphere="球", frustum="圆台")
STAG = dict(cube="ABCD-A₁B₁C₁D₁", cuboid="ABCD-A₁B₁C₁D₁", prism="ABC-A₁B₁C₁", pyramid="P-ABCD", cylinder="OO₁", cone="P-O", sphere="O", frustum="OO₁")
ALIAS = {"正方体": "cube", "立方体": "cube", "cube": "cube", "box": "cube", "长方体": "cuboid", "cuboid": "cuboid", "棱柱": "prism", "三棱柱": "prism", "正三棱柱": "prism", "prism": "prism", "cylinder3": "prism",
         "棱锥": "pyramid", "四棱锥": "pyramid", "正四棱锥": "pyramid", "pyramid": "pyramid", "cone4": "pyramid", "圆柱": "cylinder", "cylinder": "cylinder", "圆锥": "cone", "cone": "cone",
         "球": "sphere", "sphere": "sphere", "ball": "sphere", "圆台": "frustum", "frustum": "frustum", "truncated": "frustum"}
PARAMS = dict(cube=["a"], cuboid=["a", "b", "h"], prism=["a", "h"], pyramid=["a", "h"], cylinder=["r", "h"], cone=["r", "h"], sphere=["r"], frustum=["R", "r", "h"])
PDEF = dict(a=("底面棱 a", 1, 6, 0.1), b=("底宽 b", 1, 6, 0.1), h=("高 h", 0.8, 7, 0.1), r=("半径 r", 0.4, 4, 0.1), R=("下底半径 R", 0.6, 5, 0.1))
SIZE0 = dict(cube=dict(a=2), cuboid=dict(a=2, b=3, h=4), prism=dict(a=2.2, h=4), pyramid=dict(a=3, h=3), cylinder=dict(r=1.2, h=3), cone=dict(r=1.3, h=3), sphere=dict(r=1.6), frustum=dict(R=2, r=1, h=3))
NSEG = 44


def fnum(v, d):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return d
    return v if math.isfinite(v) and 0.05 < v < 20 else d


def ring(n, r, y, phase=0):
    return [[r * math.cos(phase + TAU * i / n), y, r * math.sin(phase + TAU * i / n)] for i in range(n)]


def strip(A, B):
    n = len(A)
    return [dict(v=[A[i], A[(i + 1) % n], B[(i + 1) % n], B[i]], cull=True) for i in range(n)]


def _labels(names):
    return [dict(name=k, text=sub_txt(k)) for k in names]


def build_box(kind, s):
    a = s["a"]
    b = a if kind == "cube" else s["b"]
    h = a if kind == "cube" else s["h"]
    x, z, y = a / 2, b / 2, h / 2
    pts = dict(A=[-x, -y, z], B=[x, -y, z], C=[x, -y, -z], D=[-x, -y, -z], A1=[-x, y, z], B1=[x, y, z], C1=[x, y, -z], D1=[-x, y, -z])
    faces = [dict(v=v) for v in (["A", "B", "C", "D"], ["A1", "B1", "C1", "D1"], ["A", "B", "B1", "A1"], ["B", "C", "C1", "B1"], ["C", "D", "D1", "C1"], ["D", "A", "A1", "D1"])]
    Rc = 0.5 * math.sqrt(a * a + b * b + h * h)
    return dict(key=kind, curved=False, auto_edges=True, pts=pts, faces=faces, labels=_labels(["A", "B", "C", "D", "A1", "B1", "C1", "D1"]),
                dims=[dict(a="A", b="B", text=f"a={num(a, 1)}")] if kind == "cube" else [dict(a="A", b="B", text=f"a={num(a, 1)}"), dict(a="B", b="C", text=f"b={num(b, 1)}"), dict(a="A", b="A1", text=f"h={num(h, 1)}")],
                aux=[], diag=dict(face=[dict(a="A", b="C", t="AC")], body=[dict(a="A", b="C1", t="AC₁")]), mid_edges=[["A", "B"], ["A", "D"], ["A", "A1"]],
                rel=dict(dihedral=dict(x="A1", e1="B", e2="D", y="A", label="A₁-BD-A"), linePlane=dict(p="A", q="C1", plane=["A", "B", "C", "D"], label="AC₁ 与底面 ABCD"), skew=dict(l1=["A", "A1"], l2=["B", "C1"], n1="AA₁", n2="BC₁"),
                         circum=dict(c=[0, 0, 0], R=Rc, tex=f"R=\\frac{{√3}}{{2}}a=\\frac{{√3}}{{2}}×{num(a, 1)}={num(Rc, 4)}" if kind == "cube" else f"R=\\frac{{1}}{{2}}\\sqrt{{a^2+b^2+h^2}}=\\frac{{1}}{{2}}\\sqrt{{{num(a * a + b * b + h * h, 2)}}}={num(Rc, 4)}")))


def build_prism(s):
    a, h = s["a"], s["h"]
    y, R3 = h / 2, a / math.sqrt(3)
    pts = dict(A=[0, -y, R3], B=[-a / 2, -y, -R3 / 2], C=[a / 2, -y, -R3 / 2], A1=[0, y, R3], B1=[-a / 2, y, -R3 / 2], C1=[a / 2, y, -R3 / 2])
    faces = [dict(v=v) for v in (["A", "B", "C"], ["A1", "B1", "C1"], ["A", "B", "B1", "A1"], ["B", "C", "C1", "B1"], ["C", "A", "A1", "C1"])]
    Rc = math.sqrt(a * a / 3 + h * h / 4)
    return dict(key="prism", curved=False, auto_edges=True, pts=pts, faces=faces, labels=_labels(["A", "B", "C", "A1", "B1", "C1"]), dims=[dict(a="A", b="B", text=f"a={num(a, 1)}"), dict(a="A", b="A1", text=f"h={num(h, 1)}")], aux=[],
                diag=dict(face=[dict(a="A", b="B1", t="AB₁")], body=[dict(a="A", b="C1", t="AC₁")]), mid_edges=[["A", "B"], ["A", "C"], ["A", "A1"]],
                rel=dict(dihedral=dict(x="A1", e1="B", e2="C", y="A", label="A₁-BC-A"), linePlane=dict(p="A", q="B1", plane=["A", "B", "C"], label="AB₁ 与底面 ABC"), skew=dict(l1=["A", "A1"], l2=["B", "C1"], n1="AA₁", n2="BC₁"),
                         circum=dict(c=[0, 0, 0], R=Rc, tex=f"R=\\sqrt{{a^2/3+h^2/4}}=\\sqrt{{{num(a * a / 3, 4)}+{num(h * h / 4, 4)}}}={num(Rc, 4)}")))


def build_pyramid(s):
    a, h = s["a"], s["h"]
    y, x = h / 2, a / 2
    pts = dict(A=[-x, -y, x], B=[x, -y, x], C=[x, -y, -x], D=[-x, -y, -x], P=[0, y, 0], O=[0, -y, 0], M=[x, -y, 0])
    faces = [dict(v=v) for v in (["A", "B", "C", "D"], ["P", "A", "B"], ["P", "B", "C"], ["P", "C", "D"], ["P", "D", "A"])]
    z0 = (h * h - a * a / 2) / (2 * h)
    Rc = math.sqrt(a * a / 2 + z0 * z0)
    return dict(key="pyramid", curved=False, auto_edges=True, pts=pts, faces=faces, labels=_labels(["A", "B", "C", "D", "P"]), dims=[dict(a="A", b="B", text=f"a={num(a, 1)}")],
                aux=[dict(a="P", b="O", text=f"h={num(h, 1)}"), dict(a="P", b="M", text=f"斜高 {num(math.sqrt(h * h + (a / 2) ** 2), 2)}")], diag=dict(face=[dict(a="A", b="C", t="AC")], body=[dict(a="P", b="A", t="PA")]), mid_edges=[["A", "B"], ["A", "D"], ["A", "P"]],
                rel=dict(dihedral=dict(x="P", e1="B", e2="C", y="A", label="P-BC-A"), linePlane=dict(p="P", q="A", plane=["A", "B", "C", "D"], label="棱 PA 与底面"), skew=dict(l1=["P", "A"], l2=["B", "C"], n1="PA", n2="BC"),
                         circum=dict(c=[0, -y + z0, 0], R=Rc, tex=f"R=\\sqrt{{a^2/2+z_0^2}}=\\sqrt{{{num(a * a / 2, 4)}+{num(z0 * z0, 4)}}}={num(Rc, 4)}")))


def _idx():
    return round(NSEG / 4), round(NSEG * 3 / 4), 0, round(NSEG / 2)


def _axis_rel(x, gen_a, gen_b, n1):
    return dict(dihedral=dict(x=x, e1="A", e2="B", y="C", label="轴截面与底面"), linePlane=dict(p=gen_a, q=gen_b, plane=["O", "A", "C"], label=f"母线 {n1} 与底面"))


def build_cylinder(s):
    r, h = s["r"], s["h"]
    y = h / 2
    B, Tp = ring(NSEG, r, -y), ring(NSEG, r, y)
    iF, iBk, iR, iL = _idx()
    pts = dict(O=[0, -y, 0], O1=[0, y, 0], A=B[iF], A1=Tp[iF], B=B[iBk], C=B[iR], D=B[iL], B1=Tp[iBk])
    faces = strip(B, Tp) + [dict(v=B, cull=True), dict(v=Tp, cull=True)]
    Rc = math.sqrt(r * r + h * h / 4)

    def sil(cam):
        ph = math.atan2(cam[0], cam[2])
        out = []
        for d in (math.pi / 2, -math.pi / 2):
            x, z = r * math.cos(ph + d), r * math.sin(ph + d)
            out.append([[x, -y, z], [x, y, z]])
        return out
    rel = _axis_rel("O1", "A", "A1", "AA₁")
    rel.update(skew=dict(l1=["A", "A1"], l2=["B", "D"], n1="AA₁", n2="BD"), circum=dict(c=[0, 0, 0], R=Rc, tex=f"R=\\sqrt{{r^2+h^2/4}}=\\sqrt{{{num(r * r, 4)}+{num(h * h / 4, 4)}}}={num(Rc, 4)}"))
    return dict(key="cylinder", curved=True, auto_edges=False, pts=pts, faces=faces, edges=[], chains=[dict(pts=B, closed=True), dict(pts=Tp, closed=True)],
                labels=[dict(name="A", text="A"), dict(name="A1", text="A₁"), dict(name="O", text="O"), dict(name="O1", text="O₁")], dims=[dict(a="O", b="A", text=f"r={num(r, 1)}")],
                aux=[dict(a="O", b="O1", text=f"h={num(h, 1)}"), dict(a="A", b="A1", text=f"母线 {num(h, 2)}")], sil=sil, rel=rel)


def build_cone(s):
    r, h = s["r"], s["h"]
    y = h / 2
    B = ring(NSEG, r, -y)
    iF, iBk, iR, iL = _idx()
    pts = dict(O=[0, -y, 0], P=[0, y, 0], A=B[iF], B=B[iBk], C=B[iR], D=B[iL])
    faces = [dict(v=[B[i], B[(i + 1) % NSEG], pts["P"]], cull=True) for i in range(NSEG)] + [dict(v=B, cull=True)]
    Rc = (r * r + h * h) / (2 * h)

    def sil(cam):
        ph = math.atan2(cam[0], cam[2])
        return [[[r * math.cos(ph + d), -y, r * math.sin(ph + d)], [0, y, 0]] for d in (math.pi / 2, -math.pi / 2)]
    rel = _axis_rel("P", "P", "A", "PA")
    rel.update(skew=dict(l1=["P", "A"], l2=["B", "C"], n1="PA", n2="BC"), circum=dict(c=[0, y - Rc, 0], R=Rc, tex=f"R=\\frac{{r^2+h^2}}{{2h}}=\\frac{{{num(r * r + h * h, 4)}}}{{{num(2 * h, 4)}}}={num(Rc, 4)}"))
    return dict(key="cone", curved=True, auto_edges=False, pts=pts, faces=faces, edges=[], chains=[dict(pts=B, closed=True)], labels=[dict(name="A", text="A"), dict(name="P", text="P"), dict(name="O", text="O")], dims=[dict(a="O", b="A", text=f"r={num(r, 1)}")],
                aux=[dict(a="P", b="O", text=f"h={num(h, 1)}"), dict(a="P", b="A", text=f"母线 {num(math.sqrt(r * r + h * h), 2)}")], sil=sil, rel=rel)


def build_frustum(s):
    R0, r0, h = s["R"], s["r"], s["h"]
    y = h / 2
    B, Tp = ring(NSEG, R0, -y), ring(NSEG, r0, y)
    iF, iBk, iR, iL = _idx()
    pts = dict(O=[0, -y, 0], O1=[0, y, 0], A=B[iF], A1=Tp[iF], B=B[iBk], C=B[iR], D=B[iL])
    faces = strip(B, Tp) + [dict(v=B, cull=True), dict(v=Tp, cull=True)]
    z0 = (r0 * r0 + h * h - R0 * R0) / (2 * h)
    Rc = math.sqrt(R0 * R0 + z0 * z0)

    def sil(cam):
        ph = math.atan2(cam[0], cam[2])
        out = []
        for d in (math.pi / 2, -math.pi / 2):
            x, z = math.cos(ph + d), math.sin(ph + d)
            out.append([[R0 * x, -y, R0 * z], [r0 * x, y, r0 * z]])
        return out
    rel = _axis_rel("O1", "A", "A1", "AA₁")
    rel.update(skew=dict(l1=["A", "A1"], l2=["B", "D"], n1="AA₁", n2="BD"), circum=dict(c=[0, -y + z0, 0], R=Rc, tex=f"R=\\sqrt{{R^2+z_0^2}}=\\sqrt{{{num(R0 * R0, 4)}+{num(z0 * z0, 4)}}}={num(Rc, 4)}"))
    return dict(key="frustum", curved=True, auto_edges=False, pts=pts, faces=faces, edges=[], chains=[dict(pts=B, closed=True), dict(pts=Tp, closed=True)],
                labels=[dict(name="A", text="A"), dict(name="A1", text="A₁"), dict(name="O", text="O"), dict(name="O1", text="O₁")], dims=[dict(a="O", b="A", text=f"R={num(R0, 1)}"), dict(a="O1", b="A1", text=f"r={num(r0, 1)}")],
                aux=[dict(a="O", b="O1", text=f"h={num(h, 1)}"), dict(a="A", b="A1", text=f"母线 {num(math.sqrt((R0 - r0) ** 2 + h * h), 2)}")], sil=sil, rel=rel)


def build_sphere(s):
    r, NL, NM = s["r"], 10, 20
    rings = [ring(NM, r * math.cos(-math.pi / 2 + math.pi * i / NL), r * math.sin(-math.pi / 2 + math.pi * i / NL)) for i in range(NL + 1)]
    faces = []
    for i in range(NL):
        faces += strip(rings[i], rings[i + 1])
    eq = ring(48, r, 0)
    mer = [[0, r * math.cos(TAU * i / 48), r * math.sin(TAU * i / 48)] for i in range(48)]

    def sil(cam):
        d = unit(cam)
        u = cross(d, [0, 1, 0])
        if vlen(u) < 1e-6:
            u = cross(d, [1, 0, 0])
        u = unit(u)
        v = unit(cross(d, u))
        return [{"closed": True, "pts": [add(mul(u, r * math.cos(TAU * i / 72)), mul(v, r * math.sin(TAU * i / 72))) for i in range(72)]}]
    return dict(key="sphere", curved=True, auto_edges=False, pts=dict(O=[0, 0, 0], N=[0, r, 0], E=[r, 0, 0], W=[-r, 0, 0], S=[0, -r, 0]), faces=faces, edges=[],
                chains=[dict(pts=eq, closed=True, surf=True), dict(pts=mer, closed=True, surf=True)], labels=[dict(name="O", text="O")], dims=[], aux=[], diag=dict(face=[], body=[]), sil=sil, surf=dict(c=[0, 0, 0], r=r),
                rel=dict(dihedral=dict(x="N", e1="E", e2="W", y=[0, 0, r], label="两大圆面夹角"), linePlane=dict(p="O", q="E", plane=[[r, 0, 0], [r, r, 0], [r, 0, r]], label="半径 OE 与切平面"),
                         skew=dict(l1=[[0, 0.62 * r, -0.8 * r], [0, 0.62 * r, 0.8 * r]], l2=[[-0.8 * r, 0, 0], [0.8 * r, 0, 0]], n1="截面弦", n2="直径"), circum=dict(c=[0, 0, 0], R=r, tex=f"R=r={num(r, 4)}")))


def build(key, s):
    fn = dict(cuboid=lambda: build_box("cuboid", s), prism=lambda: build_prism(s), pyramid=lambda: build_pyramid(s), cylinder=lambda: build_cylinder(s), cone=lambda: build_cone(s), sphere=lambda: build_sphere(s), frustum=lambda: build_frustum(s)).get(key, lambda: build_box("cube", s))
    return fn()


def rp(G, x):
    if isinstance(x, (list, tuple)):
        return x
    return G["pts"].get(norm_name(x)) or [0, 0, 0]


def plane_of(lst):
    if not lst or len(lst) < 3:
        return dict(n=[0, 1, 0], d=0)
    for i in range(1, len(lst) - 1):
        for j in range(i + 1, len(lst)):
            n0 = cross(sub(lst[i], lst[0]), sub(lst[j], lst[0]))
            if vlen(n0) > 1e-9:
                n = unit(n0)
                return dict(n=n, d=dot(n, lst[0]))
    return dict(n=[0, 1, 0], d=lst[0][1])


def poly_area3(P):
    if not P or len(P) < 3:
        return 0
    c = mean(P)
    u = unit(sub(P[1], P[0]))
    nrm = cross(sub(P[1], P[0]), sub(P[2], P[0]))
    if vlen(nrm) < 1e-9:
        return 0
    v = unit(cross(unit(nrm), u))
    s = 0
    for i, p in enumerate(P):
        a, b = sub(p, c), sub(P[(i + 1) % len(P)], c)
        s += dot(a, u) * dot(b, v) - dot(b, u) * dot(a, v)
    return abs(s) / 2


def poly_perim(P):
    return sum(dist(p, P[(i + 1) % len(P)]) for i, p in enumerate(P))


def section_poly(G, pl):
    if not pl:
        return []
    S = G.get("scale") or 1
    eps = 1e-5 * S
    raw = []
    for f in G["faces"]:
        w = [rp(G, x) for x in f["v"]]
        for i, p in enumerate(w):
            q = w[(i + 1) % len(w)]
            dp, dq = dot(pl["n"], p) - pl["d"], dot(pl["n"], q) - pl["d"]
            if abs(dp) < eps:
                raw.append(p)
            if dp * dq < 0:
                raw.append(add(p, mul(sub(q, p), dp / (dp - dq))))
    uniq = []
    for p in raw:
        if not any(dist(p, q) < 1e-4 * S for q in uniq):
            uniq.append(p)
    if len(uniq) < 3:
        return []
    c = mean(uniq)
    u = unit(sub(uniq[0], c))
    if vlen(u) < 0.5:
        u = unit(cross(pl["n"], [0, 1, 0]))
    v = unit(cross(pl["n"], u))
    return sorted(uniq, key=lambda p: math.atan2(dot(sub(p, c), v), dot(sub(p, c), u)))


def _perp(A, M, e):
    w = sub(A, M)
    p = sub(w, mul(e, dot(w, e)))
    return None if vlen(p) < 1e-7 else unit(p)


def calc_dihedral(G, r):
    if not r:
        return None
    X, E1, E2, Y = rp(G, r["x"]), rp(G, r["e1"]), rp(G, r["e2"]), rp(G, r["y"])
    M, e = mid(E1, E2), unit(sub(E2, E1))
    u1, u2 = _perp(X, M, e), _perp(Y, M, e)
    if not u1 or not u2:
        return None
    cs = clamp(dot(u1, u2), -1, 1)
    th = math.acos(cs)
    return dict(E1=E1, E2=E2, M=M, e=e, u1=u1, u2=u2, n1=unit(cross(e, u1)), n2=unit(cross(e, u2)), cos=cs, th=th, deg=th * DEG, label=r["label"])


def calc_line_plane(G, r):
    if not r:
        return None
    A, B = rp(G, r["p"]), rp(G, r["q"])
    pl = plane_of([rp(G, x) for x in r.get("plane") or []])
    n = pl["n"]
    d = sub(B, A)
    dl = vlen(d) or 1
    sn = abs(dot(d, n)) / dl
    th = math.asin(clamp(sn, 0, 1))
    dn = dot(d, n)
    if abs(dot(n, A) - pl["d"]) < 1e-7:
        X = A
    else:
        X = add(A, mul(d, (pl["d"] - dot(n, A)) / dn)) if abs(dn) > 1e-9 else A
    far = A if dist(A, X) >= dist(B, X) else B
    u1 = unit(sub(far, X))
    up = sub(u1, mul(n, dot(u1, n)))
    flat = vlen(up) < 1e-6
    u2 = unit(cross(n, [1, 0, 0])) if flat else unit(up)
    foot = sub(far, mul(n, dot(n, far) - pl["d"]))
    return dict(A=A, B=B, X=X, far=far, foot=foot, n=n, sin=sn, th=th, deg=th * DEG, flat=flat, u1=u1, u2=u2, label=r["label"])


def calc_skew(G, r):
    if not r:
        return None
    A1, A2, B1, B2 = rp(G, r["l1"][0]), rp(G, r["l1"][1]), rp(G, r["l2"][0]), rp(G, r["l2"][1])
    d1, d2 = sub(A2, A1), sub(B2, B1)
    n = cross(d1, d2)
    nl = vlen(n)
    if nl < 1e-9:
        return None
    dd = abs(dot(sub(B1, A1), n)) / nl
    w0 = sub(A1, B1)
    a, b, c = dot(d1, d1), dot(d1, d2), dot(d2, d2)
    g, h = dot(d1, w0), dot(d2, w0)
    den = a * c - b * b
    P, Q = mid(A1, A2), mid(B1, B2)
    if abs(den) > 1e-9:
        P = add(A1, mul(d1, (b * h - c * g) / den))
        Q = add(B1, mul(d2, (a * h - b * g) / den))
    return dict(A1=A1, A2=A2, B1=B1, B2=B2, P=P, Q=Q, dist=dd)


def vol_surf(k, s):
    P = math.pi
    if k == "cube":
        return s["a"] ** 3, 6 * s["a"] ** 2
    if k == "cuboid":
        return s["a"] * s["b"] * s["h"], 2 * (s["a"] * s["b"] + s["a"] * s["h"] + s["b"] * s["h"])
    if k == "prism":
        A = math.sqrt(3) / 4 * s["a"] ** 2
        return A * s["h"], 2 * A + 3 * s["a"] * s["h"]
    if k == "pyramid":
        ln = math.sqrt(s["h"] ** 2 + s["a"] ** 2 / 4)
        return s["a"] ** 2 * s["h"] / 3, s["a"] ** 2 + 2 * s["a"] * ln
    if k == "cylinder":
        return P * s["r"] ** 2 * s["h"], 2 * P * s["r"] * (s["r"] + s["h"])
    if k == "cone":
        ln = math.sqrt(s["r"] ** 2 + s["h"] ** 2)
        return P * s["r"] ** 2 * s["h"] / 3, P * s["r"] * (s["r"] + ln)
    if k == "sphere":
        return 4 / 3 * P * s["r"] ** 3, 4 * P * s["r"] ** 2
    if k == "frustum":
        ln = math.sqrt((s["R"] - s["r"]) ** 2 + s["h"] ** 2)
        return P * s["h"] * (s["R"] ** 2 + s["R"] * s["r"] + s["r"] ** 2) / 3, P * (s["R"] ** 2 + s["r"] ** 2 + (s["R"] + s["r"]) * ln)
    return 0, 0


def vol_tex(k, s):
    n = num
    if k == "cube":
        return f"V=a^3={n(s['a'], 1)}^3", f"S=6a^2=6×{n(s['a'] ** 2, 2)}"
    if k == "cuboid":
        return f"V=abh={n(s['a'], 1)}×{n(s['b'], 1)}×{n(s['h'], 1)}", "S=2(ab+ah+bh)"
    if k == "prism":
        return f"V=\\frac{{√3}}{{4}}a^2h={n(math.sqrt(3) / 4 * s['a'] ** 2, 3)}×{n(s['h'], 1)}", "S=\\frac{√3}{2}a^2+3ah"
    if k == "pyramid":
        return f"V=\\frac{{1}}{{3}}a^2h=\\frac{{1}}{{3}}×{n(s['a'] ** 2 * s['h'], 3)}", "S=a^2+2a·l"
    if k == "cylinder":
        return f"V=πr^2h=π×{n(s['r'] ** 2, 2)}×{n(s['h'], 1)}", "S=2πr(r+h)"
    if k == "cone":
        return f"V=\\frac{{1}}{{3}}πr^2h=\\frac{{1}}{{3}}×π×{n(s['r'] ** 2, 2)}×{n(s['h'], 1)}", "S=πr(r+l)"
    if k == "sphere":
        return f"V=\\frac{{4}}{{3}}πr^3=\\frac{{4}}{{3}}×π×{n(s['r'] ** 3, 2)}", "S=4πr^2"
    if k == "frustum":
        return "V=\\frac{1}{3}πh(R^2+Rr+r^2)", "S=π(R^2+r^2+(R+r)l)"
    return "V=0", "S=0"


def ask_of(text):
    t = str(text or "")
    if re.search("二面", t):
        return "dihedral"
    if re.search("线面", t):
        return "linePlane"
    if re.search("异面", t):
        return "skew"
    if re.search("外接|球半径", t):
        return "circum"
    if re.search("体积|表面积", t):
        return "volume"
    return "dihedral"


ASK_LABEL = dict(dihedral="二面角", linePlane="线面角", skew="异面直线距离", circum="外接球半径", volume="体积")
