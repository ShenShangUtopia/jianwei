"""习题台的三个工具对话框：导入题目（粘贴 → 判题型）、场景搭建器、快捷键帮助。"""
from __future__ import annotations

import re
import time

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QDialog, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget)

from ..design.widgets import qss
from ..kit.home import load_json, save_json
from .ph_core import SCENES

SUBJECTS = ["数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理"]
BUILT = "bank-built.json"
PHYS = [(r"平抛|斜抛|抛出|抛体", "projectile"), (r"斜面|倾角", "incline"), (r"弹簧|劲度", "spring"), (r"圆周|向心|绳|摆", "circular"), (r"波|波长|频率|振动", "wave"), (r"折射|全反射|棱镜|玻璃砖|光", "optics"),
        (r"电路|电阻|电源|电动势|电流", "circuit"), (r"平行板|电场|偏转", "efield"), (r"碰撞|反弹|动量", "collision"), (r"卫星|轨道|万有引力", "gravity")]
SUBJ = [(r"遗传|等位基因|表现型|杂交|Aa|基因型", "genetics"), (r"细胞|膜|细胞器|光合|呼吸作用|酶", "cell"), (r"生态|食物链|能量流动|种群", "ecology"), (r"滴定|pH|中和", "titration"), (r"平衡|转化率|平衡常数|K=", "equilibrium"),
        (r"原电池|电解|电极|电化学", "electrochem"), (r"反应|方程式|配平|mol|氧化|还原", "reaction"), (r"诗|词|意象|颔联|颈联|文言", "poem"), (r"syntax|从句|定语|状语|谓语|英文|English", "syntax"),
        (r"朝代|变法|革命|条约|世纪|公元|年号|1[0-9]{3}\s*年", "timeline"), (r"经纬|海拔|气候|洋流|河流|地形|降水量|流域|等高线", "map")]


def detect(text):
    s = str(text or "")
    if re.search("椭圆|双曲线|抛物线|离心率|焦点|准线", s) and not re.search("顶点|开口|对称轴", s):
        return dict(engine="graph", mode="conic")
    if re.search(r"f\s*\(x\)|函数|图象|导数|极值|单调", s):
        if re.search("sin|cos|tan|周期|振幅", s):
            return dict(engine="graph", mode="trig")
        if re.search(r"绝对值|\|x", s):
            return dict(engine="graph", mode="piecewise")
        if "向量" in s:
            return dict(engine="graph", mode="vec")
        return dict(engine="graph", mode="poly")
    for pat, k in PHYS:
        if re.search(pat, s):
            return dict(engine="physics", kind=k)
    if re.search("正方体|长方体|棱柱|棱锥|棱台|圆柱|圆锥|圆台|三视图|二面角|线面角|截面|体积|表面积", s):
        return dict(engine="solid", shape="cube")
    for pat, m in SUBJ:
        if re.search(pat, s):
            return dict(engine="subjects", mode=m)
    return dict(engine="subjects", mode="flow")


def _grab(s, pat, d):
    m = re.search(pat, s)
    if not m:
        return d
    g = next((x for x in m.groups() if x), None)
    return float(g) if g else d


def physics_params(kind, s):
    n = lambda pat, d: _grab(s, pat, d)   # noqa: E731
    if kind == "projectile":
        return dict(v0=n(r"v_?0?\s*[=:]\s*([\d.]+)", n(r"([\d.]+)\s*m/s", 10)), angle=n(r"([\d.]+)\s*°", 0), h0=n(r"h\s*[=:]\s*([\d.]+)\s*m", n(r"([\d.]+)\s*m\s*高|高\s*([\d.]+)", 0)), g=10)
    if kind == "incline":
        return dict(angle=n(r"([\d.]+)\s*°", 30), m=n(r"([\d.]+)\s*kg", 1), mu=n(r"μ\s*[=:]\s*([\d.]+)", 0.2), g=10)
    if kind == "circuit":
        return dict(Emf=n(r"([\d.]+)\s*V", 12), R1=n(r"R1?\s*[=:]\s*([\d.]+)", 4), R2=n(r"R2\s*[=:]\s*([\d.]+)", 6), r=n(r"r\s*[=:]\s*([\d.]+)", 1))
    if kind == "optics":
        return dict(n=n(r"n\s*[=:]\s*([\d.]+)", 1.5), angle=n(r"([\d.]+)\s*°", 45))
    if kind == "wave":
        return dict(v0=n(r"([\d.]+)\s*m/s", 2), f=n(r"([\d.]+)\s*Hz", 1))
    if kind == "spring":
        return dict(k=n(r"k\s*[=:]\s*([\d.]+)", 200), m=n(r"([\d.]+)\s*kg", 1))
    if kind == "circular":
        return dict(r=n(r"r\s*[=:]\s*([\d.]+)", 0.5), v0=n(r"([\d.]+)\s*m/s", 2), m=n(r"([\d.]+)\s*kg", 1))
    if kind == "efield":
        return dict(E=n(r"E\s*[=:]\s*([\d.]+)", 6), v0=n(r"([\d.]+)\s*m/s", 3))
    if kind == "gravity":
        return dict(r=n(r"r\s*[=:]\s*([\d.]+)", 12))
    return {}


def expression(s):
    m = re.search(r"y\s*=\s*([^，。；\n,;]+)", s) or re.search(r"([\d.]*\s*(?:sin|cos|tan|ln|exp)\s*\([^)]*\))", s)
    if not m:
        return ""
    return re.sub(r"\s+", "", m.group(1).replace("π", "pi").replace("×", "*").replace("÷", "/").replace("−", "-").replace("–", "-"))


def steps_of(text):
    return [t.strip() for t in str(text or "").split("\n") if t.strip()][:6]


def guess_subject(s):
    for pat, name in ((r"[函数导向量椭圆双曲线抛物线数列概率]", "数学"), (r"电路|力|速度|加速度|磁|电场|卫星|折射", "物理"), (r"mol|反应|方程式|氧化|溶液|滴定|电解", "化学"), (r"细胞|基因|遗传|种群|光合", "生物"), (r"诗|词|文言|作文", "语文"), (r"[A-Za-z]{4,}\s+[A-Za-z]{3,}", "英语"), (r"朝代|变法|革命|条约", "历史"), (r"经纬|气候|洋流|河流", "地理")):
        if re.search(pat, s):
            return name
    return "数学"


def build_import(text, steps="", answer="", subject=None, engine="auto", title=""):
    text = str(text or "").strip()
    d = {"engine": engine} if engine and engine != "auto" else detect(text)
    view = dict(engine=d["engine"])
    if d["engine"] == "graph":
        mode = d.get("mode") or "poly"
        expr = expression(text)
        if expr:
            bare = re.sub(r"sin|cos|tan|sqrt|abs|ln|exp|log|pi", "", expr, flags=re.I)
            if re.search(r"[a-wyz]", bare.replace("x", ""), re.I):
                expr = ""   # 带 a / b / c 这类符号参数，退回模板
        expr = expr or ("sin(x)" if mode == "trig" else "x^2")
        view.update(mode=mode, expr=expr if "x" in expr else expr + "*x", xr=[-6, 6], yr=[-4, 4], call="拖动曲线平移 · 滚轮伸缩 · 拖右环旋转")
        if mode == "trig":
            view["params"] = [dict(k="A", label="振幅 A", min=0.2, max=3, step=0.1, v=1), dict(k="B", label="角频率 B", min=0.2, max=3, step=0.1, v=1), dict(k="H", label="相位 H", min=-3, max=3, step=0.1, v=0), dict(k="K", label="上下 K", min=-3, max=3, step=0.1, v=0)]
            if "A" not in expr:
                view.update(expr="A*sin(B*x+H)+K", ghost="sin(x)")
        elif mode == "conic":
            view.pop("expr")
            view["params"] = None
        else:
            view["params"] = [dict(k="A", label="纵向 A", min=0.2, max=3, step=0.1, v=1)]
    elif d["engine"] == "physics":
        view.update(kind=d.get("kind") or "projectile", cue="这题要算的量")
        view["params"] = physics_params(view["kind"], text)
    elif d["engine"] == "solid":
        view.update(shape=d.get("shape") or "cube", size=dict(a=2, b=3, h=4, r=1))
    else:
        lines = steps_of(steps)
        view.update(mode=d.get("mode") or "flow", params={}, data=dict(title=text[:16] or "导入题", lines=lines or ["读题找条件", "列式或列关系", "代入求解", "回头检验"]))
    st = steps_of(steps) or ["读题，圈出已知与所求", "选模型、列关系式", "代入求解", "回头检验单位与范围"]
    return dict(id=f"imp-{int(time.time() * 1000):x}", year=time.localtime().tm_year, paper="导入", subject=subject or guess_subject(text), type="导入", title=(title or re.sub(r"\s+", " ", text)[:18] or "导入题"), stem=text, answer=str(answer or ""), steps=st, points=[], why="自己导入的题", view=view)


ENGINE_NAMES = dict(graph="函数图象", physics="物理过程", solid="立体几何", subjects="分学科图解")


class ImportDialog(QDialog):
    """粘贴题干，自动判断题型；确认后加入题库并打开。"""

    def __init__(self, parent, on_done):
        super().__init__(parent)
        self.on_done = on_done
        self.setObjectName("jw2")
        self.setWindowTitle("导入题目")
        self.resize(620, 560)
        self.setStyleSheet(qss())
        v = QVBoxLayout(self)
        v.setSpacing(8)
        v.addWidget(QLabel("题干（粘贴后自动判断用哪种图解）"))
        self.stem = QPlainTextEdit()
        self.stem.setPlaceholderText("把题目粘贴到这里")
        self.stem.textChanged.connect(self.refresh)
        v.addWidget(self.stem, 2)
        f = QFormLayout()
        self.title_ = QLineEdit()
        self.title_.setPlaceholderText("可不填，默认取题干开头")
        f.addRow("标题", self.title_)
        self.subject = QComboBox()
        self.subject.addItems(SUBJECTS)
        f.addRow("学科", self.subject)
        self.engine = QComboBox()
        self.engine.addItem("自动判断", "auto")
        for k, n in ENGINE_NAMES.items():
            self.engine.addItem(n, k)
        self.engine.currentIndexChanged.connect(self.refresh)
        f.addRow("图解", self.engine)
        self.answer = QLineEdit()
        f.addRow("答案", self.answer)
        v.addLayout(f)
        v.addWidget(QLabel("解题步骤（可选，一行一步）"))
        self.steps = QPlainTextEdit()
        self.steps.setMaximumHeight(110)
        v.addWidget(self.steps)
        self.detect_l = QLabel("")
        self.detect_l.setObjectName("note")
        v.addWidget(self.detect_l)
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = QPushButton("取消")
        cancel.clicked.connect(self.reject)
        ok = QPushButton("加入题库并打开")
        ok.setObjectName("pri")
        ok.clicked.connect(self.commit)
        row.addWidget(cancel)
        row.addWidget(ok)
        v.addLayout(row)
        self.refresh()

    def refresh(self):
        text = self.stem.toPlainText()
        self.subject.setCurrentText(guess_subject(text)) if text.strip() else None
        eng = self.engine.currentData()
        d = detect(text) if eng == "auto" else dict(engine=eng)
        extra = d.get("kind") or d.get("mode") or d.get("shape") or ""
        self.detect_l.setText(f"将使用：{ENGINE_NAMES.get(d['engine'], d['engine'])}" + (f" · {extra}" if extra else ""))

    def commit(self):
        text = self.stem.toPlainText().strip()
        if not text:
            self.detect_l.setText("先粘贴题干")
            return
        self.on_done(build_import(text, self.steps.toPlainText(), self.answer.text(), self.subject.currentText(), self.engine.currentData(), self.title_.text().strip()))
        self.accept()


SCENE_NAMES = dict(projectile="平抛 / 斜抛", incline="斜面", circular="圆周运动", collision="一维碰撞", spring="弹簧振子", gravity="卫星圆轨道", gravity2="变轨", efield="平行板偏转", circuit="闭合电路", efield2="电场线与等势面", magnet="磁场圆周", induction="电磁感应",
                   optics="折射", lens="透镜成像", interference="双缝干涉", wave="横波", shm="简谐振动")


def load_built():
    raw = load_json(BUILT, [])
    return raw if isinstance(raw, list) else []


def build_scene_question(kind, params, title="", stem="", points=""):
    nm = SCENE_NAMES.get(kind, kind)
    st = stem.strip() or f"调整参数，观察「{nm}」的过程，先预测再验证。"
    pts = [x for x in re.split(r"[，,、\s]+", points.strip()) if x][:4]
    return dict(id=f"bd-{int(time.time() * 1000)}", year=time.localtime().tm_year, paper="场景搭建器", subject="物理", type="实验", title=title.strip() or f"我的场景 · {time.strftime('%m-%d %H:%M')}", stem=st, answer="（自己观察）",
                steps=["先看已知参数", "开始播放观察过程", "记录关键量"], points=pts, why="自己搭的场景，先预测再验证", view=dict(engine="physics", kind=kind, params=params, cue=st))


class BuilderDialog(QDialog):
    """物理场景搭建器：选场景、调参数、存成自己的题。"""

    def __init__(self, parent, on_open):
        super().__init__(parent)
        self.on_open = on_open
        self.setObjectName("jw2")
        self.setWindowTitle("场景搭建器")
        self.resize(780, 560)
        self.setStyleSheet(qss())
        h = QHBoxLayout(self)
        left = QVBoxLayout()
        left.addWidget(QLabel("场景"))
        self.scene_l = QListWidget()
        for k, n in SCENE_NAMES.items():
            it = QListWidgetItem(n)
            it.setData(Qt.ItemDataRole.UserRole, k)
            self.scene_l.addItem(it)
        self.scene_l.currentRowChanged.connect(self.pick)
        left.addWidget(self.scene_l, 1)
        h.addLayout(left, 2)
        mid = QVBoxLayout()
        self.form_host = QWidget()
        self.form = QFormLayout(self.form_host)
        mid.addWidget(self.form_host)
        self.title_ = QLineEdit()
        self.title_.setPlaceholderText("标题（可不填）")
        self.stem = QLineEdit()
        self.stem.setPlaceholderText("说明（可不填）")
        self.points = QLineEdit()
        self.points.setPlaceholderText("知识点，逗号分隔（可不填）")
        for w in (self.title_, self.stem, self.points):
            mid.addWidget(w)
        mid.addStretch(1)
        ok = QPushButton("保存并打开")
        ok.setObjectName("pri")
        ok.clicked.connect(self.save)
        mid.addWidget(ok)
        h.addLayout(mid, 3)
        right = QVBoxLayout()
        right.addWidget(QLabel("已存的场景"))
        self.saved = QListWidget()
        self.saved.itemDoubleClicked.connect(lambda _i: self.open_saved())
        right.addWidget(self.saved, 1)
        row = QHBoxLayout()
        b1 = QPushButton("打开")
        b1.clicked.connect(self.open_saved)
        b2 = QPushButton("删除")
        b2.clicked.connect(self.delete_saved)
        row.addWidget(b1)
        row.addWidget(b2)
        right.addLayout(row)
        h.addLayout(right, 2)
        self.spins = {}
        self.scene_l.setCurrentRow(0)
        self.refresh_saved()

    def pick(self, row):
        while self.form.rowCount():
            self.form.removeRow(0)
        self.spins = {}
        kind = self.scene_l.item(row).data(Qt.ItemDataRole.UserRole)
        self.kind = kind
        sc = SCENES[kind]()
        for k, lb, mn, mx, step, dec in sc.sliders:
            sp = QDoubleSpinBox()
            sp.setRange(mn, mx)
            sp.setSingleStep(step)
            sp.setDecimals(dec if dec else 0)
            sp.setValue(getattr(sc.P, k))
            self.form.addRow(lb, sp)
            self.spins[k] = sp

    def refresh_saved(self):
        self.saved.clear()
        for q in reversed(load_built()):
            it = QListWidgetItem(q.get("title") or q["id"])
            it.setData(Qt.ItemDataRole.UserRole, q["id"])
            self.saved.addItem(it)

    def save(self):
        q = build_scene_question(self.kind, {k: s.value() for k, s in self.spins.items()}, self.title_.text(), self.stem.text(), self.points.text())
        save_json(BUILT, (load_built() + [q])[-100:])
        self.on_open(q)
        self.accept()

    def _current(self):
        it = self.saved.currentItem()
        if not it:
            return None
        qid = it.data(Qt.ItemDataRole.UserRole)
        return next((q for q in load_built() if q["id"] == qid), None)

    def open_saved(self):
        q = self._current()
        if q:
            self.on_open(q)
            self.accept()

    def delete_saved(self):
        q = self._current()
        if q:
            save_json(BUILT, [x for x in load_built() if x["id"] != q["id"]])
            self.refresh_saved()


class HelpDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setObjectName("jw2")
        self.setWindowTitle("快捷键")
        self.setStyleSheet(qss())
        v = QVBoxLayout(self)
        rows = (("← / →", "上一步 / 下一步"), ("空格", "播放 / 暂停讲解"), ("R", "从头重播"), ("A", "显示 / 收起答案"), ("S", "标为错题 / 取消"), ("1 2 3", "提示 1 / 2 / 3"), ("I", "导入题目"), ("B", "场景搭建器"), ("Ctrl+F", "搜索题目"), ("Ctrl+E", "把当前画面导出为 PNG"), ("?", "打开这张表"), ("Esc", "关闭知识卡或这张表"))
        f = QFormLayout()
        for k, d in rows:
            f.addRow(QLabel(f"<b>{k}</b>"), QLabel(d))
        v.addLayout(f)
