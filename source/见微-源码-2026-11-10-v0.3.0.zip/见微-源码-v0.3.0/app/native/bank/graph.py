"""graph 引擎：函数变换视图（由 views/graph.js + graphplus.js 改写）。

三件手势：拖曲线平移 · 滚轮伸缩 · 拖右环旋转。题目给 expr + params，画布实时代入；
右栏的「函数性质」按当前视野实算（零点、极值、拐点、渐近线、单调、奇偶、周期、值域）。
"""
from __future__ import annotations

import math
import re
import time

from PySide6.QtCore import QPointF, Qt, QTimer
from PySide6.QtGui import QPainterPath
from PySide6.QtWidgets import QApplication, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from ..design.tokens import T, alpha, qc
from ..kit.core import clamp
from ..kit.draw import D
from ..kit.expr import ExprError, compile_expr
from ..kit.home import load_json, save_json
from .fx import fx
from .graph_an import analyze, fmt_a
from .ph_core import Cv, plabel, stroke_arc
from .sb_core import C, num

PI, TAU = math.pi, math.tau
cos, sin, sqrt, atan2 = math.cos, math.sin, math.sqrt, math.atan2
ISF = math.isfinite

FAMILIES = {
    "sin": ("正弦 sin x", "sin t", math.sin),
    "quad": ("二次 x²", "t^2", lambda t: t * t),
    "cubic": ("三次 x³", "t^3", lambda t: t * t * t),
    "inv": ("倒数 1/x", "\\frac{1}{t}", lambda t: 1 / t if t else math.nan),
    "sqrt": ("根式 √x", "\\sqrt{t}", lambda t: math.nan if t < 0 else math.sqrt(t)),
    "exp": ("指数 e^x", "e^t", lambda t: math.exp(t) if t < 700 else math.nan),
    "ln": ("对数 ln x", "ln t", lambda t: math.nan if t <= 0 else math.log(t)),
    "circle": ("圆 x²+y²=1", "(cos t, sin t)", None),
}


def _ps(k, label, mn, mx, step, v):
    return dict(k=k, label=label, min=mn, max=mx, step=step, v=v)


_DRAG = "拖曲线平移 · 滚轮横向伸缩 · Shift+滚轮纵向伸缩 · 拖右环旋转"
GMODES = {
    "trig": dict(name="三角", expr="A*sin(B*x+H)+K", ghost="sin(x)", xr=[-6.6, 6.6], yr=[-3.6, 3.6], neutral=dict(A=1, B=1, H=0, K=0), call="左加右减：相位 H 越大，曲线越靠左。", legend=_DRAG,
                 params=[_ps("A", "振幅 A", 0.2, 3, 0.1, 2), _ps("B", "横向伸缩 B", 0.3, 3, 0.1, 2), _ps("H", "相位 H", -6.3, 6.3, 0.05, PI / 3), _ps("K", "纵移 K", -3, 3, 0.1, -1)]),
    "poly": dict(name="二次", expr="A*((x-H)/B)^2+K", ghost="x^2", xr=[-6.6, 6.6], yr=[-3.6, 3.6], neutral=dict(A=1, B=1, H=0, K=0), call="顶点在 (H, K)，A 定开口，B 管胖瘦。", legend=_DRAG,
                 params=[_ps("A", "开口 A", -2, 2, 0.1, 0.8), _ps("B", "横向伸缩 B", 0.3, 3, 0.1, 1), _ps("H", "顶点横标 H", -5, 5, 0.1, 1), _ps("K", "顶点纵标 K", -3.5, 3.5, 0.1, -1.6)]),
    "conic": dict(name="圆锥曲线", expr="", ghost="", xr=[-6.6, 6.6], yr=[-3.6, 3.6], neutral=dict(A=1, B=1, H=0, K=0), call="双曲线：两支各自逼近渐近线，准线左右对称。", legend="拖中心平移 · 滚轮改实半轴 · Shift+滚轮改虚半轴 · 拖右环旋转",
                  params=[_ps("A", "实半轴 A", 0.4, 3, 0.1, 2), _ps("B", "虚半轴 B", 0.3, 3, 0.1, 1.2), _ps("H", "中心横标 H", -4, 4, 0.1, 0), _ps("K", "中心纵标 K", -3, 3, 0.1, 0)]),
    "piecewise": dict(name="分段", expr="A*abs(B*(x-H))+K", ghost="abs(x)", xr=[-6.6, 6.6], yr=[-3.6, 3.6], neutral=dict(A=1, B=1, H=0, K=0), call="两段直线拼成 V 形，拐点是 (H, K)。", legend=_DRAG,
                      params=[_ps("A", "斜率 A", 0.2, 3, 0.1, 1), _ps("B", "横向伸缩 B", 0.3, 3, 0.1, 1), _ps("H", "拐点横标 H", -5, 5, 0.1, 0.5), _ps("K", "拐点纵标 K", -3, 3, 0.1, -0.8)]),
    "vec": dict(name="向量", expr="", ghost="", xr=[-4.6, 4.6], yr=[-3.2, 3.2], neutral=dict(A=0, B=0, H=0, K=0), call="u 与 v 首尾相接得到 u+v；拖箭头改分量。", legend="拖箭头改分量 · 滚轮改 v 的横分量 · Shift+滚轮改 u 的横分量 · 拖右环旋转",
                params=[_ps("A", "u 横分量", -3, 3, 0.1, 2.4), _ps("H", "u 纵分量", -3, 3, 0.1, 1.2), _ps("B", "v 横分量", -3, 3, 0.1, 1.2), _ps("K", "v 纵分量", -3, 3, 0.1, -1.6)]),
    "lab": dict(name="实验室", expr="", ghost="", xr=[-6.6, 6.6], yr=[-3.6, 3.6], neutral=dict(A=1, B=1, H=0, K=0), call="选函数族，看矩阵 M 与平移向量 T 怎么改图形。", legend=_DRAG,
                params=[_ps("A", "纵向伸缩 A", 0.2, 3, 0.1, 1.2), _ps("B", "横向伸缩 B", 0.2, 3, 0.1, 1.5), _ps("H", "横移 H", -5, 5, 0.1, 0.6), _ps("K", "纵移 K", -3, 3, 0.1, 0.3)]),
}

# 变换实验室：按知识块进入
LAB_PRESETS = [
    ("函数与导数", [("一次函数", "A*(B*x+H)+K", dict(A=1, B=1, H=0, K=0)), ("二次函数", "A*((x-H)/B)^2+K", dict(A=1, B=1, H=0, K=0)), ("三次函数", "A*x^3+B*x^2+H*x+K", dict(A=0.4, B=1, H=0, K=0)), ("反比例", "A/(B*x+H)+K", dict(A=1, B=1, H=0, K=0))]),
    ("指数与对数", [("指数函数", "A*exp(B*x+H)+K", dict(A=1, B=1, H=0, K=0)), ("对数函数", "A*ln(B*x+H)+K", dict(A=1, B=1, H=0, K=0)), ("幂函数", "A*x^B+K", dict(A=1, B=1, K=0))]),
    ("三角函数", [("正弦型", "A*sin(B*x+H)+K", dict(A=1, B=1, H=0, K=0)), ("余弦型", "A*cos(B*x+H)+K", dict(A=1, B=1, H=0, K=0)), ("正切型", "A*tan(B*x+H)+K", dict(A=1, B=1, H=0, K=0))]),
    ("解析几何", [("抛物线", "A*((x-H)/B)^2+K", dict(A=1, B=1, H=0, K=0)), ("双曲线一支", "A*sqrt(1+((x-H)/B)^2)+K", dict(A=1, B=1, H=0, K=0)), ("圆的上半", "K+sqrt(A^2-(x-H)^2)", dict(A=2, H=0, K=0))]),
    ("绝对值与分段", [("绝对值", "A*abs(B*x+H)+K", dict(A=1, B=1, H=0, K=0)), ("双绝对值", "A*abs(x+B)+H*abs(x-K)", dict(A=1, B=0, H=0, K=2))]),
]


def preset_question(group_item):
    name, e, p = group_item
    lb = dict(A="伸缩 A", B="横缩 B", H="横移 H", K="纵移 K")
    params = [dict(k=k, label=lb.get(k, k), min=-6 if k in "HK" else 0.2, max=6 if k in "HK" else 4, step=0.1, v=v) for k, v in p.items()]
    if "B" in p and p["B"] == 0:
        params[[x["k"] for x in params].index("B")]["min"] = -4
    return dict(id="lab-preset", subject="数学", year=None, title=name, stem=f"y = {e}", answer="", steps=["写出解析式", "看图象变换", "看性质"], points=["函数图象"],
                view=dict(engine="graph", mode="poly", expr=e, params=params, xr=[-6.6, 6.6], yr=[-4, 4], preset=True, call="拖动曲线平移 · 滚轮伸缩 · 下方按钮微调"))


def lab_question():
    return dict(id="lab", subject="数学", year=None, title="变换实验室", stem="选函数族或知识块，看平移、伸缩、旋转怎样改变图形。", answer="", steps=["原始函数", "纵向伸缩", "横向伸缩", "横向平移", "纵向平移"], points=["函数图象变换"], view=dict(engine="graph", lab=True))


# ---------------------------------------------------------------- 数字与公式
def near(a, b):
    return abs(a - b) < 1e-6


def fxn(v, d=2):
    if not ISF(v):
        return "0"
    t = num(abs(v), d)
    return ("−" if v < 0 and float(t) > 0 else "") + t


def term(v, fn, pad=False):
    if abs(v) < 1e-9:
        return ""
    return (((" − " if pad else "−") if v < 0 else (" + " if pad else "+"))) + fn(abs(v))


def pi_val(v):
    if abs(v) >= 5e-4:
        r = v / PI
        for q in range(1, 13):
            n = round(r * q)
            if n and abs(r * q - n) < 1e-7:
                a = abs(n)
                s = "π" if a == 1 else f"{a}π"
                return ("−" if n < 0 else "") + (s if q == 1 else f"{s}/{q}")
    return fxn(v)


def n2(v):
    if not ISF(v):
        return "0.00"
    r = 0 if abs(v) < 0.005 else v
    return ("−" if r < 0 else "") + f"{abs(r):.2f}"


def step_for(span):
    raw = abs(span) / 8 or 1
    p = 10 ** math.floor(math.log10(raw))
    n = raw / p
    return (1 if n < 1.5 else 2 if n < 3 else 5 if n < 7 else 10) * p


def _num(v, default=None):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return f if ISF(f) else default


def pair(v, d):
    if isinstance(v, (list, tuple)) and len(v) >= 2:
        a, b = _num(v[0]), _num(v[1])
        if a is not None and b is not None and b > a:
            return [a, b]
    return list(d)


def rot_pt(p, th):
    if not th:
        return (p[0], p[1])
    c, s = cos(th), sin(th)
    return (p[0] * c - p[1] * s, p[0] * s + p[1] * c)


def inv_rot(p, th):
    c, s = cos(th), sin(th)
    return (p[0] * c + p[1] * s, -p[0] * s + p[1] * c)


# ---------------------------------------------------------------- 挂载
def mount_graph(W):
    L, c = W.L, W.c
    spec = W.view
    raw_mode = str(spec.get("mode") or "").lower()
    is_lab = not spec or spec.get("lab") is True or raw_mode == "lab"
    mode = "lab" if is_lab else raw_mode if raw_mode in GMODES else "trig"
    df = GMODES[mode]
    expr = "" if is_lab else str(spec.get("expr") or df["expr"] or "").replace("**", "^")
    xr0, yr0 = pair(spec.get("xr"), df["xr"]), pair(spec.get("yr"), df["yr"])
    cv = Cv(c)
    cv.set_range(xr0, yr0)

    params = []
    src_params = spec.get("params") if isinstance(spec.get("params"), list) and spec.get("params") else df["params"]
    for i, raw in enumerate(src_params):
        raw = raw or {}
        base = next((d for d in df["params"] if d["k"] == raw.get("k")), {})
        step = _num(raw.get("step"))
        step = step if step and step > 0 else base.get("step", 0.1)
        mn = _num(raw.get("min"), base.get("min", -5))
        mx = _num(raw.get("max"), base.get("max", 5))
        v = clamp(_num(raw.get("v"), base.get("v", 0)), mn, mx)
        k = str(raw.get("k") or base.get("k") or f"p{i}")
        params.append(dict(k=k, label=str(raw.get("label") or base.get("label") or f"参数 {k}"), min=mn, max=mx, step=step, v=v, dec=3 if step < 0.1 else 2 if step < 1 else 1, neutral=_num(raw.get("neutral")), ui=None))
    pmap = {p["k"]: p for p in params}
    S = {"theta": 0.0}
    for p in params:
        S[p["k"]] = p["v"]
    if is_lab and _num(spec.get("theta")) is not None:
        S["theta"] = clamp(math.radians(float(spec["theta"])), -PI, PI)
    st = dict(family=str(spec.get("family") or "sin") if is_lab else "sin", drag=None, ghost=None, note="", demo=None, vp=False, A=None, tip=None)
    if st["family"] not in FAMILIES:
        st["family"] = "sin"
    keys = [p["k"] for p in params if p["k"] not in ("x", "y", "t", "theta")]
    argv = ["x", "y", "t"] + keys + [n for n in ("PI", "E") if n not in keys]
    expr_error = None

    def build(src):
        return compile_expr(src, argv)
    try:
        raw_fn = build(expr) if expr else None
    except ExprError as exc:
        raw_fn, expr_error = None, str(exc)
    ghost_src = "" if is_lab else str(spec.get("ghost") if spec.get("ghost") else df["ghost"])
    try:
        ghost_fn = compile_expr(ghost_src.replace("**", "^")) if ghost_src else None
    except ExprError:
        ghost_fn = None

    def cur_fn():
        """当前参数下的 y = f(x)。"""
        if raw_fn is None:
            return lambda _x: math.nan
        vals = [S[k] for k in keys] + ([PI] if "PI" not in keys else []) + ([math.e] if "E" not in keys else [])

        def f(x):
            return raw_fn(x, 0, 0, *vals)
        return f

    def clamp_p(k, v):
        p = pmap.get(k)
        return clamp(v, p["min"], p["max"]) if p else v

    # ---- 曲线采样
    def sample(f, a, b, n):
        segs, seg, prev = [], [], None
        for i in range(n + 1):
            x = a + (b - a) * i / n
            y = f(x)
            if not ISF(y) or abs(y) > 1e7:
                if len(seg) > 1:
                    segs.append(seg)
                seg, prev = [], None
                continue
            Y = cv.py(y)
            if prev is not None and abs(Y - prev) > cv.h * 0.6:
                if len(seg) > 1:
                    segs.append(seg)
                seg = []
            seg.append((x, y))
            prev = Y
        if len(seg) > 1:
            segs.append(seg)
        return segs

    def conic_segs():
        A, B, H, K = max(0.05, abs(S["A"])), max(0.05, abs(S["B"])), S["H"], S["K"]
        far = max(abs(cv.xr[0] - H), abs(cv.xr[1] - H))
        tmax = min(3.4, max(1.2, math.acosh(max(1, far / A + 0.3))))
        right, left = [], []
        for i in range(241):
            t = -tmax + 2 * tmax * i / 240
            ch, sh = math.cosh(t), math.sinh(t)
            right.append((H + A * ch, K + B * sh))
            left.append((H - A * ch, K + B * sh))
        return [right, left]

    def vec_segs():
        u, v, r = (S["A"], S["H"]), (S["B"], S["K"]), (S["A"] + S["B"], S["H"] + S["K"])
        return [[(0, 0), u], [(0, 0), v], [(0, 0), r]]

    def lab_segs():
        th, name = S["theta"], st["family"]
        cc, ss = cos(th), sin(th)
        fam = FAMILIES[name]
        if fam[2] is None:
            base = [[(cos(i / 200 * TAU), sin(i / 200 * TAU)) for i in range(201)]]
        else:
            b = 0.05 if abs(S["B"]) < 0.05 else S["B"]
            t0, t1 = sorted(((cv.xr[0] - 6) / b, (cv.xr[1] + 6) / b))
            base = sample(fam[2], t0, t1, 800)
        return [[(cc * S["B"] * p[0] - ss * S["A"] * p[1] + S["H"], ss * S["B"] * p[0] + cc * S["A"] * p[1] + S["K"]) for p in seg] for seg in base]

    def cur_segs():
        if is_lab:
            return lab_segs()
        if mode == "conic" and not expr:
            return conic_segs()
        if mode == "vec" and not expr:
            return vec_segs()
        return sample(cur_fn(), cv.xr[0], cv.xr[1], max(400, min(1200, round(c.w * 1.1))))

    def rot_segs(segs, th):
        return segs if not th else [[rot_pt(p, th) for p in seg] for seg in segs]

    # ---- 画笔
    def lbl(x, y, s, size=10, color=None, weight=400, align="left"):
        plabel(cv, x, y, s, color or C.ink, size, weight=weight, align=align)

    def dot_(x, y, r, fill=None, stroke=None):
        D.circle(c.g, x, y, r, fill or C.ink, stroke, 1.4)

    def paint(segs, color=None, width=1.5, dash=None, alpha_=None):
        if not segs:
            return
        g = c.g
        path = QPainterPath()
        for seg in segs:
            if not seg:
                continue
            path.moveTo(cv.px(seg[0][0]), cv.py(seg[0][1]))
            for p in seg[1:]:
                path.lineTo(cv.px(p[0]), cv.py(p[1]))
        col = qc(color or C.ink)
        if alpha_ is not None:
            col = alpha(col, col.alphaF() * alpha_)
        pen = g._pen(col, width, dash or [])
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        g.p.strokePath(path, pen)

    def scr(p):
        return cv.px(p[0]), cv.py(p[1])

    def inside(X, Y, m=8):
        return -m < X < c.w + m and -m < Y < c.h + m

    # ---- 各部件
    def draw_axes():
        cv.grid(step_for(cv.xr[1] - cv.xr[0]), True)

    def draw_ref():
        if not ghost_fn:
            return
        segs = sample(ghost_fn, cv.xr[0], cv.xr[1], 500)
        paint(segs, C.data[2], 1.2, [4, 5], 0.55)
        for seg in segs:
            for p in reversed(seg):
                X, Y = scr(p)
                if c.w * 0.55 < X < c.w - 16 and 24 < Y < c.h - 42:
                    lbl(X + 6, Y - 9, "原函数", 9.5, C.data[2])
                    return

    def draw_guides():
        th = S["theta"]
        y0, y1 = cv.yr
        if is_lab or mode == "vec":
            return
        if mode == "poly" and "H" in S:
            paint([[rot_pt((S["H"], y0), th), rot_pt((S["H"], y1), th)]], C.grid2, 1, [3, 5])
        if mode == "conic" and not expr:
            A, B, H, K = max(0.05, abs(S["A"])), max(0.05, abs(S["B"])), S["H"], S["K"]
            m = B / A
            cc = sqrt(A * A + B * B)
            ln = max(abs(cv.xr[0]), abs(cv.xr[1])) + 4
            paint([[rot_pt((H - ln, K - m * ln), th), rot_pt((H + ln, K + m * ln), th)], [rot_pt((H - ln, K + m * ln), th), rot_pt((H + ln, K - m * ln), th)]], C.data[2], 1, [5, 5], 0.8)
            dx = A * A / cc
            paint([[rot_pt((H + dx, y0), th), rot_pt((H + dx, y1), th)], [rot_pt((H - dx, y0), th), rot_pt((H - dx, y1), th)]], C.ink2, 1, [2, 4], 0.55)
            la = scr(rot_pt((H + ln * 0.72, K + m * ln * 0.72), th))
            if inside(la[0], la[1], -6):
                lbl(la[0] - 12, la[1] - 10, "渐近线", 9, C.data[2], align="right")
            ld = scr(rot_pt((H + dx, y1), th))
            if inside(ld[0], ld[1], 0):
                lbl(ld[0] + 4, ld[1] + 12, "准线", 9, C.ink2)

    def draw_vectors(segs):
        if len(segs) < 3:
            return
        u, v, r = segs[0][1], segs[1][1], segs[2][1]
        paint([[u, r], [v, r]], C.data[3], 1, [3, 4])
        cv.arrow(0, 0, u[0], u[1], C.ink, 2, 9)
        cv.arrow(0, 0, v[0], v[1], C.ink2, 2, 9)
        cv.arrow(0, 0, r[0], r[1], C.accent, 1.7, 10)
        su, sv, sr = scr(u), scr(v), scr(r)
        dot_(su[0], su[1], 2.6, C.ink)
        dot_(sv[0], sv[1], 2.6, C.ink2)
        dot_(sr[0], sr[1], 3, C.accent)
        lbl(su[0] + 8, su[1] - 10, "u", 11, C.ink, 600)
        lbl(sv[0] + 8, sv[1] - 10, "v", 11, C.ink2, 600)
        lbl(sr[0] + 8, sr[1] + 14, "u + v", 10.5, C.accent, 600)
        dot_(cv.px(0), cv.py(0), 2.4, C.ink)

    def draw_marks():
        for m in spec.get("marks") if isinstance(spec.get("marks"), list) else []:
            m = m or {}
            mx, my = _num(m.get("x")), _num(m.get("y"))
            if mx is None or my is None:
                continue
            X, Y = scr(rot_pt((mx, my), S["theta"]))
            if inside(X, Y, 20):
                dot_(X, Y, 3.6, C.ink2, C.card)
                if m.get("label"):
                    lbl(X + 7, Y - 9, str(m["label"]), 9.5)

    def has(*ks):
        return all(k in S for k in ks)

    def draw_keys():
        th = S["theta"]
        if mode == "trig" and has("A", "B", "H", "K") and (not expr or re.fullmatch(r"A\*sin\(B\*x\+H\)\+K", expr)):
            B = 1e-6 if abs(S["B"]) < 1e-6 else S["B"]
            H, A, K = S["H"], S["A"], S["K"]
            xc = (cv.xr[0] + cv.xr[1]) / 2
            n0 = round((B * xc + H) / (PI / 2)) - 2
            zeros = []
            for j in range(5):
                n = n0 + j
                m = n % 4
                x = (n * PI / 2 - H) / B
                y, kind = K, "zero"
                if m == 1:
                    y, kind = K + A, "peak" if A >= 0 else "trough"
                if m == 3:
                    y, kind = K - A, "trough" if A >= 0 else "peak"
                X, Y = scr(rot_pt((x, y), th))
                if not inside(X, Y, 4):
                    continue
                if kind == "zero":
                    dot_(X, Y, 2.7, C.card, C.ink2)
                    zeros.append(x)
                else:
                    dot_(X, Y, 3.1, C.accent, C.card)
                    lbl(X, Y + (-13 if kind == "peak" else 15), "峰" if kind == "peak" else "谷", 9.5, C.accent, align="center")
            if abs(th) <= 1e-3 and len(zeros) >= 2:
                X1, X2 = cv.px(zeros[0]), cv.px(zeros[1])
                if X1 >= 4 and X2 <= c.w - 4 and X2 - X1 >= 18:
                    yb = c.h - 42
                    for a, b, e, f in ((X1, yb - 4, X1, yb + 4), (X2, yb - 4, X2, yb + 4), (X1, yb, X2, yb)):
                        D.line(c.g, a, b, e, f, C.ink2, 1)
                    lbl((X1 + X2) / 2, yb + 15, f"T = {pi_val(TAU / max(1e-6, abs(S['B'])))}", 9.5, C.faint, align="center")
        elif mode == "poly" and has("A", "B", "H", "K"):
            A, B, H, K = S["A"], S["B"], S["H"], S["K"]
            X, Y = scr(rot_pt((H, K), th))
            if inside(X, Y, 20):
                dot_(X, Y, 3.4, C.accent, C.card)
                lbl(X + 8, Y - 11, f"顶点 ({fxn(H)}, {fxn(K)})", 9.5)
            if abs(A) > 1e-6 and -K / A >= 0:
                d = abs(B) * sqrt(-K / A)
                for x in (H - d, H + d):
                    X, Y = scr(rot_pt((x, 0), th))
                    if inside(X, Y, 20):
                        dot_(X, Y, 2.8, C.card, C.ink2)
                        lbl(X, Y - 12, f"({fxn(x)}, 0)", 9, C.ink2, align="center")
        elif mode in ("conic", "piecewise") and has("H", "K"):
            X, Y = scr(rot_pt((S["H"], S["K"]), th))
            if inside(X, Y, 20):
                dot_(X, Y, 3.4, C.accent, C.card)
                lbl(X + 8, Y - 11, "中心" if mode == "conic" else f"拐点 ({fxn(S['H'])}, {fxn(S['K'])})", 9.5)

    def draw_handle():
        g, hx, hy = c.g, c.w - 38, c.h * 0.5
        D.circle(g, hx, hy, 20, C.card, C.accent, 1.4)
        stroke_arc(cv, hx, hy, 10.5, -2.55, 0.65, C.accent, 1.2)
        ea = 0.65
        D.poly(g, [(hx + cos(ea) * 13.4, hy + sin(ea) * 13.4), (hx + cos(ea - 0.62) * 6.4, hy + sin(ea - 0.62) * 6.4), (hx + cos(ea - 0.62) * 13.6, hy + sin(ea - 0.62) * 13.6)], C.accent)
        D.circle(g, hx, hy, 1.6, C.accent)
        lbl(hx, hy + 32, "旋转", 9.5, C.faint, align="center")
        to = S["theta"]
        if abs(to) > 1e-3:
            ox, oy = cv.px(0), cv.py(0)
            if inside(ox, oy, 0):
                r = min(82, max(42, min(c.w, c.h) * 0.17))
                g.begin_path()
                g.arc(ox, oy, r, 0, -to, to > 0)
                g.p.strokePath(g.path, g._pen(C.accent, 1.3, [3, 4]))
                e = -to
                ex, ey, dr = ox + cos(e) * r, oy + sin(e) * r, 1 if to > 0 else -1
                D.poly(g, [(ex, ey), (ex - 7 * cos(e - dr * 0.38), ey - 7 * sin(e - dr * 0.38)), (ex - 7 * cos(e + dr * 0.38), ey - 7 * sin(e + dr * 0.38))], C.accent)
                lbl(ox + cos(-to / 2) * (r + 16), oy + sin(-to / 2) * (r + 16), f"θ {num(abs(math.degrees(to)), 0)}°", 9, C.accent, align="center")

    def draw_ghost():
        gh = st["ghost"]
        if not gh:
            return
        if gh.get("segs"):
            paint(gh["segs"], C.accent, 1.3, [4, 5], 0.55)
        ar = gh.get("arrow")
        if ar:
            D.arrow(c.g, ar[0][0], ar[0][1], ar[1][0], ar[1][1], C.accent, 1.3, 8)
            lbl(ar[0][0] + 9, ar[0][1] - 11, "原曲线", 9, C.accent)

    def tag(x, y, text, color):
        tx = clamp(x + 7, 2, c.w - 56)
        ty = clamp(y - 7, 11, c.h - 4)
        w = D.measure(text, 10) + 6
        D.rect(c.g, tx - 3, ty - 8, w, 13, alpha(qc(C.card), 0.85))
        D.text(c.g, text, tx, ty - 1, color, size=10)

    def draw_markers():
        A = st["A"]
        if not A or is_lab:
            return
        g, f = c.g, cur_fn()
        if show["asym"]:
            for i, v in enumerate(A["vert"][:2]):
                X = cv.px(v)
                D.line(g, X, 0, X, c.h, alpha(qc(C.soft), 0.5), 1, [4, 4])
                if i == 0:
                    tag(X, 14, f"x ≈ {fmt_a(v)}", C.soft)
            for i, v in enumerate(A["horiz"][:2]):
                Y = cv.py(v)
                D.line(g, 0, Y, c.w, Y, alpha(qc(C.soft), 0.5), 1, [4, 4])
                if i == 0:
                    tag(c.w * 0.62, Y, f"y ≈ {fmt_a(v)}", C.soft)
        if show["zero"]:
            for i, v in enumerate(A["zeros"]):
                D.circle(g, cv.px(v), cv.py(0), 3.2, C.ink)
                if i < 2:
                    tag(cv.px(v), cv.py(0), f"零点 {fmt_a(v)}", C.ink)
        if show["ext"]:
            for lst, col, nm in ((A["maxs"], C.accent, "极大"), (A["mins"], C.ink2, "极小")):
                for i, v in enumerate(lst):
                    y = f(v)
                    if ISF(y):
                        D.circle(g, cv.px(v), cv.py(y), 5.2, None, col, 1.6)
                        if i < 1:
                            tag(cv.px(v), cv.py(y), f"{nm} ({fmt_a(v)}, {fmt_a(y)})", col)
        if show["inf"]:
            for i, v in enumerate(A["inflect"][:4]):
                y = f(v)
                if ISF(y):
                    X, Y = cv.px(v), cv.py(y)
                    D.poly(g, [(X, Y - 3.6), (X + 3.6, Y), (X, Y + 3.6), (X - 3.6, Y)], None, C.jade, 1.4)
                    if i < 1:
                        tag(X, Y, f"拐点 {fmt_a(v)}", C.jade)

    def render(_w, _h):
        if c.w < 40 or c.h < 40:
            return
        draw_axes()
        draw_ref()
        draw_guides()
        pre = cur_segs()
        rotated = pre if is_lab else rot_segs(pre, S["theta"])
        if mode == "vec" and not is_lab and not expr:
            draw_vectors(rotated)
        else:
            paint(rotated, C.ink, 2.2)
        if not is_lab:
            draw_keys()
        draw_marks()
        draw_ghost()
        draw_markers()
        draw_handle()

    # ---- 公式
    def subst_display():
        s = expr
        for k in keys:
            v = S[k]
            if not ISF(v):
                continue
            s = re.sub(rf"\b{re.escape(k)}\b", f"({fxn(v)})" if v < 0 else fxn(v), s)
        s = re.sub(r"(\d)\*([a-zA-Z(√])", r"\1\2", s)
        s = re.sub(r"\b1\(", "(", s)
        s = s.replace("/1)", ")")
        s = re.sub(r"\+\([−-]([\d.]+)\)", r" − \1", s)
        s = re.sub(r"[−-]\([−-]([\d.]+)\)", r"+ \1", s)
        s = re.sub(r"\+0(?![\d.])", "", s)
        s = re.sub(r"\(\(([^()]*)\)\)", r"(\1)", s)
        s = re.sub(r"([0-9a-zA-Z)])[−-]([0-9a-zA-Z(])", r"\1−\2", s)
        s = re.sub(r"^[−-]", "−", s)
        return s

    def eq_text():
        if is_lab:
            fam = FAMILIES[st["family"]]
            return "p(t) = M·(cos t, sin t) + T" if fam[2] is None else f"p(t) = M·(t, {fam[1]}) + T"
        if expr:
            return "y = " + subst_display()
        A, B, H, K = S.get("A", 1), S.get("B", 1), S.get("H", 0), S.get("K", 0)
        if mode == "conic":
            nx = "x^2" if near(H, 0) else f"(x{term(-H, fxn, True)})^2"
            ny = "y^2" if near(K, 0) else f"(y{term(-K, fxn, True)})^2"
            return f"\\frac{{{nx}}}{{{fxn(abs(A))}^2}} − \\frac{{{ny}}}{{{fxn(abs(B))}^2}} = 1"
        if mode == "vec":
            return f"u = ({fxn(A)}, {fxn(H)})，v = ({fxn(B)}, {fxn(K)})，u + v = ({fxn(A + B)}, {fxn(H + K)})"
        return ""

    def matrix_info():
        cc, ss = cos(S["theta"]), sin(S["theta"])
        if is_lab:
            return "变换矩阵 M", cc * S["B"], -ss * S["A"], ss * S["B"], cc * S["A"], True
        if mode == "vec" and has("A", "B", "H", "K"):
            return "向量矩阵 R·M", cc * S["A"] - ss * S["H"], cc * S["B"] - ss * S["K"], ss * S["A"] + cc * S["H"], ss * S["B"] + cc * S["K"], False
        return "旋转矩阵 R", cc, -ss, ss, cc, False

    # 画布左上的公式卡、右上的矩阵卡：普通 QLabel 浮在画布上（鼠标穿透）
    stage = L.stage
    eq_box = QLabel(stage)
    mat_box = QLabel(stage)
    for b in (eq_box, mat_box):
        b.setTextFormat(Qt.TextFormat.RichText)
        b.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        b.show()
    eq_box.setWordWrap(True)

    def card_style():
        return f"background:{alpha(qc(C.card), 0.88).name(qc(C.card).NameFormat.HexArgb)};border:1px solid {qc(C.line).name()};border-radius:6px;padding:5px 9px;"

    def place_overlays():
        sw, sh = stage.width(), stage.height()   # 画布的 c.w 要到绘制时才更新，这里以控件尺寸为准
        eq_box.setFixedWidth(int(min(max(220, sw * 0.56), 560)))
        eq_box.adjustSize()
        eq_box.move(10, 10)
        mat_box.adjustSize()
        mat_box.move(int(sw - mat_box.width() - 10), 10)
        pad.adjustSize()
        pad.move(int(sw - pad.width() - 10), int(sh - pad.height() - 10))

    # ---- 视野按钮（浮在右下）
    def mini_css():
        return f"QPushButton#mini{{padding:0 6px;min-width:0;border:1px solid {qc(C.line2).name()};border-radius:4px;background:{qc(C.card).name()};color:{qc(C.soft).name()};}}QPushButton#mini:hover{{color:{qc(C.ink).name()};}}QPushButton#mini:checked{{background:{qc(T.accent).name()};color:{qc(C.card).name()};}}"
    pad = QWidget(stage)
    ph = QHBoxLayout(pad)
    ph.setContentsMargins(0, 0, 0, 0)
    ph.setSpacing(3)

    def view_shift(fx_, fy_):
        dx, dy = (cv.xr[1] - cv.xr[0]) * fx_, (cv.yr[1] - cv.yr[0]) * fy_
        cv.set_range([cv.xr[0] + dx, cv.xr[1] + dx], [cv.yr[0] + dy, cv.yr[1] + dy])
        recompute_now()

    def view_zoom(k):
        cx, cy = sum(cv.xr) / 2, sum(cv.yr) / 2
        hw, hh = (cv.xr[1] - cv.xr[0]) / 2 * k, (cv.yr[1] - cv.yr[0]) / 2 * k
        cv.set_range([cx - hw, cx + hw], [cy - hh, cy + hh])
        recompute_now()

    def view_home():
        cv.set_range(xr0, yr0)
        recompute_now()
    for text, tip, fn, rep in (("←", "视野左移", lambda: view_shift(-0.22, 0), True), ("↑", "视野上移", lambda: view_shift(0, 0.22), True), ("↓", "视野下移", lambda: view_shift(0, -0.22), True), ("→", "视野右移", lambda: view_shift(0.22, 0), True),
                               ("＋", "视野放大", lambda: view_zoom(1 / 1.22), True), ("－", "视野缩小", lambda: view_zoom(1.22), True), ("原", "回到初始视野", view_home, False)):
        b = QPushButton(text)
        b.setObjectName("mini")
        b.setFixedSize(26, 24)
        b.setStyleSheet(mini_css())
        b.setToolTip(tip)
        b.setAutoRepeat(rep)
        b.setAutoRepeatDelay(400)
        b.setAutoRepeatInterval(120)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.clicked.connect(lambda _c=False, f=fn: f())
        ph.addWidget(b)
    vp_btn = QPushButton("拖视野")
    vp_btn.setObjectName("mini")
    vp_btn.setStyleSheet(mini_css())
    vp_btn.setFixedHeight(24)
    vp_btn.setCheckable(True)
    vp_btn.setToolTip("开启后按住拖动＝平移视野")
    vp_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    vp_btn.toggled.connect(lambda on: st.update(vp=on))
    ph.addWidget(vp_btn)
    pad.show()

    # ---- 检查器
    show = {"zero": True, "ext": True, "inf": True, "asym": True}
    show.update(load_json("graphplus.json", {}).get("show", {}) if isinstance(load_json("graphplus.json", {}), dict) else {})
    if is_lab:
        L.select("函数族", [[k, v[0]] for k, v in FAMILIES.items()], st["family"], lambda v: (st.update(family=v, ghost=None), update_text(), W.redraw()))
    if is_lab or spec.get("preset"):
        names = [it for _g, items in LAB_PRESETS for it in items]

        def pick(v):
            it = next((x for x in names if x[0] == v), None)
            if it and getattr(L, "open_question", None):
                QTimer.singleShot(0, lambda: L.open_question(preset_question(it)))
        W.sec("按知识块选择")
        L.select("换成", [["", "选一个知识块…"]] + [[it[0], f"{g} · {it[0]}"] for g, items in LAB_PRESETS for it in items], (W.q.get("title") if spec.get("preset") else ""), pick)
    W.sec("演示")
    chip = W.chips(["平移", "伸缩", "旋转"], "平移", lambda n: demo(n))

    def mark(name):
        try:
            chip.set(name, silent=True)
        except TypeError:
            pass
    W.sec("参数")

    def on_slider(k, v):
        stop_demo(True)
        S[k] = v
        update_text()
        W.redraw()
        schedule()
    for p in params:
        p["ui"] = L.slider(p["label"], p["min"], p["max"], p["step"], S[p["k"]], lambda v, k=p["k"]: on_slider(k, v), "", p["dec"])
    # 不靠滚轮也能调（触屏、希沃白板）：按住连续生效
    W.sec("微调")
    grid = QWidget()
    gv = QVBoxLayout(grid)
    gv.setContentsMargins(0, 0, 0, 0)
    gv.setSpacing(3)
    rows_ = [[("横缩", lambda: nudge("B", 1 / 1.1)), ("横放", lambda: nudge("B", 1.1)), ("纵缩", lambda: nudge("A", 1 / 1.1)), ("纵放", lambda: nudge("A", 1.1))],
             [("左转", lambda: rot_by(-15)), ("右转", lambda: rot_by(15))]]
    for r in rows_:
        rw = QWidget()
        rh = QHBoxLayout(rw)
        rh.setContentsMargins(0, 0, 0, 0)
        rh.setSpacing(3)
        for text, fn in r:
            b = QPushButton(text)
            b.setAutoRepeat(True)
            b.setAutoRepeatDelay(400)
            b.setAutoRepeatInterval(90)
            b.clicked.connect(lambda _c=False, f=fn: f())
            rh.addWidget(b)
        gv.addWidget(rw)
    L._add(grid)
    L.button("复位", lambda _b: do_reset())
    kv1 = W.kv("—")
    kv2 = W.kv("—")
    kv1_key = kv1.label.parent().findChild(QLabel)
    kv2_key = kv2.label.parent().findChild(QLabel)
    W.sec("手势")
    L.note(df["legend"])
    # 函数性质
    prop = {}
    if not is_lab:
        W.sec("函数性质（按当前视野实算）")
        for k in ("零点", "极值", "驻点", "拐点", "渐近线", "单调", "奇偶", "周期", "值域"):
            prop[k] = W.kv(k)
        W.sec("图上标记")
        for k, nm in (("zero", "零点"), ("ext", "极值 · 驻点"), ("inf", "拐点"), ("asym", "渐近线")):
            def on_show(v, k=k):
                show[k] = bool(v)
                save_json("graphplus.json", {"show": show})
                W.redraw()
            W.toggle(nm, show[k], on_show)
        W.sec("自定义函数")
        inp = L.input("y =", "", lambda _v: None, ph="如 2*sin(x)+1")
        err = L.note("支持 sin cos tan sqrt abs ln exp ^ π 与字母 A B H K")

        def apply_custom(_b=None):
            raw = str(inp.v or "").strip()
            if not raw:
                err.setText("先写一个函数")
                return
            e = re.sub(r"\s+", "", raw.replace("²", "^2").replace("³", "^3").replace("−", "-").replace("–", "-"))
            used = sorted(set(re.findall(r"\b[ABHK]\b", e)))
            try:
                pf = compile_expr(e, ["x"] + used)
            except ExprError as exc:
                err.setText(f"写法有问题：{exc}")
                return
            if not ISF(pf(0.7, *[1] * len(used))) and not ISF(pf(2.1, *[1] * len(used))):
                err.setText("这个式子算不出值，检查写法")
                return
            lb = dict(A="纵向 A", B="横向 B", H="横移 H", K="纵移 K")
            dv = dict(A=1, B=1, H=0, K=0)
            ps = [dict(k=k, label=lb[k], min=-6 if k in "HK" else 0.2, max=6 if k in "HK" else 4, step=0.1, v=dv[k]) for k in used] or [dict(k="A", label="纵向 A", min=0.2, max=4, step=0.1, v=1)]
            q = dict(id="custom-fn", subject="数学", year=None, title="自定义函数", stem=f"y = {raw}", answer="", steps=["写出解析式", "看性质", "看图象"], points=["自定义函数"],
                     view=dict(engine="graph", mode="trig" if re.search("sin|cos|tan", e) else "poly", expr=e, params=ps, xr=list(cv.xr), yr=list(cv.yr), call="拖动曲线平移 · 滚轮伸缩 · 下方按钮微调"))
            if getattr(L, "open_question", None):
                QTimer.singleShot(0, lambda: L.open_question(q))
        L.button("应用", apply_custom, True)

    def render_stats():
        def put(a, va, b, vb):
            kv1_key.setText(a)
            kv1.text(va)
            kv2_key.setText(b)
            kv2.text(vb)
        H, K = S.get("H", 0), S.get("K", 0)
        A_, B_ = S.get("A", 1), S.get("B", 1)
        if is_lab:
            put("det M", fxn(A_ * B_), "平移 T", f"({fxn(H)}, {fxn(K)})")
        elif mode == "trig":
            a = st["A"]
            if expr and a:
                put("周期 T", fxn(a["period"], 2) if a["period"] else pi_val(TAU / max(1e-6, abs(B_))), "振幅", fxn((a["range"][1] - a["range"][0]) / 2, 2) if a["range"] else "—")
            else:
                put("周期 T", pi_val(TAU / max(1e-6, abs(B_))), "横移", pi_val(-H / (1e-6 if abs(B_) < 1e-6 else B_)))
        elif mode == "poly":
            v = quad_vertex() if expr else None
            put("顶点", f"({fxn(v[0], 2)}, {fxn(v[1], 2)})" if v else f"({fxn(H)}, {fxn(K)})", "开口", ("向上" if v[2] else "向下") if v else ("向上" if A_ >= 0 else "向下"))
        elif mode == "piecewise":
            put("拐点", f"({fxn(H)}, {fxn(K)})", "两段斜率", f"±{fxn(abs(A_ * B_))}")
        elif mode == "conic":
            put("中心", f"({fxn(H)}, {fxn(K)})", "离心率 e", fxn(sqrt(A_ * A_ + B_ * B_) / max(1e-6, abs(A_))))
        else:
            put("合成 u + v", f"({fxn(A_ + B_)}, {fxn(H + K)})", "模长", fxn(math.hypot(A_ + B_, H + K)))

    def quad_vertex():
        """三点定二次：顶点由 expr 实算，不照抄画布里的 H / K。"""
        f = cur_fn()
        a, b = cv.xr
        xs = [a + (b - a) * i / 12 for i in (3, 6, 9)]
        x1, x2, x3 = xs
        y1, y2, y3 = [f(x) for x in xs]
        if not (ISF(y1) and ISF(y2) and ISF(y3)):
            return None
        den = (x1 - x2) * (x1 - x3) * (x2 - x3)
        if abs(den) < 1e-12:
            return None
        A = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / den
        B = (x3 * x3 * (y1 - y2) + x2 * x2 * (y3 - y1) + x1 * x1 * (y2 - y3)) / den
        Cc = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + x1 * x2 * (x1 - x2) * y3) / den
        if abs(A) < 1e-7:
            return None
        return (-B / (2 * A), Cc - B * B / (4 * A), A > 0)

    def update_text():
        fgc, softc = qc(T.fg).name(), qc(T.muted).name()
        call = st["note"] or (str(spec["call"]) if spec.get("call") else ("选函数族，拖曲线平移，滚轮伸缩，拖右环旋转。" if is_lab else df.get("call", "")))
        head = "函数族" if is_lab else df["name"]
        if expr_error:
            call = f"解析式有问题：{expr_error}"
        eq_box.setStyleSheet(card_style())
        mat_box.setStyleSheet(card_style())
        eq_box.setText(f"<div style='color:{softc};font-size:11px'>{head}</div><div style='color:{fgc};font-size:15px;font-weight:600'>{fx(eq_text())}</div><div style='color:{qc(T.accent if st['note'] else T.muted).name()};font-size:11.5px'>{call}</div>")
        kick, a, b, cc, d, tr = matrix_info()
        deg = round(math.degrees(S["theta"]))
        mono = "font-family:Consolas,monospace"
        mat_box.setText(f"<div style='color:{softc};font-size:10.5px'>{kick}　θ {'−' + str(abs(deg)) if deg < 0 else deg}°</div><div style='color:{fgc};font-size:11.5px;{mono}'>[{n2(a)}, {n2(b)}]<br>[{n2(cc)}, {n2(d)}]</div>" + (f"<div style='color:{softc};font-size:10.5px'>T = ({fxn(S['H'])}, {fxn(S['K'])})</div>" if tr else ""))
        render_stats()
        place_overlays()

    def sync_sliders():
        for p in params:
            p["ui"].set(S[p["k"]], silent=True)

    def sync_all():
        sync_sliders()
        update_text()
        W.redraw()
        schedule()

    # ---- 性质分析（防抖）
    timer = QTimer(stage)
    timer.setSingleShot(True)
    timer.setInterval(70)
    L.timers.append(timer)   # 换题时一起停掉，免得给已删除的面板写读数

    def recompute_now():
        if is_lab or raw_fn is None:
            W.redraw()
            return
        st["A"] = analyze(cur_fn(), cv.xr, cv.yr)
        render_rows(st["A"])
        render_stats()
        W.redraw()
    timer.timeout.connect(recompute_now)

    def schedule():
        if not is_lab:
            timer.start()

    def render_rows(A):
        f = cur_fn()
        F = fmt_a
        z = "，".join(F(v) for v in A["zeros"][:3]) + (f" 等 {len(A['zeros'])} 个" if len(A["zeros"]) > 3 else "")
        prop["零点"].text(z or "无")
        ext = [f"极大 ({F(v)}, {F(f(v))})" for v in A["maxs"][:2]] + [f"极小 ({F(v)}, {F(f(v))})" for v in A["mins"][:2]]
        prop["极值"].text("；".join(ext) or "无")
        prop["驻点"].text("，".join(F(v) for v in A["stat"][:3]) or "无")
        prop["拐点"].text("，".join(f"({F(v)}, {F(f(v))})" for v in A["inflect"][:3]) or "无")
        asym = [f"x ≈ {F(v)}" for v in A["vert"][:2]] + [f"y ≈ {F(v)}" for v in A["horiz"][:2]]
        prop["渐近线"].text("；".join(asym) or "无")
        prop["单调"].text(" ".join(f"{'增' if m[2] > 0 else '减'}({F(m[0], 1)},{F(m[1], 1)})" for m in A["mono"][:4]) or "—")
        prop["奇偶"].text(A["parity"])
        prop["周期"].text(F(A["period"]) if A["period"] else "非周期/未检出")
        prop["值域"].text(f"[{F(A['range'][0])}, {F(A['range'][1])}]" if A["range"] else "—")

    # ---- 演示动画
    demo_t = QTimer(stage)
    demo_t.setInterval(16)
    L.timers.append(demo_t)

    def stop_demo(restore):
        demo_t.stop()
        base = st["demo"]
        st["demo"] = None
        if restore and base:
            S.update(base[1])
            sync_all()

    def demo(name):
        stop_demo(True)
        st["demo"] = (name, dict(S), time.perf_counter())
        demo_t.start()

    def demo_frame():
        if not st["demo"]:
            demo_t.stop()
            return
        name, base, t0 = st["demo"]
        t = min(1, (time.perf_counter() - t0) / 0.56)
        w = sin(PI * t)
        if name == "平移":
            if "H" in base:
                S["H"] = clamp_p("H", base["H"] + (-0.85 if mode == "trig" else 0.85) * w)
            if "K" in base:
                S["K"] = clamp_p("K", base["K"] + 0.55 * w)
        elif name == "伸缩":
            if "B" in base:
                S["B"] = clamp_p("B", base["B"] * (1 + 0.45 * w))
            if "A" in base:
                S["A"] = clamp_p("A", base["A"] * (1 + 0.32 * w))
        else:
            S["theta"] = clamp(base["theta"] + math.radians(30) * w, -PI, PI)
        sync_sliders()
        update_text()
        W.redraw()
        if t >= 1:
            demo_t.stop()
            st["demo"] = None
            schedule()
    demo_t.timeout.connect(demo_frame)

    # ---- 拖动映射
    def probe_ratio(letter):
        """拖曲线时 H / K 要动多少：由 expr 数值求导，表达式写法不同也能跟手。"""
        if raw_fn is None or letter not in keys:
            return None
        idx = keys.index(letter)
        extra = ([PI] if "PI" not in keys else []) + ([math.e] if "E" not in keys else [])

        def ev(x, val):
            vals = [S[k] for k in keys]
            vals[idx] = val
            return raw_fn(x, 0, 0, *vals, *extra)
        h = 1e-3
        v0 = S[letter]
        if letter == "K":
            fk = (ev(0.8, v0 + h) - ev(0.8, v0 - h)) / (2 * h)
            return clamp(1 / fk, -20, 20) if ISF(fk) and abs(fk) >= 1e-6 else None
        bx, bd = 0, 0
        for x in (0.4, 1.1, 1.9, 2.7):
            fh = (ev(x, v0 + h) - ev(x, v0 - h)) / (2 * h)
            if ISF(fh) and abs(fh) > abs(bd):
                bd, bx = fh, x
        if not bx or abs(bd) < 1e-6:
            return None
        fx_ = (ev(bx + h, v0) - ev(bx - h, v0)) / (2 * h)
        return clamp(-fx_ / bd, -20, 20) if ISF(fx_) else None

    def shift_coefs():
        if is_lab or (mode == "conic" and not expr):
            return 1, 1
        if mode == "vec" and not expr:
            return 1, 1
        ch = (probe_ratio("H") or 1) if re.search(r"\bH\b", expr) else 0
        ck = (probe_ratio("K") or 1) if re.search(r"\bK\b", expr) else 0
        return ch, ck

    def near_handle(x, y):
        return (x - (c.w - 38)) ** 2 + (y - c.h * 0.5) ** 2 <= 32 * 32

    def ptr_angle(x, y):
        return atan2(-(y - cv.py(0)), x - cv.px(0))

    def hit(x, y):
        return "rot" if near_handle(x, y) else "vp" if st["vp"] else "vec" if (mode == "vec" and not is_lab and not expr) else "pan"

    def down(x, y, cur):
        stop_demo(True)
        now = rot_segs(cur_segs(), 0 if is_lab else S["theta"])
        if cur == "rot":
            st["drag"] = dict(theta0=S["theta"], ang0=ptr_angle(x, y))
            st["ghost"] = dict(segs=now)
            mark("旋转")
        elif cur == "vp":
            st["drag"] = dict(xr=list(cv.xr), yr=list(cv.yr), x=x, y=y)
        elif cur == "vec":
            u, v = rot_pt((S["A"], S["H"]), S["theta"]), rot_pt((S["B"], S["K"]), S["theta"])
            which = "u" if math.hypot(cv.px(u[0]) - x, cv.py(u[1]) - y) <= math.hypot(cv.px(v[0]) - x, cv.py(v[1]) - y) else "v"
            st["drag"] = dict(which=which, A0=S["A"], H0=S["H"], B0=S["B"], K0=S["K"], ax=0, ay=0)
            st["ghost"] = dict(segs=now, arrow=(scr(u if which == "u" else v),) * 2)
            mark("平移")
        else:
            best, bd = None, 1e18
            for seg in now:
                for p in seg[::2]:
                    d = (cv.px(p[0]) - x) ** 2 + (cv.py(p[1]) - y) ** 2
                    if d < bd:
                        bd, best = d, p
            base = best or (cv.dx(x), cv.dy(y))
            ch, ck = shift_coefs()
            st["drag"] = dict(theta=S["theta"], H0=S.get("H", 0), K0=S.get("K", 0), cH=ch, cK=ck, anchor=base if is_lab else inv_rot(base, S["theta"]), ax=0, ay=0)
            st["ghost"] = dict(segs=now)
            mark("平移")

    def drag(cur, x, y, dx, dy):
        d = st["drag"]
        if not d:
            return
        if cur == "rot":
            diff = ptr_angle(x, y) - d["ang0"]
            S["theta"] = clamp(d["theta0"] + atan2(sin(diff), cos(diff)), -PI, PI)
            update_text()
        elif cur == "vp":
            mx = -(x - d["x"]) / c.w * (d["xr"][1] - d["xr"][0])
            my = (y - d["y"]) / c.h * (d["yr"][1] - d["yr"][0])
            cv.set_range([d["xr"][0] + mx, d["xr"][1] + mx], [d["yr"][0] + my, d["yr"][1] + my])
            schedule()
        elif cur == "vec":
            d["ax"] += dx
            d["ay"] += dy
            mx, my = d["ax"] / c.w * (cv.xr[1] - cv.xr[0]), -d["ay"] / c.h * (cv.yr[1] - cv.yr[0])
            if d["which"] == "u":
                S["A"], S["H"] = clamp_p("A", d["A0"] + mx), clamp_p("H", d["H0"] + my)
            else:
                S["B"], S["K"] = clamp_p("B", d["B0"] + mx), clamp_p("K", d["K0"] + my)
            tipp = rot_pt((S["A"], S["H"]) if d["which"] == "u" else (S["B"], S["K"]), S["theta"])
            st["ghost"]["arrow"] = (st["ghost"]["arrow"][0], scr(tipp))
            sync_sliders()
            update_text()
        else:
            d["ax"] += dx
            d["ay"] += dy
            mx, my = d["ax"] / c.w * (cv.xr[1] - cv.xr[0]), -d["ay"] / c.h * (cv.yr[1] - cv.yr[0])
            if d["cH"] and "H" in S:
                S["H"] = clamp_p("H", d["H0"] + d["cH"] * mx)
            if d["cK"] and "K" in S:
                S["K"] = clamp_p("K", d["K0"] + d["cK"] * my)
            adx = (S["H"] - d["H0"]) / d["cH"] if d["cH"] and "H" in S else 0
            ady = (S["K"] - d["K0"]) / d["cK"] if d["cK"] and "K" in S else 0
            a = d["anchor"]
            b = (a[0] + adx, a[1] + ady)
            if is_lab:
                st["ghost"]["arrow"] = (scr(a), scr(b))
            else:
                st["ghost"]["arrow"] = (scr(rot_pt(a, d["theta"])), scr(rot_pt(b, d["theta"])))
            sync_sliders()
            update_text()
        schedule()

    def up(_cur):
        st["drag"] = None
        st["ghost"] = None
        schedule()

    def wheel(x, y, steps):
        stop_demo(True)
        shift = bool(QApplication.keyboardModifiers() & Qt.KeyboardModifier.ShiftModifier)
        key = "A" if shift else "B"
        if key not in pmap:
            return False
        S[key] = clamp_p(key, S[key] * math.exp(steps * 0.16))
        sync_all()
        mark("伸缩")
        return True
    L.interact(c, hit=hit, down=down, drag=drag, up=up, wheel=wheel)

    def nudge(k, f):
        if k in pmap:
            stop_demo(True)
            S[k] = clamp_p(k, S[k] * f)
            sync_all()
            mark("伸缩")

    def rot_by(deg):
        stop_demo(True)
        S["theta"] = clamp(S["theta"] + math.radians(deg), -PI, PI)
        update_text()
        W.redraw()
        mark("旋转")

    # ---- 步骤
    def neutral_for(k):
        p = pmap.get(k)
        if p and p["neutral"] is not None:
            return p["neutral"]
        if k in df["neutral"]:
            return clamp(df["neutral"][k], p["min"], p["max"]) if p else df["neutral"][k]
        if p:
            if p["min"] <= 0 <= p["max"]:
                return 0
            return max(p["min"], 1) if p["min"] > 0 else p["max"]
        return 0

    def norm_step(s):
        if not isinstance(s, dict):
            return None
        op = str(s.get("op") or s.get("type") or "").lower()
        op = {"平移": "shift", "translate": "shift", "pan": "shift", "伸缩": "scale", "stretch": "scale", "旋转": "rotate", "rot": "rotate", "参数": "param"}.get(op, op)
        axis = str(s.get("axis") or "").lower()
        axis = {"横": "x", "水平": "x", "纵": "y", "竖直": "y"}.get(axis, axis)
        v = s.get("v", s.get("value"))
        if op == "param" and not s.get("k"):
            return None
        if op not in ("shift", "scale", "rotate", "param"):
            return None
        return dict(op=op, k=str(s.get("k") or ""), axis=axis, v=v, note=s.get("note") or "")
    vsteps = [n for n in (norm_step(s) for s in (spec.get("steps") or [])) if n] if isinstance(spec.get("steps"), list) else []
    if not vsteps:
        vsteps = [dict(op="param", k=p["k"], axis="", v=p["v"], note=f"{p['label']} = {num(p['v'], p['dec'])}") for p in params]

    def apply_one(s):
        v = _num(s["v"])
        if v is None:
            return
        if s["op"] == "param":
            if s["k"] in S:
                S[s["k"]] = clamp_p(s["k"], v)
        elif s["op"] == "shift":
            for k, ax in (("H", "x"), ("K", "y")):
                if k in S and s["axis"] in (ax, ""):
                    S[k] = clamp_p(k, v)
        elif s["op"] == "scale":
            for k, ax in (("B", "x"), ("A", "y")):
                if k in S and s["axis"] in (ax, ""):
                    S[k] = clamp_p(k, v)
        else:
            S["theta"] = clamp(math.radians(v), -PI, PI)

    def describe(s):
        if s["note"]:
            return s["note"]
        v = _num(s["v"], 0)
        if s["op"] == "param":
            p = pmap.get(s["k"])
            return f"{p['label'] if p else s['k']} = {num(v, 2)}"
        if s["op"] == "shift":
            return {"x": f"横向平移 H = {fxn(v)}", "y": f"纵向平移 K = {fxn(v)}"}.get(s["axis"], f"平移 {fxn(v)}")
        if s["op"] == "scale":
            return {"x": f"横向伸缩 B = {fxn(v)}", "y": f"纵向伸缩 A = {fxn(v)}"}.get(s["axis"], f"伸缩 {fxn(v)}")
        return f"旋转 {fxn(v)}°"

    def apply_step(i):
        stop_demo(False)
        st["ghost"] = st["drag"] = None
        n = max(0, min(len(vsteps), int(i or 0)))
        for p in params:
            S[p["k"]] = clamp(neutral_for(p["k"]), p["min"], p["max"])
        S["theta"] = 0.0
        note = ""
        for s in vsteps[:n]:
            apply_one(s)
            note = describe(s)
        W.step = n
        st["note"] = "第一步：原始函数，还没做变换" if n == 0 else f"第 {n} 步 · {note}"
        sync_all()
        mark("平移")
    W.apply_step = apply_step

    def do_reset():
        stop_demo(False)
        st["ghost"] = st["drag"] = None
        st["note"] = ""
        S["theta"] = 0.0
        for p in params:
            S[p["k"]] = p["v"]
        sync_all()
        mark("平移")

    def focus(i):
        """引导层：当前步骤在画布上的聚焦位置。"""
        if raw_fn is None:
            return None
        A = st["A"]
        f = cur_fn()
        if not A:
            return None
        if i == 0:
            cand = A["maxs"] + A["mins"]
            x = cand[0] if cand else None
        elif i - 1 < len(A["zeros"]):
            x = A["zeros"][i - 1]
        else:
            x = None
        if x is None:
            x = cv.xr[0] + (cv.xr[1] - cv.xr[0]) * (0.25 + 0.5 * min(1, max(0, i - 1) / 4))
        y = f(x)
        return dict(x=cv.px(x), y=cv.py(y), r=24) if ISF(y) else None
    W.focus = focus
    W.set(render)
    W.graph_state = S
    stage.resize_fn = place_overlays   # 浮层只在尺寸或文字变化时挪，别在绘制途中动控件
    update_text()
    W.redraw()
    schedule()
    _ = (kv1_key, kv2_key, QPointF)
