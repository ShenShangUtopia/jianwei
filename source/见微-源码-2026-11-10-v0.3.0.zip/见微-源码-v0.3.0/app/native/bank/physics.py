"""physics 引擎：把一个 Scene 挂到题目视图上。时间轴、状态、读数、参数面板都在这里，场景只管画。"""
from __future__ import annotations

import math
from types import SimpleNamespace

from PySide6.QtCore import QRectF, Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QWidget

from ..design.tokens import T, family, qc
from ..kit.core import clamp
from ..kit.draw import D
from . import ph_core, ph_scenes1, ph_scenes2, ph_scenes3  # noqa: F401  注册场景
from .ph_core import SCENES, Cv, fmt
from .sb_core import C

TL_H = 26   # 画布底部时间轴的高度


def apply_params(sc, src):
    """题目参数注入场景；落在滑块量程外时向两侧扩量程，留出调节余量。"""
    P = sc.P
    for k in vars(P):
        v = src.get(k)
        if isinstance(v, (int, float)) and math.isfinite(v):
            setattr(P, k, float(v))
    sc.aux(src)
    for s in sc.sliders:
        k, _lb, mn, mx = s[0], s[1], s[2], s[3]
        v = getattr(P, k, mn)
        if not isinstance(v, (int, float)) or not math.isfinite(v):
            v = mn
            setattr(P, k, v)
        if v < mn:
            s[2] = v * 0.6 if v >= 0 else v * 1.6
        if v > mx:
            s[3] = v * 1.6 if v >= 0 else v * 0.6
        if not s[3] > s[2]:
            s[2], s[3] = v - 1, v + 1
    if getattr(P, "g", None):
        P.g = clamp(P.g, 1, 20)


class _Row:
    """一行读数：标签、数值、单位，都可能随帧变化。"""

    def __init__(self, L):
        self.box = QWidget()
        h = QHBoxLayout(self.box)
        h.setContentsMargins(4, 2, 4, 2)
        h.setSpacing(6)
        self.a, self.b, self.u = QLabel(), QLabel(), QLabel()
        self.a.setObjectName("ctlLabel")
        self.u.setObjectName("ctlLabel")
        self.b.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        h.addWidget(self.a, 0)
        h.addWidget(self.b, 1)
        h.addWidget(self.u, 0)
        L._add(self.box)
        self.last, self.hot = None, None

    def set(self, label, value, unit):
        cur = (label, value, unit)
        if cur != self.last:
            self.last = cur
            self.a.setText(label)
            self.b.setText(str(value))
            self.u.setText(unit or "")

    def set_hot(self, on):
        if on == self.hot:
            return
        self.hot = on
        col = qc(T.accent if on else T.fg).name()
        self.b.setStyleSheet(f"color:{col};font-weight:{700 if on else 500};font-family:'{family('num')}';")


def mount_physics(W):
    L, c = W.L, W.c
    view = W.view
    kind = view.get("kind") if view.get("kind") in SCENES else "projectile"
    sc = SCENES[kind]()
    sc.kind = kind
    apply_params(sc, view.get("params") or {})
    cv = Cv(c)
    lesson = bool(view.get("lesson"))   # 析题页一步一步讲：由页面给每一步设时刻、讲到的量
    sc.frozen = lesson                  # 讲题时不让场景自己扫参数（透镜物距来回变），画面就是题目的条件
    st = SimpleNamespace(t=0.0, T=4.0, lv=0, playing=not lesson, speed=1.0, was=False, drag=False, focus=set(), stop_at=None, ghost=None)
    W.on_change = None                  # 讲题页挂上：拖动条件后重算讲解

    def changed():
        if lesson and W.on_change:
            W.on_change()

    def dur():
        d = sc.duration()
        return clamp(d, 0.2, 120) if math.isfinite(d) and d > 0 else 4

    def norm_time():
        st.T = dur()
        st.t = min(st.t, st.T) if sc.one_shot else st.t % st.T

    # ---- 检查器
    if view.get("cue"):
        L.note(f"<b>求：</b>{view['cue']}")
    row = L.button_row()
    play_btn = row.add("暂停", lambda: toggle())
    row.add("重置", lambda: reset())
    W.toggle("慢放 ×0.5", False, lambda on: setattr(st, "speed", 0.5 if on else 1.0))
    L.note("拖动时间轴回看 · 空格键暂停/播放")
    W.sec("参数")
    for s in sc.sliders:
        k, lb, mn, mx, step, dec = s

        def on_param(v, k=k):
            setattr(sc.P, k, v)
            norm_time()
            changed()
            W.redraw()
        L.slider(lb, mn, mx, step, getattr(sc.P, k), on_param, "", dec)
    for ch in sc.chips:
        W.sec(ch.label)

        def on_chip(text, ch=ch):
            i = ch.items.index(text)
            ch.index = i
            ch.set(i)
            st.t = 0.0
            changed()
            W.redraw()
        W.chips(ch.items, ch.items[ch.index], on_chip)
    W.sec("读数")
    rows: list[_Row] = []
    hint = W.note("")

    def sync_stats():
        rd = sc.readouts(st.t)
        while len(rows) < len(rd):
            rows.append(_Row(L))
        hot = sc.hot[int(clamp(st.lv, 0, 2))] if sc.hot else []
        for i, (lb, val, unit) in enumerate(rd):
            rows[i].set(lb, val, unit)
            rows[i].set_hot(i in hot)

    def sync_play():
        text = "暂停" if st.playing else "重放" if (sc.one_shot and st.t >= st.T - 1e-4) else "播放"
        if play_btn.text() != text:
            play_btn.setText(text)

    # ---- 绘制
    def track_rect(w, h):
        return 14, h - TL_H + 13, max(40, w - 150)

    def render(w, h):
        if w < 24 or h < 24:
            return
        norm_time()
        if lesson:
            ph_core.LESSON = dict(focus=st.focus)
        try:
            sc.draw(cv, st.t, st.lv)
        finally:
            ph_core.LESSON = None
        if lesson and st.ghost:
            draw_ghost(st.ghost)
        g = c.g
        if lesson and hasattr(sc, "vt"):
            inset_vt(g, w, h)
        # 时间轴压在画面底部一条窄带上
        g.p.fillRect(QRectF(0, h - TL_H, w, TL_H), qc(C.card))
        D.line(g, 0, h - TL_H + 0.5, w, h - TL_H + 0.5, C.line, 1)
        x, y, tw = track_rect(w, h)
        f = clamp(st.t / st.T, 0, 1) if st.T > 0 else 0
        g.p.fillRect(QRectF(x, y - 1.5, tw, 3), qc(C.line2))
        g.p.fillRect(QRectF(x, y - 1.5, tw * f, 3), qc(T.accent))
        D.circle(g, x + tw * f, y, 5.5, T.accent, C.card, 2)
        D.text(g, f"{st.t:.2f} / {st.T:.2f} s", w - 12, y, C.soft, size=10.5, mono=True, align="right")
        # 时刻与状态
        D.text(g, f"t = {st.t:.2f} s", 12, 16, C.soft, size=11, mono=True)
        D.text(g, f"状态：{sc.status(st.t)}", w - 12, 16 if kind not in ("shm",) else 12, C.soft, size=11, align="right")
        sync_stats()
        sync_play()
    def draw_ghost(gh):
        """常见错误画在同一张图上：红色虚线 + 落点 + 一句标注（世界坐标，用场景刚设好的视窗）。"""
        try:
            pts = [(float(x), float(y)) for x, y in gh.get("path") or []]
            if len(pts) >= 2:
                ph_core.polyline(cv, pts, T.bad, 2.2, [6, 4])
            at = gh.get("at")
            if at:
                ph_core.dot(cv, float(at[0]), float(at[1]), 5.5, T.bad, C.paper, 1.6)
                if gh.get("text"):
                    ph_core.label(cv, float(at[0]), float(at[1]), str(gh["text"]), T.bad, 10.5, oy=-16, align="center", weight=700)
        except (TypeError, ValueError):
            pass

    def inset_vt(g, w, h):
        """讲题模式：右上角一张小 v–t 图，和画面共用同一个时刻（原来单独一页的「同一时刻双图」）。"""
        title, T_, fn, sym = sc.vt()
        if not (T_ > 0 and math.isfinite(T_)):
            return
        pw, ph = min(250, w * 0.34), min(140, h * 0.3)
        x0, y0 = w - pw - 12, 30
        g.p.save()
        g.p.setRenderHint(g.p.RenderHint.Antialiasing)
        D.rrect(g, x0, y0, pw, ph, 8, C.card, C.line2, 1)
        D.text(g, title, x0 + 10, y0 + 13, C.soft, size=10.5, bold=True)
        n = 60
        vals = [fn(T_ * i / n) for i in range(n + 1)]
        lo, hi = min(0.0, min(vals)), max(0.0, max(vals))
        if hi - lo < 1e-9:
            hi = lo + 1
        ax0, ax1, ay0, ay1 = x0 + 30, x0 + pw - 12, y0 + 28, y0 + ph - 18
        X = lambda t: ax0 + (ax1 - ax0) * t / T_
        Y = lambda v: ay1 - (ay1 - ay0) * (v - lo) / (hi - lo)
        D.line(g, ax0, ay0, ax0, ay1, C.faint, 1)
        D.line(g, ax0, Y(0), ax1, Y(0), C.faint, 1)
        D.text(g, "t", ax1, Y(0) + 9, C.faint, size=9.5, align="right")
        from ..design.quantity import color as qcolor
        col = qcolor(sym) or T.accent
        tt = clamp(st.t, 0, T_)
        k = int(round(n * tt / T_))
        pts = [(X(T_ * i / n), Y(vals[i])) for i in range(n + 1)]
        for i in range(n):   # 走过的部分实线，没走到的淡虚线
            done = i < k
            D.line(g, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], col if done else C.line2, 2.2 if done else 1.2, None if done else [3, 3])
        vx, vy = X(tt), Y(fn(tt))
        D.line(g, vx, ay0, vx, ay1, C.line2, 1, [2, 3])
        D.circle(g, vx, vy, 4.5, col, C.card, 1.5)
        D.text(g, f"{sym} = {fmt(fn(tt), 2)} m/s", x0 + pw - 10, y0 + 13, col, size=10.5, bold=True, align="right")
        g.p.restore()
    W.set(render)

    # ---- 操作
    def tick(dt):
        if not st.playing:
            return
        st.T = dur()
        st.t += dt * st.speed
        if st.stop_at is not None and st.t >= st.stop_at:
            st.t, st.playing, st.stop_at = min(st.stop_at, st.T), False, None
            W.redraw()
            return
        if st.t >= st.T:
            if sc.one_shot:
                st.t = st.T
                st.playing = False
            else:
                st.t -= st.T
        W.redraw()
    L.loop(tick)

    def toggle():
        if st.playing:
            st.playing = False
        else:
            if sc.one_shot and st.t >= st.T - 1e-4:
                st.t = 0.0
            st.playing = True
        W.redraw()

    def reset():
        st.t = 0.0
        W.redraw()

    def seek(px):
        x, _y, tw = track_rect(c.w, c.h)
        st.T = dur()
        st.t = clamp((px - x) / tw, 0, 1) * st.T

    def hit(_x, y):
        if y >= c.h - TL_H:
            return "tl"
        return "scene" if sc.has_drag else None

    def down(x, y, cur):
        if cur == "tl":
            st.was, st.playing = st.playing, False
            seek(x)
            W.redraw()
        elif cur == "scene":
            sc.drag("down", cv.dx(x), cv.dy(y))

    def drag(cur, x, y, _dx, _dy):
        if cur == "tl":
            seek(x)
        elif cur == "scene":
            sc.drag("move", cv.dx(x), cv.dy(y))

    def up(cur):
        if cur == "tl":
            st.playing = st.was
        elif cur == "scene":
            sc.drag("up", 0, 0)
    L.interact(c, hit=hit, down=down, drag=drag, up=up)

    def key(k):
        if k == " ":
            toggle()
            return True
        return False
    L.on_key(key)

    def apply_step(i):
        st.lv = int(clamp(int(i or 0), 0, 2))
        W.step = st.lv
        hint.text(sc.hints[st.lv] if st.lv < len(sc.hints) else "")
        W.redraw()
    W.apply_step = apply_step

    def beat(b):
        """讲题的一步：画到第几层、停在 / 从哪个时刻播到哪个时刻、讲到哪些量。"""
        st.lv = int(clamp(int(b.get("lv", 0)), 0, 2))
        W.step = st.lv
        st.focus = set(b.get("focus") or ())
        st.ghost = b.get("ghost")
        st.T = dur()
        t0 = float(b.get("t") or 0.0)
        st.t = clamp(t0, 0, st.T)
        to = b.get("play_to")
        if to is not None and float(to) > st.t + 1e-6:
            st.stop_at, st.playing = clamp(float(to), 0, st.T), True
        else:
            st.stop_at, st.playing = None, False
        hint.text("")
        W.redraw()
    W.beat = beat

    def params():
        """场景现在的条件（讲题页拖动条件后重算讲解用）。"""
        p = {k: v for k, v in vars(sc.P).items() if isinstance(v, (int, float))}
        if kind == "collision":
            ex = getattr(sc, "exact_e", None)
            p["e"] = ex if ex is not None else (1, 0.6, 0)[sc.ei]
        elif kind == "circuit":
            p["mode"] = "parallel" if sc.mode == 1 else "series"
            p["R3"] = getattr(sc, "fixed_R3", None) or 0
        return p
    W.params = params
    W.scene, W.state = sc, st   # 自测与「讲题」用
    apply_step(0)
    sync_stats()
