"""习题台自测：逐题打开、走完每一步（昼 / 夜），汇报出错的题；默认只给每个模式存一张截图。

用法：python -m native.bank.selftest <输出目录> [题目 id 或 引擎名 ...]
"""
from __future__ import annotations

from ..kit import test_runtime

test_runtime.configure()

import os
import sys
import time
import traceback
from pathlib import Path


def _main(argv=None) -> int:
    import faulthandler
    faulthandler.enable()
    argv = list(sys.argv[1:] if argv is None else argv)
    out = Path(argv.pop(0) if argv else "bank-selftest")
    out.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    if os.path.isdir(r"C:\Windows\Fonts"):
        os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    from PySide6.QtWidgets import QFileDialog
    app = test_runtime.application(sys.argv[:1])
    QFileDialog.getSaveFileName = staticmethod(lambda *_a, **_k: ("", ""))
    from ..design import tokens
    from .data import bank
    from .desk import Desk
    errs: list = []
    w = Desk("day")
    w.resize(1440, 900)
    w.show()
    app.processEvents()
    sys.excepthook = lambda et, ev, tb: errs.append("".join(traceback.format_exception(et, ev, tb))[-500:])   # 窗口建好以后才接管：之前的错要直接报出来
    want = set(argv)
    bad = []
    shot = set()
    total = 0
    for theme in ("day", "night"):
        tokens.set_theme(theme)
        w.apply_theme()
        for q in bank.questions:
            v = q.get("view") or {}
            key = f"{v.get('engine')}-{v.get('mode') or v.get('kind') or ''}"
            if want and q["id"] not in want and v.get("engine") not in want and v.get("mode") not in want and v.get("kind") not in want:
                continue
            total += 1
            errs.clear()
            try:
                w.open(q["id"])
                w.pause()
                n = max(1, w.n_steps())
                for i in range(n):
                    w.set_step(i)
                    app.processEvents()
                    w.ctx.stage.repaint()
            except Exception:  # noqa: BLE001  主流程的异常不走 excepthook 的话会被吞掉，这里直接记下
                errs.append(traceback.format_exc()[-600:])
            time.sleep(0.002)
            err = (w.ctx.stage.error if w.ctx else "未打开") or (errs[0] if errs else None)
            if err:
                bad.append((q["id"], theme, key, err))
                print(f"{theme:5s} {q['id']:24s} {key:22s} ERR {err}", flush=True)
            if (theme, key) not in shot:
                shot.add((theme, key))
                w.grab().save(str(out / f"{key}-{theme}.png"))
    print("BANK SELFTEST", "FAIL" if bad else "OK", total, "runs", len(bad), "errors", flush=True)
    sys.stdout.flush()
    return 1 if bad else 0


def main(argv=None):
    from PySide6.QtWidgets import QFileDialog
    saved=(QFileDialog.getSaveFileName,sys.excepthook)
    try:
        return _main(argv)
    finally:
        QFileDialog.getSaveFileName,sys.excepthook=saved


if __name__ == "__main__":
    raise SystemExit(test_runtime.run(main))
