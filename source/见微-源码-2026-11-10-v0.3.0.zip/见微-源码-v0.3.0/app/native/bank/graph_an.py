"""函数性质的数值分析（由 graphplus.js 改写）：零点、驻点、极值、拐点、渐近线、单调、奇偶、周期、值域。

纯数学，不碰界面；analyze(fn, xr, yr) 返回一个字典。fn 在定义域外返回 nan。
"""
from __future__ import annotations

import math

ISF = math.isfinite


def fmt_a(v, d=2):
    if v is None or not ISF(v):
        return "—"
    r = 0 if abs(v) < 1e-9 else v
    k = 10 ** d
    s = f"{round(r * k) / k:.{d}f}".rstrip("0").rstrip(".")
    return (s or "0").replace("-", "−")


def bisect(f, lo, hi, iters=34):
    flo, fhi = f(lo), f(hi)
    if not ISF(flo) or not ISF(fhi) or flo * fhi > 0:
        return None
    m = lo
    for _ in range(iters):
        m = (lo + hi) / 2
        fm = f(m)
        if not ISF(fm):
            return None
        if flo * fm <= 0:
            hi = m
        else:
            lo, flo = m, fm
    return m


def analyze(fn, xr, yr, N=600):
    a, b = xr
    h = (b - a) / N
    span = max(1e-9, yr[1] - yr[0])
    edge = span * 40 + 20
    xs = [a + h * i for i in range(N + 1)]
    ys = []
    for x in xs:
        y = fn(x)
        ys.append(y if ISF(y) and abs(y) < edge else math.nan)

    def ok(i):
        return ISF(ys[i])

    def d1(i):
        return (ys[i + 1] - ys[i - 1]) / (2 * h)

    def d2(i):
        return (ys[i + 1] - 2 * ys[i] + ys[i - 1]) / (h * h)

    zeros = []
    for i in range(1, N):
        if not ok(i) or not ok(i + 1):
            continue
        if ys[i] == 0:
            zeros.append(xs[i])
        elif ys[i] * ys[i + 1] < 0:
            r = bisect(fn, xs[i], xs[i + 1])
            if r is not None:
                zeros.append(r)
    stat, maxs, mins = [], [], []
    tt = max(1e-7, h / 8)

    def dfn(x):
        return (fn(x + tt) - fn(x - tt)) / (2 * tt)
    for i in range(2, N - 1):
        if not (ok(i - 2) and ok(i - 1) and ok(i) and ok(i + 1) and ok(i + 2)):
            continue
        a1, a2 = d1(i - 1), d1(i + 1)
        if a1 * a2 > 0:
            continue
        r = bisect(dfn, xs[i - 1], xs[i + 1])
        if r is None or any(abs(v - r) < h * 1.5 for v in stat):
            continue
        stat.append(r)
        s2 = d2(i)
        if s2 < -1e-9:
            maxs.append(r)
        elif s2 > 1e-9:
            mins.append(r)
    inflect = []
    t2 = max(1e-6, h)

    def d2fn(x):
        return (fn(x + t2) - 2 * fn(x) + fn(x - t2)) / (t2 * t2)
    for i in range(2, N - 1):
        if not (ok(i - 2) and ok(i - 1) and ok(i) and ok(i + 1) and ok(i + 2)):
            continue
        b1, b2 = d2(i - 1), d2(i + 1)
        if b1 * b2 > 0 or (abs(b1) < 1e-7 and abs(b2) < 1e-7):   # 直线段二阶导全是 0，不算拐点
            continue
        r = bisect(d2fn, xs[i - 1], xs[i + 1], 26)
        if r is not None and not any(abs(v - r) < h * 1.5 for v in inflect):
            inflect.append(r)
    vert = []
    guard = (b - a) * 0.01
    for i in range(1, N):
        if ok(i) and ok(i - 1):
            continue
        x0 = xs[i]
        yl, yr2 = fn(x0 - h * 0.02), fn(x0 + h * 0.02)
        big = (ISF(yl) and abs(yl) > span * 2) or (ISF(yr2) and abs(yr2) > span * 2)
        # 两侧至少一边是有限值才算渐近线；两侧都无定义（如 √x 的 x<0）只是定义域的边
        if big or (ISF(yl) != ISF(yr2) and math.inf in (abs(yl), abs(yr2))):
            if x0 < a + guard or x0 > b - guard:
                continue
            if len(vert) >= 4:
                break
            if not any(abs(v - x0) < (b - a) / 40 for v in vert):
                vert.append(x0)

    def tail(right):
        vals = []
        for i in range(24):
            y = ys[N - i if right else i]
            if not ISF(y):
                return None
            vals.append(y)
        mn, mx = min(vals), max(vals)
        return (mn + mx) / 2 if mx - mn < span * 0.008 else None
    horiz = []
    hr, hl = tail(True), tail(False)
    if hr is not None:
        horiz.append(hr)
    if hl is not None and (hr is None or abs(hl - hr) > span * 0.01):
        horiz.append(hl)
    mono = []
    sign, start = 0, a
    for i in range(1, N):
        if not ok(i):
            sign, start = 0, xs[i]
            continue
        if not (ok(i - 1) and ok(i + 1)):
            continue
        d = d1(i)
        if abs(d) < 1e-9:
            continue
        s = 1 if d > 0 else -1
        if sign == 0:
            sign, start = s, xs[i]
        elif s != sign:
            mono.append((start, xs[i], sign))
            start, sign = xs[i], s
    if sign:
        mono.append((start, b, sign))
    parity = "非奇非偶"
    lim = min(abs(a), abs(b))
    if lim > 0.6:
        even = odd = True
        cnt = 0
        for k in range(1, 25):
            x = lim * k / 24
            f1, f2 = fn(x), fn(-x)
            if not ISF(f1) or not ISF(f2):
                continue
            cnt += 1
            if abs(f1 - f2) > span * 0.01:
                even = False
            if abs(f1 + f2) > span * 0.01:
                odd = False
        if cnt >= 8:
            parity = "偶函数" if even else "奇函数" if odd else "非奇非偶"
    # 周期：在采样序列里找最小滞后使 f(x+T)≈f(x)，比「极大值间距」稳
    period = None
    M = 240
    base = [fn(a + (b - a) * i / M) for i in range(M)]
    flat = max((v for v in base if ISF(v)), default=0) - min((v for v in base if ISF(v)), default=0) < span * 0.01
    if not flat:
        for lag in range(6, int(M * 0.92) + 1):
            err, cnt = 0.0, 0
            for i in range(M - lag):
                d = abs(base[i] - base[i + lag])
                if ISF(d):
                    err += d
                    cnt += 1
                    if err > span * 0.006 * M:   # 已经超了，提前收工
                        break
            else:
                if cnt > M * 0.5 and err / cnt < span * 0.006:
                    period = (b - a) * lag / M
                    break
    if period is None and len(maxs) >= 2:
        gaps = sorted(maxs[i] - maxs[i - 1] for i in range(1, len(maxs)))
        med = gaps[len(gaps) // 2]
        if med > h * 3:
            period = med
    fin = [v for v in ys if ISF(v)]
    return dict(zeros=zeros, stat=stat, maxs=maxs, mins=mins, inflect=inflect, vert=vert, horiz=horiz, mono=mono, parity=parity, period=period, range=(min(fin), max(fin)) if fin else None)
