"""subjects 引擎 · 化学模式（由 views/subjects.js 改写）：方程式配平、滴定曲线、化学平衡、原电池。"""
from __future__ import annotations

import math
import re

from ..kit.core import clamp
from .sb_core import C, mode, num, sub_num, tw


# ---------------------------------------------------------------- 方程式
def parse_formula(f):
    s = re.sub(r"\s+", "", str(f or ""))
    s = re.sub(r"[(\[（](s|l|g|aq)[)\]）]", "", s, flags=re.I)
    stack = [{}]
    i = 0
    while i < len(s):
        ch = s[i]
        if ch in "(（":
            stack.append({})
            i += 1
        elif ch in ")）":
            i += 1
            d = ""
            while i < len(s) and s[i].isdigit():
                d += s[i]
                i += 1
            m = int(d) if d else 1
            group = stack.pop() if len(stack) > 1 else {}
            up = stack[-1]
            for k, v in group.items():
                up[k] = up.get(k, 0) + v * m
        elif "A" <= ch <= "Z":
            sym = ch
            i += 1
            while i < len(s) and "a" <= s[i] <= "z":
                sym += s[i]
                i += 1
            d = ""
            while i < len(s) and s[i].isdigit():
                d += s[i]
                i += 1
            stack[-1][sym] = stack[-1].get(sym, 0) + (int(d) if d else 1)
        else:
            i += 1
    return stack[0]


def parse_eq(st):
    s = re.sub(r"\s+", "", str(st or ""))
    parts = re.split(r"->|→|=>|⇌|=|⟶", s)
    if len(parts) < 2:
        return None

    def side(t):
        out = []
        for term in filter(None, t.split("+")):
            m = re.match(r"^([0-9]*)(.*)$", term)
            coef = max(1, int(m.group(1))) if m.group(1) else 1
            form = m.group(2) or term
            out.append({"coef": coef, "formula": form, "atoms": parse_formula(form)})
        return out
    left, right = side(parts[0]), side(parts[1])
    if not left or not right or not all(t["atoms"] for t in left) or not all(t["atoms"] for t in right):
        return None
    return {"left": left, "right": right}


def atom_totals(lst):
    o = {}
    for t in lst:
        for k, v in t["atoms"].items():
            o[k] = o.get(k, 0) + v * t["coef"]
    return o


def balance_solve(left, right):
    al = left + right
    n = len(al)
    if n < 2 or n > 5:
        return None
    els = []
    for t in al:
        for k in t["atoms"]:
            if k not in els:
                els.append(k)
    if not els:
        return None
    pick = [1] * n
    best = [None]

    def ok():
        for k in els:
            s = 0
            for i in range(n):
                c = al[i]["atoms"].get(k, 0) * pick[i]
                s += c if i < len(left) else -c
            if s:
                return False
        return True

    def rec(i):
        if best[0] and best[0][0] <= n:
            return
        if i == n:
            if ok():
                sm = sum(pick)
                if not best[0] or sm < best[0][0]:
                    best[0] = (sm, list(pick))
            return
        for c in range(1, 9):
            pick[i] = c
            rec(i + 1)
    rec(0)
    return best[0][1] if best[0] else None


@mode("reaction")
def mount_reaction(W):
    fallback = "2H2+O2->2H2O"
    S = {"cond": W.D.get("cond") or W.P.get("cond") or "点燃", "show": True, "parsed": parse_eq(W.D.get("eq") or W.P.get("eq") or fallback) or parse_eq(fallback)}
    W.head_title("方程式配平", "反应物 → 条件 → 产物 · 原子账本")
    W.add_steps(["反应物", "条件", "产物", "账本"])
    W.sec("读数")
    vL, vR, vB = W.stat("左侧原子"), W.stat("右侧原子"), W.stat("守恒")
    kv_els = W.kv("元素")
    note = W.note("点步骤推进：先数反应物，再看条件与产物，最后核对原子账本。")
    W.sec("条件标注")
    conds = ["点燃", "加热", "催化剂", "电解"]
    W.chips(conds + ([S["cond"]] if S["cond"] not in conds else []), S["cond"], lambda v: (S.__setitem__("cond", v), W.redraw()))
    W.sec("显示")
    W.toggle("显示化学计量数", True, lambda on: (S.__setitem__("show", on), W.redraw()))

    def auto():
        p = S["parsed"]
        sol = balance_solve(p["left"], p["right"])
        if sol:
            for t, c in zip(p["left"] + p["right"], sol):
                t["coef"] = c
            note.text(f"已配平，系数 <b>{' : '.join(map(str, sol))}</b>；左右原子数逐元素相等。")
        else:
            note.text("未找到 1–8 的整数系数解，可能式中有错或需要更复杂的配平思路。")
        W.redraw()

    def reset():
        S["parsed"] = parse_eq(W.D.get("eq") or fallback) or parse_eq(fallback)
        note.text("已回到原始方程式。")
        W.redraw()
    W.button("自动配平", auto, True)
    W.button("还原", reset)

    def render(w, h):
        p = S["parsed"]
        Pd = 22
        Lt, Rt = atom_totals(p["left"]), atom_totals(p["right"])
        els = []
        for k in list(Lt) + list(Rt):
            if k not in els:
                els.append(k)
        tot_l, tot_r = sum(Lt.values()), sum(Rt.values())
        balanced = all(Lt.get(k, 0) == Rt.get(k, 0) for k in els)
        step = W.step

        def dim(need):
            return 1 if step >= need else 0.24
        mid_y = max(96, h * 0.30)
        box_h, plus_w, gap = 50, 22, 24
        W.txt(Pd, 24, "化学方程式 · 反应流程", size=12.5, weight=700)
        W.txt(w - Pd, 24, f"左 {tot_l} 原子  ·  右 {tot_r} 原子", size=11, anchor="end", fill=C.soft if balanced else C.accent)
        W.line(Pd, 36, w - Pd, 36, C.line2)

        def mk(lst, size):
            out = []
            for t in lst:
                st = ("" if not S["show"] or t["coef"] == 1 else str(t["coef"])) + sub_num(t["formula"])
                out.append((st, max(56, tw(st, size) + 26)))
            return out
        size = 13
        li, ri = mk(p["left"], size), mk(p["right"], size)

        def wid(m):
            return sum(x[1] for x in m) + plus_w * (len(m) - 1)
        if wid(li) + wid(ri) + gap * 2 + 54 > w - 2 * Pd:
            size = 11
            li, ri = mk(p["left"], size), mk(p["right"], size)
        left_w, right_w = wid(li), wid(ri)

        def draw_row(metrics, x0, op):
            x = x0
            for i, (st, mw) in enumerate(metrics):
                active = step == 0 and op == 1
                W.rect(x, mid_y - box_h / 2, mw, box_h, rx=3, fill=C.card if active else C.grid2, stroke=C.ink2 if active else C.line, width=1.3 if active else 1, opacity=op)
                W.txt(x + mw / 2, mid_y - 2, st, size=size, weight=600, anchor="middle", opacity=op)
                x += mw
                if i < len(metrics) - 1:
                    W.txt(x + plus_w / 2, mid_y, "+", size=12, anchor="middle", fill=C.faint, opacity=op)
                    x += plus_w
        lop, rop = dim(0), dim(2)
        draw_row(li, Pd, lop)
        rstart = w - Pd - right_w
        draw_row(ri, rstart, rop)
        ax1, ax2 = Pd + left_w + gap, rstart - gap
        aop = dim(1)
        W.line(ax1, mid_y, ax2, mid_y, C.ink2, 1.4, opacity=aop)
        W.head(ax2, mid_y, 0, 7, C.ink2, aop)
        cx = (ax1 + ax2) / 2
        W.txt(cx, mid_y - 16, S["cond"], size=11.5, anchor="middle", weight=600, opacity=aop)
        W.txt(cx, mid_y + 15, "条件", size=9.5, anchor="middle", fill=C.faint, opacity=aop)
        if step == 1:
            cw = tw(S["cond"], 11.5)
            W.rect(cx - cw / 2 - 8, mid_y - 27, cw + 16, 21, rx=10, stroke=C.accent)
        W.txt(Pd, mid_y - box_h / 2 - 12, "反应物", size=10, fill=C.faint, opacity=lop)
        W.txt(w - Pd, mid_y - box_h / 2 - 12, "产物", size=10, fill=C.faint, anchor="end", opacity=rop)
        ly = mid_y + box_h / 2 + 54
        rows = max(1, len(els))
        row_h = clamp((h - ly - 26) / rows, 22, 40)
        o = dim(3)
        W.txt(Pd, ly - 22, "原子账本", size=11.5, weight=700, opacity=o)
        W.txt(w - Pd, ly - 22, "左右守恒" if balanced else "尚未守恒", size=10.5, anchor="end", fill=C.jade if balanced else C.accent, opacity=o)
        W.line(Pd, ly - 10, w - Pd, ly - 10, C.line2, opacity=o)
        W.txt(Pd + 4, ly + 6, "元素", size=9.5, fill=C.faint, opacity=o)
        W.txt(w * 0.28, ly + 6, "反应物侧", size=9.5, fill=C.faint, opacity=o)
        W.txt(w * 0.55, ly + 6, "产物侧", size=9.5, fill=C.faint, opacity=o)
        dot_r, dg = min(3.4, row_h * 0.12), 9.4
        max_dots = max(4, int((w * 0.25) // dg) - 1)
        for i, k in enumerate(els):
            y = ly + 28 + i * row_h
            lv, rv = Lt.get(k, 0), Rt.get(k, 0)
            good = lv == rv
            W.txt(Pd + 6, y, k, size=12, weight=700, opacity=o)
            for x0, v, col in ((w * 0.15, lv, C.data[1]), (w * 0.58, rv, C.data[2])):
                for d in range(min(v, max_dots)):
                    W.circ(x0 + d * dg, y, dot_r, fill=col, opacity=o)
                if v > max_dots:
                    W.txt(x0 + max_dots * dg, y, f"+{v - max_dots}", size=9.5, fill=C.soft, opacity=o)
                W.txt(x0 + min(v, max_dots) * dg + 6, y, f"×{v}", size=10.5, fill=C.soft, weight=600, opacity=o)
            W.txt(w * 0.46, y, "=" if good else "≠", size=12, anchor="middle", fill=C.faint if good else C.accent, weight=700, opacity=o)
            if not good and step >= 3:
                W.txt(w * 0.43, y + 13, f"差 {abs(lv - rv)}", size=9, anchor="end", fill=C.accent, opacity=o)
        vL.text(tot_l)
        vR.text(tot_r)
        vB.text("守恒" if balanced else "不守恒", C.ink if balanced else C.accent)
        kv_els.text(" · ".join(els) or "—")
        if step == 3:
            if balanced:
                note.text("逐元素比对：" + "，".join(f"{k} {Lt.get(k, 0)}={Rt.get(k, 0)}" for k in els) + "。")
            else:
                note.text("逐元素比对：" + "，".join(f"{k} 左 {Lt.get(k, 0)} / 右 {Rt.get(k, 0)}" for k in els if Lt.get(k, 0) != Rt.get(k, 0)) + "。")
    W.set(render)


# ---------------------------------------------------------------- 滴定
INDS = [("酚酞", 8.2, 10.0), ("甲基橙", 3.1, 4.4), ("石蕊", 5.0, 8.0)]


@mode("titration")
def mount_titration(W):
    P, D_ = W.P, W.D
    pka = float(P["pKa"]) if P.get("pKa") is not None else (-math.log10(float(P["Ka"])) if P.get("Ka") else 4.76)
    S = {"pKa": pka, "c": float(P.get("c", 0.1)), "V0": float(P.get("V0", 25)), "cb": float(P.get("cb", 0.1)), "V": 0.0, "ind": 0, "geo": None, "curve": [], "Vmax": 50.0, "veq": 25.0}

    def ph_at(V):
        Ka, Kw = 10 ** -S["pKa"], 1e-14
        vt = S["V0"] + V
        ct, cn = S["c"] * S["V0"] / vt, S["cb"] * V / vt
        lo, hi = 0.0, 14.0
        for _ in range(40):
            m = (lo + hi) / 2
            H = 10 ** -m
            if H + cn - Kw / H - ct * Ka / (Ka + H) > 0:
                lo = m
            else:
                hi = m
        return (lo + hi) / 2

    def build():
        S["veq"] = S["c"] * S["V0"] / S["cb"]
        S["Vmax"] = max(0.8, S["veq"] * 2)
        if D_.get("curve"):
            S["curve"] = [(float(p[0]), float(p[1])) if isinstance(p, list) else (float(p["v"]), float(p["ph"])) for p in D_["curve"]]
            S["Vmax"] = max(0.8, S["curve"][-1][0])
        else:
            S["curve"] = [(S["Vmax"] * i / 300, ph_at(S["Vmax"] * i / 300)) for i in range(301)]
        S["V"] = clamp(S["V"], 0, S["Vmax"])
    build()
    W.head_title("酸碱滴定曲线", "pH–V 计算 · 突跃与指示剂")
    W.add_steps(["曲线", "突跃", "等当点", "读数"])
    W.sec("读数")
    vV, vPh, vDv = W.stat("滴定体积", "0", "mL"), W.stat("pH", "0"), W.stat("距等当点", "0", "mL")
    kvEq, kvJump, kvInd = W.kv("等当点"), W.kv("突跃 pH"), W.kv("指示剂")
    W.sec("参数")

    def setp(k):
        return lambda v: (S.__setitem__(k, v), build(), W.redraw())
    W.range("pKa", 2, 9, 0.05, S["pKa"], setp("pKa"), 2)
    W.range("c(酸) / mol·L⁻¹", 0.02, 0.3, 0.01, S["c"], setp("c"), 2)
    W.chips([x[0] for x in INDS], INDS[0][0], lambda n: (S.__setitem__("ind", [x[0] for x in INDS].index(n)), W.redraw()))
    W.L.note("在图上拖动可以读任意体积的 pH。")

    def jump_range():
        cv = S["curve"]
        max_s, mi = 0.0, 1
        for i in range(1, len(cv)):
            dv = cv[i][0] - cv[i - 1][0]
            if dv > 0:
                s = abs(cv[i][1] - cv[i - 1][1]) / dv
                if s > max_s:
                    max_s, mi = s, i
        th = max_s * 0.3
        a = b = mi
        while a > 1 and abs(cv[a][1] - cv[a - 1][1]) / max(1e-9, cv[a][0] - cv[a - 1][0]) > th:
            a -= 1
        while b < len(cv) - 1 and abs(cv[b + 1][1] - cv[b][1]) / max(1e-9, cv[b + 1][0] - cv[b][0]) > th:
            b += 1
        return cv[a][0], cv[b][0], cv[a][1], cv[b][1]

    def render(w, h):
        Lm, Rm, Tm, Bm = 46, 18, 26, 40
        iw, ih = w - Lm - Rm, h - Tm - Bm
        Vmax, veq, cv = S["Vmax"], S["veq"], S["curve"]

        def x(v):
            return Lm + v / Vmax * iw

        def y(ph):
            return Tm + (1 - ph / 14) * ih
        S["geo"] = (Lm, iw)
        step = W.step
        nm, lo, hi = INDS[S["ind"]]
        j0, j1, p0, p1 = jump_range()
        eq_ph = min(cv, key=lambda p: abs(p[0] - veq))[1]
        read_ph = min(cv, key=lambda p: abs(p[0] - S["V"]))[1]
        for ph in range(0, 15, 2):
            W.line(Lm, y(ph), w - Rm, y(ph), C.line if ph == 7 else C.grid2)
            W.txt(Lm - 8, y(ph), ph, size=9.5, anchor="end", fill=C.faint)
        vstep = 10 if Vmax > 40 else 5
        v = 0.0
        while v <= Vmax + 0.01:
            W.line(x(v), Tm, x(v), Tm + ih, C.grid2)
            W.txt(x(v), h - Bm + 14, num(v, 0), size=9.5, anchor="middle", fill=C.faint)
            v += vstep
        W.line(Lm, Tm + ih, w - Rm, Tm + ih, C.faint)
        W.line(Lm, Tm, Lm, Tm + ih, C.faint)
        W.txt(Lm - 8, Tm - 12, "pH", size=10, anchor="end", fill=C.soft)
        W.txt(w - Rm, h - 10, "V(NaOH) / mL", size=10, anchor="end", fill=C.soft)
        if step >= 1:
            W.rect(x(j0), y(p1), x(j1) - x(j0), y(p0) - y(p1), fill=C.data[4])
            W.line(x(j0), y(p1), x(j1), y(p1), C.data[2], dash="3 3", opacity=0.7)
            W.line(x(j0), y(p0), x(j1), y(p0), C.data[2], dash="3 3", opacity=0.7)
            W.txt(x((j0 + j1) / 2), y(p1) - 8, f"突跃 {num(p0, 1)}–{num(p1, 1)}", size=10, anchor="middle", fill=C.soft)
        if step >= 2:
            W.rect(Lm, y(hi), iw, y(lo) - y(hi), fill=C.data[4], opacity=0.8)
            W.line(Lm, y(lo), w - Rm, y(lo), C.data[3], dash="4 3")
            W.line(Lm, y(hi), w - Rm, y(hi), C.data[3], dash="4 3")
            W.txt(w - Rm - 4, y(hi) - 8, f"{nm} {num(lo, 1)}–{num(hi, 1)}", size=10, anchor="end", fill=C.soft)
        W.poly([(x(p[0]), y(p[1])) for p in cv], stroke=C.ink2, width=1.9)
        if step >= 2:
            W.line(x(veq), Tm, x(veq), Tm + ih, C.ink2, dash="3 4", opacity=0.65)
            W.circ(x(veq), y(eq_ph), 3.6, fill=C.ink)
            W.txt(x(veq) + 7, y(eq_ph) - 12, f"等当点 {num(veq, 1)} mL · pH {num(eq_ph, 2)}", size=10, weight=600)
        ccol = C.accent if step >= 3 else C.ink2
        cx = x(S["V"])
        W.line(cx, Tm, cx, Tm + ih, ccol, 1.6 if step >= 3 else 1.2, opacity=1 if step >= 3 else 0.55)
        W.circ(cx, y(read_ph), 4, fill=C.card, stroke=ccol, width=1.6)
        W.rect(clamp(cx - 34, Lm, w - Rm - 68), Tm + 4, 68, 20, rx=2, fill=C.card, stroke=C.line, opacity=0.95)
        W.txt(clamp(cx, Lm + 34, w - Rm - 34), Tm + 14, f"pH {num(read_ph, 2)}", size=10.5, anchor="middle", weight=700)
        if step >= 3:
            W.txt(cx + 6, Tm + ih - 8, "可拖动", size=9.5, fill=C.accent, anchor="end" if cx > w - 80 else "start")
        vV.text(num(S["V"], 1))
        vPh.text(num(read_ph, 2))
        vDv.text(num(S["V"] - veq, 1))
        kvEq.text(f"{num(veq, 1)} mL · pH {num(eq_ph, 2)}")
        kvJump.text(f"{num(p0, 1)}–{num(p1, 1)}")
        kvInd.text(nm + (" 未变色" if read_ph < lo else " 已变色" if read_ph > hi else " 变色中"))
    W.set(render)

    def read_at(px):
        if S["geo"]:
            S["V"] = clamp((px - S["geo"][0]) / S["geo"][1], 0, 1) * S["Vmax"]
            W.redraw()
    W.L.interact(W.c, hit=lambda x, _y: (read_at(x), {"t": 1})[1], drag=lambda _o, x, _y, _dx, _dy: read_at(x))


# ---------------------------------------------------------------- 化学平衡
@mode("equilibrium")
def mount_equilibrium(W):
    P = W.P
    S = {"K": float(P.get("K", 2.5)), "A0": float(P.get("cA", P.get("A0", 1))), "B0": float(P.get("cB", P.get("B0", 0))), "t": 2.4, "T": 10.0, "tau": 1.6}

    def eq_state():
        Ct = S["A0"] + S["B0"]
        return Ct / (1 + S["K"]), S["K"] * Ct / (1 + S["K"]), Ct

    def conc(t):
        ea, eb, _ = eq_state()
        k = math.exp(-t / S["tau"])
        return ea + (S["A0"] - ea) * k, eb + (S["B0"] - eb) * k
    W.head_title("化学平衡", "浓度–时间 · Q 与 K 判定方向")
    W.add_steps(["初始", "趋向", "Q 与 K", "平衡"])
    W.L.note("A ⇌ B　　K = [B] / [A]")
    W.sec("读数")
    vA, vB, vQ, vK = W.stat("[A]", None, "M"), W.stat("[B]", None, "M"), W.stat("Q"), W.stat("K")
    kvDir, kvEq = W.kv("方向"), W.kv("平衡 [A] / [B]")
    W.sec("可调参数")

    def setp(k):
        return lambda v: (S.__setitem__(k, v), W.redraw())
    W.range("平衡常数 K", 0.2, 8, 0.1, S["K"], setp("K"), 1)
    W.range("初始 [A]₀", 0.2, 2, 0.05, S["A0"], setp("A0"), 2)
    W.range("初始 [B]₀", 0, 1, 0.05, S["B0"], setp("B0"), 2)
    W.range("时间 t / s", 0, S["T"], 0.1, S["t"], setp("t"), 1)
    W.note("K 越大平衡越靠右；Q = [B]/[A]，Q &lt; K 时正向进行。")

    def render(w, h):
        Lm, Rm, Tm, Bm = 48, 74, 34, 42
        iw, ih = w - Lm - Rm, h - Tm - Bm
        Tt = S["T"]

        def x(t):
            return Lm + t / Tt * iw
        ea, eb, Ct = eq_state()
        ca, cb = conc(S["t"])
        ymax = max(S["A0"], S["B0"], Ct) * 1.18 + 0.05

        def y(v):
            return Tm + (1 - v / ymax) * ih
        Q = cb / ca if ca > 1e-9 else math.inf
        step = W.step
        for i in range(6):
            v = ymax * i / 5
            W.line(Lm, y(v), w - Rm, y(v), C.grid2)
            W.txt(Lm - 8, y(v), num(v, 2), size=9.5, anchor="end", fill=C.faint)
        for t in range(0, int(Tt) + 1, 2):
            W.line(x(t), Tm, x(t), Tm + ih, C.grid2)
            W.txt(x(t), Tm + ih + 14, t, size=9.5, anchor="middle", fill=C.faint)
        W.line(Lm, Tm + ih, w - Rm, Tm + ih, C.faint)
        W.line(Lm, Tm, Lm, Tm + ih, C.faint)
        W.txt(Lm - 8, Tm - 14, "c / mol·L⁻¹", size=10, fill=C.soft)
        W.txt(w - Rm, h - 10, "t / s", size=10, anchor="end", fill=C.soft)
        op = 1 if step >= 1 else 0.3
        for idx, col, label in ((0, C.ink, "A"), (1, C.data[1], "B")):
            W.poly([(x(Tt * i / 220), y(conc(Tt * i / 220)[idx])) for i in range(221)], stroke=col, width=1.9, opacity=op)
            W.txt(x(Tt) + 8, y(conc(Tt)[idx]), label, size=11, fill=col, weight=700, opacity=op)
        if step >= 1:
            for val in (ea, eb):
                W.line(Lm, y(val), w - Rm, y(val), C.faint, dash="3 4", opacity=0.9 if step >= 3 else 0.3)
                W.txt(w - Rm + 8, y(val), f"平衡 {num(val, 2)}", size=9.5, fill=C.ink if step >= 3 else C.faint, opacity=1 if step >= 3 else 0.5)
        W.line(x(S["t"]), Tm, x(S["t"]), Tm + ih, C.ink2, 1, "2 3", 0.6)
        W.circ(x(S["t"]), y(ca), 3.4, fill=C.ink)
        W.circ(x(S["t"]), y(cb), 3.4, fill=C.data[1])
        W.txt(x(S["t"]) + 7, y(ca) - 10, f"[A] {num(ca, 2)}", size=9.5)
        W.txt(x(S["t"]) + 7, y(cb) + 12, f"[B] {num(cb, 2)}", size=9.5, fill=C.data[1])
        K = S["K"]
        d = 1 if Q < K * 0.995 else -1 if Q > K * 1.005 else 0
        if step >= 2:
            bx, by = w - Rm - 110, Tm + 10
            W.rect(bx, by, 110, 34, rx=2, fill=C.card, stroke=C.line2, opacity=0.96)
            W.txt(bx + 55, by + 11, f"Q = {num(Q, 2) if math.isfinite(Q) else '∞'}   K = {num(K, 2)}", size=9.5, anchor="middle", fill=C.soft)
            W.txt(bx + 55, by + 25, "正向进行 →" if d > 0 else "← 逆向进行" if d < 0 else "已达平衡", size=10.5, anchor="middle", fill=C.ink if d else C.jade, weight=600)
            if d:
                W.arrow(bx + 40, by + 44, bx + (84 if d > 0 else 16), by + 44, C.accent, 1.2, 5)
                W.txt(bx + 55, by + 56, "净反应方向", size=8.5, anchor="middle", fill=C.faint)
        vA.text(num(ca, 2))
        vB.text(num(cb, 2))
        vQ.text(num(Q, 2) if math.isfinite(Q) else "∞")
        vK.text(num(K, 2))
        kvDir.text("正向（Q<K）" if d > 0 else "逆向（Q>K）" if d < 0 else "平衡（Q≈K）")
        kvEq.text(f"{num(ea, 2)} / {num(eb, 2)}")
    W.set(render)


# ---------------------------------------------------------------- 原电池
def poly_at(pts, f):
    total = sum(math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]) for i in range(1, len(pts)))
    target = ((f % 1) + 1) % 1 * total
    for i in range(1, len(pts)):
        a, b = pts[i - 1], pts[i]
        ln = math.hypot(b[0] - a[0], b[1] - a[1])
        if target <= ln:
            t = target / ln if ln else 0
            return a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
        target -= ln
    return pts[-1]


@mode("electrochem")
def mount_electrochem(W):
    D_, P = W.D, W.P
    L0 = {"metal": "Zn", "ion": "Zn²⁺", "sol": "ZnSO₄ 溶液", "e": -0.76, **(D_.get("left") or D_.get("anode") or P.get("left") or {})}
    R0 = {"metal": "Cu", "ion": "Cu²⁺", "sol": "CuSO₄ 溶液", "e": 0.34, **(D_.get("right") or D_.get("cathode") or P.get("right") or {})}
    S = {"closed": False, "phase": 0.0, "emf": round(float(D_["emf"] if D_.get("emf") is not None else R0["e"] - L0["e"]), 2), "ions": True}
    W.head_title("原电池装置", "两极 · 电子流向 · 离子迁移")
    W.add_steps(["装置", "电子", "离子", "电极反应"])
    W.sec("读数")
    W.stat("电动势", num(S["emf"], 2), "V")
    vLoop = W.stat("回路", "断开")
    W.kv("负极（氧化）", f"{L0['metal']} / {L0['ion']}")
    W.kv("正极（还原）", f"{R0['metal']} / {R0['ion']}")
    W.sec("电极反应")
    W.L.note(f"{L0['metal']} − 2e⁻ → {L0['ion']}<br>{R0['ion']} + 2e⁻ → {R0['metal']}")
    W.sec("控制")

    def flip(b):
        S["closed"] = not S["closed"]
        b.setText("断开开关" if S["closed"] else "合上开关")
        vLoop.text("闭合" if S["closed"] else "断开")
        W.redraw()
    W.L.button("合上开关", flip, True)
    W.toggle("显示离子迁移", True, lambda on: (S.__setitem__("ions", on), W.redraw()))
    W.note("电子由负极经导线流向正极；盐桥中阳离子向正极、阴离子向负极迁移。")

    def render(w, h):
        step = W.step

        def dim(need):
            return 1 if step >= need else 0.34
        xL, xR = w * 0.27, w * 0.73
        bw, bh = min(112, w * 0.17), min(104, h * 0.26)
        by = h * 0.66
        e_top, e_bot, rail = h * 0.40, by + bh - 14, h * 0.17
        pts = [(xL, e_top), (xL, rail), (xR, rail), (xR, e_top)]
        W.poly(pts, stroke=C.ink2, width=1.6)
        swx = w * 0.38
        W.rect(swx - 7, rail - 2, 14, 4, fill=C.paper)
        W.circ(swx - 6, rail, 2.6, fill=C.ink)
        W.circ(swx + 6, rail, 2.6, fill=C.ink)
        if S["closed"]:
            W.line(swx - 6, rail, swx + 6, rail, C.ink, 2.2)
        else:
            W.line(swx - 6, rail, swx + 4, rail - 9, C.ink, 2.2)
        W.txt(swx, rail - 22, "开关", size=9.5, anchor="middle", fill=C.faint)
        mx, mr = w * 0.55, min(19, h * 0.048)
        my = rail + 38
        W.line(mx, rail, mx, my - mr, C.ink2, 1.2)
        W.circ(mx, my, mr, fill=C.card, stroke=C.ink2, width=1.3)
        W.txt(mx, my - 3, "V", size=8.5, anchor="middle", fill=C.faint)
        W.txt(mx, my + 7, num(S["emf"], 2) if S["closed"] else "—", size=9, anchor="middle", weight=700)
        for bx, label, sol, metal, col in ((xL, "负极 · " + L0["metal"], L0["sol"], L0["metal"], C.ink), (xR, "正极 · " + R0["metal"], R0["sol"], R0["metal"], C.data[1])):
            x0 = bx - bw / 2
            W.poly([(x0, by - 10), (x0, by + bh), (x0 + bw, by + bh), (x0 + bw, by - 10)], stroke=C.line, width=1.4)
            W.rect(x0 + 1, by + 6, bw - 2, bh - 6, fill=C.data[4])
            W.line(x0 + 1, by + 6, x0 + bw - 1, by + 6, C.data[2], opacity=0.5)
            W.txt(bx, by + bh - 12, sol, size=9.5, anchor="middle", fill=C.soft)
            W.txt(bx, by + bh + 20, label, size=10.5, anchor="middle", weight=600)
            W.rect(bx - 5.5, e_top, 11, e_bot - e_top, fill=col)
            W.txt(bx, e_top - 12, metal, size=10.5, anchor="middle", fill=col, weight=700)
        sb = by - 24

        def bridge(g):
            g.move_to(xL + bw * 0.32, sb + 6)
            g.bezier_to(xL + bw * 0.5, sb - 34, xR - bw * 0.5, sb - 34, xR - bw * 0.32, sb + 6)
        W.stroke_path(bridge, stroke=C.data[3], width=12, opacity=0.65)
        W.stroke_path(bridge, stroke=C.data[2], width=1, dash="2 4", opacity=0.8)
        mid = (xL + xR) / 2
        W.txt(mid, sb - 40, "盐桥", size=9.5, anchor="middle", fill=C.faint)
        if S["ions"]:
            io = dim(2)
            W.arrow(mid - 26, sb - 20, mid + 8, sb - 20, C.data[2], 1.1, 5, opacity=io)
            W.txt(mid - 6, sb - 32, "K⁺ → 正极", size=9, anchor="middle", fill=C.soft, opacity=io)
            W.arrow(mid + 22, sb - 6, mid - 12, sb - 6, C.soft, 1.1, 5, opacity=io)
            W.txt(mid + 6, sb + 6, "← Cl⁻ 负极", size=9, anchor="middle", fill=C.soft, opacity=io)
        ro = dim(3)
        W.txt(xL, by + bh + 42, f"{L0['metal']} − 2e⁻ → {L0['ion']}", size=10, anchor="middle", weight=600, opacity=ro)
        W.txt(xR, by + bh + 42, f"{R0['ion']} + 2e⁻ → {R0['metal']}", size=10, anchor="middle", weight=600, opacity=ro)
        eo = dim(1)
        W.arrow(xL + 34, rail + 17, xL + 72, rail + 17, C.ink2, 1, 4, opacity=eo * 0.8)
        W.txt(xL + 80, rail + 17, "电子 e⁻", size=9, fill=C.soft, opacity=eo)
        W.txt(xL, rail - 12, "−", size=12, anchor="middle", weight=700, opacity=eo)
        W.txt(xR, rail - 12, "+", size=12, anchor="middle", weight=700, opacity=eo)
        for i in range(9):
            p = poly_at(pts, (S["phase"] + i / 9) % 1)
            W.circ(p[0], p[1], 3.1, fill=C.accent, opacity=eo if S["closed"] else 0.18)
        if not S["closed"]:
            W.txt(mx, my + mr + 13, "回路断开 · 无电流", size=9, anchor="middle", fill=C.faint)
    W.set(render)

    def tick(dt):
        if S["closed"]:
            S["phase"] = (S["phase"] + dt * 0.16) % 1
            W.redraw()
    W.L.loop(tick)
