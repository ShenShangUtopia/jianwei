"""学习助手的数据与逻辑（由 study.js 改写）：知识卡匹配、错题本、提示阶梯。不碰界面。"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..kit.home import load_json, save_json
from .data import bank
from .fx import fx

STARS = "stars.json"
_N = re.compile(r"[\s·・、，,。；;：:（）()《》「」“”\"'‘’\-—_+－]")
_cards = None


def cards():
    global _cards
    if _cards is None:
        _cards = json.loads((Path(__file__).parent / "cards.json").read_text(encoding="utf-8"))
    return _cards


def norm(s):
    return _N.sub("", str("" if s is None else s).lower())


def cut(s, n):
    s = re.sub(r"\s+", " ", str("" if s is None else s)).strip()
    return s[:n] + "…" if len(s) > n else s


def match_card(text):
    t = norm(text)
    data = cards()
    if not t:
        return data["generic"]
    best, best_score = None, 0
    for c in data["cards"]:
        sc = 0
        cn = norm(c["n"])
        if cn == t:
            sc = 1000
        elif cn in t or t in cn:
            sc = 400 + min(len(cn), len(t))
        for k in c["k"]:
            kk = norm(k)
            if not kk:
                continue
            if kk == t:
                sc = max(sc, 900)
            elif kk in t or t in kk:
                ln = min(len(kk), len(t))
                if ln >= 2:
                    sc = max(sc, 200 + ln * 10 + (30 if len(kk) >= 4 else 0))
        if sc > best_score:
            best_score, best = sc, c
    return best or data["generic"]


def _point_hit(pt, card, chip):
    p, c = norm(pt), norm(chip)
    if not p:
        return False
    if c and (p == c or c in p or p in c):
        return True
    for k in card["k"]:
        kk = norm(k)
        if len(kk) >= 2 and (kk in p or p in kk):
            return True
    return False


def related_to_card(card, chip, current=None):
    out = [q for q in bank.questions if any(_point_hit(p, card, chip) for p in q.get("points") or [])]
    if not out and card is cards()["generic"] and current:
        out = [current]
    return out


class Stars:
    """错题本：只存题目 id。"""

    def __init__(self):
        raw = load_json(STARS, [])
        self.ids = [x for x in raw if isinstance(x, str) and x] if isinstance(raw, list) else []

    def has(self, qid):
        return qid in self.ids

    def toggle(self, qid):
        if qid in self.ids:
            self.ids.remove(qid)
        else:
            self.ids.append(qid)
        save_json(STARS, self.ids)

    def questions(self):
        return [q for q in bank.questions if q["id"] in self.ids]


def asks_of(q):
    s = str(q.get("stem") or "")
    segs = [x.strip() for x in re.split(r"[。；;?？]", s) if x.strip()]
    want = [x for x in segs if re.search("求|则|是|判断|说明|多少|哪|试|写出", x)]
    return cut(want[-1] if want else segs[-1] if segs else s, 52)


def hint_html(level, q, key_color, foot_color):
    """三级提示：审题 → 方法 → 关键一步。level 0 返回空串。"""
    if not q or not level:
        return ""

    def row(k, v, plain=False):
        import html as _h
        return f"<div><span style='color:{key_color};font-weight:600'>{k}</span>　{_h.escape(str(v)) if plain else fx(v)}</div>"
    out = []
    if level >= 1:
        out.append(row("给了", cut(q.get("stem"), 76), True))
        out.append(row("要求", asks_of(q), True))
        out.append(f"<div style='color:{foot_color}'>先圈已知量与单位，再确认问的是哪个量。</div>")
    if level >= 2:
        pts = [str(p) for p in (q.get("points") or [])[:3]]
        if not pts:
            out.append(row("模型", "题干没标知识点：先写已知、待求，再找把它们连起来的公式。", True))
        else:
            c = match_card(pts[0])
            out.append(row("模型", "、".join(pts), True))
            out.append(row("公式", c["f"][0] if c.get("f") else f"这张卡没有固定公式，按「{c['n']}」的顺序走。"))
    if level >= 3:
        steps = q.get("steps") or []
        first = steps[0] if steps else None
        if isinstance(first, dict):
            first = first.get("text") or first.get("title")
        out.append(row("第一步", first or "这题没有拆步，先写出你认定的第一条关系式。", not first))
        out.append(f"<div style='color:{foot_color}'>只到这里，剩下的自己写；答案按钮先别按。</div>")
    return "".join(out)
