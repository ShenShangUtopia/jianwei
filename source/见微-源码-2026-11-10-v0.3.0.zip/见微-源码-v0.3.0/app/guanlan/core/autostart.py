"""Windows startup registration without console flashes.

We prefer the per-user Run key: it launches silently, survives folder moves
only until the next settings toggle, and is easy for a user to remove. Older
builds may have left a .vbs or .lnk in the Startup folder; both are cleaned up.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from .paths import ROOT

try:
    import winreg
except Exception:  # pragma: no cover - non-Windows fallback
    winreg = None

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
VALUE_NAME = "GuanlanDailyBrief"
STARTUP_NAME = "观澜 · 每日视界.vbs"
LEGACY_LINK = "观澜 · 每日视界.lnk"


def startup_dir() -> Path:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return ROOT
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def _command() -> str:
    if getattr(sys, "frozen", False):
        return f'"{Path(sys.executable)}" --background'
    python = Path(sys.executable)
    pythonw = python.with_name("pythonw.exe")
    if not pythonw.exists():
        pythonw = python
    return f'"{pythonw}" "{ROOT / "main.py"}" --background'


def _read_value() -> str | None:
    if winreg is None:
        return None
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ) as key:
            value, _ = winreg.QueryValueEx(key, VALUE_NAME)
            return str(value)
    except Exception:
        return None


def is_enabled() -> bool:
    # The registry is authoritative; old startup-folder leftovers also count
    # so a user can see and disable them from the settings sheet.
    if _read_value():
        return True
    return (startup_dir() / STARTUP_NAME).exists() or (startup_dir() / LEGACY_LINK).exists()


def _clean_startup_folder() -> None:
    for name in (STARTUP_NAME, LEGACY_LINK):
        path = startup_dir() / name
        try:
            if path.exists():
                path.unlink()
        except Exception:
            pass


def set_enabled(enabled: bool) -> tuple[bool, str]:
    if winreg is None:
        return False, "当前系统不支持注册表自启"
    try:
        if not enabled:
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                    winreg.DeleteValue(key, VALUE_NAME)
            except FileNotFoundError:
                pass
            except OSError:
                pass
            _clean_startup_folder()
            return True, "已关闭开机自启"

        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, VALUE_NAME, 0, winreg.REG_SZ, _command())
        _clean_startup_folder()
        return True, "已开启开机自启"
    except Exception as exc:
        return False, str(exc)
