"""Orchestrates one edition: collect, gate, enrich, score, select, save."""
from __future__ import annotations

import json
import logging
import os
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path

from .archive import save_edition
from .editorial import (
    EDITORIAL_TITLES, SECTION_META, SECTION_ORDER, WEIGHTS, DIMENSIONS,
)
from .filters import keywords_for, prepare, select_news
from .library import choose_editorial, editorial_ids, update_history
from .paths import (
    ARCHIVE_DIR, DATA_DIR, EDITIONS_DIR, HISTORY_PATH, INDEX_PATH, LATEST_PATH,
    LOG_DIR, ROOT, ensure_dirs, load_config,
)
from .sources import enrich_candidates, fetch_all, fetch_article_context

log = logging.getLogger("guanlan")


def _setup_logging() -> None:
    ensure_dirs()
    if log.handlers:
        return
    log.setLevel(logging.INFO)
    handler = logging.FileHandler(LOG_DIR / "curator.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    log.addHandler(handler)
    log.propagate = False


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _atomic_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _weekday_cn(dt: datetime) -> str:
    return "周" + "一二三四五六日"[dt.weekday()]


def _short_time(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso)
        return dt.strftime("%m-%d %H:%M")
    except Exception:
        return (iso or "")[:16].replace("T", " ")


def _display_title(title: str) -> str:
    return re.sub(
        r"^(国际观察|新闻分析|记者手记|热点问答|全球连线|专访|观察|聚焦|深度|特稿|推荐)[\s丨｜|]+",
        "",
        title or "",
    ).strip()


def _clip(text: str, limit: int) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    for sep in ("。", "！", "？", "；"):
        idx = cut.rfind(sep)
        if idx >= limit * 0.55:
            return cut[: idx + 1]
    return cut.rstrip("，、, ") + "…"


def _story_dict(item) -> dict:
    detail = _clip(item.full_summary or item.summary or "", 620)
    summary = _clip(detail or item.summary or "", 155)
    tags = [t for t in (item.tags or []) if t not in ("中国", "全球", "亚太", "欧洲", "美国", "中东", "拉美", "非洲", "亚洲")]
    if not tags:
        tags = list(item.themes or [])[:2]
    return {
        "id": item.id,
        "title": item.title,
        "display_title": _display_title(item.title),
        "url": item.url,
        "source": item.source,
        "published": item.published.isoformat(),
        "published_display": _short_time(item.published.isoformat()),
        "region": item.region,
        "theme": (item.themes or ["社会民生"])[0],
        "themes": item.themes or [],
        "lens": item.lens,
        "question": item.question,
        "why": item.why,
        "summary": summary,
        "detail": detail,
        "scores": {k: round(v, 1) for k, v in item.scores.items()},
        "total": round(item.total, 1),
        "tags": tags[:4],
        "read_minutes": max(2, min(9, round(len(detail) / 260 + 1))),
        "section": item.section,
        "section_label": "今日焦点" if item.section == "lead" else SECTION_META.get(item.section, {}).get("label", ""),
    }


def _edition_title(lead) -> str:
    theme = (lead.themes or ["社会民生"])[0]
    return EDITORIAL_TITLES.get(theme, "今天，世界在这些地方转弯")


CONCRETE_KEYWORDS = [
    "APEC", "欧盟", "能源通道", "人工智能", "生物多样性", "新能源汽车",
    "贸易规则", "供应链", "全球治理", "气候", "人口", "航天", "教育",
]


def _keywords(selected_stories, lead) -> list[str]:
    items = [lead] + selected_stories
    present = {tag for item in items for tag in (item.tags or [])}
    out = [word for word in CONCRETE_KEYWORDS if word in present]
    if len(out) < 5:
        counter: Counter = Counter()
        for item in items:
            for tag in item.tags or []:
                if tag in ("中国", "全球", "亚太", "欧洲", "美国", "中东", "拉美", "非洲", "亚洲"):
                    continue
                counter[tag] += 1
        for word, _ in counter.most_common(12):
            if word not in out:
                out.append(word)
            if len(out) >= 5:
                break
    if len(out) < 3:
        for item in items:
            for theme in (item.themes or [])[:1]:
                if theme not in out:
                    out.append(theme)
                if len(out) >= 5:
                    break
    return out[:5]


def _build_edition(lead, selected_stories, stats, initial_prep, final_prep, cfg, existing) -> tuple[dict, dict]:
    now = datetime.now().astimezone()
    date_str = now.date().isoformat()
    themes: list[str] = []
    for item in [lead] + selected_stories:
        for theme in item.themes or []:
            if theme not in themes:
                themes.append(theme)

    # Preserve the humanistic picks during same-day refreshes.
    existing_ids = None
    if existing and existing.get("date") == date_str and existing.get("editorial_ids"):
        existing_ids = existing["editorial_ids"]
    history = _read_json(HISTORY_PATH, {})
    editorial = choose_editorial(date_str, themes, history, existing_ids)

    keywords = _keywords(selected_stories, lead)
    if len(keywords) < 3:
        keywords += [t for t in themes if t not in keywords][: 4 - len(keywords)]
    subtitle = "从“{}”到“{}”，{} 条线索，拼出今天的世界坐标。".format(
        keywords[0] if keywords else lead.region,
        keywords[1] if len(keywords) > 1 else (lead.themes[0] if lead.themes else "世界"),
        len(selected_stories) + 1,
    )

    scores_avg = {}
    for key in WEIGHTS:
        vals = [getattr(item, "scores", {}).get(key, 0) for item in [lead] + selected_stories]
        scores_avg[key] = round(sum(vals) / max(1, len(vals)), 1)
    funnel = {
        "fetched": initial_prep["funnel"]["fetched"],
        "gate_pass": initial_prep["funnel"]["gate_pass"],
        "deduped": final_prep["funnel"]["deduped"],
        "selected": len(selected_stories) + 1,
    }
    selected_ids = {item.id for item in [lead] + selected_stories}
    candidate_rows = []
    for c in final_prep["scored"][:30]:
        candidate_rows.append({
            "title": _display_title(c.title),
            "score": round(c.total, 1),
            "total": round(c.total, 1),
            "source": c.source,
            "region": c.region,
            "selected": c.id in selected_ids,
        })
    source_dist = dict(Counter(item.source for item in [lead] + selected_stories))
    region_dist = dict(Counter(item.region for item in [lead] + selected_stories))
    selection = {
        "funnel": funnel,
        "sources": sorted(source_dist),
        "regions": sorted(region_dist),
        "source_distribution": source_dist,
        "region_distribution": region_dist,
        "weights": dict(cfg.get("weights") or WEIGHTS),
        "averages": scores_avg,
        "rejected_reasons": initial_prep["reasons"].most_common(10),
        "source_stats": stats.get("sources", {}),
        "fetch_errors": stats.get("errors", []),
        "candidate_pool": candidate_rows,
        "notes": [
            "硬门槛先排除标题党、软新闻、消费电子、猎奇与未证实传闻",
            "六维加权评分：信源 20% / 结构 28% / 影响 18% / 时效 10% / 可读 12% / 高考适配 12%",
            "结构约束：同源 ≤3、同地区 ≤3，至少 4 个来源、3 个地区",
            "标题相似度 + 摘要指纹双重去重，同题只留一个版本",
        ],
    }

    lead_dict = _story_dict(lead)
    lead_dict["section"] = "lead"
    lead_dict["section_label"] = "今日焦点"
    stories = [_story_dict(c) for c in selected_stories]
    stories.sort(key=lambda x: (SECTION_ORDER.index(x["section"]) if x["section"] in SECTION_ORDER else 9, -x["total"]))

    edition = {
        "date": date_str,
        "date_label": now.strftime("%Y.%m.%d"),
        "weekday": _weekday_cn(now),
        "generated_at": now.isoformat(timespec="seconds"),
        "edition": (existing or {}).get("edition") or len(_read_json(INDEX_PATH, [])) + 1,
        "title": _edition_title(lead),
        "subtitle": subtitle,
        "keywords": keywords[:5],
        "lead": lead_dict,
        "stories": stories,
        "sections": {
            section: [s for s in stories if s["section"] == section]
            for section in SECTION_ORDER
        },
        "person": editorial["person"],
        "person_alternates": editorial["people_alternates"],
        "quotes": editorial["quotes"],
        "term": editorial["term"],
        "editorial_ids": editorial_ids(date_str, editorial),
        "selection": selection,
        "read_count": len(stories) + 1,
        "reading_minutes": min(18, 8 + len(stories) + 1),
        "archive_path": f"档案库/{date_str[:4]}/{date_str[5:7]}/{date_str}",
        "source_count": stats.get("source_count", 0),
        "fetch_errors": stats.get("errors", []),
    }
    return edition, history


def run(force: bool = False, log_fn=print) -> dict:
    _setup_logging()
    ensure_dirs()
    cfg = load_config()
    now = datetime.now().astimezone()
    today = now.date().isoformat()

    existing = _read_json(LATEST_PATH, None)
    yesterday = (now.date() - timedelta(days=1)).isoformat()
    previous = _read_json(EDITIONS_DIR / f"{yesterday}.json", None)
    if previous is None and existing and existing.get("date") != today:
        previous = existing
    if existing and existing.get("date") == today:
        try:
            generated = datetime.fromisoformat(existing["generated_at"])
            age_min = (now - generated).total_seconds() / 60
        except Exception:
            age_min = 9999
        if age_min < 120 and not force:
            log.info("reuse same-day edition age=%.1f min", age_min)
            return {"ok": True, "edition": existing, "reused": True}

    log.info("fetch start force=%s", force)
    log_fn("连接信源，抓取今日候选…")
    candidates, stats, errors, elapsed = fetch_all()
    if not candidates:
        raise RuntimeError("今天没有抓到任何新闻，请检查网络后重试。")

    weights = cfg.get("weights") or WEIGHTS
    initial = prepare(candidates, weights)
    log.info("fetched=%s gate=%s deduped=%s", stats["fetched"], initial["funnel"]["gate_pass"], initial["funnel"]["deduped"])
    log_fn(f"已抓取 {stats['fetched']} 条，进入精读…")
    changed = enrich_candidates(initial["gate_pass"], 42)
    final = prepare(initial["gate_pass"], weights)
    lead, chosen, diag = select_news(final["scored"], int(cfg.get("max_stories", 7)), previous=previous)
    if not lead:
        raise RuntimeError("筛选后没有可用的头条，请稍后重试。")
    selected = [c for c in chosen if c.id != lead.id]
    log.info("enriched=%s selected=%s sources=%s", changed, len(selected) + 1, diag["sources"])
    log_fn(f"精排完成：{len(selected) + 1} 条入选，正在补全上下文…")

    # Give the reader a little more than a one-line wire summary.
    need_context = [c for c in [lead] + selected if len(c.summary or "") < 300]
    if need_context:
        with ThreadPoolExecutor(max_workers=7) as pool:
            future_map = {pool.submit(fetch_article_context, c.url, c.title): c for c in need_context}
            for future in as_completed(future_map):
                c = future_map[future]
                try:
                    ctx = future.result()
                except Exception:
                    ctx = ""
                if ctx and len(ctx) > len(c.summary or ""):
                    c.full_summary = ctx
    for c in [lead] + selected:
        if not c.full_summary:
            c.full_summary = c.summary

    edition, history = _build_edition(lead, selected, stats, initial, final, cfg, existing)
    day_dir = ARCHIVE_DIR / edition["date"][:4] / edition["date"][5:7] / edition["date"]
    index_entry = {
        "date": edition["date"],
        "weekday": edition["weekday"],
        "title": edition["title"],
        "lead": edition["lead"]["display_title"],
        "read_count": edition["read_count"],
        "reading_minutes": edition["reading_minutes"],
        "keywords": edition["keywords"],
        "sources": edition["selection"]["sources"],
        "path": edition["archive_path"],
        "generated_at": edition["generated_at"],
    }
    saved = save_edition(edition, edition["selection"]["candidate_pool"], index_entry)
    edition["archive_dir"] = saved["archive_dir"]
    edition["archive_files"] = saved["files"]
    # Persist the archive paths in the app's copy too.
    _atomic_json(EDITIONS_DIR / f"{edition['date']}.json", edition)
    _atomic_json(LATEST_PATH, edition)

    history = update_history(history, edition["date"], {
        "person": edition["person"],
        "people_alternates": edition["person_alternates"],
        "quotes": edition["quotes"],
        "term": edition["term"],
    })
    _atomic_json(HISTORY_PATH, history)
    log.info("saved archive=%s", saved["archive_dir"])
    return {"ok": True, "edition": edition, "saved": saved, "stats": stats}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="观澜每日内容筛选器")
    parser.add_argument("--force", action="store_true", help="强制重新抓取")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    result = run(force=args.force, log_fn=(lambda *_: None) if args.quiet else print)
    print(json.dumps({
        "ok": result.get("ok"),
        "date": result["edition"]["date"],
        "read_count": result["edition"]["read_count"],
        "archive": result["edition"].get("archive_path"),
        "sources": result["edition"]["selection"]["sources"],
    }, ensure_ascii=False, indent=2))
