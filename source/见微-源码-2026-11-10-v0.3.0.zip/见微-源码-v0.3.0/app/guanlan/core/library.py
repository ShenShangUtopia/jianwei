"""Daily selection of people, lines and a world-affairs term.

The news is live; these three sections are curated libraries. They rotate
without repeating recent choices, and prefer entries that resonate with the
day's news without forcing a false connection.
"""
from __future__ import annotations

import random
from datetime import date

from .library_people import PEOPLE
from .library_quotes import QUOTES
from .library_terms import TERMS

PERSON_THEME_TAGS = {
    "科技": ["科学", "技术", "航天", "医学", "计算", "工程", "人工智能", "天文"],
    "气候": ["生态", "自然", "土地", "粮食安全", "环保", "环境"],
    "经济": ["经济", "粮食安全", "发展", "商业", "金融"],
    "外交": ["和平", "和解", "民权", "国际", "自由", "正义", "非暴力", "公共"],
    "社会": ["教育", "女性", "乡村", "医学", "社会", "公共", "生命", "职业精神"],
    "文化": ["文学", "文化", "思想", "艺术", "教育", "写作", "启蒙"],
    "安全": ["战争", "核", "安全", "冲突", "密码", "工程"],
    "能源": ["能源", "资源", "电池"],
    "政治": ["政治", "制度", "改革", "法治", "独立"],
}

QUOTE_THEME_TAGS = {
    "外交": ["责任", "公共", "他人", "世界", "和平", "正义", "制度", "规则"],
    "经济": ["生活", "奋斗", "实践", "时间", "行动", "具体"],
    "科技": ["科学", "理性", "思考", "未来", "问题", "深度"],
    "气候": ["自然", "生命", "希望", "未来", "生活"],
    "社会": ["具体", "爱", "他人", "责任", "尊严", "教育", "公共"],
    "文化": ["文明", "诗意", "记忆", "语言", "美", "自我"],
    "安全": ["勇气", "正义", "历史", "批判", "反抗"],
    "能源": ["行动", "未来", "困难", "勇气"],
    "政治": ["制度", "公共", "历史", "自由", "判断"],
}

TERM_THEME_TAGS = {
    "外交": ["全球治理", "多极化", "大国关系", "合作", "中国", "公共品"],
    "经济": ["经济", "供应链", "贸易", "发展", "制度", "产业"],
    "科技": ["科技", "治理", "规则", "人工智能"],
    "气候": ["气候", "发展", "全球治理", "公共品"],
    "社会": ["人口", "社会", "发展", "文化"],
    "能源": ["能源", "供应链", "资源"],
    "安全": ["安全", "大国关系", "历史", "霸权"],
    "文化": ["文化", "文明", "传播"],
    "政治": ["制度", "历史", "霸权", "全球治理"],
}


def _theme_weights(story_themes: list[str]) -> dict[str, float]:
    weights: dict[str, float] = {}
    for idx, theme in enumerate(story_themes):
        weights[theme] = weights.get(theme, 0) + (2.0 if idx == 0 else 1.0)
    return weights


def _entry_score(tags: list[str], weights: dict[str, float], mapping: dict[str, list[str]]) -> float:
    score = 0.0
    for theme, weight in weights.items():
        wanted = mapping.get(theme, [])
        for tag in tags:
            if tag in wanted:
                score += weight
    return score


def _pick_unseen(items: list[dict], recent: set[str], rng: random.Random) -> list[dict]:
    pool = [x for x in items if x.get("id") not in recent]
    if len(pool) < 3:
        pool = list(items)
    return pool


def choose_editorial(date_str: str, story_themes: list[str], history: dict, existing: dict | None = None) -> dict:
    weights = _theme_weights(story_themes)
    rng = random.Random(f"{date_str}-guanlan")

    # Same-day refresh keeps the same humanistic picks, so the edition feels
    # like one day rather than a slot machine.
    if existing:
        by_person = {p["id"]: p for p in PEOPLE}
        by_quote = {q["id"]: q for q in QUOTES}
        by_term = {t["id"]: t for t in TERMS}
        people = [by_person[x] for x in existing.get("people_ids", []) if x in by_person]
        quotes = [by_quote[x] for x in existing.get("quote_ids", []) if x in by_quote]
        term = by_term.get(existing.get("term_id"))
        if len(people) >= 3 and len(quotes) >= 3 and term:
            return {
                "person": people[0],
                "people_alternates": people[1:3],
                "quotes": quotes[:3],
                "term": term,
            }

    recent_people = set(history.get("people", [])[-45:])
    people_pool = _pick_unseen(PEOPLE, recent_people, rng)
    scored_people = sorted(
        people_pool,
        key=lambda p: (-_entry_score(p.get("tags", []), weights, PERSON_THEME_TAGS), rng.random()),
    )
    people = scored_people[:3]
    if len(people) < 3:
        people = (people + PEOPLE[:3])[:3]

    recent_quotes = set(history.get("quotes", [])[-50:])
    quote_pool = _pick_unseen(QUOTES, recent_quotes, rng)
    theme_sorted = sorted(
        quote_pool,
        key=lambda q: (-_entry_score(q.get("tags", []), weights, QUOTE_THEME_TAGS), rng.random()),
    )
    resilient = sorted(
        [q for q in quote_pool if set(q.get("tags", [])) & {"韧性", "行动", "坚持", "勇气", "奋斗"}],
        key=lambda q: rng.random(),
    )
    spacious = sorted(
        [q for q in quote_pool if set(q.get("tags", [])) & {"视野", "文明", "自我", "时间", "诗意", "生活"}],
        key=lambda q: rng.random(),
    )
    chosen_quotes: list[dict] = []
    for pool in (theme_sorted, resilient, spacious, quote_pool):
        for q in pool:
            if len(chosen_quotes) >= 3:
                break
            if q in chosen_quotes:
                continue
            if any(q.get("author") == x.get("author") for x in chosen_quotes):
                continue
            chosen_quotes.append(q)
        if len(chosen_quotes) >= 3:
            break
    if len(chosen_quotes) < 3:
        for q in quote_pool:
            if q not in chosen_quotes:
                chosen_quotes.append(q)
            if len(chosen_quotes) >= 3:
                break

    recent_terms = set(history.get("terms", [])[-24:])
    term_pool = [t for t in TERMS if t.get("id") not in recent_terms]
    if not term_pool:
        term_pool = list(TERMS)
    term = sorted(
        term_pool,
        key=lambda t: (-_entry_score(t.get("tags", []), weights, TERM_THEME_TAGS), rng.random()),
    )[0]

    return {
        "person": people[0],
        "people_alternates": people[1:3],
        "quotes": chosen_quotes[:3],
        "term": term,
    }


def update_history(history: dict, date_str: str, editorial: dict) -> dict:
    history = dict(history or {})
    for key, values in (
        ("people", [editorial["person"]["id"]] + [p["id"] for p in editorial["people_alternates"]]),
        ("quotes", [q["id"] for q in editorial["quotes"]]),
        ("terms", [editorial["term"]["id"]]),
    ):
        arr = list(history.get(key, []))
        for value in values:
            if value in arr:
                arr.remove(value)
            arr.append(value)
        history[key] = arr[-120:]
    history["last_edition"] = date_str
    history.setdefault("editions", {})[date_str] = {
        "people": [editorial["person"]["id"]] + [p["id"] for p in editorial["people_alternates"]],
        "quotes": [q["id"] for q in editorial["quotes"]],
        "term": editorial["term"]["id"],
    }
    # Keep the index of per-day editorial picks bounded.
    if len(history["editions"]) > 120:
        for old_key in sorted(history["editions"])[:-120]:
            history["editions"].pop(old_key, None)
    return history


def editorial_ids(date_str: str, editorial: dict) -> dict:
    return {
        "date": date_str,
        "people_ids": [editorial["person"]["id"]] + [p["id"] for p in editorial["people_alternates"]],
        "quote_ids": [q["id"] for q in editorial["quotes"]],
        "term_id": editorial["term"]["id"],
    }
