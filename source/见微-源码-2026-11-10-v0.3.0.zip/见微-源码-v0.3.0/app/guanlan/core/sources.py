"""Collect candidates from a small, deliberately chosen set of sources.

We use RSS where it exists and lightweight HTML parsing where it does not.
No browser, no login, no full-text scraping: the curator only needs enough
context to judge and introduce a story, and readers are sent to the source.
"""
from __future__ import annotations

import html
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from urllib.parse import urljoin, urlparse
from xml.etree import ElementTree as ET

import requests
from bs4 import BeautifulSoup

from .editorial import SOURCE_PRIORITY, SOURCE_TIER

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
}

TAG_RE = re.compile(r"<[^>]+>")
SPACE_RE = re.compile(r"\s+")
DATE_PATH_RE = re.compile(r"/((?:20\d{2})[/-]?\d{2}[/-]?\d{2})/")


@dataclass
class Candidate:
    title: str
    url: str
    source: str
    published: datetime
    summary: str = ""
    origin: str = ""
    kind: str = "news"
    region: str = ""
    themes: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    china_relevance: bool = False
    scores: dict = field(default_factory=dict)
    total: float = 0.0
    section: str = ""
    why: str = ""
    question: str = ""
    lens: str = ""
    read_minutes: int = 2
    full_summary: str = ""
    id: str = ""

    @property
    def source_tier(self) -> int:
        return SOURCE_TIER.get(self.source, 3)

    @property
    def priority(self) -> int:
        return SOURCE_PRIORITY.get(self.source, 50)


def now_local() -> datetime:
    return datetime.now().astimezone()


def clean_text(raw: str, limit: int = 600) -> str:
    if not raw:
        return ""
    text = html.unescape(str(raw))
    text = TAG_RE.sub(" ", text)
    text = text.replace("\u3000", " ").replace("\xa0", " ")
    text = SPACE_RE.sub(" ", text).strip()
    text = re.sub(r"^(新华社|中新社|人民网|澎湃新闻|联合国新闻)[^。]{0,28}?电[（(][^）)]*[）)]", "", text).strip()
    text = re.sub(r"^\s*[（(][^）)]{0,20}[）)]\s*", "", text)
    if len(text) > limit:
        cut = text[:limit]
        for sep in ("。", "！", "？", "；"):
            idx = cut.rfind(sep)
            if idx >= limit * 0.55:
                return cut[: idx + 1]
        return cut.rstrip("，、, ") + "…"
    return text


def _decode(resp: requests.Response) -> str:
    raw = resp.content
    if not raw:
        return ""
    for enc in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def safe_get(url: str, timeout: tuple[int, int] = (8, 22)) -> requests.Response | None:
    for attempt in range(2):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=timeout)
            if resp.status_code < 400 and resp.content:
                return resp
        except Exception:
            if attempt == 0:
                time.sleep(0.4)
    return None


def _parse_date(value: str, fallback: datetime | None = None) -> datetime:
    value = (value or "").strip()
    if value:
        try:
            dt = parsedate_to_datetime(value)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=now_local().tzinfo)
            return dt.astimezone()
        except Exception:
            pass
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d", "%Y年%m月%d日"):
            try:
                dt = datetime.strptime(value[:19] if "%H" in fmt else value[:10], fmt)
                return dt.replace(tzinfo=now_local().tzinfo)
            except Exception:
                continue
    return fallback or now_local()


def _rss_items(text: str, source: str, origin: str, default_kind: str = "news") -> list[Candidate]:
    if not text:
        return []
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
    try:
        root = ET.fromstring(text)
    except Exception:
        # Malformed feeds: fall back to a forgiving regex parse.
        items = re.findall(r"<item[^>]*>(.*?)</item>", text, re.S | re.I)
        out = []
        for item in items:
            title = re.search(r"<title[^>]*>(.*?)</title>", item, re.S | re.I)
            link = re.search(r"<link[^>]*>(.*?)</link>", item, re.S | re.I)
            desc = re.search(r"<description[^>]*>(.*?)</description>", item, re.S | re.I)
            pub = re.search(r"<pubDate[^>]*>(.*?)</pubDate>", item, re.S | re.I)
            if title and link:
                out.append(Candidate(
                    title=clean_text(html.unescape(title.group(1)), 140),
                    url=clean_text(html.unescape(link.group(1)), 500),
                    source=source,
                    published=_parse_date(pub.group(1) if pub else ""),
                    summary=clean_text(desc.group(1) if desc else "", 420),
                    origin=origin,
                    kind=default_kind,
                ))
        return out

    out: list[Candidate] = []
    for node in root.iter():
        tag = node.tag.split("}")[-1].lower()
        if tag not in ("item", "entry"):
            continue
        def child(name: str) -> str:
            for c in node:
                if c.tag.split("}")[-1].lower() == name:
                    return c.text or ""
            return ""
        title = child("title")
        link = child("link")
        if not link:
            for c in node:
                if c.tag.split("}")[-1].lower() == "link":
                    link = c.attrib.get("href", "")
                    break
        desc = child("description") or child("summary") or child("content")
        pub = child("pubdate") or child("published") or child("updated")
        if not title or not link:
            continue
        out.append(Candidate(
            title=clean_text(html.unescape(title), 140),
            url=clean_text(html.unescape(link), 500),
            source=source,
            published=_parse_date(pub),
            summary=clean_text(html.unescape(desc), 420),
            origin=origin,
            kind=default_kind,
        ))
    return out


def fetch_cns_world() -> list[Candidate]:
    url = "https://www.chinanews.com.cn/rss/world.xml"
    resp = safe_get(url)
    if not resp:
        raise RuntimeError("中新网国际 RSS 无响应")
    return _rss_items(_decode(resp), "中国新闻网", url)[:35]


def fetch_cns_scroll() -> list[Candidate]:
    url = "https://www.chinanews.com.cn/rss/scroll-news.xml"
    resp = safe_get(url)
    if not resp:
        raise RuntimeError("中新网滚动 RSS 无响应")
    return _rss_items(_decode(resp), "中国新闻网", url)[:35]


def _scrape_news_list(url: str, source: str, domain: str, date_pattern: re.Pattern, limit: int = 45) -> list[Candidate]:
    resp = safe_get(url)
    if not resp:
        raise RuntimeError(f"{source} 页面无响应")
    text = _decode(resp)
    soup = BeautifulSoup(text, "html.parser")
    out: list[Candidate] = []
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        title = clean_text(a.get_text(" ", strip=True), 140)
        if not (8 <= len(title) <= 96):
            continue
        href = urljoin(url, a["href"])
        if domain not in urlparse(href).netloc:
            continue
        if not date_pattern.search(href):
            continue
        if href in seen:
            continue
        seen.add(href)
        m = re.search(r"/(20\d{2})[/-]?(\d{2})[/-]?(\d{2})/", href)
        if m:
            try:
                published = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), 12, 0, tzinfo=now_local().tzinfo)
            except Exception:
                published = now_local()
        else:
            published = now_local()
        out.append(Candidate(
            title=title,
            url=href,
            source=source,
            published=published,
            origin=url,
            kind="news",
        ))
        if len(out) >= limit:
            break
    return out


def fetch_xinhua_world() -> list[Candidate]:
    return _scrape_news_list(
        "https://www.news.cn/world/",
        "新华网",
        "news.cn",
        re.compile(r"/20\d{6}/[0-9a-f]{20,}/c\.html"),
        limit=50,
    )


def fetch_people_world() -> list[Candidate]:
    return _scrape_news_list(
        "https://world.people.com.cn/",
        "人民网",
        "people.com.cn",
        re.compile(r"/n1/20\d{2}/\d{4}/c\d+-\d+\.html"),
        limit=50,
    )


def fetch_un_news() -> list[Candidate]:
    url = "https://news.un.org/feed/subscribe/zh/news/all/rss.xml"
    resp = safe_get(url)
    if not resp:
        raise RuntimeError("联合国新闻 RSS 无响应")
    return _rss_items(_decode(resp), "联合国新闻", url)[:35]


def _walk_paper(obj, found: list):
    if isinstance(obj, dict):
        if obj.get("name") and (obj.get("contId") or obj.get("link")) and (obj.get("publishTime") or obj.get("pubTimeLong")):
            found.append(obj)
        for value in obj.values():
            if isinstance(value, (dict, list)):
                _walk_paper(value, found)
    elif isinstance(obj, list):
        for value in obj:
            _walk_paper(value, found)


def fetch_thepaper() -> list[Candidate]:
    url = "https://www.thepaper.cn/"
    resp = safe_get(url)
    if not resp:
        raise RuntimeError("澎湃新闻页面无响应")
    soup = BeautifulSoup(_decode(resp), "html.parser")
    tag = soup.find("script", id="__NEXT_DATA__")
    out: list[Candidate] = []
    seen: set[str] = set()
    if tag and tag.string:
        try:
            data = json.loads(tag.string)
            found: list = []
            _walk_paper(data, found)
            for item in found:
                title = clean_text(item.get("name", ""), 140)
                link = item.get("link") or ""
                if not title or title in seen:
                    continue
                if link.startswith("/"):
                    link = "https://www.thepaper.cn" + link
                if not link.startswith("http"):
                    cont = item.get("contId")
                    if not cont:
                        continue
                    link = f"https://www.thepaper.cn/newsDetail_forward_{cont}"
                published = now_local()
                pt = item.get("publishTime")
                if pt:
                    published = _parse_date(pt, published)
                elif item.get("pubTimeLong"):
                    try:
                        published = datetime.fromtimestamp(int(item["pubTimeLong"]) / 1000, tz=now_local().tzinfo)
                    except Exception:
                        pass
                seen.add(title)
                out.append(Candidate(
                    title=title,
                    url=link,
                    source="澎湃新闻",
                    published=published,
                    origin=url,
                    kind="news",
                ))
        except Exception:
            pass
    if len(out) < 8:
        # Forgiving fallback: anchors on the page.
        for a in soup.find_all("a", href=True):
            title = clean_text(a.get_text(" ", strip=True), 140)
            href = urljoin(url, a["href"])
            if 10 <= len(title) <= 90 and "newsDetail" in href and title not in seen:
                seen.add(title)
                out.append(Candidate(title=title, url=href, source="澎湃新闻", published=now_local(), origin=url))
    return out[:40]


def fetch_ithome() -> list[Candidate]:
    url = "https://www.ithome.com/rss/"
    resp = safe_get(url)
    if not resp:
        raise RuntimeError("IT之家 RSS 无响应")
    return _rss_items(_decode(resp), "IT之家", url, default_kind="tech")[:35]


SOURCES = [
    ("新华网·国际", fetch_xinhua_world),
    ("人民网·国际", fetch_people_world),
    ("中国新闻网·国际", fetch_cns_world),
    ("中国新闻网·滚动", fetch_cns_scroll),
    ("联合国新闻", fetch_un_news),
    ("澎湃新闻", fetch_thepaper),
    ("IT之家", fetch_ithome),
]


def fetch_all() -> tuple[list[Candidate], dict, list[str], float]:
    started = time.time()
    candidates: list[Candidate] = []
    errors: list[str] = []
    per_source: dict[str, int] = {}

    with ThreadPoolExecutor(max_workers=7) as pool:
        future_map = {pool.submit(fn): label for label, fn in SOURCES}
        for future in as_completed(future_map):
            label = future_map[future]
            try:
                items = future.result()
                # Keep the original source label separate from display source.
                for item in items:
                    item.origin = item.origin or label
                candidates.extend(items)
                per_source[label] = len(items)
            except Exception as exc:
                errors.append(f"{label}: {exc}")
                per_source[label] = 0

    # Deduplicate exact URLs early.
    unique: dict[str, Candidate] = {}
    for item in candidates:
        key = item.url.split("#")[0].strip()
        if not key:
            continue
        if key not in unique or item.priority > unique[key].priority:
            unique[key] = item
    candidates = list(unique.values())
    elapsed = round(time.time() - started, 1)
    stats = {
        "fetched": len(candidates),
        "sources": per_source,
        "errors": errors,
        "elapsed": elapsed,
        "source_count": len([n for n in per_source.values() if n > 0]),
    }
    return candidates, stats, errors, elapsed


def fetch_article_context(url: str, title: str) -> str:
    """Fetch a small amount of context for a selected item, if missing."""
    try:
        host = urlparse(url).netloc
        if not host:
            return ""
        resp = safe_get(url, timeout=(5, 12))
        if not resp:
            return ""
        soup = BeautifulSoup(_decode(resp), "html.parser")
        title_key = re.sub(r"\W+", "", title)[:18]
        meta = None
        for sel in (
            'meta[name="description"]',
            'meta[property="og:description"]',
            'meta[name="Description"]',
        ):
            node = soup.select_one(sel)
            if node and node.get("content"):
                meta = clean_text(node["content"], 360)
                if len(meta) >= 40 and re.sub(r"\W+", "", meta)[:18] != title_key:
                    break
                meta = None
        paragraphs: list[str] = []
        total = 0
        for p in soup.find_all("p"):
            text = clean_text(p.get_text(" ", strip=True), 300)
            if len(text) < 45 or re.search(r"责任编辑|版权声明|免责声明|举报|扫一扫|来源：", text):
                continue
            if re.sub(r"\W+", "", text)[:18] == title_key:
                continue
            paragraphs.append(text)
            total += len(text)
            if total >= 360:
                break
        joined = " ".join(paragraphs)[:480]
        if meta and len(meta) >= 240:
            return meta
        if joined and (not meta or len(joined) >= len(meta) + 50):
            return joined
        return meta or joined
    except Exception:
        return ""
    return ""


def enrich_candidates(items: list[Candidate], limit: int = 45) -> int:
    """Add a short contextual paragraph to scraped items that lack a summary."""
    from .editorial import STRUCTURAL_GROUPS

    def title_signal(item: Candidate) -> int:
        score = 0
        if any(k in item.title for k in ("观察", "分析", "问答", "解读", "专访", "记者手记")):
            score += 8
        if any(k in item.title for k in ("APEC", "欧盟", "联合国", "伊朗", "美国", "人工智能", "气候", "贸易", "峰会", "预算")):
            score += 7
        if any(k in item.title for words in STRUCTURAL_GROUPS.values() for k in words):
            score += 3
        return score

    need = [
        item for item in items
        if len(item.summary or "") < 45 and item.url.startswith("http")
        and (now_local() - item.published).total_seconds() / 3600 < 90
    ]
    need.sort(key=lambda c: (-(c.priority + title_signal(c)), -c.published.timestamp()))
    need = need[:limit]
    if not need:
        return 0
    changed = 0
    with ThreadPoolExecutor(max_workers=10) as pool:
        future_map = {pool.submit(fetch_article_context, item.url, item.title): item for item in need}
        for future in as_completed(future_map):
            item = future_map[future]
            try:
                context = future.result()
            except Exception:
                context = ""
            if context and len(context) > len(item.summary or ""):
                item.summary = context
                item.kind = "enriched"
                changed += 1
    return changed
