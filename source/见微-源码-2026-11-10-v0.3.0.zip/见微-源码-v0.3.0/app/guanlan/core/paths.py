"""Path and configuration helpers for Guanlan."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

APP_NAME = "观澜"
APP_SUBTITLE = "每日视界"


def base_dir() -> Path:
    # 见微内嵌模式：数据目录与源码分离，避免污染独立版观澜
    home = os.environ.get("JIANWEI_GUANLAN_HOME")
    if home:
        return Path(home)
    if getattr(sys, "frozen", False):
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
        return base / "Jianwei" / "guanlan"
    return Path(__file__).resolve().parents[1]


CODE_DIR = Path(__file__).resolve().parents[1]


ROOT = base_dir()
DATA_DIR = ROOT / "data"
EDITIONS_DIR = DATA_DIR / "editions"
ARCHIVE_DIR = ROOT / "档案库"
LOG_DIR = ROOT / "logs"
CONFIG_PATH = ROOT / "config.json"
HISTORY_PATH = DATA_DIR / "history.json"
LATEST_PATH = DATA_DIR / "latest.json"
INDEX_PATH = DATA_DIR / "index.json"
ASSET_DIR = Path(getattr(sys, "_MEIPASS", CODE_DIR)) / "assets"

DEFAULT_CONFIG = {
    "update_time": "07:15",
    "auto_start": True,
    "auto_collapse_seconds": 180,
    "auto_play": False,
    "auto_play_seconds": 12,
    "hide_on_fullscreen": True,
    "always_on_top": False,
    "opacity": 0.99,
    "max_stories": 7,
    "weights": {
        "authority": 0.20,
        "structure": 0.28,
        "impact": 0.18,
        "freshness": 0.10,
        "readability": 0.12,
        "exam_fit": 0.12,
    },
    "first_run_done": False,
}


def ensure_dirs() -> None:
    for d in (DATA_DIR, EDITIONS_DIR, ARCHIVE_DIR, LOG_DIR):
        d.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    ensure_dirs()
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))
            if isinstance(raw, dict):
                cfg.update(raw)
                merged_weights = dict(DEFAULT_CONFIG["weights"])
                merged_weights.update(raw.get("weights") or {})
                cfg["weights"] = merged_weights
        except Exception:
            pass
    return cfg


def save_config(cfg: dict) -> None:
    ensure_dirs()
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, CONFIG_PATH)


def resource_path(*parts: str) -> Path:
    return ASSET_DIR.joinpath(*parts)
