# 2.9实施记录

## 最新进度（优先于下方历史条目）

发行产物：`release-2.9-2026-11-07/见微-绿色版-2026-11-07-v2.9.zip`及同目录源码ZIP；桌面交付目标`C:/Users/华为/Desktop/AI/`，文件名不变，不删除旧包。最终压缩包清单/SHA见release目录packages.json，原题库一致性及私密条目审计见package-audit.json，桌面副本校验见copy-verification.json；以这些最终记录为准，下方“进行中/待确认”只保留过程历史。初次审计已确认258源码条目、151绿色版条目，原206题库字节不变，无私密记录/密钥条目；审计脚本输出编码已改用test_runtime.configure统一UTF-8，避免cp1252中文打印异常。

最终BUILD_OK；冻结frozen-test-9c081006返回0，26项全部通过，指纹295cdc73a837a9189d5afc3eaeebee74f2e28ead709648d38a3712f9a878e6d3。67+6遍历、412题库、analysis、lecture、panels、全部新增专项均OK。初轮冻结对松散all_modules.py的文件假设已修复：源码仍检查文件清单，冻结时检查编译导入manifest的新helper绑定，同时保留全部实际实验遍历。没有跳过67实验。初轮frozen-test-c178459b的traversal/lecture失败保留，仅最后9c081006是交付依据。下文“其余26项”是早期计数笔误：初次聚合除lecture外其余记录OK，最终总数26项。

性能最终串行、无构建/其他测试并行：perf28-final.json对perf29-final.json六工作台；化学首批重绘波动5.057ms，单独重复chem28-repeat.json/chem29-repeat.json为15.528→16.175ms，打开1510→1598.88ms。首次和复测均写RELEASE，不挑数据；离屏频次不等于真机FPS，不代表堆满器件或67实验全部帧率。早先Qt/导入等待、与构建重叠数据不采纳；诊断进程最终全部自然退出0，无强杀或线程终止。当前pack、审计ZIP原题库和私密条目、桌面AI复制SHA校验中；完成后追加路径。

最新专项stage6-final3.log通过并正常退出0，覆盖共同scale_max、真实Figure.caption量名悬停和换步清除。新增caption只把经过html.escape的文字链接化，不让题目变成任意HTML。217个Python文件语法通过；55个相比2.8变化的Python文件做了pyflakes，输出只剩原Guanlan/shell未用导入及显式注册模块的F401（原有noqa用途），新practice自测未用导入已清。日志lint-changed.log。

第一轮source aggregate其余26项（包括67+6遍历、412题库、analysis、panels）均OK，lecture因新增本地图区使旧测试固定itemAt(1)误取AI容器而CRASH；另有固定0.3秒假查询等待的竞态。现改为核对实际Card顺序[3,2,1]、验证本地图在资料之前，并有界等待结果（2秒限制未取消）。lecture-fixed.log已LECTURE OK/TEST_PROCESS_EXIT 0。不得把aggregate.log的SELFTEST_FAIL改写成通过。最终全聚合需以最后一次冻结结果为准。

第二轮build已BUILD_OK，初次冻结smoke还在正常运行，仍含修复前lecture断言；必须等其正常退出再重建，不强杀。当前源码还多了bank.selftest恢复hook/对话框的finally、caption联动、lecture测试修正，故该初次smoke不可交付。release.py现在build会清除过期验证，smoke前后核对同一源码指纹，pack拒绝指纹不同的验证报告，防止旧smoke结果错配新构建。

阶段6专项stage6-final2.log已正常退出0：6份签名补图昼夜与全部步骤、导出不受悬停污染、真实AnalysisPage标签linkHovered、两种物理共享时间、超长抛体有界核对、查询旧票据拒绝、日志白名单/默认不写。随后补强平衡柱状图共同scale_max=2并增加类型拒绝测试，需在最终聚合/冻测覆盖。课件本地图解限完整题干精确匹配和光合作用/细胞器/全反射三个精确概念定性图；没有声称任意课件题都本地求解。专用补图58，原flow替换25/89，64未换。physics_clock只抛体和静止无外力斜面，共用物理t，不改老仿真。匿名日志默认关，完成不含后续额外实验配置。

stage5最新learning-stage5-final.log已通过；17类各一个独立变式参考以practice-all17c为准。main聚合已接入practice/models29/models29b/learning/stage6、native全遍历、bank和analysis；analysis旧自测改为复用QApplication。test_runtime.cleanup(False)在每组后停止/销毁窗口和计时器、保留Qt应用，避免大量旧窗口累积使后续测试变慢；native.selftest包装恢复文件对话框和异常hook，避免污染后续组。第一轮source aggregate启动较早，仍使用旧的未分组清理执行体；不得把它的慢遍历耗时当作产品性能。它在verify-2.9/aggregate，最终结果待确认。

真实少量调用脚本verify-2.9/real_calls.py通过应用settings接口只在内存取得配置，不显示内容。无可用key，输出real-timings.json为not_configured/calls=0，真实网络耗时未验；自测仍全录制/隔离。不要通过搜索密钥文件补救，也不要将此说成真实请求成功。

版本已改2.9.0，release.py改独立release-2.9-2026-11-07，新增9项预期结果；两种ZIP附RELEASE-0.2.9.md/真机验收清单.md。首轮build开始后又修正柱状图共用尺度，预期源码指纹守卫会拒绝该轮发行，等正常完成后重新build，不强杀、不手改stage。尚待性能串行对照、最终build/smoke/pack、桌面AI复制与SHA校验。所有源码/构建稳定前不要报告已交付。

用户已确认PROMPT-下一轮-给GPT.md的一页方案，并补充：合理且不大改的决定直接推进，无需逐项确认。只在阶段完成后汇报，先专项自测通过再进入下一阶段。不改2.8的外观、胶囊、观澜、暮省；不强杀、不启动Word、不读取真实密钥；所有测试test_runtime、隔离数据和离屏。

## 已完成阶段1

native/backup.py：带格式/程序版本、逐文件大小与SHA256的jwbackup；最多10万文件/8GiB；字节保真（含未知扩展与BOM）；排除密钥env/key/pem/pfx、日志、缓存等；拒绝路径穿越、设备名、重复大小写路径、链接、未登记条目、未来版本和坏校验。正常退出后独占数据目录操作，main.py对正常启动及CLI持有共享锁；LockFileEx使用FAIL_IMMEDIATELY=1、EXCLUSIVE=2。恢复前生成自动备份，UUID兄弟目录交换，排除项原封不动移动；日记记录未完成操作，启动先回滚。保留.previous兄弟目录作第二份恢复副本，不自动删除。UI在设置数据区；校验在QThread中，结束后确认恢复、启动维护进程、正常退出，等待所有合作进程离开再操作。旧主窗口用QLocalSocket拒绝；旧版--no-single及非见微外部写入不在合作锁保障内，真机验收需关闭旧版。

backup_selftest已接入main聚合，最终通过目录verify-2.9/backup-stage1-final，日志backup-stage1-final.log。覆盖还原、坏包/未来版本/路径、写满、4处rename失败回滚、进程中断恢复、同进程及跨进程共享/独占锁；临时数据，无真实用户数据。早期锁标志测试曾阻塞，仅对精确识别的测试线程调用CancelSynchronousIo取消等待让其自行退出，没有kill。失败测试日志保留，后续不得复用错误标志。

## 已完成阶段2核心

analysis/practice.py、practice_ui.py：析题与Desk入口，后台检查学生“量名=结果”或有限明确等式，显示最早已核对的不符行，不推断未识别步骤。10类中间量/结果核对范围在INTERMEDIATE；其他7类只按可用结果比较。不保证10类都有具体错因规则：数值像漏摩擦/漏平方只说可能；明确填写a=g*sin(theta)且当前下滑有摩擦时可指出等式漏项。符号相反只提示方向，未知/乱填看不出来。数值比对不沿用绝对0.005（会将极小电荷0判正确），使用1%相对容差。常数表达式严格编译、拒绝尾部未知单位/字符和fact/comb/perm。

变式支持17类现有参数结构，UI只提供允许的数值及特定表达式/碱基/父本字符串叶子。仅重算所选task，清除旧claimed/AI图/model/calc，生成新ticket、新答案、推导与原生图；不改原题和原记录。参数或独立核对失败不给新答案。attempts.json新增v1，保留原stars.json，未来版本作答记录只读保护。

practice_selftest通过verify-2.9/practice-stage2-final，日志practice-stage2-final.log。17类参数接口、11个独立数值参考、错因边界、极小数值、不支持单位、原记录不变、未来版本保护、真实对话框异步计算与截图。尚需接入main总自测并跑既有回归。

## 后续工作

阶段4最终专项models-stage4-final.log通过（新增真实测力计加速度和变光电门宽度检查）。stage4-traversal中phys/scene昼夜通过，bio首次发现原mouse(kind,event)在leave QEvent上调用.position()的旧错误，已加坐标事件判断，stage4-bio-fixed.log昼夜全遍历通过。不得把首次FAIL日志说成通过，最终结果明确分开。

阶段5已实现learning.py固定间隔计划、learning_ui今日统计/队列/自评；stars不改格式，新learning.json v1，跨天/回拨有效日期取最近记录，不重复推进，同日每项目一次。题库check_answer记录时长/科目，正确率只计确切选项核对，原数字/关键词相似度归未判定，不假装判卷；自评复习另计。知识卡有加入复习入口，错题标记同步计划。今日卡引用自定milestones，7天内给通用复习建议，不预设考试日。提前加载题库前沿用data_import.run_once，保留1.x导入顺序。作文素材：guanlan嵌入模式的金句/词条/人物新增收素材功能入口，不改版式配色；Host信号转Shell已有ClipBus，category=作文素材且默认固定不受30项裁剪。素材篮搜索/分类/Markdown文字导出；旧Clip v1和旧资产不动。learning_selftest已通过learning-stage5，含跨天、回拨、幂等、未来版本、统计来源、自评UI、分类搜索导出、收集信号与主题切换；加强为主题切换后点击真正的新金句按钮，当前跑learning-stage5-final待结果。

阶段6计划只做有证据的原生图文字悬停、两个物理题型双图同一时钟、课件查询面板本地图解以及可选匿名耗时日志；70道剩余flow不批量换皮冒充专用补图，复杂几何自由工具与四端子继电器等保留未完成说明。后面仍需总回归、性能对照、真实少量请求（只合成题、绝不打印密钥）、2.9冻测打包和桌面AI校验。

阶段3全遍历已通过stage3-traversal.log：67实验/6工作台，昼夜正常退出0。阶段2随后加强为17类各一个独立数值/序列参考，practice-all17c.log通过；修正旧JSON整数不等于物理离散量（1mol可改0.5mol），只有题型求解器负责整数约束；补mol等单位和化学方程式等比例核对。

阶段4已实现、专项models29b_selftest在verify-2.9/models-stage4b通过：实际运动插值纸带和光电门，拉伸单向测力计；scene_types4光纤、圆锥摆、回旋加速器、速度选择器、导轨棒解析模型，含明确非相对论/采样/尺度边界；回旋图是瞬时跨缝加速的半圆连接，不是随意螺旋。cell_detail逐条染色体8时期计数/身份/分配规则，合成QMouseEvent拖动测试；有明确2n=4/无交换/无不分离范围，未来嵌套版本拒绝覆盖；二维细胞器不同结构可点选；bio新增energy_network四节点分支能量分配，旧foodweb三级链保留。快照兼容，图标登记design/icons.py，辅助模块登记all_modules。尚未做几何新轨迹/圆锥曲线/自由空间截面，不能称该部分完成。当前正跑stage4-traversal.log（只phys/scene/bio），会话ID需从工具结果恢复。native.selftest新增20ms自动reject临时QDialog，防止新细胞详情的模态对话框在自动按键测试中等用户；详情窗口的真实交互由models29b合成事件专项覆盖。仍未实测实体拖动/笔/触屏。

注意新增practice、models29、models29b自测尚未接入main聚合，release脚本尚未更新2.9；最终必须完成接入与冻测再打包。新增备份已接入main。

阶段3专项已通过models29_selftest（verify-2.9/models-stage3-final，models-stage3-final.log）：3套独立过程样品的过滤/Raoult理想二元蒸馏/萃取分液装置，端口条件、滤纸、分配系数/层位/放液实际改变状态；明确不与任意酸碱试剂混算。5个新电路器件（motor/inductor/galvanometer/multimeter/scope）接原节点电压求解，Norton源/后向欧拉/量程/内阻/电阻档内置电池及带电禁用。图标走design.icons；状态纳入原transfer，无新独立数据格式。继电器需要四端子图模型，本轮暂不硬塞；交流/变压器未做。纯数值守恒/电机堵转与稳态/RL储能耗散/电阻档及量程、实际RC节点求解对解析解、8个物品的click/drop/state均通过，正常退出。已跑native.selftest全遍历会话58253，日志stage3-traversal.log，目前待结果；通过后才进入阶段4。

继续阶段3真实化学/电路模型，阶段4力学/场景/几何/生物；按实现能力明确裁剪，不做摆设。之后阶段5复习/记录/Clip/节点，阶段6联动/补图/框选，阶段7独立release-2.9构建smoke打包桌面AI，更新全部文档和真机验收清单。当前版本仍2.8，发行脚本仍2.8，不可直接pack覆盖旧包。

阶段1/2只专项通过，尚未声称总自测/冻结版通过。修改shell.py的quit_app检查备份校验线程；其原有draw_icon unused pyflakes警告是既有。backup、practice新增文件需继续lint。阶段2诊断的反应计量刚补balanced及各物质mol检查，应增加专项断言再宣称该范围。
