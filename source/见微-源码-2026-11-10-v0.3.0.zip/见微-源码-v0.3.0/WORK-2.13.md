# 2.13实施与验证记录

## 最终状态

最终构建BUILD_OK；冻结`frozen-test-98df5e16`28项全部通过，TEST_PROCESS_EXIT=0，passed=true。指纹90d7c94b6b5132c5085138170a3a33b672d5a7e14a80db8019b50ba21b0f2eda，与源码/构建一致。交付产物位于release-2.13-2026-11-08，目标桌面`C:/Users/华为/Desktop/AI/见微-绿色版-2026-11-08-v2.13.zip`及同名日期源码ZIP。压缩包与桌面副本以packages.json、package-audit.json和copy-verification.json为最终记录，不覆盖旧包、旧dist和快捷方式。

## 过程记录（下方待办为历史状态）

首轮冻结frozen-test-f6f02260的28个模块结果均OK，但TEST_PROCESS_EXIT=1、passed=false：课件页say()的4秒匿名singleShot在页面已销毁后访问QLabel。不得只凭SELFTEST_OK当作发行通过。已将该回调及相关面板/存档提示的延迟回调绑定QObject上下文，销毁后自动取消。新增明确销毁页面后等待4.1秒的回归；compat-lifetime-final.log正常退出0。

另用visibility_probe.py确认隐藏笔迹后重新拿笔时按钮文字过期，已统一show_ink状态更新，兼容重新打开和切屏。visibility-fixed.log显示visible=True、label=隐藏笔迹，正常退出0；该情形已纳入新专项。当前重新build并准备最后一次完整冻结；不交付首轮failed包。

基线app/store.py=2.12.2，依据本轮用户要求修改课件导入符号、工具栏体验及应用外可选悬浮工具栏。旧版发布产物在release-2.12.2-2026-11-08保留；本轮版本2.13.0，发行目录独立release-2.13-2026-11-08，桌面AI仅新增本轮ZIP，不改桌面快捷方式或src2/dist。

实现文件：lecture/rich_symbols.py、builtin.py、page.py、library.py、player.py；kit/desktop_tools.py、pen_bar.py；shell.py入口；main.py新增compat-tools自测；tools/release.py新增预期与发布说明。只改本轮功能，不修改实验/题库/观澜/胶囊内容。

新专项compat-final3已通过，正常退出0：PPTX/DOCX科学字体/基线/PDF实际字形，OMML线性分式，后台重新生成副本和原笔迹字节保留，桌面笔迹历史/形状/清除/透明导出，指针穿透标志、关闭、位置、未来版本保护，单例，放映固定和窄屏两行。原课件全回归lecture-final通过，PPT缓存speed专项通过（固定夹具80→8布局、40→1解码，26.94倍仅为该夹具）。新业务文件和自测pyflakes无告警。

Windows实际后端native_probe.py：临时窗口中工具窗/置顶、隐藏主测试窗口后工具栏独立可见、WS_EX_TRANSPARENT指针开/批注关/返回开、关闭同时隐藏overlay均通过；正常退出0，结果verify-2.13/native-windows.json。没有读取用户桌面图像、操作其他真实应用或注入按键；真实软件/笔/双屏按真机清单验收。

测试继续test_runtime保护、隔离HOME/LOCALAPPDATA、离屏字体目录。无Word/强杀/真实密钥/联网。新桌面工具用户主动打开，默认pointer且不自动随启动打开；位置v1，笔迹仅会话内存，导出仅透明PNG。复杂公式不宣称原排版，缺失专有字体/MathType/OLE/已成图片的缺字无从凭空恢复。默认原样优先与2.12.2原生放映保持。

当前待最终build→smoke→pack、压缩包与桌面副本校验。后续以发行目录frozen-verification.json、packages.json及copy-verification.json记录为准。
