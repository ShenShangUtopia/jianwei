"""见微设计令牌（2.4「青瓷仪器」）：界面色（昼 / 夜）、数据色板、字体、间距、圆角、动效。

视觉概念：见微 = 看清细处的仪器。墨绿窄栏 + 朱砂印为识别，冷瓷面板，细线与刻度，按键有实体的下沿。

界面与实验画布都从这里取色；切换主题只需 set_theme()，再让窗口重画。
数据色板改编自 Okabe–Ito（色盲友好），按昼 / 夜各调一套明度，保证在纸底和墨底上都够对比。
"""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase

DAY = {
    # 瓷面：略带青的冷白，不再用暖米色
    "bg": "#E9EDE9", "surface": "#F5F7F4", "raised": "#FFFFFF", "stage": "#FCFDFB",
    "fg": "#14201D", "soft": "#33423D", "muted": "#58675F", "faint": "#8A9791",
    "line": "#D9DFD9", "line2": "#C3CBC4", "edge": "#A5AFA7", "hover": "#E2E7E2", "press": "#D5DCD6",
    # 画布
    "grid": "#E7EBE6", "grid2": "#D3D9D3", "axis": "#76827C",
    # 品牌与窄栏：墨绿底 + 朱砂印。窄栏昼夜都是深色，是这套界面最稳的识别
    "brand": "#C8402A", "rail": "#15231F", "rail2": "#22332E", "railfg": "#A9BAB3", "railon": "#FFFFFF",
    # 语义
    "accent": "#0F6B62", "gold": "#A87A2C", "ok": "#21804F", "bad": "#C2331F", "warn": "#B97F00",
    # 学科
    "math": "#2B55A6", "phys": "#B5502B", "chem": "#0F7D78", "bio": "#53831F",
    # 数据（Okabe–Ito 改编）
    "c1": "#0072B2", "c2": "#D55E00", "c3": "#009E73", "c4": "#C98A00", "c5": "#A35A98", "c6": "#3A9AD9",
    "shadow": "rgba(11,31,79,0.10)",
}
NIGHT = {
    "bg": "#0C1311", "surface": "#131B18", "raised": "#1A2420", "stage": "#0E1614",
    "fg": "#E6EEE9", "soft": "#C2CFC9", "muted": "#93A39C", "faint": "#65746D",
    "line": "#25312C", "line2": "#34423C", "edge": "#080D0B", "hover": "#1E2925", "press": "#27342F",
    "grid": "#17201D", "grid2": "#25302C", "axis": "#7F8F88",
    "brand": "#EE6448", "rail": "#080E0C", "rail2": "#18231F", "railfg": "#8FA098", "railon": "#FFFFFF",
    "accent": "#6FC7B6", "gold": "#E4B863", "ok": "#5CC98A", "bad": "#FF6B5E", "warn": "#F2C14E",
    "math": "#86ADF0", "phys": "#EE8A5E", "chem": "#4CC3B5", "bio": "#9CCC5A",
    "c1": "#5AB0F0", "c2": "#FF8A4C", "c3": "#3CCB9A", "c4": "#F2C14E", "c5": "#D68FC0", "c6": "#7CC8F2",
    "shadow": "rgba(0,0,0,0.45)",
}

# ---------------------------------------------------------------- 水墨（0.3.2 起的默认皮肤）
# 宣纸底、浓墨字、花青做强调、朱砂印做识别。暖灰一路到底，不掺别的色相；学科色和数据色沿用上面两套。
INK_DAY = dict(DAY, **{
    "bg": "#F2EFE7", "surface": "#F7F5EE", "raised": "#FFFDF8", "stage": "#FFFEFB",
    "fg": "#1B1A18", "soft": "#383633", "muted": "#66625A", "faint": "#99948A",
    "line": "#E3DED2", "line2": "#CFC9BB", "edge": "#B5AE9F", "hover": "#EBE7DC", "press": "#DFDACD",
    "grid": "#ECE8DE", "grid2": "#DAD5C8", "axis": "#7C776D",
    "brand": "#C23B2A", "rail": "#1D1C1A", "rail2": "#2F2D2A", "railfg": "#ADA89D", "railon": "#FFFFFF",
    "accent": "#2B5F78", "gold": "#A6672E", "ok": "#3A7A57", "bad": "#B93A2B", "warn": "#A9741B",
    "shadow": "rgba(27,26,24,0.10)",
})
INK_NIGHT = dict(NIGHT, **{
    "bg": "#121211", "surface": "#191918", "raised": "#21201E", "stage": "#161615",
    "fg": "#ECE8DE", "soft": "#CFCABE", "muted": "#9D988C", "faint": "#6F6B62",
    "line": "#2B2A27", "line2": "#3C3A36", "edge": "#090908", "hover": "#262523", "press": "#302E2B",
    "grid": "#1C1B1A", "grid2": "#2A2927", "axis": "#8A857B",
    "brand": "#E05A45", "rail": "#0B0B0A", "rail2": "#201F1D", "railfg": "#989388", "railon": "#FFFFFF",
    "accent": "#8FC3D4", "gold": "#D9A566", "ok": "#6CC492", "bad": "#FF7462", "warn": "#E8B95A",
    "shadow": "rgba(0,0,0,0.50)",
})

SKINS = {"ink": (INK_DAY, INK_NIGHT), "celadon": (DAY, NIGHT)}
SKIN_NAMES = (("ink", "水墨"), ("celadon", "青瓷"))

_theme = "day"
_skin = "ink"
_subject = ""   # 没有学科时 accent 用皮肤的强调色；实验台选了学科才换成学科色


class _Palette(dict):
    """T.fg / T['fg'] 两种写法都行；T.c 是数据色列表；T.accent 跟当前学科走。"""

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as e:
            raise AttributeError(k) from e


T = _Palette()


def _rebuild() -> None:
    day, night = SKINS.get(_skin, SKINS["ink"])
    src = night if _theme == "night" else day
    T.clear()
    T.update(src)
    T["accent"] = src.get(_subject, src["accent"])
    T["c"] = [src[f"c{i}"] for i in range(1, 7)]
    T["dark"] = _theme == "night"
    T["skin"] = _skin


def set_theme(name: str) -> None:
    global _theme
    _theme = "night" if name == "night" else "day"
    _rebuild()


def set_skin(name: str) -> None:
    """换皮肤（水墨 / 青瓷）。昼夜不变；换完让窗口重新套样式、重画。"""
    global _skin
    _skin = name if name in SKINS else "ink"
    _rebuild()


def skin() -> str:
    return _skin


def set_subject(subj: str) -> None:
    global _subject
    _subject = subj
    _rebuild()


def theme() -> str:
    return _theme


def qc(c, a: float | None = None) -> QColor:
    """'#rrggbb' / 'rgba(...)' / QColor → QColor，可另给透明度。"""
    if isinstance(c, QColor):
        col = QColor(c)
    elif isinstance(c, str) and c.startswith("rgb"):   # rgb(...) / rgba(...)
        parts = [x.strip() for x in c[c.index("(") + 1:c.index(")")].split(",")]
        col = QColor(int(float(parts[0])), int(float(parts[1])), int(float(parts[2])))
        if len(parts) > 3:
            col.setAlphaF(max(0.0, min(1.0, float(parts[3]))))
    else:
        col = QColor(c)
    if a is not None:
        col.setAlphaF(max(0.0, min(1.0, a)))
    return col


def alpha(c, a: float) -> QColor:
    return qc(c, a)


def css(c, a: float | None = None) -> str:
    """样式表里用的颜色字符串（带透明度时写成 rgba()）。"""
    col = qc(c, a)
    if col.alpha() == 255:
        return col.name()
    return f"rgba({col.red()},{col.green()},{col.blue()},{col.alphaF():.3f})"


# ---------------------------------------------------------------- 字体
SIZE = {"xs": 11, "sm": 12, "md": 13, "lg": 15, "xl": 18, "h2": 22, "h1": 28}
SPACE = {"xs": 4, "sm": 8, "md": 12, "lg": 16, "xl": 24}
RADIUS = {"sm": 6, "md": 8, "lg": 10}
MOTION = {"fast": 120, "base": 160, "slow": 240}

_fam: dict = {}


def _pick(cands: list[str]) -> str:
    have = set(QFontDatabase.families())
    for f in cands:
        if f in have:
            return f
    return cands[-1]


def family(kind: str) -> str:
    if kind not in _fam:
        _fam[kind] = _pick({
            "ui": ["Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans SC", "PingFang SC", "sans-serif"],
            "num": ["Bahnschrift", "Segoe UI", "Cambria", "sans-serif"],   # 仪表读数：DIN 系等高数字
            "mono": ["Cascadia Mono", "Consolas", "IBM Plex Mono", "monospace"],
            "serif": ["Noto Serif SC", "SimSun", "Songti SC", "serif"],        }[kind])
    return _fam[kind]


_fonts: dict = {}


def font(px: float = 13, weight: int = 400, kind: str = "ui", spacing: float = 0.0) -> QFont:
    if weight == 600 and kind == "ui":   # 微软雅黑没有半粗，Windows 上合成出来的字发糊
        weight = 700
    key = (round(px, 2), weight, kind, spacing)
    f = _fonts.get(key)
    if f is None:
        f = QFont(family(kind))
        f.setPixelSize(max(6, int(round(px))))
        f.setWeight(QFont.Weight(weight))
        if spacing:
            f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
        f.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
        _fonts[key] = f
    return f


_rebuild()
