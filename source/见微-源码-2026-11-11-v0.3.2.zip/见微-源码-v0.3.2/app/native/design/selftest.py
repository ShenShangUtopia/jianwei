"""设计系统自测：昼夜配色的对比度、按键尺寸、图标齐全、画笔工具条的状态同步。

用法：python -m native.design.selftest <隔离目录>
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

LAST_FAILS: list[str] = []


def _lum(c) -> float:
    def f(v):
        v /= 255
        return v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4
    return .2126 * f(c.red()) + .7152 * f(c.green()) + .0722 * f(c.blue())


def contrast(a, b) -> float:
    from .tokens import qc
    la, lb = _lum(qc(a)), _lum(qc(b))
    return (max(la, lb) + .05) / (min(la, lb) + .05)


def main(out_dir=None) -> int:
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv[:1])
    LAST_FAILS.clear()

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f" {detail}" if detail and not ok else ""), flush=True)
        if not ok:
            LAST_FAILS.append(name)

    from . import tokens
    from .icons import _ICONS
    from .tokens import DAY, INK_DAY, INK_NIGHT, NIGHT
    from .widgets import IconButton, RailButton, Segmented, qss
    for name, pal in (("青瓷昼", DAY), ("青瓷夜", NIGHT), ("水墨昼", INK_DAY), ("水墨夜", INK_NIGHT)):
        for fg, bg, need in (("fg", "bg", 7), ("fg", "surface", 7), ("soft", "surface", 7), ("muted", "surface", 4.5), ("muted", "bg", 4.2),
                             ("railfg", "rail", 4.5), ("railon", "rail2", 7), ("stage", "accent", 4.5), ("bad", "raised", 4.5)):
            r = contrast(pal[fg], pal[bg])
            check(f"{name} 对比度 {fg}/{bg} ≥ {need}", r >= need, f"实测 {r:.2f}")
        for subj in ("math", "phys", "chem", "bio"):
            r = contrast(pal["stage"], pal[subj])
            check(f"{name} 学科色 {subj} 上的按键文字可读", r >= 4.2, f"实测 {r:.2f}")
    tokens.set_theme("day")
    for icon in ("today", "guanlan", "countdown", "desk", "lab", "bench", "analysis", "lecture", "settings", "basket",
                 "pen", "marker", "chalk", "eraser", "lasso", "laser", "pointer", "select", "undo", "redo", "more", "close", "min", "reagent", "box", "tune", "note"):
        check(f"图标 {icon}", icon in _ICONS)

    # 样式表不能把按键的固定尺寸撑坏（曾因 min-height 让窄栏的键塌掉）
    from PySide6.QtWidgets import QVBoxLayout, QWidget
    host = QWidget()
    host.setObjectName("jw2")
    host.setStyleSheet(qss())
    lay = QVBoxLayout(host)
    rail = RailButton("desk", "习题")
    icon = IconButton("pen", "笔", 30)
    seg = Segmented([("a", "甲"), ("b", "乙")], "a")
    for w in (rail, icon, seg):
        lay.addWidget(w)
    host.resize(200, 400)
    host.show()
    app.processEvents()
    check("窄栏键高度不被样式表改变", rail.height() == 54 and rail.minimumHeight() == 54, rail.height())
    check("图标键保持方形", icon.width() == 30 and icon.height() == 30)
    host.hide()

    from ..kit.pen_bar import PenBar, SHAPES

    class Target:
        tool, color, width_px = "pen", "#E5484D", 3.5

        def set_tool(self, t):
            self.tool = t

        def undo(self):
            self.undone = True

        def redo(self):
            pass

    class Session:
        snap_enabled, eraser_mode, ids = True, "stroke", ()

    t = Target()
    bar = PenBar(t, Session())
    check("打开时笔键选中", bar.keys["pen"].isChecked() and not bar.keys["marker"].isChecked())
    bar.keys["marker"].click()
    check("点荧光笔键切工具", t.tool == "marker" and bar.tool_box.currentData() == "marker")
    check("其余工具键取消选中", not bar.keys["pen"].isChecked() and bar.keys["marker"].isChecked())
    bar.tool_box.setCurrentIndex(bar.tool_box.findData("eraser"))
    check("下拉状态切工具会同步到键", t.tool == "eraser" and bar.keys["eraser"].isChecked())
    bar.set_tool(SHAPES[1])
    check("形状工具时形状键选中并换图标", bar.shape_key.isChecked() and bar.shape_key.icon == SHAPES[1])
    bar.width_box.setValue(6)
    check("笔宽写回目标", t.width_px == 6)
    bar.set_color("#2F6FED")
    check("选颜色写回目标", t.color == "#2F6FED")
    bar.undo_key.click()
    check("撤销键生效", getattr(t, "undone", False))
    board = PenBar(Target(), Session(), board=True, on_dark=True)
    check("黑板工具条的指针是移动工具", "move" in board.keys and "select" not in board.keys)
    v = PenBar(Target(), Session(), vertical=True)
    check("竖排能建立", v.layout().count() > 5)
    for w in (bar, board, v, host):
        w.deleteLater()
    print("DESIGN " + ("OK" if not LAST_FAILS else "FAIL " + ",".join(LAST_FAILS)), flush=True)
    return int(bool(LAST_FAILS))


if __name__ == "__main__":
    from ..kit import test_runtime
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if target:
        os.environ.setdefault("JIANWEI_HOME", str(target / "home"))
        os.environ.setdefault("LOCALAPPDATA", str(target / "local"))
    test_runtime.application(sys.argv[:1])
    sys.exit(test_runtime.run(lambda: main(target)))
