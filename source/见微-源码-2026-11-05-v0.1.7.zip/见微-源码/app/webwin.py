"""见微 · 内嵌窗口：习题台、格物实验台、题目导入不再交给 Edge，而在见微自己的窗口里打开（QtWebEngine）。

- 一个窗口、一页：顶部是见微风格的细工具条（后退 / 前进 / 刷新、四个去处、在浏览器中打开），没有地址栏和标签页。
- 存储用独立的持久配置（%LOCALAPPDATA%\\Jianwei\\web）：习题台的导入题、收藏，实验台的画板、讲题记录都留在这里。
- 站外链接交给系统浏览器；页面里「存图」之类的下载弹出另存为对话框。
- 见微切换昼夜时，窗口与页面一起换（不刷新页面）。
- QtWebEngine 不可用（例如精简打包）时 available() 为 False，调用方退回用 Edge 打开。
"""
from __future__ import annotations

import ctypes
import json
from pathlib import Path

from PySide6.QtCore import QByteArray, QTimer, QUrl, Qt
from PySide6.QtGui import QDesktopServices, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QFileDialog, QHBoxLayout, QLabel, QProgressBar, QPushButton,
                               QVBoxLayout, QWidget)

import store
import ui_kit

try:
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings
    from PySide6.QtWebEngineWidgets import QWebEngineView
    _OK = True
except Exception:  # noqa: BLE001  精简打包或缺组件
    _OK = False


def available() -> bool:
    return _OK


WEB_HOME = store.HOME / "web"
_profile = None


def _internal(url: QUrl) -> bool:
    """见微自己的页面：本地文件、本机服务、内嵌数据。其余（教材网站、字体以外的外链）交给系统浏览器。"""
    s = url.scheme()
    return s in ("file", "data", "blob", "about", "qrc") or url.host() in ("127.0.0.1", "localhost")


def profile():
    """命名配置 = 持久化：localStorage、缓存都落在 WEB_HOME。整个进程共用一份。"""
    global _profile
    if _profile is None:
        WEB_HOME.mkdir(parents=True, exist_ok=True)
        p = QWebEngineProfile("jianwei", QApplication.instance())
        p.setPersistentStoragePath(str(WEB_HOME / "storage"))
        p.setCachePath(str(WEB_HOME / "cache"))
        p.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        p.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        s = p.settings()
        A = QWebEngineSettings.WebAttribute
        s.setAttribute(A.LocalStorageEnabled, True)
        s.setAttribute(A.LocalContentCanAccessRemoteUrls, True)  # file:// 的习题台要去本机服务的实验台、网络字体
        s.setAttribute(A.LocalContentCanAccessFileUrls, True)
        s.setAttribute(A.ScrollAnimatorEnabled, True)
        s.setAttribute(A.FullScreenSupportEnabled, True)
        s.setAttribute(A.JavascriptCanAccessClipboard, True)
        p.downloadRequested.connect(_on_download)
        _profile = p
    return _profile


_warm = None


EXPORT_JS = "JSON.stringify(Object.fromEntries(Object.keys(localStorage).map(k => [k, localStorage.getItem(k)])))"


def export_for_v2(page) -> None:
    """把本机记录（错题本、导入的题、自建场景、讲题记录、几何画板）写成 export-1x.json，2.0 启动时读它。"""
    def done(text) -> None:
        try:
            if not text or text == "{}":
                return
            path = store.HOME / "export-1x.json"
            # 习题台（file://）和实验台（本机服务）是两个存储源：合并，不互相覆盖
            try:
                merged = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                merged = {}
            merged.update(json.loads(text))
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(merged, ensure_ascii=False), encoding="utf-8")
            import os
            os.replace(tmp, path)
        except Exception:  # noqa: BLE001  导出失败不影响使用，下次打开再试
            pass
    page.runJavaScript(EXPORT_JS, 0, done)


def prewarm(url: str = "", url2: str = "") -> None:
    """后台预热：建好配置并让一个看不见的空白页拉起 Chromium 进程。

    开机后第一次打开习题台 / 实验台时，QtWebEngine 冷启动（加载 Chromium、杀毒扫描子进程）实测要
    十几秒；先在空闲时热好，点开时只剩页面本身的加载。真窗口建好后这张空白页就释放。"""
    global _warm
    if not _OK or _warm is not None:
        return
    app = QApplication.instance()
    page = QWebEnginePage(profile(), app)
    if url:   # 顺便载入本机页面，导出一次记录（1.x 的 localStorage 只有同源页面读得到）
        todo = [url2] if url2 else []

        def loaded(ok: bool) -> None:
            if ok:
                export_for_v2(page)
            if todo:   # 两个存储源都走一遍；留点时间让上一页的导出回调先回来
                nxt = todo.pop()
                QTimer.singleShot(400, lambda: page.load(QUrl(nxt)))
        page.loadFinished.connect(loaded)
    page.load(QUrl(url or "about:blank"))
    _warm = page
    # 页面必须先于配置销毁，否则退出时会卡住：不管从哪条路退出都先放掉
    app.aboutToQuit.connect(release_warm)


def release_warm() -> None:
    global _warm
    if _warm is not None:
        # 立即销毁（退出时事件循环已停，deleteLater 不会再执行）
        import shiboken6
        if shiboken6.isValid(_warm):
            shiboken6.delete(_warm)
        _warm = None


def _on_download(req) -> None:
    """页面里的「存图」「导出」：问一下存到哪。"""
    downloads = Path.home() / "Downloads"
    name = req.downloadFileName() or "见微导出"
    path, _ = QFileDialog.getSaveFileName(None, "保存", str(downloads / name))
    if not path:
        req.cancel()
        return
    p = Path(path)
    req.setDownloadDirectory(str(p.parent))
    req.setDownloadFileName(p.name)
    req.accept()


if _OK:
    class _Page(QWebEnginePage):
        def __init__(self, win: "WebWindow") -> None:
            super().__init__(profile(), win)
            self.win = win
            self._pending: list = []

        def acceptNavigationRequest(self, url, nav_type, is_main):  # noqa: N802 (Qt 命名)
            if is_main and not _internal(url):
                QDesktopServices.openUrl(url)
                return False
            return super().acceptNavigationRequest(url, nav_type, is_main)

        def createWindow(self, _kind):  # noqa: N802
            """target=_blank / window.open：在本窗口里打开（站外地址交给系统浏览器）。"""
            tmp = QWebEnginePage(self.profile(), self)
            self._pending.append(tmp)

            def go(u: QUrl) -> None:
                if u.isEmpty():
                    return
                if _internal(u):
                    self.win.view.load(u)
                else:
                    QDesktopServices.openUrl(u)
                if tmp in self._pending:
                    self._pending.remove(tmp)
                tmp.deleteLater()
            tmp.urlChanged.connect(go)
            return tmp

        def javaScriptConsoleMessage(self, level, message, line, source):  # noqa: N802
            if level != QWebEnginePage.JavaScriptConsoleMessageLevel.ErrorMessageLevel:
                return
            try:
                (store.HOME / "logs").mkdir(parents=True, exist_ok=True)
                with open(store.HOME / "logs" / "web.log", "a", encoding="utf-8") as fh:
                    fh.write(f"{source}:{line}  {message}\n")
            except Exception:
                pass


# 四个去处：(按钮文字, 打开方式)；打开方式交给 Shell，由它拼出带主题的地址
PLACES = [("习题台", "studio"), ("格物实验台", "lab"), ("导入题目", "import"), ("自由工作台", "bench")]


class WebWindow(QWidget):
    def __init__(self, shell) -> None:
        super().__init__(None)
        self.shell = shell
        self.setObjectName("webWin")
        self.setWindowTitle("见微")
        try:
            self.setWindowIcon(shell.windowIcon())
        except Exception:
            pass
        self.setMinimumSize(900, 600)
        self._restore_geometry()

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.bar = QWidget(self)
        self.bar.setObjectName("webBar")
        self.bar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        h = QHBoxLayout(self.bar)
        h.setContentsMargins(10, 6, 10, 6)
        h.setSpacing(4)

        def tool(text: str, tip: str, fn) -> QPushButton:
            b = QPushButton(text, self.bar)
            b.setObjectName("webTool")
            b.setToolTip(tip)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(fn)
            h.addWidget(b)
            return b

        self.btn_back = tool("‹", "后退（Alt+←）", lambda: self.view.back())
        self.btn_fwd = tool("›", "前进（Alt+→）", lambda: self.view.forward())
        self.btn_reload = tool("⟳", "刷新（F5）", lambda: self.view.reload())
        h.addSpacing(10)

        self.place_btns: dict[str, QPushButton] = {}
        for text, key in PLACES:
            b = QPushButton(text, self.bar)
            b.setObjectName("webPlace")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            h.addWidget(b)
            self.place_btns[key] = b
        h.addStretch(1)
        self.title = QLabel("", self.bar)
        self.title.setObjectName("webTitle")
        h.addWidget(self.title)
        h.addSpacing(8)
        tool("↗", "在系统浏览器中打开当前页", self.open_external)
        lay.addWidget(self.bar)

        # 一次性提示：以前在 Edge 里留下的记录可以搬过来
        self.notice = QWidget(self)
        self.notice.setObjectName("webNotice")
        self.notice.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        nh = QHBoxLayout(self.notice)
        nh.setContentsMargins(14, 5, 10, 5)
        nh.setSpacing(8)
        self.notice_text = QLabel("习题台和实验台现在在见微自己的窗口里打开。以前在 Edge 里导入的题、收藏和讲题记录可以搬过来。", self.notice)
        self.notice_text.setObjectName("webNoticeText")
        nh.addWidget(self.notice_text, 1)
        for text, fn, name in [("搬过来", self._start_migration, "webNoticeGo"), ("不用了", self._dismiss_notice, "webNoticeNo")]:
            b = QPushButton(text, self.notice)
            b.setObjectName(name)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(fn)
            nh.addWidget(b)
        self.notice.setVisible(not (WEB_HOME / "migrated.flag").exists())
        lay.addWidget(self.notice)
        self._mig_timer = QTimer(self)
        self._mig_timer.setInterval(1000)
        self._mig_timer.timeout.connect(self._poll_migration)
        self._mig_left = 0

        self.progress = QProgressBar(self)
        self.progress.setObjectName("webProgress")
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(2)
        self.progress.setRange(0, 100)
        self.progress.hide()
        lay.addWidget(self.progress)

        self.view = QWebEngineView(self)
        self.page = _Page(self)
        self.view.setPage(self.page)
        QTimer.singleShot(3000, release_warm)  # 真页面的渲染进程起来了，预热页可以放掉
        lay.addWidget(self.view, 1)

        self.view.titleChanged.connect(self._on_title)
        self.view.urlChanged.connect(self._on_url)
        self.view.loadStarted.connect(lambda: (self.progress.setValue(5), self.progress.show()))
        self.view.loadProgress.connect(self.progress.setValue)
        self.view.loadFinished.connect(self._on_loaded)

        for keys, fn in [("F5", self.view.reload), ("Ctrl+R", self.view.reload), ("Alt+Left", self.view.back),
                         ("Alt+Right", self.view.forward), ("F11", self._toggle_full),
                         ("Ctrl+=", lambda: self._zoom(0.1)), ("Ctrl++", lambda: self._zoom(0.1)),
                         ("Ctrl+-", lambda: self._zoom(-0.1)), ("Ctrl+0", lambda: self.view.setZoomFactor(1.0))]:
            QShortcut(QKeySequence(keys), self, activated=fn)
        self.apply_theme()

    # ------------------------------------------------------------ 打开
    def load(self, url: str) -> None:
        self.view.load(QUrl(url))
        self.present()

    def present(self) -> None:
        if self.isMinimized():
            self.showNormal()
        self.show()
        self.raise_()
        self.activateWindow()

    def go(self, key: str) -> None:
        self.shell.open_web(key)

    def open_external(self) -> None:
        url = self.view.url()
        if url.isValid() and not url.isEmpty():
            QDesktopServices.openUrl(url)

    # ------------------------------------------------------------ 状态
    def _place_of(self, url: QUrl) -> str:
        path, frag = url.path(), url.fragment()
        if "/gewu/" in path:
            if frag == "import":
                return "import"
            if frag.startswith("bench"):
                return "bench"
            return "lab"
        return "studio"

    def _on_url(self, url: QUrl) -> None:
        cur = self._place_of(url)
        for k, b in self.place_btns.items():
            b.setChecked(k == cur)
        self.btn_back.setEnabled(self.view.history().canGoBack())
        self.btn_fwd.setEnabled(self.view.history().canGoForward())

    def _on_title(self, t: str) -> None:
        t = (t or "").replace("见微 · ", "").strip()
        self.title.setText(t)
        self.setWindowTitle(f"见微 · {t}" if t else "见微")

    def _on_loaded(self, _ok: bool) -> None:
        self.progress.setValue(100)
        QTimer.singleShot(250, self.progress.hide)
        self._on_url(self.view.url())
        self._push_theme()
        self._inject_migration()
        export_for_v2(self.page)

    # ------------------------------------------------------------ 从 Edge 搬旧记录
    def _dismiss_notice(self) -> None:
        self.notice.hide()
        try:
            WEB_HOME.mkdir(parents=True, exist_ok=True)
            (WEB_HOME / "migrated.flag").write_text("dismissed", encoding="utf-8")
        except Exception:
            pass

    def _start_migration(self) -> None:
        if not self.shell.studio.open_migration():
            self.notice_text.setText("没有找到 Edge，旧记录搬不过来；以后的记录都会存在见微里。")
            return
        self.notice_text.setText("已在 Edge 里打开两张搬家页，搬完会自动回到这里……")
        self._mig_left = 90
        self._mig_timer.start()

    def _poll_migration(self) -> None:
        self._mig_left -= 1
        files = [WEB_HOME / f"migrate-{s}.json" for s in ("file", "http")]
        if any(f.exists() for f in files):
            self._inject_migration()
        # 收到 = 交过来了（另一个源的记录等你切到那一页时再写入）
        got = [f.exists() or f.with_suffix(".done").exists() for f in files]
        if all(got) or (any(got) and self._mig_left < 80) or self._mig_left <= 0:
            self._mig_timer.stop()
            if any(got):
                self.notice_text.setText("旧记录已经搬过来了。")
                (WEB_HOME / "migrated.flag").write_text("done", encoding="utf-8")
                QTimer.singleShot(4000, self.notice.hide)
            else:
                self.notice_text.setText("还没收到旧记录。可以在 Edge 的搬家页上看看提示，或者再点一次「搬过来」。")

    def _inject_migration(self) -> None:
        """当前页属于哪个源，就把那个源的旧记录写进来：没有的键直接写，两边都是列表的合并去重，已有的不覆盖。"""
        url = self.view.url()
        src = "file" if url.scheme() == "file" else "http" if url.host() in ("127.0.0.1", "localhost") else ""
        f = WEB_HOME / f"migrate-{src}.json"
        if not src or not f.exists():
            return
        try:
            items = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            return
        js = """(function(items){var n=0;for(var k in items){var v=items[k],cur=localStorage.getItem(k);
          if(cur===null){localStorage.setItem(k,v);n++;continue;}
          try{var a=JSON.parse(cur),b=JSON.parse(v);if(Array.isArray(a)&&Array.isArray(b)){var seen={},out=[];
            (k==='lab-lessons'?a.concat(b):b.concat(a)).forEach(function(x){var s=JSON.stringify(x);if(!seen[s]){seen[s]=1;out.push(x);}});
            if(out.length!==a.length){localStorage.setItem(k,JSON.stringify(out));n++;}}}catch(e){}}
          return n;})(%s)""" % json.dumps(items, ensure_ascii=False)

        def after(n) -> None:
            try:
                f.replace(f.with_suffix(".done"))
            except Exception:
                pass
            if n:
                self.view.reload()  # 页面按新记录重画
        self.page.runJavaScript(js, 0, after)

    def _zoom(self, d: float) -> None:
        self.view.setZoomFactor(max(0.5, min(2.5, round(self.view.zoomFactor() + d, 2))))

    def _toggle_full(self) -> None:
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    # ------------------------------------------------------------ 主题
    def apply_theme(self) -> None:
        C = ui_kit.C
        night = ui_kit.theme() == "night"
        sel_bg, sel_fg = (C.ACCENTH, "#22190A") if night else (C.INKH, "#FFFFFF")
        self.setStyleSheet(f"""
            QWidget#webWin {{ background: {C.PAPERH}; }}
            QWidget#webBar {{ background: {C.SIDEH}; border-bottom: 1px solid {C.LINEH}; }}
            QPushButton#webTool {{ min-width: 30px; max-width: 30px; min-height: 28px; max-height: 28px; padding: 0;
                border: 1px solid transparent; border-radius: 8px; background: transparent; color: {C.SOFTH};
                font: 17px "{ui_kit.UI}"; }}
            QPushButton#webTool:hover {{ background: {C.CARDH}; border-color: {C.LINEH}; color: {C.INKH}; }}
            QPushButton#webTool:disabled {{ color: {C.LINEH}; }}
            QPushButton#webPlace {{ min-height: 28px; max-height: 28px; padding: 0 13px; border-radius: 8px;
                border: 1px solid transparent; background: transparent; color: {C.SOFTH};
                font: 13px "{ui_kit.UI}"; }}
            QPushButton#webPlace:hover {{ color: {C.INKH}; background: {C.CARDH}; border-color: {C.LINEH}; }}
            QPushButton#webPlace:checked {{ background: {sel_bg}; color: {sel_fg}; border-color: {sel_bg}; font-weight: 600; }}
            QLabel#webTitle {{ color: {C.FAINTH}; font: 12px "{ui_kit.UI}"; }}
            QWidget#webNotice {{ background: {"#1A2436" if night else "#FBEFE6"}; border-bottom: 1px solid {C.LINEH}; }}
            QLabel#webNoticeText {{ color: {C.INKH}; font: 12.5px "{ui_kit.UI}"; }}
            QPushButton#webNoticeGo {{ min-height: 24px; padding: 0 12px; border-radius: 7px; border: 1px solid {C.ACCENTH};
                background: {C.ACCENTH}; color: {"#22190A" if night else "#FFFFFF"}; font: 600 12px "{ui_kit.UI}"; }}
            QPushButton#webNoticeNo {{ min-height: 24px; padding: 0 10px; border-radius: 7px; border: 1px solid transparent;
                background: transparent; color: {C.SOFTH}; font: 12px "{ui_kit.UI}"; }}
            QPushButton#webNoticeNo:hover {{ color: {C.INKH}; border-color: {C.LINEH}; }}
            QProgressBar#webProgress {{ border: 0; background: transparent; }}
            QProgressBar#webProgress::chunk {{ background: {C.ACCENTH}; }}
        """)
        self._dark_titlebar(night)
        self._push_theme()

    def _push_theme(self) -> None:
        """不刷新页面，直接让页面换昼夜：习题台有 JWTheme，实验台点它自己的主题按钮。"""
        t = ui_kit.theme()
        js = ("(function(t){try{"
              "if(window.JWTheme){if(JWTheme.get()!==t)JWTheme.set(t);return;}"
              "var b=document.getElementById('theme');if(typeof App!=='undefined'&&b){"
              "var dark=document.documentElement.dataset.theme==='dark';if(dark!==(t==='night'))b.click();}"
              "else{localStorage.setItem('lab-theme',t==='night'?'dark':'light');}"
              "}catch(e){}})(%s)" % json.dumps(t))
        try:
            self.page.runJavaScript(js)
        except Exception:
            pass

    def _dark_titlebar(self, on: bool) -> None:
        """Windows 10 1809+ / 11：夜间让系统标题栏也变深。"""
        try:
            hwnd = int(self.winId())
            val = ctypes.c_int(1 if on else 0)
            for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE（新、旧编号）
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                    break
        except Exception:
            pass

    # ------------------------------------------------------------ 窗口位置
    def _geom_file(self) -> Path:
        return WEB_HOME / "window.json"

    def _restore_geometry(self) -> None:
        try:
            data = json.loads(self._geom_file().read_text(encoding="utf-8"))
            if self.restoreGeometry(QByteArray.fromBase64(data["geometry"].encode("ascii"))):
                return
        except Exception:
            pass
        self.resize(1460, 940)

    def closeEvent(self, ev) -> None:  # noqa: N802
        """关窗只是收起：再打开时停在原处（页面在后台会自动暂停动画）。"""
        try:
            WEB_HOME.mkdir(parents=True, exist_ok=True)
            self._geom_file().write_text(json.dumps({"geometry": bytes(self.saveGeometry().toBase64()).decode("ascii")}),
                                         encoding="utf-8")
        except Exception:
            pass
        ev.ignore()
        self.hide()
