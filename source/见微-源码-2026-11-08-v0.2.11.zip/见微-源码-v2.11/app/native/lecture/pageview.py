"""课件一页的显示与笔画：渲染缓存、缩放平移、笔 / 荧光笔 / 橡皮、框选截取。"""
from __future__ import annotations

import math
import time

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QCursor, QImage, QPainter, QPen, QPixmap, QPointingDevice
from PySide6.QtPdf import QPdfDocument
from PySide6.QtWidgets import QWidget

from . import anim as anim_mod
from ..kit import pen as ink
from ..kit.pen_session import PenSession
from .effects import Run

BG_SLIDE = QColor("#0A0F0D")
BG_DOC = QColor("#1B2622")
MIN_SELECT = 10


def render_page(doc: QPdfDocument, page: int, w: int, h: int) -> QImage:
    """渲染一页，垫上白底：有些 PDF 的页面背景是透明的，直接贴到深色背景上字就看不见了。"""
    src = doc.render(page, QSize(max(1, w), max(1, h)))
    out = QImage(max(1, w), max(1, h), QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(Qt.GlobalColor.white)
    if not src.isNull():
        p = QPainter(out)
        p.drawImage(0, 0, src)
        p.end()
    return out


def text_in_rect(doc: QPdfDocument, page: int, rect: QRectF, limit: int = 8000) -> str:
    """取框内的文字：逐字看它的位置（比 PDF 的「从这到那」选择更准，分栏时不会串）。"""
    total = len(doc.getAllText(page).text())
    out = []
    last_bottom = None
    for i in range(min(total, limit)):
        sel = doc.getSelectionAtIndex(page, i, 1)
        r = sel.boundingRectangle()
        if r.isEmpty() or not rect.contains(r.center()):
            continue
        ch = sel.text()
        if last_bottom is not None and r.top() > last_bottom:
            out.append("\n")
        last_bottom = r.bottom()
        out.append(ch)
    return "".join(out).strip()


class PageView(QWidget):
    page_changed = Signal(int)
    frame_changed = Signal()
    selected = Signal(object)        # 页面坐标的 QRectF；空矩形表示取消
    ink_changed = Signal()
    activity = Signal()

    def __init__(self, doc: QPdfDocument, kind: str = "slides", strokes=None, timeline=None):
        super().__init__()
        self.doc, self.kind = doc, kind
        tl = timeline if timeline and len(timeline.get("frames", [])) == doc.pageCount() else anim_mod.identity(doc.pageCount())
        self.frames, self.slides = tl["frames"], tl["slides"]
        self.pages = len(self.slides)   # 张数：一张幻灯片可以有好几个动画画面
        self.page = 0
        self.frame = 0
        self.run = None
        self.zoom, self.ox, self.oy = 1.0, 0.0, 0.0
        self.tool = "pointer"
        self.color, self.width_px = "#E5484D", 3.0
        self.histories = {int(k): ink.History(v) for k, v in (strokes or {}).items()}
        self.active = None
        self.sel = None          # 框选（页面坐标）
        self.sel_drag = None
        self.pan_from = None
        self.press_pos = None
        self.erasing_tablet = False
        self.cache = {}
        self.cache_order = []
        self.fast, self.fast_doc = None, None   # 原样出图的课件：直接解 JPEG（frames.FrameSource）
        self.fast_timer = QTimer(self)
        self.fast_timer.timeout.connect(self._collect_fast)
        self._layer = None
        self._layer_key = None
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TabletTracking, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.preload = QTimer(self)
        self.preload.setSingleShot(True)
        self.preload.timeout.connect(self._preload)
        self.settle = QTimer(self)          # 缩放停下来之后再按新尺寸渲染
        self.settle.setSingleShot(True)
        self.settle.timeout.connect(self.update)
        self.run_timer = QTimer(self)
        self.run_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.run_timer.timeout.connect(self._tick_run)
        self.auto_timer = QTimer(self)
        self.auto_timer.setSingleShot(True)
        self.auto_timer.timeout.connect(self._auto_next)
        self._apply_cursor()
        self.pen_session = PenSession(self, lambda:self.history().strokes, self._live_ink,
                                      self._commit_ink,self.to_page,self.to_view,self.scale)

    def _live_ink(self,strokes):
        h = self.history()
        h.strokes = list(strokes)
        h._bump()
        self.update()

    def _commit_ink(self,before,after):
        if self.history().replace(after,before):
            self.ink_changed.emit()
        self.update()

    # ---- 几何
    @property
    def pdf(self) -> int:
        """现在显示的是 PDF 的第几页。"""
        return self.frames[self.frame]["page"] if self.frames else 0

    def final_pdf(self, slide: int) -> int:
        """这张幻灯片所有动画放完的样子（目录里用）。"""
        return self.frames[self.slides[slide]["last"]]["page"]

    def page_size(self, page=None):
        s = self.doc.pagePointSize(self.pdf if page is None else self.frames[self.slides[page]["first"]]["page"])
        return max(1.0, s.width()), max(1.0, s.height())

    def fit_scale(self, page=None):
        pw, ph = self.page_size(page)
        w, h = max(1, self.width()), max(1, self.height())
        if self.kind == "doc":
            return min((w - 48) / pw, 2.2) if w > 80 else w / pw
        return min(w / pw, h / ph)

    def scale(self):
        return self.fit_scale() * self.zoom

    def page_rect(self) -> QRectF:
        pw, ph = self.page_size()
        s = self.scale()
        rw, rh = pw * s, ph * s
        w, h = self.width(), self.height()
        x = (w - rw) / 2 if rw <= w else max(w - rw, min(0.0, self.ox))
        y = (h - rh) / 2 if rh <= h else max(h - rh, min(0.0, self.oy))
        return QRectF(x, y, rw, rh)

    def to_page(self, pos) -> QPointF:
        r = self.page_rect()
        s = self.scale()
        return QPointF((pos.x() - r.x()) / s, (pos.y() - r.y()) / s)

    def to_view(self, pt) -> QPointF:
        r = self.page_rect()
        s = self.scale()
        return QPointF(r.x() + pt.x() * s, r.y() + pt.y() * s)

    def view_rect(self, rect: QRectF) -> QRectF:
        a = self.to_view(rect.topLeft())
        s = self.scale()
        return QRectF(a.x(), a.y(), rect.width() * s, rect.height() * s)

    # ---- 翻页与缩放
    def history(self, page=None) -> ink.History:
        page = self.page if page is None else page
        i = self.slides[page].get("history_id",page)
        if i not in self.histories:
            self.histories[i] = ink.History()
        return self.histories[i]

    def go(self, i: int, at_bottom: bool = False, at_end: bool = False) -> None:
        """跳到某一张。默认从头放它的动画；at_end 表示停在放完的样子（往回翻时）。"""
        i = max(0, min(self.pages - 1, i))
        if i == self.page:
            return
        self.pen_session.reset()
        if self.active is not None:
            self._finish_stroke()
        self._stop_run()
        self.page = i
        self.frame = self.slides[i]["last" if at_end else "first"]
        self.sel = None
        self.ox = 0.0
        self.oy = -1e9 if at_bottom else 0.0
        self.selected.emit(QRectF())
        self.page_changed.emit(i)
        self.frame_changed.emit()
        self.update()
        self._after_frame()

    def next(self):
        """点一下：动画还在放就先放完；否则进到下一个画面。"""
        if self.run is not None:
            self._finish_run()
            return
        self._advance()

    def _advance(self):
        if self.frame + 1 >= len(self.frames):
            return
        nxt = self.frames[self.frame + 1]
        old_pdf = self.pdf
        if nxt["slide"] != self.page:
            self.pen_session.reset()
            if self.active is not None:
                self._finish_stroke()
            trans = self.slides[nxt["slide"]].get("transition")
            self.page = nxt["slide"]
            self.frame += 1
            self.sel = None
            self.ox, self.oy = 0.0, 0.0
            self.selected.emit(QRectF())
            self.page_changed.emit(self.page)
            self.frame_changed.emit()
            if trans and trans["kind"] != "cut":
                self._start_run(old_pdf, nxt["page"], [], trans)
            else:
                self.update()
                self._after_frame()
            return
        self.frame += 1
        self.frame_changed.emit()
        if nxt["effects"]:
            self._start_run(old_pdf, nxt["page"], nxt["effects"], None)
        else:
            self.update()
            self._after_frame()

    def prev(self):
        """往回不放动画，一步步退（和 PPT 放映一样）。"""
        self._stop_run()
        if self.frame <= 0:
            return
        f = self.frames[self.frame - 1]
        if f["slide"] != self.page:
            self.go(f["slide"], at_end=True)
            return
        self.frame -= 1
        self.frame_changed.emit()
        self.update()

    def start(self):
        """开始放映时调用：有的动画是一进来就自动放的。"""
        self._after_frame()

    # ---- 动画
    def _start_run(self, a, b, effects, transition):
        s = self.scale()
        w, h = self._pixel_size(None, s)
        self.run = Run(self._render(a, w, h), self._render(b, w, h), effects, transition)
        self.run_t0 = time.perf_counter()
        self.run_timer.start(14)
        self.update()

    def _tick_run(self):
        if self.run is None or time.perf_counter() - self.run_t0 >= self.run.total:
            self._finish_run()
        else:
            self.update()

    def _stop_run(self):
        self.auto_timer.stop()
        self.run_timer.stop()
        self.run = None

    def _finish_run(self):
        self._stop_run()
        self.update()
        self._after_frame()

    def _after_frame(self):
        """这个画面放完了：下一个是自动接上的、或者这张设了自动换片，就排上。"""
        self.auto_timer.stop()
        if self.frame + 1 < len(self.frames) and self.frames[self.frame + 1]["auto"] and self.frames[self.frame + 1]["slide"] == self.page:
            self.auto_timer.start(40)
            return
        sl = self.slides[self.page]
        if self.frame == sl["last"] and sl.get("adv") is not None and self.frame + 1 < len(self.frames):
            self.auto_timer.start(max(40, int(sl["adv"] * 1000)))

    def _auto_next(self):
        if self.run is None:
            self._advance()

    def set_zoom(self, z, anchor=None):
        z = max(1.0, min(6.0, z))
        anchor = anchor or QPointF(self.width() / 2, self.height() / 2)
        pt = self.to_page(anchor)
        self.zoom = z
        s = self.scale()
        self.ox, self.oy = anchor.x() - pt.x() * s, anchor.y() - pt.y() * s
        self.settle.start(140)
        self.update()

    def set_tool(self, tool):
        self.pen_session.reset()
        if self.active is not None:
            self._finish_stroke()
        self.tool = tool
        if tool != "select" and self.sel is not None:
            self.clear_selection()
        self._apply_cursor()
        self.update()

    def clear_selection(self):
        self.sel = None
        self.sel_drag = None
        self.selected.emit(QRectF())
        self.update()

    def _apply_cursor(self):
        c = {"pen": Qt.CursorShape.CrossCursor, "marker": Qt.CursorShape.CrossCursor, "select": Qt.CursorShape.CrossCursor, "eraser": Qt.CursorShape.PointingHandCursor}.get(self.tool, Qt.CursorShape.ArrowCursor)
        self.setCursor(QCursor(c))

    # ---- 渲染
    def use_frames(self, source, base) -> None:
        """挂上取图器。base 是原课件的 PDF：插页文档（inserts.Document）前面的页就是它的页，照样能直接取图；
        插进来的页不在 doc.pdf 里，取图器给不出，自动回到渲染。"""
        if self.fast is not None and self.fast is not source:
            self.fast.close()
        self.fast, self.fast_doc = source, base

    def _fast_ok(self) -> bool:
        return self.fast is not None and getattr(self.doc, "base", self.doc) is self.fast_doc and self.fast.usable

    def page_image(self, page, w, h) -> QImage:
        """某一页按这个像素大小的图（目录缩略图、截图也用它）。"""
        im = self.fast.image(page, w, h) if self._fast_ok() else None
        return im if im is not None else render_page(self.doc, page, w, h)

    def _remember(self, key, pm):
        self.cache[key] = pm
        self.cache_order.append(key)
        while len(self.cache_order) > 12:
            self.cache.pop(self.cache_order.pop(0), None)

    def _render(self, page, w, h) -> QPixmap:
        key = (page, w, h)
        pm = self.cache.get(key)
        if pm is None:
            pm = QPixmap.fromImage(self.page_image(page, w, h))
            self._remember(key, pm)
        return pm

    def _collect_fast(self):
        if self.fast is None:
            self.fast_timer.stop()
            return
        for page, w, h, im in self.fast.done():
            if (page, w, h) not in self.cache:
                self._remember((page, w, h), QPixmap.fromImage(im))
        if not self.fast.pending:
            self.fast_timer.stop()

    def _pixel_size(self, slide, scale):
        pw, ph = self.page_size(slide)
        d = self.devicePixelRatioF()
        return max(1, int(pw * scale * d)), max(1, int(ph * scale * d))

    def _preload(self):
        if not self.isVisible() or self.run is not None:
            return
        fast = self._fast_ok()
        # 能在后台解图时多备几张：连点翻页也不卡；否则只备前后各一张（同步渲染，备多了会顿）
        for i in ((self.frame + 1, self.frame + 2, self.frame + 3, self.frame - 1) if fast else (self.frame + 1, self.frame - 1)):
            if 0 <= i < len(self.frames):
                f = self.frames[i]
                pw = self.doc.pagePointSize(f["page"])
                k = self.fit_scale(f["slide"]) * (self.zoom if f["slide"] == self.page else 1.0)
                d = self.devicePixelRatioF()
                w, h = max(1, int(pw.width() * k * d)), max(1, int(pw.height() * k * d))
                if fast:
                    if (f["page"], w, h) not in self.cache:
                        self.fast.request(f["page"], w, h)
                else:
                    self._render(f["page"], w, h)
        if fast and self.fast.pending:
            self.fast_timer.start(15)

    def _ink_layer(self, r, marker=False) -> QPixmap:
        d = self.devicePixelRatioF()
        h = self.history()
        key = (self.page, round(r.width()), round(r.height()), h.version, d,marker)
        cache = getattr(self,"_ink_cache",{})
        if key not in cache:
            pm = QPixmap(max(1, int(r.width() * d)), max(1, int(r.height() * d)))
            pm.setDevicePixelRatio(d)
            pm.fill(Qt.GlobalColor.transparent)
            if h.strokes:
                p = QPainter(pm)
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                s = self.scale()
                p.scale(s, s)
                for st in h.strokes:
                    if (st["tool"] == "marker") == marker:
                        ink.draw(p, st)
                p.end()
            if len(cache) >= 2:
                cache.clear()
            cache[key] = pm
            self._ink_cache = cache
        return cache[key]

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.fillRect(self.rect(), BG_DOC if self.kind == "doc" else BG_SLIDE)
        if self.pages <= 0:
            p.end()
            return
        r = self.page_rect()
        s = self.scale()
        w, h = self._pixel_size(None, s)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        if self.run is not None:
            p.save()
            p.setClipRect(r)
            p.translate(r.topLeft())
            k = r.width() / max(1, self.run.a.width())
            p.scale(k, k)
            self.run.paint(p, time.perf_counter() - self.run_t0)
            p.restore()
        else:
            pm = None
            if self.settle.isActive():      # 正在缩放：先拉伸已有的那张，停下来再重新渲染
                for key in reversed(self.cache_order):
                    if key[0] == self.pdf:
                        pm = self.cache[key]
                        break
            pm = pm or self._render(self.pdf, w, h)
            p.drawPixmap(r, pm, QRectF(pm.rect()))
        if self.history().strokes:
            p.save()
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
            p.drawPixmap(r.topLeft(), self._ink_layer(r,True))
            p.restore()
            p.drawPixmap(r.topLeft(), self._ink_layer(r))
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self.active is not None:
            p.save()
            p.translate(r.topLeft())
            p.scale(s, s)
            ink.draw(p, self.active)
            p.restore()
        self._paint_selection(p)
        self.pen_session.paint(p)
        if getattr(self,"source_rect",None) is not None:
            p.setPen(QPen(QColor("#F0B44D"),2,Qt.PenStyle.DashLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(self.view_rect(self.source_rect))
        p.end()
        if not self.settle.isActive() and not self.preload.isActive():
            self.preload.start(160)

    def _paint_selection(self, p):
        rect = self.sel_drag or self.sel
        if rect is None or rect.isEmpty():
            return
        v = self.view_rect(rect)
        shade = QColor(0, 0, 0, 120)
        W, H = self.width(), self.height()
        p.fillRect(QRectF(0, 0, W, v.top()), shade)
        p.fillRect(QRectF(0, v.bottom(), W, H - v.bottom()), shade)
        p.fillRect(QRectF(0, v.top(), v.left(), v.height()), shade)
        p.fillRect(QRectF(v.right(), v.top(), W - v.right(), v.height()), shade)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor("#FFFFFF"), 1.5))
        p.drawRect(v)
        p.setPen(QPen(QColor("#E0563C"), 1.5, Qt.PenStyle.DashLine))
        p.drawRect(v)
        p.setBrush(QColor("#FFFFFF"))
        p.setPen(QPen(QColor("#E0563C"), 1.5))
        for c in (v.topLeft(), v.topRight(), v.bottomLeft(), v.bottomRight()):
            p.drawEllipse(c, 4, 4)

    # ---- 笔
    def _begin_stroke(self, pos, pr, pressure):
        tool = self.tool if self.tool in ("marker","chalk") else "pen"
        s = self.scale()
        w = (self.width_px * (4.5 if tool == "marker" else 1.0)) / s
        col = "#FFD60A" if tool == "marker" and self.color == "#E5484D" else self.color
        self.active = ink.new_stroke(tool, col, w, pressure and tool in ("pen","chalk"))
        q = self.to_page(pos)
        ink.add_point(self.active, q.x(), q.y(), pr)
        self._dirty_tail()

    def _extend_stroke(self, pos, pr):
        q = self.to_page(pos)
        if ink.add_point(self.active, q.x(), q.y(), pr, 0.6 / self.scale()):
            self._dirty_tail()

    def _dirty_tail(self):
        """只重画笔尖附近；荧光笔半透明，要整笔重画。"""
        if self.active is None:
            return
        if self.active["tool"] == "marker":
            self.update(self.view_rect(ink.bounds(self.active)).toAlignedRect().adjusted(-3, -3, 3, 3))
            return
        pts = ink.points_of(self.active)[-4:]
        s = self.scale()
        m = (self.active["width"] * 1.6 * s) + 3
        vs = [self.to_view(QPointF(a[0], a[1])) for a in pts]
        xs, ys = [v.x() for v in vs], [v.y() for v in vs]
        self.update(QRectF(min(xs) - m, min(ys) - m, max(xs) - min(xs) + 2 * m, max(ys) - min(ys) + 2 * m).toAlignedRect())

    def _finish_stroke(self):
        if self.active is None:
            return
        st, self.active = self.active, None
        self.history().add(st)
        self.ink_changed.emit()
        self.update()

    def _erase_at(self, pos):
        q = self.to_page(pos)
        r = 10.0 / self.scale()
        h = self.history()
        gone = [s for s in h.strokes if ink.hit(s, q.x(), q.y(), r)]
        if gone:
            h.remove(gone)
            self.ink_changed.emit()
            self.update()

    def undo(self):
        self.pen_session.reset()
        if self.history().undo():
            self.ink_changed.emit()
            self.update()

    def redo(self):
        self.pen_session.reset()
        if self.history().redo():
            self.ink_changed.emit()
            self.update()

    def clear_page(self):
        self.pen_session.reset()
        self.history().clear()
        self.ink_changed.emit()
        self.update()

    def ink_data(self) -> dict:
        keep = getattr(self,"persistent_empty",set())
        return {str(k): v.strokes for k, v in self.histories.items() if v.strokes or k in keep}

    # ---- 输入
    def _press(self, pos, pr=1.0, pressure=False, eraser=False):
        self.activity.emit()
        self.press_pos = QPointF(pos)
        self.press_t = time.perf_counter()
        if eraser or self.tool == "eraser":
            self.erasing_tablet = True
            self._erase_at(pos)
        elif self.tool in ("pen", "marker", "chalk"):
            self._begin_stroke(pos, pr, pressure)
        elif self.tool == "select":
            self.sel = None
            self.selected.emit(QRectF())
            self.sel_start = self._clamp_page(self.to_page(pos))
            self.sel_drag = QRectF(self.sel_start, self.sel_start)
            self.select_begin()
            self.update()
        else:
            self.pan_from = (QPointF(pos), self.page_rect().x(), self.page_rect().y())

    def select_begin(self):
        """开始框选：提前连上搜索站。"""
        from .lookup import warm
        warm()

    def _clamp_page(self, q):
        pw, ph = self.page_size()
        return QPointF(max(0.0, min(pw, q.x())), max(0.0, min(ph, q.y())))

    def _move(self, pos, pr=1.0):
        if self.erasing_tablet:
            self._erase_at(pos)
        elif self.active is not None:
            self._extend_stroke(pos, pr)
        elif self.sel_drag is not None:
            self.sel_drag = QRectF(self.sel_start, self._clamp_page(self.to_page(pos))).normalized()
            self.update()
        elif self.pan_from is not None:
            a, x0, y0 = self.pan_from
            self.ox = x0 + pos.x() - a.x()
            self.oy = y0 + pos.y() - a.y()
            self.update()

    def _release(self, pos):
        if self.erasing_tablet:
            self.erasing_tablet = False
        elif self.active is not None:
            self._finish_stroke()
        elif self.sel_drag is not None:
            rect, self.sel_drag = self.sel_drag, None
            v = self.view_rect(rect)
            if v.width() >= MIN_SELECT and v.height() >= MIN_SELECT:
                self.sel = rect
                self.selected.emit(rect)
            self.update()
        elif self.pan_from is not None:
            a = self.pan_from[0]
            self.pan_from = None
            moved = math.hypot(pos.x() - a.x(), pos.y() - a.y())
            if moved < 5 and self.kind == "slides" and self.tool == "pointer" and self.zoom == 1.0:
                self.next()   # 单击下一页，和 PPT 放映一样

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.RightButton:
            if self.tool == "pointer":
                self.prev()
            return
        if e.button() == Qt.MouseButton.LeftButton:
            self._press(e.position())

    def mouseMoveEvent(self, e):  # noqa: N802
        self.activity.emit()
        if e.buttons() & Qt.MouseButton.LeftButton:
            self._move(e.position())

    def mouseReleaseEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._release(e.position())

    def tabletEvent(self, e):  # noqa: N802
        """手写笔：有压感；笔尾橡皮直接擦。"""
        t = e.type()
        pos = e.position()
        eraser = e.pointerType() == QPointingDevice.PointerType.Eraser
        if t == e.Type.TabletPress:
            self._press(pos, e.pressure(), True, eraser)
        elif t == e.Type.TabletMove:
            self._move(pos, e.pressure())
        elif t == e.Type.TabletRelease:
            self._release(pos)
        e.accept()

    def wheelEvent(self, e):  # noqa: N802
        self.activity.emit()
        dy = e.angleDelta().y()
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.set_zoom(self.zoom * (1.12 if dy > 0 else 1 / 1.12), e.position())
            return
        r = self.page_rect()
        if r.height() <= self.height() + 1:
            self._wheel_flip(dy)
            return
        old = r.y()
        self.ox, self.oy = r.x(), r.y() + dy * 0.9
        if abs(self.page_rect().y() - old) < 0.5:   # 已经滚到头：翻到邻页
            self._wheel_flip(dy, keep_edge=True)
        self.update()

    def _wheel_flip(self, dy, keep_edge=False):
        now = time.perf_counter()
        if now - getattr(self, "_flip_t", 0) < 0.18:   # 触摸板一下会发很多事件
            return
        self._flip_t = now
        if dy < 0:
            self.next()
        elif dy > 0 and self.kind == "slides" and not keep_edge:
            self.prev()   # 幻灯片往回滚一格退一步动画，和 PPT 放映一样
        elif dy > 0:
            self.go(self.page - 1, at_bottom=keep_edge)

    # ---- 截取
    def highlight_source(self,rect):
        self.source_rect = rect
        token = object()
        self._highlight_token = token
        def clear():
            if self._highlight_token is token:
                self.source_rect = None
                self.update()
        QTimer.singleShot(2000,self,clear)
        self.update()

    def capture(self, rect: QRectF, long_side: int = 2000, include_ink=True):
        """返回框内的 QImage（含笔迹）；清晰度和屏幕无关，放到黑板上放大也清楚。"""
        rect = QRectF(rect)
        k = min(long_side / max(1.0, max(rect.width(), rect.height())), 6000 / max(self.page_size()))
        k = max(k, 1.0)
        pw, ph = self.page_size()
        full = self.page_image(self.pdf, int(pw * k), int(ph * k)).convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
        strokes = self.history().strokes
        if strokes and include_ink:
            p = QPainter(full)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.scale(k, k)
            for s in strokes:
                if ink.bounds(s).intersects(rect):
                    ink.draw(p, s)
            p.end()
        return full.copy(int(rect.x() * k), int(rect.y() * k), max(1, int(rect.width() * k)), max(1, int(rect.height() * k)))

    text_lookup = None   # 放映页是演示软件导出的图时，由播放器给出「这一页的文字在哪份 PDF 的第几页」

    def selection_text(self, rect: QRectF) -> str:
        if self.text_lookup is not None:
            found = self.text_lookup(self.pdf)
            if found is not None:
                doc, page = found
                text = text_in_rect(doc, page, rect)
                if text:
                    return text
        return text_in_rect(self.doc, self.pdf, rect)

    def resizeEvent(self, e):  # noqa: N802
        self._layer = None
        if self.run is not None:
            self._finish_run()
        super().resizeEvent(e)
