# 见微 0.3.7 · 交接（2026-11-15）

`store.VERSION` = **0.3.7**。源码改完、全量自测过；**已打包**（2026-11-15）：`E:\space for Claude\jianwei\release-0.3.7-2026-11-15\`，绿色版 271 MB、源码包 2 MB；冻结版自测全过，包里没有 .env、没有像密钥的字符串。用户说明见 `RELEASE-0.3.7.md`。

## 1. 这一轮做了什么

| 事项 | 状态 |
| --- | --- |
| 读文：真 DeepSeek 实测（用户临时放的密钥，测完已删） | 做完；英语对齐改成只比字母数字，颜色先看成分，详见 `HANDOFF-0.3.6.md` §3 |
| 打包 0.3.6 | 做完：`E:\space for Claude\jianwei\release-0.3.6-2026-11-15\`，冻结版自测全过，包里查过没有密钥 |
| 读文：课件框选「读文」键、文字整理、整段替换可撤销、修 Ctrl+Z 失效 | 做完，读文自测 38 项 |
| 观澜：第二批人物 / 金句 / 词条 | 做完：51 / 84 / 34 |
| 观澜：素材库（维度筛选 + 搜索） | 做完 |
| 观澜：新闻筛选偏好（多看 / 少看主题、地区、屏蔽词、条数） | 做完；**没联网跑过一次真实抓取** |
| 观澜：档案搜索、按月筛 | 做完 |
| 见微主窗口观澜页：素材库与筛选卡片 | 做完 |

## 2. 结构

### 读文接课件
- `lecture/player.py`：选区工具条加「读文」（`selection_read`），做成 clip 发给总线，target `"reading"`。
- `kit/transfer_router.py`：`route` 认 `reading` → `read(clip)`：有文字直接 `ReadingPage.set_text`，没文字就用 OCR（`read_done` 信号，和析题那套一样的写法）。
- `reading/analyze.py` `tidy(text, lang)`：接回版面换行；文言去字间空格、句末标点处分段；英语接连字符断词；空行分段。
- `reading/page.py`：
  - `set_text` 编辑区有内容时用 `QTextCursor` 整段替换，放在一个 edit block 里，Ctrl+Z 能回去。
  - **`spacing()` 不再 `setUndoRedoEnabled(False)`**：那样会清空整个撤销栈。现在用 `joinPreviousEditBlock` 把调行距并进上一步编辑；行距已经对的段落直接跳过。

### 观澜
- `guanlan/core/library_more.py`：第二批数据。`library_people/quotes/terms.py` 末尾 `+=` 进各自的列表；id 全局不重复（自测查）。
- `guanlan/core/facets.py`：素材库的维度，不依赖 Qt。
  - 人物：`field`（新条目自带，老条目按 `_FIELD_OF`）、`era`（`_ERA` 归成四段）、`region`（中国 / 世界）、`theme`（`THEMES` 关键词表在 tags + qualities 里匹配，可多选）。
  - 金句：`origin`（自带的，或者按作者是否外国、年份是否早于 1840 推）、`theme`。
  - 词条：`subject`（看 `exam` 字段里有没有「政治：」这类前缀）。
  - `search(kind, picks, text)` 筛条目；`counts(kind, picks, text)` 算每个按键点下去还剩几条，界面据此标数字、把 0 条的变灰。
- `guanlan/ui/base.py`：新增 `Chip`（可勾选；`mode` 给三态用）和 `FlowLayout`（放不下就折行）。`theme.qss()` 加了 QLineEdit 的样式。
- `guanlan/ui/library.py` `LibrarySheet(BaseSheet)`：
  - 顶部固定区：库切换、搜索（180 ms 防抖，`refresh` 开头先停掉防抖计时器）、各维度 `FacetRow`、计数、清除、收起筛选。
  - 结果每次建 20 条（`PAGE`）。人物在这一层里读：`PersonView.build` 多了 `kicker` 参数；`step` 处理 ←→；在人物详情里 `close_sheet` 先回列表。
- `guanlan/ui/window.py`：
  - 各层统一走 `_sheets()`，原来写死的三元组全换掉了；以后再加一层，只要加进 `_sheets()`。
  - `_open_library(kind)`；`_arrow` 在素材库打开时交给 `library_sheet.step`。
  - 今日、人物、金句、档案四页都有 `open_shelf(str)` 信号，连到 `_open_library`。
- 偏好：
  - 存在配置的 `prefs = {more, less, regions, mute}`，`max_stories` 原来就有。
  - `filters.clean_prefs` 清洗手改的配置。
  - `prepare(candidates, weights, prefs)`：先查屏蔽词（只看标题，挡下的计入 reasons「你屏蔽的词」），再过硬门槛，打分后加 `pref_bonus`：多看 +8、少看 −8（第二主题减半），地区 +5。
  - `curator` 把 `prefs`、`pref_hits` 写进 `selection`，`FilterSheet` 里显示「你的偏好」。
  - 设置页 `SettingsSheet._build_prefs`。
- 档案：`pages.archive_match(entry, text, month)`；`ArchivePage` 只重建列表那一块（`list_box`），所以打字时搜索框不会丢焦点。注意切到档案页时，`window._tab_changed` 会用真实索引重新 `set_data`。
- 见微：
  - `guanlan_host.py` 加了 `open_library`、`open_settings`（打开后滚到偏好那一段）、`prefs_summary`、`library_counts`。
  - `pages.build_guanlan` 加「素材库与筛选」卡片。

## 3. 坑

- **折行的 QLabel 不要放进观澜各层的滚动区**：报不出高度，整行会被压扁。用 `TextBlock(...).fit()`（定高、按中文规则折行）。
- 新加的控件要等事件循环跑一轮才显示：自测截图前要 `spin(.2~.3)`，不然截出来是空的。
- `DEFAULT_CONFIG["prefs"]` 是共享的 dict（`load_config` 是浅拷贝），界面一律构造新 dict 再赋值，不能原地改。

## 4. 没做 / 可以接着做

1. 带偏好的新闻抓取没联网跑过。下次真更新后，看「这些新闻是怎么选出来的」里的「你的偏好」。
2. 内容核对：第二批人物的年份和事迹都是常见、有据可查的说法；拿不准的地方已经改成「前后」「约」，或者干脆不写年份。金句的出处和译名都标了。有空可以再请人核一遍。
3. 素材库还可以加：收藏、按「今天的新闻主题」推荐、导出成作文素材卡。
4. 0.3.7 已打包。以后打包同样：**不要把密钥打进去**（`eligible()` 排除 `.env`，构建时数据目录都重定向了）。绿色版没在真机上手点过。

## 5. 测试（全部隔离 JIANWEI_HOME / LOCALAPPDATA）

- `panels_selftest`：通过。这次新加的检查有：偏好 8 项、素材库 20 多项、档案 4 项、主窗口入口 3 项。截图有 `guanlan-library.png`、`guanlan-library-folded.png`、`guanlan-prefs.png`、`guanlan-archive.png`。
- `native.reading.selftest` 38 项通过。
- 全量 `main.py --self-test --no-single`（离屏）：**37 组全部 OK**（2026-11-15）。
