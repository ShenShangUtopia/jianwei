"""见微 · 主窗口的视觉底座（配色与学习窗口的 design/tokens 同一套：墨绿窄栏、朱砂印、冷瓷面板）。"""
from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, QSize, Qt, QVariantAnimation
from PySide6.QtGui import QColor, QFont, QFontDatabase, QFontMetrics, QPainter, QPainterPath, QPen
import re

from PySide6.QtWidgets import (QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea,
                               QVBoxLayout, QWidget)


_THEMES = {
    "day": dict(
        PAPER="#E9EDE9", SIDE="#15231F", CARD="#FFFFFF", INK="#14201D", INK2="#0F6B62",
        SOFT="#58675F", FAINT="#7F8D86", LINE="#D9DFD9", LINE2="#E7EBE6", BODY="#33423D",
        ACCENT="#C8402A", JADE="#21804F", DEEP="#080E0C", WINDOW_LINE="#C3CBC4",
        KEY="#FFFFFF", KEYLINE="#C3CBC4", KEYEDGE="#A5AFA7", KEYHOVER="#E2E7E2", PRI="#14201D", PRIHOVER="#25342F", PRIEDGE="#000000", ONPRI="#F5F7F4",
        SOFTKEY="#F5F7F4", MUTEDLINE="#C3CBC4",
    ),
    "night": dict(
        PAPER="#0C1311", SIDE="#080E0C", CARD="#1A2420", INK="#E6EEE9", INK2="#6FC7B6",
        SOFT="#93A39C", FAINT="#7A8A83", LINE="#25312C", LINE2="#1E2925", BODY="#C2CFC9",
        ACCENT="#EE6448", JADE="#5CC98A", DEEP="#050A08", WINDOW_LINE="#25312C",
        KEY="#1F2B26", KEYLINE="#34423C", KEYEDGE="#080D0B", KEYHOVER="#27342F", PRI="#E6EEE9", PRIHOVER="#FFFFFF", PRIEDGE="#93A39C", ONPRI="#0C1311",
        SOFTKEY="#1A2420", MUTEDLINE="#34423C",
    ),
}
# 水墨皮肤：宣纸底、浓墨字、花青强调、朱砂印（和 native/design/tokens 的 INK_DAY / INK_NIGHT 同一套）
_INK = {
    "day": dict(
        PAPER="#F2EFE7", SIDE="#1D1C1A", CARD="#FFFDF8", INK="#1B1A18", INK2="#2B5F78",
        SOFT="#66625A", FAINT="#8E897E", LINE="#E3DED2", LINE2="#ECE8DE", BODY="#383633",
        ACCENT="#C23B2A", JADE="#3A7A57", DEEP="#0E0E0D", WINDOW_LINE="#CFC9BB",
        KEY="#FFFDF8", KEYLINE="#CFC9BB", KEYEDGE="#B5AE9F", KEYHOVER="#EBE7DC", PRI="#1B1A18", PRIHOVER="#3A3835", PRIEDGE="#000000", ONPRI="#F7F5EE",
        SOFTKEY="#F7F5EE", MUTEDLINE="#CFC9BB",
    ),
    "night": dict(
        PAPER="#121211", SIDE="#0B0B0A", CARD="#21201E", INK="#ECE8DE", INK2="#8FC3D4",
        SOFT="#9D988C", FAINT="#7F7A70", LINE="#2B2A27", LINE2="#262523", BODY="#CFCABE",
        ACCENT="#E05A45", JADE="#6CC492", DEEP="#070706", WINDOW_LINE="#2B2A27",
        KEY="#262523", KEYLINE="#3C3A36", KEYEDGE="#55524C", KEYHOVER="#302E2B", PRI="#ECE8DE", PRIHOVER="#FFFFFF", PRIEDGE="#9D988C", ONPRI="#121211",
        SOFTKEY="#21201E", MUTEDLINE="#3C3A36",
    ),
}
# 手绘皮肤：奶油纸、粗墨线、明亮的色块、硬边投影——简笔画 / 动画片的画风（和 tokens 的 DOODLE_* 同一套）
_DOODLE = {
    "day": dict(
        PAPER="#FFF4DC", SIDE="#27304A", CARD="#FFFFFF", INK="#1F2233", INK2="#2458E6",
        SOFT="#5B5F73", FAINT="#8B8FA3", LINE="#E9DFC6", LINE2="#F3EAD3", BODY="#33374A",
        ACCENT="#F0483C", JADE="#188A5A", DEEP="#12141F", WINDOW_LINE="#1F2233",
        KEY="#FFFFFF", KEYLINE="#1F2233", KEYEDGE="#1F2233", KEYHOVER="#FFEFC2", PRI="#FFC93C", PRIHOVER="#FFD766", PRIEDGE="#1F2233", ONPRI="#1F2233",
        SOFTKEY="#FFF9EC", MUTEDLINE="#1F2233",
    ),
    "night": dict(
        PAPER="#191B2A", SIDE="#10111C", CARD="#262A40", INK="#F6F2E6", INK2="#8FB2FF",
        SOFT="#A9ADC4", FAINT="#7D819A", LINE="#353A54", LINE2="#2B2F45", BODY="#D5D8E8",
        ACCENT="#FF7A6E", JADE="#4FD49A", DEEP="#0A0B13", WINDOW_LINE="#07080E",
        KEY="#2E3350", KEYLINE="#07080E", KEYEDGE="#07080E", KEYHOVER="#3A4066", PRI="#FFC93C", PRIHOVER="#FFD766", PRIEDGE="#07080E", ONPRI="#1F2233",
        SOFTKEY="#262A40", MUTEDLINE="#07080E",
    ),
}
_SKINS = {"ink": _INK, "celadon": _THEMES, "doodle": _DOODLE}
CURRENT_THEME = "day"
CURRENT_SKIN = "ink"


def _pal() -> dict:
    return _SKINS[CURRENT_SKIN][CURRENT_THEME]


# 页面代码里还写着上一代配色的字面量：一律当作语义名，按当前主题换成新色（昼夜都换）
_LEGACY = {
    "#F7F2EB": "PAPER", "#FBF8F3": "CARD", "#FFFFFF": "CARD", "#081F5C": "INK", "#334EAC": "INK2", "#5F6E8C": "SOFT",
    "#93A0B8": "FAINT", "#E6EAF1": "LINE", "#F0F2F6": "LINE2", "#B4553C": "ACCENT", "#3F6F62": "JADE", "#050C1C": "DEEP",
    "#E2E7F0": "WINDOW_LINE", "#44557A": "BODY", "#B9C3D6": "FAINT", "#EDF0F6": "LINE", "#F2F5FB": "KEYHOVER",
}


class C:
    PAPER = QColor("#E9EDE9")
    SIDE = QColor("#15231F")
    CARD = QColor("#FFFFFF")
    INK = QColor("#14201D")
    INK2 = QColor("#0F6B62")
    SOFT = QColor("#58675F")
    FAINT = QColor("#7F8D86")
    LINE = QColor("#D9DFD9")
    LINE2 = QColor("#E7EBE6")
    ACCENT = QColor("#C8402A")
    JADE = QColor("#21804F")
    DEEP = QColor("#080E0C")


def apply_theme(name: str, skin: str | None = None) -> str:
    """切到 day / night（skin 给了就连皮肤一起换），并把 C.* 与 C.*H 都更新；学习窗口的令牌同步切换。"""
    global CURRENT_THEME, CURRENT_SKIN
    if skin is not None:
        CURRENT_SKIN = skin if skin in _SKINS else "ink"
    CURRENT_THEME = name if name in ("day", "night") else "day"
    for k, v in _pal().items():
        setattr(C, k, QColor(v))
        setattr(C, k + "H", v)
    from native.design import tokens
    tokens.set_skin(CURRENT_SKIN)
    tokens.set_theme("night" if CURRENT_THEME == "night" else "day")
    return CURRENT_THEME


def theme() -> str:
    return CURRENT_THEME


def skin() -> str:
    return CURRENT_SKIN


def _swap(text: str) -> str:
    """把旧配色字面量换成当前主题色值（一次扫描，不会连环替换）。"""
    pal = _pal()
    return re.sub(r"#[0-9a-fA-F]{6}\b", lambda m: pal[_LEGACY[m.group(0).upper()]] if m.group(0).upper() in _LEGACY else m.group(0), text)


def qss() -> str:
    return _qss(_pal())


def restyle_tree(root) -> None:
    """把控件里写死的旧配色字面量换成当前主题色；origStyle 留原文，切主题时重新换算。"""
    if root is None:
        return
    try:
        widgets = [root] + root.findChildren(QWidget)
    except Exception:
        return
    for w in widgets:
        try:
            orig = w.property("origStyle")
            if orig is None:
                orig = w.styleSheet() or ""
                if "#" not in orig:      # 没写颜色字面量的控件（绝大多数）不用记、不用换
                    continue
                w.setProperty("origStyle", orig)
            want = _swap(orig)
            if w.styleSheet() != want:
                w.setStyleSheet(want)
        except Exception:
            continue


def _pick(cands: list[str]) -> str:
    fams = set(QFontDatabase.families())
    for c in cands:
        if c in fams:
            return c
    return cands[-1]


UI = _pick(["Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC", "Segoe UI"])
NUM = _pick(["Bahnschrift", "Segoe UI", "Cambria"])   # 仪表读数：DIN 系等高数字
MONO = _pick(["Consolas", "Cascadia Mono", "Courier New"])


def f(size: float = 13, weight: int = 400, spacing: float = 0.0) -> QFont:
    if weight == 600:   # 微软雅黑没有半粗，Windows 上合成出来的字发糊（学习窗口的 tokens.font 也是这么处理的）
        weight = 700
    font = QFont(UI)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    return font


def serif(size: float = 40, weight: int = 600, spacing: float = 0.0) -> QFont:
    font = QFont(NUM)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return font


def mono(size: float = 13, weight: int = 400) -> QFont:
    font = QFont(MONO)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    return font


def _qss(t: dict) -> str:
    bw = 2 if CURRENT_SKIN == "doodle" else 1                       # 手绘皮肤的线是粗的
    hov = t['KEYLINE'] if CURRENT_SKIN == "doodle" else t['FAINT']  # 悬停时的边色
    return f"""
QWidget {{ color: {t['INK']}; font-family: '{UI}'; }}
QToolTip {{ background: {t['INK']}; color: {t['PAPER']}; border: none; padding: 5px 8px; font-size: 11px; }}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 3px 2px 3px 2px; }}
QScrollBar::handle:vertical {{ background: {t['KEYLINE']}; border-radius: 3px; min-height: 36px; }}
QScrollBar::handle:vertical:hover, QScrollBar::handle:vertical:pressed {{ background: {t['FAINT']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
QFrame#card {{ background: {t['CARD']}; border: 1px solid {t['LINE']}; border-radius: 12px; }}
QPushButton {{ border: none; background: transparent; }}
QPushButton#ghost {{ color: {t['SOFT']}; background: transparent; border: 1px solid {t['LINE']}; border-radius: 8px; padding: 0 10px; }}
QPushButton#ghost:hover {{ color: {t['INK']}; background: {t['KEYHOVER']}; }}
QPushButton#btn, QPushButton#btn-soft {{
    background: {t['KEY']}; border: {bw}px solid {t['KEYLINE']}; border-radius: 8px;
    padding: 7px 14px; color: {t['INK']}; font-size: 12.5px;
}}
QPushButton#btn:hover, QPushButton#btn-soft:hover {{ background: {t['KEYHOVER']}; border-color: {hov}; }}
QPushButton#btn:pressed, QPushButton#btn-soft:pressed {{ background: {t['LINE']}; }}
QPushButton#btn:disabled {{ color: {t['FAINT']}; border-color: {t['LINE']}; }}
QPushButton#btn-primary {{
    background: {t['PRI']}; border: 1px solid {t['PRI']}; border-radius: 8px;
    padding: 7px 14px; color: {t['ONPRI']}; font-size: 12.5px; font-weight: 700;
}}
QPushButton#btn-primary:hover {{ background: {t['PRIHOVER']}; border-color: {t['PRIHOVER']}; }}
QPushButton#btn-danger {{
    background: {t['KEY']}; border: 1px solid {t['KEYLINE']}; border-radius: 8px;
    padding: 7px 14px; color: {t['ACCENT']}; font-size: 12.5px;
}}
QPushButton#btn-danger:hover {{ border-color: {t['ACCENT']}; }}
QLabel#kicker {{ color: {t['FAINT']}; font-size: 10px; }}
QLabel#h2 {{ color: {t['INK']}; font-size: 17px; font-weight: 600; }}
QLabel#body {{ color: {t['BODY']}; font-size: 12.5px; }}
QSlider::groove:horizontal {{ height: 4px; background: {t['LINE']}; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {t['INK']}; height: 4px; border-radius: 2px; }}
QSlider::handle:horizontal {{ width: 12px; height: 12px; margin: -6px 0; border-radius: 8px;
    background: {t['CARD']}; border: 2px solid {t['INK']}; }}
QSlider::handle:horizontal:hover, QSlider::handle:horizontal:pressed {{ background: {t['INK']}; }}
QCheckBox {{ color: {t['BODY']}; font-size: 12px; spacing: 8px; }}
QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid {t['FAINT']}; border-radius: 3px; background: {t['KEY']}; }}
QCheckBox::indicator:checked {{ background: {t['INK2']}; border-color: {t['INK2']}; }}
QLineEdit, QDateEdit {{
    background: {t['KEY']}; border: {bw}px solid {t['KEYLINE']}; border-radius: 8px;
    padding: {9 - bw}px {12 - bw}px; color: {t['INK']}; font-size: 12.5px;
}}
QLineEdit {{ selection-background-color: {t['INK2']}; selection-color: {t['DEEP'] if CURRENT_THEME == 'night' else '#FFFFFF'}; }}
QLineEdit:hover {{ border-color: {hov}; }}
QLineEdit:focus {{ border: {bw}px solid {t['INK2'] if CURRENT_SKIN == 'doodle' else t['INK']}; }}
QComboBox {{ background: {t['KEY']}; color: {t['INK']}; border: 1px solid {t['KEYLINE']}; border-radius: 8px; padding: 5px 9px; font-size: 12.5px; }}
QComboBox QAbstractItemView {{ background: {t['CARD']}; color: {t['INK']}; border: 1px solid {t['KEYLINE']}; outline: none; padding: 3px;
    selection-background-color: {t['KEYHOVER']}; selection-color: {t['INK']}; font-size: 12px; }}
QComboBox QAbstractItemView::item {{ min-height: 26px; padding: 0 8px; border-radius: 3px; }}
QMenu {{ background: {t['CARD']}; color: {t['INK']}; border: 1px solid {t['KEYLINE']}; padding: 5px; font-size: 12px; }}
QMenu::item {{ padding: 6px 26px 6px 14px; border-radius: 3px; }}
QMenu::item:selected {{ background: {t['KEYHOVER']}; }}
QMenu::separator {{ height: 1px; background: {t['LINE']}; margin: 4px 8px; }}
"""


def label(text: str, size: float = 12.5, color: QColor | None = None,
          weight: int = 400, wrap: bool = False, spacing: float = 0.0) -> QLabel:
    w = QLabel(text)
    w.setFont(f(size, weight, spacing))
    w.setStyleSheet(f"color:{color.name() if color else C.BODYH}; background: transparent;")
    w.setWordWrap(wrap)
    w.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
    return w


def kicker(text: str) -> QLabel:
    w = QLabel(text)
    w.setObjectName("kicker")
    w.setFont(f(10, 600, 2.4))
    w.setStyleSheet(f"color:{C.FAINTH};background:transparent;")
    return w


def divider(vertical: bool = False) -> QFrame:
    line = QFrame()
    line.setFixedHeight(1) if not vertical else line.setFixedWidth(1)
    line.setStyleSheet(f"background:{C.LINEH};border:none;")
    return line


class Card(QFrame):
    def __init__(self, title: str = "", sub: str = "", pad: tuple[int, int, int, int] = (20, 18, 20, 18)):
        super().__init__()
        self.setObjectName("jcard")     # 自己画（paint_card），不走样式表里的 #card
        self.body = QVBoxLayout(self)
        l, t, r, b = pad
        if dense():     # 紧凑排法：卡片里的留白收掉三成
            l, t, r, b = max(10, int(l * .72)), max(8, int(t * .66)), max(10, int(r * .72)), max(8, int(b * .66))
        self.body.setContentsMargins(l, t, r, b + (int(DROP) if doodle() else 0))
        self.body.setSpacing(6 if dense() else 9)
        if title:
            head = QHBoxLayout()
            head.setSpacing(8)
            t = QLabel(title)
            t.setFont(f(13, 600, 0.4))
            t.setStyleSheet(f"color:{C.INKH};background:transparent;")
            head.addWidget(t)
            self.head = head
            if sub:
                s = QLabel(sub)
                s.setFont(f(10.5))
                s.setStyleSheet(f"color:{C.FAINTH};background:transparent;")
                head.addWidget(s, 0, Qt.AlignmentFlag.AlignBottom)
            head.addStretch(1)
            self.body.addLayout(head)
        self._title = title

    def add(self, w):
        if isinstance(w, QWidget):
            self.body.addWidget(w)
        else:
            self.body.addLayout(w)
        return w

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        paint_card(p, self.rect())
        p.end()


def _mix(a: QColor, b: QColor, k: float) -> QColor:
    k = max(0.0, min(1.0, k))
    return QColor(int(a.red() + (b.red() - a.red()) * k), int(a.green() + (b.green() - a.green()) * k),
                  int(a.blue() + (b.blue() - a.blue()) * k), int(a.alpha() + (b.alpha() - a.alpha()) * k))


class _Key(QPushButton):
    """自己画的按键的公共部分：悬停渐变、按下时从落点晕开的一圈墨、键盘焦点环。

    设计（0.3.2）：平的，圆角 8，高 34；不再有实体下沿和按下时的 1 像素下沉。
    层级只靠填色区分——主键实心墨色，普通键纸面 + 细边，轻键只有一层淡墨，危险键朱砂字。
    """

    H = 34
    RADIUS = 8.0

    def __init__(self, text: str = ""):
        super().__init__(text)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        self.setFixedHeight(self.H)
        self._h = 0.0           # 悬停进度 0..1
        self._ripple = 0.0      # 墨晕进度 0..1（0 表示没有）
        self._at = QPointF(0, 0)
        self._hover_anim = QVariantAnimation(self)
        self._hover_anim.setDuration(120)
        self._hover_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._hover_anim.valueChanged.connect(self._set_h)
        self._ripple_anim = QVariantAnimation(self)
        self._ripple_anim.setDuration(380)
        self._ripple_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._ripple_anim.setStartValue(0.02)
        self._ripple_anim.setEndValue(1.0)
        self._ripple_anim.valueChanged.connect(self._set_ripple)
        self._ripple_anim.finished.connect(lambda: self._set_ripple(0.0))

    def _set_h(self, v) -> None:
        self._h = float(v)
        self.update()

    def _set_ripple(self, v) -> None:
        self._ripple = float(v)
        self.update()

    def _hover_to(self, end: float) -> None:
        self._hover_anim.stop()
        if not motion():
            self._set_h(end)
            return
        self._hover_anim.setStartValue(self._h)
        self._hover_anim.setEndValue(end)
        self._hover_anim.start()

    def enterEvent(self, e) -> None:  # noqa: N802
        self._hover_to(1.0)
        super().enterEvent(e)

    def leaveEvent(self, e) -> None:  # noqa: N802
        self._hover_to(0.0)
        super().leaveEvent(e)

    def mousePressEvent(self, e) -> None:  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton and motion():
            self._at = e.position()
            self._ripple_anim.stop()
            self._ripple_anim.start()
        super().mousePressEvent(e)

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return self.sizeHint()

    # 子类给出：面色、边色、字色、墨晕色
    def _colors(self):
        raise NotImplementedError

    def _radius(self) -> float:
        return self.RADIUS

    def _paint_key(self, p: QPainter) -> QColor:
        fill, line, text, wash = self._colors()
        if not self.isEnabled():
            p.setOpacity(0.45)
        if doodle():
            # 手绘：每颗键都有 2 像素墨线和一条硬边投影；按下去键面沉到投影上
            r = QRectF(self.rect()).adjusted(1, 1, -1, -1 - DROP)
            rad = min(self._radius() + 2, r.height() / 2)
            if self.isDown():
                r.translate(0, DROP - 1)
            elif fill.alpha() > 200:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(C.KEYLINE)
                p.drawRoundedRect(r.translated(0, DROP), rad, rad)
            path = QPainterPath()
            path.addRoundedRect(r, rad, rad)
            p.setPen(QPen(C.KEYLINE, 2) if fill.alpha() > 200 else Qt.PenStyle.NoPen)
            p.setBrush(fill)
            p.drawPath(path)
            self._face = r
        else:
            r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
            rad = min(self._radius(), r.height() / 2)
            path = QPainterPath()
            path.addRoundedRect(r, rad, rad)
            p.setPen(QPen(line, 1) if line is not None else Qt.PenStyle.NoPen)
            p.setBrush(fill)
            p.drawPath(path)
            self._face = r
        if self.isDown():
            p.fillPath(path, QColor(wash.red(), wash.green(), wash.blue(), 26))
        if self._ripple > 0:
            p.save()
            p.setClipPath(path)
            reach = max(self.width(), self.height()) * 1.15
            c = QColor(wash)
            c.setAlphaF(0.20 * (1 - self._ripple))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(c)
            p.drawEllipse(self._at, reach * self._ripple, reach * self._ripple)
            p.restore()
        if self.hasFocus() and self.focusPolicy() != Qt.FocusPolicy.NoFocus:
            ring = QColor(C.INK2)
            ring.setAlpha(170)
            p.setPen(QPen(ring, 1.6))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(r.adjusted(2, 2, -2, -2), max(1.0, rad - 2), max(1.0, rad - 2))
        return text


class Btn(_Key):
    """文字按键。variant：primary 主键 / 空串 普通键 / soft 轻键 / danger 危险键；icon 是 design.icons 里的名字。"""

    def __init__(self, text: str, variant: str = "", tip: str = "", icon: str = ""):
        super().__init__(text)
        self.variant, self.icon_name = variant, icon
        self.setObjectName("jbtn")      # 不叫 btn：样式表里的 #btn 规则是给外来的原生按钮用的
        self.setFont(f(12.5, 700 if variant == "primary" else 500))
        if tip:
            self.setToolTip(tip)

    def sizeHint(self) -> QSize:  # noqa: N802
        w = QFontMetrics(self.font()).horizontalAdvance(self.text()) + 32 + (22 if self.icon_name else 0)
        return QSize(max(64, w), self.H)

    def _colors(self):
        h = self._h
        if self.variant == "primary":
            return _mix(C.PRI, C.PRIHOVER, h), None, QColor(C.ONPRI), QColor(C.ONPRI)
        if self.variant == "soft":
            base = QColor(C.INK)
            base.setAlphaF(0.055 + 0.055 * h)
            return base, None, QColor(C.INK), QColor(C.INK)
        if self.variant == "danger":
            wash = QColor(C.ACCENT)
            wash.setAlphaF(0.10 * h)
            return _mix(C.KEY, _mix(C.KEY, C.ACCENT, 0.10), h), _mix(C.KEYLINE, C.ACCENT, h), QColor(C.ACCENT), QColor(C.ACCENT)
        return _mix(C.KEY, C.KEYHOVER, h), _mix(C.KEYLINE, C.FAINT, h), QColor(C.INK), QColor(C.INK)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        text = self._paint_key(p)
        fm = QFontMetrics(self.font())
        tw = fm.horizontalAdvance(self.text())
        iw = 22 if self.icon_name else 0
        x = (self.width() - tw - iw) / 2
        if self.icon_name:
            from native.design.icons import draw_icon
            draw_icon(p, self.icon_name, QRectF(x, self._face.center().y() - 8, 16, 16), text, 1.6)
        p.setFont(self.font())
        p.setPen(text)
        p.drawText(QRectF(x + iw, self._face.y(), tw + 2, self._face.height() - 1),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.text())
        p.end()


class Chip(_Key):
    """筛选用的小圆角键：选中是实心墨色。"""

    H = 30

    def __init__(self, text: str):
        super().__init__(text)
        self.setObjectName("jchip")
        self.setCheckable(True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFont(f(12))

    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(QFontMetrics(self.font()).horizontalAdvance(self.text()) + 28, self.H)

    def _radius(self) -> float:
        return self.H / 2

    def _colors(self):
        if self.isChecked():
            return _mix(C.PRI, C.PRIHOVER, self._h), None, QColor(C.ONPRI), QColor(C.ONPRI)
        return _mix(C.KEY, C.KEYHOVER, self._h), _mix(C.KEYLINE, C.FAINT, self._h), _mix(C.SOFT, C.INK, self._h), QColor(C.INK)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        text = self._paint_key(p)
        font = QFont(self.font())
        if self.isChecked():
            font.setWeight(QFont.Weight.Bold)
        p.setFont(font)
        p.setPen(text)
        p.drawText(self._face.adjusted(0, 0, 0, -1), int(Qt.AlignmentFlag.AlignCenter), self.text())
        p.end()


class TickRow(QWidget):
    """1 格 = 1 周：瓷器的刻度，不是进度条。"""

    def __init__(self, total: int = 32, filled: int = 12, label_text: str = ""):
        super().__init__()
        self.total, self.filled, self.label_text = total, filled, label_text
        self.setFixedHeight(34)
        self.setMinimumWidth(240)

    def set(self, total: int, filled: int, label_text: str = ""):
        self.total, self.filled, self.label_text = total, max(0, filled), label_text
        self.update()

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        w = self.width()
        right_pad = 92 if self.label_text else 0
        gap = 3.0
        cell = max(1.6, (w - right_pad - gap * (self.total - 1)) / max(1, self.total))
        y = 12
        for i in range(self.total):
            x = i * (cell + gap)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.ACCENT if i == self.filled - 1 else (C.INK if i < self.filled else C.LINE))
            p.drawRect(QRectF(x, y, cell, 12 if (i + 1) % 4 == 0 else 8))
        if self.label_text:
            p.setPen(QPen(C.FAINT))
            p.setFont(f(10.5))
            p.drawText(QRectF(w - right_pad + 10, y - 4, right_pad - 10, 18),
                       int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), self.label_text)
        p.end()


class Dot(QWidget):
    def __init__(self, color: QColor = C.JADE, size: int = 6):
        super().__init__()
        self.color, self.size = color, size
        self.setFixedSize(size, size)

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(self.color)
        p.drawEllipse(QRectF(0, 0, self.size, self.size))
        p.end()


def lab(text: str, size: float = 12.5, tone: str = "BODY", weight: int = 400,
        spacing: float = 0.0, wrap: bool = False) -> QLabel:
    """一行字：tone 是配色的语义名（INK / BODY / SOFT / FAINT / INK2 / ACCENT / JADE），建的时候就按当前主题取色。"""
    w = QLabel(text)
    w.setFont(f(size, weight, spacing))
    w.setStyleSheet(f"color:{getattr(C, tone + 'H')};background:transparent;")
    if wrap:
        w.setWordWrap(True)
    return w


# 页面布局（配置键 pageLayout）：整个主窗口怎么组织。和风格、疏密互不相干，可以任意搭
PAGE_LAYOUTS = (("pages", "经典页面 · 左边菜单，一次看一个功能"),
                ("desktop", "模块桌面 · 没有侧栏，功能摆成一张桌面，直接在块里用"),
                ("workspace", "工作台 · 几个功能并排同屏，可拖动、改大小、增减"))
PAGE_LAYOUT = "pages"
DENSE = False       # 疏密（配置键 density）：紧凑时页边距、卡片留白、行高都收小


def set_page_layout(name) -> str:
    global PAGE_LAYOUT
    PAGE_LAYOUT = name if name in ("pages", "desktop", "workspace") else "pages"
    return PAGE_LAYOUT


def set_dense(on: bool) -> None:
    global DENSE
    DENSE = bool(on)


def split() -> bool:
    """0.3.4 的「分栏」排法：已被模块桌面 / 工作台取代，现在总是 False（pages.py 里的分栏分支留着不用）。"""
    return False


def dense() -> bool:
    return DENSE


def doodle() -> bool:
    """当前是不是手绘皮肤：粗墨线 + 硬边投影，卡片和按键的画法和另外两套不一样。"""
    return CURRENT_SKIN == "doodle"


CARD_RADIUS = 12.0
DROP = 3.0      # 手绘皮肤里硬边投影往下错开多少


def paint_card(p: QPainter, rect, radius: float = CARD_RADIUS, hover: bool = False, down: bool = False,
               fill: QColor | None = None, line: QColor | None = None) -> QRectF:
    """画一张卡片的底，返回卡片面所在的矩形（内容照这个矩形排）。

    水墨 / 青瓷：一圈细线。手绘：2 像素墨线 + 向下错开的硬边投影；按下时面沉下去、投影收掉。
    """
    r = QRectF(rect)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    if not doodle():
        face = r.adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(QPen(line or (C.INK if hover else C.LINE), 1))
        p.setBrush(fill or C.CARD)
        p.drawRoundedRect(face, radius, radius)
        return face
    face = r.adjusted(1, 1, -1, -1 - DROP)
    if down:
        face.translate(0, DROP - 1)
    else:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.KEYLINE)
        p.drawRoundedRect(face.translated(0, DROP), radius, radius)
    p.setPen(QPen(line or C.KEYLINE, 2))
    p.setBrush(fill or (C.KEYHOVER if hover else C.CARD))
    p.drawRoundedRect(face, radius, radius)
    return face


def title_font(size: float = 22, weight: int = 700) -> QFont:
    """页面标题的字：界面字体的粗体，字距放开一点。

    试过水墨皮肤用楷体：开发机上没有装楷体，效果核对不了，各台电脑装的楷体也不一样，所以不用。
    """
    return f(size, weight, 1.2 if CURRENT_SKIN == "ink" else 0.4)


class BrushRule(QWidget):
    """标题下面那一笔：水墨皮肤是一道由浓到淡、收笔变细的墨痕，青瓷皮肤是一条细线。"""

    def __init__(self):
        super().__init__()
        self.setFixedHeight(9)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        w = self.width()
        if CURRENT_SKIN == "doodle":      # 手绘：标题下一道荧光笔似的黄杠，带墨线
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.fillRect(0, 4, w, 1, C.LINE)
            p.setPen(QPen(C.KEYLINE, 1.6))
            p.setBrush(C.PRI)
            p.drawRoundedRect(QRectF(1, 1, 64, 7), 3.5, 3.5)
            p.end()
            return
        if CURRENT_SKIN != "ink":
            p.fillRect(0, 4, w, 1, C.LINE)
            p.end()
            return
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.fillRect(0, 4, w, 1, C.LINE)
        # 起笔顿一下、行笔渐细、收笔飞白：一个上下不对称的细长形
        length = min(150.0, w * 0.3)
        path = QPainterPath(QPointF(0, 4.4))
        path.cubicTo(4, 0.6, 14, 1.2, length * 0.35, 2.6)
        path.cubicTo(length * 0.6, 3.4, length * 0.85, 4.0, length, 4.3)
        path.cubicTo(length * 0.8, 5.2, length * 0.5, 6.2, length * 0.25, 6.6)
        path.cubicTo(10, 7.2, 2, 7.4, 0, 4.4)
        from PySide6.QtGui import QLinearGradient
        g = QLinearGradient(0, 0, length, 0)
        ink = QColor(C.INK)
        g.setColorAt(0.0, ink)
        mid = QColor(ink)
        mid.setAlphaF(0.75)
        g.setColorAt(0.55, mid)
        end = QColor(ink)
        end.setAlphaF(0.0)
        g.setColorAt(1.0, end)
        p.fillPath(path, g)
        p.end()


def motion() -> bool:
    """要不要放界面过渡动画。自测截图时关掉，不然截到的是过渡到一半的画面。"""
    import os
    return os.environ.get("JIANWEI_SELFTEST") != "1" and os.environ.get("QT_QPA_PLATFORM") != "offscreen"


class Check(QCheckBox):
    """自己画的勾选框：选中是一块青瓷色 + 白勾（样式表画不出勾），切换时有一小段过渡。"""

    BOX = 16

    def __init__(self, text: str = ""):
        super().__init__(text)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(f(12))
        self._k = 0.0
        self._hover = False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(130)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._step)
        self.toggled.connect(self._animate)

    def setChecked(self, on: bool) -> None:  # noqa: N802
        super().setChecked(on)
        if self._anim.state() != QVariantAnimation.State.Running:
            self._k = 1.0 if self.isChecked() else 0.0

    def _step(self, v) -> None:
        self._k = float(v)
        self.update()

    def _animate(self, on: bool) -> None:
        self._anim.stop()
        if not self.isVisible() or not motion():
            self._k = 1.0 if on else 0.0
            self.update()
            return
        self._anim.setStartValue(self._k)
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def sizeHint(self) -> QSize:  # noqa: N802
        fm = QFontMetrics(self.font())
        return QSize(self.BOX + 9 + fm.horizontalAdvance(self.text()) + 4, max(24, fm.height() + 6))

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return self.sizeHint()

    def hitButton(self, pos) -> bool:  # noqa: N802
        return self.rect().contains(pos)

    def enterEvent(self, e) -> None:  # noqa: N802
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e) -> None:  # noqa: N802
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        b = self.BOX
        box = QRectF(0.5, (self.height() - b) / 2 + 0.5, b - 1, b - 1)
        k = self._k
        on = QColor(C.INK2)
        if not self.isEnabled():
            on = QColor(C.FAINT)
        fill = QColor(C.KEY)
        if k > 0:
            fill = QColor(int(fill.red() + (on.red() - fill.red()) * k), int(fill.green() + (on.green() - fill.green()) * k),
                          int(fill.blue() + (on.blue() - fill.blue()) * k))
        if doodle():
            p.setPen(QPen(C.KEYLINE, 1.8))
        else:
            p.setPen(QPen(on if (k > 0.5 or self._hover) else C.FAINT, 1))
        p.setBrush(fill)
        p.drawRoundedRect(box, 4, 4)
        if k > 0.02:
            path = QPainterPath()
            x, y = box.x(), box.y()
            path.moveTo(x + 3.6, y + 7.9)
            path.lineTo(x + 6.5, y + 10.7)
            path.lineTo(x + 11.6, y + 4.9)
            mark = QColor(C.ONPRI if CURRENT_THEME == "night" else QColor("#FFFFFF"))
            mark.setAlphaF(min(1.0, k * 1.4))
            p.setPen(QPen(mark, 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
        p.setFont(self.font())
        p.setPen(C.BODY if self.isEnabled() else C.FAINT)
        p.drawText(QRectF(b + 9, 0, self.width() - b - 9, self.height()),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.text())
        p.end()


class Combo(QComboBox):
    """自己画的下拉框：和按键一样带下沿，右边一个细箭头（Fusion 默认的那块凸起箭头和这套界面不搭）。"""

    def __init__(self):
        super().__init__()
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(f(12))
        self._hover = False
        self.setMinimumHeight(34)

    def sizeHint(self) -> QSize:  # noqa: N802
        fm = QFontMetrics(self.font())
        widest = max([fm.horizontalAdvance(self.itemText(i)) for i in range(self.count())] or [40])
        return QSize(widest + 46, 34)

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return self.sizeHint()

    def enterEvent(self, e) -> None:  # noqa: N802
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e) -> None:  # noqa: N802
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        if doodle():
            r = r.adjusted(0.5, 0.5, -0.5, -0.5)
            p.setPen(QPen(C.KEYLINE, 2))
        else:
            p.setPen(QPen(C.FAINT if self._hover else C.KEYLINE, 1))
        p.setBrush(C.KEYHOVER if self._hover else C.KEY)
        p.drawRoundedRect(r, 8, 8)
        p.setFont(self.font())
        p.setPen(C.INK)
        p.drawText(QRectF(11, 0, self.width() - 36, self.height() - 1),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.currentText())
        cx, cy = self.width() - 16, self.height() / 2 - 0.5
        p.setPen(QPen(C.SOFT, 1.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        path = QPainterPath()
        path.moveTo(cx - 4, cy - 2)
        path.lineTo(cx, cy + 2)
        path.lineTo(cx + 4, cy - 2)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        p.end()


class SmoothScroll(QScrollArea):
    """滚轮滚动带一小段缓动：一格一格跳着走的长页面读起来累。触控板（像素级滚动）原样放行。"""

    STEP = 96        # 滚轮一格走多少像素
    MS = 210
    SMOOTH = True    # design/ux 的全局过滤器认这个标记：滑块上的滚轮转给这里时也走缓动

    def __init__(self, parent=None):
        super().__init__(parent)
        self._target = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(self.MS)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(lambda v: self.verticalScrollBar().setValue(int(round(float(v)))))

    def wheelEvent(self, e) -> None:  # noqa: N802
        bar = self.verticalScrollBar()
        dy = e.angleDelta().y()
        if bar.maximum() <= 0 or dy == 0 or not e.pixelDelta().isNull() or e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            super().wheelEvent(e)
            return
        running = self._anim.state() == QVariantAnimation.State.Running
        base = self._target if running else float(bar.value())
        self._target = max(float(bar.minimum()), min(float(bar.maximum()), base - dy / 120.0 * self.STEP))
        self._anim.stop()
        if not motion():
            bar.setValue(int(self._target))
        else:
            self._anim.setStartValue(float(bar.value()))
            self._anim.setEndValue(self._target)
            self._anim.start()
        e.accept()

    def scroll_top(self) -> None:
        self._anim.stop()
        self.verticalScrollBar().setValue(0)


apply_theme("day")


def row(*widgets, spacing: int = 8, stretch_last: bool = False) -> QHBoxLayout:
    lay = QHBoxLayout()
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(spacing)
    for w in widgets:
        if w is None:
            lay.addStretch(1)
        elif isinstance(w, QWidget):
            lay.addWidget(w)
        else:
            lay.addLayout(w)
    if stretch_last:
        lay.addStretch(1)
    return lay
