"""素材库：人物 / 金句 / 词条全部条目，按几个方面筛、全文搜索。从右边滑入，和其他层一样 Esc 返回。

每排筛选按键后面标着「点下去还剩几条」，0 条的变灰；结果超过一页时点「再显示」往下加，
免得一次建几十张卡片。点开一条（或「随机翻一条」）就在这一层里单独读，←→ 在筛出来的条目里换。

0.3.8 起：每条右上角有星标收藏（存在 data/favorites.json）；「只看收藏」「和今天的新闻相关」
两个开关可以和其他筛选叠加；每条都能「复制素材卡」；Ctrl+F 跳到搜索框。
"""
from __future__ import annotations

import random

from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QVBoxLayout, QWidget

from .base import Chip, FlowLayout, Hairline, IconButton, TextBlock, TextButton
from .cards import PersonSeal, QuoteCard, TermCard, _card, _label
from .pages import PersonView, clear_layout
from .sheets import BaseSheet
from .theme import C

PAGE = 20
UNIT = {"people": "位", "quotes": "句", "terms": "个"}


class StarButton(IconButton):
    """收藏星标：空心 = 没收藏，实心强调色 = 已收藏。"""

    def __init__(self, on: bool = False, parent: QWidget | None = None):
        super().__init__("star", "", 28, C.MUTED, parent)
        self.set_on(on)

    def set_on(self, on: bool) -> None:
        self.on = bool(on)
        self._color = C.ACCENT if self.on else C.MUTED
        self.setToolTip("取消收藏" if self.on else "收藏这一条")
        self.set_icon("star_fill" if self.on else "star")


class PersonRow(QWidget):
    """人物库里的一行：印章、名字、身份、一句话，右边星标。"""
    clicked = Signal(dict)

    def __init__(self, person: dict, star: StarButton | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.person = person
        self._hover = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 8, 6, 8)
        lay.setSpacing(10)
        seal = PersonSeal(person.get("monogram", ""))
        seal.setFixedSize(40, 40)
        lay.addWidget(seal, 0, Qt.AlignmentFlag.AlignTop)
        # 都用定高的 TextBlock：会折行的 QLabel 放在滚动区里报不出高度，整行会被压扁
        col = QVBoxLayout()
        col.setSpacing(1)
        col.addWidget(TextBlock(f"{person.get('name', '')}  ·  {person.get('years', '')}", 13, 700, C.TEXT, 1, 1.5))
        col.addWidget(TextBlock(person.get("identity", ""), 12, 400, C.MUTED, 2, 1.45).fit())
        col.addWidget(TextBlock(person.get("headline", ""), 12, 400, C.TEXT_SOFT, 2, 1.5).fit())
        lay.addLayout(col, 1)
        if star is not None:
            lay.addWidget(star, 0, Qt.AlignmentFlag.AlignTop)

    def enterEvent(self, e) -> None:
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.person)
        super().mousePressEvent(e)

    def paintEvent(self, e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        _card(p, QRectF(self.rect()).adjusted(.5, .5, -.5, -.5), C.CARD_HOVER if self._hover else C.CARD, 7)


class FacetRow(QWidget):
    """一个维度：左边名字，右边一串可以折行的按键（全部 + 各选项），单选。"""
    picked = Signal(str, str)

    def __init__(self, key: str, label: str, options, parent: QWidget | None = None):
        super().__init__(parent)
        self.key = key
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        name = _label(label, 12, 600, C.MUTED)
        name.setFixedWidth(52)
        lay.addWidget(name, 0, Qt.AlignmentFlag.AlignTop)
        box = QWidget()
        self.flow = FlowLayout(box, 5)
        lay.addWidget(box, 1)
        self.chips: dict[str, Chip] = {}
        from core.facets import ALL
        for opt in (ALL,) + tuple(options):
            chip = Chip(opt)
            chip.setChecked(opt == ALL)
            chip.clicked.connect(lambda _=False, o=opt: self._pick(o))
            self.flow.addWidget(chip)
            self.chips[opt] = chip
        self.value = ALL

    def _pick(self, opt: str) -> None:
        self.set_value(opt)
        self.picked.emit(self.key, opt)

    def set_value(self, opt: str) -> None:
        self.value = opt
        for o, c in self.chips.items():
            c.setChecked(o == opt)

    def set_counts(self, counts: dict) -> None:
        from core.facets import ALL
        for o, c in self.chips.items():
            n = counts.get(o, 0)
            c.set_count(None if o == ALL else n)
            c.setEnabled(o == self.value or n > 0)
        self.flow.invalidate()


class LibrarySheet(BaseSheet):
    copy_requested = Signal(str)
    card_copied = Signal(str)
    collect_requested = Signal(dict)
    open_url = Signal(str)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, "素材库")
        from core import favorites
        from core.facets import KINDS
        self.kinds = KINDS
        self.kind = "people"
        self.picks: dict[str, dict] = {k: {} for k in KINDS}
        self.results: list[dict] = []
        self.shown = 0
        self.person_index = -1         # 正在单独读第几条（-1 = 在列表里）；人物、金句、词条都用它
        self.favs = favorites.load()
        self.today_themes: list[str] = []
        self.stars: dict[str, list[StarButton]] = {}
        self._rng = random.Random()

        # 顶部固定区：库切换、开关、搜索、各维度；下面滚动区放结果
        head = QWidget()
        hl = QVBoxLayout(head)
        hl.setContentsMargins(8, 0, 8, 4)
        hl.setSpacing(8)
        kinds_box = QWidget()
        kf = FlowLayout(kinds_box, 6)
        self.kind_chips: dict[str, Chip] = {}
        for key, spec in KINDS.items():
            chip = Chip(spec["label"], len(spec["items"]))
            chip.clicked.connect(lambda _=False, k=key: self.open_kind(k, reopen=False))
            kf.addWidget(chip)
            self.kind_chips[key] = chip
        hl.addWidget(kinds_box)

        modes_box = QWidget()
        mf = FlowLayout(modes_box, 6)
        self.fav_chip = Chip("★ 只看收藏")
        self.fav_chip.setToolTip("只显示你收藏的条目，按收藏先后排")
        self.fav_chip.clicked.connect(lambda _=False: self._toggle_mode("_fav"))
        mf.addWidget(self.fav_chip)
        self.today_chip = Chip("和今天的新闻相关")
        self.today_chip.setToolTip("按今天几条新闻的主题挑出相关的条目，越贴近越靠前")
        self.today_chip.clicked.connect(lambda _=False: self._toggle_mode("_today"))
        mf.addWidget(self.today_chip)
        self.today_chip.hide()
        self.random_btn = TextButton("随机翻一条", C.ACCENT, 12, "dice")
        self.random_btn.setToolTip("从当前筛出来的条目里随便挑一条单独看")
        self.random_btn.clicked.connect(self.open_random)
        mf.addWidget(self.random_btn)
        hl.addWidget(modes_box)

        self.search = QLineEdit()
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self._debounce.start())
        hl.addWidget(self.search)
        self.facets_holder = QWidget()
        self.facets_box = QVBoxLayout(self.facets_holder)
        self.facets_box.setContentsMargins(0, 0, 0, 0)
        self.facets_box.setSpacing(6)
        hl.addWidget(self.facets_holder)
        foot = QHBoxLayout()
        self.count_label = _label("", 12, 500, C.DIM)
        foot.addWidget(self.count_label)
        foot.addStretch(1)
        self.fold_btn = TextButton("收起筛选", C.MUTED, 12, "chevron_up")
        self.fold_btn.setToolTip("筛选按键收起来，给结果多留地方")
        self.fold_btn.clicked.connect(self.toggle_facets)
        foot.addWidget(self.fold_btn)
        self.reset_btn = TextButton("清除筛选", C.MUTED, 12, None)
        self.reset_btn.clicked.connect(self.reset)
        foot.addWidget(self.reset_btn)
        hl.addLayout(foot)
        hl.addWidget(Hairline())
        self.layout().insertWidget(1, head)
        self.head = head
        self.rows: dict[str, FacetRow] = {}

        self.back_btn = TextButton("回到列表", C.ACCENT, 13, "chevron_left")
        self.back_btn.clicked.connect(self.back_to_list)
        self.top.insertWidget(2, self.back_btn)
        self.back_btn.hide()

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(180)
        self._debounce.timeout.connect(self.refresh)

        find = QShortcut(QKeySequence(QKeySequence.StandardKey.Find), self)
        find.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        find.activated.connect(self.focus_search)

    # ------------------------------------------------------------ 打开、切换
    def open_kind(self, kind: str = "people", reopen: bool = True) -> None:
        from core import favorites
        if kind not in self.kinds:
            kind = "people"
        if reopen:
            self.favs = favorites.load()      # 见微主窗口或者另一个观澜窗口可能改过
        if kind != self.kind or not self.rows:
            self.kind = kind
            self._build_facets()
        for k, c in self.kind_chips.items():
            c.setChecked(k == kind)
        self.search.blockSignals(True)
        self.search.setText(self.picks[kind].get("_text", ""))
        self.search.blockSignals(False)
        self.search.setPlaceholderText({"people": "搜名字、事迹、品质……（Ctrl+F）", "quotes": "搜句子、作者、出处……（Ctrl+F）",
                                        "terms": "搜词条、定义、考点……（Ctrl+F）"}[kind])
        self.random_btn._text = "随机读一位" if kind == "people" else "随机翻一" + UNIT[kind]
        self.random_btn.updateGeometry()
        self.person_index = -1
        self.refresh()
        if reopen:
            self.open_sheet()

    def set_today(self, themes) -> None:
        """今天新闻的主题（按出现先后）。没有今日版时「和今天的新闻相关」不出现。"""
        self.today_themes = [t for t in (themes or []) if t]
        self.today_chip.setVisible(bool(self.today_themes))
        if not self.today_themes:
            for p in self.picks.values():
                p.pop("_today", None)
        if self.isVisible() and self.person_index < 0:
            self.refresh()

    def focus_search(self) -> None:
        if self.person_index >= 0:
            self.back_to_list()
        self.search.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self.search.selectAll()

    def _build_facets(self) -> None:
        clear_layout(self.facets_box)
        self.rows = {}
        for key, label, opts in self.kinds[self.kind]["rows"]:
            row = FacetRow(key, label, opts)
            row.set_value(self.picks[self.kind].get(key, "全部"))
            row.picked.connect(self._picked)
            self.facets_box.addWidget(row)
            self.rows[key] = row

    def toggle_facets(self) -> None:
        self.facets_holder.setVisible(self.facets_holder.isHidden())
        self._sync_fold()

    def _sync_fold(self) -> None:
        folded = self.facets_holder.isHidden()
        picked = sum(1 for k, v in self.picks[self.kind].items() if not k.startswith("_") and v != "全部")
        self.fold_btn._text = ("展开筛选" + (f"（已选 {picked} 项）" if picked else "")) if folded else "收起筛选"
        self.fold_btn._arrow = "chevron_down" if folded else "chevron_up"
        self.fold_btn.updateGeometry()
        self.fold_btn.update()

    def _picked(self, key: str, value: str) -> None:
        self.picks[self.kind][key] = value
        self.refresh()

    def _toggle_mode(self, key: str) -> None:
        p = self.picks[self.kind]
        p[key] = not p.get(key)
        self.refresh()

    def reset(self) -> None:
        self.picks[self.kind] = {}
        for row in self.rows.values():
            row.set_value("全部")
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self.refresh()

    # ------------------------------------------------------------ 收藏
    def is_fav(self, entry: dict, kind: str | None = None) -> bool:
        return entry.get("id") in self.favs.get(kind or self.kind, [])

    def _star(self, entry: dict) -> StarButton:
        star = StarButton(self.is_fav(entry))
        star.clicked.connect(lambda _=False, e=entry: self.toggle_fav(e))
        self.stars.setdefault(entry.get("id", ""), []).append(star)
        star.destroyed.connect(lambda _o=None, i=entry.get("id", ""), s=star: self._forget_star(i, s))
        return star

    def _forget_star(self, item_id: str, star) -> None:
        lst = self.stars.get(item_id)
        if lst and star in lst:
            lst.remove(star)

    def toggle_fav(self, entry: dict) -> bool:
        from core import favorites
        item_id = entry.get("id")
        if not item_id:
            return False
        try:
            on = favorites.toggle(self.kind, item_id)
        except OSError:
            return self.is_fav(entry)
        self.favs = favorites.load()
        for star in list(self.stars.get(item_id, [])):
            try:
                star.set_on(on)
            except RuntimeError:           # 卡片已经删掉了
                pass
        self._sync_modes()
        return on

    def _sync_modes(self) -> None:
        p = self.picks[self.kind]
        n = len([i for i in self.favs.get(self.kind, []) if any(e.get("id") == i for e in self.kinds[self.kind]["items"])])
        self.fav_chip._text = "★ 只看收藏"
        self.fav_chip.set_count(n)
        self.fav_chip.setChecked(bool(p.get("_fav")))
        self.fav_chip.setEnabled(n > 0 or bool(p.get("_fav")))
        self.today_chip.setChecked(bool(p.get("_today")))

    # ------------------------------------------------------------ 结果
    def _filters(self) -> tuple[dict, str]:
        picks = {k: v for k, v in self.picks[self.kind].items() if not k.startswith("_")}
        return picks, self.search.text()

    def _scope(self) -> dict:
        p = self.picks[self.kind]
        return dict(only=self.favs.get(self.kind, []) if p.get("_fav") else None,
                    themes=self.today_themes if p.get("_today") and self.today_themes else None)

    def refresh(self) -> None:
        from core import facets
        self._debounce.stop()      # 打字时排着的那次刷新作废，免得晚到一步把刚点开的人物又刷回列表
        self.picks[self.kind]["_text"] = self.search.text()
        picks, text = self._filters()
        scope = self._scope()
        self.results = facets.search(self.kind, picks, text, **scope)
        counts = facets.counts(self.kind, picks, text, **scope)
        for key, row in self.rows.items():
            row.set_counts(counts.get(key, {}))
        unit = UNIT[self.kind]
        total = len(self.kinds[self.kind]["items"])
        where = "收藏里" if scope["only"] is not None else ("和今天相关的" if scope["themes"] else "")
        self.count_label.setText(f"{where}找到 {len(self.results)} {unit}" + ("" if len(self.results) == total else f"（共 {total}）"))
        self.reset_btn.setVisible(bool(text.strip()) or any(v != "全部" for v in picks.values())
                                  or bool(self.picks[self.kind].get("_fav") or self.picks[self.kind].get("_today")))
        self.random_btn.setEnabled(bool(self.results))
        self._sync_modes()
        self._sync_fold()
        self.person_index = -1
        self._show_list()

    def _empty_hint(self) -> str:
        p = self.picks[self.kind]
        if p.get("_fav") and not self.favs.get(self.kind):
            return "还没有收藏。看到有用的条目，点右上角的星标就能收进来。"
        if p.get("_fav"):
            return "收藏里没有符合的条目，换个筛选或搜索词，或者关掉「只看收藏」。"
        if p.get("_today"):
            return "今天的新闻主题和这些筛选对不上，关掉「和今天的新闻相关」看看全部。"
        return "没有符合的条目，换个筛选或搜索词试试。"

    def _show_list(self) -> None:
        self.head.show()
        self.back_btn.hide()
        self.title_label.setText("素材库")
        self.clear()
        self.shown = 0
        if not self.results:
            hint = _label(self._empty_hint(), 13, 400, C.MUTED)
            hint.setWordWrap(True)
            self.il.addWidget(hint)
            self.il.addStretch(1)
            return
        self.more_btn = TextButton("", C.ACCENT, 13, "chevron_down")
        self.more_btn.clicked.connect(self._more)
        self.il.addWidget(self.more_btn)
        self.il.addStretch(1)
        self._more()
        self.scroll.stop_scroll()
        self.scroll.verticalScrollBar().setValue(0)

    def _more(self) -> None:
        start, end = self.shown, min(len(self.results), self.shown + PAGE)
        at = self.il.indexOf(self.more_btn)
        for i in range(start, end):
            self.il.insertWidget(at, self._card(self.results[i], i))
            at += 1
        self.shown = end
        left = len(self.results) - end
        self.more_btn.setVisible(left > 0)
        if left > 0:
            self.more_btn._text = f"再显示 {min(PAGE, left)} 条（还有 {left} 条）"
            self.more_btn.updateGeometry()
            self.more_btn.update()

    def _copy_button(self, entry: dict) -> IconButton:
        from core.facets import material_card
        btn = IconButton("copy", "复制素材卡（整条整理成一段文字）", 28, C.MUTED)
        btn.clicked.connect(lambda _=False, e=entry, k=self.kind: self.card_copied.emit(material_card(k, e)))
        return btn

    def _card(self, entry: dict, i: int) -> QWidget:
        if self.kind == "people":
            row = PersonRow(entry, self._star(entry))
            row.clicked.connect(lambda _p, k=i: self.open_person(k))
            return row
        if self.kind == "quotes":
            card = QuoteCard(entry, i + 1)
            card.copy_clicked.connect(self.copy_requested)
            card.collect_requested.connect(self.collect_requested)
            card.add_action(self._star(entry))
            return card
        card = TermCard(entry)
        card.collect_requested.connect(self.collect_requested)
        card.add_action(self._copy_button(entry))
        card.add_action(self._star(entry))
        return card

    # ------------------------------------------------------------ 单独读一条
    def open_random(self) -> None:
        if not self.results:
            return
        choices = [i for i in range(len(self.results)) if i != self.person_index] or [0]
        self.open_person(self._rng.choice(choices))

    def open_person(self, index: int) -> None:
        """单独读第 index 条：人物是完整的人物页，金句、词条是一张大卡加上下条。名字沿用旧的，自测和窗口都在调。"""
        if not self.results:
            return
        self.person_index = index % len(self.results)
        entry = self.results[self.person_index]
        self.head.hide()
        self.back_btn.show()
        self.title_label.setText("")
        self.clear()
        if self.kind == "people":
            view = PersonView()
            view.collect_requested.connect(self.collect_requested)
            view.card_copied.connect(self.card_copied)
            view.build(entry, self.person_index, len(self.results),
                       lambda: self.step(-1), lambda: self.step(1), self.open_url.emit, kicker="人物库",
                       extra=(self._star(entry),))
            self.il.addWidget(view)
        else:
            top = QHBoxLayout()
            top.addWidget(_label(f"{self.kinds[self.kind]['label']}库  {self.person_index + 1} / {len(self.results)}", 12, 700, C.ACCENT))
            top.addStretch(1)
            prev = IconButton("chevron_left", "上一条（←）", 28)
            nxt = IconButton("chevron_right", "下一条（→）", 28)
            prev.clicked.connect(lambda: self.step(-1))
            nxt.clicked.connect(lambda: self.step(1))
            top.addWidget(prev)
            top.addWidget(nxt)
            self.il.addLayout(top)
            self.il.addWidget(self._card(entry, self.person_index))
            if self.kind == "terms":
                for key, name in (("why", "为什么重要"), ("misread", "常见误读")):
                    if entry.get(key):
                        self.il.addWidget(_label(name, 12, 700, C.MUTED))
                        self.il.addWidget(TextBlock(entry[key], 13, 400, C.TEXT_SOFT, 6, 1.6).fit())
            actions = QHBoxLayout()
            actions.setSpacing(16)
            again = TextButton("再随机一" + UNIT[self.kind], C.ACCENT, 13, "dice")
            again.clicked.connect(self.open_random)
            actions.addWidget(again)
            if self.kind == "quotes":
                from core.facets import material_card
                copy = TextButton("复制素材卡", C.MUTED, 13, "copy")
                copy.clicked.connect(lambda: self.card_copied.emit(material_card("quotes", entry)))
                actions.addWidget(copy)
            actions.addStretch(1)
            self.il.addLayout(actions)
            self.il.addStretch(1)
        self.scroll.stop_scroll()
        self.scroll.verticalScrollBar().setValue(0)

    def step(self, d: int) -> bool:
        """←→：单独读一条时换上一条 / 下一条。返回是否处理了。"""
        if self.person_index < 0:
            return False
        self.open_person(self.person_index + d)
        return True

    def back_to_list(self) -> None:
        self.person_index = -1
        self._show_list()

    def close_sheet(self) -> None:
        """单独读一条时按 Esc / 返回：先回列表，再按一次才关。"""
        if self.person_index >= 0 and self.isVisible():
            self.back_to_list()
            return
        super().close_sheet()
