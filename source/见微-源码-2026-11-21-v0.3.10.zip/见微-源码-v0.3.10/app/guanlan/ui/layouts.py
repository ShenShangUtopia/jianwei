"""观澜的另外三种版式（配置键 layout）。

- panel  侧栏面板：原来那块 430 宽、带四个标签页的面板（window.py 自己搭）
- paper  宽版报纸：没有「今日」标签页，焦点 / 线索 / 人物金句档案三栏一眼看全
- card   新闻卡片：一张小卡一次一条，自动轮换，点一下读全文
- strip  标题横条：一条细长横条滚动标题，点标题读全文

卡片和横条读全文时，窗口临时撑大成面板大小盖一层阅读页，关掉就缩回去（window.py 的 _make_room）。
"""
from __future__ import annotations

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget

from .base import BrandMark, IconButton, SnapFade, TextBlock
from .pages import story_key
from .theme import C, font, mono, motion, serif, tint

LAYOUTS = ("panel", "paper", "card", "strip")
LAYOUT_NAMES = {"panel": "侧栏面板", "paper": "宽版报纸", "card": "新闻卡片", "strip": "标题横条"}
LAYOUT_TIPS = {"panel": "原来的样子：一块竖着的面板，四个标签页",
               "paper": "宽的一页：焦点、线索、人物金句并排，一眼看全",
               "card": "桌角一张小卡，一次一条，自动轮换",
               "strip": "一条细长横条滚动标题，最不占地方"}
COMPACT = ("card", "strip")      # 读全文要临时撑大窗口的版式
DRAG_PX = 4


def layout_name(cfg: dict) -> str:
    name = str(cfg.get("layout", "panel"))
    return name if name in LAYOUTS else "panel"


def labelled_stories(edition: dict | None) -> list[tuple[str, dict]]:
    """阅读顺序同 story_list，每条带上栏目名（卡片、横条要写出来）。"""
    if not edition:
        return []
    out = [("今日焦点", edition["lead"])] if edition.get("lead") else []
    try:
        from core.editorial import SECTION_META
    except Exception:   # 单独测控件时没有 core
        SECTION_META = {}
    sections = edition.get("sections") or {}
    for key in ("world", "china_world", "tech", "society"):
        label = SECTION_META.get(key, {}).get("label", "")
        out.extend((label, s) for s in sections.get(key) or [])
    return out


class DragArea(QWidget):
    """按住拖动窗口；没怎么动就松开算一次点击。卡片的正文、横条的标题都既能点又能拖。"""
    clicked = Signal()
    drag_started = Signal(object)
    drag_moved = Signal(object)
    drag_ended = Signal()

    def __init__(self, parent: QWidget | None = None, clickable: bool = True):
        super().__init__(parent)
        self._press: QPoint | None = None
        self._dragging = False
        self._clickable = clickable
        self._hover = False
        if clickable:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._press = event.globalPosition().toPoint()
            self._dragging = False

    def mouseMoveEvent(self, event) -> None:
        if self._press is None:
            return
        pos = event.globalPosition().toPoint()
        if not self._dragging and (pos - self._press).manhattanLength() >= DRAG_PX:
            self._dragging = True
            self.setCursor(Qt.CursorShape.SizeAllCursor)
            self.drag_started.emit(self._press)
        if self._dragging:
            self.drag_moved.emit(pos)

    def mouseReleaseEvent(self, event) -> None:
        if self._press is None:
            return
        was = self._dragging
        self._press, self._dragging = None, False
        if self._clickable:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        else:
            self.unsetCursor()
        if was:
            self.drag_ended.emit()
        elif self._clickable:
            self.clicked.emit()


class Dots(QWidget):
    """第几条：一条一个点，当前这条拉长，读过的点亮一半。"""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.total, self.index, self.read = 0, 0, set()
        self.setFixedHeight(14)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

    def set_state(self, total: int, index: int, read: set[int]) -> None:
        self.total, self.index, self.read = total, index, set(read)
        self.setFixedWidth(max(10, total * 10 + 10))
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        x = 2.0
        cy = self.height() / 2
        for i in range(self.total):
            if i == self.index:
                p.setBrush(C.ACCENT)
                p.drawRoundedRect(QRectF(x, cy - 3, 14, 6), 3, 3)
                x += 18
            else:
                p.setBrush(tint(C.ACCENT, 0.45) if i in self.read else C.HAIRLINE_STRONG)
                p.drawEllipse(QPointF(x + 3, cy), 3, 3)
                x += 10


class _Rotator(QWidget):
    """卡片和横条共用：一组条目、当前第几条、自动轮换（鼠标停在上面时不换）。"""
    open_story = Signal(dict)
    drag_started = Signal(object)
    drag_moved = Signal(object)
    drag_ended = Signal()
    more_clicked = Signal(object)
    collapse_clicked = Signal()
    rotate_toggled = Signal(bool)

    def __init__(self, interval_s: int = 12, rotating: bool = True, parent: QWidget | None = None):
        super().__init__(parent)
        self.items: list[tuple[str, dict]] = []
        self.read_keys: set[str] = set()
        self.index = 0
        self.rotating = rotating
        self._timer = QTimer(self)
        self._timer.setInterval(max(5, int(interval_s)) * 1000)
        self._timer.timeout.connect(self._tick)

    # ---- 数据
    def set_edition(self, edition: dict | None, read_keys=None) -> None:
        old = story_key(self.current()) if self.items else ""
        self.items = labelled_stories(edition)
        self.read_keys = set(read_keys or ())
        keys = [story_key(s) for _l, s in self.items]
        if old in keys:
            self.index = keys.index(old)
        else:   # 新的一版：从第一条没读过的开始
            self.index = next((i for i, k in enumerate(keys) if k not in self.read_keys), 0)
        self._render(0)
        self._sync_timer()

    def mark_read(self, story: dict) -> None:
        self.read_keys.add(story_key(story))
        self._render(0, animate=False)

    def current(self) -> dict:
        return self.items[self.index][1] if self.items else {}

    def step(self, delta: int) -> None:
        if not self.items:
            return
        self.index = (self.index + delta) % len(self.items)
        self._render(delta)
        if self._timer.isActive():
            self._timer.start()     # 手动换过就重新计时，别刚换完又被自动换走

    def set_rotating(self, on: bool) -> None:
        self.rotating = bool(on)
        self._sync_play_icon()
        self._sync_timer()

    def set_interval(self, seconds: int) -> None:
        self._timer.setInterval(max(5, int(seconds)) * 1000)

    def _sync_timer(self) -> None:
        if self.rotating and len(self.items) > 1 and self.isVisible():
            if not self._timer.isActive():
                self._timer.start()
        else:
            self._timer.stop()

    def _tick(self) -> None:
        if self.underMouse() or not self.window().isVisible():
            return
        self.step(1)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._sync_timer()

    def hideEvent(self, event) -> None:
        self._timer.stop()
        super().hideEvent(event)

    def _open(self) -> None:
        if self.items:
            self.open_story.emit(self.current())

    def _wire_drag(self, area: DragArea) -> None:
        area.drag_started.connect(self.drag_started)
        area.drag_moved.connect(self.drag_moved)
        area.drag_ended.connect(self.drag_ended)

    def _sync_play_icon(self) -> None:
        btn = getattr(self, "play_btn", None)
        if btn is not None:
            btn.set_icon("pause" if self.rotating else "play")
            btn.setToolTip("暂停轮换" if self.rotating else "自动轮换")

    def _toggle_rotate(self) -> None:
        self.set_rotating(not self.rotating)
        self.rotate_toggled.emit(self.rotating)

    def _render(self, direction: int, animate: bool = True) -> None:  # 子类实现
        raise NotImplementedError


class CardView(_Rotator):
    """新闻卡片：栏目 + 标题 + 摘要 + 来源，底下一排点和左右键。"""

    def __init__(self, interval_s: int = 12, rotating: bool = True, parent: QWidget | None = None):
        super().__init__(interval_s, rotating, parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        head = DragArea(clickable=False)
        head.setFixedHeight(44)
        hl = QHBoxLayout(head)
        hl.setContentsMargins(14, 8, 8, 2)
        hl.setSpacing(6)
        hl.addWidget(BrandMark(24), 0, Qt.AlignmentFlag.AlignVCenter)
        self.section = _Text("观澜", 13, 700, C.TEXT)
        hl.addWidget(self.section, 1)
        self.count = _Text("", 12, 500, C.DIM, mono_font=True, align=Qt.AlignmentFlag.AlignRight)
        self.count.setFixedWidth(52)
        hl.addWidget(self.count)
        self.more_btn = IconButton("more", "更多", 28)
        self.more_btn.clicked.connect(lambda: self.more_clicked.emit(self.more_btn))
        self.collapse_btn = IconButton("collapse", "收起到屏幕边（Esc）", 28)
        self.collapse_btn.clicked.connect(self.collapse_clicked)
        hl.addWidget(self.more_btn)
        hl.addWidget(self.collapse_btn)
        self._wire_drag(head)
        outer.addWidget(head)

        self.body = _CardBody()
        self.body.clicked.connect(self._open)
        self._wire_drag(self.body)
        outer.addWidget(self.body, 1)
        self._snap = SnapFade(self.body)

        foot = QWidget()
        foot.setFixedHeight(40)
        fl = QHBoxLayout(foot)
        fl.setContentsMargins(10, 0, 10, 6)
        fl.setSpacing(4)
        self.prev_btn = IconButton("chevron_left", "上一条（←）", 28)
        self.next_btn = IconButton("chevron_right", "下一条（→）", 28)
        self.prev_btn.clicked.connect(lambda: self.step(-1))
        self.next_btn.clicked.connect(lambda: self.step(1))
        self.dots = Dots()
        self.play_btn = IconButton("pause", "", 28)
        self.play_btn.clicked.connect(self._toggle_rotate)
        self._sync_play_icon()
        fl.addWidget(self.prev_btn)
        fl.addStretch(1)
        fl.addWidget(self.dots, 0, Qt.AlignmentFlag.AlignVCenter)
        fl.addStretch(1)
        fl.addWidget(self.next_btn)
        fl.addWidget(self.play_btn)
        outer.addWidget(foot)

    def _render(self, direction: int, animate: bool = True) -> None:
        snap = None
        if animate and direction and self.isVisible() and motion():
            snap = self.body.grab()
        if not self.items:
            self.section.set_text("观澜 · 今天还没有内容")
            self.count.set_text("")
            self.body.set_story({}, False)
            self.dots.set_state(0, 0, set())
            return
        label, story = self.items[self.index]
        self.section.set_text(label or "观澜")
        self.count.set_text(f"{self.index + 1} / {len(self.items)}")
        self.body.set_story(story, story_key(story) in self.read_keys)
        read = {i for i, (_l, s) in enumerate(self.items) if story_key(s) in self.read_keys}
        self.dots.set_state(len(self.items), self.index, read)
        if snap is not None:
            self._snap.play(snap, 1 if direction > 0 else -1)


class _CardBody(DragArea):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, clickable=True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 6, 18, 4)
        lay.setSpacing(6)
        self.title = TextBlock("", 17, 700, C.TEXT, 2, 1.4)
        self.summary = TextBlock("", 13, 400, C.TEXT_SOFT, 3, 1.55)
        self.meta = _Text("", 12, 400, C.DIM)
        lay.addWidget(self.title)
        lay.addWidget(self.summary)
        lay.addStretch(1)
        lay.addWidget(self.meta)
        self.setToolTip("点一下读全文")

    def set_story(self, story: dict, read: bool) -> None:
        if not story:
            self.title.setText("今天的内容还没有筛选")
            self.summary.setText("每天早上会自动更新；也可以在「更多」里立即更新。")
            self.meta.set_text("")
            return
        self.title.setText(story.get("display_title") or story.get("title", ""))
        self.title.setColor(C.MUTED if read else C.TEXT)
        self.summary.setText(story.get("summary", ""))
        bits = [story.get("source", ""), (story.get("published_display") or "")[-5:],
                f"约 {story.get('read_minutes', 2)} 分钟", "已读" if read else ""]
        self.meta.set_text("  ·  ".join(b for b in bits if b))

    def paintEvent(self, event) -> None:
        if not self._hover:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.CARD_HOVER)
        p.drawRoundedRect(QRectF(self.rect()).adjusted(8, 0, -8, 0), 7, 7)


class StripView(_Rotator):
    """标题横条：印 · 栏目 · 标题（可点）· 第几条 · 左右 · 更多。"""

    def __init__(self, interval_s: int = 9, rotating: bool = True, parent: QWidget | None = None):
        super().__init__(interval_s, rotating, parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 0, 6, 0)
        lay.setSpacing(4)
        grip = DragArea(clickable=False)
        grip.setFixedWidth(34)
        gl = QHBoxLayout(grip)
        gl.setContentsMargins(0, 0, 0, 0)
        mark = BrandMark(26)
        mark.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        gl.addWidget(mark, 0, Qt.AlignmentFlag.AlignCenter)
        grip.setToolTip("按住拖动")
        self._wire_drag(grip)
        lay.addWidget(grip)
        self.headline = _Headline()
        self.headline.clicked.connect(self._open)
        self._wire_drag(self.headline)
        lay.addWidget(self.headline, 1)
        self._snap = SnapFade(self.headline)
        self.count = _Text("", 12, 500, C.DIM, mono_font=True, align=Qt.AlignmentFlag.AlignRight)
        self.count.setFixedWidth(44)
        lay.addWidget(self.count)
        self.prev_btn = IconButton("chevron_left", "上一条", 28)
        self.next_btn = IconButton("chevron_right", "下一条", 28)
        self.prev_btn.clicked.connect(lambda: self.step(-1))
        self.next_btn.clicked.connect(lambda: self.step(1))
        self.play_btn = IconButton("pause", "", 28)
        self.play_btn.clicked.connect(self._toggle_rotate)
        self._sync_play_icon()
        self.more_btn = IconButton("more", "更多", 28)
        self.more_btn.clicked.connect(lambda: self.more_clicked.emit(self.more_btn))
        for b in (self.prev_btn, self.next_btn, self.play_btn, self.more_btn):
            lay.addWidget(b)

    def _render(self, direction: int, animate: bool = True) -> None:
        snap = None
        if animate and direction and self.isVisible() and motion():
            snap = self.headline.grab()
        if not self.items:
            self.headline.set_story("观澜", "今天的内容还没有筛选", False)
            self.count.set_text("")
            return
        label, story = self.items[self.index]
        self.headline.set_story(label or "观澜", story.get("display_title") or story.get("title", ""),
                                story_key(story) in self.read_keys)
        self.headline.setToolTip(story.get("summary", "") or "点一下读全文")
        self.count.set_text(f"{self.index + 1}/{len(self.items)}")
        if snap is not None:
            self._snap.play(snap, 1 if direction > 0 else -1)


class _Headline(DragArea):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, clickable=True)
        self._tag, self._title, self._read = "", "", False

    def set_story(self, tag: str, title: str, read: bool) -> None:
        self._tag, self._title, self._read = tag, title, read
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect())
        if self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.CARD_HOVER)
            p.drawRoundedRect(r.adjusted(0, 8, 0, -8), 6, 6)
        tag_f = font(12, 700)
        tw = QFontMetrics(tag_f).horizontalAdvance(self._tag) + 14
        tag = QRectF(8, r.center().y() - 11, tw, 22)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(tint(C.SEAL if self._tag == "今日焦点" else C.ACCENT, 0.15))
        p.drawRoundedRect(tag, 4, 4)
        p.setFont(tag_f)
        p.setPen(C.SEAL if self._tag == "今日焦点" else C.ACCENT)
        p.drawText(tag, Qt.AlignmentFlag.AlignCenter, self._tag)
        title_f = font(14, 700)
        p.setFont(title_f)
        p.setPen(C.MUTED if self._read else C.TEXT)
        x = tag.right() + 10
        w = r.width() - x - 8
        p.drawText(QRectF(x, 0, w, r.height()), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                   QFontMetrics(title_f).elidedText(self._title, Qt.TextElideMode.ElideRight, int(w)))


class _Text(QWidget):
    """一行字：自己画，省掉 QLabel 的样式表开销。"""

    def __init__(self, text: str, size: int, weight: int, color, mono_font: bool = False, align=Qt.AlignmentFlag.AlignLeft):
        super().__init__()
        self._text, self._color, self._align = text, color, align
        self._font = mono(size, weight) if mono_font else font(size, weight)
        self.setFixedHeight(QFontMetrics(self._font).height() + 4)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

    def set_text(self, text: str) -> None:
        if text != self._text:
            self._text = text
            self.update()

    def text(self) -> str:
        return self._text

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setFont(self._font)
        p.setPen(self._color)
        fm = QFontMetrics(self._font)
        p.drawText(QRectF(self.rect()), self._align | Qt.AlignmentFlag.AlignVCenter,
                   fm.elidedText(self._text, Qt.TextElideMode.ElideRight, self.width()))


class VRule(QWidget):
    """报纸栏与栏之间的一道竖线。"""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedWidth(1)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setPen(QPen(C.HAIRLINE, 1))
        p.drawLine(0, 10, 0, self.height() - 10)


class ColumnHead(QWidget):
    """报纸每栏顶上的小标题：朱色短条 + 字。"""

    def __init__(self, text: str, parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self.setFixedHeight(30)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.SEAL)
        p.drawRoundedRect(QRectF(14, 9, 3, 14), 1.5, 1.5)
        p.setFont(serif(14, 700))
        p.setPen(C.TEXT)
        p.drawText(QRectF(24, 0, self.width() - 30, self.height()), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self._text)


def build_paper(win) -> QWidget:
    """宽版报纸：顶栏 / 三栏（焦点 · 线索 · 人物金句档案）/ 底栏。用 window 上已经建好的控件拼。"""
    page = QWidget()
    v = QVBoxLayout(page)
    v.setContentsMargins(0, 0, 0, 0)
    v.setSpacing(0)
    v.addWidget(win.topbar)
    v.addWidget(win.busy_line)
    row = QHBoxLayout()
    row.setContentsMargins(4, 0, 4, 0)
    row.setSpacing(0)

    def column(head: str, body: QWidget, stretch: int, width: int | None = None) -> None:
        col = QWidget()
        cl = QVBoxLayout(col)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)
        cl.addWidget(ColumnHead(head))
        cl.addWidget(body, 1)
        if width:
            col.setFixedWidth(width)
        row.addWidget(col, stretch)

    pw = getattr(win, "_panel_w", 1000)
    left_w, right_w = min(330, int(pw * .33)), min(300, int(pw * .30))   # 屏幕窄时两边跟着收，中栏至少留三成
    column("今日焦点", win.today_page, 0, left_w)
    row.addWidget(VRule())
    column("世界线索", win.stories_page, 1)
    row.addWidget(VRule())
    side = QWidget()
    sl = QVBoxLayout(side)
    sl.setContentsMargins(12, 2, 8, 0)
    sl.setSpacing(4)
    sl.addWidget(win.tabs)
    sl.addWidget(win.page_stack, 1)
    side_wrap = QWidget()
    swl = QVBoxLayout(side_wrap)
    swl.setContentsMargins(0, 6, 0, 0)
    swl.addWidget(side)
    side_wrap.setFixedWidth(right_w)
    row.addWidget(side_wrap)
    v.addLayout(row, 1)
    v.addWidget(win.footer)
    return page
