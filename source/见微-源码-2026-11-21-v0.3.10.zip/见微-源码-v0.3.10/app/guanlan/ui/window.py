"""The floating window, its lifecycle, and Windows-native conveniences."""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
import traceback
from ctypes import wintypes
from datetime import datetime, time as dtime
from pathlib import Path

from PySide6.QtCore import (
    QAbstractNativeEventFilter, QCoreApplication, QEasingCurve, QEvent, QPoint, QPropertyAnimation,
    QRect, QRectF, QSize, Qt, QThread, QTimer, QUrl, Signal,
)
from PySide6.QtGui import (QAction, QColor, QDesktopServices, QFont, QIcon, QInputEvent, QKeySequence, QPainter, QPen,
                           QPixmap, QShortcut)
from PySide6.QtWidgets import (
    QApplication, QGraphicsOpacityEffect, QMenu, QStackedWidget, QSystemTrayIcon, QVBoxLayout, QWidget,
)

from core.autostart import is_enabled as autostart_enabled, set_enabled as set_autostart
from core.paths import ARCHIVE_DIR, CONFIG_PATH, DATA_DIR, LATEST_PATH, ROOT, load_config, save_config
from . import theme as _theme
from .base import BusyLine, Panel, Rail, SnapFade, TabBar
from . import layouts as _layouts
from .cards import Footer, TopBar
from .pages import ArchivePage, PeoplePage, QuotesPage, TodayPage, edition_themes, story_key, story_list
from .library import LibrarySheet
from .sheets import DetailSheet, FilterSheet, SettingsSheet, Toast
from .theme import C, paint_shadow, qss, serif


HWND_BOTTOM = 1
HWND_TOP = 0
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010


def _set_window_z(hwnd: int, insert_after: int) -> None:
    try:
        if hwnd:
            ctypes.windll.user32.SetWindowPos(
                hwnd, insert_after, 0, 0, 0, 0,
                SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE,
            )
    except Exception:
        pass


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_ulong),
        ("rcMonitor", RECT),
        ("rcWork", RECT),
        ("dwFlags", ctypes.c_ulong),
    ]


def foreground_is_fullscreen(our_hwnd: int = 0) -> bool:
    try:
        user32 = ctypes.windll.user32
        hwnd = int(user32.GetForegroundWindow())
        if not hwnd or hwnd == our_hwnd:
            return False
        if user32.IsIconic(hwnd):
            return False
        cls = ctypes.create_unicode_buffer(128)
        user32.GetClassNameW(hwnd, cls, 128)
        if cls.value in ("Progman", "WorkerW", "Shell_TrayWnd", "Windows.UI.Core.CoreWindow"):
            return False
        rect = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return False
        MONITOR_DEFAULTTONEAREST = 2
        monitor = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
        if not monitor:
            return False
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        if not user32.GetMonitorInfoW(monitor, ctypes.byref(mi)):
            return False
        m = mi.rcMonitor
        return (
            rect.left <= m.left + 2 and rect.top <= m.top + 2
            and rect.right >= m.right - 2 and rect.bottom >= m.bottom - 2
        )
    except Exception:
        return False


class HotkeyFilter(QAbstractNativeEventFilter):
    def __init__(self, callback):
        super().__init__()
        self.callback = callback
        self.hotkey_id = 0xB017
        self.registered = False

    def install(self) -> bool:
        try:
            user32 = ctypes.windll.user32
            MOD_ALT, MOD_SHIFT, MOD_NOREPEAT = 0x0001, 0x0004, 0x4000
            ok = user32.RegisterHotKey(None, self.hotkey_id, MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, ord("G"))
            if not ok:
                return False
            QCoreApplication.instance().installNativeEventFilter(self)
            self.registered = True
            return True
        except Exception:
            return False

    def remove(self) -> None:
        if not self.registered:
            return
        try:
            ctypes.windll.user32.UnregisterHotKey(None, self.hotkey_id)
            QCoreApplication.instance().removeNativeEventFilter(self)
        except Exception:
            pass
        self.registered = False

    def nativeEventFilter(self, event_type, message):
        try:
            if bytes(event_type) != b"windows_generic_MSG":
                return False, 0
            msg = wintypes.MSG.from_address(int(message))
            if msg.message == 0x0312 and int(msg.wParam) == self.hotkey_id:
                self.callback()
        except Exception:
            pass
        return False, 0


class CuratorWorker(QThread):
    progress = Signal(str)
    ok = Signal(dict)
    failed = Signal(str)

    def __init__(self, force: bool = True, parent=None):
        super().__init__(parent)
        self.force = force

    def run(self) -> None:
        try:
            from core.curator import run
            result = run(force=self.force, log_fn=self.progress.emit)
            self.ok.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc())


class MainWindow(QWidget):
    material_requested=Signal(dict)
    def __init__(self, start_collapsed: bool = False, start_hidden: bool = False):
        super().__init__()
        self._start_collapsed = start_collapsed
        self._start_hidden = start_hidden
        self._initializing = True
        self._watching = False      # 应用级事件过滤器现在挂没挂着（只在面板展开可见时挂）
        self._z_hold_until = 0.0
        self._last_activity = time.monotonic()
        self.cfg = load_config()
        self.edition = None
        self.index_entries: list[dict] = []
        self._busy = False
        self._worker: CuratorWorker | None = None
        self._collapsed = False
        self._animating = False
        self._hidden_for_fullscreen = False
        self._quitting = False
        self._pinned = bool(self.cfg.get("pinned", False))
        self._last_error = ""
        self._auto_attempt_at = None
        self._auto_play = bool(self.cfg.get("auto_play", False))
        self._auto_play_index = 0
        self._play_scroll_anim = None
        self._play_steps = [(0, 0.0), (0, 0.45), (0, 0.8), (1, 0.0), (2, 0.0), (3, 0.0)]

        self.setWindowTitle("观澜 · 每日视界")
        # Deliberately not WindowStaysOnTopHint: Guanlan belongs to the desktop
        # layer. It may be raised by the hotkey/tray, then sinks again when it
        # loses focus or the pointer leaves.
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setMinimumSize(80, 60)
        self.setStyleSheet(qss())
        self.setWindowOpacity(float(self.cfg.get("opacity", 0.99)))

        self.screen_geo = QApplication.primaryScreen().availableGeometry()
        self._embedded = os.environ.get("JIANWEI_EMBED") == "1"
        self._read_date = ""
        self._read: set[str] = set()
        self._drag_from: QPoint | None = None
        self._layout = _layouts.layout_name(self.cfg)
        self._reading = False       # 卡片 / 横条为了读全文临时撑大了
        self._right_gap = 12
        self._top_gap = 8
        self._collapsed_panel = (58, 176)
        self._collapsed_win = (58 + 32, 176 + 32)
        self._target_collapsed = False
        self._apply_layout_size()

        self._build_ui()
        self._load_data()
        self._apply_window_geometry(collapsed=False)
        self._setup_tray()
        self._setup_shortcuts()
        self._setup_hotkey()
        self._setup_timers()

        self._set_collapsed(start_collapsed, animate=False)
        self._initializing = False
        self._z_hold_until = time.monotonic() + 2.5
        if start_hidden:
            self.hide()
        else:
            self.show()
            self._play_startup_fade()
        QTimer.singleShot(1800, self._auto_check)
        QTimer.singleShot(1400, self._ensure_autostart)
        if self._auto_play and not start_hidden:
            QTimer.singleShot(2400, self._begin_auto_play)

    def paintEvent(self, event) -> None:
        # 面板阴影：九宫格贴图（原先的 QGraphicsDropShadowEffect 让面板里每次小重绘都整块重画）
        p = QPainter(self)
        paint_shadow(p, QRectF(self.panel.geometry()), **Panel.SHADOW)
        p.end()

    # ------------------------------------------------------- 后台开销跟着可见性走
    def _sync_watch(self) -> None:
        """记「最近有没有人在用」的事件过滤器挂在整个应用上，每个事件都要过一遍 Python。

        它只在面板展开、看得见的时候有用（自动收起、自动播放让位），其余时间摘掉：
        观澜大部分时间是收起或隐藏的，这段时间不该拖慢见微别的窗口（实验台的动画、课件放映）。
        """
        want = self.isVisible() and not self._collapsed and not self._quitting
        if want == self._watching:
            return
        app = QApplication.instance()
        if app is None:
            return
        if want:
            app.installEventFilter(self)
        else:
            app.removeEventFilter(self)
        self._watching = want

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if hasattr(self, "_z_timer"):
            self._z_timer.start()
            self._fs_timer.start()
        self._sync_watch()

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        if hasattr(self, "_z_timer"):
            self._z_timer.stop()            # 看不见就不用每 1.5 秒重申一次置底
            if not self._hidden_for_fullscreen:
                self._fs_timer.stop()       # 因为全屏才藏起来的要接着查，好在全屏结束后回来
        self._sync_watch()

    # ------------------------------------------------------------------ UI
    def _build_ui(self, rebuild: bool = False) -> None:
        outer = self.layout() if rebuild else QVBoxLayout(self)
        outer.setContentsMargins(16, 16, 16, 16)
        outer.setSpacing(0)
        self.panel = Panel(self)
        outer.addWidget(self.panel)
        panel_layout = QVBoxLayout(self.panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)
        self.view_stack = QStackedWidget()
        self.view_stack.setStyleSheet("background: transparent;")
        panel_layout.addWidget(self.view_stack)

        self.topbar = TopBar()
        self.busy_line = BusyLine()
        self.footer = Footer()
        paper = self._layout == "paper"
        self.today_page = TodayPage(parts=("head", "lead", "kw", "term", "invite") if paper else None)
        self.stories_page = TodayPage(parts=("stories",)) if paper else None
        self.people_page = PeoplePage()
        self.quotes_page = QuotesPage()
        self.archive_page = ArchivePage()
        if paper:   # 报纸的左右两栏比面板窄：单行字允许折行
            for page in (self.today_page, self.stories_page, self.people_page, self.quotes_page, self.archive_page):
                page.narrow = True
        for page in (self.today_page, self.people_page, self.quotes_page) + ((self.stories_page,) if paper else ()):
            page.collect_requested.connect(self.material_requested)
        # 报纸版式里「今日」拆成左两栏，标签页只剩人物 / 金句 / 档案
        tab_pages = ([self.people_page, self.quotes_page, self.archive_page] if paper
                     else [self.today_page, self.people_page, self.quotes_page, self.archive_page])
        self.tabs = TabBar(["人物", "金句", "档案"] if paper else ["今日", "人物", "金句", "档案"])
        self.page_stack = QStackedWidget()
        self.page_stack.setStyleSheet("background: transparent;")
        for page in tab_pages:
            self.page_stack.addWidget(page)

        self.expanded_page = QWidget()
        exp = QVBoxLayout(self.expanded_page)
        exp.setContentsMargins(0, 0, 0, 0)
        exp.setSpacing(0)
        exp.addWidget(self.topbar)
        exp.addWidget(self.busy_line)
        tab_wrap = QWidget()
        tab_layout = QVBoxLayout(tab_wrap)
        tab_layout.setContentsMargins(14, 6, 14, 4)
        tab_layout.setSpacing(0)
        tab_layout.addWidget(self.tabs)
        exp.addWidget(tab_wrap)
        exp.addWidget(self.page_stack, 1)
        exp.addWidget(self.footer)

        self.compact_view = None
        if paper:
            self.expanded_page = _layouts.build_paper(self)
        elif self._layout in _layouts.COMPACT:
            # 卡片 / 横条：面板那一套照样建着（阅读层、刷新状态都挂在上面），只是不显示
            self._panel_holder = self.expanded_page
            self._panel_holder.hide()
            self._panel_holder.setParent(self.panel)
            cls = _layouts.CardView if self._layout == "card" else _layouts.StripView
            secs = int(self.cfg.get("rotate_seconds", 12 if self._layout == "card" else 9) or 12)
            self.compact_view = cls(secs, bool(self.cfg.get("rotate", True)))
            self.compact_view.open_story.connect(self._open_story)
            self.compact_view.drag_started.connect(self._drag_start)
            self.compact_view.drag_moved.connect(self._drag_move)
            self.compact_view.drag_ended.connect(self._drag_end)
            self.compact_view.more_clicked.connect(self._more_menu)
            self.compact_view.collapse_clicked.connect(lambda: self._set_collapsed(True, animate=True))
            self.compact_view.rotate_toggled.connect(self._rotate_toggled)
            self.expanded_page = self.compact_view
        self.view_stack.addWidget(self.expanded_page)

        self.rail = Rail()
        self.view_stack.addWidget(self.rail)

        self.detail_sheet = DetailSheet(self.panel)
        self.filter_sheet = FilterSheet(self.panel)
        self.settings_sheet = SettingsSheet(self.cfg, self.panel, embedded=self._embedded)
        self.library_sheet = LibrarySheet(self.panel)
        self.toast = Toast(self.panel)
        self._page_snap = SnapFade(self.page_stack)
        self._startup_fade = None

        self.today_page.open_story.connect(self._open_story)
        self.today_page.open_filter.connect(self._open_filter)
        self.today_page.refresh_requested.connect(lambda: self.refresh(True))
        if self.stories_page is not None:
            self.stories_page.open_story.connect(self._open_story)
        for sheet in self._sheets():
            sheet.closed.connect(self._leave_room)
        self.detail_sheet.story_opened.connect(self._mark_read)
        self.tabs.changed.connect(self._tab_changed)
        self.people_page.open_url.connect(self._open_url)
        self.quotes_page.copy_requested.connect(self._copy)
        self.archive_page.open_entry.connect(self._open_archive_entry)
        self.archive_page.open_library.connect(self._open_archive)
        for page in (self.people_page, self.quotes_page, self.archive_page, self.today_page):
            page.open_shelf.connect(self._open_library)
        self.library_sheet.copy_requested.connect(self._copy)
        self.library_sheet.card_copied.connect(self._copy_card)
        self.people_page.card_copied.connect(self._copy_card)
        self.library_sheet.collect_requested.connect(self.material_requested)
        self.library_sheet.open_url.connect(self._open_url)
        self.topbar.refresh_clicked.connect(lambda: self.refresh(True))
        self.topbar.pin_toggled.connect(self._pin_toggled)
        self.topbar.collapse_clicked.connect(lambda: self._set_collapsed(True, animate=True))
        self.topbar.more_clicked.connect(self._more_menu)
        self.topbar.drag_started.connect(self._drag_start)
        self.topbar.drag_moved.connect(self._drag_move)
        self.topbar.drag_ended.connect(self._drag_end)
        self.topbar.reset_position.connect(self._reset_position)
        self.footer.clicked.connect(self._footer_clicked)
        self.rail.expand_requested.connect(lambda: self._set_collapsed(False, animate=True))
        self.settings_sheet.refresh_requested.connect(lambda: self.refresh(True))
        self.settings_sheet.archive_requested.connect(self._open_archive)
        self.settings_sheet.settings_changed.connect(self._settings_changed)
        self.settings_sheet.layout_requested.connect(self.set_layout)

        self.topbar.pin_btn.blockSignals(True)
        self.topbar.pin_btn.setChecked(self._pinned)
        self.topbar.pin_btn.blockSignals(False)

    # ------------------------------------------------------------- theme
    def set_theme(self, name: str, skin: str | None = None) -> None:
        """换昼夜 / 皮肤：颜色在控件创建时就取好了，所以整块面板重建（数据不动、停在原来的页）。"""
        want_dark = name != "day"
        if want_dark == C.dark and (skin is None or skin == C.skin):
            return
        tab = self.tabs.active
        _theme.use(name, skin)
        self.setStyleSheet(qss())
        self.layout().removeWidget(self.panel)
        old = self.panel
        old.hide()
        old.setParent(None)
        old.deleteLater()
        self._build_ui(rebuild=True)
        self._load_data()
        if tab:
            self.tabs.set_active(tab)
        self.view_stack.setCurrentWidget(self.rail if self._collapsed else self.expanded_page)
        self.rail.side = self._rail_side()
        self.update()

    # ------------------------------------------------------------ layout
    def _apply_layout_size(self) -> None:
        """面板多大由版式决定；窗口比面板四周各多 16 像素放阴影。"""
        g = self.screen_geo
        lay = self._layout
        if lay == "paper":
            w, h = min(1000, g.width() - 40), min(660, max(420, g.height() - 24))
        elif lay == "card":
            w, h = 400, 264
        elif lay == "strip":
            w, h = min(860, g.width() - 40), 56
        else:
            w, h = 430, min(840, max(420, g.height() - 24))
        self._panel_w, self._panel_h = w, h
        self._win_w, self._win_h = w + 32, h + 32

    def _pos_key(self) -> str:
        """每种版式各记各的位置：横条在屏幕底下，面板在右上，互不打架。"""
        return "panel_pos" if self._layout == "panel" else f"pos_{self._layout}"

    def set_layout(self, name: str) -> None:
        """换版式：整块面板按新版式重搭（数据不动），窗口换成这种版式的大小和位置。"""
        name = name if name in _layouts.LAYOUTS else "panel"
        if name == self._layout:
            return
        if self._auto_play:
            self._set_auto_play(False, announce=False)
        for sheet in self._sheets():
            sheet.hide()
        self._reading = False
        self._layout = name
        self.cfg["layout"] = name
        self._save_cfg()
        self._apply_layout_size()
        self.layout().removeWidget(self.panel)
        old = self.panel
        old.hide()
        old.setParent(None)
        old.deleteLater()
        self._build_ui(rebuild=True)
        self._load_data()
        self._collapsed = False
        self.view_stack.setCurrentWidget(self.expanded_page)
        self.rail.side = self._rail_side()
        self.setGeometry(self._expanded_rect())
        self._sync_watch()
        self._restart_idle()
        self.update()
        self._toast(f"已换成「{_layouts.LAYOUT_NAMES[name]}」")

    def _rotate_toggled(self, on: bool) -> None:
        self.cfg["rotate"] = bool(on)
        self._save_cfg()

    def _make_room(self) -> None:
        """卡片、横条太小，放不下阅读层：临时撑成面板大小（贴着原来的位置往屏幕里长），关掉阅读层再缩回去。"""
        if self._layout not in _layouts.COMPACT or self._reading:
            return
        self._reading = True
        self._compact_geo = self.geometry()
        g = self.screen_geo
        w, h = 430 + 32, min(760, max(420, g.height() - 24)) + 32
        cur = self.geometry()
        x = cur.center().x() - w // 2 if self._layout == "strip" else cur.right() - w + 1
        x = max(g.left() - 16, min(g.right() - w + 17, x))
        y = cur.top() if cur.center().y() < g.center().y() else cur.bottom() - h + 1
        y = max(g.top() - 16, min(g.bottom() - h + 17, y))
        self._z_hold_until = time.monotonic() + 3
        self.setGeometry(QRect(x, y, w, h))
        if self.layout() is not None:
            self.layout().activate()
        self._sync_overlay_geometry()

    def _leave_room(self) -> None:
        if not self._reading or self._open_sheet() is not None:
            return
        self._reading = False
        geo = getattr(self, "_compact_geo", None)
        self.setGeometry(geo if geo is not None else self._expanded_rect())

    # ------------------------------------------------------------- read state
    def _read_path(self) -> Path:
        return DATA_DIR / "read.json"

    def _load_read(self) -> None:
        """只记今天这一版读过哪几条，换版就清零。"""
        date = (self.edition or {}).get("date", "")
        data = self._read_json(self._read_path(), {})
        data = data if isinstance(data, dict) else {}
        keys = data.get("keys") if data.get("date") == date else []
        self._read_date = date
        self._read = {str(k) for k in keys} if isinstance(keys, list) else set()

    def _mark_read(self, story: dict) -> None:
        key = story_key(story)
        if not key or key in self._read:
            return
        self._read.add(key)
        self.today_page.mark_read(story)
        if self.stories_page is not None:
            self.stories_page.mark_read(story)
        if self.compact_view is not None:
            self.compact_view.mark_read(story)
        self._sync_rail()
        try:
            self._read_path().parent.mkdir(parents=True, exist_ok=True)
            tmp = self._read_path().with_suffix(".json.tmp")
            tmp.write_text(json.dumps(dict(date=self._read_date, keys=sorted(self._read)), ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self._read_path())
        except OSError:
            pass   # 已读记录存不下不影响阅读

    def _sync_rail(self) -> None:
        stories = story_list(self.edition)
        label = (self.edition or {}).get("date_label", "") or datetime.now().strftime("%Y.%m.%d")
        self.rail.set_info(label, sum(1 for s in stories if story_key(s) not in self._read), len(stories))

    # ------------------------------------------------------------- data
    def _read_json(self, path: Path, default):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default

    def _load_data(self) -> None:
        self.edition = self._read_json(LATEST_PATH, None)
        self.index_entries = self._read_json(DATA_DIR / "index.json", []) or []
        self._load_read()
        self.today_page.set_edition(self.edition, self._read)
        if self.stories_page is not None:
            self.stories_page.set_edition(self.edition, self._read)
        if self.compact_view is not None:
            self.compact_view.set_edition(self.edition, self._read)
        self.people_page.set_edition(self.edition)
        self.quotes_page.set_edition(self.edition)
        self.archive_page.set_data(self.index_entries, self.edition)
        if getattr(self, "library_sheet", None) is not None:
            self.library_sheet.set_today(edition_themes(self.edition))
        if self.edition:
            self.topbar.set_date(self.edition.get("date_label", ""), self.edition.get("weekday", ""))
            src_count = len(self.edition.get("selection", {}).get("sources", []))
            left = f"今日 {self.edition.get('read_count', 7)} 条，来自 {src_count} 家信源"
            try:
                dt = datetime.fromisoformat(self.edition.get("generated_at", ""))
                right = "更新 " + dt.strftime("%H:%M")
                if self.edition.get("date") != datetime.now().astimezone().date().isoformat():
                    left = f"这是 {self.edition.get('date', '')[5:]} 的版本，共 {self.edition.get('read_count', 7)} 条"
            except Exception:
                right = "更新 07:15"
            self.footer.set_status(left, right, True)
        else:
            self.topbar.set_date(datetime.now().strftime("%Y.%m.%d"), "")
            self.footer.set_status("还没有今日版", "", True)
        self._sync_rail()

    def _tab_changed(self, idx: int) -> None:
        prev = self.page_stack.currentIndex()
        snap = None
        if idx != prev and self.isVisible() and not self._collapsed and not self._animating and _theme.motion():
            snap = self.page_stack.grab()       # 旧页的样子：盖在新页上滑出、淡出
        self.page_stack.setCurrentIndex(idx)
        if snap is not None:
            self._page_snap.play(snap, 1 if idx > prev else -1)
        page = self.page_stack.currentWidget()
        if hasattr(page, "scroll_top"):
            page.scroll_top()
        if page is self.archive_page:
            self.index_entries = self._read_json(DATA_DIR / "index.json", []) or []
            self.archive_page.set_data(self.index_entries, self.edition)
        if getattr(self, "library_sheet", None) is not None:
            self.library_sheet.set_today(edition_themes(self.edition))

    def _play_startup_fade(self) -> None:
        try:
            target = float(self.cfg.get("opacity", 0.99))
            self.setWindowOpacity(0.0)
            anim = QPropertyAnimation(self, b"windowOpacity", self)
            anim.setDuration(280)
            anim.setStartValue(0.0)
            anim.setEndValue(target)
            anim.setEasingCurve(QEasingCurve.Type.OutCubic)
            self._startup_fade = anim
            anim.start()
        except Exception:
            self.setWindowOpacity(float(self.cfg.get("opacity", 0.99)))

    # ------------------------------------------------------------ geometry
    def _expanded_rect(self) -> QRect:
        g = self.screen_geo
        pos = self.cfg.get(self._pos_key())
        if isinstance(pos, list) and len(pos) == 2:   # 换过屏幕也不能跑到看不见的地方
            full = QApplication.primaryScreen().virtualGeometry()
            x = max(full.left() - 16, min(full.right() - self._win_w + 17, int(pos[0])))
            y = max(full.top() - 16, min(full.bottom() - min(120, self._win_h) + 1, int(pos[1])))
            return QRect(x, y, self._win_w, self._win_h)
        if self._layout == "strip":     # 横条默认在屏幕底部居中（顶上留给时间胶囊）
            x = g.left() + (g.width() - self._win_w) // 2
            return QRect(x, g.bottom() - self._win_h + 16 - 10, self._win_w, self._win_h)
        x = g.right() - self._win_w - self._right_gap + 1
        return QRect(x, g.top() + self._top_gap, self._win_w, self._win_h)

    def _rail_side(self) -> str:
        """收起时贴哪条边：面板在屏幕左半边就贴左边。"""
        g = self.screen_geo
        return "left" if self._expanded_rect().center().x() < g.center().x() else "right"

    def _collapsed_rect(self) -> QRect:
        g = self.screen_geo
        w, h = self._collapsed_win
        x = g.left() + self._right_gap - 16 if self._rail_side() == "left" else g.right() - w - self._right_gap + 1
        y = min(max(g.top() + 70, self._expanded_rect().top() + 70), g.bottom() - h - 10)
        return QRect(x, y, w, h)

    # ------------------------------------------------------------ move
    def _drag_start(self, global_pos) -> None:
        self._drag_from = global_pos - self.pos()
        self._drag_origin = self.pos()
        self._z_hold_until = time.monotonic() + 8

    def _drag_move(self, global_pos) -> None:
        if self._drag_from is not None and not self._animating:
            self.move(global_pos - self._drag_from)

    def _drag_end(self) -> None:
        if self._drag_from is None:
            return
        self._drag_from = None
        if self._reading:   # 读全文时拖的是撑大后的窗口：缩回去的卡片跟着挪同样的距离
            geo = QRect(getattr(self, "_compact_geo", self._expanded_rect()))
            geo.translate(self.pos() - self._drag_origin)
            self._compact_geo = geo
            self.cfg[self._pos_key()] = [geo.x(), geo.y()]
        else:
            self.cfg[self._pos_key()] = [self.x(), self.y()]
        self.rail.side = self._rail_side()
        self._save_cfg()

    def _reset_position(self) -> None:
        self.cfg.pop(self._pos_key(), None)
        self.rail.side = self._rail_side()
        self._save_cfg()
        self.setGeometry(self._expanded_rect())
        self._toast("已回到默认位置")

    def _save_cfg(self) -> None:
        try:
            save_config(self.cfg)
        except OSError:
            pass

    def _more_menu(self, anchor) -> None:
        menu = QMenu(self)
        if self._layout in _layouts.COMPACT:
            menu.addAction("立即更新", lambda: self.refresh(True)).setEnabled(not self._busy)
        else:
            play = menu.addAction("自动播放（Ctrl+P）")
            play.setCheckable(True)
            play.setChecked(self._auto_play)
            play.triggered.connect(lambda checked: self._set_auto_play(checked))
        menu.addAction("这些新闻是怎么选出来的", self._open_filter).setEnabled(bool(self.edition))
        menu.addAction("打开今日档案", self._open_archive)
        sub = menu.addMenu("版式")
        for key in _layouts.LAYOUTS:
            act = sub.addAction(_layouts.LAYOUT_NAMES[key])
            act.setCheckable(True)
            act.setChecked(key == self._layout)
            act.setToolTip(_layouts.LAYOUT_TIPS[key])
            act.triggered.connect(lambda _=False, k=key: QTimer.singleShot(0, lambda: self.set_layout(k)))
        menu.addSeparator()
        menu.addAction("设置", self._open_settings)
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    def _apply_window_geometry(self, collapsed: bool) -> None:
        self.setGeometry(self._collapsed_rect() if collapsed else self._expanded_rect())
        self._sync_overlay_geometry()

    def _sync_overlay_geometry(self) -> None:
        for sheet in self._sheets():
            if sheet.isVisible():
                sheet.resize(self.panel.size())

    def _set_collapsed(self, collapsed: bool, animate: bool = True) -> None:
        if self._animating or (self._collapsed == collapsed and self.isVisible()):
            if self._collapsed == collapsed and not animate:
                self.view_stack.setCurrentWidget(self.rail if collapsed else self.expanded_page)
            return
        if not self.isVisible() and not getattr(self, "_initializing", False):
            self.show()
        if collapsed:
            self._reading = False       # 读全文时直接收起：展开回来是版式本来的大小
            if self._auto_play and not self._initializing:
                self._set_auto_play(False, announce=False)
            for sheet in self._sheets():
                if sheet.isVisible():
                    sheet.hide()
            self._idle_timer.stop()
        self.rail.side = self._rail_side()
        self._collapsed = collapsed
        self._sync_watch()
        target = self._collapsed_rect() if collapsed else self._expanded_rect()
        if not animate:
            self.view_stack.setCurrentWidget(self.rail if collapsed else self.expanded_page)
            self.setGeometry(target)
            self._animating = False
            if not collapsed:
                self._restart_idle()
            return
        self._animating = True
        self.view_stack.hide()
        anim = QPropertyAnimation(self, b"geometry", self)
        anim.setDuration(230)
        anim.setStartValue(self.geometry())
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._geom_anim = anim

        def done():
            self.view_stack.setCurrentWidget(self.rail if collapsed else self.expanded_page)
            self.view_stack.show()
            self.view_stack.raise_()
            self._animating = False
            if not collapsed:
                self._restart_idle()
            self._sync_overlay_geometry()

        anim.finished.connect(done)
        anim.start()

    def _restart_idle(self) -> None:
        self._last_activity = time.monotonic()
        if self._auto_play or self._pinned or self._collapsed or not self.isVisible():
            self._idle_timer.stop()
            return
        if not self._idle_timer.isActive():
            self._idle_timer.start()

    def _idle_check(self) -> None:
        if self._auto_play:
            return
        if self._pinned or self._collapsed or not self.isVisible():
            return
        if self._layout in _layouts.COMPACT and not self._reading:
            return      # 卡片、横条本来就小，不用自己收起
        if self._reading and not any(s.isVisible() for s in self._sheets()):
            self._leave_room()
            return
        if any(s.isVisible() for s in self._sheets()):
            self._last_activity = time.monotonic()
            return
        seconds = max(30, int(self.cfg.get("auto_collapse_seconds", 180) or 180))
        if time.monotonic() - self._last_activity >= seconds:
            self._set_collapsed(True, animate=True)

    # ---------------------------------------------------------- auto play
    def _auto_play_interval(self) -> int:
        return max(6, int(self.cfg.get("auto_play_seconds", 12) or 12)) * 1000

    def _set_auto_play(self, enabled: bool, persist: bool = True, announce: bool = True) -> None:
        enabled = bool(enabled)
        if self.compact_view is not None:   # 卡片、横条的「自动播放」就是自己轮换
            if enabled != self.compact_view.rotating:
                self.compact_view.set_rotating(enabled)
                self._rotate_toggled(enabled)
                if announce:
                    self._toast("自动轮换" if enabled else "已暂停轮换")
            return
        if enabled == self._auto_play:
            return
        self._auto_play = enabled
        try:
            if hasattr(self, "act_autoplay"):
                self.act_autoplay.blockSignals(True)
                self.act_autoplay.setChecked(enabled)
                self.act_autoplay.blockSignals(False)
        except Exception:
            pass
        if enabled:
            if self._collapsed:
                self._set_collapsed(False, animate=True)
            self._begin_auto_play()
            if announce:
                self._toast("自动播放已开始 · Ctrl+P 暂停")
        else:
            self._auto_play_timer.stop()
            if self._play_scroll_anim is not None:
                self._play_scroll_anim.stop()
                self._play_scroll_anim = None
            if not self._collapsed:
                self._restart_idle()
            if announce:
                self._toast("自动播放已暂停")
        if persist:
            try:
                self.cfg["auto_play"] = enabled
                save_config(self.cfg)
            except Exception:
                pass

    def _begin_auto_play(self) -> None:
        if not self._auto_play or self.compact_view is not None:
            return
        if self._collapsed:
            self._set_collapsed(False, animate=True)
        self._auto_play_index = 0
        self._idle_timer.stop()
        QTimer.singleShot(320, self._apply_play_step)
        self._auto_play_timer.start(self._auto_play_interval())

    def _auto_play_tick(self) -> None:
        if not self._auto_play:
            return
        if (self._collapsed or not self.isVisible() or self._busy
                or any(s.isVisible() for s in self._sheets())):
            self._auto_play_timer.start(3000)
            return
        if time.monotonic() - self._last_activity < 4.0:
            self._auto_play_timer.start(2500)
            return
        self._auto_play_index = (self._auto_play_index + 1) % len(self._steps())
        self._apply_play_step()
        self._auto_play_timer.start(self._auto_play_interval())

    def _steps(self) -> list:
        """自动播放的步子：（标签页，滚到几成）；报纸版式先把中间一栏的线索滚一遍，再看人物、金句。"""
        if self._layout == "paper":
            return [(None, 0.0), (None, 0.45), (None, 0.9), (0, 0.0), (1, 0.0)]
        return self._play_steps

    def _apply_play_step(self) -> None:
        steps = self._steps()
        if not self._auto_play or not steps:
            return
        tab, fraction = steps[self._auto_play_index % len(steps)]
        if tab is None:
            page = self.stories_page
        else:
            if self.tabs.active != tab:
                self.tabs.set_active(tab)
            page = self.page_stack.widget(tab)
        scroll = getattr(page, "scroll", None)
        if scroll is None:
            return
        bar = scroll.verticalScrollBar()
        target = int(bar.maximum() * max(0.0, min(1.0, fraction)))
        if self._play_scroll_anim is not None:
            self._play_scroll_anim.stop()
        if page is not self.today_page and page is not self.stories_page:
            bar.setValue(0)
            return
        anim = QPropertyAnimation(bar, b"value", self)
        anim.setDuration(680)
        anim.setStartValue(bar.value())
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._play_scroll_anim = anim
        anim.start()

    # ------------------------------------------------------------- timers
    def _setup_timers(self) -> None:
        self._idle_timer = QTimer(self)
        self._idle_timer.setInterval(1000)
        self._idle_timer.timeout.connect(self._idle_check)
        self._auto_play_timer = QTimer(self)
        self._auto_play_timer.setSingleShot(True)
        self._auto_play_timer.timeout.connect(self._auto_play_tick)
        self._auto_timer = QTimer(self)
        self._auto_timer.setInterval(60_000)
        self._auto_timer.timeout.connect(self._auto_check)
        if not self._embedded:      # 内嵌在见微里时抓取由见微的每日节律负责，这个表不用走
            self._auto_timer.start()
        # 下面两个只在窗口看得见时有用：showEvent 里开，hideEvent 里关
        self._fs_timer = QTimer(self)
        self._fs_timer.setInterval(2400)
        self._fs_timer.timeout.connect(self._check_fullscreen)
        self._z_timer = QTimer(self)
        self._z_timer.setInterval(1500)
        self._z_timer.timeout.connect(self._keep_bottom)
        if self.isVisible():
            self._fs_timer.start()
            self._z_timer.start()

    def _send_to_bottom(self) -> None:
        try:
            _set_window_z(int(self.winId()), HWND_BOTTOM)
        except Exception:
            pass

    def _bring_forward(self) -> None:
        self._z_hold_until = time.monotonic() + 5.0
        try:
            self.show()
            self.raise_()
            self.activateWindow()
            _set_window_z(int(self.winId()), HWND_TOP)
        except Exception:
            pass

    def _keep_bottom(self) -> None:
        if not self.isVisible() or self._animating:
            return
        if time.monotonic() < self._z_hold_until:
            return
        if self.isActiveWindow() or self.underMouse():
            return
        if any(s.isVisible() for s in self._sheets()):
            return
        self._send_to_bottom()

    def _auto_check(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            return  # 抓取交给见微的每日节律，避免两头同时跑
        if self._busy:
            return
        now = datetime.now().astimezone()
        today = now.date().isoformat()
        update_at = str(self.cfg.get("update_time", "07:15"))
        try:
            hh, mm = [int(x) for x in update_at.split(":")[:2]]
            cutoff = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        except Exception:
            cutoff = now
        if now < cutoff:
            return
        if self._auto_attempt_at is not None:
            if (now - self._auto_attempt_at).total_seconds() < 600:
                return
        # The edition may already exist from an early/manual refresh. If it was
        # generated before today's cutoff, refresh it once after the cutoff;
        # if it was generated after the cutoff, it is already today's fresh copy.
        if self.edition and self.edition.get("date") == today:
            try:
                generated = datetime.fromisoformat(str(self.edition.get("generated_at", "")))
                if generated.tzinfo is None:
                    generated = generated.replace(tzinfo=now.tzinfo)
                if generated >= cutoff:
                    return
            except Exception:
                pass
        self._auto_attempt_at = now
        self.refresh(force=True)

    def _check_fullscreen(self) -> None:
        if not self.cfg.get("hide_on_fullscreen", True):
            if self._hidden_for_fullscreen:
                self._hidden_for_fullscreen = False
                self.show()
            return
        try:
            hwnd = int(self.winId())
        except Exception:
            hwnd = 0
        is_fs = foreground_is_fullscreen(hwnd)
        if is_fs and self.isVisible():
            self._hidden_for_fullscreen = True
            self.hide()
        elif not is_fs and self._hidden_for_fullscreen:
            self._hidden_for_fullscreen = False
            self.show()
            self._set_collapsed(True, animate=False)

    # ------------------------------------------------------------- tray
    def _make_icon(self) -> QIcon:
        pix = QPixmap(64, 64)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#C8402A"))
        p.drawRoundedRect(4, 4, 56, 56, 9, 9)
        p.setFont(serif(34, 700))
        p.setPen(QColor("#FFFFFF"))
        p.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, "观")
        p.end()
        return QIcon(pix)

    def _setup_tray(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            self.tray = None
            self.act_autostart = self.act_pin = self.act_fullscreen = None
            self.setWindowIcon(self._make_icon())
            return
        self.tray = QSystemTrayIcon(self._make_icon(), self)
        self.tray.setToolTip("观澜 · 每日视界")
        menu = QMenu()
        menu.setStyleSheet(qss())
        act_toggle = QAction("展开 / 收起", self)
        act_toggle.triggered.connect(self.toggle_window)
        act_refresh = QAction("立即更新", self)
        act_refresh.triggered.connect(lambda: self.refresh(True))
        self.act_autoplay = QAction("自动播放", self)
        self.act_autoplay.setCheckable(True)
        self.act_autoplay.setChecked(self._auto_play)
        self.act_autoplay.toggled.connect(self._set_auto_play)
        act_archive = QAction("打开今日档案", self)
        act_archive.triggered.connect(self._open_archive)
        act_library = QAction("打开档案库", self)
        act_library.triggered.connect(self._open_archive_root)
        menu.addAction(act_toggle)
        menu.addAction(act_refresh)
        menu.addAction(self.act_autoplay)
        menu.addAction(act_archive)
        menu.addAction(act_library)
        menu.addSeparator()
        self.act_autostart = QAction("开机自动启动", self)
        self.act_autostart.setCheckable(True)
        self.act_autostart.setChecked(bool(self.cfg.get("auto_start", True)))
        self.act_autostart.toggled.connect(self._tray_autostart)
        self.act_fullscreen = QAction("全屏时自动隐身", self)
        self.act_fullscreen.setCheckable(True)
        self.act_fullscreen.setChecked(bool(self.cfg.get("hide_on_fullscreen", True)))
        self.act_fullscreen.toggled.connect(self._tray_fullscreen)
        self.act_pin = QAction("保持展开", self)
        self.act_pin.setCheckable(True)
        self.act_pin.setChecked(self._pinned)
        self.act_pin.toggled.connect(self._tray_pin)
        menu.addAction(self.act_autostart)
        menu.addAction(self.act_fullscreen)
        menu.addAction(self.act_pin)
        menu.addSeparator()
        act_quit = QAction("退出观澜", self)
        act_quit.triggered.connect(self.quit_app)
        menu.addAction(act_quit)
        self._tray_menu = menu
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()
        self.setWindowIcon(self._make_icon())

    def _tray_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self.toggle_window()

    def _tray_autostart(self, checked: bool) -> None:
        ok, msg = set_autostart(checked)
        if not ok:
            self.act_autostart.blockSignals(True)
            self.act_autostart.setChecked(not checked)
            self.act_autostart.blockSignals(False)
            self._toast("开机自启设置失败")
            return
        self.cfg["auto_start"] = checked
        save_config(self.cfg)
        self.settings_sheet.set_config(self.cfg)
        self._toast(msg)

    def _tray_fullscreen(self, checked: bool) -> None:
        self.cfg["hide_on_fullscreen"] = checked
        save_config(self.cfg)
        self.settings_sheet.set_config(self.cfg)

    def _tray_pin(self, checked: bool) -> None:
        self._set_pinned(checked, from_tray=True)

    def _ensure_autostart(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            return
        if self.cfg.get("auto_start", True) and not autostart_enabled():
            ok, _ = set_autostart(True)
            if not ok:
                self.cfg["auto_start"] = False
                save_config(self.cfg)
                self.settings_sheet.set_config(self.cfg)
                self.act_autostart.blockSignals(True)
                self.act_autostart.setChecked(False)
                self.act_autostart.blockSignals(False)

    # ---------------------------------------------------------- hotkey/shortcut
    def _setup_shortcuts(self) -> None:
        self._esc = QShortcut(QKeySequence("Esc"), self)
        self._esc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self._esc.activated.connect(self._esc_pressed)
        self._play_shortcut = QShortcut(QKeySequence("Ctrl+P"), self)
        self._play_shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self._play_shortcut.activated.connect(lambda: self._set_auto_play(not self._auto_play))
        self._keys = []
        for i in range(4):
            self._add_key(str(i + 1), lambda _=False, k=i: self._go_tab(k))
        self._add_key("R", lambda: self.refresh(True))
        self._add_key("Left", lambda: self._arrow(-1))
        self._add_key("Right", lambda: self._arrow(1))

    def _add_key(self, seq: str, fn) -> None:
        sc = QShortcut(QKeySequence(seq), self)
        sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        sc.activated.connect(fn)
        self._keys.append(sc)

    def _open_sheet(self):
        return next((s for s in self._sheets() if s.isVisible()), None)

    def _esc_pressed(self) -> None:
        """Esc 一层一层退：先关阅读层，再收起面板。"""
        sheet = self._open_sheet()
        if sheet is not None:
            sheet.close_sheet()
        else:
            self._set_collapsed(True, animate=True)

    def _go_tab(self, idx: int) -> None:
        if self._collapsed or self._open_sheet() is not None or self.compact_view is not None:
            return
        if idx < len(self.tabs.tabs):
            self.tabs.set_active(idx)

    def _arrow(self, step: int) -> None:
        if self.detail_sheet.isVisible():
            self.detail_sheet.go_next() if step > 0 else self.detail_sheet.go_prev()
        elif self.library_sheet.isVisible():
            self.library_sheet.step(1 if step > 0 else -1)
        elif self._collapsed or self._open_sheet() is not None:
            return
        elif self.compact_view is not None:
            self.compact_view.step(1 if step > 0 else -1)
        elif self.page_stack.currentWidget() is self.people_page:
            self.people_page.next() if step > 0 else self.people_page.prev()

    def _setup_hotkey(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            self._hotkey = None
            return
        self._hotkey = HotkeyFilter(self.toggle_window)
        self._hotkey.install()

    def show_window(self) -> None:
        if not self.isVisible():
            self._hidden_for_fullscreen = False
            self.show()
            if _theme.motion():
                self._play_startup_fade()   # 从托盘 / 热键唤出来时淡入
        if self._collapsed:
            self._set_collapsed(False, animate=True)
        self._bring_forward()

    def toggle_window(self) -> None:
        if not self.isVisible():
            self._hidden_for_fullscreen = False
            self.show()
            self._set_collapsed(False, animate=True)
            self._bring_forward()
            return
        if self._collapsed:
            self._set_collapsed(False, animate=True)
            self._bring_forward()
        elif not self.isActiveWindow():
            # Hotkey/tray is an explicit summons: bring a covered panel forward
            # instead of hiding it, then let it sink again when focus leaves.
            self._bring_forward()
        else:
            self._set_collapsed(True, animate=True)

    # ------------------------------------------------------------- actions
    def _pin_toggled(self, checked: bool) -> None:
        self._set_pinned(checked)

    def _set_pinned(self, checked: bool, from_tray: bool = False) -> None:
        self._pinned = checked
        self.cfg["pinned"] = checked
        save_config(self.cfg)
        self.topbar.pin_btn.blockSignals(True)
        self.topbar.pin_btn.setChecked(checked)
        self.topbar.pin_btn.blockSignals(False)
        if not from_tray:
            self._sync_action(self.act_pin, checked)
        self.settings_sheet.set_config(self.cfg)
        if checked:
            self._idle_timer.stop()
            self._toast("已固定展开")
        else:
            self._restart_idle()
            self._toast("已恢复自动收起")

    @staticmethod
    def _sync_action(action, checked: bool) -> None:
        """托盘菜单的勾选（内嵌在见微里时没有托盘）。"""
        if action is not None:
            action.blockSignals(True)
            action.setChecked(checked)
            action.blockSignals(False)

    def _settings_changed(self, cfg: dict) -> None:
        previous_start = bool(self.cfg.get("auto_start", True))
        self.cfg.update(cfg)
        if self.cfg.get("auto_start") != previous_start and not self._embedded:
            ok, msg = set_autostart(bool(self.cfg.get("auto_start")))
            if not ok:
                self.cfg["auto_start"] = previous_start
                self.settings_sheet.set_config(self.cfg)
                self._toast("开机自启设置失败")
                return
            self._sync_action(self.act_autostart, bool(self.cfg.get("auto_start")))
        self._pinned = bool(self.cfg.get("pinned", False))
        self.topbar.pin_btn.blockSignals(True)
        self.topbar.pin_btn.setChecked(self._pinned)
        self.topbar.pin_btn.blockSignals(False)
        self._sync_action(self.act_pin, self._pinned)
        self._sync_action(self.act_fullscreen, bool(self.cfg.get("hide_on_fullscreen", True)))
        save_config(self.cfg)
        if self._pinned:
            self._idle_timer.stop()
        else:
            self._restart_idle()

    def _open_settings(self) -> None:
        self._make_room()
        self.settings_sheet.set_config(self.cfg)
        self.settings_sheet.open_sheet()
        self._idle_timer.stop()

    def _sheets(self) -> tuple:
        """盖在面板上的几层（阅读、筛选说明、设置、素材库）：Esc、自动收起、换版式都按这一组处理。"""
        return tuple(s for s in (getattr(self, "detail_sheet", None), getattr(self, "filter_sheet", None),
                                 getattr(self, "settings_sheet", None), getattr(self, "library_sheet", None)) if s is not None)

    def _open_library(self, kind: str = "people", favorites: bool = False) -> None:
        self._make_room()
        if favorites and kind in self.library_sheet.picks:
            self.library_sheet.picks[kind]["_fav"] = True
        self.library_sheet.open_kind(kind)
        self._idle_timer.stop()

    def _open_filter(self) -> None:
        if self.edition:
            self._make_room()
            self.filter_sheet.open_filter(self.edition)
            self._idle_timer.stop()

    def _open_story(self, story: dict) -> None:
        if story:
            self._make_room()
            self.detail_sheet.open_story(story, story_list(self.edition))
            self._idle_timer.stop()

    def _copy(self, text: str) -> None:
        QApplication.clipboard().setText(text)
        self._toast("已复制这句话")

    def _copy_card(self, text: str) -> None:
        QApplication.clipboard().setText(text)
        self._toast("已复制素材卡，可以直接贴进笔记")

    def _open_url(self, url: str) -> None:
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def _open_archive_entry(self, entry: dict) -> None:
        rel = entry.get("path") or ""
        folder = ROOT / rel
        if folder.exists():
            os.startfile(str(folder))
        else:
            self._open_archive_root()

    def _open_archive(self) -> None:
        if self.edition and self.edition.get("archive_path"):
            folder = ROOT / self.edition["archive_path"]
            if folder.exists():
                os.startfile(str(folder))
                return
        self._open_archive_root()

    def _open_archive_root(self) -> None:
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        os.startfile(str(ARCHIVE_DIR))

    def _footer_clicked(self) -> None:
        if self._last_error:
            self.refresh(True)

    def _toast(self, text: str) -> None:
        # Background refreshes must never pop the panel open. If it is
        # collapsed, the rail's count and (for updates) the tray notification
        # are enough.
        if self._collapsed:
            return
        self.toast.show_message(text)

    # ------------------------------------------------------------- refresh
    def refresh(self, force: bool = True) -> None:
        if self._busy:
            return
        self._busy = True
        self._last_error = ""
        self.topbar.set_busy(True)
        self.busy_line.set_running(True)
        self.footer.set_status("正在连接信源并筛选…", "可以继续阅读", True)
        self._worker = CuratorWorker(force=force, parent=self)
        self._worker.progress.connect(self._on_progress)
        self._worker.ok.connect(self._on_refresh_ok)
        self._worker.failed.connect(self._on_refresh_failed)
        self._worker.start()

    def _on_progress(self, text: str) -> None:
        if self._busy:
            self.footer.set_status(text, "正在更新", True)

    def _on_refresh_ok(self, result: dict) -> None:
        self._busy = False
        self.topbar.set_busy(False)
        self.busy_line.set_running(False)
        worker = self._worker
        self._worker = None
        if worker:
            worker.deleteLater()
        edition = result.get("edition")
        if edition:
            self.edition = edition
        self._load_data()
        if self._collapsed:
            if self.tray is not None and self.tray.isSystemTrayAvailable():
                try:
                    self.tray.showMessage("观澜 · 今日版已更新", "新的世界线索已经放好。", QSystemTrayIcon.MessageIcon.Information, 2800)
                except Exception:
                    pass
        else:
            self._toast(f"今日版已更新 · {self.edition.get('read_count', 7)} 条精选")

    def _on_refresh_failed(self, error: str) -> None:
        self._busy = False
        self.topbar.set_busy(False)
        self.busy_line.set_running(False)
        worker = self._worker
        self._worker = None
        if worker:
            worker.deleteLater()
        self._last_error = error
        detail = error.strip().splitlines()[-1] if error.strip() else "网络或信源暂时不可用"
        self.footer.set_status("更新失败，点这里重试", "已保留上一版", False)
        if self._collapsed:
            if self.tray is not None and self.tray.isSystemTrayAvailable():
                try:
                    self.tray.showMessage("观澜 · 更新失败", "已保留上一版内容，稍后可重试。", QSystemTrayIcon.MessageIcon.Warning, 2600)
                except Exception:
                    pass
        else:
            self._toast("更新失败，已保留上一版内容")
        try:
            (ROOT / "logs").mkdir(exist_ok=True)
            with open(ROOT / "logs" / "ui_errors.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat()} | {error}\n")
        except Exception:
            pass

    # ------------------------------------------------------------- lifecycle
    _ACTIVITY = frozenset((
        QEvent.Type.MouseMove, QEvent.Type.MouseButtonPress,
        QEvent.Type.MouseButtonRelease, QEvent.Type.MouseButtonDblClick,
        QEvent.Type.Wheel, QEvent.Type.KeyPress, QEvent.Type.KeyRelease,
        QEvent.Type.TouchBegin,
    ))

    def eventFilter(self, obj, event) -> bool:
        # 全应用的事件都会到这里：先用便宜的判断把「不是输入事件」「不是本窗口里的控件」挡掉
        try:
            if isinstance(event, QInputEvent) and isinstance(obj, QWidget) and (obj is self or self.isAncestorOf(obj)):
                if event.type() in self._ACTIVITY:
                    self._last_activity = time.monotonic()
                    if not self._pinned and not self._collapsed and self.isVisible() and not self._idle_timer.isActive():
                        self._idle_timer.start()
        except Exception:
            pass
        return False

    def enterEvent(self, event) -> None:
        if not self._collapsed:
            self._restart_idle()
        super().enterEvent(event)

    def changeEvent(self, event) -> None:
        super().changeEvent(event)

    def closeEvent(self, event) -> None:
        if self._quitting:
            event.accept()
            return
        event.ignore()
        self._idle_timer.stop()
        self.hide()

    def quit_app(self) -> None:
        self._quitting = True
        try:
            QApplication.instance().removeEventFilter(self)
        except Exception:
            pass
        try:
            if self._hotkey is not None:
                self._hotkey.remove()
        except Exception:
            pass
        if self.tray is not None:
            self.tray.hide()
        save_config(self.cfg)
        QApplication.quit()
