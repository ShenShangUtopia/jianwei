"""阅读界面的条目：顶栏、底栏、今日焦点、新闻条目、词典、金句、档案行。"""
from __future__ import annotations
import os

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget

from .base import BrandMark, IconButton, TagLabel, TextBlock, TextButton
from .icons import draw_icon
from .theme import C, font, mono, serif, tint


def _label(text: str, size: int = 12, weight: int = 400, color: QColor | None = None, spacing: float = 0.0) -> QLabel:
    lab = QLabel(text)
    lab.setFont(font(size, weight, spacing=spacing))
    lab.setStyleSheet(f"color: {(color or C.MUTED).name()}; background: transparent;")
    lab.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
    return lab


def _card(p: QPainter, r: QRectF, fill: QColor, radius: float = 7, line: QColor | None = None) -> None:
    p.setBrush(fill)
    p.setPen(QPen(line or C.HAIRLINE, 1))
    p.drawRoundedRect(r, radius, radius)


class TopBar(QWidget):
    """顶栏也是拖动手柄：按住空白处能把观澜挪到别的位置，双击回到默认位置。"""
    refresh_clicked = Signal()
    pin_toggled = Signal(bool)
    collapse_clicked = Signal()
    more_clicked = Signal(object)
    drag_started = Signal(object)
    drag_moved = Signal(object)
    drag_ended = Signal()
    reset_position = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(56)
        self._drag = False
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 8, 8, 0)
        layout.setSpacing(2)
        self.mark = BrandMark(34)
        layout.addWidget(self.mark, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addSpacing(8)
        brand = QVBoxLayout()
        brand.setSpacing(0)
        brand.setContentsMargins(0, 0, 0, 0)
        name = _label("观澜", 15, 700, C.TEXT, 1.5)
        self.date_label = _label("", 12, 400, C.MUTED)
        brand.addStretch(1)
        brand.addWidget(name)
        brand.addWidget(self.date_label)
        brand.addStretch(1)
        layout.addLayout(brand)
        layout.addStretch(1)

        self.refresh_btn = IconButton("refresh", "重新筛选今日内容（R）", 30)
        self.pin_btn = IconButton("pin", "保持展开，不自动收起", 30)
        self.pin_btn.setCheckable(True)
        self.more_btn = IconButton("more", "更多", 30)
        self.collapse_btn = IconButton("collapse", "收起到屏幕边（Esc）", 30)
        for btn in (self.refresh_btn, self.pin_btn, self.more_btn, self.collapse_btn):
            layout.addWidget(btn)

        self.refresh_btn.clicked.connect(self.refresh_clicked)
        self.pin_btn.toggled.connect(self.pin_toggled)
        self.collapse_btn.clicked.connect(self.collapse_clicked)
        self.more_btn.clicked.connect(lambda: self.more_clicked.emit(self.more_btn))

    def set_date(self, date_label: str, weekday: str) -> None:
        short = date_label[5:].replace(".", "/") if len(date_label) >= 10 else date_label
        self.date_label.setText(f"{short} {weekday}".strip())

    def set_busy(self, busy: bool) -> None:
        self.refresh_btn.set_busy(busy)
        self.refresh_btn.setToolTip("正在抓取并筛选…" if busy else "重新筛选今日内容（R）")

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag = True
            self.setCursor(Qt.CursorShape.SizeAllCursor)
            self.drag_started.emit(event.globalPosition().toPoint())

    def mouseMoveEvent(self, event) -> None:
        if self._drag:
            self.drag_moved.emit(event.globalPosition().toPoint())

    def mouseReleaseEvent(self, event) -> None:
        if self._drag:
            self._drag = False
            self.unsetCursor()
            self.drag_ended.emit()

    def mouseDoubleClickEvent(self, event) -> None:
        self._drag = False
        self.unsetCursor()
        self.reset_position.emit()


class Footer(QWidget):
    """底栏：左边状态，右边更新时间。失败时变色，整条可点重试。"""
    clicked = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(32)
        self._left = ""
        self._right = ""
        self._ok = True

    def set_status(self, left: str, right: str, ok: bool = True) -> None:
        self._left, self._right, self._ok = left, right, ok
        self.setCursor(Qt.CursorShape.ArrowCursor if ok else Qt.CursorShape.PointingHandCursor)
        self.update()

    def status(self) -> str:
        return self._left

    def mousePressEvent(self, event) -> None:
        self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(C.HAIRLINE)
        p.drawLine(QPointF(14, 0.5), QPointF(self.width() - 14, 0.5))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.ACCENT if self._ok else C.WARN)
        p.drawEllipse(QPointF(18, 16), 2.5, 2.5)
        p.setFont(font(12, 400))
        p.setPen(C.MUTED if self._ok else C.WARN)
        p.drawText(QRectF(27, 2, self.width() - 140, 28), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self._left)
        p.setFont(font(12, 400))
        p.setPen(C.DIM)
        p.drawText(QRectF(self.width() - 130, 2, 116, 28), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, self._right)


class HeroCard(QWidget):
    """今日焦点：这一条值得多看一眼，所以字大、框实。"""
    clicked = Signal()

    def __init__(self, story: dict | None = None, read: bool = False, parent: QWidget | None = None):
        super().__init__(parent)
        self.story = story or {}
        self._hover = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 13, 16, 12)
        layout.setSpacing(6)
        top = QHBoxLayout()
        self.overline = _label("今日焦点", 12, 700, C.SEAL, 1.0)
        self.state = _label("已读" if read else "", 12, 400, C.DIM)
        top.addWidget(self.overline)
        top.addStretch(1)
        top.addWidget(self.state)
        layout.addLayout(top)
        self.title = TextBlock(self.story.get("display_title") or self.story.get("title", ""), 18, 700, C.TEXT, 3, 1.4).fit()
        layout.addWidget(self.title)
        self.summary = TextBlock(self.story.get("summary", ""), 13, 400, C.TEXT_SOFT, 3, 1.6).fit()
        layout.addWidget(self.summary)
        q = self.story.get("question", "")
        self.question = TextBlock(f"带着问题读：{q}" if q else "", 13, 500, C.ACCENT, 2, 1.5).fit()
        self.question.setVisible(bool(q))
        layout.addWidget(self.question)
        meta = "  ·  ".join(x for x in (self.story.get("source", ""), self.story.get("published_display", ""),
                                       f"约 {self.story.get('read_minutes', 2)} 分钟") if x)
        layout.addWidget(_label(meta, 12, 400, C.DIM))

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        _card(p, r, C.CARD_HOVER if self._hover else C.CARD, 8, C.HAIRLINE_STRONG if self._hover else C.HAIRLINE)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.SEAL)
        p.drawRoundedRect(QRectF(0, 14, 3, 18), 1.5, 1.5)


class StoryCard(QWidget):
    """一条新闻：序号 + 标题 + 摘要 + 来源。读过的变淡，序号换成勾。"""
    clicked = Signal(dict)

    def __init__(self, story: dict, index: int = 1, read: bool = False, parent: QWidget | None = None):
        super().__init__(parent)
        self.story = story
        self.index = index
        self.read = read
        self._hover = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        outer = QHBoxLayout(self)
        outer.setContentsMargins(38, 9, 10, 9)
        layout = QVBoxLayout()
        layout.setSpacing(3)
        title = story.get("display_title") or story.get("title", "")
        self.title = TextBlock(title, 14, 600, C.MUTED if read else C.TEXT, 2, 1.45).fit()
        layout.addWidget(self.title)
        self.summary = TextBlock(story.get("summary", ""), 12, 400, C.DIM if read else C.MUTED, 2, 1.55).fit()
        layout.addWidget(self.summary)
        tag = (story.get("tags") or [story.get("region", "")])[0]
        time_text = (story.get("published_display") or "")[-5:]
        meta = "  ·  ".join(x for x in (tag, story.get("source", ""), time_text) if x)
        layout.addWidget(_label(meta, 12, 400, C.DIM))
        outer.addLayout(layout)

    def set_read(self, read: bool) -> None:
        self.read = read
        self.title.setColor(C.MUTED if read else C.TEXT)
        self.summary.setColor(C.DIM if read else C.MUTED)
        self.update()

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.story)
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect())
        if self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.CARD_HOVER)
            p.drawRoundedRect(r, 6, 6)
        slot = QRectF(6, 10, 28, 22)
        if self.read:
            draw_icon(p, "check", QRectF(12, 12, 16, 16), C.ACCENT, 1.6)
        else:
            p.setFont(mono(15, 500))
            p.setPen(C.ACCENT)
            p.drawText(slot, Qt.AlignmentFlag.AlignCenter, str(self.index))


class TermCard(QWidget):
    collect_requested=Signal(dict)
    def __init__(self, term: dict | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.term = term or {}
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(4)
        layout.addWidget(_label("格局词典", 12, 700, C.ACCENT, 1.0))
        row = QHBoxLayout()
        row.setSpacing(8)
        self.name = QLabel(self.term.get("term", ""))
        self.name.setFont(font(17, 700))
        self.name.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        row.addWidget(self.name)
        self.en = _label(self.term.get("en", ""), 12, 400, C.DIM)
        row.addWidget(self.en, 0, Qt.AlignmentFlag.AlignBottom)
        row.addStretch(1)
        if os.environ.get('JIANWEI_EMBED')=='1':
            collect=TextButton('收素材',size=12,arrow=None)
            collect.clicked.connect(lambda:self.collect_requested.emit(dict(kind='term',data=self.term)))
            row.addWidget(collect)
        self.actions = row
        layout.addLayout(row)
        layout.addWidget(TextBlock(self.term.get("definition", ""), 13, 400, C.TEXT_SOFT, 5, 1.6).fit())
        exam = self.term.get("exam", "")
        if exam:
            layout.addWidget(TextBlock(f"高考连接：{exam}", 12, 400, C.MUTED, 3, 1.5).fit())

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        _card(p, QRectF(self.rect()).adjusted(.5, .5, -.5, -.5), C.CARD, 8)


def _add_action(self, widget: QWidget) -> None:
    """素材库往卡片右上角那排加按键（收藏、复制素材卡）。"""
    self.actions.addWidget(widget)


TermCard.add_action = _add_action


class QuoteCard(QWidget):
    copy_clicked = Signal(str)
    collect_requested=Signal(dict)

    def __init__(self, quote: dict, index: int = 1, parent: QWidget | None = None):
        super().__init__(parent)
        self.quote = quote
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 10, 8, 12)
        layout.setSpacing(6)
        top = QHBoxLayout()
        top.addWidget(_label(f"第 {index} 句", 12, 700, C.ACCENT))
        top.addStretch(1)
        if os.environ.get('JIANWEI_EMBED')=='1':
            collect=TextButton('收素材',size=12,arrow=None)
            collect.clicked.connect(lambda:self.collect_requested.emit(dict(kind='quote',data=self.quote)))
            top.addWidget(collect)
        copy_btn = IconButton("copy", "复制这句话", 28, C.MUTED)
        copy_btn.clicked.connect(lambda: self.copy_clicked.emit(self.quote.get("text", "")))
        top.addWidget(copy_btn)
        self.actions = top
        layout.addLayout(top)
        text = TextBlock(quote.get("text", ""), 16, 400, C.TEXT, 8, 1.65).fit()
        text.set_text_font(serif(16, 500), 27)
        text.fit()
        layout.addWidget(text)
        layout.addWidget(_label(f"—— {quote.get('author', '')}，{quote.get('source', '')}", 12, 500, C.MUTED))
        if quote.get("use"):
            layout.addWidget(TextBlock(f"可用在：{quote.get('use', '')}", 12, 400, C.DIM, 3, 1.5).fit())

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        _card(p, QRectF(self.rect()).adjusted(.5, .5, -.5, -.5), C.CARD, 8)


QuoteCard.add_action = _add_action


class PersonSeal(QWidget):
    def __init__(self, monogram: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self._monogram = monogram
        self.setFixedSize(58, 58)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setBrush(tint(C.ACCENT, 0.12))
        p.setPen(QPen(tint(C.ACCENT, 0.55), 1))
        p.drawRoundedRect(r, 8, 8)
        p.setFont(serif(26, 700))
        p.setPen(C.ACCENT)
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self._monogram)


class ArchiveRow(QWidget):
    clicked = Signal(dict)

    def __init__(self, entry: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self.entry = entry
        self._hover = False
        self.setFixedHeight(68)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("打开这一天的档案文件夹")

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.entry)
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        _card(p, r, C.CARD_HOVER if self._hover else C.CARD, 7)
        date = self.entry.get("date", "")
        p.setFont(mono(22, 500))
        p.setPen(C.ACCENT)
        p.drawText(QRectF(10, 8, 46, 30), Qt.AlignmentFlag.AlignCenter, date[-2:])
        p.setFont(font(12))
        p.setPen(C.DIM)
        month = date[5:7].lstrip("0") if len(date) >= 7 else ""
        p.drawText(QRectF(6, 38, 54, 20), Qt.AlignmentFlag.AlignCenter, f"{month} 月" if month else "")
        p.setPen(C.HAIRLINE)
        p.drawLine(QPointF(64, 12), QPointF(64, self.height() - 12))
        title = self.entry.get("title") or self.entry.get("lead") or ""
        p.setFont(font(13, 600))
        p.setPen(C.TEXT_SOFT)
        w = self.width() - 104
        p.drawText(QRectF(76, 11, w, 22), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                   QFontMetrics(p.font()).elidedText(title, Qt.TextElideMode.ElideRight, w))
        p.setFont(font(12))
        p.setPen(C.DIM)
        meta = f"{self.entry.get('weekday', '')}  ·  {self.entry.get('read_count', 0)} 条  ·  {self.entry.get('reading_minutes', 0)} 分钟"
        p.drawText(QRectF(76, 35, w, 20), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, meta)
        draw_icon(p, "chevron_right", QRectF(self.width() - 26, 26, 16, 16), C.ACCENT if self._hover else C.DIM, 1.4)
