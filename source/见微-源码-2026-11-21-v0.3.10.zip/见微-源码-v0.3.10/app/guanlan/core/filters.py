"""The editorial filter: hard gates, multi-dimensional scoring, and quotas.

The score is intentionally explainable. Every number shown in the app can be
traced back to one of six dimensions, and every selection passes a hard gate
before it is allowed to compete.
"""
from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from datetime import datetime
from difflib import SequenceMatcher

from .editorial import (
    CHINA_TERMS, FOREIGN_TERMS, HARD_BLOCK_WORDS, SOFT_BLOCK_WORDS, TECH_SOFT_WORDS,
    SOURCE_PRIORITY, STRUCTURAL_GROUPS, TAG_LABELS, THEME_KEYWORDS,
    THEME_LENS, THEME_QUESTIONS, THEME_WHY, REGION_KEYWORDS, WEIGHTS,
    SECTION_META,
)
from .sources import Candidate, clean_text, now_local

PREFIX_RE = re.compile(
    r"^(?:国际观察|新闻分析|记者手记|热点问答|全球连线|专访|观察|聚焦|深度|特稿|推荐|视频|直播)\s*[丨｜|]\s*"
)
PUNCT_RE = re.compile(r"[\s\W_]+", re.UNICODE)
CJK_RE = re.compile(r"[\u4e00-\u9fff]")
SPECIFIC_FOREIGN = [w for w in FOREIGN_TERMS if w not in ("全球", "国际")]
SOFT_DIPLO_WORDS = (
    "对话会", "交流活动", "文化中心", "成功举办", "纪念大会", "图片展",
    "音乐会", "书画", "研究中心", "座谈会", "招待会", "开放日",
    "鲁班工坊", "授人以渔", "共话", "地方合作", "商业对话", "交流", "研讨会",
)


def is_soft_diplomacy(item: Candidate) -> bool:
    title = item.title or ""
    if not any(w in title for w in SOFT_DIPLO_WORDS):
        return False
    hard = ("峰会", "预算", "制裁", "关税", "冲突", "协议", "条约", "安全", "芯片", "人工智能")
    return not any(w in title for w in hard)


def normalize_title(title: str) -> str:
    text = PREFIX_RE.sub("", title or "").strip()
    return PUNCT_RE.sub("", text)


def text_key(text: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]", "", text or "")


def char_ngrams(text: str, n: int = 2) -> set[str]:
    chars = "".join(CJK_RE.findall(text or ""))
    if len(chars) < n:
        return set(chars)
    stop = {"中国", "美国", "一个", "我们", "他们", "可以", "已经", "表示", "进行", "以及", "这个", "没有"}
    return {chars[i:i+n] for i in range(len(chars) - n + 1)} - stop


def similarity(a: str, b: str) -> float:
    a, b = normalize_title(a), normalize_title(b)
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def is_duplicate(a: Candidate, b: Candidate) -> bool:
    if a.url and b.url and a.url.split("#")[0] == b.url.split("#")[0]:
        return True
    if similarity(a.title, b.title) >= 0.76:
        return True
    sa, sb = text_key(a.summary)[:180], text_key(b.summary)[:180]
    if len(sa) > 60 and len(sb) > 60 and SequenceMatcher(None, sa, sb).ratio() >= 0.72:
        return True
    na, nb = char_ngrams(a.title), char_ngrams(b.title)
    if len(na) > 6 and len(nb) > 6:
        jac = len(na & nb) / len(na | nb)
        if jac >= 0.62:
            return True
    return False


def previous_signatures(previous: dict | None) -> tuple[set[str], set[str], str]:
    """URLs, normalized titles and lead title selected in the previous edition."""
    urls: set[str] = set()
    titles: set[str] = set()
    lead_title = ""
    if not isinstance(previous, dict):
        return urls, titles, lead_title
    items = [previous.get("lead")] + list(previous.get("stories") or [])
    for item in items:
        if not isinstance(item, dict):
            continue
        url = str(item.get("url") or "").split("#")[0].strip()
        if url:
            urls.add(url)
        title = normalize_title(str(item.get("title") or item.get("display_title") or ""))
        if title:
            titles.add(title)
    lead = previous.get("lead") or {}
    lead_title = normalize_title(str(lead.get("title") or lead.get("display_title") or ""))
    return urls, titles, lead_title


def is_previous(item: Candidate, urls: set[str], titles: set[str]) -> bool:
    if item.url:
        if item.url.split("#")[0].strip() in urls:
            return True
    title = normalize_title(item.title)
    return bool(title and title in titles)


def _hits(text: str, words: list[str]) -> int:
    return sum(1 for w in words if w and w.lower() in text.lower())


def _weighted_hits(title: str, summary: str, words: list[str]) -> float:
    return 5.0 * _hits(title, words) + 1.0 * _hits(summary, words)


def china_hits(text: str) -> int:
    # "发展中国家" contains the characters "中国" but is not China. Remove
    # compounds that produce false positives before counting.
    scrubbed = text.replace("发展中国家", "").replace("发展中经济体", "").replace("中美洲", "")
    return sum(1 for w in CHINA_TERMS if w and w in scrubbed)


def classify(item: Candidate) -> Candidate:
    title = item.title or ""
    summary = item.summary or ""
    text = title + "\n" + summary

    # Theme scores. Title mentions matter more than a paragraph mention.
    theme_scores = {}
    for theme, words in THEME_KEYWORDS.items():
        score = _weighted_hits(title, summary, words)
        if score:
            theme_scores[theme] = score
    if "人工智能" in text or "AI" in title:
        theme_scores["科技产业"] = theme_scores.get("科技产业", 0) + 6
    if "APEC" in text:
        theme_scores["外交合作"] = theme_scores.get("外交合作", 0) + 6
    ordered = sorted(theme_scores.items(), key=lambda kv: (-kv[1], -list(THEME_KEYWORDS).index(kv[0])))
    item.themes = [t for t, _ in ordered[:2]] or ["社会民生"]

    # Region: prefer the strongest non-China region when a story is explicitly
    # about China interacting with the world, while still recording relevance.
    # Region is decided by the headline first. A paragraph may mention five
    # countries; the headline tells us what the story is actually about.
    def region_scores_for(text: str) -> dict[str, float]:
        scores = {}
        for region_name, words in REGION_KEYWORDS.items():
            if region_name == "中国":
                continue
            hits = sum(1 for w in words if w and w.lower() in text.lower())
            if hits:
                scores[region_name] = float(hits)
        return scores

    title_regions = region_scores_for(title)
    summary_regions = region_scores_for(summary)
    region_scores = title_regions or summary_regions
    china_score = china_hits(title) * 2 + china_hits(summary)
    item.china_relevance = china_score > 0
    if region_scores:
        # "全球" terms such as UN/IMF should not drown out a concrete region.
        concrete = {k: v for k, v in region_scores.items() if k != "全球"}
        if concrete:
            region = max(concrete.items(), key=lambda kv: kv[1])[0]
            if region_scores.get("全球", 0) >= max(concrete.values()) + 2:
                region = "全球"
        else:
            region = "全球"
    elif china_score:
        region = "中国"
    else:
        region = "全球"
    # A domestic Chinese story can mention Washington in paragraph three; that
    # does not make it a foreign story. If the headline has no foreign signal
    # but has a clear Chinese institutional signal, keep it at home.
    if not title_regions and china_score >= 2 and not any(w in title for w in SPECIFIC_FOREIGN):
        region = "中国"
    item.region = region

    # Tags are a display layer, not a claim about the story's only meaning.
    tags = []
    for label, words in TAG_LABELS.items():
        if _hits(text, words):
            tags.append(label)
    if region and region != "全球":
        tags.insert(0, region)
    item.tags = list(dict.fromkeys(tags))[:5]

    # Structural groups hit.
    groups = []
    for group, words in STRUCTURAL_GROUPS.items():
        if _hits(text, words):
            groups.append(group)
    item._structural_groups = groups  # type: ignore[attr-defined]
    item.id = hashlib.sha1(item.url.encode("utf-8", "ignore")).hexdigest()[:12]
    return item


def hard_gate(item: Candidate) -> tuple[bool, str]:
    title = (item.title or "").strip()
    text = title + " " + (item.summary or "")
    if not (8 <= len(title) <= 96):
        return False, "标题过短或过长"
    if not item.url.startswith("http"):
        return False, "无有效原文链接"
    if any(w in title for w in HARD_BLOCK_WORDS):
        return False, "标题党/软新闻/视觉内容"
    if item.source == "IT之家" and any(w in title for w in TECH_SOFT_WORDS):
        return False, "消费电子/游戏等非结构性科技"
    if item.source == "IT之家" and not any(k in text for k in THEME_KEYWORDS["科技产业"]):
        return False, "科技源但不含结构性科技议题"
    age_h = (now_local() - item.published).total_seconds() / 3600
    if age_h > 100:
        return False, "超过四天，失去时效"
    if age_h < -6:
        return False, "时间异常"
    soft = any(w in text for w in SOFT_BLOCK_WORDS)
    groups = getattr(item, "_structural_groups", [])
    if soft and len(groups) < 2:
        return False, "体育/娱乐/生活方式等软新闻"
    if not groups:
        # Top-tier analysis can still pass if it has a clear public theme.
        if item.priority < 90 or not any(t in (item.themes or []) for t in ("外交合作", "经济贸易", "科技产业", "气候生态")):
            return False, "缺少结构性议题"
    if item.region == "中国" and not item.china_relevance:
        return False, "无法识别公共议题"
    return True, ""


def score(item: Candidate, weights: dict | None = None) -> Candidate:
    weights = {**WEIGHTS, **(weights or {})}
    text = (item.title or "") + "\n" + (item.summary or "")
    groups = getattr(item, "_structural_groups", [])
    analysis = bool(re.search(r"观察|分析|问答|解读|前瞻|深度|专访|记者手记", item.title))

    authority = float(SOURCE_PRIORITY.get(item.source, 55))

    structure = 28 + 15 * len(groups)
    if analysis:
        structure += 8
    if item.themes and item.themes[0] in ("外交合作", "经济贸易", "安全冲突", "科技产业", "能源资源", "气候生态"):
        structure += 7
    if re.search(r"条约|规则|预算|关税|供应链|治理|秩序|格局|战略|安全|峰会|协议|APEC|领导人非正式会议", text):
        structure += 5
    structure = min(100.0, structure)

    global_actor_count = _hits(text, ["联合国", "IMF", "世界银行", "WTO", "欧盟", "美国", "中国", "俄罗斯", "东盟", "非盟", "全球"])
    impact = 34 + min(24, global_actor_count * 7)
    if item.region not in ("中国", "全球"):
        impact += 8
    if item.china_relevance:
        impact += 8
    if re.search(r"\d", text):
        impact += 5
    if any(g in groups for g in ("气候与生态", "社会与人口", "规则与制度")):
        impact += 6
    if re.search(r"踩踏|坠亡|车祸|枪击|遇难|死亡", item.title):
        impact -= 10
    if is_soft_diplomacy(item):
        impact -= 14
    impact = max(0.0, min(100.0, impact))

    age_h = max(0.0, (now_local() - item.published).total_seconds() / 3600)
    freshness = 100.0 * math.exp(-age_h / 42.0)
    if age_h <= 24:
        freshness = max(freshness, 56.0)
    freshness = max(28.0, min(100.0, freshness))

    readability = 66.0
    if 16 <= len(item.title) <= 46:
        readability += 10
    elif len(item.title) > 55:
        readability -= 8
    if 50 <= len(item.summary) <= 260:
        readability += 12
    elif len(item.summary) < 20:
        readability -= 7
    if analysis:
        readability += 4
    if item.title.count("，") >= 4 or item.title.count("、") >= 5:
        readability -= 4
    readability = max(20.0, min(100.0, readability))

    exam_map = {
        "外交合作": 90, "经济贸易": 94, "科技产业": 90, "气候生态": 87,
        "政治制度": 86, "能源资源": 86, "社会民生": 79, "公共卫生": 81,
        "文化教育": 74, "安全冲突": 78,
    }
    exam_fit = float(exam_map.get(item.themes[0] if item.themes else "社会民生", 78))
    if analysis:
        exam_fit += 6
    if item.china_relevance:
        exam_fit += 4
    if re.search(r"伤亡|遇难|踩踏|车祸|枪击|尸体", text):
        exam_fit -= 12
    if is_soft_diplomacy(item):
        exam_fit -= 8
    exam_fit = max(20.0, min(100.0, exam_fit))

    item.scores = {
        "authority": round(authority, 1),
        "structure": round(structure, 1),
        "impact": round(impact, 1),
        "freshness": round(freshness, 1),
        "readability": round(readability, 1),
        "exam_fit": round(exam_fit, 1),
    }
    total = sum(item.scores[k] * weights.get(k, 0) for k in item.scores)
    if is_incident(item):
        total -= 5.0
    item.total = round(total, 1)
    item.why = THEME_WHY.get(item.themes[0], "它把一条长期线索，推到了今天的桌面上。")
    item.question = THEME_QUESTIONS.get(item.themes[0], "这条新闻，改变了谁的选择？")
    item.lens = THEME_LENS.get(item.themes[0], "事实 / 判断")
    item.read_minutes = max(2, min(8, round(len(item.summary) / 260 + 1)))
    return item


def dedupe(items: list[Candidate]) -> tuple[list[Candidate], int]:
    ordered = sorted(items, key=lambda c: (-c.priority, -c.published.timestamp(), -len(c.summary)))
    kept: list[Candidate] = []
    removed = 0
    for item in ordered:
        dup_index = None
        for idx, existing in enumerate(kept):
            if is_duplicate(item, existing):
                dup_index = idx
                break
        if dup_index is None:
            kept.append(item)
            continue
        removed += 1
        existing = kept[dup_index]
        # Keep the higher-priority framing, but retain the richer summary.
        if len(item.summary) > len(existing.summary) + 20:
            existing.summary = item.summary
        if item.priority > existing.priority:
            kept[dup_index] = item
    return kept, removed


# ---------------------------------------------------------------- 读者偏好
# 用户自己定的筛选偏好：只在硬门槛之后起作用（屏蔽词例外），不会让软新闻借偏好混进来。
PREF_MORE, PREF_LESS, PREF_REGION = 8.0, -8.0, 5.0


def clean_prefs(prefs: dict | None) -> dict:
    """配置里的偏好可能是手改的：只留认得的主题、地区，屏蔽词去空、去重、限长。"""
    from .editorial import REGION_KEYWORDS, THEME_ORDER
    p = prefs if isinstance(prefs, dict) else {}
    more = [t for t in p.get("more") or [] if t in THEME_ORDER]
    less = [t for t in p.get("less") or [] if t in THEME_ORDER and t not in more]
    regions = [r for r in p.get("regions") or [] if r in REGION_KEYWORDS]
    mute = []
    for w in p.get("mute") or []:
        w = str(w).strip()[:12]
        if w and w not in mute:
            mute.append(w)
    return dict(more=more, less=less, regions=regions, mute=mute[:30])


def muted(item: Candidate, prefs: dict) -> str:
    """标题里有用户屏蔽的词：返回那个词。只看标题，摘要里顺带提一句不算。"""
    title = item.title or ""
    return next((w for w in prefs.get("mute") or [] if w.lower() in title.lower()), "")


def pref_bonus(item: Candidate, prefs: dict) -> float:
    themes = list(item.themes or [])
    bonus = 0.0
    for i, t in enumerate(themes[:2]):
        scale = 1.0 if i == 0 else 0.5
        if t in prefs.get("more", ()):
            bonus += PREF_MORE * scale
        elif t in prefs.get("less", ()):
            bonus += PREF_LESS * scale
    if item.region in prefs.get("regions", ()):
        bonus += PREF_REGION
    return bonus


def prepare(candidates: list[Candidate], weights: dict | None = None, prefs: dict | None = None) -> dict:
    prefs = clean_prefs(prefs)
    raw = len(candidates)
    classified = [classify(c) for c in candidates]
    gate_pass: list[Candidate] = []
    reasons: Counter = Counter()
    for item in classified:
        word = muted(item, prefs)
        if word:
            reasons["你屏蔽的词"] += 1
            continue
        ok, reason = hard_gate(item)
        if ok:
            gate_pass.append(item)
        else:
            reasons[reason] += 1
    deduped, duplicates = dedupe(gate_pass)
    scored = [score(c, weights) for c in deduped]
    for c in scored:
        b = pref_bonus(c, prefs)
        c.pref_bonus = b    # type: ignore[attr-defined]
        c.total = round(c.total + b, 1)
    scored.sort(key=lambda c: (-c.total, -c.published.timestamp()))
    return {
        "raw": raw,
        "gate_pass": gate_pass,
        "deduped": deduped,
        "scored": scored,
        "duplicates": duplicates,
        "reasons": reasons,
        "funnel": {
            "fetched": raw,
            "gate_pass": len(gate_pass),
            "deduped": len(deduped),
            "selected": 0,
        },
    }


def eligible_sections(item: Candidate) -> set[str]:
    themes = set(item.themes)
    out: set[str] = set()
    groups = getattr(item, "_structural_groups", [])
    analysis = any(k in item.title for k in ("分析", "观察", "问答", "解读", "专访"))
    if "科技产业" in themes and not any(w in item.title for w in TECH_SOFT_WORDS):
        out.add("tech")
    if item.china_relevance and any(w in item.title for w in SPECIFIC_FOREIGN):
        if themes & {"外交合作", "经济贸易", "安全冲突", "能源资源", "科技产业", "气候生态", "政治制度"}:
            out.add("china_world")
    primary = (item.themes or [""])[0]
    if item.source != "IT之家" and primary in {"社会民生", "公共卫生", "气候生态", "文化教育"}:
        out.add("society")
    if item.source != "IT之家" and item.region != "中国":
        if themes & {"外交合作", "经济贸易", "安全冲突", "能源资源", "气候生态", "政治制度"}:
            if len(groups) >= 2 or analysis:
                out.add("world")
    if not out and item.region != "中国" and len(groups) >= 2:
        out.add("world")
    return out


def is_incident(item: Candidate) -> bool:
    title = item.title or ""
    return bool(re.search(r"袭击|遇袭|枪击|爆炸|踩踏|坠亡|死亡|伤亡|被捕|冲突|骚乱", title)) and not any(
        k in title for k in ("分析", "观察", "问答", "解读")
    )


def _lead_penalty(item: Candidate) -> float:
    penalty = 0.0
    if re.search(r"袭击|空袭|遇难|死亡|踩踏|坠亡|枪杀", item.title):
        penalty += 7
    if item.themes and item.themes[0] in ("社会民生", "公共卫生", "文化教育"):
        penalty += 6
    if item.region == "中国":
        penalty += 8
    return penalty


def _agenda_bonus(item: Candidate) -> float:
    text = item.title + " " + item.summary
    bonus = 0.0
    if any(k in text for k in ("APEC", "峰会", "联合国大会", "COP", "预算", "贸易规则", "全球治理", "条约")):
        bonus += 7.0
    if "APEC" in text:
        # The 2026 APEC summit is hosted by China. When the agenda-setting
        # summit is in the pool, it earns the front page over a routine item.
        bonus += 14.0
    if "领导人非正式会议" in text:
        bonus += 10.0
    if "分析" in item.title or "观察" in item.title or "问答" in item.title:
        bonus += 2.0
    return bonus


def choose_lead(
    scored: list[Candidate],
    previous_urls: set[str] | None = None,
    previous_titles: set[str] | None = None,
    previous_lead_title: str = "",
) -> Candidate | None:
    previous_urls = previous_urls or set()
    previous_titles = previous_titles or set()

    def is_repeat(item: Candidate) -> bool:
        if previous_urls or previous_titles:
            if is_previous(item, previous_urls, previous_titles):
                return True
        if previous_lead_title and similarity(item.title, previous_lead_title) >= 0.72:
            return True
        return False

    eligible = []
    for item in scored:
        age_h = (now_local() - item.published).total_seconds() / 3600
        groups = getattr(item, "_structural_groups", [])
        if "世界进行时" in item.title or "本期要点" in item.title:
            continue
        if age_h > 60 or item.scores.get("authority", 0) < 82:
            continue
        if len(groups) < 2:
            continue
        if item.themes and item.themes[0] in ("社会民生", "公共卫生", "文化教育") and item.total < 80:
            continue
        if is_repeat(item):
            continue
        eligible.append(item)
    if not eligible:
        # Never fall back to yesterday's lead when a fresh alternative exists.
        for item in scored:
            if item.themes and item.themes[0] in ("社会民生", "公共卫生", "文化教育") and item.total < 80:
                continue
            if not is_repeat(item):
                return item
        return scored[0] if scored else None
    eligible.sort(key=lambda c: -(
        c.total * 0.68 + c.scores["structure"] * 0.20 + c.scores["impact"] * 0.12
        + _agenda_bonus(c) - _lead_penalty(c)
    ))
    return eligible[0]


def select_news(
    scored: list[Candidate],
    max_stories: int = 7,
    previous: dict | None = None,
) -> tuple[Candidate | None, list[Candidate], dict]:
    if not scored:
        return None, [], {"funnel": {"fetched": 0, "gate_pass": 0, "deduped": 0, "selected": 0}, "selected": []}
    previous_urls, previous_titles, previous_lead = previous_signatures(previous)
    lead = choose_lead(scored, previous_urls, previous_titles, previous_lead)
    selected: list[Candidate] = []
    if lead:
        lead.section = "lead"
        selected.append(lead)

    # Quotas: 2 world, 2 China & world, 1 tech, 1 society.
    # Allocate the specific slots first; "world" absorbs the best remaining
    # geopolitics and security stories instead of swallowing climate/tech items.
    quota = [("china_world", 2), ("tech", 1), ("society", 1), ("world", 2)]
    # If the lead already occupies a natural section, do not over-count it;
    # it remains the "lead" and section quotas are still filled from others.
    source_count = Counter(c.source for c in selected)
    region_count = Counter(c.region for c in selected)

    def can_take(c: Candidate, cap_source: int = 3, cap_region: int = 3) -> bool:
        if c in selected:
            return False
        if previous_urls or previous_titles:
            if is_previous(c, previous_urls, previous_titles):
                return False
        if source_count[c.source] >= cap_source:
            return False
        if region_count[c.region] >= cap_region:
            return False
        for s in selected:
            if is_duplicate(c, s):
                return False
            if similarity(c.title, s.title) >= 0.46:
                return False
        return True

    for section, count in quota:
        if len(selected) >= max_stories:
            break
        candidates = [c for c in scored if section in eligible_sections(c) and can_take(c)]
        def section_score(c: Candidate) -> float:
            value = c.total
            if section == "china_world":
                value += 7 if c.china_relevance else 0
                value += 3 if c.region != "中国" else 0
                value -= 10 if is_soft_diplomacy(c) else 0
            elif section == "society":
                value += 9 if c.region != "中国" else -5
                value += 4 if "气候生态" in c.themes else 0
                value += 3 if "公共卫生" in c.themes else 0
                value -= 12 if is_soft_diplomacy(c) else 0
            elif section == "tech":
                value += 5 if any(k in (c.title + c.summary) for k in ("人工智能", "芯片", "半导体", "算力", "航天", "量子")) else 0
                value += 5 if any(k in c.title for k in ("分析", "观察", "解读", "专访")) else 0
                value += 2 if c.source != "IT之家" else 0
            elif section == "world":
                value += 2 if c.region not in region_count else 0
                value += 5 if any(t in c.themes for t in ("安全冲突", "能源资源", "外交合作", "政治制度")) else 0
                value -= 4 if "科技产业" in c.themes else 0
                value -= 7 if c.china_relevance else 0
                value -= 6 if is_incident(c) else 0
                value += 5 if ("能源通道" in (c.tags or []) or any(k in c.title for k in ("霍尔木兹", "海峡", "油轮", "航道"))) else 0
                value += 3 if any(k in c.title for k in ("分析", "观察", "问答", "解读")) else 0
            # A small nudge toward a new voice; quality still dominates.
            if source_count[c.source] == 0:
                value += 3
            elif source_count[c.source] == 1:
                value += 1
            elif source_count[c.source] >= 3:
                value -= 3
            if c.themes and not any(c.themes[0] in (s.themes or []) for s in selected):
                value += 1
            return value
        candidates.sort(key=lambda c: -section_score(c))
        for c in candidates[:count]:
            if len(selected) >= max_stories:
                break
            if not can_take(c):
                continue
            c.section = section
            selected.append(c)
            source_count[c.source] += 1
            region_count[c.region] += 1

    # Relax constraints only to fill the edition, never to lower the hard gate.
    # Cross-day repeats stay out: a shorter edition is better than a rerun.
    if len(selected) < max_stories:
        for c in scored:
            if len(selected) >= max_stories:
                break
            if c in selected:
                continue
            if previous_urls or previous_titles:
                if is_previous(c, previous_urls, previous_titles):
                    continue
            if source_count[c.source] >= 3:
                continue
            if any(is_duplicate(c, s) for s in selected):
                continue
            sections = sorted(eligible_sections(c), key=lambda s: SECTION_META.get(s, {}).get("order", 9))
            if not sections and c.region != "中国":
                sections = ["world"]
            if not sections:
                continue
            c.section = sections[0]
            selected.append(c)
            source_count[c.source] += 1
            region_count[c.region] += 1

    selected = selected[:max_stories]

    # Source diversity is a feature, not a tie-breaker: an edition should not
    # become a single wire service. If we only have three voices, swap the
    # weakest non-lead pick for a comparable story from an unused source.
    for _ in range(3):
        current_sources = {c.source for c in selected}
        if len(current_sources) >= 4:
            break
        replaced = False
        for low in sorted([c for c in selected if c.section != "lead"], key=lambda c: c.total):
            base = [c for c in selected if c is not low]
            base_regions = Counter(c.region for c in base)
            options = []
            for cand in scored:
                if cand in selected or cand.source in current_sources:
                    continue
                if previous_urls or previous_titles:
                    if is_previous(cand, previous_urls, previous_titles):
                        continue
                if low.section not in eligible_sections(cand):
                    continue
                if base_regions[cand.region] >= 3:
                    continue
                if any(is_duplicate(cand, s) for s in base):
                    continue
                if cand.total < low.total - 12:
                    continue
                options.append(cand)
            if options:
                options.sort(key=lambda c: -c.total)
                chosen = options[0]
                chosen.section = low.section
                selected[selected.index(low)] = chosen
                replaced = True
                break
        if not replaced:
            break

    source_count = Counter(c.source for c in selected)
    region_count = Counter(c.region for c in selected)
    sources = sorted({c.source for c in selected})
    regions = sorted({c.region for c in selected})
    funnel = {
        "fetched": 0,
        "gate_pass": 0,
        "deduped": len(scored),
        "selected": len(selected),
    }
    diagnostics = {
        "selected": selected,
        "sources": sources,
        "regions": regions,
        "source_distribution": dict(source_count),
        "region_distribution": dict(region_count),
        "funnel": funnel,
    }
    return lead, selected, diagnostics


def keywords_for(stories: list[Candidate], limit: int = 5) -> list[str]:
    counter: Counter = Counter()
    for item in stories:
        for tag in item.tags:
            if tag not in ("全球", "中国"):
                counter[tag] += 1
        for theme in item.themes[:1]:
            counter[theme] += 1
    return [k for k, _ in counter.most_common(limit)]
