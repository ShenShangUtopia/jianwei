"""素材库的收藏：人物 / 金句 / 词条各存一串 id，写在 data/favorites.json。

只存 id，库里的内容以后改了也跟着变；库里已经删掉的 id 读的时候自动跳过。
写入先写临时文件再替换，半路断电也不会把原来的收藏弄坏。
"""
from __future__ import annotations

import json
import os

from . import paths

KINDS = ("people", "quotes", "terms")


def _path():
    return paths.DATA_DIR / "favorites.json"


def load() -> dict[str, list[str]]:
    out = {k: [] for k in KINDS}
    try:
        raw = json.loads(_path().read_text(encoding="utf-8-sig"))
    except Exception:
        return out
    if isinstance(raw, dict):
        for k in KINDS:
            ids = raw.get(k)
            if isinstance(ids, list):
                seen = []
                for x in ids:
                    if isinstance(x, str) and x and x not in seen:
                        seen.append(x)
                out[k] = seen
    return out


def save(data: dict) -> None:
    paths.ensure_dirs()
    clean = {k: [x for x in (data.get(k) or []) if isinstance(x, str)] for k in KINDS}
    tmp = _path().with_suffix(".json.tmp")
    tmp.write_text(json.dumps(clean, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, _path())


def toggle(kind: str, item_id: str) -> bool:
    """切换一条的收藏状态，返回切换后是否已收藏。新收藏的排在最前。"""
    data = load()
    ids = data.setdefault(kind, [])
    if item_id in ids:
        ids.remove(item_id)
        on = False
    else:
        ids.insert(0, item_id)
        on = True
    save(data)
    return on
