"""素材库的筛选维度：人物、金句、词条各按几个方面分组，外加全文搜索。

维度尽量从已有字段推出来（时代、地区、标签、出处、高考连接），新条目也可以直接写
field / origin 字段。界面只管把这里给的选项摆成一排排按键。
"""
from __future__ import annotations

import re

from .library_people import PEOPLE
from .library_quotes import QUOTES
from .library_terms import TERMS

ALL = "全部"

# 作文主题：人物和金句共用一套，标签 / 品质里出现这些词就算属于这个主题（可以属于好几个）
THEMES = {
    "青年与理想": ("青年", "理想", "志向", "青春", "梦想", "求索", "远行", "自信", "一代人", "成长", "少年", "进取", "视野", "格局"),
    "责任与担当": ("责任", "担当", "使命", "家国", "国家需要", "牺牲", "奉献", "公共", "他人", "隐姓埋名", "归国", "守护", "忧乐"),
    "逆境与坚持": ("逆境", "坚持", "韧性", "困境", "苦难", "耐心", "勇气", "抗争", "反抗", "困难", "旷达", "紧迫感", "坚守", "残障"),
    "创新与探索": ("科学", "技术", "创造", "想象力", "传统与创新", "开创", "更新", "航天", "人工智能", "计算", "大科学工程", "探索", "工程", "发现"),
    "实践与学习": ("实践", "学习", "行动", "知行合一", "认知", "思考", "独立思考", "理性", "问题", "求是", "长期记录", "长期主义", "读书", "积累"),
    "人与自然": ("生态", "自然", "土地", "粮食安全", "农业", "绿色革命", "气候", "社区", "种子", "山水"),
    "生活与心境": ("生活", "心境", "诗意", "幸福", "从容", "珍惜", "时间", "向往", "美", "温柔", "童心", "本质", "意义", "过程", "热爱"),
    "公平与尊严": ("尊严", "正义", "民权", "非暴力", "自由", "和解", "宽恕", "女性", "女孩", "普通人", "解放", "和平", "平等", "民生"),
    "文明与交流": ("文明", "文化", "敦煌", "汉字", "差异", "共识", "交往", "历史", "思想", "启蒙", "哲学", "文学", "写作", "语言", "记忆", "诗词", "建筑", "音乐"),
    "制度与治理": ("政治", "制度", "经济", "市场", "政府", "就业", "制度设计", "国家统一", "独立", "分工", "判断", "公共生活", "变法", "改革", "实业"),
}

# 人物领域：新条目写 field，老条目按 id 归类
FIELDS = ("科学技术", "生态农业", "教育医学", "人文艺术", "公共事务")
_FIELD_OF = {
    "yuan-longping": "生态农业", "norman-borlaug": "生态农业", "wangari-maathai": "生态农业", "rachel-carson": "生态农业",
    "zhang-guimei": "教育医学", "lin-qiaozhi": "教育医学", "malala": "教育医学",
    "fan-jinshi": "人文艺术", "lu-xun": "人文艺术", "su-shi": "人文艺术", "wang-yangming": "人文艺术", "hannah-arendt": "人文艺术",
    "nelson-mandela": "公共事务", "martin-luther-king": "公共事务", "rosa-parks": "公共事务", "gandhi": "公共事务",
    "abraham-lincoln": "公共事务", "john-keynes": "公共事务", "adam-smith": "公共事务",
}

ERAS = ("古代", "近代", "现代", "当代")
_ERA = {"古代": "古代", "16世纪": "近代", "17世纪": "近代", "18世纪": "近代", "19世纪": "近代", "近代": "近代", "20世纪": "现代", "现代": "现代", "当代": "当代"}

ORIGINS = ("古代中国", "近现代中国", "外国")
_FOREIGN = {"里尔克", "海明威", "泰戈尔", "歌德", "康德", "马克思", "梭罗", "荷尔德林", "圣埃克苏佩里", "塞内加", "马拉拉",
            "陀思妥耶夫斯基", "牛顿", "帕斯卡", "苏格拉底", "普希金", "罗曼·罗兰", "爱因斯坦", "居里夫人", "奥斯特洛夫斯基"}

SUBJECTS = ("政治", "经济", "地理", "历史", "写作")


def _themes(words) -> list[str]:
    words = [str(w) for w in words if w]
    out = []
    for theme, keys in THEMES.items():
        if any(k in w for w in words for k in keys):
            out.append(theme)
    return out


def person_facets(p: dict) -> dict:
    region = "中国" if p.get("region") == "中国" else "世界"
    return dict(field=p.get("field") or _FIELD_OF.get(p.get("id"), "科学技术"),
                era=_ERA.get(p.get("era", ""), "现代"), region=region,
                theme=_themes(list(p.get("tags") or []) + list(p.get("qualities") or [])))


def quote_origin(q: dict) -> str:
    if q.get("origin") in ORIGINS:
        return q["origin"]
    author = q.get("author", "")
    if "·" in author or author in _FOREIGN or "译" in q.get("source", ""):
        return "外国"
    year = str(q.get("year", ""))
    m = re.match(r"约?(\d{3,4})", year)
    if m:
        return "古代中国" if int(m.group(1)) < 1840 else "近现代中国"
    return "古代中国"       # 先秦、唐、北宋……这类朝代写法


def quote_facets(q: dict) -> dict:
    return dict(origin=quote_origin(q), theme=_themes(q.get("tags") or []))


def term_facets(t: dict) -> dict:
    subjects = [s for s in SUBJECTS if s + "：" in t.get("exam", "")]
    return dict(subject=subjects)


def _blob(entry: dict) -> str:
    parts = []
    for v in entry.values():
        if isinstance(v, str):
            parts.append(v)
        elif isinstance(v, (list, tuple)):
            parts += [x if isinstance(x, str) else " ".join(str(y) for y in x.values()) if isinstance(x, dict) else str(x) for x in v]
        elif isinstance(v, dict):
            parts += [str(x) for x in v.values()]
    return "\n".join(parts).lower()


# 每种库：条目、怎么取维度、界面上摆哪几排（键、名字、选项）
KINDS = {
    "people": dict(label="人物", items=PEOPLE, facets=person_facets,
                   rows=(("field", "领域", FIELDS), ("era", "时代", ERAS), ("region", "地区", ("中国", "世界")),
                         ("theme", "作文主题", tuple(THEMES)))),
    "quotes": dict(label="金句", items=QUOTES, facets=quote_facets,
                   rows=(("origin", "出处", ORIGINS), ("theme", "作文主题", tuple(THEMES)))),
    "terms": dict(label="词条", items=TERMS, facets=term_facets,
                  rows=(("subject", "学科", SUBJECTS),)),
}


def _match(value, want: str) -> bool:
    if want in ("", ALL):
        return True
    return want in value if isinstance(value, (list, tuple, set)) else value == want


def _base(kind: str, only=None, themes=None) -> list[dict]:
    """筛选前的底子：only（收藏的 id，按收藏先后）、themes（今天新闻的主题：只留相关的，越贴近越靠前）。"""
    items = KINDS[kind]["items"]
    if only is not None:
        by_id = {e.get("id"): e for e in items}
        items = [by_id[i] for i in only if i in by_id]
    if themes:
        from .library import relevance
        scored = [(relevance(kind, e, themes), n, e) for n, e in enumerate(items)]
        items = [e for s, _n, e in sorted(scored, key=lambda t: (-t[0], t[1])) if s > 0]
    return items


def search(kind: str, picks: dict | None = None, text: str = "", only=None, themes=None) -> list[dict]:
    """按选中的维度（每排一个，全部 = 不限）和搜索词筛条目，保持库里的顺序
    （给了 only 按收藏先后，给了 themes 按和今天新闻的贴合度）。"""
    spec = KINDS[kind]
    picks = picks or {}
    words = [w for w in re.split(r"\s+", (text or "").strip().lower()) if w]
    out = []
    for entry in _base(kind, only, themes):
        f = spec["facets"](entry)
        if not all(_match(f.get(key), picks.get(key, ALL)) for key, _label, _opts in spec["rows"]):
            continue
        if words:
            blob = _blob(entry)
            if not all(w in blob for w in words):
                continue
        out.append(entry)
    return out


def counts(kind: str, picks: dict | None = None, text: str = "", only=None, themes=None) -> dict:
    """每个选项现在点下去会剩几条（其余维度保持不变），界面拿来标数字、把 0 条的变灰。"""
    spec = KINDS[kind]
    picks = dict(picks or {})
    out = {}
    for key, _label, opts in spec["rows"]:
        row = {}
        for opt in (ALL,) + tuple(opts):
            row[opt] = len(search(kind, {**picks, key: opt}, text, only, themes))
        out[key] = row
    return out


def material_card(kind: str, entry: dict) -> str:
    """复制出去的「素材卡」：纯文本，贴进笔记、作文本都能直接用。"""
    if kind == "people":
        lines = [f"【人物】{entry.get('name', '')}（{entry.get('years', '')}）{entry.get('identity', '')}"]
        if entry.get("headline"):
            lines.append(entry["headline"])
        if entry.get("story"):
            lines += ["", entry["story"]]
        moments = entry.get("moments") or []
        if moments:
            lines += ["", "关键时刻："] + [f"· {m.get('year', '')}  {m.get('text', '')}" for m in moments]
        if entry.get("qualities"):
            lines.append("可迁移的品质：" + "；".join(entry["qualities"]))
        if entry.get("essay_angle"):
            lines.append("作文可用：" + entry["essay_angle"])
        q = entry.get("quote") or {}
        if q.get("text"):
            lines.append(f"“{q['text']}”—— {q.get('source', '')}")
    elif kind == "quotes":
        lines = [f"“{entry.get('text', '')}”", f"—— {entry.get('author', '')}，{entry.get('source', '')}"]
        if entry.get("use"):
            lines.append("可用在：" + entry["use"])
    else:
        lines = [f"【词条】{entry.get('term', '')}  {entry.get('en', '')}".rstrip(), entry.get("definition", "")]
        for key, name in (("why", "为什么重要"), ("exam", "高考连接"), ("misread", "常见误读")):
            if entry.get(key):
                lines.append(f"{name}：{entry[key]}")
    if entry.get("source_url"):
        lines.append("延伸阅读：" + entry["source_url"])
    return "\n".join(lines).strip()
