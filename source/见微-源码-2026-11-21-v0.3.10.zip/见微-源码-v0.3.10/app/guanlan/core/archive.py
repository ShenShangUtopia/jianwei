"""Write each day's edition to readable, separated Markdown documents."""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from .editorial import DIMENSIONS, SECTION_META, SECTION_ORDER, WEIGHTS
from .library_people import PEOPLE
from .library_quotes import QUOTES
from .library_terms import TERMS
from .paths import ARCHIVE_DIR, DATA_DIR, EDITIONS_DIR, INDEX_PATH, LATEST_PATH, ROOT


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _source_line(item: dict) -> str:
    published = (item.get("published") or "")[:16].replace("T", " ")
    return f"来源：[{item['source']}]({item['url']}) · {published} · 结构评分 {item.get('total', 0):.1f}"


def format_story(item: dict, index: int | None = None) -> str:
    label = f"### {index:02d}  {item['title']}" if index is not None else f"### {item['title']}"
    tags = " · ".join(item.get("tags") or []) or item.get("region", "")
    return f"""{label}

> {item.get('why', '')}

{item.get('detail') or item.get('summary') or '（原文以链接为准）'}

- **观察镜头**：{item.get('lens', '')}
- **带着问题读**：{item.get('question', '')}
- **坐标**：{item.get('region', '')} · {tags}
- **为什么入选**：信源 {item['scores']['authority']:.0f} / 结构 {item['scores']['structure']:.0f} / 影响 {item['scores']['impact']:.0f} / 时效 {item['scores']['freshness']:.0f} / 可读 {item['scores']['readability']:.0f} / 高考适配 {item['scores']['exam_fit']:.0f}
- {_source_line(item)}
"""


def build_overview(edition: dict) -> str:
    lead = edition["lead"]
    rows = []
    for item in [lead] + edition["stories"]:
        section = "今日焦点" if item["section"] == "lead" else SECTION_META.get(item["section"], {}).get("label", "")
        rows.append(f"| {section} | [{item['title']}]({item['url']}) | {item['source']} | {item['total']:.1f} |")
    quotes = edition["quotes"]
    term = edition["term"]
    person = edition["person"]
    return f"""# 观澜 · {edition['date_label']}  {edition['weekday']}

> {edition['title']}  
> {edition['subtitle']}

**今日关键词**：{' / '.join(edition['keywords'])}

## 今日焦点

### {lead['title']}

{lead.get('detail') or lead.get('summary') or ''}

- **观察镜头**：{lead.get('lens', '')}
- **带着问题读**：{lead.get('question', '')}
- **阅读角度**：{lead.get('why', '')}
- {_source_line(lead)}

## 今日线索

| 板块 | 标题 | 来源 | 评分 |
| --- | --- | --- | --- |
{chr(10).join(rows)}

## 今日人物 · {person['name']}

{person.get('headline', '')}

{person.get('story', '')}

- **作文角度**：{person.get('essay_angle', '')}
- **延伸阅读**：[{person.get('source_name', '')}]({person.get('source_url', '')})

## 今日三句

{chr(10).join(f"> {q['text']}  \n> —— {q['author']}，{q['source']}" for q in quotes)}

## 今日词条 · {term['term']}

{term['definition']}

**为什么与你有关**：{term['why']}

---

## 编辑台记录

今天从 **{edition['selection']['funnel']['fetched']}** 条抓取内容中，经过硬门槛余 **{edition['selection']['funnel']['gate_pass']}** 条、去重余 **{edition['selection']['funnel']['deduped']}** 条，最终保留 **{edition['selection']['funnel']['selected']}** 条。

- 来源：{'、'.join(edition['selection']['sources'])}
- 地区：{'、'.join(edition['selection']['regions'])}
- 同一来源不超过 3 条，同一地区不超过 3 条，入选至少来自 4 个来源。
- 筛选维度：{'；'.join(f"{label} {int(weight*100)}%" for (_, label, _), weight in zip(DIMENSIONS, WEIGHTS.values()))}

> 新闻只提供事实的入口，不替你完成判断。带着问题读，比记住结论更重要。

*由观澜编辑部自动筛选与编排。所有内容均保留原文链接，请以原始报道为准。*
"""


def build_section(edition: dict, section: str) -> str:
    meta = SECTION_META[section]
    items = [x for x in edition["stories"] if x["section"] == section]
    if not items:
        return ""
    body = "\n\n".join(format_story(item, i + 1) for i, item in enumerate(items))
    return f"""# {meta['label']} · {edition['date_label']}

> {edition['title']}  
> {edition['subtitle']}

{body}

---

**本日观察问题**  
{chr(10).join(f"- {item['question']}" for item in items)}
"""


def build_person(edition: dict) -> str:
    person = edition["person"]
    alt = edition.get("person_alternates") or []
    moments = "\n".join(f"- **{m['year']}**：{m['text']}" for m in person.get("moments", []))
    qualities = " / ".join(person.get("qualities", []))
    alt_text = "、".join(p["name"] for p in alt)
    return f"""# 人物档案 · {person['name']}

> {person['headline']}

**{person['name']}**（{person['years']}）  
{person['identity']} · {person['region']} · {person['era']}

## 他/她经历了什么

{person['story']}

## 三个时刻

{moments}

## 可迁移的品质

{qualities}

## 作文可用

{person['essay_angle']}

> “{person['quote']['text']}”  
> —— {person['quote']['source']}

**延伸阅读**：[{person['source_name']}]({person['source_url']})

今天的人物库里还有：{alt_text}。可在观澜的“人物”页切换阅读。

*人物故事为编辑部综合公开资料整理；事实以延伸阅读和权威来源为准。*
"""


def build_quotes(edition: dict) -> str:
    parts = []
    for i, q in enumerate(edition["quotes"], 1):
        parts.append(f"""## {i:02d}

> {q['text']}

—— {q['author']}，{q['source']}

**可用在**：{q['use']}
""")
    return f"""# 每日金句 · {edition['date_label']}

> 好句不是装饰，而是把复杂感受压缩成一条可以带走的线。

{chr(10).join(parts)}

---

## 抄写建议

选一句，用自己的话解释它为什么成立，再举一个今天新闻里的例子。三句话即可，不求长。
"""


def build_term(edition: dict) -> str:
    t = edition["term"]
    return f"""# 格局词条 · {t['term']}

**{t['en']}**

## 它是什么

{t['definition']}

## 为什么今天值得懂

{t['why']}

## 高考连接

{t['exam']}

## 最容易误解的地方

{t['misread']}
"""


def build_selection(edition: dict, top_candidates: list[dict]) -> str:
    sel = edition["selection"]
    lines = []
    for c in top_candidates[:15]:
        mark = "✓" if c.get("selected") else " "
        lines.append(
            f"| {mark} | {c['total']:.1f} | {c['source']} | {c['region']} | {c['title']} |"
        )
    dims = "\n".join(
        f"| {label} | {int(weight*100)}% | {sel['averages'].get(key, 0):.0f} | {desc} |"
        for (key, label, desc), weight in zip(DIMENSIONS, WEIGHTS.values())
    )
    reasons = "\n".join(f"- {reason}：{count} 条" for reason, count in sel.get("rejected_reasons", [])[:8])
    return f"""# 筛选记录 · {edition['date_label']}

## 今天的漏斗

- 抓取：{sel['funnel']['fetched']} 条
- 通过硬门槛：{sel['funnel']['gate_pass']} 条
- 去重后：{sel['funnel']['deduped']} 条
- 最终入选：{sel['funnel']['selected']} 条

## 多维度评分

| 维度 | 权重 | 今日均值 | 说明 |
| --- | ---: | ---: | --- |
{dims}

## 结构约束

- 同一来源最多 3 条；入选至少来自 4 个来源。
- 同一地区最多 3 条；入选至少覆盖 3 个地区。
- 标题相似度、摘要指纹双重去重；同一事件只保留一个版本。
- 标题党、软新闻、消费电子、猎奇与未经证实的传闻，在硬门槛阶段直接排除。
- “中国与世界”必须同时出现中国主体与明确的境外对象；“世界脉络”优先非中国中心的结构性议题。

## 被挡在门外的原因

{reasons or '- 无'}

## 今日候选池（按评分）

| 入选 | 分数 | 来源 | 地区 | 标题 |
| :---: | ---: | --- | --- | --- |
{chr(10).join(lines)}

## 编辑原则

筛掉的不是“不重要”，而是“今天不必占用你注意力”的。观澜优先保留能解释长期变化、能连接多个地区、能带进作文与课堂的线索；对事实密度不足、情绪先行、来源单一的内容保持克制。
"""


def build_library_docs() -> dict[str, str]:
    people = []
    for p in PEOPLE:
        people.append(f"""## {p['name']}（{p['years']}）

{p['identity']} · {p['region']} · {p['tags']}

> {p['headline']}

{p['story']}

- **三个时刻**：{'；'.join(f"{m['year']} {m['text']}" for m in p['moments'])}
- **品质**：{' / '.join(p['qualities'])}
- **作文角度**：{p['essay_angle']}
- **延伸阅读**：[{p['source_name']}]({p['source_url']})
""")
    quotes = []
    for q in QUOTES:
        quotes.append(f"- “{q['text']}” —— {q['author']}，{q['source']}  \n  可用：{q['use']}")
    terms = []
    for t in TERMS:
        terms.append(f"""## {t['term']} · {t['en']}

{t['definition']}

- **为什么重要**：{t['why']}
- **高考连接**：{t['exam']}
- **易混点**：{t['misread']}
""")
    return {
        "人物库.md": f"# 观澜人物库\n\n> {len(PEOPLE)} 个可以带进作文的人，按“具体行动”而不是“标签”来写。\n\n" + "\n".join(people),
        "金句库.md": "# 观澜金句库\n\n> 每句都尽量标注出处；译句与意译已注明。\n\n" + "\n".join(quotes),
        "格局词典.md": "# 观澜格局词典\n\n> 读懂新闻背后的概念，而不是记住术语。\n\n" + "\n".join(terms),
    }


def save_edition(edition: dict, top_candidates: list[dict], index_entry: dict) -> dict:
    day_dir = ARCHIVE_DIR / edition["date"][:4] / edition["date"][5:7] / edition["date"]
    day_dir.mkdir(parents=True, exist_ok=True)

    files = {
        "00_今日总览.md": build_overview(edition),
        "01_世界脉络.md": build_section(edition, "world"),
        "02_中国与世界.md": build_section(edition, "china_world"),
        "03_科技与未来.md": build_section(edition, "tech"),
        "04_社会与生态.md": build_section(edition, "society"),
        "05_人物档案.md": build_person(edition),
        "06_每日金句.md": build_quotes(edition),
        "07_格局词条.md": build_term(edition),
        "08_筛选记录.md": build_selection(edition, top_candidates),
    }
    for name, text in files.items():
        if text:
            _write(day_dir / name, text)

    month_dir = day_dir.parent
    days = sorted([p.name for p in month_dir.iterdir() if p.is_dir() and len(p.name) == 10], reverse=True)
    month_lines = [f"# {edition['date'][:4]} 年 {int(edition['date'][5:7])} 月 · 观澜档案", "", "> 每日一页，按日期归档。", ""]
    for day in days:
        overview = month_dir / day / "00_今日总览.md"
        title = ""
        if overview.exists():
            try:
                for line in overview.read_text(encoding="utf-8").splitlines():
                    if line.startswith("> ") and len(line) > 4:
                        title = line[2:].strip()
                        break
            except Exception:
                pass
        month_lines.append(f"- [{day}]({day}/00_今日总览.md) · {title}")
    _write(month_dir / "索引.md", "\n".join(month_lines) + "\n")

    library_dir = ARCHIVE_DIR / "素材库"
    for name, text in build_library_docs().items():
        _write(library_dir / name, text)

    _write(ARCHIVE_DIR / "README.md", """# 观澜档案库

每天一个文件夹，按“今日总览 / 世界脉络 / 中国与世界 / 科技与未来 / 社会与生态 / 人物 / 金句 / 词条 / 筛选记录”分开保存。

- 00_今日总览.md：先读这一页。
- 08_筛选记录.md：看今天为什么留下这些、又筛掉了什么。
- 素材库/：可以反复使用的人物、金句和格局词条。

所有新闻都保留原文链接。档案是阅读线索，不是新闻原文的替代品。
""")

    _write_json(EDITIONS_DIR / f"{edition['date']}.json", edition)
    _write_json(LATEST_PATH, edition)

    entries = []
    if INDEX_PATH.exists():
        try:
            entries = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
        except Exception:
            entries = []
    entries = [e for e in entries if e.get("date") != edition["date"]]
    entries.append(index_entry)
    entries.sort(key=lambda e: e.get("date", ""), reverse=True)
    _write_json(INDEX_PATH, entries[:180])

    return {
        "archive_dir": str(day_dir),
        "files": [str(day_dir / name) for name in files if (day_dir / name).exists()],
        "month_index": str(month_dir / "索引.md"),
    }
