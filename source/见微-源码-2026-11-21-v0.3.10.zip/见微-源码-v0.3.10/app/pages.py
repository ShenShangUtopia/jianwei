"""见微 · 六个页面：今日 / 观澜 / 倒计时 / 习题台 / 实验室 / 设置。

页面由主壳按需建：第一次点到才建，换主题或数据变了只重建正在看的那一页（其余标记为待重建）。
颜色在建的时候按当前主题取（ui_kit.lab / C.*H），自己画的控件在重绘时取 —— 不再靠事后扫一遍控件树换色。
"""
from __future__ import annotations

import math
import os
import subprocess
from datetime import datetime, timedelta

from PySide6.QtCore import QPointF, QRect, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QFontMetricsF, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QSizePolicy,
    QSlider, QVBoxLayout, QWidget,
)

import store
from countdown import draw_pill, format_milestones, parse_milestones, phase_week
from native.bank.fx import plain
from native.design.icons import draw_icon
from ui_kit import (Btn, BrushRule, C, Card, Check, Chip, Combo, Dot, SmoothScroll, dense, divider, doodle, f, kicker, lab,
                    label, paint_card, row, serif, title_font)

WEEK_CN = "一二三四五六日"


def _clip(text: str, n: int = 56) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= n else text[: n - 1] + "…"


def _tint(color: QColor, alpha: float) -> QColor:
    out = QColor(color)
    out.setAlphaF(alpha)
    return out


def scroll(widget: QWidget) -> SmoothScroll:
    area = SmoothScroll()
    area.setWidgetResizable(True)
    area.setFrameShape(SmoothScroll.Shape.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    area.setWidget(widget)
    area.setStyleSheet("QScrollArea{background:transparent;border:none;}")
    return area


class Page(QWidget):
    def __init__(self, ctx, kick: str, title: str, sub: str = ""):
        super().__init__()
        self.ctx = ctx
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        inner = QWidget()
        tight = dense()
        self.gap = 9 if tight else 14
        frame = QVBoxLayout(inner)
        frame.setContentsMargins(*((22, 10, 22, 16) if tight else (32, 18, 32, 28)))
        frame.setSpacing(self.gap)
        # 页头只有三样：标题、一句说明、这一页最常用的一两个操作（靠右）。kick 不再显示，留着参数是为了不改调用处
        head = QHBoxLayout()
        head.setSpacing(12)
        t = QLabel(title)
        t.setFont(title_font(20 if tight else 24))
        t.setStyleSheet(f"color:{C.INKH};background:transparent;")
        head.addWidget(t, 0, Qt.AlignmentFlag.AlignBottom)
        if sub:
            s = lab(sub, 11.5, "SOFT")
            s.setContentsMargins(0, 0, 0, 4)
            head.addWidget(s, 0, Qt.AlignmentFlag.AlignBottom)
        head.addStretch(1)
        self.head = head
        self.actions = QHBoxLayout()
        self.actions.setSpacing(8)
        head.addLayout(self.actions)
        frame.addLayout(head)
        frame.addWidget(BrushRule())
        if not tight:
            frame.addSpacing(2)
        # 页头下面只有一栏 body。（0.3.4 的「分栏」右栏已删；side 参数留着，调用处不用改。）
        self.body = QVBoxLayout()
        self.body.setContentsMargins(0, 0, 0, 0)
        self.body.setSpacing(self.gap)
        frame.addLayout(self.body, 1)
        self.inner = inner
        # 内容最宽 1220：窗口最大化或用顶栏布局时不会把一行字拉得老长，多出来的留白分在两边
        inner.setMaximumWidth(1220)
        holder = QWidget()
        hl = QHBoxLayout(holder)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(0)
        hl.addStretch(1)
        hl.addWidget(inner, 1000)
        hl.addStretch(1)
        self.area = scroll(holder)
        outer.addWidget(self.area)

    def add(self, w, side: bool = False):  # noqa: ARG002  side 是 0.3.4 分栏留下的参数，已无作用
        target = self.body
        if isinstance(w, QWidget):
            target.addWidget(w)
        else:
            target.addLayout(w)
        return w

    def action(self, text: str, fn, variant: str = "", tip: str = "", icon: str = "") -> Btn:
        """页头右边加一个操作键。一页只该有一个 primary。"""
        b = Btn(text, variant, tip, icon)
        b.clicked.connect(lambda _=False: fn())
        self.actions.addWidget(b)
        return b


class _Hover(QWidget):
    """自己画的可点小块的公共部分：悬停状态、手形光标、松开才算点。"""

    def __init__(self, on_click=None):
        super().__init__()
        self._hover = False
        self._down = False
        self.on_click = on_click
        if on_click is not None:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, _e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self._hover = False
        self._down = False
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._down = True
            self.update()

    def mouseReleaseEvent(self, e):  # noqa: N802
        was = self._down
        self._down = False
        self.update()
        if was and e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()) and self.on_click:
            self.on_click()


# ------------------------------------------------------------------ 今日
class Hero(QWidget):
    """今日页最上面一块：剩余天数 + 一把学期时间尺（和桌面胶囊同一个母题）。每半分钟自己刷新。"""

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.k = 0.8 if dense() else 1.0       # 紧凑排法：整块按比例缩小
        self.setFixedHeight(int(158 * self.k))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._t = QTimer(self)
        self._t.setInterval(30_000)
        self._t.timeout.connect(self.update)

    def showEvent(self, e):  # noqa: N802
        self._t.start()
        super().showEvent(e)

    def hideEvent(self, e):  # noqa: N802
        self._t.stop()      # 看不见的时候不跑定时器
        super().hideEvent(e)

    def paintEvent(self, _e):  # noqa: N802
        from native.design.tokens import T
        cfg = self.ctx.cfg
        now = datetime.now()
        target, start = store.target_dt(cfg), store.start_dt(cfg)
        if start >= target:
            start = target - timedelta(days=280)
        total = max(1.0, (target - start).total_seconds())
        secs = max(0.0, (target - now).total_seconds())
        frac = min(1.0, max(0.0, 1 - secs / total))
        days = str(int(secs // 86400))
        name = str(cfg.get("label", "高考"))
        w, h = self.width() / self.k, 158

        p = QPainter(self)
        paint_card(p, self.rect())
        p.scale(self.k, self.k)

        pad, base = 28, 104
        p.setFont(f(10, 600, 2.4))
        p.setPen(C.FAINT)
        p.drawText(QPointF(pad, 36), f"{cfg.get('year', '2027')} 届 · 距{name}")
        big = serif(66, 600)
        p.setFont(big)
        p.setPen(C.INK)
        p.drawText(QPointF(pad - 3, base), days)
        nw = QFontMetricsF(big).horizontalAdvance(days)
        p.setFont(f(14, 500))
        p.setPen(C.SOFT)
        p.drawText(QPointF(pad + nw + 6, base), "天")
        if secs > 0:
            rest = int(secs % 86400)
            p.setFont(f(12, 400))
            p.setPen(C.FAINT)
            p.drawText(QPointF(pad + nw + 30, base), f"{rest // 3600} 时 {rest % 3600 // 60:02d} 分")
        p.setFont(f(11))
        p.setPen(C.FAINT)
        p.drawText(QPointF(pad, 134), f"{target:%Y.%m.%d %H:%M} 开考 · 第 {phase_week()} 周 · 周{WEEK_CN[now.weekday()]}")

        # 右边：学期时间尺
        x0, x1 = max(pad + nw + 170.0, w * 0.44), w - pad - 2.0
        if x1 - x0 < 200:
            p.end()
            return
        width = x1 - x0
        nx = x0 + width * frac
        p.setFont(f(10, 600, 2.0))
        p.setPen(C.FAINT)
        p.drawText(QPointF(x0, 36), "学期刻度")
        pct = f"已过 {int(frac * 100)}%"
        p.setFont(serif(13, 600))
        p.setPen(C.INK2)
        p.drawText(QRectF(x1 - 120, 22, 120, 20), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), pct)

        bar_y, tick_top = 96.0, 82.0
        end_text = f"{name} {target.month}/{target.day}"
        end_font = f(10.5, 700)
        end_w = QFontMetricsF(end_font).horizontalAdvance(end_text)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        weeks = max(1, int(total // (86400 * 7)))
        step = 1
        while width / (weeks / step) < 5 and step < 8:
            step *= 2
        for i in range(0, weeks + 1, step):
            x = x0 + width * i / weeks
            p.setPen(QPen(_tint(C.INK, 0.62) if x <= nx else _tint(C.FAINT, 0.45), 1))
            p.drawLine(QPointF(x, bar_y - 6), QPointF(x, bar_y - 1))
        months, (y, m) = [], (start.year, start.month)
        while True:
            when = datetime(y, m, 1)
            if when > target:
                break
            if when >= start:
                months.append(when)
            y, m = (y + 1, 1) if m == 12 else (y, m + 1)
        lab_font = f(10.5)
        fm = QFontMetricsF(lab_font)
        every = 1 if width / max(1, len(months)) >= 34 else 2
        for i, when in enumerate(months):
            x = x0 + width * (when - start).total_seconds() / total
            passed = x <= nx
            p.setPen(QPen(_tint(C.INK, 0.85) if passed else _tint(C.FAINT, 0.7), 1))
            p.drawLine(QPointF(x, tick_top), QPointF(x, bar_y - 1))
            text = f"{when.month}月"
            tw = fm.horizontalAdvance(text)
            if i % every == 0 and x + tw < x1 - end_w - 10 and abs(x + tw / 2 - nx) > tw / 2 + 8:
                p.setFont(lab_font)
                p.setPen(C.SOFT if passed else C.FAINT)
                p.drawText(QPointF(x, tick_top - 7), text)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.LINE)
        p.drawRoundedRect(QRectF(x0, bar_y, width, 4), 2, 2)
        fill = QLinearGradient(x0, 0, max(nx, x0 + 1), 0)
        fill.setColorAt(0, _tint(C.INK2, 0.55))
        fill.setColorAt(1, C.INK2)
        p.setBrush(fill)
        p.drawRoundedRect(QRectF(x0, bar_y, max(4.0, nx - x0), 4), 2, 2)

        gold = QColor(T.gold)
        cap_font = f(10.5)
        cap = f"今天 · 还剩 {max(0, math.ceil(secs / 604800))} 周"
        cap_w = QFontMetricsF(cap_font).horizontalAdvance(cap)
        cap_x = max(x0, min(x1 - cap_w, nx - cap_w / 2))
        for item in cfg.get("milestones") or []:
            try:
                when = datetime.strptime(str(item.get("date")), "%Y-%m-%d")
            except (ValueError, AttributeError):
                continue
            if not start <= when <= target:
                continue
            x = x0 + width * (when - start).total_seconds() / total
            p.setPen(QPen(C.CARD, 1))
            p.setBrush(gold)
            p.drawPolygon(QPolygonF([QPointF(x, bar_y - 2.5), QPointF(x + 4.5, bar_y + 2), QPointF(x, bar_y + 6.5), QPointF(x - 4.5, bar_y + 2)]))
            text = str(item.get("label") or "")
            lw = QFontMetricsF(cap_font).horizontalAdvance(text)
            if text and not (cap_x - 8 < x + lw / 2 and x - lw / 2 < cap_x + cap_w + 8):
                p.setFont(cap_font)
                p.setPen(gold)
                p.drawText(QRectF(x - lw / 2 - 2, bar_y + 10, lw + 4, 18), int(Qt.AlignmentFlag.AlignCenter), text)
        p.setFont(end_font)
        p.setPen(C.INK2)
        p.drawText(QRectF(x1 - end_w - 2, tick_top - 20, end_w + 2, 16), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), end_text)
        p.setPen(QPen(C.INK2, 1.6))
        p.drawLine(QPointF(x1, tick_top - 2), QPointF(x1, bar_y + 4))
        p.setPen(QPen(C.ACCENT, 2))
        p.drawLine(QPointF(nx, tick_top - 8), QPointF(nx, bar_y + 6))
        p.setPen(QPen(C.CARD, 1.5))
        p.setBrush(C.ACCENT)
        p.drawEllipse(QPointF(nx, tick_top - 9), 3.6, 3.6)
        p.setFont(cap_font)
        p.setPen(C.SOFT)
        p.drawText(QRectF(cap_x, bar_y + 10, cap_w + 2, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), cap)
        p.end()


class EntryTile(_Hover):
    """一个入口：图标 + 名字 + 一句话。整块可点。"""

    def __init__(self, icon: str, name: str, desc: str, on_click, tip: str = ""):
        super().__init__(on_click)
        self.icon, self.name, self.desc = icon, name, desc
        self.setFixedHeight(52 if dense() else 62)
        self.setMinimumWidth(170)
        if tip:
            self.setToolTip(tip)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        fill = None if doodle() else (C.LINE if self._down else C.KEYHOVER if self._hover else C.CARD)
        r = paint_card(p, self.rect(), 12, self._hover, self._down, fill)
        box = QRectF(r.x() + 13, r.y() + (r.height() - 34) / 2, 34, 34)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_tint(C.INK2, 0.16 if self._hover else 0.10))
        p.drawRoundedRect(box, 7, 7)
        draw_icon(p, self.icon, box.adjusted(8, 8, -8, -8), C.INK2, 1.6)
        tx = box.right() + 12
        tw = r.right() - tx - 26
        p.setFont(f(12.5, 700))
        p.setPen(C.INK)
        top = r.y() + (r.height() - 39) / 2
        p.drawText(QRectF(tx, top, tw, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.name)
        p.setFont(f(10.5))
        p.setPen(C.FAINT)
        fm = QFontMetricsF(p.font())
        p.drawText(QRectF(tx, top + 20, tw, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   fm.elidedText(self.desc, Qt.TextElideMode.ElideRight, tw))
        draw_icon(p, "chevron_r", QRectF(r.right() - 24, r.center().y() - 7, 14, 14), C.INK2 if self._hover else C.FAINT, 1.5)
        p.end()


def _today_question_card(ctx) -> Card:
    q = store.question_of_day()
    card = Card("今日一题", f"每天换一道 · {store.bank_years()} 高考题")
    if not q:
        card.add(label("题库尚未就绪", 12, C.FAINT, wrap=True))
        return card
    card.add(lab(f"{q['subject']} · {q['year']} 年 · {q['paper']}", 10.5, "INK2", 700, 1.0))
    card.add(lab(q["title"], 15.5, "INK", 700, wrap=True))
    card.add(lab(_clip(plain(q["stem"]), 150), 11.5, "SOFT", wrap=True))   # 先换上下标再截断
    card.body.addStretch(1)
    btn = Btn("打开解析 →", "primary")
    btn.setFixedWidth(112)
    btn.clicked.connect(lambda: ctx.open_question(q["id"]))
    rnd = Btn("换一道", "soft", "从题库里随机抽一道")
    rnd.clicked.connect(ctx.random_question)
    card.add(row(btn, rnd, None))
    return card


def _guanlan_card(ctx) -> Card:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    card = Card("观澜 · 今日焦点", store.guanlan_date() or "等待今日版")
    title = lab(_clip(lead.get("title", ""), 46) or "今日版尚未生成", 15.5, "INK", 700, wrap=True)
    if not stories:
        title.setToolTip("在「观澜」页点「刷新内容」抓取一次")
    card.add(title)
    if lead.get("summary"):
        card.add(lab(_clip(lead["summary"], 78), 11.5, "SOFT", wrap=True))
    for i, st in enumerate(stories[1:4], start=2):
        line = QHBoxLayout()
        line.setSpacing(8)
        n = QLabel(f"{i:02d}")
        n.setFont(serif(11, 600))
        n.setStyleSheet(f"color:{C.INK2H};background:transparent;")
        n.setFixedWidth(18)
        line.addWidget(n)
        line.addWidget(lab(_clip(st["title"], 34), 11.5, "BODY"), 1)
        card.body.addLayout(line)
    card.body.addStretch(1)
    btn = Btn("打开浮窗", "soft", "在桌面上打开观澜浮窗")
    btn.setFixedWidth(96)
    btn.clicked.connect(ctx.toggle_guanlan)
    more = lab(f"共 {len(stories)} 条 · 约 15 分钟" if stories else "到「观澜」页刷新一次即可", 10.5, "FAINT")
    card.add(row(btn, more, None))
    return card


def _entries(ctx, cols: int = 3) -> QGridLayout:
    grid = QGridLayout()
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setHorizontalSpacing(8 if dense() else 12)
    grid.setVerticalSpacing(7 if dense() else 10)
    items = [
        ("guanlan", "观澜浮窗", "每日 7 条世界线索 · 人物 · 金句", ctx.toggle_guanlan),
        ("countdown", "时间胶囊", "贴在桌面上的一把时间尺", ctx.toggle_pill),
        ("studio", "习题台", "真题一题一图 · 引导动画讲过程", lambda: ctx.open_studio("")),
        ("lab", "格物实验台", "四科实验 · 自由工作台", lambda: ctx.open_lab("")),
        ("analysis", "析题", "粘贴一道题：解题、选实验、演示", lambda: ctx.open_lab("import")),
        ("lecture", "课件", "导入课件 · 放映 · 画笔与黑板", lambda: ctx.goto("lecture")),
    ]
    for i, (icon, name, desc, fn) in enumerate(items):
        grid.addWidget(EntryTile(icon, name, desc, fn), i // cols, i % cols)
    for c in range(cols):
        grid.setColumnStretch(c, 1)
    return grid


def build_overview(ctx) -> QWidget:
    now = datetime.now()
    hello = "早上好" if now.hour < 11 else "中午好" if now.hour < 14 else "下午好" if now.hour < 18 else "晚上好"
    page = Page(ctx, "见微 · 高考学习舱", "今日", f"{hello} · {now:%Y 年 %m 月 %d 日} 周{WEEK_CN[now.weekday()]}")
    page.add(Hero(ctx))
    grid = QGridLayout()
    grid.setSpacing(page.gap)
    grid.addWidget(_today_question_card(ctx), 0, 0)
    grid.addWidget(_guanlan_card(ctx), 0, 1)
    grid.setColumnStretch(0, 1)
    grid.setColumnStretch(1, 1)
    page.add(grid)
    page.add(_entries(ctx))
    from native.learning_ui import card as learning_card
    learn = learning_card(ctx)
    for b in learn.findChildren(QPushButton):     # 这张卡里是原生按钮：套上主窗口的按键样式
        if not b.objectName():
            b.setObjectName("btn")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFont(f(12))
    for lb in learn.findChildren(QLabel):
        if not lb.styleSheet():
            lb.setFont(f(11.5))
            lb.setStyleSheet(f"color:{C.SOFTH};background:transparent;")
    page.add(learn)     # 这张卡里是图表和几段会折行的字，放不进窄的右栏：三种排法都留在主栏
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 课件
class DeckCard(_Hover):
    """一份课件：缩略图 + 名字 + 一行信息。点一下直接全屏放映；右键有删除和管理。"""

    W, TH = 250, 141

    def __init__(self, ctx, meta: dict):
        super().__init__(lambda: ctx.play_lecture(meta))
        self.ctx, self.meta = ctx, meta
        if dense():
            self.W, self.TH = 204, 115      # 紧凑排法：缩略图小一号，一行多放一份
        self.setFixedSize(self.W, self.TH + 62)
        self.setToolTip(f"{meta.get('src_name') or meta.get('title', '')}\n点一下全屏放映；右键更多")
        self.thumb = None
        try:
            from native.lecture import library
            pm = QPixmap(str(library.folder(meta["id"]) / "thumb.png"))
            if not pm.isNull():
                self.thumb = pm.scaled(QSize(self.W, self.TH), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                       Qt.TransformationMode.SmoothTransformation)
        except Exception:
            self.thumb = None

    def contextMenuEvent(self, e):  # noqa: N802
        menu = QMenu(self)
        menu.addAction("全屏放映", lambda: self.ctx.play_lecture(self.meta))
        menu.addAction("预习这一课", self._preview)
        menu.addAction("在学习窗口里管理（重新生成、兼容模式）", lambda: self.ctx.open_web("lecture"))
        menu.addSeparator()
        menu.addAction("删除…", lambda: self.ctx.delete_lecture(self.meta))
        menu.exec(e.globalPos())

    def _preview(self):
        try:
            from native.preview_ui import preview_lecture
            if preview_lecture(self.ctx, self.meta, self.window()) is None:
                self.ctx.toast("这份课件里没认出知识点；可以在「今日 → 预习」里按章节选。")
        except Exception as exc:  # noqa: BLE001
            self.ctx.toast(f"打不开预习：{exc}")

    def paintEvent(self, _e):  # noqa: N802
        m = self.meta
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        r = paint_card(p, self.rect(), 12, False, self._down, fill=C.CARD)
        card = QPainterPath()
        card.addRoundedRect(r, 12, 12)
        p.save()
        p.setClipPath(card)
        if doodle():
            p.translate(0, r.y() - 1)       # 手绘皮肤里卡面按下会下沉：里面的内容跟着走
        area = QRectF(0, 0, self.W, self.TH)
        p.setClipRect(area, Qt.ClipOperation.IntersectClip)
        if self.thumb is not None:
            p.drawPixmap(int((self.W - self.thumb.width()) / 2), int((self.TH - self.thumb.height()) / 2), self.thumb)
        else:
            p.fillRect(area, _tint(C.INK, 0.06))
            draw_icon(p, "lecture", QRectF(self.W / 2 - 16, self.TH / 2 - 16, 32, 32), C.FAINT, 1.6)
        if self._hover:
            p.fillRect(area, QColor(0, 0, 0, 70))
            c = area.center()
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 255, 255, 238))
            p.drawEllipse(c, 22, 22)
            tri = QPolygonF([QPointF(c.x() - 6, c.y() - 9), QPointF(c.x() + 10, c.y()), QPointF(c.x() - 6, c.y() + 9)])
            p.setBrush(QColor("#1B1A18"))
            p.drawPolygon(tri)
        p.restore()
        p.setPen(QPen(C.LINE, 1))
        p.drawLine(QPointF(1, self.TH + 0.5), QPointF(self.W - 1, self.TH + 0.5))
        pages = int(m.get("display_pages") or m.get("pages") or 0)
        at = int(m.get("page") or 0)
        if pages > 1 and at > 0:     # 上次看到哪了：缩略图下沿一道进度
            p.fillRect(QRectF(0, self.TH - 1, self.W * min(1.0, (at + 1) / pages), 3), C.ACCENT)
        p.setFont(f(13, 700))
        p.setPen(C.INK)
        fm = QFontMetricsF(p.font())
        p.drawText(QRectF(14, self.TH + 10, self.W - 28, 22), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   fm.elidedText(str(m.get("title", "")), Qt.TextElideMode.ElideRight, self.W - 28))
        slides = m.get("kind") == "slides"
        info = f"{'演示' if slides else '文档'} · {pages} {'张' if slides else '页'}"
        if pages > 1 and at > 0:
            info += f" · 看到第 {min(pages, at + 1)} {'张' if slides else '页'}"
        elif m.get("steps"):
            info += " · 有动画"
        p.setFont(f(11))
        p.setPen(C.FAINT)
        p.drawText(QRectF(14, self.TH + 32, self.W - 28, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), info)
        p.setPen(QPen(C.KEYLINE, 2) if doodle() else QPen(C.INK if self._hover else C.LINE, 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(card)
        p.end()


class DropZone(_Hover):
    """还没有课件时的一整块：告诉人这里能干什么，点一下或拖文件进来就开始。"""

    def __init__(self, on_click):
        super().__init__(on_click)
        self.setMinimumHeight(300)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(C.INK if self._hover else C.KEYLINE, 1.2, Qt.PenStyle.DashLine))
        p.setBrush(_tint(C.INK, 0.035 if self._hover else 0.0))
        p.drawRoundedRect(r, 14, 14)
        c = r.center()
        box = QRectF(c.x() - 28, c.y() - 78, 56, 56)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_tint(C.INK, 0.07))
        p.drawRoundedRect(box, 14, 14)
        draw_icon(p, "lecture", box.adjusted(15, 15, -15, -15), C.INK, 1.7)
        p.setFont(title_font(18 if r.width() > 440 else 15))
        p.setPen(C.INK)
        p.drawText(QRectF(r.x(), c.y() - 8, r.width(), 30), int(Qt.AlignmentFlag.AlignCenter), "把课件拖到这里")
        p.setFont(f(12 if r.width() > 440 else 11))
        p.setPen(C.SOFT)
        p.drawText(QRectF(r.x(), c.y() + 26, r.width(), 22), int(Qt.AlignmentFlag.AlignCenter),
                   "PPT、Word、PDF 都行；或者点这里选文件")
        if r.width() > 440:     # 窄的时候（分栏排法的右栏里）放不下这一行
            p.setFont(f(11))
            p.setPen(C.FAINT)
            p.drawText(QRectF(r.x(), c.y() + 54, r.width(), 20), int(Qt.AlignmentFlag.AlignCenter),
                       "导入后点一下就全屏放映，可以用笔勾画、框选一块上网查、带进黑板")
        p.end()


def build_lecture(ctx) -> QWidget:
    from native.design.widgets import FlowLayout
    try:
        from native.lecture import library
        from native.lecture.convert import SUPPORTED
        items = library.all_lectures()
    except Exception:
        items, SUPPORTED = [], ()
    sub = f"{len(items)} 份 · 点一下全屏放映" if items else "导入 PPT、Word、PDF，全屏放映"
    page = Page(ctx, "课件", "课件", sub)

    status_card = Card("", pad=(16, 11, 16, 11))
    status = lab("", 12, "BODY", wrap=True)
    status_card.add(status)
    status_card.hide()
    watcher = QTimer(page)
    watcher.setInterval(350)

    def backend():
        native = getattr(ctx, "_native", None)
        return native.pages.get("lecture") if native is not None else None

    def watch():
        b = backend()
        if b is None:
            watcher.stop()
            return
        text = b.status.text()
        if b.worker is not None or b.queue:
            status.setText(text or "正在导入…")
            status_card.show()
            return
        watcher.stop()      # 这一批导完了：换成新的课件列表，结果用提示条说一声
        if text:
            ctx.toast(text if len(text) < 60 else text[:58] + "…")
        QTimer.singleShot(0, lambda: ctx.refresh_pages(("lecture",)))

    watcher.timeout.connect(watch)

    def start_import(paths=None):
        if ctx.import_lectures(paths):
            status.setText("正在导入…")
            status_card.show()
            watcher.start()

    page.action("桌面工具栏", ctx.toggle_desktop_tools,
                tip="一条悬浮在桌面上的画笔工具栏：在别的软件（比如直接用 WPS 放映）上也能批注")
    page.action("导入课件", start_import, "primary", "选 PPT、Word、PDF 文件；也可以直接把文件拖进这一页", "plus")
    page.add(status_card)

    if not items:
        page.add(DropZone(start_import))
    else:
        holder = QWidget()
        flow = FlowLayout(holder, spacing=16)

        def fill(text=""):
            while flow.count():
                it = flow.takeAt(0)
                if it.widget() is not None:
                    it.widget().hide()
                    it.widget().deleteLater()
            text = text.strip().casefold()
            shown = [m for m in items if not text or text in (str(m.get("title", "")) + " " + str(m.get("src_name", ""))).casefold()]
            for m in shown:
                flow.addWidget(DeckCard(ctx, m))
            holder.updateGeometry()

        if len(items) > 8:
            search = QLineEdit()
            search.setPlaceholderText("搜课件名字")
            search.setClearButtonEnabled(True)
            search.setFixedWidth(260)
            search.textChanged.connect(fill)
            page.add(row(search, None))
        fill()
        page.add(holder)
        page.add(lab("笔迹和黑板跟着课件一起保存。右键课件可以删除；要重新生成副本、换兼容模式，到学习窗口的课件页。", 11, "FAINT", wrap=True),
                 side=True)
    page.body.addStretch(1)

    # 整页都能接拖进来的文件
    def drag_enter(e):
        if e.mimeData().hasUrls() and any(os.path.splitext(u.toLocalFile())[1].lower() in SUPPORTED for u in e.mimeData().urls()):
            e.acceptProposedAction()

    def drop(e):
        start_import([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])
        e.acceptProposedAction()

    page.setAcceptDrops(True)
    page.dragEnterEvent = drag_enter
    page.dropEvent = drop
    b = backend()
    if b is not None and (b.worker is not None or b.queue):     # 页面重建时正好有课件在导：接着显示进度
        status_card.show()
        watcher.start()
    return page


# ------------------------------------------------------------------ 观澜
def build_guanlan(ctx) -> QWidget:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    page = Page(ctx, "观澜 · 每日世界线索", "观澜", "每天七条世界线索，在桌面浮窗里读")
    lead_card = Card("", pad=(26, 22, 26, 22))
    lead_card.add(kicker(f"今日焦点 · {store.guanlan_date() or '—'}"))
    lead_card.add(lab(lead.get("title", "") or "今日版尚未生成", 18 if dense() else 22, "INK", 700, 0.2, wrap=True))
    if lead.get("summary"):
        lead_card.add(lab(lead["summary"], 12.5, "SOFT", wrap=True))
    elif not stories and not store.guanlan_date():
        lead_card.add(label("还没有任何一期内容。点下面的「刷新内容」抓取今天的世界线索（需要联网，约 30 秒）；"
                            "之后见微在托盘里常驻时，每天 07:15 会自动更新。", 12, C.SOFT, wrap=True))
    page.add(lead_card)

    # 浮窗版式：四种里选一种，点了立即生效（浮窗开着就当场换）
    ctx.guanlan._ensure_path()      # 和浮窗用同一份模块（ui.*），别从 guanlan.ui 再导一份
    from ui.layouts import LAYOUT_NAMES, LAYOUT_TIPS, LAYOUTS  # type: ignore
    form = Card("浮窗版式", "桌面上的观澜长什么样")
    chips_row = QHBoxLayout()
    chips_row.setSpacing(6)
    current = ctx.guanlan.layout()
    gl_chips: dict = {}
    hint = lab(LAYOUT_TIPS.get(current, ""), 11, "FAINT", wrap=True)

    def pick(key: str) -> None:
        for k, c in gl_chips.items():
            c.setChecked(k == key)
        hint.setText(LAYOUT_TIPS[key])
        ctx.guanlan.set_layout(key)
        ctx.toast(f"观澜换成「{LAYOUT_NAMES[key]}」")

    for key in LAYOUTS:
        chip = Chip(LAYOUT_NAMES[key])
        chip.setChecked(key == current)
        chip.setToolTip(LAYOUT_TIPS[key])
        chip.clicked.connect(lambda _=False, k=key: pick(k))
        gl_chips[key] = chip
        chips_row.addWidget(chip)
    chips_row.addStretch(1)
    form.body.addLayout(chips_row)
    form.add(hint)
    page.add(form, side=True)
    page.action("刷新内容", ctx.refresh_guanlan, tip="重新抓取今天的世界线索：需要联网，约 30 秒。平时每天 07:15 自动更新")
    page.action("打开浮窗", ctx.toggle_guanlan, "primary", "在桌面上打开 / 收起观澜浮窗（Alt+Shift+G）", "guanlan")

    b_now = Btn("现在播放", "", "生成今晚的暮省并全屏播放", "play")
    b_now.clicked.connect(ctx.evening)
    b_old = Btn("往期", "soft", "选一期重播")
    b_old.clicked.connect(ctx.evening_archive)
    n = ctx.guanlan.library_counts()
    shelf = Card("素材库与筛选", (f"人物 {n.get('people', 0)} 位 · 金句 {n.get('quotes', 0)} 句 · 格局词条 {n.get('terms', 0)} 个"
                                if n else "人物、金句、格局词条"))
    shelf.add(lab("素材库可以按领域、时代、地区、作文主题、出处、学科筛选，也能直接搜索；"
                  "每条都能收藏、复制成素材卡，还能只看和今天新闻相关的。"
                  "新闻的筛选偏好（多看 / 少看的主题、地区、屏蔽词、每天几条）在浮窗的设置里。", 11.5, "SOFT", wrap=True))
    summary = ctx.guanlan.prefs_summary()
    if summary:
        shelf.add(lab("现在：" + summary, 11, "FAINT", wrap=True))
    row = QHBoxLayout()
    row.setSpacing(6)
    for text, kind in (("人物库", "people"), ("金句库", "quotes"), ("格局词典", "terms")):
        b = Btn(text, "soft", f"打开浮窗里的{text}")
        b.clicked.connect(lambda _=False, k=kind: ctx.guanlan.open_library(k))
        row.addWidget(b)
    favs = n.get("favorites", 0) if n else 0
    b = Btn(f"我的收藏 {favs}" if favs else "我的收藏", "soft", "打开素材库，只看收藏的人物")
    b.clicked.connect(lambda _=False: ctx.guanlan.open_library("people", favorites=True))
    row.addWidget(b)
    b = Btn("筛选偏好", "soft", "打开浮窗的设置，调整新闻的筛选偏好")
    b.clicked.connect(lambda _=False: ctx.guanlan.open_settings())
    row.addWidget(b)
    row.addStretch(1)
    shelf.body.addLayout(row)
    page.add(shelf)

    eve = Card("晚间暮省", "每晚 22:20 全屏回看这一天；也可以现在就看")
    eve.head.addWidget(b_old)
    eve.head.addWidget(b_now)
    page.add(eve, side=True)

    if stories:
        list_card = Card("今日线索", f"共 {len(stories)} 条 · 在浮窗里读全文")
        for i, st in enumerate(stories, 1):
            line = QHBoxLayout()
            line.setSpacing(12)
            idx = QLabel(f"{i:02d}")
            idx.setFont(serif(13, 600))
            idx.setStyleSheet(f"color:{C.INK2H if i == 1 else C.FAINTH};background:transparent;")
            idx.setFixedWidth(24)
            line.addWidget(idx, 0, Qt.AlignmentFlag.AlignTop)
            col = QVBoxLayout()
            col.setSpacing(2)
            col.addWidget(lab(st["title"], 12.5, "INK", 500, wrap=True))
            meta = " · ".join(x for x in [st.get("section", ""), st.get("source", ""),
                                          (f"{st['minutes']} 分钟" if st.get("minutes") else "")] if x)
            if meta:
                col.addWidget(lab(meta, 10.5, "FAINT"))
            line.addLayout(col, 1)
            list_card.body.addLayout(line)
            if i < len(stories):
                list_card.body.addWidget(divider())
        page.add(list_card)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 实验室
_SUBJ = (("math", "数学", "#2B55A6", "#86ADF0"), ("phys", "物理", "#BF4D27", "#EE8A5E"),
         ("chem", "化学", "#0F7D78", "#4CC3B5"), ("bio", "生物", "#53831F", "#9CCC5A"))
# 题库里文科也有题：给一套同样明度的颜色（昼 / 夜）
_SUBJ_NAME = {"数学": ("#2B55A6", "#86ADF0"), "物理": ("#BF4D27", "#EE8A5E"), "化学": ("#0F7D78", "#4CC3B5"),
              "生物": ("#53831F", "#9CCC5A"), "语文": ("#8A5A2B", "#D9A66B"), "英语": ("#6B4FA0", "#B79BE8"),
              "历史": ("#9A3B3B", "#E58B8B"), "地理": ("#2F7A8C", "#6CC4D8"), "政治": ("#7A6A1F", "#D4C261")}


def _subj_color(key: str) -> str:
    import ui_kit
    night = ui_kit.theme() == "night"
    for k, _, day, dark in _SUBJ:
        if k == key:
            return dark if night else day
    pair = _SUBJ_NAME.get(key)
    if pair:
        return pair[1] if night else pair[0]
    return C.INK2.name()


class _SubjTile(_Hover):
    """一科一格：大数字 + 学科色细条，点一下进实验台对应学科。"""

    def __init__(self, key: str, name: str, count: int, on_click):
        super().__init__(on_click)
        self.key, self.name, self.count = key, name, count
        self.setFixedHeight(92)
        self.setMinimumWidth(120)
        self.setToolTip(f"打开格物实验台 · {name}")

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        col = QColor(_subj_color(self.key))
        r = paint_card(p, self.rect(), 12, False, self._down,
                       fill=C.CARD, line=col if (self._hover and not doodle()) else None)
        if self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_tint(col, 0.06))
            p.drawRoundedRect(r, 12, 12)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawRoundedRect(QRectF(16, 16, 22, 4), 2, 2)
        p.setPen(QPen(C.SOFT))
        p.setFont(f(12, 600, 1.2))
        p.drawText(QRectF(16, 26, r.width() - 32, 22), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   self.name)
        p.setPen(QPen(col))
        p.setFont(serif(30, 600))
        p.drawText(QRectF(16, 44, r.width() - 32, 40), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   str(self.count))
        p.setPen(QPen(col if self._hover else C.FAINT))
        p.setFont(f(10.5))
        p.drawText(QRectF(16, 44, r.width() - 32, 40), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter),
                   "个实验 →" if self._hover else "个实验")
        p.end()


def build_reading(ctx) -> QWidget:
    """读文：和学习窗口的「读文」模式是同一个控件（原文、草稿、精析缓存都共用）。"""
    from native.reading.page import ReadingPage
    page = Page(ctx, "读文", "读文", "文言文 · 英语：边输入边逐字精析，光标放到哪个字就讲哪个字")
    reading = ReadingPage(compact=True)
    reading.setMinimumHeight(560)
    page.body.addWidget(reading, 1)
    page.reading = reading
    return page


def build_lab(ctx) -> QWidget:
    st = store.lab_stats()
    page = Page(ctx, "格物实验台 · 高中数理化生", "实验室",
                f"{st['total']} 个教材实验 · {len(st['benches'])} 个自由工作台")
    page.action("析题", lambda: ctx.open_lab("import"), tip="粘贴一道题：解题、选实验、配参数、演示", icon="analysis")
    page.action("打开实验台", lambda: ctx.open_lab(""), "primary", "在学习窗口里打开格物实验台", "lab")

    page.add(lab("点一科，进这一科的教材实验", 11.5, "FAINT"))
    tiles = QHBoxLayout()
    tiles.setSpacing(12)
    for key, name, _, _ in _SUBJ:
        tiles.addWidget(_SubjTile(key, name, st["subj"].get(key, 0),
                                  lambda k=key: ctx.open_lab(f"subj/{k}")), 1)
    page.add(tiles)

    bench = Card("自由工作台", "自己选器材，搭想做的实验")
    for i, b in enumerate(st["benches"]):
        line = QHBoxLayout()
        line.setSpacing(12)
        line.addWidget(Dot(QColor(_subj_color(b["subj"])), 7), 0, Qt.AlignmentFlag.AlignVCenter)
        n = lab(b["title"], 12.5, "INK", 700)
        n.setFixedWidth(112)
        line.addWidget(n)
        line.addWidget(lab(b["sub"], 11, "SOFT", wrap=True), 1)
        if b["id"] in ("draw", "scene"):
            line.addWidget(lab("原变换实验室", 10, "FAINT"))
        go = Btn("进入", "soft")
        go.setFixedWidth(64)
        go.clicked.connect(lambda _=False, k=b["id"]: ctx.open_lab(f"bench/{k}"))
        line.addWidget(go)
        bench.body.addLayout(line)
        if i < len(st["benches"]) - 1:
            bench.add(divider())
    page.add(bench)

    ds = store.deepseek_settings()
    imp = Card("题目导入", "粘贴题干 → 解题、选实验、配参数 → 直接演示")
    imp.add(label("分析分四步：解题并挑实验 → 设好控件 → 读出画面数值和答案比对 → 不符就重解。"
                  "数都由程序算，再用第二种方法核对；没有密钥时用离线读题器处理常见题型。", 11.5, C.SOFT, wrap=True))
    state = lab(("● " + ds["name"] + " 已配置（" + ds["model"] + "）") if ds["key"] else "○ 未配置 AI 密钥，使用离线读题器",
                11, "JADE" if ds["key"] else "ACCENT", 700)
    go_imp = Btn("打开导入", "soft")
    go_imp.clicked.connect(lambda: ctx.open_lab("import"))
    go_set = Btn("去设置密钥")
    go_set.clicked.connect(lambda: ctx.goto("settings"))
    imp.add(row(state, None, go_set, go_imp))
    page.add(imp, side=True)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 倒计时
class PillPreview(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.sync_size()
        self._t = QTimer(self)
        self._t.setInterval(1000)
        self._t.timeout.connect(self.update)

    def sync_size(self) -> None:
        """预览框的高度跟着版式：横条矮，方块、竖条高一些。"""
        from countdown import pill_layout
        self.setFixedHeight({"tile": 250, "column": 360}.get(pill_layout(self.ctx.cfg), 132))
        self.update()

    def showEvent(self, e):  # noqa: N802
        self._t.start()
        super().showEvent(e)

    def hideEvent(self, e):  # noqa: N802
        self._t.stop()      # 不在这一页时不用每秒重画
        super().hideEvent(e)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        # 一小块模拟桌面：胶囊是半透明的，放在白卡片上看不出真实效果
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()), 7, 7)
        light = str(self.ctx.cfg.get("pillStyle", "auto")) == "porcelain"
        g = QLinearGradient(0, 0, self.width(), self.height())
        g.setColorAt(0, QColor("#DCE6E2" if light else "#2A4A52"))
        g.setColorAt(1, QColor("#AFC4C8" if light else "#16282C"))
        p.fillPath(path, g)
        from countdown import pill_size
        cw, ch = pill_size(self.ctx.cfg)
        scale = min(1.0, (self.width() - 40) / max(1, cw), (self.height() - 24) / max(1, ch))
        p.translate((self.width() - cw * scale) / 2, (self.height() - ch * scale) / 2)
        p.scale(scale, scale)
        draw_pill(p, cw, ch, self.ctx.cfg, datetime.now(), None, 0.7)
        p.end()


def _slider(ctx, label_text: str, key: str, lo: int, hi: int, changed=None) -> tuple[QWidget, QSlider, QLabel]:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(3)
    top = QHBoxLayout()
    v = QLabel(str(ctx.cfg.get(key)))
    v.setFont(serif(12, 600))
    v.setStyleSheet(f"color:{C.INKH};background:transparent;")
    top.addWidget(lab(label_text, 11, "SOFT"))
    top.addStretch(1)
    top.addWidget(v)
    s = QSlider(Qt.Orientation.Horizontal)
    s.setRange(lo, hi)
    s.setValue(int(ctx.cfg.get(key, lo)))
    s.setCursor(Qt.CursorShape.PointingHandCursor)
    s.setProperty("jw_default", int(store.DEFAULT_CONFIG.get(key, lo)))   # 双击滑块回到默认值
    s.setToolTip("拖动调整；双击回到默认值")

    def on_change(val):
        v.setText(str(val))
        ctx.cfg[key] = val
        ctx.apply_pill()
        if changed:
            changed()

    s.valueChanged.connect(on_change)
    lay.addLayout(top)
    lay.addWidget(s)
    return box, s, v


def build_countdown(ctx) -> QWidget:
    page = Page(ctx, "倒计时 · 时间胶囊", "倒计时", "贴在桌面上的一把时间尺")
    shown = lambda: ctx.pill is not None and ctx.pill.isVisible()  # noqa: E731
    toggle = page.action("隐藏胶囊" if shown() else "显示胶囊", lambda: None, "primary", "在桌面上显示 / 隐藏时间胶囊", "countdown")

    def flip():
        ctx.show_pill(not shown())
        toggle.setText("隐藏胶囊" if shown() else "显示胶囊")

    toggle.clicked.connect(flip)
    preview = Card("", pad=(16, 14, 16, 14))
    pill_view = PillPreview(ctx)
    preview.add(pill_view)
    preview.add(lab("一周一格、一月一道长刻度，朱砂指针是今天。桌面上可以直接拖动；右键有常用操作，双击打开见微，鼠标移到尺上能看任意一天",
                    10.5, "FAINT", wrap=True))
    page.add(preview)

    ctrl = Card("外观与行为", "改动立即生效，自动保存")
    from countdown import LAYOUT_NAMES, LAYOUTS, pill_layout
    lay_row = QHBoxLayout()
    lay_row.setSpacing(6)
    lay_row.addWidget(lab("版式", 11, "SOFT"))
    lay_row.addSpacing(4)
    lay_tips = {"bar": "横在屏幕顶上的一把时间尺（原来的样子）", "tile": "放在桌面角落的方块：表盘 + 下一个节点",
                "column": "贴在屏幕边上的竖条：尺从上往下走", "mini": "很小的一条：只有天数、细进度和时钟"}
    lay_chips: dict[str, Chip] = {}
    for key in LAYOUTS:
        chip = Chip(LAYOUT_NAMES[key])
        chip.setChecked(key == pill_layout(ctx.cfg))
        chip.setToolTip(lay_tips[key])
        lay_chips[key] = chip
        lay_row.addWidget(chip)
    lay_row.addStretch(1)
    ctrl.body.addLayout(lay_row)

    def set_layout(key: str) -> None:
        for k, c in lay_chips.items():
            c.setChecked(k == key)
        ctx.set_pill_layout(key)
        pill_view.sync_size()
        sync_layout_knobs()

    for key, chip in lay_chips.items():
        chip.clicked.connect(lambda _=False, k=key: set_layout(k))

    date_row = QHBoxLayout()
    date_row.setSpacing(8)
    date_row.addWidget(lab("目标时刻", 11, "SOFT"))
    edit = QLineEdit(ctx.cfg.get("target", "2027-06-07 09:00:00"))
    edit.setFixedWidth(190)
    edit.setPlaceholderText("2027-06-07 09:00:00")
    date_row.addWidget(edit)
    ok = Btn("应用")
    ok.setFixedWidth(56)

    def apply_date():
        txt = edit.text().strip()
        try:
            datetime.strptime(txt, "%Y-%m-%d %H:%M:%S")
            ctx.cfg["target"] = txt
            ctx.apply_pill()
            ctx.save()
            pill_view.update()
            ctx.toast("目标时刻已更新")
        except Exception:
            ctx.toast("格式应为 2027-06-07 09:00:00")

    ok.clicked.connect(apply_date)
    edit.returnPressed.connect(apply_date)
    date_row.addWidget(ok)
    date_row.addSpacing(18)
    date_row.addWidget(lab("样式", 11, "SOFT"))
    style_box = Combo()
    for text, key in (("跟随壁纸明暗", "auto"), ("墨色", "ink"), ("瓷白", "porcelain")):
        style_box.addItem(text, key)
    style_box.setCurrentIndex(max(0, style_box.findData(str(ctx.cfg.get("pillStyle", "auto")))))

    def set_style(_i):
        ctx.cfg["pillStyle"] = style_box.currentData()
        ctx.apply_pill()
        pill_view.update()

    style_box.currentIndexChanged.connect(set_style)
    date_row.addWidget(style_box)
    date_row.addStretch(1)
    ctrl.body.addLayout(date_row)

    mile_row = QHBoxLayout()
    mile_row.setSpacing(8)
    mile_row.addWidget(lab("尺上节点", 11, "SOFT"))
    mile = QLineEdit(format_milestones(ctx.cfg.get("milestones")))
    mile.setPlaceholderText("可选：2027-03-10 一模；2027-04-20 二模")
    mile_row.addWidget(mile, 1)
    mile_ok = Btn("应用")
    mile_ok.setFixedWidth(56)

    def apply_miles():
        items = parse_milestones(mile.text())
        ctx.cfg["milestones"] = items
        mile.setText(format_milestones(items))
        ctx.apply_pill()
        pill_view.update()
        ctx.toast(f"尺上有 {len(items)} 个节点")

    mile_ok.clicked.connect(apply_miles)
    mile.returnPressed.connect(apply_miles)
    mile_row.addWidget(mile_ok)
    ctrl.body.addLayout(mile_row)
    ctrl.body.addSpacing(2)

    sliders = QGridLayout()
    sliders.setHorizontalSpacing(26)
    sliders.setVerticalSpacing(6)
    knobs: dict[str, tuple[QSlider, QLabel]] = {}
    for i, (text, key, lo, hi) in enumerate((("宽度", "width", 640, 1200), ("高度", "height", 52, 88),
                                             ("距顶部", "marginTop", 0, 160),
                                             ("指针光晕", "aurora", 0, 160),   # 默认 96；上限要盖住默认值，否则一碰就被截断
                                             ("底色浓度", "shade", 40, 150))):
        box, s, v = _slider(ctx, text, key, lo, hi, pill_view.update)
        knobs[key] = (s, v)
        sliders.addWidget(box, i // 2, i % 2)
    ctrl.body.addLayout(sliders)
    ctrl.body.addSpacing(2)

    def sync_layout_knobs():
        """宽度只对横尺有用；别的版式「高度」就是整体大小。"""
        bar = pill_layout(ctx.cfg) == "bar"
        knobs["width"][0].setEnabled(bar)
        knobs["width"][0].setToolTip("拖动调整；双击回到默认值" if bar else "这种版式的宽度是固定比例，用「高度」调整体大小")
        knobs["height"][0].setToolTip("拖动调整；双击回到默认值" if bar else "这种版式里，高度就是整体大小（60 = 1 倍）")

    sync_layout_knobs()

    def sync_knobs():
        """预设、居中这类操作改了配置：把滑块挪到新值（不再触发保存）。"""
        for key, (s, v) in knobs.items():
            s.blockSignals(True)
            s.setValue(int(ctx.cfg.get(key, s.value())))
            s.blockSignals(False)
            v.setText(str(s.value()))
        pill_view.update()

    checks = QHBoxLayout()
    checks.setSpacing(20)
    for text, key in (("显示秒", "showSeconds"), ("显示日期", "showDate"),
                      ("点击穿透", "clickThrough"), ("启动时显示", "showPill")):
        cb = Check(text)
        cb.setChecked(bool(ctx.cfg.get(key)))
        cb.toggled.connect(lambda v, k=key: (ctx.cfg.__setitem__(k, v), ctx.apply_pill(), ctx.save(), pill_view.update()))
        checks.addWidget(cb)
    top_cb = Check("置顶显示")
    top_cb.setChecked(str(ctx.cfg.get("zorder", "bottom")) == "top")
    top_cb.setToolTip("默认沉在最底层：只在壁纸上可见，任何窗口都能压住它")
    top_cb.toggled.connect(lambda v: (ctx.cfg.__setitem__("zorder", "top" if v else "bottom"),
                                      ctx.apply_pill(), ctx.save()))
    checks.addWidget(top_cb)
    checks.addStretch(1)
    ctrl.body.addLayout(checks)
    ctrl.body.addSpacing(2)

    btns = QHBoxLayout()
    btns.setSpacing(8)
    b_center = Btn("回到顶部居中")
    b_center.clicked.connect(lambda: (ctx.center_pill(), sync_knobs()))
    btns.addWidget(b_center)
    btns.addStretch(1)
    btns.addWidget(lab("尺寸预设", 11, "SOFT"))
    for name, (w, h) in (("紧凑", (720, 52)), ("标准", (860, 60)), ("宽幅", (1060, 72))):
        b = Btn(name, "soft")
        b.clicked.connect(lambda _=False, w=w, h=h: (ctx.preset_pill(w, h), sync_knobs()))
        btns.addWidget(b)
    ctrl.body.addLayout(btns)
    page.add(ctrl)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 习题台
class QuestionList(QWidget):
    """题目索引：整张表自己画，只画看得见的那几行。

    以前每道题是一行控件（标签 ×4 + 按钮 + 容器），两百多题就是一千多个控件，
    建页面和换主题各要半秒多；现在是一个控件，滚动、筛选都只是重画。
    """

    ROW = 42

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        if dense():
            self.ROW = 34       # 紧凑排法：行矮一些，一屏多看四五道
        self.rows: list[dict] = []
        self.hover = -1
        self.empty_text = "这个科目还没有题目"
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_rows(self, rows: list[dict], empty_text: str = "") -> None:
        self.rows = rows
        self.hover = -1
        if empty_text:
            self.empty_text = empty_text
        self.setFixedHeight(max(self.ROW * len(rows), 96))
        self.update()

    def _at(self, y: float) -> int:
        i = int(y // self.ROW)
        return i if 0 <= i < len(self.rows) else -1

    def _row_rect(self, i: int) -> QRect:
        return QRect(0, i * self.ROW, self.width(), self.ROW)

    def _set_hover(self, i: int) -> None:
        if i != self.hover:
            old, self.hover = self.hover, i
            for k in (old, i):
                if k >= 0:
                    self.update(self._row_rect(k))
            self.setCursor(Qt.CursorShape.PointingHandCursor if i >= 0 else Qt.CursorShape.ArrowCursor)

    def mouseMoveEvent(self, e):  # noqa: N802
        self._set_hover(self._at(e.position().y()))

    def leaveEvent(self, _e):  # noqa: N802
        self._set_hover(-1)

    def mouseReleaseEvent(self, e):  # noqa: N802
        i = self._at(e.position().y())
        if e.button() == Qt.MouseButton.LeftButton and i >= 0:
            self.ctx.open_question(self.rows[i]["id"])

    def paintEvent(self, ev):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, R = self.width(), self.ROW
        if not self.rows:
            p.setFont(f(12))
            p.setPen(C.FAINT)
            p.drawText(self.rect(), int(Qt.AlignmentFlag.AlignCenter), self.empty_text)
            p.end()
            return
        f_subj, f_year, f_title, f_small, f_go = f(10.5, 700), serif(11.5, 500), f(12.5), f(10.5), f(11.5, 700)
        fm_title, fm_small = QFontMetricsF(f_title), QFontMetricsF(f_small)
        center = int(Qt.AlignmentFlag.AlignCenter)
        left = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        right = int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        first = max(0, ev.rect().top() // R)
        last = min(len(self.rows) - 1, ev.rect().bottom() // R)
        for i in range(first, last + 1):
            q = self.rows[i]
            y = i * R
            hot = i == self.hover
            if hot:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(C.KEYHOVER)
                p.drawRoundedRect(QRectF(0, y + 2, w, R - 4), 6, 6)
            elif i < len(self.rows) - 1 and i + 1 != self.hover:
                p.setPen(QPen(C.LINE2, 1))
                p.drawLine(QPointF(10, y + R - 0.5), QPointF(w - 10, y + R - 0.5))
            col = QColor(_subj_color(q["subject"]))
            chip = QRectF(10, y + (R - 20) / 2, 40, 20)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_tint(col, 0.13))
            p.drawRoundedRect(chip, 4, 4)
            p.setFont(f_subj)
            p.setPen(col)
            p.drawText(chip, center, q["subject"])
            p.setFont(f_year)
            p.setPen(C.FAINT)
            p.drawText(QRectF(62, y, 40, R), left, q["year"])
            go_w = 64
            paper_w = min(150.0, fm_small.horizontalAdvance(q["paper"]) + 4)
            title_w = max(60.0, w - 108 - paper_w - go_w - 22)
            p.setFont(f_title)
            p.setPen(C.INK)
            p.drawText(QRectF(108, y, title_w, R), left, fm_title.elidedText(q["title"], Qt.TextElideMode.ElideRight, title_w))
            p.setFont(f_small)
            p.setPen(C.FAINT)
            p.drawText(QRectF(w - go_w - 14 - paper_w, y, paper_w, R), right, q["paper"])
            if hot:
                p.setFont(f_go)
                p.setPen(C.INK2)
                p.drawText(QRectF(w - go_w - 6, y, go_w - 6, R), right, "解析 →")
            else:
                draw_icon(p, "chevron_r", QRectF(w - 28, y + (R - 14) / 2, 14, 14), C.FAINT, 1.4)
        p.end()


def build_studio(ctx) -> QWidget:
    qs = store.questions()
    subjects = []
    for q in qs:
        if q["subject"] and q["subject"] not in subjects:
            subjects.append(q["subject"])
    page = Page(ctx, "习题台 · 题目可视化", "习题台",
                f"{len(qs)} 道 {store.bank_years()} 高考题，一题一图讲过程")
    page.action("导入题目", lambda: ctx.open_studio("", imp=True), tip="把自己的题加进题库")
    page.action("随机一题", ctx.random_question, tip="从题库里随机抽一道，直接打开解析")
    page.action("打开习题台", lambda: ctx.open_studio(""), "primary", "在学习窗口里打开习题台", "studio")

    state = {"cur": "全部", "text": ""}
    holder = Card("题目索引", "", pad=(12, 16, 12, 10))
    holder.head.setContentsMargins(8, 0, 8, 0)
    count = lab("", 10.5, "FAINT")
    holder.head.insertWidget(1, count, 0, Qt.AlignmentFlag.AlignBottom)
    listing = QuestionList(ctx)
    holder.add(listing)

    def fill():
        cur, text = state["cur"], state["text"].strip().lower()
        shown = [q for q in qs if (cur == "全部" or q["subject"] == cur)
                 and (not text or text in (q["title"] + " " + q["year"] + " " + q["paper"] + " " + q["subject"] + " " + q["stem"]).lower())]
        listing.set_rows(shown, "没有匹配的题目，换个关键词试试" if text else "这个科目还没有题目")
        count.setText(f"{len(shown)} 题" if len(shown) == len(qs) else f"{len(shown)} / {len(qs)} 题")

    chips = QHBoxLayout()
    chips.setSpacing(6)
    chip_widgets: list[Chip] = []

    def set_subject(name: str) -> None:
        state["cur"] = name
        for c in chip_widgets:
            c.setChecked(c.text() == name)
        fill()
        page.area.scroll_top()

    for name in ["全部"] + subjects:
        ch = Chip(name)
        ch.setChecked(name == "全部")
        ch.clicked.connect(lambda _=False, n=name: set_subject(n))
        chip_widgets.append(ch)
        chips.addWidget(ch)
    chips.addStretch(1)
    search = QLineEdit()
    search.setPlaceholderText("搜题目、年份、试卷")
    search.setClearButtonEnabled(True)
    search.setFixedWidth(210)
    search.textChanged.connect(lambda t: (state.__setitem__("text", t), fill()))
    holder.head.addWidget(search)       # 搜索框放在索引卡的右上角：和它搜的东西挨着，也不和科目键挤一行
    page.add(chips)
    fill()
    page.add(holder)
    page.body.addStretch(1)
    page.question_list, page.search = listing, search
    return page


# ------------------------------------------------------------------ 设置
def _deepseek_card(ctx) -> Card:
    """AI 服务（析题、读文、课件框选查找、识图、题目导入共用）：选服务商、填密钥和模型。
    设置存在数据目录的 deepseek.env（文件名沿用旧版），不进 config.json、不进网页、不进打包。"""
    from native.analysis import llm
    card = Card("AI 服务", "析题、读文、框选查找、识图、导入题目时使用；可以换成别家")
    ds = llm.settings()
    from_env = bool(os.environ.get(llm.PROVIDERS[ds["provider"]]["key"]))
    status = label("", 11, C.SOFT, wrap=True)
    which = Combo()
    for pid, spec in llm.PROVIDERS.items():
        which.addItem(spec["name"], pid)
    which.setCurrentIndex(max(0, which.findData(ds["provider"])))
    key_edit = QLineEdit()
    key_edit.setEchoMode(QLineEdit.EchoMode.Password)
    key_edit.setMinimumWidth(280)
    model_edit, base_edit, vision_edit = QLineEdit(), QLineEdit(), QLineEdit()
    save, test, clear = Btn("保存", "primary"), Btn("测试连接"), Btn("清除密钥", "danger")

    def cur():
        return which.currentData() or "deepseek"

    def describe():
        pid = cur()
        spec, s = llm.PROVIDERS[pid], llm.settings(pid)
        key_edit.setPlaceholderText("密钥（在 " + spec["site"] + " 申请）")
        model_edit.setText(s["model"])
        model_edit.setPlaceholderText("模型名，如 " + (spec["model"] or "接入点 ID"))
        base_edit.setText(s["base"])
        base_edit.setPlaceholderText("接口地址，如 https://…/v1")
        vision_edit.setText(s["vision"])
        vision_edit.setPlaceholderText("看图用的模型（不填就不识图）")
        if os.environ.get(spec["key"]):
            text = f"当前密钥来自环境变量 {spec['key']}（优先于这里填的）"
        elif s["key"]:
            text = f"{spec['name']} 已保存密钥：{s['key'][:3]}…{s['key'][-4:]}"
        else:
            text = f"{spec['name']} 还没有密钥。没有密钥时，析题用离线读题器，读文只用离线词表，框选查找不做 AI 核查"
        using = llm.settings()["provider"]
        status.setText(text + ("" if using == pid else f"。现在用的是 {llm.PROVIDERS[using]['name']}，点「保存」切换到这一家"))

    def do_save():
        pid = cur()
        llm.save_settings(pid, key=key_edit.text().strip() or None, model=model_edit.text(), base=base_edit.text(), vision=vision_edit.text())
        key_edit.clear()
        describe()
        ctx.toast(f"已切换到 {llm.PROVIDERS[pid]['name']}" + ("，密钥已保存" if llm.settings(pid)["key"] else "，但还没有密钥"))

    def do_clear():
        llm.save_settings(cur(), key="")
        describe()
        ctx.toast("已清除这一家的密钥")

    def do_test():
        pid = cur()
        s = llm.settings(pid)
        key = key_edit.text().strip() or s["key"]
        base = base_edit.text().strip().rstrip("/") or s["base"]
        model = model_edit.text().strip() or s["model"]
        if not key or not base or not model:
            ctx.toast("密钥、接口地址、模型名要先填齐")
            return
        ctx.toast(f"正在连接 {llm.PROVIDERS[pid]['name']}…")

        def work():
            import json as _json
            import time as _time
            import urllib.request
            body = dict(model=model, messages=[dict(role="user", content="只回答：好")], max_tokens=8, stream=False, **llm.thinking_field(model, False))
            t0 = _time.perf_counter()
            try:
                req = urllib.request.Request(base + "/chat/completions", data=_json.dumps(body).encode("utf-8"),
                                             headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
                with urllib.request.urlopen(req, timeout=20) as r:   # noqa: S310  地址是用户自己填的
                    ok = r.status == 200
                ms = (_time.perf_counter() - t0) * 1000
                ctx.toast_sig.emit(f"连接正常，用时 {ms:.0f} 毫秒（模型 {model}）" if ok else "返回异常")
            except Exception as exc:  # noqa: BLE001
                code = getattr(exc, "code", None)
                ctx.toast_sig.emit("密钥无效（401）" if code == 401 else "模型名不对或没开通（404）" if code == 404 else f"连接失败：{exc}")

        import threading
        threading.Thread(target=work, daemon=True).start()

    which.currentIndexChanged.connect(lambda _i: describe())
    save.clicked.connect(do_save)
    key_edit.returnPressed.connect(do_save)
    test.clicked.connect(do_test)
    clear.clicked.connect(do_clear)
    describe()
    head = QHBoxLayout()
    head.setSpacing(10)
    tag = lab("服务商", 12, "SOFT")
    tag.setFixedWidth(62)
    head.addWidget(tag)
    head.addWidget(which)
    head.addStretch(1)
    card.add(head)
    card.add(row(key_edit, save, test, clear, None))
    for name, edit in (("模型", model_edit), ("接口地址", base_edit), ("识图模型", vision_edit)):
        line = QHBoxLayout()
        line.setSpacing(10)
        tg = lab(name, 12, "SOFT")
        tg.setFixedWidth(62)
        line.addWidget(tg)
        line.addWidget(edit, 1)
        card.add(line)
    card.add(status)
    card.add(lab("都走 OpenAI 兼容接口。模型名以服务商文档为准，改了点「保存」。密钥只存在本机数据目录，不会打包、不会上传到别处。", 10.5, "FAINT", wrap=True))
    if from_env:
        card.add(lab("提示：环境变量里的密钥优先。", 10.5, "FAINT", wrap=True))
    card.add(divider())
    timing_box = Check("记录析题本地耗时（仅时长与状态，不含题目、答案或密钥）")
    timing_box.setChecked(ctx.cfg.get("analysisTiming") is True)
    timing_box.toggled.connect(lambda value: (ctx.cfg.__setitem__("analysisTiming", value), ctx.save()))
    card.add(timing_box)
    return card


def build_settings(ctx) -> QWidget:
    page = Page(ctx, "见微 · 设置", "设置", "本地运行 · 不上传任何数据")

    def check(card, text, key, default=False, tip=""):
        cb = Check(text)
        cb.setChecked(bool(ctx.cfg.get(key, default)))
        cb.toggled.connect(lambda v, k=key: (ctx.cfg.__setitem__(k, v), ctx.save()))
        if tip:
            cb.setToolTip(tip)
        card.add(cb)
        return cb

    import ui_kit
    look = Card("外观", "风格、页面布局、导航位置各三种，随便搭；立即生效")
    density = "dense" if dense() else "normal"
    from shell import LAYOUTS
    from native.design.tokens import SKIN_NAMES
    skin_names = {"ink": "水墨 · 宣纸与墨", "celadon": "青瓷 · 冷瓷与墨绿", "doodle": "手绘 · 粗线与色块"}
    saved_mode = str(ctx.cfg.get("themeMode") or ("auto" if ctx.cfg.get("theme") not in ("day", "night") else ctx.cfg.get("theme")))
    for name, items, current, apply in (
            ("风格", [(skin_names.get(k, n), k) for k, n in SKIN_NAMES], ui_kit.skin(), ctx.set_skin),
            ("页面布局", [(t, k) for k, t in ui_kit.PAGE_LAYOUTS], ui_kit.PAGE_LAYOUT, ctx.set_page_layout),
            ("导航位置", [(t, k) for k, t in LAYOUTS], str(ctx.cfg.get("layout") or "side"), ctx.set_layout),
            ("疏密", [("标准 · 留白多，读起来松", "normal"), ("紧凑 · 间距收小，一屏看到更多", "dense")], density, ctx.set_density),
            ("昼夜", [("跟随时间（7 点到 19 点是白天）", "auto"), ("白天", "day"), ("夜晚", "night")], saved_mode, ctx.set_theme_mode)):
        line = QHBoxLayout()
        line.setSpacing(10)
        tag = lab(name, 12, "SOFT")
        tag.setFixedWidth(62)
        line.addWidget(tag)
        box = Combo()
        for text, key in items:
            box.addItem(text, key)
        box.setCurrentIndex(max(0, box.findData(current)))
        # 换外观会重建这一页（连同这个下拉框）：等这次点击处理完再换
        box.currentIndexChanged.connect(lambda _i, b=box, fn=apply: QTimer.singleShot(0, lambda k=b.currentData(): fn(k)))
        line.addWidget(box)
        line.addStretch(1)
        look.add(line)
    look.add(lab("风格管颜色和笔触（学习窗口、观澜浮窗一起换）；页面布局管整个主窗口怎么组织；"
                 "导航位置只对「经典页面」有用（模块桌面和工作台没有菜单栏）。",
                 10.5, "FAINT", wrap=True))
    page.add(look)

    startup = Card("启动与托盘")
    cb1 = Check("开机自动启动（随 Windows 登录，静默驻留托盘）")
    cb1.setChecked(ctx.autostart_enabled())
    cb1.toggled.connect(ctx.set_autostart)
    startup.add(cb1)
    check(startup, "关闭窗口时最小化到托盘，而不是退出", "closeToTray", True)
    check(startup, "启动时直接进入托盘（不显示主窗口）", "startMinimized", False)
    check(startup, "空闲时预先备好学习窗口（第一次点开更快，多占一些内存）", "prewarmWeb", True,
          "关掉后少占一些内存；第一次打开习题台、实验台要多等一会儿")
    page.add(startup)

    daily = Card("每日节律", "由见微接管，不依赖原版观澜进程")
    check(daily, "启动时打开观澜浮窗（侧边窗口）", "showGuanlanOnStart", True)
    check(daily, "每天 07:15 自动更新世界线索", "autoFetch", True)
    check(daily, "每天 22:20 自动生成并全屏播放暮省", "autoEvening", True)
    scene_row = QHBoxLayout()
    scene_row.setSpacing(8)
    scene_row.addWidget(lab("暮省夜景", 11, "SOFT"))
    scene_box = Combo()
    for text, key in (("每晚轮换", "auto"), ("观澜 · 潮线", "tide"), ("远山 · 月下层峦", "ridge"), ("观星 · 星图", "stars"), ("灯下 · 一盏灯", "lamp"), ("月白 · 信笺", "moon")):
        scene_box.addItem(text, key)
    scene_box.setCurrentIndex(max(0, scene_box.findData(str(ctx.cfg.get("eveningTheme", "auto")))))
    scene_box.currentIndexChanged.connect(lambda _i: (ctx.cfg.__setitem__("eveningTheme", scene_box.currentData()), ctx.save()))
    scene_row.addWidget(scene_box)
    scene_row.addWidget(lab("山形、潮线和星位每晚都不一样；选好后点「现在生成暮省」能直接看", 10.5, "FAINT"))
    scene_row.addStretch(1)
    daily.add(scene_row)
    acts = QHBoxLayout()
    acts.setSpacing(8)
    b_now = Btn("现在生成暮省")
    b_now.clicked.connect(ctx.evening)
    b_fetch = Btn("现在就抓取")
    b_fetch.clicked.connect(ctx.refresh_guanlan)
    acts.addWidget(b_now)
    acts.addWidget(b_fetch)
    acts.addStretch(1)
    daily.add(acts)
    page.add(daily)

    page.add(_deepseek_card(ctx))

    data = Card("数据与题库")
    data.add(label(f"数据目录：{store.HOME}", 11, C.SOFT, wrap=True))
    qs = store.questions()
    data.add(label(f"本地题库：{len(qs)} 题（{store.bank_years()} 高考题）。题目可视化在本机运行，不联网。",
                   11, C.SOFT, wrap=True))
    btns = QHBoxLayout()
    btns.setSpacing(8)
    open_dir = Btn("打开数据目录")
    open_dir.clicked.connect(lambda: subprocess.Popen(["explorer", str(store.HOME)]))
    rescan = Btn("重新扫描题库")
    rescan.clicked.connect(ctx.rescan_bank)

    def import_1x():
        from native.data_import import run_once
        ctx.toast(run_once(force=True) or "没有找到可导入的 1.x 记录（先运行一次 1.7，它会导出记录）")
    imp1 = Btn("从 1.x 导入记录")
    imp1.clicked.connect(import_1x)
    btns.addWidget(open_dir)
    btns.addWidget(rescan)
    btns.addWidget(imp1)
    from native.backup_ui import controls as backup_controls
    before = btns.count()
    backup_controls(ctx, btns)
    for i in range(before, btns.count()):     # 备份的两个键是学习窗口那套样式：换成主窗口的按键
        b = btns.itemAt(i).widget()
        if isinstance(b, QPushButton):
            b.setStyleSheet("")
            b.setObjectName("btn")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFont(f(12))
    btns.addStretch(1)
    data.add(btns)
    page.add(data)

    about = Card("关于")
    about.add(label(f"见微 · 高考学习舱　v{store.VERSION}", 13, C.INK, 600))
    about.add(label("一个托盘，几件每天用得上的事：观澜（每日世界线索与暮省）、时间胶囊（桌面上的一把时间尺）、"
                    "习题台（真题可视化）、实验台（四科实验与自由工作台）、析题（AI 读题、程序复算）、课件与课堂。"
                    "界面是「青瓷仪器」：墨绿窄栏、朱砂印、冷瓷面板，读数用等高的仪表数字。", 11.5, C.SOFT, wrap=True))
    page.add(about)     # 设置是一张长表单，几行都要整宽：分栏排法下也不拆右栏
    page.body.addStretch(1)
    return page
