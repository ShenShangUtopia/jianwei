"""全局的小交互修正：装一次，所有窗口都受益。

- 滚轮停在滑块、下拉框、数字框上时，如果它们没有焦点，就滚动外面的面板，不改数值。
  （检查器一滚就改了参数，是这类界面最容易中招的地方。）
- 点滑块的轨道直接跳到那个位置，可以接着拖（Qt 默认只挪一小格）。
- 双击滑块回到打开面板时的数值（控件设了 jw_default 属性才有）。
"""
from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, QPointF, Qt
from PySide6.QtWidgets import QAbstractScrollArea, QAbstractSpinBox, QApplication, QComboBox, QSlider, QStyle, QStyleOptionSlider

_installed = None


def _scroll_ancestor(w):
    p = w.parentWidget()
    while p is not None:
        if isinstance(p, QAbstractScrollArea) and p.verticalScrollBar().maximum() > 0:
            return p
        p = p.parentWidget()
    return None


def _handle_rect(sl: QSlider):
    opt = QStyleOptionSlider()
    sl.initStyleOption(opt)
    return sl.style().subControlRect(QStyle.ComplexControl.CC_Slider, opt, QStyle.SubControl.SC_SliderHandle, sl)


def jump_to(sl: QSlider, pos: QPointF) -> None:
    """把滑块移到鼠标所在位置（滑块中心对准鼠标）。"""
    handle = _handle_rect(sl)
    if sl.orientation() == Qt.Orientation.Horizontal:
        span = sl.width() - handle.width()
        at = int(pos.x() - handle.width() / 2)
    else:
        span = sl.height() - handle.height()
        at = int(pos.y() - handle.height() / 2)
    value = QStyle.sliderValueFromPosition(sl.minimum(), sl.maximum(), max(0, min(span, at)), max(1, span),
                                           sl.invertedAppearance())
    sl.setValue(value)


_TARGETS = (QSlider, QComboBox, QAbstractSpinBox)
_WHEEL = QEvent.Type.Wheel
_PRESS = QEvent.Type.MouseButtonPress
_DOUBLE = QEvent.Type.MouseButtonDblClick


class UxFilter(QObject):
    def eventFilter(self, obj, event):  # noqa: N802
        # 全应用每个事件都会经过这里（定时器、重绘、鼠标移动……）：先用最便宜的类型判断挡掉绝大多数，
        # 只有滑块 / 下拉框 / 数字框才去取事件类型（取一次要造一个枚举对象，比 isinstance 贵得多）
        if not isinstance(obj, _TARGETS):
            return False
        kind = event.type()
        if kind == _WHEEL:
            if not obj.hasFocus():
                area = _scroll_ancestor(obj)
                if area is not None:
                    # 带缓动的滚动区（主窗口各页）交给它自己的滚轮处理，别的直接转给滚动条
                    smooth = getattr(area, "SMOOTH", False)
                    QApplication.sendEvent(area.viewport() if smooth else area.verticalScrollBar(), event)
                    return True
        elif kind == _PRESS:
            if isinstance(obj, QSlider) and event.button() == Qt.MouseButton.LeftButton and obj.isEnabled():
                if not _handle_rect(obj).contains(event.position().toPoint()):
                    jump_to(obj, event.position())
        elif kind == _DOUBLE:
            if isinstance(obj, QSlider) and obj.property("jw_default") is not None:
                obj.setValue(int(obj.property("jw_default")))
                return True
        return False


def install(app=None) -> None:
    """重复调用只装一次。"""
    global _installed
    app = app or QApplication.instance()
    if app is None or _installed is not None:
        return
    _installed = UxFilter(app)
    app.installEventFilter(_installed)
