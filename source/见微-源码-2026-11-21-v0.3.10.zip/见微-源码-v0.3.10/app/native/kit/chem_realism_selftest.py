"""滴定首批：独立计量基准、真实按钮转移、容量边界和保存恢复。"""
from . import test_runtime
test_runtime.configure()

import copy
import math
import sys
from pathlib import Path


def main(output=None):
    app = test_runtime.application()
    from ..lab.benches import chem_titration as t
    from ..lab.benches.chem_model import eqm
    from ..lab.studio import Studio
    from . import state_graph
    from .ctx import Loop
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks = []

    def check(name, ok):
        assert ok, name
        checks.append(name)

    def refuses(fn):
        try:
            fn()
        except ValueError:
            return True
        return False

    check("top to bottom reading", [t.reading(v) for v in (50, 45, 10, 0)] == [0, 5, 40, 50])
    check("invalid volumes", all(refuses(lambda v=v: t.reading(v)) for v in (-1, 51, math.nan, math.inf)))
    source = dict(id=1, V=40., oil=0., solids=[], pp={}, titration_target=2)
    target = dict(id=2, V=25., oil=0.)
    check("initial reading required", refuses(lambda: t.dose(source, target, .05, 250)))
    t.begin(source, target)
    check("nonzero initial reading", source['titration_run']['initial'] == 10)
    check("self target rejected", refuses(lambda: t.begin(source, source)))
    for amount in (.05, .5, 1.):
        before = source['V']
        actual = t.dose(source, target, amount, 250)
        source['V'] -= actual
        target['V'] += actual
        t.commit(source, before)
    check("final minus initial", abs(t.reading(source['V']) - 10 - 1.55) < 1e-10)
    check("actual received volume", abs(source['titration_run']['delivered'] - 1.55) < 1e-10)
    check("capacity limit", abs(t.dose(source, dict(id=2, V=249.98), .05, 250) - .02) < 1e-10)
    check("full receiver rejected", refuses(lambda: t.dose(source, dict(id=2, V=250.), .05, 250)))
    check("target change rejected", refuses(lambda: t.dose(source, dict(id=3, V=25.), .05, 250)))
    source['V'] += 1
    check("refill invalidates measurement", refuses(lambda: t.dose(source, target, .05, 250)))
    t.begin(source, target)
    check("invalid dose", all(refuses(lambda n=n: t.dose(source, target, n, 250)) for n in (0, -1, math.nan)))
    check("two phases rejected", refuses(lambda: t.begin(dict(source, oil=1), target)))
    check("precipitate rejected", refuses(lambda: t.begin(dict(source, pp={'AgCl': {'amt': 1}}), target)))
    check("equivalence pH reference", abs(eqm(dict(Cl=2.5, Na=2.5), 50)['pH'] - 7) < .01)

    studio = Studio('day')
    studio.resize(1440, 900)
    studio.show()
    studio.open_bench('chem')
    app.processEvents()
    loop = next(timer for timer in studio.ctx.timers if isinstance(timer, Loop))
    loop.pause()
    B = studio.B
    B.pal.items['vessel-burette'].it['click']()
    B.pal.items['vessel-flask'].it['click']()
    snap = state_graph.decode(B.transfer_snapshot())
    source = next(v for v in snap['objs'] if v.get('type') == 'burette')
    target = next(v for v in snap['objs'] if v.get('type') == 'flask')
    source.update(V=40., tot={'Na': 4.}, titration_target=target['id'], dose=1., titration_training=False)
    source['e'] = eqm(source['tot'], source['V'])
    target.update(V=25., tot={'Cl': 2.5})
    target['e'] = eqm(target['tot'], target['V'])
    snap['W']['sel'] = source
    B.transfer_restore(state_graph.encode(snap))

    def press(name):
        next(c for c in studio.ctx.ctrls if c['kind'] == 'button' and c['name'] == name)['press']()

    def current():
        data = state_graph.decode(B.transfer_snapshot())
        return (next(v for v in data['objs'] if v.get('type') == 'burette'),
                next(v for v in data['objs'] if v['id'] == target['id']))

    press('滴加一次')
    check("real button blocks unrecorded dose", current()[0]['V'] == 40)
    press('记录初始读数')
    for _ in range(25):
        press('滴加一次')
    src, dst = current()
    check("real transfer volume", abs(src['V'] - 15) < 1e-9 and abs(dst['V'] - 50) < 1e-9)
    check("real transfer material", abs(src['tot']['Na'] - 1.5) < 1e-9 and abs(dst['tot']['Na'] - 2.5) < 1e-9)
    check("real receiver equivalence pH", abs(dst['e']['pH'] - 7) < .01)
    check("curve actual volume", abs(dst['titration_trace'][-1][0] - 25) < 1e-9)
    check("source reading difference", abs(t.reading(src['V']) - src['titration_run']['initial'] - 25) < 1e-9)
    saved = B.transfer_snapshot()
    B.transfer_restore(saved)
    press('滴加一次')
    src, dst = current()
    check("restored buttons mutate restored state", abs(src['V'] - 14) < 1e-9 and abs(dst['V'] - 51) < 1e-9)
    check("restored run continues", abs(src['titration_run']['delivered'] - 26) < 1e-9)
    check("past equivalence alkaline", dst['e']['pH'] > 10)
    studio.ctx.stage.repaint()
    app.processEvents()
    check("render without error", not studio.ctx.stage.error)
    for _ in range(4):
        app.processEvents()
    studio.grab().save(str(out / 'chem-titration-day.png'))
    snapshot = B.transfer_snapshot()
    night = Studio('night')
    night.resize(1000, 620)
    night.show()
    night.open_bench('chem')
    for timer in night.ctx.timers:
        if isinstance(timer, Loop):
            timer.pause()
    night.B.transfer_restore(snapshot)
    for _ in range(6):
        app.processEvents()
    night.ctx.stage.repaint()
    check("night narrow render", not night.ctx.stage.error)
    night.grab().save(str(out / 'chem-titration-night-narrow.png'))
    night.go_home()
    night.close()
    from ..design import tokens
    tokens.set_theme('day')
    studio.apply_theme()

    # 接收液已满只允许剩余容量，管内与接收液的物料仍守恒。
    data = state_graph.decode(B.transfer_snapshot())
    dst = next(v for v in data['objs'] if v['id'] == target['id'])
    dst['V'] = 249.98
    dst['e'] = eqm(dst['tot'], dst['V'])
    B.transfer_restore(state_graph.encode(data))
    before = current()[0]['V']
    press('滴加一次')
    src, dst = current()
    check("button receiver capacity", abs(dst['V'] - 250) < 1e-9 and abs(before - src['V'] - .02) < 1e-9)
    before = copy.deepcopy(src)
    press('滴加一次')
    check("full receiver no material lost", current()[0]['tot'] == before['tot'] and current()[0]['V'] == before['V'])
    press('清空')
    check("empty resets run", 'titration_run' not in current()[0])
    studio.go_home()
    studio.close()
    (out / 'chem-realism-result.txt').write_text('OK\n' + '\n'.join(checks), encoding='utf-8')
    print('CHEM_REALISM OK', len(checks), 'checks', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(test_runtime.run(main))
