"""0.3.9：别家 AI 服务商设置、JSON 模式退回、框选查找的搜索词与来源排序、结论加入复习。不联网。

python -m native.kit.ai_provider_selftest <目录>（在 src2/app 下，隔离 JIANWEI_HOME / LOCALAPPDATA）
"""
import io
import json
import os
import sys
import urllib.error
from pathlib import Path
from unittest.mock import patch

from . import test_runtime

test_runtime.configure()


def main(output=None):
    test_runtime.application()
    from ..analysis import llm
    from ..lecture import lookup
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks, failures = [], []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        (checks if ok else failures).append(name)

    env_file = llm._env_file()
    env_file.parent.mkdir(parents=True, exist_ok=True)
    saved = {k: os.environ.pop(k, None) for k in [p["key"] for p in llm.PROVIDERS.values()] + ["AI_PROVIDER", "DEEPSEEK_MODEL", "DEEPSEEK_BASE_URL"]}
    try:
        env_file.write_text("DEEPSEEK_API_KEY=sk-test-not-real\n", encoding="utf-8")
        s = llm.settings()
        check("旧版只有 DeepSeek 密钥的文件照旧可用", s["provider"] == "deepseek" and s["key"] == "sk-test-not-real" and s["base"] == "https://api.deepseek.com")
        llm.save_settings("qwen", key="qw-test-not-real", model="")
        s = llm.settings()
        check("切换到通义千问：密钥、默认模型、地址", s["provider"] == "qwen" and s["key"] == "qw-test-not-real" and s["model"] == "qwen-plus"
              and "dashscope" in s["base"] and s["name"] == "通义千问", s)
        check("DeepSeek 的密钥还留着（换回来不用重填）", llm.settings("deepseek")["key"] == "sk-test-not-real")
        check("别家不发 thinking 字段，模型名用设置里的", llm.pick_model(True) == ("qwen-plus", True) and llm.thinking_field("qwen-plus", False) == {})
        llm.save_settings("custom", key="k", model="my-model", base="https://example.invalid/v1/")
        s = llm.settings()
        check("自定义接口：地址去掉末尾斜杠", s["base"] == "https://example.invalid/v1" and s["model"] == "my-model")
        llm.save_key("")
        check("清除当前这家的密钥", not llm.settings()["key"] and llm.settings("qwen")["key"] == "qw-test-not-real")
        text = env_file.read_text(encoding="utf-8")
        check("设置文件里每家各存一份", "QWEN_API_KEY=qw-test-not-real" in text and "AI_PROVIDER=custom" in text)
        import store
        llm.save_settings("qwen")
        check("主窗口读到的也是当前服务商", store.deepseek_settings()["provider"] == "qwen")

        # JSON 模式不支持时自动退回
        calls = []

        class Resp(io.BytesIO):
            status = 200

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        def fake(req, timeout=0):
            body = json.loads(req.data.decode("utf-8"))
            calls.append(body)
            if "response_format" in body:
                raise urllib.error.HTTPError(req.full_url, 400, "bad", {}, io.BytesIO(b'{"error":"response_format json_object not supported"}'))
            data = 'data: {"choices":[{"delta":{"content":"{\\"ok\\":1}"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n'
            return Resp(data.encode("utf-8"))
        with patch("urllib.request.urlopen", fake):
            txt, trunc = llm.chat_once("sys", [dict(role="user", content="hi")], "qwen-plus")
        check("不支持 JSON 模式的服务商：去掉 response_format 重试一次", len(calls) == 2 and "response_format" not in calls[1] and txt == '{"ok":1}', calls)
        check("报错信息用服务商的名字", "通义千问" in str(_err(lambda: llm.chat_once("s", [], "", None))))
    finally:
        env_file.unlink(missing_ok=True)
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v

    # 框选查找：搜索词与来源
    q = lookup.focus_query("3．下列关于细胞呼吸的说法正确的是（  ）\nA．有氧呼吸只在线粒体中进行\nB．无氧呼吸不产生ATP")
    check("去掉题号、选项和套话，加学科", q == "高中生物 细胞呼吸", q)
    check("关于…下列说法中正确的是", lookup.focus_query("关于牛顿第一定律，下列说法中正确的是") == "高中物理 牛顿第一定律")
    check("长的不加学科词", not lookup.focus_query("把铜片放进浓硝酸中，溶液变绿并放出红棕色气体，写出离子方程式并说明原因").startswith("高中"))
    check("学科分不清时不乱加", lookup.guess_subject("今天天气不错") == "")
    check("网站类型与可信度", lookup.site_kind("https://baike.baidu.com/item/x") == ("百科", 3) and lookup.site_kind("https://zhidao.baidu.com/q")[1] == 0
          and lookup.site_kind("https://abc.edu.cn/")[0] == "教育")
    check("改写的搜索词和原来差不多就不再搜一轮", lookup._same_query("高中生物 细胞呼吸", "细胞呼吸") and not lookup._same_query("有氧呼吸的场所", "细胞呼吸"))

    # 面板：先按可信度排、结论第一行加粗、加入复习
    from ..lecture.panel import LookupPanel
    os.environ["JIANWEI_SELFTEST"] = "1"
    pn = LookupPanel(lookup.Ocr())
    pn.resize(420, 760)
    pn.show()
    pn.job = 5
    pn.t0 = 0
    pn.query = "细胞呼吸"
    items = [dict(title="细胞呼吸 问答", url="https://zhidao.baidu.com/q/1", snippet="细胞呼吸是…", source="360", kind="问答", trust=0),
             dict(title="细胞呼吸 百科", url="https://baike.baidu.com/item/细胞呼吸", snippet="细胞呼吸是指…", source="必应", kind="百科", trust=3)]
    pn._on_results(5, items, 0.3)
    order = [pn.list.itemAt(i).widget() for i in range(pn.list.count()) if pn.list.itemAt(i).widget() in pn.cards]
    check("没核查前按网站可信度排：百科在问答前面", [c.item["kind"] for c in order] == ["百科", "问答"], [c.item.get("kind") for c in order])
    src = [w.text() for c in order for w in c.findChildren(type(c.title)) if w.objectName() == "src"]
    check("每条写明网站类型", src and src[0].startswith("百科 · baike.baidu.com"), src)
    pn._set_ai("有机物在细胞内氧化分解释放能量 [2]\n· 有氧呼吸主要在线粒体 [2]")
    check("一句话结论加粗、要点分行", pn.ai_body.text().startswith("<b") and "<br>" in pn.ai_body.text())
    from .. import learning
    pn.edit.setText("细胞呼吸")
    pn._to_review()
    items_now = learning.load()["items"]
    card = next((v for v in items_now.values() if v.get("kind") == "card"), None)
    check("结论加入复习：存成知识卡，不带引用编号", card and card["title"] == "细胞呼吸" and "[2]" not in card["card"]["d"] and card["subject"] == "生物",
          card)
    check("按键变成已加入", pn.review_btn.text() == "已加入复习" and not pn.review_btn.isEnabled())
    pn.grab().save(str(out / "lookup-panel.png"))
    pn.close_panel()
    pn.close()
    (out / "ai-provider-result.txt").write_text("OK" if not failures else "FAIL\n" + "\n".join(failures), encoding="utf-8")
    print(f"AI_PROVIDER {'OK' if not failures else 'FAIL'} {len(checks)} checks", flush=True)
    return 0 if not failures else 1


def _err(fn):
    try:
        fn()
    except Exception as e:  # noqa: BLE001
        return e
    return None


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
