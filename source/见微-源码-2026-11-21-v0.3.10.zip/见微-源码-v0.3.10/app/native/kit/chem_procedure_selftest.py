"""化学操作训练：实际试剂按钮、润洗残液、气泡、连续流液与终点记录。"""
from . import test_runtime
test_runtime.configure()

import copy
import json
import sys
from pathlib import Path


def main(output=None):
    app = test_runtime.application()
    from ..lab.benches import chem_titration as t
    from ..lab.benches.chem_model import eqm
    from ..lab.studio import Studio
    from ..design import tokens
    previous_skin, previous_theme = tokens.skin(), tokens.theme()
    from . import state_graph
    from .ctx import Loop
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks = []

    def check(name, value):
        assert value, name
        checks.append(name)

    # 不排气的独立基准：读数差 .20mL，.12mL填管尖，只有.08mL真正流出。
    source = dict(id=1, V=40., oil=0., tot={'Na': 4.}, solids=[], pp={}, titration_target=2)
    receiver = dict(id=2, V=25., oil=0.)
    t.prepare(source)
    t.begin(source, receiver)
    before = source['V']
    draw = t.dose(source, receiver, .20, 250)
    source['V'] -= draw - t.TIP_CAPACITY
    received = t.commit(source, before, tip_fill=t.TIP_CAPACITY)
    check('bubble indicated volume', abs(t.source_reading(source) - 10 - .20) < 1e-10)
    check('bubble received volume', abs(received - .08) < 1e-10)
    check('source conserves tip liquid', abs(source['V'] + received - 40) < 1e-10)
    check('head and valve affect rate', t.flow_rate(source, .5) < t.flow_rate(source, 1.) and
          t.flow_rate(dict(source, V=20.), 1.) < t.flow_rate(source, 1.))

    studio = Studio('day')
    studio.resize(1440, 900)
    studio.show()
    studio.open_bench('chem')
    app.processEvents()
    B = studio.B
    loop = next(timer for timer in studio.ctx.timers if isinstance(timer, Loop))
    loop.pause()
    B.pal.items['chem-titration-training'].it['click']()
    data = state_graph.decode(B.transfer_snapshot())
    source_id = next(v['id'] for v in data['objs'] if v.get('type') == 'burette')
    receiver_id = next(v['id'] for v in data['objs'] if v.get('type') == 'flask')
    waste_id = next(v['id'] for v in data['objs'] if v.get('name') == '废液烧杯')

    def state():
        return state_graph.decode(B.transfer_snapshot())

    def object_(ident):
        return next(v for v in state()['objs'] if v['id'] == ident)

    def press(name):
        next(c for c in studio.ctx.ctrls if c['kind'] == 'button' and c['name'] == name)['press']()

    def reagent(name):
        next(item for item in B.pal.all if item.it['label'] == name).it['click']()
        loop.fn(.6)

    def restore(data, selected=source_id):
        data['W']['sel'] = next(v for v in data['objs'] if v['id'] == selected)
        B.transfer_restore(state_graph.encode(data))

    check('demo uses actual acid amount', object_(receiver_id)['tot']['Cl'] == 2.5)
    check('new burette training default', object_(source_id)['titration_training'])
    reagent('蒸馏水')
    press('旋转润洗并排液')
    src, waste = object_(source_id), object_(waste_id)
    check('water rinse leaves actual film', abs(src['V'] - .1) < 1e-10 and abs(waste['V'] - 4.9) < 1e-10)
    check('water rinse counted', src['titration_prep']['water_rinses'] == 1)
    reagent('氢氧化钠溶液')
    src = object_(source_id)
    check('water film dilutes titrant', abs(src['tot']['Na'] / src['V'] - .5/5.1) < 1e-10)
    press('旋转润洗并排液')
    for _ in range(2):
        reagent('氢氧化钠溶液')
        press('旋转润洗并排液')
    src = object_(source_id)
    check('three solution rinses', src['titration_prep']['solution_rinses'] == 3)
    check('repeated rinse reduces dilution', abs(src['tot']['Na'] / src['V'] - .1) < 1e-6)

    data = state()
    data['st']['amt'] = 20.
    restore(data)
    reagent('氢氧化钠溶液')
    reagent('氢氧化钠溶液')
    before = state()
    total_na = sum(v['tot'].get('Na', 0) for v in before['objs'])
    total_water = sum(v['V'] for v in before['objs'])
    press('排尽管尖气泡')
    src, waste = object_(source_id), object_(waste_id)
    check('purge fills tip', abs(t.tip_volume(src) - .12) < 1e-10)
    check('purge actual material conservation', abs(sum(v['tot'].get('Na', 0) for v in state()['objs']) - total_na) < 1e-9)
    check('purge actual volume conservation', abs(sum(v['V'] for v in state()['objs']) - total_water) < 1e-9)
    check('purge changes scale not just waste', abs(t.source_reading(src) - (50 - 40.1 + .05 + .12)) < 1e-8)
    press('固定到接收瓶上方')
    press('记录初始读数')
    before_v = object_(source_id)['V']
    press('打开活塞')
    check('opening valve consumes no instantaneous volume', object_(source_id)['V'] == before_v)
    studio.hide()
    loop.fn(.05)
    check('hidden experiment does not flow', object_(source_id)['V'] == before_v)
    studio.show()
    app.processEvents()
    for _ in range(10):
        loop.fn(.05)
    press('打开活塞')  # 注册名稳定，按钮文字已变为“关闭活塞”。
    src = object_(source_id)
    check('continuous valve delivers solution', src['V'] < before_v and src['titration_run']['delivered'] > .01)
    check('closed valve state', not src['titration_valve'])
    recorded = src['titration_run']
    check('purged reading equals received', abs(t.source_reading(src) - recorded['initial'] - recorded['delivered']) < 1e-8)
    saved = B.transfer_snapshot()
    data = state_graph.decode(saved)
    source = next(v for v in data['objs'] if v['id'] == source_id)
    source['titration_valve'] = True
    restore(data)
    check('restoration closes valve', not object_(source_id)['titration_valve'])
    check('restoration preserves prep and run', object_(source_id)['titration_prep'] == src['titration_prep'] and
          object_(source_id)['titration_run'] == src['titration_run'])
    data = state()
    receiver = next(v for v in data['objs'] if v['id'] == receiver_id)
    receiver['x'] += 60
    restore(data)
    before_moved = object_(source_id)['V']
    source_x = object_(source_id)['x']
    press('滴加一次')
    check('moving receiver prevents false delivery', object_(source_id)['V'] == before_moved)
    check('stand stays fixed when receiver moves', object_(source_id)['x'] == source_x)
    press('固定到接收瓶上方')
    check('remount realigns apparatus', object_(source_id)['x'] == object_(receiver_id)['x'])
    data = state()
    next(v for v in data['objs'] if v['id'] == receiver_id)['x'] -= 60
    restore(data)
    press('固定到接收瓶上方')

    # 从真实酸样品一路滴至25.02mL，保持浅红，再实际过滴；不替换样品数据。
    data = state()
    next(v for v in data['objs'] if v['id'] == source_id)['dose'] = 2.
    restore(data)
    while object_(source_id)['titration_run']['delivered'] < 23.:
        press('滴加一次')
    data = state()
    source = next(v for v in data['objs'] if v['id'] == source_id)
    source['dose'] = 25.02 - source['titration_run']['delivered']
    restore(data)
    press('滴加一次')
    receiver = object_(receiver_id)
    check('full procedure received volume', abs(receiver['V'] - 50.02) < 1e-8)
    check('full procedure endpoint pH', 9.5 < receiver['e']['pH'] < 9.7)
    for _ in range(600):
        loop.fn(.05)
    check('pink stable hold advances', object_(receiver_id)['endpoint_hold'] > 29.9)
    restore(state(), receiver_id)
    press('记录终点')
    check('endpoint record saved', len(object_(receiver_id)['titration_results']) == 1)
    restore(state())
    image_snapshot = B.transfer_snapshot()
    data = state()
    next(v for v in data['objs'] if v['id'] == source_id)['dose'] = .2
    restore(data)
    press('滴加一次')
    loop.fn(.05)
    check('actual overshoot clears pink criterion', object_(receiver_id)['endpoint_hold'] == 0 and object_(receiver_id)['e']['pH'] > 10.)

    # 实际按钮故意跳过排气，比较读数差与实收，并检查接收容量边界。
    data = state()
    source = next(v for v in data['objs'] if v['id'] == source_id)
    source['titration_prep']['tip_ml'] = 0.
    source.pop('titration_run', None)
    source['dose'] = .2
    restore(data)
    before = object_(receiver_id)['V']
    press('记录初始读数')
    press('滴加一次')
    src = object_(source_id)
    check('real buttons reproduce bubble error', abs(object_(receiver_id)['V'] - before - .08) < 1e-9)
    check('real scale error is tip capacity', abs(t.source_reading(src) - src['titration_run']['initial'] - src['titration_run']['delivered'] - .12) < 1e-9)
    data = state()
    receiver = next(v for v in data['objs'] if v['id'] == receiver_id)
    receiver['V'] = 249.98
    receiver['e'] = eqm(receiver['tot'], receiver['V'])
    restore(data)
    press('滴加一次')
    check('trained receiver capacity', abs(object_(receiver_id)['V'] - 250) < 1e-9)

    # 相同真实实验状态下做皮肤/昼夜及窄窗截图。
    for skin, theme, size in (('ink', 'day', (1440, 900)), ('ink', 'night', (1440, 900)),
                              ('celadon', 'day', (1000, 620)), ('doodle', 'night', (1000, 620))):
        tokens.set_skin(skin)
        tokens.set_theme(theme)
        studio.resize(*size)
        studio.apply_theme()
        B.transfer_restore(copy.deepcopy(image_snapshot))
        for label in list(B._toasts.labels):
            B._toasts._drop(label)
        for _ in range(8):
            app.processEvents()
        studio.chrome.set_right(True)
        for _ in range(4):
            app.processEvents()
        studio.ctx.stage.repaint()
        check(f'render {skin} {theme} {size[0]}', not studio.ctx.stage.error)
        studio.grab().save(str(out / f'procedure-{skin}-{theme}-{size[0]}.png'))
    studio.go_home()
    studio.close()
    tokens.set_skin(previous_skin)
    tokens.set_theme(previous_theme)
    (out / 'chem-procedure-result.txt').write_text('OK\n' + json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
    print('CHEM_PROCEDURE OK', len(checks), 'checks', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(test_runtime.run(main))
