"""几何画板的函数功能（0.3.9）：性质分析、切线、动点吸附、伸缩平移、存档往返、画面。

python -m native.kit.math_fn_selftest <目录>（在 src2/app 下，离屏，隔离 JIANWEI_HOME / LOCALAPPDATA）
"""
import math
import sys
import time
from pathlib import Path

from . import test_runtime

test_runtime.configure()


def main(output=None):
    app = test_runtime.application()
    from PySide6.QtCore import QEvent, QPointF, Qt
    from PySide6.QtGui import QMouseEvent
    from ..lab.benches import geo_calc as gc
    from ..lab.studio import Studio
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks, failures = [], []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        (checks if ok else failures).append(name)

    def spin(t=0.15):
        end = time.time() + t
        while time.time() < end:
            app.processEvents()

    near = lambda a, b, e=1e-4: abs(a - b) <= e

    # ---- 纯数值
    r = gc.analyze(lambda x: x ** 3 - 3 * x, -4, 4)
    check("三次函数：三个零点", [round(x, 4) for x, _ in r["zeros"]] == [-1.7321, 0.0, 1.7321], r["zeros"])
    check("三次函数：极大 (−1, 2)、极小 (1, −2)", len(r["maxima"]) == 1 and near(r["maxima"][0][0], -1) and near(r["maxima"][0][1], 2)
          and len(r["minima"]) == 1 and near(r["minima"][0][0], 1))
    check("三次函数：拐点在原点、奇函数", len(r["inflections"]) == 1 and near(r["inflections"][0][0], 0) and r["parity"] == "奇函数")
    check("三次函数：单调区间 增 减 增", [k for _a, _b, k in r["mono"]] == ["增", "减", "增"])
    r = gc.analyze(lambda x: x * x, -3, 3)
    check("x²：取样恰好落在极值点也找得到", len(r["minima"]) == 1 and near(r["minima"][0][0], 0) and len(r["zeros"]) == 1 and r["parity"] == "偶函数")
    r = gc.analyze(math.sin, -7, 7)
    check("sin：周期 2π", r["period"] is not None and near(r["period"], 2 * math.pi, 1e-6))
    r = gc.analyze(math.tan, -4, 4)
    check("tan：渐近线不算零点、极值、拐点", len(r["zeros"]) == 3 and not r["maxima"] and not r["inflections"] and len(r["breaks"]) == 2)
    check("tan：用零点间距也能判出周期 π", r["period"] is not None and near(r["period"], math.pi, 1e-6))
    r = gc.analyze(lambda x: 1 / x if x else float("nan"), -5, 5)
    check("1/x：间断处不算零点", not r["zeros"] and r["breaks"])
    y0, k = gc.tangent(lambda x: x * x, 1)
    check("切线：x² 在 1 处斜率 2", near(y0, 1) and near(k, 2, 1e-6) and gc.line_text(k, y0 - k) == "y = 2x − 1")
    g = gc.apply_tf(math.sin, dict(a=2, b=3, h=1, k=-1))
    check("伸缩平移：a·f(b(x−h))+k", near(g(2), 2 * math.sin(3 * 1) - 1))
    check("写回解析式不误改 exp 里的 x", gc.bake("exp(x)", dict(a=1, b=2, h=0, k=0)) == "exp((2*x))")
    check("写回解析式括号干净", gc.bake("x^3-3x", dict(a=1, b=1, h=2, k=1)) == "(x-2)^3-3(x-2)+1"
          and gc.bake("x^2", dict(a=-1, b=1, h=-1, k=-2)) == "-((x+1)^2)-2", gc.bake("x^3-3x", dict(a=1, b=1, h=2, k=1)))
    check("变换说明按先横后纵", gc.tf_notes(dict(a=2, b=0.5, h=1, k=0)) == ["横坐标变为原来的 2 倍", "向右平移 1 个单位", "纵坐标变为原来的 2 倍"])
    feats = dict(zeros=[(0.0, 0)], maxima=[(1.0, 1)], minima=[], inflections=[])
    check("吸附到极值点", gc.snap_x(1.08, feats, 0.1) == (1.0, "极大值点") and gc.snap_x(1.3, feats, 0.1)[1] == "")

    # ---- 画板里
    st = Studio("day")
    st.resize(1400, 860)
    st.show()
    spin(.3)
    st.open_bench("draw")
    spin(.3)
    bd = st.B.geo_board
    bd.clear_scene()
    spin()
    bd.view = {"cx": 0.0, "cy": 0.0, "scale": 60.0}
    ok = bd.add_function_from_input("x^3-3x")
    spin(.2)
    fo = next(o for o in bd.objects if o["type"] == "function")
    check("画出函数并自动选中", ok and bd.selection == [fo["id"]])
    rows = dict(bd.fn_rows(fo))
    check("右栏写出零点、极值、单调、奇偶", "x≈1.732" in rows["零点"] and "(-1, 2)" in rows["极大值"] and "增" in rows["单调"] and rows.get("奇偶") == "奇函数", rows)
    st.grab().save(str(out / "math-fn-props.png"))

    # 双击曲线作切线
    sx, sy = bd.X(0.5), bd.Y(fo["fn"](0.5))
    c = st.ctx.stage

    def mouse(kind, x, y, mods=Qt.KeyboardModifier.NoModifier):
        typ = {"down": QEvent.Type.MouseButtonPress, "move": QEvent.Type.MouseMove, "up": QEvent.Type.MouseButtonRelease, "dbl": QEvent.Type.MouseButtonDblClick}[kind]
        btn = Qt.MouseButton.NoButton if kind == "move" else Qt.MouseButton.LeftButton
        e = QMouseEvent(typ, QPointF(x, y), QPointF(x, y), btn, Qt.MouseButton.LeftButton if kind != "up" else Qt.MouseButton.NoButton, mods)
        bd.on_mouse(kind, e)
    mouse("dbl", sx, sy)
    spin()
    check("双击曲线作切线", fo.get("tan") and abs(fo["tan"]["x"] - 0.5) < 0.05, fo.get("tan"))
    # 拖切点到 x≈0.95 附近：吸附到极小值点 1
    p = bd.tangent_point(fo)
    mouse("down", bd.X(p[0]), bd.Y(p[1]))
    check("点中切点进入拖动", bd.pointer and bd.pointer.get("mode") == "slide")
    tx = 0.93
    mouse("move", bd.X(tx), bd.Y(fo["fn"](tx)))
    check("拖到极值点附近吸附过去", near(fo["tan"]["x"], 1.0, 1e-6) and fo["tan"].get("snap") == "极小值点", fo["tan"])
    st.grab().save(str(out / "math-fn-tangent.png"))
    mouse("move", bd.X(tx), bd.Y(fo["fn"](tx)), Qt.KeyboardModifier.AltModifier)
    check("按住 Alt 不吸附", near(fo["tan"]["x"], tx, 0.02) and not fo["tan"].get("snap"), fo["tan"])
    mouse("up", bd.X(tx), bd.Y(fo["fn"](tx)))
    spin()
    check("松开后保存切点、去掉吸附提示", "snap" not in fo["tan"] and bd.pointer is None)
    bd.do_undo(silent=True)
    spin()
    fo = next(o for o in bd.objects if o["type"] == "function")
    check("撤销一次回到拖动前", near(fo["tan"]["x"], 0.5, 0.05), fo.get("tan"))

    # 自动沿曲线走
    bd.start_play(fo)
    x_before = fo["tan"]["x"]
    spin(.4)
    check("切点自动沿曲线走", fo["tan"]["x"] != x_before and bd.play_id == fo["id"])
    bd.stop_play()
    check("停止", bd.play_id is None and not bd.play_timer.isActive())

    # 伸缩平移
    bd.push_history()
    fo["tf"] = dict(a=1, b=1, h=2, k=1)
    from ..lab.benches.geo_core import compose_fn
    compose_fn(fo)
    bd.refresh_all()
    spin()
    r2 = bd.fn_features(fo)
    check("平移后极大值点跟着动到 (1, 3)", r2["maxima"] and near(r2["maxima"][0][0], 1, 1e-4) and near(r2["maxima"][0][1], 3, 1e-4), r2["maxima"])
    st.grab().save(str(out / "math-fn-transform.png"))
    saved = bd.export_state()
    check("存档里有 tf、tan，没有函数对象本身", "fn" not in saved["objects"][0] and "_base" not in saved["objects"][0] and saved["objects"][0]["tf"]["h"] == 2)
    bd.load_state(saved)
    bd.refresh_all()
    fo = next(o for o in bd.objects if o["type"] == "function")
    check("读档后伸缩平移还在", near(fo["fn"](1), 3, 1e-9))
    from ..lab.benches.geo_calc import bake
    bd.set_function_expr(fo, bake(fo["expr"], fo["tf"]))
    fo["tf"] = None
    compose_fn(fo)
    check("写进解析式后图像不变", near(fo["fn"](1), 3, 1e-9) and near(fo["fn"](0), (-2) ** 3 - 3 * (-2) + 1, 1e-9), fo["expr"])
    fo["deriv"] = True
    fo["marks"] = True
    bd.selection = []
    bd.render()
    spin()
    st.grab().save(str(out / "math-fn-deriv.png"))
    check("画面没有报错", not st.ctx.stage.error)
    t0 = time.perf_counter()
    for _ in range(10):
        st.ctx.stage.repaint()
    ms = (time.perf_counter() - t0) * 100
    check("带切线、导函数、特殊点时一帧 < 40 ms（离屏）", ms < 40, f"{ms:.1f} ms")
    st.close()
    print(f"MATH_FN {'OK' if not failures else 'FAIL'} {len(checks)} checks" + ("" if not failures else " failed: " + ", ".join(failures)), flush=True)
    return 0 if not failures else 1


if __name__ == "__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
