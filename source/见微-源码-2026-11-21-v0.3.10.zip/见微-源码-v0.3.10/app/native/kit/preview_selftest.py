"""0.3.10：预习单、B 站视频入口、复习里的「看讲解视频」与「上次没记住先看视频」、课件「预习这一课」。不联网、不开浏览器。

python -m native.kit.preview_selftest <目录>（在 src2/app 下，隔离 JIANWEI_HOME / LOCALAPPDATA）
"""
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import unquote

from . import test_runtime

test_runtime.configure()


def main(output=None):
    test_runtime.application()
    from PySide6.QtCore import QUrl
    from .. import learning, preview
    from ..bank.data import bank
    from ..kit.registry import lab
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks, failures = [], []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        (checks if ok else failures).append(name)

    with test_runtime.isolated_data(out / "data"):
        bank.load()
        lab.load()
        ids = {e.id for e in lab.list}
        bad = [(s, n, x) for s, rows in preview.CHAPTERS.items() for n, cs, ls in rows
               for x in cs + ls if not (preview.card_by_name(x) if x in cs else x in ids)]
        check("章节表里的知识卡、实验都存在", not bad, bad)
        check("八科都有章节", all(preview.chapters(s) for s in preview.SUBJECTS),
              [s for s in preview.SUBJECTS if not preview.chapters(s)])

        q = preview.video_query("动量守恒定律（碰撞）", "物理")
        check("视频搜索词：高中+学科+知识点+讲解，去掉括号", q == "高中物理 动量守恒定律 讲解", q)
        check("学科已在词里时不重复", preview.video_query("高中物理 光", "物理").count("物理") == 1)
        url = preview.bili_url(q)
        check("B 站链接按播放量排序、关键词编码",
              url.startswith("https://search.bilibili.com/all?keyword=") and url.endswith("&order=click")
              and " " not in url and unquote(url.split("=")[1].split("&")[0]) == q, url)

        sh = preview.make("物理", "动量守恒定律")
        check("预习单：知识点、实验、视频", sh["cards"] == ["动量守恒与碰撞"] and sh["lab"] == "p-collide"
              and "动量守恒" in sh["video"], sh)
        check("课前小题最多三道、不重复、都在题库里",
              0 < len(sh["quiz"]) <= 3 and len(set(sh["quiz"])) == len(sh["quiz"])
              and all(x in bank.by_id for x in sh["quiz"]), sh["quiz"])
        big = preview.make("数学", "函数的概念与性质")
        check("多知识点章节：小题从各张卡轮流挑", len(big["cards"]) == 3 and len(big["quiz"]) == 3, big)
        wen = preview.make("语文", preview.chapters("语文")[0])
        check("文科：一张卡一节，没有实验不算进进度",
              not wen["lab"] and "lab" not in preview.parts(wen), preview.parts(wen))

        preview.save(sh)
        check("存下后是当前预习", preview.current()["id"] == sh["id"])
        before = len(learning.load()["events"])
        preview.tick(sh["id"], "cards")
        preview.tick(sh["id"], "cards")
        ev = learning.load()["events"]
        check("打勾只记一次学习事件", len(ev) == before + 1 and ev[-1]["kind"] == "preview"
              and ev[-1]["correct"] is None, ev[-1:])
        check("进度", preview.progress(preview.current()) == (1, 4), preview.progress(preview.current()))
        check("不认识的部分报错", _err(lambda: preview.tick(sh["id"], "nope")) is not None)
        check("note 只收三种类型", _err(lambda: learning.note("attempt", "x")) is not None)
        check("daily 仍能统计新事件", learning.daily()[-1]["count"] >= 1)

        got = preview.from_text("第三节 动量守恒定律\n系统不受外力或所受外力之和为零时，碰撞前后总动量不变。完全非弹性碰撞动能损失最大。", "动量")
        check("从课件文字认出知识点", got and got["subject"] == "物理" and "动量守恒与碰撞" in got["cards"], got)
        check("认不出时返回 None", preview.from_text("今天天气很好，我们去公园散步。") is None)

        # ---- 预习窗口
        from ..preview_ui import Preview, lecture_text, preview_lecture
        calls = []
        host = SimpleNamespace(open_lab=lambda i: calls.append(i), _no_browser=True)
        real_cur = preview.current
        preview.current = lambda: None
        try:
            e = Preview(host)
            e.set_subject("化学")
            e.render()
            check("空状态：推荐这科的章节", len(e.picks) == 4 and e.picks[0].text() == preview.chapters("化学")[0],
                  [b.text() for b in e.picks])
            e.resize(760, 520)
            e.grab().save(str(out / "preview-empty.png"))
            e.act("pick", e.picks[1].text())
            check("点推荐章节直接生成", e.sheet and e.sheet["topic"] == preview.chapters("化学")[1], e.sheet)
            e.close()
        finally:
            preview.current = real_cur
        dlg = Preview(host)
        dlg._no_browser = True
        dlg.set_subject("物理")
        dlg.chapter.setCurrentText("动量守恒定律")
        dlg.generate()
        sid = dlg.sheet["id"]
        check("当前一步是读知识点", dlg.now == "cards" and dlg.badges["cards"].current)
        from PySide6.QtWidgets import QPushButton
        pri = [b.text() for c in dlg.cards.values() for b in c.findChildren(QPushButton) if b.objectName() == "pri"]
        check("整页只有当前一步一个主键", pri == ["读完了，加入复习"], pri)
        dlg.resize(780, 720)
        dlg.grab().save(str(out / "preview-start.png"))
        dlg.act("lab", "p-collide")
        check("打开实验借主窗口的 open_lab，并打勾", calls == ["p-collide"] and "lab" in dlg.sheet["done"], calls)
        check("做完的步骤折成一行", dlg.cards["lab"].lay.count() == 1)
        dlg.act("open", "lab")
        check("「再看看」能展开", dlg.cards["lab"].lay.count() > 1)
        dlg.act("video")
        check("看视频：打开 B 站搜索并打勾", dlg.opened and "order=click" in dlg.opened[0]
              and "video" in dlg.sheet["done"], dlg.opened)
        check("看视频记一笔 video 事件", learning.load()["events"][-2]["kind"] == "video")
        dlg.act("toggle", "video")
        check("点圆圈取消打勾", "video" not in dlg.sheet["done"] and preview.progress(preview.current())[0] == 1)
        dlg.act("toggle", "video")
        check("再点圆圈打回来", "video" in dlg.sheet["done"])
        qs = list(dlg.sheet["quiz"])
        qid = qs[0]
        dlg.act("q", qid)
        from ..bank.fx import fx
        ans = fx(bank.by_id[qid].get("answer", ""))[:12]
        check("点「看答案」展开答案", ans and ans in dlg.answers[qid].text() and not dlg.answers[qid].isHidden()
              and dlg.answer_btns[qid].text() == "收起答案", ans)
        for x in qs[1:]:
            dlg.act("q", x)
        check("每道题答案都看过，小题自动打勾", "quiz" in dlg.sheet["done"])
        dlg.act("review")
        items = [v for v in learning.load()["items"].values() if v["kind"] == "card"]
        check("知识点加入复习", any(v["title"] == "动量守恒与碰撞" for v in items), items)
        check("加入复习 = 读过知识点，四步做完", preview.progress(preview.current()) == (4, 4)
              and preview.current()["id"] == sid)
        dlg.grab().save(str(out / "preview-sheet.png"))
        dlg.close()

        # ---- 复习：看视频、上次没记住先看视频
        from ..learning_ui import Daily, Review
        key, item = next((k, v) for k, v in learning.load()["items"].items() if v["kind"] == "card")
        item = dict(item, stage=0, last_review="2026-01-01")
        r = Review()
        r._no_browser = True
        r.queue = [(key, item)]
        r.index = 0
        r.render()
        check("复习：知识卡的视频搜索词", r.query == "高中物理 动量守恒与碰撞 讲解" and r.video.isEnabled(), r.query)
        check("上次没记住：提示先看视频", not r.hint.isHidden() and "视频" in r.hint.text())
        check("知识卡正面给公式填空线索", "______" in r.front.toPlainText(), r.front.toPlainText())
        check("两个自评键写出后果", "明天" in r.no.text() and "3 天后" in r.yes.text()
              and r.yes.objectName() == r.no.objectName(), (r.no.text(), r.yes.text()))
        r.resize(760, 620)
        r.grab().save(str(out / "review-card-front.png"))
        n0 = len(learning.load()["events"])
        r.watch()
        check("复习里看视频记一笔", len(learning.load()["events"]) == n0 + 1 and "B 站" in r.status.text())
        r.queue = [(key, dict(item, stage=1))]
        r.render()
        check("记住了的不提示", r.hint.isHidden())
        qitem = dict(kind="question", ref=sh["quiz"][0], title="动量守恒：弹性正碰", subject="物理", stage=-1, last_review=None)
        r.queue = [("question:x", qitem)]
        r.render()
        check("题目用第一个考点搜视频", r.query.startswith("高中物理 ") and r.query.endswith(" 讲解"), r.query)
        r.grade(True)
        check("没翻面只有翻面键", r.yes.isHidden() and r.no.isHidden() and not r.flip.isHidden())
        check("没翻面不能自评", "先查看答案" in r.status.text())
        r.reveal()
        check("翻面：答案出来，换成两个自评键", r.flipped and not r.answer.isHidden() and not r.yes.isHidden() and r.flip.isHidden())
        r.grab().save(str(out / "review-video.png"))
        r.index = 1
        r.tally = [0, 1]
        r.render()
        check("完成页：只剩「完成」主键", not r.done_btn.isHidden() and r.video.isHidden() and r.skip.isHidden()
              and r.flip.isHidden() and "记住 1" in r.front.toPlainText())
        r.grab().save(str(out / "review-done.png"))
        r.close()

        d = Daily(SimpleNamespace(cfg={}))
        check("今日卡片写出预习进度", "预习：物理 · 动量守恒定律，完成 4 / 4" in d.pre_line.text(), d.pre_line.text())
        check("预习做完后按键是「预习下一章」", d.pre.text() == "预习下一章", d.pre.text())
        check("到期数字", d.big.text().isdigit())
        check("学习记录默认收起", d.history.isHidden())
        d.resize(620, 220)
        d.grab().save(str(out / "daily-card.png"))
        d.close()

        # ---- 课件「预习这一课」：造一份带文字层的 PDF
        from PySide6.QtGui import QPageSize, QPainter, QPdfWriter, QFont
        from ..lecture import library
        f = library.folder("t-preview")
        f.mkdir(parents=True, exist_ok=True)
        w = QPdfWriter(str(f / "text.pdf"))
        w.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        p = QPainter(w)
        p.setFont(QFont("Microsoft YaHei", 14))
        p.drawText(200, 600, "第二节 光合作用 光反应 暗反应 叶绿体 卡尔文循环")
        p.end()
        txt = lecture_text("t-preview")
        check("课件取字（text.pdf）", "光合作用" in txt, txt[:60])
        import native.preview_ui as pu
        shown = []
        real = pu.Preview.exec
        pu.Preview.exec = lambda self: shown.append(self.sheet)
        try:
            got = preview_lecture(host, dict(id="t-preview", title="光合作用"))
            miss_dir = library.folder("t-empty")
            miss_dir.mkdir(parents=True, exist_ok=True)
            miss = preview_lecture(host, dict(id="t-empty", title="空"))
        finally:
            pu.Preview.exec = real
        check("预习这一课：生物 · 光合作用", got and got["subject"] == "生物" and "光合作用" in got["cards"]
              and shown and shown[0]["id"] == got["id"] and preview.current()["id"] == got["id"], got)
        check("没有文字的课件返回 None", miss is None)

    (out / "preview-result.txt").write_text("OK" if not failures else "FAIL\n" + "\n".join(failures), encoding="utf-8")
    print(f"PREVIEW {'OK' if not failures else 'FAIL'} {len(checks)} checks", flush=True)
    return 0 if not failures else 1


def _err(fn):
    try:
        fn()
    except Exception as e:  # noqa: BLE001
        return e
    return None


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
