"""生物真实性首批：制片状态、显微镜光学与调焦、渗透模型、存档，以及窗口上的合成鼠标操作与截图。

    python -m native.kit.bio_realism_selftest <输出目录>

离屏运行；这里的「鼠标」是程序发的合成事件，不是真机验收。
"""
from . import test_runtime
test_runtime.configure()

import copy
import json
import math
import sys
import time
from pathlib import Path


def main(output=None):
    app = test_runtime.application()
    from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
    from PySide6.QtGui import QMouseEvent, QWheelEvent
    from ..design import tokens
    from ..lab.benches import bio_slide as M
    from ..lab.benches.bio_model import calculate
    from ..lab.benches.bio_scope import ScopeDialog
    from ..lab.benches.bio_scope_view import render
    from ..lab.benches.bio_tissue import build
    from ..lab.studio import Studio
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks = []

    def check(name, ok):
        assert ok, name
        checks.append(name)

    def refuses(fn):
        try:
            fn()
        except M.StepError:
            return True
        return False

    def prepared(seed=5, kind="onion_inner", stain=True, method="angled"):
        r = M.fresh(seed)
        for step in (("wipe",), ("drop",), ("take", kind), ("spread",), ("cover", method)):
            M.act(r, *step)
        if stain:
            M.act(r, "irrigate", "iodine")
            M.act(r, "wick")
            M.act(r, "wick")
            M.advance(r, 240)
        return r

    def on_stage(r, objective=4):
        M.act(r, "load")
        r["scope"]["x"], r["scope"]["y"] = r["sample"]["at"]
        r["scope"]["z"] = -M.OBJECTIVES[4]["offset"]
        for m in (4, 10, 40)[:(4, 10, 40).index(objective) + 1]:
            M.set_objective(r, m)
            M.focus_by(r, -M.OBJECTIVES[m]["offset"] - r["scope"]["z"])
        return r

    def stats(img):
        """(平均亮度, 平均蓝/红比, 相邻像素差的平均) —— 只看视野中间一块。"""
        n = img.width()
        raw = bytes(img.constBits())
        line = img.bytesPerLine()
        lum = blue = red = edge = count = 0
        for y in range(n // 4, n * 3 // 4, 2):
            prev = None
            for x in range(n // 4, n * 3 // 4):
                i = y * line + x * 4
                b, g, r = raw[i], raw[i + 1], raw[i + 2]
                v = (r * 3 + g * 6 + b) / 10
                lum += v
                blue += b
                red += r
                if prev is not None:
                    edge += abs(v - prev)
                prev = v
                count += 1
        return lum / count, blue / max(1, red), edge / count

    # ---------------------------------------------------------- 光学
    scope = M.fresh_scope()
    scope["aperture"] = 5
    fields, res = {}, {}
    for m in (4, 10, 40):
        scope["objective"] = m
        o = M.optics(scope)
        fields[m], res[m] = o["field"], o["resolution"]
    check("field = field number / objective", [round(fields[m]) for m in (4, 10, 40)] == [4500, 1800, 450])
    check("resolution 0.61 lambda / NA at full aperture", all(abs(res[m] - 0.61 * 0.55 / M.OBJECTIVES[m]["na"]) < 1e-9 for m in (4, 10, 40)))
    scope["objective"], scope["aperture"] = 40, 5
    bright40 = M.optics(scope)["brightness"]
    scope["objective"] = 10
    check("brightness ~ (NA/M)^2", abs(bright40 / M.optics(scope)["brightness"] - (0.65 / 40) ** 2 / (0.25 / 10) ** 2) < 1e-9)
    scope["aperture"] = 2
    check("small aperture: dimmer and coarser", M.optics(scope)["brightness"] < 0.3 and M.optics(scope)["resolution"] > res[10])
    scope.update(objective=40, eyepiece=16, aperture=5)
    o = M.optics(scope)
    check("magnification separate from resolution", o["total"] == 640 and abs(o["resolution"] - res[40]) < 1e-9 and o["field"] < fields[40])
    scope.update(objective=4, eyepiece=5)
    check("total = objective x eyepiece", M.optics(scope)["total"] == 20 and round(M.optics(scope)["field"]) == 5000)
    check("scale bar shorter than field", all(M.scale_bar(f) <= f / 4 for f in (5000, 4500, 1800, 450, 275)))

    # ---------------------------------------------------------- 制片：前提
    r = M.fresh(3)
    check("spread needs material", refuses(lambda: M.act(r, "spread")))
    check("wick needs cover", refuses(lambda: M.act(r, "wick")))
    M.act(r, "take", "onion_inner")
    check("spread needs liquid", refuses(lambda: M.act(r, "spread")))
    check("no second material", refuses(lambda: M.act(r, "take", "onion_outer")))
    check("wipe too late", refuses(lambda: M.act(r, "wipe")))
    M.act(r, "drop")
    M.act(r, "spread")
    check("no second spread", refuses(lambda: M.act(r, "spread")))
    M.act(r, "cover", "angled")
    check("no second cover", refuses(lambda: M.act(r, "cover", "flat")))
    check("no material after cover", refuses(lambda: M.act(r, "take", "onion_inner")))
    M.act(r, "irrigate", "iodine")
    M.act(r, "wick")
    check("finish one liquid before the next", refuses(lambda: M.act(r, "irrigate", "sucrose03")))
    M.act(r, "wick")
    M.act(r, "load")
    check("no prep on the stage", all(refuses(lambda a=a: M.act(r, *a)) for a in (("wipe",), ("spread",), ("cover", "flat"), ("take", "onion_inner"))))
    check("irrigate on the stage is allowed", bool(M.act(r, "irrigate", "water")))
    check("no double load", refuses(lambda: M.act(r, "load")))
    r = M.fresh(3)
    for step in (("drop",), ("drop",), ("drop",)):
        M.act(r, *step)
    check("overflow refused", refuses(lambda: M.act(r, "drop")))
    M.act(r, "cover", "angled")
    check("excess liquid blocks loading", refuses(lambda: M.act(r, "load")))
    for _ in range(3):
        M.act(r, "wick")
    check("wicking removes the excess", r["sample"]["fill"] <= 1.3 and bool(M.act(r, "load")))
    failed = copy.deepcopy(r)
    check("refused step leaves state unchanged", refuses(lambda: M.act(r, "cover", "flat")) and r == failed)

    # ---------------------------------------------------------- 制片：状态影响结果
    good = prepared()
    check("textbook order: no issues", M.issues(good["sample"]) == [] and all(s == "done" for _n, s, _t in M.checklist(good["sample"])))
    flat = prepared(method="flat", stain=False)
    check("flat cover traps bubbles", len(flat["sample"]["bubbles"]) >= 5 and len(prepared(stain=False)["sample"]["bubbles"]) <= 1)
    check("bubbles reported", any("气泡" in line for line in M.issues(flat["sample"])))
    dry = M.fresh(5)
    M.act(dry, "take", "onion_inner")
    M.act(dry, "cover", "angled")
    check("dry mount", dry["sample"]["bath"] == [None] * M.STRIPS and len(dry["sample"]["bubbles"]) >= 9 and any("干" in line for line in M.issues(dry["sample"])))
    M.act(dry, "irrigate", "water")
    M.act(dry, "wick")
    M.act(dry, "wick")
    check("irrigating rescues a dry mount", all(b == "water" for b in dry["sample"]["bath"]))
    thick = prepared(kind="onion_chunk", stain=False)
    check("thick material reported", any("太厚" in line for line in M.issues(thick["sample"])))
    rough = M.fresh(5)
    for step in (("drop",), ("take", "onion_inner"), ("cover", "angled")):
        M.act(rough, *step)
    found = M.issues(rough["sample"])
    check("unspread, unwiped, unstained reported", any("展平" in line for line in found) and any("灰尘" in line for line in found) and any("染色" in line for line in found))
    over = prepared(stain=False)
    for _ in range(2):
        M.act(over, "wick")
    check("over-wicking lets air in", len(over["sample"]["bubbles"]) >= 2 and over["sample"]["fill"] < 0.75)
    check("same seed, same slide", prepared(method="flat") == prepared(method="flat") and build("onion_inner", 5).count == build("onion_inner", 5).count > 400)
    check("another seed, another slide", prepared(seed=6, method="flat")["sample"]["bubbles"] != prepared(seed=5, method="flat")["sample"]["bubbles"])

    # ---------------------------------------------------------- 染色与引流
    r = prepared(stain=False)
    M.act(r, "irrigate", "iodine")
    M.advance(r, 60)
    s = r["sample"]
    check("without wicking the stain only creeps in", s["bath"][0] == "iodine" and s["bath"][-1] == "water" and M.stain_at(s, M.STRIPS - 1) == 0)
    M.act(r, "wick")
    check("one wick: about half way", s["bath"][5] == "iodine" and s["bath"][8] == "water" and s["edge"] is not None)
    M.act(r, "wick")
    check("two wicks: across", all(b == "iodine" for b in s["bath"]) and s["edge"] is None)
    M.advance(r, 20)
    early = M.stain_at(s, M.STRIPS - 1)
    M.advance(r, 220)
    check("staining deepens with time", 0.2 < early < 0.5 and M.stain_at(s, M.STRIPS - 1) > 0.95 and M.stain_at(s, 0) > M.stain_at(s, M.STRIPS - 1))
    check("clock stops when nothing changes", M.active(prepared(stain=False)) is False and M.active(r) is False)
    r2 = prepared(stain=False)
    M.act(r2, "irrigate", "iodine")
    check("clock runs while staining", M.active(r2))
    check("bad time steps refused", all(refuses(lambda d=d: M.advance(r2, d)) for d in (-1, math.nan, math.inf, 1e9)))
    direct = M.fresh(5)
    M.act(direct, "drop", "iodine")
    check("direct staining before the cover", all(b == "iodine" for b in direct["sample"]["bath"]))

    # ---------------------------------------------------------- 调焦与倍数边界
    r = prepared()
    M.act(r, "load")
    m = r["scope"]
    check("slide starts off centre", (m["x"], m["y"]) != tuple(r["sample"]["at"]) and m["z"] == -9000)
    blur_far = M.focus_state(m)["blur"]
    M.focus_by(r, 8000)
    blur_near = M.focus_state(m)["blur"]
    M.focus_by(r, 1000)
    check("coarse focus brings the image in", blur_far > blur_near > 0 and M.focus_state(m)["sharp"])
    M.set_objective(r, 10)
    check("parfocal but not exactly: 10x needs the fine knob", not M.focus_state(m)["sharp"] and M.focus_state(m)["blur"] < 2)
    M.focus_by(r, -6)
    check("10x sharp after fine focus", M.focus_state(m)["sharp"])
    M.set_objective(r, 40)
    check("40x soft after switching", not M.focus_state(m)["sharp"])
    M.focus_by(r, 15)
    check("40x sharp after fine focus", M.focus_state(m)["sharp"] and abs(M.focus_state(m)["clearance"] - 650) < 1e-6)
    M.focus_by(r, 0.5)
    check("40x depth of field is one micrometre", M.focus_state(m)["sharp"] and not M.focus_state(dict(m, z=m["z"] + 0.5))["sharp"])
    before = copy.deepcopy(r["sample"])
    check("fine knob near contact does not break glass", M.focus_by(r, 640) == "" and r["sample"] == before)
    check("coarse knob at 40x cracks the cover", M.focus_by(r, 300) == "crash" and r["sample"]["crack"] is not None and abs(M.focus_state(m)["clearance"]) < 1e-6)
    check("crack is reported", any("压裂" in line for line in M.issues(r["sample"])))
    M.set_objective(r, 10)
    M.focus_by(r, 3000)
    check("40x refuses to swing in when it would hit", refuses(lambda: M.set_objective(r, 40)) and m["objective"] == 10)
    check("stage travel limit", M.focus_by(r, 1e6) == "limit" and m["z"] == min(M.STAGE_MAX, 6100 - 6))
    M.set_objective(r, 4)
    check("lower travel limit", M.focus_by(r, -1e6) == "limit" and m["z"] == M.STAGE_MIN)
    bare = M.fresh(5)
    for step in (("wipe",), ("drop",), ("take", "onion_inner"), ("spread",)):
        M.act(bare, *step)
    M.act(bare, "load")
    check("no cover: no high power", refuses(lambda: M.set_objective(bare, 40)) and M.set_objective(bare, 10) != "")
    r = on_stage(prepared())
    x0 = r["scope"]["x"]
    M.move_by(r, 100, 0)
    check("pushing the slide right moves the axis left on the slide", r["scope"]["x"] == x0 - 100)
    M.move_by(r, 1e9, 1e9)
    check("slide travel limit", r["scope"]["x"] == -M.TRAVEL_X and r["scope"]["y"] == -M.TRAVEL_Y)
    check("bad moves refused", refuses(lambda: M.move_by(r, math.nan, 0)) and refuses(lambda: M.focus_by(r, math.inf)))

    # ---------------------------------------------------------- 渗透
    check("van't Hoff reference", abs(M.LIQUIDS["sucrose03"]["pi"] - 300 / 342.3 * 8.314 * 298.15 / 1000) < 1e-9 and 2.1 < M.LIQUIDS["sucrose03"]["pi"] < 2.2)
    check("water equilibrium at full turgor", abs(M.equilibrium(0) - M.V_WATER) < 1e-3 and abs(M.equilibrium(M.PI0) - 1) < 1e-9)
    check("turgor in water matches the source value", abs(M.EPS * (M.equilibrium(0) - 1) - 0.54) < 0.01)
    r = prepared(kind="onion_outer", stain=False)
    s = r["sample"]
    check("no plasmolysis in water", M.plasmolysed(s) == 0 and not M.active(r))
    M.act(r, "irrigate", "sucrose03")
    M.act(r, "wick")
    M.act(r, "wick")
    M.advance(r, 30)
    v30 = s["vol"][3]
    M.advance(r, 570)
    target = M.equilibrium(M.LIQUIDS["sucrose03"]["pi"])
    check("plasmolysis progresses to the osmotic equilibrium", 0.6 < v30 < 1.0 and abs(s["vol"][3] - target) < 0.01 and M.plasmolysed(s) == 1 and max(s["damage"]) < 1)
    M.act(r, "irrigate", "water")
    M.act(r, "wick")
    check("recovery follows the water front", s["bath"][0] == "water" and s["bath"][-1] == "sucrose03")
    M.act(r, "wick")
    M.advance(r, 600)
    check("deplasmolysis in water", min(s["vol"]) > 1.03 and M.plasmolysed(s) == 0 and max(s["damage"]) < 1)
    check("treatment history is kept", any("蔗糖" in text for _t, text in s["log"]) and s["clock"] > 1000)
    r = prepared(kind="onion_outer", stain=False)
    s = r["sample"]
    M.act(r, "irrigate", "sucrose05")
    M.act(r, "wick")
    M.act(r, "wick")
    M.advance(r, 900)
    check("0.5 g/mL kills", min(s["damage"]) >= 1)
    M.act(r, "irrigate", "water")
    M.act(r, "wick")
    M.act(r, "wick")
    M.advance(r, 900)
    check("dead cells do not recover", max(s["vol"]) < 0.5 and M.plasmolysed(s) == 1)
    r = prepared(kind="onion_outer", stain=False)
    M.act(r, "irrigate", "sucrose03")
    M.act(r, "wick")
    M.act(r, "wick")
    M.advance(r, 3600)
    M.advance(r, 1200)
    check("too long in sucrose also kills", min(r["sample"]["damage"]) >= 1)
    chunk = prepared(kind="onion_chunk", stain=False)
    M.act(chunk, "irrigate", "sucrose03")
    M.act(chunk, "wick")
    M.act(chunk, "wick")
    M.advance(chunk, 300)
    check("osmosis only modelled for the epidermis peels", chunk["sample"]["vol"] == [M.V_WATER] * M.STRIPS)

    # ---------------------------------------------------------- 存档
    r = on_stage(prepared(method="flat"), 10)
    saved = json.loads(json.dumps(r, ensure_ascii=False))
    check("record survives JSON", saved == r and M.valid(saved))
    for name, edit in (("version", lambda d: d.update(v=2)), ("bath length", lambda d: d["sample"]["bath"].pop()),
                       ("NaN focus", lambda d: d["scope"].update(z=math.nan)), ("unknown liquid", lambda d: d["sample"]["bath"].__setitem__(0, "acid")),
                       ("bubble shape", lambda d: d["sample"]["bubbles"].append([0, 0])), ("missing key", lambda d: d["sample"].pop("dye")),
                       ("objective", lambda d: d["scope"].update(objective=100))):
        broken = copy.deepcopy(saved)
        edit(broken)
        check("invalid record rejected: " + name, not M.valid(broken))
    check("old microscope card unchanged", calculate("microscope", dict(magnification=100))["rows"] == [["总放大倍数", "100 ×"], ["视野直径", "1.8 mm"]])
    rows = calculate("microscope", dict(slide=saved))["rows"]
    check("card reads the new record", rows[0] == ["总放大倍数", "100 ×"] and rows[1] == ["视野直径", "1.8 mm"])
    check("card survives a broken record", calculate("microscope", dict(slide=dict(v=9)))["rows"][2][1].startswith("损坏"))

    # ---------------------------------------------------------- 画面（由状态决定）
    def view(r, objective, **scope_edits):
        r = on_stage(copy.deepcopy(r), objective)
        r["scope"].update(scope_edits)
        return r
    stained, plain = prepared(), prepared(stain=False)
    timing = {}
    for objective in (4, 10, 40):
        r = view(stained, objective, aperture=5)
        t0 = time.perf_counter()
        img = render(r, 520)
        timing[objective] = (time.perf_counter() - t0) * 1000
        img.save(str(out / f"view-stained-{objective}x.png"))
        render(view(plain, objective, aperture=5), 520).save(str(out / f"view-unstained-{objective}x.png"))
    check("render time within budget (ms): " + ", ".join(f"{k}x {v:.0f}" for k, v in timing.items()), max(timing.values()) < 1500)
    sharp = stats(render(view(stained, 10), 360))
    soft = stats(render(view(stained, 10, z=-6 + 120), 360))
    check("defocus lowers detail", sharp[2] > soft[2] * 1.8)
    check("iodine turns the field yellow", sharp[1] < 0.8 < stats(render(view(plain, 10), 360))[1])
    dim = stats(render(view(stained, 40, aperture=3), 360))
    lit = stats(render(view(stained, 40, aperture=5), 360))
    check("40x is dark until the aperture is opened", dim[0] < lit[0] * 0.75)
    check("small aperture raises contrast of unstained cells", stats(render(view(plain, 10, aperture=2), 360))[2] / stats(render(view(plain, 10, aperture=2), 360))[0]
          > stats(render(view(plain, 10, aperture=3), 360))[2] / stats(render(view(plain, 10, aperture=3), 360))[0])
    empty = M.fresh(5)
    M.act(empty, "wipe")
    M.act(empty, "load")
    check("clean empty slide is an even bright field", stats(render(empty, 360))[2] < sharp[2] * 0.6)
    one = prepared(stain=False)
    one["sample"]["bubbles"] = [[one["sample"]["at"][0] + 500, one["sample"]["at"][1], 250.0]]
    one = view(one, 4)
    img = render(one, 360)
    raw, line = bytes(img.constBits()), img.bytesPerLine()
    left = sum(1 for x in range(100, 180) if raw[180 * line + x * 4 + 1] < 70)       # 气泡的黑边
    right = sum(1 for x in range(180, 260) if raw[180 * line + x * 4 + 1] < 70)
    check("image is inverted: a bubble on the slide's right shows on the left", left >= 2 and right == 0)
    for name, r in (("bubbles-4x", view(flat, 4)), ("dry-4x", view(dry if False else _dry(M), 4)), ("thick-10x", view(thick, 10)),
                    ("fold-dust-10x", view(rough, 10)), ("defocus-10x", view(stained, 10, z=-6 + 120)), ("dim-40x", view(stained, 40, aperture=3))):
        render(r, 520).save(str(out / f"view-{name}.png"))
    osmo = prepared(kind="onion_outer", stain=False)
    render(view(osmo, 10), 520).save(str(out / "view-purple-water-10x.png"))
    M.act(osmo, "irrigate", "sucrose03")
    M.act(osmo, "wick")
    M.act(osmo, "wick")
    M.advance(osmo, 240)
    render(view(osmo, 10), 520).save(str(out / "view-purple-sucrose-10x.png"))
    render(view(osmo, 40, aperture=5), 520).save(str(out / "view-purple-sucrose-40x.png"))

    # ---------------------------------------------------------- 窗口：合成事件
    def mouse(widget, kind, point, button=Qt.MouseButton.LeftButton):
        buttons = Qt.MouseButton.LeftButton if kind != QEvent.Type.MouseButtonRelease else Qt.MouseButton.NoButton
        app.sendEvent(widget, QMouseEvent(kind, point, widget.mapToGlobal(point.toPoint()), button, buttons, Qt.KeyboardModifier.NoModifier))

    def drag(widget, a, b):
        mouse(widget, QEvent.Type.MouseButtonPress, a)
        mouse(widget, QEvent.Type.MouseMove, b, Qt.MouseButton.NoButton)
        mouse(widget, QEvent.Type.MouseButtonRelease, b)

    def wheel(widget, notches, ctrl=False):
        pos = QPointF(widget.width() / 2, widget.height() / 2)
        mods = Qt.KeyboardModifier.ControlModifier if ctrl else Qt.KeyboardModifier.NoModifier
        app.sendEvent(widget, QWheelEvent(pos, QPointF(widget.mapToGlobal(pos.toPoint())), QPoint(0, 0), QPoint(0, int(notches * 120)),
                                         Qt.MouseButton.NoButton, mods, Qt.ScrollPhase.NoScrollPhase, False))

    def pick(seg, key):
        x = seg.PAD
        for (k, _t), w in zip(seg.items, seg._w):
            if k == key:
                mouse(seg, QEvent.Type.MouseButtonPress, QPointF(x + w / 2, seg.height() / 2))
                return
            x += w
        raise AssertionError(key)

    def menu(dialog, tool, index):
        dialog.tools[tool].menu().actions()[index].trigger()

    remembered = []
    params = dict(magnification=100, custom="keep")
    dialog = ScopeDialog(params, lambda: remembered.append(1))
    dialog.show()
    app.processEvents()
    check("window opens with a fresh record", M.valid(params["slide"]) and params["custom"] == "keep" and not dialog.timer.isActive())
    dialog.grab().save(str(out / "window-empty-day.png"))
    dialog.tools["spread"].click()
    check("refused step is explained, state untouched", "材料" in dialog.message.text() and params["slide"]["sample"]["specimen"] is None)
    dialog.tools["wipe"].click()
    dialog.tools["drop"].click()
    menu(dialog, "take", 0)
    dialog.tools["spread"].click()
    menu(dialog, "cover", 0)
    s = params["slide"]["sample"]
    check("buttons prepare the slide", s["slide_clean"] and s["water"] == 1 and s["specimen"] == "onion_inner" and s["spread"] and s["cover"] == "angled")
    menu(dialog, "irrigate", 0)
    check("timer runs while the stain creeps in", s["edge"]["liquid"] == "iodine" and dialog.timer.isActive())
    dialog.tools["wick"].click()
    dialog.tools["wick"].click()
    for _ in range(300):
        dialog._tick()
    check("timer ticks stain the tissue and then stop", M.stain_at(s, M.STRIPS - 1) > 0.95 and not dialog.timer.isActive())
    dialog.grab().save(str(out / "window-prepared-day.png"))
    dialog.load_btn.click()
    m = params["slide"]["scope"]
    check("load button", m["loaded"] and dialog.load_btn.text() == "取下装片" and not dialog.tools["wipe"].isEnabled())
    z0 = m["z"]
    drag(dialog.coarse, QPointF(50, 80), QPointF(50, 0))
    check("dragging the coarse knob up raises the stage", m["z"] == z0 + 80 * 25)
    M.focus_by(params["slide"], -m["z"] - 100)
    wheel(dialog.eye, 1, ctrl=True)
    check("ctrl + wheel is the coarse knob", m["z"] == 0)
    wheel(dialog.eye, 3)
    wheel(dialog.fine, -3)
    check("wheel is the fine knob", m["z"] == 0)
    x0, y0, renders = m["x"], m["y"], dialog.eye.renders
    c = QPointF(dialog.bench.width() / 2, dialog.bench.height() / 2)
    drag(dialog.bench, c, QPointF(c.x() + 20, c.y() - 10))
    app.processEvents()
    dialog.eye.repaint()
    check("dragging the slide on the stage moves the view", m["x"] < x0 and m["y"] > y0 and dialog.eye.renders > renders)
    m["x"], m["y"] = s["at"]
    pick(dialog.obj_seg, "10")
    check("objective switch", m["objective"] == 10 and "10×" in dialog.info.text() and "1.8 mm" in dialog.info.text())
    wheel(dialog.fine, -12)
    dialog.refresh()
    dialog.grab().save(str(out / "window-10x-day.png"))
    pick(dialog.obj_seg, "40")
    pick(dialog.ap_seg, "5")
    pick(dialog.mirror_seg, "concave")
    wheel(dialog.fine, 30)
    check("40x in focus through the window", m["objective"] == 40 and m["aperture"] == 5 and m["mirror"] == "concave" and M.focus_state(m)["sharp"])
    dialog.refresh()
    dialog.grab().save(str(out / "window-40x-day.png"))
    wheel(dialog.eye, 4, ctrl=True)
    wheel(dialog.eye, 4, ctrl=True)
    check("coarse wheel at 40x cracks the cover and says so", s["crack"] is not None and "压裂" in dialog.message.text())
    pick(dialog.obj_seg, "10")
    drag(dialog.coarse, QPointF(50, 0), QPointF(50, 100))
    pick(dialog.eye_seg, "16")
    check("eyepiece switch", m["eyepiece"] == 16 and "160×" in dialog.info.text())
    dialog.resize(1020, 640)
    app.processEvents()
    dialog.grab().save(str(out / "window-min-cracked-day.png"))
    check("minimum window keeps the eyepiece usable", dialog.eye.side() >= 300 and dialog.width() == 1020 and dialog.eye.geometry().right() < dialog.side.geometry().left())
    dialog.hide()
    check("hidden window stops its timer", not dialog.timer.isActive())
    check("undo snapshots only for discrete steps", 12 <= len(remembered) <= 30)
    dialog.close()
    broken = dict(slide=dict(v=99, keep="me"))
    try:
        ScopeDialog(broken, lambda: None)
    except ValueError:
        pass
    else:
        raise AssertionError("broken record overwritten")
    check("broken record is not overwritten", broken == dict(slide=dict(v=99, keep="me")))

    tokens.set_theme("night")
    night = dict(slide=view(osmo, 10))
    dialog = ScopeDialog(night, lambda: None)
    dialog.show()
    app.processEvents()
    check("plasmolysed slide keeps the clock running while shown", dialog.timer.isActive())
    dialog.grab().save(str(out / "window-plasmolysis-night.png"))
    dialog.resize(1020, 640)
    app.processEvents()
    dialog.grab().save(str(out / "window-min-night.png"))
    dialog.close()
    tokens.set_theme("day")

    # ---------------------------------------------------------- 酶：具体的酶、不可逆失活、底物
    from ..lab.benches import bio_division as D, bio_enzyme as E, bio_photo as P
    from ..lab.benches.cell_detail import fresh as tokens_for

    def bad(fn):
        try:
            fn()
        except ValueError:
            return True
        return False

    base = E.fresh("amylase")
    m = E.measure(base)
    check("fresh enzyme at 37 C and its optimum pH is about 1", 0.9 < m["mean"] <= 1 and m["before"] == 1 and 0.9 < m["after"] < 1)
    best = {k: E.apparent_optimum(E.fresh(k)) for k in E.ENZYMES}
    check("apparent optimum of a 10 min assay matches the textbook ranges", all(36 <= best[k] <= 42 for k in ("amylase", "pepsin", "trypsin", "catalase")) and 45 <= best["malt"] <= 52)
    check("a longer assay lowers the apparent optimum", E.apparent_optimum({**base, "minutes": 60}) < best["amylase"] < E.apparent_optimum({**base, "minutes": 1}))
    instant = E.curve({**base, "minutes": 0})
    check("at zero time there is no optimum: rate only rises", all(b > a for a, b in zip(instant, instant[1:])))
    boiled = E.measure({**base, "pre_T": 80, "pre_min": 5})
    check("80 C pretreatment is not undone by going back to 37 C", boiled["before"] < 1e-9 and boiled["mean"] < 1e-9 and boiled["left"] > 0.999999)
    iced = E.measure({**base, "pre_T": 0, "pre_min": 30})
    check("0 C pretreatment leaves the enzyme intact", iced["before"] > 0.9999 and abs(iced["mean"] - m["mean"]) < 1e-4)
    cold = E.measure({**base, "temperature": 0})
    check("at 0 C the reaction is slow but the enzyme survives", cold["mean"] < 0.1 and cold["after"] > 0.9999 and cold["left"] > m["left"])
    check("pepsin pH curve fits the manual: ~90% at 1.5, ~35% at 4.5", abs(E.ph_factor("pepsin", 1.5) - 0.9) < 0.05 and abs(E.ph_factor("pepsin", 4.5) - 0.35) < 0.05)
    pepsin = E.fresh("pepsin")
    check("pepsin kept at pH 8 does not come back at pH 2", E.measure({**pepsin, "pre_T": 37, "pre_pH": 8, "pre_min": 5})["mean"] < 0.01 < E.measure({**pepsin, "pre_T": 37, "pre_pH": 5, "pre_min": 5})["mean"])
    check("pepsin does nothing at pH 7", E.measure({**pepsin, "pH": 7})["mean"] < 0.01)
    ranges = dict(amylase=(6.7, 7.0), pepsin=(1.0, 4.0), trypsin=(7.8, 8.7), catalase=(7.0, 7.0), malt=(4.6, 5.2))
    check("optimum pH inside the checked ranges", all(lo - 1e-9 <= E.optimum_ph(k) <= hi + 1e-9 for k, (lo, hi) in ranges.items()))
    check("enzymes differ: amylase is dead in the stomach, pepsin in the mouth", E.ph_factor("amylase", 2) < 0.01 and E.ph_factor("pepsin", 6.8) < 0.01)
    half = E.measure({**base, "substrate": 1})["initial"]
    full = E.measure({**base, "substrate": 50})["initial"]
    check("Michaelis-Menten: half the saturated rate at Km", abs(half / (full * 51 / 50) - 0.5) < 1e-9)
    check("initial rate proportional to enzyme amount", abs(E.measure({**base, "dose": 2})["initial"] / m["initial"] - 2) < 1e-9)
    lefts = [E.measure({**base, "minutes": t})["left"] for t in (1, 5, 10, 30, 60)]
    check("substrate only goes down with time and never below zero", all(a > b >= 0 for a, b in zip(lefts, lefts[1:])) and lefts[0] < 1)
    s0, used = 5.0, E.VMAX * m["mean"] * 10
    s1 = m["left"] * s0
    check("integrated rate law holds", abs(s1 + math.log(s1) - (s0 + math.log(s0) - used)) < 1e-9 and abs(m["used"] - (s0 - s1)) < 1e-12)
    check("saturated enzyme: substrate drop tracks enzyme-minutes", E.measure({**base, "substrate": 50, "dose": 0.5})["used"] < E.measure({**base, "substrate": 50})["used"])
    check("bad enzyme records are refused", all(bad(lambda q=q: E.measure(q)) for q in (dict(enzyme="x"), {**base, "pH": math.nan}, {**base, "temperature": 500}, {**base, "dose": "1"}, {**base, "minutes": True})))
    legacy_enzyme = calculate("enzyme", dict(temperature=37, pH=7))
    check("old enzyme card unchanged", legacy_enzyme["rows"] == [["相对活性", "1.0000"]] and len(legacy_enzyme["values"]) == 81 and "mark" not in legacy_enzyme)
    shown = calculate("enzyme", {**base, "pre_T": 80, "pre_min": 5})
    check("enzyme readout: activity first, pretreatment and optimum reported", float(shown["rows"][0][1]) == 0 and any("预处理" in a for a, _ in shown["rows"]) and "全部失活" in shown["rows"][-1][1] and len(shown["values"]) == 101)
    check("enzyme readout without pretreatment hides that row", not any("预处理" in a for a, _ in calculate("enzyme", base)["rows"]) and f"约 {best['amylase']} ℃" == calculate("enzyme", base)["rows"][-1][1])
    check("broken enzyme record reads as broken", calculate("enzyme", dict(enzyme="x"))["rows"][0][1] == "—")

    # ---------------------------------------------------------- 光合与呼吸：分开算
    for light, co2 in ((0, 0.04), (500, 0.04), (2000, 0.1), (130, 0.01)):
        q = P.measure(dict(light=light, co2=co2, temperature=25))
        check(f"25 C equals the old model at light {light}", abs(q["gross"] - 20 * light / (light + 200) * co2 / (co2 + 0.02)) < 1e-12 and abs(q["respiration"] - 2) < 1e-12 and abs(q["net"] - (q["gross"] - 2)) < 1e-12)
    dark = P.measure(dict(light=0, co2=0.04, temperature=30))
    check("in the dark only respiration is measured", dark["gross"] == 0 and dark["net"] == -dark["respiration"] < 0)
    check("respiration ignores light and CO2", P.measure(dict(light=2000, co2=0.1, temperature=30))["respiration"] == dark["respiration"])
    check("respiration doubles per 10 C", abs(P.respiration(35) / P.respiration(25) - 2) < 0.02 and abs(P.respiration(15) / P.respiration(25) - 0.5) < 1e-3)
    point = P.compensation(0.04, 25)
    check("compensation point: gross equals respiration", abs(P.gross(point, 0.04, 25) - P.respiration(25)) < 1e-9 and abs(P.measure(dict(light=point, co2=0.04, temperature=25))["net"]) < 1e-9)
    check("warmer leaf needs more light to break even", P.compensation(0.04, 35) > point and P.compensation(0.04, 45) is None)
    day = dict(light=500, co2=0.04, temperature=25)
    q = P.measure({**day, "day": 12})
    check("daily balance = gross x light hours - respiration x 24", abs(q["daily"] - (q["gross"] * 12 - q["respiration"] * 24)) < 1e-12 and P.measure({**day, "day": 0})["daily"] == -48 and P.measure(day)["daily"] == q["daily"])
    check("hot nights cost more than they earn", P.measure({**day, "temperature": 40, "day": 12})["daily"] < 0 < q["daily"])
    check("light curve passes through the current reading", abs(P.curve(day)[20] - q["net"]) < 1e-12 and len(P.curve(day)) == 81)
    check("bad photosynthesis records are refused", bad(lambda: P.measure({**day, "light": -1})) and bad(lambda: P.measure({**day, "day": 25})) and calculate("photosynthesis", {**day, "temperature": math.inf})["rows"][0][1] == "—")
    rows = calculate("photosynthesis", dict(light=0))["rows"]
    check("readout keeps gross, respiration and net as separate rows", [float(rows[i][1]) for i in range(3)] == [0, 2, -2] and "呼吸" in rows[1][0] and "净光合" in rows[2][0])
    check("readout says when light cannot compensate", "补偿不了" in calculate("photosynthesis", dict(light=500, temperature=45))["rows"][3][1])

    # ---------------------------------------------------------- 分裂：计数前后对得上
    old = dict(mitosis=(["前期", "中期", "后期", "末期（每个子细胞）"], [4, 4, 8, 4], [8, 8, 8, 4]),
               meiosis=(["减Ⅰ前期", "减Ⅰ后期（分裂前整细胞）", "减Ⅱ中期（每个细胞）", "减Ⅱ完成（每个细胞）"], [4, 4, 2, 2], [8, 8, 4, 2]))
    for mode, (names, chromosomes, dna) in old.items():
        got = [D.phase(mode, i) for i in range(4)]
        check(f"{mode}: the four old stages keep their names and numbers", [g["name"] for g in got] == names and [g["chromosomes"] for g in got] == chromosomes and [g["dna"] for g in got] == dna)
        every = [D.phase(mode, stage) for stage, _ in D.phases(mode)]
        check(f"{mode}: chromatids, DNA and centromeres agree in every phase", all(g["dna"] == g["chromatids"] == 2 * g["chromosomes"] if g["chromatids"] else g["dna"] == g["chromosomes"] for g in every))
        check(f"{mode}: total nuclear DNA is 4 before replication and 8 ever after", [g["total_dna"] for g in every] == [4] + [8] * (len(every) - 1))
        check(f"{mode}: cell number never goes down", all(a["cells"] <= b["cells"] for a, b in zip(every, every[1:])) and every[-1]["cells"] == (2 if mode == "mitosis" else 4))
        for stage in range(4):
            pieces = tokens_for(mode, stage)["tokens"]
            g = D.phase(mode, stage)
            check(f"{mode} stage {stage}: the drag board has the same chromosomes", len(pieces) == g["total_chromosomes"] and sum(2 if t["sister"] is None else 1 for t in pieces) == g["total_dna"])
        rows = calculate(mode, dict(stage=0))["rows"]
        check(f"{mode}: card still reads chromosomes and DNA from rows 1 and 2", int(rows[1][1]) == 4 and int(rows[2][1]) == 8 and len(rows) == 8)
    late = D.phase("mitosis", 2)
    check("mitosis anaphase: 8 chromosomes, 0 chromatids, 4 pairs, 4 sets, one cell", (late["chromosomes"], late["chromatids"], late["pairs"], late["sets"], late["cells"]) == (8, 0, 4, 4, 1))
    second = D.phase("meiosis", 7)
    check("meiosis II anaphase: back to 4 chromosomes, no homologs, two cells", (second["chromosomes"], second["dna"], second["chromatids"], second["pairs"], second["sets"], second["cells"]) == (4, 4, 0, 0, 2, 2))
    check("tetrads only in prophase / metaphase I", [D.phase("meiosis", stage)["tetrads"] for stage, _ in D.phases("meiosis")] == [0, 2, 2, 0, 0, 0, 0, 0] and "四分体" in calculate("meiosis", dict(stage=0))["rows"][4][1])
    gamete = D.phase("meiosis", 3)
    check("gametes: one set, no homologs, four cells", (gamete["chromosomes"], gamete["dna"], gamete["pairs"], gamete["sets"], gamete["cells"]) == (2, 2, 0, 1, 4))
    check("secondary cells have no homologs", D.phase("meiosis", 6)["pairs"] == 0 == D.phase("meiosis", 2)["pairs"] and D.phase("meiosis", 1)["pairs"] == 2)
    check("unknown phase and unsplit division are refused", bad(lambda: D.phase("mitosis", 9)) and bad(lambda: D.phase("mitosis", True)) and bad(lambda: D.phase("x", 0)) and bad(lambda: D.divide_equal(D.replicate(D.start()))))

    # ---------------------------------------------------------- 卡片封面
    from ..lab.benches import bio_cover as C
    from ..lab.benches.bio_model import DEFAULT, NAMES

    def cover(kind, **p):
        full = {**DEFAULT, **p}
        result = calculate(kind, full)
        image = C.render(kind, full, result, 1.0, render(view(stained, 10), C.VIEW, 1.0) if "slide" in p else None)
        return bytes(image.constBits()), C.caption(kind, full, result), C.key(kind, full)

    blank = bytes(C.render("plant", dict(DEFAULT), dict(rows=[]), 1.0).constBits())
    drawn = {kind: cover(kind, **(E.fresh() if kind == "enzyme" else {})) for kind in NAMES}
    check("every kind of card has its own cover and a two-line caption", len({d[0] for d in drawn.values()}) == len(NAMES) and all(len(d[1]) == 2 and all(d[1]) for d in drawn.values()))
    for mode in ("mitosis", "meiosis"):
        shots = [cover(mode, stage=stage) for stage, _ in D.phases(mode)]
        same = {(D.phases(mode)[i][0], D.phases(mode)[j][0]) for i in range(len(shots)) for j in range(i) if shots[i][0] == shots[j][0]}
        check(f"{mode}: each phase draws differently unless the chromosomes are in the same state", same <= {(0, 5)} and all(s[1][0] == name for s, (_, name) in zip(shots, D.phases(mode))))
    check("cover follows the readings", cover("enzyme", **base)[0] != cover("enzyme", **{**base, "pre_min": 5})[0] and cover("cross")[0] != cover("cross", father="AA")[0]
          and cover("photosynthesis")[0] != cover("photosynthesis", temperature=40)[0] and cover("microscope")[0] != cover("microscope", magnification=400)[0])
    check("cover key ignores the nested records but sees every simple setting", C.key("mitosis", {**DEFAULT, "chromosomes": dict(v=1)}) == C.key("mitosis", dict(DEFAULT)) != C.key("mitosis", {**DEFAULT, "stage": 1}))
    check("microscope with a slide shows the real view", cover("microscope", slide=view(stained, 10))[0] != drawn["microscope"][0] and "内表皮" in cover("microscope", slide=view(stained, 10))[1][1])
    check("captions carry the numbers", cover("mitosis", stage=2)[1] == ("后期", "染色体 8 · 核DNA 8 · 单体 0") and cover("foodweb")[1][1] == "1000 → 150 → 22.5" and "底物剩余" in drawn["enzyme"][1][1]
          and cover("meiosis", stage=3)[1][1].startswith("4 个细胞，每个：染色体 2"))
    check("broken records still get a cover", cover("enzyme", enzyme="x")[1] == ("记录读不出来", "—") and cover("photosynthesis", light=-5)[1][1] == "—" and blank != drawn["plant"][0])

    from PySide6.QtCore import QByteArray, QRectF
    from PySide6.QtGui import QImage, QPainter
    from PySide6.QtSvg import QSvgRenderer

    def small(kind):
        image = QImage(28, 28, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(0)
        painter = QPainter(image)
        C.icon(kind)(painter, QRectF(0, 0, 28, 28))
        painter.end()
        return bytes(image.constBits())

    icons = {kind: small(kind) for kind in list(NAMES) + ["undo"]}
    check("every model has its own panel icon and a short subtitle", len(set(icons.values())) == len(icons) and all(any(icons[k]) for k in icons) and all(0 < len(C.SUBS[k]) <= 12 for k in NAMES))
    check("home banner art is a valid 160x110 svg", QSvgRenderer(QByteArray(C.ART.replace("currentColor", "#000").replace("<svg", "<svg xmlns='http://www.w3.org/2000/svg'", 1).encode())).viewBoxF().size().toTuple() == (160.0, 110.0))

    # ---------------------------------------------------------- 工作台：卡片、存档、旧存档
    studio = Studio("day")
    studio.resize(1440, 900)
    studio.show()
    studio.open_bench("bio")
    app.processEvents()
    app.sendEvent(studio.ctx.stage, QEvent(QEvent.Type.Leave))
    B = studio.B
    B.transfer_restore(dict(v=1, objects=[], selected=None, seq=0))     # 上次留在台面上的东西不算
    B.pal.items["bio-microscope"].it["click"]()
    app.processEvents()
    names = [c["name"] for c in studio.ctx.ctrls]
    check("card offers the new window", "制片与显微观察" in names and "总放大倍数" in names)
    legacy = B.transfer_snapshot()
    check("old save: microscope without a slide record", "slide" not in legacy["objects"][0]["p"])
    state = B.transfer_model
    state["objects"][0]["p"]["slide"] = view(stained, 10)
    B.transfer_restore(B.transfer_snapshot())
    app.processEvents()
    names = [c["name"] for c in studio.ctx.ctrls]
    check("card with a slide drops the free magnification slider", "总放大倍数" not in names and "制片与显微观察" in names)
    saved = json.loads(json.dumps(B.transfer_snapshot(), ensure_ascii=False))
    B.transfer_restore(saved)
    studio.ctx.stage.repaint()
    check("bench save / restore keeps the slide", not studio.ctx.stage.error and B.transfer_snapshot() == saved and M.valid(B.transfer_snapshot()["objects"][0]["p"]["slide"]))
    studio.grab().save(str(out / "bench-card-day.png"))
    B.transfer_restore(legacy)
    studio.ctx.stage.repaint()
    check("old save still opens", not studio.ctx.stage.error and "slide" not in B.transfer_snapshot()["objects"][0]["p"])

    def ctrl(name):
        return next(c for c in studio.ctx.ctrls if c["name"] == name)

    def last():
        return B.transfer_snapshot()["objects"][-1]["p"]

    B.transfer_restore(dict(v=1, objects=[], selected=None, seq=0))
    B.pal.items["bio-enzyme"].it["drop"](330, 120)
    app.processEvents()
    names = [c["name"] for c in studio.ctx.ctrls]
    check("new enzyme card is a specific enzyme with the full set of controls", last()["enzyme"] == "amylase" and last()["pH"] == 6.8 and all(n in names for n in ("酶", "反应温度 / °C", "底物浓度（以 Km 为 1）", "预处理温度 / °C", "预处理 pH")))
    ctrl("酶")["set"]("pepsin")
    app.processEvents()
    check("switching enzyme moves the pH to that enzyme and rebuilds the panel", last()["enzyme"] == "pepsin" and last()["pH"] == last()["pre_pH"] == round(E.optimum_ph("pepsin"), 1) and ctrl("反应 pH")["get"]() == last()["pH"])
    ctrl("预处理时间 / min（0 = 不做）")["set"](5)
    ctrl("预处理 pH")["set"](8)
    check("pretreatment set from the panel kills the enzyme in the readout", last()["pre_min"] == 5 and float(calculate("enzyme", last())["rows"][0][1]) < 0.01)
    B.pal.items["bio-photosynthesis"].it["drop"](640, 120)
    app.processEvents()
    check("photosynthesis card: temperature and day length without touching the save", "day" not in last() and ctrl("每天光照 / h")["get"]() == 12 and ctrl("温度 / °C")["get"]() == 25)
    ctrl("每天光照 / h")["set"](8)
    ctrl("温度 / °C")["set"](35)
    check("photosynthesis sliders reach the model", last()["day"] == 8 and last()["temperature"] == 35 and abs(float(calculate("photosynthesis", last())["rows"][1][1]) - P.respiration(35)) < 1e-3)
    B.pal.items["bio-meiosis"].it["drop"](330, 330)
    app.processEvents()
    ctrl("分裂时期")["set"]("7")
    check("phase picker reaches the new phases", last()["stage"] == 7 and calculate("meiosis", last())["rows"][0][1] == "减Ⅱ后期（每个细胞）")
    ctrl("逐条拖动并核对染色体")["press"]()
    check("count-only phase does not open the drag board", "chromosomes" not in last())
    B.pal.items["bio-mitosis"].it["drop"](640, 330)
    app.processEvents()
    saved = json.loads(json.dumps(B.transfer_snapshot(), ensure_ascii=False))
    B.transfer_restore(saved)
    studio.ctx.stage.repaint()
    check("bench save / restore keeps the new cards", not studio.ctx.stage.error and B.transfer_snapshot() == saved)
    studio.grab().save(str(out / "bench-models-day.png"))
    old_cards = dict(v=1, selected=1, seq=3, objects=[dict(id=1, kind="enzyme", p=dict(temperature=50, pH=6), x=330, y=120), dict(id=2, kind="photosynthesis", p=dict(light=300, co2=0.03), x=640, y=120),
                                                    dict(id=3, kind="meiosis", p=dict(stage=2), x=330, y=330)])
    B.transfer_restore(old_cards)
    studio.ctx.stage.repaint()
    names = [c["name"] for c in studio.ctx.ctrls]
    p0 = B.transfer_snapshot()["objects"][0]["p"]
    check("old enzyme card keeps the old curve and old sliders", not studio.ctx.stage.error and "enzyme" not in p0 and "温度 / °C" in names and "预处理 pH" not in names
          and calculate("enzyme", p0)["rows"] == [["相对活性", f"{math.exp(-((50 - 37) / 20) ** 2 - ((6 - 7) / 2) ** 2):.4f}"]])
    p1 = B.transfer_snapshot()["objects"][1]["p"]
    check("old photosynthesis card reads the same numbers", [r[1] for r in calculate("photosynthesis", p1)["rows"][:3]] == [f"{20 * 300 / 500 * 0.03 / 0.05:.3f}", "2.000", f"{20 * 300 / 500 * 0.03 / 0.05 - 2:.3f}"])
    ctrl("酶")["set"]("catalase")
    app.processEvents()
    check("old enzyme card can be turned into a specific enzyme", B.transfer_snapshot()["objects"][0]["p"]["enzyme"] == "catalase" and B.transfer_snapshot()["objects"][0]["p"]["temperature"] == 50 and "预处理 pH" in [c["name"] for c in studio.ctx.ctrls])
    B.transfer_restore(saved)
    tokens.set_theme("night")
    studio.ctx.stage.repaint()
    check("new cards draw at night", not studio.ctx.stage.error)
    studio.ctx.stage.grab().save(str(out / "bench-models-night.png"))
    tokens.set_theme("day")
    B.transfer_restore(dict(v=1, objects=[], selected=None, seq=0))
    studio.go_home()
    studio.close()
    (out / "bio-realism-result.txt").write_text("OK\n" + "\n".join(checks), encoding="utf-8")
    print("BIO_REALISM OK", len(checks), "checks", flush=True)
    return 0


def _dry(M):
    r = M.fresh(5)
    M.act(r, "wipe")
    M.act(r, "take", "onion_inner")
    M.act(r, "cover", "angled")
    return r


if __name__ == "__main__":
    raise SystemExit(test_runtime.run(main))
