"""化学反应式守恒与铁硫氰单配体平衡的独立数值基准。"""
from . import test_runtime
test_runtime.configure()

import json
import math
import sys
from pathlib import Path


def main(output=None):
    test_runtime.application()
    from ..lab.benches import chem_equations as equations
    from ..lab.benches import chem_model as m
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    audited = set()
    for expressions in (m.HF.values(), ([x] for x in m.HD.values()), (event[:1] for event in m.EV.values())):
        for group in expressions:
            for text in group:
                if text and isinstance(text, str):
                    parsed = equations.parse(text)
                    assert parsed.balanced, (text, parsed.imbalance())
                    audited.add(text)
    # 动态事件表达式也纳入：碳酸/碳酸氢根与铵盐的不同条件。
    for context in (dict(T=25, added=[], ev=set()), dict(T=80, added=['NaHCO₃'], ev=set()),
                    dict(T=25, added=['NH₄Cl'], ev={'r:CO3-H1'})):
        for key in ('r:CO2', 'r:NH3'):
            text = m.EV[key][0](context, dict(pH=8))
            assert equations.parse(text).balanced, text
            audited.add(text)
    for text in ('Ag₂O + 4NH₃ + H₂O ⇌ 2[Ag(NH₃)₂]⁺ + 2OH⁻',
                 'CuSO₄·5H₂O = CuSO₄ + 5H₂O', 'Fe³⁺ + e⁻ = Fe²⁺'):
        assert equations.parse(text).balanced, text
        audited.add(text)
    assert not equations.parse('H₂ + O₂ = H₂O').balanced
    assert not equations.parse('Fe³⁺ = Fe²⁺').balanced
    assert equations.parse('2H₂O₂ =MnO₂= 2H₂O + O₂↑').condition == 'MnO₂'
    assert '加热' in equations.display('Cu(OH)₂ =△= CuO + H₂O')
    assert 'AgOH' not in m.HF['Ag'][1] and '棕褐' in m.PDN['Ag']

    total = dict(Fe3=1., SCN=1., K=1., Cl=13.)
    for volume in (10., 100., 1000.):
        result = m.eqm(total, volume)
        free_fe, free_scn, bound = result['dis']['Fe3'], result['dis']['SCN'], result['feSCN']
        assert abs(free_fe + bound + result['p']['Fe3'] - 1) < 1e-9
        assert abs(free_scn + bound - 1) < 1e-9
        formation = bound * volume / (free_fe * free_scn)
        assert abs(formation - m.FE_SCN_K) < 1e-5
        charge = (result['h'] - result['oh'])*volume + 1 + 3*free_fe + 2*bound - 13 - free_scn
        assert abs(charge) < 1e-7, charge
    assert m.eqm(total, 10)['feSCN'] > m.eqm(total, 1000)['feSCN']
    basic = m.eqm(dict(Fe3=1, SCN=1, K=1, Cl=3, Na=20), 100)
    assert basic['p']['Fe3'] > .99 and basic['feSCN'] < .001
    assert abs(basic['dis']['Fe3'] + basic['feSCN'] + basic['p']['Fe3'] - 1) < 1e-8
    assert abs(m.eqm(dict(A=5, Na=2.5), 100)['pH'] + math.log10(m.KA)) < .002
    (out / 'chem-science-result.txt').write_text('OK\n' + json.dumps(dict(equations=len(audited),
        notes='元素、电荷与计量核对；不等于已验证所有反应条件或真实常数'), ensure_ascii=False), encoding='utf-8')
    print('CHEM_SCIENCE OK', len(audited), 'equations; complex equilibrium, charge and material references', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(test_runtime.run(main))
