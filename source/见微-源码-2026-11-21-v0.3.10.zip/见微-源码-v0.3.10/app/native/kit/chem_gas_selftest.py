"""气密性、漏气收支和实际制氧/排水收集的守恒回归。"""
from . import test_runtime
test_runtime.configure()

import copy
import json
import sys
from pathlib import Path


def main(output=None):
    app = test_runtime.application()
    from ..lab.benches.apparatus_model import route_gas, gas_volume, prepare_water_collection
    from ..lab.studio import Studio
    from . import state_graph
    from .ctx import Loop
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks = []

    def check(name, ok):
        assert ok, name
        checks.append(name)

    source = dict(id=1, gas_to=2, gas_seal=False)
    dest = dict(id=2, V=0., tot={}, gas_capacity=250, collection='water', gas_water_ready=False)
    check('open flask vents gas', route_gas(source, [source, dest], 'O2', 1) == (0, 1))
    source['gas_seal'] = True
    check('water preparation required', route_gas(source, [source, dest], 'O2', 1) == (0, 1))
    prepare_water_collection(dest, 250)
    source['gas_leak'] = .25
    captured, released = route_gas(source, [source, dest], 'O2', 1)
    check('leak capture conservation', abs(captured-.75) < 1e-12 and abs(released-.25) < 1e-12)
    check('gas displaces water', abs(dest['V'] + gas_volume(.75) - 250) < 1e-9)
    check('displaced water recorded', abs(dest['water_displaced'] - gas_volume(.75)) < 1e-9)
    captured, released = route_gas(source, [source, dest], 'O2', 100)
    check('full collector bounded', abs(dest['V']) < 1e-9 and abs(captured+released-100) < 1e-9)
    check('full collector gas volume', abs(sum(gas_volume(n) for n in dest['collected'].values()) - 250) < 1e-7)
    # 串联中只有一部分被洗气瓶吸收，剩余再漏气；所有捕集/逸散仍计入总量。
    source = dict(id=1, gas_to=2)
    wash = dict(id=2, gas_to=3, gas_seal=True, gas_leak=.5, collection='wash', V=50, tot={'Ca': 1.})
    dest = dict(id=3, collection='up', gas_capacity=250)
    captured, released = route_gas(source, [source, wash, dest], 'CO2', 4)
    check('serial wash leak balance', abs(captured-3) < 1e-9 and abs(released-1) < 1e-9)
    check('serial wash solute and captured gas', wash['tot']['C'] == 2 and dest['collected']['CO2'] == 1)

    studio = Studio('day')
    studio.resize(1440, 900)
    studio.show()
    studio.open_bench('chem')
    app.processEvents()
    B = studio.B
    loop = next(timer for timer in studio.ctx.timers if isinstance(timer, Loop))
    loop.pause()

    def press(name):
        next(c for c in studio.ctx.ctrls if c['kind'] == 'button' and c['name'] == name)['press']()

    def state():
        return state_graph.decode(B.transfer_snapshot())

    def select(data, obj):
        data['W']['sel'] = obj
        B.transfer_restore(state_graph.encode(data))

    scenarios = {}
    for mode, sealed, leak in (('open', False, 0.), ('sealed', True, 0.), ('leaky', True, .25)):
        B.pal.items['chem-oxygen-training'].it['click']()
        data = state()
        collector = next(v for v in data['objs'] if v['type'] == 'gasjar')
        select(data, collector)
        press('注满水并倒置')
        data = state()
        source = next(v for v in data['objs'] if v['type'] == 'flask')
        select(data, source)
        next(c for c in studio.ctx.ctrls if c['kind'] == 'check' and c['name'] == '加塞并密封导气口')['set'](sealed)
        next(c for c in studio.ctx.ctrls if c['kind'] == 'slider' and c['name'] == '接口漏气比例')['set'](leak)
        next(item for item in B.pal.all if item.it['label'] == '二氧化锰').it['click']()
        for _ in range(200):
            loop.fn(.05)
        data = state()
        source = next(v for v in data['objs'] if v['type'] == 'flask')
        collector = next(v for v in data['objs'] if v['type'] == 'gasjar')
        totals = source['gas_totals']
        check(mode+' oxygen stoichiometry', abs((9-source['tot']['H2O2'])/2 - totals['produced']) < 1e-7)
        check(mode+' gas accounting', abs(totals['produced']-totals['captured']-totals['released']) < 1e-7)
        check(mode+' collector consistency', abs(totals['captured']-collector.get('collected', {}).get('O2', 0)) < 1e-7)
        check(mode+' water gas consistency', abs(collector['V']+gas_volume(totals['captured'], collector['T'])-250) < 1e-6)
        if sealed:
            check(mode+' correct capture fraction', abs(totals['captured']/totals['produced'] - (1-leak)) < 1e-6)
        else:
            check(mode+' no capture', totals['captured'] == 0)
        scenarios[mode] = copy.deepcopy(data)
        for label in list(B._toasts.labels):
            B._toasts._drop(label)
        studio.ctx.stage.repaint()
        check(mode+' renders', not studio.ctx.stage.error)
        for _ in range(5):
            app.processEvents()
        studio.grab().save(str(out / ('oxygen-'+mode+'.png')))
    check('sealing matters with same generation', scenarios['open']['objs'][0]['gas_totals']['produced'] == scenarios['sealed']['objs'][0]['gas_totals']['produced'])
    data = scenarios['sealed']
    collector = next(v for v in data['objs'] if v['type'] == 'gasjar')
    select(data, collector)
    press('带火星的木条')
    collector = next(v for v in state()['objs'] if v['type'] == 'gasjar')
    check('actual collected oxygen relights splint', collector['test']['res'] == 'relight')
    press('清空')
    collector = next(v for v in state()['objs'] if v['type'] == 'gasjar')
    check('clear empties captured gas and water state', not collector.get('collected') and not collector['gas_water_ready'])
    studio.go_home()
    studio.close()
    (out / 'chem-gas-result.txt').write_text('OK\n'+json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
    print('CHEM_GAS OK', len(checks), 'checks', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(test_runtime.run(main))
