"""预习单与 B 站讲解视频入口：纯数据，不依赖 Qt。

一张预习单 = 3–6 个知识点（知识卡） + 一个相关实验 + 一段讲解视频 + 三道课前小题。
预习单存在 preview.json；做完的部分打勾，同时往 learning 的事件流里记一笔。

B 站只给搜索链接（按播放量排序），不写死某个视频，免得视频被删后变死链。
"""
from __future__ import annotations

import re
import time
import uuid
from urllib.parse import quote

from .kit.home import load_json, save_json

FILE = "preview.json"
PARTS = ("cards", "lab", "video", "quiz")
PART_NAME = {"cards": "知识点", "lab": "实验", "video": "讲解视频", "quiz": "课前小题"}
SUBJECTS = ("数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理")

# 章节 → 知识卡名（必须是 bank/cards.json 里有的）+ 实验 id（lab 注册表里有的，可为空）
CHAPTERS = {
    "数学": [
        ("集合与常用逻辑用语", ["集合与常用逻辑"], []),
        ("函数的概念与性质", ["函数单调性", "函数周期性", "对称轴与对称中心"], ["m-func"]),
        ("指数函数与对数函数", ["指对运算与比大小"], ["m-func"]),
        ("三角函数", ["三角函数图象与性质", "三角恒等变换"], ["m-trig"]),
        ("解三角形", ["解三角形"], ["m-trig"]),
        ("平面向量", ["平面向量数量积"], ["m-vec"]),
        ("复数", ["复数运算"], ["m-cplx"]),
        ("立体几何与空间向量", ["立体几何与空间角"], ["m-solid", "m-spacevec"]),
        ("直线与圆", ["直线与圆的位置关系"], ["m-conic"]),
        ("圆锥曲线", ["圆锥曲线离心率", "圆锥曲线综合"], ["m-conic"]),
        ("数列", ["数列求和"], ["m-seq"]),
        ("导数及其应用", ["导数与切线", "恒成立与参数范围", "函数单调性"], ["m-deriv"]),
        ("计数原理", ["排列组合与二项式"], ["m-pascal"]),
        ("概率与随机变量", ["古典概型与条件概率", "离散型随机变量的期望"], ["m-condprob", "m-dist"]),
    ],
    "物理": [
        ("牛顿运动定律", ["牛顿第二定律"], ["p-incline", "p-elev"]),
        ("抛体运动", ["平抛运动"], ["p-proj"]),
        ("圆周运动", ["圆周运动"], ["p-circle"]),
        ("万有引力与宇宙航行", ["万有引力与卫星"], ["p-grav"]),
        ("机械能守恒定律", ["机械能守恒与动能定理"], ["p-energy"]),
        ("动量守恒定律", ["动量守恒与碰撞"], ["p-collide"]),
        ("静电场", ["电场力做功与电势能", "带电粒子在电场中偏转"], ["p-field", "p-cap"]),
        ("电路及其应用", ["闭合电路欧姆定律"], ["p-circuit"]),
        ("电磁感应", ["电磁感应"], ["p-induct"]),
        ("机械振动与机械波", ["简谐运动", "机械波"], ["p-shm", "p-wave"]),
        ("光", ["光的折射"], ["p-refract"]),
    ],
    "化学": [
        ("物质的量", ["物质的量与阿伏加德罗常数"], ["c-eq"]),
        ("离子反应", ["离子共存与离子方程式"], ["c-conduct"]),
        ("氧化还原反应", ["氧化还原反应"], ["c-eq"]),
        ("元素周期律", ["元素周期律与化学键"], ["c-ptable"]),
        ("常见无机物及其转化", ["无机物转化与检验"], ["c-flame"]),
        ("化学反应速率与化学平衡", ["化学反应速率", "化学平衡与平衡常数"], ["c-equil", "c-rate"]),
        ("水溶液中的离子平衡", ["电离平衡与盐类水解"], ["c-ion", "c-titr"]),
        ("电化学", ["电化学"], ["c-cell"]),
    ],
    "生物": [
        ("细胞的分子组成", ["蛋白质与脂质"], []),
        ("细胞的能量供应和利用", ["细胞呼吸", "光合作用"], ["b-photo", "b-enzyme"]),
        ("遗传因子的发现", ["基因分离定律", "基因自由组合定律"], ["b-mendel"]),
        ("种群和群落", ["种群增长与物质循环"], ["b-pop", "b-lv"]),
        ("生态系统", ["生态系统能量流动", "种群增长与物质循环"], ["b-energy"]),
    ],
}


def _cards():
    from .bank.study import cards
    return cards()["cards"]


def card_by_name(name):
    for c in _cards():
        if c["n"] == name:
            return c
    return None


def chapters(subject):
    """某科的章节名；文科没有手写章节时，一张知识卡算一节。"""
    if subject in CHAPTERS:
        return [c[0] for c in CHAPTERS[subject]]
    return [c["n"] for c in _cards() if c["s"] == subject]


def _chapter(subject, name):
    for row in CHAPTERS.get(subject, []):
        if row[0] == name:
            return row
    if card_by_name(name):
        return (name, [name], [])
    raise KeyError(f"没有这个章节：{subject} · {name}")


# ---------------------------------------------------------------- B 站
_TRIM = re.compile(r"[（(].*?[)）]|[，,。；;：:、/]+")


def video_query(point, subject=""):
    """「高中物理 动量守恒定律 讲解」：去掉括号注释和标点，前面加学段学科。"""
    point = re.sub(r"\s+", " ", _TRIM.sub(" ", str(point or ""))).strip()
    head = f"高中{subject}" if subject and subject not in point else ""
    return " ".join(x for x in (head, point, "讲解") if x)


def bili_url(query):
    """B 站综合搜索，order=click 是按播放量排序。"""
    return "https://search.bilibili.com/all?keyword=" + quote(query, safe="") + "&order=click"


# ---------------------------------------------------------------- 从一段文字找知识点
def _norm(s):
    from .bank.study import norm
    return norm(s)


def cards_in(text, subject="", limit=6):
    """按知识卡名和关键词在文字里出现的情况打分，取前几张。"""
    t = _norm(text)
    if not t:
        return []
    scored = []
    for c in _cards():
        if subject and c["s"] != subject:
            continue
        sc = 0
        if _norm(c["n"]) in t:
            sc += 10
        for k in c["k"]:
            kk = _norm(k)
            if len(kk) >= 2 and kk in t:
                sc += 2 + min(len(kk), 6) / 3
        if sc:
            scored.append((sc, c))
    scored.sort(key=lambda x: -x[0])
    return [c for _, c in scored[:limit]]


def _lab_for(cards):
    """知识卡关键词和实验关键词重合最多的那个实验。"""
    try:
        from .kit.registry import lab
        lab.load()
        exps = list(lab.list)
    except Exception:
        return ""
    subj = {"数学": "math", "物理": "phys", "化学": "chem", "生物": "bio"}
    want = {subj.get(c["s"]) for c in cards}
    words = [_norm(k) for c in cards for k in [c["n"], *c["k"]] if len(_norm(k)) >= 2]
    best, score = "", 0
    for e in exps:
        if e.subj not in want:
            continue
        hay = _norm(f"{e.title} {e.unit} {e.kw}")
        sc = sum(1 for w in words if w in hay)
        if sc > score:
            best, score = e.id, sc
    return best


def _quiz_for(cards, n=3):
    """课前小题只测概念：先挑单选、填空，再补别的；每张卡轮流挑，不重复。"""
    try:
        from .bank.data import bank
        from .bank.study import related_to_card
        bank.load()
    except Exception:
        return []
    order = {"单选": 0, "填空": 1, "简答": 2}
    pools = []
    for c in cards:
        qs = related_to_card(c, c["n"])
        pools.append(sorted(qs, key=lambda q: (order.get(q.get("type"), 3), str(q.get("id")))))
    out = []
    while len(out) < n and any(pools):
        for pool in pools:
            while pool:
                q = pool.pop(0)
                if q["id"] not in out:
                    out.append(q["id"])
                    break
            if len(out) >= n:
                break
    return out


# ---------------------------------------------------------------- 预习单
def make(subject, chapter):
    name, names, labs = _chapter(subject, chapter)
    cards = [c for c in (card_by_name(x) for x in names) if c]
    return _sheet(f"{subject} · {name}", subject, name, cards, labs[0] if labs else _lab_for(cards))


def from_text(text, title="这一课", subject=""):
    """课件里点「预习这一课」：从这一课的文字里认出知识点。认不出返回 None。"""
    cards = cards_in(text, subject)
    if not cards:
        return None
    subject = subject or cards[0]["s"]
    cards = [c for c in cards if c["s"] == subject] or cards
    return _sheet(f"预习 · {title}", subject, cards[0]["n"] if len(cards) == 1 else title, cards, _lab_for(cards))


def _sheet(title, subject, topic, cards, lab_id):
    return dict(id=uuid.uuid4().hex[:12], title=title, subject=subject, topic=topic,
                cards=[c["n"] for c in cards][:6], lab=lab_id or "",
                video=video_query(topic, subject), quiz=_quiz_for(cards),
                made=time.strftime("%Y-%m-%d"), done=[])


def parts(sheet):
    """这张单子实际有的部分（没有实验或没有小题的，不算进进度）。"""
    return [p for p in PARTS if (sheet.get(p) if p != "cards" else sheet.get("cards"))]


def progress(sheet):
    ps = parts(sheet)
    return sum(1 for p in ps if p in sheet.get("done", [])), len(ps)


def _load():
    data = load_json(FILE, None)
    if not isinstance(data, dict) or data.get("v") != 1 or not isinstance(data.get("sheets"), dict):
        data = dict(v=1, current="", sheets={})
    return data


def save(sheet):
    """存一张单子并设成当前预习。最多留 30 张。"""
    data = _load()
    data["sheets"][sheet["id"]] = sheet
    data["current"] = sheet["id"]
    if len(data["sheets"]) > 30:
        keep = sorted(data["sheets"].values(), key=lambda s: s.get("made", ""))[-30:]
        data["sheets"] = {s["id"]: s for s in keep}
    save_json(FILE, data)
    return sheet


def current():
    data = _load()
    return data["sheets"].get(data.get("current") or "")


def untick(sheet_id, part):
    data = _load()
    sheet = data["sheets"].get(sheet_id)
    if sheet is None:
        raise KeyError("预习单不存在")
    if part in sheet["done"]:
        sheet["done"].remove(part)
        save_json(FILE, data)
    return sheet


def suggest(subject, n=4):
    """空状态里推荐的章节：这科里还没预习过的前几章。"""
    seen = {s.get("topic") for s in _load()["sheets"].values() if s.get("subject") == subject}
    rows = [c for c in chapters(subject) if c not in seen]
    return (rows or chapters(subject))[:n]


def tick(sheet_id, part):
    """把一部分标成做完；第一次标的时候往学习记录里记一笔。"""
    if part not in PARTS:
        raise ValueError("预习单没有这一部分")
    data = _load()
    sheet = data["sheets"].get(sheet_id)
    if sheet is None:
        raise KeyError("预习单不存在")
    if part not in sheet["done"]:
        sheet["done"].append(part)
        save_json(FILE, data)
        try:
            from . import learning
            learning.note("preview", f"preview:{sheet_id}:{part}", sheet.get("subject", ""))
        except Exception:
            pass
    return sheet
