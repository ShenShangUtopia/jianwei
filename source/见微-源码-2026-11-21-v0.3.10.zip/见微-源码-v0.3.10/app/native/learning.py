"""Small versioned review plan and explicit learning events, no inferred grading."""
import copy
import hashlib
import json
import time
import uuid
import math
from datetime import date,datetime,timedelta
from .kit.home import home,save_json

FILE='learning.json'
INTERVALS=(1,3,7,14,30)


def load():
    path=home()/FILE
    if not path.exists():
        return dict(v=1,clock_day=None,items={},events=[])
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(data,dict) or data.get('v')!=1 or not isinstance(data.get('items'),dict) or not isinstance(data.get('events'),list):
        raise ValueError('学习记录损坏或版本不支持，未覆盖原文件')
    return data


def day(data,now=None):
    actual=now or date.today()
    if isinstance(actual,datetime):
        actual=actual.date()
    previous=date.fromisoformat(data['clock_day']) if data.get('clock_day') else actual
    return max(actual,previous)


def sync_questions(ids,questions,now=None):
    data=load()
    today=day(data,now)
    wanted=set(ids)
    before=copy.deepcopy(data)
    for ident,item in data['items'].items():
        if item['kind']=='question':
            item['active']=item['ref'] in wanted
    for qid in wanted:
        q=questions.get(qid)
        if q is None:
            continue
        key='question:'+qid
        if key not in data['items']:
            data['items'][key]=dict(kind='question',ref=qid,title=q.get('title',qid),subject=q.get('subject',''),stage=-1,due=(today+timedelta(days=1)).isoformat(),active=True,last_review=None)
    if data!=before:
        data['clock_day']=today.isoformat()
        save_json(FILE,data)
    return data


def add_card(card,subject='',now=None):
    data=load()
    today=day(data,now)
    raw=json.dumps(card,sort_keys=True,ensure_ascii=False)
    key='card:'+hashlib.sha256(raw.encode()).hexdigest()[:24]
    if key not in data['items']:
        data['items'][key]=dict(kind='card',ref=key,title=card.get('n') or card.get('title') or '知识卡',subject=subject,card=copy.deepcopy(card),stage=-1,due=today.isoformat(),active=True,last_review=None)
        data['clock_day']=today.isoformat()
        save_json(FILE,data)
    return key


def due(now=None):
    data=load()
    today=day(data,now)
    return [(key,copy.deepcopy(item)) for key,item in data['items'].items() if item.get('active') and date.fromisoformat(item['due'])<=today and item.get('last_review')!=today.isoformat()]


def grade(key,correct,seconds=0.,event_id=None,now=None):
    if type(correct) is not bool:
        raise ValueError('复习结果须明确选择记住或未记住')
    if not math.isfinite(float(seconds)):
        raise ValueError('复习用时无效')
    data=load()
    today=day(data,now)
    item=data['items'][key]
    if item.get('last_review')==today.isoformat():
        return copy.deepcopy(item)
    if not item.get('active'):
        raise ValueError('这个项目已退出复习计划')
    if date.fromisoformat(item['due'])>today:
        raise ValueError('尚未到复习日期，不提前推进间隔')
    event_id=event_id or uuid.uuid4().hex
    if any(e.get('id')==event_id for e in data['events']):
        return copy.deepcopy(item)
    item['stage']=min(4,max(-1,item['stage'])+1) if correct else 0
    item['due']=(today+timedelta(days=INTERVALS[item['stage']])).isoformat()
    item['last_review']=today.isoformat()
    data['clock_day']=today.isoformat()
    data['events'].append(dict(id=event_id,day=today.isoformat(),kind='review',reference=key,correct=correct,source='self',subject=item.get('subject',''),seconds=max(0,min(86400,float(seconds))),t=time.time()))
    data['events']=data['events'][-20000:]
    save_json(FILE,data)
    return copy.deepcopy(item)


def record(reference,subject,seconds,correct=None,source='ungraded',event_id=None,now=None):
    if correct is not None and type(correct) is not bool:
        raise ValueError('正确与否未知时应记录为未判定')
    if source not in ('program','self','ungraded'):
        raise ValueError('学习事件来源无效')
    if not math.isfinite(float(seconds)):
        raise ValueError('学习用时无效')
    data=load()
    event_id=event_id or uuid.uuid4().hex
    if any(e.get('id')==event_id for e in data['events']):
        return
    today=day(data,now)
    data['clock_day']=today.isoformat()
    data['events'].append(dict(id=event_id,day=today.isoformat(),kind='attempt',reference=reference,correct=correct,source=source,subject=subject,seconds=max(0,min(86400,float(seconds))),t=time.time()))
    data['events']=data['events'][-20000:]
    save_json(FILE,data)


NOTE_KINDS=('preview','video','lab')


def note(kind,reference,subject='',now=None):
    """预习打勾、看视频、开实验：只记发生过，不判对错，也不推进复习排期。"""
    if kind not in NOTE_KINDS:
        raise ValueError('学习事件类型无效')
    data=load()
    today=day(data,now)
    data['clock_day']=today.isoformat()
    data['events'].append(dict(id=uuid.uuid4().hex,day=today.isoformat(),kind=kind,reference=str(reference),correct=None,source='ungraded',subject=subject,seconds=0.,t=time.time()))
    data['events']=data['events'][-20000:]
    save_json(FILE,data)


def forgot(item):
    """上次复习选了「没记住」：stage 回到 0 且复习过。"""
    return item.get('stage')==0 and bool(item.get('last_review'))


def daily(now=None,days=7):
    data=load()
    today=day(data,now)
    result=[]
    for i in range(days-1,-1,-1):
        current=(today-timedelta(days=i)).isoformat()
        events=[e for e in data['events'] if e['day']==current]
        program=[e for e in events if e['source']=='program' and type(e.get('correct')) is bool]
        subjects={}
        for e in events:
            subjects[e.get('subject') or '未分类']=subjects.get(e.get('subject') or '未分类',0)+1
        result.append(dict(day=current,count=len(events),attempts=sum(e['kind']=='attempt' for e in events),seconds=sum(e['seconds'] for e in events),graded=len(program),correct=sum(e['correct'] for e in program),self_review=sum(e['kind']=='review' for e in events),subjects=subjects))
    return result
