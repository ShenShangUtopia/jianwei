"""分步SVG互通、来源回跳和讲题PDF/长图导出。"""
import sys
from pathlib import Path
from ...kit import test_runtime

test_runtime.configure()


def main(output=None):
    app=test_runtime.application()
    from ...main_win import NativeWindow
    from .. import lesson
    from .schema import expression
    from PySide6.QtPdf import QPdfDocument
    from PySide6.QtGui import QImage
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    assert expression("a*x^2",("a",))(2,0,3)==12
    window=NativeWindow("day")
    window.resize(1500,900)
    window.show()
    page=window.goto("analysis")
    value=dict(problem="已知 y=x²，观察其开口与对称性。",ticket=lesson.ticket("x²",1),subject="数学",topic="二次函数",answer="开口向上，关于y轴对称",steps=["观察开口方向","观察对称性"],knowns=[],taskRes=[],figure=dict(v=1,title="函数图像",layers=[dict(id="f",type="function",expr="x^2",range=[-3,3,-1,9],x=100,y=80,w=700,h=450)],steps=[dict(say="开口",show=["f"],highlight=[]),dict(say="对称",show=["f"],highlight=["f"])]))
    page.rev=1
    value["figure"]["params"]={"a":dict(min=.5,max=3,value=1)}
    value["figure"]["layers"][0]["expr"]="a*x^2"
    page._on_done(1,value)
    page.go_step(1)
    before=page.figure_view.image()
    original=bytes(before.constBits())
    page.figure_view.set_parameter("a",2)
    after=page.figure_view.image()
    assert original!=bytes(after.constBits())
    app.processEvents()
    window.transfer_router.export_analysis(page,"board")
    clip=window.clip_bus.store.load(window.clip_bus.recent()[0]["id"])
    assert clip.get("svg") and clip["origin"]["ref"]["step"]==1
    assert b"<svg" in window.clip_bus.store.asset(clip,"svg").read_bytes()
    page.go_step(0)
    window.clip_bus.origin_requested.emit(clip["origin"])
    assert page.figure_view.k==1
    assert page.figure_view.parameters["a"]==2
    page.export_lesson(str(out/"lesson.pdf"))
    pdf=QPdfDocument()
    pdf.load(str(out/"lesson.pdf"))
    assert pdf.pageCount()>=3
    from ...lecture.pageview import page_text     # 有的字体把「二」记成部首「⼆」：按界面取字的方式比
    assert "二次函数" in page_text(pdf, 0)
    pdf.close()
    page.export_lesson(str(out/"lesson.png"))
    image=QImage(str(out/"lesson.png"))
    assert not image.isNull() and image.width()*image.height()<=16_000_000
    window.shutdown()
    window.close()
    print("FIGURE_TRANSFER OK SVG, step origin, PDF text/pages, bounded PNG",flush=True)
    return 0


if __name__=="__main__":
    import os
    os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR",r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
