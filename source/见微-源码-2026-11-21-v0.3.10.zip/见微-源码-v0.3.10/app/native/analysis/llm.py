"""DeepSeek 对话（不依赖网页与本机服务）：流式接收、JSON 宽松解析、校验 + 最多两轮修正。

全部是普通函数，在工作线程里调用；界面通过 on_text / on_think / status 回调拿进度。密钥只留在本机数据目录。
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path


class AskError(Exception):
    def __init__(self, msg, transient=False, busy=False, raw=""):
        super().__init__(msg)
        self.transient, self.busy, self.raw = transient, busy, raw


def _env_file():
    base = os.environ.get("JIANWEI_HOME") or os.path.join(os.environ.get("LOCALAPPDATA", str(Path.home())), "Jianwei")
    return Path(base) / "deepseek.env"


# 能用的 AI 服务商：都走 OpenAI 兼容的 /chat/completions。默认模型名是 2026 年各家文档里的常用名，
# 服务商改名时用户可以在设置里改（AI_MODEL_<ID>）；vision 是看图用的模型（课件框选识图），空串表示这家不用来看图。
PROVIDERS = {
    "deepseek": dict(name="DeepSeek", base="https://api.deepseek.com", model="deepseek-flash", vision="deepseek-flash",
                     key="DEEPSEEK_API_KEY", site="platform.deepseek.com"),
    "qwen": dict(name="通义千问", base="https://dashscope.aliyuncs.com/compatible-mode/v1", model="qwen-plus", vision="qwen-vl-plus",
                 key="QWEN_API_KEY", site="阿里云百炼 bailian.console.aliyun.com"),
    "glm": dict(name="智谱 GLM", base="https://open.bigmodel.cn/api/paas/v4", model="glm-4-flash", vision="glm-4v-flash",
                key="GLM_API_KEY", site="open.bigmodel.cn"),
    "kimi": dict(name="Kimi", base="https://api.moonshot.cn/v1", model="moonshot-v1-8k", vision="moonshot-v1-8k-vision-preview",
                 key="MOONSHOT_API_KEY", site="platform.moonshot.cn"),
    "doubao": dict(name="豆包（火山方舟）", base="https://ark.cn-beijing.volces.com/api/v3", model="", vision="",
                   key="ARK_API_KEY", site="console.volcengine.com/ark（模型名填推理接入点 ID）"),
    "siliconflow": dict(name="硅基流动", base="https://api.siliconflow.cn/v1", model="deepseek-ai/DeepSeek-V3", vision="Qwen/Qwen2.5-VL-72B-Instruct",
                        key="SILICONFLOW_API_KEY", site="cloud.siliconflow.cn"),
    "openai": dict(name="OpenAI", base="https://api.openai.com/v1", model="gpt-4o-mini", vision="gpt-4o-mini",
                   key="OPENAI_API_KEY", site="platform.openai.com"),
    "custom": dict(name="自定义兼容接口", base="", model="", vision="", key="CUSTOM_API_KEY", site="填 OpenAI 兼容接口的地址、模型名"),
}


def _read_env():
    env = {}
    try:
        for line in _env_file().read_text(encoding="utf-8-sig").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
            elif line.strip().startswith("sk-") and " " not in line.strip():
                env.setdefault("DEEPSEEK_API_KEY", line.strip())   # 文件里只写了密钥本身
    except OSError:
        pass
    return env


def settings(provider=None):
    """当前（或指定）服务商的设置：key、model、base、vision、provider、name。
    兼容旧版：只写了 DEEPSEEK_API_KEY / DEEPSEEK_MODEL / DEEPSEEK_BASE_URL 的照旧用 DeepSeek。"""
    env = _read_env()

    def get(k, d=""):
        return os.environ.get(k) or env.get(k) or d
    pid = provider or get("AI_PROVIDER", "deepseek")
    if pid not in PROVIDERS:
        pid = "deepseek"
    spec = PROVIDERS[pid]
    up = pid.upper()
    if pid == "deepseek":
        model = get("AI_MODEL_DEEPSEEK") or get("DEEPSEEK_MODEL", DEFAULT_MODEL)
        base = get("AI_BASE_DEEPSEEK") or get("DEEPSEEK_BASE_URL", spec["base"])
    else:
        model = get("AI_MODEL_" + up, spec["model"])
        base = get("AI_BASE_" + up, spec["base"])
    return dict(key=get(spec["key"]), model=model, base=str(base).rstrip("/"), vision=get("AI_VISION_" + up, spec["vision"]),
                provider=pid, name=spec["name"])


def save_settings(provider, key=None, model=None, base=None, vision=None):
    """改服务商设置：provider 同时设成当前使用的；key/model/base/vision 为 None 时不动，空串时清除。"""
    if provider not in PROVIDERS:
        raise ValueError("不认识的服务商")
    p = _env_file()
    p.parent.mkdir(parents=True, exist_ok=True)
    env = _read_env()
    env["AI_PROVIDER"] = provider
    up = provider.upper()
    for name, value in ((PROVIDERS[provider]["key"], key), ("AI_MODEL_" + up, model), ("AI_BASE_" + up, base), ("AI_VISION_" + up, vision)):
        if value is None:
            continue
        if str(value).strip():
            env[name] = str(value).strip()
        else:
            env.pop(name, None)
    p.write_text("".join(f"{k}={v}\n" for k, v in env.items()), encoding="utf-8")


def headers(ds=None):
    ds = ds or settings()
    return {"Content-Type": "application/json", "Authorization": "Bearer " + ds["key"]}


def json_unsupported(status, detail):
    """服务商不支持 JSON 模式时的报错（400 且提到 response_format / json）：调用方去掉 response_format 再试一次。"""
    d = str(detail or "").lower()
    return status == 400 and ("response_format" in d or "json" in d)


# DeepSeek 2026-04-24 公告：旧名 deepseek-chat / deepseek-reasoner 定于 2026-07-24 停用，现行文档已不再列出（无密钥未实测旧名是否还能调通）。
# 现行名 deepseek-flash（另有 deepseek-v4-pro），思考与否不再靠换模型名，而是请求里的 thinking 字段（默认开启）。
DEFAULT_MODEL = "deepseek-flash"
_LEGACY = {"deepseek-chat": False, "deepseek-reasoner": True}   # 旧名 → 当年对应的是否思考


def pick_model(think=None):
    """(模型名, 是否思考)。think=None 时跟随设置：旧名 deepseek-reasoner 视为要思考，其余不思考。
    设置里还写着旧名（用户的 deepseek.env / 环境变量）就自动换成 deepseek-flash。"""
    ds = settings()
    name = ds["model"]
    if ds["provider"] != "deepseek":   # 别家：用设置里的模型名；「深度思考」靠模型本身，不另发字段
        return name, bool(think)
    legacy = _LEGACY.get(name)
    if legacy is not None:
        name = DEFAULT_MODEL
    return name, (bool(legacy) if think is None else think)


def thinking_field(model, think):
    """DeepSeek 官方模型默认开思考，要不思考必须显式关；兼容服务（非 deepseek- 开头）不发这个字段。"""
    return {"thinking": {"type": "enabled" if think else "disabled"}} if model.startswith("deepseek-") else {}


def save_key(key):
    """给当前服务商存（或清除）密钥。"""
    save_settings(settings()["provider"], key=key or "")


def available():
    return bool(settings()["key"])


def chat_once(system, messages, model, on_text=None, on_think=None, cancel=None,on_packet=None, think=False):
    """一次流式请求，返回 (正文, 是否被截断)。think=True 走思考模式（原 deepseek-reasoner）。"""
    ds = settings()
    who = ds["name"]
    if not ds["key"]:
        raise AskError(f"还没有填 {who} 密钥")
    if not ds["base"] or not model:
        raise AskError(f"{who} 的接口地址或模型名没填：到设置里的「AI 服务」补上")
    msgs = [dict(role="system", content=system)] + [dict(role=m["role"], content=str(m["content"])) for m in messages[:12]]
    payload = dict(model=model, messages=msgs, temperature=0.2, stream=True, **thinking_field(model, think))
    if not think:   # 思考模式沿用原 reasoner 的做法：不开 JSON 模式、不限 max_tokens（思考模式下 temperature 不生效但不报错）
        payload["response_format"] = dict(type="json_object")
        payload["max_tokens"] = 8192
    for attempt in (0, 1):
        req = urllib.request.Request(ds["base"] + "/chat/completions", data=json.dumps(payload).encode("utf-8"), headers=headers(ds))
        try:
            resp = urllib.request.urlopen(req, timeout=300)   # noqa: S310  base 是用户自己的设置
            break
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            if attempt == 0 and "response_format" in payload and json_unsupported(e.code, detail):
                payload.pop("response_format")     # 这家不支持 JSON 模式：去掉再试，靠宽松解析
                continue
            raise AskError(f"{who} 返回 {e.code}：{detail}", e.code in (429, 500, 502, 503, 504), e.code == 429) from e
        except OSError as e:
            raise AskError(f"连接 {who} 失败：{e}", True) from e
    text, think, finish, done = "", 0, None, False
    try:
        with resp:
            for raw in resp:
                if cancel and cancel():
                    raise AskError("已取消")
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                if on_packet:
                    on_packet()
                data = line[5:].strip()
                if data == "[DONE]":
                    done = True
                    break
                try:
                    ch = (json.loads(data).get("choices") or [{}])[0]
                except ValueError:
                    continue
                delta = ch.get("delta") or {}
                if delta.get("content"):
                    text += delta["content"]
                    if on_text:
                        on_text(text)
                if delta.get("reasoning_content"):
                    think += len(delta["reasoning_content"])
                    if on_think:
                        on_think(think)
                finish = ch.get("finish_reason") or finish
    except OSError as e:
        raise AskError(f"连接中断：{e}", True) from e
    if not done and not finish:
        raise AskError("回答中途断开", True)
    return text, finish == "length"


class Engine:
    """一个分析引擎。测试时可以换成假的：只要有 ask(messages, ...) 就行。"""

    name = "deepseek"

    def __init__(self, system, cancel=None):
        self.system = system
        self.calls = 0
        self.cancel = cancel

    def ask(self, messages, deep=False, on_text=None, on_think=None, status=None,on_packet=None):
        model, think = pick_model(True if deep else None)

        def once():
            self.calls += 1
            return chat_once(self.system, messages, model, on_text, on_think, self.cancel,**({'on_packet':on_packet} if on_packet else {}), think=think)
        try:
            return once()
        except AskError as e:
            if not e.transient:
                raise
            if status:
                status("连接不稳定，正在重试…")
            time.sleep(4 if e.busy else 1.5)
            return once()


# ---------------------------------------------------------------- JSON
def lenient(t):
    """模型常见的 JSON 小毛病（只改字符串外面）：1.8×10⁻⁵、1.8×10^-5 这种数，裸写的分数 1/16，结尾多余的逗号。"""
    sup = "⁰¹²³⁴⁵⁶⁷⁸⁹"

    def fix(x):
        x = re.sub(r"(\d(?:\.\d+)?)\s*[×xX*]\s*10\s*\^\s*\(?\s*([-−]?\d+)\s*\)?", lambda m: f"{m.group(1)}e{m.group(2).replace('−', '-')}", x)
        x = re.sub(r"(\d(?:\.\d+)?)\s*[×xX*]\s*10([⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)", lambda m: m.group(1) + "e" + "".join("-" if c == "⁻" else "" if c == "⁺" else str(sup.index(c)) for c in m.group(2)), x)
        x = re.sub(r"([:\[,]\s*)(-?\d+(?:\.\d+)?\s*/\s*\d+(?:\.\d+)?)(?=\s*[,\]}])", r'\1"\2"', x)
        return re.sub(r",(\s*[}\]])", r"\1", x)
    out, seg, in_str, esc = "", "", False, False
    for ch in t:
        if in_str:
            out += ch
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        elif ch == '"':
            out += fix(seg) + ch
            seg = ""
            in_str = True
        else:
            seg += ch
    return out + fix(seg)


def parse_json(text):
    s = re.sub(r"```(?:json)?", "", str(text or ""))
    a, b = s.find("{"), s.rfind("}")
    if a < 0 or b < a:
        raise ValueError("模型没有返回 JSON")
    body = s[a:b + 1]
    try:
        return json.loads(body)
    except ValueError:
        return json.loads(lenient(body))


def try_parse(text):
    try:
        j = parse_json(text)
        return j if isinstance(j, dict) else None
    except ValueError:
        return None


def peek(text):
    """从还没写完的 JSON 里取出 summary 和 steps，给实时草稿用。"""
    from .figure.stream import peek_figure,without_figure
    figure=peek_figure(text)
    text=without_figure(text)
    def un(s):
        try:
            return json.loads('"' + re.sub(r"\\$", "", s) + '"')
        except ValueError:
            return s.replace("\\n", " ").replace('\\"', '"')

    def st(key):
        m = re.search(rf'"{key}"\s*:\s*"((?:[^"\\]|\\.)*)', text)
        return un(m.group(1)) if m else ""

    def arr(key):
        m = re.search(rf'"{key}"\s*:\s*\[', text)
        if not m:
            return []
        out, i = [], m.end()
        while i < len(text):
            ch = text[i]
            if ch == "]":
                break
            if ch == '"':
                s = re.match(r'"((?:[^"\\]|\\.)*)("?)', text[i:])
                out.append(un(s.group(1)))
                i += s.end()
                if not s.group(2):
                    break
                continue
            i += 1
        return out
    result = dict(topic=st("topic"), summary=st("summary"), knowns=arr("knowns"), steps=arr("steps"), answer=st("answer"))
    if figure:
        result["figure"] = figure
    return result


def unreadable(text, truncated):
    if not str(text or "").strip():
        return "你的上一条回复是空的。请直接输出要求的 JSON 对象（不要思考过程、不要 Markdown、不要解释）。"
    if truncated:
        return "你的上一条回复太长，被截断了，不是完整的 JSON。请重新输出一个更简短但完整的 JSON 对象：步骤写得精炼些，可选字段可以省略。"
    return f"你的上一条回复不是一个合法的 JSON 对象（开头是：{json.dumps(str(text).strip()[:120], ensure_ascii=False)}）。请只输出一个 JSON 对象：以 {{ 开头、以 }} 结尾，不要 Markdown 代码块、注释或解释文字。"


def repair_msg(errors):
    return "程序检查你的 JSON 时发现以下问题，请改正后重新输出完整的 JSON（只改有问题的部分，其余保持不变）：\n" + "\n".join(f"- {e}" for e in errors)


def ask_json(engine, first, check, repairs=2, status=None, **live):
    """问一个必须回 JSON 的问题，用 check 校验：不合格就把问题发回去修正（默认最多两轮，最后一轮允许深度思考）。

    check(json) → {ok, value} 或 {ok: False, errors, fallback?}；fallback 是去掉不合格的可选部分后仍可用的结果。
    """
    msgs = list(first) if isinstance(first, list) else [dict(role="user", content=first)]
    fallback, last = None, None
    for rnd in range(repairs + 1):
        text, trunc = engine.ask(msgs, deep=(rnd == 2), status=status, **live)
        js = try_parse(text)
        res = check(js) if js is not None else None
        conv = msgs + [dict(role="assistant", content=text)]
        if res and res.get("ok"):
            return dict(ok=True, value=res["value"], msgs=conv, repairs=rnd)
        if res and res.get("fallback"):
            fallback = dict(ok=True, value=res["fallback"], msgs=conv, repairs=rnd, dropped=res.get("errors"))
        last = (text, trunc, js, res)
        if rnd >= repairs:
            break
        if status:
            status(f"AI 的输出没有通过校验，正在让它修正（第 {rnd + 1} 次）…")
        msgs = msgs + [dict(role="assistant", content=text or "（空）"), dict(role="user", content=repair_msg(res["errors"]) if js is not None else unreadable(text, trunc))]
    if fallback:
        return fallback
    text, trunc, js, res = last
    if js is not None:
        msg = f"AI 的输出没有通过校验（已修正 {repairs} 次）：{'；'.join(res['errors'][:3])}"
    else:
        msg = "AI 的回答太长被截断，没有得到完整的 JSON" if trunc else f"AI 没有按要求输出 JSON（已重试 {repairs} 次）"
    raise AskError(msg, raw=str(text or "")[:1500])
