"""预习单窗口：上面选科目和章节，下面四张步骤卡（知识点 → 实验 → 讲解视频 → 课前小题），做完打勾。

也放着复习窗口共用的几个小部件：Card（圆角卡片）、Badge（步骤号 / 对勾）、Bar（进度条）、icon（线性图标）。
"""
from __future__ import annotations

import html

from PySide6.QtCore import QRectF, QSize, Qt, QUrl
from PySide6.QtGui import QDesktopServices, QIcon, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (QButtonGroup, QComboBox, QDialog, QFrame, QHBoxLayout, QLabel, QPushButton,
                               QScrollArea, QVBoxLayout, QWidget)

from . import preview
from .bank.fx import fx
from .design.icons import draw_icon
from .design.tokens import T, qc
from .design.widgets import qss


# ------------------------------------------------------------------ 共用小部件
def icon(name, color=None, size=16):
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    draw_icon(p, name, QRectF(0, 0, size, size), qc(color or T.soft), 1.5)
    p.end()
    return QIcon(pm)


def text(s, size=13, tone="fg", bold=False, rich=False, wrap=True):
    lb = QLabel(s)
    lb.setTextFormat(Qt.TextFormat.RichText if rich else Qt.TextFormat.PlainText)
    lb.setWordWrap(wrap)
    lb.setStyleSheet(f"color:{getattr(T, tone)};font-size:{size}px;{'font-weight:700;' if bold else ''}background:transparent;")
    if rich:
        lb.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    return lb


def button(label, kind="", ico=None, tip=""):
    b = QPushButton(label)
    if kind:
        b.setObjectName(kind)
    if ico:
        b.setIcon(icon(ico, T.stage if kind == "pri" else T.soft))
        b.setIconSize(QSize(15, 15))
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if tip:
        b.setToolTip(tip)
    return b


class Card(QFrame):
    """圆角卡片：raised 底色 + 一圈细线；done 时左边一条绿色。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.done = False
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(18, 14, 18, 16)
        self.lay.setSpacing(8)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(QPen(qc(T.line), 1))
        p.setBrush(qc(T.raised))
        p.drawRoundedRect(r, 10, 10)
        if self.done:
            path = QPainterPath()
            path.addRoundedRect(r, 10, 10)
            p.setClipPath(path)
            p.fillRect(QRectF(r.x(), r.y(), 3, r.height()), qc(T.ok))
        p.end()


class Badge(QWidget):
    """步骤号：没做完是细圈加数字，做完是实心绿底加对勾。给了 on_click 就能点（点圆圈打勾 / 取消）。"""

    def __init__(self, n, parent=None, on_click=None, current=False):
        super().__init__(parent)
        self.n, self.done, self.on_click, self.current = n, False, on_click, current
        self.setFixedSize(28, 28)
        if on_click:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, e):  # noqa: N802
        if self.on_click and e.button() == Qt.MouseButton.LeftButton:
            self.on_click()
        else:
            super().mousePressEvent(e)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(1, 1, 26, 26)
        if self.done:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.ok))
            p.drawEllipse(r)
            pen = QPen(qc(T.stage), 2)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            p.setPen(pen)
            path = QPainterPath()
            path.moveTo(8.5, 14.5)
            path.lineTo(12.5, 18.5)
            path.lineTo(19.5, 10.5)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
        else:
            p.setPen(QPen(qc(T.accent if self.current else T.line2), 1.8 if self.current else 1.4))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(r)
            p.setPen(qc(T.accent if self.current else T.soft))
            f = p.font()
            f.setPixelSize(13)
            f.setBold(True)
            p.setFont(f)
            p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), str(self.n))
        p.end()


class Bar(QWidget):
    """细进度条。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.value = 0.
        self.setFixedHeight(6)

    def set(self, v):
        self.value = max(0., min(1., v))
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        r = QRectF(self.rect())
        p.setBrush(qc(T.line))
        p.drawRoundedRect(r, 3, 3)
        if self.value > 0:
            p.setBrush(qc(T.ok if self.value >= 1 else T.accent))
            p.drawRoundedRect(QRectF(0, 0, max(6., r.width() * self.value), r.height()), 3, 3)
        p.end()


def tag(s, tone="accent"):
    lb = QLabel(s)
    c = getattr(T, tone)
    lb.setStyleSheet(f"color:{c};border:1px solid {c};border-radius:9px;padding:0 8px;font-size:11.5px;background:transparent;")
    lb.setFixedHeight(20)
    return lb


# ------------------------------------------------------------------ 外部入口
def open_video(query, subject="", host=None):
    """用系统浏览器打开 B 站搜索，并记一笔「看过视频」。返回打开的网址。"""
    url = preview.bili_url(query)
    if not getattr(host, "_no_browser", False):
        QDesktopServices.openUrl(QUrl(url))
    try:
        from . import learning
        learning.note("video", query, subject)
    except Exception:
        pass
    return url


def lecture_text(lid, pages=40):
    """一份课件的文字：优先用后台做的 text.pdf（原样出图的课件 doc.pdf 里没有字）。"""
    from PySide6.QtPdf import QPdfDocument
    from .lecture import library
    from .lecture.pageview import page_text
    d = library.folder(lid)
    out = []
    for name in ("text.pdf", "doc.pdf"):
        if not (d / name).is_file():
            continue
        doc = QPdfDocument()
        doc.load(str(d / name))
        out = [page_text(doc, i) for i in range(min(pages, doc.pageCount()))]
        doc.close()
        if "".join(out).strip():
            break
    return "\n".join(out)


def preview_lecture(host, meta, parent=None):
    """课件右键「预习这一课」。认不出知识点时返回 None（调用方提示一句）。"""
    sheet = preview.from_text(lecture_text(meta["id"]), meta.get("title") or "这一课")
    if sheet is None:
        return None
    preview.save(sheet)
    dialog = Preview(host, sheet, parent)
    dialog.exec()
    return sheet


# ------------------------------------------------------------------ 预习窗口
STEPS = (("cards", "读知识点", "定义、公式先过一遍，有个印象就行"),
         ("lab", "先玩一下实验", "动手拖一拖，看现象怎么变"),
         ("video", "看一段讲解", "B 站按播放量排序，挑一段 10–20 分钟的"),
         ("quiz", "课前小题", "只测概念，做完再看答案"))


class Preview(QDialog):
    def __init__(self, host=None, sheet=None, parent=None):
        super().__init__(parent if parent is not None else (host if hasattr(host, "isWidgetType") else None))
        self.host = host
        self.sheet = sheet or preview.current()
        self.shown = set()      # 展开了答案的题
        self.opened = []        # 打开过的外部链接（自测用）
        self.answers = {}       # qid → 答案标签
        self.seen = set()       # 看过答案的题
        self.expanded = set()   # 做完后又点开的步骤
        self.setObjectName("jw2")
        self.setStyleSheet(qss() + f"QScrollArea#pvScroll,QWidget#pvInner{{background:{T.bg};border:none;}}")
        self.setWindowTitle("预习")
        self.resize(780, 720)
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 18, 22, 14)
        root.setSpacing(12)

        # 科目：一排分段键
        subj = QHBoxLayout()
        subj.setSpacing(6)
        self.group = QButtonGroup(self)
        self.subj_btns = {}
        for s in preview.SUBJECTS:
            b = button(s, "seg")
            b.setCheckable(True)
            b.setFixedHeight(30)
            self.group.addButton(b)
            self.subj_btns[s] = b
            b.clicked.connect(lambda _=False, s=s: self.set_subject(s))
            subj.addWidget(b)
        subj.addStretch(1)
        root.addLayout(subj)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.chapter = QComboBox()
        self.chapter.setMinimumWidth(280)
        self.chapter.setFixedHeight(32)
        self.make = button("生成预习单", "pri", "spark")
        self.make.setFixedHeight(32)
        self.make.clicked.connect(self.generate)
        row.addWidget(text("章节", 12.5, "muted", wrap=False))
        row.addWidget(self.chapter, 1)
        row.addWidget(self.make)
        root.addLayout(row)

        self.scroll = QScrollArea()
        self.scroll.setObjectName("pvScroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root.addWidget(self.scroll, 1)
        self.status = text("", 12, "muted")
        root.addWidget(self.status)

        self.subject = (self.sheet or {}).get("subject") if (self.sheet or {}).get("subject") in preview.SUBJECTS else "数学"
        self.set_subject(self.subject)
        if self.sheet:
            i = self.chapter.findText(self.sheet.get("topic", ""))
            if i >= 0:
                self.chapter.setCurrentIndex(i)
        self.render()

    # ------------------------------------------------------------ 数据
    def set_subject(self, s):
        self.subject = s
        self.subj_btns[s].setChecked(True)
        self.chapter.clear()
        self.chapter.addItems(preview.chapters(s))

    def generate(self):
        try:
            self.sheet = preview.save(preview.make(self.subject, self.chapter.currentText()))
            self.shown.clear()
            self.seen.clear()
            self.expanded.clear()
            self.status.setText("已生成。按 1 → 4 做，蓝色按键就是下一步；点左边圆圈也能打勾。")
        except Exception as exc:  # noqa: BLE001
            self.status.setText(f"生成不了：{exc}")
        self.render()

    def _tick(self, part):
        if self.sheet:
            self.sheet = preview.tick(self.sheet["id"], part)

    def act(self, kind, arg=""):
        """所有按键走这里（自测也直接调它）。"""
        if not self.sheet and kind != "pick":
            return
        if kind == "do":
            self._tick(arg)
        elif kind == "toggle":          # 点圆圈：打勾 / 取消
            if arg in self.sheet.get("done", []):
                self.sheet = preview.untick(self.sheet["id"], arg)
            else:
                self._tick(arg)
        elif kind == "open":            # 点已折叠的步骤，展开看
            self.expanded ^= {arg}
        elif kind == "lab":
            try:
                self.host.open_lab(arg)
                self._tick("lab")
            except Exception as exc:  # noqa: BLE001
                self.status.setText(f"打不开实验：{exc}")
        elif kind == "video":
            self.opened.append(open_video(self.sheet["video"], self.sheet.get("subject", ""), self.host))
            self._tick("video")
            self.status.setText("已在浏览器打开 B 站搜索。")
        elif kind == "q":
            self.shown ^= {arg}
            self.seen.add(arg)
            if set(self.sheet.get("quiz", [])) <= self.seen and "quiz" not in self.sheet["done"]:
                self._tick("quiz")      # 每道题的答案都看过了，这一步就算做完
            else:
                lb = self.answers.get(arg)
                if lb is not None:      # 只切换这一题，不整页重建（不跳滚动位置）
                    lb.setVisible(arg in self.shown)
                    self.sender_btn(arg)
                    return
        elif kind == "review":
            from . import learning
            n = 0
            for name in self.sheet["cards"]:
                c = preview.card_by_name(name)
                if c:
                    learning.add_card(dict(c), c["s"])
                    n += 1
            self._tick("cards")         # 加入复习 = 读过了
            self.status.setText(f"已加入复习：{n} 个知识点，今天就到期。")
        elif kind == "pick":            # 空状态里点推荐章节
            i = self.chapter.findText(arg)
            if i >= 0:
                self.chapter.setCurrentIndex(i)
            self.generate()
            return
        self.render()

    def sender_btn(self, qid):
        b = self.answer_btns.get(qid)
        if b is not None:
            b.setText("收起答案" if qid in self.shown else "看答案")

    # ------------------------------------------------------------ 画面
    def render(self):
        y = self.scroll.verticalScrollBar().value()
        inner = QWidget()
        inner.setObjectName("pvInner")
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(0, 4, 8, 8)
        lay.setSpacing(12)
        self.answers, self.answer_btns, self.cards = {}, {}, {}
        sh = self.sheet
        if not sh:
            empty = Card()
            empty.lay.setContentsMargins(28, 34, 28, 34)
            empty.lay.addWidget(text("选一章开始预习", 17, "fg", True))
            empty.lay.addWidget(text("四步：读知识点、玩一下实验、看一段讲解、做三道课前小题。大约 15 分钟。", 13, "muted"))
            empty.lay.addSpacing(6)
            picks = QHBoxLayout()
            picks.setSpacing(8)
            for ch in preview.suggest(self.subject):
                b = button(ch, "")
                b.setFixedHeight(34)
                b.clicked.connect(lambda _=False, ch=ch: self.act("pick", ch))
                picks.addWidget(b)
            picks.addStretch(1)
            empty.lay.addLayout(picks)
            self.picks = [picks.itemAt(i).widget() for i in range(picks.count()) if picks.itemAt(i).widget()]
            lay.addWidget(empty)
            lay.addStretch(1)
            self.scroll.setWidget(inner)
            return
        done, total = preview.progress(sh)
        head = QHBoxLayout()
        head.addWidget(text(sh["title"], 20, "fg", True, wrap=False))
        head.addStretch(1)
        head.addWidget(text(f"完成 {done} / {total}", 12.5, "ok" if done == total else "muted", wrap=False))
        lay.addLayout(head)
        bar = Bar()
        bar.set(done / total if total else 0)
        lay.addWidget(bar)
        lay.addSpacing(4)
        n = 0
        todo = [p for p in preview.parts(sh) if p not in sh.get("done", [])]
        self.now = todo[0] if todo else ""      # 当前这一步：只有它有主键
        for part, title, sub in STEPS:
            if part not in preview.parts(sh):
                continue
            n += 1
            lay.addWidget(self._step(n, part, title, sub))
        lay.addStretch(1)
        self.scroll.setWidget(inner)
        self.scroll.verticalScrollBar().setValue(y)
        self.status.setText("四步都做完了。今天上课时留意这几个知识点。" if done == total else
                            self.status.text() if self.status.text().startswith(("已", "生成不了", "打不开")) else f"还差 {total - done} 步。")

    def _step(self, n, part, title, sub):
        sh = self.sheet
        is_done = part in sh.get("done", [])
        is_now = part == self.now
        folded = is_done and part not in self.expanded
        card = Card()
        card.done = is_done
        if folded:
            card.lay.setContentsMargins(18, 10, 18, 10)
        self.cards[part] = card
        top = QHBoxLayout()
        top.setSpacing(12)
        badge = Badge(n, on_click=lambda: self.act("toggle", part), current=is_now)
        badge.done = is_done
        badge.setToolTip("点圆圈：取消打勾" if is_done else "点圆圈：标成做完")
        self.badges = getattr(self, "badges", {})
        self.badges[part] = badge
        top.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)
        col = QVBoxLayout()
        col.setSpacing(2)
        col.addWidget(text(title, 15, "fg" if not is_done else "muted", True))
        if not folded:
            col.addWidget(text(sub, 12, "muted"))
        top.addLayout(col, 1)
        main = None
        if not folded and part == "lab":
            main = button("打开实验", "pri" if is_now else "", "lab")
            main.clicked.connect(lambda: self.act("lab", sh["lab"]))
        elif not folded and part == "video":
            main = button("去 B 站看", "pri" if is_now else "", "play")
            main.clicked.connect(lambda: self.act("video"))
        if main is not None:
            top.addWidget(main, 0, Qt.AlignmentFlag.AlignTop)
        if is_done:
            again = button("收起" if part in self.expanded else "再看看", "ghost")
            again.clicked.connect(lambda: self.act("open", part))
            top.addWidget(again, 0, Qt.AlignmentFlag.AlignTop)
        card.lay.addLayout(top)
        if folded:
            return card
        body = QVBoxLayout()
        body.setContentsMargins(40, 4, 0, 0)
        body.setSpacing(10)
        if part == "cards":
            for name in sh["cards"]:
                c = preview.card_by_name(name) or {}
                body.addWidget(text(name, 13.5, "fg", True))
                body.addWidget(text(fx(c.get("d", "")), 13, "soft", rich=True))
                if c.get("f"):
                    f = text("<br>".join(fx(x) for x in c["f"]), 12.5, "accent", rich=True)
                    f.setStyleSheet(f.styleSheet() + f"border-left:2px solid {T.line2};padding-left:10px;")
                    body.addWidget(f)
            add = button("读完了，加入复习", "pri" if is_now else "ghost", "plus",
                         "这几个知识点进复习计划，这一步打勾")
            add.clicked.connect(lambda: self.act("review"))
            body.addWidget(add, 0, Qt.AlignmentFlag.AlignLeft)
        elif part == "lab":
            body.addWidget(text(self._lab_title(sh["lab"]), 13.5, "soft"))
        elif part == "video":
            body.addWidget(text(f"搜索：{sh['video']}", 13, "soft"))
        elif part == "quiz":
            self._quiz(body, sh["quiz"])
            body.addWidget(text("每道题都看过答案，这一步自动打勾。", 11.5, "faint"))
        card.lay.addLayout(body)
        return card

    def _quiz(self, body, ids):
        try:
            from .bank.data import bank
            bank.load()
        except Exception:
            body.addWidget(text("题库读不到。", 13, "muted"))
            return
        for i, qid in enumerate(ids, 1):
            q = bank.by_id.get(qid)
            if not q:
                continue
            head = QHBoxLayout()
            head.setSpacing(8)
            head.addWidget(text(f"第 {i} 题", 13, "fg", True, wrap=False))
            head.addWidget(tag(q.get("type", "") or "题", "muted"))
            head.addStretch(1)
            b = button("收起答案" if qid in self.shown else "看答案", "ghost")
            b.clicked.connect(lambda _=False, qid=qid: self.act("q", qid))
            self.answer_btns[qid] = b
            head.addWidget(b)
            body.addLayout(head)
            body.addWidget(text(fx(q.get("stem", "")).replace("\n", "<br>"), 13, "soft", rich=True))
            ans = text("答案　" + fx(q.get("answer", "")) + (f"<br><span style='color:{T.muted}'>{fx(q['why'])}</span>" if q.get("why") else ""),
                       13, "fg", rich=True)
            ans.setStyleSheet(ans.styleSheet() + f"background:{T.surface};border-radius:8px;padding:8px 12px;")
            ans.setVisible(qid in self.shown)
            self.answers[qid] = ans
            body.addWidget(ans)

    @staticmethod
    def _lab_title(eid):
        try:
            from .kit.registry import lab
            lab.load()
            for e in lab.list:
                if e.id == eid:
                    return e.title
        except Exception:
            pass
        return eid
