"""Date rollback, idempotence, review UI, composition Clip and embedded collection."""
from .kit import test_runtime
test_runtime.configure()
import sys
from datetime import date,timedelta
from pathlib import Path
from types import SimpleNamespace


def main(output=None):
    app=test_runtime.application()
    from . import learning as l
    from .kit.home import home
    from .kit.clip import ClipBus,ClipStore
    from .kit.composition import collect,export
    from .kit.clip_ui import MaterialBasket
    from .learning_ui import Daily,Review
    from .bank.data import bank
    from PySide6.QtWidgets import QWidget
    from .design.widgets import qss
    out=Path(output or sys.argv[1])
    out.mkdir(parents=True,exist_ok=True)
    with test_runtime.isolated_data(out/'calendar'):
        start=date(2026,11,7)
        questions={'test':dict(title='测试题',subject='数学')}
        l.sync_questions(['test'],questions,start)
        assert not l.due(start)
        due=l.due(start+timedelta(days=1))
        assert len(due)==1
        key=due[0][0]
        first=l.grade(key,False,20,event_id='first',now=start+timedelta(days=1))
        assert first['due']=='2026-11-09'
        assert not l.due(start+timedelta(days=1))
        again=l.grade(key,True,20,event_id='double',now=start+timedelta(days=1))
        assert again==first and len(l.load()['events'])==1
        second=l.grade(key,True,10,now=start+timedelta(days=2))
        assert second['due']=='2026-11-12'
        # Backwards clock neither duplicates nor advances the last review day.
        assert l.grade(key,False,1,now=start)==second
        assert not l.due(start)
        l.sync_questions([],questions,start)
        assert not l.load()['items'][key]['active']
        l.sync_questions(['test'],questions,start)
        assert l.load()['items'][key]['active']
        card=l.add_card(dict(n='定义',d='内容',f=['式子'],p=[]),now=start+timedelta(days=2))
        assert card in dict(l.due(start+timedelta(days=2)))
        l.record('q','数学',30,True,'program',event_id='one',now=start+timedelta(days=2))
        l.record('q','数学',30,False,'program',event_id='one',now=start+timedelta(days=2))
        l.record('q2','生物',40,None,'ungraded',now=start+timedelta(days=2))
        row=l.daily(start+timedelta(days=2))[-1]
        assert row['graded']==1 and row['correct']==1 and row['attempts']==2 and row['self_review']==1
        assert row['subjects']=={'数学':2,'生物':1}
        path=home()/l.FILE
        path.write_text('{"v":99,"items":{},"events":[]}',encoding='utf-8')
        before=path.read_bytes()
        try:
            l.record('q','数学',1)
        except ValueError:
            pass
        else:
            raise AssertionError('future learning overwritten')
        assert path.read_bytes()==before
    with test_runtime.isolated_data(out/'ui'):
        bank.load()
        q=bank.questions[0]
        yesterday=date.today()-timedelta(days=1)
        l.sync_questions([q['id']],bank.by_id,yesterday)
        plan=Review()
        plan.show();app.processEvents()
        assert plan.current
        plan.grade(True)
        assert '先查看' in plan.status.text()
        plan.reveal()       # 0.3.10 起翻面走 reveal（空格键 / 「翻面看答案」），不再直接显示答案控件
        plan.grade(False)
        assert not l.due()
        plan.grab().save(str(out/'review-session.png'))
        plan.close()
        l.add_card(dict(n='知识卡测试',d='定义',f=['公式'],p=['注意条件']),subject='数学')
        holder=QWidget()
        holder.setObjectName('jw2');holder.setStyleSheet(qss())
        ctx=SimpleNamespace(cfg=dict(milestones=[dict(date=(date.today()+timedelta(days=3)).isoformat(),label='自定考试')]))
        daily=Daily(ctx,holder)
        from PySide6.QtWidgets import QVBoxLayout
        layout=QVBoxLayout(holder);layout.addWidget(daily)
        holder.resize(800,370);holder.show();app.processEvents()
        assert '3天' in daily.nodes.text() and '建议' in daily.nodes.text()
        assert '暂无可判定' in daily.details.text()
        holder.grab().save(str(out/'daily-learning.png'))
        holder.close()
        bus=ClipBus(store=ClipStore(home()/'clips'))
        payload=dict(kind='quote',data=dict(text='合成测试金句，不是真实引文',author='测试作者',source='测试来源'))
        first=collect(bus,payload)
        assert collect(bus,payload)['id']==first['id']
        assert len(bus.recent())==1 and bus.recent()[0]['pinned']
        collect(bus,dict(kind='term',data=dict(term='合成词条',definition='定义测试')))
        collect(bus,dict(kind='person',data=dict(name='合成人物',role='仅自测')))
        for i in range(35):
            c=bus.store.create(text=str(i),origin=dict(type='test'))
            bus.remember(c)
        assert len([r for r in bus.recent() if r['pinned']])==3
        host=QWidget();host.resize(900,650);host.show()
        basket=MaterialBasket(bus,host)
        basket.show();app.processEvents()
        basket.category.setCurrentIndex(1)
        assert basket.list.count()==3
        basket.search.setText('词条')
        assert basket.list.count()==1
        cid=basket.list.item(0).data(256)
        export(bus.store,[cid],out/'素材导出.md')
        assert '合成词条' in (out/'素材导出.md').read_text(encoding='utf-8')
        basket.grab().save(str(out/'composition-search.png'))
        basket.close();host.close()
        # Exercise actual Guanlan collection signal and theme rebuild, no fetch.
        import store
        old_home,old_g=store.HOME,store.GUANLAN_HOME
        store.HOME=home();store.GUANLAN_HOME=home()/'guanlan'
        try:
            from guanlan_host import GuanlanHost
            gh=GuanlanHost()
            caught=[]
            gh.on_material=lambda payload:caught.append(collect(bus,payload)['id'])
            window=gh.ensure()
            from ui.cards import QuoteCard,TermCard
            from ui.pages import PersonView
            from ui.base import TextButton
            for widget in (QuoteCard(payload['data']),TermCard(dict(term='按钮词条',definition='定义')),PersonView()):
                if isinstance(widget,PersonView):
                    widget.build(dict(name='按钮人物'),0,1,lambda:None,lambda:None,lambda _url:None)
                widget.collect_requested.connect(window.material_requested)
                button=next(b for b in widget.findChildren(TextButton) if b._text=='收素材')
                button.click()
                app.processEvents()
                widget.close()
            assert len(caught)==3
            window.set_theme('night')
            window.quotes_page.set_edition(dict(quotes=[dict(text='换主题后仍可收集',author='测试',source='自测')]))
            button=next(b for b in window.quotes_page.findChildren(TextButton) if b._text=='收素材')
            button.click()
            assert len(caught)==4
            window.close()
        finally:
            store.HOME,store.GUANLAN_HOME=old_home,old_g
    print('LEARNING OK intervals, day rollback, idempotence, source-aware stats, review UI, pinned composition/search/export and Guanlan signals',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(test_runtime.run(main))
