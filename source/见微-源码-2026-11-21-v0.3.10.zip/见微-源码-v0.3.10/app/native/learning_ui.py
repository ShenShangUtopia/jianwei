"""Review queue and a quiet daily summary, using existing application styles."""
import time
from datetime import date
from PySide6.QtCore import Qt,QRectF,QTimer
from PySide6.QtGui import QPainter
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QPlainTextEdit,QDialog
from . import learning
from .design.tokens import T,qc,font
from .design.widgets import qss


class History(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.rows=[]
        self.setMinimumHeight(115)

    def paintEvent(self,event):
        p=QPainter(self)
        p.setFont(font(12))
        maximum=max([1]+[r['count'] for r in self.rows])
        width=self.width()/max(1,len(self.rows))
        for i,row in enumerate(self.rows):
            x=i*width+12
            h=row['count']/maximum*65
            p.fillRect(QRectF(x,80-h,max(10,width-24),h),qc(T.accent))
            p.setPen(qc(T.fg))
            p.drawText(QRectF(x,83,width-24,22),int(Qt.AlignmentFlag.AlignCenter),row['day'][5:])
            p.drawText(QRectF(x,58-h,width-24,20),int(Qt.AlignmentFlag.AlignCenter),str(row['count']))
        p.end()


class Review(QDialog):
    """到期复习：一张一张过。先想 → 翻面 → 自评。空格翻面，1 没记住，2 记住了。"""

    def __init__(self,parent=None):
        super().__init__(parent)
        from .bank.data import bank
        from .preview_ui import Bar,Card,button,tag,text
        bank.load()
        self.bank=bank
        self.queue=learning.due()
        self.index=0
        self.current=None
        self.flipped=False
        self.query=''
        self.tally=[0,0]
        self.started=time.monotonic()
        self.setObjectName('jw2')
        self.setStyleSheet(qss())
        self.setWindowTitle('到期复习')
        self.resize(760,620)
        root=QVBoxLayout(self)
        root.setContentsMargins(24,20,24,16)
        root.setSpacing(12)
        top=QHBoxLayout()
        self.count=text('',12.5,'muted',wrap=False)
        self.kind=text('',12.5,'muted',True,wrap=False)
        self.skip=button('跳过','ghost','chevron_r','这次先不看，排期不变')
        top.addWidget(self.kind)
        top.addStretch(1)
        top.addWidget(self.count)
        top.addWidget(self.skip)
        root.addLayout(top)
        self.bar=Bar()
        root.addWidget(self.bar)
        self.hint=text('',12.5,'warn')
        self.hint.setStyleSheet(self.hint.styleSheet()+f'border-left:3px solid {T.warn};padding:4px 10px;')
        self.hint.hide()
        root.addWidget(self.hint)
        self.card=Card()
        self.card.lay.setContentsMargins(26,22,26,22)
        self.title=text('',19,'fg',True)
        self.card.lay.addWidget(self.title)
        self.front=self._browser()
        self.card.lay.addWidget(self.front,1)
        root.addWidget(self.card,3)
        self.answer=Card()
        self.answer.done=True
        self.answer.lay.setContentsMargins(26,16,26,18)
        self.answer.lay.addWidget(text('答案',12,'muted',True))
        self.answer_text=self._browser()
        self.answer.lay.addWidget(self.answer_text,1)
        self.answer.hide()
        root.addWidget(self.answer,3)
        row=QHBoxLayout()
        row.setSpacing(8)
        self.video=button('看讲解视频','ghost','play','用系统浏览器打开 B 站搜索，按播放量排序')
        self.flip=button('翻面看答案　空格','pri','',"先在心里答一遍，再翻面")
        # 两个自评键等宽等权：不把「记住了」做成主色，免得一律点它
        self.no=button('没记住','','','')
        self.yes=button('记住了','','','')
        self.no.setStyleSheet(f'QPushButton{{color:{T.bad};}}')
        self.yes.setStyleSheet(f'QPushButton{{color:{T.ok};}}')
        self.done_btn=button('完成','pri','','关掉复习窗口')
        for b in (self.flip,self.no,self.yes,self.done_btn):
            b.setMinimumWidth(150)
            b.setFixedHeight(38)
        self.video.clicked.connect(self.watch)
        self.skip.clicked.connect(self.next)
        self.flip.clicked.connect(self.reveal)
        self.no.clicked.connect(lambda:self.grade(False))
        self.yes.clicked.connect(lambda:self.grade(True))
        self.done_btn.clicked.connect(self.accept)
        row.addWidget(self.video)
        row.addStretch(1)
        for b in (self.flip,self.no,self.yes,self.done_btn):
            row.addWidget(b)
        root.addLayout(row)
        self.status=text('',11.5,'faint')
        root.addWidget(self.status)
        self.render()

    @staticmethod
    def _browser():
        from PySide6.QtWidgets import QTextBrowser,QFrame
        b=QTextBrowser()
        b.setFrameShape(QFrame.Shape.NoFrame)
        b.setStyleSheet(f'QTextBrowser{{background:transparent;color:{T.soft};font-size:14px;border:none;}}')
        b.setOpenLinks(False)
        return b

    def keyPressEvent(self,e):
        k=e.key()
        if k==Qt.Key.Key_Space and self.current is not None and not self.flipped:
            self.reveal()
        elif k==Qt.Key.Key_1 and self.flipped:
            self.grade(False)
        elif k==Qt.Key.Key_2 and self.flipped:
            self.grade(True)
        else:
            super().keyPressEvent(e)

    def _mode(self):
        self.flip.setVisible(self.current is not None and not self.flipped)
        self.no.setVisible(self.flipped)
        self.yes.setVisible(self.flipped)
        self.answer.setVisible(self.flipped)
        live=self.current is not None
        self.done_btn.setVisible(not live)
        self.video.setVisible(live)
        self.skip.setVisible(live)
        # 答案出来后正面让位，长答案不被裁
        lay=self.layout()
        lay.setStretchFactor(self.card,1 if self.flipped else 3)
        lay.setStretchFactor(self.answer,4)

    @staticmethod
    def _cue(card):
        """知识卡正面给一条线索：第一条公式只留左半边，让学生补全（像 Anki 的填空）。"""
        import re
        from .bank.fx import fx
        for f in card.get('f',[]):
            m=re.split(r'(⇒|⇔|=|→)',f,maxsplit=1)
            if len(m)==3 and m[0].strip():
                return (f"<p style='color:{T.muted}'>补全这条公式，再说出定义和一个易错点：</p>"
                        f"<p style='color:{T.accent};font-size:16px'>{fx(m[0].strip())} {m[1]} ______</p>")
        return f"<p style='color:{T.muted}'>先在心里说出：定义、公式、一个常见陷阱。</p>"

    def render(self):
        from .bank.fx import fx
        self.started=time.monotonic()
        self.flipped=False
        self.hint.hide()
        total=len(self.queue)
        self.bar.set(self.index/total if total else 1)
        if self.index>=total:
            self.current=None
            self.kind.hide()
            self.count.setText(f'{total} / {total}' if total else '')
            self.title.setText('今天的复习做完了' if total else '今天没有到期的项目')
            skipped=total-sum(self.tally)
            self.front.setHtml((f"<p>记住 {self.tally[1]} · 没记住 {self.tally[0]}"+(f" · 跳过 {skipped}" if skipped else '')+'</p>'
                                f"<p style='color:{T.muted}'>没记住的明天再来；跳过的下次打开还在。</p>") if total else
                               '<p>收藏的题、加入复习的知识卡会按 1、3、7、14、30 天的间隔排进来。</p>')
            self._mode()
            self.done_btn.setFocus()
            return
        key,item=self.queue[self.index]
        self.current=key
        self.count.setText(f'{self.index+1} / {total}')
        is_q=item['kind']=='question'
        self.kind.setText(('题目' if is_q else '知识卡')+(' · '+item['subject'] if item.get('subject') else ''))
        self.kind.show()
        self.no.setText('没记住 · 明天再来　1')
        self.yes.setText(f"记住了 · {learning.INTERVALS[min(4,max(-1,item.get('stage',-1))+1)]} 天后　2")
        self.title.setText(item['title'])
        self.query=self._query(item)
        self.video.setEnabled(bool(self.query))
        self.skip.setEnabled(True)
        self.flip.setEnabled(True)
        if learning.forgot(item) and self.query:
            # 上次没记住的，这次先看视频再想（ROADMAP §5.4）
            self.hint.setText('上次没记住。先点「看讲解视频」看一段，再回来想。')
            self.hint.show()
        if is_q:
            q=self.bank.by_id.get(item['ref'])
            if q:
                self.front.setHtml('<p>'+fx(q.get('stem','')).replace('\n','<br>')+'</p>')
                steps=''.join(f'<li>{fx(x)}</li>' for x in q.get('steps',[]))
                self.answer_text.setHtml(f"<p style='color:{T.fg}'><b>{fx(q.get('answer',''))}</b></p>"+(f'<ol>{steps}</ol>' if steps else ''))
            else:
                self.front.setHtml('<p>原题不在当前题库里了。记录还在，可以先跳过。</p>')
                self.answer_text.setHtml('')
                self.flip.setEnabled(False)
        else:
            card=item['card']
            self.front.setHtml(self._cue(card))
            parts=[f"<p style='color:{T.fg}'>{fx(card.get('d',''))}</p>"]
            if card.get('f'):
                parts.append(f"<p style='color:{T.accent}'>"+'<br>'.join(fx(x) for x in card['f'])+'</p>')
            if card.get('p'):
                parts.append(f"<p style='color:{T.muted}'>易错：</p><ul>"+''.join(f'<li>{fx(x)}</li>' for x in card['p'])+'</ul>')
            self.answer_text.setHtml(''.join(parts))
        self._mode()

    def grade(self,correct):
        if self.current is None:
            return
        if not self.flipped:
            self.status.setText('先查看答案并核对，再选择是否记住。')
            return
        try:
            item=learning.grade(self.current,correct,time.monotonic()-self.started)
            self.tally[bool(correct)]+=1
            self.status.setText('已更新，下次复习：'+item['due'])
        except Exception as exc:
            self.status.setText('未更新排期：'+str(exc))
            return
        self.next()

    def next(self):
        self.index+=1
        self.render()

    def reveal(self):
        if self.current is None:
            return
        self.flipped=True
        self._mode()
        self.yes.setFocus()

    def _query(self,item):
        """视频搜索词：知识卡用卡名；题目用它的第一个考点，没有就用标题。"""
        from . import preview
        subject=item.get('subject','')
        if item['kind']=='card':
            return preview.video_query((item.get('card') or {}).get('n') or item.get('title',''),subject)
        q=self.bank.by_id.get(item['ref']) or {}
        points=q.get('points') or []
        point=points[0] if points else q.get('title') or item.get('title','')
        return preview.video_query(point,subject or q.get('subject','')) if point else ''

    def watch(self):
        if not self.query:
            return
        from .preview_ui import open_video
        open_video(self.query,(self.queue[self.index][1].get('subject','') if self.current else ''),self)
        self.status.setText('已在浏览器打开 B 站搜索：'+self.query)


class Daily(QWidget):
    def __init__(self,ctx,parent=None):
        super().__init__(parent)
        self.ctx=ctx
        root=QVBoxLayout(self)
        root.setContentsMargins(0,0,0,0)
        # 「今天要做」一条：大数字 + 一个主键；下面一行预习进度；统计收进「学习记录」
        from ui_kit import Btn,lab
        from .preview_ui import Bar
        root.setSpacing(10)
        top=QHBoxLayout()
        top.setSpacing(14)
        self.big=lab('0',30,'INK',700)
        top.addWidget(self.big)
        col=QVBoxLayout()
        col.setSpacing(0)
        self.big_cap=lab('项到期',13,'INK',700)
        self.summary=lab('',11.5,'FAINT',wrap=True)
        col.addStretch(1);col.addWidget(self.big_cap);col.addWidget(self.summary);col.addStretch(1)
        top.addLayout(col,1)
        self.start=Btn('开始复习','primary','先想、再翻面、自评记住没有')
        self.start.setFixedWidth(120)
        self.start.clicked.connect(self.review)
        top.addWidget(self.start,0,Qt.AlignmentFlag.AlignVCenter)
        root.addLayout(top)
        pre=QHBoxLayout()
        pre.setSpacing(10)
        self.pre_line=lab('',12.5,'BODY')
        self.pre_bar=Bar()
        self.pre_bar.setFixedWidth(90)
        self.pre=Btn('预习','soft','选一章，生成预习单：知识点、实验、讲解视频、课前小题')
        self.pre.clicked.connect(self.preview)
        pre.addWidget(self.pre_line,1);pre.addWidget(self.pre_bar,0,Qt.AlignmentFlag.AlignVCenter);pre.addWidget(self.pre)
        root.addLayout(pre)
        self.nodes=lab('',11.5,'SOFT',wrap=True)
        root.addWidget(self.nodes)
        self.more=Btn('学习记录','','近七天的作答和复习')
        self.more.clicked.connect(self._toggle_more)
        root.addWidget(self.more,0,Qt.AlignmentFlag.AlignLeft)
        self.history=History()
        self.details=lab('',11.5,'SOFT',wrap=True)
        for w in (self.history,self.details):
            w.hide()
            root.addWidget(w)
        self.timer=QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(60000)
        self._stale=False
        self.refresh()

    def _tick(self):
        # 见微常驻托盘：看不见这张卡时不用每分钟读题库和记录，记一笔，等再显示时补刷
        if self.isVisible():
            self.refresh()
        else:
            self._stale=True

    def showEvent(self,event):
        super().showEvent(event)
        if self._stale:
            self._stale=False
            QTimer.singleShot(0,self.refresh)

    def refresh(self):
        try:
            from .bank.data import bank
            from .bank.study import Stars
            from .data_import import run_once
            run_once()
            bank.load()
            learning.sync_questions(Stars().ids,bank.by_id)
            rows=learning.daily()
            today=rows[-1]
            count=len(learning.due())
            self.big.setText(str(count))
            self.big_cap.setText('项到期' if count else '今天没有到期的')
            self.summary.setText(f"今天作答 {today['attempts']} 次、复习 {today['self_review']} 项" if today['count'] else
                                 '收藏的题、加入复习的知识卡会按间隔排进来')
            self.start.setEnabled(count>0)
            self.start.setToolTip('先想、再翻面、自评记住没有' if count else '今天没有到期的项目')
            rate=f"{today['correct']/today['graded']:.0%}（{today['graded']}次）" if today['graded'] else '暂无可判定的选择题'
            subjects='、'.join(f'{k} {v}次' for k,v in today['subjects'].items()) or '暂无记录'
            self.details.setText('选择题自动核对正确率：'+rate+'。\n科目分布：'+subjects+'。图中是每天作答和复习的次数。')
            self.history.rows=rows;self.history.update()
            from . import preview
            sheet=preview.current()
            if sheet:
                done,total=preview.progress(sheet)
                self.pre_line.setText(f"预习：{sheet['title']}，完成 {done} / {total}")
                self.pre_bar.set(done/total if total else 0)
                self.pre_bar.show()
                self.pre.setText('继续预习' if done<total else '预习下一章')
            else:
                self.pre_line.setText('课前花 15 分钟预习一章：知识点、实验、视频、小题')
                self.pre_bar.hide()
                self.pre.setText('选一章预习')
        except Exception:
            self.summary.setText('复习或学习记录暂不可读取，原文件已保留；可先到设置备份数据。')
            self.start.setEnabled(False)
        lines=[]
        for node in self.ctx.cfg.get('milestones') or []:
            try:
                gap=(date.fromisoformat(node['date'])-date.today()).days
            except (TypeError,KeyError,ValueError):
                continue
            if gap>=0:
                text=f"{node.get('label') or '自定节点'}：{node['date']}，还有{gap}天"
                if gap<=7:
                    text+='。建议先复习到期错题和薄弱知识卡，再安排新题。'
                lines.append((gap,text))
        self.nodes.setText('\n'.join(text for _,text in sorted(lines)[:3]) or '尚未添加考试节点；可在倒计时设置中填写自己的日期。')

    def _toggle_more(self):
        show=self.history.isHidden()
        self.history.setVisible(show)
        self.details.setVisible(show)
        self.more.setText('收起学习记录' if show else '学习记录')

    def review(self):
        dialog=Review(self)
        dialog.exec()
        self.refresh()

    def preview(self):
        from .preview_ui import Preview
        Preview(self.ctx,parent=self).exec()
        self.refresh()


def card(ctx):
    # The host calls this after QApplication exists, matching ui_kit's contract.
    from ui_kit import Card
    item=Card('复习与预习','间隔 1、3、7、14、30 天')
    item.add(Daily(ctx))
    return item
