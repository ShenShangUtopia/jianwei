"""读文自测（离屏，不联网）：分句、离线词表、AI 结果校验与对齐、页面实时流程（假 DeepSeek）、失败路径、截图。

python -m native.reading.selftest <输出目录>
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

from ..kit import test_runtime


def _fake_result(lang, batch):
    from . import classical, english
    out = {}
    for b in batch:
        if lang == "wyw":
            toks = [dict(w=ch, pos="名词", sense=f"「{ch}」的本句义", kind="实词" if ch in classical.SHICI else "虚词" if ch in classical.XUCI else "一般")
                    for ch in b["text"] if ch not in classical.PUNCT and not ch.isspace()]
            out[b["id"]] = dict(translation=f"译文：{b['text']}", patterns=[dict(type="判断句", mark="者……也", note="测试")], tokens=toks)
        else:
            toks = [dict(w=w, lemma=w.lower(), pos="n.", sense=f"{w} 的意思", role="主语" if i == 0 else "谓语" if i == 1 else "状语")
                    for i, (_, _, w) in enumerate(english.words(b["text"]))]
            out[b["id"]] = dict(translation="中文译文", structure="主语 + 谓语", tokens=toks,
                                clauses=[dict(text="who had waited", type="定语从句", note="修饰 villagers")], patterns=[])
    return out


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    from PySide6.QtCore import QCoreApplication, QEvent
    from PySide6.QtGui import QTextCursor
    from ..analysis import llm
    from ..design import tokens
    from . import analyze, classical, english
    checks, bad = [], []

    def check(name, ok, info=""):
        checks.append(("OK  " if ok else "FAIL") + " " + name + (f"  ({info})" if info and not ok else ""))
        if not ok:
            bad.append(name)

    # ---- 分句
    t = "Mr. Smith paid $3.5 for it. Really? Yes!"
    sp = [t[a:b] for a, b in analyze.split_sentences(t, english.END)]
    check("英语分句跳过缩写和小数", sp == ["Mr. Smith paid $3.5 for it.", "Really?", "Yes!"], sp)
    w = "师者，所以传道受业解惑也。“孰能无惑？”惑而不从师"
    sp = [w[a:b] for a, b in analyze.split_sentences(w, classical.END)]
    check("文言分句：引号跟着上一句，未写完的最后一句单独成句", sp == ["师者，所以传道受业解惑也。", "“孰能无惑？”", "惑而不从师"], sp)
    long_ = "，".join(["学而时习之"] * 40) + "。"
    check("没有句号的长段落按逗号切开", all(b - a <= analyze.LONG for a, b in analyze.split_sentences(long_, classical.END)))

    # ---- 离线
    check("词表规模", len(classical.SHICI) >= 110 and len(classical.XUCI) == 18 and len(classical.TONGJIA) >= 40,
          (len(classical.SHICI), len(classical.XUCI), len(classical.TONGJIA)))
    s = analyze.offline("wyw", "师者，所以传道受业解惑也。")[0]
    kinds = {x["w"]: x["kind"] for x in s["tokens"]}
    check("离线：所以＝古今异义、也＝虚词、道＝实词", kinds.get("所以") == "古今异义" and kinds.get("也") == "虚词" and kinds.get("道") == "实词", kinds)
    check("离线：认出「者……也」判断句", any(p["type"] == "判断句" for p in s["patterns"]))
    check("离线 token 位置和原文一致", all(s["text"][x["start"]:x["end"]] == x["w"] for x in s["tokens"]))
    check("离线：通假只作提示，不画线", all(x["kind"] != "通假" for x in s["tokens"]) and any("有时通「授」" in o for x in s["tokens"] for o in x["other"]))
    e = analyze.offline("en", "She has been invited to speak. I am looking forward to seeing you.")
    check("英语时态：现在完成时被动", "现在完成时（被动）" in [p["mark"] for p in e[0]["patterns"]], e[0]["patterns"])
    check("英语短语：动词变形也认（looking forward to）", [x["w"] for x in e[1]["tokens"] if x["kind"] == "短语"] == ["looking", "forward", "to"])

    # ---- 校验与合并
    batch = [dict(id=0, text="师者，所以传道受业解惑也。")]
    good = _fake_result("wyw", batch)
    r = analyze.check("wyw", batch)(dict(sentences=[dict(good[0], id=0)]))
    check("校验：逐字对得上就通过", r.get("ok"), r)
    broken = dict(good[0], id=0, tokens=good[0]["tokens"][:-2])
    r = analyze.check("wyw", batch)(dict(sentences=[broken]))
    check("校验：少字就报错并给出只留翻译的结果", not r["ok"] and r["fallback"] and r["fallback"][0]["tokens"] == [], r.get("errors"))
    m = analyze.merge("wyw", analyze.offline("wyw", batch[0]["text"])[0], good[0])
    check("合并：位置按原文对齐、保留考纲义项", all(batch[0]["text"][x["start"]:x["end"]] == x["w"] for x in m["tokens"])
          and any(x["other"] for x in m["tokens"] if x["w"] == "道"))
    eb = [dict(id=0, text="It's a well-known fact, isn't it?")]
    er = _fake_result("en", eb)
    er[0]["tokens"][2] = dict(w="well-known", sense="著名的", role="定语")     # AI 把连字符词写成一个：也要对得上
    er[0]["tokens"].pop(3)
    r = analyze.check("en", eb)(dict(sentences=[dict(er[0], id=0)]))
    check("校验：英语连字符词按同样规则切分", r.get("ok"), r.get("errors"))
    me = analyze.merge("en", analyze.offline("en", eb[0]["text"])[0], er[0])
    check("合并：英语逐词对齐", [x["w"] for x in me["tokens"]] == ["It's", "a", "well", "known", "fact", "isn't", "it"]
          and me["tokens"][2]["sense"] == me["tokens"][3]["sense"] == "著名的")

    # ---- 页面：假 DeepSeek，实时流程
    calls = []

    def fake_ask(lang, b, context, engine=None, status=None):
        calls.append([x["text"] for x in b])
        time.sleep(0.05)
        return _fake_result(lang, b)

    real_ask, real_avail = analyze.ask, llm.available
    analyze.ask, llm.available = fake_ask, (lambda: True)
    try:
        from .page import ReadingPage
        page = ReadingPage()
        page.resize(1280, 760)
        page.show()

        def settle(limit=6.0):
            t0 = time.time()
            while time.time() - t0 < limit:
                app.processEvents()
                QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
                if page.worker is None and not page._ai.isActive() and not page._off.isActive() and not page._todo(True):
                    break
                time.sleep(0.02)
            for _ in range(5):
                app.processEvents()

        page.set_lang("wyw")
        page.load_sample()
        settle()
        states = [s["state"] for s in page.sents]
        check("文言：写完整的句子都自动精析了", states and all(x == "ai" for x in states), states)
        check("文言：一批不超过 BATCH 句", calls and max(len(c) for c in calls) <= analyze.BATCH, calls)
        n_calls = len(calls)
        page.run_offline()
        settle(1)
        check("已精析的句子走缓存，不再请求", len(calls) == n_calls)
        text = page.edit.toPlainText()
        pos = text.index("道")
        c = page.edit.textCursor()
        c.setPosition(pos)
        page.edit.setTextCursor(c)
        app.processEvents()
        html_ = page.detail.toHtml()
        check("光标所在字的详解：本句义 + 考纲义项 + 译文", "「道」的本句义" in html_ and "考纲里的常见义项" in html_ and "译文" in html_)
        page.grab().save(str(out / "reading-wyw-day.png"))

        # 改一句：只有这一句回到离线、重新精析
        c.setPosition(text.index("惑也") + 1)
        page.edit.setTextCursor(c)
        page.edit.insertPlainText("之")
        app.processEvents()
        page.run_offline()
        st = {s["text"]: s["state"] for s in page.sents}
        changed = [k for k in st if "惑之也" in k]
        check("改过的句子回到离线，其余仍是精析结果", changed and st[changed[0]] in ("offline", "pending")
              and sum(1 for v in st.values() if v == "ai") == len(st) - 1, st)
        page.edit.clearFocus()
        settle()
        check("改过的句子重新精析", all(s["state"] == "ai" for s in page.sents))

        # 没写完的最后一句：光标还在里面时不送，点「精析全文」才送
        page.edit.setFocus()
        cur = page.edit.textCursor()
        cur.movePosition(QTextCursor.MoveOperation.End)
        page.edit.setTextCursor(cur)
        page.edit.insertPlainText("今之众人")
        page.run_offline()
        page.schedule_ai()
        settle(1)
        last = page.sents[-1]
        check("光标还在没写完的句子里时不送精析", last["text"] == "今之众人" and last["state"] == "offline", last["state"])
        page.analyze_all()
        settle()
        check("精析全文：没写完的那句也送", page.sents[-1]["state"] == "ai")

        # 失败路径
        def boom(*_a, **_k):
            raise llm.AskError("测试用的连接失败", True)
        analyze.ask = boom
        page.edit.insertPlainText("，其下圣人也亦远矣。")
        page.edit.clearFocus()
        settle()
        check("精析失败：这一句标成失败，状态栏给原因", page.sents[-1]["state"] == "error" and "测试用的连接失败" in page.status.text(),
              (page.sents[-1]["state"], page.status.text()))
        analyze.ask = fake_ask
        page.analyze_all()
        settle()
        check("精析全文会重试失败的句子", page.sents[-1]["state"] == "ai")

        # 英语
        page.set_lang("en")
        page.load_sample()
        page.edit.clearFocus()
        settle()
        check("英语：全部精析", all(s["state"] == "ai" for s in page.sents), [s["state"] for s in page.sents])
        t2 = page.edit.toPlainText()
        c = page.edit.textCursor()
        c.setPosition(t2.index("villagers") + 2)
        page.edit.setTextCursor(c)
        app.processEvents()
        h2 = page.detail.toHtml()
        check("英语详解：词义、成分、从句", "villagers 的意思" in h2 and "状语" in h2 and "定语从句" in h2)
        kinds = {t["kind"] for t in page.edit.tokens}
        check("英语下划线按成分分组", {"主干", "修饰"} <= kinds, kinds)
        page.grab().save(str(out / "reading-en-day.png"))

        # 草稿：换语种、重开都还在
        page.set_lang("wyw")
        check("换回文言，草稿还在", "今之众人" in page.edit.toPlainText())
        page2 = ReadingPage(compact=True)
        check("重开页面：上次的语种和文字都在", page2.lang == "wyw" and "今之众人" in page2.edit.toPlainText())
        page2.close()
        page2.deleteLater()

        # 三种皮肤 × 昼夜
        for skin in ("ink", "celadon", "doodle"):
            for theme in ("day", "night"):
                tokens.set_skin(skin)
                tokens.set_theme(theme)
                page.apply_theme()
                page.run_offline()
                app.processEvents()
                page.grab().save(str(out / f"reading-wyw-{skin}-{theme}.png"))
        tokens.set_skin("ink")
        tokens.set_theme("day")
        page.apply_theme()
        page.stop()
        page.close()
        page.deleteLater()
    finally:
        analyze.ask, llm.available = real_ask, real_avail

    # ---- 没有密钥：只用离线，不请求
    calls.clear()
    llm_avail = llm.available
    llm.available = lambda: False
    try:
        from .page import ReadingPage
        p3 = ReadingPage()
        p3.set_text("学而时习之，不亦说乎？", "wyw")
        p3.schedule_ai(True)
        app.processEvents()
        check("没有密钥：不请求，状态栏说明", not calls and "离线" in p3.status.text(), p3.status.text())
        check("没有密钥：句子仍有离线标注", any(t["kind"] for t in p3.edit.tokens))
        check("外部送进来的英文自动切到英语", (p3.set_text("This is a test.") or p3.lang) == "en")
        p3.set_text("It is an infor-\nmation age,  and\nwe live in it.\n\nNew paragraph.")
        check("课件英文：版面换行接回、连字符断词接回、空行分段",
              p3.edit.toPlainText() == "It is an information age, and we live in it.\nNew paragraph.", repr(p3.edit.toPlainText()))
        p3.edit.undo()
        check("整段替换能撤销回原来的内容", p3.edit.toPlainText() == "This is a test.", repr(p3.edit.toPlainText()))
        c = p3.edit.textCursor()
        c.movePosition(QTextCursor.MoveOperation.End)
        p3.edit.setTextCursor(c)
        p3.edit.insertPlainText("\nSecond line.")
        p3.edit.spacing()
        p3.edit.undo()
        check("打字（含换行调行距）后 Ctrl+Z 有用", p3.edit.toPlainText() == "This is a test.", repr(p3.edit.toPlainText()))
        p3.set_text("师 者 ， 所 以 传 道\n受 业 解 惑 也 。\n人 非 生 而 知 之 者")
        check("课件文言：字间空格去掉、句末换行分段", p3.lang == "wyw" and p3.edit.toPlainText() == "师者，所以传道受业解惑也。\n人非生而知之者",
              repr(p3.edit.toPlainText()))
        p3.close()
        p3.deleteLater()
    finally:
        llm.available = llm_avail

    ok = not bad
    (out / "reading-result.txt").write_text(("OK" if ok else "FAIL") + "\n" + "\n".join(checks), encoding="utf-8")
    print("\n".join(checks))
    print("READING", "OK" if ok else "FAIL", len(checks), "checks", flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(test_runtime.run(main))
