"""读文的分析核心（不依赖 Qt）：分句、离线标注、DeepSeek 逐句精析、校验、合并、缓存。

流程：文本一变就整段离线标注（毫秒级）；句子写完整了（遇到句末标点，或停手一会儿）才把它送去 DeepSeek，
几句一批。AI 的结果按「语种 + 句子原文」缓存在数据目录，同一句不会问第二次。
AI 给的每个字词必须和原句逐个对得上，对不上就让它改；改不对的句子只留翻译和句式，字词仍用离线结果。
"""
from __future__ import annotations

import json
import re
import threading

from ..kit.home import load_json, save_json
from . import classical, english

LANGS = {"wyw": "文言文", "en": "英语"}
CACHE_FILE = "reading-cache.json"
CACHE_MAX = 3000
BATCH = 3                # 一次请求最多几句：句子少，回得快，界面一句一句亮起来
LONG = 160               # 没有句末标点的长段落，按逗号切到这个长度以内

_ABBR = re.compile(r"(?:\b(?:Mr|Mrs|Ms|Dr|St|Prof|Jr|Sr|vs|etc|e\.g|i\.e|No)|\b[A-Z])\.$")


def split_sentences(text: str, ends: str) -> list[tuple[int, int]]:
    """按句末标点切句，返回 [(start, end)]；句末的引号、括号跟着上一句。英语跳过缩写和小数点。"""
    spans, start, i, n = [], 0, 0, len(text)
    closers = "”’」』）)\"'"
    while i < n:
        ch = text[i]
        cut = False
        if ch in ends or ch == "\n":
            cut = True
            if ch == "." and (_ABBR.search(text[max(0, i - 6):i + 1]) or (i + 1 < n and text[i + 1].isdigit())):
                cut = False
        if cut:
            j = i + 1
            while j < n and (text[j] in ends or text[j] in closers):
                j += 1
            spans.append((start, j))
            start = i = j
            continue
        i += 1
    if start < n:
        spans.append((start, n))
    out = []
    for a, b in spans:
        while a < b and text[a].isspace():
            a += 1
        while b > a and text[b - 1].isspace():
            b -= 1
        if b <= a:
            continue
        while b - a > LONG:             # 太长：在 LONG 以内最后一个逗号处切
            cut = max(text.rfind(c, a, a + LONG) for c in "，,；;")
            if cut <= a:
                break
            out.append((a, cut + 1))
            a = cut + 1
            while a < b and text[a].isspace():
                a += 1
        if b > a:
            out.append((a, b))
    return out


def tidy(text: str, lang: str) -> str:
    """把课件 / 截图识别出来的字接回成段：版面换行去掉，空行和句末标点后的换行当分段。
    文言去掉字间空格（PDF 常把每个字分开排）；英语行尾连字符断开的词接回（infor-\\nmation）。"""
    text = str(text or "").replace("\r\n", "\n").replace("\r", "\n").replace("　", " ")
    ends = classical.END + "”」』" if lang == "wyw" else english.END + "\"”"
    paras, cur = [], []
    for line in text.split("\n"):
        s = line.strip()
        if not s:
            if cur:
                paras.append(cur)
                cur = []
            continue
        cur.append(s)
        if lang == "wyw" and s[-1] in ends:
            paras.append(cur)
            cur = []
    if cur:
        paras.append(cur)
    out = []
    for lines in paras:
        if lang == "wyw":
            p = "".join(lines)
            p = re.sub(r"(?<=[^\x00-\x7f])\s+(?=[^\x00-\x7f])", "", p)
        else:
            p = ""
            for s in lines:
                if p.endswith("-") and len(p) > 1 and p[-2].isalpha() and s[:1].islower():
                    p = p[:-1] + s
                else:
                    p = (p + " " + s) if p else s
            p = re.sub(r"[ \t]{2,}", " ", p)
        out.append(p)
    return "\n".join(out)


def offline(lang: str, text: str) -> list[dict]:
    return (classical if lang == "wyw" else english).offline(text)


def complete(lang: str, s: dict, text: str, typing_at: int | None) -> bool:
    """这句写完了吗：以句末标点结尾，或者光标不在这句里（用户已经在别处了）。"""
    ends = classical.END if lang == "wyw" else english.END
    tail = s["text"].rstrip("”’」』）)\"' ")
    if tail and tail[-1] in ends:
        return True
    return typing_at is None or not (s["start"] <= typing_at <= s["end"] + 1)


# ---------------------------------------------------------------- 缓存
class Cache:
    def __init__(self):
        self._lock = threading.Lock()
        self.data = load_json(CACHE_FILE, {}) or {}
        if not isinstance(self.data, dict):
            self.data = {}

    @staticmethod
    def key(lang, sentence):
        return lang + "\x1f" + sentence.strip()

    def get(self, lang, sentence):
        return self.data.get(self.key(lang, sentence))

    def put(self, lang, sentence, value):
        with self._lock:
            self.data[self.key(lang, sentence)] = value
            if len(self.data) > CACHE_MAX:
                for k in list(self.data)[:len(self.data) - CACHE_MAX]:
                    del self.data[k]
            save_json(CACHE_FILE, self.data)


_shared: Cache | None = None


def shared_cache() -> Cache:
    """整个进程共用一份缓存（主窗口和学习窗口的读文页、请求线程都用它），免得几份各写各的互相覆盖。"""
    global _shared
    if _shared is None:
        _shared = Cache()
    return _shared


# ---------------------------------------------------------------- 提示词
SYSTEM = {
    "wyw": """你是经验丰富的高中语文老师，帮学生逐字精读文言文。只输出一个 JSON 对象，不要 Markdown、不要解释。
格式：
{"sentences":[{"id":句子编号,"translation":"准确通顺的现代汉语译文（直译为主）",
 "patterns":[{"type":"判断句|被动句|宾语前置|定语后置|状语后置|主谓倒装|省略句|固定句式|其他","mark":"标志词或结构","note":"一句话说明"}],
 "tokens":[{"w":"原文的字或词","pos":"词性","sense":"在本句中的意思","kind":"实词|虚词|通假|古今异义|词类活用|固定结构|专有名词|一般","usage":"用法要点，可空","note":"补充，可空","pinyin":"多音字、生僻字给拼音，否则空"}]}]}
规则：
1. tokens 按原句顺序；把所有 w 连起来，必须一字不差地等于原句去掉标点和空格后的文字。每个字都要覆盖，不能跳过、合并错位或改字。
2. 一般按单字切分；双音节词、古今异义词、固定结构（如「所以」「何以」「无乃……乎」中连着的部分）、人名地名可以作为一个 w。
3. sense 写本句中的具体意思；通假写「通『X』，……」；词类活用在 usage 写清（如「名词作状语，像狗一样」「使动用法，使……」）。
4. kind 选最能帮学生的一项：考纲 18 虚词标「虚词」，有考点的实词标「实词」，没有考点的普通字标「一般」。
5. 没有特殊句式时 patterns 给空数组。""",
    "en": """You are an experienced English teacher in a Chinese senior high school, helping a student read an English passage word by word. Output exactly one JSON object, no Markdown, no explanation. All explanations in Simplified Chinese.
Format:
{"sentences":[{"id":sentence id,"translation":"准确通顺的中文译文",
 "structure":"句子主干，用原文词语标出成分，如：The man（主语）+ gave（谓语）+ me（间接宾语）+ a book（直接宾语）",
 "patterns":[{"type":"时态|语态|从句|非谓语|倒装|强调句|虚拟语气|独立主格|省略|其他","mark":"原文中的标志","note":"一句话说明"}],
 "clauses":[{"text":"从句原文","type":"定语从句|宾语从句|主语从句|表语从句|同位语从句|状语从句（时间/原因/条件/让步/目的/结果/方式/比较）","note":"修饰谁或在句中作什么，引导词在从句中作什么"}],
 "tokens":[{"w":"原文单词","lemma":"原形","pos":"词性","sense":"本句中的中文意思","role":"句子成分（主语/谓语/宾语/表语/定语/状语/补语/同位语/引导词/…）","usage":"语法要点，可空","phrase":"所在固定搭配，可空"}]}]}
Rules:
1. tokens must list EVERY word of the sentence in order, punctuation excluded. A contraction such as don't or it's is ONE word; hyphenated words are split at the hyphen into separate words; numbers are one word.
2. The sequence of w must equal the words of the original sentence exactly (same spelling).
3. phrase is ONLY for real fixed collocations / phrasal verbs (look forward to, in spite of, give up); leave it empty for tense forms (has lived), ordinary prepositional phrases (for 3.5 years) and articles.
4. Use empty arrays when there is no clause or special pattern.""",
}


def prompt(lang: str, batch: list[dict], context: str) -> str:
    lines = "\n".join(f"[{s['id']}] {s['text']}" for s in batch)
    ctx = context.strip()
    if len(ctx) > 1500:
        ctx = ctx[:1500] + "……"
    return (f"全文（供理解上下文，只分析下面编号的句子）：\n{ctx}\n\n要分析的句子：\n{lines}\n\n"
            f"请按格式为这 {len(batch)} 句各给一个对象，id 与编号一致。")


# ---------------------------------------------------------------- 校验
def _letters(s):
    """英语比对只看字母数字：I'm 切成 I + 'm、well-known 写成一个词、Mr 少了点，都算对得上。"""
    return "".join(ch.lower() for ch in s if ch.isalnum())


def _plain(lang, s):
    if lang == "wyw":
        return "".join(ch for ch in s if ch not in classical.PUNCT and not ch.isspace())
    return _letters(s)


def _ai_words(lang, toks):
    ws = [str(t.get("w", "")) for t in toks if isinstance(t, dict)]
    if lang == "wyw":
        return "".join(w.strip() for w in ws)
    return _letters("".join(ws))


def check(lang: str, batch: list[dict]):
    """给 llm.ask_json 用：每句都要有翻译，字词要和原句对得上。对不上的句子在 fallback 里去掉 tokens。"""
    want = {s["id"]: s["text"] for s in batch}

    def run(js):
        rows = js.get("sentences") if isinstance(js, dict) else None
        if not isinstance(rows, list):
            return dict(ok=False, errors=["缺少 sentences 数组"])
        got, errors, partial = {}, [], {}
        for r in rows:
            if not isinstance(r, dict) or r.get("id") not in want:
                continue
            sid = r["id"]
            text = want[sid]
            toks = r.get("tokens") if isinstance(r.get("tokens"), list) else []
            good = dict(r)
            if not str(r.get("translation", "")).strip():
                errors.append(f"第 {sid} 句没有 translation")
            if _ai_words(lang, toks) != _plain(lang, text):
                exp = _plain(lang, text)
                if lang == "en":
                    exp = " ".join(w for _, _, w in english.words(text))
                errors.append(f"第 {sid} 句的 tokens 连起来和原句对不上：原句应为「{exp}」")
                good = dict(r, tokens=[])
            got[sid] = r
            partial[sid] = good
        for sid in want:
            if sid not in got:
                errors.append(f"缺少第 {sid} 句")
        if not errors:
            return dict(ok=True, value=got)
        usable = {k: v for k, v in partial.items() if str(v.get("translation", "")).strip()}
        return dict(ok=False, errors=errors, fallback=usable or None)
    return run


def ask(lang: str, batch: list[dict], context: str, engine=None, status=None):
    """问 DeepSeek 一批句子。返回 {id: 结果}；不合格的句子 tokens 为空（只留翻译和句式）。"""
    from ..analysis import llm
    engine = engine or llm.Engine(SYSTEM[lang])
    r = llm.ask_json(engine, prompt(lang, batch, context), check(lang, batch), repairs=1, status=status)
    return r["value"]


# ---------------------------------------------------------------- 合并
def _str(x):
    return str(x or "").strip()


def merge(lang: str, s: dict, ai: dict) -> dict:
    """把 AI 对一句的结果套到离线结果上：位置按原文重新对齐，离线词表里的「其他义项」保留。"""
    out = dict(s, translation=_str(ai.get("translation")), state="ai")
    pats = [dict(type=_str(p.get("type")), mark=_str(p.get("mark")), note=_str(p.get("note")), src="ai")
            for p in ai.get("patterns") or [] if isinstance(p, dict) and _str(p.get("type"))]
    out["patterns"] = pats
    if lang == "en":
        out["structure"] = _str(ai.get("structure"))
        out["clauses"] = [dict(text=_str(c.get("text")), type=_str(c.get("type")), note=_str(c.get("note")), src="ai")
                          for c in ai.get("clauses") or [] if isinstance(c, dict) and _str(c.get("text"))]
    toks = [t for t in ai.get("tokens") or [] if isinstance(t, dict)]
    if not toks:
        out["state"] = "ai-partial"
        return out
    out["tokens"] = (_align_wyw if lang == "wyw" else _align_en)(s, toks)
    return out


def _align_wyw(s, toks):
    text, base = s["text"], s["start"]
    i, out = 0, []
    for t in toks:
        w = _str(t.get("w"))
        while i < len(text) and (text[i] in classical.PUNCT or text[i].isspace()):
            i += 1
        off = classical.annotate(w, text, i, base)     # 考纲义项、通假的「其他义项」
        kind = _str(t.get("kind"))
        out.append(dict(start=base + i, end=base + i + len(w), w=w, kind="" if kind in ("", "一般") else kind,
                        pos=_str(t.get("pos")), sense=_str(t.get("sense")), usage=_str(t.get("usage")), note=_str(t.get("note")),
                        pinyin=_str(t.get("pinyin")), other=off["other"], exam=off["kind"] if off["kind"] in ("实词", "虚词") else "",
                        src="ai"))
        i += len(w)
    return out


def _align_en(s, toks):
    """按字母逐个对：AI 的每个 token 吃掉原文里相应个数的字母数字，范围取首尾；
    再按原文的词切开（AI 把 well-known 当一个词时，well、known 各得一份同样的解释）。"""
    text, base = s["text"], s["start"]
    pos = [i for i, ch in enumerate(text) if ch.isalnum()]
    owner, k = [None] * len(text), 0
    for t in toks:
        n = len(_letters(_str(t.get("w"))))
        for i in pos[k:k + n]:
            owner[i] = t
        k += n
    phrased = {(t["start"], t["end"]) for t in s.get("tokens") or [] if t.get("kind") == "短语"}
    out = []
    for a, b, w in english.words(text):
        t = next((owner[i] for i in range(a, b) if owner[i] is not None), None)
        if t is None:
            continue
        role, phrase = _str(t.get("role")), _str(t.get("phrase"))
        out.append(dict(start=base + a, end=base + b, w=w, lemma=_str(t.get("lemma")), pos=_str(t.get("pos")), sense=_str(t.get("sense")),
                        role=role, usage=_str(t.get("usage")), phrase=phrase, note="", other=[],
                        kind=_role_kind(role, phrase, w, (base + a, base + b) in phrased), src="ai"))
    return out


def _role_kind(role: str, phrase: str, w: str = "", fixed: bool = False) -> str:
    """英语下划线颜色按句子成分分组：主干（主谓宾表）、修饰（定状补）、引导词、固定搭配。
    「固定搭配」只给离线词表也认出的搭配（look forward to 这种）：模型的 phrase 填得很宽，
    has lived、for 3.5 years 都会写，全按它来下划线就全成一个颜色了。"""
    if fixed and phrase:
        return "短语"
    if "引导" in role and w.lower() != "there":
        return "从句引导"
    if any(k in role for k in ("主语", "谓语", "宾语", "表语")) and "介词" not in role:
        return "主干"
    if any(k in role for k in ("定语", "状语", "补语", "同位语", "介词")):
        return "修饰"
    if fixed:
        return "短语"
    return ""


def dumps(sentences: list[dict]) -> str:
    return json.dumps(sentences, ensure_ascii=False, indent=1)
