"""英语离线标注：功能词的词性和用法、高中常考短语、按助动词认时态和语态、从句引导词。

实词（名词、动词、形容词的具体意思）离线不查，只按词尾猜词性并注明「猜测」；句子成分和翻译要联网。
"""
from __future__ import annotations

import re

END = ".?!;"
WORD = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)*|\d+(?:[.,]\d+)*")

# 功能词：词 → (词性, 中文, 用法说明)
_FUNC = """
a|冠词|一（个）|不定冠词，用在辅音音素开头的词前
an|冠词|一（个）|不定冠词，用在元音音素开头的词前
the|冠词|这、那|定冠词，特指
i|代词|我|人称代词主格
me|代词|我|人称代词宾格
my|代词|我的|形容词性物主代词
mine|代词|我的（东西）|名词性物主代词
you|代词|你；你们|人称代词，主格宾格同形
your|代词|你的；你们的|形容词性物主代词
he|代词|他|人称代词主格
him|代词|他|人称代词宾格
his|代词|他的|物主代词
she|代词|她|人称代词主格
her|代词|她；她的|宾格或形容词性物主代词
it|代词|它|人称代词；也常作形式主语、形式宾语（it is ... to do / that ...）
its|代词|它的|形容词性物主代词
we|代词|我们|人称代词主格
us|代词|我们|人称代词宾格
our|代词|我们的|形容词性物主代词
they|代词|他们；它们|人称代词主格
them|代词|他们；它们|人称代词宾格
their|代词|他们的|形容词性物主代词
this|代词|这；这个|指示代词／限定词
that|代词／连词|那；（引导从句）|指示代词，或引导宾语、主语、同位语、表语、定语从句
these|代词|这些|指示代词
those|代词|那些|指示代词
who|代词|谁；……的人|疑问代词，或引导定语从句（指人，作主语）
whom|代词|谁；……的人|who 的宾格，引导定语从句（指人，作宾语）
whose|代词|谁的；……的|引导定语从句，表所属
which|代词|哪个；……的|疑问代词，或引导定语从句（指物）；非限制性定语从句可指代前面整句
what|代词|什么；……的东西|疑问代词，或引导名词性从句（在从句中作成分）
whatever|代词|无论什么|引导名词性从句或让步状语从句
when|副词／连词|什么时候；当……时|疑问副词，引导时间状语从句或定语从句
where|副词／连词|哪里；在……的地方|疑问副词，引导地点状语从句或定语从句
why|副词|为什么|疑问副词，引导定语从句（the reason why）或名词性从句
how|副词|怎样；多么|疑问副词，引导名词性从句或感叹句
if|连词|如果；是否|引导条件状语从句，或引导宾语从句（是否）
whether|连词|是否|引导名词性从句，可与 or not 连用
because|连词|因为|引导原因状语从句
since|连词／介词|自从；既然|引导时间或原因状语从句；与现在完成时连用表「自从」
as|连词／介词|当……时；因为；像；作为|引导时间、原因、方式、让步状语从句，或作介词「作为」
although|连词|虽然|引导让步状语从句，不与 but 连用
though|连词／副词|虽然；不过|引导让步状语从句
while|连词|当……时；然而|引导时间状语从句，或表对比
unless|连词|除非|引导条件状语从句（= if ... not）
until|连词／介词|直到|引导时间状语从句；not ... until 直到……才
before|连词／介词|在……之前|引导时间状语从句
after|连词／介词|在……之后|引导时间状语从句
so|连词／副词|所以；如此|表结果；so ... that 如此……以至于
than|连词|比|用于比较级之后
and|连词|和；并且|并列连词
but|连词|但是|并列连词，表转折
or|连词|或者；否则|并列连词，表选择；祈使句 + or 表「否则」
nor|连词|也不|neither ... nor ...；否定倒装
not|副词|不|否定副词
no|限定词|没有；不|否定
never|副词|从不|频度副词，句首时倒装
very|副词|很|程度副词
too|副词|太；也|too ... to ... 太……而不能
also|副词|也|放在实义动词前、be 动词后
only|副词|只；仅仅|only + 状语放句首时部分倒装
even|副词|甚至|加强语气
just|副词|刚刚；只是|常与现在完成时连用
already|副词|已经|常用于现在完成时
yet|副词／连词|还；然而|用于否定句和疑问句的完成时
in|介词|在……里；在（年、月）|表地点、时间、方式
on|介词|在……上；在（某天）|表地点、具体某一天
at|介词|在（某点）|表时间点、地点
of|介词|……的|表所属、部分、同位
to|介词／不定式符号|到；向；（不定式）|介词表方向；to + 动词原形为不定式
for|介词|为了；对于；（时间）长达|表目的、对象、时间段
with|介词|和；用；带有|表伴随、工具；with + 宾语 + 补语为独立结构
by|介词|被；通过；在……旁|被动句中引出动作执行者；by doing 通过……
from|介词|从|表起点、来源
about|介词|关于；大约|
into|介词|进入|表方向
through|介词|穿过；通过|
without|介词|没有|
during|介词|在……期间|
between|介词|在（两者）之间|
among|介词|在（三者以上）之间|
is|动词|是|be 动词第三人称单数现在时；也作助动词（进行时、被动语态）
am|动词|是|be 动词第一人称单数现在时
are|动词|是|be 动词现在时复数
was|动词|是|be 动词过去式（单数）
were|动词|是|be 动词过去式（复数）；虚拟语气中各人称都用 were
be|动词|是|be 动词原形
been|动词|是|be 的过去分词，用于完成时
being|动词|是|be 的现在分词／动名词，being done 表被动进行
have|动词|有；（助动词）|实义动词「有」，或与过去分词构成完成时
has|动词|有；（助动词）|have 的第三人称单数
had|动词|有；（助动词）|have 的过去式；had done 为过去完成时
do|动词|做；（助动词）|实义动词，或用于构成疑问、否定、强调
does|动词|做；（助动词）|do 的第三人称单数
did|动词|做；（助动词）|do 的过去式
will|情态动词|将；会|will + 动词原形构成一般将来时
would|情态动词|将会；愿意|过去将来时，或表委婉、虚拟
can|情态动词|能；可以|表能力、可能
could|情态动词|能；可能|can 的过去式，或表委婉、推测
may|情态动词|可以；可能|表许可、推测
might|情态动词|可能|表较弱的推测
must|情态动词|必须；一定|表义务或肯定推测
should|情态动词|应该|表义务、建议；虚拟语气中可省略
shall|情态动词|将；要|用于第一人称将来时或征求意见
there|副词|那里；（引导词）|there be 句型表「存在」
"""
FUNC = {}
for _line in _FUNC.strip().splitlines():
    _w, _pos, _cn, _use = (x.strip() for x in _line.split("|"))
    FUNC[_w] = (_pos, _cn, _use)

# 高中常考短语（小写；…… 处可插一个宾语）
PHRASES = {
    "look forward to": "盼望（to 是介词，后接名词或动名词）", "be used to": "习惯于（to 是介词，后接名词或动名词）",
    "used to": "过去常常（后接动词原形）", "in spite of": "尽管", "as well as": "以及；和……一样",
    "because of": "因为（后接名词或代词）", "instead of": "代替；而不是", "according to": "根据；按照",
    "in order to": "为了（表目的）", "so that": "以便；结果", "as soon as": "一……就……",
    "as long as": "只要", "as if": "好像（从句常用虚拟语气）", "even if": "即使", "even though": "即使；尽管",
    "not only": "不仅（not only ... but also ...；放句首时部分倒装）", "but also": "而且（not only ... but also ...）",
    "neither nor": "既不……也不……", "either or": "或者……或者……", "no sooner than": "一……就……（句首倒装）",
    "hardly when": "一……就……（句首倒装）", "it is that": "强调句型 It is ... that ...",
    "take part in": "参加（活动）", "make up": "组成；编造；化妆", "give up": "放弃", "carry out": "执行；实施",
    "put off": "推迟", "put up with": "忍受", "come up with": "想出（主意）", "keep up with": "跟上",
    "catch up with": "赶上", "get along with": "与……相处", "depend on": "依靠；取决于", "pay attention to": "注意（to 是介词）",
    "be interested in": "对……感兴趣", "be good at": "擅长", "be able to": "能够", "be about to": "正要；即将",
    "be supposed to": "应该；被期望", "be likely to": "可能", "be known as": "作为……而出名", "be known for": "因……而出名",
    "a number of": "许多（谓语用复数）", "the number of": "……的数量（谓语用单数）", "a great deal of": "大量（修饰不可数名词）",
    "in front of": "在……前面", "on the other hand": "另一方面", "in addition": "此外", "as a result": "结果",
    "at the same time": "同时", "for example": "例如", "in fact": "事实上", "at least": "至少", "at last": "最后",
    "by the way": "顺便说一下", "on purpose": "故意", "in the end": "最后", "rather than": "而不是",
    "would rather": "宁愿（后接动词原形，或接虚拟从句）", "had better": "最好（后接动词原形）",
    "make sure": "确保",
    "turn out": "结果是；证明是", "deal with": "处理；应对", "lead to": "导致（to 是介词）",
    "contribute to": "有助于；导致（to 是介词）", "devote to": "致力于（to 是介词）", "result in": "导致",
    "result from": "由……引起", "consist of": "由……组成", "take care of": "照顾", "make use of": "利用",
    "take advantage of": "利用", "in terms of": "就……而言", "with the help of": "在……帮助下",
    "it is said that": "据说", "it is reported that": "据报道",
}
# 短语各部分之间最多隔几个词：成对连词隔得远，动副短语中间可插宾语（put it off），其余必须连着
GAP = {"neither nor": 12, "either or": 12, "no sooner than": 12, "hardly when": 12, "it is that": 12,
       "put off": 2, "give up": 2, "make up": 2, "carry out": 2, "turn out": 1, "make sure": 0,
       "devote to": 3, "pay attention to": 0, "take care of": 0}
_PHRASE_WORDS = sorted(((k.split(), v) for k, v in PHRASES.items()), key=lambda kv: -len(kv[0]))

IRREGULAR_PAST = set("""was were had did said made went took came saw got gave found knew thought told became left felt brought
began kept held wrote stood heard let meant set met ran paid sat spoke lay led read grew lost fell sent built understood
drew broke spent cut rose drove bought wore chose sought threw caught dealt won forgot fought taught""".split())
IRREGULAR_PP = set("""been had done said made gone taken come seen got gotten given found known thought told become left felt
brought begun kept held written stood heard let meant set met run paid sat spoken lain led read grown lost fallen sent built
understood drawn broken spent cut risen driven bought worn chosen sought thrown caught dealt won forgotten fought taught""".split())

BE_FORMS = {"is", "are", "was", "were", "be", "been", "being", "am"}
AUX = {"will", "would", "shall", "should", "may", "might", "must", "can", "could", "has", "have", "had", "to"}
_IRR = {"be": BE_FORMS, "take": {"took", "taken"}, "give": {"gave", "given"}, "come": {"came"}, "make": {"made"},
        "get": {"got", "gotten"}, "keep": {"kept"}, "catch": {"caught"}, "pay": {"paid"}, "deal": {"dealt"},
        "lead": {"led"}, "put": set(), "know": {"knew", "known"}, "lead to": set()}


def same(word: str, part: str) -> bool:
    """短语里的动词允许变形：looking forward to、took part in、is used to。"""
    if word == part:
        return True
    if len(part) < 2 or part in FUNC and part not in _IRR:
        return False
    if word in _IRR.get(part, ()):
        return True
    stem = part[:-1] if part.endswith("e") else part
    return word in {part + "s", part + "es", part + "ed", part + "d", stem + "ing", part + "ing",
                    part + part[-1] + "ing", part + part[-1] + "ed", stem[:-1] + "ied" if part.endswith("y") else ""}
CLAUSE_HEADS = {"that", "which", "who", "whom", "whose", "what", "whatever", "when", "where", "why", "how", "if", "whether",
                "because", "since", "although", "though", "while", "unless", "until", "before", "after", "as"}


def words(sentence: str, base: int = 0) -> list[tuple[int, int, str]]:
    return [(base + m.start(), base + m.end(), m.group()) for m in WORD.finditer(sentence)]


def _guess_pos(w: str) -> str:
    lw = w.lower()
    if lw.isdigit():
        return "数词"
    if lw.endswith("ly") and len(lw) > 4:
        return "副词（猜测）"
    if lw.endswith(("tion", "sion", "ment", "ness", "ity", "ance", "ence", "ship", "ism")):
        return "名词（猜测）"
    if lw.endswith(("ful", "less", "ous", "ive", "able", "ible", "al", "ic")) and len(lw) > 4:
        return "形容词（猜测）"
    if lw.endswith("ing"):
        return "动词 -ing 形式（猜测）"
    if lw.endswith("ed") or lw in IRREGULAR_PAST:
        return "动词过去式／过去分词（猜测）"
    return ""


def tense(sentence: str) -> list[str]:
    """按助动词组合认谓语的时态和语态（只认最典型的组合）。"""
    s = " " + re.sub(r"[^a-z' ]", " ", sentence.lower()) + " "
    pp = r"(?:\w+ed|" + "|".join(sorted(IRREGULAR_PP)) + r")"
    rules = [
        (rf" (?:will|shall) have been {pp} ", "将来完成时（被动）"), (rf" (?:will|shall) have {pp} ", "将来完成时"),
        (r" had been \w+ing ", "过去完成进行时"), (r" (?:has|have) been \w+ing ", "现在完成进行时"),
        (rf" had been {pp} ", "过去完成时（被动）"), (rf" (?:has|have) been {pp} ", "现在完成时（被动）"),
        (rf" had {pp} ", "过去完成时"), (rf" (?:has|have) {pp} ", "现在完成时"),
        (rf" (?:am|is|are) being {pp} ", "现在进行时（被动）"), (rf" (?:was|were) being {pp} ", "过去进行时（被动）"),
        (r" (?:am|is|are) \w+ing ", "现在进行时"), (r" (?:was|were) \w+ing ", "过去进行时"),
        (rf" (?:will|shall) be {pp} ", "一般将来时（被动）"), (r" (?:will|shall) be \w+ing ", "将来进行时"),
        (r" (?:will|shall) \w+ ", "一般将来时"), (r" (?:am|is|are) going to ", "一般将来时（be going to）"),
        (rf" (?:am|is|are) {pp} ", "一般现在时（被动）"), (rf" (?:was|were) {pp} ", "一般过去时（被动）"),
        (r" would \w+ ", "过去将来时或虚拟／委婉语气"),
    ]
    found = []
    for rx, name in rules:
        if re.search(rx, s) and not any(name.split("（")[0] in f for f in found):
            found.append(name)
    return found


def tokenize(sentence: str, base: int = 0) -> list[dict]:
    ws = words(sentence, base)
    low = [w.lower() for _, _, w in ws]
    phrase_of: dict[int, str] = {}
    for parts, meaning in _PHRASE_WORDS:
        key = " ".join(parts)
        gap = GAP.get(key, 0)
        for i in range(len(low)):
            if not same(low[i], parts[0]):
                continue
            idx, j = [i], i + 1
            for part in parts[1:]:
                hit = next((x for x in range(j, min(j + gap + 1, len(low))) if same(low[x], part)), None)
                if hit is None:
                    break
                idx.append(hit)
                j = hit + 1
            if len(idx) == len(parts) and all(x not in phrase_of for x in idx):
                for x in idx:
                    phrase_of[x] = key + "：" + meaning
    for i in range(len(low) - 1):       # there be 句型：be 有各种形式（there will be / there has been 也算）
        if low[i] != "there" or i in phrase_of:
            continue
        be = next((x for x in (i + 1, i + 2) if x < len(low) and low[x] in BE_FORMS), None)
        if be is not None and (be == i + 1 or low[i + 1] in AUX):
            phrase_of[i] = phrase_of[be] = "there be 句型：表示「有、存在」，谓语和后面的真正主语保持一致"
    out = []
    for i, (a, b, w) in enumerate(ws):
        lw = w.lower()
        t = dict(start=a, end=b, w=w, kind="", pos="", sense="", usage="", note="", other=[], role="", phrase="", src="offline")
        if lw in FUNC:
            pos, cn, use = FUNC[lw]
            t.update(kind="功能词", pos=pos, sense=cn, note=use)
        else:
            t["pos"] = _guess_pos(w)
        if lw in CLAUSE_HEADS and i > 0:
            t["kind"] = "从句引导"
        if i in phrase_of:
            t["phrase"] = phrase_of[i]
            t["kind"] = "短语"
        out.append(t)
    return out


def clauses(sentence: str) -> list[dict]:
    """离线只指出可能的从句引导词，不判断从句类型（that / as 等一词多用，判断不了）。"""
    out = []
    ws = words(sentence)
    for i, (_, _, w) in enumerate(ws):
        if i and w.lower() in CLAUSE_HEADS:
            out.append(dict(text=w, type="可能的从句引导词", note="从句类型和成分要联网分析", src="offline"))
    return out


def offline(text: str) -> list[dict]:
    from .analyze import split_sentences
    out = []
    for start, end in split_sentences(text, END):
        s = text[start:end]
        tn = tense(s)
        out.append(dict(start=start, end=end, text=s, tokens=tokenize(s, start), clauses=clauses(s),
                        patterns=[dict(type="时态", mark=x, note="离线按助动词组合认出", src="offline") for x in tn],
                        translation="", structure="", state="offline"))
    return out
