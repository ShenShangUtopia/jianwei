"""生物 · 必修1 分子与细胞（由 gewu/bio.js 改写）：跨膜运输、酶、光合与呼吸、有丝分裂。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha
from ...kit.core import PI, TAU, clamp, fmt, rnd
from ...kit.draw import D
from ...kit.registry import lab


# ---------------------------------------------------------------- 物质跨膜运输
@lab.reg(id="b-osmo", subj="bio", book=0, unit="细胞的物质输入和输出", title="质壁分离与跨膜运输方式",
         kw="渗透作用 质壁分离 复原 原生质层 自由扩散 协助扩散 主动运输 载体 通道",
         info="<p><b>渗透作用</b>需要半透膜和膜两侧的浓度差。成熟植物细胞的原生质层（细胞膜、液泡膜及两层膜之间的细胞质）相当于半透膜。"
              "外界溶液浓度大于细胞液浓度时细胞失水，原生质层与细胞壁分离（质壁分离）；放回清水中发生复原。</p>"
              "<p>在一定浓度的 KNO₃ 溶液中，细胞先发生质壁分离，随后 K⁺、NO₃⁻ 被主动吸收，细胞液浓度升高，自动复原。外界浓度过高时细胞会失水过多而死亡，不能复原。</p>"
              "<p class='fb'>自由扩散：顺浓度梯度，不需要载体和能量，速率 ∝ 浓度差<br>协助扩散：顺浓度梯度，需要转运蛋白，有饱和现象<br>"
              "主动运输：可逆浓度梯度，需要载体蛋白，消耗能量（ATP），受 O₂ 浓度影响</p>",
         tasks=["把外界蔗糖浓度设为 0.3 g/mL，观察质壁分离；再换成清水，观察复原。", "选 KNO₃ 溶液，为什么不用换清水细胞也能复原？",
                "运输方式模式中，协助扩散的速率为什么在高浓度时不再增加？"])
def b_osmo(L):
    c = L.canvas()
    S = {"st": {"v": 1.0, "s": 0.15, "dead": False, "t": 0.0}, "hist": []}
    parts = [{"x": rnd(0, 1), "y": rnd(0, 1), "out": random.random() < 0.5} for _ in range(60)]

    def on_mode(v):
        G1.setVisible(v == "pl")
        G2.setVisible(v == "tr")
        L.draw()
    L.group("模式")
    mode = L.seg("", [["pl", "质壁分离"], ["tr", "运输方式"]], "pl", on_mode)
    G1 = L.group("外界溶液")
    sol = L.select("", [["suc", "蔗糖溶液"], ["kno3", "KNO₃ 溶液"], ["water", "清水"]], "suc", lambda _v: S.__setitem__("hist", []))
    co = L.slider("浓度", 0, 0.6, 0.01, 0.3, None, "g/mL")

    def new_cell(_b):
        S["st"] = {"v": 1.0, "s": 0.15, "dead": False, "t": 0.0}
        S["hist"] = []
    L.button("换一个新细胞", new_cell)
    out = L.out()
    G2 = L.group("运输方式")
    G2.setVisible(False)
    kind = L.seg("", [["free", "自由扩散"], ["fac", "协助扩散"], ["act", "主动运输"]], "free")
    q = L.params({"dc": ["膜两侧浓度差（外 − 内）", -10, 10, 0.5, 6], "car": ["转运蛋白数量", 1, 10, 1, 4], "o2": ["O₂ 浓度（能量供应）", 0, 10, 0.5, 6]})
    out2 = L.out()

    def rate():
        k, dc = kind.v, q.dc
        if k == "free":
            return 0.4 * dc
        if k == "fac":
            return math.copysign(1, dc) * q.car * 1.2 * abs(dc) / (abs(dc) + 2) if dc else 0.0
        return q.car * 1.2 * q.o2 / (q.o2 + 2) * (1 if q.o2 > 0 else 0.15)

    def tick(dt):
        st = S["st"]
        if mode.v == "pl":
            ext = 0 if sol.v == "water" else co.v
            inside = st["s"] / st["v"]
            if not st["dead"]:
                dv = 0.8 * (inside - ext) * dt
                if st["v"] >= 1 and dv > 0:
                    dv = 0
                st["v"] = clamp(st["v"] + dv, 0.3, 1)
                if sol.v == "kno3" and ext > 0:
                    st["s"] += 0.012 * ext * dt
                if ext > 0.5 and st["v"] < 0.42:
                    st["dead"] = True
            st["t"] += dt
            S["hist"].append((st["t"], st["v"]))
            if len(S["hist"]) > 600:
                S["hist"].pop(0)
        else:
            r = rate()
            d = 1 if kind.v == "act" else (1 if q.dc > 0 else -1 if q.dc < 0 else 0)
            for p in parts:
                p["x"] = clamp(p["x"] + rnd(-1, 1) * dt * 0.3, 0, 1)
                p["y"] = clamp(p["y"] + rnd(-1, 1) * dt * 0.3, 0, 1)
            if d and random.random() < abs(r) * dt * 0.8:
                src = [p for p in parts if p["out"] == (d > 0)]
                if src:
                    pp = random.choice(src)
                    pp["out"] = not (d > 0)
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        st = S["st"]
        if mode.v == "pl":
            W = min(c.w * 0.5, 320)
            H = W * 0.62
            x0, y0 = 30, (c.h - H) / 2
            ext = 0 if sol.v == "water" else co.v
            D.rect(g, 10, 10, c.w * 0.55, c.h - 20, f"rgba(120,170,240,{0.06 + ext * 0.5:.3f})")
            D.rrect(g, x0, y0, W, H, 14, None, "#6b8e23", 8)
            vv = st["v"]
            iw, ih = (W - 16) * math.sqrt(vv), (H - 16) * math.sqrt(vv)
            cx, cy = x0 + W / 2, y0 + H / 2
            D.rrect(g, cx - iw / 2, cy - ih / 2, iw, ih, 12 * vv, alpha("#7cb342", 0.5), "#558b2f", 2)
            vac = clamp(st["s"] / vv / 0.6, 0, 1)
            D.rrect(g, cx - iw / 2 + 8, cy - ih / 2 + 8, iw - 16, ih - 16, 10 * vv, f"rgba(150,40,160,{0.25 + vac * 0.6:.3f})")
            D.circle(g, cx - iw / 2 + 18, cy - ih / 2 + 18, 7, alpha("#33691e", 0.8))
            for i, s in enumerate(("细胞壁", "原生质层", "液泡（紫色细胞液）")):
                D.text(g, s, x0 + W + 8, y0 + 10 + 18 * i, T.muted, size=11)
            if st["dead"]:
                D.text(g, "细胞已失水过多死亡", cx, y0 + H + 22, T.bad, align="center", bold=True)
            gx = c.w * 0.58
            gw = c.w - gx - 20
            hist = S["hist"]
            if len(hist) > 1 and gw > 120:
                D.chart(g, gx, 30, gw, c.h - 70, [{"pts": hist, "color": T.c5, "w": 2}], title="原生质层相对大小", xl="t",
                        xmin=hist[0][0], xmax=st["t"], ymin=0.2, ymax=1.05)
            inside = st["s"] / st["v"]
            if st["dead"]:
                state = "死亡"
            elif vv < 0.97:
                state = "正在失水，质壁分离" if inside < ext - 0.005 else "正在吸水，质壁分离复原" if inside > ext + 0.005 else "质壁分离（平衡）"
            else:
                state = "正常（紧贴细胞壁）"
            out.set([["外界溶液浓度", f"{fmt(ext, 2)} g/mL"], ["细胞液浓度（相对）", fmt(inside * 2, 3)], ["原生质层体积", fmt(vv * 100, 1) + " %"],
                     ["状态", state], ["液泡颜色", "变深" if vv < 0.97 else "正常"]])
        else:
            mx, top = c.w * 0.27, 30
            H = c.h - 60
            D.rect(g, mx - 12, top, 24, H, alpha("#d9a441", 0.35))
            y = top
            while y < top + H:
                D.circle(g, mx - 9, y + 7, 4, alpha("#d9a441", 0.9))
                D.circle(g, mx + 9, y + 7, 4, alpha("#d9a441", 0.9))
                y += 14
            car = int(q.car)
            if kind.v != "free":
                for k in range(car):
                    yy = top + (k + 0.5) * H / car
                    D.rrect(g, mx - 16, yy - 12, 32, 24, 8, T.c2 if kind.v == "act" else T.c3)
            if kind.v == "act":
                D.text(g, "ATP → ADP + Pi", mx, top + H + 14, T.c2, align="center", size=11)
            col = T.c2 if kind.v == "act" else T.c3 if kind.v == "fac" else T.c1
            for p in parts:
                D.circle(g, 20 + p["x"] * (mx - 50) if p["out"] else mx + 30 + p["x"] * (mx - 50), top + p["y"] * H, 4, col)
            D.text(g, "膜外", 24, 18, T.muted)
            D.text(g, "膜内", mx + 30, 18, T.muted)
            gx = c.w * 0.58
            gw, gh = c.w - gx - 20, (c.h - 80) / 2
            xs = [i / 5 for i in range(51)]
            c1 = D.chart(g, gx, 24, gw, gh, [{"pts": [(x, 0.4 * x) for x in xs], "color": T.c1, "w": 2},
                                              {"pts": [(x, q.car * 1.2 * x / (x + 2)) for x in xs], "color": T.c3, "w": 2}],
                         title="速率 − 浓度差（蓝：自由扩散，绿：协助扩散）", xl="浓度差", xmin=0, xmax=10, ymin=0, ymax=13)
            if kind.v != "act":
                D.circle(g, c1["X"](abs(q.dc)), c1["Y"](abs(rate())), 5, T.c2)
            c2 = D.chart(g, gx, 50 + gh, gw, gh, [{"pts": [(x, q.car * 1.2 * x / (x + 2) + (q.car * 0.18 if x == 0 else 0)) for x in xs], "color": T.c2, "w": 2}],
                         title="主动运输速率 − O₂ 浓度", xl="O₂", xmin=0, xmax=10, ymin=0, ymax=13)
            if kind.v == "act":
                D.circle(g, c2["X"](q.o2), c2["Y"](rate()), 5, T.c4)
            name = {"free": "自由扩散（如 O₂、CO₂、甘油）", "fac": "协助扩散（如葡萄糖进入红细胞、水通过水通道）", "act": "主动运输（如 K⁺ 进入细胞、小肠吸收葡萄糖）"}[kind.v]
            out2.set([["运输方式", ""], name, ["方向", "可逆浓度梯度" if kind.v == "act" else "高浓度 → 低浓度（向内）" if q.dc >= 0 else "高浓度 → 低浓度（向外）"],
                      ["需要转运蛋白", "否" if kind.v == "free" else "是"], ["消耗能量", "是" if kind.v == "act" else "否"], ["相对速率", fmt(abs(rate()), 2)]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 酶
@lab.reg(id="b-enzyme", subj="bio", book=0, unit="细胞的能量供应和利用", title="影响酶活性的因素", kw="酶 高效性 专一性 最适温度 最适 pH 变性 底物浓度 过氧化氢酶",
         info="<p>酶是活细胞产生的具有催化作用的有机物，绝大多数是蛋白质。酶的作用机理是<b>降低化学反应的活化能</b>。</p>"
              "<p class='fb'>高效性：与无机催化剂相比，酶降低活化能的作用更显著<br>专一性：每种酶只能催化一种或一类化学反应<br>"
              "作用条件温和：有最适温度和最适 pH；高温、过酸、过碱使酶空间结构破坏而永久失活，低温只抑制活性</p>"
              "<p>底物浓度较低时，反应速率随底物浓度增加而增加；底物足够多时受酶量限制，速率不再增加。</p>"
              "<p class='fb'>本实验和生物工作台的酶卡片用同一个模型：升温使催化加快，同时使酶失活加快，"
              "所以测得的「最适温度」和作用时间有关——作用越久，曲线的峰越往低温移。数值为相对值，假设见工作台酶卡片的「原理」。</p>",
         tasks=["比较唾液淀粉酶和胃蛋白酶的最适 pH。", "勾选「先经过 80 ℃ 处理」，再把温度调回 37 ℃，活性能恢复吗？与 0 ℃ 处理比较。",
                "把作用时间从 2 分钟调到 60 分钟，看温度曲线的峰（表观最适温度）往哪边移。", "高效性模式中，比较三支试管产生气泡的速度。"])
def b_enzyme(L):
    from ..benches import bio_enzyme as M
    c = L.canvas()
    E = {"amy": "amylase", "pep": "pepsin", "try": "trypsin", "cat": "catalase", "malt": "malt"}   # 旧存档的键不变
    L.group("模式")
    mode = L.seg("", [["tp", "温度与 pH"], ["s", "底物浓度"], ["eff", "高效性"]], "tp")
    L.group("条件")
    en = L.select("酶", [[k, M.ENZYMES[v]["name"]] for k, v in E.items()], "amy")
    p = L.params({"T": ["温度", 0, 100, 1, 37, "℃"], "pH": ["pH", 0, 14, 0.1, 6.8], "min": ["作用时间", 1, 60, 1, 10, "min"],
                  "S": ["底物浓度（Km 倍）", 0, 10, 0.1, 4], "e": ["酶量（相对）", 0.2, 2, 0.1, 1]})
    hot = L.check("先经过 80 ℃ 处理 10 分钟", False)
    cold = L.check("先经过 0 ℃ 处理 10 分钟", False)
    out = L.out()
    memo: dict = {}

    def cond(key, **kw):
        """模型的一组条件：当前滑块 + 预处理；kw 覆盖其中几项。"""
        pre_T, pre_min = (80, 10) if hot.v else (0, 10) if cold.v else (37, 0)
        enz = E[key]
        base = dict(enzyme=enz, temperature=float(p.T), pH=float(p.pH), substrate=5.0, dose=1.0, minutes=float(p.min),
                    pre_T=float(pre_T), pre_pH=round(M.optimum_ph(enz), 1), pre_min=float(pre_min))
        base.update(kw)
        return base

    def mean(q):
        return M.measure(q)["mean"]

    def peak(key):
        """这种酶在最适 pH、不做预处理时，这段作用时间里各温度的最高平均活性：相对活性 100 % 的基准。"""
        k = ("peak", key, p.min)
        if k not in memo:
            memo[k] = max(M.curve(cond(key, pH=M.optimum_ph(E[key]), pre_min=0.0))) or 1.0
        return memo[k]

    def rel(key, **kw):
        return mean(cond(key, **kw)) / peak(key)

    def t_curve(key):
        k = ("T", key, p.pH, p.min, hot.v, cold.v)
        if k not in memo:
            ref = peak(key)
            memo[k] = [v / ref for v in M.curve(cond(key))]
        return memo[k]

    def ph_curve(key):
        k = ("pH", key, p.T, p.min, hot.v, cold.v)
        if k not in memo:
            memo[k] = [rel(key, pH=i / 10) for i in range(141)]
        return memo[k]
    bub: list = []

    def tick(dt):
        if mode.v != "eff":
            return
        for i, r in enumerate((6, 1.2, 0.05)):
            if random.random() < r * dt * 3:
                bub.append({"i": i, "x": rnd(-14, 14), "y": 0.0})
        for b in bub:
            b["y"] += dt * 60
        bub[:] = [b for b in bub if b["y"] < 160]
        L.draw()
    L.loop(tick)

    def draw():
        c.clear()
        g = c.g
        if len(memo) > 300:
            memo.clear()
        enz = E[en.v]
        nm = M.ENZYMES[enz]["name"]
        q = cond(en.v)
        r = M.measure(q)
        a = r["mean"] / peak(en.v)
        Tc = t_curve(en.v)
        top = max(Tc)
        To = Tc.index(top) if top > 1e-6 else None
        band = [i / 10 for i in range(141) if M.ph_factor(enz, i / 10) >= 0.9]   # 九成以上活性的 pH 范围
        gw, gh = (c.w - 90) / 2, c.h - 80
        if mode.v == "tp":
            ch1 = D.chart(g, 40, 30, gw, gh, [{"pts": list(enumerate(Tc)), "color": T.c2, "w": 2.2}],
                          title=f"{nm} 活性 − 温度（pH {fmt(p.pH, 1)}，作用 {fmt(p.min, 0)} min）", xl="温度 / ℃", xmin=0, xmax=100, ymin=0, ymax=1.1)
            if To is not None:
                D.line(g, ch1["X"](To), ch1["Y"](0), ch1["X"](To), ch1["Y"](top), alpha(T.c2, 0.55), 1, [4, 4])
                D.text(g, f"表观最适 {To} ℃", ch1["X"](To) + 6, ch1["Y"](top) - 10, T.c2, size=11)
            D.circle(g, ch1["X"](p.T), ch1["Y"](a), 5, T.c2)
            Ps = [i / 10 for i in range(141)]
            ch2 = D.chart(g, 60 + gw, 30, gw, gh, [{"pts": list(zip(Ps, ph_curve(en.v))), "color": T.c1, "w": 2.2}],
                          title=f"活性 − pH（{fmt(p.T, 0)} ℃，虚线：其他酶）", xl="pH", xmin=0, xmax=14, ymin=0, ymax=1.1)
            D.circle(g, ch2["X"](p.pH), ch2["Y"](a), 5, T.c1)
            for k in E:
                if k == en.v:
                    continue
                g.stroke_style, g.line_width, g.dash = alpha(T.muted, 0.5), 1, [3, 3]
                g.begin_path()
                for i, (x, y) in enumerate(zip(Ps, ph_curve(k))):
                    (g.line_to if i else g.move_to)(ch2["X"](x), ch2["Y"](y))
                g.stroke()
                g.dash = []
        elif mode.v == "s":
            Ss = [i / 10 for i in range(101)]

            def V(s, e):
                return a * e * s / (1 + s)       # 米氏方程，底物以 Km 为单位
            ch = D.chart(g, 40, 30, c.w - 80, gh, [{"pts": [(s, V(s, p.e)) for s in Ss], "color": T.c3, "w": 2.4},
                                                    {"pts": [(s, V(s, p.e * 2)) for s in Ss], "color": alpha(T.muted, 0.6), "w": 1.4, "dash": [5, 4]}],
                         title="反应速率 − 底物浓度（虚线：酶量加倍；点线：最大速率的一半）", xl="底物浓度 / Km", xmin=0, xmax=10, ymin=0,
                         ymax=max(0.4, a * p.e * 2 * 1.1))
            if a * p.e > 1e-6:
                D.line(g, ch["X"](0), ch["Y"](a * p.e / 2), ch["X"](1), ch["Y"](a * p.e / 2), alpha(T.muted, 0.7), 1, [2, 3])
                D.line(g, ch["X"](1), ch["Y"](0), ch["X"](1), ch["Y"](a * p.e / 2), alpha(T.muted, 0.7), 1, [2, 3])
            D.circle(g, ch["X"](p.S), ch["Y"](V(p.S, p.e)), 5, T.c2)
        else:
            names = ["过氧化氢酶（肝脏研磨液）", "FeCl₃ 溶液", "蒸馏水（对照）"]
            xs = [f * c.w for f in (0.2, 0.5, 0.8)]
            by = c.h - 60
            for i, x in enumerate(xs):
                D.rrect(g, x - 24, by - 170, 48, 170, 20, alpha(T.c1, 0.1), T.fg, 1.8)
                D.rect(g, x - 22, by - 110, 44, 108, alpha(T.c1, 0.15))
                D.text(g, names[i], x, by + 18, T.fg, align="center", size=12)
            for b in bub:
                D.circle(g, xs[b["i"]] + b["x"] * 0.7, by - 10 - b["y"] * 0.65, 3, None, T.muted, 1)
            D.text(g, "各加 2 mL 3% H₂O₂ 溶液：2H₂O₂ → 2H₂O + O₂↑", c.w / 2, 24, T.muted, align="center")
        lo, hi = M.ENZYMES[enz]["stable"]
        if hot.v:
            state = f"80 ℃ 处理后只剩 {fmt(r['before'] * 100, 1)} % 的酶有活性：空间结构破坏，降温也不能恢复"
        elif p.pH < lo or p.pH > hi:
            state = ("过酸" if p.pH < lo else "过碱") + f"：作用期间酶不断变性，结束时剩 {fmt(r['after'] * 100, 1)} %，不可逆"
        elif r["after"] < 0.8 and p.T > 37:
            state = f"高温下边催化边失活，结束时剩 {fmt(r['after'] * 100, 1)} % 的酶"
        elif p.T < 15:
            state = "低温抑制：催化变慢，但酶没有失活，升温即恢复"
        elif cold.v:
            state = "0 ℃ 处理没有破坏酶，回到适宜温度活性照常"
        else:
            state = "接近最适条件" if a > 0.8 else "活性受抑制"
        out.set([["酶", nm], ["最适 pH（九成活性以上）", f"{fmt(band[0], 1)}–{fmt(band[-1], 1)}" if band else "—"],["表观最适温度", (f"{To} ℃" if To is not None else "—") + f"（作用 {fmt(p.min, 0)} min）"],
                 ["当前相对活性", fmt(a * 100, 1) + " %"], ["结束时有活性的酶", fmt(r["after"] * 100, 1) + " %"], ["状态", ""], state])
    L.on_draw(draw)


# ---------------------------------------------------------------- 光合作用与呼吸作用
@lab.reg(id="b-photo", subj="bio", book=0, unit="细胞的能量供应和利用", title="光合作用与呼吸作用",
         kw="光合作用 呼吸作用 光补偿点 光饱和点 净光合速率 CO2 浓度 温度 一昼夜",
         info="<p class='fb'>总（真）光合速率 = 净光合速率 + 呼吸速率<br>光补偿点：光合速率 = 呼吸速率　光饱和点：光合速率不再随光照增强而增加</p>"
              "<p>光照强度主要影响光反应；CO₂ 浓度主要影响暗反应（卡尔文循环）；温度通过影响酶活性同时影响光合作用与呼吸作用。阴生植物的光补偿点和光饱和点都比阳生植物低。</p>"
              "<p>「一昼夜」模式模拟密闭玻璃罩内 CO₂ 浓度的变化：曲线的最高点和最低点对应光合速率等于呼吸速率的时刻。</p>",
         tasks=["提高 CO₂ 浓度，光补偿点和光饱和点分别怎样移动？", "把温度从 25 ℃ 升到 40 ℃，净光合速率为什么下降？",
                "一昼夜模式中，24 时的 CO₂ 浓度低于 0 时，说明植物有机物积累了还是减少了？"])
def b_photo(L):
    c = L.canvas()
    L.group("模式")
    mode = L.seg("", [["lc", "光照强度曲线"], ["day", "一昼夜（密闭容器）"]], "lc")
    pt = L.select("植物类型", [["sun", "阳生植物"], ["shade", "阴生植物"]], "sun")
    p = L.params({"I": ["光照强度", 0, 1500, 10, 600, "μmol·m⁻²·s⁻¹"], "C": ["CO₂ 浓度", 0.01, 0.12, 0.005, 0.04, "%", 3], "T": ["温度", 5, 45, 1, 25, "℃"]})
    out = L.out()

    def model(I, C, Tc):
        sun = pt.v == "sun"
        fT = math.exp(-(((Tc - 27) / 11) ** 2))
        Pm = (30 if sun else 12) * C / (C + 0.03) * fT
        Ik = 300 if sun else 90
        R = (3.2 if sun else 1.2) * 2 ** ((Tc - 25) / 10)
        P = Pm * I / (I + Ik)
        return {"P": P, "R": R, "net": P - R, "Pm": Pm, "Ik": Ik}

    def draw():
        c.clear()
        g = c.g
        m = model(p.I, p.C, p.T)
        if mode.v == "lc":
            Is = [i * 10 for i in range(151)]
            lw = min(200, c.w * 0.28)
            ch = D.chart(g, lw + 60, 30, c.w - lw - 90, c.h - 70,
                         [{"pts": [(I, model(I, p.C, p.T)["net"]) for I in Is], "color": T.c3, "w": 2.4},
                          {"pts": [(I, model(I, p.C, p.T)["P"]) for I in Is], "color": alpha(T.muted, 0.7), "w": 1.4, "dash": [5, 4]}],
                         title="净光合速率（实线）与总光合速率（虚线） − 光照强度", xl="光照强度", xmin=0, xmax=1500, ymin=-6, ymax=32)
            D.circle(g, ch["X"](p.I), ch["Y"](m["net"]), 5.5, T.c2)
            comp = m["Ik"] * m["R"] / (m["Pm"] - m["R"]) if m["R"] < m["Pm"] else None
            sat = 19 * m["Ik"]
            if comp is not None and comp <= 1500:
                D.line(g, ch["X"](comp), ch["Y"](-6), ch["X"](comp), ch["Y"](0), T.c2, 1.2, [3, 3])
                D.text(g, "补偿点", ch["X"](comp) + 3, ch["Y"](-4), T.c2, size=10)
            if sat < 1500:
                ns = model(sat, p.C, p.T)["net"]
                D.line(g, ch["X"](sat), ch["Y"](0), ch["X"](sat), ch["Y"](ns), T.c4, 1.2, [3, 3])
                D.text(g, "饱和点(95%)", ch["X"](sat) + 3, ch["Y"](ns) - 10, T.c4, size=10)
            lx, ly = 30 + lw / 2, c.h / 2
            g.fill_style = alpha("#5c9d2e", 0.75)
            g.begin_path()
            g.ellipse(lx, ly, lw / 2 - 10, lw / 4, -0.3)
            g.fill()
            D.circle(g, lx - 40, ly - 110, 18 + p.I / 60, f"rgba(255,200,40,{0.3 + p.I / 2500:.3f})")
            D.text(g, "光", lx - 40, ly - 110, T.fg, align="center")
            k = clamp(abs(m["net"]) / 25, 0.1, 1)
            inn = m["net"] >= 0
            D.arrow(g, lx + (-80 if inn else -20), ly + 60, lx + (-20 if inn else -80), ly + 60, T.c1, 1 + 4 * k)
            D.text(g, "CO₂", lx - 50, ly + 76, T.c1, align="center", size=12)
            D.arrow(g, lx + (20 if inn else 80), ly + 60, lx + (80 if inn else 20), ly + 60, T.c2, 1 + 4 * k)
            D.text(g, "O₂", lx + 50, ly + 76, T.c2, align="center", size=12)
            out.set([["总光合速率", fmt(m["P"], 2)], ["呼吸速率", fmt(m["R"], 2)], ["净光合速率", fmt(m["net"], 2)],
                     ["光补偿点", fmt(comp, 0) if comp is not None else "无（呼吸 > 最大光合）"], ["光饱和点（95%）", fmt(sat, 0)],
                     ["气体交换", "吸收 CO₂，释放 O₂" if m["net"] > 0 else "吸收 O₂，释放 CO₂" if m["net"] < 0 else "无净交换"]])
        else:
            hrs = [i / 10 for i in range(241)]
            Imax = p.I

            def light(h):
                return max(0.0, Imax * math.sin(PI * (h - 6) / 12))
            co2, series, nets = 1000.0, [], []
            for h in hrs:
                n = model(light(h), p.C * co2 / 1000, p.T)["net"]
                nets.append((h, n))
                series.append((h, co2))
                co2 = max(80.0, co2 - n * 2.4)
            gh = (c.h - 90) / 2
            ch = D.chart(g, 50, 30, c.w - 80, gh, [{"pts": series, "color": T.c1, "w": 2.4}], title="密闭容器内 CO₂ 浓度（相对）", xl="时刻 / h", xmin=0, xmax=24)
            ny = [q[1] for q in nets]
            D.chart(g, 50, 60 + gh, c.w - 80, gh, [{"pts": nets, "color": T.c3, "w": 2.2},
                                                   {"pts": [(h, light(h) / Imax * 10 if Imax else 0) for h in hrs], "color": alpha(T.c4, 0.8), "w": 1.4, "dash": [4, 3]}],
                    title="净光合速率（实线）与光照（虚线）", xl="时刻 / h", xmin=0, xmax=24, ymin=min([-5] + ny), ymax=max([10] + ny) * 1.1)
            ext = [nets[i][0] for i in range(1, len(nets)) if nets[i - 1][1] * nets[i][1] < 0]
            for h in ext:
                D.line(g, ch["X"](h), 30, ch["X"](h), 60 + 2 * gh, T.c2, 1, [3, 3])
                D.text(g, fmt(h, 1) + " 时", ch["X"](h) + 3, 44, T.c2, size=10)
            d = series[-1][1] - series[0][1]
            out.set([["光合 = 呼吸的时刻", "、".join(fmt(h, 1) + " 时" for h in ext) or "无"], ["CO₂ 最低点", fmt(ext[1], 1) + " 时" if len(ext) > 1 else "—"],
                     ["24 时 − 0 时 CO₂", fmt(d, 0)], ["一昼夜有机物", "积累（植物能生长）" if d < 0 else "减少（植物不能生长）"]])
    L.on_draw(draw)


# ---------------------------------------------------------------- 细胞分裂（有丝 / 减数）
MIT = ["间期", "前期", "中期", "后期", "末期", "子细胞"]
MEI = ["减Ⅰ 前期", "减Ⅰ 中期", "减Ⅰ 后期", "减Ⅰ 末期", "减Ⅱ 前期", "减Ⅱ 中期", "减Ⅱ 后期", "减Ⅱ 末期"]
# [染色体数, 核 DNA 数, 染色单体数, 同源染色体对数]（2n = 4）
CNT = {"mit": [[4, "4→8", "0→8", 2], [4, 8, 8, 2], [4, 8, 8, 2], [8, 8, 0, 4], [4, 4, 0, 2], [4, 4, 0, 2]],
       "mei": [[4, 8, 8, 2], [4, 8, 8, 2], [4, 8, 8, 2], [2, 4, 4, 0], [2, 4, 4, 0], [2, 4, 4, 0], [4, 4, 0, 0], [2, 2, 0, 0]]}
DNA = {"mit": [(0, 4), (0.5, 8), (1, 8), (2, 8), (3, 8), (4, 8), (4.5, 4), (5, 4)], "mei": [(0, 8), (3, 8), (3.5, 4), (6, 4), (6.5, 2), (7, 2)]}
RED, BLUE = "#d6453d", "#3b6fd8"


def cell_division(L, start_mode):
    c = L.canvas()
    S = {"mode": start_mode, "stage": 0, "orient": [0, 1], "cross": False}

    def names():
        return MIT if S["mode"] == "mit" else MEI

    def on_mode(m):
        S["mode"], S["stage"] = m, 0
        sl.set_range(0, len(names()) - 1)
        sl.set(0, True)
        L.draw()
    L.group("分裂方式")
    L.seg("", [["mit", "有丝分裂"], ["mei", "减数分裂"]], start_mode, on_mode)
    L.group("时期")

    def on_stage(v):
        S["stage"] = int(v)
        L.draw()
    sl = L.slider("时期", 0, len(names()) - 1, 1, 0, on_stage, lambda v: names()[int(v)])
    L.button("上一期", lambda _b: sl.set(max(0, S["stage"] - 1)))
    L.button("下一期", lambda _b: sl.set(min(len(names()) - 1, S["stage"] + 1)), True)
    acc = [0.0]

    def tick(dt):
        acc[0] += dt
        if acc[0] > 1.6:
            acc[0] = 0
            sl.set((S["stage"] + 1) % len(names()))
    play = L.loop(tick, False)
    L.button("自动播放", lambda _b: play.toggle())
    L.check("减数分裂中发生交叉互换", False, lambda v: (S.__setitem__("cross", v), L.draw()))

    def reorient(_b):
        S["orient"] = [random.randint(0, 1), random.randint(0, 1)]
        L.draw()
    L.button("换一种非同源染色体组合", reorient)
    out = L.out()

    def draw():
        c.clear()
        g = c.g
        mode, s, cross = S["mode"], S["stage"], S["cross"]
        cw = c.w * 0.62
        R = min(cw * 0.36, c.h * 0.36)
        CX, CY = cw / 2 + 10, c.h / 2
        lenA, lenB, wd = R * 0.34, R * 0.2, max(4, R * 0.055)
        g.line_cap = "round"

        def bar(x, y, ln, ang, col, tip=None):
            dx, dy = math.cos(ang) * ln / 2, math.sin(ang) * ln / 2
            D.line(g, x - dx, y - dy, x + dx, y + dy, col, wd)
            if tip:
                D.line(g, x + dx * 0.35, y + dy * 0.35, x + dx, y + dy, tip, wd)

        def X(x, y, ln, ang, col, tips=(None, None)):
            nx, ny = -math.sin(ang) * wd * 0.55, math.cos(ang) * wd * 0.55
            bar(x - nx, y - ny, ln, ang, col, tips[0])
            bar(x + nx, y + ny, ln, ang, col, tips[1])
            D.circle(g, x, y, wd * 0.55, T.fg)

        def cell(x, y, r, ry=None):
            g.begin_path()
            g.ellipse(x, y, r, ry or r)
            g.fill_style = alpha("#f4c7b0", 0.12 if T.dark else 0.35)
            g.fill()
            g.stroke_style, g.line_width = T.fg, 1.8
            g.stroke()

        def spindle(x1, y1, x2, y2, targets):
            D.circle(g, x1, y1, 3, T.fg)
            D.circle(g, x2, y2, 3, T.fg)
            for tx, ty, side in targets:
                if side <= 0:
                    D.line(g, x1, y1, tx, ty, alpha(T.muted, 0.6), 0.8)
                if side >= 0:
                    D.line(g, x2, y2, tx, ty, alpha(T.muted, 0.6), 0.8)

        chromo = [("A", 0), ("A", 1), ("B", 0), ("B", 1)]

        def col_of(par):
            return BLUE if par else RED

        def len_of(k):
            return lenA if k == "A" else lenB

        def tip_for(k, par, side):
            return col_of(1 - par) if cross and k == "A" and side == (0 if par else 1) else None

        def caption(t, dy=20):
            D.text(g, t, CX, CY + R + dy, T.muted, align="center", size=12)

        if mode == "mit":
            if s <= 3:
                cell(CX, CY, R)
            if s == 0:
                D.circle(g, CX, CY, R * 0.45, alpha(T.c5, 0.08), T.fg, 1.2)
                for i, (k, par) in enumerate(chromo):
                    g.stroke_style, g.line_width = col_of(par), 2
                    g.begin_path()
                    for j in range(30):
                        a = i * 1.7 + j * 0.35
                        r = R * (0.08 + 0.3 * (j / 30))
                        (g.line_to if j else g.move_to)(CX + r * math.cos(a) + math.sin(j) * 4, CY + r * math.sin(a))
                    g.stroke()
                D.text(g, "染色质", CX, CY + R * 0.6, T.muted, align="center", size=12)
                caption("DNA 复制和有关蛋白质合成")
            elif s == 1:
                g.dash = [5, 6]
                D.circle(g, CX, CY, R * 0.5, None, T.muted, 1.2)
                g.dash = []
                spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, [])
                for i, (k, par) in enumerate(chromo):
                    X(CX + [-0.2, 0.18, -0.05, 0.25][i] * R, CY + [-0.2, 0.15, 0.25, -0.25][i] * R, len_of(k), [0.4, 1.9, 2.6, 1][i], col_of(par))
                caption("核膜、核仁消失，出现染色体和纺锤体")
            elif s == 2:
                ys = [-0.45, -0.15, 0.15, 0.45]
                spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, [(CX, CY + y * R, 0) for y in ys])
                D.line(g, CX, CY - R * 0.8, CX, CY + R * 0.8, alpha(T.c4, 0.6), 1, [4, 4])
                for i, (k, par) in enumerate(chromo):
                    X(CX, CY + ys[i] * R, len_of(k), PI / 2, col_of(par))
                caption("着丝粒排列在赤道板上")
            elif s == 3:
                ys = [-0.45, -0.15, 0.15, 0.45]
                spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, [])
                for i, (k, par) in enumerate(chromo):
                    for sd in (-1, 1):
                        x, y = CX + sd * R * 0.5, CY + ys[i] * R * 0.7
                        D.line(g, CX + sd * R * 0.9, CY, x, y, alpha(T.muted, 0.6), 0.8)
                        bar(x + sd * len_of(k) * 0.3, y, len_of(k) * 0.9, 0.0, col_of(par))
                        D.circle(g, x, y, wd * 0.5, T.fg)
                caption("着丝粒分裂，姐妹染色单体分开，移向两极")
            else:
                off = R * 0.55 if s == 4 else R * 0.75
                rr = R * 0.62 if s == 4 else R * 0.6
                for sd in (-1, 1):
                    cell(CX + sd * off, CY, rr, R * 0.85 if s == 4 else rr)
                    D.circle(g, CX + sd * off, CY, rr * 0.45, alpha(T.c5, 0.08), T.fg, 1)
                    for i, (k, par) in enumerate(chromo):
                        bar(CX + sd * off + [-0.12, 0.1, -0.05, 0.12][i] * rr, CY + [-0.15, 0.12, 0.2, -0.2][i] * rr, len_of(k) * 0.6, [0.3, 1.2, 2, 2.6][i], col_of(par))
                caption("细胞膜从中部向内凹陷（动物细胞），核膜重新出现" if s == 4 else "两个子细胞染色体组成与亲代完全相同")
        else:
            oa, ob = S["orient"]
            if s <= 2:
                cell(CX, CY, R)
            if s == 0:
                D.circle(g, CX, CY, R * 0.55, None, alpha(T.muted, 0.6), 1)
                for k, x, y in (("A", -0.15, -0.2), ("B", 0.2, 0.2)):
                    X(CX + x * R - wd * 1.3, CY + y * R, len_of(k), 1.2, RED, (None, tip_for(k, 0, 1)))
                    X(CX + x * R + wd * 1.3, CY + y * R, len_of(k), 1.2, BLUE, (tip_for(k, 1, 0), None))
                caption("同源染色体联会，形成 2 个四分体" + ("，非姐妹染色单体交叉互换" if cross else ""))
            elif s == 1:
                D.line(g, CX, CY - R * 0.8, CX, CY + R * 0.8, alpha(T.c4, 0.6), 1, [4, 4])
                spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, [(CX - R * 0.1, CY - R * 0.3, -1), (CX + R * 0.1, CY - R * 0.3, 1),
                                                             (CX - R * 0.1, CY + R * 0.3, -1), (CX + R * 0.1, CY + R * 0.3, 1)])
                for k, y, o in (("A", -0.3, oa), ("B", 0.3, ob)):
                    X(CX - R * 0.1, CY + y * R, len_of(k), PI / 2, col_of(o), (tip_for(k, 1, 0) if o else None, None if o else tip_for(k, 0, 1)))
                    X(CX + R * 0.1, CY + y * R, len_of(k), PI / 2, col_of(1 - o), (None if o else tip_for(k, 1, 0), tip_for(k, 0, 1) if o else None))
                caption("同源染色体成对排列在赤道板两侧")
            elif s == 2:
                spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, [])
                for k, y, o in (("A", -0.3, oa), ("B", 0.3, ob)):
                    X(CX - R * 0.55, CY + y * R, len_of(k), 1.0, col_of(o))
                    X(CX + R * 0.55, CY + y * R, len_of(k), 2.1, col_of(1 - o))
                caption("同源染色体分离，非同源染色体自由组合")
            elif s <= 6:
                off, rr = R * 0.62, R * 0.5
                for sd in (-1, 1):
                    ox = CX + sd * off
                    sset = [("A", oa if sd < 0 else 1 - oa), ("B", ob if sd < 0 else 1 - ob)]
                    cell(ox, CY, rr, R * 0.8 if s == 3 else rr * 1.15)
                    if s in (3, 4):
                        for i, (k, par) in enumerate(sset):
                            X(ox + (0.15 if i else -0.15) * rr, CY + (0.25 if i else -0.25) * rr, len_of(k), 0.6 + i, col_of(par))
                    if s == 5:
                        spindle(ox, CY - rr * 1.05, ox, CY + rr * 1.05, [(ox + (0.25 if i else -0.25) * rr, CY, 0) for i in range(2)])
                        for i, (k, par) in enumerate(sset):
                            X(ox + (0.25 if i else -0.25) * rr, CY, len_of(k) * 0.9, 0, col_of(par))
                    if s == 6:
                        for i, (k, par) in enumerate(sset):
                            for v in (-1, 1):
                                x, y = ox + (0.25 if i else -0.25) * rr, CY + v * rr * 0.6
                                bar(x, y - v * len_of(k) * 0.3, len_of(k) * 0.8, PI / 2, col_of(par))
                                D.circle(g, x, y, wd * 0.5, T.fg)
                caption(["减Ⅰ 结束：形成 2 个子细胞，染色体数目减半", "减Ⅱ 前期：无同源染色体", "减Ⅱ 中期：着丝粒排列在赤道板上",
                         "减Ⅱ 后期：着丝粒分裂，姐妹染色单体分开"][s - 3])
            else:
                rr = R * 0.42
                for j, (sx, sy) in enumerate(((-1, -1), (-1, 1), (1, -1), (1, 1))):
                    ox, oy = CX + sx * R * 0.55, CY + sy * R * 0.52
                    half = 0 if sx < 0 else 1
                    sset = [("A", 1 - oa if half else oa), ("B", 1 - ob if half else ob)]
                    cell(ox, oy, rr)
                    D.circle(g, ox, oy, rr * 0.5, alpha(T.c5, 0.08), T.fg, 1)
                    for i, (k, par) in enumerate(sset):
                        tip = col_of(1 - par) if cross and k == "A" and j % 2 == 1 else None
                        bar(ox + (0.15 if i else -0.15) * rr, oy, len_of(k) * 0.75, PI / 2 + (0.3 if i else -0.3), col_of(par), tip)
                caption("形成 4 个子细胞（精细胞），染色体数目为体细胞的一半", 26)
        g.line_cap = "butt"
        nm = names()
        gx = cw + 20
        gw = c.w - gx - 16
        if gw > 120:
            xmax = 5 if mode == "mit" else 7
            hh = c.h * 0.45
            ch = D.chart(g, gx, 30, gw, hh, [{"pts": DNA[mode], "color": T.c1, "w": 2.2}], title="每个细胞核 DNA 含量（2n = 4）", xmin=0, xmax=xmax, ymin=0, ymax=9)
            xs = [0.25, 1.5, 2.5, 3.5, 4.25, 4.8] if mode == "mit" else [0.5, 1.5, 2.5, 3.25, 4.5, 5.5, 6.25, 6.8]
            D.line(g, ch["X"](xs[s]), 30, ch["X"](xs[s]), 30 + hh, T.c2, 1.5, [4, 3])
            for i, n in enumerate(nm):
                D.text(g, n.replace("减", ""), ch["X"](xs[i]), 30 + hh + 12 + (i % 2) * 12, T.c2 if i == s else T.muted, align="center", size=9.5)
        k = CNT[mode][s]
        out.set([["时期", nm[s]], ["染色体数", k[0]], ["核 DNA 分子数", k[1]], ["染色单体数", k[2]], ["同源染色体对数", k[3]],
                 ["四分体数", 2] if mode == "mei" and s <= 1 else None,
                 ["图例", f"<span style='color:{RED}'>■</span> 母方　<span style='color:{BLUE}'>■</span> 父方"]])
    L.on_draw(draw)


@lab.reg(id="b-mitosis", subj="bio", book=0, unit="细胞的生命历程", title="有丝分裂各时期", kw="有丝分裂 间期 前期 中期 后期 末期 染色体 染色单体 DNA 纺锤体 赤道板",
         info="<p>以 2n = 4 的动物细胞为例。红色、蓝色分别表示来自母方和父方的染色体，长、短两种形态代表两对同源染色体。</p>"
              "<p class='fb'>间期：DNA 复制和有关蛋白质合成（DNA 加倍，染色体数不变）<br>前期：膜仁消失显两体　中期：形数清晰赤道齐<br>后期：点裂数增均两极　末期：两消两现重开始</p>"
              "<p>有丝分裂的意义：亲代细胞的染色体经复制后精确地平均分配到两个子细胞中，保持了遗传性状的稳定性。</p>",
         tasks=["在哪个时期染色体数目加倍？加倍的原因是什么？", "染色单体在哪个时期形成、哪个时期消失？", "观察右侧曲线：核 DNA 含量在哪两个时期发生变化？"])
def b_mitosis(L):
    cell_division(L, "mit")
