"""分裂各时期的计数：从一个 2n=4 的细胞出发，按规则一步步推出来，不是抄表。纯数据，不依赖 Qt。

一条染色体记成 (家族, 来源, 染色单体数)：家族 0/1 是两对同源染色体，来源 m/p 是母方 / 父方。
计数规则：
  染色体数   = 着丝粒数 = 记录条数
  核 DNA     = 各条染色体的染色单体数之和（没复制的算 1）
  染色单体数 = 只数复制后、着丝粒还没分开的那些
  同源染色体 = 同一个细胞里，同一家族的母方和父方能配成几对
  染色体组   = 每个家族都凑得齐的套数
"""
N = 2   # 一个染色体组里的染色体数；体细胞 2n = 4


def start():
    return [[(family, origin, 1) for family in range(N) for origin in "mp"]]


def replicate(cells):
    """间期 DNA 复制：每条染色体变成两条姐妹染色单体，着丝粒还是一个。"""
    return [[(f, o, 2) for f, o, _ in cell] for cell in cells]


def split_sisters(cells):
    """着丝粒分开：姐妹染色单体各成一条染色体，还在同一个细胞里。"""
    return [[(f, o, 1) for f, o, c in cell for _ in range(c)] for cell in cells]


def divide_equal(cells):
    """细胞一分为二，分开的姐妹各去一边。"""
    out = []
    for cell in cells:
        a, b, waiting = [], [], set()
        for token in cell:
            if token in waiting:
                waiting.remove(token)
                b.append(token)
            else:
                waiting.add(token)
                a.append(token)
        if waiting:
            raise ValueError("着丝粒还没分开，不能这样分")
        out += [a, b]
    return out


def divide_homologs(cells):
    """减数第一次分裂：同源染色体分到两个细胞，姐妹染色单体还连在一起。"""
    out = []
    for cell in cells:
        out += [[t for t in cell if t[1] == "m"], [t for t in cell if t[1] == "p"]]
    return out


def count(cell):
    families = [[t for t in cell if t[0] == f] for f in range(N)]
    return dict(chromosomes=len(cell), dna=sum(c for _, _, c in cell), chromatids=sum(c for _, _, c in cell if c == 2),
                pairs=sum(min(sum(1 for t in fam if t[1] == "m"), sum(1 for t in fam if t[1] == "p")) for fam in families),
                sets=min(len(fam) for fam in families))


def _build():
    g1 = start()
    g2 = replicate(g1)
    late = split_sisters(g2)
    first = divide_homologs(g2)
    second = split_sisters(first)
    # (存档里的 stage, 名称, 细胞, 是否联会成四分体)；0–3 是旧存档就有的四个时期，名称不变
    return {
        "mitosis": [(4, "间期：DNA 复制前", g1, False), (5, "间期：DNA 复制后", g2, False), (0, "前期", g2, False), (1, "中期", g2, False),
                    (2, "后期", late, False), (3, "末期（每个子细胞）", divide_equal(late), False)],
        "meiosis": [(4, "间期：DNA 复制前", g1, False), (0, "减Ⅰ前期", g2, True), (5, "减Ⅰ中期", g2, True),
                    (1, "减Ⅰ后期（分裂前整细胞）", g2, False), (6, "减Ⅰ完成 / 减Ⅱ前期（每个细胞）", first, False),
                    (2, "减Ⅱ中期（每个细胞）", first, False), (7, "减Ⅱ后期（每个细胞）", second, False),
                    (3, "减Ⅱ完成（每个细胞）", divide_equal(second), False)],
    }


_PHASES = _build()
SORTABLE = (0, 1, 2, 3)     # 「逐条拖动并核对」支持的时期


def phases(mode):
    """按先后顺序的 (stage, 名称)。"""
    return [(stage, name) for stage, name, _, _ in _PHASES[mode]]


def cells(mode, stage):
    """这个时期每个细胞里的染色体记录（画图用）。"""
    for number, _, state, _ in _PHASES.get(mode, ()):
        if number == stage and type(stage) is int:
            return [sorted(cell) for cell in state]
    raise ValueError("未知的分裂时期")


def phase(mode, stage):
    for number, name, cells, tetrads in _PHASES.get(mode, ()):
        if number == stage and type(stage) is int:
            counts = [count(cell) for cell in cells]
            if any(c != counts[0] for c in counts):
                raise ValueError("各细胞计数不一致")
            return dict(counts[0], name=name, cells=len(cells), tetrads=counts[0]["pairs"] if tetrads else 0,
                        total_dna=sum(c["dna"] for c in counts), total_chromosomes=sum(c["chromosomes"] for c in counts))
    raise ValueError("未知的分裂时期")
