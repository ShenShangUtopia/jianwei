"""临时装片 + 光学显微镜 + 渗透（质壁分离）的教学模型。

纯数据、不依赖 Qt：界面只调用这里的动作、读这里算出的量；整份记录可以直接存进工作台存档。

    record = fresh(seed)          {"v": 1, "sample": {...}, "scope": {...}}
    act(record, "drop") …         制片动作；前提不满足时抛 StepError（文字直接给用户看）
    focus_by / move_by / set_*    显微镜操作
    advance(record, dt)           模型时间推进（染色、引流扩散、渗透）
    optics / focus_state / issues / checklist / readout    由状态算出的量

带「来源」的常数见 SOURCES；标「假设」的量没有找到可核对的定标数据，只保证量级和变化方向。
"""
from __future__ import annotations

import math
import random

V = 1


class StepError(ValueError):
    """动作的前提不满足；str(exc) 是给用户看的原因。"""


# ---------------------------------------------------------------- 光学
WAVELENGTH = 0.55   # µm，绿光
# 消色差物镜：数值孔径、工作距离（µm）、景深（µm）。offset 是齐焦误差（假设），换物镜后要用细准焦螺旋补。
OBJECTIVES = {
    4: dict(na=0.10, wd=30000.0, dof=55.5, offset=0.0),
    10: dict(na=0.25, wd=6100.0, dof=8.5, offset=6.0),
    40: dict(na=0.65, wd=650.0, dof=1.0, offset=-9.0),
}
# 目镜视场数（mm）。5×、10× 取自来源；16× 的 11 mm 是假设。
EYEPIECES = {5: 20.0, 10: 18.0, 16: 11.0}
# 遮光器五档光圈对应的照明数值孔径（假设：最大一档刚好配满 40× 物镜，最小一档比 4× 物镜还小）。
APERTURES = {1: 0.05, 2: 0.12, 3: 0.25, 4: 0.45, 5: 0.65}
MIRRORS = {"flat": ("平面镜", 1.0), "concave": ("凹面镜", 1.8)}   # 凹面镜聚光的增益是假设
STAGE_MIN, STAGE_MAX = -15000.0, 7000.0     # 载物台行程（µm，0 = 4× 物镜对准标本平面）
COARSE, FINE = 100.0, 0.5                    # 每格：粗 / 细准焦螺旋（µm）
TRAVEL_X, TRAVEL_Y = 14000.0, 9000.0         # 装片在载物台上能移动的范围（µm）
COVER = 18000.0                              # 盖玻片边长（µm）
SLIDE_W, SLIDE_H = 76000.0, 26000.0          # 载玻片（µm）

# ---------------------------------------------------------------- 标本与液体
SPECIMENS = {
    "onion_inner": dict(name="洋葱鳞片叶内表皮", short="内表皮", layers=1, purple=False),
    "onion_outer": dict(name="紫色洋葱鳞片叶外表皮", short="紫色外表皮", layers=1, purple=True),
    "onion_chunk": dict(name="一小块洋葱鳞片叶（没有撕薄）", short="鳞片叶小块", layers=4, purple=False),
}
GAS_R, TEMP = 8.314, 298.15


def van_t_hoff(mol_per_litre: float) -> float:
    """稀溶液近似的渗透压（MPa）。高浓度蔗糖实际值更高，这里明确按近似算。"""
    return mol_per_litre * 1000.0 * GAS_R * TEMP / 1e6


SUCROSE_M = 342.3
LIQUIDS = {
    "water": dict(name="清水", pi=0.0),
    "iodine": dict(name="碘液", pi=0.0),
    "sucrose03": dict(name="0.3 g/mL 蔗糖溶液", pi=van_t_hoff(300.0 / SUCROSE_M)),
    "sucrose05": dict(name="0.5 g/mL 蔗糖溶液", pi=van_t_hoff(500.0 / SUCROSE_M)),
}
STRIPS = 12             # 盖玻片下的液体沿引流方向分成 12 条，各自记录是什么液体
STAIN_TAU = 45.0        # 碘液着色的时间常数（s，假设：课堂上约一两分钟染好）
DIFFUSE = 0.0015        # 不引流时液体自己渗进去的速度（每秒占盖玻片宽度的比例，假设）

# 渗透：v 是原生质体相对体积，v = 1 是刚好不压细胞壁（初始质壁分离点）。
PI0 = 0.574             # v = 1 时细胞液渗透压（MPa）：由充分吸水时膨压 0.54 MPa 反推，见 SOURCES
B_FRAC = 0.20           # 不参与渗透的体积比例（假设）
EPS = 10.8              # 细胞壁体积弹性模量（MPa）：假设充分吸水时体积比初始质壁分离点大 5%
V_WATER = 1.05          # 清水里平衡时的 v
K_WATER = 0.004         # 水透过速率（1/(MPa·s)，假设：0.3 g/mL 蔗糖里一两分钟明显分离）
V_CRIT = 0.38           # 失水到这以下开始快速受损（假设）
DEEP_RATE = 0.0786      # 过度失水的受损速率（每秒每单位 v，假设：0.5 g/mL 蔗糖几分钟后失活）
LONG_TAU = 1800.0       # 长时间处于分离状态的受损时间尺度（s，假设）

SOURCES = [
    ("物镜数值孔径、工作距离（消色差 4×/0.10、10×/0.25、40×/0.65；30.0、6.1、0.65 mm）",
     "Nikon MicroscopyU, Properties of Microscope Objectives",
     "https://www.microscopyu.com/microscopy-basics/properties-of-microscope-objectives"),
    ("景深 55.5 / 8.5 / 1.0 µm",
     "Nikon MicroscopyU, Depth of Field and Depth of Focus, Table 1",
     "https://www.microscopyu.com/microscopy-basics/depth-of-field-and-depth-of-focus"),
    ("分辨极限 r = 1.22λ / (NA物镜 + NA聚光)，光圈开足时即 0.61λ / NA",
     "Nikon MicroscopyU, Resolution", "https://www.microscopyu.com/microscopy-basics/resolution"),
    ("视野直径 = 目镜视场数 / 物镜倍数；10× 目镜视场数 16–18 mm，5× 约 20 mm",
     "Nikon MicroscopyU, Field of View", "https://www.microscopyu.com/microscopy-basics/field-of-view"),
    ("透射光下像的亮度 ∝ (NA / M)²",
     "Nikon MicroscopyU, Image Brightness", "https://www.microscopyu.com/microscopy-basics/image-brightness"),
    ("有效放大倍数 = 500–1000 × NA",
     "Nikon MicroscopyU, Useful Magnification Range",
     "https://www.microscopyu.com/microscopy-basics/useful-magnification-range"),
    ("洋葱表皮细胞充分吸水时膨压 0.54 ± 0.02 MPa（只读到检索摘要，原文页面有人机验证，未通读）",
     "Wei, Lintilhac & Tanguay (2001) Plant Physiology", "https://pmc.ncbi.nlm.nih.gov/articles/PMC116469/"),
]
ASSUMPTIONS = [
    "洋葱表皮细胞长约 0.2–0.4 mm、宽约 0.05–0.08 mm，细胞核长径约 20 µm：课堂测量的常见量级，没有取得可核对的文献数值。",
    "16× 目镜视场数 11 mm、遮光器各档照明孔径、凹面镜增益 1.8、齐焦误差 ±10 µm 以内。",
    "碘液着色时间常数 45 s；不引流时液体渗入速度。",
    "渗透模型：van't Hoff 稀溶液近似；不参与渗透的体积 20%；充分吸水比初始质壁分离点体积大 5%；水透过速率、失活阈值与速率为示意量级。",
    "盖玻片下的液体按 12 条记录，细胞之间的差异（±15%）为示意。",
]


# ---------------------------------------------------------------- 记录
def fresh_sample(seed: int) -> dict:
    return dict(v=V, seed=int(seed) % 1000003, clock=0.0, slide_clean=False, cover_clean=False,
                water=0, specimen=None, spread=False, at=[0.0, 0.0], rot=0.0,
                cover=None, fill=0.0, bubbles=[], bath=[None] * STRIPS, dye=[0.0] * STRIPS,
                vol=[V_WATER] * STRIPS, damage=[0.0] * STRIPS, edge=None, crack=None, log=[])


def fresh_scope() -> dict:
    return dict(objective=4, eyepiece=10, z=-9000.0, x=0.0, y=0.0, aperture=3, mirror="flat", loaded=False)


def fresh(seed: int = 1) -> dict:
    return dict(v=V, sample=fresh_sample(seed), scope=fresh_scope())


def _num(value, lo, hi) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and lo <= value <= hi


def valid(record) -> bool:
    """存档里的记录能不能用。不能用时调用方保留原记录、不覆盖。"""
    try:
        if not isinstance(record, dict) or record.get("v") != V:
            return False
        s, m = record["sample"], record["scope"]
        if s.get("v") != V or type(s["seed"]) is not int or not _num(s["clock"], 0, 1e9):
            return False
        if s["specimen"] not in (None, *SPECIMENS) or s["cover"] not in (None, "angled", "flat"):
            return False
        if type(s["water"]) is not int or not 0 <= s["water"] <= 4 or not _num(s["fill"], 0, 4):
            return False
        if not all(type(s[k]) is bool for k in ("slide_clean", "cover_clean", "spread")):
            return False
        if not (isinstance(s["at"], list) and len(s["at"]) == 2 and all(_num(a, -9000, 9000) for a in s["at"])):
            return False
        if not _num(s["rot"], -180, 180):
            return False
        for key, lo, hi in (("dye", 0, 1e9), ("vol", B_FRAC, 1.3), ("damage", 0, 2.0)):
            if not (isinstance(s[key], list) and len(s[key]) == STRIPS and all(_num(a, lo, hi) for a in s[key])):
                return False
        if not (isinstance(s["bath"], list) and len(s["bath"]) == STRIPS and all(a is None or a in LIQUIDS for a in s["bath"])):
            return False
        if not isinstance(s["bubbles"], list) or len(s["bubbles"]) > 60:
            return False
        for b in s["bubbles"]:
            if not (isinstance(b, list) and len(b) == 3 and _num(b[0], -COVER, COVER) and _num(b[1], -COVER, COVER) and _num(b[2], 1, 5000)):
                return False
        e = s["edge"]
        if e is not None and not (isinstance(e, dict) and e.get("liquid") in LIQUIDS and _num(e.get("drawn"), 0, 1)):
            return False
        c = s["crack"]
        if c is not None and not (isinstance(c, list) and len(c) == 2 and all(_num(a, -SLIDE_W, SLIDE_W) for a in c)):
            return False
        if not isinstance(s["log"], list) or len(s["log"]) > 80 or not all(
                isinstance(r, list) and len(r) == 2 and _num(r[0], 0, 1e9) and isinstance(r[1], str) for r in s["log"]):
            return False
        return (m["objective"] in OBJECTIVES and m["eyepiece"] in EYEPIECES and m["aperture"] in APERTURES
                and m["mirror"] in MIRRORS and type(m["loaded"]) is bool and _num(m["z"], STAGE_MIN, STAGE_MAX)
                and _num(m["x"], -TRAVEL_X, TRAVEL_X) and _num(m["y"], -TRAVEL_Y, TRAVEL_Y))
    except (KeyError, TypeError):
        return False


def _log(s: dict, text: str) -> None:
    s["log"].append([round(s["clock"], 1), text])
    del s["log"][:-60]


# ---------------------------------------------------------------- 制片
def _wet(s: dict) -> bool:
    return any(b is not None for b in s["bath"])


def wipe(record) -> str:
    s = record["sample"]
    _off_stage(record, "擦拭")
    if s["water"] or s["specimen"] or s["cover"]:
        raise StepError("载玻片上已经有液滴或材料，现在不能再擦；要重做请点「重新制片」。")
    s["slide_clean"] = s["cover_clean"] = True
    _log(s, "擦：用纱布把载玻片和盖玻片擦干净")
    return "载玻片和盖玻片已擦净。"


def drop(record, liquid: str = "water") -> str:
    s = record["sample"]
    if liquid not in LIQUIDS:
        raise StepError("没有这种液体。")
    if s["cover"]:
        return irrigate(record, liquid)
    _off_stage(record, "滴液")
    if s["water"] >= 3:
        raise StepError("液滴已经漫出载玻片了，不能再滴。")
    s["water"] += 1
    s["bath"] = [liquid if liquid != "water" or b is None else b for b in s["bath"]]
    name = LIQUIDS[liquid]["name"]
    _log(s, f"滴：在载玻片中央滴一滴{name}（共 {s['water']} 滴）")
    return f"滴了一滴{name}。" + ("液滴偏多，盖片后会漫出来。" if s["water"] >= 2 else "")


def take(record, kind: str = "onion_inner") -> str:
    s = record["sample"]
    _off_stage(record, "取材")
    if kind not in SPECIMENS:
        raise StepError("没有这种材料。")
    if s["cover"]:
        raise StepError("已经盖上盖玻片，不能再放材料。")
    if s["specimen"]:
        raise StepError("载玻片上已经有材料了；要换材料请点「重新制片」。")
    rng = random.Random(s["seed"] * 31 + 7)
    s["specimen"] = kind
    s["spread"] = False
    s["at"] = [round(rng.uniform(-1500, 1500), 1), round(rng.uniform(-1000, 1000), 1)]
    s["rot"] = round(rng.uniform(-24, 24), 1)
    _log(s, "撕：取" + SPECIMENS[kind]["name"] + ("，放进液滴" if s["water"] else "，直接放在干的载玻片上"))
    if not s["water"]:
        return "材料放在了干的载玻片上：没有液滴，材料会干缩，看不清。"
    if SPECIMENS[kind]["layers"] > 1:
        return "材料放进了液滴。这块没有撕薄，有好几层细胞。"
    return "材料放进了液滴。"


def spread(record) -> str:
    s = record["sample"]
    _off_stage(record, "展平")
    if not s["specimen"]:
        raise StepError("还没有材料可以展平。")
    if s["cover"]:
        raise StepError("已经盖上盖玻片，不能再展平。")
    if not s["water"]:
        raise StepError("没有液滴，材料展不开：先滴一滴清水。")
    if s["spread"]:
        raise StepError("材料已经展平了。")
    s["spread"] = True
    _log(s, "展：用解剖针把材料在液滴里展平")
    return "材料已经展平。" if SPECIMENS[s["specimen"]]["layers"] == 1 else "展开了，但这块材料本身太厚。"


def cover(record, method: str = "angled") -> str:
    s = record["sample"]
    _off_stage(record, "盖盖玻片")
    if method not in ("angled", "flat"):
        raise StepError("盖片方式无效。")
    if s["cover"]:
        raise StepError("已经盖过盖玻片了。")
    rng = random.Random(s["seed"] * 131 + (1 if method == "flat" else 0))
    s["cover"] = method
    s["fill"] = {0: 0.0, 1: 1.0, 2: 1.6, 3: 2.2}[s["water"]]
    cx, cy = s["at"] if s["specimen"] else (0.0, 0.0)
    bubbles = []

    def add(n, lo, hi, reach):
        for _ in range(n):
            r = rng.uniform(lo, hi)
            bubbles.append([round(_clip(cx + rng.uniform(-reach, reach), COVER / 2 - r), 1),
                            round(_clip(cy + rng.uniform(-reach * 0.8, reach * 0.8), COVER / 2 - r), 1), round(r, 1)])
    if not s["water"]:
        add(9, 500, 1600, 4200)          # 没有液体：大片空气
    elif method == "flat":
        add(rng.randint(5, 8), 90, 620, 3600)
    elif rng.random() < 0.3:
        add(1, 60, 160, 3200)
    if s["specimen"] and SPECIMENS[s["specimen"]]["layers"] > 1 and s["water"]:
        add(3, 200, 700, 3000)           # 材料太厚把盖玻片垫起来，边上进空气
    s["bubbles"] = bubbles
    _log(s, "盖：" + ("盖玻片一侧先接触液滴，再缓缓放平" if method == "angled" else "盖玻片直接平放下去") + f"（气泡 {len(bubbles)} 个）")
    if not s["water"]:
        return "盖上了，但下面没有液体，全是空气。"
    if s["fill"] > 1.3:
        return "盖上了。液体太多，从盖玻片四周漫了出来：用吸水纸吸掉再上镜。"
    return "盖上了。" + (f"压进了 {len(bubbles)} 个气泡。" if len(bubbles) > 1 else "")


def irrigate(record, liquid: str) -> str:
    """在盖玻片一侧滴一滴液体，等着被吸水纸从对侧引过去。没有盖玻片时就是直接滴。"""
    s = record["sample"]
    if liquid not in LIQUIDS:
        raise StepError("没有这种液体。")
    if not s["cover"]:
        return drop(record, liquid)
    old = s["edge"]
    if old and old["drawn"] < 1 and old["liquid"] != liquid and old["drawn"] > 0:
        raise StepError("上一滴" + LIQUIDS[old["liquid"]]["name"] + "还没有引完：先用吸水纸引完，再换液体。")
    s["edge"] = dict(liquid=liquid, drawn=0.0)
    s["fill"] = min(4.0, s["fill"] + 0.3)
    _log(s, "滴：在盖玻片一侧滴一滴" + LIQUIDS[liquid]["name"])
    return "在盖玻片左侧滴了一滴" + LIQUIDS[liquid]["name"] + "。用吸水纸在右侧吸引，它才会很快进去。"


def wick(record) -> str:
    s = record["sample"]
    if not s["cover"]:
        raise StepError("还没有盖盖玻片，吸水纸会把材料一起带走。")
    e = s["edge"]
    if e:
        e["drawn"] = min(1.0, e["drawn"] + 0.5)
        name = LIQUIDS[e["liquid"]]["name"]
        done = e["drawn"] >= 1
        _front(s)
        if s["fill"] > 1.0:
            s["fill"] = max(1.0, round(s["fill"] - 0.5, 3))
        _log(s, f"吸：吸水纸在对侧引流，{name}" + ("已经布满盖玻片下" if done else "进到一半"))
        return name + ("已经布满盖玻片下。" if done else "被引到了一半，再吸一次。")
    s["fill"] = round(max(0.0, s["fill"] - 0.35), 3)
    if s["fill"] < 0.75 and len(s["bubbles"]) < 40:
        rng = random.Random(s["seed"] * 17 + len(s["bubbles"]))
        for _ in range(2):
            r = rng.uniform(500, 1300)
            s["bubbles"].append([round(COVER / 2 - r - rng.uniform(0, 2500), 1), round(rng.uniform(-6000, 6000), 1), round(r, 1)])
        _log(s, "吸：没有补液又吸了一次，空气从边上进来了")
        return "液体吸得太多，空气从盖玻片边上进来了。"
    _log(s, "吸：用吸水纸吸去盖玻片边上多余的液体")
    return "吸掉了多余的液体。"


def _front(s: dict) -> None:
    e = s["edge"]
    if not e:
        return
    for i in range(min(STRIPS, int(e["drawn"] * STRIPS + 1e-6))):
        s["bath"][i] = e["liquid"]
    if e["drawn"] >= 1:
        s["edge"] = None


def _clip(value: float, limit: float) -> float:
    return max(-limit, min(limit, value))


def _off_stage(record, what: str) -> None:
    if record["scope"]["loaded"]:
        raise StepError(f"装片还在载物台上：先取下装片再{what}。")


def load(record) -> str:
    s, m = record["sample"], record["scope"]
    if m["loaded"]:
        raise StepError("装片已经在载物台上。")
    if s["fill"] > 1.3:
        raise StepError("盖玻片周围有多余的液体，会弄湿载物台和物镜：先用吸水纸吸去。")
    if not s["cover"] and s["water"] and m["objective"] == 40:
        raise StepError("没有盖玻片时不能对着高倍物镜放装片：物镜会沾到液体。先换回低倍物镜。")
    _check_clearance(m, m["objective"], m["z"])
    rng = random.Random(s["seed"] * 53 + 11)
    ang = rng.uniform(0, math.tau)
    m["x"] = round(_clip(s["at"][0] + math.cos(ang) * 2600, TRAVEL_X), 1)
    m["y"] = round(_clip(s["at"][1] + math.sin(ang) * 1700, TRAVEL_Y), 1)
    m["loaded"] = True
    _log(s, "把装片放上载物台，用压片夹压住")
    return "装片已放上载物台。先用低倍物镜找到物像。"


def unload(record) -> str:
    m = record["scope"]
    if not m["loaded"]:
        raise StepError("载物台上没有装片。")
    m["loaded"] = False
    _log(record["sample"], "取下装片")
    return "装片已取下。"


def reset(record) -> str:
    seed = record["sample"]["seed"] + 1
    record["sample"] = fresh_sample(seed)
    record["scope"]["loaded"] = False
    return "换了一套干净的载玻片和盖玻片。"


ACTIONS = dict(wipe=wipe, drop=drop, take=take, spread=spread, cover=cover, irrigate=irrigate, wick=wick,
               load=load, unload=unload, reset=reset)


def act(record, name: str, *args) -> str:
    return ACTIONS[name](record, *args)


# ---------------------------------------------------------------- 显微镜
def optics(scope: dict) -> dict:
    mo, me = scope["objective"], scope["eyepiece"]
    o = OBJECTIVES[mo]
    na_ill = min(APERTURES[scope["aperture"]], o["na"])
    total = mo * me
    brightness = MIRRORS[scope["mirror"]][1] * (na_ill / mo) ** 2 / (0.25 / 10) ** 2 * (10 / me) ** 2
    return dict(objective=mo, eyepiece=me, total=total, na=o["na"], na_ill=na_ill,
                field=EYEPIECES[me] / mo * 1000.0,                    # 视野直径 µm
                resolution=1.22 * WAVELENGTH / (o["na"] + na_ill),    # µm
                dof=o["dof"], wd=o["wd"], brightness=brightness,
                useful=(500 * o["na"], 1000 * o["na"]), empty=total > 1000 * o["na"])


def focus_state(scope: dict, plane: float = 0.0) -> dict:
    """plane 是被看的那一层相对标本平面的高度（µm，向上为正）。"""
    o = OBJECTIVES[scope["objective"]]
    defocus = scope["z"] + o["offset"] - plane
    excess = max(0.0, abs(defocus) - o["dof"] / 2)
    blur = 2 * excess * math.tan(math.asin(o["na"]))          # 物方弥散斑直径 µm
    return dict(defocus=defocus, blur=blur, sharp=excess == 0.0, clearance=o["wd"] - (scope["z"] + o["offset"]))


def _check_clearance(scope: dict, objective: int, z: float) -> None:
    o = OBJECTIVES[objective]
    if scope["loaded"] and o["wd"] - (z + o["offset"]) <= 0:
        raise StepError(f"{objective}× 物镜转不过来：镜头会碰到装片。先用粗准焦螺旋把载物台降下去。")


def set_objective(record, objective: int) -> str:
    s, m = record["sample"], record["scope"]
    if objective not in OBJECTIVES:
        raise StepError("没有这个物镜。")
    if objective == m["objective"]:
        return ""
    if m["loaded"] and objective == 40 and not s["cover"] and s["water"]:
        raise StepError("没有盖玻片，高倍物镜会沾到液体：不能换高倍。")
    _check_clearance(m, objective, m["z"])
    m["objective"] = objective
    if m["loaded"]:
        _log(s, f"转动转换器，换成 {objective}× 物镜")
    return f"换成 {objective}× 物镜。" + ("高倍镜下只用细准焦螺旋。" if objective == 40 else "")


def set_eyepiece(record, eyepiece: int) -> None:
    if eyepiece not in EYEPIECES:
        raise StepError("没有这个目镜。")
    record["scope"]["eyepiece"] = eyepiece


def set_aperture(record, aperture: int) -> None:
    if aperture not in APERTURES:
        raise StepError("没有这一档光圈。")
    record["scope"]["aperture"] = aperture


def set_mirror(record, mirror: str) -> None:
    if mirror not in MIRRORS:
        raise StepError("反光镜只有平面和凹面。")
    record["scope"]["mirror"] = mirror


def focus_by(record, dz: float) -> str:
    """载物台升降 dz（µm，向上为正）。返回 ''、'limit'（到头）或 'crash'（压到装片）。"""
    s, m = record["sample"], record["scope"]
    if not math.isfinite(dz):
        raise StepError("调焦量无效。")
    o = OBJECTIVES[m["objective"]]
    target = max(STAGE_MIN, min(STAGE_MAX, m["z"] + dz))
    event = "limit" if target != m["z"] + dz else ""
    if m["loaded"]:
        contact = o["wd"] - o["offset"]            # 镜头碰到盖玻片时的 z
        if target >= contact:
            over = m["z"] + dz - contact
            target = contact
            event = "limit"
            if over > 60 and s["crack"] is None:    # 镜头前端的弹簧只能让一点点
                s["crack"] = [m["x"], m["y"]]
                _log(s, f"{m['objective']}× 物镜压到了装片，盖玻片压裂了")
                event = "crash"
    m["z"] = round(target, 3)
    return event


def move_by(record, dx: float, dy: float) -> None:
    """把装片在载物台上推 (dx, dy)（µm，装片自己的坐标）。像是倒的：装片往右，视野里的像往左。"""
    m = record["scope"]
    if not (math.isfinite(dx) and math.isfinite(dy)):
        raise StepError("移动量无效。")
    # 光轴落在装片上的点 = 装片位移的反方向
    m["x"] = round(_clip(m["x"] - dx, TRAVEL_X), 2)
    m["y"] = round(_clip(m["y"] - dy, TRAVEL_Y), 2)


# ---------------------------------------------------------------- 时间
def osmotic_step(v: float, damage: float, pi_ext: float, dt: float) -> tuple:
    """一条液体带上的原生质体体积与受损程度推进 dt 秒。damage ≥ 1 即失活，不再有选择透过性。"""
    n = max(1, math.ceil(dt / 0.5))
    h = dt / n
    for _ in range(n):
        if damage >= 1.0:
            damage = min(2.0, damage + h / 300.0)       # 失活后色素慢慢漏出来
            continue
        pi_int = PI0 * (1 - B_FRAC) / (v - B_FRAC)
        turgor = EPS * (v - 1) if v > 1 else 0.0
        v += K_WATER * (pi_int - turgor - pi_ext) * h
        v = max(B_FRAC + 0.02, min(1.25, v))
        damage += h * (max(0.0, V_CRIT - v) * DEEP_RATE + max(0.0, 1 - v) / LONG_TAU)
    return v, min(2.0, damage)


def equilibrium(pi_ext: float) -> float:
    """外界渗透压下原生质体的平衡体积（不考虑失活）。"""
    if pi_ext >= PI0:
        return B_FRAC + (1 - B_FRAC) * PI0 / pi_ext
    lo, hi = 1.0, 1.25
    for _ in range(60):
        mid = (lo + hi) / 2
        if PI0 * (1 - B_FRAC) / (mid - B_FRAC) - EPS * (mid - 1) - pi_ext > 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def advance(record, dt: float) -> None:
    s = record["sample"]
    if not (math.isfinite(dt) and 0 <= dt <= 3600):
        raise StepError("时间步长无效。")
    if dt == 0:
        return
    s["clock"] = round(s["clock"] + dt, 3)
    e = s["edge"]
    if e and s["cover"]:
        e["drawn"] = min(1.0, e["drawn"] + DIFFUSE * dt)
        _front(s)
    alive = s["specimen"] in ("onion_inner", "onion_outer")
    for i, liquid in enumerate(s["bath"]):
        if liquid is None:
            continue
        if liquid == "iodine" and s["specimen"]:
            s["dye"][i] = min(1e6, s["dye"][i] + dt)
        if alive:
            v, d = osmotic_step(s["vol"][i], s["damage"][i], LIQUIDS[liquid]["pi"], dt)
            s["vol"][i], s["damage"][i] = round(v, 5), round(d, 5)


def active(record) -> bool:
    """还有没有随时间变化的东西（界面据此决定要不要继续计时）。"""
    s = record["sample"]
    if s["edge"] and s["cover"]:
        return True
    alive = s["specimen"] in ("onion_inner", "onion_outer")
    for i, liquid in enumerate(s["bath"]):
        if liquid is None:
            continue
        if liquid == "iodine" and s["specimen"] and s["dye"][i] < STAIN_TAU * 5:
            return True
        if alive:
            if 1.0 <= s["damage"][i] < 2.0 or s["vol"][i] < 0.999:
                return True
            if abs(s["vol"][i] - equilibrium(LIQUIDS[liquid]["pi"])) > 0.002:
                return True
    return False


# ---------------------------------------------------------------- 读数
def strip_of(x: float) -> int:
    """盖玻片下 x（µm，装片坐标）处是第几条液体带。引流从左（x 小）往右。"""
    return max(0, min(STRIPS - 1, int((x + COVER / 2) / COVER * STRIPS)))


def stain_at(s: dict, i: int) -> float:
    return 1 - math.exp(-s["dye"][i] / STAIN_TAU)


def cell_volume(v: float, gain: float) -> float:
    """这一带的 v 换成某个细胞的 v；gain 是细胞间差异（0.85–1.15）。"""
    return max(B_FRAC + 0.02, min(V_WATER, V_WATER - (V_WATER - v) * gain))


def plasmolysed(s: dict) -> float:
    """发生质壁分离的液体带比例（按带估计，不是逐个细胞计数）。"""
    if s["specimen"] not in ("onion_inner", "onion_outer"):
        return 0.0
    wet = [i for i, b in enumerate(s["bath"]) if b is not None]
    return sum(1 for i in wet if s["vol"][i] < 0.97) / len(wet) if wet else 0.0


def issues(s: dict) -> list:
    """装片现在有哪些会影响观察的问题。"""
    out = []
    if not s["specimen"]:
        return ["载玻片上还没有材料。"] if not s["cover"] else ["盖玻片下没有材料。"]
    kind = SPECIMENS[s["specimen"]]
    if not _wet(s):
        out.append("没有滴液：材料是干的，细胞干缩、轮廓发黑。")
    if kind["layers"] > 1:
        out.append("材料太厚：几层细胞叠在一起，透光差，调不出清楚的一层。")
    elif not s["spread"]:
        out.append("材料没有展平：有褶皱和重叠。")
    if not s["cover"]:
        out.append("还没有盖盖玻片：只能用低倍物镜。")
    n = len(s["bubbles"])
    if n > 1:
        out.append(f"盖玻片下有 {n} 个气泡。")
    if not (s["slide_clean"] and s["cover_clean"]):
        out.append("玻片没有擦：视野里有灰尘和纤维。")
    if s["fill"] > 1.3:
        out.append("盖玻片周围有多余的液体。")
    if s["crack"] is not None:
        out.append("盖玻片被物镜压裂了。")
    if not kind["purple"] and kind["layers"] == 1 and _wet(s) and max(stain_at(s, i) for i in range(STRIPS)) < 0.3:
        out.append("没有染色：细胞核很淡，不容易看清。")
    return out


def checklist(s: dict) -> list:
    """课本的七步：(名称, 状态, 说明)。状态 done / todo / issue。只是对照，不限制操作顺序。"""
    stained = max(stain_at(s, i) for i in range(STRIPS)) > 0.3
    reached = all(b == "iodine" or stain_at(s, i) > 0.3 for i, b in enumerate(s["bath"])) and _wet(s)
    rows = [
        ("擦", "done" if s["slide_clean"] else ("issue" if s["water"] or s["specimen"] else "todo"), "擦净载玻片和盖玻片"),
        ("滴", "done" if s["water"] == 1 else ("issue" if s["water"] > 1 or s["specimen"] else "todo"), "中央滴一滴清水"),
        ("撕", "todo" if not s["specimen"] else ("issue" if SPECIMENS[s["specimen"]]["layers"] > 1 else "done"), "撕取一小块内表皮"),
        ("展", "done" if s["spread"] else ("issue" if s["cover"] and s["specimen"] else "todo"), "在水滴里展平"),
        ("盖", "todo" if not s["cover"] else ("done" if len(s["bubbles"]) <= 1 else "issue"), "一侧先接触水滴，缓缓放平"),
        ("染", "done" if stained or any(b == "iodine" for b in s["bath"]) or (s["edge"] or {}).get("liquid") == "iodine" else "todo", "一侧滴碘液"),
        ("吸", "done" if stained and reached else "todo", "对侧用吸水纸引流"),
    ]
    return rows


def readout(record) -> list:
    """给面板的读数行。"""
    s, m = record["sample"], record["scope"]
    o = optics(m)
    rows = [["物镜 × 目镜", f"{o['objective']}× × {o['eyepiece']}× = {o['total']}×"],
            ["视野直径", _length(o["field"])],
            ["分辨极限", f"{o['resolution']:.2f} µm"],
            ["景深", f"{o['dof']:g} µm"]]
    if o["empty"]:
        rows.append("总倍数超过 1000 × NA：再放大也看不出更多细节。")
    if not m["loaded"]:
        rows.append("载物台上没有装片。")
        return rows
    f = focus_state(m)
    rows.append(["离焦", "在景深内" if f["sharp"] else f"{f['defocus']:+.1f} µm"])
    rows.append(["镜头到装片", _length(max(0.0, f["clearance"]))])
    if s["specimen"] in ("onion_inner", "onion_outer") and s["cover"]:
        i = strip_of(m["x"])
        liquid = s["bath"][i]
        if liquid is not None:
            rows.append(["视野中央的外界溶液", LIQUIDS[liquid]["name"]])
            rows.append(["外界渗透压（近似）", f"{LIQUIDS[liquid]['pi']:.2f} MPa"])
            rows.append(["原生质体相对体积", f"{s['vol'][i]:.2f}"])
            rows.append(["这一带的细胞", "已失活" if s["damage"][i] >= 1 else "存活"])
    return rows


def advice(record) -> str:
    """现在最该做的一件事（界面中间那行提示）。"""
    s, m = record["sample"], record["scope"]
    if not m["loaded"]:
        if not s["specimen"] and not s["cover"]:
            return "先在左边制片：擦 → 滴 → 撕 → 展 → 盖，再放上载物台。"
        if not s["cover"]:
            return "材料放好了：展平、盖上盖玻片，再放上载物台。"
        return "装片做好了：点「放上载物台」开始观察。"
    o = optics(m)
    f = focus_state(m)
    if o["brightness"] < 0.12:
        return "视野太暗：调大光圈，或把反光镜换成凹面镜。"
    if o["brightness"] > 1.3:
        return "视野太亮、发白：调小光圈。"
    if f["blur"] > o["field"] / 70:
        if m["objective"] == 40:
            return "物像模糊：高倍镜下只转细准焦螺旋。" if abs(f["defocus"]) < 60 else "离焦太远：换回低倍物镜重新找物像。"
        return "物像模糊：转粗准焦螺旋找到物像，再用细准焦螺旋调清楚。"
    if not s["specimen"]:
        return "视野里没有材料：这张装片上什么都没放。"
    dx, dy = m["x"] - s["at"][0], m["y"] - s["at"][1]
    if abs(dx) > 2500 + o["field"] / 2 or abs(dy) > 1900 + o["field"] / 2:
        return "视野里没有材料：在左边拖动装片，把材料移到通光孔上。"
    if m["objective"] < 40:
        return "物像清楚了。把要看的细胞移到视野中央，再换高倍物镜。"
    if not f["sharp"]:
        return "来回转细准焦螺旋：细胞壁、细胞核、核仁不在同一层上。"
    found = issues(s)
    return found[0] if found else "高倍镜下看清了：细胞壁、细胞核和核仁。"


def _length(um: float) -> str:
    return f"{um / 1000:.3g} mm" if um >= 1000 else f"{um:.3g} µm"


def scale_bar(field_um: float) -> float:
    """比视野直径的四分之一短一点的整数比例尺（µm）。"""
    target = field_um / 4
    for step in (2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1):
        if step <= target:
            return float(step)
    return 1.0
