"""制片与显微观察：左边制片台 / 载物台，中间目镜视野，右边显微镜。

状态全在 parameters["slide"]（bio_slide 的记录，纯数据），跟着生物工作台的存档走。
窗口只在显示时计时；没有随时间变化的东西时计时器停着。
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QFontMetrics, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QMenu, QPushButton, QScrollArea, QVBoxLayout, QWidget

from ...design.tokens import RADIUS, T, family, font, qc
from ...design.widgets import Segmented, qss
from . import bio_slide as M
from .bio_scope_view import _col, exposure, paint_slide, render, stamp

SPEEDS = (("1", "×1"), ("10", "×10"), ("60", "×60"))
TICK_MS = 100


class Eyepiece(QWidget):
    """目镜视野。滚轮 = 细准焦螺旋，Ctrl + 滚轮 = 粗准焦螺旋。"""
    focus = Signal(float)

    def __init__(self, dialog: "ScopeDialog"):
        super().__init__()
        self.dialog = dialog
        self.setMinimumSize(340, 340)
        self._key = None
        self._img = None
        self.renders = 0
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.setToolTip("滚轮：细准焦螺旋　Ctrl + 滚轮：粗准焦螺旋　方向键：移动装片")

    def side(self) -> int:
        return max(200, min(self.width(), self.height() - 30, 660))

    def image(self):
        record = self.dialog.record
        side = self.side()
        dpr = min(2.0, self.devicePixelRatioF())
        key = (stamp(record), side, dpr)
        if key != self._key:
            self._img = render(record, side, dpr)
            self._key = key
            self.renders += 1
        return self._img

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        p.fillRect(self.rect(), _col((8, 8, 8)))
        side = self.side()
        x, y = (self.width() - side) / 2, max(0.0, (self.height() - 30 - side) / 2)
        p.drawImage(QRectF(x, y, side, side), self.image())
        record = self.dialog.record
        o = M.optics(record["scope"])
        bar = M.scale_bar(o["field"])
        w = bar / o["field"] * side
        bx, by = x + side * 0.5 - w / 2, y + side + 12
        p.setPen(QPen(_col((235, 235, 235)), 2))
        p.drawLine(QPointF(bx, by), QPointF(bx + w, by))
        p.drawLine(QPointF(bx, by - 4), QPointF(bx, by + 4))
        p.drawLine(QPointF(bx + w, by - 4), QPointF(bx + w, by + 4))
        p.setFont(font(12, 700, "mono"))
        p.drawText(QRectF(bx + w + 8, by - 10, 160, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), M._length(bar))
        p.setPen(_col((150, 150, 150)))
        p.setFont(font(11.5))
        p.drawText(QRectF(8, by - 10, bx - 16, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "显微像是倒像")
        p.end()

    def wheelEvent(self, e):  # noqa: N802
        steps = e.angleDelta().y() / 120
        coarse = bool(e.modifiers() & Qt.KeyboardModifier.ControlModifier)
        self.focus.emit(steps * (M.COARSE if coarse else M.FINE))
        e.accept()

    def keyPressEvent(self, e):  # noqa: N802
        step = M.optics(self.dialog.record["scope"])["field"] / 20
        move = {Qt.Key.Key_Left: (-step, 0), Qt.Key.Key_Right: (step, 0), Qt.Key.Key_Up: (0, -step), Qt.Key.Key_Down: (0, step)}.get(e.key())
        if move and self.dialog.record["scope"]["loaded"]:
            self.dialog.push(*move)
            e.accept()
            return
        super().keyPressEvent(e)


class Bench(QWidget):
    """没上镜：载玻片俯视图。上了镜：载物台俯视，拖动装片。"""

    def __init__(self, dialog: "ScopeDialog"):
        super().__init__()
        self.dialog = dialog
        self.setMinimumHeight(190)
        self._drag = None
        self._k = 1.0
        self.wicking = False

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect())
        record = self.dialog.record
        s, m = record["sample"], record["scope"]
        clip = QPainterPath()
        clip.addRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), RADIUS["md"], RADIUS["md"])
        p.setClipPath(clip)
        c = QPointF(r.center().x(), r.center().y() + 8)
        k = (r.width() - 20) / (M.SLIDE_W * 0.62)       # 只画载玻片中间一段，两头裁掉，细节才看得清
        self._k = k
        if not m["loaded"]:
            p.fillRect(r, qc(T.stage))
            w, h = M.SLIDE_W * k, M.SLIDE_H * k
            paint_slide(p, QRectF(c.x() - w / 2, c.y() - h / 2, w, h), s, self.wicking)
            p.setClipping(False)
            p.setPen(QPen(qc(T.line), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), RADIUS["md"], RADIUS["md"])
            p.setPen(qc(T.muted))
            p.setFont(font(11.5, 700))
            p.drawText(r.adjusted(10, 6, -10, 0), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop), "制片台（俯视）")
            p.end()
            return
        p.fillRect(r, _col((38, 42, 44)))
        level, _glare = exposure(M.optics(m))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_col(tuple(v * (0.35 + 0.65 * level) for v in (255, 250, 232))))
        p.drawEllipse(c, 4200 * k, 4200 * k)
        w, h = M.SLIDE_W * k, M.SLIDE_H * k
        box = QRectF(c.x() - m["x"] * k - w / 2, c.y() - m["y"] * k - h / 2, w, h)
        paint_slide(p, box, s, self.wicking)
        p.setPen(QPen(_col((200, 205, 208)), 2.4))
        for sx in (-1, 1):       # 压片夹
            p.drawLine(QPointF(c.x() + sx * r.width() * 0.47, c.y() - h * 0.75), QPointF(c.x() + sx * r.width() * 0.30, c.y() - h * 0.18))
        p.setPen(QPen(_col((255, 90, 60)), 1.2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(c, max(2.5, M.optics(m)["field"] / 2 * k), max(2.5, M.optics(m)["field"] / 2 * k))
        p.setPen(_col((200, 205, 208)))
        p.setFont(font(11.5, 700))
        p.drawText(r.adjusted(10, 6, -10, 0), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop), "载物台（俯视）· 拖动装片")
        p.end()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton and self.dialog.record["scope"]["loaded"]:
            self._drag = e.position()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._drag is not None:
            d = e.position() - self._drag
            self._drag = e.position()
            self.dialog.push(d.x() / self._k, d.y() / self._k)

    def mouseReleaseEvent(self, _e):  # noqa: N802
        self._drag = None
        self.unsetCursor()


class Knob(QWidget):
    """准焦螺旋：按住上下拖，或在上面滚轮。向上 = 载物台上升。"""
    turned = Signal(float)

    def __init__(self, label: str, per_px: float, per_notch: float, big: bool):
        super().__init__()
        self.label, self.per_px, self.per_notch, self.big = label, per_px, per_notch, big
        self.angle = 0.0
        self._last = None
        self.setFixedSize(112, 100)
        self.setCursor(Qt.CursorShape.SizeVerCursor)
        self.setToolTip(f"{label}：按住上下拖，或滚轮。向上是载物台上升。")

    def turn(self, um: float) -> None:
        self.angle = (self.angle + um / self.per_notch * 9) % 360
        self.update()
        self.turned.emit(um)

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._last = e.position().y()

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._last is not None:
            dy = self._last - e.position().y()
            self._last = e.position().y()
            if dy:
                self.turn(dy * self.per_px)

    def mouseReleaseEvent(self, _e):  # noqa: N802
        self._last = None

    def wheelEvent(self, e):  # noqa: N802
        self.turn(e.angleDelta().y() / 120 * self.per_notch)
        e.accept()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        c = QPointF(self.width() / 2, 40)
        r = 34 if self.big else 24
        p.setPen(QPen(qc(T.line2), 1))
        p.setBrush(qc(T.raised))
        p.drawEllipse(c, r, r)
        p.setPen(QPen(qc(T.faint), 1.4))
        for i in range(24 if self.big else 16):
            a = math.radians(self.angle + i * (360 / (24 if self.big else 16)))
            p.drawLine(QPointF(c.x() + math.cos(a) * (r - 6), c.y() + math.sin(a) * (r - 6)),
                       QPointF(c.x() + math.cos(a) * (r - 1.5), c.y() + math.sin(a) * (r - 1.5)))
        a = math.radians(self.angle - 90)
        p.setPen(QPen(qc(T.accent), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawLine(QPointF(c.x() + math.cos(a) * 6, c.y() + math.sin(a) * 6), QPointF(c.x() + math.cos(a) * (r - 9), c.y() + math.sin(a) * (r - 9)))
        p.setPen(qc(T.soft))
        p.setFont(font(12.5, 700))
        p.drawText(QRectF(0, 79, self.width(), 20), int(Qt.AlignmentFlag.AlignCenter), self.label)
        p.end()


class Steps(QWidget):
    """擦 滴 撕 展 盖 染 吸：做了的打勾，出了问题的标出来。只是对照，不限制顺序。"""

    def __init__(self):
        super().__init__()
        self.rows = []
        self.setFixedHeight(46)

    def set_rows(self, rows) -> None:
        self.rows = rows
        self.setToolTip("\n".join(f"{name}：{note}" for name, _state, note in rows))
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        n = max(1, len(self.rows))
        gap = 5
        w = (self.width() - gap * (n - 1)) / n
        for i, (name, state, _note) in enumerate(self.rows):
            box = QRectF(i * (w + gap), 1, w, self.height() - 2)
            tone = T.ok if state == "done" else T.warn if state == "issue" else T.faint
            p.setPen(QPen(qc(tone if state != "todo" else T.line2), 1.2))
            p.setBrush(qc(tone, 0.14) if state != "todo" else qc(T.raised))
            p.drawRoundedRect(box, 6, 6)
            p.setPen(qc(T.fg if state != "todo" else T.muted))
            p.setFont(font(13, 700))
            p.drawText(box.adjusted(0, 3, 0, -16), int(Qt.AlignmentFlag.AlignCenter), name)
            p.setPen(qc(tone))
            p.setFont(font(11, 700))
            p.drawText(box.adjusted(0, 24, 0, -2), int(Qt.AlignmentFlag.AlignCenter), {"done": "✓", "issue": "!", "todo": "·"}[state])
        p.end()


def _title(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setObjectName("grpTitle")
    return lb


class ScopeDialog(QDialog):
    def __init__(self, parameters: dict, remember, parent=None):
        super().__init__(parent)
        current = parameters.get("slide")
        if current is not None and not M.valid(current):
            raise ValueError("装片记录损坏或版本不支持，未覆盖原记录")
        self.parameters, self.remember = parameters, remember
        if current is None:
            remember()
            current = parameters["slide"] = M.fresh(parameters.get("slide_seed", 1))
        self.record = current
        self.speed = 10.0
        self.setObjectName("jw2")
        self.setStyleSheet(qss())
        self.setWindowTitle("制片与显微观察")
        self.resize(1200, 760)
        self.setMinimumSize(1020, 640)
        self.timer = QTimer(self)
        self.timer.setInterval(TICK_MS)
        self.timer.timeout.connect(self._tick)
        self._wick_timer = QTimer(self)
        self._wick_timer.setSingleShot(True)
        self._wick_timer.timeout.connect(self._wick_done)

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 14)
        root.setSpacing(10)
        head = QHBoxLayout()
        self.title = QLabel()
        self.title.setFont(font(16, 700))
        head.addWidget(self.title, 1)
        self.reset_btn = self._button("重新制片", lambda: self.do("reset"), "换一套干净的玻片，从头做")
        head.addWidget(self.reset_btn)
        close = self._button("关闭", self.accept)
        head.addWidget(close)
        root.addLayout(head)
        cols = QHBoxLayout()
        cols.setSpacing(14)
        root.addLayout(cols, 1)

        # ---- 左：制片台
        left = QVBoxLayout()
        left.setSpacing(8)
        holder = QWidget()
        holder.setFixedWidth(300)
        holder.setLayout(left)
        left.setContentsMargins(0, 0, 0, 0)
        self.bench = Bench(self)
        left.addWidget(self.bench)
        self.steps = Steps()
        left.addWidget(self.steps)
        grid = QGridLayout()
        grid.setSpacing(6)
        self.tools = {}

        def tool(key, text, row, col, fn=None, menu=None, tip=""):
            b = self._button(text, fn, tip)
            if menu:
                m = QMenu(b)
                for label, args in menu:
                    m.addAction(label, lambda a=args: self.do(*a))
                b.setMenu(m)
            grid.addWidget(b, row, col)
            self.tools[key] = b
        tool("wipe", "擦拭玻片", 0, 0, lambda: self.do("wipe"), tip="用纱布擦净载玻片和盖玻片")
        tool("drop", "滴清水", 0, 1, lambda: self.do("drop", "water"), tip="在载玻片中央滴一滴清水")
        tool("take", "取材料", 1, 0, menu=[(v["name"], ("take", k)) for k, v in M.SPECIMENS.items()], tip="用镊子取一块材料放到载玻片上")
        tool("spread", "展平", 1, 1, lambda: self.do("spread"), tip="用解剖针把材料在液滴里展平")
        tool("cover", "盖盖玻片", 2, 0, menu=[("一侧先接触液滴，缓缓放平", ("cover", "angled")), ("直接平放下去", ("cover", "flat"))])
        tool("irrigate", "一侧滴液", 2, 1, menu=[(v["name"], ("irrigate", k)) for k, v in M.LIQUIDS.items() if k != "water"] + [("清水", ("irrigate", "water"))],
             tip="在盖玻片一侧滴一滴液体（染色、换外界溶液）")
        tool("wick", "吸水纸引流", 3, 0, lambda: self.do("wick"), tip="用吸水纸在盖玻片另一侧吸引")
        left.addLayout(grid)
        self.load_btn = QPushButton()
        self.load_btn.setObjectName("pri")
        self.load_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.load_btn.clicked.connect(lambda: self.do("unload" if self.record["scope"]["loaded"] else "load"))
        left.addWidget(self.load_btn)
        left.addWidget(_title("装片状态"))
        self.issue_label = QLabel()
        self.issue_label.setObjectName("note")
        self.issue_label.setWordWrap(True)
        self.issue_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        left.addWidget(self.issue_label, 1)
        cols.addWidget(holder)

        # ---- 中：目镜
        mid = QVBoxLayout()
        mid.setSpacing(6)
        self.eye = Eyepiece(self)
        self.eye.focus.connect(self.turn_focus)
        mid.addWidget(self.eye, 1)
        self.info = QLabel()
        self.info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.info.setFont(font(13, 700, "mono"))
        mid.addWidget(self.info)
        self.advice = QLabel()
        self.advice.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.advice.setWordWrap(True)
        self.advice.setObjectName("ctlLabel")
        mid.addWidget(self.advice)
        self.message = QLabel(" ")
        self.message.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.message.setWordWrap(True)
        self.message.setMinimumHeight(36)
        mid.addWidget(self.message)
        clock = QHBoxLayout()
        clock.addStretch(1)
        clock.addWidget(_title("时间"))
        self.speed_seg = Segmented(list(SPEEDS), "10")
        self.speed_seg.changed.connect(lambda v: setattr(self, "speed", float(v)))
        clock.addWidget(self.speed_seg)
        self.clock_label = QLabel()
        self.clock_label.setObjectName("note")
        self.clock_label.setMinimumWidth(96)
        clock.addWidget(self.clock_label)
        clock.addStretch(1)
        mid.addLayout(clock)
        cols.addLayout(mid, 1)

        # ---- 右：显微镜
        right = QVBoxLayout()
        right.setSpacing(7)
        rh = QWidget()
        rh.setLayout(right)
        right.setContentsMargins(0, 0, 8, 0)
        area = QScrollArea()          # 窗口矮的时候右栏自己滚，不互相压
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.Shape.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        area.setFixedWidth(286)
        area.setWidget(rh)
        self.side = area
        right.addWidget(_title("物镜"))
        self.obj_seg = Segmented([(str(k), f"{k}×") for k in M.OBJECTIVES], str(self.record["scope"]["objective"]))
        self.obj_seg.changed.connect(lambda v: self.set_objective(int(v)))
        right.addWidget(self.obj_seg)
        right.addWidget(_title("目镜"))
        self.eye_seg = Segmented([(str(k), f"{k}×") for k in M.EYEPIECES], str(self.record["scope"]["eyepiece"]))
        self.eye_seg.changed.connect(lambda v: self._set(M.set_eyepiece, int(v)))
        right.addWidget(self.eye_seg)
        knobs = QHBoxLayout()
        self.coarse = Knob("粗准焦螺旋", 25.0, M.COARSE, True)
        self.fine = Knob("细准焦螺旋", 0.25, M.FINE, False)
        self.coarse.turned.connect(self.turn_focus)
        self.fine.turned.connect(self.turn_focus)
        knobs.addWidget(self.coarse)
        knobs.addWidget(self.fine)
        knobs.addStretch(1)
        right.addLayout(knobs)
        right.addWidget(_title("光圈（1 最小）"))
        self.ap_seg = Segmented([(str(k), str(k)) for k in M.APERTURES], str(self.record["scope"]["aperture"]))
        self.ap_seg.changed.connect(lambda v: self._set(M.set_aperture, int(v)))
        right.addWidget(self.ap_seg)
        right.addWidget(_title("反光镜"))
        self.mirror_seg = Segmented([(k, v[0]) for k, v in M.MIRRORS.items()], self.record["scope"]["mirror"])
        self.mirror_seg.changed.connect(lambda v: self._set(M.set_mirror, v))
        right.addWidget(self.mirror_seg)
        self.out = QLabel()
        self.out.setObjectName("out")
        self.out.setTextFormat(Qt.TextFormat.RichText)
        self.out.setWordWrap(True)
        right.addWidget(self.out)
        right.addWidget(_title("操作记录"))
        self.log_label = QLabel()
        self.log_label.setObjectName("note")
        self.log_label.setWordWrap(True)
        self.log_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        right.addWidget(self.log_label)
        note = QLabel("颜色是标本和染色剂自己的颜色；常数来源和假设见工作台「原理」页。")
        note.setObjectName("note")
        note.setWordWrap(True)
        right.addWidget(note)
        right.addStretch(1)
        cols.addWidget(area)
        self.refresh()

    # ---- 小工具
    def _button(self, text, fn=None, tip="") -> QPushButton:
        b = QPushButton(text)
        b.setObjectName("btn")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        if fn:
            b.clicked.connect(lambda _=False: fn())
        if tip:
            b.setToolTip(tip)
        return b

    def say(self, text: str, tone: str = "") -> None:
        color = T.bad if tone == "bad" else T.ok if tone == "ok" else T.accent
        self.message.setStyleSheet(f"color:{color}; font-size:13px; font-weight:700;")
        self.message.setText(text or " ")

    # ---- 动作
    def do(self, name: str, *args) -> bool:
        """制片动作。前提不满足时不改状态，只说明原因。"""
        self.remember()
        try:
            text = M.act(self.record, name, *args)
        except M.StepError as exc:
            self.say(str(exc), "bad")
            return False
        if name == "wick":
            self.bench.wicking = True
            self._wick_timer.start(700)
        self.say(text, "ok")
        self.refresh()
        return True

    def _wick_done(self) -> None:
        self.bench.wicking = False
        self.bench.update()

    def set_objective(self, objective: int) -> bool:
        self.remember()
        try:
            text = M.set_objective(self.record, objective)
        except M.StepError as exc:
            self.say(str(exc), "bad")
            self.obj_seg.set_value(str(self.record["scope"]["objective"]))
            return False
        self.say(text)
        self.refresh()
        return True

    def _set(self, fn, value) -> None:
        fn(self.record, value)
        self.refresh()

    def turn_focus(self, um: float) -> None:
        event = M.focus_by(self.record, um)
        if event == "crash":
            self.say("物镜压到了装片：盖玻片压裂了。高倍镜下不能用粗准焦螺旋往上调。", "bad")
        elif event == "limit":
            self.say("到头了：不能再往这个方向调。", "bad")
        self.refresh(light=True)

    def push(self, dx: float, dy: float) -> None:
        """把装片推 (dx, dy) µm。"""
        M.move_by(self.record, dx, dy)
        self.refresh(light=True)

    # ---- 时间
    def _tick(self) -> None:
        M.advance(self.record, TICK_MS / 1000 * self.speed)
        self.refresh(light=True)

    def _sync_timer(self) -> None:
        run = self.isVisible() and M.active(self.record)
        if run and not self.timer.isActive():
            self.timer.start()
        elif not run and self.timer.isActive():
            self.timer.stop()

    def showEvent(self, e):  # noqa: N802
        super().showEvent(e)
        self._sync_timer()

    def hideEvent(self, e):  # noqa: N802
        self.timer.stop()
        super().hideEvent(e)

    # ---- 显示
    def refresh(self, light: bool = False) -> None:
        record = self.record
        s, m = record["sample"], record["scope"]
        o = M.optics(m)
        name = M.SPECIMENS[s["specimen"]]["name"] if s["specimen"] else "还没有材料"
        self.title.setText("制片与显微观察 · " + name)
        self.info.setText(f"{o['objective']}× 物镜 · {o['eyepiece']}× 目镜 = {o['total']}×　　视野 {M._length(o['field'])}")
        self.advice.setText(M.advice(record))
        mono = family("mono")
        html = ["<table width='100%' cellspacing='0' cellpadding='2'>"]
        for row in M.readout(record):
            if isinstance(row, list):
                html.append(f"<tr><td style='color:{T.muted}'>{row[0]}</td><td align='right' style='color:{T.fg};font-family:\"{mono}\";font-weight:700'>{row[1]}</td></tr>")
            else:
                html.append(f"<tr><td colspan='2' style='color:{T.warn}'>{row}</td></tr>")
        html.append("</table>")
        self.out.setText("".join(html))
        t = int(s["clock"])
        self.clock_label.setText(f"已过 {t // 60} 分 {t % 60:02d} 秒" + ("" if M.active(record) else " · 静止"))
        self.eye.update()
        self.bench.update()
        self._sync_timer()
        if light:
            return
        self.steps.set_rows(M.checklist(s))
        found = M.issues(s)
        self.issue_label.setText("<br>".join("· " + line for line in found) if found else "· 没有发现问题。")
        self.log_label.setText("<br>".join(f"<span style='color:{T.faint}'>{int(t0) // 60}:{int(t0) % 60:02d}</span> {text}" for t0, text in reversed(s["log"][-6:])))
        loaded = m["loaded"]
        self.load_btn.setText("取下装片" if loaded else "放上载物台")
        for key in ("wipe", "drop", "take", "spread", "cover"):
            self.tools[key].setEnabled(not loaded)
        for seg, value in ((self.obj_seg, m["objective"]), (self.eye_seg, m["eyepiece"]), (self.ap_seg, m["aperture"]), (self.mirror_seg, m["mirror"])):
            seg.set_value(str(value))


def thumbnail(record: dict, px: int, dpr: float = 1.0):
    """工作台卡片上的小视野。"""
    return render(record, px, dpr)


def _unused():
    _ = QFontMetrics
