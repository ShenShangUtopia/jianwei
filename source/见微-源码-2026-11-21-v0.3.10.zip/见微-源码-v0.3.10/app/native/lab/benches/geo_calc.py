"""几何画板的函数分析（纯数值，不依赖 Qt）：零点、极值、拐点、单调区间、奇偶性、周期、切线、伸缩平移。

都在给定区间（一般是当前可视范围）里数值求解：先密集取样找变号，再二分细化。
结果是「数值近似」，界面上也这么标。间断处（tan、1/x）两侧的跳变不算零点、不算极值。
"""
from __future__ import annotations

import math
import re

N = 900          # 取样点数
_BIS = 60        # 二分次数


def _ok(y):
    return isinstance(y, (int, float)) and math.isfinite(y)


def deriv(f, x):
    h = 1e-5 * (1 + abs(x))
    a, b = f(x - h), f(x + h)
    return (b - a) / (2 * h) if _ok(a) and _ok(b) else float("nan")


def deriv2(f, x):
    h = 1e-3 * (1 + abs(x))
    a, m, b = f(x - h), f(x), f(x + h)
    return (a - 2 * m + b) / (h * h) if _ok(a) and _ok(m) and _ok(b) else float("nan")


def _bisect(g, a, b):
    ga = g(a)
    for _ in range(_BIS):
        m = (a + b) / 2
        gm = g(m)
        if not _ok(gm):
            return None
        if (ga <= 0) == (gm <= 0):
            a, ga = m, gm
        else:
            b = m
    return (a + b) / 2


def _continuous(f, a, b, ya, yb, span):
    """a、b 之间没有间断：中点的值在两端之间附近，且两端差得不离谱。"""
    m = f((a + b) / 2)
    if not _ok(m):
        return False
    lo, hi = min(ya, yb), max(ya, yb)
    pad = (hi - lo) * 0.6 + span * 1e-3
    return lo - pad <= m <= hi + pad and abs(yb - ya) < span * 0.5 + 1e-9


def _crossings(vals, eps):
    """vals 里正负号的变化处：[(左下标, 右下标, 左边的号)]。中间等于 0（|v| ≤ eps）的样本跳过，
    这样取样恰好落在极值点、拐点上（导数为 0）时也能找到；遇到求不出的值就断开。"""
    out, last = [], None
    for i, v in enumerate(vals):
        if not _ok(v):
            last = None
            continue
        if abs(v) <= eps:
            continue
        s = v > 0
        if last is not None and last[1] != s:
            out.append((last[0], i, last[1]))
        last = (i, s)
    return out


def _dedupe(xs, tol):
    out = []
    for x in sorted(xs):
        if not out or abs(x - out[-1]) > tol:
            out.append(x)
    return out


def analyze(f, x0, x1, n=N):
    """在 [x0, x1] 里找特殊点。返回 dict：zeros、maxima、minima、inflections（都是 [(x, y)]）、
    y0（与 y 轴交点或 None）、mono（[(a, b, '增'/'减')]）、parity、period、breaks（间断点 x）。"""
    if not (math.isfinite(x0) and math.isfinite(x1)) or x1 - x0 <= 1e-9:
        return dict(zeros=[], maxima=[], minima=[], inflections=[], y0=None, mono=[], parity="", period=None, breaks=[])
    dx = (x1 - x0) / n
    xs = [x0 + i * dx for i in range(n + 1)]
    ys = [f(x) for x in xs]
    fin = [y for y in ys if _ok(y)]
    span = (max(fin) - min(fin)) if fin else 1.0
    span = span if span > 1e-12 else 1.0
    tol = dx * 1.5

    zeros, breaks = [], []
    for i in range(n):
        a, b, ya, yb = xs[i], xs[i + 1], ys[i], ys[i + 1]
        if not (_ok(ya) and _ok(yb)):
            if _ok(ya) != _ok(yb):
                breaks.append((a + b) / 2)
            continue
        if ya == 0:
            zeros.append(a)
            continue
        if (ya < 0) != (yb < 0):
            if _continuous(f, a, b, ya, yb, span):
                r = _bisect(f, a, b)
                if r is not None:
                    zeros.append(r)
            else:
                breaks.append((a + b) / 2)
    if _ok(ys[-1]) and ys[-1] == 0:
        zeros.append(xs[-1])

    def smooth(i, j):
        """i 到 j 之间每一小段都连续（没有跨过间断）。"""
        return all(_ok(ys[t]) and _ok(ys[t + 1]) and _continuous(f, xs[t], xs[t + 1], ys[t], ys[t + 1], span) for t in range(i, j))

    ds = [deriv(f, x) for x in xs]
    dscale = max((abs(v) for v in ds if _ok(v)), default=0.0)
    maxima, minima, touch = [], [], []
    for i, j, up in _crossings(ds, dscale * 1e-9):
        if not smooth(i, j):
            continue
        r = _bisect(lambda x: deriv(f, x), xs[i], xs[j])
        if r is None:
            continue
        y = f(r)
        if not _ok(y):
            continue
        (maxima if up else minima).append((r, y))
        if abs(y) < span * 1e-7:          # 切于 x 轴（如 x²）：也是零点
            touch.append(r)
    zeros = _dedupe(zeros + touch, tol)

    d2 = [deriv2(f, x) for x in xs]
    scale = max((abs(v) for v in d2 if _ok(v)), default=0.0)
    infl = []
    if scale > 1e-9:
        for i, j, _up in _crossings(d2, scale * 1e-4):
            if not smooth(i, j) or any(min(abs(xs[i] - bx), abs(xs[j] - bx)) < dx * 4 for bx in breaks):
                continue
            r = _bisect(lambda x: deriv2(f, x), xs[i], xs[j])
            if r is not None and _ok(f(r)):
                infl.append((r, f(r)))
    infl = [p for p in infl if all(abs(p[0] - q[0]) > tol for q in maxima + minima)]

    y0 = f(0.0) if x0 <= 0 <= x1 and _ok(f(0.0)) else None

    # 单调区间：以极值点、间断点为界
    cuts = sorted([x0] + [p[0] for p in maxima + minima] + breaks + [x1])
    mono = []
    for a, b in zip(cuts, cuts[1:]):
        if b - a < dx:
            continue
        m = (a + b) / 2
        d = deriv(f, m)
        if not _ok(d) or abs(d) < 1e-12:
            continue
        kind = "增" if d > 0 else "减"
        if mono and mono[-1][2] == kind and abs(mono[-1][1] - a) < dx * 2 and not any(abs(a - bx) < dx * 2 for bx in breaks):
            mono[-1] = (mono[-1][0], b, kind)
        else:
            mono.append((a, b, kind))

    return dict(zeros=[(z, 0.0) for z in zeros], maxima=_dedupe_pts(maxima, tol), minima=_dedupe_pts(minima, tol),
                inflections=_dedupe_pts(infl, tol), y0=y0, mono=mono, parity=parity(f, x0, x1),
                period=period(f, x0, x1, maxima or minima) or period(f, x0, x1, [(z, 0.0) for z in zeros]), breaks=_dedupe(breaks, tol))


def _dedupe_pts(pts, tol):
    out = []
    for p in sorted(pts):
        if not out or abs(p[0] - out[-1][0]) > tol:
            out.append(p)
    return out


def parity(f, x0, x1):
    """在对称的那一段上比 f(−x) 和 f(x)：偶 / 奇 / 非奇非偶；对称段太短返回空串。"""
    r = min(abs(x0), abs(x1)) if x0 < 0 < x1 else 0
    if r < 0.5:
        return ""
    even = odd = True
    seen = 0
    for i in range(1, 41):
        x = r * i / 41
        a, b = f(x), f(-x)
        if not (_ok(a) and _ok(b)):
            continue
        seen += 1
        tol = 1e-7 * (1 + abs(a))
        even &= abs(a - b) <= tol
        odd &= abs(a + b) <= tol
    if seen < 8:
        return ""
    return "偶函数" if even and not odd else "奇函数" if odd and not even else "既奇又偶" if odd and even else "非奇非偶"


def period(f, x0, x1, extrema):
    """用相邻同类极值点的间距猜周期，再在 20 个点上验证 f(x + T) = f(x)。"""
    xs = sorted(p[0] for p in extrema)
    if len(xs) < 2:
        return None
    for T in sorted({round(b - a, 9) for a, b in zip(xs, xs[1:]) if b - a > 1e-6})[:4]:
        good = checked = 0
        for i in range(20):
            x = x0 + (x1 - x0) * (i + 0.37) / 21
            a, b = f(x), f(x + T)
            if _ok(a) and _ok(b):
                checked += 1
                good += abs(a - b) <= 1e-6 * (1 + abs(a))
        if checked >= 10 and good == checked:
            return T
    return None


def tangent(f, a):
    """在 x = a 处的切线：(y0, 斜率)；求不出来返回 None。"""
    y = f(a)
    k = deriv(f, a)
    return (y, k) if _ok(y) and _ok(k) else None


def line_text(k, b):
    """y = kx + b 的好看写法。"""
    def n(v):
        v = 0.0 if abs(v) < 5e-10 else v
        s = f"{v:.3f}".rstrip("0").rstrip(".")
        return "0" if s in ("-0", "") else s
    if abs(k) < 5e-10:
        return f"y = {n(b)}"
    kx = "x" if abs(k - 1) < 5e-10 else "−x" if abs(k + 1) < 5e-10 else n(k).replace("-", "−") + "x"
    if abs(b) < 5e-10:
        return "y = " + kx
    return f"y = {kx} {'+' if b > 0 else '−'} {n(abs(b))}"


# ---------------------------------------------------------------- 伸缩平移 y = a·f(b(x − h)) + k
IDENT_TF = dict(a=1.0, b=1.0, h=0.0, k=0.0)


def is_ident(tf):
    return not tf or all(abs(float(tf.get(k, v)) - v) < 1e-12 for k, v in IDENT_TF.items())


def apply_tf(base, tf):
    if is_ident(tf):
        return base
    a, b, h, k = (float(tf.get(x, IDENT_TF[x])) for x in ("a", "b", "h", "k"))

    def g(x):
        y = base(b * (x - h))
        return a * y + k if _ok(y) else float("nan")
    return g


def _num(v):
    s = f"{v:.3f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def bake(expr, tf):
    """把伸缩平移写回解析式（字符串替换变量 x），用于「写进式子」。"""
    if is_ident(tf):
        return expr
    a, b, h, k = (float(tf.get(x, IDENT_TF[x])) for x in ("a", "b", "h", "k"))
    inner = "x" if abs(h) < 1e-12 else f"(x-{_num(h)})" if h > 0 else f"(x+{_num(-h)})"
    if abs(b - 1) > 1e-12:
        inner = f"(-{inner})" if abs(b + 1) < 1e-12 else f"({_num(b)}*{inner})"
    body = re.sub(r"(?<![A-Za-z_])x(?![A-Za-z_])", inner, expr)
    out = body if abs(a - 1) < 1e-12 else f"-({body})" if abs(a + 1) < 1e-12 else f"{_num(a)}*({body})"
    return out if abs(k) < 1e-12 else f"{out}+{_num(k)}" if k > 0 else f"{out}-{_num(-k)}"


def tf_notes(tf):
    """每个参数对图像做了什么（给学生看的结论）。"""
    a, b, h, k = (float(tf.get(x, IDENT_TF[x])) for x in ("a", "b", "h", "k"))
    out = []
    if abs(b - 1) > 1e-12:
        r = abs(1 / b)
        out.append(f"横坐标变为原来的 {_num(r)} 倍" + ("（再关于 y 轴翻折）" if b < 0 else ""))
    if abs(h) > 1e-12:
        out.append(f"向{'右' if h > 0 else '左'}平移 {_num(abs(h))} 个单位")
    if abs(a - 1) > 1e-12:
        out.append(f"纵坐标变为原来的 {_num(abs(a))} 倍" + ("（再关于 x 轴翻折）" if a < 0 else ""))
    if abs(k) > 1e-12:
        out.append(f"向{'上' if k > 0 else '下'}平移 {_num(abs(k))} 个单位")
    return out


def snap_x(x, feats, tol):
    """动点吸附：离特殊点或整数 x 不到 tol 就吸过去。返回 (x, 吸到的名字或 '')。"""
    best, name = None, ""
    for label in ("zeros", "maxima", "minima", "inflections"):
        for p in feats.get(label, ()):
            d = abs(p[0] - x)
            if d <= tol and (best is None or d < abs(best - x)):
                best, name = p[0], {"zeros": "零点", "maxima": "极大值点", "minima": "极小值点", "inflections": "拐点"}[label]
    if best is not None:
        return best, name
    r = round(x)
    if abs(r - x) <= tol * 0.6:
        return float(r), "整数点"
    return x, ""
