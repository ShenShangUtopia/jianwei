"""自由工作台 · 化学（由 gewu/bench-chem.js 改写）：台面、容器、试剂、反应、检验。模型和数据在 chem_model.py。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha, qc
from ...design.icons import bench_object_svg
from ...kit.bench import bench
from ...kit import state_graph
from ...kit.core import PI, TAU, clamp, fmt, lerp, rnd, sci
from ...kit.draw import D, Gradient
from .apparatus_model import route_gas, gas_volume, prepare_water_collection
from . import separation, chem_titration, chem_equations
from .chem_model import (ART, COAT, COATN, DISP, DSV, EV, HD, HF, HM, IC, KD, MI, NIT, NM, PC, PD, PDN, PHP, PK, PM, PN, PRE, RG, RG_BY, SO, VT, css, eqm, hx,
                         ic_bottle, ic_dropper, ic_solid, mix3, ramp, swatch, tint, tint_oil)

DH = {"n:s": 57.3, "n:a": 56.1, "n:b": 52.2, "n:ab": 50.4}   # 中和热（kJ/mol）：弱酸、弱碱电离要吸热，放出的热量比强酸强碱少
BF = {"H2": 90, "O2": 260, "CO2": 110, "NO": 140}
FREE_GAS = {"H2": 0.0, "O2": 0.0, "CO2": 0.0, "NO": 0.0, "NH3": 0.0}


def _add(t, k, x):
    t[k] = t.get(k, 0) + x


def _hexc(c):
    return qc(css(c)).name()


def _eq(v):
    """平衡结果带缓存：总量和温度都没变（静置的容器）就不重算，这是工作台最耗时的一步。"""
    t = v["tot"]
    key = (tuple(sorted(t.items())), v["V"], round(v["T"], 1))
    if v.get("_ek") == key:
        return v["e"]
    e = v["e"] = eqm(t, v["V"], v["e"]["pH"] if v.get("e") else None, v["T"])
    v["_ek"] = key
    return e


@bench.reg(id="chem", subj="chem", short="化学", title="化学工作台", sub="试剂 · 器材 · 反应现象与方程式",
           desc="试管、烧杯、锥形瓶、酒精灯，三十多种试剂和十余种固体。滴加、倾倒、加热、萃取、检验气体，自动显示沉淀、气泡、颜色变化、温度、pH 和离子方程式。",
           art=ART)
def chem(B):
    L = B.L
    c = L.canvas()
    st = {"amt": 2.0, "speed": 1.0}
    objs: list = []
    cnt = {"tube": 0, "beaker": 0, "flask": 0}
    W = {"sel": None, "uid": 0, "S": 1.0, "TY": 0.0, "clock": 0.0, "ui": None, "tip": ""}
    records: list = []

    def vessels():
        return [o for o in objs if o["kind"] == "v"]

    def lamps():
        return [o for o in objs if o["kind"] == "lamp"]

    def layout():
        left, _t, right, _b = B.safe()
        W["S"] = clamp(min(c.h / 460, max(300, c.w - left - right) / 500), 0.62, 1.6)
        if any(v.get('titration_mount') for v in vessels()):
            W["S"] = min(W["S"], c.h / 540)
        W["TY"] = c.h - 66 * W["S"]

    # ---- 对象
    def outer_w(v):
        return (VT[v["type"]].W + 3) * W["S"]

    def half_w(o):
        return max(52 * W["S"], outer_w(o["v"]) if o.get("v") else 0) if o["kind"] == "lamp" else outer_w(o)

    def base(v):
        if v.get('titration_mount') and not v.get('pour'):
            return W['TY'] - v.get('titration_mount_height', VT['flask'].H + 24) * W['S']
        return (W["TY"] - (84 if v["type"] == "tube" else 112) * W["S"] if v.get("lamp") else W["TY"]) - v["lift"]

    def top_y(v):
        return base(v) - VT[v["type"]].H * W["S"]

    def ok_x(o, x):
        hw = half_w(o)
        if x < hw + 6 or x > c.w - hw - 6:
            return False
        for u in objs:
            if u is o or u is o.get("v") or u is o.get("lamp") or (u["kind"] == "v" and u.get("lamp")):
                continue
            if abs(u["x"] - x) <= hw + half_w(u) + 8 * W["S"]:
                return False
        return True

    def near_free(o, x0):
        # 先在没被浮窗盖住的范围里找位置，放不下才往两边挤
        left, _t, right, _b = B.safe()
        hw = half_w(o)
        d = 0
        while d < c.w:
            for x in (x0 - d, x0 + d):
                if left + hw <= x <= c.w - right - hw and ok_x(o, x):
                    return x
            d += 6
        d = 0
        while d < c.w:
            if ok_x(o, x0 - d):
                return x0 - d
            if ok_x(o, x0 + d):
                return x0 + d
            d += 6
        return clamp(x0, 40, c.w - 40)

    def clear_mid():
        left, _t, right, _b = B.safe()
        return (left + c.w - right) / 2

    def uid():
        W["uid"] += 1
        return W["uid"]

    def new_v(typ, x=None):
        if len(vessels()) >= 8:
            B.toast("台面上最多放 8 个容器")
            return None
        cnt[typ] = cnt.get(typ,0)+1
        v = {"kind": "v", "id": uid(), "type": typ, "x": 0.0, "name": f"{VT[typ].n} {cnt[typ]}", "tot": {}, "V": 0.0, "T": 25.0, "solids": [], "pp": {}, "bub": [], "ev": set(),
             "gas": dict(FREE_GAS), "bacc": 0.0, "tacc": 0.0, "added": [], "ind": {}, "feed": [], "anims": [], "lamp": None, "lift": 0.0, "foam": 0.0, "last": "", "stir": 0.0,
             "test": None, "pour": None, "oil": 0.0, "ex": 0.0, "prevA": {}, "e": None}
        v["e"] = eqm(v["tot"], 0)
        v["gas_capacity"] = VT[typ].cap
        v['gas_seal'] = False
        if typ == 'gasjar':
            v['gas_water_ready'] = False
        if typ == 'burette':
            chem_titration.prepare(v)
        objs.append(v)
        v["x"] = near_free(v, clear_mid() if x is None else x)
        return v

    def new_lamp(x=None):
        if len(lamps()) >= 3:
            B.toast("最多放 3 盏酒精灯")
            return None
        o = {"kind": "lamp", "id": uid(), "x": 0.0, "lit": False, "v": None}
        objs.append(o)
        o["x"] = near_free(o, clear_mid() if x is None else x)
        return o

    def select(o):
        if W["sel"] is not o:
            W["sel"] = o
            inspect()
        L.draw()

    def remove(o):
        if o["kind"] == "v" and o.get("lamp"):
            o["lamp"]["v"] = None
        if o["kind"] == "lamp" and o.get("v"):
            o["v"]["lamp"] = None
            o["v"]["x"] = near_free(o["v"], o["x"] + 80 * W["S"])
        objs.remove(o)
        if W["sel"] is o:
            W["sel"] = None
            inspect()

    def empty(v):
        v.update(tot={}, V=0.0, T=25.0, solids=[], pp={}, bub=[], added=[], ind={}, feed=[], foam=0.0, last="", oil=0.0, ex=0.0, prevA={})
        v.pop("titration_run", None)
        v.pop("titration_trace", None)
        for key in ('collected', 'gas_totals', 'water_displaced', 'gas_note', 'titration_results', 'endpoint_hold'):
            v.pop(key, None)
        if v['type'] == 'gasjar':
            v['gas_water_ready'] = False
        v['titration_valve'] = False
        if v.get('titration_training'):
            v.pop('titration_prep', None)
            chem_titration.prepare(v)
        v["ev"].clear()
        v["gas"] = dict(FREE_GAS)
        v["e"] = eqm(v["tot"], 0)
        v["_ek"] = None

    def liq(v):
        return v["V"] + (v["oil"] or 0)   # 水层 + CCl₄ 层的总体积

    def lvl(v):
        if v['type'] == 'gasjar' and v.get('gas_water_ready') and v.get('collection') == 'water':
            return VT['gasjar'].H * clamp(v['V'] / VT['gasjar'].cap, 0, 1)
        return VT[v["type"]].lvl(liq(v) - (chem_titration.tip_volume(v) if v['type'] == 'burette' else 0.))

    def aq_f(v, k):
        o = v["oil"] or 0
        if o <= 0 or not v["ex"]:
            return 1.0
        Dk = KD[k]
        return 1 - v["ex"] * Dk * o / (Dk * o + max(v["V"], 0.05))

    def note(v, f):
        if f in v["added"]:
            v["added"].remove(f)
        v["added"].append(f)
        if len(v["added"]) > 6:
            v["added"].pop(0)

    # ---- 记录与事件
    def render_log():
        lb = (W["ui"] or W.get("uil") or {}).get("log") if (W["ui"] or W.get("uil")) else None
        if lb is None:
            return
        try:
            if records:
                lb.setText("<br>".join(records[:8]))
            else:
                lb.setText("还没有发生反应。往容器里加试剂试试。")
        except RuntimeError:
            pass

    def say(v, eq_, ph):
        eqh = f"<b>{chem_equations.display(eq_)}</b><br>" if eq_ else ""
        rec = f"{eqh}<span style='color:{T.muted}'>{v['name']}：</span>{ph}"
        records.insert(0, rec)
        del records[80:]
        B.log.add(rec)
        B.toast(rec, ms=4800)
        render_log()

    def ev(v, key):
        if key in v["ev"]:
            return
        v["ev"].add(key)
        d = EV.get(key)
        if d:
            def f(x):
                return x(v, v["e"]) if callable(x) else x
            say(v, f(d[0]), f(d[1]))

    def ppt_on(v, k, e):
        if k == "CuO":
            return
        if k == "Fe3" and (e["p"]["Fe2"] > 0.002 or "r:Fe(OH)2-air" in v["ev"]):
            return
        if k == "CaCO3" and v["T"] > 60 and "CO₂" in v["added"]:
            return say(v, "Ca(HCO₃)₂ =△= CaCO₃↓ + CO₂↑ + H₂O", "受热后溶液又变浑浊")
        if k == "CaCO3" and v["last"] == "CO2":
            return say(v, "CO₂ + Ca²⁺ + 2OH⁻ = CaCO₃↓ + H₂O", "澄清石灰水变浑浊")
        if k == "CaOH" and v["last"] == "CaO":
            return say(v, "", "生成的 Ca(OH)₂ 微溶，液体变浑浊（石灰乳）")
        if k == "CaOH" and v["T"] > 33 and v["last"] not in ("NaOH", "NaOHs", "Na", "Na2O2"):
            return say(v, "", "溶液变浑浊：Ca(OH)₂ 的溶解度随温度升高而减小")
        # [Al(OH)₄]⁻、[Zn(OH)₄]²⁻ 遇酸或 CO₂ 重新生成沉淀
        if k == "Al" and v["prevA"].get("Al", 0) > 0.002:
            co2 = v["last"] == "CO2"
            return say(v, "[Al(OH)₄]⁻ + CO₂ = Al(OH)₃↓ + HCO₃⁻" if co2 else "[Al(OH)₄]⁻ + H⁺ = Al(OH)₃↓ + H₂O",
                       "生成白色胶状沉淀" + ("（CO₂ 过量时沉淀也不溶解）" if co2 else "（酸过量时沉淀又会溶解）"))
        if k == "Zn" and v["prevA"].get("Zn", 0) > 0.002:
            return say(v, "[Zn(OH)₄]²⁻ + 2H⁺ = Zn(OH)₂↓ + 2H₂O", "生成白色沉淀")
        # Al³⁺、Fe³⁺ 与 HCO₃⁻、CO₃²⁻ 相互促进水解
        add_ = v["added"]
        ib = len(add_) - 1 - add_[::-1].index("NaHCO₃") if "NaHCO₃" in add_ else -1
        ic = len(add_) - 1 - add_[::-1].index("Na₂CO₃") if "Na₂CO₃" in add_ else -1
        if k in ("Al", "Fe3") and (ib >= 0 or ic >= 0) and "dh" not in v["ev"]:
            v["ev"].add("dh")
            v["ev"].add("r:CO2")
            Mn, Pp = ("Al", "白色沉淀") if k == "Al" else ("Fe", "红褐色沉淀")
            return say(v, f"{Mn}³⁺ + 3HCO₃⁻ = {Mn}(OH)₃↓ + 3CO₂↑" if ib > ic else f"2{Mn}³⁺ + 3CO₃²⁻ + 3H₂O = 2{Mn}(OH)₃↓ + 3CO₂↑",
                       f"生成{Pp}，同时产生大量气泡：两种离子的水解相互促进" + ("（泡沫灭火器的原理）" if k == "Al" and ib > ic else ""))
        f = HF.get(k)
        if not f:
            return
        nh = v["last"] == "NH3" and len(f) > 1
        say(v, f[1 if nh else 0], (PDN.get(k) if nh else None) or PD[k])

    def ppt_off(v, k, e):
        if v["V"] < 0.05:
            return
        if k == "Fe2" and e["p"]["Fe3"] > 0.002:
            return
        if k == "Cu" and v["tot"].get("CuO", 0) > 0.002:
            return
        if k == "Al" and e["pH"] > 9:
            return say(v, "Al(OH)₃ + OH⁻ = [Al(OH)₄]⁻", "白色沉淀溶解：Al(OH)₃ 是两性氢氧化物（旧教材写作 Al(OH)₃ + OH⁻ = AlO₂⁻ + 2H₂O）")
        if k == "Cu" and e["cuN"] > 0.001:
            v["ev"].add("c:CuN")
            return say(v, "Cu(OH)₂ + 4NH₃ = [Cu(NH₃)₄]²⁺ + 2OH⁻", "蓝色沉淀溶解，得到深蓝色溶液")
        if k == "Ag" and e["agN"] > 0.001:
            return say(v, "Ag₂O + 4NH₃ + H₂O ⇌ 2[Ag(NH₃)₂]⁺ + 2OH⁻", "棕褐色沉淀溶解，得到银氨溶液")
        if k == "Zn" and e["znN"] > 0.001:
            return say(v, "Zn(OH)₂ + 4NH₃ = [Zn(NH₃)₄]²⁺ + 2OH⁻", "白色沉淀溶解")
        if k == "Zn" and e["znO"] > 0.001 and e["pH"] > 9:
            return say(v, "Zn(OH)₂ + 2OH⁻ = [Zn(OH)₄]²⁻", "白色沉淀溶解：Zn(OH)₂ 也是两性氢氧化物")
        if k == "CaOH":
            return say(v, "", "浑浊消失：Ca(OH)₂ 溶解")
        if k == "CaCO3" and v["last"] == "CO2":
            return say(v, "CaCO₃ + CO₂ + H₂O = Ca(HCO₃)₂", "浑浊消失，溶液重新变澄清")
        if HD.get(k) and e["pH"] < 7:
            return say(v, HD[k], "沉淀溶解，产生气泡" if k.endswith("CO3") else "沉淀溶解")
        say(v, "", PN[k] + " 沉淀溶解")

    def indicators(v, e):
        t, s = v["tot"], v["ind"]
        if v["V"] < 0.05:
            return
        pH = e["pH"]
        if t.get("phth", 0) > 0.05:
            n = "r" if pH > 9 else "n" if pH < 8.2 else s.get("phth")
            if n != s.get("phth"):
                if n == "r":
                    say(v, "", "酚酞变红：溶液呈碱性（pH > 8.2）")
                elif s.get("phth") == "r":
                    say(v, "", "红色褪去：溶液不再呈碱性")
                s["phth"] = n
        if t.get("lit", 0) > 0.05:
            n = "r" if pH < 5 else "b" if pH > 8 else "p"
            if n != s.get("lit"):
                if n == "r":
                    say(v, "", "石蕊变红：溶液呈酸性")
                elif n == "b":
                    say(v, "", "石蕊变蓝：溶液呈碱性")
                elif s.get("lit"):
                    say(v, "", "石蕊呈紫色：溶液接近中性")
                s["lit"] = n
        if t.get("mo", 0) > 0.05:
            n = "r" if pH < 3.1 else "y" if pH > 4.4 else "o"
            if n != s.get("mo"):
                say(v, "", "甲基橙变红（pH < 3.1）" if n == "r" else "甲基橙呈黄色（pH > 4.4）" if n == "y" else "甲基橙呈橙色（pH 3.1~4.4）")
                s["mo"] = n

    def flag(v, key, on, off):
        if on:
            ev(v, key)
        elif off:
            v["ev"].discard(key)

    # ---- 加入、混合与倾倒
    def heat_cap(v):
        return v["V"] * 4.18 + (v["oil"] or 0) * 1.35 + VT[v["type"]].glass

    def acid_base(e, V):
        return e["h"] * V + e["hac"], e["oh"] * V + e["nh3"]

    def mix(v, tt, mL, Tin):
        V0 = v["V"]
        e0, er = eqm(v["tot"], V0, None, v["T"]), eqm(tt, mL, None, Tin)
        a0, b0 = acid_base(e0, V0) if V0 > 0 else (0, 0)
        ar, br = acid_base(er, mL)
        C0, Cr = heat_cap(v), mL * 4.18
        for k, x in tt.items():
            _add(v["tot"], k, x)
        v["T"] = (C0 * v["T"] + Cr * Tin) / (C0 + Cr)
        v["V"] += mL
        e1 = v["e"] = eqm(v["tot"], v["V"], None, v["T"])
        v["_ek"] = None
        a1, b1 = acid_base(e1, v["V"])
        nW = max(0, min(a0 + ar, b0 + br, (a0 + ar + b0 + br - a1 - b1) / 2))
        if nW < 0.03:
            return None
        wa = (e0["hac"] if V0 > 0 else 0) + er["hac"] > (e0["h"] * V0 if V0 > 0 else 0) + er["h"] * mL
        wb = (e0["nh3"] if V0 > 0 else 0) + er["nh3"] > (e0["oh"] * V0 if V0 > 0 else 0) + er["oh"] * mL
        k = "n:ab" if wa and wb else "n:a" if wa else "n:b" if wb else "n:s"
        dT = DH[k] * nW / heat_cap(v)
        v["T"] += dT
        return {"dT": dT, "k": k}

    def neutral(v, r):
        if not r or r["dT"] < 0.3:   # 例如向 Na₂CO₃ 溶液中加酸：中和的只是少量 OH⁻，不单独提示
            return
        if r["k"] not in v["ev"]:
            v["ev"].add(r["k"])
            say(v, EV[r["k"]][0], f"酸碱中和，放出热量，温度升高 {fmt(r['dT'], 1)} °C" + ("" if r["k"] == "n:s" else "（有弱酸或弱碱参加，电离要吸热，中和放出的热量比强酸与强碱少）"))
        elif r["dT"] >= 0.5:
            B.toast(f"{v['name']}：中和放热，温度升高 {fmt(r['dT'], 1)} °C")

    def queued(v):
        return sum(a.get("mL", 0) for a in v["anims"])

    def add_reagent(v, r):
        if v.get('process'):
            B.toast('分离装置使用检查器中的过程样品，不混入任意反应试剂')
            return
        if r["id"] == "CO2":
            if v["V"] + queued(v) < 0.5:
                B.toast("容器里没有水溶液，CO₂ 无处吸收")
                return

            def go():
                v["feed"].append({"k": "C", "rate": 0.3, "left": 0.3})
                v["last"] = "CO2"
                note(v, "CO₂")
            v["anims"].append({"k": "gas", "t": 0.0, "go": go})
            return
        cap = VT[v["type"]].cap
        mL = 0.1 if r.get("drop") else st["amt"]
        if liq(v) + queued(v) + mL > cap + 1e-9:
            mL = cap - liq(v) - queued(v)
            if mL < 0.01:
                B.toast(f"{v['name']} 已经满了")
                return
            B.toast(f"{v['name']} 只能再装 {fmt(mL, 1)} mL")
        if r.get("oil"):
            def go_oil():
                first = not v["oil"]
                v["oil"] += mL
                v["T"] = (heat_cap(v) * v["T"] - mL * 1.35 * (v["T"] - 25)) / heat_cap(v)
                v["last"] = r["id"]
                note(v, r["f"])
                if first:
                    say(v, "", "CCl₄ 与水互不相溶，密度比水大，沉在下层。点「振荡 / 搅拌」让两层充分接触" if v["V"] > 0.3 else "CCl₄ 是无色油状液体，不溶于水")
            v["anims"].append({"k": "drip" if mL < 0.5 else "stream", "t": 0.0, "mL": mL, "col": swatch(r), "go": go_oil})
            return
        dilution = st.get('dilution', 1.) if not r.get('drop') and r['a'] else 1.
        tt = {k: x * mL * dilution for k, x in r["a"].items()}

        def go():
            v["last"] = r["id"]
            note(v, r["f"])
            neutral(v, mix(v, tt, mL, 25))
            if dilution != 1.:
                B.toast(f"{r['n']}：以水配制为标签浓度的 {dilution:g} 倍，加入 {mL:g} mL")
        v["anims"].append({"k": "drip" if mL < 0.5 else "stream", "t": 0.0, "mL": mL, "col": swatch(r), "go": go})

    def add_solid(v, k):
        if v.get('process'):
            B.toast('请使用分离装置内的独立样品')
            return
        if len(v["solids"]) + sum(1 for a in v["anims"] if a["k"] == "solid") >= 4:
            B.toast("一个容器里最多放 4 块固体")
            return
        d = SO[k]
        s = {"k": k, "n": d["mm"], "n0": d["mm"], "coat": {}, "lx": rnd(-0.5, 0.5), "seed": rnd(0, 100), "vx": 0.0}

        def go():
            v["solids"].append(s)
            note(v, d["f"])
            v["last"] = k
            if k == "Na" and v["V"] < 0.3:
                B.toast("钠要放进水里才会反应")
        v["anims"].append({"k": "solid", "t": 0.0, "s": s, "go": go})

    def transfer(v, u, fr):
        if v.get('process') or u.get('process'):
            B.toast('请用分离装置检查器操作，不与反应容器混倒')
            return
        Lq = liq(v)
        if Lq <= 1e-6 or fr <= 0:
            return True
        room_ = VT[u["type"]].cap - liq(u) - queued(u)
        mL = min(Lq * fr, room_)
        if mL <= 1e-6:
            return False
        k = mL / Lq
        Vw, Vo = v["V"] * k, (v["oil"] or 0) * k
        tt = {}
        for s in v["tot"]:
            tt[s] = v["tot"][s] * k
            v["tot"][s] -= tt[s]
        v["V"] -= Vw
        v["oil"] -= Vo
        if liq(v) < 1e-4:
            v["V"], v["oil"] = 0.0, 0.0
            for s in v["tot"]:
                v["tot"][s] = 0
        for a in list(v["added"]):
            note(u, a)
        if Vo > 0:
            u["ex"] = min(u["ex"], v["ex"]) if u["oil"] > 0 else v["ex"]
            u["oil"] += Vo
        u["last"] = v["last"]
        r = mix(u, tt, Vw, v["T"])
        v["e"] = eqm(v["tot"], v["V"], None, v["T"])
        v["_ek"] = None
        if r and v["pour"]:
            v["pour"]["dT"] = v["pour"].get("dT", 0) + r["dT"]
            v["pour"]["k"] = r["k"]
        else:
            neutral(u, r)
        return mL >= Lq * fr - 1e-6

    def start_pour(v, u):
        if v.get('process') or u.get('process'):
            B.toast('请用装置的连接端口与操作按钮转移样品')
            return
        if liq(v) < 0.01:
            B.toast(f"{v['name']} 是空的")
            v["lift"] = 0.0
            v["x"] = near_free(v, v.get("homeX", v["x"]))
            return
        if v.get("lamp"):
            v["lamp"]["v"] = None
            v["lamp"] = None
        v["pour"] = {"to": u, "t": 0.0, "done": 0.0, "full": False}

    # ---- 反应
    def solid_pos(v, s, lv):
        hw = max(0, VT[v["type"]].hw(5) - 9)
        if s["k"] == "Na":
            return s["lx"] * hw, lv - 2.5 if lv > 3 else 3
        return s["lx"] * hw, 3

    def spawn(v, src):
        t = VT[v["type"]]
        lv = lvl(v)
        if lv < 3 or len(v["bub"]) > 180:
            return
        if isinstance(src, dict) and src.get("k"):
            x, y = solid_pos(v, src, lv)
            x += rnd(-4, 4)
            y += rnd(0, 5)
        elif src == "tube":
            x, y = t.hw(8) * 0.45, 7
        else:
            y = rnd(2, lv * 0.8) if src == "w" else rnd(1, 6)
            x = rnd(-1, 1) * max(0, t.hw(y) - 3)
        v["bub"].append({"x": x, "y": min(y, lv - 1), "r": rnd(1.2, 3), "vy": rnd(35, 80), "w": rnd(0, TAU)})

    def gas(v, k, n, src):
        caught, lost = 0., n
        if v.get("gas_to"):
            caught, lost = route_gas(v,vessels(),k,n)
        totals = v.setdefault('gas_totals', dict(produced=0., captured=0., released=0.))
        totals['produced'] += n
        totals['captured'] += caught
        totals['released'] += lost
        local = n if not v.get('gas_to') or not v.get('gas_seal', True) else n * v.get('gas_leak', 0.)
        v["gas"][k] += local
        v["bacc"] += n * BF[k]
        m = 0
        while v["bacc"] >= 1 and m < 8:
            m += 1
            v["bacc"] -= 1
            spawn(v, src)
        if v["bacc"] > 3:
            v["bacc"] = 3

    def react(v, h):
        t = v["tot"]
        e = _eq(v)
        V = max(v["V"], 0.05)
        wet = v["V"] > 0.3
        Tf = 2 ** ((v["T"] - 25) / 10)
        hac = e["hac"] / V
        acid = e["h"] * V + e["hac"]
        d = e["dis"]
        eh = e["h"]
        heat = 0.0
        co2src = None
        for f in v["feed"]:
            x = min(f["left"], f["rate"] * h)
            f["left"] -= x
            _add(t, f["k"], x)
        if v["feed"]:
            v["feed"] = [f for f in v["feed"] if f["left"] > 1e-7]
        if wet:
            for s in v["solids"]:
                if s["n"] <= 1e-6:
                    continue
                k_ = s["k"]
                A = SO[k_]["A"] * ((s["n"] / s["n0"]) ** 2) ** (1 / 3)
                if k_ == "Na":
                    x = min(s["n"], 1.2 * A * h)
                    s["n"] -= x
                    _add(t, "Na", x)
                    gas(v, "H2", x / 2, s)
                    heat += 184 * x
                    ev(v, "m:Na")
                    continue
                ds = DSV.get(k_)
                if ds:   # 溶解或与水反应的固体
                    x = min(s["n"], ds["r"] * A * h)
                    s["n"] -= x
                    for kk, q in ds["add"].items():
                        _add(t, kk, q * x)
                    heat += ds["H"] * x
                    if k_ == "Na2O2":   # 2Na₂O₂ + 2H₂O：部分先生成 H₂O₂
                        gas(v, "O2", 0.35 * x, s)
                        _add(t, "H2O2", 0.3 * x)
                    if x / h > 1e-3:
                        ev(v, ds["ev"])
                    continue
                if k_ == "CaCO3":
                    pas = (d.get("SO4") or 0) / V > 0.05
                    x = min(s["n"], 0.08 * (eh + 0.05 * hac) * A * Tf * (0.06 if pas else 1) * h, 0.3 * acid / 2)
                    if x > 0:
                        s["n"] -= x
                        _add(t, "Ca", x)
                        _add(t, "C", x)
                        heat += 15 * x
                        co2src = s
                        if x / h > 4e-3:
                            ev(v, "m:CaCO3-HAc" if hac > eh * 5 else "m:CaCO3")
                        if pas and x / h < 2e-3 and "m:CaCO3" in v["ev"]:
                            ev(v, "m:CaCO3-SO4")
                    continue
                if d["NO3"] / V > 0.3 and eh > 0.1 and k_ in NIT:   # 稀硝酸把金属氧化，放出 NO 而不是 H₂
                    ion, z, kk = NIT[k_]
                    x = min(s["n"], kk * eh * A * Tf * h, 0.3 * eh * V * 3 / (4 * z))
                    if x > 1e-9:
                        s["n"] -= x
                        _add(t, ion, x)
                        _add(t, "NO3", -z * x / 3)
                        gas(v, "NO", z * x / 3, s)
                        heat += 120 * x
                        if x / h > 5e-4:
                            ev(v, "x:" + k_)
                    continue
                km = {"Zn": 0.1, "Fe": 0.03, "Mg": 0.6, "Al": 0.05}.get(k_)
                if km:
                    z = 3 if k_ == "Al" else 2
                    cell = 4 if s["coat"].get("Cu", 0) + s["coat"].get("Ag", 0) > 0.02 else 1   # 析出的铜与原金属构成原电池
                    x = min(s["n"], km * cell * (eh + 0.05 * hac) * A * Tf * h, 0.3 * acid / z)
                    if x > 1e-9:
                        s["n"] -= x
                        _add(t, MI[k_], x)
                        gas(v, "H2", x * z / 2, s)
                        heat += HM[k_] * x
                        if x / h > 1e-3:
                            ev(v, f"m:{k_}-H")
                            if cell > 1:
                                ev(v, "g:cell")
                    if k_ == "Al" and e["oh"] > 0.01:
                        y = min(s["n"], 0.04 * e["oh"] * A * Tf * h, 0.3 * e["oh"] * V)
                        if y > 0:
                            s["n"] -= y
                            _add(t, "Al", y)
                            gas(v, "H2", 1.5 * y, s)
                            heat += 400 * y
                            if y / h > 1e-3:
                                ev(v, "m:Al-OH")
                for ion, nu, dep in DISP.get(k_, ()):
                    av = d["Cu"] + e["cuN"] if ion == "Cu" else d["Ag"] + e["agN"] if ion == "Ag" else d["Zn"] + e["znN"] if ion == "Zn" else d[ion]
                    if not (av > 1e-7) or (ion == "Fe2" and d["Fe3"] > 1e-5):   # Fe³⁺ 先被还原
                        continue
                    kr = 0.06 if ion in ("Fe2", "Zn") else 0.2
                    x = min(s["n"], kr * av / V * A * Tf * h / nu, 0.5 * av / nu)
                    if x <= 0:
                        continue
                    s["n"] -= x
                    _add(t, MI[k_], x)
                    _add(t, ion, -nu * x)
                    if dep:
                        s["coat"][dep] = s["coat"].get(dep, 0) + nu * x
                    else:
                        _add(t, "Fe2", nu * x)
                    heat += 60 * x
                    if x / h > 3e-4:
                        ev(v, f"d:{k_}-{ion}")
        hp = t.get("H2O2", 0)
        if hp > 1e-6 and wet:
            mn = next((s for s in v["solids"] if s["k"] == "MnO2"), None)
            fe = d["Fe3"] / V
            kc = (0.08 if mn else 0) + 3 * fe
            kk = (kc + 3e-4) * Tf
            x = min(hp, hp * kk * h)
            _add(t, "H2O2", -x)
            gas(v, "O2", x / 2, mn or "w")
            heat += 98 * x
            if x / h > 2e-3:
                ev(v, "h2o2-MnO2" if mn else "h2o2-Fe3" if kc > 3e-4 * Tf else "h2o2-heat")
        fr = min(1, 10 * h)
        if eh > 1e-3 and d["MnO4"] > 1e-8:
            x = min(d["MnO4"], d["Fe2"] / 5) * fr
            if x > 1e-9:
                _add(t, "MnO4", -x)
                _add(t, "Mn", x)
                _add(t, "Fe2", -5 * x)
                _add(t, "Fe3", 5 * x)
                ev(v, "r:MnO4-Fe2")
            y = min(t.get("MnO4", 0) / 2, t.get("H2O2", 0) / 5) * fr
            if y > 1e-9:
                _add(t, "MnO4", -2 * y)
                _add(t, "Mn", 2 * y)
                _add(t, "H2O2", -5 * y)
                gas(v, "O2", 5 * y, "w")
                ev(v, "r:MnO4-H2O2")
        if t.get("Cl2", 0) > 1e-8:
            x = min(t["Cl2"], d["I"] / 2) * fr
            if x > 1e-9:
                _add(t, "Cl2", -x)
                _add(t, "I", -2 * x)
                _add(t, "I2", x)
                _add(t, "Cl", 2 * x)
                ev(v, "r:Cl2-I")
            x = min(t["Cl2"], min(d["Fe2"], t.get("Fe2", 0)) / 2) * fr
            if x > 1e-9:
                _add(t, "Cl2", -x)
                _add(t, "Fe2", -2 * x)
                _add(t, "Fe3", 2 * x)
                _add(t, "Cl", 2 * x)
                ev(v, "r:Cl2-Fe2")
            x = min(t["Cl2"], (d.get("Br") or 0) / 2) * fr   # 还原性 I⁻ > Fe²⁺ > Br⁻
            if x > 1e-9 and not (d["I"] > 1e-6) and not (d["Fe2"] > 1e-6):
                _add(t, "Cl2", -x)
                _add(t, "Br", -2 * x)
                _add(t, "Br2", x)
                _add(t, "Cl", 2 * x)
                ev(v, "r:Cl2-Br")
            if t["Cl2"] / V > 2e-3:
                for k in ("phth", "lit", "mo"):
                    if t.get(k, 0) > 0.05:
                        t[k] *= math.exp(-0.5 * h)
                        ev(v, "r:bleach")
        if t.get("Br2", 0) > 1e-8:
            x = min(t["Br2"], d["I"] / 2) * fr
            if x > 1e-9:
                _add(t, "Br2", -x)
                _add(t, "I", -2 * x)
                _add(t, "I2", x)
                _add(t, "Br", 2 * x)
                ev(v, "r:Br2-I")
            x = min(t["Br2"], min(d["Fe2"], t.get("Fe2", 0)) / 2) * fr
            if x > 1e-9:
                _add(t, "Br2", -x)
                _add(t, "Fe2", -2 * x)
                _add(t, "Fe3", 2 * x)
                _add(t, "Br", 2 * x)
                ev(v, "r:Br2-Fe2")
        # H₂O₂ 在强碱性溶液中使酚酞褪色（Na₂O₂ 与水的实验）
        if t.get("H2O2", 0) / V > 4e-3 and e["pH"] > 11.5 and t.get("phth", 0) > 0.05 and wet:
            t["phth"] *= math.exp(-0.12 * h)
            if t["phth"] < 0.5:
                ev(v, "r:H2O2-phth")
        # 氨的挥发：受热时加快（铵盐与碱共热放出 NH₃）
        if e["nh3"] > 1e-6 and wet:
            x = e["nh3"] * 0.0015 * 2 ** ((v["T"] - 25) / 10) * h
            _add(t, "N", -x)
            v["gas"]["NH3"] += x
            if v["T"] > 50 and x / h > 1e-3:
                ev(v, "r:NH3")
        if d["NO3"] / V > 0.3 and eh > 0.1 and d["Fe2"] > 1e-7:
            x = d["Fe2"] * min(1, 1.5 * h) / 3
            _add(t, "Fe2", -3 * x)
            _add(t, "Fe3", 3 * x)
            _add(t, "NO3", -x)
            gas(v, "NO", x, "w")
            if x / h > 1e-4:
                ev(v, "r:Fe2-HNO3")
        fi = min(d["Fe3"], d["I"], t.get("I", 0)) * min(1, 1.5 * h) / 2
        if fi > 1e-9:
            _add(t, "Fe3", -2 * fi)
            _add(t, "Fe2", 2 * fi)
            _add(t, "I", -2 * fi)
            _add(t, "I2", fi)
            if fi / h > 1e-4:
                ev(v, "r:Fe3-I")
        if eh > 1e-2 and t.get("H2O2", 0) > 1e-7 and d["I"] > 1e-7:
            x = 0.3 * min(t["H2O2"], d["I"] / 2) * h
            _add(t, "H2O2", -x)
            _add(t, "I", -2 * x)
            _add(t, "I2", x)
            if x / h > 1e-4:
                ev(v, "r:H2O2-I")
        p = e["p"]
        if p["Fe2"] > 1e-6:
            x = p["Fe2"] * 0.05 * Tf * h
            _add(t, "Fe2", -x)
            _add(t, "Fe3", x)
            if p["Fe2"] > 0.004 and p["Fe3"] > 0.15 * p["Fe2"]:
                ev(v, "r:Fe(OH)2-air")
        if v["T"] > 75 and p["Cu"] > 1e-6:
            x = p["Cu"] * 0.3 * h
            _add(t, "Cu", -x)
            _add(t, "CuO", x)
            if p["Cu"] > 0.004:
                ev(v, "r:CuO")
        if t.get("CuO", 0) > 1e-7 and eh > 1e-3:
            x = min(t["CuO"], (0.3 * t["CuO"] + 0.01) * h, 0.3 * eh * V / 2)
            _add(t, "CuO", -x)
            _add(t, "Cu", x)
            if x / h > 1e-3:
                ev(v, "r:CuO-H")
        # CO₂ 逸出
        c0 = e["h2co3"] / V
        sat = 0.034 * clamp(1.4 - v["T"] / 60, 0.15, 1)
        xc = (c0 - sat) * V * min(1, 4 * h) if c0 > sat else c0 * V * 0.003 * Tf * h
        if v["T"] > 95:
            xc += c0 * V * 0.2 * h
        if xc > 0 and wet:
            _add(t, "C", -xc)
            gas(v, "CO2", xc, co2src or ("w" if c0 > sat else "b"))
            if (xc / h > 3e-3 and not co2src and v["last"] != "CO2" and not v["feed"]
                    and not ((t.get("Al", 0) > 0.01 or t.get("Fe3", 0) > 0.01) and any(a in ("NaHCO₃", "Na₂CO₃") for a in v["added"]))):
                ev(v, "r:CO2")
        # 温度
        C = heat_cap(v)
        v["T"] += heat / C
        if v.get("lamp") and v["lamp"]["lit"]:
            v["T"] += 60 * h / C
        v["T"] -= (v["T"] - 25) * 0.004 * h * (2 if v["type"] == "tube" else 1)
        if v["T"] > 100 and v["V"] > 0:
            ex = (v["T"] - 100) * C
            v["T"] = 100.0
            v["V"] = max(0.0, v["V"] - ex / 2260)
            if v["V"] > 0:
                ev(v, "r:boil")
        if v["T"] > 300:
            v["T"] = 300.0
        if v["oil"] > 0 and v["T"] > 76:
            v["oil"] = max(0.0, v["oil"] - 0.02 * (v["T"] - 76) * h)
            if "w:CCl4" not in v["ev"]:
                v["ev"].add("w:CCl4")
                B.toast(f"{v['name']}：CCl₄ 沸点约 77 °C，受热挥发（蒸气有毒，实验中不要加热）", ms=5000)
        for k in t:
            if t[k] < 0:
                t[k] = 0

    def after(v, sd, dt):
        e = _eq(v)
        t = v["tot"]
        V = max(v["V"], 0.05)
        # 萃取：振荡时卤素单质很快在两层间达到分配平衡，静置时很慢
        if v["oil"] > 0 and v["V"] > 0.1:
            v["ex"] += (1 - v["ex"]) * (1 - math.exp(-(2.5 if v["stir"] > 0 else 0.01) * dt))
            if v["ex"] > 0.85 and v["stir"] <= 0:
                if t.get("I2", 0) > 2e-4:
                    ev(v, "k:I2")
                if t.get("Br2", 0) > 2e-4:
                    ev(v, "k:Br2")
        # 向 Na₂CO₃ 溶液中逐滴加酸：先生成 HCO₃⁻
        if ("Na₂CO₃" in v["added"] and v["last"] in ("HCl", "H2SO4", "HNO3", "HAc") and e["hco3"] > 0.6 * (e["hco3"] + e["co3"] + e["h2co3"])
                and e["hco3"] > 0.05 and "r:CO2" not in v["ev"]):
            ev(v, "r:CO3-H1")
        decay = math.exp(-sd / 5)
        pp = v["pp"]
        for k in PK:
            a = t.get("CuO", 0) if k == "CuO" else e["p"].get(k, 0)
            o = pp.get(k)
            if o is None:
                if a <= 0:
                    continue
                o = pp[k] = {"amt": 0.0, "sus": 0.0}
            if a > o["amt"]:
                o["sus"] += a - o["amt"]
            else:
                o["sus"] = o["sus"] * a / o["amt"] if o["amt"] > 0 else 0.0
            o["amt"] = a
            o["sus"] = min(o["sus"] * decay, a)
            if a > 0.004 and "p:" + k not in v["ev"]:
                v["ev"].add("p:" + k)
                ppt_on(v, k, e)
            elif a < 0.002 and "p:" + k in v["ev"]:
                v["ev"].discard("p:" + k)
                ppt_off(v, k, e)
        v["prevA"] = {"Al": e["alO"], "Zn": e["znO"]}
        fs = e.get("feSCN", 0) / V
        flag(v, "c:FeSCN", fs > 3e-4, fs < 1e-4)
        i2v = t.get("I2", 0) / V
        flag(v, "c:starch", t.get("starch", 0) > 0.05 and i2v > 3e-5, i2v < 1e-5)
        flag(v, "c:CuN", e["cuN"] / V > 5e-3 and not (e["p"]["Cu"] > 0.004), e["cuN"] / V < 1e-3)
        if v["T"] < 95:
            v["ev"].discard("r:boil")
        indicators(v, e)
        kg = math.exp(-dt / 12)
        for k in v["gas"]:
            v["gas"][k] *= kg
        # 气泡与泡沫（按真实时间）
        lv = lvl(v)
        if v["feed"]:
            v["tacc"] += dt * 30
            while v["tacc"] > 1:
                v["tacc"] -= 1
                spawn(v, "tube")
        if v["T"] > 99 and v["V"] > 0.3 and v.get("lamp") and v["lamp"]["lit"]:
            v["tacc"] += dt * 26
            while v["tacc"] > 1:
                v["tacc"] -= 1
                spawn(v, "b")
        pop = 0
        if v["bub"]:
            for b in v["bub"]:
                b["y"] += b["vy"] * dt
                b["w"] += dt * 6
                b["x"] += math.sin(b["w"]) * 0.3
                if b["y"] >= lv - 1:
                    pop += 1
            v["bub"] = [b for b in v["bub"] if b["y"] < lv - 1]
        v["foam"] = min(1, v["foam"] * math.exp(-dt * 1.5) + pop * 0.015)
        hw = max(1, VT[v["type"]].hw(max(lv, 5)) - 9)
        for s in v["solids"]:
            if s["k"] == "Na" and s["n"] > 1e-4 and v["V"] > 0.3:
                s["vx"] += rnd(-1, 1) * 260 * dt
                s["vx"] *= math.exp(-dt * 1.2)
                s["lx"] += s["vx"] * dt / hw
                if abs(s["lx"]) > 0.85:
                    s["lx"] = math.copysign(0.85, s["lx"])
                    s["vx"] *= -0.6
        v["solids"] = [s for s in v["solids"] if s["n"] > s["n0"] * 0.004 or any(x > 0.01 for x in s["coat"].values()) or s["k"] == "MnO2"]
        if v["stir"] > 0:
            v["stir"] -= dt
            for o in pp.values():
                o["sus"] = o["amt"]
        if v["test"]:
            v["test"]["t"] += dt
            if v["test"]["t"] > 2.2:
                v["test"] = None

    # ---- 检验与操作
    def test(v, k):
        g_ = {key: value + v.get('collected', {}).get(key, 0.) for key, value in v['gas'].items()}
        th = 0.012
        if k == "burn":
            if g_["H2"] > th:
                res, msg = "pop", "气体被点燃，发出轻微的“噗”声：是 H₂（若听到尖锐的爆鸣声，说明 H₂ 中混有空气，点燃前必须验纯）"
            elif g_["O2"] > th:
                res, msg = "bright", "木条燃烧得更旺：气体是 O₂（助燃）"
            elif g_["CO2"] > th:
                res, msg = "out", "燃着的木条熄灭：气体不支持燃烧，可能是 CO₂（N₂ 等也能使木条熄灭，要用澄清石灰水确认）"
            else:
                res, msg = "none", "木条照常燃烧：容器口没有收集到明显的气体"
        elif k == "lime":
            res, msg = ("cloudy", "澄清石灰水变浑浊：气体是 CO₂（CO₂ + Ca(OH)₂ = CaCO₃↓ + H₂O）") if g_["CO2"] > th else ("clear", "澄清石灰水没有变浑浊：容器口没有 CO₂")
        elif k == "litmus":
            res, msg = ("blue", "湿润的红色石蕊试纸变蓝：气体是 NH₃（NH₃ + H₂O ⇌ NH₃·H₂O，溶液显碱性）") if g_["NH3"] > 0.004 else ("red", "湿润的红色石蕊试纸不变色：没有检出 NH₃")
        else:
            res, msg = ("relight", "带火星的木条复燃：气体是 O₂") if g_["O2"] > th else ("ember", "木条没有复燃")
        v["test"] = {"k": k, "t": 0.0, "res": res}
        say(v, "", msg)

    def on_lamp(v):
        if v.get('process'):
            B.toast('请在分离装置检查器中操作加热')
            return
        if v['type'] in ('burette', 'cylinder', 'volumetric', 'bottle', 'gasjar'):
            B.toast('该计量或储存器材不用于直接加热；请换用适合加热的试管或烧瓶')
            return
        lp = next((l_ for l_ in lamps() if not l_["v"]), None)
        if not lp:
            B.toast("酒精灯上已经有容器了" if lamps() else "先从左侧添加一盏酒精灯")
            return
        if v.get("lamp"):
            return
        v["lamp"] = lp
        lp["v"] = v
        v["x"] = lp["x"]
        v["lift"] = 0.0
        inspect()

    def toggle_lamp(l_):
        l_["lit"] = not l_["lit"]
        B.toast("点燃酒精灯（用火柴点燃，不能用另一盏酒精灯引燃）" if l_["lit"] else "用灯帽盖灭酒精灯")
        sel = W["sel"]
        if sel is l_ or (sel and sel.get("lamp") is l_):
            inspect()

    # ---- 绘制
    def pcol(k, v):
        if k == "Fe2":
            a = v["pp"]["Fe2"]["amt"] if "Fe2" in v["pp"] else 0
            b = v["pp"]["Fe3"]["amt"] if "Fe3" in v["pp"] else 0
            return mix3(hx(PC["Fe2"]), (0.43, 0.5, 0.38), clamp(b / (a + b + 1e-9) * 3, 0, 1))
        return hx(PC[k])

    def mixc(lst):
        w = 0.0
        r = [0.0, 0.0, 0.0]
        for col, k in lst:
            w += k
            for i in range(3):
                r[i] += col[i] * k
        return tuple(x / w for x in r) if w else (1.0, 1.0, 1.0)

    def room_base():
        g = c.g
        S, TY = W["S"], W["TY"]
        wall = Gradient("linear", (0, 0, 0, TY), [(0, T.stage), (1, "#141c19" if T.dark else "#eef2f0")])
        D.rect(g, 0, 0, c.w, TY, wall)
        tile = 48 * S
        y, r = TY - tile, 0
        while y > 0:
            D.line(g, 0, y, c.w, y, T.grid, 1)
            x = (r % 2) * tile / 2
            while x < c.w:
                D.line(g, x, y, x, y + tile, T.grid, 1)
                x += tile
            y -= tile
            r += 1
        wood = ("#3c322a", "#221c17") if T.dark else ("#e8dbc2", "#c9b48d")
        D.rect(g, 0, TY, c.w, c.h - TY, Gradient("linear", (0, TY, 0, c.h), [(0, wood[0]), (1, wood[1])]))
        g.stroke_style, g.line_width = alpha("#000000" if T.dark else "#8c7651", 0.08), 1
        for i in range(1, 5):
            y = TY + (c.h - TY) * i / 5
            g.begin_path()
            g.move_to(0, y)
            g.bezier_to(c.w * 0.3, y + 3, c.w * 0.7, y - 3, c.w, y)
            g.stroke()
        D.line(g, 0, TY + 0.5, c.w, TY + 0.5, "#5d4e40" if T.dark else "#f6ecd9", 2)
        D.line(g, 0, TY + 2.5, c.w, TY + 2.5, alpha("#000000", 0.35 if T.dark else 0.08), 2)

    def room(g):
        S, TY = W["S"], W["TY"]
        L.cached(("room", round(S, 4), round(TY, 2)), room_base)
        for l_ in lamps():
            if l_["lit"]:
                D.rect(g, l_["x"] - 120 * S, TY - 120 * S, 240 * S, 240 * S,
                       Gradient("radial", (l_["x"], TY, 120 * S), [(0, "rgba(255,170,70,.22)"), (1, "rgba(255,170,70,0)")]))
        for v in vessels():
            if v.get('gas_water_ready') and v.get('collection') == 'water':
                D.rect(g, v['x']-70*S, TY-20*S, 140*S, 25*S,
                       alpha('#7baec5', .23), alpha('#628d9f', .75), 1.2)
                D.line(g, v['x']-67*S, TY-16*S, v['x']+67*S, TY-16*S, alpha('#c4e3ee', .8), 1)
        g.fill_style = alpha("#000000", 0.35 if T.dark else 0.12)
        for o in objs:
            if o["kind"] == "v" and (o.get("lamp") or o["pour"] or o["lift"] > 2):
                continue
            g.begin_path()
            g.ellipse(o["x"], TY + 2 * S, (50 if o["kind"] == "lamp" else VT[o["type"]].W + 6) * S, 5 * S)
            g.fill()

    def draw_lamp(g, l_):
        S, TY = W["S"], W["TY"]
        x, s = l_["x"], S
        ty = TY - 112 * s
        metal = "#8a949c" if T.dark else "#5b636a"
        if l_["v"] and l_["v"]["type"] == "tube":   # 试管直接在外焰上加热，用试管夹夹持
            hy = base(l_["v"]) - VT["tube"].H * s * 0.78
            g.line_cap = "round"
            D.line(g, x + 14 * s, hy, x + 120 * s, hy + 26 * s, "#a87a45", 6 * s)
            D.line(g, x + 14 * s, hy - 4 * s, x + 60 * s, hy + 6 * s, "#8c6236", 2 * s)
            g.line_cap = "butt"
            D.rect(g, x - 16 * s, hy - 5 * s, 30 * s, 10 * s, None, "#8c6236", 2 * s)
        else:
            g.line_cap = "round"
            D.line(g, x - 40 * s, ty, x - 50 * s, TY, metal, 3 * s)
            D.line(g, x + 40 * s, ty, x + 50 * s, TY, metal, 3 * s)
            D.line(g, x + 3 * s, ty, x + 6 * s, TY - 4 * s, alpha(metal, 0.45), 2.4 * s)
            D.line(g, x - 46 * s, ty, x + 46 * s, ty, metal, 3 * s)
            D.rect(g, x - 44 * s, ty - 4 * s, 88 * s, 4 * s, "#59605f" if T.dark else "#a7aba6")   # 陶土网
            mesh = alpha("#c9cfcc" if T.dark else "#ffffff", 0.35)
            for i in range(-40, 41, 6):
                D.line(g, x + i * s, ty - 4 * s, x + i * s, ty, mesh, 1)
            g.line_cap = "butt"
        by, bw, bh = TY, 27 * s, 40 * s

        def body():
            g.begin_path()
            g.move_to(x - bw, by)
            g.line_to(x - bw, by - bh * 0.45)
            g.quad_to(x - bw, by - bh, x - 8 * s, by - bh)
            g.line_to(x + 8 * s, by - bh)
            g.quad_to(x + bw, by - bh, x + bw, by - bh * 0.45)
            g.line_to(x + bw, by)
            g.close_path()
        body()
        g.fill_style = "rgba(180,210,230,.08)" if T.dark else "rgba(200,225,240,.35)"
        g.fill()
        g.save()
        g.clip_path()
        D.rect(g, x - bw, by - bh * 0.5, 2 * bw, bh, "rgba(120,170,220,.28)" if T.dark else "rgba(110,160,210,.3)")
        g.restore()
        body()
        g.stroke_style, g.line_width = alpha(T.fg, 0.5), 1.6
        g.stroke()
        D.rect(g, x - 7 * s, by - bh - 8 * s, 14 * s, 8 * s, "#7b8288" if T.dark else "#8f979d")
        D.rect(g, x - 1.6 * s, by - bh - 15 * s, 3.2 * s, 7 * s, "#3b302a")
        if l_["lit"]:
            clock = W["clock"]
            f = 1 + 0.08 * math.sin(clock * 17) + 0.05 * math.sin(clock * 29)
            fy, fh, fw = by - bh - 14 * s, 34 * s * f, 9 * s
            D.rect(g, x - 60 * s, fy - fh - 50 * s, 120 * s, 120 * s,
                   Gradient("radial", (x, fy - fh * 0.4, 60 * s), [(0, "rgba(255,170,60,.28)"), (1, "rgba(255,170,60,0)")]))
            for w, hh, col in ((fw, fh, "rgba(255,140,40,.85)"), (fw * 0.62, fh * 0.72, "rgba(255,214,90,.95)"), (fw * 0.3, fh * 0.32, "rgba(110,150,255,.8)")):
                g.begin_path()
                g.move_to(x, fy - hh)
                g.bezier_to(x + w * 1.1, fy - hh * 0.45, x + w, fy, x, fy)
                g.bezier_to(x - w, fy, x - w * 1.1, fy - hh * 0.45, x, fy - hh)
                g.fill_style = col
                g.fill()

    def draw_solid(g, v, s, lv):
        d = SO[s["k"]]
        f = (max(s["n"], 0) / s["n0"]) ** (1 / 3)
        x, y = solid_pos(v, s, lv)
        cs = sorted(s["coat"].items(), key=lambda p: -p[1])
        ctot = sum(p[1] for p in cs)
        ca = min(0.9, ctot * 1.2)
        cc = COAT[cs[0][0]] if cs else "#000000"
        k = s["k"]

        def blob(r, fill, cy):
            pts = []
            for i in range(9):
                a = i / 9 * TAU
                q = r * (0.8 + 0.22 * math.sin(s["seed"] + i * 2.3))
                pts.append((x + math.cos(a) * q, cy - math.sin(a) * q * 0.8))
            D.poly(g, pts, fill)

        def shape(fill, a):
            g.global_alpha = a
            if k == "Zn":
                blob(6 * f + 2, fill, -(y + 4 * f + 1))
            elif k == "CaCO3":
                blob(9 * f + 2.5, fill, -(y + 6 * f + 1))
            elif k == "CaO":
                blob(7 * f + 1.5, fill, -(y + 5 * f + 1))
            elif k == "NaOHs":
                for i in range(4):
                    D.circle(g, x + (i - 1.5) * 6 * f, -(y + 2.2 * f), 2.6 * f + 0.6, fill)
            elif k == "Na":
                D.circle(g, x, -y, 4.5 * f + 1.2, fill)
            elif k in ("MnO2", "Na2O2", "NH4NO3"):
                kk = 1 if k == "MnO2" else f
                w = (VT[v["type"]].hw(3) - 2) * (1 if k == "MnO2" else 0.35 + 0.65 * kk)
                pts = [(-w, 0)]
                for i in range(11):
                    pts.append((-w + 2 * w * i / 10, -(3 + 1.2 * math.sin(s["seed"] + i)) * kk * (1 + 1.6 * math.sin(PI * i / 10) * (0 if k == "MnO2" else 1))))
                pts.append((w, 0))
                D.poly(g, pts, fill)
            else:
                ln = min(VT[v["type"]].H * 0.5, 72) if k == "Fe" else 38 if k == "Cu" else 36 * f + 6 if k == "Mg" else 18 * f + 4
                lean = 1.38 if v["type"] == "tube" else 1.25 if k == "Cu" else 0.16
                wd = 3.6 if k == "Fe" else 4.5 if k == "Cu" else 2.2 if k == "Mg" else 3
                x2, y2 = x + math.cos(lean) * ln, -(y + math.sin(lean) * ln)
                g.line_cap = "round"
                D.line(g, x, -y - 1, x2, y2, fill, wd)
                g.line_cap = "butt"
                if k == "Fe":
                    D.line(g, x2 - 4, y2, x2 + 4, y2, fill, 3)
            g.global_alpha = 1
        shape(d["col"], 1)
        if ca > 0.02:
            shape(cc, ca)
        if k == "Na" and s["n"] > 1e-4 and v["V"] > 0.3:
            for _ in range(5):
                D.circle(g, x + rnd(-7, 7), -y - rnd(0, 3), rnd(0.8, 1.8), "rgba(255,255,255,.7)")

    def draw_vessel(g, v, X, Yb, ang):
        t = VT[v["type"]]
        Pf, H = t.p, t.H
        e = v["e"]
        lv = lvl(v)
        clock = W["clock"]
        g.save()
        g.translate(X, Yb)
        if ang:
            g.rotate(ang)
        g.scale(W["S"], W["S"])

        def path():
            g.begin_path()
            g.move_to(-Pf[-1][0], -H)
            for q in reversed(Pf):
                g.line_to(-q[0], -q[1])
            for q in Pf:
                g.line_to(q[0], -q[1])
        g.save()
        path()
        g.clip_path()
        D.rect(g, -t.W - 4, -H - 2, 2 * t.W + 8, H + 4, "rgba(160,200,225,.05)" if T.dark else "rgba(120,170,205,.07)")
        if lv > 0.4:
            fI, fB = aq_f(v, "I2"), aq_f(v, "Br2")
            tr = tint(v["tot"], v["V"], e, fI, fB)
            lc = tr
            a = min(0.92, 0.10 + 0.82 * (1 - sum(tr) / 3))

            def fill_liq(col):
                if ang:
                    g.save()
                    g.rotate(-ang)
                    D.rect(g, -400, max(-lv, -H * math.cos(ang) - 8), 800, 800, col)
                    g.restore()
                else:
                    D.rect(g, -t.W - 3, -lv, 2 * t.W + 6, lv + 3, col)
            fill_liq(css(lc, a))
            if not ang and v["oil"] > 0.01:   # 下层 CCl₄
                lo = t.lvl(v["oil"])
                to = tint_oil(v["tot"].get("I2", 0) * (1 - fI), v["tot"].get("Br2", 0) * (1 - fB), v["oil"])
                oc = (to[0] * 0.7, to[1] * 0.78, to[2] * 0.9)
                D.rect(g, -t.W - 3, -lo, 2 * t.W + 6, lo + 3, css(oc, min(0.94, 0.38 + 0.6 * (1 - (to[0] + to[1] + to[2]) / 3))))
                if v["V"] > 0.1:
                    sw = t.hw(lo)
                    D.line(g, -sw, -lo, sw, -lo, "rgba(255,255,255,.4)", 1)
            sus = 0.0
            sl = []
            for k, o in v["pp"].items():
                if o["sus"] > 1e-5:
                    sus += o["sus"]
                    sl.append((pcol(k, v), o["sus"]))
            if sus > 1e-5:
                sc = mixc(sl)
                cs = sus / max(v["V"], 0.1)
                fill_liq(css(sc, min(0.86, 1 - math.exp(-cs * 25))))
                if not ang:   # 悬浮的颗粒
                    n = min(110, round(cs * 3000) + 6)
                    pc_ = css(tuple(x * 0.62 for x in sc), 0.6)

                    def fr(q):
                        return q - math.floor(q)
                    for i in range(n):
                        y = ((fr(math.sin(i * 78.233 + v["id"]) * 12345.678) * lv - clock * 2.5 * (1 + i % 3)) % lv + lv) % lv
                        x = (fr(math.sin(i * 12.9898 + v["id"]) * 43758.5453) * 2 - 1) * max(0, t.hw(y) - 2)
                        D.rect(g, x - 0.8, -y - 0.8, 1.6, 1.6, pc_)
            if not ang:
                sw = t.hw(lv)
                # 水相润湿玻璃：两侧稍高，中部为读数所用的弯月面底部。
                g.begin_path()
                g.move_to(-sw, -lv - 1.5)
                g.quad_to(0, -lv + 1.5, sw, -lv - 1.5)
                g.stroke_style, g.line_width = "rgba(255,255,255,.65)", 1.2
                g.stroke()
                if v["foam"] > 0.05:
                    i = -sw + 3
                    while i < sw - 2:
                        D.circle(g, i + math.sin(i * 7.3) * 1.2, -lv - 1, 1.2 + v["foam"] * 1.6 * (0.6 + 0.4 * math.sin(i * 3.1 + clock * 3)), "rgba(255,255,255,.5)")
                        i += 4
        # 沉在底部的沉淀
        st_ = 0.0
        sl2 = []
        for k, o in v["pp"].items():
            s = o["amt"] - o["sus"]
            if s > 1e-5:
                st_ += s
                sl2.append((pcol(k, v), s))
        if st_ > 2e-4:
            w = t.hw(3) + 2
            hg = min(max(lv * 0.7, 3) if lv > 2 else 24, 1.5 + 9 * math.sqrt(st_) * 14 / max(14, t.hw(3)))
            col = mixc(sl2)
            pts = [(-w, 2)] + [(-w + 2 * w * i / 14, -hg * (0.78 + 0.22 * math.sin(i * 1.7 + v["id"]))) for i in range(15)] + [(w, 2)]
            D.poly(g, pts, css(col, 0.95), css(tuple(x * 0.62 for x in col), 0.9), 1)
            dot = css(tuple(x * 0.78 for x in col), 0.9)
            for i in range(18):
                px = -w + (math.sin(i * 12.9898 + v["id"]) * 0.5 + 0.5) * 2 * w
                py = -(math.sin(i * 78.233) * 0.5 + 0.5) * hg * 0.8
                D.rect(g, px, py, 1.4, 1.4, dot)
        for s in v["solids"]:
            draw_solid(g, v, s, lv)
        for b in v["bub"]:
            D.circle(g, b["x"], -b["y"], b["r"], "rgba(255,255,255,.18)", "rgba(255,255,255,.75)", 0.8)
            D.circle(g, b['x'] - b['r']*.28, -b['y'] - b['r']*.3, max(.3, b['r']*.19), 'rgba(255,255,255,.8)')
        D.rect(g, -t.W, -H, 2*t.W, H, Gradient('linear', (-t.W, 0, t.W, 0), [
            (0, 'rgba(70,110,130,.16)'), (.08, 'rgba(235,250,255,.25)'),
            (.22, 'rgba(255,255,255,.02)'), (.7, 'rgba(255,255,255,0)'),
            (.91, 'rgba(80,120,140,.13)'), (1, 'rgba(235,250,255,.22)')]))
        g.restore()
        # 玻璃
        if W["sel"] is v:   # 选中：一圈柔和的光（宽描边叠一层代替 shadowBlur）
            path()
            g.stroke_style, g.line_width = alpha(T.accent, 0.22), 8
            g.stroke()
            path()
            g.stroke_style, g.line_width = alpha(T.accent, 0.9), 3.2
            g.stroke()
        glass = "rgba(210,228,238,.62)" if T.dark else "rgba(60,80,92,.62)"
        path()
        g.stroke_style, g.line_width = glass, 2
        g.stroke()
        rim = Pf[-1][0]
        D.line(g, -rim - 3, -H, rim + 3, -H, "rgba(210,228,238,.7)" if T.dark else "rgba(60,80,92,.7)", 2.4)
        if v.get('gas_to') and v.get('gas_seal', True):
            D.rrect(g, -rim + 1, -H-5, 2*rim-2, 9, 2, '#6c6760', '#403e39', 1)
        hl = []
        y = H * 0.16
        while y <= H * 0.84:
            hl.append((-t.hw(y) + 5, -y))
            y += 3
        D.poly(g, hl, None, "rgba(255,255,255,.35)", 2.4, close=False)
        if v["type"] == "burette":
            # 50 mL 刻度管：0 在上，50 在下；与 VType 的体积/液面映射一致。
            for mark in range(51):
                y = t.lvl(t.cap - mark)
                major = mark % 5 == 0
                D.line(g, -rim + 1, -y, -rim + (9 if major else 5), -y, alpha(T.fg, .65), .8)
                if major:
                    D.text(g, str(mark), rim + 4, -y, T.fg, size=8, mono=True)
            D.text(g, "mL", rim + 4, -H + 7, T.muted, size=8)
            # 玻璃管尖与活塞，开度影响手柄方向；空隙按模型管尖容量显示。
            D.poly(g, [(-rim, 0), (-3, 8), (-2, 18), (2, 18), (3, 8), (rim, 0)],
                   alpha('#bddbe9', .18), glass, 1)
            opening = v.get('titration_opening', .25) if v.get('titration_valve') else 0.
            D.line(g, -14, 6, 14, 6 - opening * 8, '#c7d2d6' if T.dark else '#667c88', 3)
            if v.get('titration_training') and chem_titration.tip_volume(v) < chem_titration.TIP_CAPACITY - 1e-6:
                D.circle(g, 0, 12, 2.2, alpha('#ffffff', .65), glass, .6)
        if v["type"] == "beaker":
            g.begin_path()
            g.move_to(-rim - 3, -H)
            g.quad_to(-rim - 9, -H - 2, -rim - 10, -H - 6)
            g.stroke_style, g.line_width = glass, 2
            g.stroke()
            for m in (50, 100, 150):
                y = t.lvl(m)
                D.line(g, rim - 14, -y, rim - 2, -y, alpha(T.fg, 0.45), 1)
                D.text(g, str(m), rim - 16, -y, alpha(T.fg, 0.5), size=8, align="right", mono=True)
        g.restore()

    def draw_anims(g, v):
        S = W["S"]
        clock = W["clock"]
        X = v["x"]
        top = top_y(v)
        surf = base(v) - lvl(v) * S
        if v.get('gas_arrival', 0.) > 0 and v.get('gas_water_ready') and lvl(v) > 3:
            for i in range(5):
                fraction = (clock * 1.5 + i/5) % 1
                D.circle(g, X + math.sin(i*2.1 + clock)*2*S, base(v) - (3 + fraction*(lvl(v)-3))*S,
                         1.5*S, alpha('#ffffff', .18), alpha('#def3fa', .8), .7)
        for a in v["anims"]:
            if a["k"] == "drip":
                tip = top - 10 * S
                p = clamp(a["t"] / 0.45, 0, 1)
                D.rrect(g, X - 4 * S, tip - 44 * S, 8 * S, 12 * S, 3 * S, "#b54a3c")
                D.rect(g, X - 2.5 * S, tip - 32 * S, 5 * S, 30 * S, "rgba(200,220,235,.25)" if T.dark else "rgba(150,190,215,.35)", alpha(T.fg, 0.5), 1)
                if p < 1:
                    D.circle(g, X, lerp(tip, surf, p * p), 2.6 * S, a["col"])
            elif a["k"] == "stream":
                bx, by = X + 26 * S, top - 30 * S
                g.save()
                g.translate(bx, by)
                g.rotate(-2.1)
                D.rrect(g, -9 * S, -26 * S, 18 * S, 30 * S, 3 * S, "rgba(200,220,235,.2)" if T.dark else "rgba(255,255,255,.6)", alpha(T.fg, 0.5), 1.2)
                D.rect(g, -8 * S, -12 * S, 16 * S, 15 * S, a["col"])
                g.restore()
                if a["t"] < 0.55:
                    g.begin_path()
                    g.move_to(bx - 14 * S, by + 6 * S)
                    g.quad_to(X + 4 * S, by + 10 * S, X + 2 * S, surf)
                    g.stroke_style, g.line_width = a["col"], 3 * S
                    g.stroke()
            elif a["k"] == "solid":
                p = clamp(a["t"] / 0.5, 0, 1)
                y = lerp(top - 26 * S, base(v) - 6 * S, p * p)
                D.circle(g, X, y, 4 * S, SO[a["s"]["k"]]["col"], alpha(T.fg, 0.4), 1)
        if v["gas"]["NO"] > 0.003:   # NO 在容器口遇空气变成红棕色的 NO₂
            k = clamp(v["gas"]["NO"] * 25, 0.15, 1)
            for i in range(5):
                p = (clock * 0.35 + i / 5) % 1
                sx = X + math.sin(clock * 1.3 + i * 1.7) * 10 * S * p
                D.circle(g, sx, top - 4 * S - p * 50 * S, (5 + p * 12) * S, f"rgba(176,84,34,{(1 - p) * 0.5 * k:.3f})")
        if v["T"] > 70 and v["V"] > 0.05:   # 水蒸气
            k = clamp((v["T"] - 70) / 30, 0, 1)
            rgb = "220,228,235" if T.dark else "140,152,162"
            for i in range(4):
                p = (clock * 0.45 + i / 4) % 1
                sx = X + math.sin(clock * 1.7 + i * 2) * 8 * S * p
                D.circle(g, sx, top - 6 * S - p * 60 * S, (4 + p * 10) * S, f"rgba({rgb},{(1 - p) * 0.45 * k:.3f})")
        if v["feed"]:
            tx = X + VT[v["type"]].hw(8) * 0.45 * S
            D.line(g, tx, top - 40 * S, tx, base(v) - 7 * S, "rgba(210,228,238,.6)" if T.dark else "rgba(60,80,92,.55)", 3 * S)
            D.text(g, "CO₂", tx + 6 * S, top - 34 * S, T.muted, size=11)
        if v["stir"] > 0:
            sx = X + math.sin(clock * 9) * VT[v["type"]].hw(10) * 0.5 * S
            D.line(g, sx - 8 * S, top - 30 * S, sx, base(v) - 6 * S, "rgba(220,235,245,.75)" if T.dark else "rgba(80,100,112,.7)", 3 * S)
        q = v["test"]
        if q and q["k"] in ("lime", "litmus"):
            mx, my = X + 4 * S, top - 8 * S
            p = clamp((q["t"] - 0.3) / 0.9, 0, 1)
            if q["k"] == "lime":   # 蘸有澄清石灰水的玻璃片
                D.rect(g, mx - 26 * S, my - 3 * S, 52 * S, 4 * S, "rgba(200,225,240,.35)" if T.dark else "rgba(170,205,225,.55)", alpha(T.fg, 0.45), 1)
                w = p if q["res"] == "cloudy" else 0
                g.begin_path()
                g.ellipse(mx, my + 2.5 * S, 9 * S, 3 * S)
                g.fill_style = f"rgba({int(lerp(190, 248, w))},{int(lerp(220, 248, w))},{int(lerp(240, 244, w))},{0.55 + 0.4 * w:.3f})"
                g.fill()
            else:   # 湿润的红色石蕊试纸
                c0, c1 = (214, 72, 82), (62, 98, 214)
                w = p if q["res"] == "blue" else 0
                D.line(g, mx + 30 * S, my - 34 * S, mx + 4 * S, my - 2 * S, "#b88a52", 2.4 * S)
                g.save()
                g.translate(mx, my)
                g.rotate(-0.9)
                D.rect(g, -4 * S, -2 * S, 22 * S, 7 * S, f"rgba({int(lerp(c0[0], c1[0], w))},{int(lerp(c0[1], c1[1], w))},{int(lerp(c0[2], c1[2], w))},1)")
                g.restore()
        elif q:
            mx, my = X + 6 * S, top - 4 * S
            ex, ey = mx + 70 * S, my - 46 * S
            g.line_cap = "round"
            D.line(g, ex, ey, mx, my, "#b88a52", 3.2 * S)
            g.line_cap = "butt"
            res, qt = q["res"], q["t"]
            lit = res in ("bright", "none") or (res == "relight" and qt > 0.5) or (res == "pop" and qt > 0.6)
            if res == "pop" and 0.25 < qt < 0.6:
                D.circle(g, mx, my, (qt - 0.25) * 120 * S, f"rgba(255,220,120,{0.6 - (qt - 0.25):.3f})")
            if lit:
                k = 1.8 if res == "bright" else 1.3 if res == "relight" else 1
                fh = 14 * S * k * (1 + 0.1 * math.sin(clock * 20))
                g.begin_path()
                g.move_to(mx, my - fh)
                g.quad_to(mx + 6 * S * k, my - fh * 0.3, mx, my + 2)
                g.quad_to(mx - 6 * S * k, my - fh * 0.3, mx, my - fh)
                g.fill_style = "rgba(255,160,50,.9)"
                g.fill()
            else:
                D.circle(g, mx, my, 2.4 * S, "#555555" if res == "out" else "#ff6a2a")
                if res == "out":
                    for i in range(4):
                        D.circle(g, mx + math.sin(qt * 3 + i) * 4 * S, my - (qt * 30 + i * 8) * S, 3 * S, "rgba(150,150,150,.3)")

    def pour_pose(v):   # 倾倒时源容器的位置与角度
        p = v["pour"]
        u = p["to"]
        S = W["S"]
        H = VT[v["type"]].H * S
        ang = (1 if u["x"] >= v.get("homeX", v["x"]) else -1) * 1.85 * clamp(p["t"] / 0.4, 0, 1) ** 0.7
        mx = u["x"] - math.copysign(1, ang or 1) * outer_w(u) * 0.35
        my = top_y(u) - 10 * S
        return mx - H * math.sin(ang), my + H * math.cos(ang), ang, mx, my

    def draw():
        layout()
        g = c.g
        c.clear()
        S, TY = W["S"], W["TY"]
        sel = W["sel"]
        room(g)
        for v in vessels():
            if v.get('titration_mount'):
                target_v = next((u for u in vessels() if u['id'] == v.get('titration_target') and u is not v), None)
                x, y = v['x'], base(v)
                D.rrect(g, x - 65*S, TY - 4*S, 100*S, 5*S, 2*S, '#566873')
                D.line(g, x - 48*S, TY - 4*S, x - 48*S, max(50*S, y - 220*S), '#7b909c', 4*S)
                D.line(g, x - 48*S, y - 170*S, x + 10*S, y - 170*S, '#7b909c', 3*S)
                D.rect(g, x - 14*S, y - 175*S, 28*S, 10*S, None, '#71858e', 2*S)
                fall = v.get('titration_drop', 0.)
                if fall > 0 and target_v:
                    phase = 1 - fall / .35
                    y0, y1 = y + 18*S, base(target_v) - lvl(target_v)*S
                    D.circle(g, x, lerp(y0, y1, phase*phase), 1.7*S, alpha('#74b9d1', .85))
        for l_ in lamps():
            draw_lamp(g, l_)
        vs = sorted((v for v in vessels() if not v["pour"]), key=lambda v: v is sel)
        for v in vs:
            v["x"] = clamp(v["x"], outer_w(v) + 4, c.w - outer_w(v) - 4)
            draw_vessel(g, v, v["x"], base(v), 0)
            draw_anims(g, v)
        for v in vessels():
            u = next((q for q in vessels() if q["id"]==v.get("gas_to")),None)
            if u:
                sy, uy = top_y(v), top_y(u)
                level = min(sy, uy) - 25*S
                g.begin_path()
                g.move_to(v['x'], sy)
                g.line_to(v['x'], level)
                if u.get('gas_water_ready') and u.get('collection') == 'water':
                    side = u['x'] + (VT[u['type']].W + 18)*S
                    g.line_to(side, level)
                    g.line_to(side, base(u) - 4*S)
                    g.line_to(u['x'], base(u) - 4*S)
                else:
                    g.line_to(u['x'], level)
                    g.line_to(u['x'], uy + 15*S)
                g.stroke_style, g.line_width = '#6d929d', 4*S
                g.stroke()
                g.stroke_style, g.line_width = alpha('#d4eaf0', .7), 1.3*S
                g.stroke()
            trace = v.get("titration_trace",[])
            if len(trace)>1 and (v is sel or (sel and sel.get("titration_target")==v["id"])):
                left,top,right,_bottom=B.safe()
                x0,y0=left+20,top+32
                width=min(300,max(120,c.w-left-right-40))
                maximum=max(1,trace[-1][0])
                D.rect(g,x0,y0,width,142,T.raised,T.line,1)
                D.text(g,"滴定曲线 · 实收体积 / mL",x0+8,y0+18,T.fg,size=11)
                gx, gy, gw, gh = x0+27, y0+29, width-39, 89
                for value in (0, 7, 14):
                    yy = gy + gh - value/14*gh
                    D.line(g, gx, yy, gx+gw, yy, T.line, .7)
                    D.text(g, str(value), gx-5, yy+3, T.muted, size=8, align='right')
                D.text(g, '0', gx, gy+gh+14, T.muted, size=8)
                D.text(g, f'{maximum:.2f}', gx+gw, gy+gh+14, T.muted, size=8, align='right')
                for a,b in zip(trace,trace[1:]):
                    D.line(g,gx+a[0]/maximum*gw,gy+gh-clamp(a[1],0,14)/14*gh,
                           gx+b[0]/maximum*gw,gy+gh-clamp(b[1],0,14)/14*gh,T.c1,2)
        for v in vessels():
            if v["pour"]:
                qx, qy, ang, mx, my = pour_pose(v)
                draw_vessel(g, v, qx, qy, ang)
                if 0.35 < v["pour"]["t"] < 1.15 and liq(v) > 0.01:
                    u = v["pour"]["to"]
                    sy = base(u) - lvl(u) * S
                    tr = tint(v["tot"], v["V"], v["e"])
                    D.line(g, mx, my, mx + (u["x"] - mx) * 0.2, sy, css((tr[0] * 0.66, tr[1] * 0.84, tr[2] * 0.97), 0.85), 4 * S)
        for v in vessels():
            if v["pour"] or v["lift"] > 2:
                continue
            if v.get('titration_mount'):
                lx, ly = v['x'] + 35*S, top_y(v) + 24*S
                D.text(g, v['name'], lx, ly, T.accent if sel is v else T.fg, size=11*S, bold=True)
                D.text(g, f"读数 {chem_titration.source_reading(v):.2f} mL", lx, ly + 16*S, T.muted, size=9*S)
                continue
            ly = TY + 17 * S
            D.text(g, v["name"], v["x"], ly, T.accent if sel is v else T.fg, size=12.5 * S, align="center", bold=True)
            sub = " + ".join(v["added"][-3:]) or "空"
            D.text(g, "…" + sub[-21:] if len(sub) > 22 else sub, v["x"], ly + 16 * S, T.muted, size=11 * S, align="center")
            detail = f"{fmt(liq(v), 1)} mL · {fmt(v['T'], 0)} °C"
            if v.get('process'):
                detail = '独立过程样品'
            elif v.get('gas_water_ready'):
                volume = sum(gas_volume(n, v['T']) for n in v.get('collected', {}).values())
                detail = f"水 {v['V']:.1f} / 气 {volume:.1f} mL"
            D.text(g, detail, v['x'], ly + 31*S, T.bad if v['T'] > 40 else T.muted,
                   size=(12 if v.get('process') else 10.5)*S, align='center', mono=True)
        if sel and sel.get('process'):
            separation.draw(sel['process'],c,B)
        for l_ in lamps():
            if not l_["v"]:
                D.text(g, "酒精灯" + ("（燃着）" if l_["lit"] else ""), l_["x"], TY + 17 * S, T.accent if sel is l_ else T.muted, size=12 * S, align="center")
        if not vessels():
            D.text(g, "从左侧添加试管、烧杯或锥形瓶", clear_mid(), c.h * 0.42, T.muted, size=15, align="center")
    L.on_draw(draw)

    # ---- 交互
    def hit_obj(x, y):
        S, TY = W["S"], W["TY"]
        for o in reversed(objs):
            if o["kind"] == "v" and not o["pour"] and abs(x - o["x"]) < outer_w(o) + 6 and top_y(o) - 12 < y < base(o) + 6:
                return o
        for o in objs:
            if o["kind"] == "lamp" and abs(x - o["x"]) < 50 * S and TY - 118 * S < y < TY + 4:
                return o
        return None

    def vessel_at(x, y):
        S = W["S"]
        return next((v for v in vessels() if not v["pour"] and abs(x - v["x"]) < outer_w(v) + 22 * S and top_y(v) - 90 * S < y < base(v) + 40 * S), None)

    def settle(v):
        S = W["S"]
        tgt = next((u for u in vessels() if u is not v and not u["pour"] and abs(u["x"] - v["x"]) < (outer_w(u) + outer_w(v)) * 0.8
                    and v["lift"] > 25 * S and base(v) < top_y(u) + 36 * S), None)
        if tgt:
            start_pour(v, tgt)
            return
        v["lift"] = 0.0
        lp = next((l_ for l_ in lamps() if not l_["v"] and abs(l_["x"] - v["x"]) < 46 * S), None)
        if lp:
            v["lamp"] = lp
            lp["v"] = v
            v["x"] = lp["x"]
            inspect()
            return
        v["x"] = near_free(v, v["x"])

    def hit(x, y):
        o = hit_obj(x, y)
        return {"o": o, "ox": x - o["x"], "y0": y, "b0": base(o) if o["kind"] == "v" else 0, "moved": False} if o else None

    def down(_x, _y, h):
        if h:
            select(h["o"])

    def drag(h, x, y, _dx, _dy):
        o = h["o"]
        if o["kind"] == "v" and o["pour"]:
            return
        if not h["moved"]:
            h["moved"] = True
            if o["kind"] == "v":
                o['titration_mount'] = False
                o['titration_valve'] = False
                o["homeX"] = o["x"]
                if o.get("lamp"):
                    o["lamp"]["v"] = None
                    o["lamp"] = None
                    inspect()
        if o["kind"] == "v":
            o["x"] = clamp(x - h["ox"], 20, c.w - 20)
            o["lift"] = max(0.0, W["TY"] - (h["b0"] + y - h["y0"]))
        else:
            o["x"] = clamp(x - h["ox"], 40, c.w - 40)
            if o["v"]:
                o["v"]["x"] = o["x"]

    def up(h):
        if not h or not h["moved"]:
            return
        if h["o"]["kind"] == "v":
            settle(h["o"])
        else:
            h["o"]["x"] = near_free(h["o"], h["o"]["x"])
            if h["o"]["v"]:
                h["o"]["v"]["x"] = h["o"]["x"]

    def click(_x, _y, h):
        if not h:
            select(None)
        elif h["o"]["kind"] == "lamp":
            toggle_lamp(h["o"])
    L.interact(c, hit=hit, down=down, drag=drag, up=up, click=click)

    def on_key(k, _e):
        if k in ("Delete", "Backspace") and W["sel"]:
            remove(W["sel"])
            return True
        return False
    L.on_key(on_key)

    # ---- 示例实验：摆好容器和药品，提示下一步
    def scene(p):
        objs.clear()
        for k in cnt:
            cnt[k] = 0
        W["sel"] = None
        records.clear()
        B.log.clear()
        st["amt"] = float(p.get("amt", 2))
        st["speed"] = float(p.get("speed", 1))
        st['dilution'] = float(p.get('dilution', 1.))
        W["tip"] = p.get("tip", "")
        layout()
        n = len(p["v"])
        vs = []
        for i, d in enumerate(p["v"]):
            left, _t, right, _b = B.safe()
            x = left + (c.w - left - right) * (i + 0.7) / (n + 0.4)
            if d.get("lamp"):
                new_lamp(x)
                continue
            v = new_v(d["t"], x)
            vs.append(v)
            for id_, mL in d.get("r") or []:
                r = RG_BY[id_]
                if r.get("oil"):
                    v["oil"] += mL
                    note(v, r["f"])
                    continue
                mix(v, {k: x_ * mL for k, x_ in r["a"].items()}, mL, 25)
                note(v, r["f"])
                v["last"] = id_
            for k in d.get("s") or []:
                v["solids"].append({"k": k, "n": SO[k]["mm"], "n0": SO[k]["mm"], "coat": {}, "lx": rnd(-0.4, 0.4), "seed": rnd(0, 100), "vx": 0.0})
                note(v, SO[k]["f"])
            if d.get('sample'):
                sample = d['sample']
                mix(v, dict(sample['tot']), sample['V'], 25)
                note(v, sample['name'])
            v["e"] = eqm(v["tot"], v["V"])
            v["_ek"] = None
        if vs:
            W["sel"] = None
            select(vs[0])
        else:
            inspect()
        if W["tip"]:
            B.toast(f"<b>下一步</b><br>{W['tip']}", ms=9000)

    # ---- 检查器
    def titration_target(v):
        target_v=next((q for q in vessels() if q["id"]==v.get("titration_target")),None)
        if target_v is None:
            raise ValueError("请先选择接收容器")
        if v["anims"] or target_v["anims"] or v["pour"] or target_v["pour"]:
            raise ValueError("请等待当前加液或倾倒完成，再进行滴定计量")
        return target_v

    def waste_target(v):
        target_v = next((q for q in vessels() if q['id'] == v.get('titration_waste')), None)
        if target_v is None or target_v is v or target_v.get('process'):
            raise ValueError('请先另选废液容器')
        if v['anims'] or target_v['anims'] or v['pour'] or target_v['pour']:
            raise ValueError('请等待当前加液或倾倒完成')
        if v.get('titration_valve'):
            raise ValueError('请先关闭活塞')
        return target_v

    def rinse_burette(v):
        try:
            waste = waste_target(v)
            amount = chem_titration.rinse_amount(v, waste, VT[waste['type']].cap)
        except ValueError as error:
            B.toast(str(error))
            return
        was_water = v.get('last') == 'H2O' or not any(abs(n) > 1e-10 for n in v['tot'].values())
        transfer(v, waste, amount / liq(v))
        chem_titration.finish_rinse(v, was_water)
        v['stir'] = 1.2
        refresh()
        B.toast(f"旋转润洗后排入{waste['name']}；管壁保留 0.10 mL 残液，下一次装液会实际混合")

    def purge_burette(v):
        try:
            waste = waste_target(v)
            chem_titration._solution(v)
            missing = chem_titration.TIP_CAPACITY - chem_titration.tip_volume(v)
            draw = min(missing + .05, v['V'] - chem_titration.tip_volume(v))
            if draw < missing + .01:
                raise ValueError('溶液不足以充满管尖并排出液滴，请先装液')
            outlet = draw - missing
            if liq(waste) + queued(waste) + outlet > VT[waste['type']].cap:
                raise ValueError('废液容器容量不足')
        except ValueError as error:
            B.toast(str(error))
            return
        transfer(v, waste, outlet / liq(v))
        v['titration_prep']['tip_ml'] = chem_titration.TIP_CAPACITY
        v.pop('titration_run', None)
        refresh()
        L.draw()
        B.toast('已充满管尖并向废液容器排出液滴；现在记录初始读数')

    def begin_titration(v):
        try:
            target_v = titration_target(v)
            chem_titration.begin(v, target_v, VT[v["type"]].cap)
        except ValueError as error:
            B.toast(str(error))
            return
        target_v["titration_trace"] = [[0., _eq(target_v)["pH"]]]
        target_v['endpoint_hold'] = 0.
        refresh()
        L.draw()
        B.toast("已记录初始读数；接收液曲线开始新一轮记录")

    def titrate(v, requested=None, quiet=False):
        try:
            target_v = titration_target(v)
            if v.get('titration_training') and not v.get('titration_mount'):
                raise ValueError('请先将滴定管固定到接收瓶上方')
            if v.get('titration_mount'):
                gap = top_y(target_v) - base(v)
                mouth = max(3., VT[target_v['type']].p[-1][0] - 3) * W['S']
                if abs(v['x'] - target_v['x']) > mouth or not 20*W['S'] <= gap <= 60*W['S']:
                    raise ValueError('接收瓶已移开或高度不合适，请重新将滴定管固定到接收瓶上方')
            amount = chem_titration.dose(v, target_v, v.get("dose", .05) if requested is None else requested,
                                         VT[target_v["type"]].cap, VT[v["type"]].cap)
        except ValueError as error:
            v['titration_valve'] = False
            B.toast(str(error))
            return False
        before=v["V"]
        trace=target_v.setdefault("titration_trace",[[0,_eq(target_v)["pH"]]])
        fill = min(amount, chem_titration.TIP_CAPACITY - chem_titration.tip_volume(v)) if v.get('titration_training') else 0.
        outlet = max(0., amount - fill)
        if outlet > 1e-9:
            transfer(v,target_v,outlet / liq(v))
        amount=chem_titration.commit(v, before, VT[v["type"]].cap, fill)
        if amount > 1e-9:
            trace.append([trace[-1][0]+amount,_eq(target_v)["pH"]])
            if len(trace) > 400:
                trace = [trace[0]] + trace[2:-1:2] + [trace[-1]]
            target_v["titration_trace"] = trace
            target_v['endpoint_hold'] = 0.
            v['titration_drop'] = .35
        if not quiet:
            refresh()
            L.draw()
            B.toast(f"实际滴入 {amount:.3f} mL；{f'另有 {fill:.3f} mL 充入管尖；' if fill else ''}接收液 pH={_eq(target_v)['pH']:.3f}")
        return True

    def toggle_valve(v):
        if v.get('titration_valve'):
            v['titration_valve'] = False
        else:
            try:
                target_v = titration_target(v)
                if not v.get('titration_mount'):
                    raise ValueError('请先将滴定管固定到接收瓶上方')
                chem_titration.dose(v, target_v, .05, VT[target_v['type']].cap)
                v['titration_valve'] = True
            except ValueError as error:
                B.toast(str(error))
        refresh()

    def mount_burette(v):
        try:
            target_v = titration_target(v)
            if target_v['type'] == 'burette' or target_v.get('lamp') or target_v.get('gas_water_ready'):
                raise ValueError('请使用未在加热的锥形瓶或烧杯接收')
        except ValueError as error:
            B.toast(str(error))
            return
        v['titration_mount'] = True
        v['titration_mount_height'] = VT[target_v['type']].H + 24 + target_v['lift'] / W['S']
        v['x'] = target_v['x']
        v['lift'] = 0.
        L.draw()

    def record_endpoint(v):
        sources = [q for q in vessels() if q.get('titration_run', {}).get('target') == v['id']]
        if not sources:
            B.toast('尚无对应的滴定记录')
            return
        source = sources[-1]
        run = source['titration_run']
        if abs(source['V'] - run['expected_volume']) > 1e-6 or abs(chem_titration.tip_volume(source) - run.get('expected_tip', 0.)) > 1e-6:
            B.toast('管内液量已改变，本轮读数无效；请重新记录初始读数')
            return
        pH = _eq(v)['pH']
        record = dict(indicated=chem_titration.source_reading(source) - run['initial'],
                      received=run['delivered'], pH=pH, hold=v.get('endpoint_hold', 0.))
        v.setdefault('titration_results', []).append(record)
        v['titration_results'] = v['titration_results'][-12:]
        B.toast(f"已记录：读数差 {record['indicated']:.2f} mL，实收 {record['received']:.2f} mL，pH {pH:.2f}")
        refresh()

    def prepare_gasjar(v):
        try:
            if v['anims'] or v['pour']:
                raise ValueError('请等待当前加液或倾倒完成')
            prepare_water_collection(v, VT[v['type']].cap)
        except ValueError as error:
            B.toast(str(error))
            return
        v['e'] = eqm(v['tot'], v['V'])
        v['_ek'] = None
        note(v, '倒置排水收集')
        inspect()
        L.draw()
        B.toast('集气瓶已注满清水并倒置在水槽中；进入气体会实际排出等体积的水')

    def inspect():
        B.clear_panel()
        W["ui"] = None
        W["uil"] = None
        if W["tip"]:
            L.group("实验提示")
            L.note(W["tip"])
        sel = W["sel"]
        ui = None
        if sel and sel["kind"] == "v":
            v = sel
            if v.get('process'):
                separation.inspector(v['process'],L,L.draw)
                L.button('删除装置',lambda _b:remove(v))
                B.show_panel()
                return
            L.group(v["name"])
            ui = {"v": v, "m": L.out()}
            targets=[("0","断开")]+[(str(u["id"]),u["name"]) for u in vessels() if u is not v and not u.get('process')]
            if v['type'] != 'burette':
                L.group("导管与收集")
                L.select("导管连接至",targets,str(v.get("gas_to",0)),lambda value:v.__setitem__("gas_to",int(value)))
                L.check('加塞并密封导气口', v.get('gas_seal', True), lambda value: v.__setitem__('gas_seal', value))
                L.slider('接口漏气比例', 0, .5, .05, v.get('gas_leak', 0.), lambda value: v.__setitem__('gas_leak', value))
                L.select("本容器用途",[("up","向上排空气（较重气体）"),("down","向下排空气（较轻气体）"),("water","排水（仅H₂/O₂）"),("wash","石灰水洗气检验")],v.get("collection","up"),lambda value:v.__setitem__("collection",value))
                if v['type'] == 'gasjar':
                    L.button('注满水并倒置', lambda _b: prepare_gasjar(v))
                ui['gas_balance'] = L.out()
                L.note("密封与接口漏气会影响实际捕集量；漏气比例是本台教学参数。排水法仅支持H₂/O₂，按1atm理想气体排开等体积水。未模拟初始空气混合、水蒸气和气液压差，收集量不代表纯度。")
            if v["type"]=="burette":
                L.group("定量滴定")
                L.select("滴入容器",targets,str(v.get("titration_target",0)),lambda value:v.__setitem__("titration_target",int(value)))
                L.button('固定到接收瓶上方', lambda _b: mount_burette(v))
                if v.get('titration_training'):
                    L.select('废液容器', targets, str(v.get('titration_waste', 0)), lambda value: v.__setitem__('titration_waste', int(value)))
                    L.button('旋转润洗并排液', lambda _b: rinse_burette(v))
                    L.button('排尽管尖气泡', lambda _b: purge_burette(v))
                else:
                    def enable_training(_b):
                        chem_titration.prepare(v)
                        inspect()
                    L.button('启用操作训练', enable_training)
                ui['prep'] = L.out()
                L.slider("每次滴加",.02,2,.01,v.get("dose",.05),lambda value:v.__setitem__("dose",value),"mL")
                L.button("记录初始读数",lambda _b:begin_titration(v))
                L.button("滴加一次",lambda _b:titrate(v))
                L.slider('活塞开度', .05, 1, .05, v.get('titration_opening', .25), lambda value: v.__setitem__('titration_opening', value))
                ui['valve'] = L.button('打开活塞', lambda _b: toggle_valve(v))
                ui["titration"] = L.out()
                ui["titration"].el.setMinimumHeight(150)
                L.note("先用清水、再用待用溶液润洗，装液后排管尖气泡。记录初始读数后滴定；临近终点逐滴加入。读数是模型值，尚未模拟视差。")
            if v.get('titration_trace'):
                L.group('滴定终点观察')
                ui['endpoint'] = L.out()
                L.button('记录终点', lambda _b: record_endpoint(v))
            L.group("溶液中的主要粒子")
            ui["sp"] = L.out()
            L.group("沉淀与固体")
            ui["pp"] = L.out()
            L.group("检验与操作")
            L.button("燃着的木条", lambda _b: test(v, "burn"))
            L.button("带火星的木条", lambda _b: test(v, "glow"))
            L.button("澄清石灰水", lambda _b: test(v, "lime"))
            L.button("湿润的红色石蕊试纸", lambda _b: test(v, "litmus"))
            L.button("振荡 / 搅拌", lambda _b: v.__setitem__("stir", 1.2))
            if v.get("lamp"):
                L.button("熄灭酒精灯" if v["lamp"]["lit"] else "点燃酒精灯", lambda _b: toggle_lamp(v["lamp"]))
            else:
                L.button("放到酒精灯上", lambda _b: on_lamp(v))
            others = [u for u in vessels() if u is not v]
            if others:
                L.group("")
                s = L.select("倒入另一个容器（也可以直接把容器拖到另一个容器上方）", [[u["id"], u["name"]] for u in others], others[0]["id"], lambda _v: None)

                def pour(_b):
                    u = next((o for o in objs if str(o["id"]) == s.v), None)
                    if u:
                        v["homeX"] = v["x"]
                        start_pour(v, u)
                L.button("倒入", pour)
            L.button("清空", lambda _b: empty(v))
            L.button("移走", lambda _b: remove(v))
        elif sel and sel["kind"] == "lamp":
            lamp = sel
            L.group("酒精灯")
            L.note("点击酒精灯可以点燃或熄灭。试管可以用试管夹夹持，直接在外焰上加热；烧杯、锥形瓶要垫陶土网加热。水温最高到 100 °C 并逐渐蒸发。")
            L.button("熄灭" if lamp["lit"] else "点燃", lambda _b: toggle_lamp(lamp), True)
            L.button("移走", lambda _b: remove(lamp))
        else:
            L.group("使用方法")
            L.note("<b>选容器</b>：点击台面上的容器。<br><b>加药品</b>：点左侧的试剂加入选中的容器，或把试剂拖到任意容器上。<br>"
                   "<b>倾倒</b>：把一个容器拖到另一个容器上方后松开。<br><b>加热</b>：把容器拖到酒精灯上，点击酒精灯点燃。<br>选中后按 Delete 可移走。")
        L.group("每次加入的液体")
        L.seg("", [[0.1, "2 滴"], [1.0, "1 mL"], [2.0, "2 mL"], [5.0, "5 mL"], [20.0, "20 mL"]], st["amt"], lambda x: st.__setitem__("amt", float(x)))
        L.note("指示剂每次固定加 2 滴。")
        L.slider('溶液稀释倍率', .05, 1., .05, st.get('dilution', 1.), lambda value: st.__setitem__('dilution', value))
        L.note('本次水溶液按标签浓度 × 倍率以水配制；不影响指示剂、水和有机溶剂。')
        L.group("时间")
        L.seg("", [[1.0, "1×"], [5.0, "5×"], [20.0, "20×"]], st["speed"], lambda x: st.__setitem__("speed", float(x)))
        L.group("反应记录")
        lb = L.note("")
        L.panel_lay.addStretch(1)
        if ui is not None:
            ui["log"] = lb
            W["ui"] = ui
        else:
            W["uil"] = {"log": lb}
        render_log()
        refresh()

    def fc(x):
        return (fmt(x, 3) if x >= 0.01 else sci(x, 1)) + " mol/L"

    def refresh():
        ui = W["ui"]
        if not ui:
            return
        v = ui["v"]
        e, V, t = v["e"], v["V"], v["tot"]
        try:
            if "titration" in ui:
                ui["titration"].set(chem_titration.rows(v, VT[v["type"]].cap))
                ui['prep'].set(chem_titration.preparation_rows(v))
                ui['valve'].setText('关闭活塞' if v.get('titration_valve') else '打开活塞')
            if 'endpoint' in ui:
                phth = v['tot'].get('phth', 0) > .05
                hold = v.get('endpoint_hold', 0.)
                endpoint_rows = [['pH', f"{e['pH']:.2f}"], ['浅红保持', f'{hold:.1f} s']]
                endpoint_rows.append('酚酞浅红保持30秒可作为本例终点观察；颜色终点不等同于化学等量点。' if phth else '未加酚酞，不能用浅红色判断本例终点。')
                for rec in v.get('titration_results', [])[-3:]:
                    endpoint_rows.append(f"记录：读数差 {rec['indicated']:.2f} / 实收 {rec['received']:.2f} mL，pH {rec['pH']:.2f}")
                ui['endpoint'].set(endpoint_rows)
            if 'gas_balance' in ui:
                totals = v.get('gas_totals', {})
                rows = [[label, f'{totals.get(key, 0):.4g} mmol'] for key, label in
                        (('produced', '累计产气'), ('captured', '捕集或吸收'), ('released', '未收集'))]
                if v.get('gas_water_ready'):
                    rows.append(['已排入水槽', f"{v.get('water_displaced', 0):.2f} mL"])
                ui['gas_balance'].set(rows)
            ui["m"].set([
                ["气体收集",f"{sum(gas_volume(n,v.get('T',25)) for n in v.get('collected',{}).values()):.2f} mL"] if v['type'] != 'burette' else None,
                ["连接状态",v.get("gas_note") or ("导管已连接" if v.get("gas_to") else "未连接")] if v['type'] != 'burette' else None,
                ["剩余清水" if v.get('gas_water_ready') else "体积", f"水层 {fmt(V, 1)} + CCl₄ {fmt(v['oil'], 1)} mL" if v["oil"] > 0.01 else f"{fmt(V, 1)} / {VT[v['type']].cap} mL"],
                ["温度", f"{fmt(v['T'], 1)} °C"],
                ["pH 计", fmt(e["pH"], 2) if V > 0.05 else "—"],
                ["pH 试纸", f"<span style='color:{_hexc(ramp(PHP, e['pH']))}'>■</span> 约 {round(clamp(e['pH'], 0, 14))}"] if V > 0.05 else None,
            ])
            if V < 0.05:
                ui["sp"].set(f"<span style='color:{T.muted}'>{'只有四氯化碳，没有水溶液。' if v['oil'] > 0.01 else '容器里没有液体。'}</span>")
            else:
                rows = []

                def put(n, mm):
                    x = mm / V
                    if x > 1e-4:
                        rows.append((n, x))
                for k, n in NM.items():
                    put(n, e["dis"].get(k) or 0)
                if e["h"] > 1e-4:
                    rows.append(("H⁺", e["h"]))
                if e["oh"] > 1e-4:
                    rows.append(("OH⁻", e["oh"]))
                for n, x in (("[Cu(NH₃)₄]²⁺", e["cuN"]), ("[Ag(NH₃)₂]⁺", e["agN"]), ("[Zn(NH₃)₄]²⁺", e["znN"]), ("[Al(OH)₄]⁻", e["alO"]), ("[Zn(OH)₄]²⁻", e["znO"]),
                             ("[FeSCN]²⁺", e.get("feSCN", 0)), ("NH₃·H₂O", e["nh3"]), ("NH₄⁺", e["nh4"]), ("CH₃COOH", e["hac"]), ("CH₃COO⁻", e["ac"]),
                             ("H₂CO₃", e["h2co3"]), ("HCO₃⁻", e["hco3"]), ("CO₃²⁻", e["co3"]),
                             ("H₂O₂", t.get("H2O2", 0)), ("I₂", t.get("I2", 0) * aq_f(v, "I2")), ("Br₂", t.get("Br2", 0) * aq_f(v, "Br2")), ("Cl₂", t.get("Cl2", 0))):
                    put(n, x)
                rows.sort(key=lambda r: -r[1])
                out = [[n, fc(x)] for n, x in rows[:12]]
                pH = e["pH"]
                ind = []
                if t.get("phth", 0) > 0.05:
                    ind.append("酚酞" + ("（红）" if pH > 9 else "（浅红）" if pH > 8.2 else "（无色）"))
                if t.get("lit", 0) > 0.05:
                    ind.append("石蕊" + ("（红）" if pH < 5 else "（蓝）" if pH > 8 else "（紫）"))
                if t.get("mo", 0) > 0.05:
                    ind.append("甲基橙" + ("（红）" if pH < 3.1 else "（黄）" if pH > 4.4 else "（橙）"))
                if t.get("starch", 0) > 0.05:
                    ind.append("淀粉" + ("（蓝）" if t.get("I2", 0) / V > 3e-5 else ""))
                if ind:
                    out.append(["指示剂", " ".join(ind)])
                if v["oil"] > 0.01:
                    ci = t.get("I2", 0) * (1 - aq_f(v, "I2")) / v["oil"]
                    cb = t.get("Br2", 0) * (1 - aq_f(v, "Br2")) / v["oil"]
                    parts = ([f"I₂ {fc(ci)}"] if ci > 1e-4 else []) + ([f"Br₂ {fc(cb)}"] if cb > 1e-4 else [])
                    out.append(["CCl₄ 层", "，".join(parts) or "无色"])
                ui["sp"].set(out if out else f"<span style='color:{T.muted}'>只有水。</span>")
            pr = []
            for k in PK:
                o = v["pp"].get(k)
                if o and o["amt"] > 0.002:
                    pr.append([f"<span style='color:{_hexc(pcol(k, v))}'>■</span> {PN[k]}{'' if k == 'CuO' else ' ↓'}", f"{fmt(o['amt'] * PM[k], 1)} mg"])
            for s in v["solids"]:
                ct = [COATN[k] for k, x in s["coat"].items() if x > 0.01]
                pr.append([f"<span style='color:{qc(SO[s['k']]['col']).name()}'>■</span> {SO[s['k']]['n']}" + (f"（表面附着{'、'.join(ct)}）" if ct else ""),
                           f"{fmt(s['n'] * SO[s['k']]['M'] / 1000, 3)} g"])
            ui["pp"].set(pr if pr else f"<span style='color:{T.muted}'>没有沉淀或固体。</span>")
        except RuntimeError:   # 检查器刚被重建
            pass
    L.every(250, refresh)

    # ---- 素材栏
    def target():
        sel = W["sel"]
        return sel if sel and sel["kind"] == "v" else None

    def r_item(r):
        def clk():
            v = target()
            if not v:
                B.toast("先点选一个容器，或把试剂拖到容器上")
                return
            add_reagent(v, r)

        def drp(x, y):
            v = vessel_at(x, y)
            if not v:
                B.toast("把试剂拖到容器上")
                return
            select(v)
            add_reagent(v, r)
        col = qc(swatch(r))
        hexa = col.name()
        return {"icon": (ic_dropper if r.get("drop") else ic_bottle)(hexa), "label": r["n"], "sub": r["f"] + (" · " + r["c"] if r.get("c") else ""), "click": clk, "drop": drp}

    def s_item(k):
        def clk():
            v = target()
            if not v:
                B.toast("先点选一个容器")
                return
            add_solid(v, k)

        def drp(x, y):
            v = vessel_at(x, y)
            if not v:
                B.toast("把固体拖到容器上")
                return
            select(v)
            add_solid(v, k)
        return {"icon": ic_solid(SO[k]["col"]), "label": SO[k]["n"], "sub": SO[k]["f"], "click": clk, "drop": drp}

    def separation_item(kind):
        def drop(x=None,_y=None):
            v=new_v('flask' if kind=='distill' else 'beaker',x)
            if v:
                v['process']=separation.create(kind)
                v['name']=separation.NAMES[kind]
                select(v)
        return dict(id='process-'+kind,icon=bench_object_svg(kind,'',IC['flask']),label=separation.NAMES[kind],sub='连接、守恒量与过程读数',click=lambda:drop(),drop=drop)

    def v_item(typ, sub):
        def clk():
            v = new_v(typ)
            if v:
                select(v)

        def drp(x, _y):
            v = new_v(typ, x)
            if v:
                select(v)
        return {"id":"vessel-"+typ,"icon": IC.get(typ,IC["flask"]), "label": VT[typ].n, "sub": sub, "click": clk, "drop": drp}

    def lamp_click():
        l_ = new_lamp()
        if l_:
            select(l_)

    def lamp_drop(x, _y):
        l_ = new_lamp(x)
        if l_:
            select(l_)

    def co2_click():
        v = target()
        if not v:
            B.toast("先点选一个容器")
            return
        add_reagent(v, {"id": "CO2"})

    def co2_drop(x, y):
        v = vessel_at(x, y)
        if not v:
            B.toast("拖到容器上")
            return
        select(v)
        add_reagent(v, {"id": "CO2"})

    def safe_moved(old, new):
        """浮窗开合：台面上的东西按比例挪进露出来的范围，不会被盖住。"""
        was, now = max(1, c.w - old[0] - old[2]), max(1, c.w - new[0] - new[2])
        layout()
        for o in objs:
            o["x"] = new[0] + (o["x"] - old[0]) / was * now
    B.on_safe(safe_moved)
    blank = {"v": [{"t": "tube"}, {"t": "beaker"}, {"t": "flask"}, {"lamp": 1}]}

    def titration_demo():
        scene(dict(dilution=.1, amt=5., tip='润洗 → 装液 → 排气泡 → 固定 → 记录初读数 → 滴定。稀释倍率0.1将标签NaOH配为0.1mol/L。',
                   v=[dict(t='burette'), dict(t='flask', sample=dict(V=25., tot=dict(Cl=2.5, phth=2.), name='25mL 0.1mol/L HCl + 酚酞')),
                      dict(t='beaker')]))
        source = next(v for v in vessels() if v['type'] == 'burette')
        receiver = next(v for v in vessels() if v['type'] == 'flask')
        waste = next(v for v in vessels() if v['type'] == 'beaker')
        waste['name'] = '废液烧杯'
        source.update(titration_target=receiver['id'], titration_waste=waste['id'])
        W['sel'] = None
        select(source)

    def oxygen_demo():
        scene(dict(amt=2., tip='先选集气瓶“注满水并倒置”；再选发生瓶加塞密封，加入二氧化锰。可改变接口漏气比例，比较产气、捕集与未收集量。',
                   v=[dict(t='flask', r=[('H2O2', 10)]), dict(t='gasjar')]))
        source, collector = vessels()
        source['name'] = '氧气发生瓶'
        collector['name'] = '氧气集气瓶'
        source['gas_to'] = collector['id']
        collector['collection'] = 'water'
        W['sel'] = None
        select(source)

    B.palette([
        {'title': '操作训练', 'tab': 'exp', 'items': [dict(id='chem-titration-training', icon=IC['demo'], label='酸碱滴定 · 操作训练', sub='润洗 · 排气泡 · 活塞 · 终点记录', click=titration_demo),
             dict(id='chem-oxygen-training', icon=IC['gas'], label='制取氧气 · 气密性', sub='加塞 · 导气 · 排水 · 捕集量比较', click=oxygen_demo)]},
        {"title": "示例实验", "tab": "exp", "items": [{"icon": IC["demo"], "label": n, "sub": s, "click": (lambda p=p: scene(p))} for n, s, p in PRE]},
        {"title": "器材", "tab": "item", "items": [v_item("tube", "20 mL"), v_item("beaker", "200 mL"), v_item("flask", "250 mL"),
                                  {"icon": IC["lamp"], "label": "酒精灯", "sub": "带三脚架和陶土网", "click": lamp_click, "drop": lamp_drop},
                                  {"icon": IC["bin"], "label": "清空台面", "sub": "恢复空的试管、烧杯、锥形瓶", "replace": True, "click": lambda: scene(blank)}]},
        {"title":"计量与储存容器","tab":"item","items":[v_item(k,f"{VT[k].cap} mL · 容积/热容参与计算") for k in VT if k not in ("tube","beaker","flask")]},
        {"title":"分离装置","tab":"item","items":[separation_item(kind) for kind in separation.NAMES]},
        {"title": "酸和碱", "tab": "reagent", "items": [r_item(r) for r in RG if r["s"] == "acid"]},
        {"title": "盐溶液", "tab": "reagent", "items": [r_item(r) for r in RG if r["s"] == "salt"]},
        {"title": "氧化剂和还原剂", "tab": "reagent", "items": [r_item(r) for r in RG if r["s"] == "redox"]},
        {"title": "指示剂", "tab": "reagent", "items": [r_item(r) for r in RG if r["s"] == "ind"]},
        {"title": "固体", "tab": "reagent", "items": [s_item(k) for k in SO]},
        {"title": "水、溶剂和气体", "tab": "reagent", "items": [r_item(r) for r in RG if r["s"] == "gas"] + [{"icon": IC["gas"], "label": "通入 CO₂", "sub": "每次约 0.3 mmol", "click": co2_click, "drop": co2_drop}]},
    ])
    B.tips([("可以试试", [
        "试管里加硫酸铜溶液，再逐滴（2 滴）加氢氧化钠溶液；然后加稀硫酸。", "氯化铝溶液里逐滴加氢氧化钠溶液至过量；换一支试管改用氨水，对比现象。",
        "澄清石灰水中反复通入 CO₂，先浑浊后澄清；再放到酒精灯上加热。", "硫酸亚铁溶液中加氢氧化钠溶液，把时间调到 20×，看沉淀颜色的变化。",
        "铁钉放进硫酸铜溶液；铜片放进硝酸银溶液或氯化铁溶液。", "锥形瓶里放氢氧化钠溶液和酚酞，再分次加入稀盐酸，注意颜色和温度。",
        "过氧化氢溶液中加二氧化锰，用带火星的木条检验；锌粒与稀盐酸，用燃着的木条检验。", "FeCl₃ 溶液滴入 KSCN；FeSO₄ 溶液先加 KSCN，再加氯水。",
        "烧杯里加水和酚酞，放入一小块金属钠。", "大理石分别放入稀盐酸、稀硫酸和醋酸中，比较反应快慢。"])])

    # ---- 主循环
    def tick(dt):
        if not L.stage.isVisible() or L.stage.window().isMinimized():
            return
        W["clock"] += dt
        sd = dt * st["speed"]
        n = max(1, math.ceil(sd / 0.05))
        h = sd / n
        active_targets = set()
        for v in vessels():
            v['titration_drop'] = max(0., v.get('titration_drop', 0.) - dt)
            v['gas_arrival'] = max(0., v.get('gas_arrival', 0.) - dt)
            if v.get('titration_valve'):
                requested = chem_titration.flow_rate(v, v.get('titration_opening', .25)) * sd
                if requested > 1e-6 and titrate(v, requested, quiet=True):
                    active_targets.add(v.get('titration_target'))
                elif requested <= 1e-6 and v['V'] - chem_titration.tip_volume(v) <= 1e-5:
                    v['titration_valve'] = False
        for v in vessels():
            for a in v["anims"]:
                a["t"] += dt
                due = 0.45 if a["k"] == "drip" else 0.3 if a["k"] == "stream" else 0.35 if a["k"] == "gas" else 0.5
                if not a.get("done") and a["t"] >= due:
                    a["done"] = True
                    a["go"]()
            v["anims"] = [a for a in v["anims"] if a["t"] < (0.6 if a["k"] == "stream" else 0.55)]
            if v["pour"]:
                p = v["pour"]
                p["t"] += dt
                want = clamp((p["t"] - 0.35) / 0.7, 0, 1)
                if want > p["done"] and not p["full"]:
                    fr = (want - p["done"]) / ((1 - p["done"]) or 1)
                    if not transfer(v, p["to"], fr):
                        p["full"] = True
                        B.toast(f"{p['to']['name']} 装满了")
                    p["done"] = want
                if p["t"] > 1.4:
                    v["pour"] = None
                    v["lift"] = 0.0
                    v["x"] = near_free(v, v.get("homeX", v["x"]))
                    if p.get("dT"):
                        neutral(p["to"], {"dT": p["dT"], "k": p["k"]})
            for _ in range(n):
                react(v, h)
            after(v, sd, dt)
            if v.get('titration_trace'):
                stable = v['id'] not in active_targets and not v['anims'] and not v['pour']
                pink = v['tot'].get('phth', 0) > .05 and 8.2 <= v['e']['pH'] <= 10.
                v['endpoint_hold'] = min(3600., v.get('endpoint_hold', 0.) + sd) if stable and pink else 0.
        L.draw()
    L.loop(tick)

    # 初始台面
    layout()
    scene(blank)
    W["sel"] = None
    select(objs[0] if objs else None)
    def snapshot_transfer():
        return state_graph.encode(dict(objs=objs,st=st,cnt=cnt,W={k:v for k,v in W.items() if k not in ("ui","uil")},records=records))
    def restore_transfer(snapshot):
        data=state_graph.decode(snapshot)
        objs[:]=data["objs"]
        for v in objs:
            v['titration_valve'] = False  # 恢复记录时先关活塞，避免重开实验后自动流液。
            if v.get('kind') == 'v':
                v['_ek'] = None
                v['e'] = eqm(v['tot'], v['V'], None, v['T'])
        st.clear(); st.update(data["st"])
        cnt.clear(); cnt.update(data["cnt"])
        live_uil=W.get("uil")   # 界面里的日志标签不进快照，恢复时沿用现在这个
        W.clear(); W.update(data["W"])
        W["ui"]=None
        W["uil"]=live_uil
        records[:]=data["records"]
        restored_selection = W.get("sel")
        W["sel"] = None
        if restored_selection is not None:
            select(restored_selection)
        else:
            inspect()
        L.draw()
    B.transfer(snapshot_transfer,restore_transfer)


def _unused():
    _ = (random, PI)
