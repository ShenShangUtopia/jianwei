"""生物工作台的教学近似；模型假设与读数一起返回。"""
import itertools
import math

NAMES={"microscope":"显微镜","plant":"植物细胞","animal":"动物细胞","mitosis":"有丝分裂","meiosis":"减数分裂","cross":"单基因杂交","enzyme":"酶活性","photosynthesis":"光合与呼吸","population":"种群增长","foodweb":"能量流动"}
DEFAULT=dict(temperature=25,pH=7,light=500,co2=.04,time=5,rate=.3,initial=20,capacity=200,magnification=100,efficiency=.15,energy=1000,stage=0,father="Aa",mother="Aa")
NAMES['energy_network']='食物网能量分配'
DEFAULT.update(split=.5,eat_rabbit=.5,eat_mouse=.5)


def calculate(kind,p):
    p={**DEFAULT,**p}
    if kind=='energy_network':
        if not all(0<=p[k]<=1 for k in ('split','eat_rabbit','eat_mouse','efficiency')) or p['energy']<0:
            raise ValueError('能量和分配比例超出模型范围')
        rabbit=p['energy']*p['split']*p['efficiency']
        mouse=p['energy']*(1-p['split'])*p['efficiency']
        hawk=(rabbit*p['eat_rabbit']+mouse*p['eat_mouse'])*p['efficiency']
        remaining_rabbit=rabbit*(1-p['eat_rabbit'])
        remaining_mouse=mouse*(1-p['eat_mouse'])
        lost=max(0.,p['energy']-remaining_rabbit-remaining_mouse-hawk)
        return dict(rows=[['草的输入能量',f"{p['energy']:.5g} kJ"],['鹰获得的能量',f'{hawk:.5g} kJ'],['兔环节净转移能量',f'{rabbit:.5g} kJ'],['鼠环节净转移能量',f'{mouse:.5g} kJ'],['兔剩余',f'{remaining_rabbit:.5g} kJ'],['鼠剩余',f'{remaining_mouse:.5g} kJ'],['未保留在三类消费者的能量',f'{lost:.5g} kJ']],
                    network=[p['energy'],rabbit,mouse,hawk],stocks=[remaining_rabbit,remaining_mouse,hawk],lost=lost,
                    note='草→兔/鼠→鹰的分支食物网，箭头表示能量流向。单次封闭分配：草输入全部按比例分给兔/鼠，每级净转移效率恒定，再按摄取比例分给鹰；剩余计入相应环节存量，其余作为损耗。不含种群动态、分解者或能量再循环，不能反推真实生态系统。')
    if kind=="microscope" and p.get("slide") is not None:
        from . import bio_slide
        record=p["slide"]
        if not bio_slide.valid(record):
            return dict(rows=[["总放大倍数","—"],["视野直径","—"],["装片记录","损坏或版本不支持"]],note="装片记录读不出来，原记录没有被覆盖。")
        o=bio_slide.optics(record["scope"])
        s=record["sample"]
        name=bio_slide.SPECIMENS[s["specimen"]]["short"] if s["specimen"] else "还没有材料"
        return dict(rows=[["总放大倍数",f"{o['total']} ×"],["视野直径",f"{o['field']/1000:.3g} mm"],["分辨极限",f"{o['resolution']:.2f} µm"],["景深",f"{o['dof']:g} µm"],["装片",name+("（在载物台上）" if record["scope"]["loaded"] else "")]],
                    note="视野直径 = 目镜视场数 ÷ 物镜倍数；分辨极限由物镜和光圈的数值孔径决定，放大倍数不等于分辨率。常数来源与假设见「原理」页。")
    if kind=="microscope":
        return dict(rows=[["总放大倍数",f"{p['magnification']:g} ×"],["视野直径",f"{1.8*100/p['magnification']:.3g} mm"]],note="假定100倍时校准视野直径1.8 mm；放大倍数不等于分辨率。")
    if kind in ("plant","animal"):
        names=["细胞膜","细胞质","细胞核","线粒体"]+(["细胞壁","叶绿体","液泡"] if kind=="plant" else ["中心体"])
        return dict(rows=[["结构",name] for name in names],note="结构示意，不按真实大小绘制；植物细胞示意选用叶肉细胞。")
    if kind in ("mitosis","meiosis"):
        from . import bio_division
        c=bio_division.phase(kind,int(p["stage"]))
        each="每个细胞" if c["cells"]>1 else "这个细胞"
        pairs=f"{c['pairs']} 对" if c["pairs"] else "没有"
        if c["tetrads"]:
            pairs+=f"（联会成 {c['tetrads']} 个四分体）"
        return dict(rows=[["时期",c["name"]],["染色体数",str(c["chromosomes"])],["核DNA分子数",str(c["dna"])],["染色单体数",str(c["chromatids"])],["同源染色体",pairs],["染色体组",f"{c['sets']} 个"],["细胞数",f"{c['cells']} 个（以上各数按{each}）"],["全部细胞的核DNA合计",str(c["total_dna"])]],
                    note="假设2n=4，从一个细胞按规则推出每个时期。染色体按着丝粒计数：着丝粒一分开，染色体数加倍，染色单体同时变成 0；核DNA在间期复制时加倍，细胞一分为二时减半。阶段图是计数模型，不模拟纺锤体，无交换、无不分离。")
    if kind=="cross":
        counts={"AA":0,"Aa":0,"aa":0}
        for a,b in itertools.product(p["father"],p["mother"]):
            key="".join(sorted((a,b)))
            counts[key]+=1
        return dict(rows=[[key,f"{value}/4"] for key,value in counts.items()],values=[counts[k]/4 for k in ("AA","Aa","aa")],note="单基因、常染色体、完全显性；配子等概率，无致死或选择。")
    if kind=="enzyme" and p.get("enzyme") is not None:
        from . import bio_enzyme
        try:
            m=bio_enzyme.measure(p)
            values=bio_enzyme.curve(p)
        except ValueError as exc:
            return dict(rows=[["相对活性","—"],["酶实验记录",str(exc)]],note="这张卡片的条件读不出来，原记录没有被覆盖。")
        s=m["settings"]
        e=bio_enzyme.ENZYMES[s["enzyme"]]
        best=values.index(max(values)) if max(values)>1e-6 else None
        rows=[["相对活性（作用期间平均）",f"{m['mean']:.4f}"],["酶 / 底物",f"{e['name']} / {e['substrate']}"]]
        if s["pre_min"]:
            rows.append([f"预处理（{s['pre_T']:g} ℃、pH {s['pre_pH']:g}、{s['pre_min']:g} min）后还有活性的酶",f"{m['before']*100:.3g} %"])
        rows+=[["起始反应速率（相对）",f"{m['initial']:.4f}"],[f"作用 {s['minutes']:g} min 后底物剩余",f"{m['left']*100:.3g} %"],["结束时还有活性的酶",f"{m['after']*100:.3g} %"],
               [f"作用 {s['minutes']:g} min 的表观最适温度","酶已全部失活，没有" if best is None else f"约 {best} ℃"]]
        return dict(rows=rows,values=values,mark=(s["temperature"]/100,m["mean"]),axis=("0 ℃","100 ℃"),
                    note=f"曲线：其他条件不变，各温度下这 {s['minutes']:g} 分钟的平均活性；圆点是当前温度。相对活性 1 = 没处理过的酶在 37 ℃、最适 pH（约 {bio_enzyme.optimum_ph(s['enzyme']):.1f}）下。"
                         "温度升高催化加快，同时酶失活也加快，最高点是两者相抵的结果，作用时间越长越偏低。高温、过酸、过碱造成的失活不可逆：降温或把 pH 调回来不恢复；低温只是变慢，酶还在。"
                         "相对值，没有定标；各酶的数哪些有出处见「原理」页。")
    if kind=="enzyme":
        relative=math.exp(-((p["temperature"]-37)/20)**2-((p["pH"]-7)/2)**2)
        curve=[math.exp(-((t-37)/20)**2-((p["pH"]-7)/2)**2) for t in range(0,81)]
        return dict(rows=[["相对活性",f"{relative:.4f}"]],values=curve,note="旧的通用钟形曲线，假定最适37°C和pH7；不代表任何一种具体的酶，不模拟不可逆变性。在上面的「酶」里选一种具体的酶，可以做预处理、底物和作用时间的实验。")
    if kind=="photosynthesis":
        from . import bio_photo
        try:
            m=bio_photo.measure(p)
        except ValueError as exc:
            return dict(rows=[["总光合","—"],["呼吸","—"],["净光合","—"],["记录",str(exc)]],note="这张卡片的条件读不出来，原记录没有被覆盖。")
        s=m["settings"]
        point=m["compensation"]
        return dict(rows=[["总光合（相对）",f"{m['gross']:.3f}"],["呼吸（相对）",f"{m['respiration']:.3f}"],["净光合 = 总光合 − 呼吸",f"{m['net']:.3f}"],
                          ["光补偿点（相对光强）","这个温度和 CO₂ 下，光再强也补偿不了" if point is None else f"约 {point:.3g}" if point<=2000 else f"约 {point:.3g}（超出光强滑块范围）"],
                          [f"每天光照 {s['day']:g} h，一昼夜净积累",f"{m['daily']:.3f}"]],
                    values=bio_photo.curve(p),mark=(s["light"]/2000,m["net"]),axis=("光强 0","2000"),
                    note="都以 CO₂ 计、相对单位，没有定标。两个过程分开算：呼吸一直在进行，只随温度变；总光合随光强、CO₂、温度变。"
                         "实验里能直接测的只有两个：遮光时的 CO₂ 释放 = 呼吸；光下的 CO₂ 吸收 = 净光合（负数表示在释放）。总光合 = 净光合 + 呼吸，是算出来的。"
                         "曲线：净光合随光强的变化，虚线是 0，圆点是当前光强。假定光下呼吸和黑暗中一样、昼夜同温；不含光呼吸。")
    if kind=="population":
        def number(t):
            return p["capacity"]/(1+(p["capacity"]-p["initial"])/p["initial"]*math.exp(-p["rate"]*t))
        return dict(rows=[["种群数量",f"{number(p['time']):.2f}"],["环境容纳量",f"{p['capacity']:g}"]],values=[number(i*.25) for i in range(81)],note="连续Logistic模型；封闭种群、环境容纳量和内禀增长率恒定。")
    if kind=="foodweb":
        energies=[p["energy"]*p["efficiency"]**i for i in range(3)]
        return dict(rows=[[f"第{i+1}营养级",f"{value:.3g}"] for i,value in enumerate(energies)],values=energies,note="简化为单条三营养级链，每级同一效率；非完整食物网，不计杂食和分解者通路。")
    raise ValueError("未知生物模型")
