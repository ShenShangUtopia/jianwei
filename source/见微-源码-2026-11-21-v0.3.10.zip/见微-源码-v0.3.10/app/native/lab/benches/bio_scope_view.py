"""目镜视野与装片俯视图的绘制。颜色是标本和染色剂自己的颜色，不跟界面皮肤走。

render(record, px, dpr) 返回一张方形 QImage：圆形视野、倒像、按物镜景深逐层虚化、按光圈和物镜算亮度。
每一层（组织 / 气泡 / 灰尘 / 裂纹）单独画成透过率，再各按自己的离焦量虚化后相乘。
"""
from __future__ import annotations

import math
import random

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPolygonF, QRadialGradient

from . import bio_slide as M
from .bio_tissue import build

LAMP = (255, 250, 238)
HALF = M.COVER / 2
TISSUE_DEPTH = 30.0     # 表皮一层细胞的厚度（µm，假设）：垂直的细胞壁在这个范围内都算在焦


def _mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def _col(rgb, alpha=1.0) -> QColor:
    c = QColor(int(rgb[0]), int(rgb[1]), int(rgb[2]))
    c.setAlphaF(max(0.0, min(1.0, alpha)))
    return c


def _layer(n: int) -> QImage:
    img = QImage(n, n, QImage.Format.Format_RGB32)
    img.fill(0xFFFFFFFF)
    return img


def _blur(img: QImage, radius: float) -> QImage:
    """缩小再放大的近似虚化；radius 是像素。"""
    if radius < 0.7:
        return img
    n = img.width()
    small = max(2, int(n / max(2.0, radius * 1.6)))
    mode = Qt.TransformationMode.SmoothTransformation
    keep = Qt.AspectRatioMode.IgnoreAspectRatio
    a = img.scaled(small, small, keep, mode)
    if small * 4 < n:
        a = a.scaled(small * 4, small * 4, keep, mode)
    return a.scaled(n, n, keep, mode)


def _world(img: QImage, scope: dict, scale: float) -> QPainter:
    """装片坐标（µm）→ 图像；像是倒的（转 180°）。"""
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    n = img.width()
    p.translate(n / 2, n / 2)
    p.scale(-scale, -scale)
    p.translate(-scope["x"], -scope["y"])
    return p


def _blur_px(scope: dict, o: dict, scale: float, plane: float, depth: float = 0.0) -> float:
    f = M.focus_state(scope, plane)
    excess = max(0.0, abs(f["defocus"]) - o["dof"] / 2 - depth / 2)
    geo = 2 * excess * math.tan(math.asin(o["na"]))
    return (geo / 2 + o["resolution"] * 0.4) * scale


# ---------------------------------------------------------------- 组织
def _strip_style(s: dict, i: int, gain: float) -> dict:
    wet = s["bath"][i] is not None
    u = M.stain_at(s, i)
    if not wet:
        return dict(wet=False, u=0.0, wall=_col((46, 40, 32), 0.92), fill=_col((150, 140, 120), 0.55),
                    nuc=None, nuc_rgb=(60, 50, 40), nuc_a=0.0, ww=2.0)
    return dict(wet=True, u=u,
                wall=_col(_mix((108, 114, 108), (138, 90, 16), u), min(0.95, 0.34 * gain + (0.86 - 0.34 * gain) * u)),
                fill=_col(_mix((255, 255, 255), (252, 238, 184), u), 1.0) if u > 0.03 else None,
                nuc_rgb=_mix((140, 146, 140), (146, 84, 12), u), nuc_a=min(0.95, 0.26 * gain + (0.92 - 0.26 * gain) * u), ww=1.0)


def _protoplast(c, f: float) -> QPainterPath:
    """失水后的原生质体：先从两端和拐角离开细胞壁，再整体缩小。f 是相对清水平衡时的体积比。"""
    kw = max(0.55, min(1.0, 0.45 + 0.6 * f))        # 先贴着两条长壁，从两端和拐角缩回来
    kl = f ** 0.8 / kw
    inner_l, inner_w = c.length - 6, c.width - 12
    length, width = max(12.0, inner_l * kl), max(8.0, inner_w * kw)
    x = c.cx - length / 2 + (inner_l - length) / 2 * c.bias
    y = c.cy - width / 2 + (inner_w - width) / 2 * (1 if c.gain > 1 else -1) * 0.9
    r = min(width / 2, 4 + (1 - f) * width * 1.5)
    path = QPainterPath()
    path.addRoundedRect(QRectF(x, y, length, width), r, r)
    return path


def _paint_tissue(p: QPainter, record: dict, o: dict, scale: float, gain: float, defocus: float, copy: int = 0) -> None:
    s, scope = record["sample"], record["scope"]
    tissue = build(s["specimen"], s["seed"] + copy * 101)
    rot = math.radians(s["rot"] + copy * 9)
    ax, ay = s["at"][0] + copy * 130, s["at"][1] - copy * 90
    cos, sin = math.cos(rot), math.sin(rot)
    dx, dy = scope["x"] - ax, scope["y"] - ay
    lx, ly = dx * cos + dy * sin, -dx * sin + dy * cos
    radius = o["field"] / 2 * 1.05
    p.save()
    p.translate(ax, ay)
    p.rotate(math.degrees(rot))
    where = (ax, cos, sin)
    _cells(p, s, tissue, o, scale, gain, defocus, lx, ly, radius, where)
    if not s["spread"] and M.SPECIMENS[s["specimen"]]["layers"] == 1 and copy == 0:
        _paint_fold(p, s, tissue, o, scale, gain, defocus, lx, ly, radius, where)
    p.restore()


def _cells(p, s, tissue, o, scale, gain, defocus, lx, ly, radius, where) -> None:
    """在材料坐标里画 (lx, ly) 周围 radius 以内的细胞。where = (材料中心 x, cos, sin) 用来查细胞泡在哪一带液体里。"""
    ax, cos, sin = where
    kind = M.SPECIMENS[s["specimen"]]
    styles = [_strip_style(s, i, gain) for i in range(M.STRIPS)]
    fine = scale >= 0.9
    px = 1.0 / scale
    theta = math.tan(math.asin(o["na"]))
    purple = kind["purple"]
    living = s["specimen"] in ("onion_inner", "onion_outer")
    for c in tissue.visible(lx, ly, radius):
        i = M.strip_of(ax + c.cx * cos - c.cy * sin)
        st = styles[i]
        if c.qpoly is None:
            c.qpoly = QPolygonF([QPointF(a, b) for a, b in c.poly])
        nx, ny, rx, ry, na, nz = c.nuc
        shrunk = sap = None
        if living and st["wet"]:
            f = M.cell_volume(s["vol"][i], c.gain) / M.V_WATER
            if f < 0.985:
                shrunk = _protoplast(c, f)
                b = shrunk.boundingRect()
                nx = b.center().x() + (nx - c.cx) * b.width() / c.length
                ny = b.center().y() + (ny - c.cy) * b.height() / c.width
            if purple:
                leak = max(0.0, min(1.0, s["damage"][i] * c.hard - 1.0))
                sap = _col(_mix((126, 36, 120), (170, 150, 165), leak), min(0.93, 0.50 * c.pig / f) * (1 - 0.75 * leak))
        p.setPen(QPen(st["wall"], max(2.2 * st["ww"], px * 0.9 * st["ww"])))
        if sap is not None and shrunk is None:
            p.setBrush(sap)                     # 紫色的是液泡里的细胞液，充满整个细胞
        else:
            p.setBrush(QBrush(st["fill"]) if st["fill"] is not None else Qt.BrushStyle.NoBrush)
        p.drawPolygon(c.qpoly)
        if not st["wet"]:
            continue
        if living:
            if sap is not None and shrunk is not None:
                p.setPen(QPen(_col((70, 24, 70), 0.5), max(0.8, px * 0.7)))
                p.setBrush(sap)
                p.drawPath(shrunk)
            elif shrunk is not None:
                p.setPen(QPen(_col((110, 116, 110), 0.55 * gain), max(1.0, px * 0.8)))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawPath(shrunk)
        if rx * scale < 0.5:
            continue
        soft = 2 * max(0.0, abs(defocus - nz) - o["dof"] / 2) * theta       # 细胞核自己的弥散斑直径 µm
        if soft > 70:
            continue
        p.save()
        p.translate(nx, ny)
        p.rotate(na)
        p.setPen(Qt.PenStyle.NoPen)
        if soft * scale > 1.2:
            grow = soft / 2
            a = st["nuc_a"] * (rx * ry) / ((rx + grow) * (ry + grow))
            g = QRadialGradient(QPointF(0, 0), rx + grow)
            g.setColorAt(0, _col(st["nuc_rgb"], a))
            g.setColorAt(max(0.0, (rx - grow) / (rx + grow)), _col(st["nuc_rgb"], a))
            g.setColorAt(1, _col(st["nuc_rgb"], 0))
            p.scale(1, (ry + grow) / (rx + grow))
            p.setBrush(QBrush(g))
            p.drawEllipse(QPointF(0, 0), rx + grow, rx + grow)
        else:
            p.setBrush(_col(st["nuc_rgb"], st["nuc_a"]))
            p.drawEllipse(QPointF(0, 0), rx, ry)
            if fine:
                p.setPen(QPen(_col(st["nuc_rgb"], min(1.0, st["nuc_a"] + 0.25)), max(0.7, px * 0.7)))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QPointF(0, 0), rx, ry)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(_col(_mix(st["nuc_rgb"], (40, 26, 8), 0.5), min(1.0, st["nuc_a"] + 0.2)))
                for ox, oy, r in c.nucleoli:
                    p.drawEllipse(QPointF(ox, oy), r, r)
        p.restore()
        if fine and shrunk is None:
            if abs(defocus - nz) < 6:      # 穿过液泡的细胞质丝：只在细胞核那一层附近看得到
                p.setPen(QPen(_col(st["nuc_rgb"], 0.20 * gain + 0.12 * st["u"]), max(0.8, px * 0.7)))
                for sx, sy in c.strands:
                    p.drawLine(QPointF(nx, ny), QPointF(nx + (sx - nx) * 0.94, ny + (sy - ny) * 0.94))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_col(st["nuc_rgb"], 0.34 * gain + 0.2 * st["u"]))
            for gx, gy, gz in c.grains:    # 细胞质里的颗粒：焦面扫过才出现
                if abs(defocus - gz) < 2.2:
                    p.drawEllipse(QPointF(gx, gy), 0.8, 0.8)


FOLD_SHIFT, FOLD_TURN = (150.0, -210.0), 6.0


def _paint_fold(p, s, tissue, o, scale, gain, defocus, lx, ly, radius, where) -> None:
    """没展平：一条斜带里材料折过来叠了两层。"""
    a, c, w = tissue.fold
    x0, x1 = -tissue.half_w - 200, tissue.half_w + 200
    band = QPainterPath()
    band.addPolygon(QPolygonF([QPointF(x0, a * x0 + c), QPointF(x1, a * x1 + c), QPointF(x1, a * x1 + c + w), QPointF(x0, a * x0 + c + w)]))
    band.closeSubpath()
    p.save()
    p.setClipPath(band, Qt.ClipOperation.IntersectClip)
    p.fillPath(band, _col((205, 200, 186), 0.5))
    p.translate(*FOLD_SHIFT)
    p.rotate(FOLD_TURN)
    t = math.radians(FOLD_TURN)
    ux, uy = lx - FOLD_SHIFT[0], ly - FOLD_SHIFT[1]
    _cells(p, s, build(s["specimen"], s["seed"] + 101), o, scale, gain, defocus,
           ux * math.cos(t) + uy * math.sin(t), -ux * math.sin(t) + uy * math.cos(t), radius, where)
    p.restore()
    p.setPen(QPen(_col((70, 62, 50), 0.7), max(5.0, 2 / scale)))
    p.drawLine(QPointF(x0, a * x0 + c), QPointF(x1, a * x1 + c))
    p.setPen(QPen(_col((70, 62, 50), 0.45), max(3.0, 1.4 / scale)))
    p.drawLine(QPointF(x0, a * x0 + c + w), QPointF(x1, a * x1 + c + w))

def _paint_bath(p: QPainter, s: dict) -> None:
    """盖玻片下带颜色的液体（碘液）。"""
    w = M.COVER / M.STRIPS
    p.setPen(Qt.PenStyle.NoPen)
    tint = (246, 226, 156)
    for i, liquid in enumerate(s["bath"]):
        if liquid != "iodine":
            continue
        x = -HALF + i * w
        p.setBrush(_col(tint, 0.38))
        p.drawRect(QRectF(x - 1, -HALF, w + 2, M.COVER))
        if i + 1 < M.STRIPS and s["bath"][i + 1] != "iodine":       # 前沿不是一条直线，是渐渐淡出去的
            g = QLinearGradient(QPointF(x + w, 0), QPointF(x + w * 1.7, 0))
            g.setColorAt(0, _col(tint, 0.38))
            g.setColorAt(1, _col(tint, 0))
            p.setBrush(QBrush(g))
            p.drawRect(QRectF(x + w, -HALF, w * 0.7, M.COVER))


# ---------------------------------------------------------------- 气泡、灰尘、裂纹
def _paint_bubbles(p: QPainter, s: dict, scale: float) -> None:
    p.setPen(Qt.PenStyle.NoPen)
    for x, y, r in s["bubbles"]:
        g = QRadialGradient(QPointF(x, y), r)
        rim = min(0.3, 0.06 + 14 / r)
        g.setColorAt(0, _col((255, 255, 255)))
        g.setColorAt(max(0.0, 1 - rim * 1.9), _col((250, 250, 250)))
        g.setColorAt(1 - rim * 1.2, _col((120, 120, 120)))
        g.setColorAt(1 - rim * 0.55, _col((14, 14, 14)))
        g.setColorAt(1 - rim * 0.12, _col((30, 30, 30)))
        g.setColorAt(1, _col((150, 150, 150)))
        p.setBrush(QBrush(g))
        p.drawEllipse(QPointF(x, y), r, r)
    if s["cover"]:
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(_col((70, 80, 80), 0.8), max(8.0, 1.5 / scale)))
        p.drawRect(QRectF(-HALF, -HALF, M.COVER, M.COVER))


def _wash_bubbles(p: QPainter, s: dict) -> None:
    """气泡里没有水，下面的细胞几乎看不出来。"""
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_col((255, 255, 255), 0.8))
    for x, y, r in s["bubbles"]:
        p.drawEllipse(QPointF(x, y), r * 0.93, r * 0.93)


def _paint_dust(p: QPainter, seed: int, scale: float) -> None:
    rng = random.Random(seed)
    p.setPen(Qt.PenStyle.NoPen)
    for _ in range(230):
        x, y, r = rng.uniform(-HALF, HALF), rng.uniform(-HALF, HALF), rng.uniform(4, 20)
        p.setBrush(_col((60, 55, 48), rng.uniform(0.45, 0.9)))
        p.drawEllipse(QPointF(x, y), r, r * rng.uniform(0.5, 1.0))
    p.setBrush(Qt.BrushStyle.NoBrush)
    for _ in range(46):
        x, y = rng.uniform(-HALF, HALF), rng.uniform(-HALF, HALF)
        ang, length = rng.uniform(0, math.tau), rng.uniform(300, 1100)
        ex, ey = x + math.cos(ang) * length, y + math.sin(ang) * length
        path = QPainterPath(QPointF(x, y))
        path.cubicTo(x + rng.uniform(-300, 300), y + rng.uniform(-300, 300), ex + rng.uniform(-300, 300), ey + rng.uniform(-300, 300), ex, ey)
        p.setPen(QPen(_col((70, 66, 60), rng.uniform(0.5, 0.85)), max(rng.uniform(6, 13), 0.8 / scale)))
        p.drawPath(path)


def _paint_crack(p: QPainter, s: dict, scale: float) -> None:
    cx, cy = s["crack"]
    rng = random.Random(s["seed"] * 7 + 3)
    p.setBrush(Qt.BrushStyle.NoBrush)
    for k in range(5):
        ang = k * math.tau / 5 + rng.uniform(-0.4, 0.4)
        x, y = cx, cy
        path = QPainterPath(QPointF(x, y))
        for _ in range(7):
            ang += rng.uniform(-0.12, 0.12)      # 玻璃裂纹几乎是直的，偶尔折一下
            step = rng.uniform(500, 1500)
            x, y = x + math.cos(ang) * step, y + math.sin(ang) * step
            path.lineTo(x, y)
        w = max(3.0, 1.1 / scale)
        p.setPen(QPen(_col((16, 16, 16), 0.92), w))
        p.drawPath(path)
        p.save()
        p.translate(w * 0.9, w * 0.9)
        p.setPen(QPen(_col((120, 120, 120), 0.5), w * 0.6))
        p.drawPath(path)
        p.restore()


# ---------------------------------------------------------------- 合成
_noise = None


def _grain():
    """极淡的颗粒感，免得视野像矢量图一样干净。固定种子，只做一次。"""
    global _noise
    if _noise is None:
        from PySide6.QtGui import QPixmap
        rng = random.Random(20261113)
        img = QImage(96, 96, QImage.Format.Format_ARGB32)
        for y in range(96):
            for x in range(96):
                v = rng.random()
                img.setPixelColor(x, y, QColor(0, 0, 0, int(22 * v * v)) if v > 0.5 else QColor(255, 255, 255, int(26 * (1 - v) ** 2)))
        _noise = QPixmap.fromImage(img)
    return _noise


def exposure(o: dict) -> tuple:
    """(视野亮度 0–1, 过曝冲淡 0–0.5)。"""
    e = o["brightness"]
    return min(1.0, 0.22 + 0.78 * math.sqrt(min(1.0, e))), min(0.5, max(0.0, e - 1.3) * 0.35)


def contrast_gain(o: dict) -> float:
    """光圈比物镜孔径小时，无色透明的结构反差更大（分辨率同时变差，见 optics）。"""
    return 1 + 1.2 * max(0.0, 1 - o["na_ill"] / o["na"])


def render(record: dict, px: int, dpr: float = 1.0) -> QImage:
    s, scope = record["sample"], record["scope"]
    n = max(32, int(round(px * dpr)))
    o = M.optics(scope)
    scale = n / o["field"]
    level, glare = exposure(o)
    gain = contrast_gain(o)
    layers = []
    if scope["loaded"]:
        if s["specimen"]:
            copies = M.SPECIMENS[s["specimen"]]["layers"]
            for k in range(copies):
                plane = -k * 60.0
                img = _layer(n)
                p = _world(img, scope, scale)
                if k == 0:
                    _paint_bath(p, s)
                _paint_tissue(p, record, o, scale, gain, M.focus_state(scope, plane)["defocus"], copy=k)
                if copies > 1:
                    p.resetTransform()
                    p.fillRect(0, 0, n, n, _col((196, 188, 160), 0.30))
                if k == 0 and s["bubbles"]:
                    p.end()
                    p = _world(img, scope, scale)
                    _wash_bubbles(p, s)
                p.end()
                layers.append(_blur(img, _blur_px(scope, o, scale, plane, TISSUE_DEPTH)))
        elif any(b == "iodine" for b in s["bath"]):
            img = _layer(n)
            p = _world(img, scope, scale)
            _paint_bath(p, s)
            p.end()
            layers.append(img)
        if s["bubbles"] or s["cover"]:
            img = _layer(n)
            p = _world(img, scope, scale)
            _paint_bubbles(p, s, scale)
            p.end()
            layers.append(_blur(img, _blur_px(scope, o, scale, 15.0)))
        for dirty, seed, plane in ((not s["slide_clean"], s["seed"] * 3 + 1, -TISSUE_DEPTH / 2 - 5), (not s["cover_clean"] and bool(s["cover"]), s["seed"] * 3 + 2, 190.0)):
            if dirty:
                img = _layer(n)
                p = _world(img, scope, scale)
                _paint_dust(p, seed, scale)
                p.end()
                layers.append(_blur(img, _blur_px(scope, o, scale, plane)))
        if s["crack"] is not None:
            img = _layer(n)
            p = _world(img, scope, scale)
            _paint_crack(p, s, scale)
            p.end()
            layers.append(_blur(img, _blur_px(scope, o, scale, 100.0)))
    out = QImage(n, n, QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(0)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.fillRect(0, 0, n, n, _col(tuple(c * level for c in LAMP)))
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
    for img in layers:
        p.drawImage(0, 0, img)
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceOver)
    if glare > 0:
        p.fillRect(0, 0, n, n, _col((255, 255, 255), glare))
    r = n / 2 - 1
    g = QRadialGradient(QPointF(n / 2, n / 2), r)
    g.setColorAt(0, _col((0, 0, 0), 0))
    g.setColorAt(0.80, _col((0, 0, 0), 0))
    g.setColorAt(1, _col((0, 0, 0), 0.30))
    p.fillRect(0, 0, n, n, QBrush(g))
    p.setOpacity(0.35)
    p.drawTiledPixmap(0, 0, n, n, _grain())
    p.setOpacity(1.0)
    mask = QPainterPath()
    mask.addRect(QRectF(0, 0, n, n))
    mask.addEllipse(QPointF(n / 2, n / 2), r, r)
    p.fillPath(mask, _col((8, 8, 8)))
    p.end()
    out.setDevicePixelRatio(dpr)
    return out


def stamp(record: dict) -> tuple:
    """视野会不会变的指纹：缩略图缓存用。"""
    s, m = record["sample"], record["scope"]
    return (s["seed"], s["specimen"], s["spread"], s["cover"], len(s["bubbles"]), s["slide_clean"], s["cover_clean"],
            s["crack"] is not None, tuple(s["bath"]), tuple(round(d / 5) for d in s["dye"]), tuple(round(v, 2) for v in s["vol"]),
            tuple(round(d, 1) for d in s["damage"]), m["loaded"], m["objective"], m["eyepiece"], m["aperture"], m["mirror"],
            round(m["z"], 1), round(m["x"]), round(m["y"]))


# ---------------------------------------------------------------- 装片俯视图
def paint_slide(p: QPainter, rect: QRectF, s: dict, wicking: bool = False) -> float:
    """把载玻片画进 rect（俯视）。返回 像素 / µm，调用方可以据此换算鼠标位置。"""
    k = min(rect.width() / M.SLIDE_W, rect.height() / M.SLIDE_H)
    w, h = M.SLIDE_W * k, M.SLIDE_H * k
    box = QRectF(rect.center().x() - w / 2, rect.center().y() - h / 2, w, h)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setPen(QPen(_col((120, 150, 160), 0.9), 1.2))
    p.setBrush(_col((226, 240, 244), 0.75))
    p.drawRoundedRect(box, 2, 2)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_col((255, 255, 255), 0.75))
    p.drawRect(QRectF(box.x() + 1.5, box.y() + 1.5, w * 0.19, h - 3))      # 磨砂标签区
    if not s["slide_clean"]:
        rng = random.Random(s["seed"] * 3 + 1)
        p.setBrush(_col((90, 84, 74), 0.5))
        for _ in range(26):
            p.drawEllipse(QPointF(box.x() + w * rng.uniform(0.22, 0.97), box.y() + h * rng.uniform(0.06, 0.94)), 0.9, 0.9)
    c = box.center()
    p.translate(c)
    p.scale(k, k)
    if s["water"] and not s["cover"]:
        r = 3600.0 * math.sqrt(s["water"])
        iodine = any(b == "iodine" for b in s["bath"])
        p.setPen(QPen(_col((150, 120, 40) if iodine else (90, 150, 190), 0.8), 1.2 / k))
        p.setBrush(_col((226, 190, 90) if iodine else (170, 215, 240), 0.55))
        p.drawEllipse(QPointF(0, 0), r * 1.12, r * 0.9)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_col((255, 255, 255), 0.7))
        p.drawEllipse(QPointF(-r * 0.4, -r * 0.35), r * 0.22, r * 0.12)
    if s["cover"]:
        wstrip = M.COVER / M.STRIPS
        p.setPen(Qt.PenStyle.NoPen)
        for i, liquid in enumerate(s["bath"]):
            if liquid is None:
                continue
            rgb = (226, 190, 90) if liquid == "iodine" else (196, 214, 238) if liquid.startswith("sucrose") else (188, 222, 240)
            p.setBrush(_col(rgb, 0.6))
            p.drawRect(QRectF(-HALF + i * wstrip, -HALF, wstrip + 20, M.COVER))
        if s["fill"] > 1.3:
            p.setBrush(_col((170, 215, 240), 0.45))
            p.drawRoundedRect(QRectF(-HALF - 1800, -HALF - 1500, M.COVER + 3600, M.COVER + 3000), 2500, 2500)
    if s["specimen"]:
        tissue = build(s["specimen"], s["seed"])
        kind = M.SPECIMENS[s["specimen"]]
        p.save()
        p.translate(s["at"][0], s["at"][1])
        p.rotate(s["rot"])
        u = max(M.stain_at(s, i) for i in range(M.STRIPS))
        rgb = (150, 70, 140) if kind["purple"] else _mix((236, 238, 226), (214, 170, 80), u)
        if kind["layers"] > 1:
            rgb = (226, 226, 200)
        p.setPen(QPen(_col(_mix(rgb, (60, 60, 50), 0.45), 0.9), 1.1 / k))
        p.setBrush(_col(rgb, 0.85 if kind["purple"] or kind["layers"] > 1 else 0.7))
        blob = QPainterPath()
        blob.addRoundedRect(QRectF(-tissue.half_w, -tissue.half_h, tissue.half_w * 2, tissue.half_h * 2), 900, 900)
        p.drawPath(blob)
        if not s["spread"] and kind["layers"] == 1:
            a, c0, wd = tissue.fold
            p.setPen(QPen(_col((80, 70, 60), 0.8), 1.4 / k))
            p.drawLine(QPointF(-tissue.half_w, -a * tissue.half_w + c0), QPointF(tissue.half_w, a * tissue.half_w + c0))
        p.restore()
    if s["cover"]:
        p.setPen(QPen(_col((70, 110, 130), 0.95), 1.3 / k))
        p.setBrush(_col((255, 255, 255), 0.18))
        p.drawRect(QRectF(-HALF, -HALF, M.COVER, M.COVER))
        p.setPen(QPen(_col((255, 255, 255), 0.85), 1.6 / k))
        p.drawLine(QPointF(-HALF + 900, -HALF + 2600), QPointF(-HALF + 2600, -HALF + 900))
        p.setPen(QPen(_col((40, 40, 40), 0.85), 1.0 / k))
        p.setBrush(_col((255, 255, 255), 0.9))
        for x, y, r in s["bubbles"]:
            p.drawEllipse(QPointF(x, y), max(r, 0.9 / k), max(r, 0.9 / k))
        e = s["edge"]
        if e:
            rgb = (190, 130, 30) if e["liquid"] == "iodine" else (120, 150, 210) if e["liquid"].startswith("sucrose") else (90, 160, 210)
            p.setPen(QPen(_col(_mix(rgb, (40, 40, 40), 0.4)), 1.0 / k))
            p.setBrush(_col(rgb, 0.8))
            r = 1900 * (1 - 0.6 * e["drawn"])
            p.drawEllipse(QPointF(-HALF - r * 0.7, 0), r, r * 1.15)
        if s["crack"] is not None:
            _paint_crack(p, s, k)
        if wicking:
            p.setPen(QPen(_col((150, 140, 120)), 1.0 / k))
            p.setBrush(_col((250, 246, 232), 0.95))
            p.drawRect(QRectF(HALF - 300, -5200, 9000, 10400))
    p.restore()
    return k
