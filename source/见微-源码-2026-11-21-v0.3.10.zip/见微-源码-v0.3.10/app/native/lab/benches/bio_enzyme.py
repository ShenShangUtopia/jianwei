"""酶促反应的教学模型：按具体的酶区分最适条件；高温、过酸、过碱造成的失活不可逆。

纯数据，不依赖 Qt。三件事分开算：
  催化本身   随温度升高而加快（Arrhenius），随 pH 呈钟形（活性中心两个基团的解离）
  酶的失活   一级反应，速率随温度、随偏离稳定 pH 范围急剧增大；失活的酶不再回来
  底物消耗   米氏方程，对变化着的酶量积分
所以「最适温度」不是写死的数：它是「升温加快」和「高温失活」在一段作用时间里相抵的结果。
"""
import math

R = 8.314
EA = 50e3          # 催化的活化能 J/mol（约等于每升 10 ℃ 快到 1.9 倍）
ED = 400e3         # 热失活的活化能 J/mol
REF = 37.0         # 相对活性 1 的参考温度
HALF = 10.0        # t10 的定义：在这个温度下保温 HALF 分钟，酶剩一半
VMAX = 0.5         # 参考条件、酶量 1、底物饱和时，每分钟消耗的底物（以 Km 为单位）
PH_SLOPE = 2.0     # 每偏出稳定范围 1 个 pH 单位，失活速率 ×100
LIMITS = dict(temperature=(0, 100), pH=(0, 14), substrate=(0, 50), dose=(0, 5), minutes=(0, 240),
              pre_T=(0, 100), pre_pH=(0, 14), pre_min=(0, 240))

# pk：活性中心两个基团的 pKa，最适 pH 是两者的中点；stable：超出就明显失活的 pH 范围；
# t10：保温 10 分钟失活一半的温度。哪些数有出处见 SOURCES / ASSUMPTIONS。
ENZYMES = {
    "amylase": dict(name="唾液淀粉酶", substrate="淀粉", pk=(5.6, 8.0), stable=(3.5, 10.5), t10=42.0),
    "pepsin": dict(name="胃蛋白酶", substrate="蛋白质", pk=(0.5, 4.2), stable=(-2.0, 7.0), t10=42.0),
    "trypsin": dict(name="胰蛋白酶", substrate="蛋白质", pk=(6.9, 9.6), stable=(2.0, 11.0), t10=42.0),
    "catalase": dict(name="过氧化氢酶", substrate="过氧化氢", pk=(4.5, 9.5), stable=(3.5, 11.0), t10=42.0),
    "malt": dict(name="麦芽淀粉酶（植物）", substrate="淀粉", pk=(3.7, 6.1), stable=(2.5, 8.5), t10=52.0),
}

SOURCES = [
    ("最适 pH：胃蛋白酶 1.5–1.6、胰蛋白酶 7.8–8.7、过氧化氢酶 7.0、胰淀粉酶 6.7–7.0、麦芽淀粉酶 4.6–5.2；极端 pH 一般使酶完全失去活性",
     "Worthington Biochemical, Introduction to Enzymes: Effects of pH, Table II",
     "https://www.worthington-biochem.com/tools-resources/intro-to-enzymes/effects-ph"),
    ("胃蛋白酶：pH 1.5 时约为最大活性的 90%，pH 4.5 时约 35%；pH 7 以上不可逆变性",
     "Worthington Enzyme Manual: Pepsin",
     "https://www.worthington-biochem.com/products/pepsin/manual"),
]

ASSUMPTIONS = [
    "唾液淀粉酶的最适 pH 取 6.8（教材数值）；核对过的来源只列了胰淀粉酶 6.7–7.0。",
    "各酶 pH 曲线的宽度（两个 pKa）：胃蛋白酶按上面的 90% / 35% 两个数拟合，最高点落在 pH 2 附近、1.5–3 都在九成以上；其余是假设。",
    "除胃蛋白酶的 pH 7 之外，各酶「超出就失活」的 pH 范围是假设；每偏出 1 个 pH 单位失活快 100 倍也是假设。",
    "热失活：一级反应，活化能 400 kJ/mol；「保温 10 分钟剩一半」的温度取 42 ℃（动物来源）和 52 ℃（麦芽），是按教材的最适温度（动物 35–40 ℃、植物 40–50 ℃）倒推的，不是实测的稳定性。",
    "催化的活化能 50 kJ/mol；米氏常数和最大速率没有定标，底物浓度以 Km 为单位，速率和活性都是相对值。",
    "「升温加快 + 高温失活」是经典模型（Peterson, Daniel, Danson & Eisenthal 2007, Biochem. J. 402:331 对它有讨论）；这篇只读到检索摘要，原文页面没连上。",
    "没有模拟：产物抑制、辅因子、底物对酶的保护、失活的部分可逆。",
]


def optimum_ph(enzyme):
    a, b = ENZYMES[enzyme]["pk"]
    return (a + b) / 2


def fresh(enzyme="amylase"):
    """一张新的酶卡片：反应条件放在这种酶的最适 pH 上，不做预处理。"""
    if enzyme not in ENZYMES:
        raise ValueError("未知的酶")
    best = round(optimum_ph(enzyme), 1)
    return dict(enzyme=enzyme, temperature=37, pH=best, substrate=5.0, dose=1.0, minutes=10, pre_T=80, pre_pH=best, pre_min=0)


def settings(p):
    """补齐缺的键并检查范围；记录有问题就抛 ValueError，不替用户改数。"""
    if p.get("enzyme") not in ENZYMES:
        raise ValueError("未知的酶")
    full = {**fresh(p["enzyme"]), **{k: p[k] for k in LIMITS if k in p}}
    for key, (lo, hi) in LIMITS.items():
        value = full[key]
        if type(value) not in (int, float) or not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError("酶实验的条件超出模型范围")
    return full


def _kelvin(t):
    return t + 273.15


def catalysis(temperature):
    """催化速率的温度因子，37 ℃ 为 1；只升不降——降下来的是酶的数量，不是这一项。"""
    return math.exp(-EA / R * (1 / _kelvin(temperature) - 1 / _kelvin(REF)))


def ph_factor(enzyme, ph):
    a, b = ENZYMES[enzyme]["pk"]

    def shape(x):
        return 1 / (1 + 10 ** (a - x) + 10 ** (x - b))
    return shape(ph) / shape((a + b) / 2)


def loss_rate(enzyme, temperature, ph):
    """失活的一级速率常数（每分钟）：热失活 + 偏出稳定 pH 范围。"""
    e = ENZYMES[enzyme]
    heat = math.log(2) / HALF * math.exp(-ED / R * (1 / _kelvin(temperature) - 1 / _kelvin(e["t10"])))
    lo, hi = e["stable"]
    return heat + 10 ** (PH_SLOPE * (ph - hi)) + 10 ** (PH_SLOPE * (lo - ph))


def survive(enzyme, temperature, ph, minutes):
    """在这个条件下放 minutes 分钟后，还有活性的酶占多少。"""
    return math.exp(-loss_rate(enzyme, temperature, ph) * minutes)


def _left(start, used):
    """米氏方程积分：S + ln S = S0 + ln S0 − used，解 S。"""
    if start <= 0:
        return 0.0
    c = start + math.log(start) - used
    x = c if c < 1 else math.log(c)
    for _ in range(60):
        step = (math.exp(x) + x - c) / (math.exp(x) + 1)
        x -= step
        if abs(step) < 1e-13:
            break
    return min(start, math.exp(x))


def measure(p):
    """做一次实验：先预处理，再在反应条件下作用 minutes 分钟。"""
    s = settings(p)
    enzyme = s["enzyme"]
    before = survive(enzyme, s["pre_T"], s["pre_pH"], s["pre_min"])
    unit = catalysis(s["temperature"]) * ph_factor(enzyme, s["pH"])      # 每份有活性的酶的催化能力
    x = loss_rate(enzyme, s["temperature"], s["pH"]) * s["minutes"]
    kept = -math.expm1(-x) / x if x > 1e-12 else 1.0                     # 作用期间平均还剩多少
    mean = s["dose"] * before * unit * kept
    start = s["substrate"]
    left = _left(start, VMAX * mean * s["minutes"])
    return dict(settings=s, before=before, after=before * math.exp(-x),
                initial=s["dose"] * before * unit * start / (1 + start),
                mean=mean, left=left / start if start else 0.0, used=start - left)


def curve(p):
    """其他条件不变，各温度（0–100 ℃）下这段作用时间的平均活性。"""
    return [measure({**p, "temperature": t})["mean"] for t in range(101)]


def apparent_optimum(p):
    values = curve(p)
    top = max(values)
    return values.index(top) if top > 1e-6 else None
