"""洋葱鳞片叶表皮的程序化组织：一排排长形细胞，同一个种子永远得到同一块材料。

纯数据、不依赖 Qt。长度单位 µm，原点在材料中心，细胞长轴沿 x。
尺寸量级是课堂测量的常见值（长约 0.2–0.4 mm、宽约 0.05–0.08 mm），不是文献定标数据。
"""
from __future__ import annotations

import math
import random

_cache: dict = {}


class Cell:
    __slots__ = ("poly", "box", "cx", "cy", "length", "width", "nuc", "nucleoli", "strands", "grains",
                 "gain", "hard", "pig", "bias", "qpoly")


class Row:
    __slots__ = ("y0", "y1", "cells")


class Tissue:
    def __init__(self, kind: str, seed: int):
        self.kind, self.seed = kind, seed
        self.half_w, self.half_h = 2500.0, 1900.0
        self.rows: list[Row] = []
        self.count = 0
        self.fold = None      # 没展平时的褶皱带（材料坐标里的一条斜带）
        self._build()

    def _build(self) -> None:
        rng = random.Random(self.seed * 9176 + sum(map(ord, self.kind)))
        outer = self.kind == "onion_outer"
        hw, hh = self.half_w, self.half_h
        lobes = (rng.uniform(0, math.tau), rng.uniform(0, math.tau))
        bounds = []
        y = -hh - 80
        while y < hh + 80:
            bounds.append((y, rng.uniform(3, 7), rng.uniform(600, 1300), rng.uniform(0, math.tau)))
            y += rng.uniform(46, 70) if outer else rng.uniform(52, 84)

        def edge(b, x):
            return b[0] + b[1] * math.sin(x * math.tau / b[2] + b[3]) + 0.4 * b[1] * math.sin(x * math.tau / (b[2] * 0.37) + b[3] * 1.7)

        for top, bot in zip(bounds, bounds[1:]):
            row = Row()
            row.cells = []
            row.y0, row.y1 = top[0] - 12, bot[0] + 12
            x = -hw - rng.uniform(0, 300)
            slant = rng.uniform(-16, 16)
            while x < hw:
                length = rng.uniform(170, 330) if outer else rng.uniform(210, 420)
                nxt, nslant = x + length, rng.uniform(-16, 16)
                cx, cy = x + length / 2, (top[0] + bot[0]) / 2
                ang = math.atan2(cy / hh, cx / hw)
                rim = 1 + 0.16 * math.sin(3 * ang + lobes[0]) + 0.09 * math.sin(5 * ang + lobes[1])
                if ((cx / hw) ** 2 + (cy / hh) ** 2) * rim < 1:
                    row.cells.append(self._cell(rng, edge, top, bot, x, slant, nxt, nslant))
                else:
                    for _ in range(40):       # 留在材料外的细胞也消耗同样多的随机数，形状才稳定
                        rng.random()
                x, slant = nxt, nslant
            if row.cells:
                self.rows.append(row)
                self.count += len(row.cells)
        a = rng.uniform(-0.5, 0.5)
        c = rng.uniform(-600, 600)
        self.fold = (a, c, rng.uniform(420, 760))

    @staticmethod
    def _cell(rng, edge, top, bot, x0, s0, x1, s1) -> Cell:
        used = [rng.random() for _ in range(40)]
        it = iter(used)

        def u(lo, hi):
            return lo + (hi - lo) * next(it)
        c = Cell()
        xt0, xb0, xt1, xb1 = x0 + s0, x0 - s0, x1 + s1, x1 - s1
        n = max(2, int((x1 - x0) / 70))
        poly = [(xt0 + (xt1 - xt0) * i / n, 0.0) for i in range(n + 1)]
        poly = [(px, edge(top, px)) for px, _ in poly]
        poly += [(px, edge(bot, px)) for px in (xb1 + (xb0 - xb1) * i / n for i in range(n + 1))]
        c.poly = poly
        xs, ys = [p[0] for p in poly], [p[1] for p in poly]
        c.box = (min(xs), min(ys), max(xs), max(ys))
        c.cx, c.cy = (x0 + x1) / 2, (top[0] + bot[0]) / 2
        c.length, c.width = x1 - x0, bot[0] - top[0]
        rx, ry = u(8, 11.5), u(6, 8.5)
        if next(it) < 0.6:      # 大液泡把细胞核挤到细胞壁边上
            ny = c.cy + (1 if next(it) < 0.5 else -1) * max(0.0, c.width / 2 - ry - 9)
        else:
            ny = c.cy + u(-0.2, 0.2) * c.width
            next(it)
        nx = c.cx + u(-0.33, 0.33) * c.length
        c.nuc = (nx, ny, rx, ry, u(-25, 25), u(-10, 10))
        c.nucleoli = [(u(-0.4, 0.4) * rx, u(-0.4, 0.4) * ry, u(1.3, 2.1)) for _ in range(1 if next(it) < 0.6 else 2)]
        c.strands = []
        for _ in range(3 + int(next(it) * 2.99)):
            k = int(next(it) * (len(poly) - 1))
            c.strands.append(poly[k])
        c.grains = []
        while True:
            try:
                gx, gy, gz = next(it), next(it), next(it)
            except StopIteration:
                break
            c.grains.append((c.box[0] + 8 + gx * (c.length - 16), c.cy + (gy - 0.5) * (c.width - 14), (gz - 0.5) * 24))
        c.gain = 0.85 + 0.30 * used[0]
        c.hard = 0.80 + 0.45 * used[1]
        c.pig = 0.0 if used[2] < 0.07 else 0.55 + 0.45 * used[3]
        c.bias = (used[4] - 0.5) * 1.2
        c.qpoly = None
        return c

    def visible(self, lx: float, ly: float, radius: float):
        """材料坐标里以 (lx, ly) 为圆心、radius 为半径的范围内可能看到的细胞。"""
        for row in self.rows:
            if row.y1 < ly - radius or row.y0 > ly + radius:
                continue
            for c in row.cells:
                if c.box[2] >= lx - radius and c.box[0] <= lx + radius:
                    yield c


def build(kind: str, seed: int) -> Tissue:
    key = (kind, seed)
    t = _cache.get(key)
    if t is None:
        if len(_cache) >= 6:
            _cache.pop(next(iter(_cache)))
        t = _cache[key] = Tissue(kind, seed)
    return t
