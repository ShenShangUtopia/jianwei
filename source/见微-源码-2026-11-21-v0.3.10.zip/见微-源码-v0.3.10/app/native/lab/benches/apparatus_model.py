"""扩展器材的可测试数据模型；mmol、mL、°C，气体按1 atm理想气体。"""
import math

GAS_MASS={"H2":2.016,"O2":31.998,"CO2":44.01,"NH3":17.031,"NO":30.006}


def gas_volume(mmol,temperature=25):
    return max(0,float(mmol))*0.082057*(temperature+273.15)


def route_gas(source,nodes,kind,amount):
    """单路串联，守恒返回(捕集/吸收,未收集)；漏气比例为声明的教学参数。"""
    by_id={node["id"]:node for node in nodes}
    current=source
    left=max(0,float(amount))
    caught_total = 0.
    source.pop('gas_note', None)
    visited={source["id"]}
    while left>1e-12:
        dest=by_id.get(current.get("gas_to"))
        if dest is None or dest["id"] in visited:
            break
        if not current.get('gas_seal', True):
            current['gas_note'] = source['gas_note'] = '导气容器未加塞密封，气体逸散，未进入下一段导管'
            break
        leak = max(0., min(1., current.get('gas_leak', 0.)))
        left *= 1 - leak
        if leak:
            source['gas_note'] = f'接口漏气：本段有 {leak:.0%} 气体未进入下一段'
        visited.add(dest["id"])
        mode=dest.get("collection","up")
        valid=(mode=="water" and kind in ("H2","O2")) or (mode=="up" and GAS_MASS.get(kind,29)>29) or (mode=="down" and GAS_MASS.get(kind,29)<29) or mode=="wash"
        if not valid:
            dest["gas_note"]="收集方法与气体性质不匹配，未计入收集量"
            source['gas_note'] = dest['gas_note']
            break
        if mode == 'water' and dest.get('gas_water_ready') is False:
            dest['gas_note'] = source['gas_note'] = '请先将集气瓶注满水并倒置，再用排水法收集'
            break
        if mode == 'water' and dest.get('gas_water_ready') and any(abs(x) > 1e-10 for x in dest.get('tot', {}).values()):
            dest['gas_note'] = source['gas_note'] = '当前排水模型只支持清水，请清空并重新准备集气瓶'
            break
        dest.pop("gas_note",None)
        if mode=="wash":
            # Limewater absorbs CO2, including excess CO2 -> bicarbonate.
            tot=dest.setdefault("tot",{})
            capacity=max(0,2*tot.get("Ca",0)-tot.get("C",0)) if dest.get("V",0)>0 else 0
            caught=min(left,capacity) if kind=="CO2" else 0
            tot["C"]=tot.get("C",0)+caught
        else:
            collected=dest.setdefault("collected",{})
            used=sum(gas_volume(n,dest.get("T",25)) for n in collected.values())
            cap=dest.get("gas_capacity",250)
            caught=min(left,max(0,cap-used)/gas_volume(1,dest.get("T",25)))
            if mode == 'water' and dest.get('gas_water_ready'):
                caught = min(caught, max(0., dest['V']) / gas_volume(1, dest.get('T',25)))
                displaced = gas_volume(caught, dest.get('T',25))
                dest['V'] = max(0., dest['V'] - displaced)
                dest['water_displaced'] = dest.get('water_displaced', 0.) + displaced
            collected[kind]=collected.get(kind,0)+caught
            if caught > 0:
                dest['gas_arrival'] = .4
        left-=caught
        caught_total += caught
        current=dest
    return caught_total,max(0.,amount-caught_total)


def prepare_water_collection(vessel, capacity):
    if vessel.get('oil', 0) or vessel.get('solids') or any(abs(x) > 1e-10 for x in vessel.get('tot', {}).values()):
        raise ValueError('请使用洁净的空集气瓶或只含清水的集气瓶')
    if sum(vessel.get('collected', {}).values()) > 1e-10:
        raise ValueError('瓶中已有收集的气体；先清空再重新准备')
    vessel.update(V=float(capacity), collection='water', gas_water_ready=True, water_displaced=0., collected={})


def titration(acid_ml=25,acid_molar=.1,base_molar=.1,added_ml=0):
    """强酸 HCl–强碱 NaOH，pH由现有电荷/平衡模型计算。"""
    from .chem_model import eqm
    total=max(1e-6,acid_ml+added_ml)
    result=eqm({"Cl":acid_ml*acid_molar,"Na":added_ml*base_molar},total)
    return dict(pH=result["pH"],equivalence_ml=acid_ml*acid_molar/max(1e-9,base_molar))


def resistance(q):
    kind=q.get("instrument")
    if kind=="ntc":
        return q.get("R0",1000)*math.exp(3500*(1/(q.get("temperature",25)+273.15)-1/298.15))
    if kind=="ldr":
        return max(1,min(1e7,q.get("R0",1000)*(100/max(1,q.get("lux",100)))**.7))
    if kind=="fuse" and q.get("tripped"):
        return 1e10
    if kind=="fuse":
        return .05
    return max(.01,q.get("R",10))
