"""滴定管计量、管尖空隙、润洗残液与流速；体积 mL。

V 记录管内全部水相（含管尖），tip_ml 是其中位于无刻度管尖的部分。
旧存档仍按管尖已充液的理想模式计量；新管使用操作训练。
"""
from __future__ import annotations

import math

TIP_CAPACITY = .12  # 本台器材标定值，不代表任意真实滴定管
FILM_VOLUME = .10  # 沥干后保留的润湿残液教学参数


def prepare(source):
    source['titration_training'] = True
    source.setdefault('titration_prep', dict(v=1, tip_ml=0., water_rinses=0, solution_rinses=0))
    source.pop('titration_run', None)
    source['titration_valve'] = False


def tip_volume(source):
    if not source.get('titration_training'):
        return 0.
    return max(0., min(TIP_CAPACITY, source.get('titration_prep', {}).get('tip_ml', 0.), source['V']))


def source_reading(source, capacity=50):
    return reading(source['V'] + source.get('oil', 0) - tip_volume(source), capacity)


def flow_rate(source, opening):
    """重力液头影响流量；最大2mL/s为教学标定，非真实活塞的通用参数。"""
    volume = max(0., source['V'] - tip_volume(source))
    opening = max(0., min(1., _number(opening)))
    return 2 * opening ** 2 * math.sqrt(volume / 50.)


def rinse_amount(source, waste, capacity):
    _solution(source)
    if source['id'] == waste['id'] or waste.get('process'):
        raise ValueError('请另选废液容器')
    if source['V'] < 2:
        raise ValueError('先加入至少 2 mL 蒸馏水或待用滴定液，再旋转润洗')
    amount = source['V'] - FILM_VOLUME
    if waste['V'] + waste.get('oil', 0) + amount > capacity + 1e-8:
        raise ValueError('废液容器容量不足，未开始润洗')
    return amount


def finish_rinse(source, was_water):
    prep = source['titration_prep']
    prep['tip_ml'] = 0.
    if was_water:
        prep['water_rinses'] += 1
        prep['solution_rinses'] = 0
    else:
        prep['solution_rinses'] += 1
    source.pop('titration_run', None)
    source['titration_valve'] = False


def preparation_rows(source):
    if not source.get('titration_training'):
        return ['旧存档理想模式：不计管尖空隙和润洗残液。']
    prep = source['titration_prep']
    return [["清水润洗", f"{prep['water_rinses']} 次"],
            ["溶液润洗", f"{prep['solution_rinses']} 次"],
            ["管尖气泡", f"{max(0., TIP_CAPACITY - tip_volume(source)):.3f} mL"],
            '沥干保留 0.10 mL 残液；再装液时实际混合并改变浓度。']


def _number(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError("滴定体积必须是有限数值")
    return value


def reading(volume, capacity=50):
    volume, capacity = _number(volume), _number(capacity)
    if capacity <= 0 or volume < -1e-8 or volume > capacity + 1e-8:
        raise ValueError("液面超出滴定管刻度范围")
    return max(0., min(capacity, capacity - volume))


def _solution(v):
    if v.get("process") or v.get("oil", 0) > 1e-8 or v.get("solids") or any(
        item.get("amt", 0) > 1e-8 for item in v.get("pp", {}).values()
    ):
        raise ValueError("滴定管仅支持不含沉淀和固体的单一水相溶液")


def begin(source, target, capacity=50):
    _solution(source)
    if source["id"] == target["id"] or target.get("process"):
        raise ValueError("请选择独立的接收容器")
    volume = _number(source["V"])
    if volume <= 1e-6:
        raise ValueError("请先向滴定管装入溶液")
    first = source_reading(source, capacity)
    source['titration_valve'] = False
    source["titration_run"] = dict(v=1, target=target["id"], initial=first,
                                   expected_volume=volume, expected_tip=tip_volume(source), delivered=0.)


def dose(source, target, requested, target_capacity, capacity=50):
    _solution(source)
    run = source.get("titration_run")
    if not run or run.get("v") != 1:
        raise ValueError("请先记录初始读数，开始本轮滴定")
    if source["id"] == target["id"] or target.get("process"):
        raise ValueError("请选择独立的接收容器")
    if run["target"] != target["id"]:
        raise ValueError("接收容器已更换，请重新记录初始读数")
    volume = _number(source["V"])
    source_reading(source, capacity)
    if abs(volume - run["expected_volume"]) > 1e-6 or abs(tip_volume(source) - run.get('expected_tip', 0.)) > 1e-6:
        raise ValueError("滴定管液量已改变，请重新记录初始读数")
    requested = _number(requested)
    if requested <= 0:
        raise ValueError("滴加量必须大于零")
    room = _number(target_capacity) - _number(target["V"]) - _number(target.get("oil", 0))
    missing = TIP_CAPACITY - tip_volume(source) if source.get('titration_training') else 0.
    if room <= 1e-6:
        raise ValueError("接收容器已满，未滴加")
    amount = min(requested, volume - tip_volume(source), max(0., room) + missing)
    if amount <= 1e-6:
        raise ValueError("滴定管已空或接收容器已满，未滴加")
    return amount


def commit(source, before, capacity=50, tip_fill=0.):
    """以物料转移后的真实体积记账，不用请求滴加量代替实收量。"""
    run = source["titration_run"]
    after = _number(source["V"])
    amount = _number(before) - after
    if amount < -1e-8 or abs(_number(before) - run["expected_volume"]) > 1e-6:
        raise ValueError("滴定计量状态不一致，请重新记录初始读数")
    if source.get('titration_training'):
        source['titration_prep']['tip_ml'] = min(TIP_CAPACITY, tip_volume(source) + tip_fill)
    source_reading(source, capacity)
    run["delivered"] += max(0., amount)
    run["expected_volume"] = after
    run['expected_tip'] = tip_volume(source)
    return max(0., amount)


def rows(source, capacity=50):
    current = source_reading(source, capacity)
    result = [["当前刻度读数", f"{current:.2f} mL"]]
    run = source.get("titration_run")
    if run and run.get("v") == 1:
        valid = abs(source["V"] - run["expected_volume"]) <= 1e-6
        valid = valid and source.get("titration_target") == run["target"]
        valid = valid and abs(tip_volume(source) - run.get('expected_tip', 0.)) <= 1e-6
        indicated = current - run['initial']
        result += [["初始读数", f"{run['initial']:.2f} mL"],
                   ["管上读数差", f"{indicated:.2f} mL"],
                   ["本轮实收体积", f"{run['delivered']:.2f} mL"],
                   ["读数差 − 实收", f"{indicated - run['delivered']:.3f} mL"],
                   "管尖未排气时，读数差可大于实收。" if valid else "液量或接收容器已改变，请重新记录"]
    else:
        result.append(["本轮滴定", "尚未记录初始读数"])
    return result
