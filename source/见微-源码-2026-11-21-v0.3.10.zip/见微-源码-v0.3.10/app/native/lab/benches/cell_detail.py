"""Native 2n=4 chromosome sorting and organelle selection; state is plain data."""
from PySide6.QtCore import Qt,QRectF,QPointF
from PySide6.QtGui import QPainter,QPen,QPainterPath
import math
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QWidget,QComboBox,QPushButton
from ...design.tokens import T,qc,font
from ...design.widgets import qss

PHASES={'mitosis':['前期','中期','后期（整细胞）','末期（两个子细胞）'],
        'meiosis':['减Ⅰ前期','减Ⅰ后期','减Ⅱ中期（两个细胞）','减Ⅱ完成（四个细胞）']}
LABELS=['A母','A父','B母','B父']


def fresh(mode,stage):
    split=(mode=='mitosis' and stage>=2) or (mode=='meiosis' and stage==3)
    tokens=[dict(h=h,sister=s,bin=-1,x=.1+.1*(h*2+s),y=.87) for h in range(4) for s in range(2)] if split else [dict(h=h,sister=None,bin=-1,x=.2+.18*h,y=.87) for h in range(4)]
    return dict(v=1,mode=mode,stage=stage,tokens=tokens)


def check(state):
    mode,stage=state['mode'],state['stage']
    tokens=state['tokens']
    expected=fresh(mode,stage)['tokens']
    if sorted((t['h'],t['sister']) for t in tokens)!=sorted((t['h'],t['sister']) for t in expected):
        return False,'染色体身份或条数不符，请重置当前时期。'
    bins=4 if mode=='meiosis' and stage==3 else 2 if (mode=='mitosis' and stage>=2) or (mode=='meiosis' and stage>=1) else 1
    if any(type(t.get('bin')) is not int or not 0<=t['bin']<bins for t in tokens):
        return False,'还有染色体未放入对应细胞或赤道板区域。'
    if bins==1:
        if mode=='meiosis':
            for family in range(2):
                pair=[t for t in tokens if t['h']//2==family]
                if abs(pair[0]['x']-pair[1]['x'])>.12 or abs(pair[0]['y']-pair[1]['y'])>.12:
                    return False,'减Ⅰ前期需要同源染色体配对；A母/A父、B母/B父分别靠在一起。'
        return True,'条数、复制状态和区域相符；未核对纺锤丝连接与交换。'
    if mode=='mitosis':
        for group in range(2):
            if sorted(t['h'] for t in tokens if t['bin']==group)!=list(range(4)):
                return False,'有丝分裂两侧都应各有原来四条染色体的一份。'
    elif stage in (1,2):
        for group in range(2):
            if sorted(t['h']//2 for t in tokens if t['bin']==group)!=[0,1]:
                return False,'减Ⅰ分离的是同源染色体；每侧各留A、B家族的一条，姐妹染色单体仍在一起。'
    else:
        for group in range(4):
            if sorted(t['h']//2 for t in tokens if t['bin']==group)!=[0,1]:
                return False,'每个减数分裂产物应有A、B家族各一条单染色单体染色体。'
        for h in range(4):
            destinations=[t['bin'] for t in tokens if t['h']==h]
            if destinations[0]==destinations[1] or destinations[0]//2!=destinations[1]//2:
                return False,'同一条原染色体的两份姐妹应分到同一个减Ⅱ母细胞产生的两个子细胞。'
    return True,'染色体身份、数量和分配相符。此模型不含交换、突变或不分离。'


class Sorting(QWidget):
    def __init__(self,state,remember,parent=None):
        super().__init__(parent)
        self.state,self.remember=state,remember
        self.dragged=None
        self.setMinimumSize(640,400)

    def regions(self):
        s=self.state
        count=4 if s['mode']=='meiosis' and s['stage']==3 else 2 if (s['mode']=='mitosis' and s['stage']>=2) or (s['mode']=='meiosis' and s['stage']>=1) else 1
        if count==1:
            values=[(.44,.15,.12,.52)] if s['mode']=='mitosis' and s['stage']==1 else [(.15,.15,.7,.52)]
        elif count==2:
            values=[(.12,.15,.3,.52),(.58,.15,.3,.52)]
            if s['mode']=='meiosis' and s['stage']==2:
                values=[(.23,.15,.08,.52),(.69,.15,.08,.52)]
        else:
            values=[(.03+i*.245,.17,.22,.48) for i in range(4)]
        return [QRectF(x*self.width(),y*self.height(),w*self.width(),h*self.height()) for x,y,w,h in values]

    def paintEvent(self,event):
        p=QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(),qc(T.stage))
        p.setFont(font(12))
        for i,r in enumerate(self.regions()):
            p.setPen(QPen(qc(T.line),2))
            p.setBrush(qc(T.surface))
            p.drawRoundedRect(r,10,10)
            p.setPen(qc(T.fg))
            p.drawText(r.adjusted(3,3,-3,-3),int(Qt.AlignmentFlag.AlignTop|Qt.AlignmentFlag.AlignHCenter),f'区域{i+1}')
        p.setPen(qc(T.muted))
        p.drawText(QRectF(8,self.height()*.75,self.width()-16,25),int(Qt.AlignmentFlag.AlignCenter),'待放置区：拖动每条染色体；颜色区分家族，标签区分来源')
        for t in self.state['tokens']:
            x,y=t['x']*self.width(),t['y']*self.height()
            p.setPen(QPen(qc(T.c1 if t['h']//2==0 else T.c2),4))
            if t['sister'] is None:
                p.drawLine(QPointF(x-7,y-15),QPointF(x+7,y+15))
                p.drawLine(QPointF(x+7,y-15),QPointF(x-7,y+15))
            else:
                p.drawLine(QPointF(x,y-15),QPointF(x,y+15))
            p.setBrush(qc(T.fg))
            p.drawEllipse(QPointF(x,y),2.5,2.5)
            p.setPen(qc(T.fg))
            label=LABELS[t['h']]+('' if t['sister'] is None else str(t['sister']+1))
            label_x=x+10 if x+68<self.width() else x-68
            p.drawText(QRectF(label_x,y-10,58,20),int(Qt.AlignmentFlag.AlignVCenter|Qt.AlignmentFlag.AlignLeft),label)
        p.end()

    def mousePressEvent(self,event):
        if event.button()!=Qt.MouseButton.LeftButton:
            return
        for t in reversed(self.state['tokens']):
            if abs(event.position().x()-t['x']*self.width())<20 and abs(event.position().y()-t['y']*self.height())<30:
                self.remember()
                self.dragged=t
                break

    def mouseMoveEvent(self,event):
        if self.dragged is not None:
            self.dragged['x']=max(.03,min(.97,event.position().x()/self.width()))
            self.dragged['y']=max(.08,min(.94,event.position().y()/self.height()))
            self.update()

    def mouseReleaseEvent(self,event):
        if self.dragged is not None:
            self.mouseMoveEvent(event)
            self.dragged['bin']=next((i for i,r in enumerate(self.regions()) if r.contains(event.position())),-1)
            self.dragged=None
            self.update()


class Chromosomes(QDialog):
    def __init__(self,mode,parameters,remember,parent=None):
        super().__init__(parent)
        self.setObjectName('jw2')
        self.setStyleSheet(qss())
        self.setWindowTitle('逐条染色体核对')
        self.resize(900,620)
        root=QVBoxLayout(self)
        note=QLabel('假设2n=4；每个X是一条含两姐妹染色单体的染色体，I为一条单染色单体染色体。无交换、无不分离；仅核对所列规则。')
        note.setWordWrap(True)
        root.addWidget(note)
        stage=QComboBox()
        stage.addItems(PHASES[mode])
        current=parameters.get('chromosomes')
        if current is not None:
            if not isinstance(current,dict) or current.get('v')!=1 or current.get('mode')!=mode or type(current.get('stage')) is not int or not 0<=current['stage']<=3 or not isinstance(current.get('tokens'),list) or len(current['tokens'])>8:
                raise ValueError('染色体记录损坏或版本不支持，未覆盖原记录')
            for token in current['tokens']:
                if not isinstance(token,dict) or type(token.get('h')) is not int or not 0<=token['h']<4 or token.get('sister') not in (None,0,1) or type(token.get('bin')) is not int or not -1<=token['bin']<4 or not all(type(token.get(k)) in (int,float) and math.isfinite(token[k]) and 0<=token[k]<=1 for k in ('x','y')):
                    raise ValueError('染色体记录无效，未覆盖原记录')
        else:
            current=fresh(mode,int(parameters.get('stage',0)))
            parameters['chromosomes']=current
        stage.setCurrentIndex(current['stage'])
        root.addWidget(stage)
        self.board=Sorting(current,remember)
        root.addWidget(self.board,1)
        self.result=QLabel('拖动后点击核对。结果不会自动推断遗传性状。')
        self.result.setWordWrap(True)
        root.addWidget(self.result)
        def reset(index):
            remember()
            parameters['stage']=index
            parameters['chromosomes']=fresh(mode,index)
            self.board.state=parameters['chromosomes']
            self.board.update()
            self.result.setText('当前时期已重置，请重新放置。')
        stage.currentIndexChanged.connect(reset)
        button=QPushButton('核对当前时期')
        button.clicked.connect(lambda:self.result.setText(check(self.board.state)[1]))
        root.addWidget(button)
        restart=QPushButton('重置当前时期')
        restart.clicked.connect(lambda:reset(stage.currentIndex()))
        root.addWidget(restart)


STRUCTURES=[('细胞核',.5,.48,'遗传信息主要储存于细胞核；核膜与核仁在分裂过程中发生变化。'),
            ('线粒体',.25,.65,'有氧呼吸的主要场所；并非有氧呼吸所有阶段都发生在线粒体。'),
            ('核糖体',.65,.35,'合成蛋白质的场所；没有膜结构。'),
            ('内质网',.7,.6,'与蛋白质加工、脂质合成等有关；粗面内质网上附着核糖体。'),
            ('高尔基体',.4,.7,'与分泌蛋白加工、分类和运输等有关；植物细胞中还与细胞壁形成有关。'),
            ('叶绿体',.25,.35,'叶肉细胞进行光合作用的场所；不代表所有植物细胞都有叶绿体。'),
            ('液泡',.52,.25,'成熟植物细胞的大液泡与渗透调节等有关；此图为示意。')]


class Organelles(QDialog):
    def __init__(self,kind,parameters,remember,parent=None):
        super().__init__(parent)
        self.setObjectName('jw2')
        self.setStyleSheet(qss())
        self.setWindowTitle('细胞结构示意图')
        root=QVBoxLayout(self)
        self.info=QLabel('点选结构看名称与功能。这是结构示意图：核糖体、内质网、高尔基体等在普通光学显微镜下看不到；二维示意，不按真实比例；植物采用叶肉细胞。')
        self.info.setWordWrap(True)
        self.items=STRUCTURES if kind=='plant' else STRUCTURES[:5]
        outer=self
        class Cell(QWidget):
            def paintEvent(self,event):
                p=QPainter(self)
                p.setRenderHint(QPainter.RenderHint.Antialiasing)
                p.fillRect(self.rect(),qc(T.stage))
                r=QRectF(self.width()*.08,self.height()*.06,self.width()*.84,self.height()*.87)
                p.setPen(QPen(qc(T.fg),3 if kind=='plant' else 2))
                p.setBrush(qc(T.surface))
                p.drawRoundedRect(r,18,18) if kind=='plant' else p.drawEllipse(r)
                p.setFont(font(12))
                for name,x,y,text in outer.items:
                    selected=parameters.get('selected_organelle')==name
                    cx,cy=x*self.width(),y*self.height()
                    if selected:
                        p.setPen(QPen(qc(T.accent),2))
                        p.setBrush(qc(T.raised))
                        p.drawRoundedRect(QRectF(cx-38,cy-24,76,48),6,6)
                    p.setPen(QPen(qc(T.c1),2))
                    p.setBrush(qc(T.surface))
                    if name=='核糖体':
                        p.setBrush(qc(T.fg))
                        for dx,dy in ((-15,0),(-3,-7),(8,6),(20,-4)):
                            p.drawEllipse(QPointF(cx+dx,cy+dy),4,4)
                    elif name in ('内质网','高尔基体'):
                        for dy in (-10,0,10):
                            path=QPainterPath(QPointF(cx-28,cy+dy))
                            path.cubicTo(cx-12,cy+dy-9,cx+10,cy+dy+9,cx+28,cy+dy)
                            p.drawPath(path)
                            if name=='内质网':
                                for dx in (-18,-2,15):
                                    p.drawEllipse(QPointF(cx+dx,cy+dy-3),1.5,1.5)
                    elif name=='细胞核':
                        p.drawEllipse(QPointF(cx,cy),23,19)
                        p.drawEllipse(QPointF(cx,cy),20,16)
                        p.setBrush(qc(T.c2))
                        p.drawEllipse(QPointF(cx+5,cy),5,5)
                    elif name=='液泡':
                        p.drawRoundedRect(QRectF(cx-30,cy-18,60,36),8,8)
                    else:
                        p.drawEllipse(QPointF(cx,cy),32,15)
                        if name=='线粒体':
                            path=QPainterPath(QPointF(cx-24,cy))
                            for dx in range(-20,25,5):
                                path.lineTo(cx+dx,cy+(-8 if dx%10 else 8))
                            p.drawPath(path)
                        else:
                            for dx in (-17,0,17):
                                for dy in (-6,0,6):
                                    p.drawRect(QRectF(cx+dx-5,cy+dy-1,10,2))
                    p.setPen(qc(T.fg))
                    p.drawText(QRectF(cx-40,cy+19,80,23),int(Qt.AlignmentFlag.AlignCenter),name)
                p.end()
            def mousePressEvent(self,event):
                for name,x,y,text in outer.items:
                    if abs(event.position().x()-x*self.width())<=34 and abs(event.position().y()-y*self.height())<=20:
                        remember()
                        parameters['selected_organelle']=name
                        outer.info.setText(name+'：'+text)
                        self.update()
                        break
        self.cell=Cell()
        self.cell.setMinimumSize(600,360)
        root.addWidget(self.cell,1)
        root.addWidget(self.info)
        self.resize(700,480)
