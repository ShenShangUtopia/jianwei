"""反应式的计量、元素、电荷和条件解析；配平校验不代表已验证反应能否发生。"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from html import escape
import re

_SUB = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")
_SUP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")


@dataclass(frozen=True)
class Species:
    coefficient: int
    formula: str
    elements: tuple
    charge: int


@dataclass(frozen=True)
class Equation:
    left: tuple
    right: tuple
    reversible: bool
    condition: str

    def imbalance(self):
        atoms = Counter()
        charge = 0
        for sign, side in ((-1, self.left), (1, self.right)):
            for item in side:
                for atom, n in item.elements:
                    atoms[atom] += sign * item.coefficient * n
                charge += sign * item.coefficient * item.charge
        return {k: v for k, v in atoms.items() if v}, charge

    @property
    def balanced(self):
        atoms, charge = self.imbalance()
        return not atoms and charge == 0


def _atoms(formula):
    text = formula.translate(_SUB)
    tokens = re.findall(r"[A-Z][a-z]?|\d+|[()\[\]]", text)
    if ''.join(tokens) != text:
        raise ValueError(f"不支持的化学式：{formula}")
    index = 0

    def group(close=None):
        nonlocal index
        result = Counter()
        while index < len(tokens):
            token = tokens[index]
            if token in (')', ']'):
                if close != token:
                    raise ValueError("化学式括号不配对")
                index += 1
                return result
            index += 1
            if token in ('(', '['):
                part = group(')' if token == '(' else ']')
            elif re.fullmatch('[A-Z][a-z]?', token):
                part = Counter({token: 1})
            else:
                raise ValueError("化学式计数位置无效")
            number = 1
            if index < len(tokens) and tokens[index].isdigit():
                number = int(tokens[index])
                index += 1
                if number <= 0:
                    raise ValueError("化学式计数必须大于零")
            result.update({k: v * number for k, v in part.items()})
        if close:
            raise ValueError("化学式括号未闭合")
        return result

    return group()


def species(text):
    original = text.strip()
    match = re.match(r'^(\d+)', original)
    coefficient = int(match[1]) if match else 1
    formula = original[match.end():] if match else original
    if coefficient <= 0:
        raise ValueError("计量数必须大于零")
    formula = re.sub(r'\((?:aq|s|l|g)\)', '', formula).rstrip('↓↑')
    charge = 0
    ion = re.search(r'([⁰¹²³⁴⁵⁶⁷⁸⁹]*)([⁺⁻])$', formula)
    if ion:
        charge = int(ion[1].translate(_SUP) or '1') * (1 if ion[2] == '⁺' else -1)
        formula = formula[:ion.start()]
    elements = Counter()
    if formula != 'e':
        for component in formula.split('·'):
            number = re.match(r'^(\d+)', component)
            multiplier = int(number[1]) if number else 1
            part = component[number.end():] if number else component
            if not part:
                raise ValueError("空的化学式")
            elements.update({k: v * multiplier for k, v in _atoms(part).items()})
    elif charge != -1:
        raise ValueError("电子必须记为 e⁻")
    return Species(coefficient, original, tuple(sorted(elements.items())), charge)


@lru_cache(maxsize=256)
def parse(text):
    arrow = re.search(r'⇌|→|=[^=]+?=|=', text)
    if not arrow or re.search(r'⇌|→|=', text[arrow.end():]):
        raise ValueError("反应式需要一个箭头")
    left = tuple(species(s) for s in re.split(r'\s+\+\s+', text[:arrow.start()].strip()))
    right = tuple(species(s) for s in re.split(r'\s+\+\s+', text[arrow.end():].strip()))
    condition = arrow[0][1:-1] if arrow[0].startswith('=') and len(arrow[0]) > 1 else ''
    return Equation(left, right, arrow[0] == '⇌', '加热' if condition == '△' else condition)


def display(text):
    try:
        equation = parse(text)
    except ValueError:
        return escape(text)
    arrow = ' ⇌ ' if equation.reversible else ' → '
    if equation.condition:
        arrow = f' —[{equation.condition}]→ '
    return escape(' + '.join(s.formula for s in equation.left) + arrow +
                  ' + '.join(s.formula for s in equation.right))
