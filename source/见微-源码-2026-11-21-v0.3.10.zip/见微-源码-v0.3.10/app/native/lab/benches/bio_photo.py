"""光合与呼吸：两个过程分开算、分开报，净光合是它们的差。纯数据，不依赖 Qt。

全部是相对单位（以 CO₂ 计，单位叶面积、单位时间），没有定标数据。
在 25 ℃ 时和旧模型的数完全一样：总光合 = 20·光/(光+200)·CO₂/(CO₂+0.02)，呼吸 = 2。
"""
import math

PMAX = 20.0        # 25 ℃、光和 CO₂ 都饱和时的总光合
K_LIGHT = 200.0    # 光的半饱和点（相对光强）
K_CO2 = 0.02       # CO₂ 的半饱和点（%）
R25 = 2.0          # 25 ℃ 时的呼吸
Q10 = 2.0          # 呼吸：每升 10 ℃ 的倍数
T_OPT = 27.0       # 总光合的最适温度
T_WIDTH = 13.0
R_HOT = 50.0       # 呼吸在这附近因高温垮掉
LIMITS = dict(light=(0, 2000), co2=(0, 1), temperature=(-5, 60), day=(0, 24))
DEFAULT = dict(day=12)

SOURCES = [
    ("呼吸的 Q10 常取 2.0，但它不是常数，随温度升高而下降",
     "Atkin & Tjoelker 2003, Trends in Plant Science 8(7):343–351（只读到摘要）",
     "https://researchportalplus.anu.edu.au/en/publications/thermal-acclimation-and-the-dynamic-response-of-plant-respiration/"),
]

ASSUMPTIONS = [
    "总光合对光强、对 CO₂ 浓度都按直角双曲线饱和；最大值 20、半饱和点 200（光）和 0.02%（CO₂）是沿用旧模型的示意数，不是某种植物的实测值。",
    "总光合的最适温度取 27 ℃、钟形宽度 13 ℃；呼吸 Q10 固定取 2，50 ℃ 附近垮掉——都是示意。",
    "光下的呼吸按和黑暗中一样算；不含光呼吸、气孔开闭、光抑制。",
    "一昼夜净积累按白天黑夜同一温度算。",
    "所有数是相对值，不能换算成 μmol·m⁻²·s⁻¹ 或 mg/h。",
]


def settings(p):
    full = {**DEFAULT, **{k: p[k] for k in LIMITS if k in p}}
    for key, (lo, hi) in LIMITS.items():
        value = full[key]
        if type(value) not in (int, float) or not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError("光合与呼吸的条件超出模型范围")
    return full


def _bell(t):
    return math.exp(-((t - T_OPT) / T_WIDTH) ** 2)


def _hot(t):
    return 1 / (1 + math.exp((t - R_HOT) / 2.5))


def ceiling(co2, temperature):
    """这个 CO₂ 浓度和温度下，光再强也超不过的总光合。"""
    return PMAX * co2 / (co2 + K_CO2) * _bell(temperature) / _bell(25)


def gross(light, co2, temperature):
    return ceiling(co2, temperature) * light / (light + K_LIGHT)


def respiration(temperature):
    return R25 * Q10 ** ((temperature - 25) / 10) * _hot(temperature) / _hot(25)


def compensation(co2, temperature):
    """光补偿点：总光合 = 呼吸时的光强；光再强也补偿不了时返回 None。"""
    top, r = ceiling(co2, temperature), respiration(temperature)
    return K_LIGHT * r / (top - r) if top > r else None


def measure(p):
    s = settings(p)
    g = gross(s["light"], s["co2"], s["temperature"])
    r = respiration(s["temperature"])
    return dict(settings=s, gross=g, respiration=r, net=g - r,
                compensation=compensation(s["co2"], s["temperature"]),
                daily=g * s["day"] - r * 24)


def curve(p):
    """净光合随光强（0–2000，每 25 一点）的变化，CO₂ 和温度取当前值。"""
    s = settings(p)
    r = respiration(s["temperature"])
    return [gross(light, s["co2"], s["temperature"]) - r for light in range(0, 2001, 25)]
