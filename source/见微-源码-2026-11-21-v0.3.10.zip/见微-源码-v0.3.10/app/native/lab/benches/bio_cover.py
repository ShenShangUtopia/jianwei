"""生物工作台卡片的封面图和两行说明。

封面是 264×112 的一块图，按卡片当前的状态画：细胞是结构示意，分裂按 bio_division 的记录一条条画染色体，
曲线、棋盘、金字塔都用卡片自己的读数。颜色跟主题走；显微镜视野由 bio_scope_view 画好传进来。
"""
import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QImage, QLinearGradient, QPainter, QPainterPath, QPen

from ...design.tokens import T, font, qc
from . import bio_division, bio_enzyme

W, H = 264, 112
VIEW = 104          # 显微镜视野在封面里的边长
LEFT = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
RIGHT = int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
CENTER = int(Qt.AlignmentFlag.AlignCenter)
# 每个时期染色体怎么摆
ARRANGE = {("mitosis", 4): "thread", ("mitosis", 5): "thread", ("mitosis", 0): "scatter", ("mitosis", 1): "equator",
           ("mitosis", 2): "poles", ("mitosis", 3): "rest",
           ("meiosis", 4): "thread", ("meiosis", 0): "pairs", ("meiosis", 5): "pairs-equator", ("meiosis", 1): "poles-homolog",
           ("meiosis", 6): "scatter", ("meiosis", 2): "equator", ("meiosis", 7): "poles", ("meiosis", 3): "rest"}


def key(kind, p):
    """封面只随这些东西变：主题和卡片上的简单参数。"""
    return (kind, T.skin, T.dark, T.accent, tuple(sorted((k, v) for k, v in p.items() if type(v) in (int, float, str, bool))))


def render(kind, p, result, dpr, view=None):
    image = QImage(int(W * dpr), int(H * dpr), QImage.Format.Format_ARGB32_Premultiplied)
    image.setDevicePixelRatio(dpr)
    image.fill(Qt.GlobalColor.transparent)
    g = QPainter(image)
    g.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    g.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
    g.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, W, H), 7, 7)
    g.setClipPath(clip)
    g.fillRect(QRectF(0, 0, W, H), qc(T.surface))
    try:
        _PAINT[kind](g, p, result, view)
    finally:
        g.end()
    return image


def caption(kind, p, result):
    """(条件, 读数) 两行。"""
    rows = result["rows"]
    if kind in ("plant", "animal"):
        return "结构示意，不按真实比例", f"{len(rows)} 种结构，可点选"
    if kind in ("mitosis", "meiosis"):
        c = bio_division.phase(kind, int(p["stage"]))
        cells = "" if c["cells"] == 1 else f"{c['cells']} 个细胞，每个："
        return c["name"], f"{cells}染色体 {c['chromosomes']} · 核DNA {c['dna']} · 单体 {c['chromatids']}"
    if kind == "cross":
        return f"父本 {p['father']} × 母本 {p['mother']}", " · ".join(f"{a} {b}" for a, b in rows if not b.startswith("0"))
    if kind == "enzyme" and p.get("enzyme") is not None:
        if len(rows) < 3:
            return "记录读不出来", "—"
        name = bio_enzyme.ENZYMES[p["enzyme"]]["name"].split("（")[0]
        left = next(b for a, b in rows if "底物剩余" in a)
        return f"{name} · {p['temperature']:g} ℃ · pH {p['pH']:g}", f"相对活性 {float(rows[0][1]):.3g} · 底物剩余 {left}"
    if kind == "enzyme":
        return f"通用曲线 · {p['temperature']:g} ℃ · pH {p['pH']:g}", f"相对活性 {float(rows[0][1]):.3g}"
    if kind == "photosynthesis":
        if rows[0][1] == "—":
            return "记录读不出来", "—"
        return (f"光强 {p['light']:g} · CO₂ {p['co2']:g}% · {p['temperature']:g} ℃",
                f"总光合 {float(rows[0][1]):.3g} · 呼吸 {float(rows[1][1]):.3g} · 净 {float(rows[2][1]):.3g}")
    if kind == "population":
        return f"t = {p['time']:g} · r = {p['rate']:g} · K = {p['capacity']:g}", f"种群数量 {float(rows[0][1]):.4g}"
    if kind == "foodweb":
        return f"传递效率 {p['efficiency'] * 100:.3g}%", " → ".join(_num(v) for v in result["values"])
    if kind == "energy_network":
        return f"草 {p['energy']:g} kJ · 每级效率 {p['efficiency'] * 100:.3g}%", f"鹰获得 {_num(result['network'][3])} kJ"
    if kind == "microscope" and p.get("slide") is not None:
        return f"总放大 {rows[0][1]} · 视野 {rows[1][1]}", rows[-1][1]
    return f"总放大 {rows[0][1]} · 视野 {rows[1][1]}", "自由倍数（示意），还没有装片"


# ---------------------------------------------------------------- 小工具
def _num(value):
    """1000 而不是 1e+03。"""
    return f"{value:.4g}" if abs(value) < 1e5 else f"{value:.3g}"


def _pen(color, width=1.5, style=Qt.PenStyle.SolidLine):
    return QPen(qc(color) if not isinstance(color, QColor) else color, width, style, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)


def _smooth(points):
    """过这些点的光滑闭合曲线。"""
    n = len(points)
    path = QPainterPath(QPointF(*points[0]))
    for i in range(n):
        p0, p1, p2, p3 = points[i - 1], points[i], points[(i + 1) % n], points[(i + 2) % n]
        path.cubicTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1])
    return path


def _capsule(g, x, y, rx, ry, angle, fill, line, ridges=False):
    g.save()
    g.translate(x, y)
    g.rotate(angle)
    g.setPen(_pen(line, 1.1))
    g.setBrush(fill)
    g.drawRoundedRect(QRectF(-rx, -ry, 2 * rx, 2 * ry), ry, ry)
    if ridges:
        path = QPainterPath(QPointF(-rx + 2.5, 0))
        step = (2 * rx - 5) / 4
        for i in range(1, 5):
            path.lineTo(-rx + 2.5 + i * step, ry * (.55 if i % 2 else -.55))
        g.setBrush(Qt.BrushStyle.NoBrush)
        g.setPen(_pen(line, .8))
        g.drawPath(path)
    g.restore()


def _text(g, rect, flags, text, size=10, color=None, weight=400):
    g.setFont(font(size, weight))
    g.setPen(qc(color or T.muted))
    g.drawText(rect, flags, text)


# ---------------------------------------------------------------- 细胞
def _plant(g, p, result, view):
    w, h, top = 122, 86, 13
    for i in (-1, 1, 0):          # 两侧的邻居只画壁和液泡，中间这个画全
        x = (W - w) / 2 + i * (w + 2.5)
        cell = QRectF(x, top, w, h)
        g.setPen(_pen(qc(T.bio, 1 if i == 0 else .55), 3))
        g.setBrush(qc(T.bio, .10 if i == 0 else .05))
        g.drawRoundedRect(cell, 9, 9)
        g.setPen(_pen(qc(T.c6, .75 if i == 0 else .35), 1.2))
        g.setBrush(qc(T.c6, .20 if i == 0 else .09))
        g.drawRoundedRect(QRectF(x + 31, top + 13, w - 46, h - 26), 17, 17)
        if i:
            continue
        g.setPen(_pen(qc(T.fg, .42), 1))
        g.setBrush(Qt.BrushStyle.NoBrush)
        g.drawRoundedRect(cell.adjusted(3.5, 3.5, -3.5, -3.5), 6.5, 6.5)
        for dx, dy, angle in ((46, 8.2, 0), (76, 8.2, 0), (104, 9, 8), (52, h - 8.2, 0), (88, h - 8.2, 0), (112.5, 44, 90), (20, 26, 62), (24, 46, 96)):
            _capsule(g, x + dx, top + dy, 7, 3.4, angle, qc(T.bio, .85), qc(T.bio))
            g.save()
            g.translate(x + dx, top + dy)
            g.rotate(angle)
            g.setPen(_pen(qc(T.raised, .7), .8))
            g.drawLine(QPointF(-3.5, 0), QPointF(3.5, 0))
            g.restore()
        _capsule(g, x + 13, top + 14, 5.2, 2.6, -35, qc(T.c2, .30), T.c2, True)
        _capsule(g, x + 111, top + 70, 5.2, 2.6, 60, qc(T.c2, .30), T.c2, True)
        g.setPen(_pen(T.c5, 1.3))
        g.setBrush(qc(T.c5, .28))
        g.drawEllipse(QPointF(x + 19, top + h - 20), 10, 9.5)
        g.setPen(Qt.PenStyle.NoPen)
        g.setBrush(qc(T.c5, .9))
        g.drawEllipse(QPointF(x + 21, top + h - 21), 3, 3)


def _animal(g, p, result, view):
    radii = (.97, 1.0, .95, 1.04, .98, 1.06, .96, 1.03, .94, 1.0, .97, 1.05, .93, 1.02, .98, 1.06, .95, 1.01)
    points = [(W / 2 + 80 * r * math.cos(i * math.pi / 9), H / 2 + 44 * r * math.sin(i * math.pi / 9)) for i, r in enumerate(radii)]
    g.setPen(_pen(qc(T.fg, .8), 1.6))
    g.setBrush(qc(T.c2, .08))
    g.drawPath(_smooth(points))
    g.setBrush(Qt.BrushStyle.NoBrush)
    for i, (dx, dy) in enumerate(((-52, 2), (-47, 5), (-42, 8))):       # 内质网：贴着核的几道弧
        path = QPainterPath(QPointF(W / 2 + dx, H / 2 - 20 + i * 2))
        path.quadTo(W / 2 + dx - 9, H / 2 + dy, W / 2 + dx + 2, H / 2 + 24 - i * 3)
        g.setPen(_pen(qc(T.c3, .7), 1.1))
        g.drawPath(path)
    for i in range(3):                                                  # 高尔基体
        path = QPainterPath(QPointF(W / 2 + 28, H / 2 + 10 + i * 5))
        path.quadTo(W / 2 + 44, H / 2 + 3 + i * 5, W / 2 + 60 - i * 3, H / 2 + 12 + i * 5)
        g.setPen(_pen(T.c4, 1.6))
        g.drawPath(path)
    for x, y, angle in ((70, 36, 25), (190, 44, -30), (150, 88, 8), (96, 84, -15)):
        _capsule(g, x, y, 9, 4.3, angle, qc(T.c2, .30), T.c2, True)
    g.setPen(_pen(T.c5, 1.4))
    g.setBrush(qc(T.c5, .25))
    g.drawEllipse(QPointF(W / 2 - 14, H / 2 - 1), 19, 17)
    g.setPen(Qt.PenStyle.NoPen)
    g.setBrush(qc(T.c5, .9))
    g.drawEllipse(QPointF(W / 2 - 10, H / 2 + 1), 4.5, 4.5)
    g.setBrush(qc(T.c4))
    for angle in (0, 90):                                               # 中心体：两个互相垂直的中心粒
        g.save()
        g.translate(W / 2 + 14 + (4 if angle else 0), H / 2 - 22 + (4 if angle else 0))
        g.rotate(angle + 20)
        g.drawRoundedRect(QRectF(-3.5, -1.3, 7, 2.6), 1, 1)
        g.restore()
    g.setPen(_pen(T.c6, 1))
    g.setBrush(qc(T.c6, .3))
    for x, y in ((205, 68), (60, 62), (176, 26), (122, 92)):
        g.drawEllipse(QPointF(x, y), 2.4, 2.4)


# ---------------------------------------------------------------- 分裂
def _chromosome(g, x, y, token, s, angle=0.0, chevron=0):
    """一条染色体：长短看家族，颜色看来源（母方暖色、父方冷色）；复制过的画成 X。"""
    family, origin, chromatids = token
    length = (17 if family == 0 else 12) * s
    color = T.c2 if origin == "m" else T.c1
    width = max(1.8, 2.7 * s)
    g.save()
    g.translate(x, y)
    g.rotate(angle)
    g.setPen(_pen(color, width))
    if chromatids == 2:
        g.drawLine(QPointF(-length * .2, -length / 2), QPointF(length * .2, length / 2))
        g.drawLine(QPointF(length * .2, -length / 2), QPointF(-length * .2, length / 2))
    elif chevron:           # 后期：着丝粒在前，两臂拖在后面
        g.drawLine(QPointF(0, 0), QPointF(chevron * length * .42, -length * .36))
        g.drawLine(QPointF(0, 0), QPointF(chevron * length * .42, length * .36))
    else:
        g.drawLine(QPointF(0, -length / 2), QPointF(0, length / 2))
    g.setPen(Qt.PenStyle.NoPen)
    g.setBrush(qc(T.fg))
    g.drawEllipse(QPointF(0, 0), width * .5, width * .5)
    g.restore()


def _cell(g, cx, cy, rx, ry, tokens, how, s):
    if how.startswith("poles"):
        rx *= 1.16 if s == 1 else 1.0
    g.setPen(_pen(qc(T.fg, .75), 1.5))
    g.setBrush(qc(T.c4, .08))
    g.drawEllipse(QPointF(cx, cy), rx, ry)
    r = min(rx, ry)
    n = len(tokens)
    spindle = _pen(qc(T.fg, .22), 1)
    poles = (QPointF(cx - rx * .84, cy), QPointF(cx + rx * .84, cy))

    def centrosomes():
        g.setPen(Qt.PenStyle.NoPen)
        g.setBrush(qc(T.c4))
        for pole in poles:
            g.drawEllipse(pole, 2.2, 2.2)

    if how in ("thread", "scatter", "pairs", "rest"):
        g.setPen(_pen(qc(T.fg, .45 if how in ("thread", "rest") else .3), 1, Qt.PenStyle.SolidLine if how in ("thread", "rest") else Qt.PenStyle.DashLine))
        g.setBrush(qc(T.c5, .08))
        g.drawEllipse(QPointF(cx, cy), r * .68, r * .68)
    if how == "thread":         # 间期：染色质细丝；复制后每条是并排的两根
        g.setBrush(Qt.BrushStyle.NoBrush)
        for i, (family, origin, chromatids) in enumerate(tokens):
            a = i * 2 * math.pi / n + .6
            x, y = cx + r * .3 * math.cos(a), cy + r * .3 * math.sin(a)
            reach = r * (.3 if family == 0 else .22)
            for k in range(chromatids):
                off = (k - (chromatids - 1) / 2) * 3
                path = QPainterPath(QPointF(x - reach * math.sin(a) + off * math.cos(a), y + reach * math.cos(a) + off * math.sin(a)))
                path.cubicTo(x + reach * .9 * math.cos(a) + off, y + reach * .2, x - reach * .9 * math.cos(a) + off, y - reach * .2,
                             x + reach * math.sin(a) + off * math.cos(a), y - reach * math.cos(a) + off * math.sin(a))
                g.setPen(_pen(qc(T.c2 if origin == "m" else T.c1, .85), 1.3))
                g.drawPath(path)
    elif how in ("scatter", "rest"):
        spread = r * (.36 if how == "scatter" else .3)
        for i, token in enumerate(tokens):
            a = i * 2 * math.pi / n + .5
            _chromosome(g, cx + spread * math.cos(a), cy + spread * math.sin(a), token, s, (i * 53) % 70 - 35)
    elif how == "pairs":        # 联会：同源的两条并排贴在一起
        for family in range(bio_division.N):
            pair = [t for t in tokens if t[0] == family]
            x, y = cx + (family * 2 - 1) * r * .28, cy + (family * 2 - 1) * r * .14
            for j, token in enumerate(pair):
                _chromosome(g, x + (j * 2 - 1) * 4.6 * s, y, token, s, (j * 2 - 1) * -8 + family * 20)
    elif how in ("equator", "pairs-equator"):
        if how == "equator":
            if n > 2:           # 四条排成一列：缩一点，免得首尾相接
                s *= .8
            spots = [(cx, cy + (i - (n - 1) / 2) * min(2 * ry * .82 / n, 22 * s), token) for i, token in enumerate(tokens)]
        else:                   # 减Ⅰ中期：成对排在赤道板两侧
            spots = [(cx + (-1 if token[1] == "m" else 1) * 6.5 * s, cy + (token[0] * 2 - 1) * ry * .3, token) for token in tokens]
        g.setPen(spindle)
        for x, y, token in spots:
            for pole in ((poles[0],) if how != "equator" and token[1] == "m" else (poles[1],) if how != "equator" else poles):
                g.drawLine(pole, QPointF(x, y))
        centrosomes()
        for x, y, token in spots:
            _chromosome(g, x, y, token, s)
    else:                       # 两极：姐妹分开（poles）或同源分开（poles-homolog）
        sides = {-1: [], 1: []}
        seen = set()
        for token in tokens:
            if how == "poles-homolog":
                side = -1 if token[1] == "m" else 1
            else:
                side = 1 if token in seen else -1
                seen.symmetric_difference_update({token})
            sides[side].append(token)
        g.setPen(spindle)
        g.drawLine(poles[0], poles[1])
        spots = []
        for side, group in sides.items():
            for i, token in enumerate(group):
                x, y = cx + side * rx * .46, cy + (i - (len(group) - 1) / 2) * min(2 * ry * .74 / max(1, len(group)), 22 * s)
                spots.append((x, y, token, side))
                g.setPen(spindle)
                g.drawLine(poles[0 if side < 0 else 1], QPointF(x, y))
        centrosomes()
        for x, y, token, side in spots:
            _chromosome(g, x, y, token, s, chevron=-side)


def _division(g, p, result, view, mode="mitosis"):
    stage = int(p["stage"])
    cells = bio_division.cells(mode, stage)
    how = ARRANGE[(mode, stage)]
    layout = {1: [(W / 2, H / 2, 62, 42)], 2: [(74, H / 2, 50, 40), (190, H / 2, 50, 40)], 4: [(36 + i * 64, H / 2, 28, 36) for i in range(4)]}[len(cells)]
    scale = {1: 1.0, 2: .88, 4: .74}[len(cells)]
    for (cx, cy, rx, ry), tokens in zip(layout, cells):
        _cell(g, cx, cy, rx, ry, tokens, how, scale)


# ---------------------------------------------------------------- 棋盘、曲线、金字塔、食物网
def _cross(g, p, result, view):
    father, mother = p["father"], p["mother"]
    gx, gy, hw, hh, cw, ch = 62, 11, 26, 20, 50, 35
    _text(g, QRectF(8, 18, 50, 14), LEFT, "父本")
    _text(g, QRectF(8, 32, 50, 20), LEFT, father, 15, T.fg, 700)
    _text(g, QRectF(8, 60, 50, 14), LEFT, "母本")
    _text(g, QRectF(8, 74, 50, 20), LEFT, mother, 15, T.fg, 700)
    _text(g, QRectF(gx, gy, hw, hh), CENTER, "配子", 9)
    for i in range(2):
        _text(g, QRectF(gx + hw + i * cw, gy, cw, hh), CENTER, father[i], 12, T.c1, 700)
        _text(g, QRectF(gx, gy + hh + i * ch, hw, ch), CENTER, mother[i], 12, T.c2, 700)
    shown = recessive = 0
    for i in range(2):
        for j in range(2):
            genotype = "".join(sorted((father[i], mother[j])))
            dominant = "A" in genotype
            shown += dominant
            recessive += not dominant
            cell = QRectF(gx + hw + i * cw + 1.5, gy + hh + j * ch + 1.5, cw - 3, ch - 3)
            g.setPen(_pen(qc(T.c3 if dominant else T.c4, .8), 1.2))
            g.setBrush(qc(T.c3 if dominant else T.c4, .16 if dominant else .28))
            g.drawRoundedRect(cell, 5, 5)
            _text(g, cell, CENTER, genotype, 13, T.fg, 700)
    bar = QRectF(204, gy + hh + 1.5, 12, 2 * ch - 3)
    split = bar.height() * shown / 4
    g.setPen(Qt.PenStyle.NoPen)
    path = QPainterPath()
    path.addRoundedRect(bar, 4, 4)
    g.save()
    g.setClipPath(path, Qt.ClipOperation.IntersectClip)
    g.fillRect(QRectF(bar.x(), bar.y(), bar.width(), split), qc(T.c3, .8))
    g.fillRect(QRectF(bar.x(), bar.y() + split, bar.width(), bar.height() - split), qc(T.c4, .9))
    g.restore()
    if shown:
        _text(g, QRectF(220, bar.y() + max(0, split / 2 - 8), 40, 16), LEFT, f"显 {shown}/4", 10, T.fg)
    if recessive:
        _text(g, QRectF(220, bar.y() + split + max(0, (bar.height() - split) / 2 - 8), 40, 16), LEFT, f"隐 {recessive}/4", 10, T.fg)


def _curve(g, values, mark=None, axis=None, top=None, level=None, signed=False, color=None):
    """一条填了色的曲线。signed：0 以上、以下用两种颜色（净光合的盈亏）；level：一条水平参考线 (值, 标签)。"""
    color = color or T.c1
    left, right, up, down = 12, W - 12, 13, H - 21
    lo = min([0] + values)
    hi = max([top if top is not None else 1] + values) if not signed else max([1e-9] + values)
    if signed and lo < 0:
        hi = max(hi, -lo * .35)

    def px(i):
        return left + i / max(1, len(values) - 1) * (right - left)

    def py(v):
        return down - (v - lo) / max(1e-9, hi - lo) * (down - up)
    line = QPainterPath(QPointF(px(0), py(values[0])))
    for i, v in enumerate(values[1:], 1):
        line.lineTo(px(i), py(v))
    zero = py(0)
    area = QPainterPath(line)
    area.lineTo(right, zero)
    area.lineTo(left, zero)
    area.closeSubpath()
    g.setPen(Qt.PenStyle.NoPen)
    if signed:
        for clip, tint in ((QRectF(0, 0, W, zero), T.bio), (QRectF(0, zero, W, H - zero), T.c2)):
            g.save()
            g.setClipRect(clip, Qt.ClipOperation.IntersectClip)
            g.fillPath(area, qc(tint, .26))
            g.restore()
    else:
        shade = QLinearGradient(0, up, 0, down)
        shade.setColorAt(0, qc(color, .34))
        shade.setColorAt(1, qc(color, .03))
        g.fillPath(area, shade)
    g.setPen(_pen(qc(T.fg, .45 if lo < 0 else .25), 1, Qt.PenStyle.DashLine if lo < 0 else Qt.PenStyle.SolidLine))
    g.drawLine(QPointF(left, zero), QPointF(right, zero))
    if level is not None:
        g.setPen(_pen(qc(T.c2, .8), 1, Qt.PenStyle.DashLine))
        g.drawLine(QPointF(left, py(level[0])), QPointF(right, py(level[0])))
        _text(g, QRectF(left + 2, py(level[0]) + 1, 60, 13), LEFT, level[1], 9.5, T.c2)
    g.setBrush(Qt.BrushStyle.NoBrush)
    g.setPen(_pen(color, 2.2))
    g.drawPath(line)
    if mark is not None:
        x = left + min(1., max(0., mark[0])) * (right - left)
        y = py(min(hi, max(lo, mark[1])))
        g.setPen(_pen(qc(T.fg, .35), 1, Qt.PenStyle.DotLine))
        g.drawLine(QPointF(x, y), QPointF(x, zero))
        g.setPen(_pen(T.surface, 2))
        g.setBrush(qc(T.c2))
        g.drawEllipse(QPointF(x, y), 5, 5)
    if axis:
        _text(g, QRectF(left, H - 18, 120, 14), LEFT, axis[0], 9.5)
        _text(g, QRectF(right - 120, H - 18, 120, 14), RIGHT, axis[1], 9.5)


def _enzyme(g, p, result, view):
    values = result.get("values")
    if not values:
        return _text(g, QRectF(0, 0, W, H), CENTER, "记录读不出来", 11)
    if "mark" in result:
        return _curve(g, values, result["mark"], result.get("axis"))
    _curve(g, values, (min(80, max(0, p["temperature"])) / 80, float(result["rows"][0][1])), ("0 ℃", "80 ℃"))


def _photosynthesis(g, p, result, view):
    values = result.get("values")
    if not values:
        return _text(g, QRectF(0, 0, W, H), CENTER, "记录读不出来", 11)
    _curve(g, values, result.get("mark"), ("光强 0", "2000"), signed=True, color=T.bio)
    _text(g, QRectF(12, 3, 120, 13), LEFT, "净光合", 9.5)


def _population(g, p, result, view):
    _curve(g, result["values"], (p["time"] / 20, float(result["rows"][0][1])), ("t = 0", "20"), top=p["capacity"] * 1.12, level=(p["capacity"], "K"), color=T.c3)


def _foodweb(g, p, result, view):
    energies = result["values"]
    full, cx, h, gap = 150, 176, 23, 6
    y = (H - 3 * h - 2 * gap) / 2
    for i, (name, color) in enumerate((("第三营养级", T.c2), ("第二营养级", T.c4), ("第一营养级", T.bio))):
        energy = energies[2 - i]
        width = max(4, full * energy / max(1e-9, energies[0]))
        g.setPen(_pen(qc(color), 1.2))
        g.setBrush(qc(color, .38))
        g.drawRoundedRect(QRectF(cx - width / 2, y, width, h), min(4, width / 2), min(4, width / 2))
        _text(g, QRectF(10, y, 84, 12), LEFT, name, 9.5)
        _text(g, QRectF(10, y + 11, 84, 13), LEFT, _num(energy), 11, T.fg, 700)
        y += h + gap


def _network(g, p, result, view):
    flows = result["network"]
    nodes = [(W / 2, 17, "草", T.bio), (66, H / 2, "兔", T.c4), (W - 66, H / 2, "鼠", T.c4), (W / 2, H - 17, "鹰", T.c2)]
    eaten = [flows[1], flows[2], flows[1] * p["eat_rabbit"] * p["efficiency"], flows[2] * p["eat_mouse"] * p["efficiency"]]
    for (a, b), flow in zip(((0, 1), (0, 2), (1, 3), (2, 3)), eaten):
        ax, ay = nodes[a][:2]
        bx, by = nodes[b][:2]
        length = math.hypot(bx - ax, by - ay)
        ux, uy = (bx - ax) / length, (by - ay) / length
        width = 1 + 5 * math.sqrt(max(0., flow) / max(1e-9, flows[1] + flows[2]))
        start, tip = QPointF(ax + ux * 20, ay + uy * 12), QPointF(bx - ux * 22, by - uy * 13)
        g.setPen(_pen(qc(T.fg, .5), width))
        g.drawLine(start, tip)
        g.setPen(_pen(qc(T.fg, .5), 1.4))
        for sign in (-1, 1):
            g.drawLine(tip, QPointF(tip.x() - ux * 7 + sign * uy * 4.5, tip.y() - uy * 7 - sign * ux * 4.5))
    for (x, y, name, color), value in zip(nodes, flows):
        g.setPen(_pen(color, 1.4))
        g.setBrush(qc(T.surface))
        g.drawRoundedRect(QRectF(x - 17, y - 10.5, 34, 21), 10, 10)
        g.setBrush(qc(color, .22))
        g.drawRoundedRect(QRectF(x - 17, y - 10.5, 34, 21), 10, 10)
        _text(g, QRectF(x - 17, y - 10.5, 34, 21), CENTER, name, 12, T.fg, 700)
        side = QRectF(x + 21, y - 8, 70, 16) if x >= W / 2 else QRectF(x - 91, y - 8, 70, 16)
        _text(g, side, LEFT if x >= W / 2 else RIGHT, _num(value), 10.5)


def _microscope(g, p, result, view):
    box = QRectF((W - VIEW) / 2, (H - VIEW) / 2, VIEW, VIEW)
    if view is not None:        # 目镜里看到的：四周是镜筒的黑
        g.fillRect(QRectF(0, 0, W, H), QColor("#0B0B0B"))
        g.drawImage(box, view)
        return
    g.fillRect(QRectF(0, 0, W, H), qc(T.fg, .06))
    # 没有装片的旧卡片：只示意「倍数越大，看到的范围越小」，不是真实视野
    ring = QPainterPath()
    ring.addEllipse(box)
    g.save()
    g.setClipPath(ring, Qt.ClipOperation.IntersectClip)
    g.fillRect(box, QColor("#F2EFE2"))
    scale = max(.3, p["magnification"] / 100)
    cw, ch = 24 * scale, 9 * scale
    g.setPen(_pen(QColor(86, 104, 70, 190), max(.7, min(2., scale * .9))))
    row, y = 0, box.y() - ch
    while y < box.bottom() + ch:
        x = box.x() - cw * (1.5 if row % 2 else 1)
        while x < box.right() + cw:
            g.drawRoundedRect(QRectF(x, y, cw, ch), min(3., ch / 3), min(3., ch / 3))
            x += cw
        y += ch
        row += 1
    g.restore()
    g.setPen(_pen(QColor("#1A1A1A"), 4))
    g.setBrush(Qt.BrushStyle.NoBrush)
    g.drawEllipse(box.adjusted(1, 1, -1, -1))
    _text(g, QRectF(W - 60, H - 19, 52, 14), RIGHT, "示意", 9.5)


# ---------------------------------------------------------------- 素材栏的小图标（28×28）和首页横幅
SUBS = {"microscope": "制片 · 调焦 · 观察", "plant": "结构示意 · 可点选", "animal": "结构示意 · 可点选", "mitosis": "6 个时期 · 可核对",
        "meiosis": "8 个时期 · 可核对", "cross": "棋盘法 · 分离比", "enzyme": "5 种酶 · 预处理", "photosynthesis": "总光合 · 呼吸 · 净",
        "population": "S 形增长 · K 值", "foodweb": "能量金字塔", "energy_network": "分支食物网"}

# 首页「自由工作台」横幅上的插图：一个植物细胞 + 一个分裂中期的细胞
ART = ('<svg viewBox="0 0 160 110"><rect x="0" y="92" width="160" height="18" fill="currentColor" opacity=".08"/>'
       '<rect x="9" y="22" width="70" height="62" rx="10" fill="#6aa52e" fill-opacity=".14" stroke="#6aa52e" stroke-width="3"/>'
       '<rect x="27" y="33" width="44" height="40" rx="13" fill="#4a9bd8" fill-opacity=".28" stroke="#4a9bd8" stroke-width="1.4"/>'
       '<circle cx="21.5" cy="70" r="7" fill="#a35a98" fill-opacity=".35" stroke="#a35a98" stroke-width="1.4"/><circle cx="22.5" cy="69" r="2.3" fill="#a35a98"/>'
       '<g fill="#6aa52e"><ellipse cx="34" cy="28" rx="5.5" ry="2.5"/><ellipse cx="52" cy="28" rx="5.5" ry="2.5"/><ellipse cx="69" cy="29" rx="5" ry="2.4"/>'
       '<ellipse cx="42" cy="78.5" rx="5.5" ry="2.5"/><ellipse cx="61" cy="78.5" rx="5.5" ry="2.5"/><ellipse cx="18" cy="40" rx="2.5" ry="5.5"/><ellipse cx="74.5" cy="52" rx="2.4" ry="5.5"/></g>'
       '<ellipse cx="120" cy="53" rx="33" ry="31" fill="#c98a00" fill-opacity=".12" stroke="currentColor" stroke-width="2.2"/>'
       '<path d="M92 53L120 36M92 53L120 53M92 53L120 70M148 53L120 36M148 53L120 53M148 53L120 70" fill="none" stroke="currentColor" stroke-width=".9" opacity=".35"/>'
       '<g fill="none" stroke-width="3.2" stroke-linecap="round"><path d="M116.5 30l7 12m0-12-7 12M117 65l6 10m0-10-6 10" stroke="#e0742a"/>'
       '<path d="M116.5 47l7 12m0-12-7 12" stroke="#3a8ed0"/></g>'
       '<circle cx="92" cy="53" r="2.2" fill="#c98a00"/><circle cx="148" cy="53" r="2.2" fill="#c98a00"/></svg>')


def icon(kind):
    """素材栏用的图标：一个 (painter, rect) 函数，和卡片封面是同一套画法的缩小版。"""
    def paint(g, rect):
        g.save()
        g.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        g.translate(rect.x(), rect.y())
        g.scale(rect.width() / 28, rect.height() / 28)
        _ICON[kind](g)
        g.restore()
    return paint


def _x(g, x, y, size, color, width=2.2):
    g.setPen(_pen(color, width))
    g.drawLine(QPointF(x - size * .3, y - size / 2), QPointF(x + size * .3, y + size / 2))
    g.drawLine(QPointF(x + size * .3, y - size / 2), QPointF(x - size * .3, y + size / 2))


def _icon_microscope(g):
    g.setPen(_pen(T.fg, 2.4))
    g.drawLine(QPointF(6, 24.5), QPointF(22, 24.5))
    arm = QPainterPath(QPointF(18.5, 24.5))
    arm.cubicTo(25, 19, 23, 9, 15.5, 6.5)
    g.setBrush(Qt.BrushStyle.NoBrush)
    g.setPen(_pen(T.fg, 2))
    g.drawPath(arm)
    g.drawLine(QPointF(6.5, 19.5), QPointF(17.5, 19.5))
    g.setPen(_pen(T.c6, 1.8))
    g.drawLine(QPointF(9, 17.8), QPointF(15, 17.8))
    g.save()
    g.translate(12.5, 10)
    g.rotate(-28)
    g.setPen(_pen(T.c1, 1.4))
    g.setBrush(qc(T.c1, .35))
    g.drawRoundedRect(QRectF(-2.9, -6.5, 5.8, 12.5), 1.6, 1.6)
    g.setBrush(qc(T.c1))
    g.drawRoundedRect(QRectF(-2, -9, 4, 2.6), 1, 1)
    g.restore()


def _icon_plant(g):
    g.setPen(_pen(T.bio, 2.2))
    g.setBrush(qc(T.bio, .14))
    g.drawRoundedRect(QRectF(2.5, 5, 23, 18), 4, 4)
    g.setPen(_pen(T.c6, 1.1))
    g.setBrush(qc(T.c6, .3))
    g.drawRoundedRect(QRectF(10, 8.5, 12.5, 11), 4, 4)
    g.setPen(Qt.PenStyle.NoPen)
    g.setBrush(qc(T.c5))
    g.drawEllipse(QPointF(7, 18.5), 2.6, 2.6)
    g.setBrush(qc(T.bio))
    for x, y in ((6.5, 9), (7, 13.5), (13, 21.2), (19, 21.2)):
        g.drawEllipse(QPointF(x, y), 1.9, 1.3)


def _icon_animal(g):
    points = [(14 + 11.5 * r * math.cos(i * math.pi / 5), 14 + 9.5 * r * math.sin(i * math.pi / 5)) for i, r in enumerate((1, .93, 1.04, .96, 1.05, .95, 1.02, .92, 1.05, .97))]
    g.setPen(_pen(qc(T.fg, .85), 1.7))
    g.setBrush(qc(T.c2, .12))
    g.drawPath(_smooth(points))
    g.setPen(_pen(T.c5, 1.2))
    g.setBrush(qc(T.c5, .3))
    g.drawEllipse(QPointF(12.5, 14), 4.6, 4.2)
    g.setPen(Qt.PenStyle.NoPen)
    g.setBrush(qc(T.c5))
    g.drawEllipse(QPointF(13.3, 14.4), 1.5, 1.5)
    _capsule(g, 20, 10.5, 2.6, 1.4, -30, qc(T.c2, .5), T.c2)
    _capsule(g, 19.5, 18.5, 2.6, 1.4, 25, qc(T.c2, .5), T.c2)


def _icon_mitosis(g):
    g.setPen(_pen(qc(T.fg, .85), 1.7))
    g.setBrush(qc(T.c4, .12))
    g.drawEllipse(QPointF(14, 14), 12, 10)
    g.setPen(_pen(qc(T.fg, .3), .8))
    for y in (9.5, 18.5):
        g.drawLine(QPointF(3.5, 14), QPointF(14, y))
        g.drawLine(QPointF(24.5, 14), QPointF(14, y))
    _x(g, 14, 9.5, 6.5, T.c2)
    _x(g, 14, 18.5, 6.5, T.c1)


def _icon_meiosis(g):
    for i, (x, y) in enumerate(((8, 8), (20, 8), (8, 20), (20, 20))):
        g.setPen(_pen(qc(T.fg, .85), 1.5))
        g.setBrush(qc(T.c4, .12))
        g.drawEllipse(QPointF(x, y), 5.4, 5.4)
        g.setPen(_pen(T.c2 if i in (0, 3) else T.c1, 2))
        g.drawLine(QPointF(x - 1.2, y - 2.4), QPointF(x + 1.2, y + 2.4))


def _icon_cross(g):
    for i in range(2):
        for j in range(2):
            recessive = i == j == 1
            g.setPen(_pen(T.c4 if recessive else T.c3, 1.3))
            g.setBrush(qc(T.c4 if recessive else T.c3, .45 if recessive else .22))
            g.drawRoundedRect(QRectF(3.5 + i * 11, 3.5 + j * 11, 10, 10), 2.5, 2.5)


def _icon_curve(g, points, color, level=None):
    line = QPainterPath(QPointF(*points[0]))
    for i in range(1, len(points) - 2, 3):
        line.cubicTo(*points[i], *points[i + 1], *points[i + 2])
    area = QPainterPath(line)
    area.lineTo(points[-1][0], 23.5)
    area.lineTo(points[0][0], 23.5)
    g.fillPath(area, qc(color, .22))
    g.setPen(_pen(qc(T.fg, .4), 1))
    g.drawLine(QPointF(3, 23.5), QPointF(25, 23.5))
    if level is not None:
        g.setPen(_pen(qc(T.c2, .9), 1, Qt.PenStyle.DashLine))
        g.drawLine(QPointF(3, level), QPointF(25, level))
    g.setBrush(Qt.BrushStyle.NoBrush)
    g.setPen(_pen(color, 2))
    g.drawPath(line)


def _icon_enzyme(g):
    _icon_curve(g, [(3, 22), (9, 21), (13, 14), (15.5, 6), (17, 3), (17.5, 22), (25, 22.5)], T.c1)


def _icon_photosynthesis(g):
    _icon_curve(g, [(3, 23), (5, 12), (12, 9), (25, 8)], T.bio)
    g.setPen(Qt.PenStyle.NoPen)
    g.setBrush(qc(T.c4))
    g.drawEllipse(QPointF(20.5, 17), 2.6, 2.6)
    g.setPen(_pen(T.c4, 1.1))
    for i in range(8):
        a = i * math.pi / 4
        g.drawLine(QPointF(20.5 + 3.8 * math.cos(a), 17 + 3.8 * math.sin(a)), QPointF(20.5 + 5.2 * math.cos(a), 17 + 5.2 * math.sin(a)))


def _icon_population(g):
    _icon_curve(g, [(3, 22), (11, 21.5), (12, 8), (25, 7.5)], T.c3, 5.5)


def _icon_foodweb(g):
    for width, y, color in ((5, 4.5, T.c2), (13, 11.5, T.c4), (22, 18.5, T.bio)):
        g.setPen(_pen(color, 1.2))
        g.setBrush(qc(color, .4))
        g.drawRoundedRect(QRectF(14 - width / 2, y, width, 5.5), 1.6, 1.6)


def _icon_network(g):
    nodes = ((14, 4.5, T.bio), (5, 14, T.c4), (23, 14, T.c4), (14, 23.5, T.c2))
    g.setPen(_pen(qc(T.fg, .55), 1.4))
    for a, b in ((0, 1), (0, 2), (1, 3), (2, 3)):
        g.drawLine(QPointF(*nodes[a][:2]), QPointF(*nodes[b][:2]))
    for x, y, color in nodes:
        g.setPen(_pen(color, 1.3))
        g.setBrush(qc(T.raised))
        g.drawEllipse(QPointF(x, y), 3.4, 3.4)
        g.setBrush(qc(color, .45))
        g.drawEllipse(QPointF(x, y), 3.4, 3.4)


def _icon_undo(g):
    path = QPainterPath(QPointF(8, 10.5))
    path.lineTo(16.5, 10.5)
    path.cubicTo(24, 10.5, 24, 21, 16.5, 21)
    path.lineTo(9.5, 21)
    g.setBrush(Qt.BrushStyle.NoBrush)
    g.setPen(_pen(T.fg, 2))
    g.drawPath(path)
    g.drawLine(QPointF(8, 10.5), QPointF(12, 6.5))
    g.drawLine(QPointF(8, 10.5), QPointF(12, 14.5))


_ICON = {"microscope": _icon_microscope, "plant": _icon_plant, "animal": _icon_animal, "mitosis": _icon_mitosis, "meiosis": _icon_meiosis,
         "cross": _icon_cross, "enzyme": _icon_enzyme, "photosynthesis": _icon_photosynthesis, "population": _icon_population,
         "foodweb": _icon_foodweb, "energy_network": _icon_network, "undo": _icon_undo}

_PAINT = {"plant": _plant, "animal": _animal, "mitosis": _division, "meiosis": lambda g, p, result, view: _division(g, p, result, view, "meiosis"),
          "cross": _cross, "enzyme": _enzyme, "photosynthesis": _photosynthesis, "population": _population, "foodweb": _foodweb,
          "energy_network": _network, "microscope": _microscope}
