"""全部实验与工作台模块（显式 import，打包工具才看得见；导入时各自注册）。新增文件要加在这里，selftest 会查漏。"""
from .benches import apparatus_model, chem, chem_model, circ, geo, geo_construct, geo_core, geo_draw, mech, scene, scene_core, scene_types1, scene_types2, scene_types3, bio, bio_model  # noqa: F401
from .benches import circuit_devices, separation, measurements, scene_types4, cell_detail  # noqa: F401
from .benches import chem_titration, chem_equations  # noqa: F401
from .benches import bio_scope, bio_scope_view, bio_slide, bio_tissue  # noqa: F401
from .benches import bio_enzyme, bio_photo, bio_division, bio_cover  # noqa: F401
from .benches import geo_calc  # noqa: F401
from .exps import bio1, bio2, bio3, bio4, bio5, chem1, chem2, chem3, chem4, chem5, math1, math2, math3, math4, math5, phys1, phys2, phys3, phys4, phys5, phys6  # noqa: F401
