# 化学实验台真实性：GPT 首批进展

2026-11-13。基于 0.3.5，未升版本、未打包。与 Claude 的生物任务分开进行。

**当前已推进到第二批，最新状态见本文末尾。前面的“尚未完成”是第一批历史，不代表当前状态。**

## 已实施

- 新增 `app/native/lab/benches/chem_titration.py`：理想滴定管刻度、初始读数、单次实收计量、容量限制、换接收容器/补液后的计量失效检查。
- `chem.py` 的滴定操作先记录初始读数，开始本轮接收液曲线；实际物料转移后按真实体积差记账。读数从上到下增大，界面显示初始/当前读数和本轮实收体积。
- 滴定拒绝无接收容器、自我接收、尚在加液/倾倒、管内含固体/沉淀或两相的情形。接收容器装满不继续扣减源液。
- 通用倾倒转移容量扣除尚在加入的排队液体，避免与加液动画抢占容量。
- 滴定管增加 0–50 mL 刻度；水相表面增加弯月面表现，不改变原工作台结构。
- 修复化学台恢复快照后检查器仍绑定旧对象的问题；重建检查器后再操作会修改恢复后的状态。清空容器清除旧滴定记录/曲线。

## 验证

输出目录：`F:\space for Claude\jianwei\verify-chem-realism-2026-11-13`。

- `native.kit.chem_realism_selftest`：29 项通过，`TEST_PROCESS_EXIT 0`。包括非零初始读数、物料/体积转移、25 mL 0.1 mol/L HCl 被同浓度 NaOH 滴至等量点、过量后 pH、接收容量、保存恢复后的真实按钮和状态、昼夜/窄窗绘制。
- `native.kit.apparatus_selftest`：通过，11 项器材放置与既有气体/计量/存档检查，退出码 0。
- `native.kit.models29_selftest`：通过，分离装置守恒、电学参考及快照回归，退出码 0。
- 已查看 `final/chem-titration-day.png` 和 `final/chem-titration-night-narrow.png`；修正初版新增读数区域的文字拥挤，最终版读数与说明不重叠。
- 测试使用隔离 `JIANWEI_HOME`/`LOCALAPPDATA`，没有使用真实密钥。

复现专项：使用 `jianwei/.venv/Scripts/python.exe`，cwd=`src2/app`，设置离屏和隔离变量后执行 `-m native.kit.chem_realism_selftest <输出目录>`。

## 尚未完成

- 此切片假设滴定管尖已充液、无气泡；未实现润洗、气泡体积、视差、连续活塞流量、终点保持时间和更完整操作流程。说明已写在界面。
- 滴定刻度为适合当前总览尺寸的简化刻度，尚无供估读 0.01 mL 的放大读数视图；两位小数为模型读数，不能声称已经实现人工估读。
- 方程式结构化与全量科学审查、真实平衡常数查证尚未完成；未改变已有反应方程式/常数，不能把滴定专项通过当成全化学模型准确性认证。
- 器材完整写实材质、装置连接/错误操作和生物功能不在本次已完成范围内。
- 暂未将新专项加入总自测与发行预期清单。新 helper 被 `chem.py` 显式引用，不是新增实验注册项；统一发行时汇总处理测试接入。
- 尚未运行全量自测、冻结版与真实鼠标验收。

## 计量规程参考

- Florida State University 化学实验室，Burets：https://www.chem.fsu.edu/chemlab/glassware/glassware.html
- Purdue 化学实验室，Cleaning the Buret：https://chemed.chem.purdue.edu/genchem/lab/equipment/buret/use.html

下一步先补齐滴定操作状态和方程式记录审查，再扩展气体/分离装置；由 GPT 统一接入 Claude 的生物成果，最后核对最新版本并发行。

## 第二批：操作、科学模型与器材画面（2026-11-13）

### 已完成

1. **滴定操作训练**：新滴定管默认启用，旧存档保留理想模式且可主动启用训练。清水/溶液润洗、实际排入废液、保留0.10mL残液；下一次装液与残液真实混合。反复用滴定液润洗后，残水引起的稀释逐步减小。
2. **管尖空隙**：本台器材采用0.12mL教学标定空隙；管内V包含全部水相，`tip_ml`只是其中位于无刻度管尖的部分，不另外创造液体。未排气就记录初读数时，管上读数差会大于实收量；正确排气后再记录，两者一致。
3. **活塞与位置**：连续流量受开度和液头影响，标定关系为 `2 × 开度² × sqrt(刻度管液量/50)` mL/s。单次滴加与连续流液共用真实物料转移。固定滴定管时画出支架、夹持和管尖；移动接收瓶不会拖走支架，不对准时停止转移并提示重新定位。隐藏/最小化停止实验推进；恢复存档先关活塞。
4. **终点与曲线**：图中有pH/实收体积坐标与刻度；长轨迹压缩时保留起点。酚酞变色状态保持计时和终点记录可保存；颜色终点不冒充化学等量点。尚无人工视差/估读模拟。
5. **溶液稀释**：侧栏可将水溶液按标签浓度的0.05–1倍用水配制。实际浓度和所加体积进入计算，不影响指示剂、水或有机溶剂。新增“酸碱滴定 · 操作训练”示例，从25mL、0.1mol/L盐酸样品开始完整流程。
6. **制氧/收气**：新器材明确加塞状态和接口漏气比例；产气、捕集/吸收、未收集量分别记账。新集气瓶的排水收集要先“注满水并倒置”，进入H₂/O₂实际排开等体积清水并记录排水量，容量有上限。串联洗气/收集/漏气合计守恒。旧存档未包含这些字段时按旧理想条件兼容。收集到的气体可用于原有检验按钮。
7. **科学修正**：银氨初始沉淀改为棕褐色Ag₂O，相应溶解方程式改为Ag₂O与氨的配合溶解；铁硫氰反应采用单配体 `[FeSCN]²⁺` 平衡，游离铁、游离SCN、配合物、沉淀共同守恒。颜色、检验事件和主要粒子读数使用同一份平衡结果。
8. **反应式解析**：新增`chem_equations.py`，解析化学计量、括号、水合物、电荷、可逆性和条件；核对96条表达式的元素与电荷守恒。记录显示反应箭头及加热/催化条件。配平通过不等于已经验证全部反应条件或常数。
9. **画面**：玻璃横向透光/边缘高光、较清澈的无色液体、弯月面、气泡反光、实际滴液动画、刻度/活塞/铁架台、导气管与水槽。修正固定滴定管与接收瓶的文字重叠；水槽集气瓶区分剩余水和气体体积。量筒、滴定管、容量瓶、试剂瓶、集气瓶不再允许直接放到酒精灯上加热。

### 文件与共享接入

- 改`chem.py`、`chem_model.py`、`chem_titration.py`、`apparatus_model.py`；新增`chem_equations.py`。
- 专项：`chem_realism_selftest.py`、`chem_science_selftest.py`、`chem_procedure_selftest.py`、`chem_gas_selftest.py`。
- 四组已加入`app/main.py --self-test`和`tools/release.py smoke`预期清单；发行OUT/TAG和版本号未变。
- `lab/all_modules.py`登记化学两个helper，也按Claude交接登记`bio_scope`、`bio_scope_view`、`bio_slide`、`bio_tissue`；`native/selftest.py`冻结版required对应增加。未改生物实现。
- 恢复化学存档时重新求平衡，旧缓存不会遮住新铁硫氰结果；恢复后检查器绑定正确对象。

### 实际验证

目录：`F:\space for Claude\jianwei\verify-chem-phase2-2026-11-13`。

- `final/verification.json`：化学科学、旧滴定、操作训练、气体训练、原有器材、原有分离/电学模型六组通过，进程退出0。
- 科学组：96条表达式配平，铁/SCN物料、电荷与表观形成常数基准，稀释和碱性沉淀，以及弱酸缓冲基准。
- 旧滴定29项；操作训练37项；气体训练30项。完整滴定流程由真实试剂/操作按钮完成，滴至25.02mL、稳定变色、记录终点、再实际过滴；测试未用固定pH替代流程结果。
- 原有器材组11项器材与气体/滴定基准通过，分离/电学`models29`回归通过。
- 化学台素材、全部可达检查器按钮及昼夜绘制走查：`traversal-final`，`SELFTEST OK 0 experiments 1 benches`、退出0。早一次查漏失败来自并行新增生物helper未登记，已完成登记并重跑通过。最后收尾的位置判定和标签改动由最终专项覆盖。
- 三种皮肤、昼夜、1440×900与1000×620截图已生成；查看了滴定与制氧截图。全部是离屏/程序操作，不冒称真人鼠标验收。
- 相关化学文件pyflakes通过；数据目录隔离，无真实密钥、无联网课堂或Office进程。

### 仍有边界

- 残液、管尖容积、活塞流量和酚酞观察范围是明确的教学器材参数，不是所有真实器材的通用定标。
- 未模拟滴定管视差、人工估读、温度引起的容量校正、真实活塞黏度和液滴尺寸分布。移开接收瓶时当前停止转移，不模拟台面泄漏/污染扩散。
- 气路仍是单路串联：未模拟初始空气、气体纯度、气液压差、水蒸气校正、气体溶解动力学。排水只支持清水中的H₂/O₂；漏气是输入比例，不是由孔径/压差求解。
- 铁硫氰用单配体表观常数890 L/mol，忽略高阶配合和介质/温度修正；其他原有放大常数与经验速率未全量替换。
- 分离装置仍是独立理想样品，尚未与台面所有试剂互通；固定化学实验未全量升级。没有完整三维渲染。
- 尚未重跑整套应用全部自测、冻结版自测、真人鼠标验收或发行新zip。

### 科学资料

- 滴定管润洗/排气/初读数：[FSU Burets](https://www.chem.fsu.edu/chemlab/glassware/glassware.html)、[Purdue Use of the Buret](https://chemed.chem.purdue.edu/genchem/lab/equipment/buret/use.html)。
- 铁硫氰的配合物与可逆变化：[Harvard教学演示](https://sciencedemonstrations.fas.harvard.edu/presentations/equilibrium-iron-iii-thiocyanate)、[Purdue Combined Equilibria](https://chemed.chem.purdue.edu/genchem/topicreview/bp/ch18/combine.php)。常数参考：[UCSC实验规程](https://www.webassign.net/question_assets/ucscgencheml1/updated_labs2020/lab-17-procedure-2023.pdf)。
- Ag₂O/氨反应：[银离子特征反应](https://chem.libretexts.org/Bookshelves/Analytical_Chemistry/Supplemental_Modules_%28Analytical_Chemistry%29/Qualitative_Analysis/Characteristic_Reactions_of_Select_Metal_Ions/Characteristic_Reactions_of_Silver_Ions_%28Ag%29)。
- 制氧与气体收集：[Royal Society of Chemistry教学实验](https://edu.rsc.org/experiments/generating-collecting-and-testing-gases/693.article)。
