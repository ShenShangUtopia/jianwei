# 见微 0.3.5 · 时间胶囊与观澜的版式 · 交接（2026-11-13）

用户的要求（原话）："more layout for Guanlan and Time capsule"。我给了草图选项，用户回 "pick some or all, it's up to you"，于是各加了三种。
**原来的样子仍是默认**，老用户什么都不改看到的还是一样。

`store.VERSION` 仍是 **0.3.5**，没有升版本、没有正式发行；只出了一个**测试包**（见第 6 节）。

---

## 1. 一眼看懂

| | 配置键（存在哪） | 可选值 | 默认 |
| --- | --- | --- | --- |
| 时间胶囊 | `pillLayout`（见微 `config.json`） | `bar` 横尺 · `tile` 方块 · `column` 竖条 · `mini` 迷你 | `bar` |
| 观澜 | `layout`（观澜自己的 `guanlan/config.json`） | `panel` 侧栏面板 · `paper` 宽版报纸 · `card` 新闻卡片 · `strip` 标题横条 | `panel` |

写错或没有这个键 → 回到默认（`countdown.pill_layout()`、`layouts.layout_name()`）。
三种风格（水墨 / 青瓷 / 手绘）× 昼夜，所有版式都跟着变。

## 2. 用户在哪里换

**胶囊**
- 右键胶囊 → 「版式」子菜单（发 action `layout:<名>`，`Shell._pill_action` → `Shell.set_pill_layout`）
- 设置 → 倒计时页，「外观与行为」卡片第一行的 4 个 Chip

**观澜**
- 观澜顶栏 ⋯ 菜单 → 「版式」子菜单
- 观澜设置层第一行的下拉框（`SettingsSheet.layout_requested`）
- 见微主程序「观澜」页右栏的「浮窗版式」卡片（`GuanlanHost.layout()` / `set_layout()`，浮窗开着就当场换）

## 3. 时间胶囊（`app/countdown.py`）

| 版式 | 尺寸（倍数 1） | 内容 | 默认位置 |
| --- | --- | --- | --- |
| 横尺 bar | 宽度 × 高度两个滑块 | 原样 | 顶上居中 |
| 方块 tile | 232 × 216 | 印 + 距几年高考 + 时钟；表盘圆环（金弧 = 走过的、月刻度、节点菱形、朱砂钉 = 今天），中间天数 / 时分 / 已走 %；底下一行「下一个节点 · 还有几天」，没节点就写日期 | 靠左 |
| 竖条 column | 96 × 548 | 印、天数、时分、第几周；尺从上往下（左边月份，右边刻度，横着的朱砂针 + 百分比）；底下时钟 + 日期 | 靠左 |
| 迷你 mini | 340 × 40 | 印、天数、一道细进度（节点菱形、终点竖线、今天的点）、时钟 | 顶上居中 |

要点：
- 非横尺版式的大小 = 「高度」滑块 / 60（`layout_scale`，夹在 0.8–1.5）。宽度滑块对它们无效，设置页会把它灰掉并给提示。
- 新的公共函数：`LAYOUTS`、`LAYOUT_NAMES`、`pill_layout`、`pill_size`、`centers_on_top`、`needle_pos`（任意版式「今天」的点，呼吸光画在这里）、`hover_day(x, y, …)`（方块没有尺，返回 None）、`next_milestone`。
- 描边和印抽成 `_draw_rim` / `_draw_seal`，横尺也改用它们（画面和以前一样）。
- `glow_rect` / `draw_pill_motion` 现在既接受横尺的 x（数），也接受 `QPointF`；老调用不用改。
- 换版式时 `pillX` 清空，回到这种版式的默认位置。拖动后「居中」只对横尺、迷你算数（`centers_on_top`）。
- 设置页的预览框高度跟着版式变（`PillPreview.sync_size`：横条 132、方块 250、竖条 360）。
- `store.DEFAULT_CONFIG` 加了 `pillLayout: "bar"`。

## 4. 观澜（`app/guanlan/ui/`）

新文件 **`layouts.py`**：`LAYOUTS` / `LAYOUT_NAMES` / `LAYOUT_TIPS` / `COMPACT`、`CardView`、`StripView`、`build_paper()`，以及 `DragArea`（能点也能拖，移动超过 4 像素才算拖）、`Dots`、`ColumnHead`、`VRule`。

| 版式 | 面板尺寸 | 说明 | 默认位置 |
| --- | --- | --- | --- |
| 侧栏面板 panel | 430 × 屏高 | 原样 | 右上 |
| 宽版报纸 paper | min(1000, 屏宽−40) × min(660, 屏高−24) | 顶栏 / 三栏：左「今日焦点」（标题、焦点、关键词、词典、筛选说明）· 中「世界线索」（按栏目的全部新闻）· 右 人物 / 金句 / 档案 三个标签页 / 底栏 | 右上 |
| 新闻卡片 card | 400 × 264 | 一次一条：栏目、标题、摘要、来源；底下 ‹ 圆点 › ⏸ | 右上 |
| 标题横条 strip | min(860, 屏宽−40) × 56 | 印 · 栏目标签 · 标题 · 第几条 · ‹ › ⏸ ⋯ | 屏幕底部居中 |

`window.py` 里改了什么：
- `_apply_layout_size()` 按版式定面板大小；`set_layout(name)` 和 `set_theme` 一样把整块面板拆掉重搭（数据、已读不丢）。
- 位置**每种版式各记一个键**：`panel_pos` / `pos_paper` / `pos_card` / `pos_strip`（`_pos_key()`）。
- 报纸：`TodayPage(parts=…)` 把今日页拆成两栏（`today_page` 左、`stories_page` 中）；标签页只剩 3 个，数字键 1–3 有效，4 不报错。
- 卡片 / 横条：面板那一套控件照样建（藏在 `_panel_holder`），因为阅读层、刷新状态、托盘等都挂在上面。
- **读全文**：卡片 / 横条太小，`_open_story` / `_open_filter` / `_open_settings` 先调 `_make_room()` 把窗口临时撑成 430 宽的面板（贴着原位置往屏幕里长）；所有阅读层的 `closed` 信号接 `_leave_room()` 缩回去。读的时候拖动，缩回去的卡片跟着挪。读的时候收起 → `_reading` 清零。
- 卡片 / 横条不会自己收起（`_idle_check` 跳过）。Ctrl+P 在这两种版式里就是「轮换开 / 关」，存 `rotate`；间隔 `rotate_seconds`（卡片 12 秒、横条 9 秒）；鼠标停在上面不换；手动换过重新计时。
- 报纸的自动播放：先把中栏线索滚三段，再看人物、金句（`_steps()`）。
- `setMinimumSize` 从 (80, 150) 改成 (80, 60)，否则横条放不下。
- 索引写死的地方改成认页面：`_tab_changed` 认 `archive_page`、`_arrow` 认 `people_page`。

**报纸窄栏的坑（已处理）**：面板里的卡片是按 430 宽设计的，单行 QLabel（人名、英文名、来源行）和成排的标签会把卡片撑出栏外、被截掉。现在 `ScrollPage.narrow = True` 时：
- `relax()` 把单行 QLabel 改成能折行（TodayPage、PeoplePage、QuotesPage 重建内容后都会调）；
- 关键词按 250 宽截，人物的品质标签按 220 宽截；
- 词典卡隐藏英文名（`TermCard.en`），不然中文词条被挤成一字一行；
- 左右栏宽度随面板收：左 min(330, 33%)、右 min(300, 30%)。

## 5. 测试（都实际跑过）

- `app/panels_selftest.py <干净目录>`：107 → **150 项全过**。新增的覆盖：四种胶囊版式尺寸 / 今天的点 / 悬停取日 / 竖条窗口默认靠左 / 右键版式菜单；观澜三种版式的大小、内容分栏、数字键、卡片撑大读全文再缩回、轮换开关、不会自己收起、横条默认在下半屏、设置撑大再缩回、换主题保持版式、换回面板；见微观澜页和倒计时页的 Chip 能换。
  **必须用干净目录**，同一目录连跑会有 5 项假失败（老问题）。
- `python -m native.design.selftest`：过。
- 冻结版自测（测试包里跑全部自测）：35 项全 OK。
- 截图：`jianwei\验收-版式-2026-11-13\`（离屏渲染，虚拟屏只有 800 宽，所以报纸是最窄的 760 宽版本；观澜用的是用户真实今日版的**副本**）。
- 离屏脚本结尾 `os._exit` 报 0xC0000005 是退出时的假象，不是错误。

## 6. 测试包（不是正式发行）

- 用 scratchpad 里的小包装脚本调 `tools/release.py` 的 build → smoke → pack，只把 `OUT` / `TAG` 改到 `jianwei\release-0.3.5-test-2026-11-13\`。**release.py 本身没改**；它写死的正式目录 `release-0.3.5-2026-11-12` 没动。
- 绿色版 zip 已拷到桌面：`AI\jianwei\见微-绿色版-2026-11-13-v0.3.5-layouts-test.zip`（约 257 MB）。
- 不解压直接跑：`jianwei\release-0.3.5-test-2026-11-13\source-final\dist\Jianwei\Jianwei.exe`。
- 下次正式发行时：升 `store.VERSION`，改 release.py 的 `OUT` / `TAG`，写 RELEASE-0.3.x.md（内容可以抄本文件第 1–4 节）。

## 7. 没做 / 要注意

- **真人鼠标验收没做**：真窗口里拖动各版式、卡片 / 横条撑大读全文时的位置、真壁纸上的胶囊磨砂效果、1920 宽屏上的报纸（只看过 760 宽）、多显示器。
- 竖条 / 方块贴屏幕边时不会自动吸边（只有横尺、迷你吸屏幕中线）。
- 报纸在比 760 更窄的屏上没试。
- 胶囊方块版没有「悬停看某一天」（没有直尺可指）。
- 动过的共享文件（如果 GPT 同时在改，合并时留意）：`countdown.py`、`shell.py`（`center_pill`、`set_pill_layout`、`_pill_action`）、`pages.py`（`PillPreview`、`build_countdown`、`build_guanlan`）、`store.py`（一个默认键）、`guanlan_host.py`、`guanlan/ui/{window,pages,cards,sheets}.py`、`panels_selftest.py`。
- 生物部分和胶囊跟随风格的交接仍在 `HANDOFF-0.3.5-后续-2026-11-13.md`。
