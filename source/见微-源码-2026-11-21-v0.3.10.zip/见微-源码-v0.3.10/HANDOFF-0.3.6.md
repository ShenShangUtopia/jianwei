# 见微 0.3.6 · 交接（2026-11-15）

`store.VERSION` = **0.3.6**。源码改完、自测过；**已打包**（2026-11-15）：`E:\space for Claude\jianwei\release-0.3.6-2026-11-15\`，`见微-绿色版-2026-11-15-v0.3.6.zip`（271 MB）、`见微-源码-2026-11-15-v0.3.6.zip`（2 MB）；`tools/release.py` build → smoke（冻结版自测全过）→ pack。查过产物里没有 `.env` 文件、没有像密钥的字符串。这台机器没有 F 盘，产物留在发行目录，没复制到别处。
用户说明见 `RELEASE-0.3.6.md`。接手先读这份，再看总交接 `HANDOFF.md`。

## 0. 环境变了（先看）

- 工作区现在在 **E 盘**：`E:\space for Claude\jianwei\src2`。这台机器**没有 F 盘**，旧文档里的 `F:\…` 路径都要换成 `E:\…`；`F:\AI\` 也不存在。
- 原来的 `.venv` 不在了，这一轮重建：
  - Python 3.12.10（和发行版打包的版本一致）用的是 python.org 发布的 **NuGet 包**，解压在 `E:\space for Claude\jianwei\python312-nuget\tools\python.exe`（没走安装器：安装器在这台机器上报 0x80070003 装不上）。
  - venv：`E:\space for Claude\jianwei\.venv`，装了 PySide6 6.12.0（和发行版一致）、requests、beautifulsoup4、pyinstaller、pyflakes。
- `Jianwei.spec` 里还写着 F 盘路径，但它是 `build.build()` 每次重新生成的，应该不碍事；**没在这台机器上打过包**，第一次打包时留意。

## 1. 这一轮做了什么

| 事项 | 状态 |
| --- | --- |
| 读文（文言文 / 英语逐字精读，新模式） | 做完；离屏自测 33 项 + 真窗口截图；**没连真 DeepSeek** |
| 必修 1「影响酶活性的因素」改用工作台酶模型 | 做完；遍历自测通过、截图看过 |
| 生物四模块登记 all_modules / 冻结版 required；生物、读文专项接总自测和 smoke | 做完 |
| 删 0.3.4 分栏死代码 | 做完（`ui_kit.split()` 本身留着，恒 False，已没人用） |
| 开着胶囊换风格的真窗口确认（0.3.5 后续遗留） | 做完：方印 / 花青 → 圆印 / 亮黄，当场变 |
| PDF 文字层部首字（新机器上全量自测查出来的） | 修了读取端：`pageview.clean_text` / `page_text`，课件框选取字、播放器查询提示都走它；课件、图解导出两组自测改用它比对 |

## 2. 读文的结构（`app/native/reading/`）

- `classical.py`：文言离线数据和标注。数据写成「字|词性·释义：例句《出处》|…」的文本块，`_parse` 读成 `SHICI` / `XUCI`；另有 `TONGJIA`、`GUJIN`、`GUDING`。`tokenize` 最长匹配多字词、其余逐字；`annotate(w)` 给一个字词的离线信息（`other` 是考纲义项列表）；`patterns` 只认有明显标志的句式；`_guess_xuci` 只在位置特征很明显时猜虚词用法（猜不准就不猜，`知之者` 里的「之」「者」就不猜）。**通假字离线只进 `other` 提示，不设 kind、不画线**（受、生、无、不这种字到处都是，画线会误导）。
- `english.py`：英语离线。`FUNC` 功能词表；`PHRASES` + `GAP`（短语各部分间最多隔几个词，成对连词 12、动副短语 1–3、其余 0）；`same()` 让短语里的动词能变形；`there be` 单独认；`tense()` 按助动词组合认时态语态；`CLAUSE_HEADS` 只说「可能的从句引导词」。
- `analyze.py`（不依赖 Qt）：
  - `split_sentences(text, ends)`：句末标点切句，引号括号跟上一句，英语跳过缩写（Mr. 等）和小数点，超过 160 字按逗号再切。
  - `complete()`：句子写完了吗（有句末标点，或光标不在这句里）。
  - `SYSTEM` 两套提示词、`prompt()`、`check()`（给 `llm.ask_json`，逐字 / 逐词必须和原文对上；对不上的句子在 fallback 里去掉 tokens，只留翻译句式）、`ask()`（repairs=1）。
  - `merge()` 把 AI 结果按原文重新算位置（`_align_wyw` / `_align_en`），文言 token 保留离线的考纲义项（`other`、`exam`）；英语按 `role` 归成 主干 / 修饰 / 从句引导 / 短语 四种颜色。
  - 缓存：`shared_cache()` 整个进程一份，文件 `reading-cache.json`（最多 3000 句）。请求线程在线程里就把结果写进缓存，页面被重建了结果也不丢。
- `page.py`：
  - `ReadEdit(QTextEdit)`：照常编辑；`paintEvent` 在 `super()` 之后画半透明的句子底色、选中字词底色、彩色短线（离线虚线、AI 实线）、正在精析的句子句尾一段点线。行距用 block format 185% / 170%，`spacing()` 里 blockSignals，否则会和 textChanged 互相触发。
  - `ReadingPage(compact=False)`：顶栏（语种 Segmented、状态、示例 / 清空 / 精析全文）+ QSplitter（编辑区 + 图例 | QTextBrowser 详解）。`_off` 200 ms 离线、`_ai` 1.4 s 送精析；一次只跑一个 `Worker`，跑完自己接着排下一批。`set_text(text, lang=None)` 给外部送文字用（不给语种按汉字比例猜）。草稿 `reading-draft.json`。
  - `_ALIVE` 集合保住还在跑的 QThread（主窗口换皮肤会重建页面）；`aboutToQuit` 时 `stop()` 等线程。
  - 字体：文言 `tokens.family("serif")`；英语 `text_family("en")` 挑 Georgia / Cambria…（通用名 serif 在这台机器上会落到打字机字体）。页面样式表前面拼了 `design.widgets.qss()`，所以放进主窗口按键也是学习窗口那套；qss 里 `QTextEdit{font-size:13px}` 会盖掉 setFont，所以编辑区的字号写在 `QTextEdit#readEdit` 规则里。
- 接入：
  - 学习窗口 `main_win.py`：`MODES` 在析题后加 `reading`，**快捷键改用 `MODE_KEYS` 显式编号**（读文 Ctrl+7，其余不变；课堂自测检查 Ctrl+6 = 课堂）。
  - 主窗口：`shell.NAV` 在课件后加 `reading`（学习组），`_builders["reading"] = pages.build_reading`（Page 里放一个 `ReadingPage(compact=True)`）；`Shell.read_text(text)` 给模块用。
  - 模块：`modules.SPEC["reading"]`、`ORDER`、`Desktop.GRID` 第 4 行通栏。
  - 图标 `design/icons.py` 的 `reading`（摊开的书）。快捷键表 `kit/quick_open.py` 加了 Ctrl+7。
- 自测：`python -m native.reading.selftest <目录>`，已接进 `main.py --self-test`（标签 `reading`）和 `tools/release.py` 的 smoke 预期。

## 3. 没做 / 没验证

1. **真 DeepSeek 已测（2026-11-15，用户临时放的密钥，测完已删）**：文言 6 句、英语 4 句（含 I'm、Mr.、3.5、well-known、there be、Not until 倒装）。
   - 第一版：文言全部一次对齐、质量好（受通授、军名作动、定语后置都对），一批 3 句约 7 s；英语 I'm 那句修一次仍对不上，另外模型的 `phrase` 填得很宽，下划线几乎全是「短语」色。
   - 修了：英语比对改成只比字母数字（`_letters`），`_align_en` 按字母逐个分配；颜色先看成分，「短语」只给离线 PHRASES 也认出的搭配；介词宾语不算主干；提示词加第 3 条限制 phrase。之后 10 句全部一次对齐，英语一批约 9 s。
   - `llm.settings()` 现在兼容 deepseek.env 里只写一行 `sk-…`（没写 `DEEPSEEK_API_KEY=`）和带 BOM 的文件。
   - **打包不许带密钥（用户明确要求）**：密钥只在 `%LOCALAPPDATA%\Jianwei\deepseek.env`，不在源码树；`tools/release.py` 的 `eligible()` 排除任何名字含 `.env` 的文件和 .pem/.key，build / smoke 时 JIANWEI_HOME、LOCALAPPDATA 都重定向到发行目录下的空目录。改打包流程时别破坏这几条；发行前可以在 dist 里搜一下 `deepseek.env` / `sk-`。
2. 可以加：从课件框选 / 析题把文字「送到读文」（`ReadingPage.set_text` 已备好）；生词本 / 收藏字词；文言朗读停顿（句读）标注。
3. 学习窗口最小高度 620，窄栏现在 9 个键（约 600 高），再加模式就要考虑窄栏滚动。
4. 冻结版已在 E 盘这台机器上打成功（Jianwei.spec 由 build 重新生成，F 盘路径不碍事）；绿色版没在真机上手动点过。

## 4. 测试（这一轮实际跑过的，全部隔离 JIANWEI_HOME / LOCALAPPDATA）

- `native.reading.selftest` 33 项、`native.kit.bio_realism_selftest` 195 项、`native.selftest`（67 实验 + 6 工作台，all_modules 无漏）、`panels_selftest`、`native.design.selftest`、`native.classroom.selftest`（95 项）：都过。
- 全量 `main.py --self-test --no-single`（离屏）：第一遍 figure-transfer、lecture 两组因 PDF 部首字失败 → 修 `clean_text` 后第二遍 **37 组全部 OK**（2026-11-15）。
- 真窗口截图脚本放在会话的 scratchpad（会被清掉），做法：建 `Shell(tray_enabled=False, jobs_enabled=False)`、配置里关 autoFetch / autoEvening / prewarmWeb，`goto("reading")`、`show_pill`、`set_skin`，`grab()` 存图。
