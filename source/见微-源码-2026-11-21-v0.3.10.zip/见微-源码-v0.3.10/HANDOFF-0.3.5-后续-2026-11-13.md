# 见微 0.3.5 之后的源码改动 · 交接（2026-11-13）

`store.VERSION` 仍是 **0.3.5**：没有升版本、没有打包、没有动发行目录和快捷方式。
这份写的是 11 月 13 日这一轮会话做了什么、做到哪、下一步是什么。接手先读这份，再按需要看：

- 总交接 `HANDOFF.md`（现状、规矩、坑）
- 生物部分的细节 `HANDOFF-生物真实性-Claude.md`（第 8、9 节是这一轮写的）
- 化学部分 `HANDOFF-化学真实性-GPT.md`（另一方的工作，这一轮没碰）

## 1. 一句话现状

| 事项 | 状态 |
| --- | --- |
| 生物：酶、光合与呼吸、分裂计数三个模型 | 做完，自测通过 |
| 生物工作台：卡片封面、左侧图标、首页横幅 | 做完，自测通过，截图给用户看过 |
| 时间胶囊跟随三种风格（水墨 / 青瓷 / 手绘） | 做完，对比图看过，`panels_selftest` 通过；**开着胶囊时现场换风格这一步没在真窗口里试**（见第 4 节） |
| 观澜跟随三种风格 | 0.3.3 就做了（`guanlan/ui/theme.py` 的 `SKINS`），这一轮只读代码确认，没改、没截图 |
| 真人鼠标验收、冻结版、全量自测 | 都没做 |

## 2. 这一轮改了哪些文件

生物（都在 `app/native/lab/benches/`，细节见生物交接第 8、9 节）：

- 新：`bio_enzyme.py`、`bio_photo.py`、`bio_division.py`、`bio_cover.py`
- 改：`bio_model.py`、`bio.py`
- 测试：`app/native/kit/bio_realism_selftest.py`（112 → **195 项**）

时间胶囊（用户直接要求，所以动了分工表里的共享文件）：

- `app/countdown.py`：加了 `SKIN_STYLES`，`resolve_style` 先按 `cfg["skin"]` 选风格再选深浅；描边和印按风格画。
- `app/shell.py`：`_apply_look()` 里加了两行——换风格时如果胶囊开着，就 `pill.apply_config(self.cfg)`。
- `app/panels_selftest.py`：加了 5 项胶囊风格的检查（102 → 107）。

没动：`store.py`、`main.py`、`lab/all_modules.py`、`design/*`、`tools/release.py`、`guanlan/*`、`pages.py`、化学的任何文件。

## 3. 生物部分（已完成）

**模型**

- 酶：五种具体的酶；催化、失活、底物消耗分开算；高温 / 过酸 / 过碱失活不可逆；「最适温度」随作用时间变。旧存档的酶卡片没有 `enzyme` 键，读数和以前一字不差。
- 光合与呼吸：总光合、呼吸、净光合分三行；加了温度和每天光照时长；25 ℃ 时和旧模型的数一样。
- 分裂：从一个 2n=4 的细胞按规则推出各时期的染色体、核 DNA、染色单体、同源染色体、染色体组、细胞数。`stage` 0–3 是旧的四个时期（不变），4 以上是新加的（只有计数，不能逐条拖动核对）。

**外观**

- 工作台上的卡片：上面一块 264×112 的封面（`bio_cover.render`），下面名称 + 一行条件 + 一行读数。封面按参数缓存，拖动卡片不再每帧重算模型。
- 左侧「模型」栏：11 个彩色小图标（`bio_cover.icon`）+ 各自的副标题（`bio_cover.SUBS`）。
- 首页「自由工作台」里生物工作台的插图：`bio_cover.ART`。

**来源**：Worthington 的 pH 最适表和胃蛋白酶手册是打开页面读过的；其余列为假设，写在 `bio_enzyme.ASSUMPTIONS` / `bio_photo.ASSUMPTIONS`，界面「原理」页同样显示。

## 4. 时间胶囊跟随风格（做完，差一步真窗口确认）

**用户的要求**：时间胶囊和观澜也用主程序那三种风格；已经做过的就不用管。

**查到的情况**

- 观澜：0.3.3 已经有三套配色，`Shell._apply_look()` 会调 `guanlan.set_theme(nxt, skin)`。按用户说的不动。翻了一遍 `guanlan/ui` 里写死的颜色，只剩托盘图标的朱砂底和印上的白字，是品牌色，不用跟风格。
- 时间胶囊：只有一套固定配色（墨绿底 / 瓷白底 + 朱砂 + 香槟金，就是青瓷那一路），完全不看 `skin`。这是要补的。

**已经写进 `countdown.py` 的**

- `STYLES` 保留原样（多了几个键），它既是青瓷风格，也是配置里没有 `skin` 时的样子——所以 `panels_selftest` 里按对象身份比较的三项（`cd.STYLES["ink"]` 等）仍然成立（跑过）。
- `SKIN_STYLES = {"celadon": STYLES, "ink": {...}, "doodle": {...}}`，每种风格还是深（`"ink"`）/ 浅（`"porcelain"`）两套。注意这里有两个「ink」：`pillStyle` 的 `"ink"` 指深色底，`skin` 的 `"ink"` 指水墨风格，别混。
- 每套多的键：`dark`（深色底）、`rim`（描边画法：`glaze` 金线 + 釉面高光 / `ink` 匀净淡墨线 / `doodle` 实心粗线）、`seal` / `seal_fg` / `seal_shape`（印的颜色和形状，水墨是方印）。
- 配色：水墨 = 浓墨或宣纸底 + 花青强调；手绘 = 藏青或奶油纸底 + 亮黄（深）/ 亮蓝（浅）。深浅仍按壁纸亮度或「胶囊样式」选，和昼夜无关（原来就是这样）。

**后来做完的**

- 对比图看过：三种风格 × 深浅六条都清楚，方印和字居中，手绘的粗描边没被裁。图存在 `jianwei\验收-生物真实性-2026-11-13\capsule-skins.png`（离屏渲染，背景是模拟的壁纸渐变）。
- `panels_selftest.py` 加了 5 项（六种画面互不相同、每套键齐全、青瓷就是原来那套、没有或写错 `skin` 时用原来那套、风格里也按壁纸选深浅），现在 **107 项通过**；`native.design.selftest` 通过。
- 注意：`panels_selftest` 要用**干净的**临时目录跑。同一个 `JIANWEI_HOME` 连跑两次，第二次会有 5 项失败（上一次留下的状态），和这次改动无关。

**还没做的**

1. 真窗口看一眼：开着胶囊时在设置里换风格，胶囊要立刻跟着变（`_apply_look` 里新加的那两行）。这一步只读了代码，没实际操作。
2. 设置页「倒计时」里的预览（`pages.py` 第 907 行起）会跟着变，但它背后那块模拟桌面的颜色是写死的青绿，可以不管。
3. 真实壁纸上的效果没看（对比图用的是渐变色块）。

## 5. 测试（实际执行过的）

都是离屏，`JIANWEI_HOME` 和 `LOCALAPPDATA` 指到临时目录。

- `python -m native.kit.bio_realism_selftest <目录>`：**195 项通过**
- `models29b_selftest`、`extension_selftest`、`models29_selftest`、`bench_ui_selftest`：**通过**
- 胶囊改动之后：`app/panels_selftest.py <干净目录>` **107 项通过**（连跑两个干净目录都过）；`python -m native.design.selftest` **通过**。生物的自测在胶囊改动之后没有重跑（两边不相干）。

截图：`F:\space for Claude\jianwei\验收-生物真实性-2026-11-13\`

- `covers-sheet-day.png` / `covers-sheet-night.png`：所有卡片封面和每个分裂时期
- `icons-panel-*.png` / `icons-home-*.png`：左侧图标、首页横幅
- `models-*`、`real-models-*`、`bench-models-*`：第二批模型的卡片和面板
- 都只截了水墨皮肤的昼夜；青瓷、手绘没截。

## 6. 需要汇总接入的共享改动（留给统一发行的那一方）

1. `lab/all_modules.py` 还缺四个：`bio_division, bio_enzyme, bio_photo, bio_cover`（`bio.py` 顶部直接 import，打包能找到，但总自测的查漏项会报缺）。
2. 冻结版自测的 `required` 名单（`native/selftest.py`）可以加上生物的八个模块。
3. 把 `native.kit.bio_realism_selftest` 接进总自测 / `release.py smoke`。
4. 发行说明要写的几条在生物交接第 6 节；另加一条：时间胶囊跟随风格（水墨是方印 + 花青，手绘是粗描边 + 亮黄 / 亮蓝，青瓷不变）；再加：胶囊四种版式、观澜四种版式（见 6b）。新文件 `guanlan/ui/layouts.py` 打包时要跟着 guanlan 目录一起进去（guanlan 是整目录拷的，应该没问题，但冻结版没试）。
5. `countdown.py`、`shell.py` 这一轮有改动；如果另一方也在改这两个文件，合并时留意 `SKIN_STYLES`、`resolve_style` / `_tone`、`draw_pill_top` 开头的描边和印、`_apply_look` 里 `guanlan.set_theme` 后面的两行。

## 6b. 时间胶囊、观澜的更多版式（同日稍后，用户要求「more layout for Guanlan and Time capsule」，让我自己挑）

> 完整说明单独写在 **`HANDOFF-0.3.5-版式-2026-11-13.md`**（入口、实现、坑、测试、测试包、没做的事），下面是摘要。

**胶囊**：配置键 `pillLayout` = `bar` 横尺（原样，默认）/ `tile` 方块（表盘 + 下一个节点）/ `column` 竖条（尺从上往下）/ `mini` 迷你（天数 + 细进度 + 时钟）。

- 全在 `app/countdown.py`：`LAYOUTS`、`pill_size(cfg)`（非横尺用「高度」/60 当整体缩放，宽度滑块只对横尺有用）、`needle_pos`（任意版式「今天」的点，呼吸光画这里）、`hover_day(x, y, …)`（方块没有尺，返回 None）、`_draw_tile/_draw_column/_draw_mini`；描边和印抽成 `_draw_rim/_draw_seal`，三种风格都跟。
- 默认位置：横尺、迷你顶上居中；方块、竖条靠左（右边是观澜）。换版式时 `pillX` 清空回默认位置（`Shell.set_pill_layout`）。
- 入口：右键菜单「版式」子菜单（action `layout:<名>`）、设置 → 倒计时页「版式」一排 Chip；预览框高度跟版式变（`PillPreview.sync_size`）。
- `store.DEFAULT_CONFIG` 加了 `pillLayout: "bar"`。

**观澜**：观澜自己的配置键 `layout` = `panel` 侧栏面板（原样，默认）/ `paper` 宽版报纸 / `card` 新闻卡片 / `strip` 标题横条。

- 新文件 `guanlan/ui/layouts.py`（`CardView`、`StripView`、`build_paper`、`DragArea` 能点也能拖、`Dots`）。
- `window.py`：`_apply_layout_size`、`set_layout`（整块重搭，同 set_theme 的做法）、位置每种版式各记一个键（`panel_pos` / `pos_paper` / `pos_card` / `pos_strip`）；横条默认屏幕底部居中。
- 报纸：`TodayPage(parts=…)` 把今日页拆成左栏（标题、焦点、关键词、词典）和中栏（各栏目线索 `stories_page`），右栏是 人物 / 金句 / 档案 三个标签页。窄栏里 `ScrollPage.narrow=True` → `relax()` 把单行 QLabel 改成能折行、品质标签和关键词按栏宽截、词典隐藏英文名（不然会把卡片撑出栏外）。
- 卡片、横条：面板那套控件照样建（藏在 `_panel_holder`），读全文 / 筛选说明 / 设置时 `_make_room()` 把窗口临时撑成 430 宽的面板，关掉阅读层 `_leave_room()` 缩回去；不会自己收起；Ctrl+P = 轮换开关（存 `rotate`），轮换间隔 `rotate_seconds`（卡片 12 秒、横条 9 秒），鼠标停在上面不换。
- 入口：观澜「更多」菜单的「版式」子菜单、观澜设置层第一行、见微主程序「观澜」页右栏「浮窗版式」（`GuanlanHost.layout()/set_layout()`）。

**测试包**（用户要的，不是正式发行）：用 scratchpad 里的包装脚本把 `tools/release.py` 的 OUT/TAG 改到 `jianwei\release-0.3.5-test-2026-11-13\` 跑 build → smoke → pack（release.py 本身没改，正式的 release-0.3.5-2026-11-12 没动）。冻结版自测 35 项全 OK；绿色版 zip 拷到了桌面 `AI\jianwei\见微-绿色版-2026-11-13-v0.3.5-layouts-test.zip`；可直接跑 `release-0.3.5-test-2026-11-13\source-final\dist\Jianwei\Jianwei.exe`。版本号仍 0.3.5。

**测试**：`panels_selftest` 107 → **150 项全过**（干净目录）；`native.design.selftest` 过。截图（离屏，800 宽的虚拟屏，所以报纸是最窄的 760 宽）在 `jianwei\验收-版式-2026-11-13\`。**没做**：真窗口里拖动、真壁纸上的效果、1920 宽屏上的报纸版式、桌面多屏。

## 7. 没做 / 可以接着做

- 固定实验 `exps/bio1.py`「影响酶活性的因素」还是旧的钟形曲线，和工作台的新模型不是一套。
- 逐条拖动核对只支持原来的四个时期。
- 生物工作台在青瓷、手绘皮肤下没看过；封面颜色跟主题色走，理论上没问题。
- 观澜在三种风格下这一轮没有截图核对。
- 首批的显微窗口最小 1020×640，更窄的屏没适配。
- 真人鼠标验收、冻结版、全量 `main.py --self-test` 都没做。
