# 见微 0.3.9 · 交接（2026-11-21）

`store.VERSION` = **0.3.9**。没打包（`tools/release.py` 的 `OUT` / `TAG` 还是 0.3.8）。用户说明见 `RELEASE-0.3.9.md`，**整体方向和清单见 `ROADMAP-0.4.md`**（用户 11.21 的反馈全在里面）。

## 1. 这一轮

| 事项 | 状态 |
| --- | --- |
| 写 `ROADMAP-0.4.md`：化学 / 生物还缺什么、画质目标、数学清单、联动、复习预习、B 站、框选查找、多家 AI | 做完 |
| 数学：函数性质、特殊点、切线、动点吸附、自动走、导函数、伸缩平移、常用函数一键画 | 做完（ROADMAP §4 第 1–6 项） |
| 多家 AI 服务商 | 做完；**没用真实别家密钥联网测** |
| 框选查找：搜索词、AI 改写再搜、来源可信度排序、结论格式、加入复习 | 做完 |
| 生物台卡片穿模（重叠、溢出） | 做完（ROADMAP §2.1 第 1、2 项） |
| 复习预习、B 站视频、联动、化学台、生物新实验、物理性能 | **没做，下一轮** |

## 2. 结构

### 数学（`native/lab/benches/`）
- `geo_calc.py`（新，纯数值，不依赖 Qt）：
  - `analyze(f, x0, x1)` 返回零点、极值、拐点、y 截距、单调区间、奇偶、周期、间断点。
    - 做法：900 点取样，找变号，再二分细化。
    - `_crossings` 跳过恰好为 0 的样本，所以取样落在极值点上也能找到。
    - `_continuous` 和 `breaks` 排除间断两侧的假零点、假极值。
  - 其他函数：`tangent`、`line_text`、`apply_tf` / `bake` / `tf_notes`（y = a·f(b(x−h))+k）、`snap_x`（吸附）。
- `geo_core.py`：
  - 函数对象：`o["_base"]` 是解析式编译出的函数，`o["fn"]` 是叠加了 `o["tf"]` 伸缩平移以后的函数（`compose_fn(o)`）。
  - `strip_object` 去掉 `fn` 和所有 `_` 开头的键。
  - 切线存在 `o["tan"] = {x, normal?}`；`fn_features`（按式子 + tf + 视野缓存）、`set_tangent`、`hit_tangent`、`fn_x_of_world`。
- `geo_draw.py`：`draw_fn_extras` 画 tf 原图虚线、导函数、特殊点记号（选中或 `o["marks"]`）、切线和读数。
- `geo.py`：
  - 鼠标：选择工具下先 `hit_tangent`，命中就进入 `pointer.mode = "slide"`；按住 Alt 不吸附；双击曲线作切线。
  - 右栏 `panel_fn_detail` → `fn_html`（性质写成能折行的段落；`Out` 表格的右列不折行，会把右栏撑宽）和 `panel_fn_transform`。
  - 自动走：`start_play` / `stop_play`（`play_timer`）。
  - `B.geo_board` 给自测用。

### AI 服务商（`native/analysis/llm.py`）
- `PROVIDERS`：8 家，都走 OpenAI 兼容接口。`settings(provider=None)` 返回 key / model / base / vision / provider / name。
- 存在 `deepseek.env`（文件名不变），键名：
  - `AI_PROVIDER`；
  - 各家密钥：`DEEPSEEK_API_KEY`、`QWEN_API_KEY`、`GLM_API_KEY`、`MOONSHOT_API_KEY`、`ARK_API_KEY`、`SILICONFLOW_API_KEY`、`OPENAI_API_KEY`、`CUSTOM_API_KEY`；
  - `AI_MODEL_<ID>`、`AI_BASE_<ID>`、`AI_VISION_<ID>`。
- 旧的 `DEEPSEEK_MODEL` / `DEEPSEEK_BASE_URL` 仍认。
- `save_settings(provider, key=, model=, base=, vision=)` 里，None 表示不动，空串表示清除；`save_key` 只改当前这一家。
- `headers(ds)`、`json_unsupported(status, detail)`：`chat_once` 和框选核查遇到 400 且提到 response_format 时，去掉 JSON 模式重试一次。
- `pick_model`：别家直接用设置里的模型名；旧名换算只对 DeepSeek。
- `store.deepseek_settings()` / `save_deepseek_key()` 现在转调 llm。主窗口设置卡片在 `pages._deepseek_card`（标题「AI 服务」）。
- `vision.py`：用 `ds["vision"]`，这一家没有识图模型时提示去设置；返回的 JSON 不规整时用 `llm.parse_json` 宽松解析。
- 课堂 `classroom/service.py` 没改，仍只读 DeepSeek 密钥。

### 框选查找（`native/lecture/lookup.py`、`panel.py`）
- `focus_query(text)` 取代 `make_query` 做首轮搜索词：
  - 去掉题号、选项行、套话（`_BOILER`）；
  - 短的搜索词前面加「高中某科」（由 `guess_subject` 判断）。
- `site_kind(url)` 返回网站类型和可信度 0–3。`fetch` 给每条资料加上 `kind` / `trust`；同一站点最多两条；送去核查的先按 trust 排。
- `_rewrite(query)` 让 AI 改写搜索词（4 秒超时）。和原词不一样（`_same_query`）就再搜一轮，并发 `rewritten(job, q2)` 信号；第二轮只在有结果时更新来源标签。
- `VERIFY_SYSTEM` 的 summary 格式改成：第一行一句话结论，下面最多三条以「· 」开头的要点。
- `panel.py`：
  - 未核查前按 trust 插入；卡片底行写「类型 · 域名 · 来自某搜索站」；
  - `_set_ai` 第一行加粗；
  - `_to_review` 调 `learning.add_card(dict(n, d, src), subject)`；
  - 「AI 识图」；提示里的服务商名字取自 `_ai_name()`。
- 改 `lookup.py` / `panel.py` 时注意它们是 **CRLF** 换行。用 PowerShell 做多行替换会对不上；scratchpad 的 `patch.py` 会先统一换行。

### 生物台（`native/lab/benches/bio.py`）
- 卡片 `CW, CH, GAP = 280, 185, 14`。
  - `slots()`：可见区域里的网格；`free_spot(x, y, skip)`：最近的空格子。
  - 放进来时找空位，满了就层叠并提示。
  - 拖动时卡片移到列表末尾（画在最上面）；松手吸进空格子。
  - `arrange()` 是「整理」；画卡片时 `setClipRect`。
- `B.bio_layout` 给自测用。

## 3. 测试（全部隔离 JIANWEI_HOME / LOCALAPPDATA）
- 新加 `native.kit.math_fn_selftest`（31 项）和 `native.kit.ai_provider_selftest`（21 项），已接进 `main.py --self-test` 和 `release.py smoke`（`math-fn`、`ai-provider`）。
- `geo_calc` 登记在 `lab/all_modules.py` 和冻结版 required 清单里。
- `extension_selftest` 加了生物卡片不重叠的检查。
- 跑过：fidelity、vision、stage6、analysis、reading、clip、interop、classroom、extensions、models29b、bio-realism，全过。
- 全量 `main.py --self-test --no-single`（离屏）：**39 组全部 OK**（2026-11-21）。中途修了两处：
  - 设置卡片少了一个换行，`pages.py` 编译不过；
  - 课件自测要适应新的「高中某科」前缀，同时把太泛的「反应」从化学术语里去掉，「暗反应」不再被判成化学。
- `main.py`、`lookup.py`、`panel.py` 都是 CRLF 换行：PowerShell 的 `.Replace` 对多行字符串会静默失败，改完要 grep 确认。

## 4. 下一轮（按 ROADMAP §8 的顺序）
1. 复习预习 + B 站：
   - 知识点 → B 站搜索链接（按播放量排序）先做；
   - 优质 UP 主名单要实际打开页面核对后再写进程序；
   - 预习单：知识卡 + 一个实验 + 视频 + 三道小题。
2. 联动（ROADMAP §5）：知识点卡片处处可开，实验 ↔ 题目 ↔ 课件 ↔ 复习。
3. 生物新实验：先做色素提取分离、酵母菌呼吸方式、血细胞计数板、三大物质检测；画质见 §2.4。
4. 化学台：
   - 先修右栏文字重叠和面板挡台面（§1.1，截图里很明显）；
   - 再按 §1.4 成组加实验。
5. 物理性能（§3）。
6. 数学 §4 的 7–9：割线逼近、定积分面积、各类函数参数化预设。

## 5. 坑
- `geo.py` 的 `_build_panel` 每次操作都会重建；别在里面初始化状态（这轮差点把 `play_timer` 清掉）。
- 几何画板右栏用 `L.out().set(rows)` 时，右列不折行；长内容写成 HTML 段落（见 `fn_html`）。
- PowerShell 里不要把函数命名为 `R`（它是 `Invoke-History` 的别名）。
