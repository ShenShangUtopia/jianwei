# 见微 0.3.10 · 交接（2026-11-21）

`store.VERSION` = **0.3.10**。没打包（`tools/release.py` 的 `OUT` / `TAG` 还是 0.3.8）。用户说明见 `RELEASE-0.3.10.md`。**下一步先看 `调研/总览.md`**：8 个板块的专项调研，改进按「影响大、改动小」排好了。

## 1. 这一轮
| 事项 | 状态 |
| --- | --- |
| ROADMAP §6 预习单（知识卡 + 实验 + B 站视频 + 三道小题）、课件「预习这一课」 | 做完 |
| B 站：知识点 → 搜索链接（按播放量排序） | 做完。**没在浏览器里实际打开核对**：内置浏览器打不开 B 站，网址格式按 `search.bilibili.com/all?keyword=…&order=click` 写 |
| B 站优质 UP 主名单（ROADMAP §6 第二步） | **没做**：名单要实际打开页面核对后才能写 |
| 复习：看讲解视频、上次没记住先提示看视频、卡片式 UI | 做完 |
| 用户嫌 UI 不好看 → 预习、复习、今日卡按调研重做 | 做完 |
| 8 个 Sonnet 子代理分板块调研 UI 和用法 | 做完，报告在 `调研/` |
| 调研里的几个小修（右栏读数竖排、化学快照、习题台标签、函数配色、今日一题公式） | 做完 |

## 2. 结构
- `native/preview.py`（纯数据，不依赖 Qt）：
  - `CHAPTERS`：四门理科的章节 → 知识卡名 + 实验 id；文科一张卡算一节。
  - `make(subject, chapter)` 和 `from_text(text, title)` 生成一张单子：`id/title/subject/topic/cards/lab/video/quiz/made/done`。
  - `video_query` / `bili_url` 生成 B 站搜索词和链接；`suggest` 推荐章节。
  - 存储：`preview.json` 最多留 30 张，`current` 记当前这张。
  - `tick` / `untick` 打勾和取消；打勾时调 `learning.note("preview", …)` 记一笔。
- `native/learning.py`：
  - 新增 `note(kind, reference, subject)`，`kind` 只收 preview / video / lab：只记一笔事件，不推进复习排期。
  - 新增 `forgot(item)`：上次选了「没记住」的项目。
- `native/preview_ui.py`：
  - 共用小部件：`Card`、`Badge`（可点，当前步骤是主色圈）、`Bar`、`icon`、`text`、`button`、`tag`。
  - `Preview` 弹窗：所有按键都走 `act(kind, arg)`，kind 有 do / toggle / open / lab / video / q / review / pick。`render()` 每次整页重建，滚动位置保留；看答案只切换那一题，不重建。
  - `open_video`：打开 B 站，并记一笔 video 事件。宿主有 `_no_browser` 属性时不开浏览器（给自测用）。
  - `lecture_text`：先读 text.pdf，没有再读 doc.pdf。`preview_lecture` 是课件右键菜单的入口。
- `native/learning_ui.py`：
  - `Review`：用 `flipped` 标志表示翻没翻面（不再看控件是否可见），`reveal()` 翻面；快捷键：空格翻面，1 没记住，2 记住了；`_cue` 在知识卡正面出公式填空；完成页只留 `done_btn`。
  - `Daily`：改用 ui_kit 的 `Btn` / `lab`。属性有 `big`、`pre_line`、`pre_bar`、`pre`、`more`；`history` 和 `details` 默认收起。
- 入口：
  - 今日页的 Daily；
  - 复习模块的「预习」（`modules._build_review`）；
  - 课件右键（`pages.DeckCard._preview`、`modules._DeckRow._preview`）。
- 其他改动：
  - `bank/fx.plain()`：纯文本标签用，把上下标换成 Unicode。今日一题（pages / modules）先 plain 再截断。
  - `kit/ctx.Out.set`：值的纯文字超过 14 个字时，改成标签一行、值另起一行，可以折行。
  - `chem.py` 快照不带 `uil`，恢复时沿用当前的日志标签。
  - `desk.py` 的 `set_index`。
  - `geo_core.add_function` 自动换色（`FN_COLORS`）。

## 3. 测试（全部隔离 JIANWEI_HOME / LOCALAPPDATA）
- 新增 `native.kit.preview_selftest`（50 项）：章节表完整、B 站链接、预习单四步、自动打勾和点圆圈、空状态推荐、复习的视频和完成页、今日卡、课件 PDF 取字。已接进 `main.py --self-test` 和 `release.py smoke`（`preview`）。
- `learning_selftest` 改成用 `plan.reveal()` 翻面。
- 跑过、都通过：`chem_gas`、`chem_procedure`、`math_fn`、`learning`。全量结果见第 5 节。

## 4. 下一轮
按 `调研/总览.md` 的「下一步」从第 1 条往下做：
- 物理台静止时停止重画；
- 几何画板做缓存；
- 习题台默认「先做后看」；
- 生物卡片缩放；
- ……

每条都有文件和行号。ROADMAP §5（联动）和 §6 的 UP 主名单还没做。

## 5. 全量自测
`main.py --self-test --no-single`（离屏、隔离数据）：**40 组全部 OK**（2026-11-21，含新的 preview）。冻结版 build/smoke/pack 没跑。

## 6. 坑
- PowerShell 的 `[IO.File]::ReadAllText` / `.Replace` 链式调用如果参数不对，可能把 `$null` 写回去、清空文件：这一轮 `preview_ui.py` 被清空过一次，已重写。**改多行优先用 Edit 工具**，用 PowerShell 写文件之前先 `throw` 检查。
- 想在内置浏览器里打开 B 站时被拦了：网址格式要等用户真机点一次才算核对过。
- 子代理的截图脚本留在 `%TEMP%\jw-research\<板块>\`，复现问题可以直接重跑（例如化学的 `s2.py`）。
