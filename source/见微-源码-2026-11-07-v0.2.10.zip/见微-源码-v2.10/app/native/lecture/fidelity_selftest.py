"""课件放映保真、搜题、查询面板的验收（不联网、不启动 Office）。

设 JIANWEI_COM_TEST=1 时另外用本机 WPS / PowerPoint 真转一份课件，逐页对照演示软件自己导出的图（只在开发机上手动跑）。
"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path
from xml.etree import ElementTree as ET


def _lum_diff(a, b) -> tuple[float, float]:
    from PySide6.QtGui import QImage, QPainter
    x = a.convertToFormat(QImage.Format.Format_RGB32)
    p = QPainter(x)
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Difference)
    p.drawImage(0, 0, b.convertToFormat(QImage.Format.Format_RGB32))
    p.end()
    gi = x.convertToFormat(QImage.Format.Format_Grayscale8)
    g = bytes(gi.constBits())
    return sum(g[::3]) * 3 / len(g), sum(1 for v in g[::3] if v > 40) * 3 / len(g)


def main(root=None) -> int:
    root = Path(root or tempfile.mkdtemp(prefix="jw-fidelity-"))
    root.mkdir(parents=True, exist_ok=True)
    from ..kit import test_runtime
    app = test_runtime.application(sys.argv[:1])
    from PySide6.QtCore import QRectF, QSize, Qt
    from PySide6.QtGui import QColor, QImage, QPainter, QPixmap
    from PySide6.QtPdf import QPdfDocument

    failures: list[str] = []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        if not ok:
            failures.append(name)

    def spin(t=0.05):
        end = time.time() + t
        while time.time() < end:
            app.processEvents()
            time.sleep(.005)

    from . import anim, convert, effects

    # ---- 出图拼 PDF：颜色、尺寸、页序都不变
    colors = ["#C8402A", "#0F6B62", "#2B55A6"]
    files = []
    for i, c in enumerate(colors):
        img = QImage(1280, 720, QImage.Format.Format_ARGB32)
        img.fill(QColor(c))
        p = QPainter(img)
        p.fillRect(QRectF(100 + i * 200, 100, 300, 200), QColor("#FFFFFF"))
        p.end()
        f = root / f"{i:04d}.png"
        img.save(str(f))
        files.append(f)
    plan = dict(w=960.0, h=540.0, slides=[], hidden=[])
    pdf = root / "frames.pdf"
    t0 = time.perf_counter()
    convert._images_to_pdf(files, pdf, plan)
    ms = (time.perf_counter() - t0) * 1000
    doc = QPdfDocument()
    doc.load(str(pdf))
    check("拼出的 PDF 能打开、页数对", doc.pageCount() == 3, doc.pageCount())
    check("页面是幻灯片原尺寸", doc.pagePointSize(0) == doc.pagePointSize(2) and abs(doc.pagePointSize(0).width() - 960) < .01)
    for i, c in enumerate(colors):
        out = doc.render(i, QSize(1280, 720))
        m, big = _lum_diff(out, QImage(str(files[i])))
        check(f"第 {i + 1} 页颜色和原图一致", m < 2.5 and big < .003, f"{m:.2f}/{big:.4f}")
        px = out.pixelColor(20, 20)
        want = QColor(c)
        check(f"第 {i + 1} 页底色没偏", max(abs(px.red() - want.red()), abs(px.green() - want.green()), abs(px.blue() - want.blue())) <= 6, px.name())
    check("拼 PDF 够快", ms < 3000, f"{ms:.0f}ms")
    alpha = QImage(64, 36, QImage.Format.Format_ARGB32)
    alpha.fill(Qt.GlobalColor.transparent)
    alpha.save(str(root / "alpha.png"))
    convert._images_to_pdf([root / "alpha.png"], root / "alpha.pdf", plan)
    d2 = QPdfDocument()
    d2.load(str(root / "alpha.pdf"))
    check("透明的导出图垫白", d2.render(0, QSize(64, 36)).pixelColor(5, 5).lightness() > 250)

    # ---- 动作路径：解析、走完停在终点
    P = anim.P
    xml = (f'<p:cTn xmlns:p="{P[1:-1]}" presetClass="path"><p:childTnLst><p:animMotion path="M 0 0 L 0.25 -0.1 E">'
           f'<p:cBhvr><p:cTn dur="1000"/></p:cBhvr></p:animMotion></p:childTnLst></p:cTn>')
    ctn = ET.fromstring(xml)
    path = anim._motion_path(ctn)
    check("动作路径读出终点", path and path[0] == (0.0, 0.0) and path[-1] == (0.25, -0.1), path)
    cls, name, _d, dur = anim._effect_of(ctn)
    check("动作路径当路径播，不再当脉冲", cls == "path" and name == "path" and dur == 1000, (cls, name, dur))
    a = QPixmap(400, 200)
    a.fill(QColor("#FFFFFF"))
    b = QPixmap(400, 200)
    b.fill(QColor("#FFFFFF"))
    pa, pb = QPainter(a), QPainter(b)
    pa.fillRect(QRectF(40, 80, 40, 40), QColor("#C8402A"))
    pb.fillRect(QRectF(140, 60, 40, 40), QColor("#C8402A"))
    pa.end()
    pb.end()
    run = effects.Run(a, b, [dict(kind="emph", effect="path", dir="r", dur=800, delay=0, rect=[0.1, 0.4, 0.1, 0.2], path=[(0, 0), (0.25, -0.1)])])
    mid = QImage(400, 200, QImage.Format.Format_RGB32)
    mid.fill(QColor("#000000"))
    q = QPainter(mid)
    run.paint(q, 0.4)
    q.end()
    check("路径走到一半时形状在中间", mid.pixelColor(110, 90).red() > 150 and mid.pixelColor(160, 80).red() < 255 and mid.pixelColor(60, 100).green() > 200,
          (mid.pixelColor(110, 90).name(), mid.pixelColor(60, 100).name()))
    end = QImage(400, 200, QImage.Format.Format_RGB32)
    q = QPainter(end)
    run.paint(q, 5)
    q.end()
    check("路径走完和后一页一样", _lum_diff(end, b.toImage())[0] < .01)

    # ---- 引擎识别
    for prog in ("PowerPoint.Application", "KWPP.Application", "Word.Application", "KWPS.Application"):
        label = convert.label(prog) if convert.has_com(prog) else convert.LABEL[prog]
        check(f"{prog} 名字能读出来", isinstance(label, str) and label)
    names = convert.engines_for(".pptx")
    check("同一个 WPS 不会试两遍", not (convert.is_wps_shim("PowerPoint.Application") and "PowerPoint.Application" in names and "KWPP.Application" in names), names)

    # ---- 搜题
    from ..bank.data import bank
    from ..kit.question_search import similar, score
    bank.load()
    q = next(x for x in bank.questions if len(str(x.get("stem") or "")) > 40)
    hits = similar(q["stem"], bank.questions)
    check("同一道题排第一、标成就是这道", hits and hits[0]["q"]["id"] == q["id"] and hits[0]["same"], [(h["q"]["id"], round(h["score"], 2)) for h in hits])
    import re
    changed = re.sub(r"\d", lambda m: str((int(m.group(0)) + 3) % 10), q["stem"])
    h2 = similar(changed, bank.questions)
    check("换了数的同型题能找到", h2 and h2[0]["q"]["id"] == q["id"], [(h["q"]["id"], round(h["score"], 2)) for h in h2])
    check("无关文字不硬配", similar("今天天气很好我们去公园散步看花", bank.questions) == [])
    check("太短不配", similar("求 a", bank.questions) == [])
    t0 = time.perf_counter()
    for _ in range(20):
        similar(q["stem"], bank.questions)
    check("题库匹配够快", (time.perf_counter() - t0) / 20 < .2, f"{(time.perf_counter() - t0) / 20 * 1000:.0f}ms")
    check("相似度对称", abs(score("牛顿第二定律", "第二定律牛顿") - score("第二定律牛顿", "牛顿第二定律")) < 1e-9)

    # ---- 查询面板
    from . import lookup
    from .panel import LookupPanel, highlight
    check("命中词高亮", "<b" in highlight("物体的加速度与合力成正比", "加速度 合力") and "&lt;" in highlight("<x>", "x"))
    pn = LookupPanel(None)
    pn.resize(460, 900)
    pn.show()
    got = {}
    pn.open_question.connect(lambda qid: got.__setitem__("open", qid))
    pn.analyze.connect(lambda t, im: got.__setitem__("analyze", (t, im.isNull())))
    img = QImage(300, 120, QImage.Format.Format_RGB32)
    img.fill(QColor("white"))
    pn.start(img, q["stem"], mode="question")
    spin()
    from .panel import QuestionCard
    cards = pn.qbox.findChildren(QuestionCard)
    check("搜题：题库卡片出来了", pn.qbox.isVisible() and cards and pn.title_label.text() == "搜题", len(cards))
    check("搜题不自动上网", not pn.sources.isVisible() and pn.n == 0)
    from PySide6.QtWidgets import QPushButton
    btn = next(b for b in cards[0].findChildren(QPushButton) if b.text() == "在习题台打开")
    btn.click()
    check("在习题台打开发出题号", got.get("open") == q["id"], got)
    go = next(b for b in pn.qbox.findChildren(QPushButton) if b.text() == "送去析题")
    go.click()
    check("送去析题带上题目文字", got.get("analyze", ("", True))[0].startswith(q["stem"][:6]), got.get("analyze"))
    pn.grab().save(str(root / "question.png"))
    pn.start(img, "今天天气很好我们去公园散步看花吧", mode="question")
    spin()
    check("题库里没有时说清楚", any("没有找到" in lbl.text() for lbl in pn.qbox.findChildren(type(pn.note))))
    # 上网查询的展示
    pn.start(img, "比较优势", mode="web")
    pn.engine.cancel()
    pn.job = 5
    pn.sources.reset(["360", "搜狗", "必应"])
    pn._on_source(5, "360", "ok", 0.7, 3)
    pn._on_source(5, "搜狗", "blocked", 0.4, 0)
    pn._on_source(4, "必应", "ok", 0.4, 9)
    check("来源状态：条数和用时", "3 条" in pn.sources.chips["360"].text() and "0.7" in pn.sources.chips["360"].text())
    check("来源状态：要验证", "验证" in pn.sources.chips["搜狗"].text())
    check("旧查询的来源状态不算", "…" in pn.sources.chips["必应"].text())
    old = lookup._ai_ready
    lookup._ai_ready = lambda: True
    try:
        pn.t0 = time.perf_counter()
        its = [dict(title=f"比较优势 资料{i}", url=f"https://e{i}.com/x", snippet="比较优势是指机会成本更低", source="360", n=i) for i in (1, 2, 3)]
        pn._on_results(5, its, .3)
        pn._on_verdict(5, "https://e1.com/x", "keep", "教材")
        pn._on_verdict(5, "https://e3.com/x", "drop", "广告")
        pn._on_ai(5, "比较优势看机会成本[1]，不是绝对成本[3]")
        pn._on_checked(5, dict(ok=True, kept=1, doubt=1, dropped=1, total=3, conflict=""))
        spin()
    finally:
        lookup._ai_ready = old
    check("结论里的出处可以点", "cite:1" in pn.ai_body.text() and pn.ai_plain.endswith("[3]"))
    check("核查比例条", pn.vbar.isVisible() and pn.vbar.parts == (1, 1, 1))
    gone = next(c for c in pn.cards if c.verdict == "drop")
    pn._cite("cite:3")
    spin()
    check("点出处会展开被筛掉的那条", gone.isVisible())
    check("资料卡左边有结论色条", "border-left:3px solid #21804F" in next(c for c in pn.cards if c.verdict == "keep").styleSheet())
    pn.grab().save(str(root / "lookup.png"))
    pn.close_panel()
    pn.close()

    # ---- 放映页的文字从文字层取
    from .pageview import PageView
    w = QPdfDocument()
    w.load(str(pdf))
    view = PageView(w, "slides")
    view.resize(960, 540)
    view.text_lookup = lambda page: (d2, 0) if page == 0 else None
    check("没文字层时回退到放映 PDF", view.selection_text(QRectF(0, 0, 960, 540)) == "")
    view.close()

    # ---- 可选：本机真转换
    if os.environ.get("JIANWEI_COM_TEST") == "1" and convert.engines_for(".pptx"):
        _com_check(root, check)
    print("FIDELITY", "OK" if not failures else "FAIL " + ",".join(failures[:12]), flush=True)
    return int(bool(failures))


def _com_check(root, check):
    """WPS / PowerPoint 真转换：逐页对照演示软件自己导出的整页图（动画全部放完的样子）。"""
    import json
    import subprocess
    from PySide6.QtCore import QSize
    from PySide6.QtGui import QImage
    from PySide6.QtPdf import QPdfDocument
    from . import convert
    src = Path(os.environ.get("JIANWEI_COM_DECK", ""))
    if not src.is_file():
        check("JIANWEI_COM_DECK 指向一份课件", False, str(src))
        return
    out = root / "com"
    out.mkdir(exist_ok=True)
    t0 = time.perf_counter()
    engine = convert.to_pdf(src, out / "doc.pdf", print)
    took = time.perf_counter() - t0
    check("真转换走原样出图", engine.endswith("原样出图"), engine)
    tl = json.loads((out / "anim.json").read_text(encoding="utf-8")) if (out / "anim.json").exists() else None
    ps = ("$app=New-Object -ComObject " + convert.engines_for(src.suffix.lower())[0] + ";$p=$app.Presentations.Open($env:JW_SRC,-1,0,0);$k=0;"
          "for($i=1;$i -le $p.Slides.Count;$i++){$s=$p.Slides.Item($i);if($s.SlideShowTransition.Hidden){continue};$s.Export(\"$env:JW_DIR\\ref$k.png\",'PNG',1280,720);$k++};$p.Saved=-1;$p.Close()")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], env=dict(os.environ, JW_SRC=str(src), JW_DIR=str(out)), capture_output=True, timeout=600)
    doc = QPdfDocument()
    doc.load(str(out / "doc.pdf"))
    worst = 0.0
    n = 0
    slides = tl["slides"] if tl else [dict(last=i) for i in range(doc.pageCount())]
    for i, s in enumerate(slides):
        ref = QImage(str(out / f"ref{i}.png"))
        if ref.isNull():
            continue
        page = tl["frames"][s["last"]]["page"] if tl else i
        m, _big = _lum_diff(doc.render(page, QSize(ref.width(), ref.height())), ref)
        worst = max(worst, m)
        n += 1
    check(f"真转换 {n} 页逐页对照（用时 {took:.1f} 秒）", n > 0 and worst < 3.0, f"最差平均差 {worst:.2f}")


if __name__ == "__main__":
    from ..kit import test_runtime
    test_runtime.configure()
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    target = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix="jw-fidelity-")
    os.environ["JIANWEI_HOME"] = str(Path(target) / "home")
    os.environ["LOCALAPPDATA"] = str(Path(target) / "local")
    raise SystemExit(test_runtime.run(lambda: main(target)))
