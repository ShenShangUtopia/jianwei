"""见微 · 主壳：无边框纸面窗 + 左侧导航 + 托盘。"""
from __future__ import annotations

import os
import sys
import threading
from datetime import datetime

from PySide6.QtCore import QPoint, QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QHBoxLayout, QLabel, QMenu, QPushButton, QStackedWidget, QSystemTrayIcon,
    QVBoxLayout, QWidget,
)

import pages
import store
import guanlan_host
import studio_server
from countdown import CountdownPill
from PySide6.QtGui import QBrush, QRadialGradient

from ui_kit import C, f


def _theme() -> str:
    import ui_kit
    return ui_kit.theme()

NAV = [
    ("today", "今日"),
    ("guanlan", "观澜"),
    ("countdown", "倒计时"),
    ("studio", "习题台"),
    ("lab", "实验室"),
    ("settings", "设置"),
]


class RailCountdown(QWidget):
    """侧栏底部的小卡：距考天数 + 学期进度，一眼可见（每分钟刷新）。"""

    def __init__(self, cfg: dict):
        super().__init__()
        self.cfg = cfg
        self.setFixedHeight(96)
        self._t = QTimer(self)
        self._t.timeout.connect(self.update)
        self._t.start(60_000)
        self.setToolTip("高考倒计时 · 在「倒计时」页可调")

    def paintEvent(self, _ev) -> None:
        from ui_kit import serif
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        now = datetime.now()
        target, start = store.target_dt(self.cfg), store.start_dt(self.cfg)
        secs = max(0.0, (target - now).total_seconds())
        frac = min(1.0, max(0.0, 1 - secs / max(1.0, (target - start).total_seconds())))
        r = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        p.setPen(QPen(C.LINE, 1))
        p.setBrush(C.CARD)
        p.drawRoundedRect(r, 12, 12)
        x = 14
        p.setPen(C.FAINT)
        p.setFont(f(10, 600, 1.6))
        p.drawText(QRectF(x, 10, r.width() - 2 * x, 16), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   f"距 {self.cfg.get('year', '2027')} {self.cfg.get('label', '高考')}")
        num = str(int(secs // 86400))
        p.setFont(serif(27, 600))
        p.setPen(C.INK)
        fm = p.fontMetrics()
        p.drawText(QPointF(x, 58), num)
        p.setFont(f(11.5, 500))
        p.setPen(C.SOFT)
        p.drawText(QPointF(x + fm.horizontalAdvance(num) + 5, 57), "天")
        bar = QRectF(x, 70, r.width() - 2 * x, 3)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.LINE)
        p.drawRoundedRect(bar, 1.5, 1.5)
        p.setBrush(C.ACCENT if _theme() == "night" else C.INK)
        p.drawRoundedRect(QRectF(bar.x(), bar.y(), max(3.0, bar.width() * frac), 3), 1.5, 1.5)
        p.setPen(C.FAINT)
        p.setFont(f(9.5))
        p.drawText(QRectF(x, 76, r.width() - 2 * x, 14), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   f"本学期已过 {int(frac * 100)}%")
        p.end()


class Shell(QWidget):
    toast_sig = Signal(str)

    def __init__(self, tray_enabled: bool = True, start_page: str = "today",
                 jobs_enabled: bool = True):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("见微 · 高考学习舱")
        self.setMinimumSize(980, 640)
        self.resize(1180, 780)

        self.cfg = store.load_config()
        self.pill: CountdownPill | None = None
        self.guanlan = guanlan_host.GuanlanHost()
        self.studio = studio_server.StudioHost()
        self._drag: QPoint | None = None
        self._tray: QSystemTrayIcon | None = None
        self._page_index = {k: i for i, (k, _) in enumerate(NAV)}

        self._build()
        if tray_enabled:
            self._build_tray()
        self.toast_sig.connect(self._show_toast)

        self._clock = QTimer(self)
        self._clock.timeout.connect(self._refresh_clock)
        self._clock.start(30000)

        self._reserve_clock = QTimer(self)
        self._reserve_clock.timeout.connect(self._sync_pill_reserve)
        self._reserve_clock.start(4000)

        self.goto(start_page)
        if self.cfg.get("showPill"):
            QTimer.singleShot(600, lambda: self.show_pill(True, quiet=True))
        if self.cfg.get("showGuanlanOnStart", True):
            QTimer.singleShot(900, self._open_guanlan_once)
        if jobs_enabled:
            self._setup_daily_jobs()
        self._setup_panel_hotkey()

    # ------------------------------------------------------------ 常驻节律
    def _setup_daily_jobs(self) -> None:
        import scheduler
        self.jobs = scheduler.DailyJobs(self.guanlan, self.cfg, self.save, self)
        self.jobs.toast.connect(self.toast_sig.emit)
        self.jobs.fetch_done.connect(self.guanlan.reload)

    def _setup_panel_hotkey(self) -> None:
        """把观澜原有的 Alt+Shift+G 收进见微；原版在跑时注册会失败，不报错。"""
        self._hotkey = None
        try:
            self.guanlan._ensure_path()
            from ui.window import HotkeyFilter  # type: ignore
            filt = HotkeyFilter(self.toggle_guanlan)
            if filt.install():
                self._hotkey = filt
        except Exception:
            self._hotkey = None

    def _open_guanlan_once(self) -> None:
        if not self.guanlan.is_visible() and self.guanlan.show():
            self.cfg["showGuanlan"] = True
            self._sync_pill_reserve()

    def _sync_pill_reserve(self) -> None:
        """胶囊固定屏幕居中；这个钩子保留，用于把旧配置里残留的让位值清掉。"""
        reserve = 0
        if self.cfg.get("pillReserveRight") != reserve:
            self.cfg["pillReserveRight"] = reserve
            if self.pill is not None and self.pill.isVisible():
                self.pill.apply_config(self.cfg)

    # ------------------------------------------------------------ 结构
    def _build(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 14, 16, 16)
        outer.setSpacing(0)

        self.surface = QWidget()
        self.surface.setObjectName("surface")
        self.surface.setStyleSheet("#surface{background:transparent;}")
        outer.addWidget(self.surface)

        lay = QVBoxLayout(self.surface)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self._titlebar())
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._rail())
        self.stack = QStackedWidget()
        body.addWidget(self.stack, 1)
        lay.addLayout(body, 1)
        self._build_pages()

        self._toast = QLabel(self.surface)
        self._toast.setFont(f(11.5))
        self._toast.setStyleSheet(
            "background:#081F5C;color:#F7F2EB;border-radius:10px;padding:8px 16px;")
        self._toast.hide()

    def _titlebar(self) -> QWidget:
        bar = QWidget()
        bar.setFixedHeight(52)
        bar.mousePressEvent = self._bar_press
        bar.mouseMoveEvent = self._bar_move
        bar.mouseReleaseEvent = self._bar_release
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(24, 0, 12, 0)
        lay.setSpacing(8)
        brand = QLabel("见微")
        brand.setFont(f(16, 700, 6))
        brand.setStyleSheet("color:#081F5C;background:transparent;")
        sub = QLabel("高考学习舱")
        sub.setFont(f(10.5, 500, 2.4))
        sub.setStyleSheet("color:#93A0B8;background:transparent;")
        # 三段同一条中线：品牌字大、副标题与时钟小，底对齐会掉到标题栏底边，看着像错位的第二行
        lay.addWidget(brand, 0, Qt.AlignmentFlag.AlignVCenter)
        sub.setContentsMargins(0, 3, 0, 0)
        lay.addWidget(sub, 0, Qt.AlignmentFlag.AlignVCenter)
        lay.addSpacing(10)
        self.clock_label = QLabel()
        self.clock_label.setFont(f(10.5, 500, 1.2))
        self.clock_label.setContentsMargins(0, 3, 0, 0)
        self.clock_label.setStyleSheet("color:#93A0B8;background:transparent;")
        lay.addWidget(self.clock_label, 0, Qt.AlignmentFlag.AlignVCenter)
        lay.addStretch(1)
        self.theme_btn = QPushButton("夜晚" if _theme() == "day" else "白天")
        self.theme_btn.setObjectName("ghost")
        self.theme_btn.setFixedHeight(24)
        self.theme_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.theme_btn.setToolTip("切换白天 / 夜晚配色")
        self.theme_btn.setFont(f(10.5, 500, 0.6))
        self.theme_btn.clicked.connect(self.toggle_theme)
        lay.addWidget(self.theme_btn)
        lay.addSpacing(4)
        for text, slot, tip in (("—", self.showMinimized, "最小化"),
                                ("×", self._close_clicked, "关闭")):
            b = QPushButton(text)
            b.setFixedSize(26, 26)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip(tip)
            b.setStyleSheet(
                "QPushButton{color:#93A0B8;font-size:14px;border-radius:3px;background:transparent;}"
                "QPushButton:hover{background:#EDF0F6;color:#081F5C;}")
            b.clicked.connect(slot)
            lay.addWidget(b)
        self._refresh_clock()
        return bar

    def _rail(self) -> QWidget:
        rail = QWidget()
        rail.setFixedWidth(186)
        lay = QVBoxLayout(rail)
        lay.setContentsMargins(14, 8, 14, 18)
        lay.setSpacing(3)
        self.nav_buttons: list[QPushButton] = []
        for key, text in NAV:
            b = QPushButton("  " + text)   # 图标与文字之间留一点气口
            b.setObjectName("nav")
            b.setCheckable(True)
            b.setAutoExclusive(True)
            b.setFixedHeight(40)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFont(f(13, 500, 0.6))
            b.setIconSize(QSize(17, 17))
            b.setProperty("navKey", key)
            b.clicked.connect(lambda _=False, k=key: self.goto(k))
            lay.addWidget(b)
            self.nav_buttons.append(b)
        self._refresh_nav_icons()
        lay.addStretch(1)
        self.rail_count = RailCountdown(self.cfg)
        lay.addWidget(self.rail_count)
        return rail

    def _refresh_nav_icons(self) -> None:
        """导航图标：平时淡墨、选中墨蓝（夜间金色）；换主题时重画。"""
        import ui_kit
        on_color = C.ACCENT if ui_kit.theme() == "night" else C.INK
        for b in getattr(self, "nav_buttons", []):
            key = b.property("navKey")
            icon = QIcon()
            icon.addPixmap(ui_kit.nav_icon(key, C.FAINT), QIcon.Mode.Normal, QIcon.State.Off)
            icon.addPixmap(ui_kit.nav_icon(key, on_color), QIcon.Mode.Normal, QIcon.State.On)
            icon.addPixmap(ui_kit.nav_icon(key, C.INK), QIcon.Mode.Active, QIcon.State.Off)
            b.setIcon(icon)

    def _build_pages(self) -> None:
        while self.stack.count():
            w = self.stack.widget(0)
            self.stack.removeWidget(w)
            w.deleteLater()
        first = self.tab if hasattr(self, "tab") else "today"
        self.stack.addWidget(pages.build_overview(self))
        self.stack.addWidget(pages.build_guanlan(self))
        self.stack.addWidget(pages.build_countdown(self))
        self.stack.addWidget(pages.build_studio(self))
        self.stack.addWidget(pages.build_lab(self))
        self.stack.addWidget(pages.build_settings(self))
        self.tab = first
        self.goto(first)
        import ui_kit
        ui_kit.restyle_tree(self)

    # ------------------------------------------------------------ 主题
    def toggle_theme(self) -> None:
        import ui_kit
        nxt = "night" if ui_kit.theme() == "day" else "day"
        ui_kit.apply_theme(nxt)
        self.cfg["theme"] = nxt
        self.save()
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(ui_kit.qss())
        self.theme_btn.setText("夜晚" if nxt == "day" else "白天")
        self._refresh_nav_icons()
        self.rail_count.update()
        self._build_pages()
        ui_kit.restyle_tree(self)
        self.update()
        for w in (self.surface,):
            w.style().unpolish(w)
            w.style().polish(w)
            w.update()

    # ------------------------------------------------------------ 绘制
    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        path = QPainterPath()
        path.addRoundedRect(rect, 10, 10)
        if _theme() == "night":
            p.fillPath(path, C.PAPER)
            p.save()
            p.setClipPath(path)
            g1 = QRadialGradient(QPointF(self.width() * 0.86, self.height() * 0.04), self.width() * 0.55)
            g1.setColorAt(0.0, QColor(124, 156, 196, 70))
            g1.setColorAt(1.0, QColor(124, 156, 196, 0))
            p.fillRect(self.rect(), QBrush(g1))
            g2 = QRadialGradient(QPointF(self.width() * 0.06, self.height() * 0.96), self.width() * 0.5)
            g2.setColorAt(0.0, QColor(228, 184, 99, 26))
            g2.setColorAt(1.0, QColor(228, 184, 99, 0))
            p.fillRect(self.rect(), QBrush(g2))
            p.restore()
        else:
            p.fillPath(path, C.PAPER)
            p.save()
            p.setClipPath(path)
            d1 = QRadialGradient(QPointF(self.width() * 0.88, self.height() * 0.02), self.width() * 0.62)
            d1.setColorAt(0.0, QColor(255, 255, 255, 210))
            d1.setColorAt(1.0, QColor(255, 255, 255, 0))
            p.fillRect(self.rect(), QBrush(d1))
            d2 = QRadialGradient(QPointF(self.width() * 0.04, self.height() * 0.98), self.width() * 0.5)
            d2.setColorAt(0.0, QColor(255, 236, 214, 120))
            d2.setColorAt(1.0, QColor(255, 236, 214, 0))
            p.fillRect(self.rect(), QBrush(d2))
            p.restore()
        # 左侧导航空白（比纸底略亮）
        side = QPainterPath()
        side.addRoundedRect(QRectF(0.5, 0.5, 186 + 16, self.height() - 1), 10, 10)
        p.save()
        p.setClipPath(path)
        p.fillPath(side, C.SIDE)
        p.restore()
        p.setPen(QPen(C.WINDOW_LINE, 1))
        p.drawRoundedRect(rect, 10, 10)
        p.end()

    # ------------------------------------------------------------ 导航
    def goto(self, key: str) -> None:
        key = key if key in self._page_index else "today"
        self.tab = key
        i = self._page_index[key]
        self.stack.setCurrentIndex(i)
        for b, (k, _) in zip(self.nav_buttons, NAV):
            b.setChecked(k == key)
        self.raise_()

    # ------------------------------------------------------------ 窗口
    def _bar_press(self, ev) -> None:
        if ev.button() == Qt.MouseButton.LeftButton:
            self._drag = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def _bar_move(self, ev) -> None:
        if self._drag is not None:
            self.move(ev.globalPosition().toPoint() - self._drag)

    def _bar_release(self, _ev) -> None:
        self._drag = None

    def _close_clicked(self) -> None:
        if self.cfg.get("closeToTray", True) and self._tray is not None:
            self.hide()
        else:
            self.quit_app()

    def closeEvent(self, ev) -> None:
        if self.cfg.get("closeToTray", True) and self._tray is not None:
            ev.ignore()
            self.hide()
            return
        self.quit_app()
        ev.accept()

    def quit_app(self) -> None:
        try:
            if self.pill:
                self.pill.close()
            self.studio.stop()
            if getattr(self, "_hotkey", None) is not None:
                self._hotkey.remove()
            self.guanlan.hide()
        except Exception:
            pass
        QApplication.instance().quit()

    def _refresh_clock(self) -> None:
        now = datetime.now()
        self.clock_label.setText(f"{now:%Y.%m.%d} 周{'一二三四五六日'[now.weekday()]} {now:%H:%M}")

    # ------------------------------------------------------------ 托盘
    def _build_tray(self) -> None:
        self._tray = QSystemTrayIcon(self._make_icon(), self)
        self._tray.setToolTip("见微 · 高考学习舱")
        menu = QMenu()
        menu.setStyleSheet(
            "QMenu{background:#FFFFFF;color:#081F5C;border:1px solid #E6EAF1;padding:6px;}"
            "QMenu::item{padding:6px 26px 6px 16px;border-radius:3px;font-size:12px;}"
            "QMenu::item:selected{background:#F2F5FB;}"
            "QMenu::separator{height:1px;background:#EDF0F6;margin:4px 8px;}")
        for text, fn in (("打开见微", self._tray_show),
                         ("观澜浮窗", self.toggle_guanlan),
                         ("倒计时胶囊", self.toggle_pill),
                         ("习题台", lambda: self.open_studio("")),
                         ("格物实验台", lambda: self.open_lab("")),
                         ("暮省全屏", self.evening),
                         ("立即更新内容", self.refresh_guanlan)):
            a = QAction(text, self)
            a.triggered.connect(fn)
            menu.addAction(a)
        menu.addSeparator()
        quit_action = QAction("退出见微", self)
        quit_action.triggered.connect(self.quit_app)
        menu.addAction(quit_action)
        self._tray.setContextMenu(menu)
        self._tray.activated.connect(
            lambda r: self._tray_show() if r in (QSystemTrayIcon.ActivationReason.Trigger,
                                                 QSystemTrayIcon.ActivationReason.DoubleClick) else None)
        self._tray.show()

    def _tray_show(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _make_icon(self) -> QIcon:
        pm = QPixmap(64, 64)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.INK)
        p.drawRoundedRect(QRectF(4, 4, 56, 56), 14, 14)
        p.setPen(QPen(QColor("#F7F2EB")))
        p.setFont(f(26, 700, 0))
        p.drawText(QRectF(4, 4, 56, 56), int(Qt.AlignmentFlag.AlignCenter), "见")
        p.setBrush(C.ACCENT)
        p.drawEllipse(QRectF(44, 44, 8, 8))
        p.end()
        return QIcon(pm)

    # ------------------------------------------------------------ 提示
    def toast(self, text: str) -> None:
        self.toast_sig.emit(text)

    def _show_toast(self, text: str) -> None:
        self._toast.setText(text)
        self._toast.adjustSize()
        self._toast.move(max(16, (self.surface.width() - self._toast.width()) // 2), self.surface.height() - 56)
        self._toast.show()
        self._toast.raise_()
        QTimer.singleShot(2400, self._toast.hide)

    # ------------------------------------------------------------ 配置
    def save(self) -> None:
        store.save_config(self.cfg)

    def apply_pill(self) -> None:
        self.save()
        if self.pill is not None and self.pill.isVisible():
            self.pill.apply_config(self.cfg)
            self.pill.update()

    def preset_pill(self, w: int, h: int) -> None:
        self.cfg["width"], self.cfg["height"] = w, h
        self.apply_pill()
        if self.pill is not None:
            self.pill.apply_config(self.cfg)
        self.toast(f"已切换 {w}×{h}")

    def center_pill(self) -> None:
        self.cfg["pillX"] = None
        self.apply_pill()
        if self.pill is not None:
            self.pill.apply_config(self.cfg)
        self.toast("已回到顶部居中")

    def show_pill(self, on: bool, quiet: bool = False) -> None:
        if on:
            if self.pill is None:
                self.pill = CountdownPill(self.cfg)
            self.pill.apply_config(self.cfg)
            self.pill.show()
            self.pill.raise_()
            self.cfg["showPill"] = True
        else:
            if self.pill is not None:
                self.pill.hide()
            self.cfg["showPill"] = False
        self.save()
        if not quiet:
            self.toast("胶囊已显示" if on else "胶囊已隐藏")

    def toggle_pill(self) -> None:
        self.show_pill(not (self.pill is not None and self.pill.isVisible()))

    # ------------------------------------------------------------ 模块
    def toggle_guanlan(self) -> None:
        self.cfg["showGuanlan"] = self.guanlan.toggle()
        self.save()
        QTimer.singleShot(120, self._sync_pill_reserve)
        self.toast("观澜浮窗已打开" if self.cfg["showGuanlan"] else "观澜浮窗已收起")

    def evening(self) -> None:
        self.guanlan.evening()
        self.toast("正在生成今晚的暮省页")

    def refresh_guanlan(self) -> None:
        def work():
            try:
                self.guanlan._ensure_home()
                self.guanlan._ensure_path()
                from core.curator import run as run_curator  # type: ignore
                run_curator(force=True, log_fn=lambda *_: None)
                self.toast_sig.emit("观澜内容已更新")
            except Exception as exc:
                self.toast_sig.emit(f"更新失败：{exc}")
        self.toast("正在更新观澜内容…")
        threading.Thread(target=work, daemon=True).start()

    def open_studio(self, qid: str = "", lab: bool = False, mode: str = "") -> None:
        ok = self.studio.open(qid, lab=lab, mode=mode)
        if not ok:
            self.toast("未找到 Edge，请先安装或改用网页版")

    def open_lab(self, mode: str = "") -> None:
        self.open_studio("", lab=True, mode=mode)

    def open_question(self, qid: str) -> None:
        self.open_studio(qid)

    def random_question(self) -> None:
        import random
        qs = store.questions()
        if not qs:
            self.toast("题库为空")
            return
        q = random.choice(qs)
        self.open_studio(q["id"])
        self.toast(f"{q['subject']} · {q['title']}")

    def rescan_bank(self) -> None:
        store._QS = None
        self._build_pages()
        n = len(store.questions())
        self.toast(f"题库已重扫：{n} 题")

    # ------------------------------------------------------------ 自启
    def autostart_enabled(self) -> bool:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_READ)
            try:
                winreg.QueryValueEx(key, "JianweiSuite")
                return True
            finally:
                winreg.CloseKey(key)
        except Exception:
            return False

    def set_autostart(self, on: bool) -> None:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
            if on:
                exe = sys.executable
                if getattr(sys, "frozen", False):
                    cmd = f'"{exe}" --background'
                else:
                    cmd = f'"{exe}" "{os.path.join(os.path.dirname(__file__), "main.py")}" --background'
                winreg.SetValueEx(key, "JianweiSuite", 0, winreg.REG_SZ, cmd)
            else:
                try:
                    winreg.DeleteValue(key, "JianweiSuite")
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
            self.toast("开机自启已开启" if on else "开机自启已关闭")
        except Exception as exc:
            self.toast(f"设置失败：{exc}")
