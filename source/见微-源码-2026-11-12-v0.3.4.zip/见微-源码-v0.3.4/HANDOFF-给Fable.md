# 交接给 Fable 5.2（2026-11-10）

你接手的是用户的「见微」——一个 PySide6 学习桌面程序。本文是 Claude（Opus 5.5）这几轮工作的上下文，读完就能接着干。

## 项目与路径

- 源码：`F:\space for Claude\jianwei\src2`（app 代码在 `app\`；入口 `app\main.py`；版本号在 `app\store.py` 的 `VERSION`，**当前是 0.3.4**）。
- Python：`F:\space for Claude\jianwei\.venv\Scripts\python.exe`。
- 发行：在 `src2` 下依次运行 `python tools/release.py build`、`smoke`、`pack`。产物放在 `F:\space for Claude\jianwei\release-<版本>-<日期>\`，然后复制到 **`F:\AI\`**（用户 2026-11-10 新指定的位置；更早的版本都在桌面 `AI\jianwei\`）。
- 版本命名：1.x 改名为 0.1.x，2.x 改名为 0.2.x，整合 OpenMAIC 后是 0.3.x。`backup._version` 会把旧的三段式 1.x/2.x 映射到 0.1/0.2，这样旧备份不会被判成「更新的版本」。
- GPT 也在同一个 `src2` 目录里开发、出版本：动版本号前先看 `store.VERSION`；给 GPT 的交接写在 `HANDOFF-给GPT.md` 末尾，或者单独写一个 `PROMPT-*.md`。

## 0.3.0 做了什么：整合 OpenMAIC

OpenMAIC v1.4.2 是清华的多智能体 AI 互动课堂（Next.js 16 + PostgreSQL，MIT 许可），现在是见微的「课堂」模式（Ctrl+6）。

- **服务端（Claude 写）**：`app\native\classroom\service.py`。
  - 启动便携 PostgreSQL 16 和 Node 26 上的 OpenMAIC standalone 服务，DeepSeek 配置按见微的设置生成。
  - 闲置 10 分钟自动关；每次启动按 `server\links.json` 重建 pnpm 的 junction（`fix_links`）。
  - 遇到中文路径时，先转 8.3 短路径，转不出就改放 `%PUBLIC%\Jianwei\pg-*`。
  - 自测：`runtime_selftest.py`。
- **界面（GPT 写）**：`page.py`、`window.py`（Edge `--app` 独立窗口，独立的 user-data-dir）、`fake_service.py`、`selftest.py`（95 项）；析题答案卡上有「做成一堂课」。
- **运行包**：`F:\space for Claude\openmaic\runtime-dist`，由 `openmaic\assemble.py --src <构建好的 OpenMAIC 目录>` 生成。`release.py build` 会把它复制成绿色版里的 `classroom\`（不复制 junction）。
- **构建 OpenMAIC**：这台 8GB 机器只能用低内存 webpack 模式构建，配置在 `F:\space for Claude\openmaic\build-lowmem\`。关键是 `webpackBuildWorker: true`，并关闭 cache、minimize、devtool；约 11 分钟，峰值约 1.8GB。源码在 `F:\space for Claude\openmaic\OpenMAIC-1.4.2`；那里的依赖装在机械盘上，很慢。上次构建是在 `C:\omb` 做的，那个目录已交给用户手动删除。
- **实测**：首次启动约 43 秒，之后约 4 秒；空闲约 500MB；用 DeepSeek 生成一堂 4 页的课，峰值 621MB。真 Edge 窗口联调通过（打开、复用、关窗被检测到、服务停止）。

## 0.3.1 做了什么：主窗口、观澜、时间胶囊的性能与界面（Fable 5.2，2026-11-10）

用户的要求是「尽你所能地优化」这三块。细节在 `RELEASE-0.3.1.md`，这里只记以后改代码要知道的：

- **主窗口页面按需建**（`shell.py`）：`_builders` 里是六个建页函数，`_built` 记哪些页是新的；`goto()` 点到才建。数据变了调 `refresh_pages(keys)`，换主题走 `_drop_pages()` + `_build_pages()`。别再一次建六页。
- **页面配色在建的时候取**（`pages.py` 用 `ui_kit.lab(text, size, tone)`，tone 是 `C` 上的语义名）。`restyle_tree` 还留着，只处理写了旧色字面量的控件；新代码不要再写 `#081F5C` 这类旧色。
- **自绘控件**：`ui_kit.Check`（带对勾）、`ui_kit.Combo`、`ui_kit.SmoothScroll`；`pages.QuestionList` 是整张自己画的题目索引（只画看得见的行）；`pages.Hero` 是今日页的时间尺。
- **过渡动画一律先问 `ui_kit.motion()` / `guanlan.ui.theme.motion()`**：自测（`JIANWEI_SELFTEST=1` 或离屏）时返回 False，不然截图会截到过渡到一半。
- **应用级事件过滤器要先做便宜的判断**（`isinstance`），再取 `event.type()`。观澜的过滤器只在浮窗展开可见时挂（`MainWindow._sync_watch`）。新加应用级过滤器前先想想能不能只挂在自己的控件上。
- **胶囊**（`countdown.py`）：`_tick` 平时只 `update(光点那一小块)`；`covered_by_foreground()` 判断被最大化窗口盖住后降到一秒一帧；`_grab_bg` 在壁纸、位置、尺寸都没变时直接返回。
- **`Shell.apply_pill(now=False)`** 默认稍后存盘（滑块拖动用）；一次性的操作传 `now=True`。
- 量性能的两个脚本思路（没有留在仓库里）：离屏建各页计时 + 截图；真窗口下用隔离的数据目录跑 `main.py --no-single --no-tray --background`，量子进程的 CPU 时间和内存（venv 的 python.exe 只是转发器，要量它的子进程；配置里先把 `autoFetch`、`autoEvening` 关掉，否则会联网、弹全屏暮省）。

## 0.3.2 做了什么：水墨皮肤、新按键、课件进主菜单（Fable 5.2，2026-11-11）

用户的原话：把课件独立到主菜单；再做一个和以前不同的主题（水墨或简单动画画风，「切记要好看」）；按键改到完美；界面要更清晰、简洁、直接。细节在 `RELEASE-0.3.2.md`。

- **皮肤是和昼夜正交的一维**：`ink`（水墨，默认）/ `celadon`（青瓷）。三处各有一套：`native/design/tokens.py`（`SKINS`、`set_skin`）、`ui_kit.py`（`_SKINS`、`apply_theme(theme, skin)`）、`guanlan/ui/theme.py`（`SKINS`、`use(name, skin)`）。换皮肤只走 `Shell.set_skin()` / `Shell._apply_look()`；配置键 `skin`、`themeMode`（auto/day/night）。加新皮肤要三处都加，并加进 `design/selftest.py` 的对比度检查。
- **按键**：主窗口的 `ui_kit.Btn` / `Chip` 是自己画的（`_Key`：悬停渐变、墨晕、焦点环），对象名是 `jbtn` / `jchip`；样式表里的 `#btn` 规则只给外来的原生按钮用。学习窗口的按键在 `design/widgets.qss()`，改成平的时特意保持了总高度和左右内边距（11 / 13 像素），有些按钮是按旧宽度写死的，内边距多 1 像素就会裁字。`draw_key` 不再画下沿。
- **页头**：`pages.Page` 现在是「标题 + 说明 + `page.action(...)`」；`kick` 参数不再显示。新页面照这个写，主键一页一个。
- **课件页**：`pages.build_lecture` 只是外壳；导入队列和放映器借学习窗口的 `LecturePage`（`Shell.lecture_backend()`，不显示学习窗口）。`Shell.play_lecture / import_lectures / delete_lecture`。每次点进课件页都会重建（课件可能在学习窗口里改过）。
- **水墨底图**在 `Shell._paint_ink`（纸筋、远山、窄栏山影），随 `_bg` 缓存；山形种子固定。试过加一轮朱砂日，像提醒红点，去掉了。
- 这台开发机**没有楷体、雅黑、宋体**（中文实际由 Noto Sans SC 显示）：别依赖没法在这里核对的字体。

## 0.3.3 做了什么：第三种风格「手绘」+ 三种布局（Fable 5.2，2026-11-12）

用户要「再做两种页面布局和一种风格，三种风格三种布局里选」。我把「页面布局」理解成主窗口导航的摆法（没有另做页面内部的排版）。

- **风格**（配置键 `skin`）：`ink` 水墨 / `celadon` 青瓷 / `doodle` 手绘。手绘在主窗口里画法不同：`ui_kit.doodle()` 为真时，`paint_card` 和 `_Key._paint_key` 画 2 像素墨线 + 硬边投影（`DROP`），样式表里的边框宽度也跟着变（`_qss` 里的 `bw`）。新的自绘卡片一律用 `paint_card(p, rect, ...)`，用它返回的矩形排内容。
- **布局**（配置键 `layout`）：`side` / `top` / `compact`，常量在 `shell.LAYOUTS`、`RAIL_W`、`TOP_H`。`Shell._build()` 把所有东西挂在 `_root` 下，`set_layout()` 整个拆掉重搭；导航键是 `shell.NavButton`（三种 mode），标题栏小键是 `shell.ShellIcon`。底图 `_paint_bg` / `_paint_ink` / `_paint_doodle` 都按 `rail_w`、`top_h` 画。`nav_buttons` 必须和 `NAV` 同序（顶栏里设置键靠右，建完会重排）。
- 加新风格：三处配色（tokens、ui_kit、guanlan theme）+ 设置页下拉的名字 + `design/selftest.py` 的对比度表。

## 0.3.4 做了什么：页面内部的三种排法（Fable 5.2，2026-11-12）

0.3.3 我把「页面布局」做成了导航位置，用户说要改的是**页面内部**。所以现在是两件事：导航位置（配置键 `layout`）和页面布局（配置键 `pageLayout`：`stack` 舒展 / `split` 分栏 / `dense` 紧凑）。

- 开关在 `ui_kit`：`PAGE_LAYOUT`、`set_page_layout()`、`split()`、`dense()`；`Shell.set_page_layout()` 拆掉所有页面按新排法重建。
- `pages.Page`：`page.body` 是主栏；分栏时多一个右栏，次要的块用 `page.add(w, side=True)`。另外两种排法没有右栏，`side=True` 的块按加入顺序排进主栏，所以**加入的顺序就是舒展排法下的顺序**。页面窄于 `SPLIT_MIN` 时右栏自动落到下面。
- 右栏只有 330 宽：一行里有好几个键或长字的卡片放不进去，要么在 `if split():` 里换个排法，要么留在主栏（设置页、今日页的复习记录就是这样）。新页面写完跑一遍溢出检查（`page.inner.width()` 不能超过 `page.area.viewport().width()`）。
- 紧凑：`Page` 的边距和标题、`Card` 的留白、`Hero.k`、`EntryTile` 高度、`QuestionList.ROW`、`DeckCard.W/TH` 各自看 `dense()`。

## 规矩（用户定的，必须遵守）

- 测试必须把 `JIANWEI_HOME` 和 `LOCALAPPDATA` 指到临时目录；不能碰用户真实的数据目录。
- **绝不打印、不写入日志用户的 DeepSeek 密钥**。真实密钥在 `%LOCALAPPDATA%\Jianwei\deepseek.env`，不要去复制它；测试要用密钥就向用户要，用完删掉副本。
- 不要乱杀进程（只停自己启动的）。WPS 测试留下的文稿用 COM 关闭。测试里不要启动 Word。不要有 Python 报错弹窗（`release.py` 已经配置好）。
- `E:\U盘备份` 里的真实课件只读。
- 不绕过验证码。
- 用户用中文交流，回复要简洁直白。

## 可能的下一步

- 课堂的 TTS/ASR 目前用浏览器原生，视频和图片生成都关着；可以考虑接入见微已有的语音。
- 绿色版多了约 0.5GB；可以研究精简 `server\node_modules`（比如 aws-sdk、mistral 等没用到的 provider）。
- 课堂生成的课和见微的讲台、析题互通（目前只做到复制题目）。
