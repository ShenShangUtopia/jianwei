"""见微 · 时间胶囊：贴在桌面上的一把「时间尺」。

从开学到高考铺成一条刻度：一周一格、一月一道长刻度，走过的是一道香槟金，朱砂指针是今天。
左边是印、剩余天数和时分，右边是时钟，尺的终点写着考试日。鼠标移到尺上能看任意一天还有多久；
拖动可以换位置（靠近屏幕中线会吸附），右键是常用操作，双击打开见微。

画面分三层：底（壁纸磨砂 + 墨 / 瓷底色）、动（指针的呼吸光）、面（文字和刻度）。
桌面浮窗把底和面各缓存成一张图，每帧只重画中间那层。
"""
from __future__ import annotations

import ctypes
import functools
import math
import os
import time
from datetime import datetime, timedelta

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import (QColor, QFont, QGuiApplication, QImage, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap, QPolygonF, QRadialGradient)
from PySide6.QtWidgets import QMenu, QToolTip, QWidget

from native.design.tokens import T, family
from ui_kit import MONO, NUM, UI
import store

WEEKDAYS = "一二三四五六日"
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x00000020
WS_EX_LAYERED = 0x00080000
WS_EX_NOACTIVATE = 0x08000000
WDA_EXCLUDEFROMCAPTURE = 0x00000011
HWND_BOTTOM = 1
HWND_TOPMOST = -1
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010

SNAP_PX = 16      # 离屏幕中线这么近就吸过去
DRAG_PX = 4       # 移动超过这么多才算拖动，手抖不算

# 两套底色：墨（放在深色壁纸或默认）、瓷（放在浅色壁纸）
STYLES = {
    "ink": dict(body=(12, 22, 20), fg=(244, 248, 246), needle="#EE6448", mark="#E4B863", line=(255, 255, 255), k=1.75,
                gold="#D9BC7C", gold2="#F6E7C4", digit=("#FFF9EC", "#DDC58F"), urgent=("#FFB7A3", "#EE6448")),
    "porcelain": dict(body=(246, 248, 244), fg=(20, 32, 29), needle="#C8402A", mark="#A87A2C", line=(20, 32, 29), k=2.0,
                      gold="#8A6A22", gold2="#B08C3A", digit=("#17231F", "#5E4C22"), urgent=("#D9553B", "#A8301C")),
}


# ---------------------------------------------------------------- 数据
def phase_week() -> str:
    """本学期第几周（以 9 月 1 日为第 1 周）。"""
    today = datetime.now()
    start = datetime(today.year if today.month >= 9 else today.year - 1, 9, 1)
    return str(max(1, (today - start).days // 7 + 1))


def _days_text(now: datetime, target: datetime) -> tuple[str, str]:
    total = (target - now).total_seconds()
    if total <= 0:
        return "0", "已到"
    return str(int(total // 86400)), "天"


def parse_milestones(text: str) -> list[dict]:
    """「2027-03-10 一模；2027-04-20 二模」→ 节点列表。写错的段落跳过。"""
    out = []
    for part in str(text or "").replace("；", ";").replace("\n", ";").split(";"):
        bits = part.split(None, 1)
        if not bits:
            continue
        try:
            datetime.strptime(bits[0], "%Y-%m-%d")
        except ValueError:
            continue
        out.append(dict(date=bits[0], label=(bits[1].strip() if len(bits) > 1 else "")[:8]))
    return out[:12]


def format_milestones(items) -> str:
    return "；".join(f"{m.get('date', '')} {m.get('label', '')}".strip() for m in items or [] if isinstance(m, dict))


def _span(cfg: dict) -> tuple[datetime, datetime]:
    target = store.target_dt(cfg)
    try:
        start = store.start_dt(cfg)
    except Exception:
        start = target - timedelta(days=280)
    if start >= target:
        start = target - timedelta(days=280)
    return start, target


def _frac(cfg: dict, when: datetime) -> float:
    start, target = _span(cfg)
    return min(1.0, max(0.0, (when - start).total_seconds() / max(1.0, (target - start).total_seconds())))


def describe_day(cfg: dict, when: datetime, now: datetime) -> str:
    """尺上某一天的说明（鼠标悬停用）。"""
    target = store.target_dt(cfg)
    day = when.date()
    gap = (day - now.date()).days
    head = f"{day.month} 月 {day.day} 日 周{WEEKDAYS[day.weekday()]}"
    rel = "今天" if gap == 0 else f"再过 {gap} 天" if gap > 0 else f"{-gap} 天前"
    left = (target.date() - day).days
    tail = f"距{cfg.get('label', '高考')}还有 {left} 天" if left > 0 else f"{cfg.get('label', '高考')}当天" if left == 0 else ""
    marks = [m.get("label", "") for m in cfg.get("milestones") or [] if isinstance(m, dict) and m.get("date") == day.isoformat()]
    return " · ".join(x for x in ([head, rel, tail] + [x for x in marks if x]) if x)


# ---------------------------------------------------------------- 样式
_LUMA_CACHE: dict = {}


def resolve_style(cfg: dict, bg: QPixmap | None) -> dict:
    """auto：按胶囊底下那片壁纸的亮度选墨或瓷，文字总能看清。"""
    name = str(cfg.get("pillStyle", "auto"))
    if name not in STYLES:
        name = "ink"
        if bg is not None and not bg.isNull() and str(cfg.get("pillStyle", "auto")) == "auto":
            key = bg.cacheKey()
            luma = _LUMA_CACHE.get(key)
            if luma is None:
                _LUMA_CACHE.clear()
                luma = bg.toImage().scaled(1, 1).pixelColor(0, 0).lightnessF()
                _LUMA_CACHE[key] = luma
            name = "porcelain" if luma > 0.62 else "ink"
    return STYLES[name]


def _rgba(rgb, a: float) -> QColor:
    return QColor(rgb[0], rgb[1], rgb[2], max(0, min(255, int(a))))


# ---------------------------------------------------------------- 版面
def _layout(w: float, h: float) -> dict:
    s = max(0.72, h / 64.0)
    seal = h - 18 * s
    x_seal = 9 * s
    x_num = x_seal + seal + 12 * s
    right_w = 124 * s
    x_right = w - h * 0.40 - right_w
    return dict(s=s, seal=seal, x_seal=x_seal, x_num=x_num, x_right=x_right, right_w=right_w,
                base=h * 0.62, top=h * 0.38, label_y=h * 0.13)


def _left_lines(cfg: dict, now: datetime, left: float) -> tuple[str, str]:
    """天数右边的两行：还差几时几分；这是距什么、第几周。"""
    if left <= 0:
        line1 = "已到"
    else:
        rest = int(left % 86400)
        line1 = f"天 {rest // 3600} 时 {rest % 3600 // 60:02d} 分"
    return line1, f"距 {cfg.get('year', '2027')} {cfg.get('label', '高考')} · 第 {phase_week()} 周"


def _days_block_width(cfg: dict, now: datetime, s: float) -> float:
    """天数 + 右边两行小字占多宽：决定尺从哪里开始。"""
    from PySide6.QtGui import QFontMetricsF
    target = store.target_dt(cfg)
    days, _unit = _days_text(now, target)
    num_w = QFontMetricsF(_font(_num_family(), 42 * s, 600)).horizontalAdvance(days)
    a, b = _left_lines(cfg, now, (target - now).total_seconds())
    w1 = QFontMetricsF(_font(UI, max(11.5, 13 * s), 700)).horizontalAdvance(a)
    w2 = QFontMetricsF(_font(UI, max(10, 11 * s), 400)).horizontalAdvance(b)
    return num_w + 9 * s + max(w1, w2)


def ruler_geometry(w: float, h: float, cfg: dict, now: datetime) -> tuple[float, float]:
    g = _layout(w, h)
    x0 = g["x_num"] + _days_block_width(cfg, now, g["s"]) + 24 * g["s"]
    x1 = g["x_right"] - 22 * g["s"]
    return x0, max(x0 + 40, x1)


def needle_x(w: float, h: float, cfg: dict, now: datetime) -> float:
    x0, x1 = ruler_geometry(w, h, cfg, now)
    return x0 + (x1 - x0) * _frac(cfg, now)


def day_at(x: float, w: float, h: float, cfg: dict, now: datetime) -> datetime | None:
    """窗口坐标 x 落在尺上的哪一天；不在尺上返回 None。"""
    x0, x1 = ruler_geometry(w, h, cfg, now)
    if x < x0 - 4 or x > x1 + 4:
        return None
    start, target = _span(cfg)
    k = min(1.0, max(0.0, (x - x0) / max(1.0, x1 - x0)))
    return start + (target - start) * k


# ---------------------------------------------------------------- 绘制
def draw_pill(p: QPainter, w: float, h: float, cfg: dict, now: datetime,
              bg: QPixmap | None, phase: float) -> None:
    """把胶囊画进 painter（坐标 0..w/0..h）。设置页预览与桌面浮窗共用。"""
    draw_pill_base(p, w, h, cfg, bg)
    draw_pill_motion(p, w, h, cfg, phase, now, bg)
    draw_pill_top(p, w, h, cfg, now, bg)


def _pill_path(w: float, h: float) -> QPainterPath:
    path = QPainterPath()
    path.addRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), h / 2.0, h / 2.0)
    return path


def draw_pill_base(p: QPainter, w: float, h: float, cfg: dict, bg: QPixmap | None) -> None:
    st = resolve_style(cfg, bg)
    path = _pill_path(w, h)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setClipPath(path)
    if bg is not None and not bg.isNull():
        p.drawPixmap(0, 0, int(w), int(h), bg)
    alpha = int(cfg.get("shade", 108)) * st["k"]
    grad = QLinearGradient(0, 0, 0, h)
    grad.setColorAt(0.0, _rgba(st["body"], alpha * 0.90))
    grad.setColorAt(1.0, _rgba(st["body"], alpha * 1.10))
    p.fillPath(path, grad)
    p.restore()


def glow_rect(w: float, h: float, x: float) -> QRectF:
    """呼吸光占的那一小块（指针脚下）：桌面浮窗每帧只重画这里。"""
    g = _layout(w, h)
    r = 12 * g["s"] + 2
    return QRectF(x - r, g["base"] - r, 2 * r, 2 * r)


def draw_pill_motion(p: QPainter, w: float, h: float, cfg: dict, phase: float,
                     now: datetime | None = None, bg: QPixmap | None = None, x: float | None = None) -> None:
    """指针的呼吸光：很慢、很淡，只是告诉你它是活的。x 是指针位置，调用方算过就传进来。"""
    k = int(cfg.get("aurora", 96)) / 100.0
    if k <= 0:
        return
    now = now or datetime.now()
    st = resolve_style(cfg, bg)
    g = _layout(w, h)
    if x is None:
        x = needle_x(w, h, cfg, now)
    y = g["base"]
    r = 12 * g["s"]
    breath = 0.55 + 0.45 * math.sin(phase * 1.0)
    rg = QRadialGradient(x, y, r)
    c0 = QColor(st["needle"])
    c0.setAlpha(int(min(150, 92 * k * breath)))
    c1 = QColor(st["needle"])
    c1.setAlpha(0)
    rg.setColorAt(0.0, c0)
    rg.setColorAt(1.0, c1)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setClipPath(_pill_path(w, h))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(rg)
    p.drawEllipse(QRectF(x - r, y - r, 2 * r, 2 * r))
    p.restore()


def _draw_ruler(p: QPainter, x0: float, x1: float, g: dict, h: float, cfg: dict, now: datetime, st: dict) -> None:
    from PySide6.QtGui import QFontMetricsF
    s, base, top = g["s"], g["base"], g["top"]
    start, target = _span(cfg)
    total = max(1.0, (target - start).total_seconds())
    width = x1 - x0
    frac = _frac(cfg, now)
    fg, line = st["fg"], st["line"]
    gold, gold2 = QColor(st["gold"]), QColor(st["gold2"])
    nx = x0 + width * frac

    def x_of(when: datetime) -> float:
        return x0 + width * min(1.0, max(0.0, (when - start).total_seconds() / total))

    p.save()
    # 周刻度：立在进度条上。格子太密就两周一格
    weeks = max(1, int(total // (86400 * 7)))
    step = 1
    while width / (weeks / step) < 4.5 * s and step < 8:
        step *= 2
    p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
    tick = base - 5 * s
    for i in range(0, weeks + 1, step):
        x = x0 + width * i / weeks
        p.setPen(QPen(_rgba(line, 150 if i / weeks <= frac else 58), 1))
        p.drawLine(QPointF(x, tick), QPointF(x, base - 1))

    # 终点的字：什么时候、考什么
    end_text = f"{cfg.get('label', '高考')} {target.month}/{target.day}"
    label_font = _font(UI, max(10, 11 * s), 500)
    end_font = _font(UI, max(10, 11 * s), 700)
    end_w = QFontMetricsF(end_font).horizontalAdvance(end_text)
    label_rect = lambda x, wd: QRectF(x, g["label_y"], wd, top - g["label_y"])  # noqa: E731

    # 月份：长刻度 + 标签；放不下就隔一个写，碰到终点字和指针帽的不写
    months = []
    y, m = start.year, start.month
    while True:
        when = datetime(y, m, 1)
        if when > target:
            break
        if when >= start:
            months.append(when)
        m += 1
        if m == 13:
            y, m = y + 1, 1
    gap = width / max(1, len(months))
    every = 1 if gap >= 28 * s else 2 if gap >= 15 * s else 3
    p.setFont(label_font)
    fm = QFontMetricsF(label_font)
    for i, when in enumerate(months):
        x = x_of(when)
        passed = x <= nx
        p.setPen(QPen(_rgba(line, 205 if passed else 92), 1))
        p.drawLine(QPointF(x, base - 10 * s), QPointF(x, base - 1))
        text = f"{when.month}月"
        tw = fm.horizontalAdvance(text)
        clash = abs(x + tw / 2 - nx) < tw / 2 + 7 * s or x + tw > x1 - end_w - 8 * s
        if i % every == 0 and not clash:
            p.setPen(_rgba(fg, 185 if passed else 112))
            p.drawText(label_rect(x, tw + 4), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), text)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    # 进度条：走过的一段是一道香槟金，比只看刻度直观
    bar_h = max(2.4, 3.0 * s)
    bar = QRectF(x0, base, width, bar_h)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_rgba(line, 34))
    p.drawRoundedRect(bar, bar_h / 2, bar_h / 2)
    fill = QLinearGradient(x0, 0, max(nx, x0 + 1), 0)
    c0 = QColor(gold)
    c0.setAlpha(150)
    fill.setColorAt(0, c0)
    fill.setColorAt(1, gold2)
    p.setBrush(fill)
    p.drawRoundedRect(QRectF(x0, base, max(bar_h, nx - x0), bar_h), bar_h / 2, bar_h / 2)

    # 今天的说明：指针下面一行字
    cap = f"今天 · 已走 {int(frac * 100)}%"
    cap_font = _font(UI, max(10, 10.5 * s), 400)
    cap_w = QFontMetricsF(cap_font).horizontalAdvance(cap)
    cap_x = max(x0, min(x1 - cap_w, nx - cap_w / 2))
    cap_y = base + bar_h + 2 * s
    cap_h = h - cap_y - 3 * s
    p.setFont(cap_font)
    p.setPen(_rgba(fg, 170))
    p.drawText(QRectF(cap_x, cap_y, cap_w + 2, cap_h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), cap)

    # 自己加的节点（一模、二模……）：小菱形 + 名字；和今天的说明撞上就只留菱形
    mark = QColor(st["mark"])
    for item in cfg.get("milestones") or []:
        try:
            when = datetime.strptime(str(item.get("date")), "%Y-%m-%d")
        except (ValueError, AttributeError):
            continue
        if not start <= when <= target:
            continue
        x = x_of(when)
        d = 3.4 * s
        cy = base + bar_h / 2
        p.setPen(QPen(_rgba(st["body"], 255), 1))
        p.setBrush(mark)
        p.drawPolygon(QPolygonF([QPointF(x, cy - d), QPointF(x + d, cy), QPointF(x, cy + d), QPointF(x - d, cy)]))
        label = str(item.get("label") or "")
        if label:
            lw = QFontMetricsF(cap_font).horizontalAdvance(label)
            if not (cap_x - 6 < x + lw / 2 and x - lw / 2 < cap_x + cap_w + 6):
                p.setFont(cap_font)
                p.setPen(mark)
                p.drawText(QRectF(x - lw / 2 - 1, cap_y, lw + 2, cap_h), int(Qt.AlignmentFlag.AlignCenter), label)

    # 终点：一道金线 + 字
    p.setPen(QPen(gold, 1.6))
    p.drawLine(QPointF(x1, top + 1), QPointF(x1, base + bar_h))
    p.setFont(end_font)
    p.setPen(gold)
    p.drawText(QRectF(x1 - end_w - 2, g["label_y"], end_w + 4, top - g["label_y"]), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), end_text)

    # 今天：朱砂指针 + 金色小钉
    needle = QColor(st["needle"])
    p.setPen(QPen(needle, 2))
    p.drawLine(QPointF(nx, top - 1), QPointF(nx, base + bar_h + 1))
    knob = 3.0 * s
    p.setPen(QPen(gold2, 1))
    p.setBrush(needle)
    p.drawEllipse(QPointF(nx, top - 2), knob, knob)
    p.restore()


def _hairline(p: QPainter, x: float, h: float, st: dict) -> None:
    """块与块之间一道两头渐隐的细线。"""
    g = QLinearGradient(0, h * .2, 0, h * .8)
    g.setColorAt(0, _rgba(st["line"], 0))
    g.setColorAt(.5, _rgba(st["line"], 60))
    g.setColorAt(1, _rgba(st["line"], 0))
    p.setPen(QPen(g, 1))
    p.drawLine(QPointF(x, h * .2), QPointF(x, h * .8))


def draw_pill_top(p: QPainter, w: float, h: float, cfg: dict, now: datetime, bg: QPixmap | None = None) -> None:
    st = resolve_style(cfg, bg)
    g = _layout(w, h)
    s = g["s"]
    fg = st["fg"]
    gold = QColor(st["gold"])
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    # 描边：一圈极细的金线，两端略亮，中段隐去
    rim = QLinearGradient(0, 0, w, 0)
    for at, alpha in ((0, 130), (.22, 56), (.5, 38), (.78, 56), (1, 130)):
        c = QColor(gold)
        c.setAlpha(alpha)
        rim.setColorAt(at, c)
    p.setPen(QPen(rim, 1.0))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRoundedRect(QRectF(0.6, 0.6, w - 1.2, h - 1.2), h / 2 - .4, h / 2 - .4)
    # 顶上一道内高光：像釉面
    p.setPen(QPen(_rgba(st["line"] if st is STYLES["ink"] else (255, 255, 255), 26 if st is STYLES["ink"] else 150), 1))
    p.drawLine(QPointF(h * .55, 1.6), QPointF(w - h * .55, 1.6))

    # 印：嵌在半圆里，外面一圈金
    d = g["seal"]
    rect = QRectF(g["x_seal"], (h - d) / 2, d, d)
    p.setPen(QPen(gold, 1))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawEllipse(rect.adjusted(-2.5 * s, -2.5 * s, 2.5 * s, 2.5 * s))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#C8402A"))
    p.drawEllipse(rect)
    p.setFont(_font(family("serif"), d * .56, 700))
    p.setPen(QColor("#FFFFFF"))
    p.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), "见")

    # 天数：画面里最大的东西。淡金渐变，不发光
    target = store.target_dt(cfg)
    days, _unit = _days_text(now, target)
    left = (target - now).total_seconds()
    urgent = 0 < left <= 100 * 86400
    p.setFont(_font(_num_family(), 42 * s, 600))
    num_w = p.fontMetrics().horizontalAdvance(days)
    colors = st["urgent"] if urgent else st["digit"]
    num = QLinearGradient(0, h * .2, 0, h * .8)
    num.setColorAt(0, QColor(colors[0]))
    num.setColorAt(1, QColor(colors[1]))
    p.setPen(QPen(num, 1))
    p.drawText(QRectF(g["x_num"], 0, num_w + 6, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), days)

    # 右边两行：几时几分、距什么
    lx = g["x_num"] + num_w + 9 * s
    line1, line2 = _left_lines(cfg, now, left)
    room = _days_block_width(cfg, now, s) - num_w - 9 * s + 8
    p.setFont(_font(UI, max(11.5, 13 * s), 700))
    p.setPen(_rgba(fg, 245))
    p.drawText(QRectF(lx, h * .15, room, h * .36), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), line1)
    p.setFont(_font(UI, max(10, 11 * s), 400))
    p.setPen(_rgba(fg, 172))
    p.drawText(QRectF(lx, h * .50, room, h * .32), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), line2)

    # 时间尺
    x0, x1 = ruler_geometry(w, h, cfg, now)
    if x1 - x0 >= 60:
        _hairline(p, x0 - 12 * s, h, st)
        _hairline(p, x1 + 13 * s, h, st)
        _draw_ruler(p, x0, x1, g, h, cfg, now, st)

    # 时钟：一眼能读
    rx, rw = g["x_right"], g["right_w"]
    show_date = cfg.get("showDate", True)
    clock_h = h * (.60 if show_date else 1.0)
    align_v = Qt.AlignmentFlag.AlignBottom if show_date else Qt.AlignmentFlag.AlignVCenter
    big = _font(_num_family(), max(19, 27 * s), 500)
    main = now.strftime("%H:%M")
    sec_w = 0.0
    if cfg.get("showSeconds", True):
        sec = now.strftime(":%S")
        p.setFont(_font(_num_family(), max(11, 14 * s), 500))
        sec_w = p.fontMetrics().horizontalAdvance(sec)
        p.setPen(gold)
        p.drawText(QRectF(rx, 0, rw, clock_h - 2.4 * s), int(Qt.AlignmentFlag.AlignRight | align_v), sec)
    p.setFont(big)
    p.setPen(_rgba(fg, 255))
    p.drawText(QRectF(rx, 0, rw - sec_w - 1, clock_h), int(Qt.AlignmentFlag.AlignRight | align_v), main)
    if show_date:
        p.setFont(_font(UI, max(10, 11 * s), 400))
        p.setPen(_rgba(fg, 172))
        p.drawText(QRectF(rx, h * .62, rw, h * .28), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter),
                   f"{now.month} 月 {now.day} 日 周{WEEKDAYS[now.weekday()]}")
    p.restore()


_NUM_FAMILY = None


def _num_family() -> str:
    """数字用等高的仪表字体（旧式数字的 5、9 会掉到基线下面）。"""
    global _NUM_FAMILY
    if _NUM_FAMILY is None:
        from PySide6.QtGui import QFontDatabase
        fams = set(QFontDatabase.families())
        _NUM_FAMILY = next((f for f in ("Bahnschrift", "Segoe UI", "Cambria") if f in fams), NUM)
    return _NUM_FAMILY


@functools.lru_cache(maxsize=64)
def _font(family_name: str, px: float, weight: int = 400, spacing: float = 0.0) -> QFont:
    font = QFont(family_name)
    font.setPixelSize(max(7, int(round(px))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    font.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    return font


# 帧率：呼吸光很慢，10 fps 看不出差别；关掉光效时只有时钟要走；被最大化窗口盖住时一秒一次就够
FRAME_IDLE_MS = 100
FRAME_STILL_MS = 250
FRAME_COVERED_MS = 1000


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def covered_by_foreground(hwnd: int) -> bool:
    """前台是不是一个最大化 / 全屏的窗口，而且和胶囊在同一块屏幕上。

    胶囊默认沉在最底层：这种时候它整个被盖住，呼吸光没人看得见，不必一秒画十次。
    判断只用几个轻量的系统调用；拿不准一律算「没盖住」。
    """
    try:
        user32 = ctypes.windll.user32
        fg = int(user32.GetForegroundWindow() or 0)
        if not fg or fg == hwnd or user32.IsIconic(fg) or not user32.IsWindowVisible(fg):
            return False
        cls = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(fg, cls, 64)
        if cls.value in ("Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow"):
            return False    # 桌面、任务栏、开始菜单：胶囊就是给这时候看的
        mon_fg = user32.MonitorFromWindow(fg, 0)
        mon_me = user32.MonitorFromWindow(hwnd, 0)
        if not mon_fg or not mon_me or mon_fg != mon_me:
            return False
        if user32.IsZoomed(fg):
            return True
        mine, theirs = _RECT(), _RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(mine)) or not user32.GetWindowRect(fg, ctypes.byref(theirs)):
            return False
        return (theirs.left <= mine.left and theirs.top <= mine.top
                and theirs.right >= mine.right and theirs.bottom >= mine.bottom)
    except Exception:
        return False


class CountdownPill(QWidget):
    moved = Signal(object, int)   # 屏幕水平位置（None 表示居中）、距顶部
    action = Signal(str)          # 右键和双击的操作，由主壳处理

    def __init__(self, cfg: dict):
        super().__init__(None, Qt.WindowType.FramelessWindowHint
                         | Qt.WindowType.Tool
                         | Qt.WindowType.WindowDoesNotAcceptFocus
                         | Qt.WindowType.NoDropShadowWindowHint)
        self.cfg = dict(cfg)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setMouseTracking(True)
        self.setWindowTitle("见微 · 时间胶囊")
        self._bg: QPixmap | None = None
        self._bg_at = 0.0
        self._t0 = time.monotonic()
        self._press: QPoint | None = None   # 按下时鼠标相对窗口的位置
        self._dragging = False
        self._hover_x: float | None = None
        self._base: QPixmap | None = None   # 底层缓存：尺寸 / 配置 / 壁纸变了才重画
        self._top: QPixmap | None = None    # 面层缓存：每秒（时钟变了）重画一次
        self._top_key = None
        self._cover = None                  # 铺满屏幕的壁纸，屏幕尺寸或壁纸文件变了才重算
        self._cover_key = None
        self._bg_sig = None                 # 上次取磨砂底时的（壁纸、位置、尺寸）：没变就不重取
        self._needle = 0.0                  # 指针位置，随面层一起算一次
        self._shown_key = None              # 屏幕上现在画的是哪一秒 / 哪一分
        self._covered = False               # 被最大化窗口盖住了：降到一秒一帧
        self._covered_at = 0.0
        self._fade = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._z_timer = QTimer(self)
        self._z_timer.timeout.connect(self._assert_zorder)
        self.apply_config(self.cfg)
        self._timer.start(FRAME_IDLE_MS)

    # ------------------------------------------------------------ 配置
    def _screen_geo(self):
        return (self.screen() or QGuiApplication.primaryScreen()).availableGeometry()

    def apply_config(self, cfg: dict) -> None:
        self.cfg = dict(cfg)
        self._base = None
        self._top = None
        w = int(cfg.get("width", 880))
        h = int(cfg.get("height", 64))
        screen = QGuiApplication.primaryScreen().availableGeometry()
        x = cfg.get("pillX")
        if isinstance(x, int):
            # 换过屏幕或分辨率时，不能把胶囊留在看不见的地方
            full = QGuiApplication.primaryScreen().virtualGeometry()
            x = max(full.left(), min(full.right() - w + 1, x))
        else:
            x = screen.x() + (screen.width() - w) // 2
        y = screen.y() + max(0, min(screen.height() - h, int(cfg.get("marginTop", 22))))
        self.setGeometry(x, y, w, h)
        self.setWindowOpacity(float(cfg.get("opacity", 0.98)))
        self._apply_flags()
        self._assert_zorder()
        self.update()

    def _assert_zorder(self) -> None:
        """默认沉到最底层：只在桌面 / 壁纸上可见，任何应用窗口都能压住它。"""
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_NOACTIVATE
            if self.cfg.get("clickThrough"):
                style |= WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
            target = HWND_TOPMOST if str(self.cfg.get("zorder", "bottom")) == "top" else HWND_BOTTOM
            user32.SetWindowPos(hwnd, target, 0, 0, 0, 0,
                                SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)
        except Exception:
            pass

    def _apply_flags(self) -> None:
        if not self.isVisible():
            return
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_LAYERED
            if self.cfg.get("clickThrough"):
                style |= WS_EX_TRANSPARENT
            else:
                style &= ~WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        except Exception:
            pass

    def showEvent(self, ev) -> None:
        super().showEvent(ev)
        try:
            ctypes.windll.user32.SetWindowDisplayAffinity(int(self.winId()), WDA_EXCLUDEFROMCAPTURE)
        except Exception:
            pass
        self._apply_flags()
        self._assert_zorder()
        self._grab_bg()
        # 频繁重申置底会和别的置底窗互相抢，画面一直在闪；1 分钟兜底一次
        self._z_timer.start(60000)
        if not self._timer.isActive():
            self._timer.start(FRAME_IDLE_MS)
        self._fade_in()

    def _fade_in(self) -> None:
        """出现时淡入，不是「啪」地贴上桌面。"""
        from PySide6.QtCore import QEasingCurve, QPropertyAnimation
        if os.environ.get("JIANWEI_SELFTEST") == "1" or os.environ.get("QT_QPA_PLATFORM") == "offscreen":
            return
        target = float(self.cfg.get("opacity", 0.98))
        self.setWindowOpacity(0.0)
        anim = QPropertyAnimation(self, b"windowOpacity", self)
        anim.setDuration(260)
        anim.setStartValue(0.0)
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade = anim
        anim.start()

    def hideEvent(self, ev) -> None:
        self._z_timer.stop()
        self._timer.stop()      # 藏起来以后一帧都不用算
        super().hideEvent(ev)

    # ------------------------------------------------------------ 帧
    def _clock_key(self, now: datetime):
        """面层什么时候要重画：显示秒就每秒，不显示秒每分钟一次就够。"""
        return now.strftime("%Y%m%d%H%M%S" if self.cfg.get("showSeconds", True) else "%Y%m%d%H%M")

    def _tick(self) -> None:
        if not self.isVisible():
            return
        now = time.monotonic()
        if now - self._bg_at > 30:
            self._grab_bg()
            self._bg_at = now
        if now - self._covered_at >= 1.0:
            self._covered_at = now
            self._covered = (str(self.cfg.get("zorder", "bottom")) != "top"
                             and covered_by_foreground(int(self.winId())))
        glow = int(self.cfg.get("aurora", 96)) > 0 and not self._covered
        interval = FRAME_COVERED_MS if self._covered else FRAME_IDLE_MS if glow else FRAME_STILL_MS
        if self._timer.interval() != interval:
            self._timer.setInterval(interval)
        if self._top is None or self._base is None or self._clock_key(datetime.now()) != self._shown_key:
            self.update()                                   # 时钟走了一格：整条重画
        elif glow:
            w, h = self.width(), self.height()
            self.update(glow_rect(w, h, self._needle).toAlignedRect())   # 平时只有指针脚下那点光在动

    def resizeEvent(self, ev) -> None:
        self._base = None
        self._top = None
        self._bg_sig = None
        super().resizeEvent(ev)

    @staticmethod
    def _wallpaper_key():
        """当前壁纸文件 + 修改时间：用来判断要不要重新读图（换壁纸后 30 秒内跟上）。"""
        try:
            buf = ctypes.create_unicode_buffer(1024)
            ok = ctypes.windll.user32.SystemParametersInfoW(0x0073, 1024, buf, 0)
            path = buf.value
            if ok and path and os.path.exists(path):
                return path, os.path.getmtime(path)
        except Exception:
            pass
        return None

    def _load_wallpaper(self):
        key = self._wallpaper_key()
        if key is None:
            return None
        img = QImage(key[0])
        return None if img.isNull() else img

    def _grab_bg(self) -> None:
        """取壁纸对应位置的一小片，重采样到极低分辨率再放大 —— 磨砂玻璃的底。

        实时截屏在这里不可用：本机 SetWindowDisplayAffinity 失败，截出来会把胶囊自己
        拍进去（越拍越黑）。壁纸磨砂在视觉上等价，且永不递归、几乎不耗 CPU。
        """
        try:
            screen = (self.screen() or QGuiApplication.primaryScreen()).geometry()
            W, H = screen.width(), screen.height()
            w, h = max(2, self.width()), max(2, self.height())
            # 整张壁纸的平滑缩放要几十毫秒：只在壁纸文件或屏幕尺寸变了时重算，平时只裁一小块
            key = (self._wallpaper_key(), W, H)
            sig = (key, self.x(), self.y(), w, h)
            if sig == self._bg_sig:
                return      # 壁纸、位置、尺寸都没变：磨砂底还是那一张，三层缓存都留着
            self._bg_sig = sig
            if key != self._cover_key:
                self._cover_key = key
                img = self._load_wallpaper() if key[0] is not None else None
                if img is None:
                    self._cover = None
                else:
                    scale = max(W / max(1, img.width()), H / max(1, img.height()))
                    self._cover = img.scaled(int(img.width() * scale + 0.5), int(img.height() * scale + 0.5),
                                             Qt.AspectRatioMode.IgnoreAspectRatio,
                                             Qt.TransformationMode.SmoothTransformation)
            cover = self._cover
            if cover is None:
                if self._bg is not None:
                    self._bg = None
                    self._base = None
                return
            sw, sh = cover.width(), cover.height()
            ox = max(0, min(sw - w, self.x() - screen.x() + (sw - W) // 2))
            oy = max(0, min(sh - h, self.y() - screen.y() + (sh - H) // 2))
            crop = cover.copy(ox, oy, w, h)
            small = crop.scaled(max(6, w // 18), max(5, h // 18),
                                Qt.AspectRatioMode.IgnoreAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
            self._bg = QPixmap.fromImage(small.scaled(
                w, h, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation))
        except Exception:
            self._bg = None
            self._bg_sig = None
        self._base = None
        self._top = None   # 墨 / 瓷可能换了

    def _layer(self, draw) -> QPixmap:
        dpr = self.devicePixelRatioF()
        pm = QPixmap(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.GlobalColor.transparent)
        q = QPainter(pm)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        draw(q)
        q.end()
        return pm

    def paintEvent(self, _ev) -> None:
        w, h, cfg = self.width(), self.height(), self.cfg
        now = datetime.now()
        if self._base is None:
            self._base = self._layer(lambda q: draw_pill_base(q, w, h, cfg, self._bg))
        clock = self._clock_key(now)
        top_key = (clock, round(self.devicePixelRatioF(), 3))
        if self._top is None or self._top_key != top_key:
            self._top = self._layer(lambda q: draw_pill_top(q, w, h, cfg, now, self._bg))
            self._top_key = top_key
            self._needle = needle_x(w, h, cfg, now)     # 要量好几次字宽：跟着面层一秒算一次，不是每帧
        self._shown_key = clock
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.drawPixmap(0, 0, self._base)
        if not self._covered:
            draw_pill_motion(p, w, h, cfg, time.monotonic() - self._t0, now, self._bg, self._needle)
        p.drawPixmap(0, 0, self._top)
        if self._hover_x is not None:   # 悬停的那一天
            g = _layout(w, h)
            st = resolve_style(cfg, self._bg)
            p.setPen(QPen(_rgba(st["line"], 200), 1, Qt.PenStyle.DashLine))
            p.drawLine(QPointF(self._hover_x, g["top"] - 2), QPointF(self._hover_x, g["base"] + 4))
        p.end()

    # ------------------------------------------------------------ 鼠标
    def mousePressEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        if ev.button() == Qt.MouseButton.LeftButton:
            self._press = ev.position().toPoint()
            self._dragging = False

    def mouseMoveEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        if self._press is not None:
            pos = ev.position().toPoint()
            if not self._dragging and (pos - self._press).manhattanLength() >= DRAG_PX:
                self._dragging = True
                self._set_hover(None)
                QToolTip.hideText()
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
            if self._dragging:
                self.move(self._snapped(ev.globalPosition().toPoint() - self._press))
            return
        day = day_at(ev.position().x(), self.width(), self.height(), self.cfg, datetime.now())
        if day is None:
            self._set_hover(None)
            QToolTip.hideText()
        else:
            self._set_hover(ev.position().x())
            QToolTip.showText(ev.globalPosition().toPoint() + QPoint(0, 18), describe_day(self.cfg, day, datetime.now()), self)

    def _snapped(self, top_left: QPoint) -> QPoint:
        """靠近屏幕中线就吸过去；不让胶囊拖出屏幕。"""
        geo = self._screen_geo()
        x = top_left.x()
        mid = geo.x() + (geo.width() - self.width()) // 2
        if abs(x - mid) <= SNAP_PX:
            x = mid
        y = max(geo.y(), min(geo.bottom() - self.height() + 1, top_left.y()))
        return QPoint(x, y)

    def _set_hover(self, x) -> None:
        if x != self._hover_x:
            self._hover_x = x
            self.update()

    def leaveEvent(self, ev) -> None:
        self._set_hover(None)
        super().leaveEvent(ev)

    def mouseReleaseEvent(self, ev) -> None:
        if self._press is None:
            return
        was_drag = self._dragging
        self._press, self._dragging = None, False
        self.unsetCursor()
        if was_drag:
            self.cfg["pillX"] = self.x()
            self._grab_bg()
            geo = self._screen_geo()
            centered = self.x() == geo.x() + (geo.width() - self.width()) // 2
            self.cfg["pillX"] = None if centered else self.x()
            self.cfg["marginTop"] = self.y() - geo.y()
            self.moved.emit(self.cfg["pillX"], self.cfg["marginTop"])

    def mouseDoubleClickEvent(self, ev) -> None:
        if ev.button() == Qt.MouseButton.LeftButton and not self.cfg.get("clickThrough"):
            self._press, self._dragging = None, False
            self.action.emit("open")

    def contextMenuEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        QToolTip.hideText()
        self.build_menu().exec(ev.globalPos())

    def build_menu(self) -> QMenu:
        menu = QMenu(self)
        menu.setStyleSheet(
            f"QMenu{{background:{T.raised};color:{T.fg};border:1px solid {T.line2};padding:4px;font-size:12.5px;}}"
            f"QMenu::item{{padding:6px 24px 6px 12px;border-radius:3px;}}"
            f"QMenu::item:selected{{background:{T.hover};}}"
            f"QMenu::separator{{height:1px;background:{T.line};margin:4px 6px;}}"
            f"QMenu::indicator{{width:13px;height:13px;left:4px;}}")

        def add(text, key, checked=None):
            a = menu.addAction(text)
            if checked is not None:
                a.setCheckable(True)
                a.setChecked(checked)
            a.triggered.connect(lambda _=False, k=key: self.action.emit(k))
            return a
        add("打开见微", "open")
        add("观澜", "guanlan")
        add("习题台", "studio")
        menu.addSeparator()
        add("总在最前", "top", str(self.cfg.get("zorder", "bottom")) == "top")
        add("显示秒", "seconds", bool(self.cfg.get("showSeconds", True)))
        add("回到顶部居中", "center")
        add("胶囊设置…", "settings")
        menu.addSeparator()
        add("隐藏胶囊", "hide")
        return menu

    def closeEvent(self, ev) -> None:
        self._timer.stop()
        self._z_timer.stop()
        super().closeEvent(ev)


_ = (MONO,)
