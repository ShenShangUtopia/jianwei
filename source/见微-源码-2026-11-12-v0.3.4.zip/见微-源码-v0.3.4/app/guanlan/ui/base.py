"""观澜界面的基础控件：全部自己画，颜色都从 C 取。"""
from __future__ import annotations

import re

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, QSize, Qt, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import QColor, QFontMetrics, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QAbstractButton, QScrollArea, QSizePolicy, QWidget

from .icons import draw_icon
from .theme import C, font, mono, motion, serif, tint


class SmoothScrollArea(QScrollArea):
    """滚轮滚动带一小段缓动，长文读起来不跳。触控板的像素级滚动原样放行。"""

    STEP = 90
    MS = 200

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._target = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(self.MS)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(lambda v: self.verticalScrollBar().setValue(int(round(float(v)))))

    def wheelEvent(self, event) -> None:
        bar = self.verticalScrollBar()
        dy = event.angleDelta().y()
        if bar.maximum() <= 0 or dy == 0 or not event.pixelDelta().isNull() or not motion():
            super().wheelEvent(event)
            return
        running = self._anim.state() == QVariantAnimation.State.Running
        base = self._target if running else float(bar.value())
        self._target = max(float(bar.minimum()), min(float(bar.maximum()), base - dy / 120.0 * self.STEP))
        self._anim.stop()
        self._anim.setStartValue(float(bar.value()))
        self._anim.setEndValue(self._target)
        self._anim.start()
        event.accept()

    def stop_scroll(self) -> None:
        self._anim.stop()


class SnapFade(QWidget):
    """切页过渡：旧页面的截图盖在新页面上，朝切换方向滑出几像素并淡出。

    每帧只是贴一张图；不用 QGraphicsOpacityEffect（那会让整页每帧离屏重画一遍）。
    """

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._pm = None
        self._k = 0.0
        self._dir = 1
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(150)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.setStartValue(1.0)
        self._anim.setEndValue(0.0)
        self._anim.valueChanged.connect(self._step)
        self._anim.finished.connect(self._done)
        self.hide()

    def play(self, pixmap, direction: int = 1) -> None:
        self._anim.stop()
        self._pm, self._k, self._dir = pixmap, 1.0, direction
        self.setGeometry(self.parentWidget().rect())
        self.show()
        self.raise_()
        self._anim.start()

    def _step(self, value) -> None:
        self._k = float(value)
        self.update()

    def _done(self) -> None:
        self._pm = None
        self.hide()

    def paintEvent(self, event) -> None:
        if self._pm is None:
            return
        p = QPainter(self)
        p.setOpacity(self._k)
        p.fillRect(self.rect(), C.PANEL)
        p.drawPixmap(int(-self._dir * (1 - self._k) * 14), 0, self._pm)


class TextBlock(QWidget):
    """按中文标点规则换行、超长加省略号的一段字。fit() 后高度跟随实际行数。"""

    NO_START = set("，。、；：？！,.;:?!）)》」』”’】〉…—·%")   # 不能开行
    NO_END = set("（(《「『“‘【〈")                          # 不能收行

    TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:[’'\-][A-Za-z0-9]+)*|[ \t]+|[一-鿿]|.", re.S)

    def __init__(self, text: str = "", size: int = 13, weight: int = 400,
                 color: QColor | None = None, max_lines: int = 2,
                 line_height: float = 1.55, family: str | None = None,
                 parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self._font = font(size, weight, family)
        self._color = color or C.TEXT
        self._max_lines = max_lines
        self._line_height = round(self._font.pixelSize() * line_height)
        self.setFixedHeight(max(1, self._max_lines * self._line_height))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._lines: list[str] = []

    def setText(self, text: str) -> None:
        if text != self._text:
            self._text = text or ""
            self._lines = []
            if getattr(self, "_fit", False) and self.width() > 20:
                self.setFixedHeight(max(1, len(self._wrap())) * self._line_height)
            self.update()

    def text(self) -> str:
        return self._text

    def setColor(self, color: QColor) -> None:
        self._color = color
        self.update()

    def set_text_font(self, f, line_height: int | None = None) -> None:
        self._font = f
        self._line_height = line_height or max(1, round(f.pixelSize() * 1.55))
        self.setFixedHeight(max(1, self._max_lines * self._line_height))
        self._lines = []
        self.update()

    def fit(self) -> "TextBlock":
        self._fit = True
        return self

    def resizeEvent(self, event) -> None:
        self._lines = []
        super().resizeEvent(event)
        if getattr(self, "_fit", False):
            want = max(1, len(self._wrap())) * self._line_height
            if want != self.height():
                self.setFixedHeight(want)

    def _wrap(self) -> list[str]:
        if self._lines:
            return self._lines
        width = max(20, self.width())
        fm = QFontMetrics(self._font)
        lines: list[str] = []
        for paragraph in (self._text or "").split("\n"):
            cur = ""
            for token in self.TOKEN_RE.findall(paragraph):
                if token == "\n":
                    continue
                if token.isspace() and not cur:
                    continue
                candidate = cur + token
                if fm.horizontalAdvance(candidate) <= width or not cur:
                    cur = candidate
                elif token[0] in self.NO_START and len(cur) > 1 and not cur[-1].isspace():
                    lines.append(cur[:-1].rstrip())   # 避头：把前一个字一起带到下一行
                    cur = cur[-1] + token
                else:
                    carry = ""   # 避尾：开引号、开括号不留在行末
                    while len(cur) > 1 and cur[-1] in self.NO_END:
                        carry, cur = cur[-1] + carry, cur[:-1]
                    lines.append(cur.rstrip())
                    cur = carry + ("" if token.isspace() else token)
            if cur.strip():
                lines.append(cur.rstrip())
            if len(lines) > self._max_lines:
                break
        if len(lines) > self._max_lines:
            head = lines[: self._max_lines - 1]
            head.append(fm.elidedText(lines[self._max_lines - 1] + "…", Qt.TextElideMode.ElideRight, width))
            lines = head
        self._lines = lines or [""]
        return self._lines

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        painter.setFont(self._font)
        painter.setPen(self._color)
        fm = QFontMetrics(self._font)
        for idx, line in enumerate(self._wrap()):
            painter.drawText(QPointF(0, fm.ascent() + idx * self._line_height), line)


class IconButton(QAbstractButton):
    def __init__(self, icon_name: str, tooltip: str = "", size: int = 30,
                 color: QColor | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.icon_name = icon_name
        self._color = color or C.MUTED
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setToolTip(tooltip)
        self._hover = False
        self._busy = False
        self._spin_angle = 0
        self._spin_timer = QTimer(self)
        self._spin_timer.setInterval(50)
        self._spin_timer.timeout.connect(self._spin)

    def set_icon(self, name: str) -> None:
        self.icon_name = name
        self.update()

    def set_busy(self, busy: bool) -> None:
        self._busy = bool(busy)
        if self._busy:
            self._spin_timer.start()
        else:
            self._spin_timer.stop()
            self._spin_angle = 0
        self.update()

    def _spin(self) -> None:
        self._spin_angle = (self._spin_angle + 12) % 360
        self.update()

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if self.isChecked():
            p.setBrush(tint(C.ACCENT, 0.18))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(rect, 5, 5)
        elif self._hover or self.isDown():
            p.setBrush(C.CARD_HOVER)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(rect, 5, 5)
        color = C.ACCENT if (self.isChecked() or self._busy) else (C.TEXT if self._hover else self._color)
        m = self.width() * 0.2
        icon_rect = QRectF(m, m, self.width() - 2 * m, self.height() - 2 * m)
        if self._busy and self.icon_name == "refresh":
            p.save()
            center = self.rect().center()
            p.translate(center.x(), center.y())
            p.rotate(self._spin_angle)
            p.translate(-center.x(), -center.y())
            draw_icon(p, self.icon_name, icon_rect, color, 1.5)
            p.restore()
        else:
            draw_icon(p, self.icon_name, icon_rect, color, 1.5)


class TextButton(QAbstractButton):
    def __init__(self, text: str, color: QColor | None = None, size: int = 13,
                 arrow: str | None = "arrow_right", parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self._color = color or C.ACCENT
        self._arrow = arrow
        self._hover = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFixedHeight(26)
        self._font = font(size, 600)
        self.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

    def sizeHint(self) -> QSize:
        fm = QFontMetrics(self._font)
        return QSize(fm.horizontalAdvance(self._text) + (18 if self._arrow else 0) + 4, 26)

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(self._font)
        color = C.TEXT if self._hover else self._color
        p.setPen(color)
        fm = QFontMetrics(self._font)
        p.drawText(QPointF(0, (self.height() + fm.ascent() - fm.descent()) / 2), self._text)
        if self._arrow:
            draw_icon(p, self._arrow, QRectF(fm.horizontalAdvance(self._text) + 5, 6, 14, 14), color, 1.4)


class TagLabel(QWidget):
    """小标签：一块淡底，不描边。"""

    def __init__(self, text: str = "", tone: str = "muted", parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self._tone = tone
        self._font = font(12, 500)
        self.setFixedHeight(22)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._resize()

    def setText(self, text: str) -> None:
        self._text = text
        self._resize()
        self.update()

    def _resize(self) -> None:
        self.setFixedWidth(QFontMetrics(self._font).horizontalAdvance(self._text) + 16)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        accent = self._tone in ("accent", "gold", "jade")
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(tint(C.ACCENT, 0.15) if accent else C.CARD_HOVER)
        p.drawRoundedRect(QRectF(self.rect()), 4, 4)
        p.setFont(self._font)
        p.setPen(C.ACCENT if accent else C.MUTED)
        p.drawText(QRectF(self.rect()), Qt.AlignmentFlag.AlignCenter, self._text)


class Hairline(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(1)

    def paintEvent(self, event) -> None:
        QPainter(self).fillRect(self.rect(), C.HAIRLINE)


class SectionHeader(QWidget):
    def __init__(self, label: str, count: int | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.label = label
        self.count = count
        self.setFixedHeight(30)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(font(13, 700))
        p.setPen(C.TEXT)
        fm = QFontMetrics(p.font())
        y = 20
        p.drawText(QPointF(0, y), self.label)
        x = fm.horizontalAdvance(self.label) + 10
        end = self.width() - (26 if self.count is not None else 0)
        if x < end - 10:
            p.setPen(C.HAIRLINE)
            p.drawLine(QPointF(x, y - 5), QPointF(end, y - 5))
        if self.count is not None:
            p.setFont(mono(12))
            p.setPen(C.DIM)
            p.drawText(QRectF(self.width() - 24, y - 15, 24, 20), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, str(self.count))


class TabBar(QWidget):
    """分段键：凹槽里一颗凸起的键，切换时滑过去。"""
    changed = Signal(int)

    def __init__(self, tabs: list[str], parent: QWidget | None = None):
        super().__init__(parent)
        self.tabs = tabs
        self.active = 0
        self.hover = -1
        self._indicator = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(170)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._on_indicator)
        self.setFixedHeight(34)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _on_indicator(self, value) -> None:
        self._indicator = float(value)
        self.update()

    def set_active(self, idx: int, emit: bool = True) -> None:
        if idx < 0 or idx >= len(self.tabs):
            return
        self.active = idx
        self._anim.stop()
        self._anim.setStartValue(self._indicator)
        self._anim.setEndValue(float(idx))
        self._anim.start()
        if emit:
            self.changed.emit(idx)

    def _index_at(self, x: float) -> int:
        return max(0, min(len(self.tabs) - 1, int(x / max(1, self.width()) * len(self.tabs))))

    def mousePressEvent(self, event) -> None:
        self.set_active(self._index_at(event.position().x()))
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        idx = self._index_at(event.position().x())
        if idx != self.hover:
            self.hover = idx
            self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event) -> None:
        self.hover = -1
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.GROOVE)
        p.drawRoundedRect(QRectF(self.rect()), 9, 9)
        w = self.width() / max(1, len(self.tabs))
        key = QRectF(self._indicator * w + 3, 3, w - 6, self.height() - 6)
        p.setPen(QPen(C.HAIRLINE_STRONG, 1))
        p.setBrush(C.CARD)
        p.drawRoundedRect(key, 7, 7)
        p.setPen(Qt.PenStyle.NoPen)
        for idx, label in enumerate(self.tabs):
            on = idx == self.active
            p.setFont(font(13, 700 if on else 500))
            p.setPen(C.ACCENT if on else (C.TEXT if idx == self.hover else C.MUTED))
            p.drawText(QRectF(idx * w, 0, w, self.height() - 1), Qt.AlignmentFlag.AlignCenter, label)


class BrandMark(QWidget):
    """朱砂印。"""

    def __init__(self, size: int = 34, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedSize(size, size)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect())
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.SEAL)
        p.drawRoundedRect(rect, rect.width() * .16, rect.width() * .16)
        p.setFont(serif(int(rect.width() * .6), 700))
        p.setPen(QColor("#FFFFFF"))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, "观")


class Panel(QWidget):
    """面板底：一块实色圆角面，加一圈细线。"""

    SHADOW = dict(blur=30, radius=10, dy=8, alpha=130)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        path = QPainterPath()
        path.addRoundedRect(rect, 10, 10)
        p.fillPath(path, C.PANEL)
        p.setPen(QPen(C.HAIRLINE_STRONG, 1))
        p.drawPath(path)


class BusyLine(QWidget):
    """更新时面板顶上的一道走动的线：不打断阅读，但看得出来在忙。"""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(2)
        self._t = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(40)
        self._timer.timeout.connect(self._step)

    def set_running(self, on: bool) -> None:
        self._timer.start() if on else self._timer.stop()
        self.update()

    def _step(self) -> None:
        self._t = (self._t + 0.02) % 1.0
        self.update()

    def paintEvent(self, event) -> None:
        if not self._timer.isActive():
            return
        p = QPainter(self)
        w = self.width()
        p.fillRect(int((self._t * 1.3 - 0.3) * w), 0, int(w * 0.3), 2, C.ACCENT)


class Switch(QAbstractButton):
    def __init__(self, checked: bool = False, parent: QWidget | None = None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setFixedSize(40, 22)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._pos = 1.0 if checked else 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(150)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._set_pos)
        self.toggled.connect(self._toggle)

    def _set_pos(self, value) -> None:
        self._pos = float(value)
        self.update()

    def _toggle(self, checked: bool) -> None:
        self._anim.stop()
        self._anim.setStartValue(self._pos)
        self._anim.setEndValue(1.0 if checked else 0.0)
        self._anim.start()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        track = QRectF(0.5, 1.5, self.width() - 1, self.height() - 3)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.ACCENT if self.isChecked() else C.HAIRLINE_STRONG)
        p.drawRoundedRect(track, track.height() / 2, track.height() / 2)
        p.setBrush(C.ON_ACCENT if self.isChecked() else C.PANEL)
        p.drawEllipse(QRectF(3 + self._pos * (self.width() - 22), 4, 14, 14))


class Rail(QWidget):
    """收起后的窄条：印、日期、还没读的条数。悬停稍等一下才展开，鼠标路过不会弹开。"""
    expand_requested = Signal()
    HOVER_MS = 550

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedSize(58, 176)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("点击展开观澜（Alt+Shift+G）")
        self._hover = False
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(self.HOVER_MS)
        self._timer.timeout.connect(self.expand_requested.emit)
        self._date = ""
        self._unread = 0
        self.side = "right"

    def set_info(self, date_label: str, unread: int, total: int = 0) -> None:
        self._date = date_label
        self._unread = unread
        self._total = max(0, int(total))
        self.update()

    def enterEvent(self, event) -> None:
        self._hover = True
        self._timer.start()
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self._timer.stop()
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        self._timer.stop()
        self.expand_requested.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        cx = self.width() / 2
        seal = QRectF(cx - 16, 14, 32, 32)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.SEAL)
        p.drawRoundedRect(seal, 5, 5)
        p.setFont(serif(20, 700))
        p.setPen(QColor("#FFFFFF"))
        p.drawText(seal, Qt.AlignmentFlag.AlignCenter, "观")
        date = self._date[-5:].replace(".", "/") if self._date else "—"
        p.setFont(mono(14, 500))
        p.setPen(C.TEXT)
        p.drawText(QRectF(0, 56, self.width(), 22), Qt.AlignmentFlag.AlignCenter, date)
        total = min(getattr(self, "_total", 0), 9)
        if total > 0:
            # 和展开后的阅读刻度同一个母题：一条新闻一格，读过的亮
            read = max(0, getattr(self, "_total", 0) - self._unread)
            x0 = cx - (total - 1) * 2.5
            p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
            for i in range(total):
                p.setPen(QPen(C.ACCENT if i < read else C.HAIRLINE_STRONG, 2))
                x = round(x0 + i * 5)
                p.drawLine(QPointF(x, 81), QPointF(x, 87))
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        else:
            p.setPen(C.HAIRLINE_STRONG)
            p.drawLine(QPointF(cx - 10, 84), QPointF(cx + 10, 84))
        if self._unread > 0:
            p.setFont(mono(22, 600))
            p.setPen(C.ACCENT)
            p.drawText(QRectF(0, 90, self.width(), 28), Qt.AlignmentFlag.AlignCenter, str(self._unread))
            p.setFont(font(12))
            p.setPen(C.MUTED)
            p.drawText(QRectF(0, 116, self.width(), 18), Qt.AlignmentFlag.AlignCenter, "未读")
        else:
            draw_icon(p, "check", QRectF(cx - 10, 94, 20, 20), C.ACCENT, 1.8)
            p.setFont(font(12))
            p.setPen(C.MUTED)
            p.drawText(QRectF(0, 116, self.width(), 18), Qt.AlignmentFlag.AlignCenter, "读完")
        name = "chevron_right" if self.side == "left" else "chevron_left"
        draw_icon(p, name, QRectF(cx - 8, 144, 16, 16), C.ACCENT if self._hover else C.DIM, 1.6)
