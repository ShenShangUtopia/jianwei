'use strict';
/* ======================= 题目分析的「网页复算」：单位换算 · 表达式 · 方程组求解 · 角度对齐 =======================
 * 思路参照 VeloΦ 26.59 的 AI 读题（github.com/Stevenzhang543/VeloPhi，src/ai/import）：
 *   AI 只负责「读题、列式」，数值一律由网页算 —— 模型把题目写成「已知量 + 未知量 + 方程」，网页用
 *   Levenberg–Marquardt 解出来，再和模型自己的答案对照；方程互相矛盾或条件不足时也能判断出来。
 * 不用 eval：表达式由下面的小解析器编译成闭包，只认 + - * / ^ ( ) 和白名单函数。
 */
const Solver = (() => {
  /* ---------------- 单位 ---------------- */
  // 单位 → [换算到国际单位的倍数, 量纲, 偏移]；国际单位值 = 值 × 倍数 + 偏移
  const U = {};
  const def = (dim, list) => { for (const [names, f, off] of list) for (const n of names.split(' ')) U[n] = [f, dim, off || 0]; };
  def('1', [['1 -', 1], ['% 百分之', 0.01], ['‰', 0.001]]);
  def('m', [['m 米', 1], ['km 千米 公里', 1e3], ['dm 分米', 0.1], ['cm 厘米', 1e-2], ['mm 毫米', 1e-3], ['μm 微米', 1e-6], ['nm 纳米', 1e-9]]);
  def('kg', [['kg 千克 公斤', 1], ['g 克', 1e-3], ['mg 毫克', 1e-6], ['t 吨', 1e3]]);
  def('s', [['s 秒 秒钟', 1], ['ms 毫秒', 1e-3], ['μs 微秒', 1e-6], ['min 分钟', 60], ['h 小时', 3600], ['d 天', 86400]]);
  def('m/s', [['m/s 米每秒', 1], ['km/h 千米每小时 公里每小时', 1 / 3.6], ['cm/s 厘米每秒', 0.01]]);
  def('m/s²', [['m/s² 米每二次方秒 N/kg', 1], ['cm/s²', 0.01]]);
  def('N', [['N 牛 牛顿', 1], ['kN 千牛', 1e3], ['mN 毫牛', 1e-3]]);
  def('J', [['J 焦 焦耳', 1], ['kJ 千焦', 1e3], ['mJ', 1e-3], ['eV 电子伏', 1.602176634e-19], ['keV', 1.602176634e-16], ['MeV', 1.602176634e-13], ['kW·h 度电 千瓦时', 3.6e6], ['cal 卡', 4.184], ['kcal 千卡', 4184]]);
  def('W', [['W 瓦 瓦特', 1], ['kW 千瓦', 1e3], ['mW 毫瓦', 1e-3], ['MW 兆瓦', 1e6]]);
  def('rad', [['rad 弧度', 1], ['° 度', Math.PI / 180]]);
  def('rad/s', [['rad/s 弧度每秒', 1], ['r/s 转每秒', 2 * Math.PI], ['r/min 转每分 rpm', Math.PI / 30]]);
  def('Hz', [['Hz 赫 赫兹', 1], ['kHz', 1e3], ['MHz', 1e6]]);
  def('Pa', [['Pa 帕 帕斯卡', 1], ['kPa 千帕', 1e3], ['MPa 兆帕', 1e6], ['hPa', 100], ['atm 标准大气压', 101325], ['cmHg', 1333.22], ['mmHg', 133.322]]);
  def('C', [['C 库 库仑', 1], ['mC 毫库', 1e-3], ['μC 微库', 1e-6], ['nC 纳库', 1e-9]]);
  def('V', [['V 伏 伏特', 1], ['kV 千伏', 1e3], ['mV 毫伏', 1e-3]]);
  def('A', [['A 安 安培', 1], ['mA 毫安', 1e-3], ['μA 微安', 1e-6]]);
  def('Ω', [['Ω 欧 欧姆', 1], ['kΩ 千欧', 1e3], ['MΩ 兆欧', 1e6]]);
  def('F', [['F 法 法拉', 1], ['μF 微法', 1e-6], ['nF', 1e-9], ['pF 皮法', 1e-12]]);
  def('H', [['H 亨 亨利', 1], ['mH 毫亨', 1e-3]]);
  def('T', [['T 特 特斯拉', 1], ['mT 毫特', 1e-3], ['Gs 高斯', 1e-4]]);
  def('Wb', [['Wb 韦伯', 1]]);
  def('V/m', [['V/m N/C 伏每米 牛每库', 1]]);
  def('N/m', [['N/m 牛每米', 1], ['N/cm', 100]]);
  def('kg/m³', [['kg/m³ 千克每立方米', 1], ['g/cm³ 克每立方厘米 g/mL', 1e3]]);
  def('m²', [['m² 平方米', 1], ['dm²', 1e-2], ['cm² 平方厘米', 1e-4], ['mm²', 1e-6], ['km²', 1e6]]);
  def('m³', [['m³ 立方米', 1], ['L 升 dm³', 1e-3], ['mL 毫升 cm³', 1e-6]]);
  def('K', [['K 开 开尔文', 1], ['℃ 摄氏度', 1, 273.15]]);
  def('mol', [['mol 摩 摩尔', 1], ['mmol 毫摩', 1e-3]]);
  def('mol/L', [['mol/L 摩每升', 1], ['mmol/L', 1e-3]]);
  def('g/mol', [['g/mol 克每摩', 1]]);
  def('kg·m/s', [['kg·m/s N·s', 1]]);
  def('J/(kg·℃)', [['J/(kg·℃) J/(kg·K)', 1]]);

  function normUnit(u) {
    let s = String(u ?? '').trim().replace(/\s+/g, '').replace(/[µu](?=[mgsCAFVTlL])/g, 'μ')
      .replace(/\^2|\*\*2/g, '²').replace(/\^3|\*\*3/g, '³').replace(/\^-1/g, '⁻¹').replace(/[*.⋅•]/g, '·')
      .replace(/^(deg|degrees?|º|˚)$/i, '°').replace(/^°C$/i, '℃').replace(/^(ohm|ohms)$/i, 'Ω').replace(/^k(ohm|Ω)$/i, 'kΩ')
      .replace(/^m\/s\/s$|^m·s⁻²$/, 'm/s²').replace(/^l$/, 'L').replace(/^ml$/i, 'mL').replace(/^kwh$/i, 'kW·h').replace(/^hz$/i, 'Hz');
    if (/^(无|无单位|none|unitless)$/i.test(s) || s === '') s = '1';
    return s;
  }
  const unitOf = u => U[normUnit(u)] || null;
  /** 写在题目里的数值 → 国际单位；单位不认识时返回 null */
  function toSI(v, unit) { const u = unitOf(unit); return u && isFinite(v) ? v * u[0] + u[2] : null; }
  function fromSI(v, unit) { const u = unitOf(unit); return u && isFinite(v) ? (v - u[2]) / u[0] : null; }
  /** 把 value（unit）换算成 target 单位；单位相同的字符串（哪怕不认识）直接通过 */
  function convert(v, unit, target) {
    const a = normUnit(unit), b = normUnit(target);
    if (a === b) return { value: v };
    const ua = U[a], ub = U[b];
    if (!ua) return { error: `不认识单位「${unit}」` };
    if (!ub) return { error: `控件单位「${target}」无法换算，请直接给出以「${target}」为单位的数值` };
    if (ua[1] !== ub[1]) return { error: `「${unit}」与「${target}」不是同一种量` };
    return { value: +(((v * ua[0] + ua[2]) - ub[2]) / ub[0]).toPrecision(12) };
  }

  /* ---------------- 表达式 ---------------- */
  const FN = {
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan, atan2: Math.atan2,
    arcsin: Math.asin, arccos: Math.acos, arctan: Math.atan, sqrt: Math.sqrt, cbrt: Math.cbrt, abs: Math.abs, exp: Math.exp,
    ln: Math.log, lg: Math.log10, log: (a, b) => b === undefined ? Math.log10(a) : Math.log(b) / Math.log(a), log2: Math.log2,
    min: Math.min, max: Math.max, sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, floor: Math.floor, ceil: Math.ceil, round: Math.round
  };
  const CONST = { pi: Math.PI, deg: Math.PI / 180 };
  class ExprError extends Error { }

  function tokenize(src) {
    const s = String(src).replace(/[−–—]/g, '-').replace(/[×·⋅∙]/g, '*').replace(/÷/g, '/').replace(/π/g, ' pi ')
      .replace(/（/g, '(').replace(/）/g, ')').replace(/，/g, ',').replace(/²/g, '^2').replace(/³/g, '^3').replace(/\*\*/g, '^').replace(/°/g, '*deg');
    const t = []; let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (/\s/.test(c)) { i++; continue; }
      const num = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i));
      if (num) { t.push({ k: 'n', v: +num[0] }); i += num[0].length; continue; }
      const id = /^[A-Za-z_][A-Za-z_0-9]*/.exec(s.slice(i));
      if (id) { t.push({ k: 'i', v: id[0] }); i += id[0].length; continue; }
      if ('+-*/^(),√'.includes(c)) { t.push({ k: c }); i++; continue; }
      throw new ExprError(`不能识别的字符「${c}」`);
    }
    // 隐式乘法：2T、2(…)、(…)(…)、(…)x
    const out = [];
    for (const k of t) {
      const p = out[out.length - 1];
      if (p && (p.k === 'n' || p.k === ')' || (p.k === 'i' && !(p.v in FN))) && (k.k === 'n' || k.k === 'i' || k.k === '(' || k.k === '√') && !(p.k === 'n' && k.k === 'n') && !(p.k === 'i' && k.k === 'n')) out.push({ k: '*' });
      out.push(k);
    }
    return out;
  }
  /** 解析成语法树：{t:'n',v} {t:'v',name} {t:'neg',a} {t:'op',op,a,b} {t:'fn',name,args} */
  function parse(src) {
    const tk = tokenize(src); let p = 0;
    const peek = () => tk[p], eat = k => { if (tk[p] && tk[p].k === k) return tk[p++]; return null; };
    const need = k => { if (!eat(k)) throw new ExprError(`缺少「${k}」`); };
    function expr() { let a = term(); for (;;) { if (eat('+')) a = { t: 'op', op: '+', a, b: term() }; else if (eat('-')) a = { t: 'op', op: '-', a, b: term() }; else return a; } }
    function term() { let a = unary(); for (;;) { if (eat('*')) a = { t: 'op', op: '*', a, b: unary() }; else if (eat('/')) a = { t: 'op', op: '/', a, b: unary() }; else return a; } }
    function unary() { if (eat('-')) return { t: 'neg', a: unary() }; if (eat('+')) return unary(); return power(); }
    function power() { const a = atom(); if (eat('^')) return { t: 'op', op: '^', a, b: unary() }; return a; }
    function atom() {
      const k = peek(); if (!k) throw new ExprError('表达式不完整');
      if (eat('√')) return { t: 'fn', name: 'sqrt', args: [atom()] };
      if (k.k === 'n') { p++; return { t: 'n', v: k.v }; }
      if (eat('(')) { const e = expr(); need(')'); return e; }
      if (k.k === 'i') {
        p++;
        if (k.v in FN && peek() && peek().k === '(') { p++; const args = []; if (!eat(')')) { do args.push(expr()); while (eat(',')); need(')'); } return { t: 'fn', name: k.v, args }; }
        if (k.v in FN) return { t: 'fn', name: k.v, args: [power()] }; // sin x、sqrt 3
        return { t: 'v', name: k.v };
      }
      throw new ExprError(`意外的「${k.k}」`);
    }
    const e = expr(); if (p < tk.length) throw new ExprError(`多余的「${tk[p].v ?? tk[p].k}」`);
    return e;
  }
  function vars(n, set = new Set()) {
    if (n.t === 'v') { if (!(n.name in CONST)) set.add(n.name); } else if (n.t === 'neg') vars(n.a, set);
    else if (n.t === 'op') { vars(n.a, set); vars(n.b, set); } else if (n.t === 'fn') n.args.forEach(a => vars(a, set));
    return set;
  }
  /** 编译成闭包：x 为未知量向量，index 为未知量下标，known 为已知量（国际单位） */
  function compile(n, index, known) {
    switch (n.t) {
      case 'n': { const v = n.v; return () => v; }
      case 'v': {
        if (n.name in CONST) { const v = CONST[n.name]; return () => v; }
        if (known.has(n.name)) { const v = known.get(n.name); return () => v; }
        const i = index.get(n.name); if (i === undefined) throw new ExprError(`未定义的名称 ${n.name}`);
        return x => x[i];
      }
      case 'neg': { const a = compile(n.a, index, known); return x => -a(x); }
      case 'op': {
        const a = compile(n.a, index, known), b = compile(n.b, index, known);
        return n.op === '+' ? x => a(x) + b(x) : n.op === '-' ? x => a(x) - b(x) : n.op === '*' ? x => a(x) * b(x) : n.op === '/' ? x => a(x) / b(x) : x => Math.pow(a(x), b(x));
      }
      case 'fn': { const f = FN[n.name], args = n.args.map(a => compile(a, index, known)); return x => f(...args.map(g => g(x))); }
    }
  }
  /** 算一个不含未知量的式子（如模型写的「2√3」「48*sqrt(3)/25」）；算不出返回 NaN */
  function evalConst(s) {
    if (typeof s === 'number') return s;
    const str = String(s ?? '').trim();
    const plain = /^[-+−]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?\s*[^\d\s.+\-*/^()√]*$/i.exec(str); // 「2.5」「2.5 m/s」「30°」
    if (plain) return parseFloat(str.replace('−', '-'));
    const tryIt = t => { try { return compile(parse(t), new Map(), new Map())(); } catch (e) { return NaN; } };
    let v = tryIt(str);
    if (!isFinite(v) && /\s\S+$/.test(str)) v = tryIt(str.replace(/\s\S+$/, '')); // 「2√3 m」去掉末尾的单位
    return v;
  }

  /* ---------------- 方程组 ---------------- */
  function solveLinear(A, b) {
    const n = b.length, M = A.map((r, i) => [...r, b[i]]);
    for (let c = 0; c < n; c++) {
      let q = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[q][c])) q = r;
      if (!(Math.abs(M[q][c]) > 1e-300)) return null;
      [M[c], M[q]] = [M[q], M[c]];
      for (let r = c + 1; r < n; r++) { const f = M[r][c] / M[c][c]; if (f) for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k]; }
    }
    const d = Array(n).fill(0);
    for (let r = n - 1; r >= 0; r--) { let s = M[r][n]; for (let k = r + 1; k < n; k++) s -= M[r][k] * d[k]; d[r] = s / M[r][r]; }
    return d;
  }
  /** 奇异值与右奇异向量（单边 Jacobi），用来找方程「管不住」的方向 */
  function svd(A, n) {
    const m = A.length, W = A.map(r => r.slice()), V = [...Array(n)].map((_, i) => [...Array(n)].map((_, j) => +(i === j)));
    for (let sweep = 0; sweep < 60; sweep++) {
      let off = 0;
      for (let p = 0; p < n - 1; p++) for (let q = p + 1; q < n; q++) {
        let a = 0, b = 0, c = 0;
        for (let i = 0; i < m; i++) { a += W[i][p] ** 2; b += W[i][q] ** 2; c += W[i][p] * W[i][q]; }
        if (c === 0 || Math.abs(c) <= 1e-15 * Math.sqrt(a * b)) continue;
        off = Math.max(off, Math.abs(c) / Math.sqrt(a * b));
        const z = (b - a) / (2 * c), t = Math.sign(z || 1) / (Math.abs(z) + Math.sqrt(1 + z * z)), cs = 1 / Math.sqrt(1 + t * t), sn = cs * t;
        for (let i = 0; i < m; i++) { const u = W[i][p], v = W[i][q]; W[i][p] = cs * u - sn * v; W[i][q] = sn * u + cs * v; }
        for (let i = 0; i < n; i++) { const u = V[i][p], v = V[i][q]; V[i][p] = cs * u - sn * v; V[i][q] = sn * u + cs * v; }
      }
      if (off < 1e-14) break;
    }
    return { s: [...Array(n)].map((_, j) => Math.sqrt(W.reduce((acc, r) => acc + r[j] ** 2, 0))), V };
  }
  const NAME = /^[A-Za-z_][A-Za-z_0-9]{0,23}$/;
  const num = v => typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? evalConst(v) : NaN;

  /**
   * 检查并整理模型写的方程模型。返回 {ok, model, errors, notes}；errors 用于让模型修正。
   * 已知量按题目原单位给出，这里换算成国际单位（角度 → 弧度）；未知量、方程一律按国际单位理解。
   */
  function build(raw, problemText = '') {
    const errors = [], notes = [];
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ok: false, errors: ['model 必须是含 knowns、unknowns、equations、asks 的对象'] };
    const list = k => { const v = raw[k] ?? []; if (!Array.isArray(v)) { errors.push(`model.${k} 必须是数组`); return []; } return v.filter((x, i) => x && typeof x === 'object' ? true : (errors.push(`model.${k}[${i}] 必须是对象`), false)); };
    const ang = statedAngles(problemText), names = new Set();
    const nameOk = (n, w) => {
      if (!NAME.test(n)) { errors.push(`${w}.name「${n}」只能用英文字母、数字和下划线，且以字母开头（如 T1、v0、theta）`); return false; }
      if (n in CONST || n in FN) { errors.push(`${w}.name「${n}」是保留字（pi、deg 和函数名）`); return false; }
      if (names.has(n)) { errors.push(`名称「${n}」重复定义`); return false; }
      names.add(n); return true;
    };
    const model = { knowns: [], unknowns: [], equations: [], asks: [] };
    list('knowns').forEach((k, i) => {
      const name = String(k.name ?? '').trim(); if (!nameOk(name, `model.knowns[${i}]`)) return;
      let v = num(k.value); const unit = String(k.unit ?? '').trim();
      if (!isFinite(v)) { errors.push(`model.knowns[${i}]（${name}）的 value 必须是数`); return; }
      if (normUnit(unit) === '°' && ang.has(v)) { notes.push(`按题目给出的三角函数值，${v}° 取为 ${ang.get(v)}°（与之一致），复算结果与按近似值手算的答案相同`); v = ang.get(v); }
      const si = toSI(v, unit);
      if (si === null) { errors.push(`model.knowns[${i}]（${name}）的单位「${unit}」无法识别；请换成常用单位，或先换算成国际单位再写`); return; }
      model.knowns.push({ name, value: v, unit, si, meaning: String(k.meaning ?? '') });
    });
    list('unknowns').forEach((u, i) => {
      const name = String(u.name ?? '').trim(); if (!nameOk(name, `model.unknowns[${i}]`)) return;
      model.unknowns.push({ name, unit: String(u.unit ?? ''), meaning: String(u.meaning ?? ''), guess: num(u.guess), min: num(u.min), max: num(u.max) });
    });
    list('equations').forEach((e, i) => {
      const text = String(e.eq ?? e.equation ?? '').trim();
      if (!text) { errors.push(`model.equations[${i}].eq 是空的`); return; }
      const parts = text.replace(/==/g, '=').split('=');
      if (parts.length > 2) { errors.push(`model.equations[${i}]「${text}」只能有一个等号`); return; }
      try { model.equations.push({ text, why: String(e.why ?? ''), l: parse(parts[0]), r: parts.length === 2 ? parse(parts[1]) : { t: 'n', v: 0 } }); }
      catch (x) { errors.push(`model.equations[${i}]「${text}」：${x.message}`); }
    });
    list('asks').forEach((a, i) => {
      const expr = String(a.expr ?? '').trim();
      try { model.asks.push({ prompt: String(a.prompt ?? expr), expr, unit: String(a.unit ?? ''), node: parse(expr), claimed: a.claimed ?? a.value ?? null }); }
      catch (x) { errors.push(`model.asks[${i}].expr「${expr}」：${x.message}`); }
    });
    if (!model.unknowns.length && !errors.length) errors.push('model.unknowns 至少要有一个未知量');
    if (!model.equations.length && !errors.length) errors.push('model.equations 至少要有一条方程');
    if (!model.asks.length && !errors.length) errors.push('model.asks 至少要有一个所求');
    const used = new Set();
    model.equations.forEach((e, i) => { for (const v of [...vars(e.l), ...vars(e.r)]) { used.add(v); if (!names.has(v)) errors.push(`model.equations[${i}]「${e.text}」用到「${v}」，它既不是已知量也不是未知量`); } });
    model.asks.forEach((a, i) => { for (const v of vars(a.node)) if (!names.has(v)) errors.push(`model.asks[${i}].expr 用到「${v}」，它既不是已知量也不是未知量`); });
    for (const u of model.unknowns) if (!used.has(u.name)) errors.push(`未知量「${u.name}」没有出现在任何方程里`);
    model.asks.forEach((a, i) => { if (a.unit && !unitOf(a.unit)) errors.push(`model.asks[${i}] 的单位「${a.unit}」无法识别`); });
    if (model.unknowns.length > 60) errors.push('未知量最多 60 个');
    return errors.length ? { ok: false, errors } : { ok: true, model, notes };
  }

  /** 解方程模型：verdict = solved | inconsistent（互相矛盾）| underdetermined（条件不足）| failed */
  function solve(m) {
    const n = m.unknowns.length, index = new Map(m.unknowns.map((u, i) => [u.name, i])), known = new Map(m.knowns.map(k => [k.name, k.si]));
    const res = m.equations.map(e => { const l = compile(e.l, index, known), r = compile(e.r, index, known); return x => l(x) - r(x); });
    const askF = m.asks.map(a => compile(a.node, index, known));
    const lo = m.unknowns.map(u => isFinite(u.min) ? u.min : -Infinity), hi = m.unknowns.map(u => isFinite(u.max) ? u.max : Infinity);
    const clampX = x => { for (let i = 0; i < n; i++) x[i] = Math.min(hi[i], Math.max(lo[i], x[i])); };
    const R = x => res.map(f => f(x)), norm2 = v => v.reduce((a, b) => a + (isFinite(b) ? b * b : 1e300), 0);
    const jac = (x, fns) => {
      const J = fns.map(() => Array(n).fill(0));
      for (let j = 0; j < n; j++) {
        const h = 1e-6 * Math.max(1, Math.abs(x[j])), xp = Float64Array.from(x), xm = Float64Array.from(x); xp[j] += h; xm[j] -= h;
        for (let i = 0; i < fns.length; i++) J[i][j] = (fns[i](xp) - fns[i](xm)) / (2 * h);
      }
      return J;
    };
    const mag = (nd, x) => { // 各项绝对值之和：残差的尺度
      if (nd.t === 'op' && (nd.op === '+' || nd.op === '-')) return mag(nd.a, x) + mag(nd.b, x);
      if (nd.t === 'neg') return mag(nd.a, x);
      try { return Math.abs(compile(nd, index, known)(x)); } catch (e) { return 0; }
    };
    const rel = x => m.equations.map((e, i) => { const v = res[i](x), sc = mag(e.l, x) + mag(e.r, x); return isFinite(v) ? Math.abs(v) / Math.max(sc, 1e-12) : Infinity; });
    const consistent = x => rel(x).every(v => v <= 1e-7);
    const start = k => {
      const x = Float64Array.from(m.unknowns.map((u, i) => {
        const g = isFinite(u.guess) ? u.guess : isFinite(lo[i]) && lo[i] > 0 ? lo[i] + 1 : isFinite(hi[i]) && hi[i] < 0 ? hi[i] - 1 : 1;
        return k === 0 ? g : g * [1, 3, -2, 0.37, 10, -0.5, 0.1, 30][k % 8] + k * 0.1;
      }));
      clampX(x); return x;
    };
    let best = null;
    for (let at = 0; at < 8; at++) {
      const x = start(at); let r = R(x), f = norm2(r), lam = 1e-3, it = 0;
      for (; it < 300 && f > 0; it++) {
        const J = jac(x, res);
        const JtJ = [...Array(n)].map((_, a) => [...Array(n)].map((_, b) => J.reduce((s, row) => s + row[a] * row[b], 0)));
        const g = [...Array(n)].map((_, a) => J.reduce((s, row, i) => s + row[a] * r[i], 0));
        let improved = false;
        for (let tries = 0; tries < 12; tries++) {
          const A = JtJ.map((row, a) => row.map((v, b) => a === b ? v + lam * Math.max(v, 1e-12) : v)), d = solveLinear(A, g.map(v => -v));
          if (!d) { lam *= 10; continue; }
          const xn = Float64Array.from(x, (v, i) => v + d[i]); clampX(xn);
          const rn = R(xn), fn = norm2(rn);
          if (fn < f) { x.set(xn); r = rn; improved = f - fn > 1e-30 || d.some(v => Math.abs(v) > 1e-15); f = fn; lam = Math.max(lam / 10, 1e-15); break; }
          lam *= 10;
        }
        if (!improved) break;
      }
      if (!best || f < best.f) best = { x: Float64Array.from(x), f, it };
      if (consistent(best.x)) break;
    }
    const x = best.x, values = {};
    m.unknowns.forEach((u, i) => values[u.name] = x[i]);
    const show = (v, unit) => { const c = unit ? fromSI(v, unit) : v; return c === null ? v : c; };
    if (![...x].every(isFinite)) return { verdict: 'failed', values, answers: m.asks.map(a => ({ prompt: a.prompt, unit: a.unit, value: null, claimed: a.claimed })), conflicts: [], undetermined: [] };
    const conflicts = rel(x).map((v, i) => ({ index: i, residual: v })).filter(c => c.residual > 1e-7).sort((a, b) => b.residual - a.residual).slice(0, 6);
    const J = jac(x, res), { s, V } = svd(J, n), smax = Math.max(...s, 0), tol = Math.max(1e-9 * smax * Math.max(n, J.length), 1e-14);
    const nulls = []; for (let j = 0; j < n; j++) if (s[j] <= tol) nulls.push(V.map(row => row[j]));
    const undetermined = m.unknowns.filter((_, i) => nulls.some(d => Math.abs(d[i]) > 1e-6)).map(u => u.name);
    const G = jac(x, askF);
    const answers = m.asks.map((a, k) => {
      const g = G[k], gn = Math.hypot(...g, 0), free = nulls.some(d => Math.abs(d.reduce((acc, v, i) => acc + v * g[i], 0)) > 1e-6 * Math.max(gn, 1e-12));
      const v = askF[k](x);
      return { prompt: a.prompt, unit: a.unit, claimed: a.claimed, value: free || !isFinite(v) ? null : show(v, a.unit) };
    });
    const verdict = conflicts.length ? 'inconsistent' : answers.some(a => a.value === null) ? 'underdetermined' : 'solved';
    return { verdict, values, answers, conflicts, undetermined };
  }
  const VERDICT = { solved: '已解出', inconsistent: '方程互相矛盾（不存在同时满足全部方程的解）', underdetermined: '条件不足（所求的量不能由这些方程确定）', failed: '数值求解失败' };

  /* ---------------- 角度对齐（sin37° = 0.6 → 36.87°） ---------------- */
  function statedAngles(text) {
    const out = new Map(), re = /(sin|cos|tan)\s*(\d{1,2}(?:\.\d+)?)\s*[°º˚]\s*[=＝≈]\s*(\d+(?:\.\d+)?)(?:\s*[/／]\s*(\d+(?:\.\d+)?))?/gi;
    for (const mm of String(text || '').matchAll(re)) {
      const fn = mm[1].toLowerCase(), deg = +mm[2], v = mm[4] ? +mm[3] / +mm[4] : +mm[3];
      const rad = fn === 'sin' ? (v <= 1 ? Math.asin(v) : NaN) : fn === 'cos' ? (v <= 1 ? Math.acos(v) : NaN) : Math.atan(v), c = rad * 180 / Math.PI;
      if (!isFinite(c) || Math.abs(c - deg) < 1e-6 || Math.abs(c - deg) >= 0.5) continue; // 只处理教材式的近似（差半度以内）
      const r4 = z => +z.toFixed(4);
      if (!out.has(deg)) out.set(deg, r4(c));
      if (!out.has(90 - deg)) out.set(r4(90 - deg), r4(90 - c));
    }
    return out;
  }

  /** 两个数是否「同一个答案」：相对 2% 或绝对 0.005 以内（与实验读数核对用同一个标准） */
  const close = (a, b) => Math.abs(a - b) <= Math.max(0.02 * Math.max(Math.abs(a), Math.abs(b)), 0.005);

  return { normUnit, unitOf, toSI, fromSI, convert, parse, evalConst, build, solve, statedAngles, close, VERDICT, ExprError };
})();
