"""盖在面板上的三个层：读一条新闻、看筛选说明、设置。都从右边滑入，Esc 或左上角的箭头返回。"""
from __future__ import annotations

import html

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, QRectF, QTimer, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget)

from .base import Hairline, IconButton, SectionHeader, SmoothScrollArea, Switch, TagLabel, TextBlock
from .cards import _label
from .pages import story_key
from .theme import C, font, mono, motion


class Toast(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._text = ""
        self.setFixedHeight(32)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.hide()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)
        self._slide = QPropertyAnimation(self, b"pos", self)
        self._slide.setDuration(170)
        self._slide.setEasingCurve(QEasingCurve.Type.OutCubic)

    def text(self) -> str:
        return self._text

    def show_message(self, text: str, ms: int = 2000) -> None:
        fresh = not self.isVisible()
        self._text = text
        fm = QFontMetrics(font(13))
        parent = self.parentWidget()
        self.setFixedWidth(min(parent.width() - 28, fm.horizontalAdvance(text) + 32))
        end = QPoint((parent.width() - self.width()) // 2, parent.height() - 76)
        self._slide.stop()
        self.show()
        self.raise_()
        if fresh and motion():      # 新出现的从下面滑上来一点；连着来的只换字
            self._slide.setStartValue(end + QPoint(0, 12))
            self._slide.setEndValue(end)
            self._slide.start()
        else:
            self.move(end)
        self._timer.start(ms)
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        p.setBrush(C.TEXT)
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(r, 6, 6)
        p.setFont(font(13, 500))
        p.setPen(C.PANEL)
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self._text)


class BaseSheet(QWidget):
    """整块面板大小的一层。顶上一条：返回箭头 + 标题。"""
    closed = Signal()
    anim_ms = 170

    def __init__(self, parent: QWidget | None = None, title: str = ""):
        super().__init__(parent)
        self.hide()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(4)
        self.top = QHBoxLayout()
        self.top.setSpacing(4)
        self.close_btn = IconButton("chevron_left", "返回（Esc）", 30)
        self.close_btn.clicked.connect(self.close_sheet)
        self.top.addWidget(self.close_btn)
        self.title_label = _label(title, 14, 700, C.TEXT)
        self.top.addWidget(self.title_label)
        self.top.addStretch(1)
        outer.addLayout(self.top)
        self.scroll = SmoothScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.inner = QWidget()
        self.il = QVBoxLayout(self.inner)
        self.il.setContentsMargins(8, 6, 8, 12)
        self.il.setSpacing(10)
        self.scroll.setWidget(self.inner)
        outer.addWidget(self.scroll, 1)
        self._anim = QPropertyAnimation(self, b"pos", self)
        self._anim.setDuration(self.anim_ms)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._closing = False
        self._anim.finished.connect(self._done)

    def clear(self) -> None:
        def wipe(lay):
            while lay.count():
                item = lay.takeAt(0)
                if item.widget():
                    item.widget().hide()
                    item.widget().deleteLater()
                elif item.layout():
                    wipe(item.layout())
        wipe(self.il)

    def open_sheet(self) -> None:
        parent = self.parentWidget()
        if not parent:
            return
        self.resize(parent.size())
        self.scroll.stop_scroll(), self.scroll.verticalScrollBar().setValue(0)
        was_open = self.isVisible() and not self._closing
        self._closing = False
        self.show()
        self.raise_()
        if was_open or BaseSheet.anim_ms <= 0:
            self._anim.stop()
            self.move(0, 0)
            return
        self._anim.stop()
        self._anim.setDuration(BaseSheet.anim_ms)
        self._anim.setStartValue(QPoint(parent.width(), 0))
        self._anim.setEndValue(QPoint(0, 0))
        self._anim.start()

    def close_sheet(self) -> None:
        parent = self.parentWidget()
        if BaseSheet.anim_ms <= 0 or parent is None or not self.isVisible():
            self.hide()
            self.closed.emit()
            return
        self._closing = True
        self._anim.stop()
        self._anim.setDuration(BaseSheet.anim_ms)
        self._anim.setStartValue(self.pos())
        self._anim.setEndValue(QPoint(parent.width(), 0))
        self._anim.start()

    def _done(self) -> None:
        if self._closing:
            self._closing = False
            self.hide()
            self.move(0, 0)
            self.closed.emit()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        p.setBrush(C.PANEL)
        p.setPen(QPen(C.HAIRLINE_STRONG, 1))
        p.drawRoundedRect(r, 10, 10)


class DetailSheet(BaseSheet):
    """读一条新闻：正文占满，←→ 换上一条、下一条。"""
    story_opened = Signal(dict)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, "")
        self.prev_btn = IconButton("chevron_up", "上一条（←）", 30)
        self.next_btn = IconButton("chevron_down", "下一条（→）", 30)
        self.prev_btn.clicked.connect(self.go_prev)
        self.next_btn.clicked.connect(self.go_next)
        self.top.addWidget(self.prev_btn)
        self.top.addWidget(self.next_btn)
        self.story: dict = {}
        self.stories: list[dict] = []
        self.index = 0

    def open_story(self, story: dict, stories=None) -> None:
        self.stories = list(stories or [story])
        keys = [story_key(s) for s in self.stories]
        self.index = keys.index(story_key(story)) if story_key(story) in keys else 0
        self._render(story)
        self.open_sheet()

    def go_prev(self) -> None:
        if self.index > 0:
            self.index -= 1
            self._render(self.stories[self.index])
            self.scroll.stop_scroll(), self.scroll.verticalScrollBar().setValue(0)

    def go_next(self) -> None:
        if self.index < len(self.stories) - 1:
            self.index += 1
            self._render(self.stories[self.index])
            self.scroll.stop_scroll(), self.scroll.verticalScrollBar().setValue(0)

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        n = len(self.stories)
        if n < 2:
            return
        # 顶栏下面一排小刻度：这一条在今天几条里的位置
        p = QPainter(self)
        x0 = self.width() - 96 - n * 6
        for i in range(n):
            p.fillRect(x0 + i * 6, 20, 3, 7 if i == self.index else 5, C.ACCENT if i <= self.index else C.HAIRLINE_STRONG)

    def _render(self, story: dict) -> None:
        self.story = story
        self.clear()
        self.update()
        self.title_label.setText(f"第 {self.index + 1} / {len(self.stories)} 条")
        self.prev_btn.setEnabled(self.index > 0)
        self.next_btn.setEnabled(self.index < len(self.stories) - 1)
        self.il.addWidget(TextBlock(story.get("display_title") or story.get("title", ""), 19, 700, C.TEXT, 4, 1.4).fit())
        meta = "  ·  ".join(x for x in (story.get("source", ""), story.get("published_display", ""), story.get("region", ""), story.get("section_label", "")) if x)
        m = _label(meta, 12, 400, C.DIM)
        m.setWordWrap(True)
        self.il.addWidget(m)
        tags = (story.get("tags") or [])[:3]
        if tags:
            row = QHBoxLayout()
            row.setSpacing(5)
            for tag in tags:
                row.addWidget(TagLabel(tag))
            row.addStretch(1)
            self.il.addLayout(row)
        detail = story.get("detail") or story.get("summary") or "这条没有摘录，点下面的「阅读原文」看完整报道。"
        body = QLabel()
        body.setWordWrap(True)
        body.setTextFormat(Qt.TextFormat.RichText)
        body.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        body.setText(f"<div style='line-height:178%;'>{html.escape(detail).replace(chr(10), '<br>')}</div>")
        body.setFont(font(14))
        body.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
        self.il.addWidget(body)
        if story.get("why") or story.get("question"):
            self.il.addWidget(SectionHeader("阅读角度"))
            if story.get("why"):
                self.il.addWidget(TextBlock(story["why"], 13, 400, C.TEXT_SOFT, 6, 1.6).fit())
            if story.get("question"):
                self.il.addWidget(TextBlock(f"带着问题读：{story['question']}", 13, 600, C.ACCENT, 4, 1.55).fit())
        actions = QHBoxLayout()
        actions.setSpacing(8)
        url = story.get("url", "")
        open_btn = QPushButton("阅读原文")
        open_btn.setObjectName("primary")
        open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        open_btn.setEnabled(bool(url))
        open_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(url)))
        actions.addWidget(open_btn)
        copy_btn = QPushButton("复制链接")
        copy_btn.setObjectName("ghost")
        copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        copy_btn.setEnabled(bool(url))
        copy_btn.clicked.connect(lambda: self._copy(url))
        actions.addWidget(copy_btn)
        actions.addStretch(1)
        self.il.addSpacing(2)
        self.il.addLayout(actions)
        self.il.addStretch(1)
        self.story_opened.emit(story)

    def _copy(self, url: str) -> None:
        QApplication.clipboard().setText(url)
        win = self.window()
        if hasattr(win, "_toast"):
            win._toast("链接已复制")


class FilterSheet(BaseSheet):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, "这些新闻是怎么选出来的")

    def open_filter(self, edition: dict) -> None:
        self.clear()
        sel = edition.get("selection") or {}
        self.il.addWidget(TextBlock("不是把信息变少，而是把注意力留给能解释世界如何运转的线索。", 13, 400, C.MUTED, 3, 1.55).fit())
        funnel = sel.get("funnel") or {}
        row = QHBoxLayout()
        row.setSpacing(4)
        steps = [("抓取", funnel.get("fetched", 0)), ("过筛", funnel.get("gate_pass", 0)), ("去重", funnel.get("deduped", 0)), ("入选", funnel.get("selected", 0))]
        for i, (label, value) in enumerate(steps):
            col = QVBoxLayout()
            col.setSpacing(0)
            v = QLabel(str(value))
            v.setFont(mono(22, 500))
            v.setStyleSheet(f"color: {(C.ACCENT if i == 3 else C.TEXT).name()}; background: transparent;")
            v.setAlignment(Qt.AlignmentFlag.AlignCenter)
            t = _label(label, 12, 400, C.MUTED)
            t.setAlignment(Qt.AlignmentFlag.AlignCenter)
            col.addWidget(v)
            col.addWidget(t)
            row.addLayout(col, 1)
        self.il.addLayout(row)

        from core.editorial import DIMENSIONS, WEIGHTS
        self.il.addWidget(SectionHeader("今天的评分均值"))
        averages = sel.get("averages") or {}
        for key, label, desc in DIMENSIONS:
            weight = int((sel.get("weights") or WEIGHTS).get(key, WEIGHTS[key]) * 100)
            self.il.addWidget(_Bar(label, float(averages.get(key, 0) or 0), weight))
            self.il.addWidget(TextBlock(desc, 12, 400, C.DIM, 3, 1.45).fit())

        def join(items):
            return "   ".join(f"{name} {count}" for name, count in items)
        src = (sel.get("source_distribution") or {}).items()
        reg = (sel.get("region_distribution") or {}).items()
        if src or reg:
            self.il.addWidget(SectionHeader("来源与地区"))
            if src:
                self.il.addWidget(TextBlock(join(src), 13, 400, C.TEXT_SOFT, 4, 1.55).fit())
            if reg:
                self.il.addWidget(TextBlock(join(reg), 13, 400, C.MUTED, 3, 1.55).fit())

        reasons = sel.get("rejected_reasons") or []
        if reasons:
            self.il.addWidget(SectionHeader("被挡下的内容"))
            for reason, count in reasons[:5]:
                self.il.addWidget(_label(f"{reason}  ·  {count} 条", 12, 400, C.MUTED))

        pool = sel.get("candidate_pool") or []
        if pool:
            self.il.addWidget(SectionHeader("候选池前 8 条"))
            for c in pool[:8]:
                mark = "✓" if c.get("selected") else "·"
                self.il.addWidget(TextBlock(f"{mark}  {c.get('score', 0):.1f}  {c.get('source', '')}  {c.get('title', '')}", 12, 400,
                                            C.TEXT_SOFT if c.get("selected") else C.DIM, 3, 1.5).fit())

        self.il.addWidget(TextBlock("硬门槛：来源可信、时效；标题党、软新闻、猎奇排除。结构约束：同源不超过 3 条、同地区不超过 3 条、至少 4 个来源和 3 个地区。", 12, 400, C.DIM, 5, 1.5).fit())
        self.il.addStretch(1)
        self.open_sheet()


class _Bar(QWidget):
    """一个评分维度：名称、权重、均值条。"""

    def __init__(self, label: str, value: float, weight: int):
        super().__init__()
        self.label, self.value, self.weight = label, value, weight
        self.setFixedHeight(32)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(font(13, 600))
        p.setPen(C.TEXT_SOFT)
        p.drawText(QRectF(0, 0, self.width(), 20), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.label)
        p.setFont(font(12))
        p.setPen(C.DIM)
        p.drawText(QRectF(0, 0, self.width(), 20), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, f"权重 {self.weight}%  ·  均值 {self.value:.0f}")
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.GROOVE)
        p.drawRoundedRect(QRectF(0, 24, self.width(), 4), 2, 2)
        p.setBrush(C.ACCENT)
        p.drawRoundedRect(QRectF(0, 24, self.width() * max(0.0, min(100.0, self.value)) / 100, 4), 2, 2)


COLLAPSE_CHOICES = ((60, "1 分钟"), (180, "3 分钟"), (300, "5 分钟"), (600, "10 分钟"))


class SettingsSheet(BaseSheet):
    refresh_requested = Signal()
    archive_requested = Signal()
    settings_changed = Signal(dict)
    layout_requested = Signal(str)

    def __init__(self, config: dict, parent: QWidget | None = None, embedded: bool = False):
        super().__init__(parent, "设置")
        self.config = dict(config)
        self.switches: dict[str, Switch] = {}
        from .layouts import LAYOUT_NAMES, LAYOUT_TIPS, LAYOUTS, layout_name
        row = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(1)
        col.addWidget(_label("版式", 13, 600, C.TEXT))
        self.layout_desc = _label(LAYOUT_TIPS[layout_name(self.config)], 12, 400, C.MUTED)
        col.addWidget(self.layout_desc)
        self.layout_box = QComboBox()
        for key in LAYOUTS:
            self.layout_box.addItem(LAYOUT_NAMES[key], key)
        self.layout_box.setCurrentIndex(LAYOUTS.index(layout_name(self.config)))
        self.layout_box.currentIndexChanged.connect(
            lambda _i: QTimer.singleShot(0, lambda: self.layout_requested.emit(self.layout_box.currentData())))
        row.addLayout(col, 1)
        row.addWidget(self.layout_box)
        self.il.addLayout(row)
        self.il.addWidget(Hairline())
        rows = [("hide_on_fullscreen", "全屏时隐藏", "看视频、放映课件时不遮挡"),
                ("pinned", "保持展开", "不自动收起，适合专注阅读")]
        if not embedded:   # 在见微里由见微管开机启动
            rows.insert(0, ("auto_start", "开机自动启动", "登录 Windows 后静默驻留"))
        for key, label, desc in rows:
            row = QHBoxLayout()
            col = QVBoxLayout()
            col.setSpacing(1)
            col.addWidget(_label(label, 13, 600, C.TEXT))
            col.addWidget(_label(desc, 12, 400, C.MUTED))
            sw = Switch(bool(self.config.get(key, key == "auto_start")))
            sw.toggled.connect(lambda checked, k=key: self._set(k, checked))
            self.switches[key] = sw
            row.addLayout(col, 1)
            row.addWidget(sw)
            self.il.addLayout(row)
            self.il.addWidget(Hairline())

        row = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(1)
        col.addWidget(_label("没操作多久后收起", 13, 600, C.TEXT))
        col.addWidget(_label("打开阅读层时不会收起", 12, 400, C.MUTED))
        self.collapse_box = QComboBox()
        for sec, text in COLLAPSE_CHOICES:
            self.collapse_box.addItem(text, sec)
        self._sync_collapse()
        self.collapse_box.currentIndexChanged.connect(self._collapse_changed)
        row.addLayout(col, 1)
        row.addWidget(self.collapse_box)
        self.il.addLayout(row)
        self.il.addWidget(Hairline())

        row = QHBoxLayout()
        row.addWidget(_label("每日更新时间", 13, 600, C.TEXT))
        row.addStretch(1)
        self.update_value = _label("", 13, 400, C.MUTED)
        row.addWidget(self.update_value)
        self.il.addLayout(row)
        self._sync_update()
        self.il.addSpacing(4)

        btns = QHBoxLayout()
        btns.setSpacing(8)
        refresh = QPushButton("立即更新")
        refresh.setObjectName("primary")
        refresh.setCursor(Qt.CursorShape.PointingHandCursor)
        refresh.clicked.connect(self.refresh_requested)
        archive = QPushButton("打开档案库")
        archive.setObjectName("ghost")
        archive.setCursor(Qt.CursorShape.PointingHandCursor)
        archive.clicked.connect(self.archive_requested)
        btns.addWidget(refresh)
        btns.addWidget(archive)
        btns.addStretch(1)
        self.il.addLayout(btns)
        self.il.addSpacing(6)
        self.il.addWidget(SectionHeader("操作"))
        for line in ("Alt+Shift+G  展开或收起", "1 2 3 4  切换今日、人物、金句、档案", "R  重新筛选    Ctrl+P  自动播放",
                     "←  →  读新闻时换一条，人物页换一位", "Esc  返回或收起", "拖动顶栏换位置，双击顶栏回到默认位置"):
            self.il.addWidget(_label(line, 12, 400, C.MUTED))
        self.il.addStretch(1)

    def _sync_update(self) -> None:
        self.update_value.setText(f"{self.config.get('update_time', '07:15')}，开机后自动补齐")

    def _sync_collapse(self) -> None:
        sec = int(self.config.get("auto_collapse_seconds", 180) or 180)
        idx = self.collapse_box.findData(sec)
        self.collapse_box.blockSignals(True)
        self.collapse_box.setCurrentIndex(idx if idx >= 0 else 1)
        self.collapse_box.blockSignals(False)

    def set_config(self, config: dict) -> None:
        from .layouts import LAYOUT_TIPS, LAYOUTS, layout_name
        self.config = dict(config)
        self.layout_box.blockSignals(True)
        self.layout_box.setCurrentIndex(LAYOUTS.index(layout_name(self.config)))
        self.layout_box.blockSignals(False)
        self.layout_desc.setText(LAYOUT_TIPS[layout_name(self.config)])
        self._sync_update()
        self._sync_collapse()
        for key, sw in self.switches.items():
            sw.blockSignals(True)
            sw.setChecked(bool(config.get(key, False)))
            sw.blockSignals(False)

    def _collapse_changed(self, _i: int) -> None:
        self.config["auto_collapse_seconds"] = int(self.collapse_box.currentData())
        self.settings_changed.emit(dict(self.config))

    def _set(self, key: str, checked: bool) -> None:
        self.config[key] = checked
        self.settings_changed.emit(dict(self.config))


_ = (QColor,)
