"""见微 · 观澜内嵌：复用观澜源码浮窗，独立数据目录，无托盘/热键冲突。"""
from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

import store

GUANLAN_DIR = Path(__file__).resolve().parent / "guanlan"


class GuanlanHost:
    def __init__(self) -> None:
        self.window = None
        self.on_material=None
        self._lock = threading.Lock()

    def _ensure_path(self) -> None:
        self._ensure_home()   # 先定数据目录，再让 core.paths 被导入，否则路径会被锁到 exe 旁
        p = str(GUANLAN_DIR)
        if p not in sys.path:
            sys.path.insert(0, p)

    def _ensure_home(self) -> None:
        home = store.GUANLAN_HOME
        home.mkdir(parents=True, exist_ok=True)
        os.environ["JIANWEI_EMBED"] = "1"
        os.environ["JIANWEI_GUANLAN_HOME"] = str(home)

    def ensure(self):
        if self.window is not None:
            return self.window
        self._ensure_home()
        self._ensure_path()
        try:
            from ui.window import MainWindow  # type: ignore
        except Exception as exc:  # 缺依赖时给出可读状态，不崩主程序
            raise RuntimeError(f"观澜模块未就绪：{exc}") from exc
        self.window = MainWindow(start_collapsed=False, start_hidden=True)
        def collect(payload):
            try:
                if self.on_material is None:
                    raise ValueError('请从见微主程序打开素材篮')
                self.on_material(payload)
                self.window._toast('已收进作文素材，可在学习窗口的素材篮搜索与导出')
            except Exception:
                self.window._toast('素材未能保存，原数据保留，请检查数据目录')
        self.window.material_requested.connect(collect)
        return self.window

    def set_theme(self, name: str, skin: str | None = None) -> None:
        """跟随见微的昼夜和皮肤。还没建窗口时只记下来，建的时候就用这个主题。"""
        self._ensure_path()
        from ui import theme  # type: ignore
        if self.window is not None:
            self.window.set_theme(name, skin)
        else:
            theme.use(name, skin)

    # ------------------------------------------------------------ 版式
    def layout(self) -> str:
        """观澜现在的版式（panel / paper / card / strip），存在观澜自己的配置里。"""
        self._ensure_path()
        if self.window is not None:
            return self.window._layout
        try:
            from core.paths import load_config  # type: ignore
            from ui.layouts import layout_name  # type: ignore
            return layout_name(load_config())
        except Exception:
            return "panel"

    def set_layout(self, name: str) -> None:
        self._ensure_path()
        if self.window is not None:
            self.window.set_layout(name)
            return
        from core.paths import load_config, save_config  # type: ignore
        cfg = load_config()
        cfg["layout"] = name
        save_config(cfg)

    # ------------------------------------------------------------ 操作
    def show(self) -> bool:
        try:
            win = self.ensure()
            win.show_window()
            win.raise_()
            win.activateWindow()
            return True
        except Exception:
            return False

    def reload(self) -> None:
        """数据文件更新后，让浮窗就地换内容（不发网络请求）。"""
        if self.window is not None:
            try:
                self.window._load_data()
            except Exception:
                pass

    def hide(self) -> None:
        if self.window is not None:
            try:
                self.window.hide()
            except Exception:
                pass

    def toggle(self) -> bool:
        if self.is_visible():
            self.hide()
            return False
        return self.show()

    def is_visible(self) -> bool:
        try:
            return bool(self.window is not None and self.window.isVisible())
        except Exception:
            return False

    def evening(self, date: str = "") -> None:
        """生成当日暮省并全屏播放：交给独立进程，界面不阻塞。date 给了就重播那一期。"""
        import subprocess
        app_root = Path(__file__).resolve().parent
        self._ensure_home()
        self._ensure_path()
        extra = ["--evening-date", date] if date else ["--evening"]
        cmd = [sys.executable, *extra] if getattr(sys, "frozen", False) else [sys.executable, str(app_root / "main.py"), *extra]
        subprocess.Popen(cmd, cwd=str(app_root), close_fds=True, creationflags=0x00000008 if os.name == "nt" else 0)
