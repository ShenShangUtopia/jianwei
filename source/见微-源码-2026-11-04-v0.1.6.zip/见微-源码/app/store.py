"""见微 · 数据层：配置、题库索引、观澜摘要。"""
from __future__ import annotations

import json
import os
import re
from datetime import date, datetime
from pathlib import Path

APP_NAME = "见微"
APP_SUBTITLE = "高考学习舱"
VERSION = "1.6.0"

CODE_DIR = Path(__file__).resolve().parent
WEB_DIR = CODE_DIR / "studio" / "web"

HOME = Path(os.environ.get("JIANWEI_HOME") or (Path(os.environ.get("LOCALAPPDATA", CODE_DIR)) / "Jianwei"))
CONFIG_PATH = HOME / "config.json"
GUANLAN_HOME = HOME / "guanlan"
EDGE_PROFILE = HOME / "edge-profile"
DEEPSEEK_ENV = HOME / "deepseek.env"   # 格式同格物实验台的 .env：DEEPSEEK_API_KEY=…

DEFAULT_CONFIG = {
    "target": "2027-06-07 09:00:00",
    "start": "2026-09-01 00:00:00",
    "label": "高考",
    "year": "2027",
    "width": 700,
    "height": 52,
    "marginTop": 18,
    "radius": 26,
    "opacity": 0.99,
    "accent": "#D8C39B",
    "aurora": 96,
    "frost": 26,
    "shade": 108,
    "clickThrough": False,
    "zorder": "bottom",
    "alwaysOnTop": False,
    "showSeconds": True,
    "showDate": True,
    "showPill": True,
    "showGuanlanOnStart": True,
    "autoFetch": True,
    "autoEvening": True,
    "lastFetchDate": "",
    "lastEveningDate": "",
    "showGuanlan": False,
    "closeToTray": True,
    "startMinimized": False,
    "pillX": None,
    "theme": "auto",
}


def _workspace() -> Path:
    return CODE_DIR.parents[2] if len(CODE_DIR.parents) >= 3 else CODE_DIR


def _seed_candidates() -> list[Path]:
    out = []
    env = os.environ.get("JIANWEI_GUANLAN_SEED")
    if env:
        out.append(Path(env))
    out.append(_workspace() / "观澜桌面视界" / "data")
    out.append(_workspace() / "10-projects" / "guanlan" / "source" / "data")
    return out


def seed_guanlan_data() -> bool:
    """首次运行时，从本机观澜发行版复制当日内容，让新装立刻有东西看。"""
    dest = GUANLAN_HOME / "data"
    if (dest / "latest.json").exists():
        return False
    import shutil
    for src in _seed_candidates():
        if not (src / "latest.json").exists():
            continue
        try:
            dest.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src / "latest.json", dest / "latest.json")
            for name in ("index.json", "history.json", "evening_history.json"):
                if (src / name).exists():
                    shutil.copy2(src / name, dest / name)
            cfg_src = src.parent / "config.json"
            if cfg_src.exists() and not (GUANLAN_HOME / "config.json").exists():
                shutil.copy2(cfg_src, GUANLAN_HOME / "config.json")
            return True
        except Exception:
            continue
    return False


def release_root() -> Path | None:
    """本机观澜发行版根目录（迁移数据与任务接管用）。"""
    env = os.environ.get("JIANWEI_GUANLAN_RELEASE")
    cands = [Path(env)] if env else []
    cands.append(_workspace() / "观澜桌面视界")
    for c in cands:
        if (c / "data" / "latest.json").exists():
            return c
    return None


def edition_date(path: Path) -> str:
    try:
        return str(json.loads(path.read_text(encoding="utf-8-sig")).get("date") or "")
    except Exception:
        return ""


def sync_from_release() -> bool:
    """发行版比我们新时，把当日内容与档案库同步过来（过渡期安全网）。"""
    root = release_root()
    if root is None:
        return False
    src = root / "data"
    dest = GUANLAN_HOME / "data"
    src_date = edition_date(src / "latest.json")
    dest_date = edition_date(dest / "latest.json")
    if not src_date or src_date <= dest_date:
        return False
    import shutil
    try:
        dest.mkdir(parents=True, exist_ok=True)
        for name in ("latest.json", "index.json", "history.json", "evening_history.json"):
            if (src / name).exists():
                shutil.copy2(src / name, dest / name)
        arch_src = root / "档案库"
        if arch_src.exists():
            shutil.copytree(arch_src, GUANLAN_HOME / "档案库", dirs_exist_ok=True)
        return True
    except Exception:
        return False


def ensure_dirs() -> None:
    for d in (HOME, GUANLAN_HOME, GUANLAN_HOME / "data", GUANLAN_HOME / "档案库", GUANLAN_HOME / "logs"):
        d.mkdir(parents=True, exist_ok=True)
    try:
        seed_guanlan_data()
        sync_from_release()
    except Exception:
        pass


def load_config() -> dict:
    ensure_dirs()
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))
            if isinstance(raw, dict):
                cfg.update(raw)
        except Exception:
            # 解析失败时下面会按默认值重写：先把原文件留一份，别让手改坏的配置悄无声息地丢掉
            try:
                CONFIG_PATH.replace(CONFIG_PATH.with_name(f"config.broken-{datetime.now():%Y%m%d-%H%M%S}.json"))
            except Exception:
                pass
    # v2 胶囊：把早期那套偏大的尺寸/偏厚的墨色迁到现在的默认值（只迁一次）
    if not cfg.get("_pillV2"):
        for k in ("width", "height", "radius", "marginTop", "accent", "aurora", "frost", "shade"):
            cfg[k] = DEFAULT_CONFIG[k]
        cfg["_pillV2"] = True
        try:
            save_config(cfg)
        except Exception:
            pass
    return cfg


def save_config(cfg: dict) -> None:
    ensure_dirs()
    tmp = CONFIG_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, CONFIG_PATH)


_LAB = None


def lab_stats() -> dict:
    """扫描格物实验台的脚本：各科实验数、自由工作台列表（给本体的实验室页用）。"""
    global _LAB
    if _LAB is not None:
        return _LAB
    subj = {"math": 0, "phys": 0, "chem": 0, "bio": 0}
    benches: list[dict] = []
    for f in sorted((WEB_DIR / "gewu").glob("*.js")):
        try:
            text = f.read_text(encoding="utf-8-sig")
        except Exception:
            continue
        for m in re.finditer(r"Lab\.reg\(\{\s*id:\s*'[^']+',\s*subj:\s*'(\w+)'", text):
            if m.group(1) in subj:
                subj[m.group(1)] += 1
        for m in re.finditer(r"Bench\.reg\(\{\s*id:\s*'(\w+)',\s*subj:\s*'(\w+)',\s*short:\s*'([^']+)',"
                             r"\s*title:\s*'([^']+)',\s*sub:\s*'([^']+)'", text):
            benches.append({"id": m.group(1), "subj": m.group(2), "short": m.group(3),
                            "title": m.group(4), "sub": m.group(5)})
    order = ["chem", "phys", "circ", "draw", "scene"]
    benches.sort(key=lambda b: order.index(b["id"]) if b["id"] in order else 99)
    _LAB = {"subj": subj, "total": sum(subj.values()), "benches": benches}
    return _LAB


def _read_env(path: Path) -> dict:
    out: dict = {}
    try:
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"')
    except Exception:
        pass
    return out


def deepseek_settings() -> dict:
    """格物实验台「题目导入」用的 DeepSeek 设置：环境变量优先，其次数据目录里的 deepseek.env。

    每次请求现读，设置页改完立即生效；密钥只留在本机，不写进网页。
    """
    env = _read_env(DEEPSEEK_ENV)
    get = lambda k, d="": os.environ.get(k) or env.get(k) or d  # noqa: E731
    return {
        "key": get("DEEPSEEK_API_KEY"),
        "model": get("DEEPSEEK_MODEL", "deepseek-chat"),
        "base": get("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/"),
    }


def save_deepseek_key(key: str) -> None:
    ensure_dirs()
    env = _read_env(DEEPSEEK_ENV)
    if key:
        env["DEEPSEEK_API_KEY"] = key
    else:
        env.pop("DEEPSEEK_API_KEY", None)
    if env:
        DEEPSEEK_ENV.write_text("".join(f"{k}={v}\n" for k, v in env.items()), encoding="utf-8")
    elif DEEPSEEK_ENV.exists():
        DEEPSEEK_ENV.unlink()


def target_dt(cfg: dict) -> datetime:
    try:
        return datetime.strptime(cfg.get("target", DEFAULT_CONFIG["target"]), "%Y-%m-%d %H:%M:%S")
    except Exception:
        return datetime(2027, 6, 7, 9, 0, 0)


def start_dt(cfg: dict) -> datetime:
    try:
        return datetime.strptime(cfg.get("start", DEFAULT_CONFIG["start"]), "%Y-%m-%d %H:%M:%S")
    except Exception:
        return datetime(2026, 9, 1)


# ---------------------------------------------------------------- 题 库
_QS: list[dict] | None = None
FIELD = r"(?:'([^']*)'|\"([^\"]*)\")"


def _field(chunk: str, name: str) -> str:
    m = re.search(r"\b" + name + r"\s*:\s*" + FIELD, chunk)
    if not m:
        m = re.search(r"\b" + name + r"\s*:\s*(-?\d+(?:\.\d+)?)", chunk)
        return m.group(1) if m else ""
    return (m.group(1) if m.group(1) is not None else m.group(2)) or ""


def bank_ids() -> list[str]:
    ids: list[str] = []
    for f in sorted(WEB_DIR.glob("js/data/bank-*.js")):
        try:
            ids += re.findall(r"\bid\s*:\s*['\"]([^'\"]+)['\"]", f.read_text(encoding="utf-8-sig"))
        except Exception:
            pass
    seen, out = set(), []
    for i in ids:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out


def questions() -> list[dict]:
    global _QS
    if _QS is not None:
        return _QS
    out: list[dict] = []
    seen: set[str] = set()
    for f in sorted(WEB_DIR.glob("js/data/bank-*.js")):
        try:
            text = f.read_text(encoding="utf-8-sig")
        except Exception:
            continue
        starts = [m.start() for m in re.finditer(r"\bid\s*:\s*['\"]", text)]
        for k, pos in enumerate(starts):
            chunk = text[pos: starts[k + 1] if k + 1 < len(starts) else min(len(text), pos + 3000)]
            qid = _field(chunk, "id")
            # 视图数据里也有 id（食物网的「草」「兔」之类）：没有科目的不是题；同 id 以先出现的为准（与网页 JW.addQuestions 一致）
            if not qid or qid in seen or not _field(chunk, "subject"):
                continue
            seen.add(qid)
            raw = _field(chunk, "stem")
            out.append({
                "id": qid,
                "year": _field(chunk, "year"),
                "paper": _field(chunk, "paper"),
                "subject": _field(chunk, "subject"),
                "type": _field(chunk, "type"),
                "title": _field(chunk, "title") or raw[:24],
                "stem": raw[:400],
            })
    _QS = out
    return out


def bank_years() -> str:
    """题库覆盖的年份段，如「2023—2026」（界面文案用，别再写死）。"""
    ys = sorted({q["year"] for q in questions() if str(q.get("year", "")).isdigit()})
    if not ys:
        return ""
    return ys[0] if len(ys) == 1 else f"{ys[0]}—{ys[-1]}"


def question_of_day() -> dict | None:
    qs = questions()
    if not qs:
        return None
    seed = date.today().toordinal()
    return qs[(seed * 7919) % len(qs)]


# ---------------------------------------------------------------- 观 澜
def guanlan_latest() -> dict:
    p = GUANLAN_HOME / "data" / "latest.json"
    if not p.exists():
        p = CODE_DIR.parent / "data" / "latest.json"
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def guanlan_stories() -> list[dict]:
    ed = guanlan_latest()
    stories = ed.get("stories") or ed.get("items") or []
    out = []
    for s in stories[:9]:
        if not isinstance(s, dict):
            continue
        out.append({
            "title": s.get("display_title") or s.get("title") or s.get("headline") or "",
            "source": s.get("source") or "",
            "minutes": s.get("read_minutes") or s.get("minutes") or "",
            "summary": (s.get("summary") or s.get("digest") or "")[:90],
            "why": s.get("why") or "",
        })
    return out


def guanlan_lead() -> dict:
    ed = guanlan_latest()
    lead = ed.get("lead")
    if isinstance(lead, dict):
        return {
            "title": lead.get("display_title") or lead.get("title", ""),
            "summary": (lead.get("summary") or lead.get("why") or "")[:160],
            "source": lead.get("source", ""),
        }
    if isinstance(lead, str):
        return {"title": lead, "summary": "", "source": ""}
    stories = guanlan_stories()
    return stories[0] if stories else {"title": "今日版尚未生成", "summary": "", "source": ""}


def guanlan_date() -> str:
    ed = guanlan_latest()
    return str(ed.get("date") or "")


def evening_page_today() -> bool:
    """今晚的暮省页是否已经生成（计划任务或见微任一跑过都算）。"""
    page = Path(os.environ.get("LOCALAPPDATA", "")) / "Guanlan" / "evening" / "index.html"
    try:
        st = page.stat()
        return st.st_size > 2000 and datetime.fromtimestamp(st.st_mtime).date() == date.today()
    except Exception:
        return False
