"""见微 · 高考倒计时胶囊：逐像素磨砂 + 极光，置顶常显。"""
from __future__ import annotations

import ctypes
import math
import os
import time
from datetime import datetime

from PySide6.QtCore import QPoint, QRectF, Qt, QTimer
from PySide6.QtGui import (QColor, QFont, QGuiApplication, QImage, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap, QRadialGradient)
from PySide6.QtWidgets import QWidget

from ui_kit import MONO, NUM, UI
import store

WEEKDAYS = "一二三四五六日"
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x00000020
WS_EX_LAYERED = 0x00080000
WS_EX_NOACTIVATE = 0x08000000
WDA_EXCLUDEFROMCAPTURE = 0x00000011
HWND_BOTTOM = 1
HWND_TOPMOST = -1
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010


def _accent_rgb(hex_str: str) -> QColor:
    c = QColor(hex_str)
    return c if c.isValid() else QColor("#C9A86A")


def phase_week() -> str:
    """本学期第几周（以 9 月 1 日为第 1 周）。"""
    today = datetime.now()
    start = datetime(today.year if today.month >= 9 else today.year - 1, 9, 1)
    return str(max(1, (today - start).days // 7 + 1))


def _days_text(now: datetime, target: datetime) -> tuple[str, str]:
    delta = target - now
    if delta.total_seconds() <= 0:
        return "0", "已结束"
    total = delta.total_seconds()
    days = int(total // 86400)
    return str(days), "天"


def draw_pill(p: QPainter, w: float, h: float, cfg: dict, now: datetime,
              bg: QPixmap | None, phase: float) -> None:
    """把胶囊画进 painter（坐标 0..w/0..h），shell 预览与桌面浮窗共用。"""
    s = max(0.55, h / 64.0)
    radius = h / 2.0
    path = QPainterPath()
    path.addRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), radius, radius)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setClipPath(path)

    if bg is not None and not bg.isNull():
        p.drawPixmap(0, 0, w, h, bg)

    # 玻璃面：先一层奶白霜，再压一层冷墨，最后才是极光——三层叠出“磨砂”
    veil = QLinearGradient(0, 0, 0, h)
    veil.setColorAt(0.0, QColor(255, 255, 255, 38))
    veil.setColorAt(0.55, QColor(255, 255, 255, 24))
    veil.setColorAt(1.0, QColor(255, 255, 255, 14))
    p.fillPath(path, veil)

    shade = int(cfg.get("shade", 108))
    grad = QLinearGradient(0, 0, 0, h)
    grad.setColorAt(0.0, QColor(18, 30, 48, min(255, int(shade * 0.60))))
    grad.setColorAt(0.5, QColor(10, 19, 34, min(255, int(shade * 0.80))))
    grad.setColorAt(1.0, QColor(6, 12, 24, min(255, int(shade * 0.96))))
    p.fillPath(path, grad)

    # 极光：横向拉长的柔光带，贴着上下缘缓慢漂移（以前是几团小光斑，远看像污点）
    aurora = int(cfg.get("aurora", 96))
    if aurora > 0:
        k = aurora / 100.0
        bands = [  # 中心 x、y（相对），横向半径（相对 w），纵向半径（相对 h），颜色，相位
            (0.10, 0.92, 0.20, 0.95, (92, 196, 176), 0.9),
            (0.40, 0.04, 0.26, 0.85, (226, 188, 118), 2.4),
            (0.68, 0.98, 0.22, 0.90, (128, 124, 224), 1.2),
            (0.94, 0.20, 0.17, 0.85, (104, 182, 228), 3.1),
        ]
        p.setPen(Qt.PenStyle.NoPen)
        for bx, by, rx, ry, (cr, cg, cb), sp in bands:
            cx = (bx + 0.035 * math.sin(phase * 0.22 + sp)) * w
            cy = (by + 0.14 * math.sin(phase * 0.37 + sp)) * h
            rr = ry * h
            p.save()
            p.translate(cx, cy)
            p.scale(rx * w / rr, 1.0)
            rg = QRadialGradient(0, 0, rr)
            rg.setColorAt(0.0, QColor(cr, cg, cb, int(min(160, 100 * k))))
            rg.setColorAt(0.45, QColor(cr, cg, cb, int(min(80, 42 * k))))
            rg.setColorAt(1.0, QColor(cr, cg, cb, 0))
            p.setBrush(rg)
            p.drawEllipse(QRectF(-rr, -rr, 2 * rr, 2 * rr))
            p.restore()

    # 掠光：每 7 秒一道极淡的斜向高光扫过，极光的“动”就在这
    sweep = (phase % 7.0) / 7.0
    if sweep < 0.30:
        t = sweep / 0.30
        cx = (-0.35 + 1.7 * t) * w
        band = QLinearGradient(cx - w * 0.22, 0, cx + w * 0.22, 0)
        band.setColorAt(0.0, QColor(255, 255, 255, 0))
        band.setColorAt(0.5, QColor(255, 255, 255, 30))
        band.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillPath(path, band)

    # 顶部霜光
    frost = int(cfg.get("frost", 22))
    sheen = QLinearGradient(0, 0, 0, h * 0.75)
    sheen.setColorAt(0.0, QColor(255, 255, 255, max(0, int(frost * 2.4))))
    sheen.setColorAt(0.42, QColor(255, 255, 255, max(0, int(frost * 0.9))))
    sheen.setColorAt(1.0, QColor(255, 255, 255, 0))
    p.fillPath(path, sheen)
    p.setClipping(False)

    # 细描边 + 内侧高光
    p.setPen(QPen(QColor(255, 255, 255, 52), 1.0))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRoundedRect(QRectF(0.6, 0.6, w - 1.2, h - 1.2), radius - 0.4, radius - 0.4)
    p.setPen(QPen(QColor(255, 255, 255, 22), 1.0))
    p.drawLine(QPoint(int(w * 0.16), 1), QPoint(int(w * 0.84), 1))

    accent = _accent_rgb(cfg.get("accent", "#C9A86A"))
    target = store.target_dt(cfg)
    days, unit = _days_text(now, target)
    try:
        start = store.start_dt(cfg)
        frac = min(1.0, max(0.0, (now - start).total_seconds() / max(1.0, (target - start).total_seconds())))
    except Exception:
        frac = 0.0

    # 两端留白按圆角算：文字永远不会挤进半圆里
    pad = radius * 0.92 + 4 * s
    sep1 = pad + 112 * s
    sep2 = w - pad - 120 * s

    # 左：届别 + 周次 / 进度
    p.setFont(_font(UI, max(10.5, 11 * s), 500, 0.6 * s))
    p.setPen(QColor(255, 255, 255, 196))
    p.drawText(QRectF(pad, 0, sep1 - pad, h * 0.54),
               int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom),
               f"距 {cfg.get('year', '2027')} {cfg.get('label', '高考')}")
    p.setFont(_font(UI, max(9.0, 9.4 * s), 400, 0.3 * s))
    p.setPen(QColor(255, 255, 255, 128))
    p.drawText(QRectF(pad, h * 0.54 + 1, sep1 - pad, h * 0.42),
               int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop),
               f"第 {phase_week()} 周 · 已走 {int(frac * 100)}%")

    # 分隔线：两头渐隐的细线
    for sx in (sep1, sep2):
        lg = QLinearGradient(0, h * 0.24, 0, h * 0.76)
        lg.setColorAt(0.0, QColor(255, 255, 255, 0))
        lg.setColorAt(0.5, QColor(255, 255, 255, 46))
        lg.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setPen(QPen(lg, 1))
        p.drawLine(QPoint(int(sx), int(h * 0.24)), QPoint(int(sx), int(h * 0.76)))

    # 中：天数（衬线大数字 + 竖向渐变）
    p.setFont(_font(_lining_serif(), 33 * s, 600, 0.4 * s))
    text_rect = QRectF(sep1, 0, sep2 - sep1, h)
    metrics = p.fontMetrics()
    num_w = metrics.horizontalAdvance(days)
    unit_font_w = 13 * s
    group_w = num_w + unit_font_w + 10 * s
    x0 = text_rect.center().x() - group_w / 2

    shadow = QColor(0, 0, 0, 90)
    for dy, color in ((2, shadow), (0, None)):
        p.save()
        p.translate(0, dy)
        if color is not None:
            p.setPen(color)
        else:
            ng = QLinearGradient(0, h * 0.18, 0, h * 0.86)
            ng.setColorAt(0.0, QColor(255, 255, 255, 250))
            ng.setColorAt(0.55, QColor(240, 236, 226, 245))
            ng.setColorAt(1.0, QColor(206, 198, 182, 235))
            p.setPen(QPen(ng, 1))
        p.drawText(QRectF(x0 - 2, 0, num_w + 8, h),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), days)
        p.restore()

    p.setFont(_font(UI, 10.5 * s, 500, 1.0 * s))
    p.setPen(QColor(255, 255, 255, 190))
    p.drawText(QRectF(x0 + num_w + 6 * s, 0, unit_font_w + 24 * s, h * 0.5 + 9 * s),
               int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom), unit)

    # 右：时间 + 日期（右缘与左栏对称地停在 pad 处）
    right = QRectF(sep2 + 10 * s, 0, w - pad - sep2 - 10 * s, h)
    p.setFont(_font(MONO, max(12.0, 13 * s), 500, 0.6 * s))
    p.setPen(QColor(255, 255, 255, 236))
    clock = now.strftime("%H:%M:%S" if cfg.get("showSeconds", True) else "%H:%M")
    clock_rect = QRectF(right.x(), 0, right.width(), h * (0.56 if cfg.get("showDate", True) else 1.0))
    p.drawText(clock_rect, int(Qt.AlignmentFlag.AlignRight
                               | (Qt.AlignmentFlag.AlignBottom if cfg.get("showDate", True) else Qt.AlignmentFlag.AlignVCenter)),
               clock)

    if cfg.get("showDate", True):
        p.setFont(_font(UI, max(9.0, 9.4 * s), 400, 0.3 * s))
        p.setPen(QColor(255, 255, 255, 136))
        date_text = f"{now:%m.%d} 周{WEEKDAYS[now.weekday()]}"
        p.drawText(QRectF(right.x(), h * 0.56 + 1, right.width(), h * 0.4),
                   int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop), date_text)

    # 底缘进度：一条细线贴着圆角内缘，末端一粒带光晕的点
    track = QRectF(pad, h - 3.2 * s, w - 2 * pad, 1.3 * s)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(255, 255, 255, 20))
    p.drawRoundedRect(track, 0.7, 0.7)
    end_x = track.x() + max(2.0, track.width() * frac)
    fg = QLinearGradient(track.x(), 0, end_x, 0)
    c0, c1 = QColor(accent), QColor(accent)
    c0.setAlpha(40)
    c1.setAlpha(190)
    fg.setColorAt(0.0, c0)
    fg.setColorAt(1.0, c1)
    p.setBrush(fg)
    p.drawRoundedRect(QRectF(track.x(), track.y(), end_x - track.x(), track.height()), 0.7, 0.7)
    glow = QRadialGradient(end_x, track.center().y(), 5 * s)
    g0 = QColor(accent)
    g0.setAlpha(150)
    glow.setColorAt(0.0, g0)
    glow.setColorAt(1.0, QColor(accent.red(), accent.green(), accent.blue(), 0))
    p.setBrush(glow)
    p.drawEllipse(QRectF(end_x - 5 * s, track.center().y() - 5 * s, 10 * s, 10 * s))
    p.setBrush(QColor(255, 248, 232, 230))
    p.drawEllipse(QRectF(end_x - 1.4 * s, track.center().y() - 1.4 * s, 2.8 * s, 2.8 * s))
    p.restore()


_LINING = None


def _lining_serif() -> str:
    """天数用等高数字的衬线体（Georgia 是旧式数字，5、9 会掉到基线下面）。"""
    global _LINING
    if _LINING is None:
        from PySide6.QtGui import QFontDatabase
        fams = set(QFontDatabase.families())
        _LINING = next((f for f in ("Cambria", "Times New Roman", "Palatino Linotype") if f in fams), NUM)
    return _LINING


def _font(family: str, px: float, weight: int = 400, spacing: float = 0.0) -> QFont:
    font = QFont(family)
    font.setPixelSize(max(7, int(round(px))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    font.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    return font


class CountdownPill(QWidget):
    def __init__(self, cfg: dict):
        super().__init__(None, Qt.WindowType.FramelessWindowHint
                         | Qt.WindowType.Tool
                         | Qt.WindowType.WindowDoesNotAcceptFocus
                         | Qt.WindowType.NoDropShadowWindowHint)
        self.cfg = dict(cfg)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setWindowTitle("见微 · 倒计时")
        self._bg: QPixmap | None = None
        self._bg_at = 0.0
        self._t0 = time.monotonic()
        self._drag_from: QPoint | None = None
        self._win_pos: QPoint | None = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self.apply_config(self.cfg)
        self._timer.start(50)

    # ------------------------------------------------------------ 配置
    def apply_config(self, cfg: dict) -> None:
        self.cfg = dict(cfg)
        w = int(cfg.get("width", 880))
        h = int(cfg.get("height", 64))
        screen = QGuiApplication.primaryScreen().availableGeometry()
        # 永远按屏幕居中；不因侧边浮窗而偏移
        x = cfg.get("pillX")
        if not isinstance(x, int):
            x = screen.x() + (screen.width() - w) // 2
        y = screen.y() + int(cfg.get("marginTop", 22))
        self.setGeometry(x, y, w, h)
        self.setWindowOpacity(float(cfg.get("opacity", 0.98)))
        self._apply_flags()
        self._assert_zorder()
        self.update()

    def _assert_zorder(self) -> None:
        """沉到最底层：只在桌面/壁纸上可见，任何应用窗口都能压住它。"""
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_NOACTIVATE
            if self.cfg.get("clickThrough"):
                style |= WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
            target = HWND_TOPMOST if str(self.cfg.get("zorder", "bottom")) == "top" else HWND_BOTTOM
            user32.SetWindowPos(hwnd, target, 0, 0, 0, 0,
                                SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)
        except Exception:
            pass

    def _apply_flags(self) -> None:
        if not self.isVisible():
            return
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_LAYERED
            if self.cfg.get("clickThrough"):
                style |= WS_EX_TRANSPARENT
            else:
                style &= ~WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        except Exception:
            pass

    def showEvent(self, ev) -> None:
        super().showEvent(ev)
        try:
            ctypes.windll.user32.SetWindowDisplayAffinity(int(self.winId()), WDA_EXCLUDEFROMCAPTURE)
        except Exception:
            pass
        self._apply_flags()
        self._assert_zorder()
        self._grab_bg()
        self._drop_shadow_hint()
        self._z_timer = QTimer(self)
        self._z_timer.timeout.connect(self._assert_zorder)
        # 每 1.5 秒重申一次置底会和别的置底窗互相抢，画面一直在闪；改成 1 分钟兜底
        self._z_timer.start(60000)

    def _drop_shadow_hint(self) -> None:
        pass

    # ------------------------------------------------------------ 帧
    def _tick(self) -> None:
        if not self.isVisible():
            return
        now = time.monotonic()
        if now - self._bg_at > 30:
            self._grab_bg()
            self._bg_at = now
        self.update()

    def _load_wallpaper(self):
        try:
            buf = ctypes.create_unicode_buffer(1024)
            ok = ctypes.windll.user32.SystemParametersInfoW(0x0073, 1024, buf, 0)
            path = buf.value
            if ok and path and os.path.exists(path):
                img = QImage(path)
                if not img.isNull():
                    return img
        except Exception:
            pass
        return None

    def _grab_bg(self) -> None:
        """取壁纸对应位置的一小片，重采样到极低分辨率再放大 —— 磨砂玻璃的底。

        实时截屏在这里不可用：本机 SetWindowDisplayAffinity 失败，截出来会把胶囊自己
        拍进去（越拍越黑）。壁纸磨砂在视觉上等价，且永不递归、几乎不耗 CPU。
        """
        try:
            if getattr(self, "_wall", None) is None:
                self._wall = self._load_wallpaper()
            if self._wall is None:
                self._bg = None
                return
            screen = (self.screen() or QGuiApplication.primaryScreen()).geometry()
            W, H = screen.width(), screen.height()
            w, h = max(2, self.width()), max(2, self.height())
            img = self._wall
            scale = max(W / max(1, img.width()), H / max(1, img.height()))
            sw = int(img.width() * scale + 0.5)
            sh = int(img.height() * scale + 0.5)
            cover = img.scaled(sw, sh, Qt.AspectRatioMode.IgnoreAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
            ox = max(0, min(sw - w, self.x() - screen.x() + (sw - W) // 2))
            oy = max(0, min(sh - h, self.y() - screen.y() + (sh - H) // 2))
            crop = cover.copy(ox, oy, w, h)
            small = crop.scaled(max(6, w // 18), max(5, h // 18),
                                Qt.AspectRatioMode.IgnoreAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
            self._bg = QPixmap.fromImage(small.scaled(
                w, h, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation))
        except Exception:
            self._bg = None

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        phase = time.monotonic() - self._t0
        draw_pill(p, self.width(), self.height(), self.cfg, datetime.now(), self._bg, phase)
        p.end()

    # ------------------------------------------------------------ 拖拽
    def mousePressEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        if ev.button() == Qt.MouseButton.LeftButton:
            self._drag_from = ev.globalPosition().toPoint() - self.pos()

    def mouseMoveEvent(self, ev) -> None:
        if self._drag_from is not None and not self.cfg.get("clickThrough"):
            self.move(ev.globalPosition().toPoint() - self._drag_from)

    def mouseReleaseEvent(self, ev) -> None:
        if self._drag_from is not None:
            self._drag_from = None
            self.cfg["pillX"] = self.x()
            self._grab_bg()

    def closeEvent(self, ev) -> None:
        self._timer.stop()
        super().closeEvent(ev)
