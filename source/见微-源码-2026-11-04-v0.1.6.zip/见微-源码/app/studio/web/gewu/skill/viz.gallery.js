/* 图解自测：在实验台页面里 eval，把 11 个题型的图解都画出来（翻到最后一步），返回出错的题型。
 * 用法：(0, eval)(await (await fetch('skill/viz.gallery.js')).text()) */
(() => {
  const specs = {
    func: { kind: 'func', f: 'x^3-3*x', asks: [{ what: 'zeros' }, { what: 'local_max' }, { what: 'tangent', x: 2 }, { what: 'integral', a: 0, b: 2 }] },
    conic: { kind: 'conic', curve: 'x^2/16+y^2/9=1', line: 'y=x+1', asks: [{ what: 'chord' }, { what: 'midpoint' }, { what: 'area' }, { what: 'distance' }] },
    solid: { kind: 'solid', points: { A: [0, 0, 0], B: [2, 0, 0], C: [2, 2, 0], D: [0, 2, 0], A1: [0, 0, 2], B1: [2, 0, 2], C1: [2, 2, 2], D1: [0, 2, 2], E: [2, 2, 1] }, asks: [{ what: 'angle_line_plane', line: ['A1', 'E'], plane: ['A', 'B', 'C'] }, { what: 'dihedral', edge: ['B', 'D'], faces: ['A1', 'A'] }, { what: 'volume', points: ['E', 'A', 'B', 'D'] }, { what: 'distance_point_plane', point: 'A', plane: ['A1', 'B', 'D'] }] },
    prob: { kind: 'prob', dist: { type: 'binomial', n: 6, p: 0.4 }, asks: [{ what: 'P', event: 'X>=3' }, { what: 'E' }, { what: 'D' }] },
    probN: { kind: 'prob', dist: { type: 'normal', mu: 100, sigma: 10 }, asks: [{ what: 'P', event: '90<X<120' }, { what: 'E' }] },
    seq: { kind: 'seq', type: 'recur', a1: 1, rule: '2*a+1', asks: [{ what: 'term', n: 5 }, { what: 'sum', n: 6 }] },
    reaction: { kind: 'reaction', equation: '2H2+O2=2H2O', given: [{ species: 'H2', mass: 4 }, { species: 'O2', mol: 0.5 }], asks: [{ what: 'mass', species: 'H2O' }] },
    solution: { kind: 'solution', components: [{ name: 'Na2CO3', type: 'salt_weak_acid', Ka: [4.4e-7, 4.7e-11], c: 0.1 }], asks: [{ what: 'pH' }] },
    equilibrium: { kind: 'equilibrium', reaction: 'N2+3H2⇌2NH3', V_L: 2, initial: { N2: 1, H2: 3 }, at_eq: { NH3: { mol: 0.4 } }, asks: [{ what: 'K' }] },
    cross: { kind: 'cross', loci: [{ alleles: ['A', 'a'] }, { alleles: ['XB', 'Xb'], sex_linked: true }], parents: ['AaXBXb', 'AaXbY'], asks: [{ what: 'P', phenotype: 'aaXbY' }, { what: 'phenotype_ratio' }] },
    cross2: { kind: 'cross', loci: [{ alleles: ['Y', 'y'] }, { alleles: ['R', 'r'] }], parents: ['YyRr', 'YyRr'], asks: [{ what: 'phenotype_ratio' }, { what: 'P', phenotype: 'Y_rr', given: { phenotype: 'Y_' } }] },
    dna: { kind: 'dna', seq: 'TACCGGATTGCAACT', strand: 'template', asks: [{ what: 'mrna' }, { what: 'protein' }] },
    foodweb: { kind: 'foodweb', links: { 鹰: { 蛇: 0.5, 鼠: 0.5 }, 蛇: { 鼠: 1 }, 鼠: { 草: 1 } }, efficiency: 0.1, asks: [{ what: 'producer', consumer: '鹰', amount: 1 }] }
  };
  let box = document.getElementById('vz-gallery');
  if (!box) { box = document.createElement('div'); box.id = 'vz-gallery'; box.className = 'lesson'; document.getElementById('view').prepend(box); }
  box.innerHTML = '';
  const errs = [];
  for (const [k, s] of Object.entries(specs)) {
    const r = Tasks.build(s);
    if (!r.ok) { errs.push(k + ': ' + r.errors.join('；')); continue; }
    const h = document.createElement('div'); h.className = 'viz-host'; h.id = 'vzg-' + k; box.appendChild(h);
    Viz.state['g-' + k] = { k: 99 };
    Viz.mount(h, r.result, 'g-' + k);
    if (!h.isConnected || h.querySelector('.note')) errs.push(k + ': ' + (h.isConnected ? h.textContent : '没有画出来'));
  }
  return { count: box.querySelectorAll('.vz').length, errs };
})();
