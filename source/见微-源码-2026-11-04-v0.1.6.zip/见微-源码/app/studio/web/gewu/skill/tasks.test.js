/* 题型求解器自测：在实验台页面的控制台运行 await import('./skill/tasks.test.js')，或把内容粘进控制台。
 * 每条都是教材 / 高考常见题，答案手算核对过。返回 {pass, fail, lines}。 */
(() => {
  const out = [], T = (name, spec, checks, problem = '') => {
    const r = Tasks.build(spec, problem);
    if (checks === 'error') { out.push([!r.ok, name, r.ok ? '应报错却通过了' : r.errors.join(' | ').slice(0, 160)]); return; }
    if (!r.ok) { out.push([false, name, r.errors.join(' | ')]); return; }
    checks.forEach((want, i) => {
      const row = r.result.rows[i];
      let ok;
      if (typeof want === 'number') ok = typeof row.value === 'number' && Math.abs(row.value - want) <= 1e-4 * Math.max(1, Math.abs(want));
      else if (want === true || want === false) ok = row.ok === want;
      else if (Array.isArray(want)) ok = Array.isArray(row.value) && row.value.length === want.length && row.value.every((v, k) => Math.abs((Array.isArray(v) ? v[0] : v) - want[k]) < 1e-4);
      else ok = String(row.text).includes(want);
      out.push([ok, `${name} · ${row.prompt}`, row.text + (row.ok === null ? '' : row.ok ? ' ✓' : ' ✗')]);
    });
  };
  // 数学
  T('三次函数', { kind: 'func', f: 'x^3-3*x', asks: [{ what: 'local_max', claimed: [2] }, { what: 'local_min' }, { what: 'zeros', claimed: '-√3, 0, √3' }, { what: 'tangent', x: 2, claimed: 'y=9x-16' }, { what: 'integral', a: 0, b: 2 }, { what: 'monotonic' }] },
    [true, [-2], true, true, -2, '减区间：(-1, 1)']);
  T('有界区间最值', { kind: 'func', f: 'x^3-3*x', domain: [-3, 3], asks: [{ what: 'max', claimed: 18 }, { what: 'min' }] }, [true, -18]);
  T('偶重根', { kind: 'func', f: '(x-1)^2*(x+2)', asks: [{ what: 'zeros' }] }, [[-2, 1]]);
  T('间断点不是零点', { kind: 'func', f: '1/x', asks: [{ what: 'zeros' }] }, [[]]);
  T('函数写错', { kind: 'func', f: 'x^^2', asks: [{ what: 'zeros' }] }, 'error');
  T('椭圆弦长', { kind: 'conic', curve: 'x^2/16+y^2/9=1', line: 'y=x+1', asks: [{ what: 'chord', claimed: '96√3/25' }, { what: 'midpoint', claimed: [-0.64, 0.36] }, { what: 'area' }, { what: 'distance' }, { what: 'chord', claimed: 3.3255 }] },
    [true, true, 24 * Math.sqrt(6) / 25, Math.SQRT1_2, false]);
  T('精确值识别', { kind: 'conic', curve: 'x^2/16+y^2/9=1', line: 'y=x+1', asks: [{ what: 'chord' }] }, ['96√3/25']);
  T('抛物线', { kind: 'conic', curve: 'y^2=4*x', line: 'x=1', asks: [{ what: 'intersections', claimed: '(1,2),(1,-2)' }, { what: 'chord' }] }, [true, 4]);
  T('相切', { kind: 'conic', curve: 'x^2+y^2=1', line: 'y=1', asks: [{ what: 'count' }] }, [1]);
  const cube = { A: [0, 0, 0], B: [2, 0, 0], C: [2, 2, 0], D: [0, 2, 0], A1: [0, 0, 2], C1: [2, 2, 2] };
  T('正方体线面角', { kind: 'solid', points: cube, given: [{ seg: ['A', 'B'], length: 2 }, { perp: [['A', 'B'], ['A', 'A1']] }], asks: [{ what: 'angle_line_plane', line: ['A1', 'C'], plane: ['A', 'B', 'C'], claimed: '√3/3' }, { what: 'dihedral', edge: ['B', 'D'], faces: ['A1', 'A'] }, { what: 'volume', points: ['A', 'B', 'D', 'A1'] }, { what: 'distance_point_plane', point: 'A', plane: ['A1', 'B', 'D'] }] },
    [true, 1 / Math.sqrt(3), 4 / 3, 2 / Math.sqrt(3)]);
  T('坐标与条件不符', { kind: 'solid', points: cube, given: [{ seg: ['A', 'B'], length: 3 }], asks: [{ what: 'distance', between: ['A', 'C1'] }] }, 'error');
  T('二项分布', { kind: 'prob', dist: { type: 'binomial', n: 5, p: 0.3 }, asks: [{ what: 'P', event: 'X>=2', claimed: 0.4718 }, { what: 'E' }, { what: 'D' }, { what: 'P', event: 'X≥2', claimed: 0.5 }] }, [true, 1.5, 1.05, false]);
  T('超几何', { kind: 'prob', dist: { type: 'hypergeometric', N: 10, M: 3, n: 4 }, asks: [{ what: 'E' }, { what: 'P', event: 'X=1', claimed: '1/2' }] }, [1.2, true]);
  T('正态', { kind: 'prob', dist: { type: 'normal', mu: 100, sigma: 10 }, asks: [{ what: 'P', event: '90<X<110', claimed: 0.6827 }] }, [true]);
  T('分布列和不为 1', { kind: 'prob', dist: { type: 'table', x: [0, 1, 2], p: [0.2, 0.5, 0.4] }, asks: [{ what: 'E' }] }, 'error');
  T('递推数列', { kind: 'seq', type: 'recur', a1: 1, rule: '2*a+1', asks: [{ what: 'term', n: 10, claimed: 1023 }, { what: 'sum', n: 10 }, { what: 'formula', formula: '2^n-1' }, { what: 'formula', formula: '2^n' }] }, [true, 2036, true, false]);
  T('等差数列', { kind: 'seq', type: 'arith', a1: 3, d: 2, asks: [{ what: 'sum_formula', formula: 'n^2+2*n' }] }, [true]);
  // 化学
  T('高锰酸钾制氯气', { kind: 'reaction', equation: '2KMnO4+16HCl(浓)=2KCl+2MnCl2+5Cl2↑+8H2O', given: [{ species: 'KMnO4', mass: 15.8 }], asks: [{ what: 'volume', species: 'Cl2', claimed: 5.6 }, { what: 'molar_mass', species: 'KMnO4' }, { what: 'mol', species: 'HCl' }] }, [true, 158, 0.8]);
  T('没配平', { kind: 'reaction', equation: 'KMnO4+HCl=KCl+MnCl2+Cl2+H2O', asks: [{ what: 'coef', species: 'Cl2' }] }, 'error');
  T('离子方程式', { kind: 'reaction', equation: 'Fe3++3OH-=Fe(OH)3↓', asks: [{ what: 'balanced', claimed: 'Fe^3+ + 3OH^- = Fe(OH)3' }] }, [true]);
  T('铵根', { kind: 'reaction', equation: 'NH4+ + OH- = NH3↑ + H2O', asks: [{ what: 'coef', species: 'NH4+' }] }, [1]);
  T('箭头上的催化剂', { kind: 'reaction', equation: '2KClO3 =MnO2= 2KCl + 3O2↑', given: [{ species: 'KClO3', mass: 24.5 }], asks: [{ what: 'mass', species: 'O2' }] }, [9.6]);
  T('不足量', { kind: 'reaction', equation: '2H2+O2=2H2O', given: [{ species: 'H2', mass: 4 }, { species: 'O2', mol: 0.5 }], asks: [{ what: 'mass', species: 'H2O' }, { what: 'remaining_mol', species: 'H2' }] }, [18, 1]);
  T('电荷歧义', { kind: 'reaction', equation: 'Ba2+ + SO42- = BaSO4', asks: [{ what: 'coef', species: 'BaSO4' }] }, 'error');
  T('醋酸 pH', { kind: 'solution', components: [{ name: 'CH3COOH', type: 'weak_acid', Ka: [1.8e-5], c: 0.1 }], asks: [{ what: 'pH', claimed: 2.87 }, { what: 'alpha' }] }, [true, 0.0133]);
  T('缓冲溶液', { kind: 'solution', components: [{ name: 'HAc', type: 'weak_acid', Ka: [1.8e-5], c: 0.1, V_mL: 20 }, { name: 'NaOH', type: 'strong_base', c: 0.1, V_mL: 10 }], asks: [{ what: 'pH', claimed: 4.74 }] }, [true]);
  T('氯化铵', { kind: 'solution', components: [{ name: 'NH4Cl', type: 'salt_weak_base', Kb: [1.8e-5], c: 0.1 }], asks: [{ what: 'pH', claimed: 5.13 }] }, [true]);
  T('碳酸钠', { kind: 'solution', components: [{ name: 'Na2CO3', type: 'salt_weak_acid', Ka: [4.4e-7, 4.7e-11], c: 0.1 }], asks: [{ what: 'pH', claimed: 11.66 }] }, [true]);
  T('硫酸', { kind: 'solution', components: [{ name: 'H2SO4', type: 'strong_acid', z: 2, c: 0.005 }], asks: [{ what: 'pH' }] }, [2]);
  T('合成氨平衡', { kind: 'equilibrium', reaction: 'N2+3H2⇌2NH3', V_L: 2, initial: { N2: 1, H2: 3 }, at_eq: { NH3: { mol: 0.4 } }, asks: [{ what: 'K' }, { what: 'conversion', species: 'N2', claimed: '20%' }, { what: 'pressure_ratio' }, { what: 'fraction', species: 'NH3' }] }, [0.04 / (0.4 * 1.728), true, 0.9, 0.4 / 3.6]);
  T('由 K 求平衡', { kind: 'equilibrium', reaction: 'N2+3H2⇌2NH3', V_L: 2, initial: { N2: 1, H2: 3 }, K: 0.04 / (0.4 * 1.728), asks: [{ what: 'mol', species: 'NH3' }] }, [0.4]);
  // 生物
  T('两对相对性状', { kind: 'cross', loci: [{ alleles: ['A', 'a'] }, { alleles: ['B', 'b'] }], parents: ['AaBb', 'AaBb'], asks: [{ what: 'phenotype_ratio', claimed: '9:3:3:1' }, { what: 'P', genotype: 'aabb', claimed: '1/16' }, { what: 'P', phenotype: 'A_bb' }, { what: 'count_genotypes' }, { what: 'P', phenotype: 'aaB_', given: { phenotype: 'aa' }, claimed: 0.75 }] }, [true, true, 3 / 16, 9, true]);
  T('伴 X', { kind: 'cross', loci: [{ alleles: ['A', 'a'] }, { alleles: ['XB', 'Xb'], sex_linked: true }], parents: ['AaXBXb', 'AaXbY'], asks: [{ what: 'P', phenotype: 'aaXbY', claimed: '1/16' }, { what: 'P', phenotype: 'XBX_', sex: 'female' }, { what: 'P', genotype: 'XbY', given: { sex: 'male' } }] }, [true, 0.25, 0.5]);
  T('显性纯合致死', { kind: 'cross', loci: [{ alleles: ['A', 'a'] }], parents: ['Aa', 'Aa'], lethal: ['AA'], asks: [{ what: 'phenotype_ratio', claimed: '2:1' }] }, [true]);
  T('ABO 血型', { kind: 'cross', loci: [{ alleles: ['IA', 'IB', 'i'], codominant: ['IA', 'IB'] }], parents: ['IAi', 'IBi'], asks: [{ what: 'phenotype_ratio', claimed: '1:1:1:1' }, { what: 'P', phenotype: 'IAIB' }, { what: 'P', phenotype: 'ii' }] }, [true, 0.25, 0.25]);
  T('F2 双显性自交', { kind: 'cross', loci: [{ alleles: ['A', 'a'] }, { alleles: ['B', 'b'] }], parents: ['AaBb', 'AaBb'], select: 'A_B_', then: 'self', asks: [{ what: 'P', genotype: 'aabb', claimed: '1/36' }] }, [true]);
  T('显性个体自由交配', { kind: 'cross', loci: [{ alleles: ['A', 'a'] }], parents: ['Aa', 'Aa'], select: 'A_', then: 'random', asks: [{ what: 'P', genotype: 'aa', claimed: '1/9' }] }, [true]);
  T('豌豆 Y/y 不是 Y 染色体', { kind: 'cross', loci: [{ alleles: ['Y', 'y'] }, { alleles: ['R', 'r'] }], parents: ['YyRr', 'YyRr'], select: 'Y_R_', then: 'self', asks: [{ what: 'P', phenotype: 'yyrr', claimed: '1/36' }, { what: 'count_genotypes' }] }, [true, 9]);
  T('豌豆 F1 表型比', { kind: 'cross', loci: [{ alleles: ['Y', 'y'] }, { alleles: ['R', 'r'] }], parents: ['YyRr', 'yyrr'], asks: [{ what: 'phenotype_ratio', claimed: '1:1:1:1' }, { what: 'P', genotype: 'Yyrr' }] }, [true, 0.25]);
  T('不完全显性', { kind: 'cross', loci: [{ alleles: ['A', 'a'], codominant: ['A', 'a'] }], parents: ['Aa', 'Aa'], asks: [{ what: 'phenotype_ratio', claimed: '1:2:1' }] }, [true]);
  T('伴 X 两雌', { kind: 'cross', loci: [{ alleles: ['XB', 'Xb'], sex_linked: true }], parents: ['XBXb', 'XbXb'], asks: [{ what: 'count_phenotypes' }] }, 'error');
  T('转录翻译', { kind: 'dna', seq: 'ATGGCCTAA', strand: 'coding', asks: [{ what: 'mrna', claimed: 'AUGGCCUAA' }, { what: 'protein', claimed: '甲硫氨酸—丙氨酸' }, { what: 'codons' }] }, [true, true, 3]);
  T('模板链', { kind: 'dna', seq: 'TACCGGATT', strand: 'template', asks: [{ what: 'protein', claimed: '甲硫氨酸-丙氨酸' }, { what: 'h_bonds' }, { what: 'gc' }] }, [true, 2 * 5 + 3 * 4, 4 / 9]);
  T('食物网', { kind: 'foodweb', links: { 鹰: { 兔: 0.5, 鼠: 0.5 }, 兔: { 草: 1 }, 鼠: { 草: 1 } }, efficiency: 0.1, asks: [{ what: 'producer', consumer: '鹰', amount: 1, claimed: 100 }] }, [true]);
  T('至少消耗', { kind: 'foodweb', links: { 鹰: { 蛇: 1, 鼠: 1 }, 蛇: { 鼠: 1 }, 鼠: { 草: 1 } }, efficiency: [0.1, 0.2], asks: [{ what: 'producer', consumer: '鹰', amount: 1, mode: 'min', claimed: 25 }, { what: 'producer', consumer: '鹰', amount: 1, mode: 'max' }, { what: 'gain', consumer: '鹰', amount: 100, mode: 'max' }] }, [true, 1000, 4]);
  const pass = out.filter(x => x[0]).length;
  return { pass, fail: out.length - pass, lines: out.map(x => (x[0] ? 'ok   ' : 'FAIL ') + x[1] + ' → ' + x[2]) };
})();
