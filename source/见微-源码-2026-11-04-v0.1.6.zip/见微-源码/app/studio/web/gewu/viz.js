'use strict';
/* ======================= 题型图解：程序求解的结果画成可以一步步讲的图 =======================
 * 每个题型（tasks.js 的 kind）一种图：函数图像、圆锥曲线、可旋转的立体图、分布图、数列、原子守恒与物质的量、
 * pH 与分布曲线、三段式、棋盘法、碱基配对与翻译、食物网。图分几步（‹ › 翻页，每步一句说明），
 * 讲题卡重画时停在原来那一步。只用 SVG + CSS 变量，昼夜主题自动跟随。
 * 数据来自 Tasks.build(...).result.viz（普通 JSON，可存进本机记录）。
 */
const Viz = (() => {
  const W = 640, H = 360;
  let uid = 0;
  const state = {};
  const E = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const N = (v, d = 4) => !isFinite(v) ? '—' : String(+(+v).toPrecision(d));
  const X = v => (isFinite(v) && Solver.exact(v)) || N(v);
  const nice = r => { const p = 10 ** Math.floor(Math.log10(r || 1)), m = r / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; };
  const PAL = n => `var(--vz${(n % 6) + 1})`;
  const SUB = n => String(n).split('').map(c => '₀₁₂₃₄₅₆₇₈₉'[c]).join(''), SUP = n => String(n).split('').map(c => '⁰¹²³⁴⁵⁶⁷⁸⁹'[c]).join('');
  const txt = (x, y, s, cls = 'vz-label', anchor = 'middle', extra = '') => `<text class="${cls}" x="${x.toFixed(1)}" y="${y.toFixed(1)}" text-anchor="${anchor}" ${extra}>${E(s)}</text>`;
  const dot = (x, y, cls = 'vz-pt', r = 4.5) => `<circle class="${cls}" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${r}"/>`;
  const line = (x1, y1, x2, y2, cls) => `<line class="${cls}" x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"/>`;
  const capOf = (t, i) => t.rows[i] ? `${t.rows[i].prompt}：${t.rows[i].text}` : '';

  /** 外框：标题、当前步说明、翻页；draw(k) 返回第 k 步的 SVG 内容 */
  function frame(host, key, title, stages, draw, opt = {}) {
    const h = opt.h || H;
    host.innerHTML = `<div class="vz"><div class="vz-head"><b>${E(title)}</b><span class="vz-cap"></span>
      <span class="vz-nav"><button type="button" class="vz-b" data-d="-1" aria-label="图解上一步">‹</button><span class="vz-k"></span><button type="button" class="vz-b" data-d="1" aria-label="图解下一步">›</button><button type="button" class="vz-b" data-d="all">全部</button></span></div>
      <svg class="vz-svg" viewBox="0 0 ${W} ${h}" role="img" aria-label="${E(title)}"></svg>${opt.hint ? `<div class="vz-hint">${E(opt.hint)}</div>` : ''}</div>`;
    const svg = host.querySelector('svg'), cap = host.querySelector('.vz-cap'), kk = host.querySelector('.vz-k'), n = stages.length;
    const st = state[key] = state[key] || { k: 0 };
    st.k = Math.min(st.k, n - 1);
    const show = () => {
      svg.innerHTML = draw(st.k);
      cap.textContent = stages[st.k]; kk.textContent = `${st.k + 1} / ${n}`;
      host.querySelector('[data-d="-1"]').disabled = st.k === 0;
      host.querySelector('[data-d="1"]').disabled = host.querySelector('[data-d="all"]').disabled = st.k === n - 1;
    };
    host.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { const d = b.dataset.d; st.k = d === 'all' ? n - 1 : Math.max(0, Math.min(n - 1, st.k + +d)); show(); });
    show();
    return { svg, show, st };
  }

  /** 直角坐标系：返回映射函数和网格、坐标轴、刻度 */
  function plot(x0, x1, y0, y1, o = {}) {
    const L = o.L ?? 46, R = 14, T = 14, B = 26, w = W - L - R, h = (o.h || H) - T - B;
    const sx = x => L + (x - x0) / (x1 - x0) * w, sy = y => T + h - (y - y0) / (y1 - y0) * h;
    const id = 'vzc' + (++uid);
    let g = `<defs><clipPath id="${id}"><rect x="${L}" y="${T}" width="${w}" height="${h}"/></clipPath></defs>`;
    const xs = o.xstep || nice((x1 - x0) / 8), ys = nice((y1 - y0) / 6);
    for (let v = Math.ceil(x0 / xs) * xs; v <= x1 + 1e-9; v += xs) g += line(sx(v), T, sx(v), T + h, 'vz-grid') + (o.noX ? '' : txt(sx(v), T + h + 16, N(v, 3), 'vz-tick'));
    for (let v = Math.ceil(y0 / ys) * ys; v <= y1 + 1e-9; v += ys) g += line(L, sy(v), L + w, sy(v), 'vz-grid') + txt(L - 6, sy(v) + 4, N(v, 3), 'vz-tick', 'end');
    if (x0 <= 0 && x1 >= 0 && !o.noYAxis) g += line(sx(0), T, sx(0), T + h, 'vz-axis');
    if (y0 <= 0 && y1 >= 0) g += line(L, sy(0), L + w, sy(0), 'vz-axis');
    return { sx, sy, g, L, T, w, h, clip: `clip-path="url(#${id})"`, x0, x1, y0, y1 };
  }
  /** 折线：pts 里的 null 表示断开 */
  const pathOf = pts => { let d = '', pen = false; for (const p of pts) { if (!p) { pen = false; continue; } d += (pen ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); pen = true; } return d; };

  /* ================= 数学 ================= */
  function func(host, t, key) {
    const v = t.viz; let f; try { f = Solver.fn(v.f, ['x']); } catch (e) { return false; }
    const d = x => { const h = 1e-5 * Math.max(1, Math.abs(x)); return (f(x + h) - f(x - h)) / (2 * h); };
    let x0, x1;
    if (v.given) { const pad = (v.b - v.a) * 0.06; x0 = v.a - pad; x1 = v.b + pad; }
    else {
      const xs = [...v.zeros, ...v.ext.map(e => e.x), ...v.tang.map(q => q.x0), ...v.ints.flatMap(q => [q.lo, q.hi]), ...v.marks.map(m => m.x), ...v.mm.map(m => m.x)].filter(isFinite);
      if (!xs.length) { x0 = -5; x1 = 5; } else { const lo = Math.min(...xs), hi = Math.max(...xs), span = Math.max(hi - lo, 2); x0 = Math.max(lo - span * 0.5, -20); x1 = Math.min(hi + span * 0.5, 20); }
    }
    const S = 700, smp = []; for (let i = 0; i <= S; i++) { const x = x0 + (x1 - x0) * i / S; smp.push([x, f(x)]); }
    const fin = smp.map(p => p[1]).filter(isFinite).sort((a, b) => a - b);
    let y0 = fin.length ? fin[Math.floor(fin.length * 0.03)] : -1, y1 = fin.length ? fin[Math.max(0, Math.ceil(fin.length * 0.97) - 1)] : 1;
    [...v.ext.map(e => e.y), ...v.mm.map(m => m.y), ...v.marks.map(m => m.y), 0].filter(isFinite).forEach(y => { y0 = Math.min(y0, y); y1 = Math.max(y1, y); });
    if (y1 - y0 < 1e-9) { y0 -= 1; y1 += 1; }
    const pad = (y1 - y0) * 0.14; y0 -= pad; y1 += pad;
    const P = plot(x0, x1, y0, y1), lim = (y1 - y0) * 4;
    const curve = mono => {
      let out = '', run = [], cls = null;
      const flush = () => { if (run.length > 1) out += `<path class="vz-curve ${cls || ''}" d="${pathOf(run)}"/>`; run = []; };
      for (let i = 0; i < smp.length; i++) {
        const [x, y] = smp[i];
        if (!isFinite(y) || y < y0 - lim || y > y1 + lim) { flush(); continue; }
        const c = mono ? (d(x) > 0 ? 'vz-up' : 'vz-down') : '';
        if (c !== cls && run.length) { const last = run[run.length - 1]; flush(); run.push(last); }
        cls = c; run.push([P.sx(x), P.sy(y)]);
      }
      flush(); return out;
    };
    const st = [[`函数图像 y = ${v.f}${v.given ? `，x ∈ [${X(v.a)}, ${X(v.b)}]` : ''}`, 'base']];
    if (v.zeros.length) st.push([`零点：f(x) = 0 的 x 为 ${v.zeros.map(X).join('，')}`, 'zeros']);
    st.push(['单调性：导数 f′(x) > 0 时递增（绿），f′(x) < 0 时递减（红）', 'mono']);
    if (v.ext.length) st.push([`极值：${v.ext.map(e => `${e.t === 'max' ? '极大值' : '极小值'} ${X(e.y)}（x = ${X(e.x)}）`).join('；')}`, 'ext']);
    if (v.mm.length) st.push([v.mm.map(m => `${m.t === 'max' ? '最大值' : '最小值'} ${X(m.y)}（x = ${X(m.x)}）`).join('；') + (v.given ? '：比较极值与区间端点' : ''), 'mm']);
    if (v.tang.length) st.push([v.tang.map(q => `x = ${X(q.x0)} 处切线：斜率 k = f′(${X(q.x0)}) = ${X(q.k)}`).join('；'), 'tang']);
    if (v.ints.length) st.push(['定积分 = 曲线与 x 轴围成的有向面积（x 轴上方为正，下方为负）', 'int']);
    if (v.marks.length) st.push([v.marks.map(m => `f(${X(m.x)}) = ${X(m.y)}`).join('；'), 'marks']);
    const draw = k => {
      const on = new Set(st.slice(0, k + 1).map(s => s[1]));
      let g = P.g + `<g ${P.clip}>`;
      if (on.has('int')) for (const q of v.ints) {
        const n = 160, pts = [];
        for (let i = 0; i <= n; i++) { const x = q.lo + (q.hi - q.lo) * i / n, y = f(x); if (isFinite(y)) pts.push([x, y]); }
        let pos = `M${P.sx(q.lo)} ${P.sy(0)}`; pts.forEach(([x, y]) => { pos += `L${P.sx(x)} ${P.sy(Math.max(0, y))}`; }); pos += `L${P.sx(q.hi)} ${P.sy(0)}Z`;
        let neg = `M${P.sx(q.lo)} ${P.sy(0)}`; pts.forEach(([x, y]) => { neg += `L${P.sx(x)} ${P.sy(Math.min(0, y))}`; }); neg += `L${P.sx(q.hi)} ${P.sy(0)}Z`;
        g += `<path class="vz-area-pos" d="${pos}"/><path class="vz-area-neg" d="${neg}"/>`;
      }
      g += curve(on.has('mono'));
      if (on.has('tang')) for (const q of v.tang) g += line(P.sx(x0), P.sy(q.k * x0 + q.b), P.sx(x1), P.sy(q.k * x1 + q.b), 'vz-hl2');
      g += '</g>';
      if (on.has('zeros')) v.zeros.forEach(z => { g += dot(P.sx(z), P.sy(0), 'vz-pt2') + txt(P.sx(z), P.sy(0) + 18, X(z), 'vz-label vz-s'); });
      if (on.has('ext')) v.ext.forEach(e => { g += line(P.sx(e.x), P.sy(0), P.sx(e.x), P.sy(e.y), 'vz-dash') + dot(P.sx(e.x), P.sy(e.y)) + txt(P.sx(e.x), P.sy(e.y) + (e.t === 'max' ? -10 : 20), `${e.t === 'max' ? '极大' : '极小'} ${X(e.y)}`); });
      if (on.has('mm')) v.mm.forEach(m => { g += `<circle class="vz-ring" cx="${P.sx(m.x)}" cy="${P.sy(m.y)}" r="9"/>` + txt(P.sx(m.x), P.sy(m.y) + (m.t === 'max' ? -16 : 28), `${m.t === 'max' ? '最大' : '最小'} ${X(m.y)}`, 'vz-label vz-strong'); });
      if (on.has('tang')) v.tang.forEach(q => { const y = q.k * q.x0 + q.b; g += dot(P.sx(q.x0), P.sy(y), 'vz-pt2') + txt(P.sx(q.x0) + 8, P.sy(y) - 10, `y = ${X(q.k)}x ${q.b < 0 ? '−' : '+'} ${X(Math.abs(q.b))}`, 'vz-label', 'start'); });
      if (on.has('int')) v.ints.forEach(q => { g += line(P.sx(q.lo), P.T, P.sx(q.lo), P.T + P.h, 'vz-dash') + line(P.sx(q.hi), P.T, P.sx(q.hi), P.T + P.h, 'vz-dash'); });
      if (on.has('marks')) v.marks.forEach(m => { g += dot(P.sx(m.x), P.sy(m.y), 'vz-pt2') + txt(P.sx(m.x), P.sy(m.y) - 10, `(${X(m.x)}, ${X(m.y)})`); });
      return g;
    };
    frame(host, key, '函数图像', st.map(s => s[0]), draw);
  }

  function conic(host, t, key) {
    const v = t.viz, parts = v.curve.split('='); let F;
    try { F = Solver.fn(`(${parts[0]})-(${parts[1]})`, ['x', 'y']); } catch (e) { return false; }
    // 找曲线的大致范围：粗网格上变号的格子
    let bx = [Infinity, -Infinity, Infinity, -Infinity];
    const R0 = 25, n0 = 100, g0 = [];
    for (let j = 0; j <= n0; j++) { g0.push([]); for (let i = 0; i <= n0; i++) g0[j].push(F(-R0 + 2 * R0 * i / n0, -R0 + 2 * R0 * j / n0)); }
    for (let j = 0; j < n0; j++) for (let i = 0; i < n0; i++) {
      const a = g0[j][i], b = g0[j][i + 1], c = g0[j + 1][i];
      if ((a > 0) !== (b > 0) || (a > 0) !== (c > 0)) { const x = -R0 + 2 * R0 * i / n0, y = -R0 + 2 * R0 * j / n0; bx = [Math.min(bx[0], x), Math.max(bx[1], x), Math.min(bx[2], y), Math.max(bx[3], y)]; }
    }
    const pts = [...v.pts, v.O, [0, 0]];
    pts.forEach(p => { bx = [Math.min(bx[0], p[0]), Math.max(bx[1], p[0]), Math.min(bx[2], p[1]), Math.max(bx[3], p[1])]; });
    if (!isFinite(bx[0])) bx = [-5, 5, -5, 5];
    let cx = (bx[0] + bx[1]) / 2, cy = (bx[2] + bx[3]) / 2, sw = Math.max(bx[1] - bx[0], 2) * 1.3, shh = Math.max(bx[3] - bx[2], 2) * 1.3;
    const pw = W - 60, ph = H - 40; // 等比例
    if (sw / pw > shh / ph) shh = sw * ph / pw; else sw = shh * pw / ph;
    const P = plot(cx - sw / 2, cx + sw / 2, cy - shh / 2, cy + shh / 2);
    // 行进方块法画隐函数曲线
    const nx = 180, ny = Math.round(nx * P.h / P.w), gv = [];
    for (let j = 0; j <= ny; j++) { gv.push([]); for (let i = 0; i <= nx; i++) gv[j].push(F(P.x0 + (P.x1 - P.x0) * i / nx, P.y0 + (P.y1 - P.y0) * j / ny)); }
    let cd = '';
    const at = (i, j) => [P.sx(P.x0 + (P.x1 - P.x0) * i / nx), P.sy(P.y0 + (P.y1 - P.y0) * j / ny)];
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      const c = [[i, j], [i + 1, j], [i + 1, j + 1], [i, j + 1]], vs = c.map(([a, b]) => gv[b][a]);
      if (vs.some(z => !isFinite(z))) continue;
      const e = [];
      for (let k = 0; k < 4; k++) {
        const a = vs[k], b = vs[(k + 1) % 4];
        if ((a > 0) !== (b > 0)) { const s = a / (a - b), p1 = at(...c[k]), p2 = at(...c[(k + 1) % 4]); e.push([p1[0] + (p2[0] - p1[0]) * s, p1[1] + (p2[1] - p1[1]) * s]); }
      }
      for (let k = 0; k + 1 < e.length; k += 2) cd += `M${e[k][0].toFixed(1)} ${e[k][1].toFixed(1)}L${e[k + 1][0].toFixed(1)} ${e[k + 1][1].toFixed(1)}`;
    }
    const { A, B, C } = v, onL = x => -(A * x + C) / B;
    const lineSeg = Math.abs(B) > 1e-12 ? [P.sx(P.x0), P.sy(onL(P.x0)), P.sx(P.x1), P.sy(onL(P.x1))] : [P.sx(-C / A), P.T, P.sx(-C / A), P.T + P.h];
    const two = v.pts.length === 2, [a, b] = v.pts, O = v.O, names = ['A', 'B', 'C', 'D'];
    const st = [[`曲线 ${v.curve}`, 'curve'], [`直线 ${v.line}`, 'line'], [v.pts.length ? `联立方程：交点 ${v.pts.map((p, i) => `${names[i] || ''}(${X(p[0])}, ${X(p[1])})`).join('、')}` : '直线与曲线没有交点', 'pts']];
    v.whats.forEach((w, i) => { if (['chord', 'midpoint', 'area', 'distance'].includes(w)) st.push([capOf(t, i), w]); });
    const draw = k => {
      const on = new Set(st.slice(0, k + 1).map(s => s[1]));
      let g = P.g + `<g ${P.clip}><path class="vz-curve" d="${cd}"/>`;
      if (on.has('line')) g += line(...lineSeg, 'vz-hl2');
      if (on.has('area') && two) g += `<path class="vz-plane" d="M${P.sx(O[0])} ${P.sy(O[1])}L${P.sx(a[0])} ${P.sy(a[1])}L${P.sx(b[0])} ${P.sy(b[1])}Z"/>`;
      if ((on.has('chord') || on.has('midpoint') || on.has('area')) && two) g += line(P.sx(a[0]), P.sy(a[1]), P.sx(b[0]), P.sy(b[1]), 'vz-hl1 vz-thick');
      if (on.has('distance')) { const t2 = (A * O[0] + B * O[1] + C) / (A * A + B * B), fx = O[0] - A * t2, fy = O[1] - B * t2; g += line(P.sx(O[0]), P.sy(O[1]), P.sx(fx), P.sy(fy), 'vz-hl3 vz-thick') + dot(P.sx(fx), P.sy(fy), 'vz-pt2', 3.5); }
      g += '</g>';
      if (on.has('pts')) v.pts.forEach((p, i) => { g += dot(P.sx(p[0]), P.sy(p[1])) + txt(P.sx(p[0]) + 8, P.sy(p[1]) - 8, names[i] || '', 'vz-label vz-strong', 'start'); });
      if (on.has('midpoint') && two) { const m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; g += dot(P.sx(m[0]), P.sy(m[1]), 'vz-pt2') + txt(P.sx(m[0]) + 8, P.sy(m[1]) + 16, `M(${X(m[0])}, ${X(m[1])})`, 'vz-label', 'start'); }
      if (on.has('area') || on.has('distance')) g += dot(P.sx(O[0]), P.sy(O[1]), 'vz-pt2', 3.5) + txt(P.sx(O[0]) - 8, P.sy(O[1]) + 16, O[0] === 0 && O[1] === 0 ? 'O' : 'P', 'vz-label', 'end');
      return g;
    };
    frame(host, key, '直线与曲线', st.map(s => s[0]), draw);
  }

  function solid(host, t, key) {
    const v = t.viz, names = Object.keys(v.points), Pt = names.map(n => v.points[n]);
    const sub = (p, q) => [p[0] - q[0], p[1] - q[1], p[2] - q[2]], dotp = (p, q) => p[0] * q[0] + p[1] * q[1] + p[2] * q[2];
    const cross = (p, q) => [p[1] * q[2] - p[2] * q[1], p[2] * q[0] - p[0] * q[2], p[0] * q[1] - p[1] * q[0]], len = p => Math.hypot(...p), scl = (p, s) => p.map(x => x * s), add = (p, q) => p.map((x, i) => x + q[i]);
    const cen = [0, 1, 2].map(i => Pt.reduce((a, p) => a + p[i], 0) / Pt.length), rad = Math.max(...Pt.map(p => len(sub(p, cen))), 1e-9), eps = 1e-6 * rad;
    const P = n => v.points[n];
    // 凸包：每个支撑平面上的点做二维凸包，得到棱；记下每条棱属于哪些面（判断可见性）
    const faces = [], seen = new Set(), edges = new Map();
    const hull2 = (idx, nrm) => {
      const o = Pt[idx[0]], u0 = sub(Pt[idx.find(i => len(sub(Pt[i], o)) > eps)] || Pt[idx[1]], o), u = scl(u0, 1 / (len(u0) || 1)), w = cross(nrm, u);
      const q = idx.map(i => ({ i, x: dotp(sub(Pt[i], o), u), y: dotp(sub(Pt[i], o), w) })).sort((p1, p2) => p1.x - p2.x || p1.y - p2.y);
      const cr = (o2, a2, b2) => (a2.x - o2.x) * (b2.y - o2.y) - (a2.y - o2.y) * (b2.x - o2.x), lo = [], hi = [];
      for (const p of q) { while (lo.length > 1 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= eps * rad) lo.pop(); lo.push(p); }
      for (const p of [...q].reverse()) { while (hi.length > 1 && cr(hi[hi.length - 2], hi[hi.length - 1], p) <= eps * rad) hi.pop(); hi.push(p); }
      return [...lo.slice(0, -1), ...hi.slice(0, -1)].map(p => p.i);
    };
    const n = Pt.length;
    if (n >= 4) for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) for (let k = j + 1; k < n; k++) {
      let nr = cross(sub(Pt[j], Pt[i]), sub(Pt[k], Pt[i])); const L = len(nr); if (L < eps * rad) continue; nr = scl(nr, 1 / L);
      const ds = Pt.map(p => dotp(sub(p, Pt[i]), nr));
      if (!(ds.every(x => x <= eps) || ds.every(x => x >= -eps))) continue;
      if (dotp(sub(cen, Pt[i]), nr) > 0) nr = scl(nr, -1); // 朝外
      const on = ds.map((x, m) => Math.abs(x) <= eps ? m : -1).filter(m => m >= 0), keyF = on.join(',');
      if (seen.has(keyF)) continue; seen.add(keyF);
      const cyc = hull2(on, nr), fi = faces.length; faces.push({ cyc, nr });
      cyc.forEach((a, m) => { const b = cyc[(m + 1) % cyc.length], ek = a < b ? `${a}-${b}` : `${b}-${a}`; if (!edges.has(ek)) edges.set(ek, []); edges.get(ek).push(fi); });
    }
    const S = state[key] = state[key] || { k: 0 }; if (S.yaw == null) { S.yaw = -1.05; S.pitch = 0.38; }
    const scale = Math.min(W, H) * 0.38 / rad;
    const rot = p => { const q = sub(p, cen), c1 = Math.cos(S.yaw), s1 = Math.sin(S.yaw), x = q[0] * c1 - q[1] * s1, y = q[0] * s1 + q[1] * c1, c2 = Math.cos(S.pitch), s2 = Math.sin(S.pitch); return [x, y * c2 - q[2] * s2, y * s2 + q[2] * c2]; };
    const pr = p => { const r = rot(p); return [W / 2 + r[0] * scale, H / 2 + 6 - r[2] * scale]; };
    const front = nr => { const c1 = Math.cos(S.yaw), s1 = Math.sin(S.yaw), y = nr[0] * s1 + nr[1] * c1; return y * Math.cos(S.pitch) - nr[2] * Math.sin(S.pitch) < 0; };
    const seg = (p, q, cls) => { const a = pr(p), b = pr(q); return line(a[0], a[1], b[0], b[1], cls); };
    const poly = (ps, cls) => `<path class="${cls}" d="${ps.map((p, i) => { const s = pr(p); return (i ? 'L' : 'M') + s[0].toFixed(1) + ' ' + s[1].toFixed(1); }).join('')}Z"/>`;
    const planePts = names3 => { // 平面上所有已知点的凸包（看起来就是那个面），不够就用三角形
      const [a, b, c] = names3.map(P); let nr = cross(sub(b, a), sub(c, a)); const L = len(nr); if (L < 1e-12) return names3.map(P); nr = scl(nr, 1 / L);
      const on = Pt.map((p, i) => Math.abs(dotp(sub(p, a), nr)) <= eps ? i : -1).filter(i => i >= 0);
      return on.length > 3 ? hull2(on, nr).map(i => Pt[i]) : names3.map(P);
    };
    const foot = (p, names3) => { const [a, b, c] = names3.map(P), nr = cross(sub(b, a), sub(c, a)), t2 = dotp(sub(p, a), nr) / dotp(nr, nr); return sub(p, scl(nr, t2)); };
    const st = [['立体图形（拖动可以旋转；虚线是被挡住的棱）', null]];
    v.asks.forEach((q, i) => st.push([capOf(t, i), i]));
    const draw = k => {
      let g = '';
      const q = k > 0 ? v.asks[k - 1] : null;
      // 先画高亮的面（在棱下面）
      if (q) {
        if (q.plane) g += poly(planePts(q.plane), 'vz-plane');
        if (q.planes) { g += poly(planePts(q.planes[0]), 'vz-plane'); g += poly(planePts(q.planes[1]), 'vz-plane2'); }
        if (q.edge && q.faces) { g += poly([P(q.edge[0]), P(q.edge[1]), P(q.faces[0])], 'vz-plane'); g += poly([P(q.edge[0]), P(q.edge[1]), P(q.faces[1])], 'vz-plane2'); }
        if (q.what === 'area' && q.points) g += poly(q.points.map(P), 'vz-plane');
        if (q.what === 'volume' && q.points) {
          const ps = q.points.map(P);
          if (ps.length === 4) [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]].forEach(tr => { g += poly(tr.map(m => ps[m]), 'vz-plane'); });
          else { g += poly(ps.slice(1), 'vz-plane2'); for (let m = 1; m < ps.length; m++) g += poly([ps[0], ps[m], ps[m + 1 < ps.length ? m + 1 : 1]], 'vz-plane'); }
        }
      }
      for (const [ek, fs] of edges) { const [a, b] = ek.split('-').map(Number); g += seg(Pt[a], Pt[b], fs.some(fi => front(faces[fi].nr)) ? 'vz-edge' : 'vz-hidden'); }
      if (q) {
        if (q.between) g += seg(P(q.between[0]), P(q.between[1]), 'vz-hl1 vz-thick');
        if (q.lines) { g += seg(P(q.lines[0][0]), P(q.lines[0][1]), 'vz-hl1 vz-thick'); g += seg(P(q.lines[1][0]), P(q.lines[1][1]), 'vz-hl2 vz-thick'); }
        if (q.line && q.plane) {
          // 线段两端各向平面作垂线，垂足连线就是线段在平面内的射影；线面角是线段与射影的夹角
          const [p1, p2] = q.line.map(P), F1 = foot(p1, q.plane), F2 = foot(p2, q.plane);
          g += seg(p1, p2, 'vz-hl1 vz-thick') + seg(F1, F2, 'vz-hl2 vz-thick');
          [[p1, F1], [p2, F2]].forEach(([p, F]) => { if (len(sub(p, F)) > eps) { g += seg(p, F, 'vz-hl3 vz-dash'); const s = pr(F); g += dot(s[0], s[1], 'vz-pt2', 3.5); } });
          const s = pr(len(sub(p1, F1)) > len(sub(p2, F2)) ? F1 : F2); g += txt(s[0] + 7, s[1] + 16, '射影', 'vz-label vz-s', 'start');
        }
        if (q.edge && q.faces) {
          const [e0, e1] = q.edge.map(P), ue = sub(e1, e0), u = scl(ue, 1 / len(ue)), R = P(q.faces[0]), Sx = P(q.faces[1]);
          const F = add(e0, scl(u, dotp(sub(R, e0), u))), r1 = sub(R, F), w0 = sub(sub(Sx, e0), scl(u, dotp(sub(Sx, e0), u))), G = add(F, scl(w0, len(r1) / (len(w0) || 1)));
          g += seg(e0, e1, 'vz-hl3 vz-thick') + seg(F, R, 'vz-hl1 vz-thick') + seg(F, G, 'vz-hl2 vz-thick');
          const s = pr(F); g += dot(s[0], s[1], 'vz-pt2', 3.5) + txt(s[0] + 7, s[1] + 14, '二面角的平面角', 'vz-label vz-s', 'start');
        }
        if (q.what === 'distance_point_plane' && q.point && q.plane) { const p = P(q.point), F = foot(p, q.plane); g += seg(p, F, 'vz-hl1 vz-thick'); const s = pr(F); g += dot(s[0], s[1], 'vz-pt2', 3.5); }
      }
      // 点名：向外偏一点
      const c2 = pr(cen);
      names.forEach(nm => { const s = pr(P(nm)), dx = s[0] - c2[0], dy = s[1] - c2[1], L = Math.hypot(dx, dy) || 1; g += dot(s[0], s[1], 'vz-pt', 3) + txt(s[0] + dx / L * 14, s[1] + dy / L * 14 + 4, nm.replace(/(\D)(\d+)$/, (m, a, d) => a + SUB(d)), 'vz-label vz-strong'); });
      return g;
    };
    const F = frame(host, key, '立体图形', st.map(s => s[0]), draw, { hint: '按住拖动旋转视角' });
    let drag = null;
    F.svg.style.touchAction = 'none'; F.svg.style.cursor = 'grab';
    F.svg.onpointerdown = e => { drag = [e.clientX, e.clientY, S.yaw, S.pitch]; F.svg.setPointerCapture(e.pointerId); F.svg.style.cursor = 'grabbing'; };
    F.svg.onpointermove = e => { if (!drag) return; S.yaw = drag[2] - (e.clientX - drag[0]) * 0.01; S.pitch = Math.max(-1.45, Math.min(1.45, drag[3] + (e.clientY - drag[1]) * 0.01)); F.svg.innerHTML = draw(S.k); };
    F.svg.onpointerup = F.svg.onpointercancel = () => { drag = null; F.svg.style.cursor = 'grab'; };
  }

  function prob(host, t, key) {
    const v = t.viz, inEv = (x, e) => (e.lo == null || x > e.lo + 1e-9 || (e.loIn && Math.abs(x - e.lo) < 1e-9)) && (e.hi == null || x < e.hi - 1e-9 || (e.hiIn && Math.abs(x - e.hi) < 1e-9));
    const st = [[v.disc ? `${v.name}：分布列（柱高 = 概率）` : `${v.name}：密度曲线（面积 = 概率）`, null]];
    v.whats.forEach((w, i) => { if (w !== 'pmf') st.push([capOf(t, i), i]); });
    let P, base;
    const phi = x => Math.exp(-((x - v.mu) ** 2) / (2 * v.sigma ** 2)) / (v.sigma * Math.sqrt(2 * Math.PI));
    if (v.disc) {
      const x0 = Math.min(...v.xs) - 0.8, x1 = Math.max(...v.xs) + 0.8, top = Math.max(...v.ps) * 1.2 || 1;
      P = plot(x0, x1, 0, top, { xstep: Math.max(1, nice((x1 - x0) / 14)) });
      base = P.g;
    } else {
      const x0 = v.mu - 4 * v.sigma, x1 = v.mu + 4 * v.sigma;
      P = plot(x0, x1, 0, phi(v.mu) * 1.18, { noYAxis: true });
      const pts = []; for (let i = 0; i <= 300; i++) { const x = x0 + (x1 - x0) * i / 300; pts.push([P.sx(x), P.sy(phi(x))]); }
      base = P.g + `<path class="vz-curve" d="${pathOf(pts)}"/>`;
    }
    const draw = k => {
      const i = st[k][1], w = i == null ? null : v.whats[i], ev = i == null ? null : v.evs[i];
      let g = base;
      if (v.disc) {
        const bw = Math.min(0.7, 0.8) * (P.sx(1) - P.sx(0));
        v.xs.forEach((x, j) => {
          const hl = ev && inEv(x, ev);
          g += `<rect class="${hl ? 'vz-bar-hl' : 'vz-bar'}" x="${(P.sx(x) - bw / 2).toFixed(1)}" y="${P.sy(v.ps[j]).toFixed(1)}" width="${bw.toFixed(1)}" height="${(P.sy(0) - P.sy(v.ps[j])).toFixed(1)}"/>`;
          if (v.xs.length <= 16) g += txt(P.sx(x), P.sy(v.ps[j]) - 5, N(v.ps[j], 3), 'vz-tick');
        });
      } else if (ev) {
        const lo = Math.max(ev.lo ?? -Infinity, P.x0), hi = Math.min(ev.hi ?? Infinity, P.x1), pts = [[P.sx(lo), P.sy(0)]];
        for (let m = 0; m <= 120; m++) { const x = lo + (hi - lo) * m / 120; pts.push([P.sx(x), P.sy(phi(x))]); }
        pts.push([P.sx(hi), P.sy(0)]);
        g += `<path class="vz-area-pos" d="${pathOf(pts)}Z"/>`;
      }
      if (w === 'E' || w === 'D') { g += line(P.sx(v.E), P.T, P.sx(v.E), P.T + P.h, 'vz-hl2') + txt(P.sx(v.E) + 6, P.T + 14, `E = ${X(v.E)}`, 'vz-label', 'start'); }
      if (w === 'D') { const s = Math.sqrt(v.V), y = P.T + P.h - 10; g += line(P.sx(v.E - s), y, P.sx(v.E + s), y, 'vz-hl1 vz-thick') + line(P.sx(v.E - s), y - 6, P.sx(v.E - s), y + 6, 'vz-hl1') + line(P.sx(v.E + s), y - 6, P.sx(v.E + s), y + 6, 'vz-hl1') + txt(P.sx(v.E + s) + 8, y + 4, `E ± σ，σ = √D = ${X(s)}`, 'vz-label vz-s', 'start'); }
      return g;
    };
    frame(host, key, '概率分布', st.map(s => s[0]), draw);
  }

  function seq(host, t, key) {
    const v = t.viz, n = Math.min(v.a.length, Math.max(8, ...v.terms.filter(m => m <= 30), ...v.sums.filter(m => m <= 30)) + 2); // 只画到所问的项附近，指数增长时前面的项才看得清
    const draw2 = (all, hl) => {
      const arr = all.slice(0, n);
      const fin = arr.filter(isFinite); let y0 = Math.min(0, ...fin), y1 = Math.max(0, ...fin); if (y1 - y0 < 1e-9) y1 += 1; const pd = (y1 - y0) * 0.1;
      const P = plot(0.3, n + 0.7, y0 - pd, y1 + pd, { xstep: Math.max(1, nice(n / 12)) });
      let g = P.g + `<path class="vz-curve vz-faint" d="${pathOf(arr.map((y, i) => isFinite(y) ? [P.sx(i + 1), P.sy(y)] : null))}"/>`;
      arr.forEach((y, i) => { if (isFinite(y)) g += dot(P.sx(i + 1), P.sy(y), hl.includes(i + 1) ? 'vz-pt2' : 'vz-pt', hl.includes(i + 1) ? 6 : 3.5); });
      hl.filter(m => m <= n).forEach(m => { g += txt(P.sx(m), P.sy(arr[m - 1]) - 12, N(arr[m - 1], 6), 'vz-label vz-strong'); });
      return g;
    };
    const st = [[`数列的前 ${n} 项（横轴 n，纵轴 aₙ）`, 'a']];
    if (v.terms.length) st.push([`所求的项：${v.terms.map(m => `a${SUB(m)}`).join('、')}${v.terms.some(m => m > n) ? '（超出图中范围的项见上表）' : ''}`, 'term']);
    st.push([`前 n 项和 Sₙ`, 'S']);
    const draw = k => st[k][1] === 'S' ? draw2(v.S, v.sums) : draw2(v.a, st[k][1] === 'term' ? v.terms : []);
    frame(host, key, '数列', st.map(s => s[0]), draw);
  }

  /* ================= 化学 ================= */
  function reaction(host, t, key) {
    const v = t.viz, sp = v.sp;
    let parsed; try { parsed = sp.map(x => x.f === 'e^-' ? { el: {}, charge: -1 } : parseFormula(x.f)); } catch (e) { return false; }
    const els = [...new Set(parsed.flatMap(p => Object.keys(p.el)))], hasQ = parsed.some(p => p.charge);
    const count = (side, k) => sp.reduce((a, x, i) => a + (x.side === side ? x.coef * (k === 'q' ? parsed[i].charge : (parsed[i].el[k] || 0)) : 0), 0);
    const eqText = [0, 1].map(s => sp.filter(x => x.side === s).map(x => (x.coef === 1 ? '' : N(x.coef)) + x.label).join(' + ')).join('  ⟶  ');
    const st = [['配平：方程式两边每种原子（离子方程式还有电荷）的数目相等', 'atoms']];
    if (v.xi != null) st.push([`物质的量之比 = 化学计量数之比；反应进度 ξ = ${X(v.xi)} mol${v.limit != null ? `（按不足量 ${sp[v.limit].label} 计算）` : ''}`, 'mol']);
    const draw = k => {
      let g = txt(W / 2, 30, eqText, 'vz-title');
      if (st[k][1] === 'atoms') {
        // 分子「小球」：每个系数一个
        const all = sp.map((x, i) => ({ ...x, i })), slot = (W - 40) / all.length;
        all.forEach((x, m) => {
          const cx = 20 + slot * (m + 0.5), cnt = Math.round(x.coef), shown = Math.min(cnt, 12);
          for (let j = 0; j < shown; j++) g += `<circle class="vz-mol" style="fill:${PAL(m)}" cx="${(cx - (Math.min(shown, 6) - 1) * 7 + (j % 6) * 14).toFixed(1)}" cy="${(64 + Math.floor(j / 6) * 14).toFixed(1)}" r="5.5"/>`;
          g += txt(cx, 104, `${cnt > 12 ? cnt + '×' : ''}${x.label}`, 'vz-label vz-s');
        });
        const rows = [...els, ...(hasQ ? ['q'] : [])], top = 126, rh = Math.min(24, (H - top - 10) / (rows.length + 1));
        g += txt(170, top, '原子', 'vz-th') + txt(330, top, '左边', 'vz-th') + txt(450, top, '右边', 'vz-th');
        rows.forEach((e, r) => {
          const y = top + rh * (r + 1), l = count(0, e), rr = count(1, e), ok = Math.abs(l - rr) < 1e-9;
          g += line(110, y - rh + 7, 530, y - rh + 7, 'vz-grid') + txt(170, y, e === 'q' ? '电荷' : e, 'vz-label vz-strong') + txt(330, y, N(l), 'vz-label') + txt(450, y, N(rr), 'vz-label') + txt(510, y, ok ? '✓' : '✗', ok ? 'vz-ok' : 'vz-bad');
        });
        return g;
      }
      // 物质的量条形图
      const given = new Map(v.given.map(q => [q.i, q.n])), amt = sp.map((x, i) => ({ used: x.coef * v.xi * (x.side === 1 ? v.Y : 1), had: given.get(i) }));
      const max = Math.max(...amt.map(a => Math.max(a.used, a.had || 0)), 1e-12), top = 56, rh = Math.min(40, (H - top - 20) / sp.length), x0 = 170, bw = W - x0 - 120;
      sp.forEach((x, i) => {
        const y = top + rh * i, a = amt[i];
        g += txt(x0 - 10, y + rh / 2 + 4, `${x.side ? '生成' : '反应'} ${x.label}`, 'vz-label', 'end');
        if (a.had != null && x.side === 0) g += `<rect class="vz-bar" x="${x0}" y="${(y + 4).toFixed(1)}" width="${(bw * a.had / max).toFixed(1)}" height="${(rh - 10).toFixed(1)}"/>`;
        g += `<rect class="${x.side ? 'vz-bar-hl' : 'vz-bar-use'}" x="${x0}" y="${(y + 4 + (a.had != null && !x.side ? (rh - 10) * 0.3 : 0)).toFixed(1)}" width="${(bw * a.used / max).toFixed(1)}" height="${((rh - 10) * (a.had != null && !x.side ? 0.4 : 1)).toFixed(1)}"/>`;
        g += txt(x0 + bw * Math.max(a.used, a.had || 0) / max + 8, y + rh / 2 + 4, `${N(a.used)} mol${a.had != null && !x.side ? ` / 给了 ${N(a.had)}` : ''}${v.limit === i ? '（不足量）' : ''}`, 'vz-label vz-s', 'start');
      });
      return g + txt(x0, H - 6, '灰色：题目给的量　深色：参加反应 / 生成的量', 'vz-tick', 'start');
    };
    frame(host, key, '化学方程式', st.map(s => s[0]), draw);
  }

  function solution(host, t, key) {
    const v = t.viz, weak = v.comps.find(c => c.Ka && c.Ka.length);
    const st = [[`pH = ${N(v.pH, 4)}：${v.pH < 6.9 ? '酸性' : v.pH > 7.1 ? '碱性' : '近中性'}（常温下 pH = 7 为中性）`, 'scale']];
    const isBase = c => /base/.test(c.type);
    const formName = (c, j) => { const n = c.Ka.length, h = n - j; return isBase(c) ? `B${h ? 'H' + (h > 1 ? SUB(h) : '') + (h > 1 ? SUP(h) : '') + '⁺' : ''}` : `${h ? 'H' + (h > 1 ? SUB(h) : '') : ''}A${j ? (j > 1 ? SUP(j) : '') + '⁻' : ''}`; };
    const alphas = (Ka, pH) => { const Hc = 10 ** -pH, tt = [1]; for (let j = 0; j < Ka.length; j++) tt.push(tt[j] * Ka[j] / Hc); const s = tt.reduce((a, b) => a + b, 0); return tt.map(x => x / s); };
    if (weak) st.push([`${weak.name} 各形态的分布：在 pH = ${N(v.pH, 3)} 处，${alphas(weak.Ka, v.pH).map((a, j) => `${formName(weak, j)} 占 ${a < 1e-4 ? '不到 0.01' : N(a * 100, 3)}%`).join('，')}`, 'dist']);
    const draw = k => {
      if (st[k][1] === 'scale') {
        const id = 'vzg' + (++uid), x0 = 50, x1 = W - 50, y = 150, sx = p => x0 + (x1 - x0) * p / 14;
        let g = `<defs><linearGradient id="${id}" x1="0" x2="1"><stop offset="0" stop-color="#d7263d"/><stop offset=".25" stop-color="#f49d37"/><stop offset=".45" stop-color="#e8d33f"/><stop offset=".55" stop-color="#5fb75f"/><stop offset=".75" stop-color="#2e86ab"/><stop offset="1" stop-color="#6a4c93"/></linearGradient></defs>`;
        g += `<rect x="${x0}" y="${y}" width="${x1 - x0}" height="34" rx="6" fill="url(#${id})"/>`;
        for (let p = 0; p <= 14; p++) g += line(sx(p), y + 34, sx(p), y + 40, 'vz-axis') + txt(sx(p), y + 54, String(p), 'vz-tick');
        g += txt(sx(3), y - 14, '酸性', 'vz-label') + txt(sx(7), y - 14, '中性', 'vz-label') + txt(sx(11), y - 14, '碱性', 'vz-label');
        const px = sx(Math.max(0, Math.min(14, v.pH)));
        g += `<path class="vz-marker" d="M${px} ${y - 2}l-8 -14h16z"/>` + txt(px, y + 80, `pH = ${N(v.pH, 4)}`, 'vz-title');
        g += txt(W / 2, y + 112, `c(H⁺) = ${N(10 ** -v.pH, 3)} mol/L　c(OH⁻) = ${N(v.Kw / 10 ** -v.pH, 3)} mol/L`, 'vz-label vz-s');
        g += txt(W / 2, 40, v.comps.map(c => `${c.name} ${N(c.C, 3)} mol/L`).join('　'), 'vz-label');
        return g;
      }
      const P = plot(0, 14, 0, 1.05, { xstep: 1 });
      let g = P.g + txt(P.L + P.w - 4, P.T + P.h - 6, 'pH →', 'vz-tick', 'end');
      const n = weak.Ka.length + 1;
      for (let j = 0; j < n; j++) {
        const pts = []; for (let m = 0; m <= 280; m++) { const pH = 14 * m / 280; pts.push([P.sx(pH), P.sy(alphas(weak.Ka, pH)[j])]); }
        g += `<path class="vz-curve" style="stroke:${PAL(j)}" d="${pathOf(pts)}"/>`;
        const peak = j === 0 ? 1 : j === n - 1 ? 13 : -Math.log10(Math.sqrt(weak.Ka[j - 1] * weak.Ka[j]));
        g += txt(P.sx(Math.max(0.6, Math.min(13.4, peak))), P.sy(alphas(weak.Ka, peak)[j]) - 8, formName(weak, j), 'vz-label vz-strong', 'middle', `style="fill:${PAL(j)}"`);
      }
      const right = v.pH < 10;
      g += line(P.sx(v.pH), P.T, P.sx(v.pH), P.T + P.h, 'vz-hl2') + txt(P.sx(v.pH) + (right ? 6 : -6), P.sy(0.5), `pH = ${N(v.pH, 3)}`, 'vz-label vz-strong', right ? 'start' : 'end');
      return g;
    };
    frame(host, key, '溶液 pH', st.map(s => s[0]), draw);
  }

  function equilibrium(host, t, key) {
    const v = t.viz, n = v.sp.length;
    const st = [['三段式：起始量、转化量（与化学计量数成正比）、平衡量', 'table'], ['起始与平衡时各物质的物质的量', 'bars']];
    const kExpr = () => {
      const c = i => `c(${v.sp[i]})${Math.abs(v.nu[i]) !== 1 ? SUP(Math.abs(v.nu[i])) : ''}`;
      const num = v.sp.map((s, i) => v.nu[i] > 0 && v.inK[i] ? c(i) : null).filter(Boolean).join('·'), den = v.sp.map((s, i) => v.nu[i] < 0 && v.inK[i] ? c(i) : null).filter(Boolean).join('·');
      return `K = ${num || '1'} / ${den ? `(${den})` : '1'} = ${N(v.K, 4)}`;
    };
    st.push([`平衡常数：${kExpr()}（浓度 = 物质的量 / ${N(v.V)} L）`, 'K']);
    const draw = k => {
      const which = st[k][1];
      if (which === 'table' || which === 'K') {
        const x0 = 140, cw = Math.min(110, (W - x0 - 20) / n), rowsT = [['起始 / mol', v.n0], ['转化 / mol', v.nu.map(u => Math.abs(u * v.xi))], ['平衡 / mol', v.ne]];
        if (v.V !== 1) rowsT.push([`平衡 / (mol/L)`, v.ne.map(x => x / v.V)]);
        let g = '';
        v.sp.forEach((s, i) => { g += txt(x0 + cw * (i + 0.5), 46, s, 'vz-th'); });
        rowsT.forEach(([lab, arr], r) => {
          const y = 80 + r * 34;
          g += line(30, y - 22, x0 + cw * n, y - 22, 'vz-grid') + txt(x0 - 12, y, lab, 'vz-label', 'end');
          arr.forEach((x, i) => { g += txt(x0 + cw * (i + 0.5), y, (r === 1 ? (v.nu[i] < 0 ? '−' : '+') : '') + N(x), r === 2 ? 'vz-label vz-strong' : 'vz-label'); });
        });
        if (which === 'K') g += txt(W / 2, 80 + rowsT.length * 34 + 40, kExpr(), 'vz-title');
        else g += txt(W / 2, 80 + rowsT.length * 34 + 30, `反应进度 ξ = ${N(v.xi)} mol：反应物减少 ν·ξ，生成物增加 ν·ξ`, 'vz-label vz-s');
        return g;
      }
      const max = Math.max(...v.n0, ...v.ne, 1e-12), P = plot(-0.5, n - 0.5, 0, max * 1.2, { noX: true, xstep: 1 });
      let g = P.g; const bw = (P.sx(1) - P.sx(0)) * 0.32;
      v.sp.forEach((s, i) => {
        g += `<rect class="vz-bar" x="${(P.sx(i) - bw - 2).toFixed(1)}" y="${P.sy(v.n0[i]).toFixed(1)}" width="${bw.toFixed(1)}" height="${(P.sy(0) - P.sy(v.n0[i])).toFixed(1)}"/>`;
        g += `<rect class="vz-bar-hl" x="${(P.sx(i) + 2).toFixed(1)}" y="${P.sy(v.ne[i]).toFixed(1)}" width="${bw.toFixed(1)}" height="${(P.sy(0) - P.sy(v.ne[i])).toFixed(1)}"/>`;
        g += txt(P.sx(i), P.T + P.h + 18, s, 'vz-label') + txt(P.sx(i) + 2 + bw / 2, P.sy(v.ne[i]) - 5, N(v.ne[i], 3), 'vz-tick');
      });
      return g + txt(W - 20, 26, '浅色：起始　深色：平衡', 'vz-tick', 'end');
    };
    frame(host, key, '化学平衡', st.map(s => s[0]), draw);
  }

  /* ================= 生物 ================= */
  function cross(host, t, key) {
    const v = t.viz, phIdx = new Map(v.pheno.map((p, i) => [p[0], i]));
    const st = [[`亲本 ${v.momName} × ${v.dadName}：各自产生的配子（等位基因分离、非等位基因自由组合）`, 'gam']];
    if (v.grid) st.push(['棋盘法：雌雄配子随机结合，每格概率相等；颜色表示表型', 'grid']);
    t.rows.forEach((r, i) => { if (v.hits && v.hits[i]) st.push([capOf(t, i), 'hit' + i]); });
    st.push([v.multi ? '经选择 / 再交配后的表型分布' : `子代表型分布：${v.pheno.map(p => p[0]).join('、')}`, 'ph']);
    const chips = (list, y, title) => {
      let g = txt(30, y - 12, title, 'vz-label vz-strong', 'start'); const cw = Math.min(110, (W - 60) / list.length);
      list.forEach((q, i) => { const x = 30 + cw * i; g += `<rect class="vz-chip" x="${x}" y="${y}" width="${cw - 8}" height="40" rx="8"/>` + txt(x + (cw - 8) / 2, y + 18, q.a, 'vz-label vz-strong') + txt(x + (cw - 8) / 2, y + 33, (Solver.rational(q.p, 512, 1e-9) || [0, 0]).join('/'), 'vz-tick'); });
      return g;
    };
    const draw = k => {
      const which = st[k][1];
      if (which === 'gam') return chips(v.mom, 70, `♀ ${v.momName}${v.hasX ? '' : '（亲本 1）'} 的配子`) + chips(v.dad, 200, `♂ ${v.dadName}${v.hasX ? '' : '（亲本 2）'} 的配子`);
      if (which === 'ph') {
        const tot = v.pheno.reduce((a, p) => a + p[1], 0), max = Math.max(...v.pheno.map(p => p[1])), top = 40, rh = Math.min(42, (H - top - 20) / v.pheno.length), x0 = 150, bw = W - x0 - 130;
        let g = '';
        v.pheno.forEach(([lab, p], i) => { const y = top + rh * i; g += txt(x0 - 10, y + rh / 2 + 4, lab, 'vz-label vz-strong', 'end') + `<rect x="${x0}" y="${(y + 4).toFixed(1)}" width="${(bw * p / max).toFixed(1)}" height="${(rh - 10).toFixed(1)}" rx="4" style="fill:${PAL(i)}"/>` + txt(x0 + bw * p / max + 8, y + rh / 2 + 4, (Solver.rational(p / tot, 5000, 1e-9) || []).join('/') || N(p, 3), 'vz-label', 'start'); });
        return g;
      }
      const R = v.grid.length, Cn = v.grid[0].length, x0 = 110, y0 = 54, cw = (W - x0 - 14) / Cn, ch = Math.min(46, (H - y0 - 8) / R), fs = Math.min(14, cw / 5.5);
      const hit = which.startsWith('hit') ? v.hits[+which.slice(3)] : null;
      let g = txt(x0 - 10, y0 - 30, '♀ \\ ♂', 'vz-tick', 'end');
      v.dad.forEach((q, j) => { g += txt(x0 + cw * (j + 0.5), y0 - 12, q.a, 'vz-th'); });
      v.mom.forEach((q, i) => { g += txt(x0 - 10, y0 + ch * (i + 0.5) + 4, q.a, 'vz-th', 'end'); });
      v.grid.forEach((row, i) => row.forEach((c, j) => {
        const h = hit ? hit[i * Cn + j] : null, x = x0 + cw * j, y = y0 + ch * i;
        g += `<rect class="vz-cell${c.dead ? ' vz-dead' : ''}${h === 2 ? ' vz-hit' : h === 1 ? ' vz-given' : hit ? ' vz-dim' : ''}" x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${(cw - 2).toFixed(1)}" height="${(ch - 2).toFixed(1)}" rx="3" style="${c.dead ? '' : `fill:${PAL(phIdx.get(c.ph) ?? 0)}`}"/>`;
        g += txt(x + cw / 2 - 1, y + ch / 2 + fs / 3, c.dead ? `${c.g} ✕` : c.g, 'vz-cell-t', 'middle', `style="font-size:${fs.toFixed(1)}px"`);
      }));
      return g;
    };
    frame(host, key, '遗传图解', st.map(s => s[0]), draw);
  }

  function dna(host, t, key) {
    const v = t.viz, max = 24;
    let off = 0; const len = v.seq.length;
    if (len > max) off = Math.max(0, Math.min(len - max, (v.start >= 0 ? v.start : 0) - 3));
    const win = s => s.slice(off, off + max), cut = len > max;
    const isRNA = v.strand === 'mrna';
    const st = [];
    if (!isRNA) st.push([`DNA 双链：A 与 T、G 与 C 互补配对（A–T 两个氢键，G≡C 三个）${cut ? `，显示第 ${off + 1}–${Math.min(len, off + max)} 个碱基` : ''}`, 'dna']);
    st.push([isRNA ? 'mRNA 序列' : `转录：以${v.strand === 'template' ? '这条模板链' : '另一条（模板）链'}为模板，按 A–U、T–A、G–C、C–G 配对合成 mRNA`, 'rna']);
    st.push([v.start < 0 ? '翻译：没有找到起始密码子 AUG' : `翻译：从第一个 AUG 开始每 3 个碱基一个密码子，到终止密码子为止，共 ${v.aa.length} 个氨基酸`, 'aa']);
    const bw = (W - 60) / max, x0 = 30;
    const row = (s, y, label) => { let g = txt(x0 - 6, y + 17, label, 'vz-tick', 'end'); [...win(s)].forEach((b, i) => { g += `<rect class="vz-b${b}" x="${(x0 + bw * i + 1).toFixed(1)}" y="${y}" width="${(bw - 2).toFixed(1)}" height="26" rx="4"/>` + txt(x0 + bw * (i + 0.5), y + 18, b, 'vz-base'); }); return g; };
    const draw = k => {
      const on = new Set(st.slice(0, k + 1).map(s => s[1]));
      let g = '';
      const coding = v.strand === 'coding' ? v.seq : v.strand === 'template' ? v.comp : null, templ = v.strand === 'template' ? v.seq : v.strand === 'coding' ? v.comp : null;
      if (!isRNA && on.has('dna')) {
        g += row(coding, 40, '编码链') + row(templ, 104, '模板链');
        [...win(coding)].forEach((b, i) => { const n2 = 'GC'.includes(b) ? 3 : 2, cx = x0 + bw * (i + 0.5); for (let m = 0; m < n2; m++) g += line(cx - (n2 - 1) * 2.5 + m * 5, 68, cx - (n2 - 1) * 2.5 + m * 5, 102, 'vz-hbond'); });
      }
      const yR = isRNA ? 60 : 180;
      if (on.has('rna')) { g += row(v.mrna, yR, 'mRNA'); if (!isRNA) g += txt(W / 2, yR - 10, '↓ 转录（与模板链互补，T 换成 U）', 'vz-tick'); }
      if (on.has('aa') && v.start >= 0) {
        const yA = yR + 54; let m = 0;
        for (let p = v.start; p + 3 <= v.mrna.length && m <= v.aa.length; p += 3, m++) {
          const a = p - off, b2 = a + 3; if (b2 <= 0 || a >= max) continue;
          const xa = x0 + bw * Math.max(a, 0) + 2, xb = x0 + bw * Math.min(b2, max) - 2, stop = m === v.aa.length;
          if (stop && !v.stop) break;
          g += `<path class="vz-codon" d="M${xa} ${yR + 30}v6H${xb}v-6"/>`;
          g += `<rect class="${stop ? 'vz-stop' : 'vz-aa'}" x="${xa}" y="${yA}" width="${(xb - xa).toFixed(1)}" height="30" rx="15"/>` + txt((xa + xb) / 2, yA + 19, stop ? '终止' : (typeof AA !== 'undefined' ? AA[v.aa[m]] : v.aa[m]), 'vz-label vz-s');
        }
      }
      return g;
    };
    frame(host, key, '碱基与中心法则', st.map(s => s[0]), draw);
  }

  function foodweb(host, t, key) {
    const v = t.viz, L = v.links, nodes = [...new Set([...Object.keys(L), ...Object.values(L).flatMap(d => Object.keys(d))])];
    const lv = {}, level = (x, seen = []) => { if (lv[x] != null) return lv[x]; if (!L[x] || seen.includes(x)) return (lv[x] = 0); return (lv[x] = 1 + Math.max(...Object.keys(L[x]).map(p => level(p, [...seen, x])))); };
    nodes.forEach(x => level(x));
    const top = Math.max(...nodes.map(x => lv[x]), 1), byL = {};
    nodes.forEach(x => (byL[lv[x]] = byL[lv[x]] || []).push(x));
    // 每层只有一个物种时左右交错，免得跨级的箭头（鼠 → 鹰）和逐级的箭头叠在同一条竖线上
    const pos = {}; Object.entries(byL).forEach(([l, xs]) => xs.forEach((x, i) => { pos[x] = [xs.length === 1 ? W / 2 + (l % 2 ? 90 : -90) : W * (i + 1) / (xs.length + 1), H - 40 - (H - 90) * l / top]; }));
    const id = 'vza' + (++uid);
    const st = [['食物网：箭头表示能量流动的方向（被捕食者 → 捕食者），每传一级只有 ' + v.eff.map(e => N(e * 100) + '%').join('～') + ' 传下去', null]];
    v.flows.forEach((f, i) => st.push([capOf(t, i), i]));
    const draw = k => {
      const f = st[k][1] == null ? null : v.flows[st[k][1]], used = f ? new Set(f.used.map(e => e.join('>'))) : null;
      let g = `<defs><marker id="${id}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="4.5" markerHeight="4.5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" class="vz-arrowhead"/></marker></defs>`;
      // 箭头从节点框的边缘出发、停在下一个框的边缘
      const edgePt = (c, u) => { const kx = 34 / Math.abs(u[0] || 1e-9), ky = 18 / Math.abs(u[1] || 1e-9), k2 = Math.min(kx, ky); return [c[0] + u[0] * k2, c[1] + u[1] * k2]; };
      for (const [pred, d] of Object.entries(L)) for (const [prey, sh] of Object.entries(d)) {
        const a = pos[prey], b = pos[pred], dx = b[0] - a[0], dy = b[1] - a[1], ln = Math.hypot(dx, dy) || 1, u = [dx / ln, dy / ln];
        const on = used && used.has(prey + '>' + pred), p1 = edgePt(a, u), p2 = edgePt(b, [-u[0], -u[1]]);
        g += `<line class="${on ? 'vz-flow-on' : used ? 'vz-flow-off' : 'vz-flow'}" x1="${p1[0].toFixed(1)}" y1="${p1[1].toFixed(1)}" x2="${p2[0].toFixed(1)}" y2="${p2[1].toFixed(1)}" marker-end="url(#${id})"/>`;
        const share = Number(sh), mx = (a[0] + b[0]) / 2 - u[1] * 12, my = (a[1] + b[1]) / 2 + u[0] * 12;
        if (Object.keys(d).length > 1 && isFinite(share) && share !== 1) g += txt(mx, my + 4, N(share * 100, 3) + '%', 'vz-tick');
      }
      nodes.forEach(x => {
        const [cx, cy] = pos[x], need = f && f.need[x];
        g += `<rect class="${!L[x] ? 'vz-node-p' : 'vz-node'}${f && need == null ? ' vz-dim' : ''}" x="${cx - 32}" y="${cy - 16}" width="64" height="32" rx="10"/>` + txt(cx, cy + 5, x, 'vz-label vz-strong');
        if (need != null) g += `<rect class="vz-chip" x="${cx + 38}" y="${cy - 11}" width="${12 + 7 * N(need, 4).length}" height="22" rx="6"/>` + txt(cx + 44, cy + 5, N(need, 4), 'vz-label vz-s vz-strong', 'start');
      });
      return g;
    };
    frame(host, key, '能量流动', st.map(s => s[0]), draw);
  }

  const R = { func, conic, solid, prob, seq, reaction, solution, equilibrium, cross, dna, foodweb };
  /** 把题型求解结果 t 画进 host；key 用来记住翻到第几步、立体图的视角 */
  function mount(host, t, key) {
    if (!t || !t.viz || !R[t.kind]) { host.remove(); return; }
    try { if (R[t.kind](host, t, key) === false) host.remove(); }
    catch (e) { host.innerHTML = `<div class="note">图解出错：${E(e.message)}</div>`; console.warn('[Viz]', e); }
  }
  return { mount, state, kinds: Object.keys(R) };
})();
