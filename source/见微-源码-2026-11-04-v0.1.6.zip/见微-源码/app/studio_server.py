"""见微 · 习题台 / 格物实验台宿主：本地静态服务 + 题目分析转发。"""
from __future__ import annotations

import ctypes
import functools
import http.server
import json
import os
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import quote

import store

EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

# 格物实验台的画板、导入记录都存在 localStorage 里，按「源」隔离：端口一变就像换了台电脑。
# 所以服务优先固定在这个端口，被占用才退回随机端口。
PREFERRED_PORT = 27631
LAB_PAGE = "gewu/index.html"


class _Quiet(http.server.SimpleHTTPRequestHandler):
    """静态文件 + 格物实验台的两个接口（/gewu/api/health、/gewu/api/chat）。"""

    def log_message(self, *_a):  # 安静运行，不弹控制台
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def _json(self, code: int, obj: dict) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _same_origin(self) -> bool:
        # 别的网页不能借本机服务调用你的 DeepSeek 密钥：带了 Origin 就必须是本服务自己
        origin = self.headers.get("Origin")
        if not origin:
            return True
        port = self.server.server_address[1]
        return origin in (f"http://127.0.0.1:{port}", f"http://localhost:{port}")

    def do_GET(self):
        if self.path.startswith("/gewu/api/health"):
            ds = store.deepseek_settings()
            return self._json(200, {"deepseek": bool(ds["key"]), "model": ds["model"]})
        return super().do_GET()

    def do_POST(self):
        if self.path.startswith("/gewu/api/migrate"):
            return self._migrate()
        if not self._same_origin():
            return self._json(403, {"error": "forbidden"})
        if not self.path.startswith("/gewu/api/chat"):
            return self._json(404, {"error": "见微内置版不提供这个接口"})
        ds = store.deepseek_settings()
        if not ds["key"]:
            return self._json(400, {"error": "还没有填 DeepSeek 密钥：见微 → 设置 → DeepSeek 题目分析"})
        try:
            req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        except json.JSONDecodeError:
            return self._json(400, {"error": "请求格式错误"})
        model = req.get("model") if req.get("model") in ("deepseek-chat", "deepseek-reasoner") else ds["model"]
        payload = chat_payload(req, model)
        r = urllib.request.Request(
            ds["base"] + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + ds["key"]},
        )
        if req.get("stream"):
            return stream_reply(self, r, payload)
        try:
            with urllib.request.urlopen(r, timeout=300) as resp:
                data = json.loads(resp.read())
            choice = data["choices"][0]
            return self._json(200, {"text": choice["message"].get("content") or "",
                                    "truncated": choice.get("finish_reason") == "length"})
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            return self._json(502, {"error": f"DeepSeek 返回 {e.code}：{detail}", "status": e.code,
                                    "transient": e.code in (429, 500, 502, 503, 504)})
        except Exception as e:  # 网络错误、超时等
            return self._json(502, {"error": f"连接 DeepSeek 失败：{e}", "transient": True})

    def _migrate(self):
        """一次性搬家：Edge 里打开的 migrate.html 把旧的 localStorage 交过来，内嵌窗口再写进自己的存储。

        file:// 页面的 Origin 是 "null"（Edge 里所有本地网页共用这个源），所以只收 jw.* 键，并且要带启动时生成的口令。
        """
        from urllib.parse import parse_qs, urlparse
        q = parse_qs(urlparse(self.path).query)
        src = (q.get("src") or [""])[0]
        origin = self.headers.get("Origin") or ""
        token = getattr(self.server, "migrate_token", "")
        ok_origin = (src == "file" and origin == "null") or (src == "http" and self._same_origin())
        if not token or (q.get("token") or [""])[0] != token or not ok_origin:
            return self._json(403, {"error": "forbidden"})
        try:
            data = json.loads(self.rfile.read(min(int(self.headers.get("Content-Length", 0)), 20_000_000)) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self._json(400, {"error": "bad json"})
        if not isinstance(data, dict):
            return self._json(400, {"error": "bad json"})
        items = {str(k): str(v) for k, v in data.items() if src == "http" or str(k).startswith("jw.")}
        items.pop("jw.theme", None)
        items.pop("lab-theme", None)  # 主题跟见微走，不搬
        (store.HOME / "web").mkdir(parents=True, exist_ok=True)
        (store.HOME / "web" / f"migrate-{src}.json").write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")
        body = json.dumps({"ok": True, "count": len(items)}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        if src == "file":
            self.send_header("Access-Control-Allow-Origin", "null")
        self.end_headers()
        self.wfile.write(body)


def stream_reply(handler, request, payload: dict) -> None:
    """流式转发：DeepSeek 的 SSE → 每行一个 JSON（{"d": 正文增量} / {"r": 思考字数} / {"done": true}），
    网页边收边显示，不用干等整段回答写完。"""
    request.data = json.dumps(dict(payload, stream=True)).encode("utf-8")
    try:
        resp = urllib.request.urlopen(request, timeout=300)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        return handler._json(502, {"error": f"DeepSeek 返回 {e.code}：{detail}", "status": e.code,
                                   "transient": e.code in (429, 500, 502, 503, 504)})
    except Exception as e:  # noqa: BLE001
        return handler._json(502, {"error": f"连接 DeepSeek 失败：{e}", "transient": True})
    handler.send_response(200)
    handler.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
    handler.send_header("Connection", "close")
    handler.end_headers()
    put = lambda obj: handler.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))  # noqa: E731
    finish = None
    try:
        with resp:
            for raw in resp:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    ch = (json.loads(data).get("choices") or [{}])[0]
                except ValueError:
                    continue
                delta, out = ch.get("delta") or {}, {}
                if delta.get("content"):
                    out["d"] = delta["content"]
                if delta.get("reasoning_content"):
                    out["r"] = len(delta["reasoning_content"])
                finish = ch.get("finish_reason") or finish
                if out:
                    put(out)
        put({"done": True, "truncated": finish == "length"})
    except Exception as e:  # noqa: BLE001  中途断线：告诉网页可以重试
        try:
            put({"error": f"连接中断：{e}", "transient": True})
        except Exception:
            pass
    handler.close_connection = True


def chat_payload(req: dict, model: str) -> dict:
    """网页发来 system + messages（多轮：提问、模型回答、修正要求……）；旧网页只发 system + user。"""
    msgs = [{"role": "system", "content": str(req.get("system", ""))}]
    conv = req.get("messages")
    if isinstance(conv, list) and conv:
        for m in conv[:12]:
            if isinstance(m, dict) and m.get("role") in ("user", "assistant"):
                msgs.append({"role": m["role"], "content": str(m.get("content", ""))})
    else:
        msgs.append({"role": "user", "content": str(req.get("user", ""))})
    payload = {"model": model, "messages": msgs, "temperature": 0.2}
    if "reasoner" not in model:  # deepseek-reasoner 不支持 JSON 模式
        payload["response_format"] = {"type": "json_object"}
        payload["max_tokens"] = 8192  # 默认 4K，带方程模型的回答可能更长
    return payload


class _Server(http.server.ThreadingHTTPServer):
    # Windows 上 SO_REUSEADDR 会允许和别的程序共用同一端口，固定端口时必须关掉
    allow_reuse_address = False
    daemon_threads = True


class StudioHost:
    def __init__(self) -> None:
        self._httpd: http.server.ThreadingHTTPServer | None = None
        self.port = 0
        self._proc: subprocess.Popen | None = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------ 服务
    def ensure(self) -> int:
        with self._lock:
            if self._httpd is not None:
                return self.port
            handler = functools.partial(_Quiet, directory=str(store.WEB_DIR))
            try:
                self._httpd = _Server(("127.0.0.1", PREFERRED_PORT), handler)
            except OSError:
                self._httpd = _Server(("127.0.0.1", 0), handler)
            self._httpd.daemon_threads = True
            import secrets
            self._httpd.migrate_token = secrets.token_urlsafe(18)  # 搬家口令：只有见微自己拼出的地址带它
            self.port = self._httpd.server_address[1]
            threading.Thread(target=self._httpd.serve_forever, daemon=True).start()
            try:
                (store.HOME / "studio.url").write_text(self.url_base(), encoding="utf-8")
            except Exception:
                pass
            return self.port

    def url_base(self) -> str:
        return f"http://127.0.0.1:{self.port}/index.html"

    def url(self, qid: str = "", lab: bool = False, audit: bool = False) -> str:
        port = self.ensure()
        query = []
        if qid:
            query.append("q=" + quote(qid))
        if lab:
            query.append("lab=1")
        if audit:
            query.append("audit=1")
        suffix = ("?" + "&".join(query)) if query else ""
        return f"http://127.0.0.1:{port}/index.html{suffix}"

    def stop(self) -> None:
        if self._httpd is not None:
            try:
                self._httpd.shutdown()
            except Exception:
                pass
            self._httpd = None

    # ------------------------------------------------------------ 打开窗口
    @staticmethod
    def edge_exe() -> str | None:
        for p in EDGE_PATHS:
            if Path(p).exists():
                return p
        return None

    # 旧入口名（变换实验室的数学 / 物理）→ 格物实验台里对应的位置
    LAB_ALIASES = {"math": "bench/draw", "physics": "bench/scene", "home": ""}

    def lab_url(self, target: str = "") -> str:
        """格物实验台走本机 HTTP（题目导入要调 /gewu/api/chat），target 是页面内的 # 路由。"""
        target = self.LAB_ALIASES.get(target, target)
        try:
            import ui_kit
            theme = ui_kit.theme()
        except Exception:
            theme = "day"
        port = self.ensure()
        return f"http://127.0.0.1:{port}/{LAB_PAGE}?theme={theme}" + (f"#{target}" if target else "")

    def page_url(self, qid: str = "", lab: bool = False, imp: bool = False,
                 mode: str = "") -> str:
        """习题台离线可用：file:// 直接打开（错题本、导入记录都存在这个源下，别换）。

        lab=True 打开格物实验台，mode 为实验台内的路由（bench/draw、import、某个实验 id……）。
        """
        if lab:
            return self.lab_url(mode)
        base = (store.WEB_DIR / "index.html").as_uri()
        query = []
        if qid:
            query.append("q=" + quote(qid))
        if imp:
            query.append("import=1")
        try:
            import ui_kit
            query.append("theme=" + ui_kit.theme())
        except Exception:
            pass
        return base + (("?" + "&".join(query)) if query else "")

    def open_migration(self) -> bool:
        """在 Edge 里打开两张搬家页：一张在 file:// 源（习题台的记录），一张在本机服务源（实验台的记录）。"""
        exe = self.edge_exe()
        if not exe:
            return False
        port = self.ensure()
        token = quote(getattr(self._httpd, "migrate_token", ""))
        tail = f"token={token}&port={port}"
        urls = [(store.WEB_DIR / "migrate.html").as_uri() + f"?src=file&{tail}",
                f"http://127.0.0.1:{port}/migrate.html?src=http&{tail}"]
        try:
            subprocess.Popen([exe, *urls, "--no-first-run"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            return False

    def open(self, qid: str = "", lab: bool = False, imp: bool = False,
             size: tuple[int, int] = (1460, 940), mode: str = "") -> bool:
        """在浏览器里开一页；不置顶、不抢焦点，是否切过去交给浏览器。"""
        exe = self.edge_exe()
        url = self.page_url(qid, lab, imp, mode)
        _close_stale_windows()
        try:
            if exe:
                subprocess.Popen([exe, url, "--no-first-run"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                os.startfile(url)  # noqa: S606
            return True
        except Exception:
            return False


TITLE_HINT = "见微 · 习题台"

_user32 = ctypes.windll.user32
try:
    from ctypes import wintypes
except Exception:  # pragma: no cover
    wintypes = None


def _enum_windows() -> list[tuple[int, str]]:
    found: list[tuple[int, str]] = []
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _l):
        if not _user32.IsWindowVisible(hwnd):
            return True
        n = _user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        _user32.GetWindowTextW(hwnd, buf, n + 1)
        found.append((int(hwnd), buf.value))
        return True

    _user32.EnumWindows(EnumProc(cb), None)
    return found


def _close_stale_windows() -> None:
    """把上一轮停在死端口上的析题台窗口关掉（只认我们自己的标题）。"""
    for hwnd, title in _enum_windows():
        if TITLE_HINT in title or title.startswith("127.0.0.1_/index.html"):
            try:
                _user32.PostMessageW(hwnd, 0x0010, 0, 0)   # WM_CLOSE
            except Exception:
                pass


def _raise_window(hint: str, timeout: float = 8.0) -> bool:
    """把标题含 hint 的窗口显示出来并置前（Edge 的应用窗不会自己抢焦点）。"""
    end = time.time() + timeout
    while time.time() < end:
        for hwnd, title in _enum_windows():
            if hint and hint in title:
                try:
                    _user32.ShowWindow(hwnd, 9)          # SW_RESTORE
                    _user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002)  # HWND_TOPMOST
                    _user32.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0001 | 0x0002)  # HWND_NOTOPMOST
                    _user32.SetForegroundWindow(hwnd)
                    _user32.BringWindowToTop(hwnd)
                except Exception:
                    pass
                return True
        time.sleep(0.25)
    return False
