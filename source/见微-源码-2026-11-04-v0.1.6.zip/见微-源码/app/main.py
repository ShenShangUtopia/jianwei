"""见微 · 高考学习舱 —— 入口。

用法：
  python main.py                 显示主窗口
  python main.py --background    静默驻留托盘
  python main.py --self-test     无头渲染各页面截图（开发验收用，不弹窗）
  python main.py --studio [id]   直接打开析题台某题
  python main.py --pill          只显示倒计时胶囊（调试）
"""
from __future__ import annotations

import argparse
import ctypes
import os
import sys
import traceback
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

import store  # noqa: E402


def _log(exc_type, exc_value, exc_tb) -> None:
    try:
        (store.HOME / "logs").mkdir(parents=True, exist_ok=True)
        with open(store.HOME / "logs" / "app.log", "a", encoding="utf-8") as fh:
            fh.write("".join(traceback.format_exception(exc_type, exc_value, exc_tb)))
            fh.write("\n")
    except Exception:
        pass


def _self_test(out_dir: Path) -> int:
    from PySide6.QtGui import QPixmap
    from PySide6.QtWidgets import QApplication

    from countdown import draw_pill
    from shell import Shell

    out_dir.mkdir(parents=True, exist_ok=True)
    app = QApplication.instance() or QApplication(sys.argv[:1])
    shell = Shell(tray_enabled=False, jobs_enabled=False)
    shell.resize(1180, 780)
    shell.show()
    app.processEvents()

    from datetime import datetime
    from PySide6.QtGui import QPainter
    for key, _ in [("today", ""), ("guanlan", ""), ("countdown", ""), ("studio", ""), ("lab", ""), ("settings", "")]:
        shell.goto(key)
        for _ in range(3):
            app.processEvents()
        shell.grab().save(str(out_dir / f"shell-{key}.png"), "PNG")

    # 观澜浮窗：验证内嵌模块能在这套环境里真的建起来
    try:
        panel = shell.guanlan.ensure()
        panel.show_window()
        for _ in range(3):
            app.processEvents()
        panel.grab().save(str(out_dir / "panel.png"), "PNG")
        shell.guanlan.hide()
        print("PANEL_OK", panel.size().width(), panel.size().height())
    except Exception as exc:
        print("PANEL_FAIL", repr(exc))

    # 胶囊：直接画到画布（不依赖桌面取景）
    pm = QPixmap(700, 52)
    pm.fill(__import__("PySide6.QtGui", fromlist=["QColor"]).QColor(0, 0, 0, 0))
    p = QPainter(pm)
    draw_pill(p, 700, 52, shell.cfg, datetime.now(), None, 0.6)
    p.end()
    pm.save(str(out_dir / "pill.png"), "PNG")

    tall = QPixmap(880 * 2, 360)
    from PySide6.QtGui import QColor
    tall.fill(QColor("#2A3346"))
    p = QPainter(tall)
    for i, cfg in enumerate([
        dict(shell.cfg, width=880, height=64),
        dict(shell.cfg, width=720, height=56, showDate=False),
        dict(shell.cfg, width=1060, height=72, aurora=80),
    ]):
        p.save()
        p.translate(40, 30 + i * 110)
        draw_pill(p, cfg["width"], cfg["height"], cfg, datetime.now(), None, 0.9 + i)
        p.restore()
    p.end()
    tall.save(str(out_dir / "pill-sizes.png"), "PNG")

    # 内嵌窗口：打包后 QtWebEngine 是否齐全；在真实桌面上（非 offscreen）再加载实验台、跑一段脚本
    try:
        import time as _time
        import webwin
        print("WEBWIN_AVAILABLE", webwin.available())
        if webwin.available() and os.environ.get("QT_QPA_PLATFORM") != "offscreen":
            box: dict = {}
            shell.open_lab("")
            shell._webwin.view.loadFinished.connect(lambda ok: box.setdefault("loaded", _time.time()))
            t0 = _time.time()
            while _time.time() - t0 < 20 and "v" not in box:
                app.processEvents()
                _time.sleep(0.05)
                if "loaded" in box and _time.time() - box["loaded"] > 1 and "asked" not in box:
                    box["asked"] = 1
                    shell._webwin.page.runJavaScript(
                        "typeof App + '/' + typeof Solver + '/' + (typeof Lab !== 'undefined' ? Lab.list.length : 0)", 0,
                        lambda v: box.setdefault("v", v))
            shell._webwin.grab().save(str(out_dir / "webwin.png"), "PNG")
            print("WEBWIN_PAGE", box.get("v"))
            shell._webwin.hide()
    except Exception as exc:
        print("WEBWIN_FAIL", repr(exc))

    shell.studio.stop()
    print("SELFTEST_OK", out_dir)
    return 0


def main() -> int:
    # 打包版的控制台可能是 cp1252/cp936：中文路径一 print 就抛 UnicodeEncodeError（自检会因此卡死在退出前）
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--background", action="store_true")
    parser.add_argument("--self-test", default="")
    parser.add_argument("--studio", default=None)
    parser.add_argument("--lab", action="store_true")
    parser.add_argument("--pill", action="store_true")
    parser.add_argument("--no-single", action="store_true")
    parser.add_argument("--no-tray", action="store_true")
    parser.add_argument("--evening", action="store_true", help="生成并全屏播放暮省，不开主窗口")
    parser.add_argument("--evening-no-open", action="store_true", help="只生成暮省页")
    parser.add_argument("--evening-serve", type=int, default=0, metavar="PORT",
                        help="内部用：只在本机提供暮省静态页（阻塞）")
    parser.add_argument("--fetch", action="store_true", help="立即抓取一次今日内容")
    args, _ = parser.parse_known_args()

    if args.evening_serve:
        import functools
        import http.server
        import socketserver
        home =Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "Guanlan" / "evening"
        handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(home))
        with socketserver.ThreadingTCPServer(("127.0.0.1", args.evening_serve), handler) as httpd:
            httpd.serve_forever()
        return 0

    if args.evening or args.evening_no_open or args.fetch:
        os.environ.setdefault("JIANWEI_CLI", "1")
        try:
            import scheduler
            if args.fetch:
                return scheduler.run_fetch()
            if args.evening and not args.evening_no_open:
                # 主路径：真实网页 kiosk（Edge 加 --no-sandbox 才在这台机器渲染）
                rc = scheduler.run_evening(open_browser=True)
                if rc == 3:
                    # 浏览器没出窗口：退到“逐页截图 + 自带播放器”
                    try:
                        import evening_slides
                        import evening_viewer
                        shots = evening_slides.render()
                        if shots:
                            return evening_viewer.show(shots)
                    except Exception:
                        import traceback
                        traceback.print_exc()
                return rc
            return scheduler.run_evening(open_browser=not args.evening_no_open)
        except Exception:
            import traceback
            traceback.print_exc()
            return 1

    if args.self_test:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        if not os.environ.get("QT_QPA_FONTDIR") and os.path.isdir(r"C:\Windows\Fonts"):
            os.environ["QT_QPA_FONTDIR"] = r"C:\Windows\Fonts"

    sys.excepthook = _log
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Jianwei.StudyCabin.1")
    except Exception:
        pass

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtWidgets import QApplication

    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    # 内嵌习题台 / 实验台用 QtWebEngine：它要求在 QApplication 之前开启 OpenGL 上下文共享
    QGuiApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("见微")
    app.setApplicationDisplayName("见微 · 高考学习舱")
    app.setOrganizationName("Jianwei")
    app.setStyle("Fusion")
    app.setQuitOnLastWindowClosed(False)
    import ui_kit
    from store import load_config
    _t = load_config().get("theme", "auto")
    if _t not in ("day", "night"):
        from datetime import datetime as _dt
        _t = "day" if 7 <= _dt.now().hour < 19 else "night"
    ui_kit.apply_theme(_t)
    app.setStyleSheet(ui_kit.qss())

    if args.self_test:
        return _self_test(Path(args.self_test))

    from PySide6.QtNetwork import QLocalServer, QLocalSocket

    server = None
    if not args.no_single:
        socket = QLocalSocket()
        socket.connectToServer("Jianwei-Suite-Local")
        if socket.waitForConnected(200):
            socket.write(b"show")
            socket.waitForBytesWritten(150)
            socket.disconnectFromServer()
            return 0
        server = QLocalServer()
        QLocalServer.removeServer("Jianwei-Suite-Local")
        server.listen("Jianwei-Suite-Local")

    from shell import Shell
    shell = Shell(tray_enabled=not args.no_tray)
    if server is not None:
        def new_connection():
            conn = server.nextPendingConnection()
            if conn is not None:
                conn.readyRead.connect(shell._tray_show)
        server.newConnection.connect(new_connection)

    if args.pill:
        shell.show_pill(True)
        return app.exec()

    if args.studio is not None:
        shell.open_studio(args.studio, lab=args.lab)
        return app.exec()

    if args.background or shell.cfg.get("startMinimized"):
        shell.hide()
    else:
        shell.show()
        shell.raise_()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
