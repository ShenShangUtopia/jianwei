"""见微 · 打包（PyInstaller onedir）+ 桌面快捷方式。

用法：python build.py            # 打包
      python build.py --shortcut # 只重建桌面快捷方式
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
DIST = ROOT / "dist"


def build() -> int:
    for junk in (ROOT / "build", DIST, ROOT / "Jianwei.spec"):
        if junk.is_dir():
            shutil.rmtree(junk, ignore_errors=True)
        elif junk.exists():
            junk.unlink()
    args = [
        sys.executable, "-m", "PyInstaller", "--noconfirm", "--onedir", "--windowed",
        "--name", "Jianwei",
        "--icon", str(APP / "assets" / "icon.ico"),
        "--add-data", f"{APP / 'studio' / 'web'};studio/web",
        "--add-data", f"{APP / 'guanlan'};guanlan",
        "--add-data", f"{APP / 'assets'};assets",
        "--paths", str(APP / "guanlan"),
        "--hidden-import", "core.paths", "--hidden-import", "core.evening",
        "--hidden-import", "core.curator", "--hidden-import", "core.autostart",
        "--collect-submodules", "core", "--collect-submodules", "ui",
        # 内嵌习题台 / 实验台窗口（QtWebEngine：QtWebEngineProcess.exe 与资源由 PySide6 的钩子带上）
        "--hidden-import", "webwin", "--hidden-import", "PySide6.QtWebEngineWidgets",
        "--hidden-import", "PySide6.QtWebEngineCore",
        "--noconsole",
        str(APP / "main.py"),
    ]
    print(" ".join(args[:8]), "…")
    code = subprocess.call(args, cwd=ROOT)
    if code == 0:
        prune(DIST / "Jianwei" / "_internal")
    return code


# ---------------------------------------------------------------- 瘦身
# QtWebEngine 的钩子会把 QML、Qt Quick 3D、开发者工具、几十种语言一并带上（约 580 MB）。
# 见微只用 Widgets + WebEngine：从真正用到的模块出发沿 PE 导入表找依赖，其余 Qt DLL / .pyd 删掉。
KEEP_PYD = {"QtCore", "QtGui", "QtWidgets", "QtNetwork", "QtSvg", "QtWebEngineCore", "QtWebEngineWidgets",
            "QtWebChannel", "QtOpenGL", "QtPrintSupport", "QtPositioning"}
KEEP_LOCALES = {"zh-CN.pak", "en-US.pak"}


def _pe_imports(path: Path) -> list[str]:
    import struct
    b = path.read_bytes()
    pe = struct.unpack_from("<I", b, 0x3C)[0]
    nsec, optsize = struct.unpack_from("<H", b, pe + 6)[0], struct.unpack_from("<H", b, pe + 20)[0]
    opt = pe + 24
    dd = opt + (112 if struct.unpack_from("<H", b, opt)[0] == 0x20B else 96)
    secs = [struct.unpack_from("<IIII", b, opt + optsize + i * 40 + 8) for i in range(nsec)]

    def off(rva: int):
        for vs, va, rs, rp in secs:
            if va <= rva < va + max(vs, rs):
                return rva - va + rp
        return None
    out, o = [], off(struct.unpack_from("<I", b, dd + 8)[0])
    while o is not None:
        name_rva = struct.unpack_from("<I", b, o + 12)[0]
        if not name_rva:
            break
        no = off(name_rva)
        out.append(b[no:b.index(b"\0", no)].decode("ascii", "replace").lower())
        o += 20
    return out


def prune(internal: Path) -> None:
    qt = internal / "PySide6"
    if not qt.is_dir():
        return
    before = sum(f.stat().st_size for f in internal.rglob("*") if f.is_file())
    roots = [qt / "QtWebEngineProcess.exe", *[qt / f"{m}.pyd" for m in KEEP_PYD],
             *(qt / "plugins").rglob("*.dll"), *qt.glob("pyside6*.dll"), *internal.glob("shiboken6/*.dll")]
    need, todo = set(), [p for p in roots if p.exists()]
    while todo:
        p = todo.pop()
        for d in _pe_imports(p):
            if d.startswith("qt6") and d not in need:
                need.add(d)
                if (qt / d).exists():
                    todo.append(qt / d)
    removed = []
    for f in qt.glob("Qt6*.dll"):
        if f.name.lower() not in need:
            removed.append(f)
    for f in qt.glob("Qt*.pyd"):
        if f.stem not in KEEP_PYD:
            removed.append(f)
    removed += list(qt.glob("resources/qtwebengine_devtools_resources*.pak"))   # 开发者工具
    loc = qt / "translations" / "qtwebengine_locales"
    removed += [f for f in loc.glob("*.pak") if f.name not in KEEP_LOCALES]
    removed += [f for f in (qt / "translations").glob("*.qm") if "zh_CN" not in f.name]
    for f in removed:
        try:
            f.unlink()
        except OSError:
            pass
    shutil.rmtree(qt / "qml", ignore_errors=True)  # Widgets 程序用不到 QML 插件
    after = sum(f.stat().st_size for f in internal.rglob("*") if f.is_file())
    print(f"prune: {len(removed)} files + qml/, {before / 1e6:.0f} MB → {after / 1e6:.0f} MB")


def shortcut() -> None:
    """桌面快捷方式交给 make_shortcut.py（UTF-16LE VBS，规避 PowerShell 中文编码坑）。"""
    subprocess.call([sys.executable, str(ROOT / "make_shortcut.py")])


if __name__ == "__main__":
    if "--shortcut" in sys.argv:
        shortcut()
    else:
        code = build()
        if code == 0:
            shortcut()
        sys.exit(code)
