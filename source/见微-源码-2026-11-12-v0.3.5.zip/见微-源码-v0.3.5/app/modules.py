"""见微 · 模块：把每个功能做成一块能直接看、直接操作的小面板。

两种布局用它：
- 模块桌面（Desktop）：没有侧栏，八个模块摆成一张桌面；模块标题旁的「展开」打开完整页面，顶栏「返回」回桌面。
- 工作台（Workspace）：几个模块并排同屏，拖标题栏换位置、拖缝隙改大小、可添加和关掉；摆好的样子存进配置。

模块的内容按 big 区分：桌面上是精简版（几行、几个键），工作台里是能填满一整块的版本（完整列表、滚动）。
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta

from PySide6.QtCore import QMimeData, QPoint, QPointF, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QDrag, QFontMetricsF, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMenu, QPlainTextEdit, QSizePolicy,
                               QSplitter, QVBoxLayout, QWidget)

import store
from native.design.icons import draw_icon
from native.design.widgets import IconButton
from ui_kit import (C, DROP, Btn, SmoothScroll, dense, doodle, f, lab, paint_card, serif, title_font)

WEEK_CN = "一二三四五六日"
MIME = "application/x-jianwei-module"


def _tint(color: QColor, a: float) -> QColor:
    out = QColor(color)
    out.setAlphaF(a)
    return out


def _clip(text: str, n: int) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= n else text[: n - 1] + "…"


# ---------------------------------------------------------------- 模块外壳
class _Glyph(QWidget):
    """模块标题前的小图标：一块淡色底上画线性图标。"""

    def __init__(self, icon: str):
        super().__init__()
        self.icon = icon
        self.setFixedSize(28, 28)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_tint(C.INK2, 0.12))
        p.drawRoundedRect(QRectF(self.rect()), 7, 7)
        draw_icon(p, self.icon, QRectF(self.rect()).adjusted(6, 6, -6, -6), C.INK2, 1.6)
        p.end()


class _Head(QWidget):
    """模块的标题栏。工作台里它是拖动把手：按住拖到别的模块上就换位置。"""

    def __init__(self, module):
        super().__init__()
        self.module = module
        self._press = None
        self.setFixedHeight(34)

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton and self.module.draggable:
            self._press = e.position().toPoint()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._press is None or (e.position().toPoint() - self._press).manhattanLength() < 8:
            return
        self._press = None
        self.unsetCursor()
        self.module.start_drag()

    def mouseReleaseEvent(self, _e):  # noqa: N802
        self._press = None
        if self.module.draggable:
            self.setCursor(Qt.CursorShape.OpenHandCursor)

    def enterEvent(self, _e):  # noqa: N802
        if self.module.draggable:
            self.setCursor(Qt.CursorShape.OpenHandCursor)


class Module(QFrame):
    """一个模块：卡片底 + 标题栏（图标、名字、一句状态、展开键）+ 内容。"""

    def __init__(self, ctx, key: str, big: bool = False, draggable: bool = False):
        super().__init__()
        self.ctx, self.key, self.big, self.draggable = ctx, key, big, draggable
        self.setObjectName("jmodule")
        self._hint = None       # 工作台里拖着别的模块经过时：落点在哪一边
        spec = SPEC[key]
        v = QVBoxLayout(self)
        tight = dense()
        v.setContentsMargins(14 if tight else 16, 10 if tight else 12, 14 if tight else 16,
                             (10 if tight else 14) + (int(DROP) if doodle() else 0))
        v.setSpacing(6 if tight else 8)
        self.head_w = _Head(self)
        head = QHBoxLayout(self.head_w)
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(8)
        head.addWidget(_Glyph(spec["icon"]))
        name = lab(spec["name"], 14, "INK", 700)
        head.addWidget(name)
        self.sub = lab("", 11, "FAINT")
        head.addWidget(self.sub)
        head.addStretch(1)
        self.head = head
        if spec.get("open"):
            b = Btn("展开", "soft", spec.get("open_tip", "打开完整页面"), "full")
            b.clicked.connect(lambda _=False: spec["open"](ctx))
            head.addWidget(b)
        v.addWidget(self.head_w)
        self.body = QVBoxLayout()
        self.body.setContentsMargins(0, 0, 0, 0)
        self.body.setSpacing(6 if tight else 8)
        v.addLayout(self.body, 1)
        spec["build"](ctx, self, big)
        self.setMinimumSize(250, 150)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        r = paint_card(p, self.rect())
        if self._hint:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.INK2)
            bar = {"top": QRectF(r.x() + 10, r.y() + 1, r.width() - 20, 4),
                   "bottom": QRectF(r.x() + 10, r.bottom() - 5, r.width() - 20, 4),
                   "left": QRectF(r.x() + 1, r.y() + 10, 4, r.height() - 20),
                   "right": QRectF(r.right() - 5, r.y() + 10, 4, r.height() - 20)}[self._hint]
            p.drawRoundedRect(bar, 2, 2)
        p.end()

    def start_drag(self) -> None:
        drag = QDrag(self)
        mime = QMimeData()
        mime.setData(MIME, self.key.encode())
        drag.setMimeData(mime)
        pm = self.grab()
        pm = pm.scaledToWidth(min(260, pm.width()), Qt.TransformationMode.SmoothTransformation)
        drag.setPixmap(pm)
        drag.setHotSpot(QPoint(pm.width() // 2, 16))
        drag.exec(Qt.DropAction.MoveAction)


# ---------------------------------------------------------------- 各模块的内容
class _CountdownView(QWidget):
    """倒计时模块：大字天数 + 一道学期进度。每半分钟自己刷新，看不见时不刷。"""

    def __init__(self, ctx, big: bool):
        super().__init__()
        self.ctx = ctx
        self.setMinimumHeight(118 if big else 106)     # 进度条下面那行小字画到 y≈102
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self._t = QTimer(self)
        self._t.setInterval(30_000)
        self._t.timeout.connect(self.update)

    def showEvent(self, e):  # noqa: N802
        self._t.start()
        super().showEvent(e)

    def hideEvent(self, e):  # noqa: N802
        self._t.stop()
        super().hideEvent(e)

    def paintEvent(self, _e):  # noqa: N802
        cfg = self.ctx.cfg
        now = datetime.now()
        target, start = store.target_dt(cfg), store.start_dt(cfg)
        if start >= target:
            start = target - timedelta(days=280)
        secs = max(0.0, (target - now).total_seconds())
        frac = min(1.0, max(0.0, 1 - secs / max(1.0, (target - start).total_seconds())))
        w = self.width()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        days = str(int(secs // 86400))
        big = serif(52, 600)
        p.setFont(big)
        p.setPen(C.INK)
        p.drawText(QPointF(0, 54), days)
        nw = QFontMetricsF(big).horizontalAdvance(days)
        p.setFont(f(13, 500))
        p.setPen(C.SOFT)
        p.drawText(QPointF(nw + 6, 52), f"天 · 距 {cfg.get('year', '2027')} {cfg.get('label', '高考')}")
        y = 74
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.LINE)
        p.drawRoundedRect(QRectF(0, y, w, 5), 2.5, 2.5)
        p.setBrush(C.INK2)
        p.drawRoundedRect(QRectF(0, y, max(5.0, w * frac), 5), 2.5, 2.5)
        p.setBrush(C.ACCENT)
        p.drawEllipse(QPointF(w * frac, y + 2.5), 4.5, 4.5)
        p.setFont(f(11))
        p.setPen(C.FAINT)
        p.drawText(QRectF(0, y + 10, w, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   f"学期已过 {int(frac * 100)}%")
        p.drawText(QRectF(0, y + 10, w, 18), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter),
                   f"{target:%Y.%m.%d} 开考")
        p.end()


def _build_countdown(ctx, m: Module, big: bool) -> None:
    m.sub.setText(f"第 {__import__('countdown').phase_week()} 周")
    m.body.addWidget(_CountdownView(ctx, big))
    shown = lambda: ctx.pill is not None and ctx.pill.isVisible()  # noqa: E731
    pill = Btn("隐藏桌面胶囊" if shown() else "显示桌面胶囊", "", "在桌面上显示 / 隐藏时间胶囊", "countdown")

    def flip():
        ctx.show_pill(not shown())
        pill.setText("隐藏桌面胶囊" if shown() else "显示桌面胶囊")
        pill.updateGeometry()
    pill.clicked.connect(flip)
    m.body.addStretch(1)
    m.body.addLayout(_row(pill))


def _row(*ws, stretch_first=False) -> QHBoxLayout:
    r = QHBoxLayout()
    r.setContentsMargins(0, 0, 0, 0)
    r.setSpacing(8)
    if stretch_first:
        r.addStretch(1)
    for w in ws:
        r.addWidget(w) if isinstance(w, QWidget) else r.addLayout(w)
    if not stretch_first:
        r.addStretch(1)
    return r


def _build_question(ctx, m: Module, big: bool) -> None:
    qs = store.questions()
    state = {"q": store.question_of_day()}
    meta = lab("", 11, "INK2", 700, 0.8)
    title = lab("", 15.5, "INK", 700, wrap=True)
    stem = lab("", 12, "SOFT", wrap=True)

    def show():
        q = state["q"]
        if not q:
            title.setText("题库尚未就绪")
            return
        meta.setText(f"{q['subject']} · {q['year']} 年 · {q['paper']}")
        title.setText(q["title"])
        stem.setText(_clip(q["stem"], 220 if big else 90))
    show()
    m.sub.setText("每天换一道")
    for w in (meta, title, stem):
        m.body.addWidget(w)
    m.body.addStretch(1)
    go = Btn("打开解析 →", "", "在学习窗口里看图解和分步讲解")
    go.clicked.connect(lambda: state["q"] and ctx.open_question(state["q"]["id"]))
    other = Btn("换一道", "soft", "从题库里随机换一道（不打开）")

    def swap():
        if qs:
            state["q"] = random.choice(qs)
            show()
    other.clicked.connect(swap)
    m.body.addLayout(_row(go, other))


def _build_review(ctx, m: Module, big: bool) -> None:
    status = lab("", 12.5, "BODY", wrap=True)
    note = lab("间隔 1、3、7、14、30 天；不排名、不设打卡目标。", 11, "FAINT", wrap=True)
    start = Btn("开始复习", "", "把今天到期的题和知识卡过一遍")

    def refresh():
        try:
            from native import learning
            n = len(learning.due())
        except Exception:
            status.setText("复习记录暂时读不到，原文件已保留。")
            start.setEnabled(False)
            return
        m.sub.setText(f"今天到期 {n} 项")
        status.setText(f"今天有 {n} 项到期。" if n else "今天没有到期的项目。做过的题、看过的知识卡会按间隔排进来。")
        start.setEnabled(n > 0)

    def review():
        try:
            from native.learning_ui import Review
            Review(ctx).exec()
        except Exception as exc:  # noqa: BLE001
            ctx.toast(f"打不开复习：{exc}")
        refresh()
    start.clicked.connect(review)
    refresh()
    m.body.addWidget(status)
    m.body.addWidget(note)
    m.body.addStretch(1)
    m.body.addLayout(_row(start))


class _DeckRow(QWidget):
    """课件模块里的一行：小缩略图 + 名字 + 看到哪了。点一下全屏放映，右键删除。"""

    def __init__(self, ctx, meta: dict):
        super().__init__()
        self.ctx, self.meta = ctx, meta
        self._hover = False
        self.setFixedHeight(52)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("点一下全屏放映；右键更多")
        self.thumb = None
        try:
            from native.lecture import library
            pm = QPixmap(str(library.folder(meta["id"]) / "thumb.png"))
            if not pm.isNull():
                self.thumb = pm.scaled(QSize(76, 43), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                       Qt.TransformationMode.SmoothTransformation)
        except Exception:
            self.thumb = None

    def enterEvent(self, _e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self._hover = False
        self.update()

    def mouseReleaseEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.ctx.play_lecture(self.meta)

    def contextMenuEvent(self, e):  # noqa: N802
        menu = QMenu(self)
        menu.addAction("全屏放映", lambda: self.ctx.play_lecture(self.meta))
        menu.addSeparator()
        menu.addAction("删除…", lambda: self.ctx.delete_lecture(self.meta))
        menu.exec(e.globalPos())

    def paintEvent(self, _e):  # noqa: N802
        m = self.meta
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.KEYHOVER)
            p.drawRoundedRect(QRectF(self.rect()), 7, 7)
        box = QRectF(4, 4.5, 76, 43)
        p.save()
        p.setClipRect(box)
        if self.thumb is not None:
            p.drawPixmap(int(box.x()), int(box.y()), self.thumb)
        else:
            p.fillRect(box, _tint(C.INK, 0.06))
            draw_icon(p, "lecture", box.adjusted(26, 10, -26, -10), C.FAINT, 1.4)
        p.restore()
        p.setPen(QPen(C.LINE, 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(box)
        pages = int(m.get("display_pages") or m.get("pages") or 0)
        at = int(m.get("page") or 0)
        if pages > 1 and at > 0:
            p.fillRect(QRectF(box.x(), box.bottom() - 2, box.width() * min(1.0, (at + 1) / pages), 2), C.ACCENT)
        tw = self.width() - 96
        p.setFont(f(12.5, 700))
        p.setPen(C.INK)
        fm = QFontMetricsF(p.font())
        p.drawText(QRectF(90, 7, tw, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   fm.elidedText(str(m.get("title", "")), Qt.TextElideMode.ElideRight, tw))
        slides = m.get("kind") == "slides"
        info = f"{pages} {'张' if slides else '页'}"
        if pages > 1 and at > 0:
            info += f" · 看到第 {min(pages, at + 1)} {'张' if slides else '页'}"
        p.setFont(f(11))
        p.setPen(C.FAINT)
        p.drawText(QRectF(90, 27, tw, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), info)
        if self._hover:
            draw_icon(p, "play", QRectF(self.width() - 26, 18, 16, 16), C.INK2, 1.6)
        p.end()


def _build_lecture(ctx, m: Module, big: bool) -> None:
    try:
        from native.lecture import library
        from native.lecture.convert import SUPPORTED
        items = library.all_lectures()
    except Exception:
        items, SUPPORTED = [], ()
    m.sub.setText(f"{len(items)} 份" if items else "")
    if not items:
        m.body.addWidget(lab("还没有课件。点「导入」选 PPT、Word、PDF，或者直接把文件拖到这块上。", 12, "SOFT", wrap=True))
        m.body.addStretch(1)
    else:
        box = QWidget()
        col = QVBoxLayout(box)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(2)
        for meta in items if big else items[:3]:
            col.addWidget(_DeckRow(ctx, meta))
        col.addStretch(1)
        if big:
            area = SmoothScroll()
            area.setWidgetResizable(True)
            area.setFrameShape(SmoothScroll.Shape.NoFrame)
            area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            area.setStyleSheet("QScrollArea{background:transparent;border:none;}")
            area.setWidget(box)
            m.body.addWidget(area, 1)
        else:
            m.body.addWidget(box)
            if len(items) > 3:
                m.body.addWidget(lab(f"还有 {len(items) - 3} 份，点「展开」看全部", 11, "FAINT"))
            m.body.addStretch(1)
    imp = Btn("导入课件", "", "选 PPT、Word、PDF 文件；也可以直接拖到这块上", "plus")
    imp.clicked.connect(lambda: ctx.import_lectures())
    tools = Btn("桌面工具栏", "soft", "悬浮在桌面上的画笔工具栏：在别的软件上也能批注")
    tools.clicked.connect(ctx.toggle_desktop_tools)
    m.body.addLayout(_row(imp, tools))

    import os

    def drag_enter(e):
        if e.mimeData().hasUrls() and any(os.path.splitext(u.toLocalFile())[1].lower() in SUPPORTED for u in e.mimeData().urls()):
            e.acceptProposedAction()

    def drop(e):
        if e.mimeData().hasUrls():
            ctx.import_lectures([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])
            e.acceptProposedAction()
    m.accept_files = (drag_enter, drop)


def _build_guanlan(ctx, m: Module, big: bool) -> None:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    m.sub.setText(store.guanlan_date() or "等待今日版")
    m.body.addWidget(lab(_clip(lead.get("title", ""), 60) or "今日版尚未生成", 14.5, "INK", 700, wrap=True))
    if lead.get("summary"):
        m.body.addWidget(lab(_clip(lead["summary"], 160 if big else 70), 11.5, "SOFT", wrap=True))
    for i, st in enumerate(stories[1:(12 if big else 4)], start=2):
        line = QHBoxLayout()
        line.setSpacing(8)
        n = QLabel(f"{i:02d}")
        n.setFont(serif(11, 600))
        n.setStyleSheet(f"color:{C.INK2H};background:transparent;")
        n.setFixedWidth(18)
        line.addWidget(n)
        t = lab(_clip(st["title"], 40), 11.5, "BODY")
        t.setToolTip(st["title"])
        line.addWidget(t, 1)
        m.body.addLayout(line)
    m.body.addStretch(1)
    float_ = Btn("打开浮窗", "", "在桌面上打开 / 收起观澜浮窗", "guanlan")
    float_.clicked.connect(ctx.toggle_guanlan)
    again = Btn("刷新", "soft", "重新抓取今天的世界线索：需要联网，约 30 秒")
    again.clicked.connect(ctx.refresh_guanlan)
    m.body.addLayout(_row(float_, again))


def _build_studio(ctx, m: Module, big: bool) -> None:
    from pages import QuestionList
    qs = store.questions()
    m.sub.setText(f"{len(qs)} 题")
    search = QLineEdit()
    search.setPlaceholderText("搜题目、年份、试卷、题干")
    search.setClearButtonEnabled(True)
    m.body.addWidget(search)
    listing = QuestionList(ctx)
    limit = None if big else 4

    def fill(text=""):
        text = text.strip().lower()
        shown = [q for q in qs if not text or text in (q["title"] + " " + q["year"] + " " + q["paper"] + " " + q["subject"] + " " + q["stem"]).lower()]
        listing.set_rows(shown[:limit] if limit else shown, "没有匹配的题目" if text else "题库为空")
        if limit:
            listing.setFixedHeight(listing.ROW * max(1, min(limit, len(shown))) if shown else 72)
    search.textChanged.connect(fill)
    fill()
    if big:
        area = SmoothScroll()
        area.setWidgetResizable(True)
        area.setFrameShape(SmoothScroll.Shape.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        area.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        area.setWidget(listing)
        m.body.addWidget(area, 1)
    else:
        m.body.addWidget(listing)
        m.body.addStretch(1)
    rnd = Btn("随机一题", "soft", "从题库里随机抽一道，直接打开解析")
    rnd.clicked.connect(ctx.random_question)
    m.body.addLayout(_row(rnd))
    m.search, m.listing = search, listing


def _build_lab(ctx, m: Module, big: bool) -> None:
    from pages import _SUBJ, _SubjTile
    st = store.lab_stats()
    m.sub.setText(f"{st['total']} 个实验")
    grid = QGridLayout()
    grid.setSpacing(8)
    for i, (key, name, _, _) in enumerate(_SUBJ):
        tile = _SubjTile(key, name, st["subj"].get(key, 0), lambda k=key: ctx.open_lab(f"subj/{k}"))
        tile.setMinimumWidth(100)
        grid.addWidget(tile, i // 2, i % 2)
    m.body.addLayout(grid)
    if big:
        for b in st["benches"]:
            row = Btn(b["title"], "soft", b["sub"])
            row.clicked.connect(lambda _=False, k=b["id"]: ctx.open_lab(f"bench/{k}"))
            m.body.addWidget(row)
    m.body.addStretch(1)
    bench = Btn("自由工作台", "", "自己挑器材、药品和场景", "bench")
    bench.clicked.connect(lambda: ctx.open_lab("bench"))
    m.body.addLayout(_row(bench))


def _build_analysis(ctx, m: Module, big: bool) -> None:
    ds = store.deepseek_settings()
    m.sub.setText("DeepSeek 已配置" if ds["key"] else "离线读题器")
    box = QPlainTextEdit()
    box.setPlaceholderText("把一道题粘贴到这里，比如：从 20 m 高处以 15 m/s 水平抛出一个小球，求落地时间和水平位移。")
    box.setFont(f(12.5))
    box.setStyleSheet(f"QPlainTextEdit{{background:{C.KEYH};color:{C.INKH};border:{2 if doodle() else 1}px solid {C.KEYLINEH};"
                      f"border-radius:8px;padding:6px 8px;}} QPlainTextEdit:focus{{border-color:{C.INK2H};}}")
    box.setMinimumHeight(70)
    if big:
        m.body.addWidget(box, 1)
    else:
        box.setFixedHeight(96)      # 桌面上固定高：不然格子比它高时多出来的地方会把标题往下挤
        m.body.addWidget(box)
    err = lab("", 11, "ACCENT")
    err.hide()
    box.textChanged.connect(err.hide)
    go = Btn("解题并演示", "", "解题、选实验、配好参数，在学习窗口里演示", "analysis")

    def run():
        text = box.toPlainText().strip()
        if not text:
            err.setText("先把题目粘贴进来")
            err.show()
            return
        ctx.analyze_text(text)
    go.clicked.connect(run)
    m.body.addWidget(err)
    if not big:
        m.body.addStretch(1)
    m.body.addLayout(_row(go))
    m.input = box


SPEC = {
    "countdown": dict(name="倒计时", icon="countdown", build=_build_countdown,
                      open=lambda ctx: ctx.goto("countdown"), open_tip="胶囊的样子、位置和尺上节点"),
    "question": dict(name="今日一题", icon="desk", build=_build_question,
                     open=lambda ctx: ctx.goto("studio"), open_tip="打开习题台页"),
    "review": dict(name="复习", icon="note", build=_build_review),
    "lecture": dict(name="课件", icon="lecture", build=_build_lecture,
                    open=lambda ctx: ctx.goto("lecture"), open_tip="看全部课件（大缩略图）"),
    "guanlan": dict(name="观澜", icon="guanlan", build=_build_guanlan,
                    open=lambda ctx: ctx.goto("guanlan"), open_tip="今日线索和晚间暮省"),
    "studio": dict(name="习题台", icon="studio", build=_build_studio,
                   open=lambda ctx: ctx.goto("studio"), open_tip="按科目筛选全部题目"),
    "lab": dict(name="实验室", icon="lab", build=_build_lab,
                open=lambda ctx: ctx.goto("lab"), open_tip="四科实验、自由工作台、题目导入"),
    "analysis": dict(name="析题", icon="analysis", build=_build_analysis,
                     open=lambda ctx: ctx.open_lab("import"), open_tip="在学习窗口里打开析题"),
}
ORDER = ["lecture", "studio", "countdown", "question", "guanlan", "analysis", "lab", "review"]


def _greeting(ctx, title: str, hint: str) -> QHBoxLayout:
    now = datetime.now()
    hello = "早上好" if now.hour < 11 else "中午好" if now.hour < 14 else "下午好" if now.hour < 18 else "晚上好"
    row = QHBoxLayout()
    row.setSpacing(12)
    t = QLabel(title or hello)
    t.setFont(title_font(20 if dense() else 22))
    t.setStyleSheet(f"color:{C.INKH};background:transparent;")
    row.addWidget(t, 0, Qt.AlignmentFlag.AlignBottom)
    s = lab(f"{hello} · {now.month} 月 {now.day} 日 周{WEEK_CN[now.weekday()]}" if title else f"{now.month} 月 {now.day} 日 周{WEEK_CN[now.weekday()]}",
            11.5, "SOFT")
    s.setContentsMargins(0, 0, 0, 3)
    row.addWidget(s, 0, Qt.AlignmentFlag.AlignBottom)
    row.addStretch(1)
    h = lab(hint, 11, "FAINT")
    h.setContentsMargins(0, 0, 0, 3)
    row.addWidget(h, 0, Qt.AlignmentFlag.AlignBottom)
    return row


# ---------------------------------------------------------------- 模块桌面
class Desktop(QWidget):
    """没有侧栏：八个模块摆成一张桌面。"""

    GRID = (("countdown", 0, 0, 1, 1), ("question", 0, 1, 1, 1), ("review", 0, 2, 1, 1),
            ("lecture", 1, 0, 1, 2), ("guanlan", 1, 2, 1, 1),
            ("studio", 2, 0, 1, 1), ("lab", 2, 1, 1, 1), ("analysis", 2, 2, 1, 1))

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.modules: dict[str, Module] = {}
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        inner = QWidget()
        inner.setMaximumWidth(1360)
        v = QVBoxLayout(inner)
        tight = dense()
        v.setContentsMargins(*((20, 12, 20, 18) if tight else (28, 18, 28, 26)))
        v.setSpacing(10 if tight else 14)
        v.addLayout(_greeting(ctx, "", "点模块里的键直接用；「展开」看完整页面，顶栏左上角回来"))
        grid = QGridLayout()
        grid.setSpacing(10 if tight else 14)
        for key, r, c, rs, cs in self.GRID:
            m = Module(ctx, key)
            self.modules[key] = m
            grid.addWidget(m, r, c, rs, cs)
        for c in range(3):
            grid.setColumnStretch(c, 1)
        v.addLayout(grid)
        v.addStretch(1)
        holder = QWidget()
        hl = QHBoxLayout(holder)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.addStretch(1)
        hl.addWidget(inner, 1000)
        hl.addStretch(1)
        self.area = SmoothScroll()
        self.area.setWidgetResizable(True)
        self.area.setFrameShape(SmoothScroll.Shape.NoFrame)
        self.area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.area.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        self.area.setWidget(holder)
        outer.addWidget(self.area)
        _enable_file_drops(self.modules.get("lecture"))


def _enable_file_drops(m) -> None:
    """课件模块接拖进来的文件（PPT、Word、PDF）。"""
    if m is None or not hasattr(m, "accept_files"):
        return
    enter, drop = m.accept_files
    m.setAcceptDrops(True)
    m.dragEnterEvent = enter
    m.dropEvent = drop


# ---------------------------------------------------------------- 工作台
DEFAULT_WS = [["lecture"], ["studio", "countdown"], ["guanlan", "analysis"]]
MAX_COLS = 4


class Panel(Module):
    """工作台里的一块：模块 + 关闭键、更多菜单；标题栏能拖，整块接别的模块的落点。"""

    def __init__(self, ctx, key: str, ws):
        super().__init__(ctx, key, big=True, draggable=True)
        self.ws = ws
        more = IconButton("more", "移动这一块", 28)
        more.clicked.connect(lambda: self._menu(more))
        close = IconButton("close", "从工作台拿掉（随时能从「添加模块」加回来）", 28)
        close.clicked.connect(lambda: QTimer.singleShot(0, lambda: ws.remove(key)))
        self.head.addWidget(more)
        self.head.addWidget(close)
        self.setAcceptDrops(True)
        self.setMinimumSize(260, 170)

    def _menu(self, anchor) -> None:
        menu = QMenu(self)
        c, i = self.ws.where(self.key)
        cols = self.ws.cols
        acts = [("上移", c, i - 1, i > 0), ("下移", c, i + 1, i < len(cols[c]) - 1),
                ("移到左边一栏", c - 1, len(cols[c - 1]) if c > 0 else 0, c > 0),
                ("移到右边一栏", c + 1, len(cols[c + 1]) if c + 1 < len(cols) else 0, c + 1 < len(cols))]
        for text, tc, ti, ok in acts:
            a = menu.addAction(text, lambda tc=tc, ti=ti: QTimer.singleShot(0, lambda: self.ws.move(self.key, tc, ti)))
            a.setEnabled(ok)
        a = menu.addAction("单独占一栏", lambda: QTimer.singleShot(0, lambda: self.ws.move_new_col(self.key, c + 1)))
        a.setEnabled(len(cols) < MAX_COLS and len(cols[c]) > 1)
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    # ---- 拖放
    def _side(self, pos) -> str:
        x, y = pos.x() / max(1, self.width()), pos.y() / max(1, self.height())
        if len(self.ws.cols) < MAX_COLS and (x < 0.18 or x > 0.82):
            return "left" if x < 0.5 else "right"
        return "top" if y < 0.5 else "bottom"

    def dragEnterEvent(self, e):  # noqa: N802
        if e.mimeData().hasFormat(MIME) and bytes(e.mimeData().data(MIME)).decode() != self.key:
            e.acceptProposedAction()
        elif hasattr(self, "accept_files"):
            self.accept_files[0](e)

    def dragMoveEvent(self, e):  # noqa: N802
        if e.mimeData().hasFormat(MIME):
            hint = self._side(e.position())
            if hint != self._hint:
                self._hint = hint
                self.update()
            e.acceptProposedAction()

    def dragLeaveEvent(self, _e):  # noqa: N802
        self._hint = None
        self.update()

    def dropEvent(self, e):  # noqa: N802
        if not e.mimeData().hasFormat(MIME):
            if hasattr(self, "accept_files"):
                self.accept_files[1](e)
            return
        key = bytes(e.mimeData().data(MIME)).decode()
        side = self._side(e.position())
        self._hint = None
        self.update()
        e.acceptProposedAction()
        QTimer.singleShot(0, lambda: self.ws.drop(key, self.key, side))


class Workspace(QWidget):
    """几个模块并排同屏。cols 是每一栏从上到下的模块名；栏宽、块高存在配置里。"""

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.panels: dict[str, Panel] = {}
        saved = ctx.cfg.get("workspace") if isinstance(ctx.cfg.get("workspace"), dict) else {}
        self.cols = self._clean(saved.get("cols"))
        self._sizes = (saved.get("w"), saved.get("h"))
        v = QVBoxLayout(self)
        tight = dense()
        v.setContentsMargins(*((14, 10, 14, 12) if tight else (20, 14, 20, 16)))
        v.setSpacing(8 if tight else 12)
        bar = _greeting(ctx, "工作台", "拖标题栏换位置（拖到一块的左右边会分出新的一栏），拖两块之间的缝改大小")
        self.add_btn = Btn("添加模块", "", "把一个模块放回工作台", "plus")
        self.add_btn.clicked.connect(self._add_menu)
        reset = Btn("恢复默认", "soft", "回到课件、习题台、观澜三栏的样子")
        reset.clicked.connect(lambda: QTimer.singleShot(0, self.reset))
        bar.addSpacing(8)
        bar.addWidget(reset)
        bar.addWidget(self.add_btn)
        v.addLayout(bar)
        self.split = None
        self._v = v
        self._rebuild(restore=True)

    @staticmethod
    def _clean(cols) -> list[list[str]]:
        seen, out = set(), []
        for col in cols if isinstance(cols, list) else []:
            keep = [k for k in col if isinstance(k, str) and k in SPEC and k not in seen] if isinstance(col, list) else []
            seen.update(keep)
            if keep:
                out.append(keep)
        return out[:MAX_COLS] or [list(c) for c in DEFAULT_WS]

    def where(self, key: str) -> tuple[int, int]:
        for c, col in enumerate(self.cols):
            if key in col:
                return c, col.index(key)
        return -1, -1

    def _rebuild(self, restore: bool = False) -> None:
        """按 cols 重搭分隔条。已经建好的模块直接挪过去（内容和输入都留着），新加的才建。"""
        split = QSplitter(Qt.Orientation.Horizontal)
        split.setChildrenCollapsible(False)
        split.setHandleWidth(12)
        hov = _tint(C.INK2, .18)
        split.setStyleSheet("QSplitter::handle{background:transparent;} QSplitter::handle:hover{background:"
                            f"rgba({hov.red()},{hov.green()},{hov.blue()},0.18);border-radius:4px;}}")
        for col in self.cols:
            cs = QSplitter(Qt.Orientation.Vertical)
            cs.setChildrenCollapsible(False)
            cs.setHandleWidth(12)
            cs.setStyleSheet(split.styleSheet())
            for key in col:
                p = self.panels.get(key)
                if p is None:
                    p = Panel(self.ctx, key, self)
                    _enable_file_drops(p)
                    self.panels[key] = p
                cs.addWidget(p)
            cs.splitterMoved.connect(lambda *_: self._save())
            split.addWidget(cs)
        split.splitterMoved.connect(lambda *_: self._save())
        old = self.split
        if old is not None:
            self._v.replaceWidget(old, split)
            old.hide()
            old.deleteLater()
        else:
            self._v.addWidget(split, 1)
        self.split = split
        w, h = self._sizes if restore else (None, None)
        if isinstance(w, list) and len(w) == len(self.cols):
            split.setSizes([int(x) for x in w])
        else:
            split.setSizes([1000] * len(self.cols))
        for i, col in enumerate(self.cols):
            cs = split.widget(i)
            hs = h[i] if isinstance(h, list) and i < len(h) else None
            cs.setSizes([int(x) for x in hs] if isinstance(hs, list) and len(hs) == len(col) else [1000] * len(col))
        self.add_btn.setEnabled(len(self.panels) < len(SPEC))

    def _save(self) -> None:
        if self.split is None:
            return
        self.ctx.cfg["workspace"] = dict(cols=[list(c) for c in self.cols], w=self.split.sizes(),
                                         h=[self.split.widget(i).sizes() for i in range(self.split.count())])
        self.ctx.save_soon()

    def _commit(self) -> None:
        self.cols = [c for c in self.cols if c]
        self._rebuild()
        self._save()

    # ---- 操作
    def move(self, key: str, col: int, idx: int) -> None:
        c, i = self.where(key)
        if c < 0 or not 0 <= col < len(self.cols):
            return
        self.cols[c].pop(i)
        if col == c and idx > i:
            idx -= 1
        self.cols[col].insert(max(0, min(idx, len(self.cols[col]))), key)
        self._commit()

    def move_new_col(self, key: str, at: int) -> None:
        c, i = self.where(key)
        if c < 0 or len(self.cols) >= MAX_COLS:
            return
        self.cols[c].pop(i)
        self.cols.insert(max(0, min(at, len(self.cols))), [key])
        self._commit()

    def drop(self, key: str, target: str, side: str) -> None:
        """把 key 拖到 target 的某一边：上下是同一栏里插前插后，左右是在旁边新开一栏。"""
        if key == target:
            return
        if key not in self.panels:
            return
        tc, ti = self.where(target)
        if tc < 0:
            return
        if side in ("left", "right") and len(self.cols) < MAX_COLS:
            c, i = self.where(key)
            self.cols[c].pop(i)
            tc, _ = self.where(target)
            self.cols.insert(tc if side == "left" else tc + 1, [key])
            self._commit()
            return
        c, i = self.where(key)
        self.cols[c].pop(i)
        tc, ti = self.where(target)
        self.cols[tc].insert(ti if side == "top" else ti + 1, key)
        self._commit()

    def remove(self, key: str) -> None:
        c, i = self.where(key)
        if c < 0 or sum(len(col) for col in self.cols) <= 1:
            self.ctx.toast("工作台上至少留一块")
            return
        self.cols[c].pop(i)
        p = self.panels.pop(key, None)
        if p is not None:
            p.hide()
            p.deleteLater()
        self._commit()

    def add(self, key: str) -> None:
        if key in self.panels or key not in SPEC:
            return
        if len(self.cols) < MAX_COLS and len(self.cols) < 3:
            self.cols.append([key])
        else:
            min(self.cols, key=len).append(key)
        self._commit()

    def reset(self) -> None:
        for key in list(self.panels):
            if not any(key in col for col in DEFAULT_WS):
                p = self.panels.pop(key)
                p.hide()
                p.deleteLater()
        self.cols = [list(c) for c in DEFAULT_WS]
        self._rebuild()
        self._save()

    def _add_menu(self) -> None:
        menu = QMenu(self)
        left = [k for k in ORDER if k not in self.panels]
        for k in left:
            menu.addAction(SPEC[k]["name"], lambda k=k: QTimer.singleShot(0, lambda: self.add(k)))
        if not left:
            menu.addAction("全部模块都在工作台上了").setEnabled(False)
        menu.exec(self.add_btn.mapToGlobal(self.add_btn.rect().bottomLeft()))
