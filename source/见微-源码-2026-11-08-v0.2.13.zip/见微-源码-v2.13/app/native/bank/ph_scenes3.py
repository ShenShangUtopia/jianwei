"""物理场景（三）：匀强磁场、导体棒切割、卫星变轨、简谐运动、凸透镜成像、双缝干涉。"""
from __future__ import annotations

import math

from PySide6.QtCore import QRectF
from PySide6.QtGui import QColor, QPainterPath

from ..design.tokens import alpha, qc
from ..kit.core import clamp
from ..kit.draw import D
from .ph_core import (INF, PI, TAU, Chip, Scene, bars_panel, cos, dot, fill_circle, fmt, frame_panel, label, nice, on_color, p_arrow, p_flow, path_point, path_table, plabel,
                      polyline, rad, ring_world, scene, sin, sqrt, stroke_arc, tag_box, vec, view_rect)
from .sb_core import C


@scene("magnet")
class Magnet(Scene):
    sliders = [("B", "磁感应强度 B (T)", 0.8, 3.2, 0.1, 1), ("v", "速率 v (m/s)", 1, 3.2, 0.1, 1), ("vp", "轴向速度 v∥ (m/s)", 0, 2, 0.1, 1)]
    hints = ["洛伦兹力 F = qvB 始终与速度垂直，只改变方向、不做功。", "正电荷绕行方向由右手定则判断，负电荷反向；半径 r = mv/(qB)。", "若速度还有沿 B 的分量 v∥，圆周运动叠加匀速直线，轨迹变成螺旋。"]
    hot = [[0, 1], [2], [0, 1, 2, 3]]
    qsign = 1

    def defaults(self):
        return dict(B=2, v=2, vp=0.4)

    def make_chips(self):
        return [Chip("电荷正负", ["正电荷", "负电荷"], lambda i: setattr(self, "qsign", -1 if i else 1))]

    def r_of(self):
        return max(0.08, self.P.v / max(abs(self.P.B), 0.05))

    def duration(self):
        return TAU / max(abs(self.P.B), 0.05)

    def draw(self, cv, t, lv):
        P, q = self.P, self.qsign
        r, th = self.r_of(), -q * abs(P.B) * t
        x, y = r * cos(th), r * sin(th)
        half = max(r * 1.3, 0.55)
        view_rect(cv, -half, half, -half, half, 0.01, True)
        cv.grid(nice(r * 2.4), False, C.grid2)
        ring_world(cv, 0, 0, r, C.data[2], 1.1, [4, 5])
        g = cv.g
        base = qc(C.data[2])
        X = 22
        while X < cv.w - 12:   # 垂直纸面向外的磁感线：点阵
            Y = 46
            while Y < cv.h - 46:
                col = alpha(base, 0.15 + 0.06 * sin(t * 1.7 + X * 0.03 + Y * 0.02))
                D.circle(g, X, Y, 3.2, None, col, 1)
                D.circle(g, X, Y, 1.1, col)
                Y += 38
            X += 42
        for k in range(38, 0, -1):
            thp = th + q * 0.135 * k
            fill_circle(cv, cv.px(r * cos(thp)), cv.py(r * sin(thp)), max(1, 2.6 * (1 - k / 52)), C.accent, 0.42 * (1 - k / 42))
        if lv >= 1:
            ln = r * 0.55
            vec(cv, x, y, q * sin(th) * ln, -q * cos(th) * ln, C.accent, 1.9, "v")
            vec(cv, x, y, -x / max(r, 1e-6) * r * 0.42, -y / max(r, 1e-6) * r * 0.42, C.jade, 1.9, "F")
        dot(cv, 0, 0, 1.8, C.faint)
        fill_circle(cv, cv.px(x), cv.py(y), 11, C.accent, 0.14)
        dot(cv, x, y, 5.2, C.ink, C.paper, 1.5)
        if lv >= 2:
            cv.line(0, 0, x, y, C.data[2], 1, [4, 4])
            label(cv, x * 0.5, y * 0.5, f"r = {fmt(r, 2)} m", C.ink2, 10, align="center", oy=-9)
        tag_box(cv, cv.w * 0.5, 18, "· B 垂直纸面向外", C.ink2, "center")
        if P.vp > 0.05:
            X0, Y0, W, H = 14, cv.h - 164, 206, 132
            D.text(g, "沿 B 方向的螺旋运动", X0 + 2, Y0 + 8, C.faint, size=9, bold=True)
            ra, span, cx, cy = min(13, H * 0.15), W - 26, X0 + 12, Y0 + 84
            dash_col = alpha(base, 0.35)
            D.line(g, cx, cy - ra, cx + span, cy - ra, dash_col, 1, [3, 5])
            D.line(g, cx, cy + ra, cx + span, cy + ra, dash_col, 1, [3, 5])
            for zx in (0, span):   # 两端圆截面：把投影读成圆柱上的螺旋
                g.begin_path()
                g.ellipse(cx + zx, cy, ra * 1.12, ra)
                g.p.strokePath(g.path, g._pen(dash_col, 1, [3, 5]))
            # 前半圈亮、后半圈暗：按 sin(角) 分两条路径描
            front, back_ = QPainterPath(), QPainterPath()
            prev = None
            for i in range(201):
                u = i / 200
                a = TAU * 6 * u
                p = (cx + span * u + cos(a) * ra * 1.12, cy + sin(a) * ra)
                if prev:
                    path = front if sin(a) > 0 else back_
                    path.moveTo(*prev)
                    path.lineTo(*p)
                prev = p
            g.p.strokePath(back_, g._pen(alpha(base, 0.42), 1.45, []))
            g.p.strokePath(front, g._pen(alpha(base, 0.9), 1.45, []))
            u = (t / self.duration()) % 1
            a = TAU * 6 * u
            D.circle(g, cx + span * u + cos(a) * ra * 1.12, cy + sin(a) * ra, 3.8, C.accent)
            p_arrow(cv, cx + span * 0.62, Y0 + H - 7, cx + span * 0.62 + 22, Y0 + H - 7, C.ink2, 1, 5)
            plabel(cv, cx + span * 0.62 + 26, Y0 + H - 8, "v∥", C.ink2, 9.5)
        elif lv >= 2:
            tag_box(cv, 14, cv.h - 42, "v∥ = 0 → 圆轨道", C.soft)

    def readouts(self, t):
        T = self.duration()
        return [("轨道半径 r", fmt(self.r_of(), 2), "m"), ("回旋周期 T", fmt(T, 2), "s"), ("速率 v", fmt(self.P.v, 2), "m/s"), ("螺旋螺距", fmt(self.P.vp * T, 2), "m")]

    def status(self, t):
        return ("螺旋运动" if self.P.vp > 0.05 else "匀速圆周") + " · " + ("顺时针" if self.qsign > 0 else "逆时针")


@scene("induction")
class Induction(Scene):
    sliders = [("B", "磁感应强度 B (T)", 0.2, 1, 0.05, 2), ("L", "导体棒长 L (m)", 0.5, 1.2, 0.05, 2), ("v", "切割速度 v (m/s)", 0.4, 2, 0.1, 1), ("R", "外电阻 R (Ω)", 1, 8, 0.2, 1)]
    hints = ["导体棒切割磁感线，回路面积增大，磁通量 Φ = BLx 随之改变。", "法拉第定律 E = ΔΦ/Δt = BLv，感应电流 I = E/(R + r)。", "楞次定律：感应电流的磁场总要阻碍原磁通量的变化。"]
    hot = [[1], [0, 2], [0, 1, 2, 3]]
    SPAN, RIN = 2.4, 0.4

    def defaults(self):
        return dict(B=0.6, L=0.8, v=1.2, R=3)

    def duration(self):
        return 2 * self.SPAN / max(self.P.v, 0.05)

    def state(self, t):
        P = self.P
        u = t / self.duration() * 2
        f = u if u < 1 else 2 - u
        emf = P.B * P.L * P.v
        return f, 1 if u < 1 else -1, emf, emf / (P.R + self.RIN), P.B * P.L * self.SPAN * f

    def draw(self, cv, t, lv):
        P, g, w, h = self.P, cv.g, cv.w, cv.h
        f, dr, emf, I, flux = self.state(t)
        xL, xE, yT, yB = w * 0.10, w * 0.80, h * 0.18, h * 0.72
        rx = xL + f * (xE - xL)
        fill = qc(C.data[4])
        g.p.fillRect(QRectF(xL, yT, xE - xL, yB - yT), alpha(fill, fill.alphaF() * 0.4))
        g.p.fillRect(QRectF(xL, yT, rx - xL, yB - yT), alpha(fill, fill.alphaF() * 1.6))
        base = qc(C.data[2])
        X = xL + 18
        while X < xE - 6:   # 垂直纸面向里的磁感线：叉号
            Y = yT + 20
            while Y < yB - 8:
                col = alpha(base, 0.22 + 0.1 * sin(t * 2 + X * 0.03 + Y * 0.02))
                D.line(g, X - 4, Y - 4, X + 4, Y + 4, col, 1.1)
                D.line(g, X + 4, Y - 4, X - 4, Y + 4, col, 1.1)
                Y += 32
            X += 30
        for a, b in (((xL, yT), (xE, yT)), ((xL, yB), (xE, yB)), ((xL, yT), (xL, yB))):
            D.line(g, a[0], a[1], b[0], b[1], C.ink2, 2.4)
        cw = [(xL, yT), (rx, yT), (rx, yB), (xL, yB), (xL, yT)]
        path = list(reversed(cw)) if dr > 0 else cw
        tab = path_table(path)
        phase = (t * (0.35 + 1.9 * I)) % 1
        p_flow(cv, path, C.accent, [4, 9], (t * 34) % 13, 1.8, 0.75)
        for i in range(10):
            p = path_point(path, tab, (phase + i / 10) % 1)
            D.circle(g, p[0], p[1], 2.6, C.accent)
        top = -1 if dr > 0 else 1
        mid = (xL + rx) / 2
        p_arrow(cv, mid - top * 12, yT, mid + top * 18, yT, C.accent, 1.6, 7)
        p_arrow(cv, mid + top * 12, yB, mid - top * 18, yB, C.accent, 1.6, 7)
        plabel(cv, mid, yT - 13, "I", C.accent, 10, align="center", weight=700)
        D.rrect(g, rx - 3, yT - 3, 6, yB - yT + 6, 3, C.accent)
        p_arrow(cv, rx + 10, (yT + yB) / 2, rx + 10 + 34 * dr, (yT + yB) / 2, C.accent, 2, 8)
        plabel(cv, rx + (18 if dr > 0 else -18), (yT + yB) / 2 - 13, f"v = {fmt(P.v, 1)} m/s", C.accent, 10.5, weight=700, align="left" if dr > 0 else "right")
        if lv >= 1:
            plabel(cv, mid, yT + 16, f"Φ = {fmt(flux, 2)} Wb", C.ink2, 10, align="center")
            plabel(cv, xL + 4, yB + 16, f"B = {fmt(P.B, 2)} T　L = {fmt(P.L, 2)} m", C.soft, 10, weight=500)
        tag_box(cv, w * 0.5, 18, "导体棒切割磁感线 · E = BLv", C.ink2, "center")
        xA, rA = xL + (xE - xL) * 0.2, 19
        D.circle(g, xA, yB, rA, C.card, C.ink2, 1.6)
        stroke_arc(cv, xA, yB, rA - 5, -PI / 2 - 0.85, -PI / 2 + 0.85, C.faint, 1)
        na = -PI / 2 + clamp(I / 0.9, 0, 1) * 0.95 * dr
        D.line(g, xA, yB, xA + cos(na) * (rA - 7), yB + sin(na) * (rA - 7), C.accent, 2)
        D.circle(g, xA, yB, 2, C.ink)
        plabel(cv, xA, yB + rA + 11, f"A　{fmt(I, 3)} A", C.ink2, 10, align="center")
        if lv >= 2:
            X0, Y0 = 14, h - 122
            fp = frame_panel(cv, X0, Y0, min(330, w * 0.46), 90, "法拉第电磁感应定律")
            plabel(cv, X0 + 10, fp.y + 4, f"E = BLv = {fmt(emf, 3)} V", C.ink, 11)
            plabel(cv, X0 + 10, fp.y + 22, f"I = E/(R+r) = {fmt(I, 3)} A", C.ink2, 10.5)
            plabel(cv, X0 + 10, fp.y + 40, f"Φ = BLx = {fmt(flux, 2)} Wb", C.ink2, 10)
            plabel(cv, X0 + 10, fp.y + 58, "磁通增大 → 电流逆时针" if dr > 0 else "磁通减小 → 电流顺时针", C.accent, 10)

    def readouts(self, t):
        _f, _d, emf, I, flux = self.state(t)
        return [("磁通量 Φ", fmt(flux, 2), "Wb"), ("电动势 E", fmt(emf, 3), "V"), ("感应电流 I", fmt(I, 3), "A"), ("电功率 P", fmt(emf * I, 3), "W")]

    def status(self, t):
        f, dr, *_r = self.state(t)
        if f < 0.02:
            return "在最左端 · 即将向右"
        if f > 0.98:
            return "在最右端 · 即将向左"
        return "向右切割 · 磁通增大" if dr > 0 else "向左切割 · 磁通减小"


@scene("gravity2")
class Gravity2(Scene):
    sliders = [("r1", "低轨半径 r₁ (km)", 8000, 14000, 200, 0), ("r2", "高轨半径 r₂ (km)", 12000, 22000, 200, 0)]
    hints = ["卫星做圆周运动时，万有引力提供向心力：GMm/r² = mv²/r。", "在低轨加速，速度超过该高度圆轨道速度，轨道拉长成椭圆；到远地点再加速即可圆化。", "开普勒第二定律：卫星与地心连线在相等时间内扫过相等面积，所以近地点快、远地点慢。"]
    hot = [[0, 1], [2], [0, 1, 3]]
    GM, RE = 398600.4418, 6371
    mode = 0

    def __init__(self):
        self._key, self._d = None, None
        super().__init__()

    def defaults(self):
        return dict(r1=11000, r2=15000)

    def make_chips(self):
        return [Chip("轨道任务", ["椭圆变轨", "圆轨道"], lambda i: setattr(self, "mode", i))]

    def build(self):
        P, GM, RE = self.P, self.GM, self.RE
        key = (P.r1, P.r2, self.mode)
        if key == self._key:
            return self._d
        self._key = key
        r1 = max(P.r1, RE + 1200)
        r2 = max(P.r2, r1 + 800)
        T1, T2 = TAU * sqrt(r1 ** 3 / GM), TAU * sqrt(r2 ** 3 / GM)
        aT = (r1 + r2) / 2
        Ttr = PI * sqrt(aT ** 3 / GM)
        bt = [0, 0, 0, 0]
        total = T1
        if self.mode == 0:
            bt[0] = 0.20 * T1
            bt[1] = bt[0] + Ttr
            bt[2] = bt[1] + 0.20 * T2
            bt[3] = bt[2] + Ttr
            total = bt[3] + 0.60 * T1
        N = 1500
        dt = total / N
        x, y, vx, vy = r1, 0.0, 0.0, sqrt(GM / r1)
        pts, burn = [], [-1, -1, -1, -1]
        for i in range(N + 1):
            tt = i * dt
            if self.mode == 0:
                for b in range(4):
                    if burn[b] < 0 and tt >= bt[b] - 1e-9:
                        burn[b] = i
                        rr = sqrt(x * x + y * y)
                        sp = sqrt(vx * vx + vy * vy) or 1
                        target = sqrt(GM / rr) if b in (1, 3) else sqrt(GM * (2 / rr - 1 / aT))
                        vx *= target / sp
                        vy *= target / sp
            pts.append((x, y, vx, vy))
            rr = sqrt(x * x + y * y) or 1
            ax, ay = -GM * x / rr ** 3, -GM * y / rr ** 3
            x += vx * dt + 0.5 * ax * dt * dt
            y += vy * dt + 0.5 * ay * dt * dt
            rn = sqrt(x * x + y * y) or 1
            vx += 0.5 * (ax - GM * x / rn ** 3) * dt
            vy += 0.5 * (ay - GM * y / rn ** 3) * dt
        self._d = dict(pts=pts, N=N, total=total, dt=dt, burn=burn, r1=r1, r2=r2, aT=aT)
        return self._d

    def idx(self, t):
        return int(clamp(round(t / 12 * self.build()["N"]), 0, self.build()["N"]))

    def duration(self):
        return 12

    def draw(self, cv, t, lv):
        d = self.build()
        pts, burn, g = d["pts"], d["burn"], cv.g
        idx = self.idx(t)
        px_, py_, vx, vy = pts[idx]
        v_now = sqrt(vx * vx + vy * vy) / 1000
        half = max(d["r2"], d["r1"]) * 1.32
        view_rect(cv, -half, half, -half, half, 0.01, True)
        cv.grid(nice(half * 2), False, C.grid2)
        polyline(cv, pts[::4] + [pts[-1]], C.data[3], 1.1, [3, 6], 0.75)
        polyline(cv, pts[max(0, idx - 110):idx + 1], C.accent, 1.8, None, 0.85)
        O = (cv.px(0), cv.py(0))
        if self.mode == 0:
            base2, base4 = qc(C.data[2]), qc(C.data[4])
            for i0, i1 in ((burn[0], burn[1]), (burn[2], burn[3])):
                if i0 < 0 or i1 <= i0:
                    continue
                n_w = 10
                for k in range(n_w):   # 等时间扇形：开普勒第二定律
                    a = round(i0 + (i1 - i0) * k / n_w)
                    b = round(i0 + (i1 - i0) * (k + 1) / n_w)
                    if idx < a:
                        continue
                    end = min(idx, b)
                    poly = [O] + [(cv.px(pts[j][0]), cv.py(pts[j][1])) for j in range(a, end + 1)]
                    al = (0.22 if lv >= 1 else 0.12) if idx >= b else (0.11 if lv >= 1 else 0.05)
                    D.poly(g, poly, alpha(base2 if k % 2 else base4, al))
                if lv >= 1:
                    for k in range(n_w + 1):
                        q = pts[round(i0 + (i1 - i0) * k / n_w)]
                        D.line(g, O[0], O[1], cv.px(q[0]), cv.py(q[1]), alpha(base2, 0.35), 0.8)
            for bi in burn:
                if bi < 0:
                    continue
                q = pts[bi]
                ds = (idx - bi) * d["dt"]
                if 0 <= ds < 2200:
                    k = ds / 2200
                    stroke_arc(cv, cv.px(q[0]), cv.py(q[1]), 6 + 26 * k, 0, TAU, C.accent, 1.6, 1 - k)
                if lv >= 1:
                    D.circle(g, cv.px(q[0]), cv.py(q[1]), 3, C.accent)
        D.circle(g, O[0], O[1], self.RE * cv.sx(), C.data[3], C.data[2], 1.4)   # 地球最后画，盖住扇形内部
        label(cv, 0, 0, "地球", C.ink2, 10, align="center", halo=False, weight=700)
        fill_circle(cv, cv.px(px_), cv.py(py_), 9, C.accent, 0.16)
        dot(cv, px_, py_, 4.6, C.ink, C.paper, 1.5)
        if lv >= 1:
            sc = half * 0.17 / max(v_now, 1e-6)
            vec(cv, px_, py_, vx / 1000 * sc, vy / 1000 * sc, C.accent, 1.8, "v", 10)
            cv.line(0, 0, px_, py_, C.data[2], 1, [4, 5])
            label(cv, px_ * 0.5, py_ * 0.5, "r", C.soft, 9.5, align="center", oy=-8, weight=500)
        if lv >= 2:
            tag_box(cv, cv.w * 0.5, 18, "等时间内扫过相等面积", C.ink2, "center")
            fp = frame_panel(cv, 14, cv.h - 110, min(292, cv.w * 0.45), 78, "开普勒第二定律")
            plabel(cv, 24, fp.y + 4, f"a = (r₁ + r₂)/2 = {fmt(d['aT'], 0)} km", C.ink, 10.5)
            plabel(cv, 24, fp.y + 22, "T = 2π√(a³/GM)", C.ink2, 10)
            plabel(cv, 24, fp.y + 40, "近地点快 · 远地点慢", C.accent, 10)
        elif lv == 0:
            tag_box(cv, cv.w * 0.5, 18, "卫星绕地球运行", C.soft, "center")

    def readouts(self, t):
        d = self.build()
        i = self.idx(t)
        x, y, vx, vy = d["pts"][i]
        r, b = sqrt(x * x + y * y), d["burn"]
        trans = self.mode == 0 and (b[0] <= i < b[1] or b[2] <= i < b[3])
        return [("当前半径 r", fmt(r, 0), "km"), ("轨道速度 v", fmt(sqrt(vx * vx + vy * vy), 2), "km/s"), ("半长轴 a", fmt(d["aT"] if trans else r, 0), "km"), ("面积速率", fmt(0.5 * abs(x * vy - y * vx), 0), "km²/s")]

    def status(self, t):
        if self.mode == 1:
            return "圆轨道 · 匀速圆周运动"
        b, i = self.build()["burn"], self.idx(t)
        if i < b[0]:
            return "低轨圆轨道 · 准备加速"
        if i < b[1]:
            return "近地点加速 · 转移椭圆"
        if i < b[2]:
            return "高轨圆轨道 · 远地点加速完成"
        if i < b[3]:
            return "远地点减速 · 返回椭圆"
        return "回到低轨 · 圆轨道"


@scene("shm")
class Shm(Scene):
    sliders = [("A", "振幅 A (m)", 0.05, 0.35, 0.01, 2), ("m", "质量 m (kg)", 0.5, 2, 0.1, 1), ("k", "劲度系数 k (N/m)", 8, 30, 1, 0), ("L", "摆长 L (m)", 0.4, 1.6, 0.05, 2)]
    hints = ["简谐运动：回复力与位移成正比、方向相反，F = −kx（或 −mg sinθ）。", "动能与势能相互转化，机械能守恒；端点处速度为零、加速度最大。", "弹簧周期 T = 2π√(m/k)，单摆小角度周期 T = 2π√(L/g)。"]
    hot = [[0, 2], [1], [0, 1, 2, 3]]
    mode = 0
    G_ = 9.8

    def defaults(self):
        return dict(A=0.22, m=1, k=16, L=1.0)

    def make_chips(self):
        return [Chip("振动模型", ["弹簧振子", "单摆"], lambda i: setattr(self, "mode", i))]

    def omega(self):
        P = self.P
        return sqrt(P.k / max(P.m, 0.01)) if self.mode == 0 else sqrt(self.G_ / max(P.L, 0.05))

    def period(self):
        return TAU / self.omega()

    def duration(self):
        return max(0.6, self.period())

    def state(self, t):
        P = self.P
        w = self.omega()
        ph = w * t
        if self.mode == 0:
            x = P.A * cos(ph)
            v = -P.A * w * sin(ph)
            KE, PE = 0.5 * P.m * v * v, 0.5 * P.k * x * x
            return dict(x=x, v=v, a=-w * w * x, KE=KE, PE=PE, E=KE + PE, thmax=0, ang=0, wv=0)
        thmax = min(rad(32), P.A / max(P.L, 0.1))
        ang, wv = thmax * cos(ph), -thmax * w * sin(ph)
        v = wv * P.L
        KE, PE = 0.5 * P.m * v * v, P.m * self.G_ * P.L * (1 - cos(ang))
        return dict(x=0, ang=ang, v=v, wv=wv, a=0, KE=KE, PE=PE, E=KE + PE, thmax=thmax)

    def draw(self, cv, t, lv):
        P, g, w, h = self.P, cv.g, cv.w, cv.h
        st, T, om = self.state(t), self.period(), self.omega()
        lw, rx, rw = w * 0.63, w * 0.655, w * 0.325
        g.p.fillRect(QRectF(0, 0, lw, h), alpha(qc(C.data[2]), 0.05))
        # 参考圆：把简谐运动画成旋转矢量在 x 轴上的投影
        pr, pcx, pcy = min(58, h * 0.10), lw * 0.21, h * 0.37
        ph = -om * t
        stroke_arc(cv, pcx, pcy, pr, 0, TAU, C.data[2], 1.2, 0.6, [3, 4])
        D.line(g, pcx - pr - 6, pcy, pcx + pr + 6, pcy, C.line2, 1)
        D.line(g, pcx, pcy - pr - 6, pcx, pcy + pr + 6, C.line2, 1)
        X, Y = pcx + cos(ph) * pr, pcy + sin(ph) * pr
        D.line(g, pcx, pcy, X, Y, C.data[2], 1.8)
        D.line(g, X, Y, X, pcy, C.faint, 1, [3, 4])
        D.circle(g, X, Y, 4, C.accent)
        if lv >= 1:
            plabel(cv, pcx, pcy + pr + 14, "参考圆 · 投影即 x" if self.mode == 0 else "参考圆 · 投影即 θ", C.faint, 9, align="center", weight=500)
        if self.mode == 0:
            fy, wall, eq = h * 0.68, w * 0.055, lw * 0.58
            amp = lw * 0.30
            bx = eq + st["x"] * amp / max(P.A, 0.02)
            D.line(g, wall, fy, lw * 0.96, fy, C.line, 2.2)
            D.rect(g, wall - 10, fy - h * 0.34, 10, h * 0.34, C.data[3], C.data[2], 1.2)
            x1, x2, y0 = wall, bx - 19, fy - 25
            if x2 - x1 >= 8:
                n, stp = 26, (x2 - x1) / 28
                coil = [(x1, y0), (x1 + stp, y0)] + [(x1 + stp * (i + 1.5), y0 + (-9 if i % 2 else 9)) for i in range(n)] + [(x2 - stp, y0), (x2, y0)]
                D.poly(g, coil, None, C.data[2], 1.5, False)
            D.rect(g, bx - 19, fy - 44, 38, 38, C.ink, C.paper, 1.5)
            D.text(g, "m", bx, fy - 25, on_color(C.ink), size=11, bold=True, align="center")
            D.line(g, eq, fy - 74, eq, fy + 8, C.data[3], 1, [4, 5])
            D.line(g, eq - amp, fy + 10, eq - amp, fy + 16, C.data[3], 1)
            D.line(g, eq + amp, fy + 10, eq + amp, fy + 16, C.data[3], 1)
            plabel(cv, eq, fy + 16, "平衡位置", C.faint, 9.5, align="center", weight=500)
            plabel(cv, eq - amp, fy + 31, "−A", C.soft, 9.5, align="center")
            plabel(cv, eq + amp, fy + 31, "+A", C.soft, 9.5, align="center")
            if lv >= 1:
                vl = 42 * clamp(st["v"] / max(P.A * om, 1e-6), -1, 1)
                p_arrow(cv, bx, fy - 56, bx + vl, fy - 56, C.accent, 2, 7)
                plabel(cv, bx + (6 if vl >= 0 else -6), fy - 68, "v", C.accent, 10.5, weight=700, align="left" if vl >= 0 else "right")
                fl = 38 * clamp(-st["x"] / max(P.A, 1e-6), -1, 1)
                p_arrow(cv, bx, fy - 88, bx + fl, fy - 88, C.jade, 2, 7)
                plabel(cv, bx + (6 if fl >= 0 else -6), fy - 100, "F", C.jade, 10.5, weight=700, align="left" if fl >= 0 else "right")
            if lv >= 2:
                D.line(g, eq, fy + 44, bx, fy + 44, C.gold, 1, [4, 4])
                plabel(cv, (eq + bx) / 2, fy + 57, f"x = {fmt(st['x'], 3)} m", C.gold, 10, align="center")
                tag_box(cv, lw * 0.48, 18, f"T = 2π√(m/k) = {fmt(T, 2)} s", C.ink2, "center")
        else:
            px0, py0, Lp = lw * 0.58, h * 0.19, h * 0.40
            thmax, ang = st["thmax"], st["ang"]
            bx, by = px0 + Lp * sin(ang), py0 + Lp * cos(ang)
            a_pts = [(px0 + Lp * sin(-thmax + 2 * thmax * i / 40), py0 + Lp * cos(-thmax + 2 * thmax * i / 40)) for i in range(41)]
            p_flow(cv, a_pts, C.data[3], [4, 5], 0, 1)
            D.line(g, px0, py0, bx, by, C.ink2, 1.6)
            D.circle(g, px0, py0, 4, C.ink)
            D.circle(g, bx, by, 17, C.ink, C.paper, 1.5)
            D.text(g, "m", bx, by, on_color(C.ink), size=11, bold=True, align="center")
            plabel(cv, (px0 + bx) / 2 + 10, (py0 + by) / 2, f"L = {fmt(P.L, 2)} m", C.soft, 9.5, weight=500)
            if lv >= 1:
                tang = 1 if (st["wv"] or 1) > 0 else -1
                tx, ty = cos(ang) * tang, -sin(ang) * tang
                vl = 46 * clamp(abs(st["v"]) / max(thmax * om * P.L, 1e-6), 0, 1)
                p_arrow(cv, bx, by, bx + tx * vl, by + ty * vl, C.accent, 2, 7)
                plabel(cv, bx + tx * (vl + 10), by + ty * (vl + 10), "v", C.accent, 10.5, weight=700)
                p_arrow(cv, bx, by, bx, by + 38, C.jade, 1.8, 7)
                plabel(cv, bx + 7, by + 46, "mg", C.jade, 9.5)
                arc = [(px0 + 34 * sin(ang * i / 16), py0 + 34 * cos(ang * i / 16)) for i in range(17)]
                p_flow(cv, arc, C.data[2], None, 0, 1)
                plabel(cv, px0 + (42 if ang >= 0 else -42), py0 + 30, "θ", C.data[2], 10, align="center")
            if lv >= 2:
                plabel(cv, px0, py0 - 12, f"θ = {fmt(math.degrees(ang), 1)}°", C.gold, 10, align="center")
                tag_box(cv, lw * 0.48, 18, f"T = 2π√(L/g) = {fmt(T, 2)} s", C.ink2, "center")
        E = st["E"]
        bars_panel(cv, rx, h * 0.10, rw, [("动能", f"{fmt(st['KE'], 2)} J", st["KE"] / E if E > 1e-9 else 0, C.ink), ("势能", f"{fmt(st['PE'], 2)} J", st["PE"] / E if E > 1e-9 else 0, C.data[2]),
                                          ("机械能", f"{fmt(E, 2)} J", 1, C.data[3])], "能量（弹簧）" if self.mode == 0 else "能量（单摆）")
        gp = frame_panel(cv, rx, h * 0.43, rw, h * 0.44, "x–t 同步图" if self.mode == 0 else "θ–t 同步图")
        mid, amp2 = gp.y + gp.h * 0.52, gp.h * 0.36
        amax = max(P.A, 1e-6) if self.mode == 0 else max(st["thmax"], 1e-6)
        D.line(g, gp.x, mid, gp.x + gp.w, mid, C.line, 1, [3, 4])
        key = "x" if self.mode == 0 else "ang"
        curve = [(gp.x + gp.w * i / 140, mid - self.state(t - 2 * T + 2 * T * i / 140)[key] / amax * amp2) for i in range(141)]
        p_flow(cv, curve, C.ink2, None, 0, 1.8, 0.95)
        D.line(g, gp.x + gp.w, gp.y, gp.x + gp.w, gp.y + gp.h, C.accent, 1, [3, 4])
        D.circle(g, gp.x + gp.w, mid - st[key] / amax * amp2, 3.8, C.accent)
        plabel(cv, gp.x + 2, mid - amp2 - 5, "+A" if self.mode == 0 else "+θ", C.faint, 8.5, weight=500)
        plabel(cv, gp.x + gp.w - 2, gp.y + gp.h - 5, "-2T", C.faint, 8.5, align="right", weight=500)
        plabel(cv, gp.x + gp.w - 2, gp.y + 2, "现在", C.accent, 8.5, align="right", weight=500)
        if lv >= 2:
            plabel(cv, gp.x + 2, gp.y + gp.h - 5, "x = A cos(ωt)" if self.mode == 0 else "θ = θ₀ cos(ωt)", C.soft, 9, weight=500)

    def readouts(self, t):
        st = self.state(t)
        return [("周期 T", fmt(self.period(), 2), "s"), ("位移 x", fmt(st["x"], 3), "m") if self.mode == 0 else ("角位移 θ", fmt(math.degrees(st["ang"]), 1), "°"), ("速度 v", fmt(st["v"], 2), "m/s"), ("机械能 E", fmt(st["E"], 2), "J")]

    def status(self, t):
        st, P = self.state(t), self.P
        if self.mode == 0:
            edge, right, accel = abs(st["x"]) > P.A * 0.96, st["v"] > 0, st["v"] * st["a"] > 0
        else:
            edge, right, accel = abs(st["ang"]) > st["thmax"] * 0.96, st["wv"] > 0, st["v"] * -st["ang"] > 0
        if edge:
            return "端点 · 速度为零、回复力最大"
        return ("向右" if right else "向左") + (" · 加速" if accel else " · 减速") + " · 平衡位置附近最快"


@scene("lens")
class Lens(Scene):
    sliders = [("u", "物距 u (m)", 0.3, 2.6, 0.05, 2), ("f", "焦距 f (m)", 0.3, 1, 0.05, 2), ("h", "物高 h (m)", 0.15, 0.5, 0.01, 2)]
    hints = ["凸透镜三条特殊光线：平行主轴的光线过焦点，过光心的光线不改变方向，过焦点的光线出射后平行主轴。", "成像公式 1/f = 1/u + 1/v，放大率 m = −v/u（实像倒立、虚像正立）。", "u > f 成倒立实像；u < f 成正立放大虚像，光屏接不到，只能透过透镜看到。"]
    hot = [[0, 1], [2], [3]]

    def defaults(self):
        return dict(f=0.55, h=0.3, u=1.3)

    def duration(self):
        return 8

    def u_now(self, t):
        return max(0.18, self.P.u * (1 + 0.15 * sin(TAU * t / 8)))

    def optics(self, u):
        f = max(self.P.f, 0.15)
        near = abs(u - f) < 0.035
        v = INF if near else u * f / (u - f)
        return f, v, near, 0 if near else -v / u * self.P.h

    def draw(self, cv, t, lv):
        P, g = self.P, cv.g
        u = self.u_now(t)
        f, v, near, hi = self.optics(u)
        h = P.h
        v_show = 0 if near else clamp(v, -6.5, 6.5)
        far = not near and (abs(v) > 6.5 or abs(hi) > 3.2)
        y3 = h if near else clamp(h * f / (f - u), -1.4, 1.4)
        a = clamp(max(abs(y3), h * 1.25, 0.42), 0.42, 1.4)
        xL, xR = min(-u * 1.18, -f * 1.35) - 0.15, max(0.8, f * 1.45, h * 1.2)
        if not near and v > 0 and not far:
            xR = max(xR, v * 1.10)
        if not near and v < 0 and not far:
            xL = min(xL, v * 1.12)
        yH = max(a * 1.10, h * 1.12, 0.40, abs(hi) * 1.06 if (not far and not near and v < 0) else 0)
        view_rect(cv, xL, xR, -yH, yH, 0.02, True)
        cv.grid(0.2, False, C.grid2)
        cv.line(cv.xr[0], 0, cv.xr[1], 0, C.line, 1.6)
        label(cv, cv.xr[0], 0, "主光轴", C.faint, 9, ox=8, oy=-8, weight=500)
        lx, top, bot, y0 = cv.px(0), cv.py(a), cv.py(-a), cv.py(0)
        bulge = clamp(cv.sx() * 0.09, 8, 22)
        g.begin_path()
        g.move_to(lx, top)
        g.quad_to(lx + bulge, y0, lx, bot)
        g.quad_to(lx - bulge, y0, lx, top)
        g.close_path()
        g.p.fillPath(g.path, alpha(qc(C.data[2]), 0.18))
        g.p.strokePath(g.path, g._pen(C.data[2], 1.6, []))
        for fx, nm in ((-f, "F"), (f, "F′")):
            X = cv.px(fx)
            D.line(g, X, y0 - 4, X, y0 + 4, C.faint, 1)
            plabel(cv, X, y0 + 14, nm, C.soft, 9.5, align="center")
        xE = cv.xr[1] - 0.02
        ray1 = [(-u, h), (0, h), (xE, h - h * xE / f)]
        ray2 = [(-u, h), (0, 0), (xE, -h * xE / u)]
        polyline(cv, ray1, C.data[2], 1.35)
        polyline(cv, ray2, C.jade, 1.25)
        if not near:
            polyline(cv, [(-u, h), (0, y3), (xE, y3)], C.gold, 1.1)
        if lv >= 2 and not near and not far and v < 0:
            polyline(cv, [(0, h), (v_show, hi)], C.data[2], 1, [4, 4])
            polyline(cv, [(0, 0), (v_show, hi)], C.jade, 1, [4, 4])
            polyline(cv, [(0, y3), (v_show, y3)], C.gold, 1, [4, 4])
        ox, oy = cv.px(-u), cv.py(h)
        D.line(g, ox, y0, ox, oy, C.accent, 2.4)
        D.poly(g, [(ox - 5, oy + 7), (ox, oy), (ox + 5, oy + 7)], None, C.accent, 2.4, False)
        plabel(cv, ox + 8, oy - 8, "物", C.accent, 10, weight=700)
        if not near and not far:
            real = v > 0
            col = C.jade if real else C.gold
            ix, iy = cv.px(v_show), cv.py(hi)
            D.line(g, ix, y0, ix, iy, col, 2.2, None if real else [5, 4])
            dr = 1 if hi >= 0 else -1
            D.poly(g, [(ix - 5, iy + dr * 7), (ix, iy), (ix + 5, iy + dr * 7)], None, col, 2.2, False)
            right_side, left_side = ix > cv.w * 0.74, ix < cv.w * 0.24
            ly = cv.py(hi * 0.55) if left_side and not real else iy + (-9 if hi >= 0 else 15)
            plabel(cv, ix + (-8 if right_side else 8), ly, "实像" if real else "虚像", col, 10, weight=700, align="right" if right_side else "left")
        if near:
            tag_box(cv, cv.w * 0.5, cv.h * 0.38, "u ≈ f：像在无穷远", C.accent, "center")
        elif far:
            tag_box(cv, cv.w * 0.5, cv.h * 0.38, "像距超过 6 m（示意截断）", C.soft, "center")
        ph = (t / 2.2) % 1
        q1, q2 = path_point(ray1, path_table(ray1), ph), path_point(ray2, path_table(ray2), (ph + 0.45) % 1)
        dot(cv, q1[0], q1[1], 3.4, C.accent, C.paper, 1)
        dot(cv, q2[0], q2[1], 3.4, C.ink2, C.paper, 1)
        if lv >= 1:
            tag_box(cv, cv.w * 0.5, 18, "平行光 → 过焦点　过光心 → 不偏折", C.ink2, "center")
        x0, y0p = 14, cv.h - 146
        lp = frame_panel(cv, x0, y0p, min(322, cv.w * 0.46), 88, "凸透镜成像")
        uv = f"u = {fmt(u, 2)} m　v = {'∞' if near else fmt(abs(v), 2) + ' m'}"
        if lv == 0:
            plabel(cv, x0 + 10, lp.y + 3, uv, C.ink, 10.5)
            plabel(cv, x0 + 10, lp.y + 21, "改变物距，物与像同步移动", C.soft, 10)
            plabel(cv, x0 + 10, lp.y + 39, "u > f 成实像；u < f 成虚像", C.accent, 10)
        elif lv == 1:
            plabel(cv, x0 + 10, lp.y + 2, "① 平行主轴 → 过 F′", C.data[2], 10)
            plabel(cv, x0 + 10, lp.y + 19, "② 过光心 → 方向不变", C.jade, 10)
            plabel(cv, x0 + 10, lp.y + 36, "③ 过 F → 出射平行主轴", C.gold, 10)
            plabel(cv, x0 + 10, lp.y + 53, uv, C.ink2, 10)
        else:
            plabel(cv, x0 + 10, lp.y + 2, "1/f = 1/u + 1/v　m = −v/u", C.ink, 10.5)
            plabel(cv, x0 + 10, lp.y + 20, uv, C.ink2, 10)
            plabel(cv, x0 + 10, lp.y + 38, f"|m| = {'—' if near else fmt(abs(v) / u, 2)}　{'不成像' if near else '倒立实像' if v > 0 else '正立放大虚像'}", C.accent, 10)
            plabel(cv, x0 + 10, lp.y + 56, "三条特殊光线决定像的位置", C.soft, 9.5)

    def readouts(self, t):
        u = self.u_now(t)
        _f, v, near, _h = self.optics(u)
        return [("物距 u", fmt(u, 2), "m"), ("像距 v", "∞" if near else fmt(abs(v), 2), "" if near else "m"), ("放大率 |m|", "—" if near else fmt(abs(v) / u, 2), ""), ("像的性质", "不成像" if near else "倒立实像" if v > 0 else "正立虚像", "")]

    def status(self, t):
        u = self.u_now(t)
        _f, v, near, _h = self.optics(u)
        if near:
            return "物距 ≈ 焦距 · 折射光近似平行"
        return f"u > f · 倒立{'放大' if abs(v) > u else '缩小'}实像" if v > 0 else "u < f · 正立放大虚像"


@scene("interference")
class Interference(Scene):
    sliders = [("lam", "波长 λ (nm)", 400, 700, 5, 0), ("d", "双缝间距 d (mm)", 0.15, 0.8, 0.01, 2), ("L", "缝到屏距离 L (m)", 0.8, 2, 0.05, 2)]
    hints = ["双缝把同一束光分成两列相干光，屏上某点的光程差决定加强与减弱。", "亮纹条件 Δ = d sinθ = kλ；近轴时条纹间距 Δy = λL/d。", "缝距越小、波长越长，条纹越稀疏；光强按 cos²(πd y/λL) 分布。"]
    hot = [[2], [0, 1], [0, 1, 2, 3]]

    def defaults(self):
        return dict(lam=550, d=0.4, L=1.2)

    def duration(self):
        return 4

    def spacing(self):
        P = self.P
        return (P.lam * 1e-9) * P.L / (P.d * 1e-3) * 1000

    def intensity(self, mm):
        P = self.P
        return cos(PI * P.d * mm * 1000 / (max(P.L, 0.1) * P.lam)) ** 2

    def draw(self, cv, t, lv):
        P, g, w, h = self.P, cv.g, cv.w, cv.h
        top, bot = h * 0.11, h * 0.80
        y0 = (top + bot) / 2
        src, bar, scr = w * 0.07, w * 0.34, w * 0.845
        gap = 18 + 24 * clamp((P.d - 0.15) / 0.65, 0, 1)
        c1, c2 = y0 - gap / 2, y0 + gap / 2
        col = QColor.fromHslF((270 - 270 * clamp((P.lam - 380) / 320, 0, 1)) / 360, 0.72, 0.46)
        max_r = scr - bar + 8
        lam_px = 14 + 12 * clamp((P.lam - 400) / 300, 0, 1)
        phase = (t * 34) % lam_px
        for k in range(16):
            rr = phase + k * lam_px
            if rr > max_r or rr < 3:
                continue
            a = (0.30 if lv >= 1 else 0.12) * (1 - rr / max_r)
            stroke_arc(cv, bar, c1, rr, -PI / 2, PI / 2, col, 1, a)
            stroke_arc(cv, bar, c2, rr, -PI / 2, PI / 2, col, 1, a)
        for y1, y2 in ((top, c1 - 3), (c1 + 3, c2 - 3), (c2 + 3, bot)):
            D.line(g, bar, y1, bar, y2, C.ink2, 2.6)
        plabel(cv, bar - 14, c1, "S₁", C.ink2, 10, align="right", weight=700)
        plabel(cv, bar - 14, c2, "S₂", C.ink2, 10, align="right", weight=700)
        plabel(cv, bar - 14, (c1 + c2) / 2 + 2, "d", C.soft, 9.5, align="right")
        D.line(g, bar - 8, c1, bar - 8, c2, C.soft, 1)
        D.line(g, bar - 11, c1, bar - 5, c1, C.soft, 1)
        D.line(g, bar - 11, c2, bar - 5, c2, C.soft, 1)
        g.p.fillRect(QRectF(scr - 8, top, 16, bot - top), QColor("#0B1836"))
        y_max = 8
        mm_of = lambda Y: (0.5 - (Y - top) / (bot - top)) * 2 * y_max   # noqa: E731
        Y = top
        while Y < bot:
            g.p.fillRect(QRectF(scr - 7, Y, 14, 2.1), alpha(col, 0.1 + 0.9 * self.intensity(mm_of(Y))))
            Y += 2
        D.rect(g, scr - 8, top, 16, bot - top, None, C.line2, 1)
        plabel(cv, scr, top - 9, "光屏", C.soft, 9.5, align="center")
        D.line(g, bar, y0, scr - 10, y0, C.faint, 1, [3, 5])
        curve = []
        for i in range(91):
            Yc = top + (bot - top) * i / 90
            curve.append((scr - 24 - self.intensity(mm_of(Yc)) * 44, Yc))
        p_flow(cv, curve, col, None, 0, 1.5, 0.9 if lv >= 1 else 0.55)
        if lv >= 1:
            for i in range(0, len(curve), 6):
                D.line(g, curve[i][0], curve[i][1], scr - 24, curve[i][1], alpha(col, 0.12), 1)
            plabel(cv, scr - 26, top - 9, "I", col, 10, align="right", weight=700)
            plabel(cv, bar + 8, y0 - 10, "中央亮纹", C.soft, 9.5, weight=500)
        probe = y0 + sin(TAU * t / 4) * (bot - top) * 0.40
        pmm = mm_of(probe)
        D.line(g, scr + 10, probe, scr + 28, probe, C.accent, 1, [3, 4])
        D.circle(g, scr + 32, probe, 3.2, C.accent)
        if lv >= 2:
            tag_box(cv, w * 0.5, 18, f"Δy = λL/d = {fmt(self.spacing(), 2)} mm", C.ink2, "center")
            dy = self.spacing() / (2 * y_max) * (bot - top)
            if 5 < dy < (bot - top) * 0.5:
                xm = scr - 78
                D.line(g, xm, y0, xm, y0 + dy, C.accent, 1)
                D.line(g, xm - 4, y0, xm + 4, y0, C.accent, 1)
                D.line(g, xm - 4, y0 + dy, xm + 4, y0 + dy, C.accent, 1)
                plabel(cv, xm - 5, y0 + dy / 2, "Δy", C.accent, 9, align="right")
        if lv == 0:
            plabel(cv, 14, h - 38, f"扫描点：{'亮纹' if self.intensity(pmm) > 0.5 else '暗纹'}", C.soft, 9.5, weight=500)
        else:
            plabel(cv, 14, h - 38, f"λ = {fmt(P.lam, 0)} nm　d = {fmt(P.d, 2)} mm　I = {fmt(self.intensity(pmm), 2)}", C.soft, 9.5, weight=500)
        if lv >= 2:
            tag_box(cv, 14, h - 60, "亮纹：Δ = kλ　暗纹：Δ = (k+½)λ", C.soft)
        D.rrect(g, src - 11, y0 - 9, 22, 18, 2, C.accent)
        plabel(cv, src, y0 + 21, "单色光源", C.soft, 9.5, align="center", weight=500)
        p_arrow(cv, src + 13, y0, bar - 6, y0, col, 1.4, 6)

    def readouts(self, t):
        P = self.P
        return [("波长 λ", fmt(P.lam, 0), "nm"), ("双缝间距 d", fmt(P.d, 2), "mm"), ("条纹间距 Δy", fmt(self.spacing(), 2), "mm"), ("缝屏距离 L", fmt(P.L, 2), "m")]

    def status(self, t):
        I = self.intensity(-6.4 * sin(TAU * t / 4))
        return f"双缝干涉 · 扫描点{'亮纹' if I > 0.5 else '暗纹'} · I = {fmt(I, 2)}"
