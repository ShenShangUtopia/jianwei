"""physics 引擎：把一个 Scene 挂到题目视图上。时间轴、状态、读数、参数面板都在这里，场景只管画。"""
from __future__ import annotations

import math
from types import SimpleNamespace

from PySide6.QtCore import QRectF, Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QWidget

from ..design.tokens import T, family, qc
from ..kit.core import clamp
from ..kit.draw import D
from . import ph_scenes1, ph_scenes2, ph_scenes3  # noqa: F401  注册场景
from .ph_core import SCENES, Cv
from .sb_core import C

TL_H = 26   # 画布底部时间轴的高度


def apply_params(sc, src):
    """题目参数注入场景；落在滑块量程外时向两侧扩量程，留出调节余量。"""
    P = sc.P
    for k in vars(P):
        v = src.get(k)
        if isinstance(v, (int, float)) and math.isfinite(v):
            setattr(P, k, float(v))
    sc.aux(src)
    for s in sc.sliders:
        k, _lb, mn, mx = s[0], s[1], s[2], s[3]
        v = getattr(P, k, mn)
        if not isinstance(v, (int, float)) or not math.isfinite(v):
            v = mn
            setattr(P, k, v)
        if v < mn:
            s[2] = v * 0.6 if v >= 0 else v * 1.6
        if v > mx:
            s[3] = v * 1.6 if v >= 0 else v * 0.6
        if not s[3] > s[2]:
            s[2], s[3] = v - 1, v + 1
    if getattr(P, "g", None):
        P.g = clamp(P.g, 1, 20)


class _Row:
    """一行读数：标签、数值、单位，都可能随帧变化。"""

    def __init__(self, L):
        self.box = QWidget()
        h = QHBoxLayout(self.box)
        h.setContentsMargins(4, 2, 4, 2)
        h.setSpacing(6)
        self.a, self.b, self.u = QLabel(), QLabel(), QLabel()
        self.a.setObjectName("ctlLabel")
        self.u.setObjectName("ctlLabel")
        self.b.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        h.addWidget(self.a, 0)
        h.addWidget(self.b, 1)
        h.addWidget(self.u, 0)
        L._add(self.box)
        self.last, self.hot = None, None

    def set(self, label, value, unit):
        cur = (label, value, unit)
        if cur != self.last:
            self.last = cur
            self.a.setText(label)
            self.b.setText(str(value))
            self.u.setText(unit or "")

    def set_hot(self, on):
        if on == self.hot:
            return
        self.hot = on
        col = qc(T.accent if on else T.fg).name()
        self.b.setStyleSheet(f"color:{col};font-weight:{700 if on else 500};font-family:'{family('num')}';")


def mount_physics(W):
    L, c = W.L, W.c
    view = W.view
    kind = view.get("kind") if view.get("kind") in SCENES else "projectile"
    sc = SCENES[kind]()
    sc.kind = kind
    apply_params(sc, view.get("params") or {})
    cv = Cv(c)
    st = SimpleNamespace(t=0.0, T=4.0, lv=0, playing=True, speed=1.0, was=False, drag=False)

    def dur():
        d = sc.duration()
        return clamp(d, 0.2, 120) if math.isfinite(d) and d > 0 else 4

    def norm_time():
        st.T = dur()
        st.t = min(st.t, st.T) if sc.one_shot else st.t % st.T

    # ---- 检查器
    if view.get("cue"):
        L.note(f"<b>求：</b>{view['cue']}")
    row = L.button_row()
    play_btn = row.add("暂停", lambda: toggle())
    row.add("重置", lambda: reset())
    W.toggle("慢放 ×0.5", False, lambda on: setattr(st, "speed", 0.5 if on else 1.0))
    L.note("拖动时间轴回看 · 空格键暂停/播放")
    W.sec("参数")
    for s in sc.sliders:
        k, lb, mn, mx, step, dec = s

        def on_param(v, k=k):
            setattr(sc.P, k, v)
            norm_time()
            W.redraw()
        L.slider(lb, mn, mx, step, getattr(sc.P, k), on_param, "", dec)
    for ch in sc.chips:
        W.sec(ch.label)

        def on_chip(text, ch=ch):
            i = ch.items.index(text)
            ch.index = i
            ch.set(i)
            st.t = 0.0
            W.redraw()
        W.chips(ch.items, ch.items[ch.index], on_chip)
    W.sec("读数")
    rows: list[_Row] = []
    hint = W.note("")

    def sync_stats():
        rd = sc.readouts(st.t)
        while len(rows) < len(rd):
            rows.append(_Row(L))
        hot = sc.hot[int(clamp(st.lv, 0, 2))] if sc.hot else []
        for i, (lb, val, unit) in enumerate(rd):
            rows[i].set(lb, val, unit)
            rows[i].set_hot(i in hot)

    def sync_play():
        text = "暂停" if st.playing else "重放" if (sc.one_shot and st.t >= st.T - 1e-4) else "播放"
        if play_btn.text() != text:
            play_btn.setText(text)

    # ---- 绘制
    def track_rect(w, h):
        return 14, h - TL_H + 13, max(40, w - 150)

    def render(w, h):
        if w < 24 or h < 24:
            return
        norm_time()
        sc.draw(cv, st.t, st.lv)
        g = c.g
        # 时间轴压在画面底部一条窄带上
        g.p.fillRect(QRectF(0, h - TL_H, w, TL_H), qc(C.card))
        D.line(g, 0, h - TL_H + 0.5, w, h - TL_H + 0.5, C.line, 1)
        x, y, tw = track_rect(w, h)
        f = clamp(st.t / st.T, 0, 1) if st.T > 0 else 0
        g.p.fillRect(QRectF(x, y - 1.5, tw, 3), qc(C.line2))
        g.p.fillRect(QRectF(x, y - 1.5, tw * f, 3), qc(T.accent))
        D.circle(g, x + tw * f, y, 5.5, T.accent, C.card, 2)
        D.text(g, f"{st.t:.2f} / {st.T:.2f} s", w - 12, y, C.soft, size=10.5, mono=True, align="right")
        # 时刻与状态
        D.text(g, f"t = {st.t:.2f} s", 12, 16, C.soft, size=11, mono=True)
        D.text(g, f"状态：{sc.status(st.t)}", w - 12, 16 if kind not in ("shm",) else 12, C.soft, size=11, align="right")
        sync_stats()
        sync_play()
    W.set(render)

    # ---- 操作
    def tick(dt):
        if not st.playing:
            return
        st.T = dur()
        st.t += dt * st.speed
        if st.t >= st.T:
            if sc.one_shot:
                st.t = st.T
                st.playing = False
            else:
                st.t -= st.T
        W.redraw()
    L.loop(tick)

    def toggle():
        if st.playing:
            st.playing = False
        else:
            if sc.one_shot and st.t >= st.T - 1e-4:
                st.t = 0.0
            st.playing = True
        W.redraw()

    def reset():
        st.t = 0.0
        W.redraw()

    def seek(px):
        x, _y, tw = track_rect(c.w, c.h)
        st.T = dur()
        st.t = clamp((px - x) / tw, 0, 1) * st.T

    def hit(_x, y):
        if y >= c.h - TL_H:
            return "tl"
        return "scene" if sc.has_drag else None

    def down(x, y, cur):
        if cur == "tl":
            st.was, st.playing = st.playing, False
            seek(x)
            W.redraw()
        elif cur == "scene":
            sc.drag("down", cv.dx(x), cv.dy(y))

    def drag(cur, x, y, _dx, _dy):
        if cur == "tl":
            seek(x)
        elif cur == "scene":
            sc.drag("move", cv.dx(x), cv.dy(y))

    def up(cur):
        if cur == "tl":
            st.playing = st.was
        elif cur == "scene":
            sc.drag("up", 0, 0)
    L.interact(c, hit=hit, down=down, drag=drag, up=up)

    def key(k):
        if k == " ":
            toggle()
            return True
        return False
    L.on_key(key)

    def apply_step(i):
        st.lv = int(clamp(int(i or 0), 0, 2))
        W.step = st.lv
        hint.text(sc.hints[st.lv] if st.lv < len(sc.hints) else "")
        W.redraw()
    W.apply_step = apply_step
    W.scene, W.state = sc, st   # 自测与「讲题」用
    apply_step(0)
    sync_stats()
