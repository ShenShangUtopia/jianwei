"""物理题型（沿用 VeloΦ 的做法）：抛体、斜面、碰撞、闭合电路、透镜、带电粒子。

每个题型 = 解析解 + 第二种方法核对（数值积分、守恒量、另一种算法）。checks 里记录核对结果；
两种方法不一致时 build() 把所有行标成待复核，不当作答案显示。viz.scene 指向习题台的物理场景，可以直接演示。
"""
from __future__ import annotations

import math

from .task_core import P, asks_of, fail, fmt_n, info_row, isf, need_num, num_row, reg

G0 = 9.8


def _chk(name, a, b, tol=2e-3):
    ok = abs(a - b) <= tol * max(abs(a), abs(b), 1e-9) + 1e-9
    return dict(name=name, ok=ok, analytic=a, reference=b, absolute_error=abs(a-b), relative_error=abs(a-b)/max(abs(a),abs(b),1e-9), tolerance=tol,
                text=f"{name}：解析 {fmt_n(a)}，核对 {fmt_n(b)}，绝对误差 {abs(a-b):.3g}")


def rk4(f, y, t, dt):
    k1 = f(t, y)
    k2 = f(t + dt / 2, [y[i] + dt / 2 * k1[i] for i in range(len(y))])
    k3 = f(t + dt / 2, [y[i] + dt / 2 * k2[i] for i in range(len(y))])
    k4 = f(t + dt, [y[i] + dt * k3[i] for i in range(len(y))])
    return [y[i] + dt / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) for i in range(len(y))]


_DOC_PROJ = """{"kind":"projectile","v0":20,"angle":30,"h0":0,"g":10,"asks":[{"what":"range","claimed":34.64},{"what":"time"},{"what":"max_height"},{"what":"impact_speed"}]}
  斜抛 / 平抛 / 竖直上抛：v0 初速（m/s），angle 与水平方向夹角（°，平抛写 0，向下抛写负数），h0 抛出点高度（m），g 默认 9.8，题目给 10 就写 10。
  what：time（落地时间）、range（水平射程）、max_height（离地最大高度）、impact_speed（落地速率）、impact_angle（落地速度与水平方向夹角 °）、speed_at（"t" 时刻的速率）、pos_at（"t" 时刻的 [x,y]，仅展示）"""


@reg("projectile", "物理", "抛体运动", _DOC_PROJ)
def run_projectile(s):
    v0 = need_num(s.get("v0"), "v0", lambda x: x >= 0, "非负数")
    ang = need_num(s.get("angle", 0), "angle", lambda x: -90 <= x <= 90, "-90~90 的角度")
    h0 = need_num(s.get("h0", 0), "h0", lambda x: x >= 0, "非负数")
    g = need_num(s.get("g", G0), "g", lambda x: x > 0, "正数")
    th = math.radians(ang)
    vx, vy = v0 * math.cos(th), v0 * math.sin(th)
    disc = vy * vy + 2 * g * h0
    Tf = (vy + math.sqrt(disc)) / g
    if not math.isfinite(Tf) or Tf <= 0 or Tf/2000==0:
        fail("按这组参数物体不会在抛出后落地（v0、h0 都为 0？）")
    R_ = vx * Tf
    H_ = h0 + (vy * vy / (2 * g) if vy > 0 else 0)
    vyf = vy - g * Tf
    vf = math.hypot(vx, vyf)
    # 核对：数值积分到落地
    y, t, dt = [0.0, h0, vx, vy], 0.0, Tf / 2000
    deriv = lambda _t, q: [q[2], q[3], 0.0, -g]   # noqa: E731
    top = h0
    while y[1] > 0 or t == 0:
        nxt = rk4(deriv, y, t, dt)
        if nxt[1] <= 0 and t > 0:
            k = y[1] / (y[1] - nxt[1])
            y = [y[i] + (nxt[i] - y[i]) * k for i in range(4)]
            t += dt * k
            break
        y, t = nxt, t + dt
        top = max(top, y[1])
        if t > Tf * 2:
            break
    checks = [_chk("落地时间（数值积分）", Tf, t), _chk("射程（数值积分）", R_, y[0]), _chk("机械能守恒（落地速率）", vf, math.sqrt(v0 * v0 + 2 * g * h0)), _chk("最大高度（数值积分）", H_, top, 4e-3)]
    rows = []
    for q in asks_of(s, ["time", "range", "max_height", "impact_speed", "impact_angle", "speed_at", "pos_at"]):
        w = q["what"]
        if w == "time":
            rows.append(num_row(q, Tf, "s"))
        elif w == "range":
            rows.append(num_row(q, R_, "m"))
        elif w == "max_height":
            rows.append(num_row(q, H_, "m"))
        elif w == "impact_speed":
            rows.append(num_row(q, vf, "m/s"))
        elif w == "impact_angle":
            rows.append(num_row(q, math.degrees(math.atan2(abs(vyf), vx)), "°"))
        elif w == "speed_at":
            tq = need_num(q.get("t"), "speed_at 的 t", lambda x: x >= 0, "非负数")
            rows.append(num_row(q, math.hypot(vx, vy - g * tq), "m/s"))
        else:
            tq = need_num(q.get("t"), "pos_at 的 t", lambda x: x >= 0, "非负数")
            rows.append(info_row(q, f"({fmt_n(vx * tq)}, {fmt_n(h0 + vy * tq - 0.5 * g * tq * tq)}) m"))
    return dict(rows=rows, checks=checks, viz=dict(scene=dict(kind="projectile", params=dict(v0=v0, angle=ang, h0=h0, g=g))), detail=[f"水平 vx = {fmt_n(vx)} m/s，竖直 vy = {fmt_n(vy)} m/s，g = {fmt_n(g)} m/s²", f"落地时间 T = {fmt_n(Tf)} s，射程 R = {fmt_n(R_)} m，最大高度 {fmt_n(H_)} m"])


_DOC_INC = """{"kind":"incline","angle":37,"mu":0.25,"m":2,"L":8,"g":10,"v0":0,"asks":[{"what":"a","claimed":4},{"what":"time","claimed":2}]}
  物块沿粗糙斜面滑动：angle 倾角（°）、mu 动摩擦因数、m 质量（kg）、L 斜面长（m）、v0 沿斜面向下的初速度（m/s，默认 0）、F 沿斜面向上的拉力（N，默认 0）、g 默认 9.8。
  what：a（加速度）、time（滑到底端的时间）、v_end（到底端的速度）、N（支持力）、f（摩擦力）、moves（是否滑动，仅展示）、work_friction（克服摩擦做的功）"""


@reg("incline", "物理", "斜面上的物块", _DOC_INC)
def run_incline(s):
    ang = need_num(s.get("angle"), "angle", lambda x: 0 <= x < 90, "0~90 的角度")
    mu = need_num(s.get("mu", 0), "mu", lambda x: x >= 0, "非负数")
    m = need_num(s.get("m", 1), "m", lambda x: x > 0, "正数")
    L = need_num(s.get("L", 1), "L", lambda x: x > 0, "正数")
    g = need_num(s.get("g", G0), "g", lambda x: x > 0, "正数")
    v0 = need_num(s.get("v0", 0), "v0", lambda x: x >= 0, "非负数")
    F = need_num(s.get("F", 0), "F")
    th = math.radians(ang)
    sn, cs = math.sin(th), math.cos(th)
    N_ = m * g * cs
    drive = m * g * sn - F
    fmax = mu * N_
    moving = v0 > 0 or drive > fmax + 1e-12
    f_ = fmax if moving else abs(drive)
    a = (drive - fmax) / m if moving else 0.0
    T_, v_end = math.nan, math.nan
    if moving:
        if abs(a) < 1e-12:
            T_ = L / v0 if v0 > 0 else math.nan
            v_end = v0
        else:
            d = v0 * v0 + 2 * a * L
            if d >= 0:
                T_ = (-v0 + math.sqrt(d)) / a
                v_end = math.sqrt(d)
    checks = [_chk("牛顿第二定律（受力合成）", m * a, drive - (fmax if moving else drive))]
    if isf(T_) and T_ > 0:
        y, t, dt = [0.0, v0], 0.0, T_ / 4000
        for _i in range(4000):
            y = rk4(lambda _t, q: [q[1], a], y, t, dt)
            t += dt
        checks.append(_chk("到底时间（数值积分）", L, y[0]))
        checks.append(_chk("动能定理（到底速度）", v_end, math.sqrt(max(0, v0 * v0 + 2 * (drive - fmax) * L / m))))
    rows = []
    for q in asks_of(s, ["a", "time", "v_end", "N", "f", "moves", "work_friction"]):
        w = q["what"]
        if w == "a":
            rows.append(num_row(q, a, "m/s²"))
        elif w == "time":
            rows.append(num_row(q, T_, "s"))
        elif w == "v_end":
            rows.append(num_row(q, v_end, "m/s"))
        elif w == "N":
            rows.append(num_row(q, N_, "N"))
        elif w == "f":
            rows.append(num_row(q, f_, "N"))
        elif w == "work_friction":
            rows.append(num_row(q, fmax * L if moving else 0.0, "J"))
        else:
            rows.append(info_row(q, "会滑动" if moving else f"静止（重力分量 {fmt_n(drive)} N ≤ 最大静摩擦 {fmt_n(fmax)} N）"))
    return dict(rows=rows, checks=checks, viz=dict(scene=dict(kind="incline", params=dict(angle=ang, mu=mu, m=m, L=L, g=g))), detail=[f"N = mg cosθ = {fmt_n(N_)} N，f = {fmt_n(f_)} N", f"a = {fmt_n(a)} m/s²" + (f"，t = {fmt_n(T_)} s，v = {fmt_n(v_end)} m/s" if isf(T_) else "")])


_DOC_COL = """{"kind":"collision","m1":2,"m2":1,"v1":4,"v2":-1,"e":1,"asks":[{"what":"v1_after","claimed":0.667},{"what":"v2_after"},{"what":"energy_loss"}]}
  一维碰撞：v 向右为正。e 恢复系数：弹性 1，完全非弹性 0（默认 1）。
  what：v1_after、v2_after、momentum（总动量）、energy_loss（损失的动能）、energy_before、energy_after"""


@reg("collision", "物理", "一维碰撞", _DOC_COL)
def run_collision(s):
    m1 = need_num(s.get("m1"), "m1", lambda x: x > 0, "正数")
    m2 = need_num(s.get("m2"), "m2", lambda x: x > 0, "正数")
    v1 = need_num(s.get("v1"), "v1")
    v2 = need_num(s.get("v2", 0), "v2")
    e = need_num(s.get("e", 1), "e", lambda x: 0 <= x <= 1, "0~1 的数")
    if v1 <= v2:
        fail(f"v1 = {fmt_n(v1)} 不大于 v2 = {fmt_n(v2)}，两物体不会相碰（向右为正）")
    a = ((m1 - e * m2) * v1 + (1 + e) * m2 * v2) / (m1 + m2)
    b = ((m2 - e * m1) * v2 + (1 + e) * m1 * v1) / (m1 + m2)
    p0, p1 = m1 * v1 + m2 * v2, m1 * a + m2 * b
    E0, E1 = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2, 0.5 * m1 * a * a + 0.5 * m2 * b * b
    # 核对：质心系里相对速度乘 e 反向
    vc = p0 / (m1 + m2)
    a2 = vc - e * (v1 - vc)
    b2 = vc - e * (v2 - vc)
    checks = [_chk("动量守恒", p0, p1), _chk("质心系（v₁′）", a, a2), _chk("质心系（v₂′）", b, b2), _chk("相对速度（恢复系数）", b - a, e * (v1 - v2))]
    rows = []
    for q in asks_of(s, ["v1_after", "v2_after", "momentum", "energy_loss", "energy_before", "energy_after"]):
        w = q["what"]
        rows.append({"v1_after": lambda: num_row(q, a, "m/s"), "v2_after": lambda: num_row(q, b, "m/s"), "momentum": lambda: num_row(q, p0, "kg·m/s"), "energy_loss": lambda: num_row(q, E0 - E1, "J"), "energy_before": lambda: num_row(q, E0, "J"), "energy_after": lambda: num_row(q, E1, "J")}[w]())
    return dict(rows=rows, checks=checks, viz=dict(scene=dict(kind="collision", params=dict(m1=m1, m2=m2, v1=v1, v2=v2,e=e))), detail=[f"碰后 v₁′ = {fmt_n(a)} m/s，v₂′ = {fmt_n(b)} m/s", f"动量 {fmt_n(p0)} kg·m/s，动能 {fmt_n(E0)} → {fmt_n(E1)} J"])


_DOC_CIR = """{"kind":"circuit","E":6,"r":0.5,"R1":4,"R2":6,"mode":"series","R3":0,"asks":[{"what":"I","claimed":0.571},{"what":"U"}]}
  闭合电路：E 电动势（V）、r 内阻（Ω，默认 0）、R1、R2、mode（series 串联 / parallel 并联）、R3（再串在干路上的电阻，默认 0）。复杂电路请用方程模型。
  what：R_total（总电阻）、I（干路电流）、U（路端电压）、I1 / I2（各支路电流）、P1 / P2（R1、R2 的功率）、P_total（电源总功率）、P_out（输出功率）、efficiency（效率）"""


@reg("circuit", "物理", "闭合电路", _DOC_CIR)
def run_circuit(s):
    E_ = need_num(s.get("E", s.get("Emf")), "E", lambda x: x > 0, "正数")
    r = need_num(s.get("r", 0), "r", lambda x: x >= 0, "非负数")
    R1 = need_num(s.get("R1"), "R1", lambda x: x > 0, "正数")
    mode = s.get("mode") or "series"
    if mode not in ("series", "parallel"):
        fail("mode 只能是 series 或 parallel")
    R2 = need_num(s.get("R2", 0 if mode == "series" else None), "R2", lambda x: x >= 0, "非负数")
    R3 = need_num(s.get("R3", 0), "R3", lambda x: x >= 0, "非负数")
    Rp = R1 + R2 if mode == "series" else R1 * R2 / (R1 + R2)
    Rt = Rp + R3 + r
    I = E_ / Rt
    U = E_ - I * r
    Up = I * Rp
    I1, I2 = (I, I) if mode == "series" else (Up / R1, Up / R2)
    P1, P2 = I1 * I1 * R1, I2 * I2 * R2
    # 核对：节点电压法 + 能量守恒
    G_ = (1 / (r + R3) if (r + R3) > 0 else 1e12) + 1 / Rp
    Vn = (E_ * (1 / (r + R3) if (r + R3) > 0 else 1e12)) / G_
    checks = [_chk("节点电压法（并联部分电压）", Up, Vn), _chk("能量守恒", E_ * I, P1 + P2 + I * I * (r + R3))]
    rows = []
    for q in asks_of(s, ["R_total", "I", "U", "I1", "I2", "P1", "P2", "P_total", "P_out", "efficiency"]):
        val = dict(R_total=(Rt, "Ω"), I=(I, "A"), U=(U, "V"), I1=(I1, "A"), I2=(I2, "A"), P1=(P1, "W"), P2=(P2, "W"), P_total=(E_ * I, "W"), P_out=(U * I, "W"), efficiency=(U / E_, ""))[q["what"]]
        rows.append(num_row(q, val[0], val[1]))
    return dict(rows=rows, checks=checks, viz=dict(scene=dict(kind="circuit", params=dict(E=E_, r=r, R1=R1, R2=R2,R3=R3,mode=mode))), detail=[f"R总 = {fmt_n(Rt)} Ω，I = {fmt_n(I)} A，U = {fmt_n(U)} V"])


_DOC_LENS = """{"kind":"lens","f":10,"u":30,"h":2,"asks":[{"what":"v","claimed":15},{"what":"m"},{"what":"nature"}]}
  薄透镜成像：f 焦距（凸透镜为正，凹透镜为负），u 物距（>0），h 物高（可选），单位统一即可。
  what：v（像距，实像为正、虚像为负）、m（放大率绝对值）、h_img（像高绝对值）、nature（像的性质，仅展示）"""


@reg("lens", "物理", "透镜成像", _DOC_LENS)
def run_lens(s):
    f = need_num(s.get("f"), "f", lambda x: x != 0, "不为 0 的数")
    u = need_num(s.get("u"), "u", lambda x: x > 0, "正数")
    h = need_num(s.get("h", 1), "h", lambda x: x > 0, "正数")
    if abs(u - f) < 1e-9:
        v = math.inf
    else:
        v = u * f / (u - f)
    m = abs(v) / u if isf(v) else math.inf
    checks = []
    if isf(v):
        # 核对：沿两条特殊光线作图求交点（光线追迹）
        k1 = -h / f      # 平行主轴的光线折射后过焦点
        k2 = -h / u      # 过光心的光线不偏折
        x_cross = (h - 0) / (k2 - k1) if abs(k2 - k1) > 1e-12 else math.nan
        checks.append(_chk("光线追迹（交点横坐标）", v, x_cross))
        checks.append(_chk("牛顿成像公式", (u - f) * (v - f), f * f))
    rows = []
    real = isf(v) and v > 0
    nature = "不成像（物在焦点上）" if not isf(v) else ("倒立" if real else "正立") + ("放大" if m > 1 + 1e-9 else "缩小" if m < 1 - 1e-9 else "等大") + ("实像" if real else "虚像")
    for q in asks_of(s, ["v", "m", "h_img", "nature"]):
        w = q["what"]
        if w == "v":
            rows.append(num_row(q, v))
        elif w == "m":
            rows.append(num_row(q, m))
        elif w == "h_img":
            rows.append(num_row(q, m * h))
        else:
            rows.append(info_row(q, nature))
    k = 0.05 if abs(f) > 3 else 1   # 场景用米：cm 级的题缩放一下
    return dict(rows=rows, checks=checks, viz=dict(scene=dict(kind="lens", params=dict(f=max(abs(f) * k, 0.3), u=u * k, h=min(max(h * k, 0.15), 0.5)))) if f > 0 else None, detail=[f"1/f = 1/u + 1/v，v = {fmt_n(v)}，|m| = {fmt_n(m)}，{nature}"])


_DOC_FIELD = """{"kind":"field","q":1.6e-19,"m":9.1e-31,"v0":1e7,"E":1e4,"L":0.05,"d":0.02,"B":0,"asks":[{"what":"deflection"},{"what":"angle"}]}
  带电粒子：平行板偏转（E 场强 N/C，或 U 板间电压 V 与 d 板距 m，L 板长 m）或匀强磁场圆周（B 特斯拉）。q 电荷量大小（C）、m 质量（kg）、v0 垂直于场的入射速度（m/s）。
  what：a（电场中的加速度）、time（板间时间）、deflection（出板时的侧移）、angle（出射偏角 °）、hits_plate（是否打在板上，仅展示）、r（磁场中的半径）、T（磁场中的周期）"""


@reg("field", "物理", "带电粒子在场中", _DOC_FIELD)
def run_field(s):
    q_ = need_num(s.get("q"), "q", lambda x: x > 0, "正数")
    m = need_num(s.get("m"), "m", lambda x: x > 0, "正数")
    v0 = need_num(s.get("v0"), "v0", lambda x: x > 0, "正数")
    B = need_num(s.get("B", 0), "B", lambda x: x >= 0, "非负数")
    d = need_num(s["d"], "d", lambda x: x > 0, "正数") if s.get("d") is not None else None
    E_ = need_num(s["E"], "E", lambda x: x >= 0, "非负数") if s.get("E") is not None else None
    if E_ is None and s.get("U") is not None and d:
        E_ = need_num(s["U"], "U") / d
    L = need_num(s["L"], "L", lambda x: x > 0, "正数") if s.get("L") is not None else None
    checks = []
    a = t_ = y_ = ang = math.nan
    hits = None
    if E_ is not None and L is not None:
        a = q_ * E_ / m
        t_ = L / v0
        y_ = 0.5 * a * t_ * t_
        ang = math.degrees(math.atan(a * t_ / v0))
        hits = d is not None and y_ > d / 2
        st, tt, dt = [0.0, 0.0, v0, 0.0], 0.0, t_ / 2000
        for _i in range(2000):
            st = rk4(lambda _t, w: [w[2], w[3], 0.0, a], st, tt, dt)
            tt += dt
        checks.append(_chk("侧移（数值积分）", y_, st[1]))
        checks.append(_chk("动能定理（出射速率）", math.hypot(v0, a * t_), math.sqrt(v0 * v0 + 2 * a * y_)))
    r_ = T_ = math.nan
    if B > 0:
        r_ = m * v0 / (q_ * B)
        T_ = 2 * math.pi * m / (q_ * B)
        w = q_ * B / m
        st, tt, dt = [0.0, 0.0, v0, 0.0], 0.0, T_ / 4000
        far = 0.0
        for _i in range(4000):
            st = rk4(lambda _t, u: [u[2], u[3], -w * u[3], w * u[2]], st, tt, dt)
            tt += dt
            far = max(far, math.hypot(st[0], st[1]))
        checks.append(_chk("半径（数值积分：直径）", 2 * r_, far))
    rows = []
    for q in asks_of(s, ["a", "time", "deflection", "angle", "hits_plate", "r", "T"]):
        w = q["what"]
        if w == "hits_plate":
            rows.append(info_row(q, "打在板上" if hits else "能飞出极板" if hits is not None else "没有给板距 d"))
        else:
            val = dict(a=(a, "m/s²"), time=(t_, "s"), deflection=(y_, "m"), angle=(ang, "°"), r=(r_, "m"), T=(T_, "s"))[w]
            if not isf(val[0]):
                fail(f"{w} 需要的条件不够（电场要 E 或 U+d、L；磁场要 B）")
            rows.append(num_row(q, val[0], val[1]))
    det = []
    if isf(a):
        det.append(f"a = qE/m = {fmt_n(a)} m/s²，t = L/v₀ = {fmt_n(t_)} s，y = {fmt_n(y_)} m，θ = {fmt_n(ang)}°")
    if isf(r_):
        det.append(f"r = mv/(qB) = {fmt_n(r_)} m，T = 2πm/(qB) = {fmt_n(T_)} s")
    return dict(rows=rows, checks=checks, viz=dict(scene=dict(kind="magnet" if B > 0 and not isf(a) else "efield", params={})), detail=det)


_ = P
