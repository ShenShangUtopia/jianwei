"""见微 2.0 的学习窗口：习题台 · 实验台 · 工作台 · 析题 · 课件，全部原生（不依赖网页与浏览器内核）。

左边一条窄栏切换模式；每个模式第一次用到时才创建，打开快、占内存少。
"""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtCore import QRectF
from PySide6.QtGui import QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QStackedWidget, QVBoxLayout, QWidget

from .design import tokens
from .design.tokens import T
from .design.widgets import RailButton, paint_seal, qss
from .kit.home import home

MODES = (("desk", "习题"), ("lab", "实验"), ("bench", "工作"), ("analysis", "析题"), ("lecture", "课件"))
MODE_ICONS = dict(desk="desk", lab="lab", bench="bench", analysis="analysis", lecture="lecture")


class SealMark(QWidget):
    """窄栏顶部的朱砂印。"""

    def __init__(self, size=34):
        super().__init__()
        self.setFixedSize(size, size)
        self.setToolTip("见微")

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        paint_seal(p, QRectF(self.rect()))
        p.end()


class NativeWindow(QWidget):
    def __init__(self, theme="day"):
        super().__init__()
        self.setObjectName("jw2")
        self.setWindowTitle("见微")
        self.resize(1440, 900)
        self.setMinimumSize(1000, 620)
        tokens.set_theme(theme)
        from .design import ux
        ux.install()
        self.pages = {}
        from .kit.clip import ClipBus
        from .kit.transfer_router import TransferRouter
        self.clip_bus = ClipBus(self)
        self.transfer_router = TransferRouter(self,self.clip_bus)
        self.material_basket = None
        self.clip_bus.basket_requested.connect(self.show_materials)
        self.mode = None
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        self.rail = QFrame()
        self.rail.setObjectName("modeRail")
        self.rail.setFixedWidth(68)
        v = QVBoxLayout(self.rail)
        v.setContentsMargins(6, 12, 6, 10)
        v.setSpacing(4)
        seal = SealMark(34)
        v.addWidget(seal, 0, Qt.AlignmentFlag.AlignHCenter)
        v.addSpacing(12)
        self.btns = {}
        for i, (key, text) in enumerate(MODES, 1):
            b = RailButton(MODE_ICONS[key], text)
            b.setToolTip(f"{text}（Ctrl+{i}）")
            b.clicked.connect(lambda _c=False, k=key: self.goto(k))
            v.addWidget(b)
            self.btns[key] = b
            QShortcut(QKeySequence(f"Ctrl+{i}"), self, activated=lambda k=key: self.goto(k))
        v.addStretch(1)
        self.search_btn = RailButton("search", "搜索")
        self.search_btn.setCheckable(False)
        self.search_btn.setToolTip("快速打开：实验、工作台、题目、操作（Ctrl+K）")
        self.search_btn.clicked.connect(self.quick_open)
        v.addWidget(self.search_btn)
        self.materials_btn = RailButton("basket", "素材")
        self.materials_btn.setCheckable(False)
        self.materials_btn.setToolTip("素材篮：从任何地方送出的内容先放这里")
        self.materials_btn.clicked.connect(self.show_materials)
        v.addWidget(self.materials_btn)
        h.addWidget(self.rail)
        self.stack = QStackedWidget()
        h.addWidget(self.stack, 1)
        self.transfer_notice = QLabel(self)
        self.transfer_notice.setWordWrap(True)
        self.transfer_notice.hide()
        self.clip_bus.error.connect(self.show_transfer_error)
        self._quick = self._keys = None
        QShortcut(QKeySequence("Ctrl+K"), self, activated=self.quick_open)
        QShortcut(QKeySequence("F1"), self, activated=self.show_shortcuts)
        self._restore()
        self.apply_theme()

    # ---- 模式
    def page(self, key):
        if key in self.pages:
            return self.pages[key]
        if key == "desk":
            from .bank.desk import Desk
            w = Desk("night" if T.dark else "day")
        elif key in ("lab", "bench"):
            from .lab.studio import Studio
            if "lab" in self.pages or "bench" in self.pages:   # 实验台和工作台共用一个窗口体
                w = self.pages.get("lab") or self.pages.get("bench")
            else:
                w = Studio("night" if T.dark else "day",self.clip_bus)
        elif key == "lecture":
            from .lecture.page import LecturePage
            w = LecturePage(self.clip_bus)
        else:
            from .analysis.page import AnalysisPage
            w = AnalysisPage()
            self.transfer_router.bind_analysis(w)
        self.pages[key] = w
        if self.stack.indexOf(w) < 0:
            self.stack.addWidget(w)
        return w

    def goto(self, key, sub=""):
        fresh = key not in self.pages
        if fresh:   # 第一次打开某个模式要建界面，给个等待光标，别像卡住了
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            w = self.page(key)
        finally:
            if fresh:
                QApplication.restoreOverrideCursor()
        self.mode = key
        for k, b in self.btns.items():
            b.setChecked(k == key)
        self.stack.setCurrentWidget(w)
        if key in ("lab", "bench"):
            from .kit.bench import bench
            if key == "bench":
                bid = sub or (w.cur_bench.id if w.cur_bench else (bench.list[0].id if bench.list else None))
                if bid:
                    w.open_bench(bid)
            elif sub.startswith("subj/"):
                w.set_subj(sub[5:])
                w.go_home()
            elif sub:
                w.open(sub)
            elif w.cur_bench:
                w.go_home()
            else:
                w.set_subj(w.subj)
        elif key == "desk" and sub:
            w.open(sub)
        # 强调色：实验台、工作台跟学科走，其余页面回到青瓷色
        tokens.set_subject(w.subj if key in ("lab", "bench") else "")
        self.sync_theme(w)
        self.sync_chrome()
        return w

    # ---- Ctrl+K / F1
    def _quick_entries(self):
        from .kit.bench import bench
        from .kit.registry import SUBJECTS, lab
        import store
        lab.load()
        bench.load()
        out = [(text, "模式", (lambda k=key: self.goto(k))) for key, text in MODES]
        out += [(k.title, "工作台", (lambda i=k.id: self.goto("bench", i))) for k in bench.list]
        out += [(e.title, f"实验 · {SUBJECTS[e.subj]['name']}", (lambda i=e.id: self.goto("lab", i))) for e in lab.list]
        out += [("切换昼 / 夜", "操作", self._toggle_theme), ("素材篮", "操作", self.show_materials),
                ("快捷键一览", "操作", self.show_shortcuts)]
        out += [(q["title"], f"题目 · {q['subject']}", (lambda i=q["id"]: self.goto("desk", i))) for q in store.questions()]
        return out

    def _toggle_theme(self):
        self.set_theme("day" if T.dark else "night")

    def quick_open(self):
        if self._quick is None:
            from .kit.quick_open import QuickOpen
            self._quick = QuickOpen(self, self._quick_entries)
        self._quick.open()

    def show_shortcuts(self):
        if self._keys is None:
            from .kit.quick_open import ShortcutSheet
            self._keys = ShortcutSheet(self)
        self._keys.open()

    def sync_chrome(self):
        """工作台铺满整个窗口：窄栏收起，模式切换收进工作台左上角的印。"""
        self.rail.setVisible(getattr(self.stack.currentWidget(), "cur_bench", None) is None)

    def sync_theme(self, w=None):
        w = w or self.stack.currentWidget()
        if w is not None and hasattr(w, "apply_theme"):
            w.apply_theme()
        self.apply_theme()

    def set_theme(self, theme):
        tokens.set_theme(theme)
        self.sync_theme()
        lecture = self.pages.get("lecture")
        if lecture is not None and lecture is not self.stack.currentWidget():
            lecture.apply_theme()
        if self.material_basket:
            self.material_basket.apply_theme()

    def show_materials(self):
        if self.material_basket is None:
            from .kit.clip_ui import MaterialBasket
            self.material_basket = MaterialBasket(self.clip_bus,self)
        self.present()
        self.material_basket.setVisible(not self.material_basket.isVisible())
        self.material_basket.raise_()

    def show_transfer_error(self,text):
        self.transfer_notice.setText(text)
        self.transfer_notice.setStyleSheet(f"background:{T.raised};color:{T.bad};border:1px solid {T.line2};border-left:3px solid {T.bad};padding:10px 12px;font-size:12.5px;")
        self.transfer_notice.setFixedWidth(min(700,max(240,self.width()-100)))
        self.transfer_notice.adjustSize()
        self.transfer_notice.move(84,12)
        self.transfer_notice.show()
        self.transfer_notice.raise_()
        QTimer.singleShot(7000,self,self.transfer_notice.hide)

    def resizeEvent(self,event):  # noqa: N802
        super().resizeEvent(event)
        basket = getattr(self,"material_basket",None)
        if basket:
            basket.setGeometry(max(0,self.width()-300),0,300,self.height())
        for layer in (getattr(self,"_quick",None),getattr(self,"_keys",None)):
            if layer is not None and layer.isVisible():
                layer.setGeometry(self.rect())

    def apply_theme(self):
        t = T
        # 窗口统一套设计系统；各模式页面在此基础上只补自己的局部样式
        self.setStyleSheet(qss() + f"""
QFrame#modeRail {{ background:{t.rail}; border:none; }}
QWidget#jw2 {{ background:{t.bg}; }}
""")
        self.rail.update()

    # ---- 打开入口（给本体外壳用）
    def open_question(self, qid=""):
        self.goto("desk", qid)
        self.present()

    def open_lab(self, mode=""):
        if mode == "import":
            self.goto("analysis")
        elif mode == "bench":
            self.goto("bench")
        elif mode.startswith("bench/"):
            self.goto("bench", mode[6:])
        else:
            self.goto("lab", mode)
        self.present()

    def open_lecture(self):
        self.goto("lecture")
        self.present()

    def open_import(self):
        d = self.goto("desk")
        self.present()
        QTimer.singleShot(0, d.show_import)

    def present(self):
        self.showNormal() if self.isMinimized() else self.show()
        self.raise_()
        self.activateWindow()

    # ---- 窗口位置
    def _geom_file(self) -> Path:
        return home() / "window-native.json"

    def _restore(self):
        try:
            g = json.loads(self._geom_file().read_text(encoding="utf-8"))
            self.resize(int(g["w"]), int(g["h"]))
            self.move(int(g["x"]), int(g["y"]))
        except (OSError, ValueError, KeyError, TypeError):
            pass

    def closeEvent(self, e):  # noqa: N802
        try:
            self._geom_file().write_text(json.dumps(dict(x=self.x(), y=self.y(), w=self.width(), h=self.height())), encoding="utf-8")
        except OSError:
            pass
        desk = self.pages.get("desk")
        if desk:
            desk.pause()
        e.accept()

    def shutdown(self):
        self.transfer_router.closing = True
        for studio in {self.pages[k] for k in ("lab","bench") if k in self.pages}:
            studio._close_exp()
        a = self.pages.get("analysis")
        if a:
            a.shutdown()
        lec = self.pages.get("lecture")
        if lec:
            lec.shutdown()
