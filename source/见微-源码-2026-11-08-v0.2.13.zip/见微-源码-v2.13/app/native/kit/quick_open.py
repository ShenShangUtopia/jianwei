"""Ctrl+K 快速打开：打几个字，直达任意实验、工作台、题目、模式或操作。F1 是快捷键一览。

候选项在第一次打开时才收集；匹配只比较标题和分类，不联网、不碰文件。
"""
from __future__ import annotations

from PySide6.QtCore import QEvent, QRect, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QFontMetrics, QPainter
from PySide6.QtWidgets import (QFrame, QGridLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QStyle,
                               QStyledItemDelegate, QVBoxLayout, QWidget)

from ..design.tokens import RADIUS, T, font, qc

MAX_ROWS = 40
ROLE_KIND = Qt.ItemDataRole.UserRole + 1
ROLE_ACT = Qt.ItemDataRole.UserRole + 2


def score(query: str, text: str) -> int:
    """越小越靠前；-1 表示不匹配。整串包含优先，其次按顺序出现的字。"""
    q, t = query.lower(), text.lower()
    if not q:
        return 0
    at = t.find(q)
    if at >= 0:
        return at
    i = 0
    gaps = 0
    for ch in q:
        j = t.find(ch, i)
        if j < 0:
            return -1
        gaps += j - i
        i = j + 1
    return 100 + gaps


class _Row(QStyledItemDelegate):
    def sizeHint(self, _opt, _idx):  # noqa: N802
        return QSize(100, 38)

    def paint(self, p, opt, idx):
        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(opt.rect).adjusted(4, 1, -4, -1)
        selected = bool(opt.state & QStyle.StateFlag.State_Selected)
        if selected:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.accent, 0.16))
            p.drawRoundedRect(r, RADIUS["sm"], RADIUS["sm"])
        kind = idx.data(ROLE_KIND) or ""
        p.setFont(font(12))
        kw = QFontMetrics(p.font()).horizontalAdvance(kind) + 8
        p.setPen(qc(T.muted))
        p.drawText(QRect(opt.rect.right() - kw - 12, opt.rect.y(), kw, opt.rect.height()),
                   int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), kind)
        p.setFont(font(14, 600 if selected else 400))
        p.setPen(qc(T.accent if selected else T.fg))
        room = opt.rect.width() - kw - 40
        text = QFontMetrics(p.font()).elidedText(idx.data(Qt.ItemDataRole.DisplayRole) or "", Qt.TextElideMode.ElideRight, room)
        p.drawText(QRect(opt.rect.x() + 16, opt.rect.y(), room, opt.rect.height()),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), text)
        p.restore()


class QuickOpen(QWidget):
    """盖在窗口上的一层：点外面或按 Esc 关掉。"""
    W = 560

    def __init__(self, win, collect):
        super().__init__(win)
        self.win = win
        self.collect = collect      # () -> [(标题, 分类, 函数)]
        self.entries: list = []
        self.hide()
        self.box = QFrame(self)
        self.box.setObjectName("quickBox")
        v = QVBoxLayout(self.box)
        v.setContentsMargins(10, 10, 10, 8)
        v.setSpacing(6)
        self.edit = QLineEdit()
        self.edit.setObjectName("quickEdit")
        self.edit.setPlaceholderText("搜实验、工作台、题目、操作…  ↑↓ 选择，Enter 打开")
        self.edit.textChanged.connect(self.refresh)
        self.edit.installEventFilter(self)
        v.addWidget(self.edit)
        self.list = QListWidget()
        self.list.setItemDelegate(_Row(self.list))
        self.list.setFrameShape(QFrame.Shape.NoFrame)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.list.itemClicked.connect(lambda _i: self.accept())
        v.addWidget(self.list, 1)

    def open(self) -> None:
        self.entries = list(self.collect())
        self.setGeometry(self.win.rect())
        self.apply_theme()
        self.edit.clear()
        self.refresh("")
        self.show()
        self.raise_()
        self.edit.setFocus()

    def close_it(self) -> None:
        self.hide()
        self.win.setFocus()

    def apply_theme(self) -> None:
        self.setStyleSheet(
            f"QFrame#quickBox{{background:{T.raised};border:1px solid {T.line2};border-radius:{RADIUS['lg']}px;}}"
            f"QLineEdit#quickEdit{{font-size:15px;padding:8px 10px;background:{T.bg};color:{T.fg};border:1px solid {T.line};border-radius:{RADIUS['md']}px;}}"
            f"QListWidget{{background:transparent;}}")

    def resizeEvent(self, _e):  # noqa: N802
        w = min(self.W, self.width() - 40)
        h = min(470, self.height() - 120)
        self.box.setGeometry((self.width() - w) // 2, 60, w, h)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.fillRect(self.rect(), qc("#000000", 0.28))

    def mousePressEvent(self, e):  # noqa: N802
        if not self.box.geometry().contains(e.position().toPoint()):
            self.close_it()

    def refresh(self, text: str) -> None:
        q = text.strip()
        hits = []
        for order, (title, kind, fn) in enumerate(self.entries):
            s = score(q, title)
            if s < 0:
                s2 = score(q, kind)
                if s2 < 0 or s2 >= 100:
                    continue
                s = 200 + s2
            hits.append((s, order, title, kind, fn))
        hits.sort(key=lambda h: h[:2])
        self.list.clear()
        for _s, _o, title, kind, fn in hits[:MAX_ROWS]:
            item = QListWidgetItem(title)
            item.setData(ROLE_KIND, kind)
            item.setData(ROLE_ACT, fn)
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)

    def accept(self) -> None:
        item = self.list.currentItem()
        if item is None:
            return
        fn = item.data(ROLE_ACT)
        self.close_it()
        fn()

    def eventFilter(self, obj, event):  # noqa: N802
        if obj is self.edit:
            if event.type() == QEvent.Type.ShortcutOverride and event.key() == Qt.Key.Key_Escape:
                event.accept()    # 别让窗口的 Esc 快捷键抢走
                return True
            if event.type() == QEvent.Type.KeyPress:
                key = event.key()
                if key == Qt.Key.Key_Escape:
                    self.close_it()
                    return True
                if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                    self.accept()
                    return True
                if key in (Qt.Key.Key_Down, Qt.Key.Key_Up):
                    n = self.list.count()
                    if n:
                        step = 1 if key == Qt.Key.Key_Down else -1
                        self.list.setCurrentRow((self.list.currentRow() + step) % n)
                    return True
        return False


SHORTCUTS = (
    ("全局", (("Ctrl+K", "快速打开"), ("Ctrl+1 … 5", "习题 · 实验 · 工作 · 析题 · 课件"), ("F1", "这张表"), ("F11", "全屏"))),
    ("习题", (("Ctrl+F", "搜索题目"), ("Ctrl+← →", "上一步 / 下一步"), ("Ctrl+E", "导出图片"))),
    ("实验 / 工作台", (("Ctrl+F", "搜索（工作台里搜素材）"), ("Esc", "实验回首页；工作台回到选择工具"),
                     ("点数值", "直接输入精确值"), ("双击滑块", "回到初始值"))),
    ("析题", (("Ctrl+Enter", "开始分析"),)),
    ("课件 / 黑板", (("P H E L V", "笔 · 荧光笔 · 橡皮 · 激光 · 指针"), ("Ctrl+Z / Y", "撤销 / 重做"))),
    ("观澜", (("Alt+Shift+G", "展开或收起（全局）"), ("1 2 3 4", "切页"), ("← →", "换一条"), ("Esc", "返回或收起"))),
)


class ShortcutSheet(QWidget):
    """F1：快捷键一览。按任意键或点一下就关。"""
    closed = Signal()

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.hide()
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.box = QFrame(self)
        self.box.setObjectName("keysBox")
        self.grid = QGridLayout(self.box)
        self.grid.setContentsMargins(22, 18, 22, 18)
        self.grid.setHorizontalSpacing(18)
        self.grid.setVerticalSpacing(5)
        row = 0
        for section, items in SHORTCUTS:
            head = QLabel(section)
            head.setObjectName("keysHead")
            self.grid.addWidget(head, row, 0, 1, 2)
            row += 1
            for keys, text in items:
                k = QLabel(keys)
                k.setObjectName("keysKey")
                t = QLabel(text)
                t.setObjectName("keysText")
                self.grid.addWidget(k, row, 0)
                self.grid.addWidget(t, row, 1)
                row += 1

    def open(self) -> None:
        self.setGeometry(self.win.rect())
        self.setStyleSheet(
            f"QFrame#keysBox{{background:{T.raised};border:1px solid {T.line2};border-radius:{RADIUS['lg']}px;}}"
            f"QLabel#keysHead{{font-size:13px;font-weight:700;color:{T.accent};padding-top:6px;}}"
            f"QLabel#keysKey{{font-size:13px;font-weight:600;color:{T.fg};}}"
            f"QLabel#keysText{{font-size:13px;color:{T.muted};}}")
        self.show()
        self.raise_()
        self.setFocus()
        self.resizeEvent(None)

    def resizeEvent(self, _e):  # noqa: N802
        hint = self.box.sizeHint()
        self.box.setGeometry((self.width() - hint.width()) // 2, max(20, (self.height() - hint.height()) // 2), hint.width(), hint.height())

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.fillRect(self.rect(), qc("#000000", 0.28))

    def mousePressEvent(self, _e):  # noqa: N802
        self.hide()

    def keyPressEvent(self, _e):  # noqa: N802
        self.hide()

    def event(self, e):
        if e.type() == QEvent.Type.ShortcutOverride:
            e.accept()
            return True
        return super().event(e)
