# 见微 · 源码包 v2.6（2026-11-07）

这是「见微 · 高考学习舱」的 Python + PySide6 源码，可自行构建发行版。

## 结构（2.0：全部原生，不依赖网页与浏览器内核）

```
见微-源码/
├─ app/
│  ├─ main.py              程序入口（参数解析、主题、单实例）
│  ├─ shell.py             主窗口、托盘、页面路由、每日节律
│  ├─ pages.py             各页面 UI
│  ├─ ui_kit.py            主题与 QSS（白天/夜间）
│  ├─ scheduler.py         07:15 抓取 / 22:20 暮省
│  ├─ store.py             配置读写
│  ├─ guanlan_host.py      内嵌观澜：路径、数据目录、浮窗与胶囊
│  ├─ assets/              图标等
│  ├─ guanlan/             观澜源码（新闻抓取、暮省渲染、浮窗）
│  └─ native/              学习窗口（PySide6 + QPainter）
│     ├─ main_win.py       习题台 · 实验台 · 工作台 · 析题 四个模式
│     ├─ design/           设计令牌、控件
│     ├─ kit/              实验内核（Ctx、画笔、表达式、坐标视图、工作台框架）
│     ├─ lab/              67 个实验（exps/）、5 个工作台（benches/）；新增模块登记到 all_modules.py
│     ├─ bank/             习题台：206 题（questions.json）、四个引擎（subjects / physics / graph / solid）、知识卡、错题本
│     ├─ analysis/         析题：protocol.md、llm（DeepSeek）、lesson（流程）、tasks_*（17 个题型）、viz（分步图解）、offline（离线读题）
│     ├─ data_import.py    1.x 记录导入
│     └─ evening.py        暮省全屏播放（内容由 guanlan/core/evening.py 生成成纯数据）
├─ build.py                PyInstaller 打包脚本
├─ Jianwei.spec            打包配置
├─ make_shortcut.py        生成桌面快捷方式
├─ switch_to_jianwei.py    开发用：切换运行目标
├─ tools/                  审计与页面接线工具
├─ HANDOFF.md              逐次改动记录（排查问题先看这里）
└─ README-使用说明.md       面向使用者的说明（同绿色版）
```

## 构建

```powershell
python -m venv .venv
.venv\Scripts\pip install PySide6 pyinstaller requests beautifulsoup4
.venv\Scripts\python build.py
# 产物：dist\Jianwei\Jianwei.exe（onedir，带 _internal）
```

构建后可以：

```powershell
dist\Jianwei\Jianwei.exe --background     # 只进托盘
dist\Jianwei\Jianwei.exe --evening        # 手动跑一次暮省
dist\Jianwei\Jianwei.exe --evening-no-open # 只生成暮省页，不弹窗
```

## 开发要点

- **主题**：`html[data-theme]` + CSS 变量；白天/夜间共用骨架，只换配色。切主题派发 `jw-theme` 事件。
- **习题台/实验室**：静态页，`window.JW` 命名空间；视图通过 `JW.registerView(engine, mountFn)` 注册。
- **暮省**：先生成单文件 HTML，再用 Edge kiosk 打开；本机 UAC 关闭时 Chromium 沙箱起不来，
  启动参数必须带 `--no-sandbox`（见 `HANDOFF.md` §20），并配 `evening.lock` 防重复触发。
- **无头验证**：`msedge --headless=new --screenshot=...`；不要在前台弹测试窗口。

## 依赖

- Windows 10/11 64 位
- Python 3.12+（本机为 3.14）
- PySide6 6.12、PyInstaller
- 运行期需要 Edge 或 Chrome（打开习题台/实验室/暮省页）

更细的改动史、每个坑的定位过程都在 `HANDOFF.md`。

2.3 变更见 RELEASE-2.3.md；可复现发行入口：python tools/release.py build / smoke / pack。

