"""见微 · 时间胶囊：贴在桌面上的一把「时间尺」。

从开学到高考铺成一条刻度：一周一格、一月一道长刻度，走过的亮，朱砂指针是今天。
左边是印和剩余天数，右边是时钟。鼠标移到尺上能看任意一天还有多久；
拖动可以换位置（靠近屏幕中线会吸附），右键是常用操作，双击打开见微。

画面分三层：底（壁纸磨砂 + 墨 / 瓷底色）、动（指针的呼吸光）、面（文字和刻度）。
桌面浮窗把底和面各缓存成一张图，每帧只重画中间那层。
"""
from __future__ import annotations

import ctypes
import functools
import math
import os
import time
from datetime import datetime, timedelta

from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import (QColor, QFont, QGuiApplication, QImage, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap, QPolygonF, QRadialGradient)
from PySide6.QtWidgets import QMenu, QToolTip, QWidget

from native.design.tokens import T, family
from ui_kit import MONO, NUM, UI
import store

WEEKDAYS = "一二三四五六日"
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x00000020
WS_EX_LAYERED = 0x00080000
WS_EX_NOACTIVATE = 0x08000000
WDA_EXCLUDEFROMCAPTURE = 0x00000011
HWND_BOTTOM = 1
HWND_TOPMOST = -1
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010

SNAP_PX = 16      # 离屏幕中线这么近就吸过去
DRAG_PX = 4       # 移动超过这么多才算拖动，手抖不算

# 两套底色：墨（放在深色壁纸或默认）、瓷（放在浅色壁纸）
STYLES = {
    "ink": dict(body=(13, 24, 21), fg=(244, 248, 246), needle="#EE6448", mark="#E4B863", line=(255, 255, 255), k=1.65),
    "porcelain": dict(body=(245, 248, 245), fg=(20, 32, 29), needle="#C8402A", mark="#A87A2C", line=(20, 32, 29), k=1.95),
}


# ---------------------------------------------------------------- 数据
def phase_week() -> str:
    """本学期第几周（以 9 月 1 日为第 1 周）。"""
    today = datetime.now()
    start = datetime(today.year if today.month >= 9 else today.year - 1, 9, 1)
    return str(max(1, (today - start).days // 7 + 1))


def _days_text(now: datetime, target: datetime) -> tuple[str, str]:
    total = (target - now).total_seconds()
    if total <= 0:
        return "0", "已到"
    return str(int(total // 86400)), "天"


def parse_milestones(text: str) -> list[dict]:
    """「2027-03-10 一模；2027-04-20 二模」→ 节点列表。写错的段落跳过。"""
    out = []
    for part in str(text or "").replace("；", ";").replace("\n", ";").split(";"):
        bits = part.split(None, 1)
        if not bits:
            continue
        try:
            datetime.strptime(bits[0], "%Y-%m-%d")
        except ValueError:
            continue
        out.append(dict(date=bits[0], label=(bits[1].strip() if len(bits) > 1 else "")[:8]))
    return out[:12]


def format_milestones(items) -> str:
    return "；".join(f"{m.get('date', '')} {m.get('label', '')}".strip() for m in items or [] if isinstance(m, dict))


def _span(cfg: dict) -> tuple[datetime, datetime]:
    target = store.target_dt(cfg)
    try:
        start = store.start_dt(cfg)
    except Exception:
        start = target - timedelta(days=280)
    if start >= target:
        start = target - timedelta(days=280)
    return start, target


def _frac(cfg: dict, when: datetime) -> float:
    start, target = _span(cfg)
    return min(1.0, max(0.0, (when - start).total_seconds() / max(1.0, (target - start).total_seconds())))


def describe_day(cfg: dict, when: datetime, now: datetime) -> str:
    """尺上某一天的说明（鼠标悬停用）。"""
    target = store.target_dt(cfg)
    day = when.date()
    gap = (day - now.date()).days
    head = f"{day.month} 月 {day.day} 日 周{WEEKDAYS[day.weekday()]}"
    rel = "今天" if gap == 0 else f"再过 {gap} 天" if gap > 0 else f"{-gap} 天前"
    left = (target.date() - day).days
    tail = f"距{cfg.get('label', '高考')}还有 {left} 天" if left > 0 else f"{cfg.get('label', '高考')}当天" if left == 0 else ""
    marks = [m.get("label", "") for m in cfg.get("milestones") or [] if isinstance(m, dict) and m.get("date") == day.isoformat()]
    return " · ".join(x for x in ([head, rel, tail] + [x for x in marks if x]) if x)


# ---------------------------------------------------------------- 样式
_LUMA_CACHE: dict = {}


def resolve_style(cfg: dict, bg: QPixmap | None) -> dict:
    """auto：按胶囊底下那片壁纸的亮度选墨或瓷，文字总能看清。"""
    name = str(cfg.get("pillStyle", "auto"))
    if name not in STYLES:
        name = "ink"
        if bg is not None and not bg.isNull() and str(cfg.get("pillStyle", "auto")) == "auto":
            key = bg.cacheKey()
            luma = _LUMA_CACHE.get(key)
            if luma is None:
                _LUMA_CACHE.clear()
                luma = bg.toImage().scaled(1, 1).pixelColor(0, 0).lightnessF()
                _LUMA_CACHE[key] = luma
            name = "porcelain" if luma > 0.62 else "ink"
    return STYLES[name]


def _rgba(rgb, a: float) -> QColor:
    return QColor(rgb[0], rgb[1], rgb[2], max(0, min(255, int(a))))


# ---------------------------------------------------------------- 版面
def _layout(w: float, h: float) -> dict:
    s = max(0.72, h / 64.0)
    seal = h - 16 * s
    x_seal = 8 * s
    x_num = x_seal + seal + 11 * s
    right_w = 104 * s
    x_right = w - h * 0.42 - right_w
    return dict(s=s, seal=seal, x_seal=x_seal, x_num=x_num, x_right=x_right, right_w=right_w,
                base=h * 0.70, top=h * 0.47)


def _ruler_range(w: float, h: float, x_after_days: float) -> tuple[float, float]:
    g = _layout(w, h)
    x0 = x_after_days + 18 * g["s"]
    x1 = g["x_right"] - 20 * g["s"]
    return x0, max(x0 + 40, x1)


def _days_block_width(cfg: dict, now: datetime, s: float) -> float:
    """天数 + 单位 + 右边两行小字占多宽：决定尺从哪里开始。"""
    from PySide6.QtGui import QFontMetricsF
    days, _unit = _days_text(now, store.target_dt(cfg))
    num_w = QFontMetricsF(_font(_num_family(), 34 * s, 600)).horizontalAdvance(days)
    lab = f"距 {cfg.get('year', '2027')} {cfg.get('label', '高考')}"
    lab_w = QFontMetricsF(_font(UI, max(10.5, 11.5 * s), 500)).horizontalAdvance(lab)
    return num_w + 8 * s + lab_w


def ruler_geometry(w: float, h: float, cfg: dict, now: datetime) -> tuple[float, float]:
    g = _layout(w, h)
    return _ruler_range(w, h, g["x_num"] + _days_block_width(cfg, now, g["s"]))


def needle_x(w: float, h: float, cfg: dict, now: datetime) -> float:
    x0, x1 = ruler_geometry(w, h, cfg, now)
    return x0 + (x1 - x0) * _frac(cfg, now)


def day_at(x: float, w: float, h: float, cfg: dict, now: datetime) -> datetime | None:
    """窗口坐标 x 落在尺上的哪一天；不在尺上返回 None。"""
    x0, x1 = ruler_geometry(w, h, cfg, now)
    if x < x0 - 4 or x > x1 + 4:
        return None
    start, target = _span(cfg)
    k = min(1.0, max(0.0, (x - x0) / max(1.0, x1 - x0)))
    return start + (target - start) * k


# ---------------------------------------------------------------- 绘制
def draw_pill(p: QPainter, w: float, h: float, cfg: dict, now: datetime,
              bg: QPixmap | None, phase: float) -> None:
    """把胶囊画进 painter（坐标 0..w/0..h）。设置页预览与桌面浮窗共用。"""
    draw_pill_base(p, w, h, cfg, bg)
    draw_pill_motion(p, w, h, cfg, phase, now, bg)
    draw_pill_top(p, w, h, cfg, now, bg)


def _pill_path(w: float, h: float) -> QPainterPath:
    path = QPainterPath()
    path.addRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), h / 2.0, h / 2.0)
    return path


def draw_pill_base(p: QPainter, w: float, h: float, cfg: dict, bg: QPixmap | None) -> None:
    st = resolve_style(cfg, bg)
    path = _pill_path(w, h)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setClipPath(path)
    if bg is not None and not bg.isNull():
        p.drawPixmap(0, 0, int(w), int(h), bg)
    alpha = int(cfg.get("shade", 108)) * st["k"]
    grad = QLinearGradient(0, 0, 0, h)
    grad.setColorAt(0.0, _rgba(st["body"], alpha * 0.92))
    grad.setColorAt(1.0, _rgba(st["body"], alpha * 1.08))
    p.fillPath(path, grad)
    p.restore()


def draw_pill_motion(p: QPainter, w: float, h: float, cfg: dict, phase: float,
                     now: datetime | None = None, bg: QPixmap | None = None) -> None:
    """指针的呼吸光：很慢，只是告诉你它是活的。"""
    k = int(cfg.get("aurora", 96)) / 100.0
    if k <= 0:
        return
    now = now or datetime.now()
    st = resolve_style(cfg, bg)
    g = _layout(w, h)
    x = needle_x(w, h, cfg, now)
    y = g["base"]
    r = 15 * g["s"]
    breath = 0.55 + 0.45 * math.sin(phase * 1.15)
    col = QColor(st["needle"])
    rg = QRadialGradient(x, y, r)
    c0 = QColor(col)
    c0.setAlpha(int(min(190, 120 * k * breath)))
    c1 = QColor(col)
    c1.setAlpha(0)
    rg.setColorAt(0.0, c0)
    rg.setColorAt(1.0, c1)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setClipPath(_pill_path(w, h))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(rg)
    p.drawEllipse(QRectF(x - r, y - r, 2 * r, 2 * r))
    p.restore()


def _draw_ruler(p: QPainter, x0: float, x1: float, g: dict, h: float, cfg: dict, now: datetime, st: dict) -> None:
    s, base, top = g["s"], g["base"], g["top"]
    start, target = _span(cfg)
    total = max(1.0, (target - start).total_seconds())
    width = x1 - x0
    frac = _frac(cfg, now)
    fg, line = st["fg"], st["line"]

    def x_of(when: datetime) -> float:
        return x0 + width * min(1.0, max(0.0, (when - start).total_seconds() / total))

    # 周刻度：格子太密就两周一格
    p.save()
    weeks = max(1, int(total // (86400 * 7)))
    step = 1
    while width / (weeks / step) < 4.5 * s and step < 8:
        step *= 2
    p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
    tick = base - 5 * s
    for i in range(0, weeks + 1, step):
        x = x0 + width * i / weeks
        passed = i / weeks <= frac
        p.setPen(QPen(_rgba(line, 165 if passed else 62), 1))
        p.drawLine(QPointF(x, tick), QPointF(x, base))

    # 月份：长刻度 + 标签；放不下就隔一个写
    months = []
    y, m = start.year, start.month
    while True:
        when = datetime(y, m, 1)
        if when > target:
            break
        if when >= start:
            months.append(when)
        m += 1
        if m == 13:
            y, m = y + 1, 1
    gap = width / max(1, len(months))
    every = 1 if gap >= 27 * s else 2 if gap >= 14 * s else 3
    p.setFont(_font(UI, max(9.5, 10.5 * s), 500))
    for i, when in enumerate(months):
        x = x_of(when)
        passed = x <= x0 + width * frac
        p.setPen(QPen(_rgba(line, 215 if passed else 95), 1))
        p.drawLine(QPointF(x, base - 10 * s), QPointF(x, base))
        near = abs(x + 12 * s - (x0 + width * frac)) < 16 * s   # 指针帽正好压在这个月的字上时不写字
        if i % every == 0 and h >= 50 and not near:
            p.setPen(_rgba(fg, 175 if passed else 100))
            p.drawText(QRectF(x - 2, top - 15 * s, 40 * s, 14 * s),
                       int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), f"{when.month}月")
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    # 基线：走过的亮
    nx = x0 + width * frac
    p.setPen(QPen(_rgba(line, 60), 1))
    p.drawLine(QPointF(x0, base + .5), QPointF(x1, base + .5))
    p.setPen(QPen(_rgba(line, 225), 1.6))
    p.drawLine(QPointF(x0, base + .5), QPointF(nx, base + .5))

    # 自己加的节点（一模、二模……）
    mark = QColor(st["mark"])
    for item in cfg.get("milestones") or []:
        try:
            when = datetime.strptime(str(item.get("date")), "%Y-%m-%d")
        except (ValueError, AttributeError):
            continue
        if not start <= when <= target:
            continue
        x = x_of(when)
        d = 3.2 * s
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(mark)
        p.drawPolygon(QPolygonF([QPointF(x, base - d + .5), QPointF(x + d, base + .5), QPointF(x, base + d + .5), QPointF(x - d, base + .5)]))
        if item.get("label") and h >= 58:
            p.setFont(_font(UI, max(9.5, 10 * s), 500))
            p.setPen(mark)
            p.drawText(QRectF(x - 30 * s, base + 3 * s, 60 * s, 13 * s), int(Qt.AlignmentFlag.AlignCenter), str(item["label"]))

    # 终点：考试那天
    p.setPen(QPen(_rgba(line, 225), 1.6))
    p.drawLine(QPointF(x1, base - 11 * s), QPointF(x1, base + .5))

    # 今天：朱砂指针
    needle = QColor(st["needle"])
    p.setPen(QPen(needle, 2))
    p.drawLine(QPointF(nx, top - 3 * s), QPointF(nx, base + 4 * s))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(needle)
    cap = 3.6 * s
    p.drawPolygon(QPolygonF([QPointF(nx - cap, top - 6 * s), QPointF(nx + cap, top - 6 * s), QPointF(nx, top - 1 * s)]))
    p.restore()


def draw_pill_top(p: QPainter, w: float, h: float, cfg: dict, now: datetime, bg: QPixmap | None = None) -> None:
    st = resolve_style(cfg, bg)
    g = _layout(w, h)
    s = g["s"]
    fg = st["fg"]
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

    # 描边
    p.setPen(QPen(_rgba(st["line"], 52), 1.0))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRoundedRect(QRectF(0.6, 0.6, w - 1.2, h - 1.2), h / 2 - .4, h / 2 - .4)

    # 印：正好嵌在胶囊的半圆里
    d = g["seal"]
    rect = QRectF(g["x_seal"], (h - d) / 2, d, d)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#C8402A"))
    p.drawEllipse(rect)
    p.setFont(_font(family("serif"), d * .56, 700))
    p.setPen(QColor("#FFFFFF"))
    p.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), "见")

    # 天数
    target = store.target_dt(cfg)
    days, unit = _days_text(now, target)
    left = (target - now).total_seconds()
    urgent = 0 < left <= 100 * 86400
    num_font = _font(_num_family(), 34 * s, 600)
    p.setFont(num_font)
    num_w = p.fontMetrics().horizontalAdvance(days)
    p.setPen(QColor(st["needle"]) if urgent else _rgba(fg, 255))
    p.drawText(QRectF(g["x_num"], 0, num_w + 4, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), days)
    lx = g["x_num"] + num_w + 8 * s
    lab_w = _days_block_width(cfg, now, s) - num_w - 8 * s + 6
    p.setFont(_font(UI, max(10.5, 11.5 * s), 600))
    p.setPen(_rgba(fg, 232))
    p.drawText(QRectF(lx, h * .17, lab_w, h * .33), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
               unit if left <= 0 else f"{unit} · 第{phase_week()}周")
    p.setFont(_font(UI, max(10, 11 * s), 400))
    p.setPen(_rgba(fg, 165))
    p.drawText(QRectF(lx, h * .50, lab_w, h * .33), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
               f"距 {cfg.get('year', '2027')} {cfg.get('label', '高考')}")

    # 时间尺
    x0, x1 = ruler_geometry(w, h, cfg, now)
    if x1 - x0 >= 60:
        _draw_ruler(p, x0, x1, g, h, cfg, now, st)

    # 时钟
    rx, rw = g["x_right"], g["right_w"]
    show_date = cfg.get("showDate", True)
    clock_h = h * (.56 if show_date else 1.0)
    align_v = Qt.AlignmentFlag.AlignBottom if show_date else Qt.AlignmentFlag.AlignVCenter
    p.setFont(_font(_num_family(), max(15, 20 * s), 500))
    fm = p.fontMetrics()
    main = now.strftime("%H:%M")
    if cfg.get("showSeconds", True):
        sec = now.strftime(":%S")
        p.setFont(_font(_num_family(), max(11, 13 * s), 500))
        sec_w = p.fontMetrics().horizontalAdvance(sec)
        p.setPen(_rgba(fg, 150))
        p.drawText(QRectF(rx, 0, rw, clock_h - 1.5 * s), int(Qt.AlignmentFlag.AlignRight | align_v), sec)
        p.setFont(_font(_num_family(), max(15, 20 * s), 500))
        p.setPen(_rgba(fg, 255))
        p.drawText(QRectF(rx, 0, rw - sec_w - 1, clock_h), int(Qt.AlignmentFlag.AlignRight | align_v), main)
    else:
        p.setPen(_rgba(fg, 255))
        p.drawText(QRectF(rx, 0, rw, clock_h), int(Qt.AlignmentFlag.AlignRight | align_v), main)
    if show_date:
        p.setFont(_font(UI, max(10, 11 * s), 400))
        p.setPen(_rgba(fg, 165))
        p.drawText(QRectF(rx, h * .57, rw, h * .32), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop),
                   f"{now.month} 月 {now.day} 日 周{WEEKDAYS[now.weekday()]}")
    _ = fm
    p.restore()


_NUM_FAMILY = None


def _num_family() -> str:
    """数字用等高的仪表字体（旧式数字的 5、9 会掉到基线下面）。"""
    global _NUM_FAMILY
    if _NUM_FAMILY is None:
        from PySide6.QtGui import QFontDatabase
        fams = set(QFontDatabase.families())
        _NUM_FAMILY = next((f for f in ("Bahnschrift", "Segoe UI", "Cambria") if f in fams), NUM)
    return _NUM_FAMILY


@functools.lru_cache(maxsize=64)
def _font(family_name: str, px: float, weight: int = 400, spacing: float = 0.0) -> QFont:
    font = QFont(family_name)
    font.setPixelSize(max(7, int(round(px))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    font.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    return font


# 帧率：呼吸光很慢，10 fps 看不出差别；关掉光效时只有时钟要走
FRAME_IDLE_MS = 100
FRAME_STILL_MS = 250


class CountdownPill(QWidget):
    moved = Signal(object, int)   # 屏幕水平位置（None 表示居中）、距顶部
    action = Signal(str)          # 右键和双击的操作，由主壳处理

    def __init__(self, cfg: dict):
        super().__init__(None, Qt.WindowType.FramelessWindowHint
                         | Qt.WindowType.Tool
                         | Qt.WindowType.WindowDoesNotAcceptFocus
                         | Qt.WindowType.NoDropShadowWindowHint)
        self.cfg = dict(cfg)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setMouseTracking(True)
        self.setWindowTitle("见微 · 时间胶囊")
        self._bg: QPixmap | None = None
        self._bg_at = 0.0
        self._t0 = time.monotonic()
        self._press: QPoint | None = None   # 按下时鼠标相对窗口的位置
        self._dragging = False
        self._hover_x: float | None = None
        self._base: QPixmap | None = None   # 底层缓存：尺寸 / 配置 / 壁纸变了才重画
        self._top: QPixmap | None = None    # 面层缓存：每秒（时钟变了）重画一次
        self._top_key = None
        self._cover = None                  # 铺满屏幕的壁纸，屏幕尺寸或壁纸文件变了才重算
        self._cover_key = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._z_timer = QTimer(self)
        self._z_timer.timeout.connect(self._assert_zorder)
        self.apply_config(self.cfg)
        self._timer.start(FRAME_IDLE_MS)

    # ------------------------------------------------------------ 配置
    def _screen_geo(self):
        return (self.screen() or QGuiApplication.primaryScreen()).availableGeometry()

    def apply_config(self, cfg: dict) -> None:
        self.cfg = dict(cfg)
        self._base = None
        self._top = None
        w = int(cfg.get("width", 880))
        h = int(cfg.get("height", 64))
        screen = QGuiApplication.primaryScreen().availableGeometry()
        x = cfg.get("pillX")
        if isinstance(x, int):
            # 换过屏幕或分辨率时，不能把胶囊留在看不见的地方
            full = QGuiApplication.primaryScreen().virtualGeometry()
            x = max(full.left(), min(full.right() - w + 1, x))
        else:
            x = screen.x() + (screen.width() - w) // 2
        y = screen.y() + max(0, min(screen.height() - h, int(cfg.get("marginTop", 22))))
        self.setGeometry(x, y, w, h)
        self.setWindowOpacity(float(cfg.get("opacity", 0.98)))
        self._apply_flags()
        self._assert_zorder()
        self.update()

    def _assert_zorder(self) -> None:
        """默认沉到最底层：只在桌面 / 壁纸上可见，任何应用窗口都能压住它。"""
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_NOACTIVATE
            if self.cfg.get("clickThrough"):
                style |= WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
            target = HWND_TOPMOST if str(self.cfg.get("zorder", "bottom")) == "top" else HWND_BOTTOM
            user32.SetWindowPos(hwnd, target, 0, 0, 0, 0,
                                SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)
        except Exception:
            pass

    def _apply_flags(self) -> None:
        if not self.isVisible():
            return
        try:
            hwnd = int(self.winId())
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= WS_EX_LAYERED
            if self.cfg.get("clickThrough"):
                style |= WS_EX_TRANSPARENT
            else:
                style &= ~WS_EX_TRANSPARENT
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        except Exception:
            pass

    def showEvent(self, ev) -> None:
        super().showEvent(ev)
        try:
            ctypes.windll.user32.SetWindowDisplayAffinity(int(self.winId()), WDA_EXCLUDEFROMCAPTURE)
        except Exception:
            pass
        self._apply_flags()
        self._assert_zorder()
        self._grab_bg()
        # 频繁重申置底会和别的置底窗互相抢，画面一直在闪；1 分钟兜底一次
        self._z_timer.start(60000)

    def hideEvent(self, ev) -> None:
        self._z_timer.stop()
        super().hideEvent(ev)

    # ------------------------------------------------------------ 帧
    def _tick(self) -> None:
        if not self.isVisible():
            return
        now = time.monotonic()
        if now - self._bg_at > 30:
            self._grab_bg()
            self._bg_at = now
        interval = FRAME_IDLE_MS if int(self.cfg.get("aurora", 96)) > 0 else FRAME_STILL_MS
        if self._timer.interval() != interval:
            self._timer.setInterval(interval)
        self.update()

    def resizeEvent(self, ev) -> None:
        self._base = None
        self._top = None
        super().resizeEvent(ev)

    @staticmethod
    def _wallpaper_key():
        """当前壁纸文件 + 修改时间：用来判断要不要重新读图（换壁纸后 30 秒内跟上）。"""
        try:
            buf = ctypes.create_unicode_buffer(1024)
            ok = ctypes.windll.user32.SystemParametersInfoW(0x0073, 1024, buf, 0)
            path = buf.value
            if ok and path and os.path.exists(path):
                return path, os.path.getmtime(path)
        except Exception:
            pass
        return None

    def _load_wallpaper(self):
        key = self._wallpaper_key()
        if key is None:
            return None
        img = QImage(key[0])
        return None if img.isNull() else img

    def _grab_bg(self) -> None:
        """取壁纸对应位置的一小片，重采样到极低分辨率再放大 —— 磨砂玻璃的底。

        实时截屏在这里不可用：本机 SetWindowDisplayAffinity 失败，截出来会把胶囊自己
        拍进去（越拍越黑）。壁纸磨砂在视觉上等价，且永不递归、几乎不耗 CPU。
        """
        try:
            screen = (self.screen() or QGuiApplication.primaryScreen()).geometry()
            W, H = screen.width(), screen.height()
            w, h = max(2, self.width()), max(2, self.height())
            # 整张壁纸的平滑缩放要几十毫秒：只在壁纸文件或屏幕尺寸变了时重算，平时只裁一小块
            key = (self._wallpaper_key(), W, H)
            if key != self._cover_key:
                self._cover_key = key
                img = self._load_wallpaper() if key[0] is not None else None
                if img is None:
                    self._cover = None
                else:
                    scale = max(W / max(1, img.width()), H / max(1, img.height()))
                    self._cover = img.scaled(int(img.width() * scale + 0.5), int(img.height() * scale + 0.5),
                                             Qt.AspectRatioMode.IgnoreAspectRatio,
                                             Qt.TransformationMode.SmoothTransformation)
            cover = self._cover
            if cover is None:
                if self._bg is not None:
                    self._bg = None
                    self._base = None
                return
            sw, sh = cover.width(), cover.height()
            ox = max(0, min(sw - w, self.x() - screen.x() + (sw - W) // 2))
            oy = max(0, min(sh - h, self.y() - screen.y() + (sh - H) // 2))
            crop = cover.copy(ox, oy, w, h)
            small = crop.scaled(max(6, w // 18), max(5, h // 18),
                                Qt.AspectRatioMode.IgnoreAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
            self._bg = QPixmap.fromImage(small.scaled(
                w, h, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation))
        except Exception:
            self._bg = None
        self._base = None
        self._top = None   # 墨 / 瓷可能换了

    def _layer(self, draw) -> QPixmap:
        dpr = self.devicePixelRatioF()
        pm = QPixmap(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.GlobalColor.transparent)
        q = QPainter(pm)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        draw(q)
        q.end()
        return pm

    def paintEvent(self, _ev) -> None:
        w, h, cfg = self.width(), self.height(), self.cfg
        now = datetime.now()
        if self._base is None:
            self._base = self._layer(lambda q: draw_pill_base(q, w, h, cfg, self._bg))
        top_key = (now.strftime("%Y%m%d%H%M%S"), round(self.devicePixelRatioF(), 3))
        if self._top is None or self._top_key != top_key:
            self._top = self._layer(lambda q: draw_pill_top(q, w, h, cfg, now, self._bg))
            self._top_key = top_key
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.drawPixmap(0, 0, self._base)
        draw_pill_motion(p, w, h, cfg, time.monotonic() - self._t0, now, self._bg)
        p.drawPixmap(0, 0, self._top)
        if self._hover_x is not None:   # 悬停的那一天
            g = _layout(w, h)
            st = resolve_style(cfg, self._bg)
            p.setPen(QPen(_rgba(st["line"], 200), 1, Qt.PenStyle.DashLine))
            p.drawLine(QPointF(self._hover_x, g["top"] - 2), QPointF(self._hover_x, g["base"] + 3))
        p.end()

    # ------------------------------------------------------------ 鼠标
    def mousePressEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        if ev.button() == Qt.MouseButton.LeftButton:
            self._press = ev.position().toPoint()
            self._dragging = False

    def mouseMoveEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        if self._press is not None:
            pos = ev.position().toPoint()
            if not self._dragging and (pos - self._press).manhattanLength() >= DRAG_PX:
                self._dragging = True
                self._set_hover(None)
                QToolTip.hideText()
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
            if self._dragging:
                self.move(self._snapped(ev.globalPosition().toPoint() - self._press))
            return
        day = day_at(ev.position().x(), self.width(), self.height(), self.cfg, datetime.now())
        if day is None:
            self._set_hover(None)
            QToolTip.hideText()
        else:
            self._set_hover(ev.position().x())
            QToolTip.showText(ev.globalPosition().toPoint() + QPoint(0, 18), describe_day(self.cfg, day, datetime.now()), self)

    def _snapped(self, top_left: QPoint) -> QPoint:
        """靠近屏幕中线就吸过去；不让胶囊拖出屏幕。"""
        geo = self._screen_geo()
        x = top_left.x()
        mid = geo.x() + (geo.width() - self.width()) // 2
        if abs(x - mid) <= SNAP_PX:
            x = mid
        y = max(geo.y(), min(geo.bottom() - self.height() + 1, top_left.y()))
        return QPoint(x, y)

    def _set_hover(self, x) -> None:
        if x != self._hover_x:
            self._hover_x = x
            self.update()

    def leaveEvent(self, ev) -> None:
        self._set_hover(None)
        super().leaveEvent(ev)

    def mouseReleaseEvent(self, ev) -> None:
        if self._press is None:
            return
        was_drag = self._dragging
        self._press, self._dragging = None, False
        self.unsetCursor()
        if was_drag:
            self.cfg["pillX"] = self.x()
            self._grab_bg()
            geo = self._screen_geo()
            centered = self.x() == geo.x() + (geo.width() - self.width()) // 2
            self.cfg["pillX"] = None if centered else self.x()
            self.cfg["marginTop"] = self.y() - geo.y()
            self.moved.emit(self.cfg["pillX"], self.cfg["marginTop"])

    def mouseDoubleClickEvent(self, ev) -> None:
        if ev.button() == Qt.MouseButton.LeftButton and not self.cfg.get("clickThrough"):
            self._press, self._dragging = None, False
            self.action.emit("open")

    def contextMenuEvent(self, ev) -> None:
        if self.cfg.get("clickThrough"):
            return
        QToolTip.hideText()
        self.build_menu().exec(ev.globalPos())

    def build_menu(self) -> QMenu:
        menu = QMenu(self)
        menu.setStyleSheet(
            f"QMenu{{background:{T.raised};color:{T.fg};border:1px solid {T.line2};padding:4px;font-size:12.5px;}}"
            f"QMenu::item{{padding:6px 24px 6px 12px;border-radius:3px;}}"
            f"QMenu::item:selected{{background:{T.hover};}}"
            f"QMenu::separator{{height:1px;background:{T.line};margin:4px 6px;}}"
            f"QMenu::indicator{{width:13px;height:13px;left:4px;}}")

        def add(text, key, checked=None):
            a = menu.addAction(text)
            if checked is not None:
                a.setCheckable(True)
                a.setChecked(checked)
            a.triggered.connect(lambda _=False, k=key: self.action.emit(k))
            return a
        add("打开见微", "open")
        add("观澜", "guanlan")
        add("习题台", "studio")
        menu.addSeparator()
        add("总在最前", "top", str(self.cfg.get("zorder", "bottom")) == "top")
        add("显示秒", "seconds", bool(self.cfg.get("showSeconds", True)))
        add("回到顶部居中", "center")
        add("胶囊设置…", "settings")
        menu.addSeparator()
        add("隐藏胶囊", "hide")
        return menu

    def closeEvent(self, ev) -> None:
        self._timer.stop()
        self._z_timer.stop()
        super().closeEvent(ev)


_ = (MONO,)
