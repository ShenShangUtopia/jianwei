"""线性图标：统一圆头描边，坐标系 0..18，按目标矩形缩放。全界面的图标都从这里画。"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QPainter, QPainterPath, QPen


def draw_icon(p: QPainter, name: str, rect, color, width: float = 1.6) -> None:
    r = QRectF(rect)
    s = min(r.width(), r.height()) / 18.0
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.translate(r.x() + (r.width() - 18 * s) / 2, r.y() + (r.height() - 18 * s) / 2)
    p.scale(s, s)
    pen = QPen(color, width / s)   # 描边保持屏幕上 width 像素，不随图标缩放变粗变细
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    f = _ICONS.get(name)
    if f:
        f(p, color)
    p.restore()


def _pt(*xy):
    return [QPointF(xy[i], xy[i + 1]) for i in range(0, len(xy), 2)]


def _lines(p, *segs):
    for x1, y1, x2, y2 in segs:
        p.drawLine(QPointF(x1, y1), QPointF(x2, y2))


def _fill_dot(p, c, x, y, r):
    p.save()
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(c)
    p.drawEllipse(QPointF(x, y), r, r)
    p.restore()


# ---------------------------------------------------------------- 通用
def _menu(p, c):
    _lines(p, (3, 5, 15, 5), (3, 9, 15, 9), (3, 13, 15, 13))


def _more(p, c):
    for x in (4, 9, 14):
        _fill_dot(p, c, x, 9, 1.3)


def _search(p, c):
    p.drawEllipse(QPointF(8, 8), 4.6, 4.6)
    p.drawLine(QPointF(11.4, 11.4), QPointF(15, 15))


def _sun(p, c):
    p.drawEllipse(QPointF(9, 9), 3.4, 3.4)
    for k in range(8):
        a = k * math.pi / 4
        p.drawLine(QPointF(9 + 5.6 * math.cos(a), 9 + 5.6 * math.sin(a)), QPointF(9 + 7.2 * math.cos(a), 9 + 7.2 * math.sin(a)))


def _moon(p, c):
    path = QPainterPath(QPointF(14.6, 11.2))
    path.cubicTo(10.4, 12.8, 5.4, 8.8, 7, 3.2)
    path.cubicTo(3.2, 4.2, 1.8, 8.4, 3.4, 11.6)
    path.cubicTo(5.4, 15.8, 11.4, 16.2, 14.6, 11.2)
    p.drawPath(path)


def _reset(p, c):
    path = QPainterPath()
    path.arcMoveTo(QRectF(3, 3, 12, 12), 60)
    path.arcTo(QRectF(3, 3, 12, 12), 60, 280)
    p.drawPath(path)
    p.drawPolyline(_pt(12, 2.5, 12.2, 5.6, 9.2, 5.8))


def _camera(p, c):
    p.drawRoundedRect(QRectF(2.5, 5, 13, 9.5), 2, 2)
    p.drawEllipse(QPointF(9, 9.8), 2.8, 2.8)
    p.drawPolyline(_pt(6.5, 5, 7.6, 3.2, 10.4, 3.2, 11.5, 5))


def _full(p, c):
    for (x, y, dx, dy) in ((3, 3, 1, 1), (15, 3, -1, 1), (3, 15, 1, -1), (15, 15, -1, -1)):
        p.drawLine(QPointF(x, y), QPointF(x + 4 * dx, y))
        p.drawLine(QPointF(x, y), QPointF(x, y + 4 * dy))


def _side(p, c):
    p.drawRoundedRect(QRectF(2.5, 3.5, 13, 11), 2, 2)
    p.drawLine(QPointF(11, 3.5), QPointF(11, 14.5))


def _home(p, c):
    p.drawPolyline(_pt(2.5, 9, 9, 3, 15.5, 9))
    p.drawPolyline(_pt(4.5, 7.5, 4.5, 15, 13.5, 15, 13.5, 7.5))


def _grid(p, c):
    p.drawRoundedRect(QRectF(3, 3, 5, 5), 1, 1)
    p.drawRoundedRect(QRectF(10, 3, 5, 5), 1, 1)
    p.drawRoundedRect(QRectF(3, 10, 5, 5), 1, 1)
    p.drawRoundedRect(QRectF(10, 10, 5, 5), 1, 1)


def _play(p, c):
    path = QPainterPath(QPointF(5.5, 3.5))
    path.lineTo(14, 9)
    path.lineTo(5.5, 14.5)
    path.closeSubpath()
    p.drawPath(path)


def _pause(p, c):
    _lines(p, (6.5, 4, 6.5, 14), (11.5, 4, 11.5, 14))


def _spark(p, c):
    path = QPainterPath(QPointF(9, 2.5))
    path.quadTo(9.6, 8.4, 15.5, 9)
    path.quadTo(9.6, 9.6, 9, 15.5)
    path.quadTo(8.4, 9.6, 2.5, 9)
    path.quadTo(8.4, 8.4, 9, 2.5)
    p.drawPath(path)


def _close(p, c):
    _lines(p, (4.5, 4.5, 13.5, 13.5), (13.5, 4.5, 4.5, 13.5))


def _min(p, c):
    p.drawLine(QPointF(4, 9), QPointF(14, 9))


def _undo(p, c):
    p.drawPolyline(_pt(6.6, 3.6, 3.2, 7, 6.6, 10.4))
    path = QPainterPath(QPointF(3.2, 7))
    path.lineTo(10.6, 7)
    path.cubicTo(16, 7, 16, 14.6, 10.6, 14.6)
    path.lineTo(7, 14.6)
    p.drawPath(path)


def _redo(p, c):
    p.drawPolyline(_pt(11.4, 3.6, 14.8, 7, 11.4, 10.4))
    path = QPainterPath(QPointF(14.8, 7))
    path.lineTo(7.4, 7)
    path.cubicTo(2, 7, 2, 14.6, 7.4, 14.6)
    path.lineTo(11, 14.6)
    p.drawPath(path)


def _plus(p, c):
    _lines(p, (9, 3.5, 9, 14.5), (3.5, 9, 14.5, 9))


def _trash(p, c):
    _lines(p, (3, 5, 15, 5), (7, 5, 7.6, 2.8), (7.6, 2.8, 10.4, 2.8), (10.4, 2.8, 11, 5), (7.6, 8, 7.6, 12.6), (10.4, 8, 10.4, 12.6))
    p.drawPolyline(_pt(4.4, 5, 5.2, 15.4, 12.8, 15.4, 13.6, 5))


def _chevron_l(p, c):
    p.drawPolyline(_pt(11, 3.5, 5.5, 9, 11, 14.5))


def _chevron_r(p, c):
    p.drawPolyline(_pt(7, 3.5, 12.5, 9, 7, 14.5))


def _chevron_d(p, c):
    p.drawPolyline(_pt(4, 7, 9, 12, 14, 7))


def _basket(p, c):
    p.drawRoundedRect(QRectF(2.6, 6.4, 12.8, 8.8), 1.8, 1.8)
    p.drawPolyline(_pt(5.2, 6.4, 5.2, 3, 12.8, 3, 12.8, 6.4))
    p.drawLine(QPointF(6.4, 10), QPointF(11.6, 10))


def _send(p, c):
    p.drawPolyline(_pt(9, 11.8, 9, 3, ))
    p.drawPolyline(_pt(5.4, 6.4, 9, 2.8, 12.6, 6.4))
    p.drawPolyline(_pt(3, 10.5, 3, 15, 15, 15, 15, 10.5))


def _board(p, c):
    p.drawRoundedRect(QRectF(2.2, 3, 13.6, 9.6), 1.4, 1.4)
    _lines(p, (6, 12.6, 4.6, 15.6), (12, 12.6, 13.4, 15.6), (5, 6.6, 9.6, 6.6), (5, 9.2, 12, 9.2))


# ---------------------------------------------------------------- 模式
def _today(p, c):
    p.drawRoundedRect(QRectF(2.5, 3.8, 13, 11.7), 2.2, 2.2)
    _lines(p, (2.5, 7.4, 15.5, 7.4), (6, 2.2, 6, 5), (12, 2.2, 12, 5))
    _fill_dot(p, c, 11.4, 11.4, 1.4)


def _guanlan(p, c):
    for y0 in (6.6, 11.6):
        path = QPainterPath(QPointF(2, y0))
        for i in range(1, 29):
            x = 2 + i * 0.5
            path.lineTo(x, y0 + 1.6 * math.sin((x - 2) / 14 * 2 * math.pi * 1.5))
        p.drawPath(path)


def _countdown(p, c):
    _lines(p, (4, 2.5, 14, 2.5), (4, 15.5, 14, 15.5))
    path = QPainterPath(QPointF(5, 2.5))
    path.cubicTo(5, 7, 8.6, 7.6, 8.6, 9)
    path.cubicTo(8.6, 10.4, 5, 11, 5, 15.5)
    p.drawPath(path)
    path = QPainterPath(QPointF(13, 2.5))
    path.cubicTo(13, 7, 9.4, 7.6, 9.4, 9)
    path.cubicTo(9.4, 10.4, 13, 11, 13, 15.5)
    p.drawPath(path)


def _desk(p, c):
    p.drawRoundedRect(QRectF(3.2, 2.2, 11.6, 13.6), 2, 2)
    _lines(p, (6, 6, 12, 6), (6, 8.8, 10.4, 8.8))
    p.drawPolyline(_pt(6.2, 12, 7.8, 13.4, 11.4, 10.6))


def _lab(p, c):
    path = QPainterPath(QPointF(7, 2.4))
    path.lineTo(7, 7)
    path.lineTo(3, 14)
    path.quadTo(2.6, 15.6, 4.4, 15.6)
    path.lineTo(13.6, 15.6)
    path.quadTo(15.4, 15.6, 15, 14)
    path.lineTo(11, 7)
    path.lineTo(11, 2.4)
    p.drawPath(path)
    _lines(p, (6, 2.4, 12, 2.4), (5, 11.4, 13, 11.4))


def _bench(p, c):
    # 工作台：一只扳手式的卡尺 + 台面
    _lines(p, (2.4, 14.8, 15.6, 14.8), (4.6, 14.8, 4.6, 10.4), (13.4, 14.8, 13.4, 10.4))
    p.drawRoundedRect(QRectF(3, 6.8, 12, 3.6), 1, 1)
    _lines(p, (6, 6.8, 6, 3.2), (6, 3.2, 12, 3.2), (12, 3.2, 12, 6.8))


def _analysis(p, c):
    # 析题：放大镜里一条折线
    p.drawEllipse(QPointF(7.8, 7.8), 5.4, 5.4)
    p.drawLine(QPointF(11.8, 11.8), QPointF(15.6, 15.6))
    p.drawPolyline(_pt(5, 9.6, 7, 7.4, 8.6, 8.8, 10.8, 6))


def _lecture(p, c):
    p.drawRoundedRect(QRectF(2.2, 2.8, 13.6, 9.6), 1.4, 1.4)
    _lines(p, (9, 12.4, 9, 15.6), (6, 15.6, 12, 15.6))
    path = QPainterPath(QPointF(7.4, 5.2))
    path.lineTo(11.4, 7.6)
    path.lineTo(7.4, 10)
    path.closeSubpath()
    p.drawPath(path)


def _settings(p, c):
    for y, kx in ((4.5, 11.5), (9, 6.5), (13.5, 10)):
        p.drawLine(QPointF(2.5, y), QPointF(kx - 2.4, y))
        p.drawLine(QPointF(kx + 2.4, y), QPointF(15.5, y))
        p.drawEllipse(QPointF(kx, y), 1.9, 1.9)


# ---------------------------------------------------------------- 画笔
def _pointer(p, c):
    path = QPainterPath(QPointF(4, 2.6))
    path.lineTo(14, 9.6)
    path.lineTo(9.4, 10.4)
    path.lineTo(7.2, 14.8)
    path.closeSubpath()
    p.drawPath(path)


def _pen(p, c):
    path = QPainterPath(QPointF(3, 15))
    path.lineTo(3.8, 11.4)
    path.lineTo(12.2, 3)
    path.lineTo(15, 5.8)
    path.lineTo(6.6, 14.2)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(10.6, 4.6), QPointF(13.4, 7.4))


def _marker(p, c):
    path = QPainterPath(QPointF(6.2, 12.4))
    path.lineTo(3.6, 9.8)
    path.lineTo(10.8, 2.6)
    path.lineTo(15.4, 7.2)
    path.lineTo(8.2, 14.4)
    path.closeSubpath()
    p.drawPath(path)
    p.drawPolyline(_pt(4.8, 11, 2.6, 15.4, 7, 13.2))


def _chalk(p, c):
    p.save()
    p.translate(9, 8)
    p.rotate(-35)
    p.drawRoundedRect(QRectF(-6.4, -2.2, 12.8, 4.4), 1, 1)
    p.drawLine(QPointF(2.4, -2.2), QPointF(2.4, 2.2))
    p.restore()
    p.drawLine(QPointF(9, 15.4), QPointF(15.6, 15.4))


def _eraser(p, c):
    path = QPainterPath(QPointF(6.4, 14.8))
    path.lineTo(2.8, 11.2)
    path.lineTo(10, 3.2)
    path.lineTo(15.4, 8.6)
    path.lineTo(9.4, 14.8)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(6, 7.6), QPointF(11.2, 12.8))
    p.drawLine(QPointF(9.4, 15.4), QPointF(15.6, 15.4))


def _lasso(p, c):
    path = QPainterPath()
    path.addEllipse(QRectF(2.8, 2.8, 12.4, 8.8))
    pen = p.pen()
    pen.setDashPattern([2.4, 2.0])
    p.setPen(pen)
    p.drawPath(path)
    pen.setStyle(Qt.PenStyle.SolidLine)
    p.setPen(pen)
    tail = QPainterPath(QPointF(6.6, 11.2))
    tail.cubicTo(5.2, 13.4, 8, 14, 7.2, 15.8)
    p.drawPath(tail)


def _laser(p, c):
    _fill_dot(p, c, 4.6, 13.4, 1.8)
    _lines(p, (7.6, 10.4, 15.4, 2.6), (4.6, 8.2, 4.6, 7), (9.8, 13.4, 11, 13.4), (8.2, 15.8, 9, 16.6))


def _line(p, c):
    p.drawLine(QPointF(3.2, 14.8), QPointF(14.8, 3.2))


def _rect(p, c):
    p.drawRoundedRect(QRectF(3, 4.4, 12, 9.2), .8, .8)


def _ellipse(p, c):
    p.drawEllipse(QPointF(9, 9), 6.4, 5)


def _arrow(p, c):
    p.drawLine(QPointF(3.2, 14.8), QPointF(14.4, 3.6))
    p.drawPolyline(_pt(8.6, 3.2, 14.8, 3.2, 14.8, 9.4))


def _axes(p, c):
    p.drawPolyline(_pt(4, 2.8, 4, 14, 15.4, 14))
    p.drawPolyline(_pt(2.4, 4.6, 4, 2.8, 5.6, 4.6))
    p.drawPolyline(_pt(13.6, 12.4, 15.4, 14, 13.6, 15.6))


def _select(p, c):
    pen = p.pen()
    pen.setDashPattern([2.2, 2.0])
    p.setPen(pen)
    p.drawRect(QRectF(3, 3, 12, 12))


def _shapes(p, c):
    p.drawRoundedRect(QRectF(2.6, 8.6, 6.8, 6.8), .8, .8)
    p.drawEllipse(QPointF(11.8, 6.2), 3.6, 3.6)


_ICONS = {"menu": _menu, "more": _more, "search": _search, "sun": _sun, "moon": _moon, "reset": _reset, "camera": _camera,
          "full": _full, "side": _side, "home": _home, "grid": _grid, "play": _play, "pause": _pause, "spark": _spark,
          "close": _close, "min": _min, "undo": _undo, "redo": _redo, "plus": _plus, "trash": _trash,
          "chevron_l": _chevron_l, "chevron_r": _chevron_r, "chevron_d": _chevron_d, "basket": _basket, "send": _send, "board": _board,
          "today": _today, "guanlan": _guanlan, "countdown": _countdown, "desk": _desk, "studio": _desk, "lab": _lab,
          "bench": _bench, "analysis": _analysis, "lecture": _lecture, "settings": _settings,
          "pointer": _pointer, "move": _pointer, "pen": _pen, "marker": _marker, "chalk": _chalk, "eraser": _eraser,
          "lasso": _lasso, "laser": _laser, "line": _line, "rect": _rect, "ellipse": _ellipse, "arrow": _arrow, "axes": _axes,
          "select": _select, "shapes": _shapes}
