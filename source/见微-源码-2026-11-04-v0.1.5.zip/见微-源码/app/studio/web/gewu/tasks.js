'use strict';
/* ======================= 题型求解器：数学 · 化学 · 生物 =======================
 * 仿照 VeloΦ 的「任务领域」（github.com/Stevenzhang543/VeloPhi，src/task 与 src/ai/import）：
 *   题目属于某个常见题型时，AI 只把题目里的条件填进这个题型的参数（task），答案由这里的专门算法算出，
 *   再与 AI 自己的答案（claimed）逐项对照；参数不合法（函数写错、坐标与题目条件不符、方程式不守恒、
 *   概率和不为 1……）时抛出 TaskError，问题清单会发回给 AI 修正。
 * 依赖：solver.js（表达式、精确值）、chem.js（parseFormula / balance / EL）、bio.js（translate / aaName）。
 */
const Tasks = (() => {
  const REG = {}, ORDER = [];
  const reg = t => { REG[t.id] = t; ORDER.push(t.id); };
  class TaskError extends Error { constructor(list) { super(list.join('；')); this.list = list; } }
  const fail = (...m) => { throw new TaskError(m); };
  const isObj = v => !!v && typeof v === 'object' && !Array.isArray(v);
  const num = v => typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Solver.evalConst(String(v).trim().replace(/%$/, '/100')) : NaN;
  const needNum = (v, name, cond = () => true, hint = '') => { const x = num(v); if (!isFinite(x) || !cond(x)) fail(`${name} 必须是${hint || '数'}（收到 ${JSON.stringify(v)}）`); return x; };
  const fmtN = (v, d = 6) => !isFinite(v) ? '—' : Math.abs(v) >= 1e6 || (Math.abs(v) < 1e-4 && v !== 0) ? v.toExponential(4).replace('e', '×10^') : String(+v.toPrecision(d));
  const withExact = v => { const e = Solver.exact(v); return e ? `${fmtN(v)}（= ${e}）` : fmtN(v); };
  const asksOf = (s, allowed) => {
    if (!Array.isArray(s.asks) || !s.asks.length) fail(`asks 必须是非空数组，每项 {"what": …}，what 可选：${allowed.join('、')}`);
    s.asks.forEach((a, i) => { if (!isObj(a) || !allowed.includes(a.what)) fail(`asks[${i}].what「${isObj(a) ? a.what : a}」不支持，可选：${allowed.join('、')}`); });
    return s.asks;
  };
  const P = a => a.prompt || a.what;
  // 行：kind 决定怎样和 claimed 比较；value 是程序算出的值
  const numRow = (a, v, unit = '') => ({ prompt: P(a), kind: 'num', value: v, unit, text: isFinite(v) ? withExact(v) + (unit ? ' ' + unit : '') : '不存在', claimed: a.claimed });
  const infoRow = (a, text) => ({ prompt: P(a), kind: 'info', value: null, text, claimed: a.claimed });

  /* ---------------- 与 claimed 对照 ---------------- */
  const claimedNum = (c, row) => typeof c === 'string' && /%\s*$/.test(c) && row.unit !== '%' ? Solver.evalConst(c.replace(/%\s*$/, '')) / 100 : Solver.evalConst(c);
  const listNums = c => (Array.isArray(c) ? c : String(c ?? '').replace(/[{}（）()\[\]]/g, ' ').split(/[,，、;；\s]+|(?<!\d)\s*和\s*/)).map(x => typeof x === 'number' ? x : Solver.evalConst(String(x).trim())).filter(x => isFinite(x));
  const normText = s => String(s ?? '').replace(/[\s\-—–_·、，,。.;；→]/g, '').replace(/氨酸/g, '').toUpperCase();
  function compare(row) {
    const c = row.claimed;
    if (row.kind === 'check') return row.ok;
    if (c == null || c === '' || row.kind === 'info') return null;
    switch (row.kind) {
      case 'num': { if (!isFinite(row.value)) return /不存在|无|none/i.test(String(c)) ? true : null; const x = claimedNum(c, row); return isFinite(x) ? Solver.close(row.value, x) : null; }
      case 'nums': {
        const a = [...row.value].sort((p, q) => p - q), b = listNums(c).sort((p, q) => p - q);
        if (!b.length && !a.length) return true;
        return b.length ? a.length === b.length && a.every((x, i) => Solver.close(x, b[i])) : null;
      }
      case 'ratio': {
        const b = Array.isArray(c) ? c.map(Number) : String(c).split(/[:：∶]/).map(x => Solver.evalConst(x.trim()));
        if (!b.length || !b.every(isFinite)) return null;
        const nm = v => { const s = v.reduce((x, y) => x + y, 0) || 1; return v.map(x => x / s).sort((x, y) => x - y); };
        const A = nm(row.value), B = nm(b);
        return A.length === B.length && A.every((x, i) => Math.abs(x - B[i]) < 0.005);
      }
      case 'text': return normText(c) === normText(row.value);
      case 'point': { const b = listNums(c); return b.length === row.value.length && row.value.every((x, i) => Solver.close(x, b[i])); }
      case 'points': {
        const b = listNums(c), pts = []; for (let i = 0; i + 1 < b.length; i += 2) pts.push([b[i], b[i + 1]]);
        if (pts.length !== row.value.length) return pts.length ? false : null;
        return row.value.every(p => pts.some(q => Solver.close(p[0], q[0]) && Solver.close(p[1], q[1])));
      }
      case 'line': { // claimed 是直线方程（y=kx+b、ax+by+c=0 都行）：在程序算出的直线上取三点代进去
        try {
          const s = String(c).replace(/^\s*[a-zA-Z]\s*[:：]\s*/, ''), parts = s.split('=');
          if (parts.length !== 2) return null;
          const g = Solver.fn(`(${parts[0]})-(${parts[1]})`, ['x', 'y']), { k, b } = row.value;
          const sc = Math.abs(g(1, 0) - g(0, 0)) + Math.abs(g(0, 1) - g(0, 0)) || 1;
          return [-1, 0, 2].every(x => Math.abs(g(x, k * x + b)) / sc < 0.01);
        } catch (e) { return null; }
      }
      case 'equation': { // 配平：系数成比例即可
        try {
          const q = parseEquation(String(c)), mine = row.value;
          if (q.species.length !== mine.species.length) return false;
          let ratio = null;
          for (let i = 0; i < mine.species.length; i++) {
            const j = q.species.findIndex(s => s.f === mine.species[i].f && s.side === mine.species[i].side); if (j < 0) return false;
            const r = q.species[j].coef / mine.species[i].coef; if (ratio === null) ratio = r; else if (Math.abs(r - ratio) > 1e-9 * ratio) return false;
          }
          return true;
        } catch (e) { return null; }
      }
    }
    return null;
  }

  /* ---------------- 一维求根（函数零点、直线与曲线交点共用） ---------------- */
  function roots(g, a, b, N = 6000) {
    const out = [], xs = [], ys = [];
    for (let i = 0; i <= N; i++) { const x = a + (b - a) * i / N; xs.push(x); ys.push(g(x)); }
    const scale = ys.filter(isFinite).reduce((m, y) => Math.max(m, Math.abs(y)), 0) || 1;
    const add = r => { if (!out.some(z => Math.abs(z - r) < 1e-7 * Math.max(1, Math.abs(b - a)))) out.push(r); };
    for (let i = 0; i < N; i++) {
      const y0 = ys[i], y1 = ys[i + 1];
      if (!isFinite(y0) || !isFinite(y1)) continue;
      if (y0 === 0) { add(xs[i]); continue; }
      if (y0 * y1 < 0) {
        let lo = xs[i], hi = xs[i + 1], flo = y0;
        for (let k = 0; k < 100; k++) { const m = (lo + hi) / 2, fm = g(m); if (!isFinite(fm)) break; if (fm === 0) { lo = hi = m; break; } if (fm * flo < 0) hi = m; else { lo = m; flo = fm; } }
        const r = (lo + hi) / 2, fr = Math.abs(g(r));
        if (fr <= 1e-6 * (1 + Math.min(Math.abs(y0), Math.abs(y1)))) add(r); // 排除间断点（两侧都很大）
      } else if (i > 0 && isFinite(ys[i - 1]) && Math.abs(y0) <= Math.abs(ys[i - 1]) && Math.abs(y0) <= Math.abs(y1) && Math.abs(y0) < 1e-3 * scale) {
        // 切点式的零点（偶重根）：|g| 的局部极小，黄金分割细化
        let lo = xs[i - 1], hi = xs[i + 1];
        for (let k = 0; k < 120; k++) { const m1 = lo + (hi - lo) * 0.382, m2 = lo + (hi - lo) * 0.618; if (Math.abs(g(m1)) < Math.abs(g(m2))) hi = m2; else lo = m1; }
        const r = (lo + hi) / 2; if (Math.abs(g(r)) < 1e-9 * (1 + scale)) add(r);
      }
    }
    return out.sort((p, q) => p - q);
  }
  const fmtX = x => { if (!isFinite(x)) return x > 0 ? '+∞' : '-∞'; const e = Solver.exact(x); return e || fmtN(x, 5); };

  /* ================= 数学 ================= */
  reg({
    id: 'func', subj: '数学', title: '函数分析',
    doc: `{"kind":"func","f":"x^3-3*x","domain":[-3,3],"asks":[{"prompt":"极大值","what":"local_max","claimed":[2]}]}
  f 以 x 为自变量，语法同方程模型（ln、exp、sqrt、abs、sin…，乘号要写）；domain 为讨论区间（没有限制就省略，程序在 [-20,20] 内搜索）。
  what：value / derivative（在 "x" 处的函数值 / 导数值）、tangent（在 "x" 处的切线，claimed 写 "y=3x-2"）、zeros（全部零点，claimed 写数组）、local_max / local_min（全部极大值 / 极小值，数组）、max / min（domain 上的最大 / 最小值）、monotonic（单调区间，仅展示）、integral（"a" 到 "b" 的定积分）、range（domain 上的值域，仅展示）`,
    run(s) {
      let f;
      try { f = Solver.fn(String(s.f ?? ''), ['x']); } catch (e) { fail(`f「${s.f}」：${e.message}`); }
      const given = Array.isArray(s.domain) && s.domain.length === 2;
      const [a, b] = given ? s.domain.map((v, i) => needNum(v, `domain[${i}]`)) : [-20, 20];
      if (!(a < b)) fail('domain 必须是 [左端点, 右端点]，且左 < 右');
      const d = x => { const h = 1e-5 * Math.max(1, Math.abs(x)); return (f(x + h) - f(x - h)) / (2 * h); };
      const zs = roots(f, a, b), cr = roots(d, a, b);
      const kinds = cr.map(x => { const h = 1e-4 * Math.max(1, Math.abs(x)) + 1e-6, l = d(x - h), r = d(x + h); return l > 0 && r < 0 ? 'max' : l < 0 && r > 0 ? 'min' : ''; });
      const ext = cr.map((x, i) => ({ x, y: f(x), t: kinds[i] })).filter(e => e.t);
      const N = 4000, samp = [...Array(N + 1).keys()].map(i => a + (b - a) * i / N).map(x => [x, f(x)]).filter(p => isFinite(p[1]));
      const cand = [...samp, ...ext.map(e => [e.x, e.y]), [a, f(a)], [b, f(b)]].filter(p => isFinite(p[1]));
      const best = w => cand.reduce((m, p) => (w === 'max' ? p[1] > m[1] : p[1] < m[1]) ? p : m, cand[0]);
      const atEdge = p => !given && (Math.abs(p[0] - a) < 1e-6 || Math.abs(p[0] - b) < 1e-6);
      const rows = asksOf(s, ['value', 'derivative', 'tangent', 'zeros', 'local_max', 'local_min', 'max', 'min', 'monotonic', 'integral', 'range']).map(q => {
        const X = () => needNum(q.x, `${q.what} 的 x`);
        switch (q.what) {
          case 'value': return numRow(q, f(X()));
          case 'derivative': return numRow(q, d(X()));
          case 'tangent': { const x0 = X(), k = d(x0), bb = f(x0) - k * x0, kk = Math.abs(k) < 1e-10 ? 0 : k; return { prompt: P(q), kind: 'line', value: { k: kk, b: bb }, text: `y = ${kk === 0 ? '' : fmtX(kk) + 'x'}${kk === 0 ? fmtX(bb) : Math.abs(bb) < 1e-12 ? '' : (bb > 0 ? ' + ' : ' - ') + fmtX(Math.abs(bb))}`, claimed: q.claimed }; }
          case 'zeros': return { prompt: P(q), kind: 'nums', value: zs, text: zs.length ? zs.map(fmtX).join('，') : '无零点', claimed: q.claimed };
          case 'local_max': case 'local_min': { const v = ext.filter(e => e.t === q.what.slice(6)); return { prompt: P(q), kind: 'nums', value: v.map(e => e.y), text: v.length ? v.map(e => `${fmtX(e.y)}（x = ${fmtX(e.x)}）`).join('，') : '没有', claimed: q.claimed }; }
          case 'max': case 'min': { const p = best(q.what); return atEdge(p) ? { ...numRow(q, NaN), text: `在搜索范围内没有${q.what === 'max' ? '最大' : '最小'}值（趋向端点）` } : { ...numRow(q, p[1]), text: `${withExact(p[1])}（x = ${fmtX(p[0])}）` }; }
          case 'monotonic': {
            const pts = [a, ...ext.map(e => e.x), b], inc = [], dec = [];
            for (let i = 0; i + 1 < pts.length; i++) { const m = (pts[i] + pts[i + 1]) / 2, iv = `(${given || i ? fmtX(pts[i]) : '-∞'}, ${given || i + 2 < pts.length ? fmtX(pts[i + 1]) : '+∞'})`; (d(m) > 0 ? inc : dec).push(iv); }
            return infoRow(q, `增区间：${inc.join('、') || '无'}；减区间：${dec.join('、') || '无'}`);
          }
          case 'integral': {
            const lo = needNum(q.a, 'integral 的 a'), hi = needNum(q.b, 'integral 的 b'), n = 4000, h = (hi - lo) / n;
            let sum = f(lo) + f(hi); for (let i = 1; i < n; i++) sum += (i % 2 ? 4 : 2) * f(lo + i * h);
            return numRow(q, sum * h / 3);
          }
          case 'range': { const lo = best('min'), hi = best('max'); return infoRow(q, `[${fmtX(lo[1])}, ${fmtX(hi[1])}]${given ? '' : '（在 [-20,20] 内）'}`); }
        }
      });
      return { rows, detail: [`f(x) = ${s.f}，讨论区间 ${given ? `[${fmtX(a)}, ${fmtX(b)}]` : '[-20, 20]（题目未限定）'}`, `零点：${zs.map(fmtX).join('，') || '无'}`, `驻点：${cr.map((x, i) => `x = ${fmtX(x)}${kinds[i] ? (kinds[i] === 'max' ? '（极大）' : '（极小）') : '（非极值）'}`).join('，') || '无'}`] };
    }
  });

  reg({
    id: 'conic', subj: '数学', title: '直线与曲线',
    doc: `{"kind":"conic","curve":"x^2/16+y^2/9=1","line":"y=x+1","point":[0,0],"asks":[{"prompt":"弦长|AB|","what":"chord","claimed":"24√2/25"}]}
  curve 是曲线方程（含 x、y，圆、椭圆、双曲线、抛物线都行），line 是直线方程（"y=kx+b"、"x=2"、"x-2y+1=0" 均可）。参数已知后代入具体数值；含参数的「取值范围」类问题不要用这个题型。
  what：intersections（交点坐标，claimed 写 [[x1,y1],[x2,y2]]）、count（交点个数）、chord（弦长）、midpoint（弦中点 [x,y]）、area（以 point 为顶点、弦为底的三角形面积，point 默认原点）、distance（point 到直线的距离）`,
    run(s) {
      const eq = (str, name) => { const p = String(str ?? '').split('='); if (p.length !== 2) fail(`${name} 必须是含一个等号的方程（收到 ${JSON.stringify(str)}）`); try { return Solver.fn(`(${p[0]})-(${p[1]})`, ['x', 'y']); } catch (e) { fail(`${name}「${str}」：${e.message}`); } };
      const F = eq(s.curve, 'curve'), G = eq(s.line, 'line');
      const C0 = G(0, 0), A = G(1, 0) - C0, B = G(0, 1) - C0;
      if (Math.abs(G(2, 3) - (2 * A + 3 * B + C0)) > 1e-9 * (1 + Math.abs(A) + Math.abs(B) + Math.abs(C0)) || (A === 0 && B === 0)) fail(`line「${s.line}」不是直线方程`);
      const O = Array.isArray(s.point) ? s.point.map((v, i) => needNum(v, `point[${i}]`)) : [0, 0];
      const nrm = Math.hypot(A, B), dir = [B / nrm, -A / nrm], p0 = Math.abs(B) > Math.abs(A) ? [0, -C0 / B] : [-C0 / A, 0];
      const H = t => F(p0[0] + t * dir[0], p0[1] + t * dir[1]);
      const ts = roots(H, -500, 500, 40000), pts = ts.map(t => [p0[0] + t * dir[0], p0[1] + t * dir[1]].map(v => Math.abs(v) < 1e-12 ? 0 : v));
      const two = pts.length === 2;
      const rows = asksOf(s, ['intersections', 'count', 'chord', 'midpoint', 'area', 'distance']).map(q => {
        switch (q.what) {
          case 'intersections': return { prompt: P(q), kind: 'points', value: pts, text: pts.map(p => `(${fmtX(p[0])}, ${fmtX(p[1])})`).join('、') || '没有交点', claimed: q.claimed };
          case 'count': return numRow(q, pts.length);
          case 'chord': return two ? numRow(q, Math.hypot(pts[0][0] - pts[1][0], pts[0][1] - pts[1][1])) : { ...numRow(q, NaN), text: `交点有 ${pts.length} 个，不构成弦` };
          case 'midpoint': return two ? { prompt: P(q), kind: 'point', value: [(pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2], text: `(${fmtX((pts[0][0] + pts[1][0]) / 2)}, ${fmtX((pts[0][1] + pts[1][1]) / 2)})`, claimed: q.claimed } : { ...numRow(q, NaN), text: '交点不是两个' };
          case 'area': return two ? numRow(q, Math.abs((pts[0][0] - O[0]) * (pts[1][1] - O[1]) - (pts[1][0] - O[0]) * (pts[0][1] - O[1])) / 2) : { ...numRow(q, NaN), text: '交点不是两个' };
          case 'distance': return numRow(q, Math.abs(A * O[0] + B * O[1] + C0) / nrm);
        }
      });
      return { rows, detail: [`曲线 ${s.curve}，直线 ${s.line}`, `交点：${pts.map(p => `(${fmtX(p[0])}, ${fmtX(p[1])})`).join('、') || '无'}`] };
    }
  });

  reg({
    id: 'solid', subj: '数学', title: '立体几何（坐标法）',
    doc: `{"kind":"solid","points":{"A":[0,0,0],"B":[2,0,0],"C":[2,2,0],"A1":[0,0,2]},"given":[{"seg":["A","B"],"length":2},{"perp":[["A","B"],["A","A1"]]}],"asks":[{"what":"angle_line_plane","line":["A1","C"],"plane":["A","B","C"],"claimed":0.5774}]}
  先建立空间直角坐标系，把用到的点的坐标写进 points（点名照题目，A₁ 写 A1）；given 列出题目中可核对的条件（seg+length 棱长、perp 两线段垂直、parallel 两线段平行），程序会检查坐标是否满足，不满足会退回。
  what：distance（"between":[P,Q]）、angle_lines（"lines":[[P,Q],[R,S]]，两直线夹角）、angle_line_plane（"line":[P,Q]，"plane":[R,S,T]）、dihedral（二面角：给 "edge":[P,Q] 和 "faces":[R,S]（两个半平面上各一点）得到真实二面角；或给 "planes":[[…3点],[…3点]] 得到锐二面角）、distance_point_plane（"point":P，"plane":[R,S,T]）、volume（"points" 4 点为四面体；更多点时第一个为顶点、其余为底面多边形）、area（"points" 平面多边形）。
  角度类可加 "output"："cos"、"sin"、"tan"、"deg"（默认：线线、二面角给 cos，线面角给 sin）。`,
    run(s) {
      if (!isObj(s.points) || !Object.keys(s.points).length) fail('points 必须是 {"点名":[x,y,z], …}');
      const Pt = {};
      for (const [k, v] of Object.entries(s.points)) { if (!Array.isArray(v) || v.length !== 3) fail(`points.${k} 必须是 [x,y,z]`); Pt[k] = v.map((x, i) => needNum(x, `points.${k}[${i}]`)); }
      const get = n => { if (!(n in Pt)) fail(`点「${n}」没有在 points 里给出坐标`); return Pt[n]; };
      const sub = (u, v) => u.map((x, i) => x - v[i]), dot = (u, v) => u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
      const cross = (u, v) => [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]], len = u => Math.hypot(...u);
      const vec = (pq, w) => { if (!Array.isArray(pq) || pq.length !== 2) fail(`${w} 必须是两个点名 [P,Q]`); return sub(get(pq[1]), get(pq[0])); };
      const normal = (pl, w) => { if (!Array.isArray(pl) || pl.length !== 3) fail(`${w} 必须是平面上不共线的三个点名`); const n = cross(sub(get(pl[1]), get(pl[0])), sub(get(pl[2]), get(pl[0]))); if (len(n) < 1e-12) fail(`${w} 的三点共线，确定不了平面`); return n; };
      // 题目条件核对
      const bad = [];
      (Array.isArray(s.given) ? s.given : []).forEach((g, i) => {
        if (!isObj(g)) return;
        if (g.seg && g.length != null) { const L = len(vec(g.seg, `given[${i}].seg`)), want = num(g.length); if (isFinite(want) && !Solver.close(L, want)) bad.push(`|${g.seg.join('')}| 按坐标算是 ${fmtX(L)}，题目给的是 ${g.length}`); }
        if (g.perp) { const u = vec(g.perp[0], `given[${i}].perp[0]`), v = vec(g.perp[1], `given[${i}].perp[1]`); if (Math.abs(dot(u, v)) > 1e-6 * len(u) * len(v)) bad.push(`${g.perp[0].join('')} 与 ${g.perp[1].join('')} 按坐标并不垂直`); }
        if (g.parallel) { const u = vec(g.parallel[0], `given[${i}].parallel[0]`), v = vec(g.parallel[1], `given[${i}].parallel[1]`); if (len(cross(u, v)) > 1e-6 * len(u) * len(v)) bad.push(`${g.parallel[0].join('')} 与 ${g.parallel[1].join('')} 按坐标并不平行`); }
      });
      if (bad.length) fail(...bad.map(b => `坐标与题目条件不符：${b}`));
      const angleOut = (q, c, def) => { // c = 夹角的余弦（0~π 的角）
        const o = q.output || def, th = Math.acos(Math.max(-1, Math.min(1, c)));
        const v = o === 'sin' ? Math.sin(th) : o === 'tan' ? Math.tan(th) : o === 'deg' ? th * 180 / Math.PI : o === 'rad' ? th : Math.cos(th);
        return { ...numRow(q, v, o === 'deg' ? '°' : ''), text: `${withExact(v)}${o === 'deg' ? '°' : ''}（${o === 'deg' ? '' : o + '，'}角 ≈ ${fmtN(th * 180 / Math.PI, 5)}°）` };
      };
      const polyArea = names => { const p = names.map(get); let n = [0, 0, 0]; for (let i = 1; i + 1 < p.length; i++) n = n.map((x, k) => x + cross(sub(p[i], p[0]), sub(p[i + 1], p[0]))[k]); return len(n) / 2; };
      const rows = asksOf(s, ['distance', 'angle_lines', 'angle_line_plane', 'dihedral', 'distance_point_plane', 'volume', 'area']).map(q => {
        switch (q.what) {
          case 'distance': return numRow(q, len(vec(q.between, 'between')));
          case 'angle_lines': { const u = vec(q.lines?.[0], 'lines[0]'), v = vec(q.lines?.[1], 'lines[1]'); return angleOut(q, Math.abs(dot(u, v)) / len(u) / len(v), 'cos'); }
          case 'angle_line_plane': { const u = vec(q.line, 'line'), n = normal(q.plane, 'plane'), sn = Math.abs(dot(u, n)) / len(u) / len(n); return angleOut(q, Math.sqrt(Math.max(0, 1 - sn * sn)), 'sin'); }
          case 'dihedral': {
            if (q.edge) {
              const P0 = get(q.edge[0]), e = vec(q.edge, 'edge'), ue = e.map(x => x / len(e));
              const perp = n => { const w = sub(get(n), P0), t = dot(w, ue); return sub(w, ue.map(x => x * t)); };
              const u = perp(q.faces?.[0]), v = perp(q.faces?.[1]);
              if (len(u) < 1e-12 || len(v) < 1e-12) fail('dihedral 的 faces 点不能在棱上');
              return angleOut(q, dot(u, v) / len(u) / len(v), 'cos');
            }
            const n1 = normal(q.planes?.[0], 'planes[0]'), n2 = normal(q.planes?.[1], 'planes[1]');
            return angleOut(q, Math.abs(dot(n1, n2)) / len(n1) / len(n2), 'cos');
          }
          case 'distance_point_plane': { const n = normal(q.plane, 'plane'); return numRow(q, Math.abs(dot(sub(get(q.point), get(q.plane[0])), n)) / len(n)); }
          case 'volume': {
            const ps = q.points; if (!Array.isArray(ps) || ps.length < 4) fail('volume 的 points 至少 4 个点');
            if (ps.length === 4) { const [a, b, c, d] = ps.map(get); return numRow(q, Math.abs(dot(sub(b, a), cross(sub(c, a), sub(d, a)))) / 6); }
            const base = ps.slice(1), n = normal(base.slice(0, 3), 'volume 的底面'), h = Math.abs(dot(sub(get(ps[0]), get(base[0])), n)) / len(n);
            return numRow(q, polyArea(base) * h / 3);
          }
          case 'area': { if (!Array.isArray(q.points) || q.points.length < 3) fail('area 的 points 至少 3 个点'); return numRow(q, polyArea(q.points)); }
        }
      });
      return { rows, detail: [`坐标：${Object.entries(Pt).map(([k, v]) => `${k}(${v.map(fmtX).join(', ')})`).join('，')}`, (s.given || []).length ? `题目条件 ${(s.given || []).length} 条，坐标全部满足` : '没有给出可核对的题目条件'] };
    }
  });

  // 正态分布函数（误差约 1e-7）
  const erf = x => { const t = 1 / (1 + 0.3275911 * Math.abs(x)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; };
  const Phi = z => 0.5 * (1 + erf(z / Math.SQRT2));
  reg({
    id: 'prob', subj: '数学', title: '概率分布',
    doc: `{"kind":"prob","dist":{"type":"binomial","n":5,"p":0.3},"asks":[{"what":"P","event":"X>=2","claimed":0.4718},{"what":"E"},{"what":"D"}]}
  dist.type：binomial（n, p）、hypergeometric（N 总数, M 其中“成功”的个数, n 抽取数）、normal（mu, sigma）、table（分布列："x":[…], "p":[…]，概率可写 "1/6"，和必须为 1）。
  what：P（"event" 写 "X=2"、"X>=2"、"X<3"、"1<=X<=3"）、E（期望）、D（方差）、pmf（分布列，仅展示）。计数问题（排列组合）请用方程模型，可用 comb(n,k)、perm(n,k)、fact(n)。`,
    run(s) {
      const D = s.dist; if (!isObj(D)) fail('dist 必须是对象，含 type');
      let xs = [], ps = [], E, V, cdf = null, name;
      const C = Solver && ((n, k) => { k = Math.round(k); n = Math.round(n); if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= Math.min(k, n - k); i++) r = r * (n - Math.min(k, n - k) + i) / i; return r; });
      if (D.type === 'binomial') {
        const n = needNum(D.n, 'dist.n', x => x >= 1 && Number.isInteger(x) && x <= 500, '正整数'), p = needNum(D.p, 'dist.p', x => x >= 0 && x <= 1, '0~1 之间的数');
        for (let k = 0; k <= n; k++) { xs.push(k); ps.push(C(n, k) * p ** k * (1 - p) ** (n - k)); }
        E = n * p; V = n * p * (1 - p); name = `X ~ B(${n}, ${fmtX(p)})`;
      } else if (D.type === 'hypergeometric') {
        const N = needNum(D.N, 'dist.N', x => Number.isInteger(x) && x >= 1, '正整数'), M = needNum(D.M, 'dist.M', x => Number.isInteger(x) && x >= 0 && x <= N, '0~N 的整数'), n = needNum(D.n, 'dist.n', x => Number.isInteger(x) && x >= 1 && x <= N, '1~N 的整数');
        for (let k = Math.max(0, n - (N - M)); k <= Math.min(n, M); k++) { xs.push(k); ps.push(C(M, k) * C(N - M, n - k) / C(N, n)); }
        E = n * M / N; V = N > 1 ? n * (M / N) * (1 - M / N) * (N - n) / (N - 1) : 0; name = `X ~ H(${N}, ${M}, ${n})`;
      } else if (D.type === 'normal') {
        const mu = needNum(D.mu, 'dist.mu'), sg = needNum(D.sigma, 'dist.sigma', x => x > 0, '正数');
        cdf = x => Phi((x - mu) / sg); E = mu; V = sg * sg; name = `X ~ N(${fmtX(mu)}, ${fmtX(sg)}²)`;
      } else if (D.type === 'table') {
        if (!Array.isArray(D.x) || !Array.isArray(D.p) || D.x.length !== D.p.length || !D.x.length) fail('table 需要等长的 "x" 和 "p" 数组');
        xs = D.x.map((v, i) => needNum(v, `dist.x[${i}]`)); ps = D.p.map((v, i) => needNum(v, `dist.p[${i}]`, x => x >= 0 && x <= 1, '0~1 之间的数'));
        const sum = ps.reduce((a, b) => a + b, 0); if (Math.abs(sum - 1) > 1e-6) fail(`分布列的概率之和是 ${fmtX(sum)}，不等于 1`);
        E = xs.reduce((a, x, i) => a + x * ps[i], 0); V = xs.reduce((a, x, i) => a + (x - E) ** 2 * ps[i], 0); name = '分布列';
      } else fail('dist.type 只能是 binomial、hypergeometric、normal、table');
      const prob = ev => {
        const e = String(ev ?? '').replace(/\s/g, '').replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/＝/g, '=').replace(/ξ|η|Y/g, 'X');
        let m, lo = -Infinity, hi = Infinity, loIn = true, hiIn = true;
        if ((m = /^X(=|>=|<=|>|<)(.+)$/.exec(e))) { const v = Solver.evalConst(m[2]); if (!isFinite(v)) fail(`event「${ev}」读不懂`); if (m[1] === '=') { lo = hi = v; } else if (m[1][0] === '>') { lo = v; loIn = m[1] === '>='; } else { hi = v; hiIn = m[1] === '<='; } }
        else if ((m = /^(.+?)(<=|<)X(<=|<)(.+)$/.exec(e))) { lo = Solver.evalConst(m[1]); hi = Solver.evalConst(m[4]); loIn = m[2] === '<='; hiIn = m[3] === '<='; if (!isFinite(lo) || !isFinite(hi)) fail(`event「${ev}」读不懂`); }
        else fail(`event「${ev}」读不懂：请写成 X=2、X>=2、X<3、1<=X<=3 这样的形式`);
        if (cdf) return (isFinite(hi) ? cdf(hi) : 1) - (isFinite(lo) ? cdf(lo) : 0);
        return xs.reduce((a, x, i) => a + ((x > lo || (loIn && Math.abs(x - lo) < 1e-9)) && (x < hi || (hiIn && Math.abs(x - hi) < 1e-9)) ? ps[i] : 0), 0);
      };
      const rows = asksOf(s, ['P', 'E', 'D', 'pmf']).map(q => {
        if (q.what === 'P') return numRow(q, prob(q.event));
        if (q.what === 'E') return numRow(q, E);
        if (q.what === 'D') return numRow(q, V);
        return infoRow(q, cdf ? '连续分布没有分布列' : xs.map((x, i) => `P(X=${fmtX(x)}) = ${fmtX(ps[i])}`).join('；'));
      });
      return { rows, detail: [`${name}，E(X) = ${fmtX(E)}，D(X) = ${fmtX(V)}`] };
    }
  });

  reg({
    id: 'seq', subj: '数学', title: '数列',
    doc: `{"kind":"seq","type":"recur","a1":1,"rule":"2*a+1","asks":[{"what":"term","n":10,"claimed":1023},{"what":"formula","formula":"2^n-1"}]}
  type：arith（"a1"、"d"）、geom（"a1"、"q"）、recur（"a1" 和递推 "rule"：用 a 表示 aₙ、n 表示项号，算出 aₙ₊₁；例如 aₙ₊₁ = 2aₙ + n 写 "2*a+n"）。已知条件需要先解出 a1、d 的，先算好再填。
  what：term（第 "n" 项）、sum（前 "n" 项和）、formula（检验你求出的通项公式 "formula"，含 n，程序逐项比对前 20 项）、sum_formula（检验前 n 项和公式）。`,
    run(s) {
      const a1 = needNum(s.a1, 'a1');
      let next;
      if (s.type === 'arith') { const d = needNum(s.d, 'd'); next = a => a + d; }
      else if (s.type === 'geom') { const q = needNum(s.q, 'q'); next = a => a * q; }
      else if (s.type === 'recur') { let r; try { r = Solver.fn(String(s.rule ?? ''), ['a', 'n']); } catch (e) { fail(`rule「${s.rule}」：${e.message}`); } next = (a, n) => r(a, n); }
      else fail('type 只能是 arith、geom、recur');
      const askN = asksOf(s, ['term', 'sum', 'formula', 'sum_formula']).map(q => q.what === 'term' || q.what === 'sum' ? needNum(q.n, `${q.what} 的 n`, x => Number.isInteger(x) && x >= 1 && x <= 2000, '1~2000 的整数') : 20);
      const N = Math.max(20, ...askN), a = [NaN, a1], S = [0, a1];
      for (let n = 1; n < N; n++) { a.push(next(a[n], n)); S.push(S[n] + a[n + 1]); }
      const check = (q, arr, label) => {
        let g; try { g = Solver.fn(String(q.formula ?? ''), ['n']); } catch (e) { fail(`${q.what} 的 formula「${q.formula}」：${e.message}`); }
        for (let n = 1; n <= 20; n++) { const v = g(n); if (!Solver.close(v, arr[n]) || !isFinite(v)) return { prompt: P(q), kind: 'check', ok: false, value: null, text: `第 ${n} 项不符：公式给 ${fmtX(v)}，${label}是 ${fmtX(arr[n])}`, claimed: q.formula }; }
        return { prompt: P(q), kind: 'check', ok: true, value: null, text: `前 20 项都符合「${q.formula}」`, claimed: q.formula };
      };
      const rows = s.asks.map(q => q.what === 'term' ? numRow(q, a[q.n]) : q.what === 'sum' ? numRow(q, S[q.n]) : check(q, q.what === 'formula' ? a : S, q.what === 'formula' ? '数列' : '前 n 项和'));
      return { rows, detail: [`前 8 项：${a.slice(1, 9).map(fmtX).join('，')}`] };
    }
  });

  /* ================= 化学 ================= */
  const MASS = { H: 1, He: 4, Li: 7, Be: 9, B: 11, C: 12, N: 14, O: 16, F: 19, Ne: 20, Na: 23, Mg: 24, Al: 27, Si: 28, P: 31, S: 32, Cl: 35.5, Ar: 40, K: 39, Ca: 40, Ti: 48, V: 51, Cr: 52, Mn: 55, Fe: 56, Co: 59, Ni: 59, Cu: 64, Zn: 65, Ga: 70, Ge: 73, As: 75, Se: 79, Br: 80, Kr: 84, Rb: 85.5, Sr: 88, Ag: 108, Cd: 112, Sn: 119, Sb: 122, I: 127, Xe: 131, Cs: 133, Ba: 137, Pt: 195, Au: 197, Hg: 201, Pb: 207 };
  const SUBS = '₀₁₂₃₄₅₆₇₈₉', SUPS = '⁰¹²³⁴⁵⁶⁷⁸⁹';
  /** 物质写法统一成 chem.js 的格式：下标数字、^电荷；去掉状态符号 */
  function normSpecies(raw) {
    let s = String(raw).trim().replace(/[₀-₉]/g, c => SUBS.indexOf(c)).replace(/([⁰-⁹¹²³]*)([⁺⁻])/g, (m, d, g) => '^' + [...d].map(c => SUPS.indexOf(c)).join('') + (g === '⁺' ? '+' : '-'))
      .replace(/[↑↓]/g, '').replace(/\((aq|s|l|g)\)$/i, '').replace(/[•∙⋅·*]/g, '·').replace(/\s+/g, '');
    if (/^e\^?-?$|^e⁻$/.test(s)) return 'e^-';
    if (!s.includes('^')) {
      // 没写 ^ 的电荷：Na+、Cl-、OH- 直接认；Fe3+ / Al3+（单个元素）数字是电荷；NH4+、MnO4-（多原子、一位数字）数字是下标、带一个电荷；
      // SO42-、PO43- 这种认不准，退回让模型用 ^ 写
      const m = /^(.*?)(\d*)([+-])$/.exec(s);
      if (m && m[1]) {
        if (!m[2]) s = `${m[1]}^${m[3]}`;
        else if (/^[A-Z][a-z]?$/.test(m[1])) s = `${m[1]}^${m[2]}${m[3]}`;
        else if (m[2].length === 1) s = `${m[1]}${m[2]}^${m[3]}`;
        else fail(`「${raw}」的电荷有歧义，请用 ^ 写电荷（如 SO4^2-、PO4^3-、Fe^3+）`);
      }
    }
    return s;
  }
  function parseEquation(src) {
    const s = String(src ?? '').replace(/[一-龥△]+/g, ' ').replace(/\(\s*\)/g, ' ');
    let parts = s.split(/<=>|⇌|⇋|<->|→|⟶|->|={1,3}|—+>?/).map(x => x.trim()).filter(Boolean);
    if (parts.length === 3) parts = [parts[0], parts[2]]; // 「=MnO2=」这类写在箭头上的催化剂
    if (parts.length !== 2) fail(`方程式「${src}」要有一个箭头或等号把反应物和生成物分开`);
    const species = [];
    parts.forEach((side, si) => {
      const t = side.replace(/\s+/g, '');
      let i = 0;
      while (i < t.length) {
        const cm = /^(\d+\/\d+|\d*\.\d+|\d+)?/.exec(t.slice(i)); let coef = 1;
        if (cm[0] && /[A-Z(\[e]/.test(t[i + cm[0].length] || '')) { coef = Solver.evalConst(cm[0]); i += cm[0].length; }
        let body = '';
        while (i < t.length) {
          const ch = t[i];
          if (ch === '^') { const m = /^\^\(?\d*[+-]\)?/.exec(t.slice(i)); if (!m) fail(`「${side}」里 ^ 后面应是电荷`); body += m[0]; i += m[0].length; continue; }
          if (ch === '+' || ch === '-') {
            const nxt = t[i + 1];
            if (ch === '+' && nxt !== undefined && nxt !== '+') break; // 分隔物质的加号
            body += ch; i++; break; // 电荷（Na+、Fe3+、OH-），交给 normSpecies 判断
          }
          body += ch; i++;
        }
        if (t[i] === '+') i++;
        if (!body) continue;
        const f = normSpecies(body);
        species.push({ f, coef, side: si, raw: body });
      }
    });
    if (!species.some(x => x.side === 0) || !species.some(x => x.side === 1)) fail(`方程式「${src}」缺少反应物或生成物`);
    return { species };
  }
  const molar = (f, masses = {}) => {
    if (f === 'e^-') return 0;
    let el; try { el = parseFormula(f).el; } catch (e) { fail(`化学式「${f}」：${e.message}`); }
    return Object.entries(el).reduce((m, [k, n]) => m + (masses[k] ?? MASS[k] ?? +(EL.by[k]?.m ?? NaN).toFixed(1)) * n, 0);
  };
  const pretty = f => f === 'e^-' ? 'e⁻' : f.replace(/\^(\d*)([+-])/, (m, d, g) => [...d].map(c => SUPS[c]).join('') + (g === '+' ? '⁺' : '⁻')).replace(/([A-Za-z)\]])(\d+)/g, (m, a, n) => a + [...n].map(c => SUBS[c]).join(''));
  const eqText = (sp, coef) => [0, 1].map(side => sp.map((x, i) => [x, coef[i]]).filter(([x]) => x.side === side).map(([x, c]) => (c === 1 ? '' : fmtN(c)) + pretty(x.f)).join(' + ')).join(' = ');
  /** 原子与电荷守恒；不守恒时给出程序配平的结果 */
  function checkBalance(eq) {
    const sp = eq.species, keys = new Set(); const parsed = sp.map(x => { try { return x.f === 'e^-' ? { el: {}, charge: -1 } : parseFormula(x.f); } catch (e) { fail(`化学式「${x.raw}」：${e.message}`); } });
    parsed.forEach(p => Object.keys(p.el).forEach(k => keys.add(k)));
    const off = [];
    for (const k of [...keys, '电荷']) {
      const l = sp.reduce((a, x, i) => a + (x.side === 0 ? x.coef * (k === '电荷' ? parsed[i].charge : (parsed[i].el[k] || 0)) : 0), 0);
      const r = sp.reduce((a, x, i) => a + (x.side === 1 ? x.coef * (k === '电荷' ? parsed[i].charge : (parsed[i].el[k] || 0)) : 0), 0);
      if (Math.abs(l - r) > 1e-9) off.push(`${k}：左边 ${fmtN(l)}，右边 ${fmtN(r)}`);
    }
    if (!off.length) return null;
    let hint = '';
    try { const b = balance(sp.filter(x => x.side === 0).map(x => x.f), sp.filter(x => x.side === 1).map(x => x.f)); hint = `程序配平结果：${eqText(sp, b.coef)}`; } catch (e) { hint = `程序也无法唯一配平（${e.message}）`; }
    return `方程式不守恒（${off.join('；')}）。${hint}`;
  }
  const findSp = (eq, name, w) => { const f = normSpecies(name ?? ''); const i = eq.species.findIndex(x => x.f === f); if (i < 0) fail(`${w}「${name}」不在方程式里（方程式中的物质：${eq.species.map(x => x.raw).join('、')}）`); return i; };

  reg({
    id: 'reaction', subj: '化学', title: '化学方程式与计量',
    doc: `{"kind":"reaction","equation":"2KMnO4+16HCl=2KCl+2MnCl2+5Cl2↑+8H2O","given":[{"species":"KMnO4","mass":15.8}],"masses":{"Cl":35.5},"asks":[{"what":"volume","species":"Cl2","claimed":5.6}]}
  equation 写配平后的方程式（离子用 ^ 写电荷：Fe^3+、NH4^+、SO4^2-、e^-；Na+、Cl-、OH- 这类也认）；程序检查原子与电荷守恒，不守恒会退回并给出程序的配平结果。
  given：题目给出的量，每项 {"species", 以及 mass（g）/ mol / volume（L，气体，标准状况）/ conc（mol/L）+ volume_mL 之一，可加 "purity"（纯度 0~1）}；给了多种反应物时程序按不足量计算。
  masses 可覆盖相对原子质量（默认 H 1、C 12、N 14、O 16、Na 23、Cl 35.5、Fe 56、Cu 64…）；"Vm" 可改气体摩尔体积（默认 22.4）；"yield" 为产率（0~1）。
  what：mol / mass / volume（某物质参加反应或生成的量）、remaining_mol / remaining_mass（过量反应物剩余）、molar_mass（摩尔质量）、coef（化学计量数）、balanced（配平的方程式，claimed 写方程式）。`,
    run(s) {
      const eq = parseEquation(s.equation), masses = isObj(s.masses) ? Object.fromEntries(Object.entries(s.masses).map(([k, v]) => [k, needNum(v, `masses.${k}`)])) : {};
      const bad = checkBalance(eq); if (bad) fail(bad);
      const Vm = s.Vm != null ? needNum(s.Vm, 'Vm', x => x > 0, '正数') : 22.4, Y = s.yield != null ? needNum(s.yield, 'yield', x => x > 0 && x <= 1, '0~1 的数') : 1;
      const M = eq.species.map(x => molar(x.f, masses));
      // 由 given 求反应进度 ξ（mol）
      const givens = Array.isArray(s.given) ? s.given : [];
      const amt = givens.map((g, k) => {
        if (!isObj(g)) fail(`given[${k}] 必须是对象`);
        const i = findSp(eq, g.species, `given[${k}].species`), pur = g.purity != null ? needNum(g.purity, `given[${k}].purity`, x => x > 0 && x <= 1, '0~1 的数') : 1;
        let n;
        if (g.mol != null) n = needNum(g.mol, `given[${k}].mol`);
        else if (g.mass != null) n = needNum(g.mass, `given[${k}].mass`) * pur / M[i];
        else if (g.volume != null) n = needNum(g.volume, `given[${k}].volume`) / Vm;
        else if (g.conc != null && g.volume_mL != null) n = needNum(g.conc, `given[${k}].conc`) * needNum(g.volume_mL, `given[${k}].volume_mL`) / 1000;
        else fail(`given[${k}] 要给 mass、mol、volume 或 conc+volume_mL 之一`);
        return { i, n, xi: n / eq.species[i].coef };
      });
      const reac = amt.filter(a => eq.species[a.i].side === 0), prod = amt.filter(a => eq.species[a.i].side === 1);
      let xi = null, limit = null;
      if (reac.length) { const m = reac.reduce((p, q) => q.xi < p.xi ? q : p); xi = m.xi; limit = m.i; }
      else if (prod.length) xi = prod[0].xi / Y;
      const need = () => { if (xi === null) fail('要计算物质的量，given 里至少给一种物质的量'); return xi; };
      const rows = asksOf(s, ['mol', 'mass', 'volume', 'remaining_mol', 'remaining_mass', 'molar_mass', 'coef', 'balanced']).map(q => {
        if (q.what === 'balanced') return { prompt: P(q), kind: 'equation', value: eq, text: eqText(eq.species, eq.species.map(x => x.coef)), claimed: q.claimed };
        const i = findSp(eq, q.species, `${q.what} 的 species`), sp = eq.species[i], y = sp.side === 1 ? Y : 1;
        switch (q.what) {
          case 'molar_mass': return numRow(q, M[i], 'g/mol');
          case 'coef': return numRow(q, sp.coef);
          case 'mol': return numRow(q, need() * sp.coef * y, 'mol');
          case 'mass': return numRow(q, need() * sp.coef * y * M[i], 'g');
          case 'volume': return numRow(q, need() * sp.coef * y * Vm, 'L');
          case 'remaining_mol': case 'remaining_mass': {
            const g = amt.find(a => a.i === i); if (!g) fail(`${q.what}：given 里没有给出「${q.species}」的量`);
            const left = Math.max(0, g.n - need() * sp.coef); return q.what === 'remaining_mol' ? numRow(q, left, 'mol') : numRow(q, left * M[i], 'g');
          }
        }
      });
      const det = [`方程式守恒：${eqText(eq.species, eq.species.map(x => x.coef))}`, `摩尔质量：${eq.species.filter(x => x.f !== 'e^-').map((x, i) => `${pretty(x.f)} ${fmtN(M[eq.species.indexOf(x)])}`).join('，')} g/mol`];
      if (xi !== null) det.push(`反应进度 ${fmtX(xi)} mol${limit !== null && reac.length > 1 ? `，不足量的是 ${pretty(eq.species[limit].f)}` : ''}${Y < 1 ? `，产率 ${fmtN(Y * 100)}%` : ''}`);
      return { rows, detail: det };
    }
  });

  reg({
    id: 'solution', subj: '化学', title: '溶液 pH',
    doc: `{"kind":"solution","components":[{"name":"CH3COOH","type":"weak_acid","Ka":[1.8e-5],"c":0.1,"V_mL":20},{"name":"NaOH","type":"strong_base","c":0.1,"V_mL":10}],"asks":[{"what":"pH","claimed":4.74}]}
  type：strong_acid / strong_base（"z" 为几元，默认 1）、weak_acid（"Ka":[Ka1,Ka2,…]）、weak_base（"Kb":[Kb1,…]）、salt_weak_acid（弱酸强碱盐如 CH3COONa、Na2CO3："Ka" 为对应弱酸的电离常数，按 H₂CO₃ 的 [Ka1,Ka2] 写；NaHCO3 再加 "z":1 表示只有一个 Na⁺）、salt_weak_base（强酸弱碱盐如 NH4Cl："Kb"）、ion（只算电荷的离子，"charge"）。
  c 为加入时的浓度（mol/L），V_mL 为加入体积，程序按混合后总体积换算（只有一种溶液可省略 V_mL）；"V_total_mL" 指定稀释后的总体积；"Kw" 默认 1e-14。程序由电荷守恒精确求解。
  what：pH、c_H、c_OH、alpha（"name" 那种弱电解质的电离度 / 水解度）。`,
    run(s) {
      if (!Array.isArray(s.components) || !s.components.length) fail('components 必须是非空数组');
      const Kw = s.Kw != null ? needNum(s.Kw, 'Kw', x => x > 0, '正数') : 1e-14;
      const comps = s.components.map((c, k) => {
        if (!isObj(c)) fail(`components[${k}] 必须是对象`);
        const T = ['strong_acid', 'strong_base', 'weak_acid', 'weak_base', 'salt_weak_acid', 'salt_weak_base', 'ion'];
        if (!T.includes(c.type)) fail(`components[${k}].type 只能是 ${T.join('、')}`);
        const K = key => { const v = c[key]; const a = Array.isArray(v) ? v : v != null ? [v] : []; if (!a.length) fail(`components[${k}]（${c.type}）需要 ${key}`); return a.map((x, i) => needNum(x, `components[${k}].${key}[${i}]`, y => y > 0, '正数')); };
        return { name: String(c.name ?? c.type), type: c.type, c: needNum(c.c, `components[${k}].c`, x => x >= 0, '非负数'), V: c.V_mL != null ? needNum(c.V_mL, `components[${k}].V_mL`, x => x > 0, '正数') : null, z: c.z != null ? needNum(c.z, `components[${k}].z`) : 1, zGiven: c.z != null, charge: c.charge != null ? needNum(c.charge, `components[${k}].charge`) : 0, Ka: /weak_acid/.test(c.type) ? K('Ka') : null, Kb: /weak_base/.test(c.type) ? K('Kb') : null };
      });
      const vols = comps.map(c => c.V), Vsum = vols.every(v => v != null) ? vols.reduce((a, b) => a + b, 0) : null;
      if (comps.length > 1 && Vsum === null && s.V_total_mL == null) fail('有多种溶液混合时，每种都要给 V_mL');
      const Vt = s.V_total_mL != null ? needNum(s.V_total_mL, 'V_total_mL', x => x > 0, '正数') : Vsum;
      comps.forEach(c => { c.C = Vt && c.V ? c.c * c.V / Vt : c.c; });
      // 酸体系：H_nA，Ka 列表；返回平均失去的质子数 Σ j·α_j 与 α_0
      const acid = (Ka, H) => { const t = [1]; for (let j = 0; j < Ka.length; j++) t.push(t[j] * Ka[j] / H); const sum = t.reduce((a, b) => a + b, 0); return { avg: t.reduce((a, x, j) => a + j * x, 0) / sum, a0: t[0] / sum, n: Ka.length }; };
      const baseAcid = Kb => [...Kb].reverse().map(k => Kw / k); // 共轭酸 H_nB^{n+} 的 Ka
      const charge = H => {
        let q = H - Kw / H;
        for (const c of comps) {
          const C = c.C;
          if (c.type === 'strong_acid') q -= c.z * C;
          else if (c.type === 'strong_base') q += c.z * C;
          else if (c.type === 'ion') q += c.charge * C;
          else if (c.type === 'weak_acid') q -= C * acid(c.Ka, H).avg;
          // 弱酸强碱盐：酸的各形态共 C（负电荷 C·avg），加旁观阳离子 z·C（Na2CO3 为 2、NaHCO3 写 "z":1；默认等于 Ka 个数）
          else if (c.type === 'salt_weak_acid') q += C * ((c.zGiven ? c.z : c.Ka.length) - acid(c.Ka, H).avg);
          else if (c.type === 'weak_base') { const a = acid(baseAcid(c.Kb), H); q += C * (a.n - a.avg); }
          // 强酸弱碱盐：碱的各形态共 C（正电荷 C·(n − avg)），加旁观阴离子 z·C
          else if (c.type === 'salt_weak_base') { const a = acid(baseAcid(c.Kb), H); q += C * (a.n - a.avg) - C * (c.zGiven ? c.z : a.n); }
        }
        return q;
      };
      let lo = -16, hi = 2;
      for (let k = 0; k < 200; k++) { const m = (lo + hi) / 2; if (charge(10 ** m) > 0) hi = m; else lo = m; }
      const H = 10 ** ((lo + hi) / 2), pH = -Math.log10(H);
      const rows = asksOf(s, ['pH', 'c_H', 'c_OH', 'alpha']).map(q => {
        if (q.what === 'pH') return numRow(q, pH);
        if (q.what === 'c_H') return numRow(q, H, 'mol/L');
        if (q.what === 'c_OH') return numRow(q, Kw / H, 'mol/L');
        const c = comps.find(x => x.name === q.name) || comps.find(x => /weak/.test(x.type));
        if (!c || !/weak/.test(c.type)) fail('alpha 需要 "name" 指向一种弱电解质或弱酸 / 弱碱盐');
        const a = c.Ka ? acid(c.Ka, H) : acid(baseAcid(c.Kb), H);
        const v = c.type === 'weak_acid' ? 1 - a.a0 : c.type === 'salt_weak_acid' ? (c.Ka.length - a.avg) / c.Ka.length : c.type === 'weak_base' ? (a.n - a.avg) / a.n : a.avg / a.n;
        return numRow(q, v);
      });
      return { rows, detail: [`混合后：${comps.map(c => `${c.name} ${fmtN(c.C, 4)} mol/L`).join('，')}${Vt ? `（总体积 ${fmtN(Vt)} mL）` : ''}`, `电荷守恒解得 c(H⁺) = ${fmtN(H, 4)} mol/L，pH = ${fmtN(pH, 4)}`] };
    }
  });

  reg({
    id: 'equilibrium', subj: '化学', title: '化学平衡',
    doc: `{"kind":"equilibrium","reaction":"N2+3H2⇌2NH3","V_L":2,"initial":{"N2":1,"H2":3},"at_eq":{"NH3":{"mol":0.4}},"asks":[{"what":"K"},{"what":"conversion","species":"N2","claimed":0.2}]}
  initial 为起始物质的量（mol，没写的为 0）；平衡信息三选一：K（浓度平衡常数）、at_eq（某物质平衡时的 {"mol":…} 或 {"conc":…}）、conversion（{"某反应物": 转化率}）。V_L 为容器体积（默认 1 L）；"exclude":["C"] 列出不写进 K 的固体、纯液体。
  what：K、mol / conc / fraction（平衡时某物质的物质的量 / 浓度 / 物质的量分数）、conversion（某反应物的转化率）、total_mol（平衡时气体总物质的量）、pressure_ratio（平衡与起始的压强比，恒温恒容）。`,
    run(s) {
      const eq = parseEquation(s.reaction), bad = checkBalance(eq); if (bad) fail(bad);
      const V = s.V_L != null ? needNum(s.V_L, 'V_L', x => x > 0, '正数') : 1, ex = new Set((s.exclude || []).map(normSpecies));
      const sp = eq.species, nu = sp.map(x => (x.side === 0 ? -1 : 1) * x.coef);
      const n0 = sp.map(x => { const k = isObj(s.initial) ? Object.keys(s.initial).find(z => normSpecies(z) === x.f) : null; return k ? needNum(s.initial[k], `initial.${k}`, y => y >= 0, '非负数') : 0; });
      const n = xi => n0.map((v, i) => v + nu[i] * xi);
      let lo = -Infinity, hi = Infinity;
      sp.forEach((x, i) => { const lim = -n0[i] / nu[i]; if (nu[i] < 0) hi = Math.min(hi, lim); else lo = Math.max(lo, lim); });
      if (!(hi > lo)) fail('起始物质的量不允许反应向任何方向进行（反应物和生成物都为 0？）');
      const inK = sp.map(x => !ex.has(x.f));
      const lnQ = xi => n(xi).reduce((a, v, i) => a + (inK[i] ? nu[i] * Math.log(Math.max(v, 1e-300) / V) : 0), 0);
      let xi;
      if (s.K != null) {
        const K = needNum(s.K, 'K', x => x > 0, '正数'), lk = Math.log(K);
        let a = lo + 1e-12 * (1 + Math.abs(lo)), b = hi - 1e-12 * (1 + Math.abs(hi));
        for (let k = 0; k < 200; k++) { const m = (a + b) / 2; if (lnQ(m) > lk) b = m; else a = m; }
        xi = (a + b) / 2;
      } else if (isObj(s.at_eq)) {
        const [k, v] = Object.entries(s.at_eq)[0] || []; const i = findSp(eq, k, 'at_eq');
        const nn = isObj(v) ? (v.mol != null ? needNum(v.mol, `at_eq.${k}.mol`) : needNum(v.conc, `at_eq.${k}.conc`) * V) : needNum(v, `at_eq.${k}`);
        xi = (nn - n0[i]) / nu[i];
      } else if (isObj(s.conversion)) {
        const [k, v] = Object.entries(s.conversion)[0] || []; const i = findSp(eq, k, 'conversion');
        if (nu[i] > 0) fail('conversion 要给反应物的转化率');
        xi = needNum(v, `conversion.${k}`, x => x >= 0 && x <= 1, '0~1 的数') * n0[i] / -nu[i];
      } else fail('平衡信息要给 K、at_eq 或 conversion 之一');
      const ne = n(xi);
      if (ne.some(v => v < -1e-9)) fail(`按给出的条件，平衡时有物质的量为负（${sp.map((x, i) => `${x.raw} ${fmtN(ne[i])}`).join('，')}），请检查`);
      const gas = ne.reduce((a, v, i) => a + (inK[i] ? v : 0), 0), gas0 = n0.reduce((a, v, i) => a + (inK[i] ? v : 0), 0);
      const K = Math.exp(lnQ(xi));
      const rows = asksOf(s, ['K', 'mol', 'conc', 'fraction', 'conversion', 'total_mol', 'pressure_ratio']).map(q => {
        if (q.what === 'K') return numRow(q, K);
        if (q.what === 'total_mol') return numRow(q, gas, 'mol');
        if (q.what === 'pressure_ratio') return numRow(q, gas / gas0);
        const i = findSp(eq, q.species, `${q.what} 的 species`);
        if (q.what === 'mol') return numRow(q, ne[i], 'mol');
        if (q.what === 'conc') return numRow(q, ne[i] / V, 'mol/L');
        if (q.what === 'fraction') return numRow(q, ne[i] / gas);
        if (nu[i] > 0 || !n0[i]) fail('conversion 要指向起始量不为 0 的反应物');
        return numRow(q, (n0[i] - ne[i]) / n0[i]);
      });
      return { rows, detail: [`三段式（mol）：起始 ${sp.map((x, i) => `${pretty(x.f)} ${fmtN(n0[i])}`).join('，')}；转化 ${sp.map((x, i) => `${fmtN(Math.abs(nu[i] * xi))}`).join('，')}；平衡 ${sp.map((x, i) => `${pretty(x.f)} ${fmtN(ne[i])}`).join('，')}`, `K = ${fmtN(K)}（V = ${fmtN(V)} L）`] };
    }
  });

  /* ================= 生物 ================= */
  reg({
    id: 'cross', subj: '生物', title: '遗传杂交',
    doc: `{"kind":"cross","loci":[{"alleles":["A","a"]},{"alleles":["XB","Xb"],"sex_linked":true}],"parents":["AaXBXb","AaXbY"],"lethal":["AA"],"asks":[{"what":"P","phenotype":"aaXbY","claimed":"1/12"},{"what":"phenotype_ratio"}]}
  loci：每对基因一项，alleles 按显性程度从高到低列出（"IA","IB","i" 这类复等位基因也行），"codominant":["IA","IB"] 表示共显性 / 不完全显性；伴 X 遗传写 "sex_linked":true，等位基因写成 "XB"、"Xb"，雄性写 Y。不考虑连锁与交叉互换。
  parents：两个亲本的基因型（伴 X 时一雌一雄）；lethal：致死的基因型（如 "AA"）或表型（带 _，如 "A_bb"）。
  写法：基因型如 "AaBb"、"XBXb"、"XbY"；表型用 "_" 表示任意：如 "A_bb"、"XBX_"、"XbY"、"ii"、"IA_"、"IAIB"。
  "select" 先从子代中挑出某表型（如 "A_B_"），"then" 再让它们 "self"（自交）或 "random"（自由交配），可写成数组表示多代。
  what：P（概率："phenotype" 或 "genotype"，可加 "sex":"male|female"，"given":{同样的条件} 表示条件概率）、phenotype_ratio、genotype_ratio（claimed 写 "9:3:3:1"）、count_phenotypes、count_genotypes。`,
    run(s) {
      if (!Array.isArray(s.loci) || !s.loci.length) fail('loci 必须是非空数组');
      const loci = s.loci.map((l, i) => {
        if (!isObj(l) || !Array.isArray(l.alleles) || l.alleles.length < 2) fail(`loci[${i}] 需要至少两个 alleles`);
        const al = l.alleles.map(String), x = !!l.sex_linked;
        if (x && !al.every(a => /^X/.test(a))) fail(`loci[${i}] 是伴 X 遗传，等位基因要写成 XB、Xb 这样`);
        return { al, x, co: new Set((l.codominant || []).map(String)) };
      });
      const hasX = loci.some(l => l.x), tokens = [...new Set(loci.flatMap(l => l.al))].sort((a, b) => b.length - a.length);
      if (hasX && tokens.includes('Y')) fail('有伴 X 遗传时，常染色体基因不能用字母 Y（会和 Y 染色体混淆），请换一个字母');
      const tokenize = (str, w, pattern) => {
        const t = String(str ?? '').replace(/\s/g, '').replace(/\^/g, ''), out = []; let i = 0;
        while (i < t.length) {
          if (pattern && t.startsWith('X_', i)) { out.push('X_'); i += 2; continue; }
          if (pattern && t[i] === '_') { out.push('_'); i++; continue; }
          const tok = tokens.find(k => t.startsWith(k, i)); // 先认等位基因：豌豆的 Y/y（黄色）不是 Y 染色体
          if (tok) { out.push(tok); i += tok.length; continue; }
          if (hasX && t[i] === 'Y') { out.push('Y'); i++; continue; }
          fail(`${w}「${str}」里「${t.slice(i)}」认不出（等位基因：${tokens.join('、')}${hasX ? '，雄性写 Y' : ''}）`);
        }
        return out;
      };
      const locusOf = tok => loci.findIndex(l => l.al.includes(tok));
      // 基因型：每个位点一对（伴 X 雄性为 [X, 'Y']）
      const parseGeno = (str, w) => {
        const tk = tokenize(str, w, false), g = loci.map(() => []), male = hasX && tk.includes('Y');
        tk.forEach(t => { if (!(hasX && t === 'Y')) g[locusOf(t)].push(t); });
        loci.forEach((l, i) => {
          if (l.x) { if (male) { if (g[i].length !== 1) fail(`${w}「${str}」是雄性，伴 X 位点应只有一个 X 基因`); g[i].push('Y'); } else if (g[i].length !== 2) fail(`${w}「${str}」伴 X 位点应有两个 X 基因（雄性要写 Y）`); }
          else if (g[i].length !== 2) fail(`${w}「${str}」第 ${i + 1} 对基因（${l.al.join('/')}）应有两个，实际 ${g[i].length} 个`);
        });
        return { g: g.map((p, i) => sortPair(p, i)), sex: hasX ? (male ? 'male' : 'female') : null };
      };
      function sortPair(p, i) { return loci[i].x && p[1] === 'Y' ? p : [...p].sort((a, b) => loci[i].al.indexOf(a) - loci[i].al.indexOf(b)); }
      const gkey = ind => ind.g.map(p => p.join('')).join('');
      // 每个位点的表型标签：不被同时存在的更显性等位基因压住的那些
      const label = (p, i) => {
        const l = loci[i], xs = l.x ? p.filter(a => a !== 'Y') : p, rank = a => l.al.indexOf(a), co = (a, b) => l.co.has(a) && l.co.has(b);
        const vis = [...new Set(xs)].filter(a => !xs.some(b => rank(b) < rank(a) && !co(a, b))).sort((a, b) => rank(a) - rank(b));
        if (l.x && p[1] === 'Y') return vis[0] + 'Y';           // 雄性：XBY、XbY
        if (vis.length > 1) return vis.join('');                // 共显性 / 不完全显性：IAIB、Aa
        const a = vis[0];
        // 还有比它更隐性、能被它盖住的等位基因 → 写 A_ / XBX_；否则只有纯合才是这个表型 → aa、ii、XbXb、（不完全显性的）AA
        const hides = l.al.some(b => rank(b) > rank(a) && !co(a, b));
        return hides ? a + (l.x ? 'X_' : '_') : a + a;
      };
      const pkey = ind => ind.g.map((p, i) => label(p, i)).join('');
      // 条件匹配：genotype（带 _ 通配）或 phenotype（与表型标签逐位点比较）
      const matcher = (cond, w) => {
        if (cond == null) return () => true;
        if (typeof cond === 'string') cond = /_/.test(cond) ? { phenotype: cond } : { genotype: cond }; // 带 _ 的是表型，否则按基因型（"AA" 致死、"XbY"）
        if (!isObj(cond)) fail(`${w} 必须是字符串或 {"phenotype"/"genotype"/"sex"}`);
        const parts = [];
        if (cond.sex) { if (!['male', 'female'].includes(cond.sex)) fail(`${w}.sex 只能是 male 或 female`); parts.push(ind => !hasX || ind.sex === cond.sex); }
        for (const key of ['genotype', 'phenotype']) {
          if (cond[key] == null) continue;
          const tk = tokenize(cond[key], `${w}.${key}`, true), per = loci.map(() => []);
          let last = -1; tk.forEach(t => { const i = t === '_' ? last : t === 'X_' || (hasX && t === 'Y') ? loci.findIndex(l => l.x) : locusOf(t); if (i < 0) fail(`${w}.${key}「${cond[key]}」写法不对`); per[i].push(t); last = i; });
          if (hasX && tk.includes('Y') && !cond.sex) parts.push(ind => ind.sex === 'male');
          if (hasX && key === 'phenotype' && per.some((p, i) => loci[i].x && p.length === 2 && p[1] !== 'Y')) parts.push(ind => ind.sex === 'female');
          parts.push(ind => per.every((p, i) => {
            if (!p.length) return true;
            if (key === 'phenotype') return label(ind.g[i], i) === p.join('').replace(/X_/g, 'X_');
            const want = p.map(t => t === 'X_' ? '_' : t), have = [...ind.g[i]];
            if (want.length !== have.length) return false;
            const rest = [...have]; for (const t of want.filter(t => t !== '_')) { const j = rest.indexOf(t); if (j < 0) return false; rest.splice(j, 1); }
            return true;
          }));
        }
        return ind => parts.every(f => f(ind));
      };
      // 配子与杂交
      const gametes = ind => { let gs = [{ a: [], p: 1 }]; ind.g.forEach(pair => { const nx = []; for (const g of gs) for (const a of pair) nx.push({ a: [...g.a, a], p: g.p / 2 }); gs = nx; }); return gs; };
      const cross = (pool1, pool2) => { // pool：[{a, p}]，pool1 为母本配子
        const out = new Map();
        for (const m of pool1) for (const f of pool2) {
          const g = loci.map((l, i) => sortPair(l.x && f.a[i] === 'Y' ? [m.a[i], 'Y'] : [m.a[i], f.a[i]], i));
          const male = hasX && loci.some((l, i) => l.x && f.a[i] === 'Y'), ind = { g, sex: hasX ? (male ? 'male' : 'female') : null };
          const k = gkey(ind) + (ind.sex || ''); const cur = out.get(k); if (cur) cur.p += m.p * f.p; else out.set(k, { ...ind, p: m.p * f.p });
        }
        return [...out.values()];
      };
      const merge = pool => { const m = new Map(); pool.forEach(g => { const k = g.a.join('|'); const c = m.get(k); if (c) c.p += g.p; else m.set(k, { ...g }); }); return [...m.values()]; };
      const lethal = (s.lethal || []).map((c, i) => matcher(c, `lethal[${i}]`));
      const alive = pop => { const keep = pop.filter(ind => !lethal.some(f => f(ind))), t = keep.reduce((a, b) => a + b.p, 0); if (!t) fail('按给出的致死基因型，子代全部致死'); return keep.map(x => ({ ...x, p: x.p / t })); };
      if (!Array.isArray(s.parents) || s.parents.length !== 2) fail('parents 必须是两个亲本的基因型');
      const par = s.parents.map((p, i) => parseGeno(p, `parents[${i}]`));
      if (hasX && par.filter(p => p.sex === 'male').length !== 1) fail('伴 X 遗传的两个亲本要一雌一雄（雄性写 Y）');
      const mom = hasX ? par.find(p => p.sex === 'female') : par[0], dad = hasX ? par.find(p => p.sex === 'male') : par[1];
      let pop = alive(cross(merge(gametes(mom)), merge(gametes(dad))));
      const det = [`亲本配子：${[mom, dad].map(p => merge(gametes(p)).map(g => g.a.join('') + ' ' + fracText(g.p)).join('、')).join('　×　')}`];
      if (s.select != null || s.then != null) {
        if (s.select != null) { const f = matcher(s.select, 'select'), keep = pop.filter(f), t = keep.reduce((a, b) => a + b.p, 0); if (!t) fail('select 的表型在子代中不存在'); pop = keep.map(x => ({ ...x, p: x.p / t })); det.push(`选出 ${typeof s.select === 'string' ? s.select : JSON.stringify(s.select)}：${pop.map(x => gkey(x) + ' ' + fracText(x.p)).join('，')}`); }
        for (const step of [].concat(s.then || [])) {
          if (step === 'self') {
            if (hasX) fail('伴 X 遗传不能自交');
            const out = new Map(); pop.forEach(ind => cross(merge(gametes(ind)), merge(gametes(ind))).forEach(c => { const k = gkey(c); const cur = out.get(k); if (cur) cur.p += c.p * ind.p; else out.set(k, { ...c, p: c.p * ind.p }); }));
            pop = alive([...out.values()]); det.push('自交一代');
          } else if (step === 'random') {
            const poolOf = sx => merge(pop.filter(i => !hasX || i.sex === sx).flatMap(ind => gametes(ind).map(g => ({ a: g.a, p: g.p * ind.p })))).map((g, _, arr) => ({ ...g, p: g.p / arr.reduce((a, b) => a + b.p, 0) }));
            pop = alive(cross(poolOf('female'), poolOf('male'))); det.push('自由交配一代');
          } else fail('then 只能是 "self" 或 "random"（或它们组成的数组）');
        }
      }
      const groups = keyf => { const m = new Map(); pop.forEach(x => m.set(keyf(x), (m.get(keyf(x)) || 0) + x.p)); return [...m.entries()].sort((a, b) => b[1] - a[1]); };
      const ratioRow = (q, gs) => { const ints = toInts(gs.map(g => g[1])); return { prompt: P(q), kind: 'ratio', value: gs.map(g => g[1]), text: `${ints.join(' : ')}（${gs.map((g, i) => `${g[0]} ${ints[i]}`).join('，')}）`, claimed: q.claimed }; };
      const phen = pkey;
      const rows = asksOf(s, ['P', 'phenotype_ratio', 'genotype_ratio', 'count_phenotypes', 'count_genotypes']).map(q => {
        if (q.what === 'phenotype_ratio') return ratioRow(q, groups(phen));
        if (q.what === 'genotype_ratio') return ratioRow(q, groups(gkey));
        if (q.what === 'count_phenotypes') return numRow(q, groups(phen).length);
        if (q.what === 'count_genotypes') return numRow(q, groups(gkey).length);
        const ev = matcher({ phenotype: q.phenotype, genotype: q.genotype, sex: q.sex }, 'asks'), giv = q.given ? matcher(q.given, 'asks.given') : () => true;
        const pg = pop.filter(giv).reduce((a, b) => a + b.p, 0), pe = pop.filter(x => giv(x) && ev(x)).reduce((a, b) => a + b.p, 0);
        if (!pg) fail('asks.given 的条件在子代中不存在');
        const v = pe / pg; return { ...numRow(q, v), text: fracText(v) };
      });
      det.push(`子代（${pop.length} 种基因型）：${pop.slice().sort((a, b) => b.p - a.p).map(x => `${gkey(x)} ${fracText(x.p)}`).join('，')}`);
      det.push(`表型：${groups(phen).map(([k, p]) => `${k} ${fracText(p)}`).join('，')}`);
      return { rows, detail: det };
    }
  });
  const fracText = v => { const r = Solver.rational(v, 5000, 1e-10); return r ? (r[1] === 1 ? String(r[0]) : `${r[0]}/${r[1]}`) + (r[1] > 1 ? `（${fmtN(v, 4)}）` : '') : fmtN(v, 5); };
  const toInts = ps => { const rs = ps.map(p => Solver.rational(p, 5000, 1e-10) || [Math.round(p * 1e4), 1e4]); const g2 = (a, b) => { while (b) [a, b] = [b, a % b]; return a; }; const L = rs.reduce((l, r) => l * r[1] / g2(l, r[1]), 1); let ints = rs.map(r => r[0] * L / r[1]); const g = ints.reduce((a, b) => g2(a, b)); return ints.map(x => x / g); };

  reg({
    id: 'dna', subj: '生物', title: '碱基与中心法则',
    doc: `{"kind":"dna","seq":"TACGGATCC","strand":"template","asks":[{"what":"mrna","claimed":"AUGCCUAGG"},{"what":"protein"}]}
  seq 为碱基序列；strand：coding（DNA 编码链）、template（DNA 模板链，按与 mRNA 对齐的方向写，即 3′→5′）、mrna。
  what：complement（互补链）、mrna、protein（从第一个 AUG 开始翻译到终止密码子；"from_start":false 表示从第一个碱基起翻译；claimed 写氨基酸名，用 - 连接）、codons（密码子个数）、gc（G+C 所占比例）、count（"base" 的个数）、h_bonds（以 seq 为一条链的双链 DNA 的氢键数）。`,
    run(s) {
      const strand = s.strand || 'coding';
      if (!['coding', 'template', 'mrna'].includes(strand)) fail('strand 只能是 coding、template、mrna');
      const seq = String(s.seq ?? '').toUpperCase().replace(/[^ACGTU]/g, '');
      if (!seq) fail('seq 里没有碱基');
      if (strand === 'mrna' ? /T/.test(seq) : /U/.test(seq)) fail(`${strand === 'mrna' ? 'mRNA 里不应有 T' : 'DNA 里不应有 U'}`);
      const comp = { A: strand === 'mrna' ? 'U' : 'T', T: 'A', U: 'A', G: 'C', C: 'G' };
      const complement = [...seq].map(b => comp[b]).join('');
      const mrna = strand === 'mrna' ? seq : strand === 'coding' ? seq.replace(/T/g, 'U') : [...seq].map(b => ({ A: 'U', T: 'A', G: 'C', C: 'G' })[b]).join('');
      const tr = s.from_start === false ? (() => { const aa = []; let stop = false; for (let i = 0; i + 3 <= mrna.length; i += 3) { const cd = mrna.slice(i, i + 3), a = CODON['UCAG'.indexOf(cd[0]) * 16 + 'UCAG'.indexOf(cd[1]) * 4 + 'UCAG'.indexOf(cd[2])]; if (a === '*') { stop = true; break; } aa.push(a); } return { start: 0, aa, stop }; })() : translate(mrna);
      const protein = tr.aa.map(aaName).join('-');
      const cnt = b => [...seq].filter(x => x === b).length, gc = (cnt('G') + cnt('C')) / seq.length;
      const rows = asksOf(s, ['complement', 'mrna', 'protein', 'codons', 'gc', 'count', 'h_bonds']).map(q => {
        switch (q.what) {
          case 'complement': return { prompt: P(q), kind: 'text', value: complement, text: complement, claimed: q.claimed };
          case 'mrna': return { prompt: P(q), kind: 'text', value: mrna, text: mrna, claimed: q.claimed };
          case 'protein': return { prompt: P(q), kind: 'text', value: protein, text: protein || (tr.start < 0 ? '没有起始密码子 AUG' : '（无）'), claimed: q.claimed };
          case 'codons': return numRow(q, tr.aa.length + (tr.stop ? 1 : 0));
          case 'gc': return numRow(q, gc);
          case 'count': { const b = String(q.base || '').toUpperCase(); if (!/^[ACGTU]$/.test(b)) fail('count 需要 "base"：A、C、G、T 或 U'); return numRow(q, cnt(b)); }
          case 'h_bonds': return numRow(q, 2 * (cnt('A') + cnt('T') + cnt('U')) + 3 * (cnt('G') + cnt('C')));
        }
      });
      return { rows, detail: [`mRNA：${mrna.match(/.{1,3}/g).join(' ')}`, `翻译：${tr.start < 0 ? '没有 AUG' : `从第 ${tr.start + 1} 个碱基起，${protein || '（无）'}${tr.stop ? '，遇终止密码子停止' : ''}`}`] };
    }
  });

  reg({
    id: 'foodweb', subj: '生物', title: '能量流动',
    doc: `{"kind":"foodweb","links":{"鹰":{"兔":0.5,"鼠":0.5},"兔":{"草":1},"鼠":{"草":1}},"efficiency":0.1,"asks":[{"what":"producer","consumer":"鹰","amount":1,"mode":"exact","claimed":100}]}
  links：每种消费者吃什么，{"食物": 所占比例}（比例和为 1）；没有出现在 links 键里的是生产者。efficiency 为能量传递效率，可写一个数或 [0.1,0.2]。
  what：producer（"consumer" 增加 "amount" 需要消耗多少生产者）、gain（生产者 "producer" 有 "amount" 时 "consumer" 能增加多少）。mode：exact（按给出的比例和效率）、min / max（题目问「至少 / 最多」：min 走最短食物链、效率取大，max 走最长食物链、效率取小；gain 的 max 对应最多能增加多少）。`,
    run(s) {
      if (!isObj(s.links)) fail('links 必须是 {"消费者": {"食物": 比例}}');
      const L = s.links, eff = Array.isArray(s.efficiency) ? s.efficiency.map((v, i) => needNum(v, `efficiency[${i}]`, x => x > 0 && x <= 1, '0~1 的数')) : [needNum(s.efficiency ?? 0.1, 'efficiency', x => x > 0 && x <= 1, '0~1 的数')];
      const eMin = Math.min(...eff), eMax = Math.max(...eff);
      for (const [k, v] of Object.entries(L)) { if (!isObj(v) || !Object.keys(v).length) fail(`links.${k} 必须是非空对象`); }
      const req = (x, mode, seen = []) => { // x 增加 1 需要的生产者量
        if (seen.includes(x)) fail(`食物网有环：${[...seen, x].join(' → ')}`);
        const d = L[x]; if (!d) return 1;
        const parts = Object.entries(d).map(([prey, share]) => [req(prey, mode, [...seen, x]), num(share)]);
        if (mode === 'exact') {
          if (eff.length > 1) fail('mode exact 时 efficiency 要给一个确定的数');
          const tot = parts.reduce((a, p) => a + p[1], 0); if (!parts.every(p => isFinite(p[1])) || Math.abs(tot - 1) > 1e-6) fail(`links.${x} 的比例之和应为 1（现在是 ${fmtN(tot)}）；比例未知时用 mode min / max`);
          return parts.reduce((a, [r, sh]) => a + sh * r / eff[0], 0);
        }
        return mode === 'min' ? Math.min(...parts.map(p => p[0])) / eMax : Math.max(...parts.map(p => p[0])) / eMin;
      };
      const rows = asksOf(s, ['producer', 'gain']).map(q => {
        const mode = q.mode || 'exact'; if (!['exact', 'min', 'max'].includes(mode)) fail('mode 只能是 exact、min、max');
        if (!q.consumer || !(q.consumer in L)) fail(`「${q.consumer}」不是 links 里的消费者`);
        const amount = needNum(q.amount, `${q.what} 的 amount`, x => x > 0, '正数');
        if (q.what === 'producer') return numRow(q, amount * req(q.consumer, mode), q.unit || '');
        return numRow(q, amount / req(q.consumer, mode === 'max' ? 'min' : mode === 'min' ? 'max' : 'exact'), q.unit || '');
      });
      return { rows, detail: [`传递效率 ${eff.map(e => fmtN(e * 100) + '%').join('～')}；食物关系：${Object.entries(L).map(([k, v]) => `${k} ← ${Object.entries(v).map(([p, sh]) => `${p}${isFinite(num(sh)) && Object.keys(v).length > 1 ? ' ' + fmtN(num(sh) * 100) + '%' : ''}`).join('、')}`).join('；')}`] };
    }
  });

  /* ---------------- 对外 ---------------- */
  function catalog() {
    return ORDER.map(id => `### ${REG[id].subj} · ${REG[id].title}（kind: ${id}）\n${REG[id].doc}`).join('\n\n');
  }
  /** 校验并求解：返回 {ok, result} 或 {ok:false, errors}；result 只含普通数据，可存进本机记录 */
  function build(spec, problem = '') {
    if (!isObj(spec)) return { ok: false, errors: ['task 必须是对象，含 kind 与 asks'] };
    const t = REG[spec.kind];
    if (!t) return { ok: false, errors: [`task.kind「${spec.kind}」不存在，可选：${ORDER.join('、')}`] };
    try {
      const r = t.run(spec, problem);
      const rows = r.rows.map(row => {
        const ok = compare(row);
        return { prompt: String(row.prompt), kind: row.kind, text: row.text, value: typeof row.value === 'object' && row.kind === 'equation' ? null : row.value, unit: row.unit || '', claimed: row.claimed ?? null, ok: ok === undefined ? null : ok };
      });
      return { ok: true, result: { kind: t.id, title: t.title, subj: t.subj, rows, detail: r.detail || [] } };
    } catch (e) {
      if (e instanceof TaskError) return { ok: false, errors: e.list.map(m => `task（${t.title}）：${m}`) };
      return { ok: false, errors: [`task（${t.title}）计算出错：${e.message}`] };
    }
  }
  return { catalog, build, list: () => ORDER.map(id => ({ id, subj: REG[id].subj, title: REG[id].title })), parseEquation, normSpecies, roots };
})();
