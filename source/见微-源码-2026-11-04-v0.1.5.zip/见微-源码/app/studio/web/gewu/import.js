'use strict';
/* ======================= 题目导入：分析 → 选实验 → 配置 → 讲题 =======================
 * 2026-11-03 起参照 VeloΦ 的 AI 读题（github.com/Stevenzhang543/VeloPhi）：
 *   · 每一步的 JSON 都由网页校验，不合格就把问题清单发回去让模型修正（最多两次，最后一次允许深度思考）；
 *   · 模型把题目写成「方程模型」，网页自己解（solver.js），和模型的答案对照 —— 数值不靠模型心算；
 *   · 单位、sin37° = 0.6 这类角度由网页换算；网络抖动自动重试一次。
 */
const Importer = {
  lesson: null, protocol: null, engines: null,
  sleep: ms => new Promise(r => setTimeout(r, ms)),

  /* ---- 分析引擎：本地 DeepSeek 代理 / claude.ai 内置 Claude / 关键词 ---- */
  async detect() {
    if (this.engines) return this.engines;
    const e = { deepseek: false, claude: null, images: false };
    try { const r = await fetch('api/health', { cache: 'no-store' }); if (r.ok) { const j = await r.json(); e.deepseek = !!j.deepseek; e.model = j.model; } } catch (err) { }
    try {
      if (window.claude && claude.use) { e.claude = await claude.use('sample'); if (e.claude && e.claude.limits) { const lim = await e.claude.limits(); e.images = !!(lim && lim.images); } }
    } catch (err) { e.claude = null; }
    this.engines = e; return e;
  },
  async loadProtocol() {
    if (this.protocol) return this.protocol;
    try { const r = await fetch('skill/protocol.md'); if (r.ok) this.protocol = await r.text(); } catch (e) { }
    return this.protocol || '你是中国高中理科教师。按用户要求只输出 JSON。';
  },
  /** 一次对话请求。msgs 是字符串（单条提问）或 [{role, content}]（带修正轮次的对话）。返回 {text, truncated} */
  async ask(engine, msgs, o = {}) {
    const system = await this.loadProtocol(), messages = typeof msgs === 'string' ? [{ role: 'user', content: msgs }] : msgs;
    const once = async () => {
      if (engine === 'deepseek' || engine === 'deepseek-r') {
        const model = engine === 'deepseek-r' && !o.fast ? 'deepseek-reasoner' : 'deepseek-chat';
        let r;
        try { r = await fetch('api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system, messages, user: messages[0].content, model }) }); }
        catch (err) { const e = new Error('连接本地服务失败'); e.transient = true; throw e; }
        const j = await r.json().catch(() => ({ error: '本地服务返回了无法解析的内容', transient: true }));
        if (!r.ok || j.error) { const e = new Error(j.error || 'DeepSeek 请求失败（' + r.status + '）'); e.transient = !!j.transient; e.busy = j.status === 429; throw e; }
        return { text: j.text || '', truncated: !!j.truncated };
      }
      if (engine === 'claude') {
        const opts = { modelTier: o.tier || 'default' };
        if (o.images && o.images.length) opts.images = o.images;
        if (o.onText) opts.onText = o.onText;
        const conv = messages.map((m, i) => i === 0 ? { role: 'user', content: system + '\n\n---\n\n' + m.content } : m);
        try { const r = await this.engines.claude(conv, opts); return { text: r.text || '', truncated: false }; }
        catch (err) {
          const e = new Error(err && err.code === 'not_granted' ? '没有获得调用 Claude 的授权' : err && err.code === 'rate_limited' ? '调用太频繁，请稍后再试' : (err && err.message) || 'Claude 请求失败');
          e.transient = !!err && err.code !== 'not_granted' && err.code !== 'rate_limited'; throw e;
        }
      }
      throw new Error('没有可用的分析引擎');
    };
    try { return await once(); }
    catch (e) { // 连接断开、服务繁忙、回复读不出来：等一会儿再问一次
      if (!e.transient) throw e;
      if (o.status) o.status('连接不稳定，正在重试…');
      await this.sleep(e.busy ? 4000 : 1500);
      return once();
    }
  },
  parse(text) {
    const s = String(text || '').replace(/```(?:json)?/g, ''), a = s.indexOf('{'), b = s.lastIndexOf('}');
    if (a < 0 || b < a) throw new Error('模型没有返回 JSON');
    const body = s.slice(a, b + 1);
    try { return JSON.parse(body); } catch (e) { return JSON.parse(this.lenient(body)); }
  },
  /** 模型常见的 JSON 小毛病（只改字符串外面）：1.8×10⁻⁵、1.8×10^-5 这种数，裸写的分数 1/16，结尾多余的逗号 */
  lenient(t) {
    const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
    const fix = x => x
      .replace(/(\d(?:\.\d+)?)\s*[×xX*]\s*10\s*\^\s*\(?\s*([-−]?\d+)\s*\)?/g, (m, a, e) => `${a}e${e.replace('−', '-')}`)
      .replace(/(\d(?:\.\d+)?)\s*[×xX*]\s*10([⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)/g, (m, a, e) => a + 'e' + [...e].map(c => c === '⁻' ? '-' : c === '⁺' ? '' : SUP.indexOf(c)).join(''))
      .replace(/([:\[,]\s*)(-?\d+(?:\.\d+)?\s*\/\s*\d+(?:\.\d+)?)(?=\s*[,\]}])/g, '$1"$2"')
      .replace(/,(\s*[}\]])/g, '$1');
    let out = '', seg = '', inStr = false, esc = false;
    for (const ch of t) {
      if (inStr) { out += ch; if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; }
      else if (ch === '"') { out += fix(seg) + ch; seg = ''; inStr = true; }
      else seg += ch;
    }
    return out + fix(seg);
  },
  tryParse(text) { try { const j = this.parse(text); return j && typeof j === 'object' && !Array.isArray(j) ? j : null; } catch (e) { return null; } },
  /** 回复读不出 JSON 时告诉模型错在哪：空的、被截断，还是夹了别的文字 */
  unreadable(text, truncated) {
    if (!String(text || '').trim()) return '你的上一条回复是空的。请直接输出要求的 JSON 对象（不要思考过程、不要 Markdown、不要解释）。';
    if (truncated) return '你的上一条回复太长，被截断了，不是完整的 JSON。请重新输出一个更简短但完整的 JSON 对象：步骤写得精炼些，可选字段可以省略。';
    return `你的上一条回复不是一个合法的 JSON 对象（开头是：${JSON.stringify(String(text).trim().slice(0, 120))}）。请只输出一个 JSON 对象：以 { 开头、以 } 结尾，不要 Markdown 代码块、注释或解释文字。`;
  },
  repairMsg(errors) { return `网页检查你的 JSON 时发现以下问题，请改正后重新输出完整的 JSON（只改有问题的部分，其余保持不变）：\n${errors.map(e => '- ' + e).join('\n')}`; },
  /**
   * 问一个必须回 JSON 的问题，并用 check 校验：不合格就把问题发回去修正（默认最多两次）。
   * check(json) → {ok, value} 或 {ok:false, errors, fallback?}；fallback 是「去掉不合格的可选部分后仍可用」的结果。
   */
  async askJSON(engine, first, check, o = {}) {
    const msgs = Array.isArray(first) ? [...first] : [{ role: 'user', content: first }], max = o.repairs ?? 2;
    let fallback = null, last = null;
    for (let round = 0; ; round++) {
      const eng = round === 2 && engine === 'deepseek' ? 'deepseek-r' : engine; // 最后一次修正允许深度思考
      const r = await this.ask(eng, msgs, round ? { ...o, images: null } : o);
      const json = this.tryParse(r.text), res = json ? check(json) : null;
      const done = value => ({ ok: true, value, msgs: [...msgs, { role: 'assistant', content: r.text }], repairs: round });
      if (res && res.ok) return done(res.value);
      if (res && res.fallback) fallback = { ...done(res.fallback), dropped: res.errors };
      last = { r, json, res };
      if (round >= max) break;
      if (o.status) o.status(`AI 的输出没有通过校验，正在让它修正（第 ${round + 1} 次）…`);
      msgs.push({ role: 'assistant', content: r.text || '（空）' }, { role: 'user', content: json ? this.repairMsg(res.errors) : this.unreadable(r.text, r.truncated) });
    }
    if (fallback) return fallback;
    const err = new Error(last.json ? `AI 的输出没有通过校验（已修正 ${max} 次）：${last.res.errors.slice(0, 3).join('；')}` : last.r.truncated ? 'AI 的回答太长被截断，没有得到完整的 JSON' : `AI 没有按要求输出 JSON（已重试 ${max} 次）`);
    err.raw = String(last.r.text || '').slice(0, 1500); throw err;
  },
  catalog() { return Lab.list.map(e => `${e.id}｜${Lab.S[e.subj].name}｜${Lab.S[e.subj].books[e.book]}｜${e.unit}｜${e.title}｜${e.kw || ''}`).join('\n'); },
  controls() {
    return (App.ctx ? App.ctx.ctrls : []).map(c => {
      const o = { name: c.name, kind: c.kind, group: c.group || undefined };
      if (c.kind === 'slider') Object.assign(o, { min: c.minF(), max: c.maxF(), step: c.step, unit: c.unit || undefined, value: c.get() });
      if (c.kind === 'select' || c.kind === 'choice') Object.assign(o, { options: c.options(), value: c.get() });
      if (c.kind === 'check' || c.kind === 'text') o.value = c.get();
      return o;
    });
  },
  async exportCatalog() { // 逐个打开实验收集默认控件，供 Claude Code 技能使用
    const out = [];
    for (const e of Lab.list) {
      location.hash = e.id; App.route(); await this.sleep(200);
      out.push({ id: e.id, subject: Lab.S[e.subj].name, book: Lab.S[e.subj].books[e.book], unit: e.unit, title: e.title, kw: e.kw || '', controls: this.controls() });
    }
    location.hash = ''; return JSON.stringify(out, null, 1);
  },
  async saveCatalog() { // 仅本地 serve.py 可用
    const r = await fetch('api/catalog', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: await this.exportCatalog() });
    return r.json();
  },
  keyword(text) {
    let best = null, bs = 0;
    for (const e of Lab.list) {
      const words = [e.title, e.unit, ...(e.kw || '').split(/\s+/)].join(' ').split(/[\s·、，（）()「」—-]+/).filter(w => w.length >= 2);
      const sc = words.reduce((s, w) => s + (text.includes(w) ? w.length : 0), 0);
      if (sc > bs) { bs = sc; best = e; }
    }
    return best;
  },

  /* ---- 校验 ---- */
  strs(v) { return Array.isArray(v) ? v.filter(x => x != null && x !== '').map(x => typeof x === 'string' ? x : JSON.stringify(x)) : v == null || v === '' ? [] : [String(v)]; },
  /** 第一步：字段齐全、实验 id 在目录里、方程模型能编译。方程模型有问题而其余都好时，可以退回「不带模型」的结果 */
  check1(A, problem) {
    const errors = [], out = { ...A }, SUB = ['数学', '物理', '化学', '生物'];
    if (!SUB.includes(out.subject)) errors.push(`subject 必须是 ${SUB.join('、')} 之一`);
    if (out.module === '' || out.module === 'null') out.module = null;
    if (out.module != null && !Lab.byId[out.module]) errors.push(`module「${out.module}」不是实验目录中的 id：只能照抄目录每行第一列，没有合适的实验就填 null`);
    for (const k of ['knowns', 'steps', 'assumptions', 'pitfalls']) out[k] = this.strs(out[k]);
    for (const k of ['summary', 'topic', 'scenario', 'method', 'check', 'conclusion']) if (out[k] != null) out[k] = String(out[k]);
    if (!out.steps.length) errors.push('steps 不能为空：按讲题顺序写出解题步骤');
    if (out.answer == null || String(out.answer).trim() === '') errors.push('answer 不能为空'); else out.answer = String(out.answer);
    let modelErr = [], taskErr = [];
    if (out.model != null) { const b = Solver.build(out.model, problem); if (b.ok) out._built = b; else modelErr = b.errors; }
    if (out.task != null && typeof Tasks !== 'undefined') { const t = this.buildTasks(out.task, problem); if (t.ok) out._task = t.results; else taskErr = t.errors; }
    if (!errors.length && !modelErr.length && !taskErr.length) return { ok: true, value: out };
    // 题型参数、方程模型是可选的：其余都合格时，修正用完仍不行就去掉它们继续
    const fb = errors.length ? null : { ...out };
    if (fb) { if (modelErr.length) delete fb.model; if (taskErr.length) delete fb.task; }
    return { ok: false, errors: [...errors, ...taskErr, ...modelErr], fallback: fb };
  },
  /** task 可以是一个题型，也可以是数组（一道题里几个独立情形，如滴定的两个点） */
  buildTasks(spec, problem) {
    const list = Array.isArray(spec) ? spec : [spec];
    if (!list.length || list.length > 6) return { ok: false, errors: ['task 是一个对象，或 1~6 个对象组成的数组'] };
    const results = [], errors = [];
    list.forEach((s, i) => { const t = Tasks.build(s, problem); if (t.ok) results.push(t.result); else errors.push(...t.errors.map(e => list.length > 1 ? `task[${i}] ${e}` : e)); });
    return errors.length ? { ok: false, errors } : { ok: true, results };
  },
  findCtrl(ctrls, n) {
    const norm = s => String(s).replace(/\s+/g, '').toLowerCase();
    return ctrls.find(c => c.name === n) || ctrls.find(c => norm(c.name) === norm(n)) || ctrls.find(c => norm(c.name).startsWith(norm(n)));
  },
  /** 把一条设置换成控件能接受的值：选项匹配、单位换算、角度对齐。返回 {value, note} 或 {error} */
  coerce(c, s, problem) {
    let v = s.value, unit = s.unit;
    if (c.kind === 'select' || c.kind === 'choice') {
      const ops = c.options(), op = ops.find(o => o.value == v) || ops.find(o => o.text === v) || ops.find(o => String(o.text).includes(String(v)));
      return op ? { value: op.value } : { error: `「${c.name}」的值「${v}」不在 options 里，可选的 value：${ops.map(o => o.value).join('、')}` };
    }
    if (c.kind !== 'slider') return { value: v };
    if (v && typeof v === 'object') { unit = v.unit; v = v.value; }
    if (typeof v === 'string') {
      const m = /^\s*([-+−]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?)\s*(.*)$/i.exec(v);
      if (m) { unit = unit ?? m[2]; v = +m[1].replace('−', '-'); } else v = Solver.evalConst(v);
    }
    v = +v;
    if (!isFinite(v)) return { error: `「${c.name}」是滑块，value 必须是数（或 {"value": 数, "unit": "单位"}）` };
    const notes = [];
    if (unit != null && String(unit).trim() !== '' && c.unit) {
      const cv = Solver.convert(v, unit, c.unit);
      if (cv.error) return { error: `「${c.name}」：${cv.error}` };
      if (cv.value !== v) notes.push(`${c.name}：${fmt(v, 4)} ${unit} = ${fmt(cv.value, 4)} ${c.unit}`);
      v = cv.value;
    }
    const ang = Solver.statedAngles(problem);
    if (c.unit && Solver.normUnit(c.unit) === '°' && ang.has(v)) { notes.push(`按题目给出的三角函数值，${c.name} ${v}° 取为 ${ang.get(v)}°，与按近似值手算的答案一致`); v = ang.get(v); }
    return { value: v, note: notes.join('；') };
  },
  /** 第二步：每个 name 都是现有控件，选项与单位都能对上 */
  check2(B, problem) {
    const ctrls = App.ctx ? App.ctx.ctrls : [], errors = [], settings = [], press = [], notes = [];
    if (!Array.isArray(B.settings)) errors.push('缺少 settings 数组（这是第二步：输出 settings、press、watch、caveats）');
    (Array.isArray(B.settings) ? B.settings : []).forEach((s, i) => {
      if (!s || typeof s !== 'object') { errors.push(`settings[${i}] 必须是 {"name": 控件名, "value": 值}`); return; }
      const c = this.findCtrl(ctrls, s.name);
      if (!c || !c.set) { errors.push(`settings[${i}].name「${s.name}」不是可设置的控件（必须与控件列表里的 name 完全一致）`); return; }
      const r = this.coerce(c, s, problem);
      if (r.error) { errors.push(r.error); return; }
      if (r.note) notes.push(r.note);
      settings.push({ name: c.name, value: r.value });
    });
    for (const n of this.strs(B.press)) { const c = this.findCtrl(ctrls, n); if (c && c.press) press.push(c.name); else errors.push(`press 里的「${n}」不是按钮控件`); }
    const value = { settings, press, watch: this.strs(B.watch), caveats: B.caveats ? String(B.caveats) : '', notes };
    return errors.length ? { ok: false, errors, fallback: Array.isArray(B.settings) ? value : null } : { ok: true, value };
  },

  /* ---- 主流程 ---- */
  async analyze(text, images, engine, status) {
    if (engine === 'keyword') {
      const e = this.keyword(text);
      return { problem: text, engine, module: e ? e.id : null, topic: e ? e.unit : '', summary: '按关键词匹配实验，未调用模型，需要手动调节参数。', knowns: [], steps: [], answer: '', settings: [], watch: [], caveats: '' };
    }
    status('第 1 步：读题、解题、填题型参数并选择实验…');
    const types = typeof Tasks !== 'undefined' ? `\n\n## 程序题型（题目属于其中之一时填 task，程序用专门算法求解）\n${Tasks.catalog()}` : '';
    const user = `## 实验目录\n${this.catalog()}${types}\n\n## 题目\n${text || '（见图片）'}\n\n## 任务\n执行协议中的第一步，只输出 JSON。`;
    const r = await this.askJSON(engine, user, j => this.check1(j, text), { images, tier: 'complex', status });
    const l = { problem: text, engine, ...r.value };
    if (r.dropped) l.calcNote = '题型参数或方程模型没有通过校验，已跳过这部分程序求解：' + r.dropped.slice(0, 2).join('；');
    await this.verifyAll(l, r.msgs, status);
    return l;
  },
  /** 程序求解（题型 task + 方程模型 model），与 AI 的答案对照；有不符就带着全部证据让 AI 重新检查一次 */
  async verifyAll(l, conv, status) {
    const ev = [this.runTask(l), await this.calc(l, conv, status)].filter(Boolean);
    if (!ev.length || !l.engine || l.engine === 'json') return;
    status('程序求解与解答不符，正在让 AI 重新检查解答…');
    const F = await this.correct(l, ev.join('\n\n'), status, true);
    if (F) l.recheck.review = F.model_wrong ? 'model' : 'answer';
  },
  /** 题型求解的结果已在校验时算好（check1 → Tasks.build），这里只整理并给出不符的证据 */
  runTask(l) {
    const ts = l._task; delete l._task;
    if (!ts) return '';
    l.taskRes = ts;
    return ts.map(t => {
      const bad = t.rows.filter(x => x.ok === false);
      if (!bad.length) return '';
      return `网页按你填写的题型参数（${t.title}）用专门算法求解（算法本身可信，除非参数与题目不符）：\n` + bad.map(x => `- ${x.prompt}：原解答给出 ${typeof x.claimed === 'object' ? JSON.stringify(x.claimed) : x.claimed}，程序算得 ${x.text}`).join('\n') +
        `\n程序的推导：\n${t.detail.map(d => '  ' + d).join('\n')}`;
    }).filter(Boolean).join('\n\n') + (ts.some(t => t.rows.some(x => x.ok === false)) ? `\n你填的参数：${JSON.stringify(l.task)}` : '');
  },
  taskList(l) { return l.taskRes ? [].concat(l.taskRes) : []; }, // 旧记录是单个对象
  /** 网页解方程模型，与模型的答案对照；无唯一解时让模型复查一次，数值不符时让模型重新检查解答 */
  async calc(l, conv, status) {
    let built = l._built; delete l._built;
    if (!built) return '';
    status('网页正在求解方程模型、复算答案…');
    let res = Solver.solve(built.model);
    if (res.verdict !== 'solved' && l.engine && l.engine !== 'json') {
      status('方程组没有唯一解，正在让 AI 复查方程…');
      try {
        const r = await this.askJSON(l.engine, [...conv, { role: 'user', content: this.verdictMsg(built, res) }], j => this.check1(j, l.problem), { repairs: 1, status });
        if (r.value._built) {
          const res2 = Solver.solve(r.value._built.model);
          if (res2.verdict === 'solved' || r.value.conclusion) {
            built = r.value._built; res = res2; delete r.value._built; Object.assign(l, r.value);
            if (l._task) { l.taskRes = l._task; delete l._task; } // AI 复查时若改了题型参数，用新的结果
          }
        }
      } catch (e) { /* 复查失败就保留原结论 */ }
      delete l._built;
    }
    const assume = new Set(l.assumptions || []); built.notes.forEach(n => assume.add(n)); l.assumptions = [...assume];
    const m = built.model;
    l.calc = {
      verdict: res.verdict,
      knowns: m.knowns.map(k => ({ name: k.name, value: k.value, unit: k.unit, meaning: k.meaning })),
      unknowns: m.unknowns.map(u => ({ name: u.name, unit: u.unit, meaning: u.meaning, value: res.values[u.name] })),
      equations: m.equations.map(e => ({ text: e.text, why: e.why })),
      conflicts: res.conflicts.map(c => ({ text: m.equations[c.index].text, residual: c.residual })),
      undetermined: res.undetermined,
      rows: res.answers.map(a => {
        const cl = a.claimed == null || a.claimed === '' ? NaN : Solver.evalConst(a.claimed);
        return { prompt: a.prompt, unit: a.unit, value: a.value, claimed: a.claimed, ok: a.value == null || !isFinite(cl) ? null : Solver.close(a.value, cl) };
      })
    };
    const bad = l.calc.rows.filter(x => x.ok === false);
    if (!bad.length) return '';
    return `网页按你在第一步写的方程模型做了数值求解（数值计算本身不会出错）：\n` + bad.map(x => `- ${x.prompt}：原解答给出 ${x.claimed}，按方程模型算得 ${this.num(x.value)}${x.unit ? ' ' + x.unit : ''}`).join('\n') +
      `\n方程模型：\n${m.equations.map(e => '  ' + e.text + (e.why ? `（${e.why}）` : '')).join('\n')}\n已知量（国际单位）：${m.knowns.map(k => `${k.name} = ${this.num(k.si)}`).join('，') || '无'}`;
  },
  verdictMsg(built, res) {
    const m = built.model, lines = [`网页解了你的方程模型，结论：${res.verdict === 'inconsistent' ? '方程互相矛盾，不存在同时满足全部方程的解' : res.verdict === 'underdetermined' ? `条件不足，不能确定：${res.undetermined.join('、') || '所求的量'}` : '数值求解失败（可能是初值或取值范围不合适）'}。`];
    if (res.conflicts.length) lines.push(`最小二乘解下不满足的方程：${res.conflicts.map(c => `第 ${c.index + 1} 条（${m.equations[c.index].text}，相对残差 ${c.residual.toPrecision(2)}）`).join('；')}。`);
    lines.push('请逐条对照题目检查：是否漏了某个力或条件、系数或正负号是否写错、角度是否已按弧度处理、未知量是否多设或少设、非线性方程的 guess / min / max 是否能选出物理上合理的根。');
    lines.push('如果方程有误：改正后输出第一步的完整 JSON。');
    lines.push('如果方程与题目一致（题目本身在理想条件下就无解或条件不足）：方程保持不变，在 JSON 中加上 "conclusion"，用一两句话说明这在物理或数学上意味着什么，steps 和 answer 也据此改写。');
    return lines.join('\n');
  },
  num(v) { return v == null || !isFinite(v) ? '—' : Math.abs(v) >= 1e5 || (Math.abs(v) < 1e-3 && v !== 0) ? v.toExponential(3) : String(+v.toPrecision(5)); },
  /** 第四步：拿着核对证据（网页复算或实验读数）让模型重新检查 */
  async correct(l, evidence, status, fromCalc) {
    const user = `## 题目\n${l.problem || '（见图片）'}\n\n## 原解答\n${JSON.stringify({ steps: l.steps, answer: l.answer })}\n\n## 核对结果\n${evidence}\n\n## 任务\n执行协议中的第四步，只输出 JSON。`;
    let F;
    try { F = (await this.askJSON(l.engine, user, j => (j.answer || j.error) ? { ok: true, value: j } : { ok: false, errors: ['必须给出 error 与 answer'] }, { tier: 'complex', repairs: 1, status })).value; }
    catch (e) { return null; }
    const box = fromCalc ? (l.recheck = l.recheck || {}) : l.verify;
    box.check = F.error ? String(F.error) : '';
    const ans = F.answer == null ? '' : String(F.answer);
    if (ans && ans.replace(/\s/g, '') !== String(l.answer).replace(/\s/g, '')) { box.oldAnswer = l.answer; l.answer = ans; }
    else box.disputed = !F.model_wrong; // 模型坚持原答案：保留冲突提示，交给老师判断
    const steps = this.strs(F.steps); if (steps.length) { l.steps = steps; l.shown = 1; }
    return F;
  },
  async configure(lesson, status) {
    const e = Lab.byId[lesson.module]; status('第 2 步：配置实验参数…');
    const user = `## 题目\n${lesson.problem || '（见图片）'}\n\n## 第一步结果\n${JSON.stringify({ summary: lesson.summary, knowns: lesson.knowns, steps: lesson.steps, answer: lesson.answer, scenario: lesson.scenario })}\n\n## 实验「${e.title}」原理\n${(e.info || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ')}\n\n## 控件列表\n${JSON.stringify(this.controls())}\n\n## 任务\n执行协议中的第二步，只输出 JSON。`;
    const B = (await this.askJSON(lesson.engine, user, j => this.check2(j, lesson.problem), { tier: 'default', fast: true, status })).value;
    Object.assign(lesson, { settings: B.settings, press: B.press, watch: B.watch, caveats: B.caveats, convNotes: B.notes });
  },
  readouts() { // 同步重绘一次再读面板（后台标签页里 requestAnimationFrame 会暂停）
    try { App.ctx && App.ctx.drawFn && App.ctx.drawFn(); } catch (e) { }
    return [...document.querySelectorAll('.panel .out')].map(o => [...o.querySelectorAll('.kv')].map(k => k.innerText.replace(/\s*\n\s*/g, '：')).join('\n') || o.innerText).filter(s => s.trim()).join('\n');
  },
  async verify(lesson, status) {
    status('第 3 步：用实验数据核对答案…');
    let prev = '', same = 0, t0 = Date.now(), minWait = (lesson.press || []).length ? 2500 : 600;
    while (Date.now() - t0 < 9000) { await this.sleep(500); const cur = this.readouts(); same = cur === prev ? same + 1 : 0; prev = cur; if (same >= 2 && Date.now() - t0 >= minWait) break; }
    if (!prev.trim()) { lesson.verify = { consistent: true, check: '实验面板没有可读的数值，未核对。', rows: [] }; return; }
    const base = `## 题目\n${lesson.problem || '（见图片）'}\n\n## 解答\n${JSON.stringify({ steps: lesson.steps, answer: lesson.answer })}\n\n## 实验设置\n${(lesson.applied?.ok || []).join('；')}\n\n## 实验读数\n${prev}`;
    const C = (await this.askJSON(lesson.engine, base + '\n\n## 任务\n执行协议中的第三步，只输出 JSON。', j => Array.isArray(j.pairs ?? []) ? { ok: true, value: j } : { ok: false, errors: ['pairs 必须是数组'] }, { repairs: 1, status })).value;
    // 网页自己比较数值，避免模型「凑数」
    const nums = s => (String(s).replace(/−/g, '-').match(/-?\d+(?:\.\d+)?(?:×10-?\d+)?/g) || []).map(t => { const [m, e] = t.split('×10'); return +m * (e ? 10 ** +e : 1); });
    const lines = prev.split('\n').map(x => { const i = x.indexOf('：'); return i < 0 ? null : [x.slice(0, i).trim(), x.slice(i + 1).trim()]; }).filter(Boolean);
    const rows = [];
    for (const p of C.pairs || []) {
      if (!p || !p.readout) continue;
      const hit = lines.find(([k]) => k === p.readout) || lines.find(([k]) => k.includes(p.readout) || String(p.readout).includes(k));
      if (!hit) continue;
      const tail = hit[1].match(/=\s*(-?\d[\d.]*(?:×10-?\d+)?)\s*[^\d=()（）]*$/), mv = tail ? tail[1] : hit[1]; // 「算式 = 结果」只取结果
      let a = Array.isArray(p.answer_value) ? p.answer_value.map(Number) : typeof p.answer_value === 'number' ? [p.answer_value] : /[:：]/.test(String(p.answer_value)) ? nums(p.answer_value) : [Solver.evalConst(p.answer_value)].filter(isFinite), m = nums(mv);
      if (!a.length) a = nums(p.answer_value);
      if (!a.length || !m.length) continue;
      if (/[:：]/.test(hit[1]) && a.length === m.length && a.length > 1) { // 比例：与顺序、倍数无关
        const nm = v => { const s = v.reduce((x, y) => x + y, 0) || 1; return v.map(x => x / s).sort((x, y) => x - y); };
        const ok = nm(a).every((x, i) => Math.abs(x - nm(m)[i]) < 0.01);
        rows.push({ quantity: p.quantity, readout: hit[0], answer: a.join(' : '), measured: hit[1], ok }); continue;
      }
      // 正方向约定可能不同（实验取向上为正、解答取向下为正）：大小一致也算一致
      const n = a.length === m.length ? a.length : 1, ok = [...Array(n).keys()].every(i => Solver.close(a[i], m[i]) || (n === 1 && Solver.close(Math.abs(a[i]), Math.abs(m[i]))));
      rows.push({ quantity: p.quantity, readout: hit[0], answer: a.slice(0, n).map(x => fmt(x, 4)).join(', '), measured: hit[1], ok });
    }
    lesson.verify = { consistent: rows.every(r => r.ok), rows, check: rows.length ? '' : (C.note || '实验中没有与答案直接对应的读数，未核对。') };
    if (lesson.verify.consistent) return;
    status('数值与实验不符，正在重新检查解答…');
    const bad = rows.filter(r => !r.ok).map(r => `${r.quantity}：原答案换算为 ${r.answer}，实验读数「${r.readout}」为 ${r.measured}`).join('\n');
    await this.correct(lesson, `实验按精确公式或数值模拟计算，读数可信，除非实验设置与题目不对应。\n实验设置：${(lesson.applied?.ok || []).join('；')}\n不符的项目：\n${bad}`, status, false);
  },
  async apply(lesson) {
    const ctrls = App.ctx ? App.ctx.ctrls : [];
    const sets = [...(lesson.settings || [])].sort((a, b) => { const r = s => { const c = this.findCtrl(ctrls, s.name); return c && (c.kind === 'select' || c.kind === 'choice') ? 0 : 1; }; return r(a) - r(b); });
    const ok = [], miss = [];
    for (const s of sets) {
      const c = this.findCtrl(ctrls, s.name); if (!c || !c.set) { miss.push(s.name); continue; }
      const r = this.coerce(c, s, lesson.problem); if (r.error) { miss.push(s.name); continue; }
      let v = r.value;
      if (c.kind === 'slider') { v = clamp(+v, c.minF(), c.maxF()); if (!isFinite(v)) { miss.push(s.name); continue; } }
      c.set(v); ok.push(`${c.name} = ${c.kind === 'slider' ? fmt(v, 4) : v}`); await this.sleep(140);
    }
    for (const n of lesson.press || []) { const c = this.findCtrl(ctrls, n); if (c && c.press) { await this.sleep(200); c.press(); ok.push(`按下「${c.name}」`); } else miss.push(n); }
    lesson.applied = { ok, miss };
  },

  /* ---- 记录（仅本机浏览器） ---- */
  history() { try { return JSON.parse(localStorage.getItem('lab-lessons') || '[]'); } catch (e) { return []; } },
  save(l) { try { const h = this.history().filter(x => x.id !== l.id); h.unshift(l); localStorage.setItem('lab-lessons', JSON.stringify(h.slice(0, 12))); } catch (e) { } },

  /* ---- 题目导入页 ---- */
  async page() {
    const v = document.getElementById('view'); v.innerHTML = '';
    const wrap = el('div', 'imp');
    wrap.innerHTML = `<div class="ehead"><h1>题目导入</h1><span class="chip">粘贴题目 → 自动解题并复算 → 打开对应实验并配置参数 → 分步讲解</span></div>
      <div class="imp-grid">
        <section class="grp">
          <h4>题目</h4>
          <label class="fld"><textarea id="imp-text" rows="9" placeholder="把题目粘贴到这里，例如：从 20 m 高处以 15 m/s 的速度水平抛出一个小球，不计空气阻力，求落地时间和水平位移。"></textarea></label>
          <label class="fld" id="imp-imgwrap" hidden><span>或上传题目图片（只有 Claude 引擎能读图）</span><input id="imp-img" type="file" accept="image/*"></label>
          <div class="row"><label class="fld" style="flex:1"><span>分析引擎</span><select id="imp-engine"></select></label></div>
          <div class="row"><button class="btn pri" id="imp-go" type="button">分析并模拟</button><button class="btn" id="imp-demo" type="button">填入示例题</button></div>
          <div class="note" id="imp-status"></div>
          <p class="note imp-how">AI 解题时同时写出一组「方程模型」，网页自己解方程复算答案；AI 的输出不合格会被退回修正，单位与 sin37° = 0.6 之类的角度由网页换算。</p>
        </section>
        <section class="grp">
          <h4>引擎状态</h4>
          <div class="out" id="imp-eng"><div class="note">正在检测…</div></div>
          <h4>直接导入讲解 JSON</h4>
          <div class="note">把 Claude Code 技能 <b>problem-sim</b> 或其他工具生成的讲解 JSON 粘贴到这里。</div>
          <label class="fld"><textarea id="imp-json" rows="4" placeholder='{"module":"p-proj","steps":[…],"settings":[…]}'></textarea></label>
          <div class="row"><button class="btn" id="imp-jsongo" type="button">导入 JSON</button></div>
          <h4>最近的题目（保存在本机浏览器）</h4>
          <div id="imp-hist" class="out"></div>
        </section>
      </div>
      <div id="imp-result"></div>`;
    v.appendChild(wrap);
    const $ = id => document.getElementById(id), st = m => { const s = $('imp-status'); if (s) s.textContent = m; else this.status(m); };
    const demos = ['从离地 20 m 高处以 15 m/s 的初速度水平抛出一个小球，不计空气阻力，g 取 10 m/s²。求小球落地时间、水平位移和落地速度大小。',
      '已知椭圆 x²/16 + y²/9 = 1，直线 y = x + 1 与椭圆交于 A、B 两点，求弦长 |AB|。',
      '质量为 2 kg 的物块从倾角 37° 的斜面顶端由静止滑下，斜面长 8 m，物块与斜面间的动摩擦因数为 0.25，g 取 10 m/s²，sin37° = 0.6，cos37° = 0.8。求物块的加速度和滑到底端所用的时间。',
      '用 0.1000 mol/L NaOH 溶液滴定 20.00 mL 0.1000 mol/L 醋酸溶液，应选用什么指示剂？滴定终点时溶液 pH 约为多少？',
      '在棱长为 2 的正方体 ABCD-A₁B₁C₁D₁ 中，求直线 A₁C 与平面 ABCD 所成角的正弦值。',
      '某种疾病的患病率为 1%，检测方法的灵敏度为 99%，对未患病者误诊为阳性的概率为 5%。某人检测为阳性，求他真正患病的概率。'];
    let di = 0; $('imp-demo').onclick = () => { $('imp-text').value = demos[di++ % demos.length]; };
    const renderHist = () => { const h = this.history(); $('imp-hist').innerHTML = h.length ? '' : '<div class="note">还没有记录。</div>'; h.forEach(l => { const a = el('a', 'kv', `<span>${(l.problem || l.summary || '').slice(0, 34)}…</span><b>${l.module ? Lab.byId[l.module]?.title || '' : '仅解答'}</b>`); a.href = '#'; a.onclick = ev => { ev.preventDefault(); this.open(l); }; $('imp-hist').appendChild(a); }); };
    renderHist();
    $('imp-jsongo').onclick = async () => {
      try {
        const l = this.parse($('imp-json').value); l.id = Date.now(); l.engine = 'json';
        if (l.module && !Lab.byId[l.module]) throw new Error('目录里没有实验 ' + l.module);
        const notes = [];
        if (l.task && !l.taskRes && typeof Tasks !== 'undefined') { const t = this.buildTasks(l.task, l.problem || ''); if (t.ok) l._task = t.results; else notes.push('题型参数有误，未求解：' + t.errors.slice(0, 2).join('；')); }
        if (l.model && !l.calc) { const b = Solver.build(l.model, l.problem || ''); if (b.ok) l._built = b; else notes.push('方程模型有误，未复算：' + b.errors.slice(0, 2).join('；')); }
        if (notes.length) l.calcNote = notes.join('　');
        await this.verifyAll(l, [], st);
        this.save(l); this.open(l);
      } catch (e) { st('JSON 有误：' + e.message); }
    };
    const eng = await this.detect();
    const opts = [];
    if (eng.deepseek) opts.push(['deepseek-r', 'DeepSeek 推理模型（推荐）'], ['deepseek', 'DeepSeek 对话模型（更快，答案由网页复算把关）']);
    if (eng.claude) opts.push(['claude', 'Claude（claude.ai 内置）']);
    opts.push(['keyword', '仅关键词匹配实验（不解题）']);
    $('imp-engine').innerHTML = opts.map(([k, t]) => `<option value="${k}">${t}</option>`).join('');
    $('imp-imgwrap').hidden = !eng.images;
    $('imp-eng').innerHTML = [['DeepSeek', eng.deepseek ? '可用（经见微本地服务转发）' : '未配置：在见微「设置 → DeepSeek 题目分析」里填入密钥'], ...(eng.claude ? [['Claude', '可用' + (eng.images ? '，支持图片' : '')]] : []), ['关键词匹配', '始终可用']].map(r => `<div class="kv"><span>${r[0]}</span><b>${r[1]}</b></div>`).join('');
    $('imp-engine').onchange = () => { $('imp-imgwrap').hidden = !(eng.images && $('imp-engine').value === 'claude'); };
    $('imp-engine').onchange();
    $('imp-go').onclick = async () => {
      const text = $('imp-text').value.trim(), file = $('imp-img').files && $('imp-img').files[0], engine = $('imp-engine').value;
      if (!text && !file) { st('请先粘贴题目或上传图片。'); return; }
      $('imp-go').disabled = true;
      try {
        const l = await this.analyze(text, file && engine === 'claude' ? [file] : null, engine, st);
        l.id = Date.now();
        if (l.module && engine !== 'keyword') { try { await this.prepareAndOpen(l, st); } catch (e) { st('配置实验时出错：' + e.message + '，已只显示解答。'); this.save(l); this.open(l); } }
        else { this.save(l); this.open(l); }
      } catch (e) { st('分析失败：' + e.message); }
      if ($('imp-go')) $('imp-go').disabled = false;
    };
  },
  async prepareAndOpen(l, st) { // 先打开实验拿到控件，再做第 2 步
    this.lesson = { ...l, pending: true };
    if (location.hash === '#' + l.module) App.route(); else location.hash = l.module;
    await this.sleep(400);
    this.status('正在根据题目配置实验参数…');
    await this.configure(this.lesson, m => this.status(m));
    delete this.lesson.pending; await this.apply(this.lesson); this.renderCard();
    const cur = this.lesson;
    try { await this.verify(cur, m => this.status(m)); } catch (e) { cur.verify = { consistent: true, check: '核对时出错：' + e.message }; }
    cur.done = true; this.save(cur); if (this.lesson === cur) this.renderCard(); void st;
  },
  open(l) {
    this.lesson = l;
    if (l.module && Lab.byId[l.module]) { if (location.hash === '#' + l.module) App.route(); else location.hash = l.module; }
    else { const r = document.getElementById('imp-result'); if (r) { r.innerHTML = ''; r.appendChild(this.card(l)); } }
  },

  /* ---- 实验页里的讲题卡 ---- */
  afterOpen(e) {
    if (!this.lesson || this.lesson.module !== e.id) return;
    const v = document.getElementById('view'), body = v.querySelector('.ebody');
    const holder = el('div'); holder.id = 'lesson'; v.insertBefore(holder, body);
    this.renderCard();
    if (!this.lesson.pending && (this.lesson.settings || []).length && !this.lesson._applied) { this.lesson._applied = true; this.apply(this.lesson).then(() => this.renderCard()); }
  },
  status(m) { const s = document.querySelector('#lesson .lsn-status'); if (s) s.textContent = m; },
  renderCard() { const h = document.getElementById('lesson'); if (!h || !this.lesson) return; h.innerHTML = ''; h.appendChild(this.card(this.lesson)); },
  /** 「程序求解」：题型求解 + 方程模型 + 重新检查的结论 */
  calcBlock(l, esc) {
    const out = [], ts = this.taskList(l), c = l.calc;
    // 旧记录把重新检查的结论存在 calc 上
    const rc = l.recheck || (c && (c.check || c.oldAnswer || c.disputed || c.review) ? c : null);
    const bad = [...ts.flatMap(t => t.rows), ...(c ? c.rows : [])].some(r => r.ok === false);
    if (bad && rc) {
      const head = rc.review === 'model' ? '程序求解与解答不符：AI 认为题型参数 / 方程模型写错了，解答保持不变' : rc.disputed ? '程序求解与解答不符，AI 坚持原答案，请老师核查' : rc.oldAnswer ? '程序求解与解答不符，已重新解答' : '程序求解与解答不符';
      out.push(`<div class="lsn-calc fix"><b>${esc(head)}</b>${rc.check ? `<div>${rc.disputed ? 'AI 的解释：' : ''}${esc(rc.check)}</div>` : ''}${rc.oldAnswer && l.showAns ? `<div class="note">原答案：${esc(rc.oldAnswer)}</div>` : ''}</div>`);
    }
    ts.forEach(t => out.push(this.taskBlock(t, esc)));
    if (c) out.push(this.modelBlock(c, esc));
    if (l.calcNote) out.push(`<p class="note">${esc(l.calcNote)}</p>`);
    return out.join('');
  },
  taskBlock(t, esc) {
    const bad = t.rows.some(r => r.ok === false), compared = t.rows.some(r => r.ok !== null);
    const head = `程序求解 · ${t.title}：${bad ? '与解答不一致' : compared ? '与解答一致' : '已算出'}`;
    const cl = v => v == null || v === '' ? '—' : typeof v === 'object' ? JSON.stringify(v) : String(v);
    const rows = t.rows.map(r => `<tr><td>${esc(r.prompt)}</td><td>${esc(cl(r.claimed))}</td><td><b>${esc(r.text)}</b></td><td class="${r.ok === false ? 'bad' : r.ok ? 'good' : ''}">${r.ok === null ? '' : r.ok ? '✓' : '✗'}</td></tr>`).join('');
    return `<div class="lsn-calc ${bad ? 'fix' : 'ok'}"><b>${esc(head)}</b>
      <table class="calc-t"><thead><tr><th>所求</th><th>AI 解答</th><th>程序求解</th><th></th></tr></thead><tbody>${rows}</tbody></table>
      ${t.detail.length ? `<details><summary>程序的推导（${esc(t.subj)} · ${esc(t.title)}）</summary><ul class="calc-eq">${t.detail.map(d => `<li>${esc(d)}</li>`).join('')}</ul></details>` : ''}</div>`;
  },
  modelBlock(c, esc) {
    const bad = c.rows.some(r => r.ok === false), compared = c.rows.some(r => r.ok !== null);
    const cls = c.verdict !== 'solved' ? 'warn' : bad ? 'fix' : 'ok';
    const head = c.verdict !== 'solved' ? `方程组${Solver.VERDICT[c.verdict]}` : !compared ? '网页已按方程模型算出结果' : !bad ? '网页解方程复算：与解答一致' : '方程模型复算与解答不一致';
    const val = r => r.value == null ? (c.verdict === 'inconsistent' ? '无解' : '不能确定') : this.num(r.value) + (r.unit && r.unit !== '1' ? ' ' + r.unit : '');
    const rows = c.rows.map(r => `<tr><td>${esc(r.prompt)}</td><td>${r.claimed == null || r.claimed === '' ? '—' : esc(r.claimed)}</td><td><b>${esc(val(r))}</b></td><td class="${r.ok === false ? 'bad' : r.ok ? 'good' : ''}">${r.ok === null ? '' : r.ok ? '✓' : '✗'}</td></tr>`).join('');
    const eqs = c.equations.map(e => `<li><code>${esc(e.text)}</code>${e.why ? `<span>${esc(e.why)}</span>` : ''}</li>`).join('');
    const kn = c.knowns.map(k => `<code>${esc(k.name)} = ${esc(k.value)}${k.unit ? ' ' + esc(k.unit) : ''}</code>${k.meaning ? esc(k.meaning) : ''}`).join('；');
    const unk = c.unknowns.map(u => `<code>${esc(u.name)}</code>${u.meaning ? esc(u.meaning) : ''}${u.unit ? `（${esc(u.unit)}）` : ''}`).join('；');
    return `<div class="lsn-calc ${cls}"><b>${esc(head)}</b>
      ${c.rows.length ? `<table class="calc-t"><thead><tr><th>所求</th><th>AI 解答</th><th>网页复算</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : ''}
      ${c.conflicts.length ? `<div class="note">不能同时满足的方程：${c.conflicts.map(x => `<code>${esc(x.text)}</code>`).join('、')}</div>` : ''}
      ${c.verdict === 'underdetermined' && c.undetermined.length ? `<div class="note">不能确定的未知量：${esc(c.undetermined.join('、'))}</div>` : ''}
      <details><summary>方程模型（${c.equations.length} 条方程，网页数值求解）</summary>
        ${kn ? `<p class="note">已知：${kn}</p>` : ''}${unk ? `<p class="note">未知：${unk}</p>` : ''}<ol class="calc-eq">${eqs}</ol></details></div>`;
  },
  card(l) {
    l.shown = l.shown ?? 1;
    const c = el('section', 'lesson'), steps = l.steps || [];
    const esc = s => String(s ?? '').replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[ch]);
    const list = (title, a) => (a || []).length ? `<h5>${title}</h5><ul>${a.map(k => `<li>${esc(k)}</li>`).join('')}</ul>` : '';
    const allShown = l.shown >= steps.length;
    c.innerHTML = `<div class="lsn-head"><h3>讲题 · ${esc(l.topic || l.subject || '')}</h3><div class="row">
        ${steps.length ? `<button class="btn pri" data-a="next" type="button">下一步（${Math.min(l.shown, steps.length)}/${steps.length}）</button><button class="btn" data-a="all" type="button">全部展开</button>` : ''}
        ${l.answer ? `<button class="btn" data-a="ans" type="button">${l.showAns ? '隐藏答案' : '显示答案'}</button>` : ''}
        ${(l.settings || []).length ? '<button class="btn" data-a="re" type="button">重新应用设置</button>' : ''}
        <button class="btn" data-a="hide" type="button">收起</button></div></div>
      ${l.problem ? `<p class="lsn-prob">${esc(l.problem)}</p>` : ''}
      ${l.summary ? `<p><b>题意：</b>${esc(l.summary)}</p>` : ''}
      <div class="lsn-grid"><div>
        ${list('已知', l.knowns)}
        ${list('假设', l.assumptions)}
        ${l.method ? `<h5>思路与规律</h5><p>${esc(l.method)}</p>` : ''}
        ${steps.length ? `<h5>解题步骤</h5><ol>${steps.slice(0, l.shown).map(k => `<li>${esc(k)}</li>`).join('')}</ol>` : ''}
        ${l.answer && l.showAns ? `<div class="fb">答案：${esc(l.answer)}</div>` : ''}
        ${l.conclusion ? `<p><b>结论：</b>${esc(l.conclusion)}</p>` : ''}
        ${allShown && l.check ? `<h5>检验</h5><p>${esc(l.check)}</p>` : ''}
        ${allShown ? list('易错点', l.pitfalls) : ''}
        ${l.showAns || allShown ? this.calcBlock(l, esc) : (l.calc || l.taskRes) ? `<p class="note">程序求解：${[...this.taskList(l).flatMap(t => t.rows), ...(l.calc ? l.calc.rows : [])].some(r => r.ok === false) ? '有不一致，展开答案后查看' : l.calc && l.calc.verdict !== 'solved' ? '方程组没有唯一解，展开答案后查看' : '已完成，展开答案后查看'}</p>` : ''}
        ${l.verify ? `<div class="lsn-verify ${l.verify.consistent ? 'ok' : 'fix'}"><b>${l.verify.consistent ? (l.verify.rows?.length ? '答案与实验读数一致' : '未能用实验核对') : l.verify.disputed ? '答案与实验读数不符，模型坚持原答案，请老师核查' : '原解答与实验读数不符，已重新解答'}</b>${l.verify.oldAnswer && l.showAns ? `（原答案：${esc(l.verify.oldAnswer)}）` : ''}
          ${(l.verify.rows || []).map(r => `<div>${r.ok ? '✓' : '✗'} ${esc(r.quantity)}：答案 ${esc(r.answer)}，实验 ${esc(r.measured)}</div>`).join('')}
          ${l.verify.check ? `<div>${l.verify.disputed ? '模型的解释：' : ''}${esc(l.verify.check)}</div>` : ''}
          ${l.verify.disputed && l.engine === 'deepseek' ? '<div>建议换用「DeepSeek 推理模型」重新分析。</div>' : ''}</div>` : ''}
      </div><div>
        ${list('在模拟中观察', l.watch)}
        ${l.caveats ? `<h5>模拟说明</h5><p class="note">${esc(l.caveats)}</p>` : ''}
        ${l.applied ? `<h5>已自动设置</h5><p class="note">${esc(l.applied.ok.join('；') || '无')}${l.applied.miss.length ? `<br>未能设置：${esc(l.applied.miss.join('、'))}` : ''}${(l.convNotes || []).length ? `<br>换算：${esc(l.convNotes.join('；'))}` : ''}</p>` : ''}
        ${!l.module ? '<p class="note">目录中没有能直接模拟这道题的实验，以上为解答。</p>' : ''}
      </div></div>
      <div class="note lsn-status">${l.pending ? '正在配置实验参数…' : ''}</div>`;
    c.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
      const a = b.dataset.a;
      if (a === 'next') l.shown = Math.min(steps.length, l.shown + 1);
      if (a === 'all') l.shown = steps.length;
      if (a === 'ans') l.showAns = !l.showAns;
      if (a === 'hide') { this.lesson = null; c.remove(); return; }
      if (a === 're') { await this.apply(l); }
      const p = c.parentElement; if (p) { p.innerHTML = ''; p.appendChild(this.card(l)); }
    });
    return c;
  }
};

// 挂到应用外壳上
(() => {
  const route = App.route.bind(App), open = App.open.bind(App);
  App.route = function () {
    if (location.hash === '#import') {
      if (this.ctx) { this.ctx.dispose(); this.ctx = null; }
      this.cur = null; this.side(document.getElementById('q').value.trim()); Importer.page(); document.getElementById('view').scrollTop = 0; return;
    }
    route();
  };
  App.open = function (e) { open(e); Importer.afterOpen(e); };
})();
