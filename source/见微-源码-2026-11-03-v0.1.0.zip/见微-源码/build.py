"""见微 · 打包（PyInstaller onedir）+ 桌面快捷方式。

用法：python build.py            # 打包
      python build.py --shortcut # 只重建桌面快捷方式
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
DIST = ROOT / "dist"


def build() -> int:
    for junk in (ROOT / "build", DIST, ROOT / "Jianwei.spec"):
        if junk.is_dir():
            shutil.rmtree(junk, ignore_errors=True)
        elif junk.exists():
            junk.unlink()
    args = [
        sys.executable, "-m", "PyInstaller", "--noconfirm", "--onedir", "--windowed",
        "--name", "Jianwei",
        "--icon", str(APP / "assets" / "icon.ico"),
        "--add-data", f"{APP / 'studio' / 'web'};studio/web",
        "--add-data", f"{APP / 'guanlan'};guanlan",
        "--add-data", f"{APP / 'assets'};assets",
        "--paths", str(APP / "guanlan"),
        "--hidden-import", "core.paths", "--hidden-import", "core.evening",
        "--hidden-import", "core.curator", "--hidden-import", "core.autostart",
        "--collect-submodules", "core", "--collect-submodules", "ui",
        "--noconsole",
        str(APP / "main.py"),
    ]
    print(" ".join(args[:8]), "…")
    return subprocess.call(args, cwd=ROOT)


def shortcut() -> None:
    """桌面快捷方式交给 make_shortcut.py（UTF-16LE VBS，规避 PowerShell 中文编码坑）。"""
    subprocess.call([sys.executable, str(ROOT / "make_shortcut.py")])


if __name__ == "__main__":
    if "--shortcut" in sys.argv:
        shortcut()
    else:
        code = build()
        if code == 0:
            shortcut()
        sys.exit(code)
