"""见微 · 接管脚本：把「观澜浮窗 + 顶部倒计时胶囊 + 暮省 + 每日抓取」全部收到见微名下。

默认只打印计划（dry-run）。真正执行加 --apply，撤销加 --revert。

做的事：
  1. 备份原来的自启项、启动文件夹快捷方式、计划任务
  2. 把观澜今天的 edition 同步进见微的数据目录
  3. 停掉原版 观澜.exe 与 GaokaoCountdown.exe
  4. 删掉原版自启（HKCU Run: GuanlanDailyBrief、启动文件夹 GaokaoCountdown.lnk）
  5. 给见微写自启（HKCU Run: JianweiSuite = Jianwei.exe --background）
  6. 22:20 的任务改由见微承担（禁用 GuanlanEveningReview，新建 JianweiEveningReview）
  7. 启动见微（托盘 + 顶部胶囊 + 侧边浮窗）
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
sys.path.insert(0, str(APP))

import store  # noqa: E402

EXE = ROOT / "dist" / "Jianwei" / "Jianwei.exe"
OLD_TASK = "GuanlanEveningReview"
NEW_TASK = "JianweiEveningReview"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
OLD_RUN = "GuanlanDailyBrief"
NEW_RUN = "JianweiSuite"
STARTUP = Path.home() / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
COUNTDOWN_LNK = STARTUP / "GaokaoCountdown.lnk"
BACKUP = store.HOME / "backup" / datetime.now().strftime("%Y%m%d-%H%M%S")


# ------------------------------------------------------------------ 小工具
def say(msg: str, mark: str = "·") -> None:
    print(f"  {mark} {msg}")


def command_line() -> tuple[list[str], str]:
    """见微的启动命令行（打包版优先）。"""
    if EXE.exists():
        return [str(EXE)], f'"{EXE}"'
    return [sys.executable, str(APP / "main.py")], f'"{sys.executable}" "{APP / "main.py"}"'


RUN_PS = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"


def _ps(cmd: str) -> str:
    """注册表读写走 PowerShell：本机 python 进程写 HKCU Run 会被拒（WinError 5）。"""
    res = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                          "-Command", cmd], capture_output=True, text=True, errors="replace")
    return (res.stdout or "").strip()


def read_run(name: str) -> str | None:
    out = _ps(f'(Get-ItemProperty -Path "{RUN_PS}" -Name {name} -ErrorAction SilentlyContinue).{name}')
    val = out.splitlines()[-1].strip() if out.strip() else ""
    return val or None


def write_run(name: str, value: str | None) -> None:
    if value is None:
        _ps(f'Remove-ItemProperty -Path "{RUN_PS}" -Name {name} -Force -ErrorAction SilentlyContinue')
    else:
        safe = value.replace("'", "''")
        _ps(f'Set-ItemProperty -Path "{RUN_PS}" -Name {name} -Value '{safe}' -Force')


def schtasks(*args: str) -> int:
    cmd = ["schtasks", *args]
    res = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
    return res.returncode


def kill(name: str) -> bool:
    proc = name[:-4] if name.lower().endswith(".exe") else name
    before = _ps(f'@(Get-Process -Name "{proc}" -ErrorAction SilentlyContinue).Count')
    _ps(f'Stop-Process -Name "{proc}" -Force -ErrorAction SilentlyContinue')
    return before.strip() not in ("", "0")


def launch_background() -> None:
    exe, _ = command_line()
    flags = 0x00000008  # DETACHED_PROCESS
    try:
        subprocess.Popen(exe + ["--background"], creationflags=flags,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        say(f"启动失败：{exc}", "!")


# ------------------------------------------------------------------ 备份
def backup() -> None:
    BACKUP.mkdir(parents=True, exist_ok=True)
    state = {
        "old_run": read_run(OLD_RUN),
        "new_run": read_run(NEW_RUN),
        "countdown_lnk": COUNTDOWN_LNK.exists(),
        "old_task_xml": None,
    }
    xml = subprocess.run(["schtasks", "/Query", "/TN", OLD_TASK, "/XML"],
                         capture_output=True, text=True, errors="replace")
    if xml.returncode == 0 and xml.stdout.strip():
        path = BACKUP / f"{OLD_TASK}.xml"
        path.write_text(xml.stdout, encoding="utf-8")
        state["old_task_xml"] = str(path)
    if COUNTDOWN_LNK.exists():
        import shutil
        shutil.copy2(COUNTDOWN_LNK, BACKUP / COUNTDOWN_LNK.name)
    (BACKUP / "state.json").write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    say(f"备份在 {BACKUP}")


# ------------------------------------------------------------------ 执行
def apply() -> int:
    exe, exe_cmd = command_line()
    say(f"见微入口：{exe_cmd}")
    backup()

    if store.sync_from_release():
        say("已把观澜最新一期同步进见微数据目录")
    else:
        say("观澜数据无需同步（见微已是最新）", " ")

    cfg = store.load_config()
    cfg.update({"showPill": True, "showGuanlanOnStart": True, "startMinimized": True,
                "closeToTray": True, "autoFetch": True, "autoEvening": True})
    store.save_config(cfg)
    say("配置：启动即带胶囊与侧边浮窗，关闭到托盘")

    for proc in ("观澜.exe", "GaokaoCountdown.exe"):
        say(f"停止 {proc}：{'已停止' if kill(proc) else '本来没在跑'}")
    write_run(OLD_RUN, None)
    say("已移除原版观澜自启（HKCU Run）")
    if COUNTDOWN_LNK.exists():
        COUNTDOWN_LNK.unlink()
        say("已移除 C# 倒计时开机启动（快捷方式已备份）")
    write_run(NEW_RUN, exe_cmd + " --background")
    say("已写入见微自启（--background）")

    if schtasks("/Change", "/TN", OLD_TASK, "/DISABLE") == 0:
        say(f"已禁用旧任务 {OLD_TASK}")
    code = schtasks("/Create", "/F", "/SC", "DAILY", "/ST", "22:20", "/TN", NEW_TASK,
                    "/TR", exe_cmd + " --evening")
    say(f"22:20 暮省任务 → 见微：{'已创建' if code == 0 else '创建失败'}")

    launch_background()
    say("见微已在后台启动（托盘 + 顶部胶囊 + 侧边浮窗）")
    print("\n接管完成。撤销：python switch_to_jianwei.py --revert")
    return 0


def revert() -> int:
    state_path = None
    for cand in sorted((store.HOME / "backup").glob("*/state.json"), reverse=True):
        state_path = cand
        break
    if state_path is None:
        print("找不到备份，无法撤销")
        return 1
    state = json.loads(state_path.read_text(encoding="utf-8"))
    say(f"使用备份 {state_path.parent}")

    schtasks("/Delete", "/TN", NEW_TASK, "/F")
    schtasks("/Change", "/TN", OLD_TASK, "/ENABLE")
    say("计划任务：删除见微任务、恢复原版任务")

    write_run(NEW_RUN, None)
    if state.get("old_run"):
        write_run(OLD_RUN, state["old_run"])
        say("已恢复观澜自启")
    backup_lnk = state_path.parent / COUNTDOWN_LNK.name
    if backup_lnk.exists():
        import shutil
        shutil.copy2(backup_lnk, COUNTDOWN_LNK)
        say("已恢复 C# 倒计时开机启动")

    kill("Jianwei.exe")
    say("已停止见微")

    release = store.release_root()
    if release and (release / "观澜.exe").exists():
        subprocess.Popen([str(release / "观澜.exe"), "--background"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        say("已重新启动原版观澜")
    countdown = Path.home() / "AppData" / "Local" / "GaokaoCountdown" / "GaokaoCountdown.exe"
    if countdown.exists():
        subprocess.Popen([str(countdown)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        say("已重新启动 C# 倒计时胶囊")
    print("\n已回到接管前状态。")
    return 0


def plan() -> int:
    exe, exe_cmd = command_line()
    print("接管计划（dry-run，真正执行加 --apply）")
    say(f"见微入口：{exe_cmd}")
    say(f"原版自启现值：{read_run(OLD_RUN) or '（无）'}")
    say(f"C# 倒计时自启：{'存在' if COUNTDOWN_LNK.exists() else '（无）'}")
    say(f"旧任务 {OLD_TASK}：" + ("存在" if schtasks("/Query", "/TN", OLD_TASK) == 0 else "（无）"))
    say(f"观澜发行版：{store.release_root() or '（未找到）'}")
    say(f"见微数据：{store.GUANLAN_HOME}（当前 {store.guanlan_date() or '空'}）")
    say("将做：备份 → 同步数据 → 停原版两进程 → 换自启 → 22:20 任务改指向见微 → 后台启动见微")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--revert", action="store_true")
    args = ap.parse_args()
    if args.revert:
        sys.exit(revert())
    if args.apply:
        sys.exit(apply())
    sys.exit(plan())
