"""Visual language for Guanlan: ink, champagne gold, jade, paper."""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QWidget


class C:
    BG_TOP = QColor("#111A24")
    BG_BOTTOM = QColor("#080D13")
    PANEL = QColor("#0C131C")
    PANEL_2 = QColor("#101923")
    CARD = QColor(255, 255, 255, 11)
    CARD_HOVER = QColor(255, 255, 255, 19)
    TEXT = QColor("#F2EDE3")
    TEXT_SOFT = QColor("#D8D2C6")
    MUTED = QColor("#96A0B0")
    DIM = QColor("#697586")
    GOLD = QColor("#C9A86A")
    GOLD_LIGHT = QColor("#E8D4A6")
    GOLD_DIM = QColor(201, 168, 106, 90)
    JADE = QColor("#7FA99C")
    JADE_DIM = QColor(127, 169, 156, 70)
    CORAL = QColor("#D17D67")
    HAIRLINE = QColor(255, 255, 255, 22)
    HAIRLINE_STRONG = QColor(255, 255, 255, 38)
    BLACK = QColor("#05080B")


UI_FAMILIES = ["Noto Sans SC", "Microsoft YaHei UI", "Microsoft YaHei", "DengXian"]
SERIF_FAMILIES = ["SimSun", "Songti SC", "Noto Serif SC", "STSong"]
MONO_FAMILIES = ["Georgia", "Cambria", "Times New Roman"]


def _pick_family(candidates: list[str]) -> str:
    available = set(QFontDatabase.families())
    for family in candidates:
        if family in available:
            return family
    return candidates[-1]


UI_FAMILY = _pick_family(UI_FAMILIES)
SERIF_FAMILY = _pick_family(SERIF_FAMILIES)
MONO_FAMILY = _pick_family(MONO_FAMILIES)


FONT_BUMP = 1


def _pixel_size(size: float) -> int:
    # One extra pixel across the board makes the small Chinese labels much
    # easier to read without breaking the editorial hierarchy.
    return max(1, int(size + 0.5) + FONT_BUMP)


def font(size: float = 13, weight: int = 400, family: str | None = None,
         spacing: float = 0.0, italic: bool = False) -> QFont:
    f = QFont(family or UI_FAMILY)
    f.setPixelSize(_pixel_size(size))
    f.setWeight(QFont.Weight(weight))
    f.setItalic(italic)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    f.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    return f


def serif(size: int = 22, weight: int = 400, spacing: float = 0.0) -> QFont:
    return font(size, weight, SERIF_FAMILY, spacing)


def mono(size: int = 10, weight: int = 400, spacing: float = 0.0) -> QFont:
    return font(size, weight, MONO_FAMILY, spacing)


def shadow(widget: QWidget, blur: int = 34, dy: int = 8, alpha: int = 170) -> QGraphicsDropShadowEffect:
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur)
    effect.setOffset(0, dy)
    effect.setColor(QColor(0, 0, 0, alpha))
    widget.setGraphicsEffect(effect)
    return effect


QSS = """
QWidget { background: transparent; color: #F2EDE3; }
QToolTip {
    background-color: #16212D;
    color: #F2EDE3;
    border: 1px solid rgba(201,168,106,150);
    border-radius: 4px;
    padding: 6px 8px;
    font-size: 12px;
}
QScrollArea { border: none; background: transparent; }
QScrollArea > QWidget > QWidget { background: transparent; }
QScrollBar:vertical {
    background: transparent;
    width: 4px;
    margin: 2px 0;
}
QScrollBar::handle:vertical {
    background: rgba(201,168,106,75);
    min-height: 26px;
    border-radius: 2px;
}
QScrollBar::handle:vertical:hover { background: rgba(201,168,106,130); }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QCheckBox { color: #D8D2C6; font-size: 12px; spacing: 8px; }
QTextBrowser {
    background: transparent;
    border: none;
    color: #D8D2C6;
    selection-background-color: #C9A86A;
    selection-color: #0B1118;
}
"""
