"""The four reading pages: Today, People, Lines, Archive."""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFontMetrics, QPainter, QPen
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QSizePolicy, QStackedWidget, QVBoxLayout, QWidget,
)

from .base import IconButton, TagLabel, TextBlock, TextButton, SectionHeader
from .cards import ArchiveRow, HeroCard, PersonSeal, QuoteCard, StoryCard, TermCard
from .icons import draw_icon
from .theme import C, font, mono, serif
from core.paths import ROOT


def clear_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.deleteLater()
        child = item.layout()
        if child is not None:
            clear_layout(child)


class ScrollPage(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        from PySide6.QtWidgets import QScrollArea
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.content = QWidget()
        self.content.setStyleSheet("background: transparent;")
        self.layout_content = QVBoxLayout(self.content)
        self.layout_content.setContentsMargins(18, 4, 14, 24)
        self.layout_content.setSpacing(13)
        self.scroll.setWidget(self.content)
        outer.addWidget(self.scroll)

    def scroll_top(self) -> None:
        self.scroll.verticalScrollBar().setValue(0)


class EditorialMasthead(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._title = ""
        self._subtitle = ""
        self._eyebrow = ""
        self.setFixedHeight(118)
        self.title = TextBlock("", 20, 600, C.TEXT, 2, 1.38)
        self.title.set_text_font(serif(20, 600, spacing=0.2), 29)
        self.sub = TextBlock("", 9.5, 400, C.MUTED, 2, 1.55)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(3)
        self.eyebrow = QLabel("")
        self.eyebrow.setFont(mono(7.5, 500, spacing=1.0))
        self.eyebrow.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        layout.addWidget(self.eyebrow)
        layout.addWidget(self.title)
        layout.addWidget(self.sub)

    def set_content(self, eyebrow: str, title: str, subtitle: str) -> None:
        self.eyebrow.setText(eyebrow)
        self._title = title
        self._subtitle = subtitle
        self.title.setText(title)
        self.sub.setText(subtitle)


class FilterInvite(QWidget):
    clicked = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(48)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover = False
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 0, 12, 0)
        lay.addStretch(1)

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setBrush(QColor(255, 255, 255, 13 if self._hover else 7))
        p.setPen(QPen(QColor(201, 168, 106, 55 if self._hover else 25), 1))
        p.drawRoundedRect(r, 10, 10)
        draw_icon(p, "spark", QRectF(15, 16, 15, 15), C.GOLD if self._hover else C.GOLD_DIM, 1.2)
        p.setFont(font(9, 400))
        p.setPen(C.MUTED if not self._hover else C.TEXT_SOFT)
        p.drawText(QPointF(39, 28), "编辑部如何筛选？")
        p.setFont(font(8.5, 400))
        p.setPen(C.GOLD_DIM)
        p.drawText(QPointF(143, 28), "查看 6 维标尺")
        draw_icon(p, "arrow_right", QRectF(self.width() - 28, 17, 14, 14), C.GOLD_DIM, 1.1)


class TodayPage(ScrollPage):
    open_story = Signal(dict)
    open_filter = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.edition: dict | None = None

    def set_edition(self, edition: dict | None) -> None:
        self.edition = edition
        clear_layout(self.layout_content)
        if not edition:
            self._empty()
            return
        mast = EditorialMasthead()
        mast.set_content(
            f"DAILY EDITION  /  NO. {edition.get('edition', 1):03d}",
            edition.get("title", ""),
            edition.get("subtitle", ""),
        )
        self.layout_content.addWidget(mast)

        hero = HeroCard(edition.get("lead") or {})
        hero.clicked.connect(lambda: self.open_story.emit(edition.get("lead") or {}))
        self.layout_content.addWidget(hero)

        keywords = QHBoxLayout()
        keywords.setSpacing(5)
        for idx, kw in enumerate(edition.get("keywords", [])[:5]):
            keywords.addWidget(TagLabel(f"# {kw}", "gold" if idx == 0 else ("jade" if idx == 2 else "muted")))
        keywords.addStretch(1)
        self.layout_content.addLayout(keywords)

        self.layout_content.addSpacing(2)
        sections = edition.get("sections") or {}
        order = ["world", "china_world", "tech", "society"]
        idx = 1
        for section in order:
            items = sections.get(section) or []
            if not items:
                continue
            from core.editorial import SECTION_META
            meta = SECTION_META[section]
            head = SectionHeader(meta["label"], meta["en"], len(items))
            self.layout_content.addWidget(head)
            for story in items:
                idx += 1
                card = StoryCard(story, idx)
                card.clicked.connect(self.open_story)
                self.layout_content.addWidget(card)

        self.layout_content.addSpacing(3)
        term = edition.get("term")
        if term:
            self.layout_content.addWidget(TermCard(term))
        invite = FilterInvite()
        invite.clicked.connect(self.open_filter)
        self.layout_content.addWidget(invite)

    def _empty(self) -> None:
        from PySide6.QtWidgets import QLabel
        box = QWidget()
        box.setMinimumHeight(300)
        lay = QVBoxLayout(box)
        lay.setContentsMargins(10, 70, 10, 10)
        title = QLabel("等待今天的筛选")
        title.setFont(serif(24, 500))
        title.setStyleSheet(f"color: {C.TEXT.name()};")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub = QLabel("点击右上角的刷新按钮，或稍候片刻。")
        sub.setFont(font(10))
        sub.setStyleSheet(f"color: {C.MUTED.name()};")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)
        lay.addWidget(sub)
        self.layout_content.addWidget(box)
        self.layout_content.addStretch(1)


class PersonView(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(12)

    def build(self, person: dict, index: int, total: int, on_prev, on_next, on_url) -> None:
        clear_layout(self.layout)
        top = QHBoxLayout()
        over = QLabel(f"TODAY'S PERSON  /  {index + 1:02d} OF {total:02d}")
        over.setFont(mono(7.5, 500, spacing=1.0))
        over.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        top.addWidget(over)
        top.addStretch(1)
        prev = IconButton("chevron_left", "上一位", 25, C.DIM)
        nxt = IconButton("chevron_right", "下一位", 25, C.DIM)
        prev.clicked.connect(on_prev)
        nxt.clicked.connect(on_next)
        top.addWidget(prev)
        top.addWidget(nxt)
        self.layout.addLayout(top)

        ident = QHBoxLayout()
        ident.setSpacing(10)
        left = QVBoxLayout()
        left.setSpacing(1)
        name = QLabel(person.get("name", ""))
        name.setFont(serif(28, 600, spacing=1.0))
        name.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        latin = QLabel(person.get("latin", ""))
        latin.setFont(mono(7.5, 500, spacing=1.2))
        latin.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        role = QLabel(f"{person.get('identity', '')}   ·   {person.get('years', '')}")
        role.setFont(font(9.5))
        role.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        role.setWordWrap(True)
        left.addWidget(name)
        left.addWidget(latin)
        left.addWidget(role)
        ident.addLayout(left, 1)
        seal = PersonSeal(person.get("monogram", ""))
        ident.addWidget(seal, 0, Qt.AlignmentFlag.AlignTop)
        self.layout.addLayout(ident)

        headline = TextBlock(person.get("headline", ""), 13, 500, C.GOLD_LIGHT, 3, 1.55)
        self.layout.addWidget(headline)

        story = QLabel(person.get("story", ""))
        story.setWordWrap(True)
        story.setTextFormat(Qt.TextFormat.RichText)
        story.setText(
            "<p style='line-height:180%; margin:0;'>"
            + (person.get("story", "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>"))
            + "</p>"
        )
        story.setFont(font(11, 400))
        story.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
        story.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.layout.addWidget(story)

        self.layout.addWidget(SectionHeader("三个时刻", "THREE MOMENTS"))
        for moment in person.get("moments", []):
            row = QHBoxLayout()
            row.setSpacing(10)
            year = QLabel(moment.get("year", ""))
            year.setFixedWidth(52)
            year.setFont(mono(9, 500))
            year.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
            txt = TextBlock(moment.get("text", ""), 9.5, 400, C.MUTED, 2, 1.55)
            row.addWidget(year, 0, Qt.AlignmentFlag.AlignTop)
            row.addWidget(txt, 1)
            self.layout.addLayout(row)

        self.layout.addWidget(SectionHeader("可迁移的品质", "WHAT TO CARRY"))
        qualities = person.get("qualities", [])
        qrow = QHBoxLayout()
        qrow.setSpacing(5)
        for q in qualities[:3]:
            tag = TagLabel(q, "jade")
            qrow.addWidget(tag)
        qrow.addStretch(1)
        self.layout.addLayout(qrow)

        essay = QWidget()
        essay.setStyleSheet("background: rgba(255,255,255,0.045); border: 1px solid rgba(201,168,106,0.18); border-radius: 10px;")
        e_lay = QVBoxLayout(essay)
        e_lay.setContentsMargins(13, 10, 13, 11)
        e_lay.setSpacing(4)
        e_title = QLabel("作文可用")
        e_title.setFont(font(8, 600, spacing=0.8))
        e_title.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        e_text = TextBlock(person.get("essay_angle", ""), 9.5, 400, C.MUTED, 3, 1.55)
        e_lay.addWidget(e_title)
        e_lay.addWidget(e_text)
        self.layout.addWidget(essay)

        quote = person.get("quote") or {}
        qbox = QWidget()
        qbox.setStyleSheet("background: transparent; border-left: 2px solid rgba(201,168,106,0.55);")
        qlay = QVBoxLayout(qbox)
        qlay.setContentsMargins(12, 2, 4, 2)
        qlay.setSpacing(4)
        qtext = TextBlock(f"“{quote.get('text', '')}”", 14, 400, C.TEXT, 3, 1.6)
        qtext.set_text_font(serif(14, 400, spacing=0.2), 23)
        qsrc = QLabel(f"—— {quote.get('source', '')}")
        qsrc.setFont(font(8.5))
        qsrc.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        qlay.addWidget(qtext)
        qlay.addWidget(qsrc)
        self.layout.addWidget(qbox)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        change = TextButton("换一位人物", C.GOLD_LIGHT, 9, "refresh")
        read = TextButton("延伸阅读", C.MUTED, 9, "arrow_up_right")
        change.clicked.connect(on_next)
        read.clicked.connect(lambda: on_url(person.get("source_url", "")))
        actions.addWidget(change)
        actions.addWidget(read)
        actions.addStretch(1)
        self.layout.addLayout(actions)
        self.layout.addStretch(1)


class PeoplePage(ScrollPage):
    open_url = Signal(str)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.people: list[dict] = []
        self.index = 0
        self.view = PersonView()
        self.layout_content.addWidget(self.view)
        self.layout_content.addStretch(1)

    def set_edition(self, edition: dict | None) -> None:
        self.people = []
        if edition:
            p = edition.get("person")
            if p:
                self.people.append(p)
            self.people.extend(edition.get("person_alternates") or [])
        self.index = 0
        self._build()

    def _build(self) -> None:
        if not self.people:
            clear_layout(self.view.layout)
            return
        self.view.build(
            self.people[self.index], self.index, len(self.people),
            self._prev, self._next, self.open_url.emit,
        )

    def _prev(self) -> None:
        if self.people:
            self.index = (self.index - 1) % len(self.people)
            self._build()
            self.scroll_top()

    def _next(self) -> None:
        if self.people:
            self.index = (self.index + 1) % len(self.people)
            self._build()
            self.scroll_top()


class QuotesPage(ScrollPage):
    copy_requested = Signal(str)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.edition = None

    def set_edition(self, edition: dict | None) -> None:
        self.edition = edition
        clear_layout(self.layout_content)
        if not edition:
            return
        over = QLabel("DAILY LINES  /  今日三句")
        over.setFont(mono(7.5, 500, spacing=1.0))
        over.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        self.layout_content.addWidget(over)
        title = QLabel("把一句话，带到明天")
        title.setFont(serif(24, 500, spacing=0.5))
        title.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        self.layout_content.addWidget(title)
        sub = TextBlock("好句不是装饰。它把复杂感受压缩成一条可以带走的线，也许正好落在你今天的作文里。", 9.5, 400, C.MUTED, 2, 1.55)
        self.layout_content.addWidget(sub)
        self.layout_content.addSpacing(2)
        for idx, quote in enumerate(edition.get("quotes", []), 1):
            card = QuoteCard(quote, idx)
            card.copy_clicked.connect(self.copy_requested)
            self.layout_content.addWidget(card)
        note = QWidget()
        note.setStyleSheet("background: rgba(201,168,106,0.055); border: 1px solid rgba(201,168,106,0.16); border-radius: 10px;")
        lay = QVBoxLayout(note)
        lay.setContentsMargins(13, 10, 13, 12)
        lay.setSpacing(4)
        t = QLabel("抄写建议")
        t.setFont(font(8, 600, spacing=0.8))
        t.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        body = TextBlock("选一句，用自己的话解释它为什么成立，再举一个今天新闻里的例子。三句话即可，不求长。", 9.5, 400, C.MUTED, 3, 1.55)
        lay.addWidget(t)
        lay.addWidget(body)
        self.layout_content.addWidget(note)


class ArchivePage(ScrollPage):
    open_entry = Signal(dict)
    open_library = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.entries: list[dict] = []
        self.edition = None

    def set_data(self, entries: list[dict], edition: dict | None) -> None:
        self.entries = entries or []
        self.edition = edition
        clear_layout(self.layout_content)
        over = QLabel("ARCHIVE  /  每日档案")
        over.setFont(mono(7.5, 500, spacing=1.0))
        over.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        over.setFixedHeight(14)
        self.layout_content.addWidget(over)
        title = QLabel("时间会筛掉噪音")
        title.setFont(serif(24, 500, spacing=0.5))
        title.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        title.setFixedHeight(36)
        self.layout_content.addWidget(title)
        sub = TextBlock("每一天的新闻都会过去，但看世界的方法会留下来。这里按日期保存每日总览与分栏文档。", 9.5, 400, C.MUTED, 2, 1.55)
        self.layout_content.addWidget(sub)

        stats = QHBoxLayout()
        stats.setSpacing(8)
        for label, value in (("已存档", f"{len(self.entries)} 天"), ("最近更新", self.entries[0]["date"][5:] if self.entries else "—")):
            box = QWidget()
            box.setStyleSheet("background: rgba(255,255,255,0.045); border: 1px solid rgba(255,255,255,0.07); border-radius: 9px;")
            box.setFixedHeight(58)
            bl = QVBoxLayout(box)
            bl.setContentsMargins(11, 7, 11, 7)
            bl.setSpacing(1)
            l1 = QLabel(label)
            l1.setFont(font(8))
            l1.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
            l2 = QLabel(value)
            l2.setFont(mono(15, 500))
            l2.setStyleSheet(f"color: {C.GOLD_LIGHT.name()}; background: transparent;")
            bl.addWidget(l1)
            bl.addWidget(l2)
            stats.addWidget(box, 1)
        open_btn = QWidget()
        open_btn.setFixedSize(58, 58)
        open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        open_btn.setStyleSheet("background: rgba(201,168,106,0.10); border: 1px solid rgba(201,168,106,0.22); border-radius: 9px;")
        ob = QVBoxLayout(open_btn)
        ob.setContentsMargins(0, 7, 0, 5)
        ic = QLabel("▸")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ic.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent; font-size: 14px;")
        tx = QLabel("文件夹")
        tx.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tx.setFont(font(7.5))
        tx.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        ob.addWidget(ic)
        ob.addWidget(tx)
        open_btn.mousePressEvent = lambda e: self.open_library.emit()
        stats.addWidget(open_btn)
        self.layout_content.addLayout(stats)

        self.layout_content.addSpacing(3)
        for entry in self.entries:
            card = ArchiveRow(entry)
            card.clicked.connect(self.open_entry)
            self.layout_content.addWidget(card)
        if not self.entries:
            hint = QLabel("从今天开始，这里会积累你的每日档案。")
            hint.setFont(font(9.5))
            hint.setStyleSheet(f"color: {C.DIM.name()}; background: transparent; padding: 20px 0;")
            hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.layout_content.addWidget(hint)
        self.layout_content.addSpacing(6)
        note = QWidget()
        note.setStyleSheet("background: rgba(201,168,106,0.045); border: 1px solid rgba(201,168,106,0.12); border-radius: 10px;")
        note.setFixedHeight(64)
        nl = QVBoxLayout(note)
        nl.setContentsMargins(13, 9, 13, 9)
        nl.setSpacing(2)
        from core.paths import load_config
        update_time = load_config().get("update_time", "07:15")
        n1 = QLabel(f"每日 {update_time} 自动筛选")
        n1.setFont(font(8.8, 500, spacing=0.3))
        n1.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
        n2 = QLabel("分栏文档 · 人物库 · 金句库 · 格局词典，全部保存在本机")
        n2.setFont(font(8.2))
        n2.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        nl.addWidget(n1)
        nl.addWidget(n2)
        self.layout_content.addWidget(note)
        self.layout_content.addStretch(1)
