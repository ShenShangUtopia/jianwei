"""Build and open the 22:20 full-screen evening review (暮省).

The daily page is assembled from the already-curated edition. No model call is
made here: the templates are static, and the day's JSON is injected into them.
"""
from __future__ import annotations

import base64
import html
import json
import logging
import os
import random
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from datetime import datetime, timedelta
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .paths import ASSET_DIR, DATA_DIR, LATEST_PATH, LOG_DIR, ROOT, ensure_dirs
from .evening_templates import BASE_CSS, PAGE

log = logging.getLogger("guanlan.evening")

EVENING_DIR = ROOT / "晚间暮省"
ARCHIVE_DIR = EVENING_DIR / "archive"
HISTORY_PATH = DATA_DIR / "evening_history.json"
# Edge on this machine does not reliably load --app=file URLs that contain
# non-ASCII directory names. Keep a browser-facing copy under LOCALAPPDATA,
# whose path is ASCII, and keep the readable copy/archive in the project.
RUNTIME_DIR = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "Guanlan" / "evening"
RUNTIME_INDEX = RUNTIME_DIR / "index.html"
RUNTIME_PROFILE = RUNTIME_DIR / "edge-profile"
TEXTURE_DIR = ASSET_DIR / "evening"

THEMES = [
    ("midnight", "深蓝金线"),
    ("rice", "宣纸朱砂"),
    ("jade", "青绿经线"),
    ("amber", "琥珀胶片"),
]

THEME_NAMES = dict(THEMES)

# Four compositions per material. This gives 16 issues before any repeat and
# lets the nightly edition change shape, not only colour.
COVER_LAYOUTS = [
    ("left", "左栏"),
    ("center", "居中"),
    ("offset", "错版"),
    ("stack", "竖题"),
]
COVER_NAMES = dict(COVER_LAYOUTS)


def _setup_logging() -> None:
    ensure_dirs()
    EVENING_DIR.mkdir(parents=True, exist_ok=True)
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    if log.handlers:
        return
    log.setLevel(logging.INFO)
    handler = logging.FileHandler(LOG_DIR / "evening.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    log.addHandler(handler)
    log.propagate = False


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _esc(value) -> str:
    return html.escape(str(value or ""), quote=True)


def _texture_css(theme: str) -> str:
    path = TEXTURE_DIR / f"{theme}.jpg"
    try:
        payload = base64.b64encode(path.read_bytes()).decode("ascii")
    except Exception:
        return ""
    return f'body{{--texture:url("data:image/jpeg;base64,{payload}")}}'


def _clip(text: str, limit: int) -> str:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    for mark in ("。", "！", "？", "；"):
        idx = cut.rfind(mark)
        if idx >= limit * 0.55:
            return cut[: idx + 1]
    return cut.rstrip("，、；： ") + "…"


def _duration(text: str, base: int = 14, cap: int = 28, floor: int = 16) -> int:
    value = base + len(re.sub(r"\s+", "", text or "")) / 55.0
    return int(max(floor, min(cap, value)))


def _issue_number(edition: dict) -> int:
    try:
        return int(datetime.fromisoformat(str(edition.get("date"))).timetuple().tm_yday)
    except Exception:
        try:
            return int(edition.get("edition") or 1)
        except Exception:
            return 1


def _history_by_date(history: list) -> list[dict]:
    by_date: dict[str, dict] = {}
    for item in history:
        if not isinstance(item, dict) or not item.get("date"):
            continue
        theme = str(item.get("theme") or "")
        if theme not in THEME_NAMES:
            continue
        cover = str(item.get("cover") or "left")
        if cover not in COVER_NAMES:
            cover = "left"
        by_date[str(item["date"])] = {
            "date": str(item["date"]),
            "theme": theme,
            "cover": cover,
            "name": THEME_NAMES[theme],
            "cover_name": COVER_NAMES[cover],
            "generated_at": str(item.get("generated_at") or ""),
        }
    return [by_date[key] for key in sorted(by_date)]


def _select_design(
    theme_override: str | None = None,
    cover_override: str | None = None,
    today: str | None = None,
) -> tuple[str, str]:
    """Pick today's material + composition.

    One issue is fixed per date. All 16 material/composition pairs are used
    before any repeat, and the last two materials cannot repeat.
    """
    history = _history_by_date(_read_json(HISTORY_PATH, []))
    today = today or datetime.now().astimezone().date().isoformat()
    if not theme_override and not cover_override:
        for item in reversed(history):
            if item["date"] == today:
                return item["theme"], item["cover"]

    recent = history[-16:]
    used = {f"{item['theme']}:{item['cover']}" for item in recent}
    recent_themes = {item["theme"] for item in recent[-2:]}
    candidates = [
        (theme, cover)
        for theme, _ in THEMES
        for cover, _ in COVER_LAYOUTS
        if f"{theme}:{cover}" not in used and theme not in recent_themes
    ]
    if not candidates:
        candidates = [
            (theme, cover)
            for theme, _ in THEMES
            for cover, _ in COVER_LAYOUTS
            if f"{theme}:{cover}" not in used
        ]
    if not candidates:
        candidates = [(theme, cover) for theme, _ in THEMES for cover, _ in COVER_LAYOUTS]

    if theme_override in THEME_NAMES:
        candidates = [item for item in candidates if item[0] == theme_override] or [
            (theme_override, cover) for cover, _ in COVER_LAYOUTS
        ]
    if cover_override in COVER_NAMES:
        candidates = [item for item in candidates if item[1] == cover_override] or [
            (theme, cover_override) for theme, _ in THEMES
        ]

    theme, cover = random.SystemRandom().choice(candidates)
    if theme_override or cover_override:
        return theme, cover

    history.append({
        "date": today,
        "theme": theme,
        "cover": cover,
        "name": THEME_NAMES[theme],
        "cover_name": COVER_NAMES[cover],
        "design": f"{theme}:{cover}",
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    })
    _atomic_write(HISTORY_PATH, json.dumps(history[-90:], ensure_ascii=False, indent=2))
    return theme, cover


def _ensure_edition() -> dict:
    edition = _read_json(LATEST_PATH, None)
    today = datetime.now().astimezone().date().isoformat()
    edition_date = str(edition.get("date") or "") if isinstance(edition, dict) else ""
    if isinstance(edition, dict) and edition.get("lead"):
        # 版次就是今天，或者比今天还新（系统时钟回拨过）：直接用，不要触发联网刷新。
        if edition_date and edition_date >= today:
            return edition
    # 联网刷新限制在 90 秒内：抓取可能卡住，不能让它把暮省拖死。
    try:
        from .curator import run as curator_run
        log.info("latest edition is not today; force refresh before evening page")
        box = {}

        def _fetch() -> None:
            try:
                box["r"] = curator_run(force=True, log_fn=lambda *_: None)
            except Exception as exc:  # noqa: BLE001
                box["e"] = exc

        worker = threading.Thread(target=_fetch, daemon=True)
        worker.start()
        worker.join(90)
        if worker.is_alive():
            log.warning("evening refresh timed out after 90s; using latest edition")
        elif "e" in box:
            log.exception("evening refresh failed; falling back to latest edition", exc_info=box["e"])
        elif isinstance(box.get("r"), dict):
            refreshed = box["r"].get("edition")
            if isinstance(refreshed, dict) and refreshed.get("lead"):
                return refreshed
    except Exception:
        log.exception("evening refresh failed; falling back to latest edition")
    if isinstance(edition, dict) and edition.get("lead"):
        return edition
    raise RuntimeError("没有可用的今日版数据，无法生成暮省页面。")


def _date_long(edition: dict) -> str:
    raw = str(edition.get("date") or "")
    try:
        dt = datetime.fromisoformat(raw)
        weekday = edition.get("weekday") or "周" + "一二三四五六日"[dt.weekday()]
        return f"{dt.year}年{dt.month}月{dt.day}日 · {weekday}"
    except Exception:
        return str(edition.get("date_label") or raw) + " · " + str(edition.get("weekday") or "")


def _rail(index: int, label: str) -> str:
    return f"""<aside class="slide-rail"><span class="rail-index">{index:02d}</span><span class="rail-label">{_esc(label)}</span></aside>"""


def _meta(story: dict, suffix: str = "") -> str:
    bits = [story.get("source", ""), story.get("published_display", "")]
    text = "  ·  ".join(str(x) for x in bits if x)
    if suffix:
        text += "  ·  " + suffix
    return f'<div class="meta">{_esc(text)}</div>'


def _lead_slide(story: dict, index: int) -> str:
    title = story.get("display_title") or story.get("title") or "今日焦点"
    summary = _clip(story.get("summary") or "", 290)
    question = str(story.get("question") or "").strip()
    qblock = f'<div class="question"><em>留一个问题</em>{_esc(question)}</div>' if question else ""
    return f"""<article class="slide slide-lead active" data-duration="32" data-section="今日焦点">
  {_rail(index, "今日焦点")}
  <div class="slide-body">
    <h2>{_esc(title)}</h2>
    {qblock}
    <p class="summary">{_esc(summary)}</p>
    {_meta(story, str(story.get("read_minutes", 3)) + " 分钟")}
  </div>
</article>"""


def _story_slide(story: dict, index: int) -> str:
    title = story.get("display_title") or story.get("title") or ""
    summary = _clip(story.get("summary") or "", 240)
    section = story.get("section_label") or "世界脉络"
    duration = _duration(summary + title, base=15, cap=26, floor=18)
    tags = []
    if story.get("region"):
        tags.append(str(story["region"]))
    if story.get("lens"):
        tags.append(str(story["lens"]))
    tag_html = "".join(f'<span class="pill">{_esc(tag)}</span>' for tag in tags)
    return f"""<article class="slide slide-story" data-duration="{duration}" data-section="{_esc(section)}">
  {_rail(index, section)}
  <div class="slide-body">
    <div class="story-tags">{tag_html}</div>
    <h2>{_esc(title)}</h2>
    <p class="summary">{_esc(summary)}</p>
    {_meta(story, str(story.get("read_minutes", 2)) + " 分钟")}
  </div>
</article>"""


def _person_slide(person: dict, index: int) -> str:
    name = person.get("name") or "今日人物"
    latin = person.get("latin") or ""
    years = person.get("years") or ""
    identity = person.get("identity") or ""
    headline = person.get("headline") or ""
    story = _clip(person.get("story") or "", 260)
    monogram = person.get("monogram") or name[:1]
    moments = person.get("moments") or []
    moment_html = "".join(
        f'<div class="moment"><b>{_esc(m.get("year"))}</b>{_esc(m.get("text"))}</div>'
        for m in moments[:3] if isinstance(m, dict)
    )
    return f"""<article class="slide slide-person" data-duration="34" data-section="人物">
  {_rail(index, "人物")}
  <div class="slide-body person-layout">
    <div class="person-seal">{_esc(monogram)}</div>
    <div>
      <h2 class="person-name">{_esc(name)}</h2>
      <div class="person-latin">{_esc(latin)}  {_esc(years)}</div>
      <div class="person-identity">{_esc(identity)}</div>
      <div class="person-headline">{_esc(headline)}</div>
      <div class="person-story">{_esc(story)}</div>
      <div class="moments">{moment_html}</div>
    </div>
  </div>
</article>"""


def _people_slide(people: list[dict], index: int) -> str:
    cards = []
    for person in people[:3]:
        if not isinstance(person, dict):
            continue
        name = person.get("name") or "人物"
        latin = person.get("latin") or ""
        years = person.get("years") or ""
        identity = person.get("identity") or ""
        headline = _clip(person.get("headline") or "", 60)
        story = _clip(person.get("story") or "", 132)
        monogram = person.get("monogram") or name[:1]
        quote = person.get("quote") or {}
        quote_text = _clip(quote.get("text") or "", 46) if isinstance(quote, dict) else ""
        quote_html = f'<div class="figure-quote">“{_esc(quote_text)}”</div>' if quote_text else ""
        moments = person.get("moments") or []
        moment = next((m for m in moments if isinstance(m, dict) and m.get("text")), None)
        moment_html = f'<div class="figure-moment"><b>{_esc(moment.get("year"))}</b>{_esc(_clip(moment.get("text") or "", 34))}</div>' if moment else ""
        cards.append(f"""<section class="figure-card">
  <div class="figure-top">
    <div class="figure-seal">{_esc(monogram)}</div>
    <div><div class="figure-name">{_esc(name)}</div><div class="figure-latin">{_esc(latin)} · {_esc(years)}</div></div>
  </div>
  <div class="figure-identity">{_esc(identity)}</div>
  <p class="figure-headline">{_esc(headline)}</p>
  <p class="figure-story">{_esc(story)}</p>
  {moment_html}
  {quote_html}
</section>""")
    return f"""<article class="slide slide-people" data-duration="44" data-section="人物">
  {_rail(index, "人物")}
  <div class="slide-body people-layout">
    <header class="people-head"><h2>今夜三个人</h2><span class="people-sub">三种选择，三条路</span></header>
    <div class="people-grid">{''.join(cards)}</div>
  </div>
</article>"""


def _quotes_slide(quotes: list[dict], index: int) -> str:
    cards = []
    for quote in quotes[:3]:
        if not isinstance(quote, dict):
            continue
        cards.append(f"""<div class="quote-card">
  <blockquote>{_esc(quote.get("text"))}</blockquote>
  <div class="author">—— {_esc(quote.get("author"))}，{_esc(quote.get("source"))}</div>
  <div class="use">{_esc(quote.get("use"))}</div>
</div>""")
    if not cards:
        cards.append('<div class="quote-card"><blockquote>今夜，把一句话留给明天。</blockquote></div>')
    return f"""<article class="slide slide-quotes" data-duration="30" data-section="今日金句">
  {_rail(index, "今日三句")}
  <div class="slide-body">
    <h2>把一句话，带到明天</h2>
    <div class="quote-grid">{''.join(cards)}</div>
  </div>
</article>"""


def _term_slide(term: dict, index: int) -> str:
    return f"""<article class="slide slide-term" data-duration="26" data-section="格局词条">
  {_rail(index, "格局词典")}
  <div class="slide-body term-layout">
    <div>
      <div class="term-word">{_esc(term.get("term"))}</div>
      <div class="term-en">{_esc(term.get("en"))}</div>
      <p class="term-def">{_esc(_clip(term.get("definition") or "", 260))}</p>
    </div>
    <div class="term-side">
      <p><b>为什么值得知道</b>{_esc(_clip(term.get("why") or "", 220))}</p>
      <p><b>高考连接</b>{_esc(_clip(term.get("exam") or "", 220))}</p>
      <p><b>容易误解</b>{_esc(_clip(term.get("misread") or "", 180))}</p>
    </div>
  </div>
</article>"""


def _end_slide(total: int) -> str:
    return f"""<article class="slide slide-end" data-duration="12" data-section="今夜已尽">
  <div class="slide-body">
    <div class="end-mark">今夜已尽</div>
    <div class="end-sub">把世界放回远处，把自己还给自己。</div>
    <div class="end-hint">右上角退出  ·  空格暂停  ·  ← → 翻页</div>
  </div>
</article>"""


def build_html(edition: dict, theme: str, cover: str = "left") -> str:
    if theme not in THEME_NAMES:
        theme = "midnight"
    if cover not in COVER_NAMES:
        cover = "left"
    lead = edition.get("lead") or {}
    stories = [s for s in edition.get("stories") or [] if isinstance(s, dict)]
    person = edition.get("person") or {}
    alternates = [p for p in edition.get("person_alternates") or [] if isinstance(p, dict)]
    quotes = edition.get("quotes") or []
    term = edition.get("term") or {}

    slides = [_lead_slide(lead, 1)]
    index = 2
    for story in stories[:6]:
        slides.append(_story_slide(story, index))
        index += 1
    people = []
    seen = set()
    for candidate in [person, *alternates]:
        if not isinstance(candidate, dict) or not candidate.get("name"):
            continue
        key = str(candidate.get("id") or candidate.get("name"))
        if key in seen:
            continue
        seen.add(key)
        people.append(candidate)
    if len(people) >= 2:
        slides.append(_people_slide(people, index)); index += 1
    elif person:
        slides.append(_person_slide(person, index)); index += 1
    slides.append(_quotes_slide(quotes, index)); index += 1
    if term:
        slides.append(_term_slide(term, index)); index += 1
    slides.append(_end_slide(len(slides)))

    date_long = _date_long(edition)
    date_short = str(edition.get("date_label") or edition.get("date") or "").replace(".", ".")
    title = f"暮省 · {date_short}"
    count = int(edition.get("read_count") or len(stories) + 1)
    minutes = int(edition.get("reading_minutes") or 15)
    total = len(slides)
    doc = PAGE
    replacements = {
        "__TITLE__": _esc(title),
        "__CSS__": BASE_CSS,
        "__TEXTURE_CSS__": _texture_css(theme),
        "__THEME__": _esc(theme),
        "__COVER__": _esc(cover),
        "__ISSUE__": f"{_issue_number(edition):03d}",
        "__EDITION__": f"{int(edition.get('edition') or 1):03d}",
        "__DATE_LONG__": _esc(date_long),
        "__DATE_SHORT__": _esc(date_short + "  " + str(edition.get("weekday") or "")),
        "__COUNT__": str(count),
        "__MINUTES__": str(minutes),
        "__TOTAL__": f"{total:02d}",
        "__SLIDES__": "\n".join(slides),
    }
    for key, value in replacements.items():
        doc = doc.replace(key, value)
    return doc


def _browser_candidates() -> list[Path]:
    return [
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
    ]


class _EveningHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(RUNTIME_DIR), **kwargs)

    def log_message(self, fmt, *args):
        return

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.send_header("Pragma", "no-cache")
        super().end_headers()

    def do_POST(self):
        if self.path.split("?", 1)[0] == "/exit":
            event = getattr(self.server, "exit_event", None)
            if event is not None:
                event.set()
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        self.send_error(404)


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def serve(port: int, root: str, timeout: int = 8 * 3600) -> int:
    """Standalone quiet static server used by --evening-serve."""
    class _Quiet(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=root, **kwargs)

        def log_message(self, fmt, *args):
            return

        def end_headers(self):
            self.send_header("Cache-Control", "no-store, max-age=0")
            super().end_headers()

    server = ThreadingHTTPServer(("127.0.0.1", port), _Quiet)
    timer = threading.Timer(max(30, timeout), server.shutdown)
    timer.daemon = True
    timer.start()
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


def _dpi_aware() -> None:
    """让本进程拿到物理像素，窗口铺设才不会按 125% 缩放出错。"""
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass


def _process_tree(root_pid: int, depth: int = 3) -> set[int]:
    """root_pid 及其后代（用 Toolhelp 快照，比每次起 PowerShell 快得多）。"""
    pids = {root_pid}
    if os.name != "nt":
        return pids
    import ctypes
    from ctypes import wintypes

    TH32CS_SNAPPROCESS = 0x00000002

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_void_p),
            ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD), ("szExeFile", wintypes.WCHAR * 260),
        ]

    k32 = ctypes.windll.kernel32
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap == -1:
        return pids
    children = {}
    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        ok = k32.Process32FirstW(snap, ctypes.byref(entry))
        while ok:
            children.setdefault(int(entry.th32ParentProcessID), []).append(int(entry.th32ProcessID))
            ok = k32.Process32NextW(snap, ctypes.byref(entry))
    finally:
        k32.CloseHandle(snap)
    frontier = [root_pid]
    for _ in range(max(1, depth)):
        nxt = []
        for pid in frontier:
            for child in children.get(pid, []):
                if child not in pids:
                    pids.add(child)
                    nxt.append(child)
        frontier = nxt
    return pids


def _top_window(pid: int) -> int:
    """该进程树里面积最大的可见顶层窗口。"""
    if os.name != "nt" or not pid:
        return 0
    import ctypes
    from ctypes import wintypes
    _dpi_aware()
    user32 = ctypes.windll.user32
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    pids = _process_tree(pid)
    best = [0, 0]

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, _lparam):
        wp = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(wp))
        if wp.value not in pids or not user32.IsWindowVisible(hwnd):
            return True
        rc = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rc))
        area = max(0, rc.right - rc.left) * max(0, rc.bottom - rc.top)
        if area > best[1]:
            best[0], best[1] = hwnd, area
        return True

    user32.EnumWindows(_cb, 0)
    return best[0]


def _window_title(hwnd: int) -> str:
    if os.name != "nt" or not hwnd:
        return ""
    import ctypes
    buf = ctypes.create_unicode_buffer(512)
    ctypes.windll.user32.GetWindowTextW(hwnd, buf, 512)
    return buf.value


def _screen_metrics() -> tuple[int, int]:
    """物理屏幕尺寸（主屏）。"""
    if os.name != "nt":
        return 0, 0
    import ctypes
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    u = ctypes.windll.user32
    return int(u.GetSystemMetrics(0)), int(u.GetSystemMetrics(1))


def _dpi_meta(hwnd: int) -> tuple[int, int]:
    """返回 (窗口 DPI, 进程 DPI 感知级别)。级别：0 不感知 / 1 系统 / 2 每显示器。"""
    if os.name != "nt":
        return 96, 2
    import ctypes
    u = ctypes.windll.user32
    dpi = 96
    aware = -1
    try:
        dpi = int(u.GetDpiForWindow(hwnd)) or 96
    except Exception:
        pass
    try:
        ctx = u.GetThreadDpiAwarenessContext()
        aware = int(u.GetAwarenessFromDpiAwarenessContext(ctx))
    except Exception:
        pass
    return dpi, aware


def _window_rect(hwnd: int) -> tuple[int, int, int, int]:
    import ctypes
    from ctypes import wintypes
    rc = wintypes.RECT()
    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rc))
    return rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top


def _fit_window(hwnd: int, topmost: bool = True) -> bool:
    """把窗口铺满屏幕：按物理屏尺寸，铺完读回校验，不够就按差值再铺一次。"""
    if os.name != "nt" or not hwnd:
        return False
    import ctypes
    from ctypes import wintypes
    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    u = ctypes.windll.user32

    sw, sh = _screen_metrics()
    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]
    mw = mh = 0
    mx = my = 0
    try:
        hmon = u.MonitorFromWindow(hwnd, 2)
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        if hmon and u.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            mx, my = mi.rcMonitor.left, mi.rcMonitor.top
            mw = mi.rcMonitor.right - mi.rcMonitor.left
            mh = mi.rcMonitor.bottom - mi.rcMonitor.top
    except Exception:
        pass

    # 监视器矩形和主屏物理尺寸取大的那个（DPI 不感知时前者会被缩小）
    tx, ty, tw, th = (mx, my, mw, mh) if mw * mh >= sw * sh else (0, 0, sw, sh)
    if tw <= 0 or th <= 0:
        return False
    dpi, aware = _dpi_meta(hwnd)
    before = _window_rect(hwnd)
    target_area = max(1, tw * th)
    before_area = max(0, before[2]) * max(0, before[3])
    if before_area >= target_area * 0.99:
        log.info("evening fit skipped: window already %s (target %sx%s)", before, tw, th)
        return True
    log.info("evening fit: screen=%sx%s monitor=%s,%s %sx%s target=%s,%s %sx%s window=%s dpi=%s aware=%s",
             sw, sh, mx, my, mw, mh, tx, ty, tw, th, before, dpi, aware)

    GWL_STYLE = -16
    WS_POPUP, WS_VISIBLE, WS_CLIPSIBLINGS = 0x80000000, 0x10000000, 0x04000000
    SWP_FRAMECHANGED, SWP_SHOWWINDOW, SWP_NOOWNERZORDER = 0x0020, 0x0040, 0x0200
    HWND_TOPMOST = -1
    u.SetWindowLongW(hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE | WS_CLIPSIBLINGS)

    ok = False
    for attempt in range(3):
        u.SetWindowPos(hwnd, HWND_TOPMOST if topmost else 0, tx, ty, tw, th,
                       SWP_FRAMECHANGED | SWP_SHOWWINDOW | SWP_NOOWNERZORDER)
        u.ShowWindow(hwnd, 5)  # SW_SHOW
        time.sleep(0.35)
        cur = _window_rect(hwnd)
        log.info("evening fit attempt %s -> %s (want %s,%s %sx%s)", attempt + 1, cur, tx, ty, tw, th)
        if abs(cur[2] - tw) <= 2 and abs(cur[3] - th) <= 2 and abs(cur[0] - tx) <= 2 and abs(cur[1] - ty) <= 2:
            ok = True
            break
        # 差值纠正：窗口被系统按缩放比缩小了，就按比例放大目标尺寸
        if cur[2] > 40 and cur[3] > 40:
            ratio = max(tw / cur[2], th / cur[3])
            if 1.05 < ratio < 2.2:
                tw, th = int(round(tw * ratio)), int(round(th * ratio))
                tx = max(0, tx - (tw - (u.GetSystemMetrics(0) or tw)) // 2)
                ty = max(0, ty - (th - (u.GetSystemMetrics(1) or th)) // 2)
                log.info("evening fit retarget -> %s,%s %sx%s (ratio %.3f)", tx, ty, tw, th, ratio)
    final = _window_rect(hwnd)
    if not ok and before_area > final[2] * final[3] * 1.02:
        # 铺满反而更小：退回原尺寸，避免“只覆盖左上角”
        u.SetWindowPos(hwnd, HWND_TOPMOST if topmost else 0, before[0], before[1], before[2], before[3],
                       SWP_FRAMECHANGED | SWP_SHOWWINDOW | SWP_NOOWNERZORDER)
        log.info("evening fit reverted to %s", before)
        final = before
    if ok:
        u.SetForegroundWindow(hwnd)
    log.info("evening fit done ok=%s final=%s", ok, final)
    return ok


def _spawn_edge(browser: Path, uri: str, profile: Path, mode: str) -> int:
    """起一个 Edge 窗口，返回 pid；窗口由调用方等待并校验。"""
    common = [
        "--no-first-run", "--no-default-browser-check",
        f"--user-data-dir={profile}",
        "--disable-features=msEdgeFirstRunExperience",
        "--disable-session-crashed-bubble", "--hide-crash-restore-bubble",
        # 本机页面不走系统代理：很多机器开着 Clash 之类的 127.0.0.1 代理，
        # 新 profile 的 Edge 会把 http://127.0.0.1 也送进代理，结果是白页。
        "--no-proxy-server",
    ]
    if mode == "app":
        # app 窗口没有地址栏；--kiosk 会把 URL 当自己的参数吞掉，导致空白页
        args = [f"--app={uri}", "--window-size=1920,1080", "--window-position=0,0"] + common
    else:
        args = ["--kiosk", uri, "--start-fullscreen"] + common
    pid_path = RUNTIME_DIR / f"edge-{mode}.pid"
    err_path = RUNTIME_DIR / f"edge-{mode}.err"
    out_path = RUNTIME_DIR / f"edge-{mode}.out"
    try:
        pid_path.unlink(missing_ok=True)
    except Exception:
        pass
    ps_args = ",".join("'" + a.replace("'", "''") + "'" for a in args)
    ps = (
        "$ErrorActionPreference = 'Stop'\n"
        f"$edge = '{browser}'\n"
        f"$p = Start-Process -FilePath $edge -ArgumentList @({ps_args}) -PassThru "
        f"-RedirectStandardError '{err_path}' -RedirectStandardOutput '{out_path}'\n"
        f"Set-Content -LiteralPath '{pid_path}' -Value $p.Id -Encoding ascii\n"
        "try { $p.WaitForExit() } catch {}\n"
    )
    launcher_path = RUNTIME_DIR / f"launch-{mode}.ps1"
    _atomic_write(launcher_path, ps)
    proc = subprocess.Popen(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
         "-File", str(launcher_path)],
        cwd=str(ROOT), close_fds=True,
        creationflags=0x08000000 if os.name == "nt" else 0,
    )
    pid = 0
    for _ in range(60):
        if pid_path.exists():
            try:
                pid = int(pid_path.read_text(encoding="ascii").strip())
                break
            except Exception:
                pass
        if proc.poll() is not None:
            break
        time.sleep(0.1)
    return pid


def _pid_exe(pid: int) -> str:
    if os.name != "nt" or not pid:
        return ""
    import ctypes
    from ctypes import wintypes
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(512)
        size = wintypes.DWORD(512)
        if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value.lower()
        return ""
    finally:
        k32.CloseHandle(h)


def _find_titled_window(pattern: str) -> tuple[int, int]:
    """全桌面按标题正则找窗口，返回 (hwnd, pid)。

    只认 Edge 的窗口：这台机器上 WPS 之类也可能有带“暮省”的标题，
    误认会把别人的窗口铺满（甚至关掉）。
    """
    if os.name != "nt" or not pattern:
        return 0, 0
    import ctypes
    import re as _re
    from ctypes import wintypes
    _dpi_aware()
    user32 = ctypes.windll.user32
    rx = _re.compile(pattern)
    found = [0, 0]

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, _lparam):
        if found[0] or not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        if not rx.search(buf.value):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if "msedge" not in _pid_exe(pid.value):
            return True
        found[0], found[1] = hwnd, pid.value
        return False

    user32.EnumWindows(_cb, 0)
    return found[0], found[1]


def _wait_titled_window(pattern: str, timeout: float = 20.0) -> tuple[int, int]:
    deadline = time.time() + timeout
    while time.time() < deadline:
        hwnd, pid = _find_titled_window(pattern)
        if hwnd:
            return hwnd, pid
        time.sleep(0.4)
    return 0, 0


def _page_ready(hwnd: int, timeout: float = 6.0) -> bool:
    """标题里出现「暮省」才算真的画出了页面（空白页标题是“无标题”）。"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if "暮省" in _window_title(hwnd):
            return True
        time.sleep(0.3)
    return False


def _kill(pid: int) -> None:
    if not pid:
        return
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=10)
    except Exception:
        pass



def _kill_background_edge() -> int:
    """关掉没有窗口的后台 Edge 进程。

    这类进程（命令行带 --no-startup-window）会接管新的启动请求，
    结果 URL 被塞进一个不存在的窗口里，用户什么也看不到。
    """
    if os.name != "nt":
        return 0
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='msedge.exe'\" | "
          "Where-Object { $_.CommandLine -like '*--no-startup-window*' } | "
          "ForEach-Object { taskkill /PID $_.ProcessId /T /F | Out-Null; $_.ProcessId }")
    try:
        raw = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                             capture_output=True, text=True, timeout=20,
                             creationflags=0x08000000)
        n = len([x for x in raw.stdout.split() if x.strip().isdigit()])
        if n:
            log.info("evening: closed %s background edge process(es)", n)
        return n
    except Exception:
        return 0


def _best_effort_fit(pid: int) -> None:
    """窗口铺满只做“加分项”：找到了就铺，找不到就算了，绝不杀进程。"""
    try:
        hwnd, _win_pid = _wait_titled_window(r"暮省\s*·\s*\d{4}", timeout=20.0)
        if not hwnd:
            log.info("evening window not found for fit (kiosk keeps its own layout)")
            return
        _fit_window(hwnd, topmost=True)
        # Edge 有时建好窗后再调一次尺寸，隔两秒再校验一次（已铺满会自动跳过）
        time.sleep(2.0)
        if _window_title(hwnd):
            _fit_window(hwnd, topmost=True)
        log.info("evening window fitted: %r", _window_title(hwnd))
    except Exception:
        log.exception("evening fit failed (ignored)")


def _port_ready(uri: str, timeout: float = 12.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(uri, timeout=0.6) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.15)
    return False


def open_fullscreen(index_path: Path) -> bool:
    """按旧观澜验证过的做法打开暮省（单独 http 服务 + Edge kiosk）。

    历史坑（观澜 HANDOFF §5.6）：
    - file:// 在 kiosk 下是白页，必须走本地 HTTP；
    - GPU 必须关（三个参数），否则复杂纹理白屏；
    - profile 用 C:\Temp\guanlan-evening-*，不污染用户配置；
    - 启动后要重试 AppActivate，否则全屏窗可能被别的窗口盖住；
    - 退出靠页面 window.close()。
    """
    del index_path
    port = _free_port()
    for candidate in range(8899, 8910):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                probe.bind(("127.0.0.1", candidate))
            port = candidate
            break
        except OSError:
            continue
    uri = f"http://127.0.0.1:{port}/index.html"
    browser = next((b for b in _browser_candidates() if b.exists()), None)
    if browser is None:
        webbrowser.open(uri)
        return False

    _kill_background_edge()
    # 1) 单独的服务进程（和旧 play.ps1 等价：python -m http.server）
    server = None
    try:
        server = subprocess.Popen(
            [sys.executable, "--evening-serve", str(port)],
            cwd=str(ROOT),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=0x08000000 if os.name == "nt" else 0,
        )
    except Exception:
        log.exception("evening server process failed to start")

    if not _port_ready(uri):
        log.error("evening http server not ready on port %s", port)
        try:
            if server:
                server.terminate()
        except Exception:
            pass
        webbrowser.open(uri)
        return False
    log.info("evening server ready at %s", uri)

    launcher = None
    edge_pid = 0
    try:
        profile = Path(r"C:\Temp") / f"guanlan-evening-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        pid_path = RUNTIME_DIR / "edge.pid"
        try:
            pid_path.unlink(missing_ok=True)
        except Exception:
            pass
        launcher_path = RUNTIME_DIR / "play.ps1"
        err_path = RUNTIME_DIR / "edge.err"
        diag_path = RUNTIME_DIR / "kiosk-diag.txt"
        ps = f"""$ErrorActionPreference = 'Continue'
$edge = '{browser}'
$diag = '{diag_path}'
'session=' + [System.Diagnostics.Process]::GetCurrentProcess().SessionId | Out-File -LiteralPath $diag -Encoding utf8
$ea = @('--kiosk','{uri}','--no-first-run','--no-default-browser-check','--user-data-dir={profile}','--disable-features=msEdgeFirstRunExperience','--disable-gpu','--disable-gpu-compositing','--disable-software-rasterizer','--no-sandbox')
$p = $null
try {{
  $p = Start-Process -FilePath $edge -ArgumentList $ea -PassThru -RedirectStandardError '{err_path}'
}} catch {{ ('startprocess_err=' + $_.Exception.Message) | Out-File -LiteralPath $diag -Append -Encoding utf8 }}
if (-not $p) {{
  try {{ $p = Start-Process -FilePath $edge -ArgumentList $ea -PassThru }} catch {{ ('startprocess_retry_err=' + $_.Exception.Message) | Out-File -LiteralPath $diag -Append -Encoding utf8 }}
}}
if ($p) {{
  Set-Content -LiteralPath '{pid_path}' -Value $p.Id -Encoding ascii
  for ($i = 0; $i -lt 12; $i++) {{
    Start-Sleep -Milliseconds 400
    try {{ $ws = New-Object -ComObject WScript.Shell; $ws.AppActivate($p.Id) | Out-Null }} catch {{}}
  }}
  $p.WaitForExit()
  ('exit=' + $p.ExitCode) | Out-File -LiteralPath $diag -Append -Encoding utf8
}} else {{
  'edge_not_started' | Out-File -LiteralPath $diag -Append -Encoding utf8
}}
"""
        _atomic_write(launcher_path, ps)
        launcher = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
             "-File", str(launcher_path)],
            cwd=str(ROOT), close_fds=True,
            creationflags=0x08000000 if os.name == "nt" else 0,
        )
        for _ in range(80):
            if pid_path.exists():
                try:
                    edge_pid = int(pid_path.read_text(encoding="ascii").strip())
                    break
                except Exception:
                    pass
            if launcher.poll() is not None:
                break
            time.sleep(0.1)
        log.info("evening kiosk launcher pid=%s edge_pid=%s url=%s", launcher.pid, edge_pid, uri)

        # 窗口出现才算成功；20 秒还没窗口就收摊，交给上层（静态页播放器）兜底。
        hwnd = 0
        for _ in range(50):
            hwnd, _win_pid = _find_titled_window(r"暮省\s*·\s*\d{4}")
            if hwnd:
                break
            if launcher.poll() is not None:
                break
            time.sleep(0.4)
        if not hwnd:
            log.warning("evening kiosk produced no window in 20s; falling back")
            return False
        log.info("evening window ready: %r", _window_title(hwnd))
        try:
            launcher.wait()
        except Exception:
            pass
        log.info("evening kiosk exited (page closed or user quit)")
        return True
    except Exception:
        log.exception("evening kiosk failed")
        return False
    finally:
        try:
            if server:
                server.terminate()
                server.wait(timeout=4)
        except Exception:
            pass


_LOCK_HANDLE = None


def _acquire_lock() -> bool:
    """同一时刻只允许一个暮省实例（内部定时 + 计划任务可能同时触发）。"""
    global _LOCK_HANDLE
    if os.name != "nt":
        return True
    try:
        import msvcrt
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        fh = open(RUNTIME_DIR / "evening.lock", "a+")
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        fh.seek(0)
        fh.truncate()
        fh.write(str(os.getpid()))
        fh.flush()
        _LOCK_HANDLE = fh
        return True
    except Exception:
        return False


def run(open_browser: bool = True, theme: str | None = None, cover: str | None = None) -> int:
    _setup_logging()
    if not _acquire_lock():
        log.info("another evening instance is running; skip this trigger")
        return 0
    try:
        edition = _ensure_edition()
        selected, selected_cover = _select_design(theme, cover)
        document = build_html(edition, selected, selected_cover)
        index_path = EVENING_DIR / "index.html"
        _atomic_write(index_path, document)
        _atomic_write(RUNTIME_INDEX, document)
        archive_path = ARCHIVE_DIR / f"{edition.get('date', 'undated')}.html"
        _atomic_write(archive_path, document)
        log.info("evening page built theme=%s cover=%s issue=%s date=%s file=%s runtime=%s", selected, selected_cover, _issue_number(edition), edition.get("date"), index_path, RUNTIME_INDEX)
        if open_browser and not open_fullscreen(RUNTIME_INDEX):
            return 3
        return 0
    except Exception:
        log.exception("evening page failed")
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
