"""Static HTML/CSS/JS assets for the 22:20 evening review page."""
from __future__ import annotations

BASE_CSS = r"""
:root {
  --serif: "Source Han Serif SC", "Noto Serif SC", "Songti SC", "STSong", "SimSun", serif;
  --sans: "Noto Sans SC", "Microsoft YaHei UI", "Microsoft YaHei", "DengXian", sans-serif;
  --mono: "Georgia", "Times New Roman", serif;
  --bg: #07111d;
  --bg2: #0d1b2a;
  --ink: #f2ecdf;
  --soft: #d8d0c1;
  --muted: #95a3b3;
  --dim: #647386;
  --accent: #c9a86a;
  --accent2: #e8d4a6;
  --line: rgba(201,168,106,.22);
  --card: rgba(255,255,255,.035);
  --shadow: 0 30px 100px rgba(0,0,0,.45);
}
* { box-sizing: border-box; }
html, body { width:100%; height:100%; margin:0; overflow:hidden; }
body {
  background: var(--bg);
  color: var(--ink);
  font-family: var(--sans);
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}
button { font: inherit; }
[hidden] { display:none !important; }
.exit-btn {
  position:fixed; top:clamp(12px,1.5vw,20px); right:clamp(12px,1.5vw,20px);
  z-index:300; padding:7px 12px; border-radius:999px;
  border:1px solid var(--line); background:rgba(8,14,22,.38);
  color:var(--soft); font-family:var(--sans); font-size:clamp(10px,.72vw,11px);
  letter-spacing:.18em; cursor:pointer; opacity:.88; backdrop-filter:blur(8px);
  transition:opacity .25s ease, border-color .25s ease, color .25s ease, background .25s ease;
}
.exit-btn:hover, .exit-btn:focus-visible { opacity:1; color:var(--ink); border-color:var(--accent); background:rgba(8,14,22,.78); outline:none; }
body[data-theme="rice"] .exit-btn { background:rgba(214,201,180,.94); color:#332e26; border-color:rgba(80,60,40,.3); }
body[data-theme="rice"] .exit-btn:hover, body[data-theme="rice"] .exit-btn:focus-visible { color:#211e19; background:#e0d4c0; }
@media (max-width:900px) { .cover-hud, .hud { padding-right:94px; } .exit-btn { padding:7px 10px; } }
::selection { background: rgba(201,168,106,.25); }

/* ---------- shared cover ---------- */
.cover {
  position: fixed; inset: 0; z-index: 20;
  display: grid; grid-template-rows: auto 1fr auto;
  padding: clamp(26px, 4.2vw, 66px) clamp(30px, 6vw, 112px) clamp(24px, 3.2vw, 48px);
  background:
    radial-gradient(900px 620px at 18% 10%, rgba(201,168,106,.10), transparent 62%),
    radial-gradient(800px 700px at 88% 84%, rgba(92,132,148,.12), transparent 60%),
    linear-gradient(135deg, var(--bg), var(--bg2) 58%, var(--bg));
  transition: opacity .9s ease, transform 1.2s cubic-bezier(.2,.7,.2,1);
}
.cover::before {
  content:""; position:absolute; inset:0; pointer-events:none;
  background-image: linear-gradient(rgba(255,255,255,.018) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(255,255,255,.014) 1px, transparent 1px);
  background-size: 72px 72px;
  mask-image: radial-gradient(ellipse at center, #000 15%, transparent 78%);
}
.cover.gone { opacity:0; transform: scale(1.025); pointer-events:none; }
.cover-hud, .cover-foot {
  position: relative; z-index:2; padding-right: 108px;
  display:flex; align-items:center; justify-content:space-between;
  gap:20px; color: var(--muted);
  font-family: var(--mono); font-size: clamp(10px, .78vw, 13px);
  letter-spacing: .18em; text-transform: uppercase;
}
.cover-hud .brand { color: var(--accent); letter-spacing: .26em; }
.cover-main {
  position:relative; z-index:2; align-self:center;
  width:min(1180px, 92vw);
  display:flex; flex-direction:column; align-items:flex-start;
  animation: coverIn 1.15s ease both;
}
@keyframes coverIn { from { opacity:0; } to { opacity:1; } }
@keyframes markIn {
  from { opacity:0; transform:translateY(18px); }
  to { opacity:1; transform:none; }
}
@keyframes lineIn {
  from { transform:scaleX(0); }
  to { transform:scaleX(1); }
}
.cover-eyebrow {
  color: var(--accent); font-family: var(--sans);
  font-size: clamp(10px, .78vw, 13px); letter-spacing: .52em;
  margin-bottom: clamp(28px, 4vw, 58px);
}
.cover-kicker {
  color: var(--soft); font-family: var(--serif);
  font-size: clamp(15px, 1.2vw, 20px); letter-spacing: .18em;
  margin-bottom: clamp(30px, 3.4vw, 54px);
}
.cover-mark {
  margin:0; font-family: var(--serif); font-weight:500;
  font-size: clamp(132px, 21vw, 300px); line-height:.82;
  letter-spacing:.02em; color: var(--ink);
  display:flex; gap: .045em; align-items:baseline;
  text-shadow: 0 18px 70px rgba(0,0,0,.28);
  animation: markIn 1.5s .08s cubic-bezier(.2,.7,.2,1) both;
}
.cover-mark span { display:block; }
.cover-date {
  margin-top: clamp(22px, 2.2vw, 32px);
  font-family: var(--serif); font-size: clamp(23px, 2.3vw, 38px);
  color: var(--accent2); letter-spacing:.08em;
}
.cover-line {
  width: clamp(100px, 10vw, 170px); height:1px; margin: clamp(20px,2.2vw,30px) 0;
  background: linear-gradient(90deg, var(--accent), transparent);
  transform-origin:var(--line-origin,left);
  animation: lineIn 1.2s .38s cubic-bezier(.2,.7,.2,1) both;
}
.cover-meta {
  color: var(--muted); font-family: var(--mono);
  font-size: clamp(11px,.95vw,15px); letter-spacing:.18em;
}
.cover-foot { color: var(--dim); }
#countdown { color: var(--accent2); font-variant-numeric: tabular-nums; letter-spacing:.2em; }
.countdown-wrap { display:inline-flex; align-items:baseline; gap:8px; }
.countdown-label { color:var(--dim); font-size:.82em; letter-spacing:.16em; }
.cover-progress {
  position:absolute; left:0; right:0; bottom:0; height:2px;
  background: rgba(255,255,255,.05);
}
.cover-progress i {
  display:block; width:0%; height:100%;
  background: linear-gradient(90deg, var(--accent), var(--accent2));
}

/* ---------- deck ---------- */
.deck {
  position:fixed; inset:0; z-index:10;
  display:grid; grid-template-rows:auto 1fr auto;
  padding: clamp(22px, 3vw, 46px) clamp(28px, 5vw, 88px) clamp(18px, 2.4vw, 34px);
  background:
    radial-gradient(1000px 700px at 82% 16%, rgba(201,168,106,.07), transparent 64%),
    linear-gradient(140deg, var(--bg), var(--bg2));
  opacity:0; animation: deckIn .9s ease forwards;
}
body.preview .deck { opacity:1; animation:none; }
body.preview .controls { display:none !important; }
@keyframes deckIn { to { opacity:1; } }
.hud {
  display:flex; align-items:center; justify-content:space-between;
  padding-right: 108px; padding-bottom: clamp(12px,1.4vw,20px);
  border-bottom:1px solid var(--line);
  color: var(--muted); font-family: var(--mono);
  font-size: clamp(11px,.86vw,14px); letter-spacing:.14em;
  text-transform: uppercase;
}
.hud-brand { display:flex; align-items:baseline; gap:18px; }
.brand-mark { color:var(--accent); font-family:var(--serif); font-size:clamp(17px,1.5vw,23px); letter-spacing:.22em; }
.hud-date { color:var(--muted); }
.hud-meta { display:flex; align-items:center; gap:24px; }
#hudSection { color:var(--accent2); }
.hud-issue { color:var(--dim); letter-spacing:.12em; }
#hudCount { color:var(--dim); font-variant-numeric: tabular-nums; }

.slides { position:relative; min-height:0; }
.slide {
  position:absolute; inset:0;
  display:grid; grid-template-columns: minmax(80px,.23fr) minmax(0,1fr);
  gap: clamp(30px, 5vw, 88px);
  align-items:center;
  padding: clamp(26px, 4vw, 64px) 0;
  opacity:0; visibility:hidden; transform:translateY(28px);
  transition: opacity .65s ease, transform .8s cubic-bezier(.2,.7,.2,1), visibility .65s;
}
.slide.active { opacity:1; visibility:visible; transform:none; }
.slide-rail {
  align-self:stretch; display:flex; flex-direction:column; justify-content:space-between;
  padding: clamp(8px,1.4vw,20px) clamp(16px,2vw,28px) clamp(8px,1.4vw,20px) 0;
  border-right:1px solid var(--line);
  font-family:var(--mono); color:var(--dim);
  font-size:clamp(10px,.78vw,13px); letter-spacing:.16em;
}
.slide-rail .rail-index { color:var(--accent); font-size:clamp(24px,2.8vw,48px); font-family:var(--serif); letter-spacing:0; }
.slide-rail .rail-label { writing-mode:vertical-rl; text-orientation:upright; color:var(--muted); letter-spacing:.22em; }
.slide-body { position:relative; max-width: min(1160px, 88vw); }
.section-label {
  display:flex; align-items:center; gap:18px;
  color:var(--accent); font-family:var(--sans); font-size:clamp(11px,.82vw,14px);
  letter-spacing:.34em; margin-bottom:clamp(16px,1.8vw,26px);
}
.section-label::after { content:""; width:clamp(32px,3.4vw,56px); height:1px; background:var(--line); }
.slide h2 {
  margin:0 0 clamp(18px,2.2vw,30px);
  font-family:var(--serif); font-weight:500;
  font-size:clamp(34px,4.2vw,72px); line-height:1.22; letter-spacing:0;
  color:var(--ink); text-wrap:balance; line-break:strict;
}
.slide .summary {
  color:var(--soft); font-size:clamp(17px,1.35vw,22px);
  line-height:1.9; max-width: 980px; margin:0;
  text-align:justify; text-justify:inter-ideograph;
  text-wrap:pretty; line-break:strict; overflow-wrap:break-word;
}
.slide .meta {
  margin-top:clamp(22px,2.5vw,36px); color:var(--muted);
  font-family:var(--mono); font-size:clamp(14px,1vw,16px); letter-spacing:.06em;
}
.question {
  margin:clamp(20px,2.2vw,30px) 0 clamp(22px,2.6vw,34px);
  padding-left:clamp(16px,1.6vw,22px);
  border-left:2px solid var(--accent);
  color:var(--accent2); font-family:var(--serif);
  font-size:clamp(18px,1.45vw,24px); line-height:1.7;
  max-width:980px;
}
.question em {
  display:block; margin-bottom:8px;
  color:var(--muted); font-style:normal; font-family:var(--mono);
  font-size:10px; letter-spacing:.22em;
}

/* lead variant */
.slide-lead .slide-body { max-width:min(1220px,88vw); }
.slide-lead h2 { font-size:clamp(40px,5.1vw,86px); }
.slide-lead .summary { color:var(--soft); font-size:clamp(18px,1.5vw,25px); }

/* story variant */
.slide-story .slide-body { display:flex; flex-direction:column; justify-content:center; }
.slide-story h2 { text-wrap:pretty; }
.story-tags { display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px; }
.pill {
  display:inline-flex; align-items:center; padding:5px 11px;
  border:1px solid var(--line); border-radius:999px;
  color:var(--muted); font-family:var(--mono); font-size:clamp(9px,.72vw,11px);
  letter-spacing:.12em;
}

/* person */
.person-layout { display:grid; grid-template-columns:clamp(170px,.22fr) minmax(0,1fr); gap:clamp(34px,5vw,78px); align-items:center; }
.person-seal {
  width:clamp(150px,14vw,240px); aspect-ratio:1; border:1px solid var(--accent);
  border-radius:50%; display:grid; place-items:center;
  color:var(--accent2); font-family:var(--serif); font-size:clamp(58px,6vw,100px);
  position:relative; box-shadow: inset 0 0 0 8px rgba(201,168,106,.04);
}
.person-seal::after { content:""; position:absolute; inset:14px; border:1px solid var(--line); border-radius:50%; }
.person-name { font-family:var(--serif); font-size:clamp(42px,4.6vw,78px); line-height:1.1; margin:0; }
.person-latin { color:var(--accent); font-family:var(--mono); letter-spacing:.18em; font-size:clamp(10px,.8vw,13px); margin-top:10px; }
.person-identity { color:var(--muted); font-size:clamp(16px,1.2vw,20px); margin-top:12px; }
.person-headline { color:var(--accent2); font-family:var(--serif); font-size:clamp(20px,1.8vw,30px); line-height:1.6; margin:20px 0 16px; }
.person-story { color:var(--soft); font-size:clamp(15px,1.1vw,18px); line-height:1.85; max-height:7.2em; overflow:hidden; }
.moments { display:grid; grid-template-columns:repeat(3,1fr); gap:clamp(14px,2vw,26px); margin-top:clamp(20px,2.4vw,32px); border-top:1px solid var(--line); padding-top:clamp(14px,1.8vw,24px); }
.moment { color:var(--muted); font-size:clamp(12px,.9vw,15px); line-height:1.55; }
.moment b { display:block; color:var(--accent); font-family:var(--mono); font-weight:400; letter-spacing:.14em; margin-bottom:7px; }


/* three people */
.people-layout { width:100%; max-width:min(1540px,94vw); display:flex; flex-direction:column; justify-content:center; gap:clamp(24px,3vw,42px); }
.people-head { display:flex; align-items:flex-end; justify-content:space-between; gap:30px; border-bottom:1px solid var(--line); padding-bottom:clamp(14px,1.6vw,20px); }
.people-head h2 { margin:0; font-size:clamp(32px,3.4vw,54px); line-height:1.15; }
.people-sub { color:var(--muted); font-family:var(--serif); font-size:clamp(15px,1.15vw,19px); letter-spacing:.06em; white-space:nowrap; }
.people-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:clamp(22px,3vw,44px); }
.figure-card { display:flex; flex-direction:column; border-top:1px solid var(--accent); padding-top:clamp(16px,1.7vw,22px); min-width:0; min-height:clamp(460px,52vh,600px); }
.figure-top { display:flex; align-items:center; gap:14px; margin-bottom:14px; }
.figure-seal { width:clamp(44px,4vw,58px); aspect-ratio:1; border:1px solid var(--accent); border-radius:50%; display:grid; place-items:center; color:var(--accent2); font-family:var(--serif); font-size:clamp(22px,2.3vw,32px); flex:none; box-shadow:inset 0 0 0 5px rgba(255,255,255,.025); }
.figure-name { font-family:var(--serif); font-size:clamp(28px,2.8vw,42px); line-height:1.1; }
.figure-latin { color:var(--accent); font-family:var(--mono); font-size:9px; letter-spacing:.13em; margin-top:5px; }
.figure-identity { color:var(--muted); font-size:clamp(12px,.92vw,15px); line-height:1.6; margin:8px 0 12px; }
.figure-headline { color:var(--accent2); font-family:var(--serif); font-size:clamp(17px,1.35vw,22px); line-height:1.65; margin:0 0 12px; }
.figure-story { color:var(--soft); font-size:clamp(13px,.95vw,16px); line-height:1.85; margin:0; max-height:9em; overflow:hidden; }
.figure-moment { margin-top:16px; padding-left:12px; border-left:2px solid var(--accent); color:var(--muted); font-size:clamp(11px,.82vw,13px); line-height:1.65; }
.figure-moment b { color:var(--accent2); font-family:var(--mono); font-weight:400; letter-spacing:.1em; margin-right:8px; }
.figure-quote { margin:auto 0 0; padding-top:16px; color:var(--muted); font-family:var(--serif); font-size:clamp(12px,.9vw,15px); line-height:1.65; border-top:1px solid var(--line); }

/* quotes */
.quote-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:clamp(18px,2.5vw,34px); width:100%; }
.quote-card {
  border-top:1px solid var(--accent); padding:clamp(20px,2.4vw,34px) 0 0;
  display:flex; flex-direction:column; min-height:clamp(240px,26vh,380px);
}
.quote-card blockquote { margin:0; font-family:var(--serif); font-size:clamp(20px,1.65vw,28px); line-height:1.72; color:var(--ink); }
.quote-card .author { margin-top:auto; padding-top:22px; color:var(--accent2); font-family:var(--mono); font-size:clamp(10px,.8vw,12px); letter-spacing:.12em; }
.quote-card .use { margin-top:12px; color:var(--muted); font-size:clamp(12px,.9vw,14px); line-height:1.65; }

/* term */
.term-layout { display:grid; grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr); gap:clamp(34px,5vw,84px); align-items:center; }
.term-word { font-family:var(--serif); font-size:clamp(56px,7vw,118px); line-height:1.1; color:var(--ink); }
.term-en { color:var(--accent); font-family:var(--mono); font-size:clamp(10px,.8vw,13px); letter-spacing:.18em; margin-top:14px; }
.term-def { color:var(--soft); font-size:clamp(17px,1.35vw,22px); line-height:1.85; margin-top:clamp(22px,2.6vw,36px); }
.term-side { border-left:1px solid var(--line); padding-left:clamp(20px,3vw,44px); color:var(--muted); font-size:clamp(13px,1vw,16px); line-height:1.8; }
.term-side p { margin:0 0 16px; }
.term-side b { color:var(--accent2); font-family:var(--mono); font-weight:400; display:block; letter-spacing:.12em; margin-bottom:4px; }

/* end */
.slide-end { grid-template-columns:1fr; text-align:center; place-items:center; }
.end-mark { font-family:var(--serif); font-size:clamp(62px,9vw,148px); color:var(--ink); letter-spacing:.08em; }
.end-sub { margin-top:22px; color:var(--muted); font-family:var(--serif); font-size:clamp(17px,1.4vw,24px); }
.end-hint { margin-top:48px; color:var(--dim); font-family:var(--mono); font-size:clamp(10px,.8vw,12px); letter-spacing:.14em; }

/* footer / controls */
.deck-foot { position:relative; padding-top:clamp(10px,1.2vw,16px); }
.deck-progress { height:1px; background:rgba(255,255,255,.07); overflow:hidden; }
.deck-progress i { display:block; width:0; height:100%; background:linear-gradient(90deg,var(--accent),var(--accent2)); }
.controls {
  position:absolute; right:0; bottom:calc(100% + 16px);
  display:flex; align-items:center; gap:6px;
  opacity:0; pointer-events:none; transition:opacity .35s ease;
  padding:6px; border:1px solid var(--line); border-radius:10px;
  background:rgba(8,14,22,.72); backdrop-filter:blur(10px);
}
body.show-controls .controls { opacity:1; pointer-events:auto; }
.controls button {
  border:0; background:transparent; color:var(--muted);
  padding:7px 11px; border-radius:6px; cursor:pointer;
  font-size:clamp(11px,.8vw,13px); letter-spacing:.05em;
}
.controls button:hover { color:var(--accent2); background:rgba(201,168,106,.10); }
.controls .hint { color:var(--dim); font-family:var(--mono); font-size:10px; letter-spacing:.08em; padding:0 8px; }
body[data-theme="rice"] .controls { background:rgba(245,240,230,.88); }

/* ---------- four visual templates ---------- */
body[data-theme="midnight"] { --bg:#06111d; --bg2:#0d1b2b; --ink:#f2ecdf; --soft:#d6cec0; --muted:#95a3b3; --dim:#5f7182; --accent:#c9a86a; --accent2:#e8d4a6; --accent3:#6f93a8; --line:rgba(201,168,106,.22); }
body[data-theme="midnight"] .cover {
  text-align:left;
  background:
    radial-gradient(900px 620px at 18% 10%, rgba(201,168,106,.11), transparent 62%),
    radial-gradient(800px 700px at 88% 84%, rgba(111,147,168,.15), transparent 60%),
    linear-gradient(135deg,#06111d,#0d1b2b 55%,#06101b);
}
body[data-theme="midnight"] .cover-line { background:linear-gradient(90deg,var(--accent),var(--accent3),transparent); }
body[data-theme="midnight"] .cover-mark span:last-child { color:var(--accent3); }
body[data-theme="midnight"] .cover-mark span:first-child { transform:translateY(-.03em); }

body[data-theme="rice"] {
  --bg:#bfb19b; --bg2:#d1c4ae; --ink:#211e19; --soft:#3d372d; --muted:#544a3c; --dim:#736553;
  --accent:#9f3c2c; --accent2:#762b21; --accent3:#3e5a60; --line:rgba(80,60,40,.22); --card:rgba(255,255,255,.25);
}
body[data-theme="rice"] .cover {
  background:
    radial-gradient(900px 600px at 14% 12%, rgba(160,60,44,.06), transparent 65%),
    radial-gradient(900px 700px at 86% 88%, rgba(62,90,96,.1), transparent 62%),
    repeating-linear-gradient(90deg, rgba(80,60,40,.035) 0 1px, transparent 1px 4px),
    linear-gradient(135deg, #c3b49e, #d6c9b4 56%, #b7a992);
}
body[data-theme="rice"] .cover::before { opacity:.35; background-size:54px 54px; }
body[data-theme="rice"] .cover-mark { color:#211e19; writing-mode:horizontal-tb; flex-direction:row; font-size:clamp(126px,19vw,260px); line-height:1; gap:.03em; }
body[data-theme="rice"] .cover-mark span:last-child { color:var(--accent); }
body[data-theme="rice"] .cover-date { color:var(--accent); }
body[data-theme="rice"] .cover-line { background:linear-gradient(90deg,var(--accent),rgba(62,90,96,.45),transparent); }
body[data-theme="rice"] .deck {
  background:
    radial-gradient(900px 700px at 80% 18%, rgba(160,60,44,.045), transparent 60%),
    radial-gradient(900px 700px at 16% 86%, rgba(62,90,96,.075), transparent 64%),
    repeating-linear-gradient(90deg, rgba(80,60,40,.025) 0 1px, transparent 1px 4px),
    linear-gradient(135deg,#c3b49e,#d6c9b4 62%,#b7a992);
}
body[data-theme="rice"] .slide-rail { border-right-color:rgba(80,60,40,.2); }
body[data-theme="rice"] .slide .summary { color:#332e26; }
body[data-theme="rice"] .quote-card blockquote { color:#211e19; }
body[data-theme="rice"] .person-story { color:#403a31; }

body[data-theme="jade"] {
  --bg:#071410; --bg2:#0d241c; --ink:#e9f0e8; --soft:#c9d8d0; --muted:#93ada1; --dim:#5f796d;
  --accent:#a9c7b3; --accent2:#e4dcc4; --accent3:#c7a46e; --line:rgba(169,199,179,.22); --card:rgba(255,255,255,.035);
}
body[data-theme="jade"] .cover {
  background:
    radial-gradient(900px 600px at 78% 22%, rgba(120,180,150,.13), transparent 62%),
    radial-gradient(760px 620px at 12% 82%, rgba(199,164,110,.1), transparent 64%),
    linear-gradient(135deg,#06110e,#0c2119 55%,#071611);
}
body[data-theme="jade"] .cover::before {
  background-image: repeating-linear-gradient(90deg, rgba(169,199,179,.065) 0 1px, transparent 1px 112px);
  background-size:auto; mask-image:linear-gradient(90deg,transparent,#000 14%,#000 86%,transparent);
}
body[data-theme="jade"] .cover-mark { font-size:clamp(126px,19vw,270px); color:#e9f0e8; }
body[data-theme="jade"] .cover-main { align-items:flex-end; text-align:right; }
body[data-theme="jade"] .cover-eyebrow, body[data-theme="jade"] .cover-kicker { align-self:flex-end; }
body[data-theme="jade"] .cover-mark span:last-child { color:var(--accent3); }
body[data-theme="jade"] .cover-date { color:var(--accent3); }
body[data-theme="jade"] .cover-line { background:linear-gradient(270deg,var(--accent),var(--accent3),transparent); }
body[data-theme="jade"] .deck {
  background-image:
    radial-gradient(900px 700px at 25% 20%, rgba(120,180,150,.08), transparent 60%),
    radial-gradient(800px 620px at 88% 82%, rgba(199,164,110,.07), transparent 64%),
    repeating-linear-gradient(90deg, rgba(169,199,179,.055) 0 1px, transparent 1px 104px),
    linear-gradient(140deg,#06110e,#0c2119);
}
body[data-theme="jade"] .slide h2 { letter-spacing:.01em; }

body[data-theme="amber"] {
  --bg:#0d0a08; --bg2:#1b130d; --ink:#f3e8d7; --soft:#d8c5ad; --muted:#b3a18b; --dim:#7f6e5b;
  --accent:#d58b4b; --accent2:#f0c48a; --accent3:#6f8e88; --line:rgba(213,139,75,.22); --card:rgba(255,255,255,.035);
}
body[data-theme="amber"] .cover {
  background:
    radial-gradient(900px 600px at 20% 20%, rgba(213,139,75,.15), transparent 60%),
    radial-gradient(800px 680px at 84% 84%, rgba(111,142,136,.11), transparent 62%),
    linear-gradient(135deg,#0c0907,#1b120b 55%,#0e0a08);
}
body[data-theme="amber"] .cover::after {
  content:""; position:absolute; inset:clamp(16px,2.2vw,30px); border:1px solid rgba(213,139,75,.18); pointer-events:none;
}
body[data-theme="amber"] .cover-mark { color:#f3e8d7; font-size:clamp(132px,20vw,286px); }
body[data-theme="amber"] .cover-mark span:last-child { color:var(--accent2); }
body[data-theme="amber"] .cover-line { background:linear-gradient(90deg,var(--accent),var(--accent3),transparent); }
body[data-theme="amber"] .deck { background:radial-gradient(900px 700px at 75% 12%, rgba(213,139,75,.07), transparent 60%), linear-gradient(140deg,#0c0907,#1b120b); }
body[data-theme="amber"] .slide h2 { color:#f6ecdc; }
body[data-theme="amber"] .quote-card { border-top-color:var(--accent); }

/* ---------- material evidence in the deck ---------- */
body[data-theme="midnight"] .deck {
  background-image:
    radial-gradient(1000px 700px at 82% 16%, rgba(201,168,106,.075), transparent 64%),
    radial-gradient(900px 720px at 14% 84%, rgba(111,147,168,.09), transparent 66%),
    linear-gradient(90deg, transparent calc(100% - 1px), rgba(201,168,106,.16) calc(100% - 1px), rgba(201,168,106,.16) 100%),
    linear-gradient(140deg, var(--bg), var(--bg2));
}
body[data-theme="midnight"] .slide h2 {
  border-top:1px solid rgba(201,168,106,.24);
  padding-top:clamp(12px,1.4vw,18px);
}

body[data-theme="rice"] .slide h2 {
  border-bottom:1px solid rgba(159,60,44,.3);
  padding-bottom:clamp(10px,1.2vw,16px);
}
body[data-theme="rice"] .slide-rail { position:relative; padding-bottom:clamp(62px,6vw,82px); }
body[data-theme="rice"] .slide-rail::after {
  content:"观"; position:absolute; right:0; bottom:0;
  width:clamp(36px,3.2vw,46px); height:clamp(36px,3.2vw,46px);
  display:grid; place-items:center;
  border:1px solid rgba(159,60,44,.62);
  color:rgba(159,60,44,.82); font-family:var(--serif); font-size:clamp(18px,1.7vw,24px);
  opacity:.8;
}

body[data-theme="jade"] .slide h2 { border-top:1px solid rgba(169,199,179,.18); padding-top:clamp(12px,1.4vw,18px); }

body[data-theme="amber"] .deck {
  background-image:
    radial-gradient(circle at 7px 7px, rgba(213,139,75,.28) 0 1.4px, transparent 1.9px),
    radial-gradient(circle at 7px 7px, rgba(213,139,75,.16) 0 1.4px, transparent 1.9px),
    radial-gradient(900px 700px at 75% 12%, rgba(213,139,75,.08), transparent 60%),
    radial-gradient(800px 680px at 18% 86%, rgba(111,142,136,.09), transparent 64%),
    linear-gradient(140deg,#0c0907,#1b120b);
  background-size: 26px 24px, 26px 24px, auto, auto;
  background-position: 0 0, 0 100%, 0 0, 0 0;
  background-repeat: repeat-x, repeat-x, no-repeat, no-repeat;
}

/* ---------- daily cover compositions ---------- */
body[data-cover="left"] .cover-main { align-items:flex-start; text-align:left; }
body[data-cover="left"] .cover-eyebrow,
body[data-cover="left"] .cover-kicker,
body[data-cover="left"] .cover-date,
body[data-cover="left"] .cover-meta { align-self:flex-start; }
body[data-cover="left"] .cover-line { --line-origin:left; }

body[data-cover="center"] .cover-main {
  width:min(1120px,92vw); align-items:center; text-align:center; justify-self:center;
}
body[data-cover="center"] .cover-eyebrow,
body[data-cover="center"] .cover-kicker,
body[data-cover="center"] .cover-date,
body[data-cover="center"] .cover-meta { align-self:center; }
body[data-cover="center"] .cover-mark { justify-content:center; }
body[data-cover="center"] .cover-line {
  --line-origin:center; margin-left:auto; margin-right:auto;
  background:linear-gradient(90deg,transparent,var(--accent),transparent);
}

body[data-cover="right"] .cover-main {
  align-items:flex-end; text-align:right; margin-left:auto;
}
body[data-cover="right"] .cover-eyebrow,
body[data-cover="right"] .cover-kicker,
body[data-cover="right"] .cover-date,
body[data-cover="right"] .cover-meta { align-self:flex-end; }
body[data-cover="right"] .cover-mark { justify-content:flex-end; }
body[data-cover="right"] .cover-line {
  --line-origin:right; margin-left:auto;
  background:linear-gradient(270deg,var(--accent),transparent);
}

body[data-cover="offset"] .cover-main {
  width:min(1540px,94vw);
  display:grid;
  grid-template-columns:minmax(0,.82fr) minmax(0,1.18fr);
  grid-template-areas:"eyebrow mark" "kicker mark" "date mark" "line mark" "meta mark";
  column-gap:clamp(30px,5vw,88px); row-gap:clamp(10px,1.2vw,18px);
  align-items:end;
}
body[data-cover="offset"] .cover-eyebrow { grid-area:eyebrow; align-self:end; margin:0; }
body[data-cover="offset"] .cover-kicker { grid-area:kicker; align-self:end; margin:0; }
body[data-cover="offset"] .cover-mark {
  grid-area:mark; align-self:center; justify-self:end;
  font-size:clamp(140px,19vw,272px);
}
body[data-cover="offset"] .cover-date {
  grid-area:date; align-self:end; margin-top:clamp(28px,4vw,58px);
}
body[data-cover="offset"] .cover-line {
  grid-area:line; --line-origin:left;
  margin:clamp(14px,1.8vw,24px) 0;
}
body[data-cover="offset"] .cover-meta { grid-area:meta; align-self:end; }

body[data-cover="stack"] .cover-main { width:min(920px,88vw); align-items:flex-start; text-align:left; }
body[data-cover="stack"] .cover-mark {
  flex-direction:column; align-items:flex-start; gap:0;
  font-size:clamp(104px,13vw,180px); line-height:.98;
}
body[data-cover="stack"] .cover-mark span:last-child { margin-left:.5em; }
body[data-cover="stack"] .cover-date { margin-top:clamp(26px,2.4vw,38px); }
body[data-cover="stack"] .cover-line { --line-origin:left; }

/* mirror the reading rail on right-composed issues */
body[data-cover="right"] .slide {
  grid-template-columns:minmax(0,1fr) minmax(80px,.23fr);
}
body[data-cover="right"] .slide-rail {
  order:2; align-items:flex-end; text-align:right;
  border-right:0; border-left:1px solid var(--line);
  padding:clamp(8px,1.4vw,20px) 0 clamp(8px,1.4vw,20px) clamp(16px,2vw,28px);
}
body[data-cover="right"] .slide-body { order:1; }

body.still *, body.still *::before, body.still *::after {
  animation:none !important; transition:none !important;
}
body.still .cover-main, body.still .cover-mark, body.still .cover-line {
  opacity:1 !important; transform:none !important;
}

/* ---------- full-bleed material plates ---------- */
body[data-theme="midnight"] .cover, body[data-theme="midnight"] .deck {
  background-image:
    radial-gradient(900px 620px at 18% 10%, rgba(201,168,106,.13), transparent 62%),
    radial-gradient(800px 700px at 88% 84%, rgba(111,147,168,.17), transparent 60%),
    linear-gradient(90deg, transparent calc(100% - 1px), rgba(201,168,106,.18) calc(100% - 1px), rgba(201,168,106,.18) 100%),
    linear-gradient(135deg, rgba(6,17,29,.54), rgba(13,27,43,.5)),
    var(--texture, none);
  background-size:auto,auto,auto,cover,cover;
  background-position:center;
  background-repeat:no-repeat;
}
body[data-theme="rice"] .cover, body[data-theme="rice"] .deck {
  background-image:
    radial-gradient(900px 600px at 14% 12%, rgba(159,60,44,.075), transparent 64%),
    radial-gradient(900px 700px at 86% 88%, rgba(62,90,96,.11), transparent 62%),
    repeating-linear-gradient(90deg, rgba(80,60,40,.03) 0 1px, transparent 1px 4px),
    linear-gradient(135deg, rgba(191,177,155,.62), rgba(209,196,174,.56)),
    var(--texture, none);
  background-size:auto,auto,auto,cover,cover;
  background-position:center;
  background-repeat:no-repeat;
}
body[data-theme="jade"] .cover, body[data-theme="jade"] .deck {
  background-image:
    radial-gradient(900px 620px at 78% 22%, rgba(120,180,150,.14), transparent 62%),
    radial-gradient(760px 620px at 12% 82%, rgba(199,164,110,.12), transparent 64%),
    repeating-linear-gradient(90deg, rgba(169,199,179,.06) 0 1px, transparent 1px 104px),
    linear-gradient(135deg, rgba(6,17,14,.6), rgba(12,33,25,.55)),
    var(--texture, none);
  background-size:auto,auto,auto,cover,cover;
  background-position:center;
  background-repeat:no-repeat;
}
body[data-theme="amber"] .cover, body[data-theme="amber"] .deck {
  background-image:
    radial-gradient(circle at 7px 7px, rgba(213,139,75,.28) 0 1.4px, transparent 1.9px),
    radial-gradient(circle at 7px 7px, rgba(213,139,75,.18) 0 1.4px, transparent 1.9px),
    radial-gradient(900px 700px at 75% 12%, rgba(213,139,75,.09), transparent 60%),
    radial-gradient(800px 680px at 18% 86%, rgba(111,142,136,.1), transparent 64%),
    linear-gradient(140deg, rgba(12,9,7,.58), rgba(27,18,11,.52)),
    var(--texture, none);
  background-size:26px 24px,26px 24px,auto,auto,cover,cover;
  background-position:0 0,0 100%,center,center,center,center;
  background-repeat:repeat-x,repeat-x,no-repeat,no-repeat,no-repeat,no-repeat;
}

/* responsive */
@media (max-width: 900px) {
  .cover { padding:24px; }
  .cover-mark { font-size:clamp(100px,25vw,180px); }
  .slide { grid-template-columns:1fr; gap:12px; padding:22px 0; }
  .slide-rail { flex-direction:row; align-items:center; border-right:0; border-bottom:1px solid var(--line); padding:0 0 10px; }
  .slide-rail .rail-label { writing-mode:horizontal-tb; }
  body[data-cover="right"] .slide { grid-template-columns:1fr; }
  body[data-cover="right"] .slide-rail { order:0; align-items:flex-start; text-align:left; border-left:0; border-bottom:1px solid var(--line); padding:0 0 10px; }
  body[data-cover="offset"] .cover-main { display:flex; flex-direction:column; align-items:flex-start; text-align:left; width:auto; }
  body[data-cover="offset"] .cover-eyebrow { margin-bottom:24px; }
  body[data-cover="offset"] .cover-kicker { margin-bottom:14px; }
  body[data-cover="offset"] .cover-mark { align-self:flex-start; }
  body[data-cover="offset"] .cover-date { margin-top:26px; }
  body[data-cover="right"] .cover-main { align-items:flex-start; text-align:left; }
  .person-layout, .term-layout, .quote-grid, .people-grid { grid-template-columns:1fr; }
  .people-head { display:block; }
  .people-sub { display:block; margin-top:8px; white-space:normal; }
  .person-seal { width:100px; }
  .quote-card { min-height:0; }
  .controls .hint { display:none; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration:.01ms !important; transition-duration:.01ms !important; }
}
"""

PAGE = r"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>__TITLE__</title>
<style>__CSS__
__TEXTURE_CSS__</style>
</head>
<body data-theme="__THEME__" data-cover="__COVER__">
<button class="exit-btn" id="enterFullscreen" type="button" aria-label="全屏显示" style="right:calc(clamp(72px,7.4vw,104px))">全屏</button>
<button class="exit-btn" id="exitFullscreen" type="button" aria-label="退出全屏">退出全屏</button>
<section class="cover" id="cover">
  <div class="cover-hud"><span class="brand">GUANLAN / EVENING REVIEW</span><span>NO.__ISSUE__</span></div>
  <div class="cover-main">
    <div class="cover-eyebrow">晚 间 副 刊</div>
    <div class="cover-kicker">今夜，先静三分钟</div>
    <h1 class="cover-mark" aria-label="暮省"><span>暮</span><span>省</span></h1>
    <div class="cover-date">__DATE_LONG__</div>
    <div class="cover-line"></div>
    <div class="cover-meta">今日 __COUNT__ 则 · 约 __MINUTES__ 分钟</div>
  </div>
  <div class="cover-foot"><span>观澜 · 每日视界</span><span class="countdown-wrap"><span class="countdown-label">静候</span><span id="countdown">03:00</span></span></div>
  <div class="cover-progress"><i id="coverBar"></i></div>
</section>

<main class="deck" id="deck" hidden>
  <header class="hud">
    <div class="hud-brand"><span class="brand-mark">暮省</span><span class="hud-date">__DATE_SHORT__</span></div>
    <div class="hud-meta"><span class="hud-issue">NO.__ISSUE__</span><span id="hudSection">今日焦点</span><span id="hudCount">01 / __TOTAL__</span></div>
  </header>
  <div class="slides" id="slides">__SLIDES__</div>
  <footer class="deck-foot">
    <div class="deck-progress"><i id="deckBar"></i></div>
    <div class="controls" id="controls">
      <button id="prev" aria-label="上一页">←</button>
      <button id="pause" aria-label="暂停">暂停</button>
      <button id="next" aria-label="下一页">→</button>
      <span class="hint">空格暂停 · ← → 翻页 · 右上角退出</span>
      <button id="close" aria-label="关闭">关闭</button>
    </div>
  </footer>
</main>

<script>
(() => {
  const COVER_MS = 180000;
  const cover = document.getElementById('cover');
  const deck = document.getElementById('deck');
  const slides = Array.from(document.querySelectorAll('.slide'));
  const countdown = document.getElementById('countdown');
  const coverBar = document.getElementById('coverBar');
  const deckBar = document.getElementById('deckBar');
  const hudSection = document.getElementById('hudSection');
  const hudCount = document.getElementById('hudCount');
  const pauseBtn = document.getElementById('pause');
  const controls = document.getElementById('controls');
  const params = new URLSearchParams(location.search);
  const preview = params.get('preview') === '1';
  if (params.get('still') === '1') document.body.classList.add('still');
  let coverStart = performance.now();
  let coverRaf = 0;
  let current = 0;
  let paused = false;
  let ended = false;
  let timer = 0;
  let startedAt = 0;
  let remaining = 0;
  let total = 0;
  let controlsTimer = 0;

  const format = ms => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  };

  function setBar(width, ms) {
    deckBar.style.transition = 'none';
    deckBar.style.width = width + '%';
    void deckBar.offsetWidth;
    if (ms > 0) {
      deckBar.style.transition = 'width ' + ms + 'ms linear';
      deckBar.style.width = '100%';
    }
  }

  function wakeControls() {
    document.body.classList.add('show-controls');
    clearTimeout(controlsTimer);
    controlsTimer = setTimeout(() => document.body.classList.remove('show-controls'), 3200);
  }

  function startDeck(index = 0) {
    cancelAnimationFrame(coverRaf);
    cover.classList.add('gone');
    setTimeout(() => {
      cover.style.display = 'none';
      deck.hidden = false;
      show(Number.isFinite(index) ? index : 0);
    }, preview ? 0 : 900);
  }

  function coverTick(now) {
    const elapsed = now - coverStart;
    const left = Math.max(0, COVER_MS - elapsed);
    countdown.textContent = format(left);
    coverBar.style.width = Math.min(100, elapsed / COVER_MS * 100) + '%';
    if (elapsed >= COVER_MS) {
      startDeck(0);
      return;
    }
    coverRaf = requestAnimationFrame(coverTick);
  }

  function show(index) {
    if (!slides.length) return;
    current = Math.max(0, Math.min(slides.length - 1, index));
    ended = false;
    slides.forEach((slide, i) => slide.classList.toggle('active', i === current));
    const slide = slides[current];
    const duration = Math.max(6000, Number(slide.dataset.duration || 20) * 1000);
    hudSection.textContent = slide.dataset.section || '暮省';
    hudCount.textContent = String(current + 1).padStart(2, '0') + ' / ' + String(slides.length).padStart(2, '0');
    pauseBtn.textContent = '暂停';
    paused = false;
    total = duration;
    remaining = duration;
    startedAt = performance.now();
    setBar(0, duration);
    clearTimeout(timer);
    timer = setTimeout(next, duration);
    wakeControls();
  }

  function next() {
    if (ended) return;
    if (current >= slides.length - 1) {
      finish();
      return;
    }
    show(current + 1);
  }

  function finish() {
    ended = true;
    paused = false;
    clearTimeout(timer);
    deckBar.style.transition = 'none';
    deckBar.style.width = '100%';
    pauseBtn.textContent = '重播';
    document.body.classList.add('show-controls');
  }

  function togglePause() {
    if (ended) {
      show(0);
      return;
    }
    if (!paused) {
      paused = true;
      clearTimeout(timer);
      remaining = Math.max(600, remaining - (performance.now() - startedAt));
      const pct = Math.min(99, Math.max(0, (1 - remaining / total) * 100));
      setBar(pct, 0);
      pauseBtn.textContent = '继续';
    } else {
      paused = false;
      startedAt = performance.now();
      deckBar.style.transition = 'width ' + remaining + 'ms linear';
      deckBar.style.width = '100%';
      timer = setTimeout(next, remaining);
      pauseBtn.textContent = '暂停';
    }
    wakeControls();
  }

  function go(delta) {
    if (ended) {
      show(0);
      return;
    }
    show(current + delta);
  }

  if (preview) {
    const requested = Number(params.get('slide') || '0');
    document.body.classList.add('preview');
    cover.style.display = 'none';
    deck.hidden = false;
    show(Number.isFinite(requested) ? requested : 0);
  } else {
    coverRaf = requestAnimationFrame(coverTick);
  }

  const fsBtn = document.getElementById('enterFullscreen');
  if (fsBtn) {
    const syncFs = () => { fsBtn.hidden = !!document.fullscreenElement; };
    document.addEventListener('fullscreenchange', syncFs);
    syncFs();
    fsBtn.addEventListener('click', async (event) => {
      event.stopPropagation();
      try {
        if (document.fullscreenElement) await document.exitFullscreen();
        else await document.documentElement.requestFullscreen();
      } catch (e) {
        fsBtn.textContent = '按 F11';
      }
    });
  }

  const exitBtn = document.getElementById('exitFullscreen');
  if (exitBtn) {
    exitBtn.addEventListener('click', async (event) => {
      event.stopPropagation();
      exitBtn.disabled = true;
      exitBtn.textContent = '正在退出…';
      try { await fetch('/exit', { method: 'POST', cache: 'no-store' }); } catch (e) {}
      try { window.close(); } catch (e) {}
      try { if (document.fullscreenElement) await document.exitFullscreen(); } catch (e) {}
    });
  }

  pauseBtn.addEventListener('click', togglePause);
  document.getElementById('next').addEventListener('click', () => go(1));
  document.getElementById('prev').addEventListener('click', () => go(-1));
  document.getElementById('close').addEventListener('click', () => {
    try { window.close(); } catch (e) {}
    document.body.classList.add('show-controls');
  });
  document.addEventListener('mousemove', wakeControls);
  document.addEventListener('keydown', (event) => {
    if (event.key === ' ') {
      event.preventDefault();
      togglePause();
    } else if (event.key === 'ArrowRight') {
      event.preventDefault();
      go(1);
    } else if (event.key === 'ArrowLeft') {
      event.preventDefault();
      go(-1);
    } else if (event.key === 'Escape') {
      wakeControls();
    }
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && !paused && !ended) togglePause();
  });
  wakeControls();
})();
</script>
</body>
</html>
"""
