"""见微 · 观澜内嵌：复用观澜源码浮窗，独立数据目录，无托盘/热键冲突。"""
from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

import store

GUANLAN_DIR = Path(__file__).resolve().parent / "guanlan"


class GuanlanHost:
    def __init__(self) -> None:
        self.window = None
        self._lock = threading.Lock()

    def _ensure_path(self) -> None:
        self._ensure_home()   # 先定数据目录，再让 core.paths 被导入，否则路径会被锁到 exe 旁
        p = str(GUANLAN_DIR)
        if p not in sys.path:
            sys.path.insert(0, p)

    def _ensure_home(self) -> None:
        home = store.GUANLAN_HOME
        home.mkdir(parents=True, exist_ok=True)
        os.environ["JIANWEI_EMBED"] = "1"
        os.environ["JIANWEI_GUANLAN_HOME"] = str(home)

    def ensure(self):
        if self.window is not None:
            return self.window
        self._ensure_home()
        self._ensure_path()
        try:
            from ui.window import MainWindow  # type: ignore
        except Exception as exc:  # 缺依赖时给出可读状态，不崩主程序
            raise RuntimeError(f"观澜模块未就绪：{exc}") from exc
        self.window = MainWindow(start_collapsed=False, start_hidden=True)
        return self.window

    # ------------------------------------------------------------ 操作
    def show(self) -> bool:
        try:
            win = self.ensure()
            win.show_window()
            win.raise_()
            win.activateWindow()
            return True
        except Exception:
            return False

    def reload(self) -> None:
        """数据文件更新后，让浮窗就地换内容（不发网络请求）。"""
        if self.window is not None:
            try:
                self.window._load_data()
            except Exception:
                pass

    def hide(self) -> None:
        if self.window is not None:
            try:
                self.window.hide()
            except Exception:
                pass

    def toggle(self) -> bool:
        if self.is_visible():
            self.hide()
            return False
        return self.show()

    def is_visible(self) -> bool:
        try:
            return bool(self.window is not None and self.window.isVisible())
        except Exception:
            return False

    def evening(self) -> None:
        """生成当日暮省并全屏播放：交给独立进程（自带渲染与播放器），界面不阻塞。"""
        import subprocess
        app_root = Path(__file__).resolve().parent
        try:
            self._ensure_home()
            self._ensure_path()
            if getattr(sys, "frozen", False):
                cmd = [sys.executable, "--evening"]
            else:
                cmd = [sys.executable, str(app_root / "main.py"), "--evening"]
            subprocess.Popen(cmd, cwd=str(app_root), close_fds=True,
                             creationflags=0x00000008 if os.name == "nt" else 0)
        except Exception:
            def work():
                try:
                    from core.evening import run as run_evening  # type: ignore
                    run_evening(open_browser=True)
                except Exception:
                    pass
            threading.Thread(target=work, daemon=True).start()
