"""见微 · 析题台宿主：本地静态服务 + Edge 无边框应用窗。"""
from __future__ import annotations

import ctypes
import functools
import http.server
import os
import subprocess
import threading
import time
from pathlib import Path
from urllib.parse import quote

import store

EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_a):  # 安静运行，不弹控制台
        pass


class StudioHost:
    def __init__(self) -> None:
        self._httpd: http.server.ThreadingHTTPServer | None = None
        self.port = 0
        self._proc: subprocess.Popen | None = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------ 服务
    def ensure(self) -> int:
        with self._lock:
            if self._httpd is not None:
                return self.port
            handler = functools.partial(_Quiet, directory=str(store.WEB_DIR))
            self._httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
            self._httpd.daemon_threads = True
            self.port = self._httpd.server_address[1]
            threading.Thread(target=self._httpd.serve_forever, daemon=True).start()
            try:
                (store.HOME / "studio.url").write_text(self.url_base(), encoding="utf-8")
            except Exception:
                pass
            return self.port

    def url_base(self) -> str:
        return f"http://127.0.0.1:{self.port}/index.html"

    def url(self, qid: str = "", lab: bool = False, audit: bool = False) -> str:
        port = self.ensure()
        query = []
        if qid:
            query.append("q=" + quote(qid))
        if lab:
            query.append("lab=1")
        if audit:
            query.append("audit=1")
        suffix = ("?" + "&".join(query)) if query else ""
        return f"http://127.0.0.1:{port}/index.html{suffix}"

    def stop(self) -> None:
        if self._httpd is not None:
            try:
                self._httpd.shutdown()
            except Exception:
                pass
            self._httpd = None

    # ------------------------------------------------------------ 打开窗口
    @staticmethod
    def edge_exe() -> str | None:
        for p in EDGE_PATHS:
            if Path(p).exists():
                return p
        return None

    def page_url(self, qid: str = "", lab: bool = False, imp: bool = False,
                 mode: str = "math") -> str:
        """离线可用：file:// 直接打开，不需要起服务。

        习题台与变换实验室是两个独立页面：lab=True 打开 lab.html，其余开 index.html。
        """
        page = "lab.html" if lab else "index.html"
        base = (store.WEB_DIR / page).as_uri()
        query = []
        if qid and not lab:
            query.append("q=" + quote(qid))
        if lab:
            query.append("mode=" + ("physics" if mode == "physics" else "math"))
        if imp and not lab:
            query.append("import=1")
        try:
            import ui_kit
            query.append("theme=" + ui_kit.theme())
        except Exception:
            pass
        return base + (("?" + "&".join(query)) if query else "")

    def open(self, qid: str = "", lab: bool = False, imp: bool = False,
             size: tuple[int, int] = (1460, 940), mode: str = "math") -> bool:
        """在浏览器里开一页；不置顶、不抢焦点，是否切过去交给浏览器。"""
        exe = self.edge_exe()
        url = self.page_url(qid, lab, imp, mode)
        _close_stale_windows()
        try:
            if exe:
                subprocess.Popen([exe, url, "--no-first-run"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                os.startfile(url)  # noqa: S606
            return True
        except Exception:
            return False


TITLE_HINT = "见微 · 习题台"

_user32 = ctypes.windll.user32
try:
    from ctypes import wintypes
except Exception:  # pragma: no cover
    wintypes = None


def _enum_windows() -> list[tuple[int, str]]:
    found: list[tuple[int, str]] = []
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _l):
        if not _user32.IsWindowVisible(hwnd):
            return True
        n = _user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        _user32.GetWindowTextW(hwnd, buf, n + 1)
        found.append((int(hwnd), buf.value))
        return True

    _user32.EnumWindows(EnumProc(cb), None)
    return found


def _close_stale_windows() -> None:
    """把上一轮停在死端口上的析题台窗口关掉（只认我们自己的标题）。"""
    for hwnd, title in _enum_windows():
        if TITLE_HINT in title or title.startswith("127.0.0.1_/index.html"):
            try:
                _user32.PostMessageW(hwnd, 0x0010, 0, 0)   # WM_CLOSE
            except Exception:
                pass


def _raise_window(hint: str, timeout: float = 8.0) -> bool:
    """把标题含 hint 的窗口显示出来并置前（Edge 的应用窗不会自己抢焦点）。"""
    end = time.time() + timeout
    while time.time() < end:
        for hwnd, title in _enum_windows():
            if hint and hint in title:
                try:
                    _user32.ShowWindow(hwnd, 9)          # SW_RESTORE
                    _user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002)  # HWND_TOPMOST
                    _user32.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0001 | 0x0002)  # HWND_NOTOPMOST
                    _user32.SetForegroundWindow(hwnd)
                    _user32.BringWindowToTop(hwnd)
                except Exception:
                    pass
                return True
        time.sleep(0.25)
    return False
