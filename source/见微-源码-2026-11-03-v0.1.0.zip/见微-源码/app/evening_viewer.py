"""暮省全屏播放器（Qt）：把渲染好的整页 PNG 铺满屏幕，方向键翻页。

这样不依赖任何图形界面浏览器，提权环境也能稳定出画面。
"""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QRectF
from PySide6.QtGui import QColor, QFont, QGuiApplication, QPainter, QPixmap
from PySide6.QtWidgets import QApplication, QWidget


class EveningViewer(QWidget):
    def __init__(self, slides: list[Path], auto_ms: int = 26000):
        super().__init__()
        self.slides = list(slides)
        self.index = 0
        self._pix: QPixmap | None = None
        self._auto = auto_ms
        self.setWindowTitle("暮省")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setStyleSheet("background:#07111d;")
        self.setCursor(Qt.CursorShape.BlankCursor)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.next)
        self._load(0)
        if self._auto > 0:
            self._timer.start(self._auto)

    # ---------- 数据 ----------
    def _load(self, i: int) -> None:
        if not self.slides:
            return
        self.index = max(0, min(len(self.slides) - 1, i))
        self._pix = QPixmap(str(self.slides[self.index]))
        self.update()

    def next(self) -> None:
        if self.index >= len(self.slides) - 1:
            self.close()
            return
        self._load(self.index + 1)

    def prev(self) -> None:
        self._load(self.index - 1)

    # ---------- 绘制 ----------
    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#07111d"))
        if self._pix and not self._pix.isNull():
            pw, ph = self._pix.width(), self._pix.height()
            k = min(self.width() / pw, self.height() / ph)
            w, h = pw * k, ph * k
            x, y = (self.width() - w) / 2, (self.height() - h) / 2
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
            p.drawPixmap(QRectF(x, y, w, h), self._pix, QRectF(0, 0, pw, ph))
        # 底部进度
        if len(self.slides) > 1:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 255, 255, 28))
            bar_w = min(self.width() * 0.46, 720)
            bx = (self.width() - bar_w) / 2
            by = self.height() - 26
            p.drawRoundedRect(QRectF(bx, by, bar_w, 2), 1, 1)
            p.setBrush(QColor(201, 168, 106, 220))
            p.drawRoundedRect(QRectF(bx, by, bar_w * (self.index + 1) / len(self.slides), 2), 1, 1)
            p.setPen(QColor(240, 236, 226, 120))
            p.setFont(QFont("Microsoft YaHei UI", 9))
            p.drawText(QRectF(bx, by - 22, bar_w, 16), Qt.AlignmentFlag.AlignCenter,
                       f"{self.index + 1} / {len(self.slides)}   ← → 翻页 · Esc 退出")

    # ---------- 交互 ----------
    def keyPressEvent(self, ev) -> None:
        k = ev.key()
        if k in (Qt.Key.Key_Right, Qt.Key.Key_Down, Qt.Key.Key_Space, Qt.Key.Key_PageDown):
            self._timer.stop()
            self.next()
        elif k in (Qt.Key.Key_Left, Qt.Key.Key_Up, Qt.Key.Key_PageUp, Qt.Key.Key_Backspace):
            self._timer.stop()
            self.prev()
        elif k in (Qt.Key.Key_Escape, Qt.Key.Key_Q):
            self.close()
        else:
            super().keyPressEvent(ev)

    def mousePressEvent(self, ev) -> None:
        if ev.button() == Qt.MouseButton.LeftButton:
            self.next()
        elif ev.button() == Qt.MouseButton.RightButton:
            self.prev()

    def closeEvent(self, ev) -> None:
        self._timer.stop()
        super().closeEvent(ev)


def show(slides: list[Path], auto_ms: int = 26000) -> int:
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("见微暮省")
    view = EveningViewer(slides, auto_ms=auto_ms)
    screen = QGuiApplication.primaryScreen()
    if screen is not None:
        view.setGeometry(screen.geometry())
    view.showFullScreen()
    view.raise_()
    view.activateWindow()
    return app.exec()


if __name__ == "__main__":
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    files = sorted(folder.glob("slide-*.png")) if folder else []
    raise SystemExit(0 if files and show(files) == 0 else 1)
