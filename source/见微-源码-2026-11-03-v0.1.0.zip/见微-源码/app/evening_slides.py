"""把暮省页逐页渲染成 PNG（无头 Edge），供见微自己的全屏播放器使用。

为什么不用浏览器窗口直接放：这台机器关闭了 UAC，所有进程都以管理员身份运行，
Edge/Chrome 在提权环境下会出白窗甚至不导航；而无头模式一直稳定。
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import time
from pathlib import Path

CODE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "Guanlan" / "evening"
SLIDE_DIR = RUNTIME_DIR / "slides"
INDEX = RUNTIME_DIR / "index.html"


def _edge() -> Path | None:
    cands = [
        Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft/Edge/Application/msedge.exe",
    ]
    for p in cands:
        if p.exists():
            return p
    return None


def count_slides(html: str) -> int:
    return len(re.findall(r'<(?:article|section)[^>]*class="slide\b', html))


def _screen_size() -> tuple[int, int]:
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        u = ctypes.windll.user32
        return int(u.GetSystemMetrics(0)) or 1920, int(u.GetSystemMetrics(1)) or 1080
    except Exception:
        return 1920, 1080


def _render_one(edge: Path, index_uri: str, out: Path, i: int, width: int, height: int, timeout: int) -> Path | None:
    prof = SLIDE_DIR / f"profile-{i:02d}"
    cmd = [
        str(edge), "--headless=new", "--disable-gpu", "--no-sandbox",
        "--hide-scrollbars", f"--user-data-dir={prof}",
        "--no-proxy-server", "--force-device-scale-factor=1",
        f"--window-size={width},{height}", f"--screenshot={out}",
        "--virtual-time-budget=3500", f"{index_uri}?preview=1&slide={i}",
    ]
    try:
        subprocess.run(cmd, capture_output=True, timeout=timeout,
                       creationflags=0x08000000 if os.name == "nt" else 0)
    except Exception:
        return None
    if out.exists() and out.stat().st_size > 8000:
        return out
    return None


def render(width: int = 0, height: int = 0, timeout: int = 40) -> list[Path]:
    """并发把每一页渲染成 PNG，返回按顺序的列表。"""
    if not width or not height:
        width, height = _screen_size()
    html = INDEX.read_text(encoding="utf-8", errors="replace")
    total = count_slides(html)
    edge = _edge()
    if not total or edge is None:
        return []
    SLIDE_DIR.mkdir(parents=True, exist_ok=True)
    for old in SLIDE_DIR.glob("slide-*.png"):
        try:
            old.unlink()
        except Exception:
            pass
    base = INDEX.as_uri()
    outs: dict[int, Path] = {}
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=4) as pool:
        futs = {
            pool.submit(_render_one, edge, base, SLIDE_DIR / f"slide-{i:02d}.png", i, width, height, timeout): i
            for i in range(total)
        }
        for fut, i in futs.items():
            try:
                got = fut.result()
            except Exception:
                got = None
            if got:
                outs[i] = got
    return [outs[i] for i in sorted(outs)]


def main() -> int:
    shots = render()
    print(f"rendered {len(shots)} slides -> {SLIDE_DIR}")
    return 0 if shots else 1


if __name__ == "__main__":
    raise SystemExit(main())
