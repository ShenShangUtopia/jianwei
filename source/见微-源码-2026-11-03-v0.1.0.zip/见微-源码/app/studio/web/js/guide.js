/* 见微 · 习题台 · 引导层
   把「解题步骤」从旁边的小字变成画面上的聚光 + 一句话说明；可自动播放，可单步。
   视图如果提供 focus(i)（返回画布坐标），引导层会在图上画圈、拉箭头、贴标签。 */
(function () {
  const JW = window.JW;
  const el = JW.el;

  function mount(stage, host) {
    const bar = el('div', { class: 'gd-bar' });
    bar.innerHTML =
      '<button type="button" class="gd-btn gd-prev" title="上一步">‹</button>' +
      '<button type="button" class="gd-btn gd-play" title="播放 / 暂停">▶</button>' +
      '<button type="button" class="gd-btn gd-next" title="下一步">›</button>' +
      '<div class="gd-text"><span class="gd-k">第 1 步</span><span class="gd-cap"></span></div>' +
      '<div class="gd-dots"></div>' +
      '<button type="button" class="gd-btn gd-replay" title="从头播放">重播</button>';
    stage.appendChild(bar);

    const cv = document.createElement('canvas');
    cv.className = 'gd-cv';
    host.appendChild(cv);
    const ctx = cv.getContext('2d');

    const api = {
      steps: [], index: 0, onStep: null, focus: null,
      playing: false, timer: 0, view: null
    };

    function size() {
      const r = host.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = Math.max(1, Math.round(r.width * dpr));
      cv.height = Math.max(1, Math.round(r.height * dpr));
      cv.style.width = r.width + 'px';
      cv.style.height = r.height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      api.w = r.width; api.h = r.height;
    }

    function pulsing(t) {
      const a = 0.55 + 0.45 * Math.sin(t / 380);
      return a;
    }

    function draw(ts) {
      if (!cv.isConnected) return;
      size();
      ctx.clearRect(0, 0, api.w, api.h);
      const f = api.focus;
      if (f && isFinite(f.x) && isFinite(f.y)) {
        const C = JW.C;
        const x = Math.max(10, Math.min(api.w - 10, f.x));
        const y = Math.max(10, Math.min(api.h - 10, f.y));
        const r = Math.max(16, Math.min(64, f.r || 26));
        const pulse = pulsing(ts || 0);
        // 聚光外圈
        ctx.save();
        ctx.strokeStyle = C.accent;
        ctx.globalAlpha = 0.25 + 0.35 * pulse;
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.beginPath(); ctx.arc(x, y, r + 6 + pulse * 5, 0, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]);
        ctx.globalAlpha = 0.85;
        ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
        // 四角准星
        ctx.globalAlpha = 0.5;
        [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (d) {
          const cx = x + d[0] * (r + 4), cy = y + d[1] * (r + 4);
          ctx.beginPath();
          ctx.moveTo(cx, cy - d[1] * 6); ctx.lineTo(cx, cy); ctx.lineTo(cx - d[0] * 6, cy);
          ctx.stroke();
        });
        ctx.restore();
        // 标签
        if (f.label) {
          ctx.font = '600 11px ' + C.sans;
          const tw = ctx.measureText(f.label).width + 14;
          const above = f.labelSide === 'above';
          const lx = above
            ? Math.max(6, Math.min(api.w - tw - 6, x - tw / 2))
            : Math.max(6, Math.min(api.w - tw - 6, x + r + 10));
          const ly = above
            ? Math.max(16, y - r - 24)
            : Math.max(20, Math.min(api.h - 8, y - 8));
          const night = document.documentElement.dataset.theme === 'night';
          ctx.fillStyle = night ? 'rgba(10,18,32,0.94)' : 'rgba(255,255,255,0.96)';
          ctx.strokeStyle = C.accent;
          ctx.lineWidth = 1;
          roundRect(ctx, lx, ly - 15, tw, 22, 8);
          ctx.fill(); ctx.stroke();
          ctx.fillStyle = C.accent;
          ctx.fillText(f.label, lx + 7, ly);
        }
      }
      if (api.playing) api.raf = requestAnimationFrame(draw);
    }

    function roundRect(c, x, y, w, h, r) {
      c.beginPath();
      c.moveTo(x + r, y);
      c.arcTo(x + w, y, x + w, y + h, r);
      c.arcTo(x + w, y + h, x, y + h, r);
      c.arcTo(x, y + h, x, y, r);
      c.arcTo(x, y, x + w, y, r);
      c.closePath();
    }

    function render() {
      const n = api.steps.length;
      bar.querySelector('.gd-k').textContent = n ? '第 ' + (api.index + 1) + ' / ' + n + ' 步' : '引导';
      const txt = api.steps[api.index];
      bar.querySelector('.gd-cap').textContent = txt ?
        (typeof txt === 'string' ? txt : (txt.text || txt.title || '')) : '这道题还没有分步说明';
      const dots = bar.querySelector('.gd-dots');
      dots.innerHTML = '';
      for (let i = 0; i < n; i++) {
        const d = el('button', { class: 'gd-dot' + (i === api.index ? ' on' : '') + (i < api.index ? ' past' : ''), type: 'button' });
        d.title = '第 ' + (i + 1) + ' 步';
        d.addEventListener('click', function (ev) { ev.stopPropagation(); pause(); api.go(i); });
        dots.appendChild(d);
      }
      bar.querySelector('.gd-prev').disabled = api.index <= 0;
      bar.querySelector('.gd-next').disabled = api.index >= n - 1;
      bar.querySelector('.gd-play').textContent = api.playing ? '❚❚' : '▶';
      bar.classList.toggle('is-empty', n === 0);
    }

    api.go = function (i) {
      i = Math.max(0, Math.min(api.steps.length - 1, i));
      api.index = i;
      api.focus = (api.view && typeof api.view.focus === 'function') ? safeFocus(i) : null;
      render();
      if (api.onStep) { try { api.onStep(i); } catch (e) { console.warn(e); } }
      if (!api.raf && !api.playing) draw(performance.now());
      if (api.playing) {
        cancelAnimationFrame(api.raf);
        api.raf = requestAnimationFrame(draw);
      }
    };

    function safeFocus(i) {
      try {
        const f = api.view.focus(i);
        if (!f) return null;
        return { x: f.x, y: f.y, r: f.r, label: f.label, labelSide: f.labelSide };
      } catch (e) { return null; }
    }

    function play() {
      if (!api.steps.length) return;
      api.playing = true;
      render();
      if (api.index >= api.steps.length - 1) api.go(0);
      cancelAnimationFrame(api.raf);
      api.raf = requestAnimationFrame(draw);
      clearInterval(api.timer);
      api.timer = setInterval(function () {
        if (!api.playing) return;
        if (api.index >= api.steps.length - 1) { pause(); return; }
        api.go(api.index + 1);
      }, 2400);
    }
    function pause() {
      api.playing = false;
      clearInterval(api.timer);
      cancelAnimationFrame(api.raf);
      api.raf = 0;
      render();
      draw(performance.now());
    }
    api.play = play;
    api.pause = pause;

    // 外部（播放器 / 右侧步骤）改步时同步，不反向调用 onStep
    api.sync = function (i) {
      i = Math.max(0, Math.min(api.steps.length - 1, i));
      api.index = i;
      api.focus = (api.view && typeof api.view.focus === 'function') ? safeFocus(i) : null;
      render();
      if (!api.playing) draw(performance.now());
    };

    api.set = function (opt) {
      api.steps = (opt.steps || []).slice(0, 9);
      api.view = opt.view || null;
      api.onStep = opt.onStep || null;
      api.index = Math.max(0, Math.min(api.steps.length - 1, opt.index || 0));
      api.focus = (api.view && typeof api.view.focus === 'function') ? safeFocus(api.index) : null;
      render();
      draw(performance.now());
    };

    bar.querySelector('.gd-prev').addEventListener('click', function () { pause(); api.go(api.index - 1); });
    bar.querySelector('.gd-next').addEventListener('click', function () { pause(); api.go(api.index + 1); });
    bar.querySelector('.gd-play').addEventListener('click', function () { api.playing ? pause() : play(); });
    bar.querySelector('.gd-replay').addEventListener('click', function () { api.go(0); play(); });
    // 鼠标进舞台就停自动播放（要把画面交还给人）
    host.addEventListener('pointerdown', function () { if (api.playing) pause(); }, true);

    new ResizeObserver(function () { draw(performance.now()); }).observe(host);
    render();
    draw(performance.now());
    return api;
  }

  window.JWGuide = { mount: mount };
})();
