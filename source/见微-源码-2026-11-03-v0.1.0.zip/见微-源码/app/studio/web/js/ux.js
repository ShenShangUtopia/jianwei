/* 见微 · 析题台 · 界面与操作体验（ux.js）
   只做自己的事：注入 ux.css、加浮层与抽屉开关、键盘快捷键、空态探测。
   不动既有模块的点击逻辑：快捷键通过 JWApp / 原生 click 复用它们。 */
(function () {
  'use strict';

  var doc = document;
  var root = doc.documentElement;
  var CSS_HREF = 'css/ux.css';
  var done = false;
  var lastFocus = null;

  function mk(tag, cls) {
    var n = doc.createElement(tag);
    if (cls) n.className = cls;
    return n;
  }

  function injectCss() {
    var links = doc.getElementsByTagName('link');
    for (var i = 0; i < links.length; i++) {
      if ((links[i].getAttribute('href') || '').indexOf('ux.css') >= 0) return;
    }
    var l = mk('link');
    l.id = 'ux-css';
    l.rel = 'stylesheet';
    l.href = CSS_HREF;
    (doc.head || root).appendChild(l);
  }

  /* ---------------- 匹配断点 ---------------- */
  var mqSide = window.matchMedia('(max-width:1279px)');
  var mqRail = window.matchMedia('(max-width:1024px)');

  /* ---------------- 顶栏高度 ---------------- */
  function syncTop() {
    var top = doc.getElementById('top');
    if (!top) return;
    var h = Math.round(top.getBoundingClientRect().height);
    if (h > 0) root.style.setProperty('--ux-top', h + 'px');
  }

  /* ---------------- 面板状态 ---------------- */
  function setSide(open) {
    if (open) setRail(false);
    root.classList.toggle('ux-side-open', !!open);
    var b = doc.getElementById('ux-side-btn');
    if (b) {
      b.classList.toggle('is-on', !!open);
      b.setAttribute('aria-expanded', open ? 'true' : 'false');
      b.setAttribute('aria-label', open ? '收起解析栏' : '打开解析栏');
      b.title = open ? '收起解析栏' : '打开解析栏';
      var lab = b.querySelector('span');
      if (lab) lab.textContent = open ? '收起' : '解析';
    }
  }

  function setRail(open) {
    if (open) setSide(false);
    root.classList.toggle('ux-rail-open', !!open);
    var b = doc.getElementById('ux-rail-btn');
    if (b) {
      b.classList.toggle('is-on', !!open);
      b.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    if (open) {
      var raf = window.requestAnimationFrame || function (f) { return setTimeout(f, 16); };
      raf(revealSelected);
    }
  }

  function closePanels() {
    setSide(false);
    setRail(false);
  }

  function setHelp(open) {
    var help = doc.getElementById('ux-help');
    if (!help) return;
    if (open) {
      lastFocus = doc.activeElement;
      help.hidden = false;
      var x = help.querySelector('.ux-hp-x');
      if (x) x.focus();
    } else {
      help.hidden = true;
      if (lastFocus && lastFocus.focus && doc.contains(lastFocus)) lastFocus.focus();
      lastFocus = null;
    }
    root.classList.toggle('ux-help-open', !!open);
  }

  /* ---------------- 构建自有节点 ---------------- */
  function build() {
    var top = doc.getElementById('top');
    var topRight = doc.getElementById('top-right');
    var importBtn = doc.getElementById('btn-import');

    /* 快捷键按钮（顶栏） */
    var helpBtn = mk('button');
    helpBtn.id = 'ux-help-btn';
    helpBtn.type = 'button';
    helpBtn.textContent = '?';
    helpBtn.title = '快捷键（?）';
    helpBtn.setAttribute('aria-label', '键盘快捷键');
    helpBtn.setAttribute('aria-keyshortcuts', '?');
    helpBtn.addEventListener('click', function () { setHelp(doc.getElementById('ux-help').hidden); });
    if (topRight) topRight.insertBefore(helpBtn, topRight.firstChild);

    /* 左栏下拉开关（窄窗） */
    var railBtn = mk('button');
    railBtn.id = 'ux-rail-btn';
    railBtn.type = 'button';
    railBtn.innerHTML = '<span>题目</span><svg viewBox="0 0 10 10" aria-hidden="true">' +
      '<path d="M2 3.6 5 6.6l3-3" fill="none" stroke="currentColor" stroke-width="1.3" ' +
      'stroke-linecap="round" stroke-linejoin="round"/></svg>';
    railBtn.setAttribute('aria-controls', 'rail');
    railBtn.setAttribute('aria-expanded', 'false');
    railBtn.title = '展开题目列表';
    railBtn.addEventListener('click', function () {
      setRail(!root.classList.contains('ux-rail-open'));
    });
    if (top && topRight) top.insertBefore(railBtn, topRight);

    /* 右栏抽屉开关（窄窗浮动） */
    var sideBtn = mk('button');
    sideBtn.id = 'ux-side-btn';
    sideBtn.type = 'button';
    sideBtn.innerHTML = '<span>解析</span><svg viewBox="0 0 10 10" aria-hidden="true">' +
      '<path d="M3.6 1.8 6.8 5l-3.2 3.2" fill="none" stroke="currentColor" stroke-width="1.4" ' +
      'stroke-linecap="round" stroke-linejoin="round"/></svg>';
    sideBtn.setAttribute('aria-controls', 'side');
    sideBtn.setAttribute('aria-expanded', 'false');
    sideBtn.title = '打开解析栏';
    sideBtn.addEventListener('click', function () {
      setSide(!root.classList.contains('ux-side-open'));
    });
    doc.body.appendChild(sideBtn);

    /* 抽屉工具条：窄窗时贴顶，滚动时内容从下面走过 */
    var side = doc.getElementById('side');
    if (side) {
      var bar = mk('div');
      bar.id = 'ux-drawer-bar';
      var barT = mk('span', 'ux-bar-t');
      barT.textContent = '本题解析';
      bar.appendChild(barT);
      side.insertBefore(bar, side.firstChild);
      if (window.MutationObserver) {
        new MutationObserver(function () {
          if (side.firstElementChild !== bar) side.insertBefore(bar, side.firstChild);
        }).observe(side, { childList: true });
      }
    }

    /* 遮罩 */
    var scrim = mk('div');
    scrim.id = 'ux-scrim';
    scrim.setAttribute('aria-hidden', 'true');
    scrim.addEventListener('click', closePanels);
    doc.body.appendChild(scrim);

    /* 快捷键面板 */
    var help = mk('div');
    help.id = 'ux-help';
    help.hidden = true;
    help.setAttribute('role', 'dialog');
    help.setAttribute('aria-modal', 'true');
    help.setAttribute('aria-labelledby', 'ux-help-title');
    help.addEventListener('click', function (e) { if (e.target === help) setHelp(false); });

    var hp = mk('div', 'ux-hp');
    var head = mk('div', 'ux-hp-h');
    var title = mk('b');
    title.id = 'ux-help-title';
    title.textContent = '键盘快捷键';
    var kicker = mk('span');
    kicker.textContent = 'KEYBOARD';
    var close = mk('button', 'ux-hp-x');
    close.type = 'button';
    close.textContent = '×';
    close.setAttribute('aria-label', '关闭快捷键面板');
    close.addEventListener('click', function () { setHelp(false); });
    head.appendChild(title);
    head.appendChild(kicker);
    head.appendChild(close);
    hp.appendChild(head);

    var rows = [
      { keys: ['←', '→'], desc: '上一步 / 下一步，跟着解题路径走' },
      { keys: ['空格'], desc: '播放 / 暂停动画', wide: true },
      { keys: ['I'], desc: '打开「导入题目」' },
      { keys: ['Esc'], desc: '关闭快捷键、抽屉与面板' },
      { keys: ['?'], desc: '打开或关闭这个面板' }
    ];
    rows.forEach(function (r) {
      var row = mk('div', 'ux-hr');
      var keys = mk('div', 'ux-keys');
      r.keys.forEach(function (k) {
        var kb = mk('kbd', 'ux-kbd' + (r.wide ? ' wide' : ''));
        kb.textContent = k;
        keys.appendChild(kb);
      });
      row.appendChild(keys);
      var d = mk('em');
      d.textContent = r.desc;
      row.appendChild(d);
      hp.appendChild(row);
    });

    var foot = mk('div', 'ux-hp-f');
    foot.textContent = '在输入框里输入时，快捷键自动让路。';
    hp.appendChild(foot);
    help.appendChild(hp);
    doc.body.appendChild(help);

    /* 导入按钮的快捷键标注 */
    if (importBtn) importBtn.setAttribute('aria-keyshortcuts', 'I');
  }

  /* ---------------- 键盘 ---------------- */
  function isTyping(t) {
    if (!t) return false;
    var tag = (t.tagName || '').toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable === true;
  }

  function hasModal() {
    return !!doc.querySelector('.ji-mask');
  }

  function stepBy(dir) {
    var lis = doc.querySelectorAll('#steps li');
    if (!lis.length) return;
    var cur = -1, i;
    for (i = 0; i < lis.length; i++) if (lis[i].classList.contains('is-on')) { cur = i; break; }
    var next = cur < 0 ? 0 : cur + dir;
    if (next < 0) next = 0;
    if (next > lis.length - 1) next = lis.length - 1;
    if (next === cur) return;
    if (window.JWApp && typeof window.JWApp.setStep === 'function') window.JWApp.setStep(next);
    else lis[next].click();
  }

  function togglePlay() {
    var b = doc.querySelector('.ph-play');
    if (!b) return false;
    b.click();
    return true;
  }

  function isNativeTarget(t) {
    return !!(t && t.closest && t.closest('button,a,summary,input,textarea,select,[contenteditable]'));
  }

  function onKey(e) {
    var t = e.target || doc.body;
    var key = e.key;

    if (key === 'Escape') {
      var help = doc.getElementById('ux-help');
      if (help && !help.hidden) { e.preventDefault(); setHelp(false); return; }
      if (root.classList.contains('ux-side-open') || root.classList.contains('ux-rail-open')) {
        e.preventDefault(); closePanels(); return;
      }
      return;
    }

    if (isTyping(t)) return;
    if (hasModal()) return;
    if (e.defaultPrevented) return;   // 播放器/视图已经处理（方向键、空格、R）

    /* 步骤条：Enter / 空格与点击等价 */
    var li = t.closest && t.closest('#steps li');
    if (li && (key === 'Enter' || key === ' ' || key === 'Spacebar')) {
      e.preventDefault();
      li.click();
      return;
    }

    /* ?：面板开着时也能关 */
    if (key === '?' || (key === '/' && e.shiftKey)) {
      e.preventDefault();
      var hp = doc.getElementById('ux-help');
      if (hp) setHelp(hp.hidden);
      return;
    }

    var helpOpen = doc.getElementById('ux-help') ? !doc.getElementById('ux-help').hidden : false;
    if (helpOpen) return;
    if (e.ctrlKey || e.altKey || e.metaKey) return;

    if (key === 'ArrowLeft' || key === 'ArrowRight') {
      if (root.classList.contains('ux-rail-open')) return;
      e.preventDefault();
      stepBy(key === 'ArrowRight' ? 1 : -1);
      return;
    }

    if (key === ' ' || key === 'Spacebar') {
      if (isNativeTarget(t)) return;
      if (togglePlay()) e.preventDefault();
      return;
    }

    if (key === 'i' || key === 'I') {
      var imp = doc.getElementById('btn-import');
      if (imp) { e.preventDefault(); imp.click(); }
    }
  }

  /* ---------------- 步骤条可聚焦 ---------------- */
  function markSteps() {
    var lis = doc.querySelectorAll('#steps li');
    for (var i = 0; i < lis.length; i++) {
      if (!lis[i].hasAttribute('tabindex')) {
        lis[i].tabIndex = 0;
        lis[i].setAttribute('role', 'button');
      }
    }
  }

  var stepsMO = null;

  /* ---------------- 左栏：把当前题滚进视野 ---------------- */
  function revealSelected() {
    var list = doc.getElementById('qlist');
    if (!list) return;
    var sel = list.querySelector('.qi.is-on');
    if (!sel) return;
    var lr = list.getBoundingClientRect();
    var sr = sel.getBoundingClientRect();
    if (!lr.height) return;
    var head = list.querySelector('.yr');
    var headH = head ? head.offsetHeight : 0;   // sticky 年份头会盖住列表顶部
    var topEdge = lr.top + headH + 6;
    var bottomEdge = lr.bottom - 6;
    if (sr.top < topEdge) list.scrollTop += (sr.top - topEdge);
    else if (sr.bottom > bottomEdge) list.scrollTop += (sr.bottom - bottomEdge);
  }

  /* ---------------- 空态 / 无选中 ---------------- */
  function detectStates() {
    var count = (window.JW && window.JW.questions) ? window.JW.questions.length : 0;
    if (count) root.removeAttribute('data-ux-empty');
    else root.setAttribute('data-ux-empty', '1');

    var qtitle = doc.getElementById('qtitle');
    var hasText = !!(qtitle && qtitle.textContent.trim());
    var selected = !!doc.querySelector('#qlist .qi.is-on');
    if (count && !hasText && !selected) root.setAttribute('data-ux-nosel', '1');
    else root.removeAttribute('data-ux-nosel');
    syncLab();
  }

  function syncLab() {
    var qtitle = doc.getElementById('qtitle');
    var txt = (qtitle && qtitle.textContent) || '';
    var isLab = /(^|[?&])lab(=|&|$)/.test(location.search) || /实验室/.test(txt);
    if (isLab) root.setAttribute('data-ux-lab', '1');
    else root.removeAttribute('data-ux-lab');
    if (!isLab && qtitle && qtitle.textContent.trim()) root.setAttribute('data-ux-open', '1');
    else root.removeAttribute('data-ux-open');
  }

  /* ---------------- 危险按钮标记（只标，不改别人） ---------------- */
  var DANGER = /删除|移除|清空|丢弃/;

  function tagDanger(scope) {
    if (!scope || !scope.querySelectorAll) return;
    var list = scope.querySelectorAll('button');
    for (var i = 0; i < list.length; i++) {
      if (DANGER.test((list[i].textContent || '').trim())) list[i].classList.add('ux-danger');
    }
  }

  /* ---------------- 初始化 ---------------- */
  function init() {
    if (done) return;
    done = true;

    try {
      injectCss();
      build();

      doc.addEventListener('keydown', onKey);

      var rail = doc.getElementById('rail');
      if (rail) {
        rail.addEventListener('click', function (e) {
          if (e.target.closest && e.target.closest('.qi')) setRail(false);
        });
      }

      var sideBtn = doc.getElementById('ux-side-btn');
      var railBtn = doc.getElementById('ux-rail-btn');
      var helpBtn = doc.getElementById('ux-help-btn');
      if (sideBtn) sideBtn.addEventListener('dblclick', function (e) { e.preventDefault(); });
      if (railBtn) railBtn.addEventListener('dblclick', function (e) { e.preventDefault(); });
      if (helpBtn) helpBtn.addEventListener('dblclick', function (e) { e.preventDefault(); });

      var steps = doc.getElementById('steps');
      if (steps && window.MutationObserver) {
        stepsMO = new MutationObserver(markSteps);
        stepsMO.observe(steps, { childList: true });
      }
      markSteps();

      var qtitle = doc.getElementById('qtitle');
      if (qtitle && window.MutationObserver) {
        new MutationObserver(function () {
          if (!doc.querySelector('#qlist .qi.is-on')) {
            if (qtitle.textContent.trim()) root.removeAttribute('data-ux-nosel');
          }
          syncLab();
        }).observe(qtitle, { childList: true, characterData: true, subtree: true });
      }

      var qlist = doc.getElementById('qlist');
      if (qlist && window.MutationObserver) {
        new MutationObserver(function () {
          if (qlist.querySelector('.qi')) root.removeAttribute('data-ux-empty');
          var raf = window.requestAnimationFrame || function (f) { return setTimeout(f, 16); };
          raf(revealSelected);
        }).observe(qlist, { childList: true });
      }

      if (window.MutationObserver) {
        new MutationObserver(function (recs) {
          recs.forEach(function (r) {
            for (var i = 0; i < r.addedNodes.length; i++) {
              var n = r.addedNodes[i];
              if (n.nodeType !== 1) continue;
              if (n.classList && (n.classList.contains('ji-mask') || n.classList.contains('ji-panel'))) tagDanger(n);
              else if (n.querySelector && n.querySelector('.ji-mask')) tagDanger(n);
            }
          });
        }).observe(doc.body, { childList: true });
      }

      var onMq = function () { applyMedia(); };
      if (mqSide.addEventListener) {
        mqSide.addEventListener('change', onMq);
        mqRail.addEventListener('change', onMq);
      } else {
        mqSide.addListener(onMq);
        mqRail.addListener(onMq);
      }
      window.addEventListener('resize', syncTop);
      if (window.ResizeObserver) {
        var top = doc.getElementById('top');
        if (top) new ResizeObserver(syncTop).observe(top);
      }

      applyMedia();

      /* 首帧之后再开过渡：避免窄窗首次打开时右栏“滑出去”闪一下 */
      var raf = window.requestAnimationFrame || function (f) { return setTimeout(f, 16); };
      raf(function () { raf(function () { root.classList.add('ux-anim'); }); });

      /* 等 app.js 的 boot 跑完再判断“没选中 / 空题库” */
      setTimeout(function () {
        detectStates();
        tagDanger(doc);
        syncTop();
        revealSelected();
        /* 调试/截图用：?ux=help|side|rail 直接打开对应浮层 */
        var m = /(?:^[?&]|&)ux=([a-z]+)/.exec(location.search);
        if (m) {
          if (m[1] === 'help') setHelp(true);
          else if (m[1] === 'side' && mqSide.matches) setSide(true);
          else if (m[1] === 'rail' && mqRail.matches) setRail(true);
        }
        root.setAttribute('data-ux-ready', '1');
      }, 0);
    } catch (err) {
      if (window.console && console.error) console.error('[ux]', err);
      root.setAttribute('data-ux-ready', 'err');
    }
  }

  function applyMedia() {
    if (!mqSide.matches) setSide(false);
    if (!mqRail.matches) setRail(false);
    syncTop();
  }

  window.JWUX = {
    openHelp: function () { setHelp(true); },
    closeHelp: function () { setHelp(false); },
    closeAll: closePanels,
    openSide: function (on) { setSide(on !== false); },
    openRail: function (on) { setRail(on !== false); },
    tagDanger: tagDanger
  };

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init);
  else init();
})();
