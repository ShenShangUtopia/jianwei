/* 见微 · 函数增强：性质分析（零点/驻点/极值/拐点/渐近线/单调/奇偶/周期/值域）
   视野平移与缩放、画布与控制栏比例、自定义函数输入、实验室按知识块进入。
   标记直接画在 graph 自己的 canvas 上（不用叠层，避免尺寸错位）。 */
(function () {
  const JW = window.JW, el = JW.el, C = JW.C;
  const KEY = 'jw.graphplus';
  const state = { split: 1, show: { zero: true, ext: true, inf: true, asym: true } };
  try { Object.assign(state, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { }
  function persist() { try { localStorage.setItem(KEY, JSON.stringify({ split: state.split, show: state.show })); } catch (e) { } }

  const fmt = (v, d) => {
    if (!isFinite(v)) return '—';
    const r = Math.abs(v) < 1e-9 ? 0 : v;
    const s = (Math.round(r * Math.pow(10, d == null ? 2 : d)) / Math.pow(10, d == null ? 2 : d)).toString();
    return s.replace('-', '−');
  };

  /* ================= 数值分析 ================= */
  function analyze(fn, xr, yr) {
    const N = 700, a = xr[0], b = xr[1], h = (b - a) / N;
    const span = Math.max(1e-9, yr[1] - yr[0]);
    const edge = span * 40 + 20;
    const xs = [], ys = [];
    for (let i = 0; i <= N; i++) {
      const x = a + h * i;
      let y = NaN;
      try { y = fn(x); } catch (e) { y = NaN; }
      xs.push(x);
      ys.push((isFinite(y) && Math.abs(y) < edge) ? y : NaN);
    }
    const d1 = i => (ys[i + 1] - ys[i - 1]) / (2 * h);
    const d2 = i => (ys[i + 1] - 2 * ys[i] + ys[i - 1]) / (h * h);
    const ok = i => isFinite(ys[i]);

    function bisect(f, lo, hi, iters) {
      let flo = f(lo), fhi = f(hi);
      if (!isFinite(flo) || !isFinite(fhi) || flo * fhi > 0) return null;
      let m = lo;
      for (let k = 0; k < (iters || 34); k++) {
        m = (lo + hi) / 2;
        const fm = f(m);
        if (!isFinite(fm)) return null;
        if (flo * fm <= 0) { hi = m; fhi = fm; } else { lo = m; flo = fm; }
      }
      return m;
    }

    const zeros = [];
    for (let i = 1; i < N; i++) {
      if (!ok(i) || !ok(i + 1)) continue;
      if (ys[i] === 0) { zeros.push(xs[i]); continue; }
      if (ys[i] * ys[i + 1] < 0) {
        const r = bisect(fn, xs[i], xs[i + 1]);
        if (r != null) zeros.push(r);
      }
    }
    const stat = [], maxs = [], mins = [];
    const dfn = x => {
      const t = Math.max(1e-7, h / 8);
      const y1 = fn(x - t), y2 = fn(x + t);
      return (y2 - y1) / (2 * t);
    };
    for (let i = 1; i < N; i++) {
      if (!ok(i - 1) || !ok(i) || !ok(i + 1)) continue;
      const a1 = d1(i - 1), a2 = d1(i + 1);
      if (!isFinite(a1) || !isFinite(a2) || a1 * a2 > 0) continue;
      const r = bisect(dfn, xs[i - 1], xs[i + 1]);
      if (r == null) continue;
      if (stat.some(v => Math.abs(v - r) < h * 1.5)) continue;
      stat.push(r);
      const s2 = d2(i);
      if (isFinite(s2)) {
        if (s2 < -1e-9) maxs.push(r);
        else if (s2 > 1e-9) mins.push(r);
      }
    }
    const inflect = [];
    for (let i = 2; i < N - 1; i++) {
      if (!ok(i - 1) || !ok(i) || !ok(i + 1)) continue;
      const b1 = d2(i - 1), b2 = d2(i + 1);
      if (!isFinite(b1) || !isFinite(b2) || b1 * b2 > 0) continue;
      const r = bisect(x => {
        const t = Math.max(1e-6, h);
        const f1 = (fn(x + t) - 2 * fn(x) + fn(x - t)) / (t * t);
        return isFinite(f1) ? f1 : NaN;
      }, xs[i - 1], xs[i + 1], 26);
      if (r != null && !inflect.some(v => Math.abs(v - r) < h * 1.5)) inflect.push(r);
    }
    const vert = [];
    const edgeGuard = (b - a) * 0.01;
    for (let i = 1; i < N; i++) {
      if (ok(i) && ok(i - 1)) continue;
      const x0 = xs[i];
      const yl = fn(x0 - h * 0.02), yr2 = fn(x0 + h * 0.02);
      if ((isFinite(yl) && Math.abs(yl) > span * 2) || (isFinite(yr2) && Math.abs(yr2) > span * 2) ||
        (!isFinite(yl) || !isFinite(yr2))) {
        if (x0 < a + edgeGuard || x0 > b - edgeGuard) continue;
        if (vert.length >= 4) break;
        if (!vert.some(v => Math.abs(v - x0) < (b - a) / 40)) vert.push(x0);
      }
    }
    const horiz = [];
    function tail(side) {
      const vals = [];
      for (let i = 0; i < 24; i++) {
        const idx = side === 'right' ? N - i : i;
        if (!isFinite(ys[idx])) return null;
        vals.push(ys[idx]);
      }
      const mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals);
      return (mx - mn < span * 0.008) ? (mn + mx) / 2 : null;
    }
    const hr = tail('right');
    if (hr != null) horiz.push(hr);
    const hl = tail('left');
    if (hl != null && (hr == null || Math.abs(hl - hr) > span * 0.01)) horiz.push(hl);

    const mono = [];
    let sign = 0, start = a;
    for (let i = 1; i < N; i++) {
      if (!ok(i)) { sign = 0; start = xs[i]; continue; }
      const d = d1(i);
      if (!isFinite(d) || Math.abs(d) < 1e-9) continue;
      const s = d > 0 ? 1 : -1;
      if (sign === 0) { sign = s; start = xs[i]; }
      else if (s !== sign) { mono.push({ a: start, b: xs[i], s: sign }); start = xs[i]; sign = s; }
    }
    if (sign !== 0) mono.push({ a: start, b: b, s: sign });

    let parity = '非奇非偶';
    {
      const lim = Math.min(Math.abs(a), Math.abs(b));
      if (lim > 0.6) {
        let even = true, odd = true, cnt = 0;
        for (let k = 1; k <= 24; k++) {
          const x = lim * k / 24;
          const f1 = fn(x), f2 = fn(-x);
          if (!isFinite(f1) || !isFinite(f2)) continue;
          cnt++;
          if (Math.abs(f1 - f2) > span * 0.01) even = false;
          if (Math.abs(f1 + f2) > span * 0.01) odd = false;
        }
        if (cnt >= 8) parity = even ? '偶函数' : odd ? '奇函数' : '非奇非偶';
      }
    }
    // 周期：先在采样序列里找最小滞后使 f(x+T)≈f(x)，比“极大值间距”稳
    let period = null;
    {
      const M = 240, base = [];
      for (let i = 0; i < M; i++) base.push(fn(a + (b - a) * i / M));
      const maxLag = Math.floor(M * 0.92);
      for (let lag = 6; lag <= maxLag; lag++) {
        let err = 0, cnt = 0;
        for (let i = 0; i + lag < M; i++) {
          const d = Math.abs(base[i] - base[i + lag]);
          if (isFinite(d)) { err += d; cnt++; }
        }
        if (cnt > M * 0.5 && err / cnt < span * 0.006) {
          const cand = (b - a) * lag / M;
          // 排除把 2 个周期误判成 1 个：取最小滞后即可
          period = cand;
          break;
        }
      }
      if (period == null && maxs.length >= 2) {
        const gaps = [];
        for (let i = 1; i < maxs.length; i++) gaps.push(maxs[i] - maxs[i - 1]);
        gaps.sort((p, q) => p - q);
        const med = gaps[Math.floor(gaps.length / 2)];
        if (med > h * 3) period = med;
      }
    }
    const finite = ys.filter(v => isFinite(v));
    const range = finite.length ? [Math.min.apply(null, finite), Math.max.apply(null, finite)] : null;
    return {
      zeros: zeros, stat: stat, maxs: maxs, mins: mins, inflect: inflect,
      vert: vert, horiz: horiz, mono: mono, parity: parity, period: period, range: range
    };
  }

  /* ================= 装饰一个 graph 视图 ================= */
  function decorate(root, host) {
    if (root.__gpx) return root.__gpx;
    const gx = host.__gx;
    if (!gx) return null;
    const side = root.querySelector('.gx-side');
    if (!side) return null;
    let last = null;
    let rowsEl = null;

    /* ---------- 性质卡 ---------- */
    const card = el('div', { class: 'gpx-panel' });
    card.innerHTML =
      '<div class="gpx-t gpx-toggle">函数性质<span class="gpx-sub">按当前视野实算</span></div>' +
      '<div class="gpx-body"><div class="gpx-rows"></div>' +
      '<div class="gpx-legend">' +
      '<span data-k="zero">零点</span><span data-k="ext">极值·驻点</span>' +
      '<span data-k="inf">拐点</span><span data-k="asym">渐近线</span></div></div>';
    side.insertBefore(card, side.firstChild);
    const isParamLab = (function () {
      try { return !!(gx.spec && gx.spec().lab); } catch (e) { return false; }
    })();
    if (isParamLab) {
      card.style.display = 'none';
      card.classList.add('is-fold');
    }
    rowsEl = card.querySelector('.gpx-rows');
    card.querySelector('.gpx-toggle').addEventListener('click', function () { card.classList.toggle('is-fold'); });
    Array.prototype.forEach.call(card.querySelectorAll('.gpx-legend span'), function (sp) {
      const k = sp.dataset.k;
      sp.classList.toggle('on', !!state.show[k]);
      sp.addEventListener('click', function () {
        state.show[k] = !state.show[k];
        sp.classList.toggle('on', state.show[k]);
        persist();
        repaint();
      });
    });

    /* ---------- 自定义函数 ---------- */
    const fnBox = el('div', { class: 'gpx-fn' });
    fnBox.innerHTML =
      '<div class="gpx-t">自定义函数</div>' +
      '<div class="gpx-fn-row"><input class="gpx-in" placeholder="如 2*sin(x)+1" spellcheck="false">' +
      '<button class="gpx-apply jw-btn" type="button">应用</button></div>' +
      '<div class="gpx-hint">支持 sin cos tan sqrt abs ln exp ^ π 与字母 A B H K</div>' +
      '<div class="gpx-err"></div>';
    side.insertBefore(fnBox, card.nextSibling);
    const input = fnBox.querySelector('.gpx-in');
    const errEl = fnBox.querySelector('.gpx-err');
    fnBox.querySelector('.gpx-apply').addEventListener('click', function () {
      const raw = String(input.value || '').trim();
      if (!raw) { errEl.textContent = '先写一个函数'; return; }
      const expr = raw.replace(/²/g, '^2').replace(/³/g, '^3').replace(/π/g, 'pi')
        .replace(/[−–]/g, '-').replace(/\s+/g, '');
      const probe = JW.compile(expr.replace(/\b[ABHK]\b/g, '1'));
      if (!isFinite(probe(0.7)) && !isFinite(probe(2.1))) { errEl.textContent = '这个式子算不出值，检查写法'; return; }
      errEl.textContent = '';
      const used = (expr.match(/\b[ABHK]\b/g) || []).filter((v, i, arr) => arr.indexOf(v) === i);
      const defaults = { A: 1, B: 1, H: 0, K: 0 };
      const params = used.map(k => ({
        k: k, label: ({ A: '纵向 A', B: '横向 B', H: '横移 H', K: '纵移 K' })[k] || k,
        min: (k === 'H' || k === 'K') ? -6 : 0.2, max: (k === 'H' || k === 'K') ? 6 : 4,
        step: 0.1, v: defaults[k] != null ? defaults[k] : 1
      }));
      const r = gx.range();
      window.JWApp.mountInto({
        id: 'custom-fn', subject: '数学', title: '自定义函数', stem: '', answer: '',
        steps: ['写出解析式', '看性质', '看图象'], points: ['自定义函数'],
        view: {
          engine: 'graph', mode: /sin|cos|tan/.test(expr) ? 'trig' : 'poly', expr: expr,
          params: params.length ? params : [{ k: 'A', label: '纵向 A', min: 0.2, max: 4, step: 0.1, v: 1 }],
          xr: r.xr.slice(), yr: r.yr.slice(),
          call: '拖动曲线平移 · 双指捏合缩放 · 下方按钮微调'
        }
      });
      const t = document.getElementById('qtitle');
      if (t) t.textContent = '自定义函数 · y = ' + raw;
    });
    // 调试用：?testfn=表达式 自动应用一次（不弹窗，仅供无头自测）
    (function () {
      const m = /[?&]testfn=([^&]+)/.exec(location.search);
      if (!m) return;
      setTimeout(function () {
        input.value = decodeURIComponent(m[1]);
        fnBox.querySelector('.gpx-apply').click();
      }, 700);
    })();

    /* ---------- 视野控制 ---------- */
    const plot = root.querySelector('.jw-plot');
    const grid = root.querySelector('.gx-grid');
    const pad = el('div', { class: 'gpx-pad' });
    pad.innerHTML =
      '<button type="button" data-a="left" title="视野左移">←</button>' +
      '<button type="button" data-a="up" title="视野上移">↑</button>' +
      '<button type="button" data-a="down" title="视野下移">↓</button>' +
      '<button type="button" data-a="right" title="视野右移">→</button>' +
      '<button type="button" data-a="in" title="视野放大">＋</button>' +
      '<button type="button" data-a="out" title="视野缩小">－</button>' +
      '<button type="button" data-a="vp" title="开启后按住拖动＝平移视野">视野</button>';
    plot.appendChild(pad);
    let vpMode = false;
    function panBy(fx, fy) {
      const r = gx.range();
      const dx = (r.xr[1] - r.xr[0]) * fx, dy = (r.yr[1] - r.yr[0]) * fy;
      gx.setRange([r.xr[0] + dx, r.xr[1] + dx], [r.yr[0] + dy, r.yr[1] + dy]);
      recomputeNow();
    }
    function zoomView(k) {
      const r = gx.range();
      const cx = (r.xr[0] + r.xr[1]) / 2, cy = (r.yr[0] + r.yr[1]) / 2;
      const hw = (r.xr[1] - r.xr[0]) / 2 * k, hh = (r.yr[1] - r.yr[0]) / 2 * k;
      gx.setRange([cx - hw, cx + hw], [cy - hh, cy + hh]);
      recomputeNow();
    }
    Array.prototype.forEach.call(pad.querySelectorAll('button'), function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        const a = b.dataset.a;
        if (a === 'vp') {
          vpMode = !vpMode;
          b.classList.toggle('on', vpMode);
          plot.classList.toggle('gpx-viewoff', vpMode);
          return;
        }
        if (a === 'left') panBy(-0.22, 0);
        else if (a === 'right') panBy(0.22, 0);
        else if (a === 'up') panBy(0, 0.22);
        else if (a === 'down') panBy(0, -0.22);
        else if (a === 'in') zoomView(1 / 1.22);
        else if (a === 'out') zoomView(1.22);
      });
    });

    let drag = null;
    plot.addEventListener('pointerdown', function (e) {
      if (!vpMode) return;
      const r = plot.getBoundingClientRect();
      drag = { x: e.clientX, y: e.clientY, w: r.width, h: r.height, range: gx.range() };
      try { plot.setPointerCapture(e.pointerId); } catch (err) { }
      e.stopPropagation(); e.preventDefault();
    }, true);
    plot.addEventListener('pointermove', function (e) {
      if (!drag) return;
      const dx = -(e.clientX - drag.x) / drag.w * (drag.range.xr[1] - drag.range.xr[0]);
      const dy = (e.clientY - drag.y) / drag.h * (drag.range.yr[1] - drag.range.yr[0]);
      gx.setRange([drag.range.xr[0] + dx, drag.range.xr[1] + dx],
        [drag.range.yr[0] + dy, drag.range.yr[1] + dy]);
      recomputeNow();
      e.stopPropagation();
    }, true);
    ['pointerup', 'pointercancel'].forEach(function (ev) {
      plot.addEventListener(ev, function () { drag = null; }, true);
    });

    /* ---------- 比例调节 ---------- */
    const split = el('div', { class: 'gpx-split', title: '拖动调整画布 / 控制栏比例' });
    plot.appendChild(split);
    function applySplit() {
      if (!grid || !grid.clientWidth) return;
      const avail = Math.max(300, grid.clientWidth - 210);
      const w = Math.max(340, Math.min(avail, Math.round(avail * (state.split || 1))));
      grid.style.gridTemplateColumns = w + 'px 210px';
      split.style.left = (w - 3) + 'px';
    }
    applySplit();
    let sd = false;
    split.addEventListener('pointerdown', function (e) {
      sd = true;
      try { split.setPointerCapture(e.pointerId); } catch (err) { }
      e.stopPropagation(); e.preventDefault();
    });
    split.addEventListener('pointermove', function (e) {
      if (!sd || !grid) return;
      const avail = Math.max(300, grid.clientWidth - 210);
      const w = Math.max(340, Math.min(avail, e.clientX - grid.getBoundingClientRect().left));
      state.split = w / avail;
      grid.style.gridTemplateColumns = w + 'px 210px';
      split.style.left = (w - 3) + 'px';
      e.stopPropagation();
    });
    ['pointerup', 'pointercancel'].forEach(function (ev) {
      split.addEventListener(ev, function () { if (sd) { sd = false; persist(); recomputeNow(); } });
    });

    /* ---------- 画布上的标记 ---------- */
    function paintMarkers(c) {
      if (!last || !c || !c.ctx || typeof c.px !== 'function' || typeof c.py !== 'function') return;
      const ctx = c.ctx, px = c.px, py = c.py;
      ctx.save();
      ctx.font = '10px ' + C.sans;
      function tag(x, y, text, color) {
        const tx = Math.max(2, Math.min(c.w - 56, x + 7));
        const ty = Math.max(11, Math.min(c.h - 4, y - 7));
        const w = ctx.measureText(text).width + 6;
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.fillRect(tx - 3, ty - 9, w, 13);
        ctx.fillStyle = color;
        ctx.fillText(text, tx, ty);
      }
      try {
        if (state.show.asym) {
          ctx.setLineDash([4, 4]);
          ctx.strokeStyle = 'rgba(107,122,153,0.5)';
          ctx.lineWidth = 1;
          last.vert.slice(0, 2).forEach(function (v, i) {
            ctx.beginPath(); ctx.moveTo(px(v), 0); ctx.lineTo(px(v), c.h); ctx.stroke();
            if (i === 0) tag(px(v), 14, 'x ≈ ' + fmt(v, 2), '#6B7A99');
          });
          last.horiz.slice(0, 2).forEach(function (v, i) {
            ctx.beginPath(); ctx.moveTo(0, py(v)); ctx.lineTo(c.w, py(v)); ctx.stroke();
            if (i === 0) tag(c.w * 0.62, py(v), 'y ≈ ' + fmt(v, 2), '#6B7A99');
          });
          ctx.setLineDash([]);
        }
        if (state.show.zero) {
          last.zeros.forEach(function (v, i) {
            ctx.beginPath(); ctx.arc(px(v), py(0), 3.2, 0, 7);
            ctx.fillStyle = C.ink; ctx.fill();
            if (i < 2) tag(px(v), py(0), '零点 ' + fmt(v, 2), '#081F5C');
          });
        }
        if (state.show.ext) {
          function ring(list, color, name, hex) {
            list.forEach(function (v, i) {
              let y = NaN;
              try { y = gx.fn()(v); } catch (e) { }
              if (!isFinite(y)) return;
              ctx.beginPath(); ctx.arc(px(v), py(y), 5.2, 0, 7);
              ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.stroke();
              if (i < 1) tag(px(v), py(y), name + ' (' + fmt(v, 2) + ', ' + fmt(y, 2) + ')', hex);
            });
          }
          ring(last.maxs, C.accent, '极大', '#B4553C');
          ring(last.mins, C.ink2, '极小', '#334EAC');
        }
        if (state.show.inf) {
          last.inflect.slice(0, 4).forEach(function (v, i) {
            let y = NaN;
            try { y = gx.fn()(v); } catch (e) { }
            if (!isFinite(y)) return;
            ctx.save();
            ctx.translate(px(v), py(y)); ctx.rotate(Math.PI / 4);
            ctx.strokeStyle = C.jade; ctx.lineWidth = 1.4;
            ctx.strokeRect(-2.5, -2.5, 5, 5);
            ctx.restore();
            if (i < 1) tag(px(v), py(y), '拐点 ' + fmt(v, 2), '#3F6F62');
          });
        }
      } catch (e) { console.warn('[gpx] markers', e); }
      ctx.restore();
    }
    function attachPainter() {
      if (isParamLab) return;
      const c = gx.canvas();
      if (!c || c.__gpxPainted) return;
      const base = c.render;
      c.render = function () {
        if (typeof base === 'function') { try { base(); } catch (e) { } }
        paintMarkers(c);
      };
      c.__gpxPainted = true;
    }
    function repaint() {
      const c = gx.canvas();
      if (c && typeof c.render === 'function') { try { c.render(); } catch (e) { } }
    }

    /* ---------- 面板与重算 ---------- */
    function row(label, value) {
      const d = el('div', { class: 'gpx-row' });
      d.innerHTML = '<span class="gpx-lb">' + label + '</span><span class="gpx-v">' + value + '</span>';
      return d;
    }
    function fnAt(x) { try { return gx.fn()(x); } catch (e) { return NaN; } }
    function renderRows(A) {
      rowsEl.innerHTML = '';
      if (!A) { rowsEl.appendChild(row('分析', '这个式子暂时算不出来')); return; }
      const zt = A.zeros.slice(0, 3).map(v => fmt(v, 2)).join('，') +
        (A.zeros.length > 3 ? ' 等 ' + A.zeros.length + ' 个' : '');
      rowsEl.appendChild(row('零点', zt || '无'));
      const ext = [];
      A.maxs.slice(0, 2).forEach(v => ext.push('极大 (' + fmt(v, 2) + ', ' + fmt(fnAt(v), 2) + ')'));
      A.mins.slice(0, 2).forEach(v => ext.push('极小 (' + fmt(v, 2) + ', ' + fmt(fnAt(v), 2) + ')'));
      rowsEl.appendChild(row('极值', ext.join('；') || '无'));
      rowsEl.appendChild(row('驻点', A.stat.slice(0, 3).map(v => fmt(v, 2)).join('，') || '无'));
      rowsEl.appendChild(row('拐点', A.inflect.slice(0, 3).map(v => fmt(v, 2) + ', ' + fmt(fnAt(v), 2)).join('，') || '无'));
      const asym = [];
      A.vert.slice(0, 2).forEach(v => asym.push('x ≈ ' + fmt(v, 2)));
      A.horiz.slice(0, 2).forEach(v => asym.push('y ≈ ' + fmt(v, 2)));
      rowsEl.appendChild(row('渐近线', asym.join('；') || '无'));
      rowsEl.appendChild(row('单调', A.mono.slice(0, 4).map(m => (m.s > 0 ? '增' : '减') + '(' + fmt(m.a, 1) + ',' + fmt(m.b, 1) + ')').join(' ') || '—'));
      rowsEl.appendChild(row('奇偶', A.parity));
      rowsEl.appendChild(row('周期', A.period ? fmt(A.period, 2) : '非周期/未检出'));
      rowsEl.appendChild(row('值域', A.range ? '[' + fmt(A.range[0], 2) + ', ' + fmt(A.range[1], 2) + ']' : '—'));
    }
    let timer = 0;
    function recompute() {
      if (timer) return;
      timer = setTimeout(function () { timer = 0; recomputeNow(); }, 20);
    }
    function recomputeNow() {
      if (isParamLab) return;
      try {
        const r = gx.range();
        last = analyze(gx.fn(), r.xr, r.yr);
        renderRows(last);
        attachPainter();
        repaint();
      } catch (e) { console.warn('[gpx] analyze', e); }
    }

    const form = root.querySelector('.jw-form');
    if (form) new MutationObserver(recompute).observe(form, { childList: true, subtree: true, characterData: true });
    new ResizeObserver(function () { applySplit(); recompute(); }).observe(plot);
    [80, 260, 700, 1400].forEach(function (ms) { setTimeout(recomputeNow, ms); });

    const api = { recompute: recomputeNow, state: state, split: applySplit };
    root.__gpx = api;
    return api;
  }

  /* ================= 实验室：按知识块 ================= */
  const LAB = [
    { g: '函数与导数', items: [
      { n: '一次函数', e: 'A*(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '二次函数', e: 'A*((x-H)/B)^2+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '三次函数', e: 'A*x^3+B*x^2+H*x+K', p: { A: 0.4, B: 1, H: 0, K: 0 } },
      { n: '反比例', e: 'A/(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } } ] },
    { g: '指数与对数', items: [
      { n: '指数函数', e: 'A*exp(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '对数函数', e: 'A*ln(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '幂函数', e: 'A*x^B+K', p: { A: 1, B: 1, H: 0, K: 0 } } ] },
    { g: '三角函数', items: [
      { n: '正弦型', e: 'A*sin(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '余弦型', e: 'A*cos(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '正切型', e: 'A*tan(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } } ] },
    { g: '解析几何', items: [
      { n: '抛物线', e: 'A*((x-H)/B)^2+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '双曲线一支', e: 'A*sqrt(1+((x-H)/B)^2)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '圆的上半', e: 'K+sqrt(A^2-(x-H)^2)', p: { A: 2, B: 1, H: 0, K: 0 } } ] },
    { g: '绝对值与分段', items: [
      { n: '绝对值', e: 'A*abs(B*x+H)+K', p: { A: 1, B: 1, H: 0, K: 0 } },
      { n: '双绝对值', e: 'A*abs(x+B)+H*abs(x-K)', p: { A: 1, B: 0, H: 0, K: 2 } } ] }
  ];
  function mountPreset(item) {
    const params = Object.keys(item.p).map(function (k) {
      return {
        k: k, label: ({ A: '伸缩 A', B: '横缩 B', H: '横移 H', K: '纵移 K' })[k] || k,
        min: (k === 'H' || k === 'K') ? -6 : 0.2, max: (k === 'H' || k === 'K') ? 6 : 4,
        step: 0.1, v: item.p[k]
      };
    });
    window.JWApp.mountInto({
      id: 'lab-' + Date.now(), subject: '数学', title: item.n, stem: '', answer: '',
      steps: ['写出解析式', '看图象变换', '看性质'], points: ['函数图象'],
      view: {
        engine: 'graph', mode: 'poly', expr: item.e, params: params, xr: [-6.6, 6.6], yr: [-4, 4],
        call: '拖动曲线平移 · 双指捏合缩放 · 下方按钮微调'
      }
    });
    const t = document.getElementById('qtitle');
    if (t) t.textContent = item.n + ' · y = ' + item.e;
  }
  function buildLabNav() {
    const rail = document.querySelector('#rail');
    if (!rail || rail.querySelector('.gpx-lab')) return;
    const box = el('div', { class: 'gpx-lab' });
    box.innerHTML = '<div class="gpx-lab-h">按知识块选择</div>';
    LAB.forEach(function (grp) {
      const g = el('div', { class: 'gpx-lab-g' });
      g.innerHTML = '<b>' + grp.g + '</b>';
      grp.items.forEach(function (it) {
        const b = el('button', { class: 'gpx-lab-i', type: 'button' }, it.n);
        b.addEventListener('click', function () { mountPreset(it); });
        g.appendChild(b);
      });
      box.appendChild(g);
    });
    const hint = el('div', { class: 'gpx-lab-h' }, '点一个知识块，直接换成对应函数');
    box.appendChild(hint);
    rail.appendChild(box);
    const tp = /[?&]testpreset=(\d+)/.exec(location.search);
    if (tp) {
      setTimeout(function () {
        const items = box.querySelectorAll('.gpx-lab-i');
        const it = items[Math.min(items.length - 1, parseInt(tp[1], 10))];
        if (it) it.click();
      }, 900);
    }
  }
  function clearLabNav() { const b = document.querySelector('.gpx-lab'); if (b) b.remove(); }
  function isLab() {
    const on = document.querySelector('#tabs .is-on');
    return (on && on.textContent === '变换实验室') || new URLSearchParams(location.search).get('lab') === '1';
  }

  function watch() {
    const host = document.getElementById('view-host');
    if (!host) return;
    function tick() {
      const roots = host.querySelectorAll('.gx-root');
      Array.prototype.forEach.call(roots, function (root) {
        if (root.__gpx) return;
        let gxHost = host;
        if (!gxHost.__gx) {
          const p = root.parentElement;
          if (p && p.__gx) gxHost = p;
        }
        if (gxHost.__gx) decorate(root, gxHost);
      });
      if (isLab()) buildLabNav(); else clearLabNav();
    }
    new MutationObserver(tick).observe(host, { childList: true });
    const tabs = document.getElementById('tabs');
    if (tabs) new MutationObserver(tick).observe(tabs, { childList: true, subtree: true, attributes: true });
    tick();
    setInterval(tick, 1200);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch);
  else watch();
})();
