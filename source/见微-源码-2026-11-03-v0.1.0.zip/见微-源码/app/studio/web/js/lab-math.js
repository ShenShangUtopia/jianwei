/* 见微 · 变换实验室 · 数学引擎
   自由画板 + 坐标系 + 仿射变换。
   核心模型：每个点 / 曲线自己保存“原像坐标 + 累计仿射矩阵 m”，
   实线画当前像，虚线画原像 ghost；右侧与画布同时显示 3×3 变换矩阵。
   契约：window.JWLabMath = { mount(shell) -> { resize, activate, exportPNG } } */
(function () {
  'use strict';
  const JW = window.JW;
  if (!JW || !JW.el || !JW.compile) return;
  const el = JW.el;
  const PI = Math.PI, TAU = PI * 2;
  const IDENT = [1, 0, 0, 0, 1, 0, 0, 0, 1];
  const SAVE_KEY = 'jw.lab.math';

  const TYPE_NAMES = {
    point: '点', segment: '线段', line: '直线', circle: '圆', polygon: '多边形',
    vector: '向量', function: '函数', mdist: '距离', mangle: '角度', marea: '面积'
  };

  /* 颜色只存“键”，切主题时由 JW.C 重新解析，避免写死日间色 */
  const COLOR_KEYS = [
    ['accent', '朱砂'], ['jade', '青瓷'], ['ink2', '靛蓝'],
    ['data1', '雾蓝'], ['gold', '金']
  ];

  const PRESETS = [
    { id: 'triangle', name: '三角形变换演示', desc: '幽灵原图 + 四种一键演示' },
    { id: 'quadratic', name: '二次函数', desc: 'y = a(x−h)² + k' },
    { id: 'trig', name: '三角函数', desc: 'y = A sin(Bx+φ) + k' },
    { id: 'inverse', name: '反比例', desc: 'y = k / x' },
    { id: 'circletangent', name: '圆与切线', desc: '切点、半径与切线方程' }
  ];

  const ICONS = {
    select: '<path d="M5 3.5l13.2 7-5.6 1.5-2.1 5.5z"/>',
    point: '<circle cx="12" cy="12" r="3.3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
    segment: '<path d="M5 18.5L19 5.5"/><circle cx="5" cy="18.5" r="2"/><circle cx="19" cy="5.5" r="2"/>',
    line: '<path d="M3.5 20.5L20.5 3.5"/><path d="M3 8.5h18" opacity=".28"/>',
    circle: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="1.1" fill="currentColor" stroke="none"/>',
    polygon: '<path d="M12 3.8l8.2 6-3.1 9.7H6.9L3.8 9.8z"/><circle cx="12" cy="3.8" r="1.1" fill="currentColor" stroke="none"/><circle cx="20.2" cy="9.8" r="1.1" fill="currentColor" stroke="none"/><circle cx="6.9" cy="19.5" r="1.1" fill="currentColor" stroke="none"/>',
    vector: '<path d="M4 19L18.5 4.5"/><path d="M12 4.5h6.5V11"/>',
    func: '<path d="M3.5 18.5c3.7-1 3.4-11.6 8.1-11.6 3.2 0 2.7 6.9 8.9 6.9"/>',
    measure: '<path d="M4 17.2L16.8 4.4l2.8 2.8L6.8 20z"/><path d="M8.4 14.6l2 2M11.6 11.4l2 2M14.8 8.2l2 2"/>',
    undo: '<path d="M9 7L4 12l5 5"/><path d="M4 12h10a5 5 0 0 1 0 10h-2"/>',
    redo: '<path d="M15 7l5 5-5 5"/><path d="M20 12H10a5 5 0 0 0 0 10h2"/>',
    trash: '<path d="M4.5 7h15M9 7V4.5h6V7M6.5 7l.8 13h9.4l.8-13M10 11v5M14 11v5"/>',
    export: '<path d="M12 3.5v11M7.5 10L12 14.5 16.5 10"/><path d="M4.5 16.5v3h15v-3"/>',
    zoomIn: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M10.5 7.5v6M7.5 10.5h6"/>',
    zoomOut: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M7.5 10.5h6"/>',
    reset: '<path d="M4.5 9.5V4.5h5M19.5 14.5v5h-5"/><path d="M5.2 14.2A7.2 7.2 0 0 0 18.7 16M18.8 9.8A7.2 7.2 0 0 0 5.3 8"/>',
    eye: '<path d="M2.5 12S6 6.2 12 6.2 21.5 12 21.5 12 18 17.8 12 17.8 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.6"/>',
    eyeOff: '<path d="M3.5 4.5l17 15"/><path d="M9.2 7.1A10.6 10.6 0 0 1 12 6.2c6 0 9.5 5.8 9.5 5.8a17.2 17.2 0 0 1-3.2 3.9M6.2 8.6A16.4 16.4 0 0 0 2.5 12S6 17.8 12 17.8c1.2 0 2.3-.2 3.3-.6"/>',
    chevron: '<path d="M8 5l7 7-7 7"/>'
  };

  const state = {
    w: 0, h: 0, dpr: 1,
    view: { cx: 0, cy: 0, scale: 52 },
    objects: [],
    selection: [],
    tool: 'select',
    draft: null,
    handle: null,
    measureMode: 'dist',
    measurePicks: [],
    pivotMode: 'origin',
    axisMode: 'x',
    preset: '',
    params: {},
    lastTransform: null,
    showGrid: true,
    snapGrid: true,
    showMeasure: true,
    showAnnotation: true,
    hover: null,
    snapInfo: null,
    pointer: null,
    pinch: null
  };

  const history = { past: [], future: [], limit: 64 };
  const fingers = new Map();

  let shellRef = null;
  let cv = null, ctx = null;
  let resizeObs = null;
  let rafId = 0;
  let saveTimer = 0;
  let seq = 0;
  let refs = {};
  let booted = false;
  let testRunning = false;

  /* ================= 小工具 ================= */
  function pal() { return JW.C; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function near(a, b, tol) { return Math.abs(a - b) <= (tol == null ? 1e-6 : tol); }
  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function uid(prefix) {
    seq += 1;
    return prefix + '_' + Date.now().toString(36) + seq.toString(36);
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function truncate(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  }
  function prettyExpr(expr) {
    return String(expr == null ? '' : expr).replace(/\(PI\)/g, 'π').replace(/\bPI\b/g, 'π');
  }
  function fmt(v, d) {
    return JW.num(v, d == null ? 2 : d);
  }
  function fmtM(v) {
    const r = Math.round(v * 1000) / 1000;
    return String(Object.is(r, -0) ? 0 : r);
  }
  function fmtAngle(rad) {
    return fmt(JW.deg(rad), 1) + '°';
  }
  function fmtPt(p) {
    return '(' + fmt(p.x, 2) + ', ' + fmt(p.y, 2) + ')';
  }
  function colorOf(key) {
    const C = pal();
    switch (key) {
      case 'accent': return C.accent;
      case 'jade': return C.jade;
      case 'ink': return C.ink;
      case 'ink2': return C.ink2;
      case 'gold': return C.gold;
      case 'soft': return C.soft;
      case 'faint': return C.faint;
      case 'data0': return (C.data && C.data[0]) || C.ink;
      case 'data1': return (C.data && C.data[1]) || C.ink2;
      case 'data2': return (C.data && C.data[2]) || C.ink2;
      default: return C.ink2;
    }
  }

  /* ================= 仿射矩阵 ================= */
  function matMul(A, B) {
    const C = new Array(9);
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        C[r * 3 + c] = A[r * 3] * B[c] + A[r * 3 + 1] * B[3 + c] + A[r * 3 + 2] * B[6 + c];
      }
    }
    return C;
  }
  function applyM(m, x, y) {
    m = m || IDENT;
    return { x: m[0] * x + m[1] * y + m[2], y: m[3] * x + m[4] * y + m[5] };
  }
  function invertM(m) {
    m = m || IDENT;
    const a = m[0], b = m[1], c = m[2], d = m[3], e = m[4], f = m[5];
    const det = a * e - b * d;
    if (!isFinite(det) || Math.abs(det) < 1e-12) return IDENT.slice();
    const ia = e / det, ib = -b / det, id = -d / det, ie = a / det;
    return [ia, ib, -(ia * c + ib * f), id, ie, -(id * c + ie * f), 0, 0, 1];
  }
  function isI(m) {
    if (!m) return true;
    for (let i = 0; i < 9; i++) if (!near(m[i], IDENT[i], 1e-6)) return false;
    return true;
  }
  function translateM(dx, dy) { return [1, 0, dx, 0, 1, dy, 0, 0, 1]; }
  function rotateM(rad, p) {
    const cs = Math.cos(rad), sn = Math.sin(rad);
    return [cs, -sn, p.x - cs * p.x + sn * p.y, sn, cs, p.y - sn * p.x - cs * p.y, 0, 0, 1];
  }
  function scaleM(k, p) {
    return [k, 0, p.x - k * p.x, 0, k, p.y - k * p.y, 0, 0, 1];
  }
  function reflectPointM(p) {
    return [-1, 0, 2 * p.x, 0, -1, 2 * p.y, 0, 0, 1];
  }
  function reflectLineM(a, b) {
    let dx = b.x - a.x, dy = b.y - a.y;
    const len = Math.hypot(dx, dy) || 1;
    dx /= len; dy /= len;
    const cs = dx * dx - dy * dy, sn = 2 * dx * dy;
    return [cs, sn, a.x - (cs * a.x + sn * a.y), sn, -cs, a.y - (sn * a.x - cs * a.y), 0, 0, 1];
  }
  function matrixRows(m) {
    m = m || IDENT;
    const rows = [];
    for (let r = 0; r < 3; r++) {
      const inner = '[' + fmtM(m[r * 3]) + ', ' + fmtM(m[r * 3 + 1]) + ', ' + fmtM(m[r * 3 + 2]) + ']';
      rows.push((r === 0 ? '[' : ' ') + inner + (r === 2 ? ']' : ','));
    }
    return rows;
  }

  /* ================= 对象 ================= */
  function byId(id) {
    for (let i = 0; i < state.objects.length; i++) if (state.objects[i].id === id) return state.objects[i];
    return null;
  }
  function findRole(role) {
    for (let i = 0; i < state.objects.length; i++) if (state.objects[i].role === role) return state.objects[i];
    return null;
  }
  function nextPointName() {
    const used = new Set();
    state.objects.forEach(function (o) {
      if (o.type === 'point' && o.name) used.add(o.name);
    });
    for (let i = 0; i < 676; i++) {
      let s = '', n = i;
      while (n >= 0) {
        s = String.fromCharCode(65 + (n % 26)) + s;
        n = Math.floor(n / 26) - 1;
      }
      if (!used.has(s)) return s;
    }
    return 'P' + state.objects.length;
  }
  function refIds(o) {
    if (!o) return [];
    if (o.type === 'point') return [o.id];
    if (o.type === 'segment' || o.type === 'line' || o.type === 'vector') return [o.a, o.b].filter(Boolean);
    if (o.type === 'circle') return [o.c, o.r].filter(Boolean);
    if (o.type === 'polygon') return (o.pts || []).slice();
    if (o.type === 'mdist') return [o.a, o.b].filter(Boolean);
    if (o.type === 'mangle') return [o.a, o.b, o.c].filter(Boolean);
    if (o.type === 'marea') return [o.poly].filter(Boolean);
    return [];
  }
  function depPoints(o) {
    return refIds(o).map(byId).filter(function (p) { return p && p.type === 'point'; });
  }
  function curOfPoint(p) {
    if (!p || p.type !== 'point') return null;
    return applyM(p.m, p.x, p.y);
  }
  function curOfId(id) {
    const o = byId(id);
    return o && o.type === 'point' ? curOfPoint(o) : null;
  }
  function currentCircle(o) {
    const c = curOfId(o.c), rp = curOfId(o.r);
    if (!c || !rp) return null;
    return { c: c, r: Math.hypot(rp.x - c.x, rp.y - c.y) };
  }
  function segmentLen(o) {
    const a = curOfId(o.a), b = curOfId(o.b);
    return a && b ? Math.hypot(b.x - a.x, b.y - a.y) : 0;
  }
  function polygonArea(o) {
    const pts = (o.pts || []).map(curOfId).filter(Boolean);
    if (pts.length < 3) return 0;
    let s = 0;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i], q = pts[(i + 1) % pts.length];
      s += p.x * q.y - q.x * p.y;
    }
    return Math.abs(s) / 2;
  }
  function polygonPerimeter(o) {
    const pts = (o.pts || []).map(curOfId).filter(Boolean);
    let s = 0;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i], q = pts[(i + 1) % pts.length];
      s += Math.hypot(q.x - p.x, q.y - p.y);
    }
    return s;
  }
  function centroidOf(pts) {
    if (!pts.length) return { x: 0, y: 0 };
    let x = 0, y = 0;
    pts.forEach(function (p) { x += p.x; y += p.y; });
    return { x: x / pts.length, y: y / pts.length };
  }
  function objectLabel(o) {
    if (!o) return '对象';
    if (o.type === 'point') return o.name || 'P';
    if (o.type === 'segment' || o.type === 'line' || o.type === 'vector') {
      if (o.name) return o.name;
      const a = byId(o.a), b = byId(o.b);
      return (a && a.name ? a.name : 'A') + (b && b.name ? b.name : 'B');
    }
    if (o.type === 'circle') {
      const c = byId(o.c);
      return '⊙' + (c && c.name ? c.name : 'O');
    }
    if (o.type === 'polygon') {
      const names = (o.pts || []).map(function (id) { const p = byId(id); return p && p.name ? p.name : ''; }).join('');
      return names.length === 3 ? '△' + names : names || '多边形';
    }
    if (o.type === 'function') return 'f(x) = ' + truncate(prettyExpr(o.expr), 14);
    if (o.type === 'mdist') return '距离 ' + (byId(o.a) || {}).name + (byId(o.b) || {}).name;
    if (o.type === 'mangle') return '∠' + (byId(o.a) || {}).name + (byId(o.b) || {}).name + (byId(o.c) || {}).name;
    if (o.type === 'marea') {
      const p = byId(o.poly);
      return '面积 ' + (p ? objectLabel(p) : '');
    }
    return TYPE_NAMES[o.type] || '对象';
  }
  function objectMeta(o) {
    if (!o) return '';
    if (o.type === 'point') return fmtPt(curOfPoint(o));
    if (o.type === 'segment') return '长度 ' + fmt(segmentLen(o), 2);
    if (o.type === 'line') return '过两点';
    if (o.type === 'vector') {
      const a = curOfId(o.a), b = curOfId(o.b);
      return a && b ? '分量 (' + fmt(b.x - a.x, 2) + ', ' + fmt(b.y - a.y, 2) + ')' : '';
    }
    if (o.type === 'circle') {
      const c = currentCircle(o);
      return c ? 'r = ' + fmt(c.r, 2) : '';
    }
    if (o.type === 'polygon') return (o.pts || []).length + ' 个顶点';
    if (o.type === 'function') return 'y = ' + truncate(prettyExpr(o.expr), 22);
    if (o.type === 'mdist') return fmt(segmentLen({ a: o.a, b: o.b }), 2);
    if (o.type === 'mangle') return fmtAngle(angleOf(o));
    if (o.type === 'marea') {
      const p = byId(o.poly);
      return p ? 'S = ' + fmt(polygonArea(p), 2) : '';
    }
    return '';
  }
  function objectColor(o) {
    if (!o) return colorOf('ink2');
    if (o.type === 'mdist' || o.type === 'mangle' || o.type === 'marea') return colorOf('accent');
    return colorOf(o.color || 'ink2');
  }
  function createPoint(x, y, opt) {
    opt = opt || {};
    const o = {
      id: uid('p'), type: 'point', x: x, y: y, m: (opt.m || IDENT).slice(),
      name: opt.name || nextPointName(), color: opt.color || 'ink2', width: 1,
      hidden: false, aux: !!opt.aux, role: opt.role || '', dash: false
    };
    state.objects.push(o);
    return o;
  }
  function createShape(type, data, opt) {
    opt = opt || {};
    const defColor = (type === 'circle' || type === 'polygon') ? 'jade' : 'ink2';
    const o = Object.assign({
      id: uid(type.slice(0, 2)), type: type, color: opt.color || defColor,
      width: opt.width || 2, hidden: false, aux: !!opt.aux, role: opt.role || '',
      dash: !!opt.dash
    }, data || {});
    state.objects.push(o);
    return o;
  }
  function setPointBase(p, x, y) {
    if (!p) return;
    p.x = x; p.y = y;
  }
  function normalizeExpr(raw) {
    let s = String(raw == null ? '' : raw).trim();
    s = s.replace(/^y\s*=\s*/i, '').replace(/^f\s*\(\s*x\s*\)\s*=\s*/i, '');
    s = s.replace(/²/g, '^2').replace(/³/g, '^3').replace(/−/g, '-').replace(/·/g, '*');
    // π 换成带括号的 PI，πx / 2π 这类写法才能被安全地解开乘法
    s = s.replace(/π/g, '(PI)');
    return s;
  }
  function compileExpr(expr) {
    const fn = JW.compile(expr);
    let ok = false;
    [0.37, 1, 2].forEach(function (x) {
      const y = fn(x);
      if (isFinite(y)) ok = true;
    });
    if (!ok) throw new Error('表达式没有可绘制的实数值');
    return fn;
  }
  function addFunction(expr, opt) {
    opt = opt || {};
    expr = normalizeExpr(expr);
    if (!expr) throw new Error('请输入函数表达式');
    const fn = compileExpr(expr);
    const o = {
      id: uid('fn'), type: 'function', expr: expr, fn: fn, m: IDENT.slice(),
      color: opt.color || 'data1', width: opt.width || 2.2, hidden: false,
      aux: !!opt.aux, role: opt.role || '', dash: false
    };
    state.objects.push(o);
    return o;
  }
  function setFunctionExpr(o, expr) {
    if (!o) return null;
    const fn = compileExpr(expr);
    o.expr = normalizeExpr(expr);
    o.fn = fn;
    return o;
  }
  function stripObject(o) {
    const c = Object.assign({}, o);
    delete c.fn;
    if (c.m) c.m = c.m.slice();
    return c;
  }
  function hydrateObject(o) {
    if (!o) return o;
    if (o.type === 'function') {
      try { o.fn = JW.compile(o.expr); } catch (e) { o.fn = function () { return NaN; }; }
    }
    if (!o.m) o.m = IDENT.slice();
    return o;
  }

  /* ================= 视觉坐标 ================= */
  function X(x) { return state.w / 2 + (x - state.view.cx) * state.view.scale; }
  function Y(y) { return state.h / 2 - (y - state.view.cy) * state.view.scale; }
  function worldAt(sx, sy) {
    return {
      x: state.view.cx + (sx - state.w / 2) / state.view.scale,
      y: state.view.cy - (sy - state.h / 2) / state.view.scale
    };
  }
  function screenOf(p) { return { x: X(p.x), y: Y(p.y) }; }
  function niceStep(pxPerUnit, target) {
    const raw = Math.max(1e-9, target / pxPerUnit);
    const p = Math.pow(10, Math.floor(Math.log10(raw)));
    const n = raw / p;
    const m = n <= 1.2 ? 1 : n <= 2.2 ? 2 : n <= 5.2 ? 5 : 10;
    return m * p;
  }
  function gridSteps() {
    const major = niceStep(state.view.scale, 58);
    return { major: major, minor: major / 5 };
  }
  function tickText(v, step) {
    const dec = step >= 1 ? 0 : Math.min(3, Math.max(0, Math.ceil(-Math.log10(step))));
    return JW.num(v, dec);
  }
  function setView(nv) {
    if (!nv) return;
    if (isNum(nv.cx)) state.view.cx = nv.cx;
    if (isNum(nv.cy)) state.view.cy = nv.cy;
    if (isNum(nv.scale)) state.view.scale = clamp(nv.scale, 5, 420);
  }
  function fitView() {
    const b = selectionBoundsAll();
    if (!b || !isFinite(b.minX)) { state.view = { cx: 0, cy: 0, scale: 52 }; }
    else {
      const pad = 92;
      const sw = Math.max(0.8, b.maxX - b.minX), sh = Math.max(0.8, b.maxY - b.minY);
      state.view.scale = clamp(Math.min((state.w - pad) / sw, (state.h - pad) / sh), 6, 240);
      state.view.cx = (b.minX + b.maxX) / 2;
      state.view.cy = (b.minY + b.maxY) / 2;
    }
    scheduleRender(); scheduleSave();
  }
  function selectionBoundsAll() {
    const xs = [], ys = [];
    const seen = new Set();
    function addPt(p) {
      if (!p || !isFinite(p.x) || !isFinite(p.y)) return;
      xs.push(p.x); ys.push(p.y);
    }
    state.objects.forEach(function (o) {
      if (o.hidden || o.aux) return;
      if (o.type === 'point') addPt(curOfPoint(o));
      else if (o.type === 'function') {
        for (let i = 0; i <= 80; i++) {
          const x = -8 + i * 16 / 80;
          const y = o.fn(x);
          if (isFinite(y)) addPt(applyM(o.m, x, y));
        }
      } else {
        depPoints(o).forEach(function (p) { addPt(curOfPoint(p)); });
      }
      if (o.type === 'circle') {
        const c = currentCircle(o);
        if (c) { addPt({ x: c.c.x - c.r, y: c.c.y - c.r }); addPt({ x: c.c.x + c.r, y: c.c.y + c.r }); }
      }
    });
    if (!xs.length) return null;
    return { minX: Math.min.apply(null, xs), maxX: Math.max.apply(null, xs), minY: Math.min.apply(null, ys), maxY: Math.max.apply(null, ys) };
  }
  function selectionBounds() {
    const xs = [], ys = [];
    const ids = expandSelection(state.selection);
    ids.forEach(function (id) {
      const o = byId(id);
      if (!o || o.hidden) return;
      if (o.type === 'point') {
        const p = curOfPoint(o); if (p) { xs.push(p.x); ys.push(p.y); }
      } else if (o.type === 'function') {
        for (let i = 0; i <= 60; i++) {
          const x = -6 + i * 12 / 60, y = o.fn(x);
          if (isFinite(y)) { const p = applyM(o.m, x, y); xs.push(p.x); ys.push(p.y); }
        }
      }
    });
    // 圆的对象中心应按整圆包围盒算，而不是“圆心 + 半径点”的包围盒
    state.selection.forEach(function (id) {
      const o = byId(id);
      if (o && o.type === 'circle' && !o.hidden) {
        const c = currentCircle(o);
        if (c) { xs.push(c.c.x - c.r); xs.push(c.c.x + c.r); ys.push(c.c.y - c.r); ys.push(c.c.y + c.r); }
      }
    });
    if (!xs.length) return null;
    return { minX: Math.min.apply(null, xs), maxX: Math.max.apply(null, xs), minY: Math.min.apply(null, ys), maxY: Math.max.apply(null, ys) };
  }
  function getPivot() {
    if (state.pivotMode === 'center') {
      const b = selectionBounds();
      if (b) return { x: (b.minX + b.maxX) / 2, y: (b.minY + b.maxY) / 2 };
      return { x: state.view.cx, y: state.view.cy };
    }
    if (state.pivotMode.indexOf('point:') === 0) {
      const p = byId(state.pivotMode.slice(6));
      const c = p ? curOfPoint(p) : null;
      if (c) return c;
    }
    return { x: 0, y: 0 };
  }
  function pivotLabel(p) {
    return '(' + fmt(p.x, 2) + ', ' + fmt(p.y, 2) + ')';
  }
  function selectionMatrix() {
    for (let i = 0; i < state.selection.length; i++) {
      const o = byId(state.selection[i]);
      if (!o) continue;
      if (o.type === 'point') return o.m || IDENT;
      if (o.type === 'function') return o.m || IDENT;
      const p = depPoints(o)[0];
      if (p) return p.m || IDENT;
    }
    return null;
  }

  /* ================= 历史 ================= */
  function snapshot() {
    return JSON.stringify({
      objects: state.objects.map(stripObject),
      selection: state.selection.slice(),
      lastTransform: state.lastTransform ? clone(state.lastTransform) : null,
      preset: state.preset,
      params: clone(state.params || {})
    });
  }
  function pushHistory() {
    history.past.push(snapshot());
    if (history.past.length > history.limit) history.past.shift();
    history.future.length = 0;
    updateHistoryUI();
  }
  function restoreSnapshot(str) {
    let d;
    try { d = JSON.parse(str); } catch (e) { return; }
    state.objects = (d.objects || []).map(hydrateObject);
    state.selection = (d.selection || []).filter(function (id) { return !!byId(id); });
    state.lastTransform = d.lastTransform || null;
    state.preset = d.preset || '';
    state.params = d.params || {};
    state.draft = null;
    state.handle = null;
    state.measurePicks = [];
    refreshAll();
    render();
    scheduleSave();
  }
  function doUndo(silent) {
    if (!history.past.length) return false;
    history.future.push(snapshot());
    restoreSnapshot(history.past.pop());
    updateHistoryUI();
    if (!silent) shellRef && shellRef.toast('已撤销');
    return true;
  }
  function doRedo(silent) {
    if (!history.future.length) return false;
    history.past.push(snapshot());
    restoreSnapshot(history.future.pop());
    updateHistoryUI();
    if (!silent) shellRef && shellRef.toast('已重做');
    return true;
  }
  function updateHistoryUI() {
    if (refs.undo) refs.undo.disabled = !history.past.length;
    if (refs.redo) refs.redo.disabled = !history.future.length;
  }

  /* ================= 选择与增删 ================= */
  function expandSelection(ids) {
    const out = [], seen = {};
    function add(id) {
      if (!id || seen[id]) return;
      const o = byId(id);
      if (!o) return;
      seen[id] = 1;
      out.push(id);
      if (o.type === 'segment' || o.type === 'line' || o.type === 'vector' ||
        o.type === 'circle' || o.type === 'polygon') {
        refIds(o).forEach(add);
      }
    }
    (ids || []).forEach(add);
    return out;
  }
  function selectObjects(ids, additive) {
    if (!additive) state.selection = [];
    (ids || []).forEach(function (id) {
      if (!byId(id)) return;
      const i = state.selection.indexOf(id);
      if (i >= 0) { if (additive) state.selection.splice(i, 1); }
      else state.selection.push(id);
    });
    refreshAll();
    render();
  }
  function selectOne(id, additive) { selectObjects([id], additive); }
  function removeObjects(ids) {
    const del = new Set(ids);
    let changed = true;
    while (changed) {
      changed = false;
      state.objects.forEach(function (o) {
        if (del.has(o.id)) return;
        if (refIds(o).some(function (id) { return del.has(id); })) {
          del.add(o.id); changed = true;
        }
      });
    }
    const before = state.objects.length;
    state.objects = state.objects.filter(function (o) { return !del.has(o.id); });
    state.selection = state.selection.filter(function (id) { return !del.has(id); });
    state.measurePicks = state.measurePicks.filter(function (id) { return !del.has(id); });
    state.draft = null;
    refreshAll(); render(); scheduleSave();
    return before - state.objects.length;
  }
  function deleteSelection() {
    if (!state.selection.length) { shellRef && shellRef.toast('先选中要删除的对象'); return; }
    pushHistory();
    const n = removeObjects(state.selection.slice());
    shellRef && shellRef.toast('已删除 ' + n + ' 个对象 · Ctrl+Z 可撤销');
  }
  function clearScene() {
    if (!state.objects.length) { shellRef && shellRef.toast('画布已经是空的'); return; }
    pushHistory();
    state.objects = [];
    state.selection = [];
    state.lastTransform = null;
    state.preset = '';
    state.params = {};
    state.draft = null;
    state.handle = null;
    state.measurePicks = [];
    refreshAll(); render(); scheduleSave();
    shellRef && shellRef.toast('已清空 · Ctrl+Z 可撤销');
  }

  /* ================= 预设 ================= */
  function presetDef(id) {
    for (let i = 0; i < PRESETS.length; i++) if (PRESETS[i].id === id) return PRESETS[i];
    return null;
  }
  function buildTriangleScene() {
    const A = createPoint(-3, -1.1, { name: 'A', color: 'ink2' });
    const B = createPoint(0, -1.1, { name: 'B', color: 'ink2' });
    const C = createPoint(-1.5, 1.6, { name: 'C', color: 'ink2' });
    const poly = createShape('polygon', { pts: [A.id, B.id, C.id] }, { color: 'jade', width: 2.2, role: 'triangle' });
    return { A: A, B: B, C: C, poly: poly };
  }
  function buildQuadraticScene(p) {
    const fn = addFunction(p.a + '*(x-(' + p.h + '))^2+(' + p.k + ')', { color: 'data1', role: 'qfunc' });
    const v = createPoint(p.h, p.k, { name: 'V', color: 'accent', role: 'qvertex', aux: false });
    return { fn: fn, v: v };
  }
  function buildTrigScene(p) {
    return { fn: addFunction(p.A + '*sin(' + p.B + '*x+(' + p.phi + '))+(' + p.k + ')', { color: 'data1', role: 'tfunc' }) };
  }
  function buildInverseScene(p) {
    return { fn: addFunction('(' + p.k + ')/x', { color: 'data1', role: 'ifunc' }) };
  }
  function buildCircleTangentScene(p, silent) {
    const O = createPoint(0, 0, { name: 'O', color: 'ink2', role: 'ctO' });
    const R = createPoint(p.r, 0, { name: 'R', color: 'ink2', role: 'ctR' });
    const th = p.theta * PI / 180;
    const P = createPoint(p.r * Math.cos(th), p.r * Math.sin(th), { name: 'P', color: 'accent', role: 'ctP' });
    const T = createPoint(P.x - Math.sin(th) * 3.4, P.y + Math.cos(th) * 3.4,
      { name: 'T', color: 'ink2', role: 'ctT', aux: true });
    const circle = createShape('circle', { c: O.id, r: R.id }, { color: 'jade', width: 2.2, role: 'ctCircle' });
    const guide = createShape('segment', { a: O.id, b: P.id }, { color: 'soft', width: 1.1, dash: true, aux: true, role: 'ctGuide' });
    const line = createShape('line', { a: P.id, b: T.id }, { color: 'accent', width: 2, role: 'ctLine', name: '切线' });
    return { O: O, R: R, P: P, T: T, circle: circle, guide: guide, line: line };
  }
  function buildPresetObjects(id) {
    const p = state.params;
    if (id === 'triangle') return buildTriangleScene();
    if (id === 'quadratic') return buildQuadraticScene(p);
    if (id === 'trig') return buildTrigScene(p);
    if (id === 'inverse') return buildInverseScene(p);
    if (id === 'circletangent') return buildCircleTangentScene(p);
    return null;
  }
  function presetView(id) {
    if (id === 'triangle') return { cx: 0, cy: 0, scale: 54 };
    if (id === 'quadratic') return { cx: 0, cy: 1.2, scale: 47 };
    if (id === 'trig') return { cx: 0, cy: 0.3, scale: 44 };
    if (id === 'inverse') return { cx: 0, cy: 0, scale: 43 };
    if (id === 'circletangent') return { cx: 0, cy: 0.15, scale: 54 };
    return { cx: 0, cy: 0, scale: 52 };
  }
  function defaultParams(id) {
    if (id === 'quadratic') return { a: 0.8, h: -1, k: -1.5 };
    if (id === 'trig') return { A: 1.6, B: 1.2, phi: 0.55, k: 0.2 };
    if (id === 'inverse') return { k: 4 };
    if (id === 'circletangent') return { r: 2, theta: 52 };
    return {};
  }
  function applyPreset(id, opts) {
    opts = opts || {};
    const def = presetDef(id);
    if (!def) return;
    if (!opts.noHistory) pushHistory();
    state.objects = [];
    state.selection = [];
    state.draft = null;
    state.handle = null;
    state.measurePicks = [];
    state.lastTransform = null;
    state.tool = 'select';
    state.preset = id;
    state.params = defaultParams(id);
    state.view = presetView(id);
    const built = buildPresetObjects(id);
    if (id === 'triangle' && built && built.poly) state.selection = [built.poly.id];
    else if (built && built.fn) state.selection = [built.fn.id];
    else if (id === 'circletangent' && built && built.circle) state.selection = [built.circle.id];
    if (opts.preview && id === 'triangle' && built && built.poly) {
      const T = rotateM(JW.rad(22), { x: 0, y: 0 });
      applyTransform(T, {
        type: 'rotate', label: '绕原点旋转 22°',
        params: { angle: 22, rad: JW.rad(22), pivot: { x: 0, y: 0 } }
      }, { silent: true, noHistory: true });
      state.selection = [built.poly.id];
    }
    refreshAll(); render();
    if (!opts.silent) scheduleSave();
    if (!opts.silent && shellRef) shellRef.toast(def.name + ' · 已载入');
  }
  function refreshPresetObjects() {
    const p = state.params;
    if (state.preset === 'quadratic') {
      const f = findRole('qfunc'), v = findRole('qvertex');
      if (f) setFunctionExpr(f, p.a + '*(x-(' + p.h + '))^2+(' + p.k + ')');
      if (v) { setPointBase(v, p.h, p.k); }
    } else if (state.preset === 'trig') {
      const f = findRole('tfunc');
      if (f) setFunctionExpr(f, p.A + '*sin(' + p.B + '*x+(' + p.phi + '))+(' + p.k + ')');
    } else if (state.preset === 'inverse') {
      const f = findRole('ifunc');
      let k = p.k;
      if (Math.abs(k) < 0.25) k = k < 0 ? -0.5 : 0.5;
      if (f) setFunctionExpr(f, '(' + k + ')/x');
    } else if (state.preset === 'circletangent') {
      const O = findRole('ctO'), R = findRole('ctR'), P = findRole('ctP'), T = findRole('ctT');
      const r = Math.max(0.3, p.r), th = p.theta * PI / 180;
      if (R) setPointBase(R, r, 0);
      if (P) setPointBase(P, r * Math.cos(th), r * Math.sin(th));
      if (T) setPointBase(T, P ? P.x - Math.sin(th) * 3.4 : 0, P ? P.y + Math.cos(th) * 3.4 : 1);
      if (O) setPointBase(O, 0, 0);
    }
  }
  function triangleDemo(kind) {
    const poly = findRole('triangle');
    if (!poly) { shellRef && shellRef.toast('请先载入三角形预设'); return; }
    state.selection = [poly.id];
    state.tool = 'select'; state.draft = null; state.handle = null;
    let T, meta;
    if (kind === 'translate') {
      T = translateM(2, 1);
      meta = { type: 'translate', label: '平移 (2, 1)', params: { dx: 2, dy: 1 } };
    } else if (kind === 'rotate') {
      T = rotateM(JW.rad(60), { x: 0, y: 0 });
      meta = { type: 'rotate', label: '绕原点旋转 60°', params: { angle: 60, rad: JW.rad(60), pivot: { x: 0, y: 0 } } };
    } else if (kind === 'scale') {
      T = scaleM(1.5, { x: 0, y: 0 });
      meta = { type: 'scale', label: '以原点为中心缩放 k=1.5', params: { k: 1.5, pivot: { x: 0, y: 0 } } };
    } else {
      T = reflectLineM({ x: 0, y: 0 }, { x: 1, y: 0 });
      meta = { type: 'sym-line', label: '关于 x 轴对称', params: { axisLabel: 'x 轴', axis: [{ x: 0, y: 0 }, { x: 1, y: 0 }] } };
    }
    applyTransform(T, meta);
  }
  function tangentEquation() {
    const p = state.params;
    const th = p.theta * PI / 180, r = p.r;
    const a = Math.cos(th), b = Math.sin(th);
    const ca = fmtM(Math.round(a * 1000) / 1000), sb = fmtM(Math.round(b * 1000) / 1000);
    return ca + 'x + ' + sb + 'y = ' + fmt(r, 2);
  }

  /* ================= 变换 ================= */
  function applyTransform(T, meta, opts) {
    opts = opts || {};
    const targets = expandSelection(state.selection);
    const movable = targets.map(byId).filter(function (o) {
      return o && (o.type === 'point' || o.type === 'function');
    });
    if (!movable.length) {
      if (!opts.silent && shellRef) shellRef.toast('先选中要变换的对象');
      return false;
    }
    if (!opts.noHistory) pushHistory();
    movable.forEach(function (o) { o.m = matMul(T, o.m || IDENT); });
    state.lastTransform = {
      type: meta && meta.type || 'transform',
      label: meta && meta.label || '变换',
      matrix: T.slice(),
      params: meta && meta.params || {}
    };
    refreshAll(); render(); scheduleSave();
    if (!opts.silent && shellRef) shellRef.toast((meta && meta.label || '变换') + ' · 已应用，虚线为原像');
    return true;
  }
  function numericApply(kind) {
    if (!state.selection.length) { shellRef && shellRef.toast('先选中对象'); return; }
    if (kind === 'translate') {
      const dx = parseFloat(refs.txX.value), dy = parseFloat(refs.txY.value);
      if (!isNum(dx) || !isNum(dy)) { shellRef && shellRef.toast('请输入平移量 dx / dy'); return; }
      applyTransform(translateM(dx, dy), {
        type: 'translate', label: '平移 (' + fmt(dx, 2) + ', ' + fmt(dy, 2) + ')',
        params: { dx: dx, dy: dy }
      });
    } else if (kind === 'rotate') {
      const deg = parseFloat(refs.txAngle.value);
      if (!isNum(deg)) { shellRef && shellRef.toast('请输入旋转角度'); return; }
      const pivot = getPivot();
      const rad = JW.rad(deg);
      applyTransform(rotateM(rad, pivot), {
        type: 'rotate', label: '绕 ' + pivotLabel(pivot) + ' 旋转 ' + fmt(deg, 1) + '°',
        params: { angle: deg, rad: rad, pivot: pivot }
      });
    } else if (kind === 'scale') {
      const k = parseFloat(refs.txK.value);
      if (!isNum(k) || Math.abs(k) < 0.02) { shellRef && shellRef.toast('缩放比 k 需大于 0'); return; }
      const pivot = getPivot();
      applyTransform(scaleM(k, pivot), {
        type: 'scale', label: '以 ' + pivotLabel(pivot) + ' 为中心缩放 k=' + fmt(k, 2),
        params: { k: k, pivot: pivot }
      });
    }
  }
  function axisInfo() {
    if (state.axisMode === 'x') return { label: 'x 轴', a: { x: 0, y: 0 }, b: { x: 1, y: 0 } };
    if (state.axisMode === 'y') return { label: 'y 轴', a: { x: 0, y: 0 }, b: { x: 0, y: 1 } };
    const line = byId(state.axisMode.indexOf('line:') === 0 ? state.axisMode.slice(5) : '');
    if (line) {
      const a = curOfId(line.a), b = curOfId(line.b);
      if (a && b) return { label: '直线 ' + objectLabel(line), a: a, b: b };
    }
    return { label: 'x 轴', a: { x: 0, y: 0 }, b: { x: 1, y: 0 } };
  }
  function applySymPoint() {
    if (!state.selection.length) { shellRef && shellRef.toast('先选中对象'); return; }
    const pivot = getPivot();
    applyTransform(reflectPointM(pivot), {
      type: 'sym-point', label: '关于点 ' + pivotLabel(pivot) + ' 对称',
      params: { pivot: pivot }
    });
  }
  function applySymLine() {
    if (!state.selection.length) { shellRef && shellRef.toast('先选中对象'); return; }
    const ax = axisInfo();
    applyTransform(reflectLineM(ax.a, ax.b), {
      type: 'sym-line', label: '关于' + ax.label + '对称',
      params: { axisLabel: ax.label, axis: [{ x: ax.a.x, y: ax.a.y }, { x: ax.b.x, y: ax.b.y }] }
    });
  }
  function beginHandle(kind) {
    if (!state.selection.length) { shellRef && shellRef.toast('先选中对象'); return; }
    state.draft = null;
    state.tool = 'select';
    updateToolUI();
    state.handle = { kind: kind, phase: 'wait' };
    updateStatus(); render();
    shellRef && shellRef.toast('在画布上拖动以' + (kind === 'rotate' ? '旋转' : kind === 'scale' ? '缩放' : '平移'));
  }
  function startHandleDrag(world, ev) {
    const h = state.handle;
    if (!h || h.phase !== 'wait') return false;
    const targets = expandSelection(state.selection).map(byId).filter(function (o) {
      return o && (o.type === 'point' || o.type === 'function');
    });
    if (!targets.length) {
      shellRef && shellRef.toast('先选中可变换对象');
      state.handle = null; return false;
    }
    const pivot = getPivot();
    h.phase = 'drag';
    h.pivot = pivot;
    h.startWorld = world;
    h.targets = targets.map(function (o) { return { id: o.id, m: (o.m || IDENT).slice() }; });
    h.futureBefore = history.future.slice();
    h.historyPushed = false;
    h.moved = false;
    h.preview = null;
    if (h.kind === 'rotate') {
      h.a0 = Math.atan2(world.y - pivot.y, world.x - pivot.x);
      if (Math.hypot(world.x - pivot.x, world.y - pivot.y) < 1e-6) h.a0 = 0;
    }
    if (h.kind === 'scale') {
      h.r0 = Math.hypot(world.x - pivot.x, world.y - pivot.y);
      if (h.r0 < 1e-6) h.r0 = 1;
    }
    return true;
  }
  function updateHandleDrag(world) {
    const h = state.handle;
    if (!h || h.phase !== 'drag') return;
    let T, label, params, type;
    if (h.kind === 'translate') {
      const dx = world.x - h.startWorld.x, dy = world.y - h.startWorld.y;
      if (Math.hypot(dx, dy) * state.view.scale < 2) return;
      T = translateM(dx, dy); type = 'translate';
      label = '平移 (' + fmt(dx, 2) + ', ' + fmt(dy, 2) + ')';
      params = { dx: dx, dy: dy };
    } else if (h.kind === 'rotate') {
      let a = Math.atan2(world.y - h.pivot.y, world.x - h.pivot.x) - h.a0;
      while (a > PI) a -= TAU;
      while (a < -PI) a += TAU;
      if (Math.abs(JW.deg(a)) < 0.4) return;
      T = rotateM(a, h.pivot); type = 'rotate';
      label = '绕 ' + pivotLabel(h.pivot) + ' 旋转 ' + fmtAngle(a);
      params = { angle: JW.deg(a), rad: a, pivot: h.pivot };
    } else {
      const r = Math.hypot(world.x - h.pivot.x, world.y - h.pivot.y);
      const k = clamp(r / h.r0, 0.1, 8);
      if (Math.abs(k - 1) * 100 < 0.5) return;
      T = scaleM(k, h.pivot); type = 'scale';
      label = '以 ' + pivotLabel(h.pivot) + ' 为中心缩放 k=' + fmt(k, 2);
      params = { k: k, pivot: h.pivot };
    }
    if (!h.historyPushed) { pushHistory(); h.historyPushed = true; }
    h.preview = { type: type, label: label, matrix: T.slice(), params: params };
    h.moved = true;
    h.targets.forEach(function (t) {
      const o = byId(t.id);
      if (o && (o.type === 'point' || o.type === 'function')) o.m = matMul(T, t.m);
    });
    render();
  }
  function finishHandle() {
    const h = state.handle;
    if (!h || h.phase !== 'drag') return;
    if (h.moved && h.preview) {
      state.lastTransform = clone(h.preview);
      state.handle = null;
      refreshAll(); render(); scheduleSave();
      shellRef && shellRef.toast(h.preview.label + ' · 已应用');
    } else {
      state.handle = null;
      render(); updateStatus();
    }
  }
  function cancelHandle() {
    const h = state.handle;
    if (!h) return false;
    if (h.historyPushed) {
      h.targets.forEach(function (t) {
        const o = byId(t.id);
        if (o && (o.type === 'point' || o.type === 'function')) o.m = t.m.slice();
      });
      history.past.pop();
      history.future = h.futureBefore ? h.futureBefore.slice() : [];
    }
    state.handle = null;
    updateHistoryUI(); updateStatus(); render(); scheduleSave();
    return true;
  }

  /* ================= 绘图工具 ================= */
  function resolvePoint(world, exclude) {
    const snap = snapWorld(world, { exclude: exclude });
    if (snap.point) return snap.point;
    return createPoint(snap.x, snap.y, { name: nextPointName() });
  }
  function snapWorld(world, opt) {
    opt = opt || {};
    let best = null, bestD = 14 * 14;
    state.objects.forEach(function (o) {
      if (o.type !== 'point' || o.hidden || o.aux || o.id === opt.exclude) return;
      const c = curOfPoint(o);
      if (!c) return;
      const dx = X(c.x) - X(world.x), dy = Y(c.y) - Y(world.y);
      const d = dx * dx + dy * dy;
      if (d < bestD) { bestD = d; best = o; }
    });
    if (best) {
      const c = curOfPoint(best);
      return { x: c.x, y: c.y, point: best };
    }
    if (state.snapGrid && !opt.fine) {
      const step = gridSteps().minor;
      return { x: Math.round(world.x / step) * step, y: Math.round(world.y / step) * step, step: step };
    }
    return { x: world.x, y: world.y };
  }
  function startDraft(tool) {
    const futureBefore = history.future.slice();
    pushHistory();
    state.draft = {
      tool: tool,
      ids: [],
      cursor: null,
      backup: state.objects.map(stripObject),
      prevSelection: state.selection.slice(),
      futureBefore: futureBefore
    };
    state.measurePicks = [];
  }
  function cancelDraft() {
    const d = state.draft;
    if (!d) return false;
    state.objects = (d.backup || []).map(hydrateObject);
    state.selection = d.prevSelection || [];
    state.draft = null;
    history.past.pop();
    history.future = d.futureBefore ? d.futureBefore.slice() : [];
    updateHistoryUI(); refreshAll(); render();
    return true;
  }
  function finishDraft() {
    const d = state.draft;
    if (!d) return false;
    const points = d.ids.map(byId).filter(Boolean);
    let created = null;
    if (d.tool === 'segment' || d.tool === 'line' || d.tool === 'vector') {
      if (points.length < 2) return false;
      created = createShape(d.tool, { a: points[0].id, b: points[1].id }, {});
    } else if (d.tool === 'circle') {
      if (points.length < 2) return false;
      const c = curOfPoint(points[0]), rp = curOfPoint(points[1]);
      if (!c || !rp || Math.hypot(rp.x - c.x, rp.y - c.y) < 0.04) return false;
      created = createShape('circle', { c: points[0].id, r: points[1].id }, {});
    } else if (d.tool === 'polygon') {
      if (points.length < 3) return false;
      created = createShape('polygon', { pts: points.map(function (p) { return p.id; }) }, {});
    }
    if (!created) return false;
    state.selection = [created.id];
    state.draft = null;
    state.measurePicks = [];
    state.tool = 'select';
    refreshAll(); render(); scheduleSave();
    shellRef && shellRef.toast('已创建' + (TYPE_NAMES[created.type] || '对象'));
    return true;
  }
  function draftAddPoint(world) {
    const d = state.draft;
    if (!d) return;
    const last = d.ids.length ? byId(d.ids[d.ids.length - 1]) : null;
    if (last) {
      const c = curOfPoint(last);
      if (c && Math.hypot(c.x - world.x, c.y - world.y) * state.view.scale < 4) return;
    }
    if (d.tool === 'polygon' && d.ids.length >= 3) {
      const first = byId(d.ids[0]);
      const f = first ? curOfPoint(first) : null;
      if (f && Math.hypot(f.x - world.x, f.y - world.y) * state.view.scale < 16) {
        finishDraft(); return;
      }
    }
    const p = resolvePoint(world);
    d.ids.push(p.id);
    if (d.tool !== 'polygon' && d.ids.length >= 2) {
      finishDraft();
    } else {
      updateStatus(); render(); scheduleSave();
    }
  }
  function beginFunction() {
    setTool('func');
    if (refs.fnInput) { refs.fnInput.focus(); refs.fnInput.select(); }
  }
  function addFunctionFromInput() {
    const raw = refs.fnInput ? refs.fnInput.value : '';
    let o;
    try {
      const expr = normalizeExpr(raw);
      if (!expr) throw new Error('请输入函数表达式');
      compileExpr(expr);
      pushHistory();
      o = addFunction(expr);
    } catch (e) {
      shellRef && shellRef.toast(e.message || '表达式无效');
      return;
    }
    state.selection = [o.id];
    state.tool = 'select';
    if (refs.fnInput) refs.fnInput.value = '';
    refreshAll(); render(); scheduleSave();
    shellRef && shellRef.toast('已绘制 f(x) = ' + truncate(prettyExpr(o.expr), 20));
  }
  function measurePick(world) {
    if (state.measureMode === 'area') {
      const hit = hitTest({ x: X(world.x), y: Y(world.y) });
      if (hit && hit.type === 'polygon') {
        pushHistory();
        const m = createShape('marea', { poly: hit.id }, { color: 'accent', role: 'measure' });
        state.selection = [m.id];
        refreshAll(); render(); scheduleSave();
        shellRef && shellRef.toast('面积 ' + fmt(polygonArea(hit), 2));
      } else {
        shellRef && shellRef.toast('面积测量：请点击一个多边形内部');
      }
      return;
    }
    const hit = hitTest({ x: X(world.x), y: Y(world.y) });
    if (!hit || hit.type !== 'point') {
      shellRef && shellRef.toast(state.measureMode === 'angle' ? '角度测量：请点三个点' : '距离测量：请点两个点');
      return;
    }
    if (state.measurePicks.indexOf(hit.id) >= 0) return;
    state.measurePicks.push(hit.id);
    const need = state.measureMode === 'angle' ? 3 : 2;
    if (state.measurePicks.length >= need) {
      pushHistory();
      const m = state.measureMode === 'angle'
        ? createShape('mangle', { a: state.measurePicks[0], b: state.measurePicks[1], c: state.measurePicks[2] }, { color: 'accent', role: 'measure' })
        : createShape('mdist', { a: state.measurePicks[0], b: state.measurePicks[1] }, { color: 'accent', role: 'measure' });
      state.measurePicks = [];
      state.selection = [m.id];
      refreshAll(); render(); scheduleSave();
      shellRef && shellRef.toast(state.measureMode === 'angle' ? '已添加角度测量' : '已添加距离测量');
    } else {
      updateStatus(); render();
    }
  }

  /* ================= 命中测试 ================= */
  function hitTest(local) {
    const C = pal();
    let best = null, bestScore = 1e9;
    for (let i = state.objects.length - 1; i >= 0; i--) {
      const o = state.objects[i];
      if (o.hidden || o.aux) continue;
      if (o.type === 'point') {
        const p = curOfPoint(o);
        const dx = X(p.x) - local.x, dy = Y(p.y) - local.y;
        const d = Math.hypot(dx, dy);
        if (d <= 11 && d < bestScore) { best = o; bestScore = d; }
      }
    }
    if (best) return best;
    for (let i = state.objects.length - 1; i >= 0; i--) {
      const o = state.objects[i];
      if (o.hidden) continue;
      let d = 1e9;
      if (o.type === 'segment' || o.type === 'vector') {
        const a = curOfId(o.a), b = curOfId(o.b);
        if (a && b) d = distToSegment(local.x, local.y, X(a.x), Y(a.y), X(b.x), Y(b.y));
      } else if (o.type === 'line') {
        const a = curOfId(o.a), b = curOfId(o.b);
        if (a && b) d = distToLine(local.x, local.y, X(a.x), Y(a.y), X(b.x), Y(b.y));
      } else if (o.type === 'circle') {
        const c = currentCircle(o);
        if (c) d = Math.abs(Math.hypot(local.x - X(c.c.x), local.y - Y(c.c.y)) - c.r * state.view.scale);
      } else if (o.type === 'polygon') {
        const pts = (o.pts || []).map(curOfId).filter(Boolean).map(screenOf);
        if (pts.length >= 3) {
          d = distToPolygon(local.x, local.y, pts);
          if (pointInPolygon(local.x, local.y, pts)) d = 0;
        }
      } else if (o.type === 'function') {
        d = distToFunction(o, local.x, local.y);
      }
      if (d <= 8 && d < bestScore) { best = o; bestScore = d; }
    }
    return best;
  }
  function distToSegment(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const len2 = dx * dx + dy * dy || 1;
    let t = ((px - x1) * dx + (py - y1) * dy) / len2;
    t = clamp(t, 0, 1);
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  }
  function distToLine(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const len = Math.hypot(dx, dy) || 1;
    return Math.abs((px - x1) * dy - (py - y1) * dx) / len;
  }
  function distToPolygon(px, py, pts) {
    let d = 1e9;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      d = Math.min(d, distToSegment(px, py, a.x, a.y, b.x, b.y));
    }
    return d;
  }
  function pointInPolygon(x, y, pts) {
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside;
    }
    return inside;
  }
  function distToFunction(o, sx, sy) {
    let best = 1e9;
    const inv = invertM(o.m);
    const corners = [worldAt(0, 0), worldAt(state.w, 0), worldAt(0, state.h), worldAt(state.w, state.h)];
    let x0 = 1e9, x1 = -1e9;
    corners.forEach(function (p) {
      const q = applyM(inv, p.x, p.y);
      x0 = Math.min(x0, q.x); x1 = Math.max(x1, q.x);
    });
    x0 = clamp(x0, -1e4, 1e4); x1 = clamp(x1, -1e4, 1e4);
    const n = 180;
    let prev = null;
    for (let i = 0; i <= n; i++) {
      const x = x0 + (x1 - x0) * i / n;
      const y = o.fn(x);
      if (!isFinite(y)) { prev = null; continue; }
      const w = applyM(o.m, x, y);
      const s = screenOf(w);
      if (prev) best = Math.min(best, distToSegment(sx, sy, prev.x, prev.y, s.x, s.y));
      prev = s;
    }
    return best;
  }

  /* ================= 绘制 ================= */
  function scheduleRender() {
    if (rafId) return;
    rafId = requestAnimationFrame(function () { rafId = 0; render(); });
  }
  function roundedPath(g, x, y, w, h, r) {
    r = Math.min(r, Math.min(w, h) / 2);
    g.beginPath();
    g.moveTo(x + r, y);
    g.arcTo(x + w, y, x + w, y + h, r);
    g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r);
    g.arcTo(x, y, x + w, y, r);
    g.closePath();
  }
  function render() {
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    if (!ctx || state.w < 2 || state.h < 2) return;
    const g = ctx;
    g.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
    g.clearRect(0, 0, state.w, state.h);
    drawScene(g, state.w, state.h, {});
  }
  function drawScene(g, w, h, opts) {
    opts = opts || {};
    const C = pal();
    if (state.showGrid) drawGrid(g, w, h);
    drawAxes(g, w, h);
    drawTransformBackdrop(g, w, h);

    // 原像 ghost
    state.objects.forEach(function (o) { drawObject(g, o, 'ghost'); });

    // 测量底色
    if (state.showMeasure) {
      state.objects.forEach(function (o) {
        if (o.hidden || o.type !== 'marea') return;
        drawMeasureBase(g, o);
      });
    }

    // 选中光晕
    state.selection.forEach(function (id) {
      const o = byId(id);
      if (!o || o.hidden) return;
      if (o.type === 'function') drawFunction(g, o, 'halo');
      else if (o.type === 'point') { }
      else if (o.type === 'mdist' || o.type === 'mangle' || o.type === 'marea') { }
      else drawShape(g, o, 'halo');
    });

    // 曲线 → 线 → 圆 → 多边形 → 点
    state.objects.forEach(function (o) { if (o.type === 'function') drawObject(g, o, 'solid'); });
    state.objects.forEach(function (o) { if (o.type === 'line' || o.type === 'segment' || o.type === 'vector') drawObject(g, o, 'solid'); });
    state.objects.forEach(function (o) { if (o.type === 'circle') drawObject(g, o, 'solid'); });
    state.objects.forEach(function (o) { if (o.type === 'polygon') drawObject(g, o, 'solid'); });
    state.objects.forEach(function (o) { if (o.type === 'point') drawObject(g, o, 'solid'); });

    if (state.showMeasure) {
      state.objects.forEach(function (o) {
        if (!o.hidden && (o.type === 'mdist' || o.type === 'mangle' || o.type === 'marea')) drawMeasure(g, o);
      });
    }

    drawDraft(g);
    drawSnap(g);
    drawTransformAnnotation(g, w, h);
    drawHandleHint(g);
    drawMatrixCard(g, w, h);
    drawScaleBar(g, w, h);
    if (opts.export) {
      g.save();
      g.font = '9px ' + C.sans;
      g.fillStyle = C.faint;
      g.globalAlpha = 0.75;
      g.textAlign = 'right'; g.textBaseline = 'bottom';
      g.fillText('见微 · 变换实验室', w - 14, h - 12);
      g.restore();
    }
  }
  function drawGrid(g, w, h) {
    const C = pal();
    const steps = gridSteps();
    const xmin = state.view.cx - w / 2 / state.view.scale;
    const xmax = state.view.cx + w / 2 / state.view.scale;
    const ymin = state.view.cy - h / 2 / state.view.scale;
    const ymax = state.view.cy + h / 2 / state.view.scale;
    const minor = steps.minor;
    if (minor * state.view.scale >= 6) {
      g.save(); g.globalAlpha = 0.04; g.strokeStyle = C.ink; g.lineWidth = 1;
      g.beginPath();
      for (let x = Math.ceil(xmin / minor) * minor; x <= xmax; x += minor) {
        const sx = Math.round(X(x)) + 0.5;
        g.moveTo(sx, 0); g.lineTo(sx, h);
      }
      for (let y = Math.ceil(ymin / minor) * minor; y <= ymax; y += minor) {
        const sy = Math.round(Y(y)) + 0.5;
        g.moveTo(0, sy); g.lineTo(w, sy);
      }
      g.stroke(); g.restore();
    }
    const major = steps.major;
    g.save(); g.globalAlpha = 0.085; g.strokeStyle = C.ink; g.lineWidth = 1;
    g.beginPath();
    for (let x = Math.ceil(xmin / major) * major; x <= xmax; x += major) {
      const sx = Math.round(X(x)) + 0.5;
      g.moveTo(sx, 0); g.lineTo(sx, h);
    }
    for (let y = Math.ceil(ymin / major) * major; y <= ymax; y += major) {
      const sy = Math.round(Y(y)) + 0.5;
      g.moveTo(0, sy); g.lineTo(w, sy);
    }
    g.stroke(); g.restore();
  }
  function drawAxes(g, w, h) {
    const C = pal();
    const steps = gridSteps();
    const major = steps.major;
    const axX = clamp(X(0), 0, w);
    const axY = clamp(Y(0), 0, h);
    g.save();
    g.strokeStyle = C.ink2; g.globalAlpha = 0.52; g.lineWidth = 1.15;
    g.beginPath();
    g.moveTo(0, Math.round(axY) + 0.5); g.lineTo(w, Math.round(axY) + 0.5);
    g.moveTo(Math.round(axX) + 0.5, 0); g.lineTo(Math.round(axX) + 0.5, h);
    g.stroke();

    // 箭头
    g.globalAlpha = 0.62; g.fillStyle = C.ink2;
    g.beginPath();
    if (X(0) < w - 2) {
      g.moveTo(w - 1, axY); g.lineTo(w - 8, axY - 3.6); g.lineTo(w - 8, axY + 3.6); g.closePath();
    }
    g.fill();
    g.beginPath();
    if (Y(0) > 2) {
      g.moveTo(axX, 1); g.lineTo(axX - 3.6, 8); g.lineTo(axX + 3.6, 8); g.closePath();
    }
    g.fill();

    // 刻度数字
    g.font = '9.5px ' + C.sans;
    g.fillStyle = C.soft; g.globalAlpha = 0.82;
    const xmin = state.view.cx - w / 2 / state.view.scale;
    const xmax = state.view.cx + w / 2 / state.view.scale;
    const ymin = state.view.cy - h / 2 / state.view.scale;
    const ymax = state.view.cy + h / 2 / state.view.scale;
    g.textAlign = 'center'; g.textBaseline = 'top';
    const xLabelY = axY < h - 22 ? axY + 6 : axY - 16;
    for (let x = Math.ceil(xmin / major) * major; x <= xmax; x += major) {
      if (Math.abs(x) < major * 1e-6) continue;
      const sx = X(x);
      if (sx < 12 || sx > w - 12) continue;
      g.fillText(tickText(x, major), sx, xLabelY);
    }
    g.textAlign = 'right'; g.textBaseline = 'middle';
    const yLabelX = axX > 48 ? axX - 6 : axX + 6;
    const yAlign = axX > 48 ? 'right' : 'left';
    g.textAlign = yAlign;
    for (let y = Math.ceil(ymin / major) * major; y <= ymax; y += major) {
      if (Math.abs(y) < major * 1e-6) continue;
      const sy = Y(y);
      if (sy < 12 || sy > h - 12) continue;
      g.fillText(tickText(y, major), yLabelX, sy);
    }
    // 原点
    if (X(0) >= 0 && X(0) <= w && Y(0) >= 0 && Y(0) <= h) {
      g.globalAlpha = 0.65; g.fillStyle = C.ink2;
      g.beginPath(); g.arc(X(0), Y(0), 1.8, 0, TAU); g.fill();
    }
    // 轴名
    g.globalAlpha = 0.72; g.fillStyle = C.soft;
    g.font = 'italic 11px ' + C.serif;
    g.textAlign = 'right'; g.textBaseline = 'bottom';
    g.fillText('x', w - 11, axY - 7);
    g.textAlign = 'left'; g.textBaseline = 'top';
    g.fillText('y', axX + 7, 11);
    g.restore();
  }
  function drawTransformBackdrop(g, w, h) {
    const lt = currentTransform();
    if (!lt || lt.type !== 'sym-line' || !state.showAnnotation) return;
    const ax = lt.params && lt.params.axis;
    if (!ax || ax.length < 2) return;
    const C = pal();
    const a = screenOf(ax[0]), b = screenOf(ax[1]);
    const seg = clipLineToRect(a.x, a.y, b.x, b.y, w, h);
    if (!seg) return;
    g.save();
    g.strokeStyle = C.accent; g.globalAlpha = 0.4; g.lineWidth = 1.2;
    g.setLineDash([7, 6]);
    g.beginPath(); g.moveTo(seg[0].x, seg[0].y); g.lineTo(seg[1].x, seg[1].y); g.stroke();
    g.restore();
  }
  function drawObject(g, o, mode) {
    if (!o || o.hidden) return;
    if (mode === 'ghost') {
      if (o.type === 'function') {
        if (!isI(o.m)) drawFunction(g, o, 'ghost');
        return;
      }
      if (o.type === 'point') {
        const p = curOfPoint(o);
        if (p && !isI(o.m)) {
          g.save(); g.strokeStyle = pal().faint; g.globalAlpha = 0.55; g.lineWidth = 1.2;
          g.setLineDash([3, 3]);
          g.beginPath(); g.arc(X(p.x), Y(p.y), 3.2, 0, TAU); g.stroke();
          g.restore();
        }
        return;
      }
      if (o.type === 'mdist' || o.type === 'mangle' || o.type === 'marea') return;
      const pts = depPoints(o);
      if (!pts.length || !pts.some(function (p) { return !isI(p.m); })) return;
      drawShape(g, o, 'ghost');
      return;
    }
    if (o.type === 'point') drawPoint(g, o);
    else if (o.type === 'function') drawFunction(g, o, mode === 'halo' ? 'halo' : 'solid');
    else if (o.type === 'circle' || o.type === 'polygon' || o.type === 'segment' ||
      o.type === 'line' || o.type === 'vector') drawShape(g, o, mode);
  }
  function shapeStyle(g, o, mode) {
    const C = pal();
    const ghost = mode === 'ghost', halo = mode === 'halo';
    g.strokeStyle = ghost ? C.faint : halo ? C.accent : objectColor(o);
    g.fillStyle = g.strokeStyle;
    g.globalAlpha = ghost ? 0.55 : halo ? 0.15 : 1;
    g.lineWidth = ghost ? 1.2 : halo ? (o.width || 2) + 6 : (o.width || 2);
    g.lineJoin = 'round'; g.lineCap = 'round';
    if (ghost) g.setLineDash([5, 4]);
    else if (o.dash) g.setLineDash([4, 4]);
    else g.setLineDash([]);
  }
  function drawShape(g, o, mode) {
    if (!o || o.hidden) return;
    const ghost = mode === 'ghost', halo = mode === 'halo';
    const ptsBase = depPoints(o).map(function (p) { return ghost ? { x: p.x, y: p.y } : curOfPoint(p); });
    if (o.type === 'circle') {
      const c = ghost ? { x: (byId(o.c) || {}).x, y: (byId(o.c) || {}).y } : curOfId(o.c);
      const rp = ghost ? { x: (byId(o.r) || {}).x, y: (byId(o.r) || {}).y } : curOfId(o.r);
      if (!c || !rp) return;
      const r = Math.hypot(rp.x - c.x, rp.y - c.y) * state.view.scale;
      if (r < 0.5) return;
      g.save(); shapeStyle(g, o, mode);
      g.beginPath(); g.arc(X(c.x), Y(c.y), r, 0, TAU);
      if (!ghost && !halo) { g.globalAlpha = 0.045; g.fill(); g.globalAlpha = 1; }
      g.stroke(); g.restore();
      if (!ghost && !halo && state.selection.indexOf(o.id) >= 0) {
        g.save(); g.strokeStyle = pal().accent; g.globalAlpha = 0.34; g.lineWidth = 1;
        g.setLineDash([4, 5]); g.beginPath();
        g.moveTo(X(c.x), Y(c.y)); g.lineTo(X(rp.x), Y(rp.y)); g.stroke(); g.restore();
      }
      return;
    }
    if (o.type === 'polygon') {
      if (ptsBase.length < 3) return;
      g.save(); shapeStyle(g, o, mode);
      g.beginPath();
      ptsBase.forEach(function (p, i) {
        if (i === 0) g.moveTo(X(p.x), Y(p.y)); else g.lineTo(X(p.x), Y(p.y));
      });
      g.closePath();
      if (!ghost && !halo) {
        g.globalAlpha = ghost ? 0 : 0.065; g.fill();
        g.globalAlpha = 1; g.stroke();
      } else g.stroke();
      g.restore();
      return;
    }
    if (o.type === 'segment' || o.type === 'vector') {
      if (ptsBase.length < 2) return;
      const a = ptsBase[0], b = ptsBase[1];
      g.save(); shapeStyle(g, o, mode);
      g.beginPath(); g.moveTo(X(a.x), Y(a.y)); g.lineTo(X(b.x), Y(b.y)); g.stroke();
      if (o.type === 'vector' && !ghost && !halo) {
        const ang = Math.atan2(Y(b.y) - Y(a.y), X(b.x) - X(a.x));
        const L = 9;
        g.beginPath();
        g.moveTo(X(b.x), Y(b.y));
        g.lineTo(X(b.x) - L * Math.cos(ang - 0.42), Y(b.y) - L * Math.sin(ang - 0.42));
        g.lineTo(X(b.x) - L * Math.cos(ang + 0.42), Y(b.y) - L * Math.sin(ang + 0.42));
        g.closePath(); g.fill();
      }
      g.restore();
      return;
    }
    if (o.type === 'line') {
      if (ptsBase.length < 2) return;
      const a = ptsBase[0], b = ptsBase[1];
      const seg = clipLineToRect(X(a.x), Y(a.y), X(b.x), Y(b.y), state.w, state.h);
      if (!seg) return;
      g.save(); shapeStyle(g, o, mode);
      g.beginPath(); g.moveTo(seg[0].x, seg[0].y); g.lineTo(seg[1].x, seg[1].y); g.stroke();
      g.restore();
    }
  }
  function drawPoint(g, o) {
    if (!o || o.hidden) return;
    const C = pal();
    const p = curOfPoint(o);
    if (!p) return;
    const sx = X(p.x), sy = Y(p.y);
    const selected = state.selection.indexOf(o.id) >= 0;
    g.save();
    if (o.aux) {
      g.fillStyle = objectColor(o); g.globalAlpha = 0.55;
      g.beginPath(); g.arc(sx, sy, 2.3, 0, TAU); g.fill();
      g.restore(); return;
    }
    g.fillStyle = objectColor(o);
    const pr = 3.4 + (o.width || 1) * 0.8;
    g.beginPath(); g.arc(sx, sy, selected ? pr + 1 : pr, 0, TAU); g.fill();
    g.strokeStyle = C.paper;
    g.globalAlpha = 0.9; g.lineWidth = 1.3;
    g.beginPath(); g.arc(sx, sy, selected ? pr + 1 : pr, 0, TAU); g.stroke();
    if (selected) {
      g.globalAlpha = 0.92; g.strokeStyle = C.accent; g.lineWidth = 1.6;
      g.beginPath(); g.arc(sx, sy, 9.2, 0, TAU); g.stroke();
      g.globalAlpha = 0.22; g.lineWidth = 4;
      g.beginPath(); g.arc(sx, sy, 9.2, 0, TAU); g.stroke();
    }
    g.globalAlpha = 0.95; g.fillStyle = selected ? C.accent : C.ink;
    g.font = 'italic 12px ' + C.serif;
    g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText(o.name || '', sx + 9, sy - 9);
    g.restore();
  }
  function drawFunction(g, o, mode) {
    if (!o || o.hidden || !o.fn) return;
    const C = pal();
    const ghost = mode === 'ghost', halo = mode === 'halo';
    const inv = invertM(o.m);
    const corners = [worldAt(0, 0), worldAt(state.w, 0), worldAt(0, state.h), worldAt(state.w, state.h)];
    let x0 = 1e9, x1 = -1e9;
    corners.forEach(function (p) {
      const q = applyM(inv, p.x, p.y);
      x0 = Math.min(x0, q.x); x1 = Math.max(x1, q.x);
    });
    x0 = clamp(x0, -1e4, 1e4); x1 = clamp(x1, -1e4, 1e4);
    if (!isFinite(x0) || !isFinite(x1) || x1 - x0 < 1e-6) return;
    const n = clamp(Math.round(state.w * 1.35), 420, 1600);
    g.save();
    g.strokeStyle = ghost ? C.faint : halo ? C.accent : objectColor(o);
    g.globalAlpha = ghost ? 0.55 : halo ? 0.16 : 1;
    g.lineWidth = ghost ? 1.2 : halo ? (o.width || 2.2) + 6 : (o.width || 2.2);
    g.lineJoin = 'round'; g.lineCap = 'round';
    if (ghost) g.setLineDash([5, 4]);
    g.beginPath();
    let pen = false, prevY = null;
    for (let i = 0; i <= n; i++) {
      const x = x0 + (x1 - x0) * i / n;
      const y = o.fn(x);
      if (!isFinite(y) || Math.abs(y) > 1e7) { pen = false; prevY = null; continue; }
      const wpt = applyM(o.m, x, y);
      const sx = X(wpt.x), sy = Y(wpt.y);
      if (!isFinite(sx) || !isFinite(sy)) { pen = false; prevY = null; continue; }
      if (prevY != null && Math.abs(sy - prevY) > state.h * 0.62) pen = false;
      if (!pen) { g.moveTo(sx, sy); pen = true; } else g.lineTo(sx, sy);
      prevY = sy;
    }
    g.stroke(); g.restore();
    if (!ghost && !halo) {
      // 曲线标签：在可视区右侧找一个点
      const targetX = state.view.cx + (state.w * 0.26) / state.view.scale;
      const y = o.fn(targetX);
      if (isFinite(y)) {
        const wpt = applyM(o.m, targetX, y);
        const s = screenOf(wpt);
        if (s.x > 20 && s.x < state.w - 20 && s.y > 50 && s.y < state.h - 30 && state.selection.indexOf(o.id) < 0) {
          drawChip(g, s.x, s.y - 18, 'y = ' + truncate(prettyExpr(o.expr), 18), { color: objectColor(o), align: 'center' });
        }
      }
    }
  }
  function drawChip(g, x, y, text, opts) {
    opts = opts || {};
    const C = pal();
    g.save();
    g.font = (opts.font || '10px ' + C.sans);
    const tw = g.measureText(text).width;
    const pad = 6, hgt = 18;
    let bx = x - tw / 2 - pad;
    if (opts.align === 'left') bx = x;
    if (opts.align === 'right') bx = x - tw - pad * 2;
    bx = clamp(bx, 6, state.w - tw - pad * 2 - 6);
    const by = y - hgt / 2;
    roundedPath(g, bx, by, tw + pad * 2, hgt, 7);
    g.fillStyle = C.card; g.globalAlpha = 0.88; g.fill();
    g.globalAlpha = 1; g.strokeStyle = C.line; g.lineWidth = 1; g.stroke();
    g.fillStyle = opts.color || C.ink; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText(text, bx + pad, y);
    g.restore();
  }
  function drawMeasureBase(g, o) {
    const poly = byId(o.poly);
    if (!poly) return;
    const pts = (poly.pts || []).map(curOfId).filter(Boolean);
    if (pts.length < 3) return;
    g.save(); g.fillStyle = pal().accent; g.globalAlpha = 0.055;
    g.beginPath(); pts.forEach(function (p, i) { if (i === 0) g.moveTo(X(p.x), Y(p.y)); else g.lineTo(X(p.x), Y(p.y)); });
    g.closePath(); g.fill(); g.restore();
  }
  function angleOf(o) {
    const a = curOfId(o.a), b = curOfId(o.b), c = curOfId(o.c);
    if (!a || !b || !c) return 0;
    const v1 = { x: a.x - b.x, y: a.y - b.y }, v2 = { x: c.x - b.x, y: c.y - b.y };
    const d = Math.hypot(v1.x, v1.y) * Math.hypot(v2.x, v2.y);
    if (d < 1e-9) return 0;
    return Math.acos(clamp((v1.x * v2.x + v1.y * v2.y) / d, -1, 1));
  }
  function drawMeasure(g, o) {
    const C = pal();
    if (o.type === 'mdist') {
      const a = curOfId(o.a), b = curOfId(o.b);
      if (!a || !b) return;
      g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.72; g.lineWidth = 1.2; g.setLineDash([4, 4]);
      g.beginPath(); g.moveTo(X(a.x), Y(a.y)); g.lineTo(X(b.x), Y(b.y)); g.stroke(); g.restore();
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      drawChip(g, X(mid.x), Y(mid.y), (byId(o.a) || {}).name + (byId(o.b) || {}).name + ' = ' + fmt(segmentLen(o), 2), { color: C.accent });
      return;
    }
    if (o.type === 'mangle') {
      const a = curOfId(o.a), b = curOfId(o.b), c = curOfId(o.c);
      if (!a || !b || !c) return;
      g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.6; g.lineWidth = 1.2; g.setLineDash([4, 4]);
      g.beginPath(); g.moveTo(X(a.x), Y(a.y)); g.lineTo(X(b.x), Y(b.y)); g.lineTo(X(c.x), Y(c.y)); g.stroke();
      g.setLineDash([]);
      const a1 = Math.atan2(Y(a.y) - Y(b.y), X(a.x) - X(b.x));
      const a2 = Math.atan2(Y(c.y) - Y(b.y), X(c.x) - X(b.x));
      const r = 32;
      g.beginPath(); g.arc(X(b.x), Y(b.y), r, Math.min(a1, a2), Math.max(a1, a2)); g.stroke();
      g.restore();
      const mid = (Math.min(a1, a2) + Math.max(a1, a2)) / 2;
      drawChip(g, X(b.x) + Math.cos(mid) * (r + 30), Y(b.y) + Math.sin(mid) * (r + 30),
        '∠' + (byId(o.a) || {}).name + (byId(o.b) || {}).name + (byId(o.c) || {}).name + ' = ' + fmtAngle(angleOf(o)),
        { color: C.accent });
      return;
    }
    if (o.type === 'marea') {
      const poly = byId(o.poly);
      if (!poly) return;
      const pts = (poly.pts || []).map(curOfId).filter(Boolean);
      if (pts.length < 3) return;
      const c = centroidOf(pts);
      drawChip(g, X(c.x), Y(c.y), 'S = ' + fmt(polygonArea(poly), 2), { color: C.accent });
    }
  }
  function drawDraft(g) {
    const C = pal();
    const d = state.draft;
    if (!d) return;
    const pts = d.ids.map(curOfId).filter(Boolean);
    const cur = d.cursor;
    g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.8; g.lineWidth = 1.4; g.setLineDash([5, 4]);
    if (pts.length && cur) {
      if (d.tool === 'circle') {
        const c = pts[0];
        const r = Math.hypot(cur.x - c.x, cur.y - c.y) * state.view.scale;
        g.beginPath(); g.arc(X(c.x), Y(c.y), r, 0, TAU); g.stroke();
        g.beginPath(); g.moveTo(X(c.x), Y(c.y)); g.lineTo(X(cur.x), Y(cur.y)); g.stroke();
      } else if (d.tool === 'polygon') {
        g.beginPath(); g.moveTo(X(pts[0].x), Y(pts[0].y));
        for (let i = 1; i < pts.length; i++) g.lineTo(X(pts[i].x), Y(pts[i].y));
        g.lineTo(X(cur.x), Y(cur.y)); g.stroke();
        if (pts.length >= 3) {
          g.globalAlpha = 0.35; g.beginPath(); g.moveTo(X(cur.x), Y(cur.y)); g.lineTo(X(pts[0].x), Y(pts[0].y)); g.stroke();
        }
      } else {
        const a = pts[pts.length - 1];
        g.beginPath(); g.moveTo(X(a.x), Y(a.y)); g.lineTo(X(cur.x), Y(cur.y)); g.stroke();
        if (d.tool === 'vector') {
          const ang = Math.atan2(Y(cur.y) - Y(a.y), X(cur.x) - X(a.x));
          g.setLineDash([]); g.beginPath();
          g.moveTo(X(cur.x), Y(cur.y));
          g.lineTo(X(cur.x) - 9 * Math.cos(ang - 0.42), Y(cur.y) - 9 * Math.sin(ang - 0.42));
          g.lineTo(X(cur.x) - 9 * Math.cos(ang + 0.42), Y(cur.y) - 9 * Math.sin(ang + 0.42));
          g.closePath(); g.fillStyle = C.accent; g.globalAlpha = 0.8; g.fill();
        }
      }
    }
    // 测量拾取环
    if (state.measurePicks.length) {
      g.setLineDash([]);
      state.measurePicks.forEach(function (id) {
        const p = curOfId(id);
        if (p) { g.globalAlpha = 0.9; g.strokeStyle = C.accent; g.lineWidth = 2; g.beginPath(); g.arc(X(p.x), Y(p.y), 10, 0, TAU); g.stroke(); }
      });
    }
    g.restore();
  }
  function drawSnap(g) {
    const s = state.snapInfo;
    if (!s) return;
    const C = pal();
    g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.85; g.lineWidth = 1.4;
    if (s.point) {
      g.beginPath(); g.arc(X(s.x), Y(s.y), 11, 0, TAU); g.stroke();
    } else if (s.step) {
      const sx = X(s.x), sy = Y(s.y);
      g.beginPath(); g.moveTo(sx - 6, sy); g.lineTo(sx + 6, sy); g.moveTo(sx, sy - 6); g.lineTo(sx, sy + 6); g.stroke();
      g.globalAlpha = 0.35; g.beginPath(); g.arc(sx, sy, 3, 0, TAU); g.stroke();
    }
    g.restore();
  }
  function currentTransform() {
    if (state.handle && state.handle.preview) return state.handle.preview;
    return state.lastTransform;
  }
  function drawTransformAnnotation(g, w, h) {
    const lt = currentTransform();
    if (!lt || !state.showAnnotation || isI(lt.matrix)) return;
    const C = pal();
    const p = lt.params || {};
    if (lt.type === 'rotate' && p.pivot) {
      const pv = p.pivot, rad = p.rad != null ? p.rad : JW.rad(p.angle || 0);
      g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.55; g.lineWidth = 1.2; g.setLineDash([4, 4]);
      const r = 36;
      g.beginPath(); g.moveTo(X(pv.x), Y(pv.y)); g.lineTo(X(pv.x) + r, Y(pv.y)); g.stroke();
      g.beginPath(); g.moveTo(X(pv.x), Y(pv.y));
      g.lineTo(X(pv.x) + r * Math.cos(rad), Y(pv.y) - r * Math.sin(rad)); g.stroke();
      g.setLineDash([]); g.globalAlpha = 0.85; g.lineWidth = 1.5;
      g.beginPath(); g.arc(X(pv.x), Y(pv.y), r, 0, -rad, rad > 0); g.stroke();
      g.fillStyle = C.accent; g.beginPath(); g.arc(X(pv.x), Y(pv.y), 2.6, 0, TAU); g.fill();
      g.restore();
      const mid = -rad / 2;
      drawChip(g, X(pv.x) + Math.cos(mid) * (r + 28), Y(pv.y) + Math.sin(mid) * (r + 28),
        'θ = ' + fmt(Math.abs(JW.deg(rad)), 1) + '°', { color: C.accent });
    } else if (lt.type === 'scale' && p.pivot) {
      g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.75; g.lineWidth = 1.3;
      g.beginPath(); g.arc(X(p.pivot.x), Y(p.pivot.y), 5, 0, TAU); g.stroke();
      g.fillStyle = C.accent; g.beginPath(); g.arc(X(p.pivot.x), Y(p.pivot.y), 2.2, 0, TAU); g.fill();
      g.restore();
      drawChip(g, X(p.pivot.x) + 14, Y(p.pivot.y) - 18, 'k = ' + fmt(p.k, 2), { color: C.accent, align: 'left' });
    } else if (lt.type === 'translate') {
      const b = selectionBounds();
      if (b && isNum(p.dx) && isNum(p.dy)) {
        const from = { x: (b.minX + b.maxX) / 2 - p.dx, y: (b.minY + b.maxY) / 2 - p.dy };
        const to = { x: from.x + p.dx, y: from.y + p.dy };
        g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.75; g.lineWidth = 1.5; g.setLineDash([5, 4]);
        g.beginPath(); g.moveTo(X(from.x), Y(from.y)); g.lineTo(X(to.x), Y(to.y)); g.stroke(); g.setLineDash([]);
        const ang = Math.atan2(Y(to.y) - Y(from.y), X(to.x) - X(from.x)), L = 8;
        g.fillStyle = C.accent; g.beginPath();
        g.moveTo(X(to.x), Y(to.y));
        g.lineTo(X(to.x) - L * Math.cos(ang - 0.42), Y(to.y) - L * Math.sin(ang - 0.42));
        g.lineTo(X(to.x) - L * Math.cos(ang + 0.42), Y(to.y) - L * Math.sin(ang + 0.42));
        g.closePath(); g.fill(); g.restore();
        drawChip(g, X(to.x), Y(to.y) - 18, '(' + fmt(p.dx, 1) + ', ' + fmt(p.dy, 1) + ')', { color: C.accent });
      }
    } else if (lt.type === 'sym-point' && p.pivot) {
      g.save(); g.strokeStyle = C.accent; g.globalAlpha = 0.8; g.lineWidth = 1.3;
      g.beginPath(); g.arc(X(p.pivot.x), Y(p.pivot.y), 6, 0, TAU); g.stroke();
      g.beginPath(); g.moveTo(X(p.pivot.x) - 9, Y(p.pivot.y)); g.lineTo(X(p.pivot.x) + 9, Y(p.pivot.y));
      g.moveTo(X(p.pivot.x), Y(p.pivot.y) - 9); g.lineTo(X(p.pivot.x), Y(p.pivot.y) + 9); g.stroke();
      g.restore();
    } else if (lt.type === 'sym-line' && p.axis) {
      const a = screenOf(p.axis[0]), b = screenOf(p.axis[1]);
      const seg = clipLineToRect(a.x, a.y, b.x, b.y, w, h);
      if (seg) drawChip(g, seg[0].x + 40, seg[0].y - 18, p.axisLabel || '对称轴', { color: C.accent, align: 'left' });
    }
  }
  function drawHandleHint(g) {
    const h = state.handle;
    if (!h || h.phase !== 'wait') return;
    const C = pal();
    let center = null;
    if (h.kind === 'translate') {
      const b = selectionBounds();
      if (b) center = { x: (b.minX + b.maxX) / 2, y: (b.minY + b.maxY) / 2 };
    } else {
      center = getPivot();
    }
    if (!center) return;
    const sx = X(center.x), sy = Y(center.y);
    if (sx < -40 || sx > state.w + 40 || sy < -40 || sy > state.h + 40) return;
    g.save();
    g.strokeStyle = C.accent; g.fillStyle = C.accent;
    g.globalAlpha = 0.8; g.lineWidth = 1.5;
    if (h.kind === 'translate') {
      g.setLineDash([4, 4]);
      g.beginPath(); g.arc(sx, sy, 24, 0, TAU); g.stroke();
      g.setLineDash([]);
      [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (d) {
        g.beginPath();
        g.moveTo(sx + d[0] * 24, sy + d[1] * 24);
        g.lineTo(sx + d[0] * 31, sy + d[1] * 31);
        g.stroke();
      });
      drawChip(g, sx, sy - 38, '拖拽平移', { color: C.accent });
    } else {
      g.setLineDash([4, 4]);
      g.beginPath(); g.arc(sx, sy, 25, 0, TAU); g.stroke();
      g.setLineDash([]);
      g.beginPath(); g.arc(sx + 25, sy, 4, 0, TAU); g.fill();
      drawChip(g, sx + 32, sy - 24, h.kind === 'rotate' ? '拖拽旋转' : '拖拽缩放', { color: C.accent, align: 'left' });
    }
    g.restore();
  }
  function drawMatrixCard(g, w, h) {
    const lt = currentTransform();
    if (!state.showAnnotation || !lt || isI(lt.matrix) || w < 850) return;
    const C = pal();
    const cw = 196, ch = 94;
    const x = w - cw - 14, y = 14;
    g.save();
    roundedPath(g, x, y, cw, ch, 13);
    g.fillStyle = C.card; g.globalAlpha = 0.92; g.fill();
    g.globalAlpha = 1; g.strokeStyle = C.line; g.lineWidth = 1; g.stroke();
    g.font = '9px ' + C.sans; g.fillStyle = C.faint;
    g.textAlign = 'left'; g.textBaseline = 'top';
    g.fillText('变换矩阵 · T', x + 12, y + 9);
    g.font = '10px ' + C.sans; g.fillStyle = C.soft;
    g.fillText(truncate(lt.label || '', 22), x + 12, y + 21);
    g.font = '10.5px ' + C.serif; g.fillStyle = C.ink;
    const rows = matrixRows(lt.matrix);
    for (let i = 0; i < 3; i++) g.fillText(rows[i], x + 12, y + 40 + i * 15);
    g.restore();
  }
  function drawScaleBar(g, w, h) {
    if (w < 340 || h < 220) return;
    const C = pal();
    const step = niceStep(state.view.scale, 86);
    const px = step * state.view.scale;
    if (px < 34 || px > w * 0.4) return;
    const x = 16, y = h - 17;
    g.save(); g.strokeStyle = C.soft; g.globalAlpha = 0.6; g.lineWidth = 1.2;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + px, y);
    g.moveTo(x, y - 4); g.lineTo(x, y + 4);
    g.moveTo(x + px, y - 4); g.lineTo(x + px, y + 4);
    g.stroke();
    g.globalAlpha = 0.72; g.fillStyle = C.faint;
    g.font = '9.5px ' + C.sans; g.textAlign = 'left'; g.textBaseline = 'bottom';
    g.fillText(tickText(step, step) + ' 单位', x, y - 6);
    g.restore();
  }
  function clipLineToRect(x1, y1, x2, y2, w, h) {
    const dx = x2 - x1, dy = y2 - y1;
    const pts = [];
    function add(x, y) {
      if (x < -0.01 || x > w + 0.01 || y < -0.01 || y > h + 0.01) return;
      for (let i = 0; i < pts.length; i++) if (Math.abs(pts[i].x - x) < 0.5 && Math.abs(pts[i].y - y) < 0.5) return;
      pts.push({ x: x, y: y });
    }
    if (Math.abs(dx) > 1e-9) {
      let t = (0 - x1) / dx; add(0, y1 + t * dy);
      t = (w - x1) / dx; add(w, y1 + t * dy);
    }
    if (Math.abs(dy) > 1e-9) {
      let t = (0 - y1) / dy; add(x1 + t * dx, 0);
      t = (h - y1) / dy; add(x1 + t * dx, h);
    }
    if (pts.length < 2) return null;
    if (pts.length === 2) return pts;
    let best = [pts[0], pts[1]], bd = -1;
    for (let i = 0; i < pts.length; i++) {
      for (let j = i + 1; j < pts.length; j++) {
        const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
        if (d > bd) { bd = d; best = [pts[i], pts[j]]; }
      }
    }
    return best;
  }

  /* ================= 指针交互 ================= */
  function eventLocal(e) {
    const r = cv.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  function onPointerDown(e) {
    if (!cv) return;
    if (e.button === 2) return;
    const local = eventLocal(e);
    const world = worldAt(local.x, local.y);
    state.hover = { x: local.x, y: local.y, world: world };
    if (e.pointerType === 'touch') e.preventDefault();
    fingers.set(e.pointerId, { x: local.x, y: local.y });
    if (fingers.size >= 2) {
      cancelGestureForPinch();
      startPinch();
      return;
    }
    try { cv.setPointerCapture(e.pointerId); } catch (err) { }
    if (e.button === 1) {
      state.pointer = { id: e.pointerId, mode: 'pan', start: local, view: { cx: state.view.cx, cy: state.view.cy }, moved: false };
      return;
    }
    if (state.handle && state.handle.phase === 'wait') {
      if (startHandleDrag(world, e)) {
        state.pointer = { id: e.pointerId, mode: 'handle', moved: false };
        updateStatus(); render();
      }
      return;
    }
    if (state.tool === 'select') {
      const hit = hitTest(local);
      if (hit) {
        if (hit.type === 'point') {
          selectOne(hit.id, e.shiftKey);
          const p = curOfPoint(hit);
          pushHistory();
          state.pointer = {
            id: e.pointerId, mode: 'point', pointId: hit.id, moved: false,
            offset: { x: X(p.x) - local.x, y: Y(p.y) - local.y }
          };
        } else {
          selectOne(hit.id, e.shiftKey);
          state.pointer = { id: e.pointerId, mode: 'click', moved: false };
        }
      } else {
        if (!e.shiftKey) { state.selection = []; refreshAll(); render(); }
        state.pointer = {
          id: e.pointerId, mode: 'pan', start: local,
          view: { cx: state.view.cx, cy: state.view.cy }, moved: false
        };
      }
      return;
    }
    if (state.tool === 'measure') {
      measurePick(world);
      state.pointer = { id: e.pointerId, mode: 'click', moved: false };
      return;
    }
    if (state.tool === 'point') {
      pushHistory();
      const snap = snapWorld(world);
      const p = createPoint(snap.x, snap.y, { name: nextPointName() });
      state.selection = [p.id];
      state.snapInfo = null;
      refreshAll(); render(); scheduleSave();
      state.pointer = { id: e.pointerId, mode: 'click', moved: false };
      return;
    }
    if (state.tool === 'segment' || state.tool === 'line' || state.tool === 'vector' ||
      state.tool === 'circle' || state.tool === 'polygon') {
      if (!state.draft || state.draft.tool !== state.tool) startDraft(state.tool);
      state.draft.cursor = world;
      draftAddPoint(world);
      state.pointer = { id: e.pointerId, mode: 'draft', moved: false };
      return;
    }
    state.pointer = { id: e.pointerId, mode: 'click', moved: false };
  }
  function onPointerMove(e) {
    if (!cv) return;
    const local = eventLocal(e);
    const world = worldAt(local.x, local.y);
    const sx = Math.round(world.x * 100) / 100, sy = Math.round(world.y * 100) / 100;
    if (shellRef) shellRef.coord('(' + fmt(sx, 2) + ', ' + fmt(sy, 2) + ')');
    state.hover = { x: local.x, y: local.y, world: world };
    if (fingers.has(e.pointerId)) fingers.set(e.pointerId, { x: local.x, y: local.y });
    if (fingers.size >= 2) { updatePinch(); return; }
    const ptr = state.pointer;
    if (ptr && ptr.id === e.pointerId) {
      if (ptr.mode === 'pan') {
        const dx = local.x - ptr.start.x, dy = local.y - ptr.start.y;
        if (!ptr.moved && Math.hypot(dx, dy) > 2) ptr.moved = true;
        state.view.cx = ptr.view.cx - dx / state.view.scale;
        state.view.cy = ptr.view.cy + dy / state.view.scale;
        scheduleRender(); updateStatus(); return;
      }
      if (ptr.mode === 'point') {
        const p = byId(ptr.pointId);
        if (p) {
          const target = { x: world.x + ptr.offset.x / state.view.scale, y: world.y - ptr.offset.y / state.view.scale };
          const snap = snapWorld(target, { exclude: p.id });
          const inv = invertM(p.m);
          const b = applyM(inv, snap.x, snap.y);
          p.x = b.x; p.y = b.y;
          if (!ptr.moved && Math.hypot(local.x - (X(snap.x) - ptr.offset.x), local.y - (Y(snap.y) + ptr.offset.y)) > 1) ptr.moved = true;
          scheduleRender();
        }
        return;
      }
      if (ptr.mode === 'handle') {
        updateHandleDrag(world);
        return;
      }
      if (ptr.mode === 'draft') {
        if (state.draft) state.draft.cursor = world;
        state.snapInfo = snapWorld(world, { fine: e.altKey });
        scheduleRender(); return;
      }
      return;
    }
    if (state.draft) {
      state.draft.cursor = world;
      state.snapInfo = snapWorld(world, { fine: e.altKey });
      scheduleRender();
      return;
    }
    if (state.tool === 'point' || state.tool === 'segment' || state.tool === 'line' ||
      state.tool === 'vector' || state.tool === 'circle' || state.tool === 'polygon') {
      state.snapInfo = snapWorld(world, { fine: e.altKey });
      scheduleRender();
    } else if (state.tool === 'select' && state.handle && state.handle.phase === 'wait') {
      state.snapInfo = null;
    }
  }
  function onPointerUp(e) {
    fingers.delete(e.pointerId);
    if (state.pinch) {
      if (fingers.size < 2) { state.pinch = null; }
      return;
    }
    const ptr = state.pointer;
    if (ptr && ptr.id === e.pointerId) {
      if (ptr.mode === 'point') {
        refreshAll(); scheduleSave();
        shellRef && shellRef.coord('(' + fmt(worldAt(eventLocal(e).x, eventLocal(e).y).x, 2) + ', ' + fmt(worldAt(eventLocal(e).x, eventLocal(e).y).y, 2) + ')');
      } else if (ptr.mode === 'pan') {
        scheduleSave();
        shellRef && shellRef.status(statusText());
      } else if (ptr.mode === 'handle') {
        finishHandle();
      }
      state.pointer = null;
    }
    state.snapInfo = null;
    scheduleRender();
  }
  function onPointerCancel(e) {
    fingers.delete(e.pointerId);
    if (state.pointer && state.pointer.id === e.pointerId) {
      if (state.pointer.mode === 'handle') cancelHandle();
      state.pointer = null;
    }
    if (fingers.size < 2) state.pinch = null;
    state.snapInfo = null;
    scheduleRender();
  }
  function cancelGestureForPinch() {
    const ptr = state.pointer;
    if (ptr && ptr.mode === 'handle') cancelHandle();
    if (state.draft) cancelDraft();
    state.pointer = null;
    state.snapInfo = null;
  }
  function startPinch() {
    const arr = Array.from(fingers.values());
    if (arr.length < 2) return;
    const mid = { x: (arr[0].x + arr[1].x) / 2, y: (arr[0].y + arr[1].y) / 2 };
    const d = Math.max(1, Math.hypot(arr[0].x - arr[1].x, arr[0].y - arr[1].y));
    const world = worldAt(mid.x, mid.y);
    state.pinch = {
      d0: d, mid0: mid, world: world,
      view: { cx: state.view.cx, cy: state.view.cy, scale: state.view.scale }
    };
    state.pointer = null;
  }
  function updatePinch() {
    const p = state.pinch;
    if (!p) return;
    const arr = Array.from(fingers.values());
    if (arr.length < 2) return;
    const mid = { x: (arr[0].x + arr[1].x) / 2, y: (arr[0].y + arr[1].y) / 2 };
    const d = Math.max(1, Math.hypot(arr[0].x - arr[1].x, arr[0].y - arr[1].y));
    const scale = clamp(p.view.scale * (d / p.d0), 5, 420);
    state.view.scale = scale;
    // 让 pinch 开始时的世界点跟随当前双指中点
    state.view.cx = p.world.x - (mid.x - state.w / 2) / scale;
    state.view.cy = p.world.y + (mid.y - state.h / 2) / scale;
    scheduleRender();
  }
  function onWheel(e) {
    e.preventDefault();
    const local = eventLocal(e);
    const world = worldAt(local.x, local.y);
    const factor = Math.exp(-e.deltaY * 0.0014);
    const next = clamp(state.view.scale * factor, 5, 420);
    if (near(next, state.view.scale, 1e-6)) return;
    state.view.scale = next;
    state.view.cx = world.x - (local.x - state.w / 2) / next;
    state.view.cy = world.y + (local.y - state.h / 2) / next;
    scheduleRender(); scheduleSave();
  }
  function zoomBy(factor) {
    const sx = state.w / 2, sy = state.h / 2;
    const world = worldAt(sx, sy);
    const next = clamp(state.view.scale * factor, 5, 420);
    state.view.scale = next;
    state.view.cx = world.x - (sx - state.w / 2) / next;
    state.view.cy = world.y + (sy - state.h / 2) / next;
    scheduleRender(); scheduleSave(); updateZoomUI();
  }
  function resetView() {
    state.view = { cx: 0, cy: 0, scale: 54 };
    scheduleRender(); scheduleSave(); updateZoomUI();
    shellRef && shellRef.toast('视野已复位');
  }
  function panByPixels(dx, dy) {
    state.view.cx -= dx / state.view.scale;
    state.view.cy += dy / state.view.scale;
    scheduleRender(); scheduleSave();
  }

  /* ================= 键盘 ================= */
  function isEditingTarget(t) {
    if (!t) return false;
    const tag = (t.tagName || '').toLowerCase();
    return tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable;
  }
  function onKeyDown(e) {
    if (!shellRef || !cv || cv.offsetWidth === 0) return;
    if (isEditingTarget(e.target)) {
      if (e.key === 'Escape' && e.target.blur) e.target.blur();
      return;
    }
    const k = (e.key || '').toLowerCase();
    if (e.ctrlKey || e.metaKey) {
      if (k === 'z') {
        e.preventDefault();
        if (e.shiftKey) doRedo(); else doUndo();
      } else if (k === 'y') {
        e.preventDefault(); doRedo();
      } else if (k === 's') {
        e.preventDefault(); exportPNG();
      } else if (k === '0') {
        e.preventDefault(); resetView();
      }
      return;
    }
    if (k === 'escape') {
      e.preventDefault();
      if (state.handle) { cancelHandle(); shellRef.toast('已取消变换'); return; }
      if (state.draft) { cancelDraft(); shellRef.toast('已取消作图'); return; }
      state.measurePicks = [];
      if (state.tool !== 'select') setTool('select');
      else { state.selection = []; refreshAll(); render(); }
      updateStatus();
      return;
    }
    if (k === 'delete' || k === 'backspace') {
      e.preventDefault(); deleteSelection(); return;
    }
    if (k === 'enter') {
      if (state.draft && state.draft.tool === 'polygon') { e.preventDefault(); finishDraft(); }
      return;
    }
    if (k === 'arrowleft' || k === 'arrowright' || k === 'arrowup' || k === 'arrowdown') {
      e.preventDefault();
      const step = e.shiftKey ? 120 : 44;
      if (k === 'arrowleft') panByPixels(step, 0);
      else if (k === 'arrowright') panByPixels(-step, 0);
      else if (k === 'arrowup') panByPixels(0, step);
      else panByPixels(0, -step);
      return;
    }
    if (k === '+' || k === '=' || k === 'add') { e.preventDefault(); zoomBy(1.2); return; }
    if (k === '-' || k === '_' || k === 'subtract') { e.preventDefault(); zoomBy(1 / 1.2); return; }
    if (k === '0') { e.preventDefault(); resetView(); return; }
    const map = { v: 'select', p: 'point', s: 'segment', l: 'line', c: 'circle', g: 'polygon', r: 'vector', f: 'func', m: 'measure' };
    if (map[k]) { e.preventDefault(); setTool(map[k]); }
  }

  /* ================= 工具与状态 ================= */
  function setTool(t, opts) {
    opts = opts || {};
    if (state.handle && !opts.keepHandle) cancelHandle();
    if (state.draft && !opts.keepDraft) cancelDraft();
    state.tool = t;
    state.snapInfo = null;
    state.measurePicks = [];
    if (t === 'func' && refs.fnInput) {
      refs.fnInput.focus();
      refs.fnInput.select();
    }
    updateToolUI(); updateStatus(); render();
  }
  function statusText() {
    if (state.handle) {
      if (state.handle.phase === 'wait') return '拖拽手柄：在画布上拖动以' + (state.handle.kind === 'rotate' ? '旋转' : state.handle.kind === 'scale' ? '缩放' : '平移');
      return '松开完成变换 · Esc 取消';
    }
    if (state.draft) {
      if (state.draft.tool === 'polygon') return '继续点击顶点 · 点回起点 / Enter / 双击闭合 · Esc 取消';
      return '再点一次确定' + (state.draft.tool === 'circle' ? '半径点' : '终点') + ' · Esc 取消';
    }
    const map = {
      select: '拖动空白平移 · 滚轮或双指缩放 · 点选对象，拖点可移动',
      point: '单击放置点 · 自动吸附网格与已有点',
      segment: '单击两个端点画线段 · 吸附已有点',
      line: '单击两点确定直线 · 直线无限延伸',
      circle: '先点圆心，再点半径点',
      polygon: '依次点击顶点 · Enter 或点回起点闭合',
      vector: '单击起点与终点画向量',
      func: '在左侧输入解析式并按 Enter 绘制',
      measure: state.measureMode === 'angle' ? '角度测量：依次点三个点，第二个点是顶点' :
        state.measureMode === 'area' ? '面积测量：点击一个多边形' : '距离测量：依次点两个点'
    };
    return map[state.tool] || '拖动空白平移 · 滚轮缩放';
  }
  function updateStatus() {
    if (shellRef) shellRef.status(statusText());
    updateCoordHint();
  }
  function updateCoordHint() {
    if (!shellRef) return;
    const h = state.hover;
    if (!h) { shellRef.coord('(0.00, 0.00)'); return; }
    const w = h.world || worldAt(h.x, h.y);
    shellRef.coord('(' + fmt(w.x, 2) + ', ' + fmt(w.y, 2) + ')');
  }
  function updateToolUI() {
    Object.keys(refs.tools || {}).forEach(function (id) {
      refs.tools[id].classList.toggle('on', state.tool === id);
    });
  }
  function updateZoomUI() {
    if (refs.zoomPct) refs.zoomPct.textContent = Math.round(state.view.scale / 54 * 100) + '%';
  }
  function updateTitle() {
    if (!shellRef) return;
    const n = state.objects.filter(function (o) { return !o.aux; }).length;
    let t = '数学 · ' + n + ' 个对象';
    if (state.lastTransform && !isI(state.lastTransform.matrix)) t += ' · ' + truncate(state.lastTransform.label, 12);
    shellRef.setTitle(t);
  }

  /* ================= 面板 ================= */
  function buildStage(shell) {
    shell.stage.innerHTML = '';
    cv = document.createElement('canvas');
    cv.className = 'lm-cv';
    cv.setAttribute('aria-label', '变换实验室画布');
    cv.tabIndex = 0;
    shell.stage.appendChild(cv);
    ctx = cv.getContext('2d');

    const bar = el('div', { class: 'lm-bar' });
    refs.tools = {};
    const toolDefs = [
      ['select', '选择', 'V', 'select'], ['point', '点', 'P', 'point'],
      ['segment', '线段', 'S', 'segment'], ['line', '直线', 'L', 'line'],
      ['circle', '圆', 'C', 'circle'], ['polygon', '多边形', 'G', 'polygon'],
      ['vector', '向量', 'R', 'vector'], ['func', '函数', 'F', 'func'],
      ['measure', '测量', 'M', 'measure']
    ];
    toolDefs.forEach(function (t) {
      const b = el('button', { class: 'lm-tool', type: 'button', title: t[1] + ' (' + t[2] + ')' });
      b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[t[3]] + '</svg><span>' + t[1] + '</span>';
      b.addEventListener('click', function () { setTool(t[0]); });
      bar.appendChild(b);
      refs.tools[t[0]] = b;
    });
    bar.appendChild(el('span', { class: 'lm-sep' }));
    function action(icon, title, fn) {
      const b = el('button', { class: 'lm-act', type: 'button', title: title });
      b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS[icon] + '</svg>';
      b.addEventListener('click', fn);
      bar.appendChild(b);
      return b;
    }
    refs.undo = action('undo', '撤销 (Ctrl+Z)', function () { doUndo(); });
    refs.redo = action('redo', '重做 (Ctrl+Shift+Z)', function () { doRedo(); });
    refs.clear = action('trash', '清空画布', clearScene);
    refs.export = action('export', '导出 PNG (Ctrl+S)', function () { exportPNG(); });
    shell.stage.appendChild(bar);

    // 右下角缩放条：放在自己的画布 host 里，模式切换时随画布一起隐藏
    const zoom = el('div', { class: 'lm-zoom lab-float' });
    Object.assign(zoom.style, { right: '10px', bottom: '10px' });
    shell.stage.appendChild(zoom);
    const zout = el('button', { type: 'button', title: '缩小 (−)' });
    zout.innerHTML = '<svg viewBox="0 0 24 24">' + ICONS.zoomOut + '</svg>';
    zout.addEventListener('click', function () { zoomBy(1 / 1.2); updateZoomUI(); });
    const pct = el('button', { type: 'button', class: 'lm-pct', title: '复位到 100%' }, '100%');
    pct.addEventListener('click', function () { state.view.scale = 54; scheduleRender(); scheduleSave(); updateZoomUI(); });
    const zin = el('button', { type: 'button', title: '放大 (+)' });
    zin.innerHTML = '<svg viewBox="0 0 24 24">' + ICONS.zoomIn + '</svg>';
    zin.addEventListener('click', function () { zoomBy(1.2); updateZoomUI(); });
    const fit = el('button', { type: 'button', title: '适配全部对象' });
    fit.innerHTML = '<svg viewBox="0 0 24 24">' + ICONS.reset + '</svg>';
    fit.addEventListener('click', fitView);
    zoom.appendChild(zout); zoom.appendChild(pct); zoom.appendChild(zin); zoom.appendChild(fit);
    refs.zoomPct = pct;

    cv.addEventListener('pointerdown', onPointerDown);
    cv.addEventListener('pointermove', onPointerMove);
    cv.addEventListener('pointerup', onPointerUp);
    cv.addEventListener('pointercancel', onPointerCancel);
    cv.addEventListener('dblclick', function (e) {
      if (state.draft && state.draft.tool === 'polygon' && state.draft.ids.length >= 3) {
        e.preventDefault();
        finishDraft();
      }
    });
    cv.addEventListener('pointerleave', function (e) {
      if (!state.pointer) { state.snapInfo = null; scheduleRender(); }
    });
    cv.addEventListener('wheel', onWheel, { passive: false });
    cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });

    document.addEventListener('keydown', onKeyDown);
    if (window.ResizeObserver) {
      resizeObs = new ResizeObserver(function () { resizeCanvas(); scheduleRender(); });
      resizeObs.observe(shell.stage);
    }
    window.addEventListener('resize', function () { resizeCanvas(); scheduleRender(); });
    window.addEventListener('beforeunload', saveState);
  }
  function section(title, cls) {
    const sec = el('div', { class: 'lab-sec' + (cls ? ' ' + cls : '') });
    const h = el('div', { class: 'lab-sec-h' }, esc(title) + ' <i></i>');
    sec.appendChild(h);
    return sec;
  }
  function checkRow(label, checked, cb) {
    const wrap = el('label', { class: 'lm-check' });
    const inp = el('input', { type: 'checkbox' });
    inp.checked = !!checked;
    inp.addEventListener('change', function () { cb(inp.checked); });
    wrap.appendChild(inp);
    wrap.appendChild(el('span', {}, label));
    return wrap;
  }
  function buildLeft() {
    const left = shellRef.left;
    left.innerHTML = '';
    refs = refs || {};
    refs.fnSection = null;

    const fnSec = section('函数作图');
    const row = el('div', { class: 'lm-fn-row' });
    const inp = el('input', { class: 'lab-in lm-fn-in', type: 'text', placeholder: '如 2sin(x)+1', spellcheck: 'false' });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); addFunctionFromInput(); } });
    const btn = el('button', { class: 'lab-btn lm-fn-btn', type: 'button' }, '绘制');
    btn.addEventListener('click', addFunctionFromInput);
    row.appendChild(inp); row.appendChild(btn);
    fnSec.appendChild(row);
    fnSec.appendChild(el('div', { class: 'lab-hint' }, '支持 sin cos tan sqrt ln exp · ^ · π'));
    left.appendChild(fnSec);
    refs.fnInput = inp;

    const objSec = section('对象');
    const objHead = objSec.querySelector('.lab-sec-h');
    const count = el('span', { class: 'lm-count' }, '0');
    objHead.insertBefore(count, objHead.querySelector('i'));
    refs.objCount = count;
    const list = el('div', { class: 'lab-list lm-objs' });
    objSec.appendChild(list);
    left.appendChild(objSec);
    refs.objList = list;

    const preSec = section('预设');
    const preList = el('div', { class: 'lab-list lm-presets' });
    refs.presetBtns = {};
    PRESETS.forEach(function (p, i) {
      const b = el('button', { class: 'lab-item lm-preset', type: 'button', title: p.desc });
      b.innerHTML = '<span class="lm-pre-no">0' + (i + 1) + '</span><span class="lm-pre-name">' + esc(p.name) + '</span>' +
        '<svg class="lm-pre-chev" viewBox="0 0 24 24" aria-hidden="true">' + ICONS.chevron + '</svg>';
      b.addEventListener('click', function () { applyPreset(p.id); });
      preList.appendChild(b);
      refs.presetBtns[p.id] = b;
    });
    preSec.appendChild(preList);
    left.appendChild(preSec);

    const dispSec = section('显示');
    const toggleBox = el('div', { class: 'lm-toggles' });
    toggleBox.appendChild(checkRow('网格', state.showGrid, function (v) { state.showGrid = v; render(); scheduleSave(); }));
    toggleBox.appendChild(checkRow('吸附', state.snapGrid, function (v) { state.snapGrid = v; scheduleSave(); }));
    const leftMeasure = checkRow('测量', state.showMeasure, function (v) {
      state.showMeasure = v; updateMeasureUI(); render(); scheduleSave();
    });
    refs.leftMeasure = leftMeasure.querySelector('input');
    toggleBox.appendChild(leftMeasure);
    toggleBox.appendChild(checkRow('变换标注', state.showAnnotation, function (v) { state.showAnnotation = v; render(); scheduleSave(); }));
    dispSec.appendChild(toggleBox);
    dispSec.appendChild(el('div', { class: 'lab-hint' }, 'Esc 取消 · Delete 删除 · Ctrl+Z 撤销'));
    left.appendChild(dispSec);

    // 视野按钮：拖拽 / 方向键之外的第三种平移方式
    const panSec = section('视野');
    const panGrid = el('div', { class: 'lm-pan' });
    function panButton(dir, title, path, cls) {
      const b = el('button', { class: 'lab-btn lm-pan-btn' + (cls ? ' ' + cls : ''), type: 'button', title: title });
      b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + path + '</svg>';
      b.addEventListener('click', function () {
        if (dir === 'reset') resetView();
        else if (dir === 'left') panByPixels(44, 0);
        else if (dir === 'right') panByPixels(-44, 0);
        else if (dir === 'up') panByPixels(0, 44);
        else panByPixels(0, -44);
      });
      panGrid.appendChild(b);
    }
    panButton('left', '视野左移 (←)', '<path d="M19 12H5M11 6l-6 6 6 6"/>');
    panButton('up', '视野上移 (↑)', '<path d="M12 19V5M6 11l6-6 6 6"/>');
    panButton('reset', '视野复位 (0)', '<path d="M4.5 9.5V4.5h5M19.5 14.5v5h-5"/><path d="M5.2 14.2A7.2 7.2 0 0 0 18.7 16M18.8 9.8A7.2 7.2 0 0 0 5.3 8"/>', 'lm-pan-reset');
    panButton('down', '视野下移 (↓)', '<path d="M12 5v14M6 13l6 6 6-6"/>');
    panButton('right', '视野右移 (→)', '<path d="M5 12h14M13 6l6 6-6 6"/>');
    panSec.appendChild(panGrid);
    left.appendChild(panSec);
  }
  function buildRight() {
    const right = shellRef.right;
    right.innerHTML = '';

    const propSec = section('选中对象');
    refs.propBody = el('div', { class: 'lm-prop' });
    propSec.appendChild(refs.propBody);
    right.appendChild(propSec);

    const matSec = section('变换矩阵');
    refs.matrixBody = el('div', { class: 'lm-matrix' });
    matSec.appendChild(refs.matrixBody);
    right.appendChild(matSec);

    const tfSec = section('变换');
    const pivotRow = el('div', { class: 'lm-trow' });
    pivotRow.appendChild(el('span', { class: 'lm-trow-n' }, '中心'));
    const pivotSel = el('select', { class: 'lab-in lm-sel lm-pivot' });
    pivotSel.addEventListener('change', function () { state.pivotMode = pivotSel.value; scheduleSave(); });
    pivotRow.appendChild(pivotSel);
    tfSec.appendChild(pivotRow);
    refs.pivotSel = pivotSel;

    function transRow(name, inputs, applyFn, handleKind, title) {
      const r = el('div', { class: 'lm-trow' });
      r.appendChild(el('span', { class: 'lm-trow-n' }, name));
      inputs.forEach(function (opt) {
        const i = el('input', { class: 'lab-in lm-numsm', type: 'number', step: opt.step || '0.1' });
        i.value = opt.value;
        i.placeholder = opt.placeholder || '';
        r.appendChild(i);
        opt.ref = i;
      });
      const ap = el('button', { class: 'lab-btn lm-ibtn', type: 'button', title: title || '按数值应用' }, '应用');
      ap.addEventListener('click', applyFn);
      r.appendChild(ap);
      if (handleKind) {
        const hb = el('button', { class: 'lab-btn lm-ibtn', type: 'button', title: '在画布上拖拽手柄' }, '拖');
        hb.addEventListener('click', function () { beginHandle(handleKind); });
        r.appendChild(hb);
      }
      tfSec.appendChild(r);
    }
    const txX = { value: '2', placeholder: 'dx' }, txY = { value: '1', placeholder: 'dy' };
    transRow('平移', [txX, txY], function () { numericApply('translate'); }, 'translate', '平移 dx / dy');
    refs.txX = txX.ref; refs.txY = txY.ref;
    const ang = { value: '90', placeholder: '°', step: '1' };
    transRow('旋转', [ang], function () { numericApply('rotate'); }, 'rotate', '绕旋转中心旋转');
    refs.txAngle = ang.ref;
    const kk = { value: '2', placeholder: 'k', step: '0.1' };
    transRow('缩放', [kk], function () { numericApply('scale'); }, 'scale', '绕旋转中心缩放');
    refs.txK = kk.ref;

    const symRow = el('div', { class: 'lm-trow' });
    symRow.appendChild(el('span', { class: 'lm-trow-n' }, '对称'));
    const bPoint = el('button', { class: 'lab-btn lm-ibtn lm-ibtn-wide', type: 'button', title: '关于旋转中心作点对称' }, '关于点');
    bPoint.addEventListener('click', applySymPoint);
    const bLine = el('button', { class: 'lab-btn lm-ibtn lm-ibtn-wide', type: 'button', title: '关于下方对称轴作线对称' }, '关于线');
    bLine.addEventListener('click', applySymLine);
    symRow.appendChild(bPoint); symRow.appendChild(bLine);
    tfSec.appendChild(symRow);

    const axisRow = el('div', { class: 'lm-trow' });
    axisRow.appendChild(el('span', { class: 'lm-trow-n' }, '对称轴'));
    const axisSel = el('select', { class: 'lab-in lm-sel' });
    axisSel.addEventListener('change', function () { state.axisMode = axisSel.value; scheduleSave(); });
    axisRow.appendChild(axisSel);
    tfSec.appendChild(axisRow);
    tfSec.appendChild(el('div', { class: 'lab-hint' }, '拖动空白平移 · 滚轮缩放 · 双指捏合'));
    right.appendChild(tfSec);
    refs.axisSel = axisSel;

    const preSec = section('预设参数');
    refs.presetBody = el('div', { class: 'lm-preset-body' });
    preSec.appendChild(refs.presetBody);
    right.appendChild(preSec);

    const meaSec = section('测量');
    refs.measureBtns = {};
    const mg = el('div', { class: 'lm-measure-grid' });
    [['dist', '距离'], ['angle', '角度'], ['area', '面积']].forEach(function (m) {
      const b = el('button', { class: 'lab-btn lm-measure-btn', type: 'button' }, m[1]);
      b.addEventListener('click', function () {
        state.measureMode = m[0];
        state.measurePicks = [];
        setTool('measure');
        updateMeasureUI();
      });
      mg.appendChild(b);
      refs.measureBtns[m[0]] = b;
    });
    meaSec.appendChild(mg);
    refs.measureToggle = checkRow('显示测量', state.showMeasure, function (v) {
      state.showMeasure = v; updateMeasureUI(); render(); scheduleSave();
    });
    meaSec.appendChild(refs.measureToggle);
    meaSec.appendChild(el('div', { class: 'lab-hint' }, '测量对象会出现在左侧对象列表'));
    right.appendChild(meaSec);
    refs.measureBody = mg;
    // 预设参数放在矩阵之后，打开预设时滑块 / 一键演示不用滚到底部
    right.insertBefore(preSec, tfSec);
  }
  function rebuildPanelsIfNeeded() {
    if (!shellRef) return;
    if (!shellRef.left.childElementCount) buildLeft();
    if (!shellRef.right.childElementCount) buildRight();
  }
  function refreshAll() {
    rebuildPanelsIfNeeded();
    renderObjectList();
    renderProperties();
    renderMatrix();
    renderPresetBody();
    renderTransformControls();
    updateMeasureUI();
    updateToolUI();
    updateHistoryUI();
    updateTitle();
    updateStatus();
    updateZoomUI();
    Object.keys(refs.presetBtns || {}).forEach(function (id) {
      refs.presetBtns[id].classList.toggle('on', state.preset === id);
    });
  }
  function renderObjectList() {
    if (!refs.objList) return;
    const list = refs.objList;
    list.innerHTML = '';
    const objs = state.objects.filter(function (o) { return !o.aux; });
    if (refs.objCount) refs.objCount.textContent = String(objs.length);
    if (!objs.length) {
      list.appendChild(el('div', { class: 'lab-empty' }, '还没有对象<br>用顶部工具开始作图'));
      return;
    }
    objs.forEach(function (o) {
      const sel = state.selection.indexOf(o.id) >= 0;
      const row = el('div', {
        class: 'lab-item lm-obj' + (sel ? ' on' : '') + (o.hidden ? ' lm-off' : ''),
        role: 'button', tabindex: '0', title: objectLabel(o) + ' · ' + objectMeta(o)
      });
      const dot = el('span', { class: 'lm-dot' });
      dot.style.background = objectColor(o);
      row.appendChild(dot);
      const name = el('span', { class: 'lm-obj-name' });
      name.textContent = objectLabel(o);
      row.appendChild(name);
      row.appendChild(el('span', { class: 'lm-obj-type' }, TYPE_NAMES[o.type] || ''));
      const eye = el('button', { class: 'lm-eye' + (o.hidden ? ' off' : ''), type: 'button', title: o.hidden ? '显示' : '隐藏' });
      eye.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + (o.hidden ? ICONS.eyeOff : ICONS.eye) + '</svg>';
      eye.addEventListener('click', function (e) {
        e.stopPropagation();
        pushHistory();
        o.hidden = !o.hidden;
        refreshAll(); render(); scheduleSave();
      });
      const del = el('button', { class: 'lm-del', type: 'button', title: '删除' });
      del.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICONS.trash + '</svg>';
      del.addEventListener('click', function (e) {
        e.stopPropagation();
        pushHistory();
        removeObjects([o.id]);
        shellRef && shellRef.toast('已删除 · Ctrl+Z 可撤销');
      });
      row.appendChild(eye); row.appendChild(del);
      row.addEventListener('click', function (e) {
        if (e.target.closest('.lm-eye,.lm-del')) return;
        selectOne(o.id, e.shiftKey);
      });
      row.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectOne(o.id, e.shiftKey); }
      });
      list.appendChild(row);
    });
  }
  function addKV(body, label, value, cls) {
    const row = el('div', { class: 'lab-kv' + (cls ? ' ' + cls : '') });
    row.appendChild(el('span', {}, label));
    const b = el('b', {}, String(value));
    row.appendChild(b);
    body.appendChild(row);
    return row;
  }
  function addField(body, label, value, step, onchange) {
    const row = el('div', { class: 'lm-field' });
    row.appendChild(el('span', { class: 'lm-field-n' }, label));
    const inp = el('input', { class: 'lab-in lm-num', type: 'number', step: step || '0.1' });
    inp.value = value;
    inp.addEventListener('change', function () {
      const v = parseFloat(inp.value);
      if (!isNum(v)) { inp.value = value; return; }
      onchange(v);
    });
    row.appendChild(inp);
    body.appendChild(row);
    return inp;
  }
  function swatchRow(body, sel) {
    const row = el('div', { class: 'lm-swatches' });
    COLOR_KEYS.forEach(function (ck) {
      const b = el('button', { class: 'lm-swatch', type: 'button', title: ck[1], 'aria-label': ck[1] });
      b.style.background = colorOf(ck[0]);
      if (sel.every(function (o) { return o.color === ck[0]; })) b.classList.add('on');
      b.addEventListener('click', function () {
        pushHistory();
        sel.forEach(function (o) { o.color = ck[0]; });
        if (refs.objList) renderObjectList();
        renderProperties(); render(); scheduleSave();
      });
      row.appendChild(b);
    });
    body.appendChild(row);
  }
  function widthRow(body, sel) {
    const cur = sel[0].width || 2;
    const wrap = el('div', { class: 'lm-width' });
    const head = el('div', { class: 'lm-width-h' });
    head.appendChild(el('span', {}, '线宽'));
    const val = el('b', {}, fmt(cur, 1));
    head.appendChild(val);
    const inp = el('input', { class: 'lab-slider lm-slider', type: 'range', min: '1', max: '5', step: '0.5' });
    inp.value = cur;
    let dirty = false;
    function begin() { dirty = false; }
    inp.addEventListener('pointerdown', begin);
    inp.addEventListener('focus', begin);
    inp.addEventListener('keydown', function () {
      if (!dirty) { pushHistory(); dirty = true; }
    });
    inp.addEventListener('input', function () {
      if (!dirty) { pushHistory(); dirty = true; }
      const v = parseFloat(inp.value);
      val.textContent = fmt(v, 1);
      sel.forEach(function (o) { o.width = v; });
      render(); scheduleSave();
    });
    inp.addEventListener('change', function () { dirty = false; });
    wrap.appendChild(head); wrap.appendChild(inp);
    body.appendChild(wrap);
  }
  function propertyActions(body, sel) {
    const row = el('div', { class: 'lm-prop-actions' });
    const vis = el('button', { class: 'lab-btn lm-prop-btn', type: 'button' }, '显示/隐藏');
    vis.addEventListener('click', function () {
      pushHistory();
      const hide = !sel.every(function (o) { return o.hidden; });
      sel.forEach(function (o) { o.hidden = hide; });
      refreshAll(); render(); scheduleSave();
    });
    const del = el('button', { class: 'lab-btn lm-prop-btn lm-danger', type: 'button' }, '删除');
    del.addEventListener('click', deleteSelection);
    row.appendChild(vis); row.appendChild(del);
    body.appendChild(row);
  }
  function renderProperties() {
    const body = refs.propBody;
    if (!body) return;
    body.innerHTML = '';
    const sel = state.selection.map(byId).filter(Boolean);
    if (!sel.length) {
      body.appendChild(el('div', { class: 'lab-empty' }, '未选中对象<br>点选图形或点 · Shift 多选'));
      return;
    }
    if (sel.length > 1) {
      addKV(body, '已选', sel.length + ' 个对象');
      const types = {};
      sel.forEach(function (o) { types[TYPE_NAMES[o.type] || o.type] = true; });
      addKV(body, '类型', Object.keys(types).join(' / '));
      addKV(body, '提示', '变换会同时作用于图形与顶点');
      swatchRow(body, sel); widthRow(body, sel); propertyActions(body, sel);
      return;
    }
    const o = sel[0];
    const head = el('div', { class: 'lm-prop-title' });
    const hb = el('b', {});
    hb.textContent = objectLabel(o);
    head.appendChild(hb);
    head.appendChild(el('span', {}, TYPE_NAMES[o.type] || '对象'));
    body.appendChild(head);
    if (o.type === 'point') {
      const p = curOfPoint(o);
      addField(body, 'x', fmt(p.x, 3), '0.1', function (v) {
        pushHistory();
        const b = applyM(invertM(o.m), v, p.y);
        o.x = b.x; o.y = b.y;
        refreshAll(); render(); scheduleSave();
      });
      addField(body, 'y', fmt(p.y, 3), '0.1', function (v) {
        pushHistory();
        const b = applyM(invertM(o.m), p.x, v);
        o.x = b.x; o.y = b.y;
        refreshAll(); render(); scheduleSave();
      });
      if (!isI(o.m)) addKV(body, '状态', '已变换 · ghost 为原像');
    } else if (o.type === 'circle') {
      const c = currentCircle(o);
      const rp = byId(o.r), cp = byId(o.c);
      addKV(body, '圆心', fmtPt(c.c));
      addKV(body, '半径', fmt(c.r, 3));
      addField(body, 'r', fmt(c.r, 3), '0.1', function (v) {
        if (v <= 0.001) return;
        pushHistory();
        const dir = { x: (curOfPoint(rp).x - c.c.x) / (c.r || 1), y: (curOfPoint(rp).y - c.c.y) / (c.r || 1) };
        const target = { x: c.c.x + dir.x * v, y: c.c.y + dir.y * v };
        const b = applyM(invertM(rp.m), target.x, target.y);
        rp.x = b.x; rp.y = b.y;
        refreshAll(); render(); scheduleSave();
      });
      addKV(body, '半径点', (rp && rp.name) || '');
    } else if (o.type === 'segment') {
      const a = curOfId(o.a), b = curOfId(o.b);
      addKV(body, '端点 A', fmtPt(a));
      addKV(body, '端点 B', fmtPt(b));
      addKV(body, '长度', fmt(segmentLen(o), 3));
    } else if (o.type === 'line') {
      const a = curOfId(o.a), b = curOfId(o.b);
      const ang = Math.atan2(b.y - a.y, b.x - a.x);
      addKV(body, '过点', fmtPt(a));
      addKV(body, '倾角', fmtAngle(ang));
      addKV(body, '方向', '(' + fmt(b.x - a.x, 2) + ', ' + fmt(b.y - a.y, 2) + ')');
    } else if (o.type === 'vector') {
      const a = curOfId(o.a), b = curOfId(o.b);
      addKV(body, '起点', fmtPt(a));
      addKV(body, '终点', fmtPt(b));
      addKV(body, '分量', '(' + fmt(b.x - a.x, 2) + ', ' + fmt(b.y - a.y, 2) + ')');
      addKV(body, '模长', fmt(segmentLen(o), 3));
    } else if (o.type === 'polygon') {
      addKV(body, '顶点数', (o.pts || []).length);
      addKV(body, '面积', fmt(polygonArea(o), 3));
      addKV(body, '周长', fmt(polygonPerimeter(o), 3));
    } else if (o.type === 'function') {
      const row = el('div', { class: 'lm-fn-edit' });
      const inp = el('input', { class: 'lab-in', type: 'text', spellcheck: 'false' });
      inp.value = prettyExpr(o.expr);
      const b = el('button', { class: 'lab-btn', type: 'button' }, '更新');
      function apply() {
        try {
          const expr = normalizeExpr(inp.value);
          compileExpr(expr);
          pushHistory();
          setFunctionExpr(o, expr);
          refreshAll(); render(); scheduleSave();
          shellRef && shellRef.toast('函数已更新');
        } catch (e) { shellRef && shellRef.toast(e.message || '表达式无效'); }
      }
      b.addEventListener('click', apply);
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); apply(); } });
      row.appendChild(inp); row.appendChild(b);
      body.appendChild(row);
      addKV(body, 'y =', truncate(prettyExpr(o.expr), 26));
      addKV(body, 'f(0)', fmt(o.fn(0), 3));
      addKV(body, 'f(1)', fmt(o.fn(1), 3));
    } else if (o.type === 'mdist') {
      addKV(body, '类型', '两点距离');
      addKV(body, '数值', fmt(segmentLen(o), 3));
    } else if (o.type === 'mangle') {
      addKV(body, '类型', '三点角度');
      addKV(body, '数值', fmtAngle(angleOf(o)));
    } else if (o.type === 'marea') {
      const p = byId(o.poly);
      addKV(body, '类型', '多边形面积');
      addKV(body, '数值', p ? fmt(polygonArea(p), 3) : '—');
    }
    if (!(o.type === 'mdist' || o.type === 'mangle' || o.type === 'marea')) {
      swatchRow(body, sel);
      widthRow(body, sel);
    }
    propertyActions(body, sel);
  }
  function renderMatrix() {
    const body = refs.matrixBody;
    if (!body) return;
    body.innerHTML = '';
    const lt = currentTransform() || {
      type: 'identity', label: '尚未变换，当前为单位矩阵',
      matrix: IDENT.slice(), params: {}
    };
    const h = el('div', { class: 'lm-matrix-h' });
    h.appendChild(el('span', {}, 'T'));
    h.appendChild(el('em', {}, lt.label || ''));
    body.appendChild(h);
    const rows = el('div', { class: 'lm-matrix-rows' });
    matrixRows(lt.matrix).forEach(function (r) { rows.appendChild(el('div', { class: 'lm-matrix-row' }, r)); });
    body.appendChild(rows);
    if (lt.type === 'rotate' && lt.params && isNum(lt.params.angle)) {
      body.appendChild(el('div', { class: 'lm-matrix-param' }, '角度 θ = ' + fmt(lt.params.angle, 2) + '° · 中心 ' + (lt.params.pivot ? pivotLabel(lt.params.pivot) : '原点')));
    } else if (lt.type === 'scale' && lt.params && isNum(lt.params.k)) {
      body.appendChild(el('div', { class: 'lm-matrix-param' }, '比例 k = ' + fmt(lt.params.k, 3) + ' · 中心 ' + (lt.params.pivot ? pivotLabel(lt.params.pivot) : '原点')));
    } else if (lt.type === 'translate' && lt.params && isNum(lt.params.dx)) {
      body.appendChild(el('div', { class: 'lm-matrix-param' }, '向量 (' + fmt(lt.params.dx, 2) + ', ' + fmt(lt.params.dy, 2) + ')'));
    } else if (lt.type === 'sym-line') {
      body.appendChild(el('div', { class: 'lm-matrix-param' }, '对称轴 · ' + (lt.params.axisLabel || '直线')));
    } else if (lt.type === 'sym-point') {
      body.appendChild(el('div', { class: 'lm-matrix-param' }, '对称中心 · ' + (lt.params.pivot ? pivotLabel(lt.params.pivot) : '原点')));
    } else if (lt.type === 'identity') {
      body.appendChild(el('div', { class: 'lm-matrix-param' }, '选择对象后可做平移 / 旋转 / 缩放 / 对称'));
    }
    const cum = selectionMatrix();
    if (cum && !isI(cum) && !matrixEqual(cum, lt.matrix)) {
      body.appendChild(el('div', { class: 'lm-matrix-sub-h' }, '累计 M'));
      const cr = el('div', { class: 'lm-matrix-rows lm-cum' });
      matrixRows(cum).forEach(function (r) { cr.appendChild(el('div', { class: 'lm-matrix-row' }, r)); });
      body.appendChild(cr);
    }
  }
  function matrixEqual(a, b) {
    if (!a || !b) return false;
    for (let i = 0; i < 9; i++) if (!near(a[i], b[i], 1e-9)) return false;
    return true;
  }
  function renderTransformControls() {
    if (!refs.pivotSel) return;
    const pivot = refs.pivotSel;
    const prev = state.pivotMode;
    pivot.innerHTML = '';
    function opt(v, label) {
      const o = el('option', { value: v }, label);
      pivot.appendChild(o);
      return o;
    }
    opt('origin', '原点 (0, 0)');
    opt('center', '选中对象中心');
    state.objects.forEach(function (o) {
      if (o.type === 'point' && !o.aux) opt('point:' + o.id, '点 ' + (o.name || '') + ' ' + fmtPt(curOfPoint(o)));
    });
    if (!Array.from(pivot.options).some(function (o) { return o.value === prev; })) {
      state.pivotMode = 'origin';
    }
    pivot.value = state.pivotMode;
    const axis = refs.axisSel;
    if (axis) {
      const aprev = state.axisMode;
      axis.innerHTML = '';
      function aopt(v, label) {
        const o = el('option', { value: v }, label);
        axis.appendChild(o);
      }
      aopt('x', 'x 轴 (y = 0)');
      aopt('y', 'y 轴 (x = 0)');
      state.objects.forEach(function (o) {
        if (o.type === 'line' && !o.aux) aopt('line:' + o.id, '直线 ' + objectLabel(o));
      });
      if (!Array.from(axis.options).some(function (o) { return o.value === aprev; })) state.axisMode = 'x';
      axis.value = state.axisMode;
    }
  }
  function presetSlider(body, label, key, min, max, step, val, fmtFn) {
    const wrap = el('div', { class: 'lm-param' });
    const head = el('div', { class: 'lm-param-h' });
    head.appendChild(el('span', {}, label));
    const v = el('b', {}, fmtFn(val));
    head.appendChild(v);
    const inp = el('input', { class: 'lab-slider lm-slider', type: 'range', min: String(min), max: String(max), step: String(step) });
    inp.value = val;
    let dirty = false;
    inp.addEventListener('pointerdown', function () { dirty = false; });
    inp.addEventListener('focus', function () { dirty = false; });
    inp.addEventListener('keydown', function () { if (!dirty) { pushHistory(); dirty = true; } });
    inp.addEventListener('input', function () {
      if (!dirty) { pushHistory(); dirty = true; }
      let nv = parseFloat(inp.value);
      if (state.preset === 'inverse' && key === 'k' && Math.abs(nv) < 0.125) {
        nv = nv < 0 ? -0.25 : 0.25;
        inp.value = String(nv);
      }
      state.params[key] = nv;
      v.textContent = fmtFn(nv);
      refreshPresetObjects();
      if (refs.presetEq && state.preset === 'circletangent') refs.presetEq.textContent = tangentEquation();
      render(); scheduleSave();
    });
    inp.addEventListener('change', function () { dirty = false; });
    wrap.appendChild(head); wrap.appendChild(inp);
    body.appendChild(wrap);
  }
  function renderPresetBody() {
    const body = refs.presetBody;
    if (!body) return;
    body.innerHTML = '';
    refs.presetEq = null;
    if (!state.preset) {
      body.appendChild(el('div', { class: 'lab-empty' }, '从左侧选择一个预设'));
      return;
    }
    if (state.preset === 'triangle') {
      body.appendChild(el('div', { class: 'lm-preset-desc' }, '原像保留为虚线 ghost，实线为当前像；连续点击可叠加。'));
      const grid = el('div', { class: 'lm-demo-grid' });
      [['translate', '平移 (2, 1)'], ['rotate', '旋转 60°'], ['scale', '缩放 ×1.5'], ['sym', '关于 x 轴对称']].forEach(function (d) {
        const b = el('button', { class: 'lab-btn lm-demo', type: 'button' }, d[1]);
        b.addEventListener('click', function () { triangleDemo(d[0]); });
        grid.appendChild(b);
      });
      body.appendChild(grid);
      return;
    }
    if (state.preset === 'quadratic') {
      body.appendChild(el('div', { class: 'lm-formula' }, 'y = a(x − h)² + k'));
      const p = state.params;
      presetSlider(body, 'a · 开口', 'a', -2, 2, 0.1, p.a, function (v) { return fmt(v, 1); });
      presetSlider(body, 'h · 横移', 'h', -5, 5, 0.1, p.h, function (v) { return fmt(v, 1); });
      presetSlider(body, 'k · 纵移', 'k', -5, 4, 0.1, p.k, function (v) { return fmt(v, 1); });
      return;
    }
    if (state.preset === 'trig') {
      body.appendChild(el('div', { class: 'lm-formula' }, 'y = A sin(Bx + φ) + k'));
      const p = state.params;
      presetSlider(body, 'A · 振幅', 'A', -3, 3, 0.1, p.A, function (v) { return fmt(v, 1); });
      presetSlider(body, 'B · 频率', 'B', 0.2, 4, 0.1, p.B, function (v) { return fmt(v, 1); });
      presetSlider(body, 'φ · 初相', 'phi', -PI, PI, 0.05, p.phi, function (v) { return fmt(v, 2) + ' rad'; });
      presetSlider(body, 'k · 纵移', 'k', -3, 3, 0.1, p.k, function (v) { return fmt(v, 1); });
      return;
    }
    if (state.preset === 'inverse') {
      body.appendChild(el('div', { class: 'lm-formula' }, 'y = k / x'));
      presetSlider(body, 'k', 'k', -8, 8, 0.25, state.params.k, function (v) { return fmt(v, 2); });
      body.appendChild(el('div', { class: 'lab-hint' }, '两支曲线分别位于一三象限或二四象限。'));
      return;
    }
    if (state.preset === 'circletangent') {
      body.appendChild(el('div', { class: 'lm-formula' }, 'x cos θ + y sin θ = r'));
      const p = state.params;
      presetSlider(body, 'r · 半径', 'r', 0.6, 4, 0.1, p.r, function (v) { return fmt(v, 1); });
      presetSlider(body, 'θ · 切点角', 'theta', 0, 360, 1, p.theta, function (v) { return fmt(v, 0) + '°'; });
      const eq = el('div', { class: 'lm-tangent-eq' }, tangentEquation());
      refs.presetEq = eq;
      body.appendChild(eq);
      body.appendChild(el('div', { class: 'lab-hint' }, 'P 为切点，OP 为半径，切线在 P 点与圆相切。'));
    }
  }
  function updateMeasureUI() {
    Object.keys(refs.measureBtns || {}).forEach(function (k) {
      refs.measureBtns[k].classList.toggle('on', state.measureMode === k && state.tool === 'measure');
    });
    if (refs.measureToggle) {
      const cb = refs.measureToggle.querySelector('input');
      if (cb) cb.checked = state.showMeasure;
    }
    if (refs.leftMeasure) refs.leftMeasure.checked = state.showMeasure;
  }
  function resizeCanvas() {
    if (!shellRef || !cv) return;
    const r = shellRef.stage.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;
    const dpr = Math.min(2.5, window.devicePixelRatio || 1);
    state.w = Math.round(r.width); state.h = Math.round(r.height); state.dpr = dpr;
    const pw = Math.max(1, Math.round(state.w * dpr)), ph = Math.max(1, Math.round(state.h * dpr));
    if (cv.width !== pw || cv.height !== ph) {
      cv.width = pw; cv.height = ph;
      cv.style.width = state.w + 'px'; cv.style.height = state.h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    updateZoomUI();
  }

  /* ================= 保存 / 恢复 ================= */
  function saveState() {
    if (!booted) return;
    try {
      const data = {
        v: 1,
        objects: state.objects.map(stripObject),
        view: { cx: state.view.cx, cy: state.view.cy, scale: state.view.scale },
        selection: state.selection.slice(),
        preset: state.preset,
        params: clone(state.params || {}),
        lastTransform: state.lastTransform ? clone(state.lastTransform) : null,
        pivotMode: state.pivotMode,
        axisMode: state.axisMode,
        measureMode: state.measureMode,
        showGrid: state.showGrid,
        snapGrid: state.snapGrid,
        showMeasure: state.showMeasure,
        showAnnotation: state.showAnnotation
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch (e) { }
  }
  function scheduleSave() {
    if (!booted) return;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveState, 320);
  }
  function loadState() {
    let raw = '';
    try { raw = localStorage.getItem(SAVE_KEY) || ''; } catch (e) { return false; }
    if (!raw) return false;
    let d;
    try { d = JSON.parse(raw); } catch (e) { return false; }
    if (!d || !Array.isArray(d.objects)) return false;
    state.objects = d.objects.map(hydrateObject).filter(function (o) { return o && o.id && o.type; });
    state.view = {
      cx: isNum(d.view && d.view.cx) ? d.view.cx : 0,
      cy: isNum(d.view && d.view.cy) ? d.view.cy : 0,
      scale: isNum(d.view && d.view.scale) ? clamp(d.view.scale, 5, 420) : 52
    };
    state.selection = (d.selection || []).filter(function (id) { return !!byId(id); });
    state.preset = d.preset || '';
    state.params = Object.assign(defaultParams(state.preset), d.params || {});
    state.lastTransform = d.lastTransform || null;
    state.pivotMode = d.pivotMode || 'origin';
    state.axisMode = d.axisMode || 'x';
    state.measureMode = d.measureMode || 'dist';
    state.showGrid = d.showGrid !== false;
    state.snapGrid = d.snapGrid !== false;
    state.showMeasure = d.showMeasure !== false;
    state.showAnnotation = d.showAnnotation !== false;
    return true;
  }

  /* ================= 导出 ================= */
  function makePNG(download) {
    if (!ctx) return '';
    const dpr = state.dpr || 1;
    const out = document.createElement('canvas');
    out.width = Math.max(1, Math.round(state.w * dpr));
    out.height = Math.max(1, Math.round(state.h * dpr));
    const g = out.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const night = shellRef && shellRef.themeOf && shellRef.themeOf() === 'night';
    g.fillStyle = night ? '#0B1322' : '#FBF8F3';
    g.fillRect(0, 0, state.w, state.h);
    drawScene(g, state.w, state.h, { export: true });
    let url = '';
    try { url = out.toDataURL('image/png'); } catch (e) { return ''; }
    if (download) {
      try {
        const a = document.createElement('a');
        a.download = '见微-变换实验室-数学.png';
        a.href = url;
        document.body.appendChild(a);
        a.click();
        a.remove();
      } catch (e) { }
    }
    return url;
  }
  function exportPNG(opts) {
    opts = opts || {};
    const url = makePNG(opts.download !== false);
    if (!url) {
      shellRef && shellRef.toast('导出失败');
      return '';
    }
    if (opts.download !== false) shellRef && shellRef.toast('已导出 PNG');
    return url;
  }

  /* ================= 自检 ================= */
  function captureFull() {
    return {
      objects: state.objects.map(stripObject),
      selection: state.selection.slice(),
      view: clone(state.view),
      preset: state.preset,
      params: clone(state.params || {}),
      lastTransform: state.lastTransform ? clone(state.lastTransform) : null,
      pivotMode: state.pivotMode,
      axisMode: state.axisMode,
      measureMode: state.measureMode,
      measurePicks: state.measurePicks.slice(),
      showGrid: state.showGrid,
      snapGrid: state.snapGrid,
      showMeasure: state.showMeasure,
      showAnnotation: state.showAnnotation,
      historyPast: history.past.slice(),
      historyFuture: history.future.slice()
    };
  }
  function restoreFull(d) {
    state.objects = (d.objects || []).map(hydrateObject);
    state.selection = (d.selection || []).filter(function (id) { return !!byId(id); });
    state.view = clone(d.view || state.view);
    state.preset = d.preset || '';
    state.params = clone(d.params || {});
    state.lastTransform = d.lastTransform || null;
    state.pivotMode = d.pivotMode || 'origin';
    state.axisMode = d.axisMode || 'x';
    state.measureMode = d.measureMode || 'dist';
    state.measurePicks = d.measurePicks || [];
    state.showGrid = d.showGrid !== false;
    state.snapGrid = d.snapGrid !== false;
    state.showMeasure = d.showMeasure !== false;
    state.showAnnotation = d.showAnnotation !== false;
    history.past = d.historyPast || [];
    history.future = d.historyFuture || [];
    state.draft = null;
    state.handle = null;
    state.pointer = null;
    state.snapInfo = null;
    fingers.clear();
    refreshAll(); render(); scheduleSave();
  }
  function resetForTest() {
    state.objects = [];
    state.selection = [];
    state.view = { cx: 0, cy: 0, scale: 52 };
    state.preset = '';
    state.params = {};
    state.lastTransform = null;
    state.pivotMode = 'origin';
    state.axisMode = 'x';
    state.measurePicks = [];
    state.draft = null;
    state.handle = null;
    state.pointer = null;
    state.pinch = null;
    state.snapInfo = null;
    fingers.clear();
    history.past = [];
    history.future = [];
    resizeCanvas();
    refreshAll(); render();
  }
  function dragToTest(pointId, target) {
    const p = byId(pointId);
    if (!p) throw new Error('待拖动的点不存在');
    const a = screenOf(curOfPoint(p));
    const b = screenOf(target);
    const rect = cv.getBoundingClientRect();
    state.tool = 'select';
    state.selection = [];
    function ev(type, x, y, buttons) {
      return new PointerEvent(type, {
        bubbles: true, cancelable: true, composed: true,
        clientX: rect.left + x, clientY: rect.top + y,
        pointerId: 99, pointerType: 'mouse', isPrimary: true,
        button: type === 'pointerup' ? 0 : 0, buttons: buttons
      });
    }
    try {
      cv.dispatchEvent(ev('pointerdown', a.x, a.y, 1));
      cv.dispatchEvent(ev('pointermove', b.x, b.y, 1));
      cv.dispatchEvent(ev('pointerup', b.x, b.y, 0));
      state.pointer = null; fingers.clear();
      return 'pointer';
    } catch (e) {
      state.pointer = null; fingers.clear();
      const inv = invertM(p.m);
      const base = applyM(inv, target.x, target.y);
      p.x = base.x; p.y = base.y;
      render();
      return 'direct';
    }
  }
  function handleDragToTest(kind, from, to) {
    const rect = cv.getBoundingClientRect();
    beginHandle(kind);
    const a = screenOf(from), b = screenOf(to);
    function ev(type, x, y, buttons) {
      return new PointerEvent(type, {
        bubbles: true, cancelable: true, composed: true,
        clientX: rect.left + x, clientY: rect.top + y,
        pointerId: 98, pointerType: 'mouse', isPrimary: true,
        button: 0, buttons: buttons
      });
    }
    try {
      cv.dispatchEvent(ev('pointerdown', a.x, a.y, 1));
      cv.dispatchEvent(ev('pointermove', b.x, b.y, 1));
      cv.dispatchEvent(ev('pointerup', b.x, b.y, 0));
    } finally {
      state.pointer = null; fingers.clear();
      if (state.handle) state.handle = null;
    }
    return state.lastTransform;
  }
  function runSelfTest() {
    const out = { ok: true, checks: [], errors: [] };
    const before = captureFull();
    testRunning = true;
    function check(name, fn) {
      try {
        const detail = fn();
        out.checks.push({ name: name, pass: true, detail: String(detail == null ? '' : detail) });
      } catch (e) {
        const msg = (e && e.message) || String(e);
        out.checks.push({ name: name, pass: false, detail: msg });
        out.errors.push(name + ': ' + msg);
      }
    }
    try {
      resizeCanvas();
      resetForTest();
      let p = null;
      check('建点', function () {
        state.selection = [];
        p = createPoint(1, 2, { name: 'A', color: 'accent' });
        if (!p || !byId(p.id)) throw new Error('点对象没有创建');
        const c = curOfPoint(p);
        if (!near(c.x, 1) || !near(c.y, 2)) throw new Error('坐标不正确');
        refreshAll(); render();
        return 'A(1, 2)';
      });
      check('拖点', function () {
        const mode = dragToTest(p.id, { x: 3, y: 2 });
        const c = curOfPoint(byId(p.id));
        if (Math.hypot(c.x - 3, c.y - 2) > 0.25) throw new Error('拖点后坐标为 ' + fmtPt(c));
        return 'A → (3, 2) · ' + mode;
      });
      check('平移', function () {
        resetForTest();
        const a = createPoint(1, 1, { name: 'A' });
        state.selection = [a.id];
        applyTransform(translateM(2, 1), { type: 'translate', label: '平移 (2, 1)', params: { dx: 2, dy: 1 } }, { silent: true });
        const c = curOfPoint(a);
        if (!near(c.x, 3, 1e-6) || !near(c.y, 2, 1e-6)) throw new Error('像点 ' + fmtPt(c));
        if (!state.lastTransform || state.lastTransform.type !== 'translate') throw new Error('矩阵未记录');
        return 'A(1,1) → ' + fmtPt(c);
      });
      check('旋转', function () {
        resetForTest();
        const a = createPoint(2, 0, { name: 'A' });
        state.selection = [a.id];
        applyTransform(rotateM(JW.rad(90), { x: 0, y: 0 }), {
          type: 'rotate', label: '绕原点旋转 90°', params: { angle: 90, rad: JW.rad(90), pivot: { x: 0, y: 0 } }
        }, { silent: true });
        const c = curOfPoint(a);
        if (!near(c.x, 0, 1e-6) || !near(c.y, 2, 1e-6)) throw new Error('像点 ' + fmtPt(c));
        return 'A(2,0) → ' + fmtPt(c);
      });
      check('缩放', function () {
        resetForTest();
        const a = createPoint(2, 1, { name: 'A' });
        state.selection = [a.id];
        applyTransform(scaleM(2, { x: 0, y: 0 }), {
          type: 'scale', label: '以原点为中心缩放 k=2', params: { k: 2, pivot: { x: 0, y: 0 } }
        }, { silent: true });
        const c = curOfPoint(a);
        if (!near(c.x, 4, 1e-6) || !near(c.y, 2, 1e-6)) throw new Error('像点 ' + fmtPt(c));
        return 'A(2,1) → ' + fmtPt(c);
      });
      check('对称', function () {
        resetForTest();
        const a = createPoint(3, 2, { name: 'A' });
        state.selection = [a.id];
        applyTransform(reflectLineM({ x: 0, y: 0 }, { x: 1, y: 0 }), {
          type: 'sym-line', label: '关于 x 轴对称', params: { axisLabel: 'x 轴', axis: [{ x: 0, y: 0 }, { x: 1, y: 0 }] }
        }, { silent: true });
        const c = curOfPoint(a);
        if (!near(c.x, 3, 1e-6) || !near(c.y, -2, 1e-6)) throw new Error('像点 ' + fmtPt(c));
        return 'A(3,2) → ' + fmtPt(c);
      });
      check('矩阵叠加', function () {
        resetForTest();
        const a = createPoint(1, 0, { name: 'A' });
        state.selection = [a.id];
        applyTransform(translateM(1, 0), { type: 'translate', label: '平移', params: { dx: 1, dy: 0 } }, { silent: true });
        applyTransform(rotateM(JW.rad(90), { x: 0, y: 0 }), {
          type: 'rotate', label: '旋转', params: { angle: 90, rad: JW.rad(90), pivot: { x: 0, y: 0 } }
        }, { silent: true });
        const c = curOfPoint(a);
        if (!near(c.x, 0, 1e-6) || !near(c.y, 2, 1e-6)) throw new Error('叠加后 ' + fmtPt(c));
        return '先平移再旋转 → ' + fmtPt(c);
      });
      check('拖拽旋转手柄', function () {
        resetForTest();
        const a = createPoint(2, 0, { name: 'A' });
        state.selection = [a.id];
        const lt = handleDragToTest('rotate', { x: 2, y: 0 }, { x: 0, y: 2 });
        const c = curOfPoint(a);
        if (!lt || lt.type !== 'rotate') throw new Error('拖拽没有产生旋转变换');
        if (!near(c.x, 0, 1e-6) || !near(c.y, 2, 1e-6)) throw new Error('拖拽后像点 ' + fmtPt(c));
        return '拖拽 90° · A(2,0) → ' + fmtPt(c);
      });
      check('撤销 / 重做', function () {
        resetForTest();
        pushHistory();
        const p2 = createPoint(0, 0, { name: 'B' });
        render();
        if (state.objects.length !== 1) throw new Error('建点失败');
        doUndo(true);
        if (state.objects.length !== 0) throw new Error('撤销后还有 ' + state.objects.length + ' 个对象');
        doRedo(true);
        if (!byId(p2.id)) throw new Error('重做后点没有恢复');
        return '1 → 0 → 1';
      });
      check('函数曲线取值', function () {
        resetForTest();
        const f = addFunction('sin(x)');
        const y = f.fn(0.5);
        if (!near(y, Math.sin(0.5), 1e-9)) throw new Error('sin(0.5) = ' + y);
        const f2 = addFunction('sin(πx)');
        const y2 = f2.fn(0.5);
        if (!near(y2, 1, 1e-9)) throw new Error('sin(πx) 在 x=0.5 处 = ' + y2);
        state.selection = [f.id];
        refreshAll(); render();
        return 'f(0.5) = ' + fmt(y, 6) + ' · πx = ' + fmt(y2, 6);
      });
      check('测量', function () {
        resetForTest();
        const A = createPoint(0, 0, { name: 'A' });
        const B = createPoint(3, 0, { name: 'B' });
        const C = createPoint(3, 4, { name: 'C' });
        state.tool = 'measure';
        state.measureMode = 'dist'; state.measurePicks = [];
        measurePick({ x: 0, y: 0 }); measurePick({ x: 3, y: 0 });
        const md = state.objects.filter(function (o) { return o.type === 'mdist'; })[0];
        if (!md || !near(segmentLen(md), 3, 1e-6)) throw new Error('两点距离不正确');
        state.measureMode = 'angle'; state.measurePicks = [];
        measurePick({ x: 0, y: 0 }); measurePick({ x: 3, y: 0 }); measurePick({ x: 3, y: 4 });
        const ma = state.objects.filter(function (o) { return o.type === 'mangle'; })[0];
        if (!ma || !near(JW.deg(angleOf(ma)), 90, 1e-6)) throw new Error('三点角度不正确');
        const poly = createShape('polygon', { pts: [A.id, B.id, C.id] }, { color: 'jade' });
        state.measureMode = 'area'; state.measurePicks = [];
        measurePick({ x: 2.2, y: 0.8 });
        const mar = state.objects.filter(function (o) { return o.type === 'marea'; })[0];
        if (!mar || !near(polygonArea(poly), 6, 1e-6)) throw new Error('多边形面积不正确');
        return 'AB=3 · ∠ABC=90° · S=6';
      });
      check('导出 PNG', function () {
        resetForTest();
        createPoint(1, 1, { name: 'A' });
        createPoint(-1, 0, { name: 'B' });
        render();
        const url = makePNG(false);
        if (!/^data:image\/png;base64,/.test(url)) throw new Error('没有拿到 PNG dataURL');
        if (url.length < 8000) throw new Error('PNG 数据过短 ' + url.length);
        return 'dataURL ' + url.length + ' 字节';
      });
    } catch (e) {
      out.errors.push('自检异常: ' + ((e && e.message) || String(e)));
    } finally {
      restoreFull(before);
      testRunning = false;
    }
    out.ok = out.errors.length === 0 && out.checks.every(function (c) { return c.pass; });
    return out;
  }
  function bootSelfTest() {
    if (!/[?&]selftest=1/.test(location.search)) return;
    setTimeout(function () {
      let res;
      try { res = window.__labMathTest(); } catch (e) {
        res = { ok: false, checks: [], errors: [String((e && e.message) || e)] };
      }
      const pass = res.checks.filter(function (c) { return c.pass; }).length;
      const pre = document.createElement('pre');
      pre.id = 'lab-selftest';
      pre.hidden = true;
      pre.textContent = JSON.stringify(res, null, 2);
      document.body.appendChild(pre);
      document.title = 'SELFTEST ' + (res.ok ? 'PASS' : 'FAIL') + ' ' + pass + '/' + res.checks.length;
    }, 700);
  }

  /* ================= 挂载 ================= */
  function mount(shell) {
    shellRef = shell;
    if (booted) {
      resizeCanvas(); refreshAll(); render();
      return makeApi();
    }
    if (/(?:\?|&)reset=1/.test(location.search)) {
      try { localStorage.removeItem(SAVE_KEY); } catch (e) { }
    }
    buildStage(shell);
    buildLeft();
    buildRight();
    booted = true;
    const loaded = loadState();
    if (!loaded) {
      applyPreset('triangle', { noHistory: true, silent: true, preview: true });
    }
    resizeCanvas();
    refreshAll();
    render();
    updateZoomUI();
    shell.onTheme(function () {
      if (!booted) return;
      // 主题切换后：画布用新 JW.C 重绘，列表色点与色板也换色
      renderObjectList();
      renderProperties();
      renderMatrix();
      render();
    });
    requestAnimationFrame(function () {
      resizeCanvas(); refreshAll(); render();
    });
    window.__labMathTest = runSelfTest;
    scheduleSave();
    bootSelfTest();
    return makeApi();
  }
  function makeApi() {
    return {
      resize: function () { resizeCanvas(); scheduleRender(); },
      activate: function () {
        if (!shellRef) return;
        resizeCanvas();
        refreshAll();
        render();
        updateStatus();
      },
      exportPNG: function (opts) { return exportPNG(opts); }
    };
  }

  window.JWLabMath = { mount: mount };
})();
