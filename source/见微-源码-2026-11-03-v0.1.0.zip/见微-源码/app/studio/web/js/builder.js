/* 见微 · 析题台 · 物理场景搭建器
   用法：加载本文件即可（自动注入 css/builder.css、自建右下角入口）
   API：window.JWBuilder = { open(cb), list(), build(opts) }
   存储：localStorage['jw.built']，最多 100 条；不依赖外部库、网络、ES module。 */
(function () {
  'use strict';
  if (window.JWBuilder) return;

  var doc = document;
  var SELF = doc.currentScript;
  var KEY = 'jw.built';
  var MAX = 100;
  var MAXC = 12;
  var CSS_ID = 'bd-css';

  /* ---------------- 样式自注入 ---------------- */
  function injectCss() {
    if (doc.getElementById(CSS_ID)) return;
    var links = doc.querySelectorAll('link[rel="stylesheet"]');
    for (var i = 0; i < links.length; i++) {
      if ((links[i].getAttribute('href') || '').indexOf('builder.css') >= 0) return;
    }
    var href = 'css/builder.css';
    if (SELF && SELF.src) {
      try { href = new URL('../css/builder.css', SELF.src).href; } catch (e) { }
    }
    var l = doc.createElement('link');
    l.id = CSS_ID;
    l.rel = 'stylesheet';
    l.href = href;
    (doc.head || doc.documentElement).appendChild(l);
  }

  /* ---------------- 场景库 ---------------- */
  function p(k, label, sym, unit, min, max, step, def, dec) {
    return { k: k, label: label, sym: sym, unit: unit, min: min, max: max, step: step, def: def, dec: dec == null ? 2 : dec };
  }
  function S(kind, name, desc, params, future) {
    return { kind: kind, name: name, desc: desc, params: params || [], future: !!future };
  }

  var LIB = [
    {
      name: '力学',
      items: [
        S('projectile', '平抛 / 斜抛', '把运动拆成水平匀速与竖直匀变速，看射程、飞行时间与落地速度。', [
          p('v0', '初速', 'v₀', 'm/s', 5, 40, 1, 20, 0),
          p('angle', '抛射角', 'θ', '°', 0, 85, 1, 45, 0),
          p('h0', '离地高度', 'h₀', 'm', 0, 20, 0.5, 0, 1),
          p('g', '重力加速度', 'g', 'm/s²', 1, 20, 0.1, 10, 1)
        ]),
        S('incline', '斜面', '调倾角、摩擦与质量，观察下滑加速度和到底速度。', [
          p('angle', '倾角', 'θ', '°', 5, 60, 1, 30, 0),
          p('mu', '摩擦系数', 'μ', '', 0, 0.6, 0.02, 0.2, 2),
          p('m', '质量', 'm', 'kg', 0.5, 5, 0.5, 2, 1),
          p('L', '斜面长', 'L', 'm', 1.5, 5, 0.1, 3, 1),
          p('g', '重力加速度', 'g', 'm/s²', 1, 20, 0.1, 10, 1)
        ]),
        S('circular', '圆周运动', '绳系小球做匀速圆周，看向心力、周期与线速度。', [
          p('r', '半径', 'r', 'm', 0.2, 1.2, 0.02, 0.5, 2),
          p('v0', '线速度', 'v', 'm/s', 0.5, 6, 0.1, 2, 1),
          p('m', '质量', 'm', 'kg', 0.5, 3, 0.1, 1, 1)
        ]),
        S('collision', '一维碰撞', '两球对心碰撞，比较碰前碰后的动量与动能。', [
          p('m1', '质量 m₁', 'm₁', 'kg', 0.5, 5, 0.1, 2, 1),
          p('m2', '质量 m₂', 'm₂', 'kg', 0.5, 5, 0.1, 1, 1),
          p('v1', '初速 v₁', 'v₁', 'm/s', -6, 10, 0.5, 4, 1),
          p('v2', '初速 v₂', 'v₂', 'm/s', -6, 10, 0.5, -1, 1)
        ]),
        S('spring', '弹簧振子', '水平弹簧振子，观察振幅、周期与能量转换。', [
          p('m', '质量', 'm', 'kg', 0.5, 5, 0.1, 2, 1),
          p('k', '劲度系数', 'k', 'N/m', 20, 400, 5, 200, 0),
          p('A', '振幅', 'A', 'm', 0.08, 0.8, 0.01, 0.35, 2)
        ]),
        S('gravity', '引力 / 卫星轨道', '地球卫星的圆轨道，看线速度、周期与向心加速度。', [
          p('r', '轨道半径', 'r', '×10⁶ m', 6.8, 42, 0.2, 12, 1)
        ])
      ],
      more: [
        S('gravity2', '变轨 / 双星', '轨道切换与双星系统的扩展视图，等待接入。', [], true)
      ]
    },
    {
      name: '电磁学',
      items: [
        S('efield', '平行板偏转', '带电粒子穿过平行板，水平匀速、竖直类平抛。', [
          p('E', '电场强度', 'E', 'N/C', 0, 30, 1, 6, 0),
          p('q', '电荷量', 'q', 'µC', 0.5, 3, 0.1, 1, 1),
          p('m', '质量', 'm', 'kg', 0.5, 3, 0.1, 2, 1),
          p('v0', '入射速度', 'v₀', 'm/s', 1.5, 5, 0.1, 3, 1)
        ]),
        S('circuit', '闭合电路', '电源、内阻与双电阻，看路端电压和电流分配。', [
          p('E', '电动势', 'E', 'V', 1.5, 12, 0.5, 6, 1),
          p('r', '内阻', 'r', 'Ω', 0.1, 2, 0.1, 0.5, 1),
          p('R1', '电阻 R₁', 'R₁', 'Ω', 1, 20, 0.5, 4, 1),
          p('R2', '电阻 R₂', 'R₂', 'Ω', 1, 20, 0.5, 6, 1)
        ])
      ],
      more: [
        S('efield2', '交变电场', '交变电压下的偏转与往复运动，等待接入。', [], true),
        S('magnet', '磁场圆周', '洛伦兹力下的圆周运动，等待接入。', [], true),
        S('induction', '电磁感应', '导体棒切割磁感线，看感应电动势，等待接入。', [], true)
      ]
    },
    {
      name: '光学',
      items: [
        S('optics', '折射', '光从空气斜射入介质，看折射角与全反射临界。', [
          p('angle', '入射角', 'θ₁', '°', 0, 80, 1, 30, 0),
          p('n', '折射率', 'n', '', 1.2, 2, 0.05, 1.5, 2)
        ])
      ],
      more: [
        S('lens', '透镜成像', '凸透镜成像规律与像距变化，等待接入。', [], true),
        S('interference', '双缝干涉', '双缝干涉条纹间距与波长的关系，等待接入。', [], true)
      ]
    },
    {
      name: '振动与波',
      items: [
        S('wave', '横波', '横波沿绳传播，看波长、频率与波速的关系。', [
          p('v0', '波速', 'v', 'm/s', 0.5, 4, 0.1, 2, 1),
          p('f', '频率', 'f', 'Hz', 0.2, 3, 0.1, 1, 1),
          p('A', '振幅', 'A', 'm', 0.1, 0.8, 0.01, 0.35, 2)
        ])
      ],
      more: [
        S('shm', '简谐振动', '位移、速度与加速度的相位关系，等待接入。', [], true)
      ]
    },
    {
      name: '近代',
      items: [
        S('photoelectric', '光电效应', '入射光频率与光强改变时，光电流和遏止电压怎么变。', [], true),
        S('energylevel', '能级跃迁', '氢原子能级与谱线，等待接入。', [], true)
      ]
    }
  ];

  var SUPPORTED = {
    projectile: 1, incline: 1, circular: 1, collision: 1, spring: 1, gravity: 1,
    efield: 1, circuit: 1, optics: 1, wave: 1
  };
  var SCENE = {};
  LIB.forEach(function (g) {
    var all = g.items.concat(g.more || []);
    all.forEach(function (it) {
      it.group = g.name;
      SCENE[it.kind] = it;
    });
  });

  /* ---------------- 小工具 ---------------- */
  function el(tag, cls, text) {
    var n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function clean(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function toNum(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    if (typeof v === 'string' && v.trim() !== '') {
      var n = Number(v);
      return isFinite(n) ? n : null;
    }
    return null;
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(d) {
    return pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  function fmtNum(v, dec) {
    if (!isFinite(v)) return '0';
    var d = dec == null ? (Math.abs(v - Math.round(v)) < 1e-9 ? 0 : 2) : dec;
    var p = Math.pow(10, d);
    var n = Math.round(v * p) / p;
    var s = String(n);
    if (s.indexOf('e') >= 0) s = n.toFixed(Math.min(6, d));
    return s;
  }
  function decOf(v) {
    var s = String(v);
    if (s.indexOf('e') >= 0) return 4;
    var i = s.indexOf('.');
    return i < 0 ? 0 : Math.min(4, s.length - i - 1);
  }
  function defaultTitle() { return '我的场景 · ' + fmtTime(new Date()); }
  function defaultStem(scene) {
    var name = scene && scene.name ? scene.name : '这个场景';
    return '调整参数，观察「' + name + '」的过程，先预测再验证。';
  }
  function percent(v, s) {
    var p = (v - s.min) / (s.max - s.min) * 100;
    if (!isFinite(p)) p = 0;
    return Math.max(0, Math.min(100, p)) + '%';
  }
  function defaults(list) {
    var o = {};
    (list || []).forEach(function (s) { o[s.k] = s.def; });
    return o;
  }
  function sanitizeParams(src) {
    var out = {};
    if (!src || typeof src !== 'object') return out;
    Object.keys(src).forEach(function (k) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,23}$/.test(k)) return;
      var v = toNum(src[k]);
      if (v != null) out[k] = v;
    });
    return out;
  }

  /* ---------------- 存储 ---------------- */
  function load() {
    try {
      var raw = window.localStorage.getItem(KEY);
      var arr = JSON.parse(raw || '[]');
      if (!Array.isArray(arr)) return [];
      return arr.filter(function (q) { return q && typeof q === 'object' && q.id; });
    } catch (e) { return []; }
  }
  function store(list) {
    try {
      window.localStorage.setItem(KEY, JSON.stringify((list || []).slice(-MAX)));
      return true;
    } catch (e) { return false; }
  }

  /* ---------------- 构造题目 ---------------- */
  function build(opts) {
    opts = opts || {};
    var kind = clean(opts.kind) || 'projectile';
    var params = sanitizeParams(opts.params);
    var rawStem = clean(opts.stem || opts.description || opts.desc);
    var scene = SCENE[kind];
    var stem = rawStem || ('调整参数，观察「' + (scene ? scene.name : kind) + '」的过程，先预测再验证。');
    var cue = clean(opts.cue) || stem;
    var points = [];
    if (Array.isArray(opts.points)) {
      opts.points.forEach(function (x) {
        var s = clean(x);
        if (s && points.length < 4 && points.indexOf(s) < 0) points.push(s);
      });
    } else if (clean(opts.points)) {
      points = [clean(opts.points)];
    }
    if (!points.length && clean(opts.point)) points = [clean(opts.point)];

    var ts = Date.now(), id = 'bd-' + ts, tries = 0, saved = load();
    while (tries < 100 && saved.some(function (x) { return x.id === id; })) {
      ts += 1; id = 'bd-' + ts; tries += 1;
    }

    return {
      id: id,
      year: '自建',
      paper: '场景搭建器',
      subject: '物理',
      type: '实验',
      title: clean(opts.title) || ('我的场景 · ' + fmtTime(new Date())),
      stem: stem,
      answer: '（自己观察）',
      steps: ['先看已知参数', '开始播放观察过程', '记录关键量'],
      points: points,
      why: '自己搭的场景，先预测再验证',
      view: { engine: 'physics', kind: kind, params: params, cue: cue }
    };
  }

  /* ---------------- 面板状态 ---------------- */
  var state = {
    mask: null, panel: null, els: null, scene: null, kind: 'projectile',
    values: {}, custom: [], adding: false, autoStem: '', cb: null,
    prevOverflow: '', onKey: null, focusBefore: null, toastTimer: 0
  };

  function formMsg(text) {
    if (!state.els) return;
    state.els.formMsg.textContent = text || '';
  }

  function toast(text) {
    if (!state.panel) return;
    var old = state.panel.querySelector('.bd-toast');
    if (old && old.parentNode) old.parentNode.removeChild(old);
    if (state.toastTimer) { clearTimeout(state.toastTimer); state.toastTimer = 0; }
    var t = el('div', 'bd-toast', text);
    t.setAttribute('role', 'status');
    state.panel.appendChild(t);
    state.toastTimer = setTimeout(function () {
      if (t.parentNode) t.parentNode.removeChild(t);
      state.toastTimer = 0;
    }, 2400);
  }

  /* ---------------- 面板骨架 ---------------- */
  function buildPanel() {
    var mask = el('div', 'bd-mask');
    mask.id = 'bd-mask';
    var panel = el('div', 'bd-panel');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-label', '物理场景搭建器');
    mask.appendChild(panel);
    doc.body.appendChild(mask);
    state.mask = mask;
    state.panel = panel;

    panel.innerHTML = [
      '<header class="bd-head">',
      '  <div class="bd-mark" aria-hidden="true">物</div>',
      '  <div class="bd-titles"><span class="bd-kicker">见微 · 实验台</span><h1>物理场景搭建器</h1></div>',
      '  <div class="bd-head-right"><span class="bd-esc">ESC</span><button type="button" class="bd-close">关闭</button></div>',
      '</header>',
      '<div class="bd-body">',
      '  <aside class="bd-lib">',
      '    <div class="bd-col-h"><h2>场景库</h2><p>按高中章节选一个模型</p></div>',
      '    <div class="bd-lib-scroll"></div>',
      '    <div class="bd-lib-note">未接入的 kind 也能保存，题目会标注「视图可能不支持」。</div>',
      '  </aside>',
      '  <section class="bd-stage">',
      '    <div class="bd-col-h"><h2>舞台设置</h2><p>拖动参数，右侧实时成式</p></div>',
      '    <div class="bd-stage-head"></div>',
      '    <div class="bd-stage-scroll"><div class="bd-sheet"></div></div>',
      '  </section>',
      '  <aside class="bd-side">',
      '    <div class="bd-col-h"><h2>预览与保存</h2><p>先看式子，再存成题目</p></div>',
      '    <div class="bd-side-scroll">',
      '      <div class="bd-formula">',
      '        <div class="bd-formula-h"><span>实时公式卡</span><span class="bd-fcount">0 项</span></div>',
      '        <div class="bd-eqs"></div>',
      '        <div class="bd-formula-note"></div>',
      '      </div>',
      '      <div class="bd-form">',
      '        <label class="bd-field"><span>题目名</span><input class="bd-title" type="text" maxlength="48" autocomplete="off" placeholder="给这个场景起个名字"></label>',
      '        <label class="bd-field"><span>说明文字</span><textarea class="bd-stem" rows="3" maxlength="320" placeholder="例如：改变初速，观察射程怎么变"></textarea></label>',
      '        <label class="bd-field"><span>一句话考点 <i>可选</i></span><input class="bd-point" type="text" maxlength="32" autocomplete="off" placeholder="例如：平抛运动的分解"></label>',
      '        <div class="bd-save-row"><button type="button" class="bd-save">保存并打开</button></div>',
      '        <p class="bd-form-msg" aria-live="polite"></p>',
      '        <p class="bd-form-hint">只存本机，最多 100 条；打开后还能在物理视图里继续调参。</p>',
      '      </div>',
      '    </div>',
      '  </aside>',
      '</div>',
      '<footer class="bd-foot">',
      '  <div class="bd-foot-h"><span>已存场景</span><span class="bd-count">0 条</span><span class="bd-foot-hint">删除只清本机记录</span></div>',
      '  <div class="bd-saved"></div>',
      '</footer>'
    ].join('');

    state.els = {
      lib: panel.querySelector('.bd-lib-scroll'),
      stageHead: panel.querySelector('.bd-stage-head'),
      sheet: panel.querySelector('.bd-sheet'),
      eqs: panel.querySelector('.bd-eqs'),
      fcount: panel.querySelector('.bd-fcount'),
      formulaNote: panel.querySelector('.bd-formula-note'),
      saved: panel.querySelector('.bd-saved'),
      count: panel.querySelector('.bd-count'),
      title: panel.querySelector('.bd-title'),
      stem: panel.querySelector('.bd-stem'),
      point: panel.querySelector('.bd-point'),
      formMsg: panel.querySelector('.bd-form-msg')
    };

    panel.querySelector('.bd-close').addEventListener('click', close);
    panel.querySelector('.bd-save').addEventListener('click', saveCurrent);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    [state.els.title, state.els.stem, state.els.point].forEach(function (n) {
      n.addEventListener('input', function () { formMsg(''); });
    });

    state.onKey = function (e) {
      if (e.key === 'Escape') { e.preventDefault(); close(); }
    };
    doc.addEventListener('keydown', state.onKey);
    doc.body.style.overflow = 'hidden';

    renderLibrary();
    renderStageHead();
    state.els.title.value = defaultTitle();
    state.autoStem = defaultStem(state.scene);
    state.els.stem.value = state.autoStem;
    renderSettings();
    renderFormula();
    renderSaved();

    try { panel.querySelector('.bd-close').focus(); } catch (e) { }
  }

  /* ---------------- 场景库渲染 ---------------- */
  function sceneBtn(it) {
    var b = el('button', 'bd-scene');
    b.type = 'button';
    b.setAttribute('data-kind', it.kind);
    b.setAttribute('aria-pressed', it.kind === state.kind ? 'true' : 'false');
    if (it.kind === state.kind) b.classList.add('is-on');
    var top = el('span', 'bd-scene-top');
    top.appendChild(el('b', 'bd-scene-name', it.name));
    top.appendChild(el('code', 'bd-scene-kind', it.kind));
    if (!SUPPORTED[it.kind]) top.appendChild(el('span', 'bd-scene-flag', '待视图'));
    b.appendChild(top);
    b.appendChild(el('span', 'bd-scene-desc', it.desc));
    b.addEventListener('click', function () { selectScene(it.kind); });
    return b;
  }

  function renderLibrary() {
    var box = state.els.lib;
    box.innerHTML = '';
    LIB.forEach(function (g) {
      var sec = el('section', 'bd-grp');
      var head = el('div', 'bd-grp-h');
      head.appendChild(el('b', '', g.name));
      head.appendChild(el('span', '', g.items.length + ' 项'));
      sec.appendChild(head);
      g.items.forEach(function (it) { sec.appendChild(sceneBtn(it)); });
      if (g.more && g.more.length) {
        var d = doc.createElement('details');
        d.className = 'bd-more';
        var sm = doc.createElement('summary');
        sm.appendChild(doc.createTextNode('扩展位 · ' + g.more.length + ' 项'));
        d.appendChild(sm);
        g.more.forEach(function (it) { d.appendChild(sceneBtn(it)); });
        sec.appendChild(d);
      }
      box.appendChild(sec);
    });
  }

  function syncSceneButtons() {
    var btns = state.els.lib.querySelectorAll('.bd-scene');
    for (var i = 0; i < btns.length; i++) {
      var on = btns[i].getAttribute('data-kind') === state.kind;
      btns[i].classList.toggle('is-on', on);
      btns[i].setAttribute('aria-pressed', on ? 'true' : 'false');
    }
  }

  function selectScene(kind) {
    if (state.kind === kind) return;
    var sc = SCENE[kind];
    if (!sc) return;
    state.kind = kind;
    state.scene = sc;
    state.values = defaults(sc.params);
    state.custom = [];
    state.adding = false;
    syncSceneButtons();
    renderStageHead();
    renderSettings();
    renderFormula();
    var stem = state.els.stem;
    if (!clean(stem.value) || clean(stem.value) === clean(state.autoStem)) {
      state.autoStem = defaultStem(sc);
      stem.value = state.autoStem;
    }
    var scroll = state.panel.querySelector('.bd-stage-scroll');
    if (scroll) scroll.scrollTop = 0;
  }

  /* ---------------- 舞台 ---------------- */
  function renderStageHead() {
    var box = state.els.stageHead;
    box.innerHTML = '';
    var sc = state.scene;
    var ok = !!SUPPORTED[sc.kind];
    var meta = el('div', 'bd-stage-meta');
    meta.appendChild(el('span', 'bd-stage-group', sc.group || '场景'));
    meta.appendChild(el('span', 'bd-stage-kind', sc.kind));
    meta.appendChild(el('span', 'bd-badge ' + (ok ? 'is-ok' : 'is-warn'), ok ? '视图已接入' : '视图可能不支持'));
    box.appendChild(meta);
    box.appendChild(el('h2', 'bd-stage-name', sc.name || sc.kind));
    box.appendChild(el('p', 'bd-stage-desc', sc.desc || '自定义场景'));
    if (!ok) {
      box.appendChild(el('p', 'bd-stage-warn', '这个 kind 还没有接入物理视图。参数仍会写进题目，保存后会标注「视图可能不支持」。'));
    }
  }

  function sliderRow(s) {
    var wrap = el('label', 'bd-ctl');
    var top = el('span', 'bd-ctl-top');
    var name = el('span', 'bd-ctl-name', s.label);
    if (s.sym) name.appendChild(el('i', 'bd-ctl-sym', s.sym));
    top.appendChild(name);
    var vbox = el('span', 'bd-ctl-val');
    var b = el('b', '', fmtNum(state.values[s.k], s.dec));
    vbox.appendChild(b);
    if (s.unit) vbox.appendChild(el('em', '', s.unit));
    top.appendChild(vbox);
    wrap.appendChild(top);

    var inp = doc.createElement('input');
    inp.type = 'range';
    inp.className = 'bd-range';
    inp.min = String(s.min);
    inp.max = String(s.max);
    inp.step = String(s.step);
    var v = state.values[s.k];
    if (!isFinite(v)) v = s.def;
    inp.value = String(v);
    inp.style.setProperty('--pct', percent(v, s));
    inp.setAttribute('aria-label', s.label + (s.unit ? '，单位 ' + s.unit : ''));
    inp.addEventListener('input', function () {
      var nv = parseFloat(inp.value);
      if (!isFinite(nv)) return;
      state.values[s.k] = nv;
      b.textContent = fmtNum(nv, s.dec);
      inp.style.setProperty('--pct', percent(nv, s));
      renderFormula();
    });
    wrap.appendChild(inp);
    wrap.appendChild(el('span', 'bd-ctl-meta',
      '范围 ' + fmtNum(s.min, s.dec) + '–' + fmtNum(s.max, s.dec) +
      ' · 步长 ' + fmtNum(s.step, s.dec) +
      ' · 默认值 ' + fmtNum(s.def, s.dec) + (s.unit ? ' ' + s.unit : '')));
    return wrap;
  }

  function customRow(c) {
    var row = el('div', 'bd-custom');
    row.appendChild(el('code', 'bd-custom-k', c.k));
    var inp = doc.createElement('input');
    inp.type = 'number';
    inp.step = 'any';
    inp.className = 'bd-num';
    inp.value = fmtNum(c.v, 3);
    inp.setAttribute('aria-label', '参数 ' + c.k);
    inp.addEventListener('input', function () {
      var nv = parseFloat(inp.value);
      if (isFinite(nv)) { c.v = nv; renderFormula(); }
    });
    inp.addEventListener('blur', function () {
      if (!isFinite(parseFloat(inp.value))) inp.value = fmtNum(c.v, 3);
    });
    row.appendChild(inp);
    var rm = el('button', 'bd-remove', '移除');
    rm.type = 'button';
    rm.addEventListener('click', function () {
      state.custom = state.custom.filter(function (x) { return x !== c; });
      renderSettings();
      renderFormula();
      var add = state.panel.querySelector('.bd-add');
      if (add) add.focus();
    });
    row.appendChild(rm);
    return row;
  }

  function addForm() {
    var f = doc.createElement('form');
    f.className = 'bd-add-form';
    var key = doc.createElement('input');
    key.type = 'text';
    key.className = 'bd-num bd-key';
    key.placeholder = '键名，如 B';
    key.setAttribute('autocomplete', 'off');
    key.setAttribute('spellcheck', 'false');
    key.setAttribute('aria-label', '参数键名，英文');
    var val = doc.createElement('input');
    val.type = 'number';
    val.step = 'any';
    val.className = 'bd-num';
    val.placeholder = '数值';
    val.setAttribute('aria-label', '参数数值');
    var ok = el('button', 'bd-add-ok', '添加');
    ok.type = 'submit';
    var no = el('button', 'bd-add-cancel', '取消');
    no.type = 'button';
    no.addEventListener('click', function () { toggleAdd(false); });
    var err = el('div', 'bd-err', '');
    err.setAttribute('aria-live', 'polite');
    f.appendChild(key);
    f.appendChild(val);
    f.appendChild(ok);
    f.appendChild(no);
    f.appendChild(err);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      addCustom(key, val, err);
    });
    return f;
  }

  function renderSettings() {
    var sheet = state.els.sheet;
    sheet.innerHTML = '';
    var ps = state.scene.params || [];
    if (!ps.length) {
      var empty = el('div', 'bd-empty');
      empty.appendChild(el('b', '', SUPPORTED[state.kind] ? '这个场景还没有预设参数' : '视图可能不支持'));
      empty.appendChild(el('span', '', SUPPORTED[state.kind]
        ? '可以点下面的「+ 添加参数」自定义键值。'
        : '可以自定义参数后保存；题目仍会进入列表，视图接入后即可直接播放。'));
      sheet.appendChild(empty);
    } else {
      ps.forEach(function (s) { sheet.appendChild(sliderRow(s)); });
    }
    state.custom.forEach(function (c) { sheet.appendChild(customRow(c)); });

    var add = el('button', 'bd-add', state.adding ? '取消添加' : '+ 添加参数');
    add.type = 'button';
    if (state.custom.length >= MAXC && !state.adding) add.disabled = true;
    add.addEventListener('click', function () { toggleAdd(); });
    sheet.appendChild(add);
    if (state.adding) sheet.appendChild(addForm());
    sheet.appendChild(el('p', 'bd-sheet-note', '参数会写进 view.params；打开题目后还能在物理视图里继续调。'));
  }

  function toggleAdd(force) {
    state.adding = force === undefined ? !state.adding : !!force;
    renderSettings();
    if (state.adding) {
      var k = state.panel.querySelector('.bd-key');
      if (k) k.focus();
      var f = state.panel.querySelector('.bd-add-form');
      if (f && f.scrollIntoView) {
        try { f.scrollIntoView({ block: 'nearest' }); } catch (e) { }
      }
    }
  }

  function addCustom(keyEl, valEl, err) {
    var k = clean(keyEl.value);
    var v = toNum(valEl.value);
    if (!/^[A-Za-z][A-Za-z0-9_]{0,23}$/.test(k)) {
      err.textContent = '键名用英文开头，只含字母、数字、下划线';
      keyEl.focus();
      return;
    }
    var dup = (state.scene.params || []).some(function (s) { return s.k === k; }) ||
      state.custom.some(function (c) { return c.k === k; });
    if (dup) {
      err.textContent = '这个键已经存在';
      keyEl.focus();
      return;
    }
    if (v == null) {
      err.textContent = '值要填一个数字';
      valEl.focus();
      return;
    }
    if (state.custom.length >= MAXC) {
      err.textContent = '自定义参数最多 ' + MAXC + ' 个';
      return;
    }
    state.custom.push({ k: k, v: v });
    state.adding = false;
    renderSettings();
    renderFormula();
    var add = state.panel.querySelector('.bd-add');
    if (add) add.focus();
    toast('已添加参数 ' + k);
  }

  function renderFormula() {
    var items = [];
    (state.scene.params || []).forEach(function (s) {
      var v = state.values[s.k];
      if (!isFinite(v)) v = s.def;
      items.push({ sym: s.sym || s.k, v: v, unit: s.unit || '', dec: s.dec, key: false });
    });
    state.custom.forEach(function (c) {
      items.push({ sym: c.k, v: c.v, unit: '', dec: decOf(c.v), key: true });
    });

    state.els.fcount.textContent = items.length + ' 项';
    state.els.eqs.innerHTML = '';
    if (!items.length) {
      state.els.eqs.appendChild(el('div', 'bd-eq-empty', '还没有参数。选一个场景，或自定义键值。'));
    } else {
      items.forEach(function (it) {
        var row = el('div', 'bd-eq');
        var sym = el('span', 'bd-eq-s' + (it.key ? ' is-key' : ''), it.sym);
        sym.title = it.sym;
        row.appendChild(sym);
        row.appendChild(el('span', 'bd-eq-op', '='));
        var val = el('span', 'bd-eq-v', fmtNum(it.v, it.dec));
        if (it.unit) val.appendChild(el('em', '', it.unit));
        row.appendChild(val);
        state.els.eqs.appendChild(row);
      });
    }
    state.els.formulaNote.textContent = '将写入 physics · ' + state.kind + (SUPPORTED[state.kind] ? '' : ' · 视图可能不支持');
  }

  /* ---------------- 保存与已存列表 ---------------- */
  function gatherParams() {
    var out = {};
    (state.scene.params || []).forEach(function (s) {
      var v = state.values[s.k];
      out[s.k] = isFinite(v) ? v : s.def;
    });
    state.custom.forEach(function (c) { out[c.k] = c.v; });
    return out;
  }

  function timeOf(q) {
    var m = /^bd-(\d+)/.exec(String(q.id || ''));
    if (m) {
      var d = new Date(Number(m[1]));
      if (!isNaN(d.getTime())) return fmtTime(d);
    }
    return '已保存';
  }

  function renderSaved() {
    var box = state.els.saved;
    box.innerHTML = '';
    var list = load();
    state.els.count.textContent = list.length + ' 条';
    if (!list.length) {
      box.appendChild(el('div', 'bd-saved-empty', '还没有保存过。左侧选场景，右侧点「保存并打开」。'));
      return;
    }
    list.slice().reverse().forEach(function (q) {
      var card = el('div', 'bd-saved-item');
      var main = el('div', 'bd-saved-main');
      var title = el('b', 'bd-saved-t', q.title || '未命名场景');
      title.title = q.title || '';
      main.appendChild(title);
      var meta = el('span', 'bd-saved-m');
      var kind = q.view && q.view.kind ? q.view.kind : '—';
      meta.appendChild(el('span', 'bd-saved-kind', kind + ' · ' + timeOf(q)));
      if (q.view && !SUPPORTED[q.view.kind]) meta.appendChild(el('span', 'bd-mini-flag', '视图可能不支持'));
      main.appendChild(meta);
      var acts = el('div', 'bd-saved-acts');
      var ob = el('button', 'bd-saved-open', '打开');
      ob.type = 'button';
      ob.setAttribute('aria-label', '打开 ' + (q.title || '场景'));
      ob.addEventListener('click', function () { openSaved(q); });
      var db = el('button', 'bd-saved-del', '删除');
      db.type = 'button';
      db.setAttribute('aria-label', '删除 ' + (q.title || '场景'));
      db.addEventListener('click', function () { deleteSaved(q); });
      acts.appendChild(ob);
      acts.appendChild(db);
      card.appendChild(main);
      card.appendChild(acts);
      box.appendChild(card);
    });
  }

  function saveCurrent() {
    try {
      var title = clean(state.els.title.value) || defaultTitle();
      var stem = clean(state.els.stem.value) || defaultStem(state.scene);
      var point = clean(state.els.point.value);
      var q = build({ kind: state.kind, params: gatherParams(), title: title, stem: stem, point: point, cue: stem });
      var list = load();
      list.push(q);
      if (list.length > MAX) list = list.slice(list.length - MAX);
      if (!store(list)) {
        formMsg('本地存储写入失败，请检查浏览器存储设置');
        return;
      }
      if (window.JW && window.JW.addQuestions) window.JW.addQuestions([q]);
      var cb = state.cb;
      close();
      if (window.JWApp && typeof window.JWApp.open === 'function' && q.id) {
        try { window.JWApp.open(q.id); } catch (e) { console.warn(e); }
      }
      if (cb) { try { cb(q); } catch (e) { console.warn(e); } }
    } catch (err) {
      formMsg('保存失败：' + (err && err.message ? err.message : '未知错误'));
    }
  }

  function openSaved(q) {
    if (!window.JWApp || typeof window.JWApp.open !== 'function') {
      formMsg('当前页面没有题目视图，无法打开');
      return;
    }
    if (window.JW && window.JW.addQuestions) window.JW.addQuestions([q]);
    var cb = state.cb;
    close();
    try { window.JWApp.open(q.id); } catch (e) { console.warn(e); }
    if (cb) { try { cb(q); } catch (e) { console.warn(e); } }
  }

  function deleteSaved(q) {
    var list = load().filter(function (x) { return x.id !== q.id; });
    if (!store(list)) {
      formMsg('删除失败，浏览器存储不可写');
      return;
    }
    if (window.JW && window.JW.questions) {
      for (var i = window.JW.questions.length - 1; i >= 0; i--) {
        if (window.JW.questions[i] && window.JW.questions[i].id === q.id) window.JW.questions.splice(i, 1);
      }
    }
    if (window.JWApp && typeof window.JWApp.renderList === 'function' && doc.getElementById('qlist')) {
      try { window.JWApp.renderList(); } catch (e) { }
    }
    renderSaved();
    toast('已删除「' + (q.title || '场景') + '」');
  }

  /* ---------------- 打开与关闭 ---------------- */
  function open(cb) {
    if (!doc.body) {
      doc.addEventListener('DOMContentLoaded', function () { open(cb); });
      return;
    }
    if (state.mask) {
      if (typeof cb === 'function') state.cb = cb;
      return;
    }
    injectCss();
    mountFab();
    ensureRegistered();

    state.cb = typeof cb === 'function' ? cb : null;
    state.focusBefore = doc.activeElement;
    state.prevOverflow = doc.body.style.overflow;
    state.kind = SCENE[state.kind] ? state.kind : 'projectile';
    state.scene = SCENE[state.kind];
    state.values = defaults(state.scene.params);
    state.custom = [];
    state.adding = false;
    state.autoStem = '';
    buildPanel();
  }

  function close() {
    if (!state.mask) return;
    if (state.onKey) {
      doc.removeEventListener('keydown', state.onKey);
      state.onKey = null;
    }
    if (state.toastTimer) { clearTimeout(state.toastTimer); state.toastTimer = 0; }
    if (state.mask.parentNode) state.mask.parentNode.removeChild(state.mask);
    state.mask = null;
    state.panel = null;
    state.els = null;
    state.cb = null;
    if (doc.body) doc.body.style.overflow = state.prevOverflow || '';
    var f = state.focusBefore;
    state.focusBefore = null;
    if (f && f.focus) { try { f.focus(); } catch (e) { } }
  }

  /* ---------------- 入口与注册 ---------------- */
  function mountFab() {
    if (doc.getElementById('bd-fab') || !doc.body) return;
    var b = el('button', 'bd-fab', '搭场景');
    b.id = 'bd-fab';
    b.type = 'button';
    b.title = '打开物理场景搭建器';
    b.setAttribute('aria-haspopup', 'dialog');
    b.addEventListener('click', function () { open(); });
    doc.body.appendChild(b);
  }

  function ensureRegistered() {
    if (!window.JW || typeof window.JW.addQuestions !== 'function') return;
    var list = load();
    if (list.length) {
      try { window.JW.addQuestions(list); } catch (e) { }
    }
    if (window.JWApp && typeof window.JWApp.renderList === 'function' && doc.getElementById('qlist')) {
      try { window.JWApp.renderList(); } catch (e) { }
    }
  }

  injectCss();

  window.JWBuilder = {
    open: open,
    list: function () { return load(); },
    build: build
  };

  function boot() {
    if (!doc.body) return;
    injectCss();
    mountFab();
    ensureRegistered();
  }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', boot);
  else boot();
  window.addEventListener('load', function () { ensureRegistered(); });
})();
