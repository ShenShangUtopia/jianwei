/* 见微 · 变换实验室 · 外壳脚本
   两个模式（数学 / 物理）各自的引擎挂在 window.JWLabMath / window.JWLabPhys，
   本文件只负责：铺壳、切模式、主题、状态栏、给引擎一份稳定的 shell API。 */
(function () {
  const JW = window.JW;
  const el = JW.el;

  const shell = {
    mode: 'math',
    stage: null, left: null, right: null,
    theme: 'day',
    _themeFns: [],
    _engines: {},
    _current: null
  };

  function qs(name) {
    return (new URLSearchParams(location.search)).get(name) || '';
  }

  shell.status = function (text) {
    const n = document.getElementById('lab-status');
    if (n) n.textContent = text || '';
  };
  shell.coord = function (text) {
    const n = document.getElementById('lab-coord');
    if (n) n.textContent = text || '';
  };
  shell.setTitle = function (text) {
    const n = document.getElementById('lab-status-top');
    if (n) n.textContent = text || '';
  };
  shell.themeOf = function () { return shell.theme; };
  shell.onTheme = function (fn) {
    shell._themeFns.push(fn);
    try { fn(shell.theme); } catch (e) { console.warn('[lab] theme', e); }
  };
  shell.toast = function (text, ms) {
    let t = document.getElementById('lab-toast');
    if (!t) {
      t = el('div', { id: 'lab-toast', class: 'lab-toast' });
      document.getElementById('lab').appendChild(t);
    }
    t.textContent = text;
    t.classList.add('on');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove('on'); }, ms || 1600);
  };

  /* 画布上的浮动工具条：引擎可以把自己的小控件钉在画布角落 */
  shell.float = function (pos) {
    const box = el('div', { class: 'lab-float' });
    if (pos === 'tl') Object.assign(box.style, { left: '10px', top: '10px' });
    else if (pos === 'tr') Object.assign(box.style, { right: '10px', top: '10px' });
    else if (pos === 'bl') Object.assign(box.style, { left: '10px', bottom: '10px' });
    else Object.assign(box.style, { right: '10px', bottom: '10px' });
    document.getElementById('lab-stage').appendChild(box);
    return box;
  };

  /* 左右栏清空（切模式时用） */
  shell.clearPanels = function () {
    shell.left.innerHTML = '';
    shell.right.innerHTML = '';
  };

  function applyThemeLabel() {
    const b = document.getElementById('lab-theme');
    if (b) b.textContent = shell.theme === 'night' ? '白天' : '夜晚';
  }

  function syncTheme(theme) {
    shell.theme = theme || (document.documentElement.dataset.theme || 'day');
    applyThemeLabel();
    shell._themeFns.forEach(function (fn) {
      try { fn(shell.theme); } catch (e) { console.warn('[lab] theme fn', e); }
    });
  }

  function setMode(mode) {
    if (mode !== 'math' && mode !== 'physics') mode = 'math';
    shell.mode = mode;
    document.querySelectorAll('#lab-modes button').forEach(function (b) {
      b.classList.toggle('is-on', b.dataset.mode === mode);
    });
    shell.clearPanels();

    // 每个引擎一个独立画布容器，切换时只显隐
    Object.keys(shell._engines).forEach(function (k) {
      shell._engines[k].host.style.display = (k === mode) ? 'block' : 'none';
    });

    if (!shell._engines[mode]) {
      const host = el('div', { class: 'lab-canvas-host' });
      Object.assign(host.style, { position: 'absolute', inset: '0' });
      document.getElementById('lab-canvas').appendChild(host);
      const engine = (mode === 'math' ? window.JWLabMath : window.JWLabPhys);
      if (!engine || typeof engine.mount !== 'function') {
        host.innerHTML = '<div class="lab-empty">这个模式的引擎还没加载</div>';
        shell._engines[mode] = { host: host, api: null };
        return;
      }
      const local = Object.create(shell);
      local.stage = host;
      local.mode = mode;
      const api = engine.mount(local) || {};
      shell._engines[mode] = { host: host, api: api };
    }
    shell._current = shell._engines[mode];
    if (shell._current.api && shell._current.api.resize) {
      try { shell._current.api.resize(); } catch (e) { }
    }
    if (shell._current.api && shell._current.api.activate) {
      try { shell._current.api.activate(); } catch (e) { }
    }
    try { history.replaceState(null, '', '?mode=' + mode); } catch (e) { }
  }

  shell.boot = function () {
    shell.left = document.getElementById('lab-left');
    shell.right = document.getElementById('lab-right');
    shell.stage = document.getElementById('lab-canvas');

    // 主题：跟随 nocturne.js 的 data-theme
    shell.theme = document.documentElement.dataset.theme || 'day';
    syncTheme(shell.theme);
    document.addEventListener('jw-theme', function (ev) { syncTheme(ev.detail && ev.detail.theme); });

    document.getElementById('lab-theme').addEventListener('click', function () {
      const next = shell.theme === 'night' ? 'day' : 'night';
      if (window.JWTheme && window.JWTheme.set) window.JWTheme.set(next);
      else {
        document.documentElement.dataset.theme = next;
        syncTheme(next);
      }
    });

    document.querySelectorAll('#lab-modes button').forEach(function (b) {
      b.addEventListener('click', function () { setMode(b.dataset.mode); });
    });

    // 键盘：Esc 交给引擎（引擎自己监听），这里只处理模式快捷键
    window.addEventListener('keydown', function (ev) {
      if (ev.altKey && ev.key === '1') { setMode('math'); }
      if (ev.altKey && ev.key === '2') { setMode('physics'); }
    });

    // 尺寸变化：通知当前引擎
    window.addEventListener('resize', function () {
      const cur = shell._engines[shell.mode];
      if (cur && cur.api && cur.api.resize) { try { cur.api.resize(); } catch (e) { } }
    });

    setMode(qs('mode') || 'math');
    window.JWLabShell = shell;
  };

  window.JWLabShell = shell;
})();
