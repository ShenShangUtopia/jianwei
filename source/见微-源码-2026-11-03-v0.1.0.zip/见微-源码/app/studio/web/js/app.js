/* 见微 · 析题台 · 主程序 */
(function () {
  const JW = window.JW, C = JW.C, el = JW.el;
  const $ = s => document.querySelector(s);
  let cur = null, viewObj = null, curStep = -1, subjFilter = '全部', guide = null;

  const SUBJ_TAB = ['全部', '数学', '物理', '化学', '生物', '语文', '英语', '历史', '地理'];

  function qs(k) {
    const m = new RegExp('[?&]' + k + '=([^&]*)').exec(location.search);
    return m ? decodeURIComponent(m[1]) : '';
  }

  /* ---------------- 左栏 ---------------- */
  function renderFilters() {
    const box = $('#filters');
    box.innerHTML = '';
    const exist = {};
    JW.questions.forEach(q => exist[q.subject] = 1);
    const items = SUBJ_TAB.filter(s => s === '全部' || exist[s]);
    box.appendChild(JW.ui.chips(items, subjFilter, s => { subjFilter = s; renderFilters(); renderList(); }));
  }

  function renderList() {
    const box = $('#qlist'); box.innerHTML = '';
    const list = JW.questions.filter(q => subjFilter === '全部' || q.subject === subjFilter);
    const years = Array.from(new Set(list.map(q => q.year))).sort((a, b) => b - a);
    years.forEach(y => {
      box.appendChild(el('div', { class: 'yr' }, y + ' 年'));
      list.filter(q => q.year === y).forEach(q => {
        const b = el('button', { class: 'qi' + (cur && cur.id === q.id ? ' is-on' : '') });
        b.innerHTML = '<span class="t">' + (q.title || q.stem.slice(0, 18)) + '</span>' +
          '<span class="m"><b>' + q.subject + '</b> · ' + q.paper + ' · ' + q.type + '</span>';
        b.addEventListener('click', () => open(q.id));
        box.appendChild(b);
      });
    });
    if (!list.length) box.appendChild(el('div', { class: 'jw-empty' }, '这个科目还没有题目'));
    $('#count').textContent = JW.questions.length + ' 题 · 2023—2025';
  }

  /* ---------------- 主区 ---------------- */
  function open(id) {
    const q = JW.byId(id);
    if (!q) return;
    cur = q; curStep = -1;
    if (viewObj && viewObj.destroy) { try { viewObj.destroy(); } catch (e) { console.warn(e); } }
    viewObj = null;
    $('#view-host').innerHTML = '';
    $('#hint').textContent = '';

    $('#qmeta').textContent = [q.year + ' 年', q.paper, q.subject, q.type].filter(Boolean).join(' · ');
    $('#qtitle').textContent = q.title || '';
    $('#qstem').innerHTML = JW.fx(q.stem || '');
    $('#answer').innerHTML = JW.fx(q.answer || '');
    $('#answer').classList.remove('hidden');
    $('#btn-answer').textContent = '收起答案';

    const ol = $('#steps'); ol.innerHTML = '';
    (q.steps || []).forEach((s, i) => {
      const li = el('li', {}, JW.fx(s));
      li.addEventListener('click', () => setStep(i));
      ol.appendChild(li);
    });
    renderRelated(q);
    $('#my-answer').value = '';
    $('#check-out').textContent = '';
    $('#check-out').className = '';
    const pts = $('#points'); pts.innerHTML = '';
    (q.points || []).forEach(p => pts.appendChild(el('span', {}, p)));
    $('#why').innerHTML = JW.fx(q.why || '');

    document.querySelectorAll('#qlist .qi').forEach(b => b.classList.remove('is-on'));
    renderList();

    const host = $('#view-host');
    const api = JW.makeApi({ host: host, q: q });
    const mount = JW.views[q.view && q.view.engine];
    if (!mount) {
      host.appendChild(el('div', { class: 'jw-card', style: 'margin:20px' },
        '<div class="jw-card-h"><h3>尚无此题型视图</h3><div class="jw-card-sub">engine=' +
        (q.view && q.view.engine) + '</div></div>'));
      return;
    }
    try {
      viewObj = mount(host, q, api) || {};
    } catch (e) {
      console.error(e);
      host.appendChild(el('div', { class: 'jw-card', style: 'margin:20px' },
        '<div class="jw-card-h"><h3>视图加载失败</h3><div class="jw-card-sub">' + e.message + '</div></div>'));
    }
    attachGuide(q);
    setStep(0);
  }

  /* ---------------- 引导层 ---------------- */
  function attachGuide(q) {
    if (!window.JWGuide) return;
    if (!guide) guide = JWGuide.mount($('#stage'), $('#view-host'));
    const steps = (q.steps || []).map(function (s) {
      return typeof s === 'string' ? s : (s.text || s.title || '');
    });
    guide.set({
      steps: steps,
      view: viewObj,
      index: 0,
      onStep: function (i) { if (i !== curStep) setStep(i); }
    });
    // 一道题只自动播放一次；一碰画面就交还给人
    if (!guide._autoPlayed) {
      guide._autoPlayed = true;
      if (steps.length >= 3) setTimeout(function () { if (!guide._touched) guide.play(); }, 900);
    }
    const host = $('#view-host');
    host.addEventListener('pointerdown', function () { guide._touched = true; if (guide.playing) guide.pause(); }, { once: false });
  }

  /* 同一考点：points 至少重合 2 个，否则按科目+题型兜底 */
  function renderRelated(q) {
    const box = $('#related');
    if (!box) return;
    box.innerHTML = '';
    const mine = (q.points || []).map(s => String(s));
    const scored = JW.questions
      .filter(x => x.id !== q.id)
      .map(x => {
        const ps = (x.points || []).map(String);
        let overlap = ps.filter(p => mine.some(m => m === p || m.indexOf(p) >= 0 || p.indexOf(m) >= 0)).length;
        if (x.subject === q.subject) overlap += 0.4;
        if (x.view && q.view && x.view.engine === q.view.engine) overlap += 0.3;
        return { q: x, score: overlap };
      })
      .filter(x => x.score >= 0.4)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);
    if (!scored.length) {
      // 再退一步：同科目里随便给三道，别留空白
      JW.questions.filter(x => x.id !== q.id && x.subject === q.subject).slice(0, 3)
        .forEach(function (x) {
          const b = JW.el('button', { class: 'jw-rel' }, '<b>' + x.subject + '</b>' + x.title);
          b.addEventListener('click', () => open(x.id));
          box.appendChild(b);
        });
      if (!box.children.length) box.appendChild(JW.el('div', { class: 'jw-empty' }, '暂时没有同类题'));
      return;
    }
    scored.forEach(function (it) {
      const b = JW.el('button', { class: 'jw-rel' }, '<b>' + it.q.subject + '</b>' + it.q.title);
      b.addEventListener('click', () => open(it.q.id));
      box.appendChild(b);
    });
  }

  /* 答案对照：只比对数字与关键词，不做判卷 */
  function normalize(s) {
    return String(s || '')
      .replace(/[\s，,。；;：:（）()]/g, '')
      .replace(/[mM]\/s/g, 'm/s')
      .toLowerCase();
  }
  function compareAnswer(mine, right) {
    const a = normalize(mine), b = normalize(right);
    if (!a) return { ok: false, msg: '先写点什么再对照' };
    const nums = x => (String(x).match(/-?\d+(?:\.\d+)?/g) || []);
    const na = nums(mine), nb = nums(right);
    const hit = nb.filter(n => na.some(m => Math.abs(parseFloat(m) - parseFloat(n)) < 1e-6)).length;
    if (a === b) return { ok: true, msg: '完全一致' };
    if (nb.length && hit === nb.length) return { ok: true, msg: '关键数值都对（' + nb.length + ' 个）' };
    if (nb.length && hit > 0) return { ok: false, msg: '对 ' + hit + '/' + nb.length + ' 个数值，再检查一下' };
    if (b.indexOf(a) >= 0) return { ok: true, msg: '方向对了，答案更完整些' };
    return { ok: false, msg: '和参考答案不一致，点「显示答案」逐项比' };
  }

  function mountInto(q) {
    if (viewObj && viewObj.destroy) { try { viewObj.destroy(); } catch (e) { } }
    viewObj = null;
    $('#view-host').innerHTML = '';
    const host = $('#view-host');
    const api = JW.makeApi({ host: host, q: q });
    const fn = JW.views[q.view && q.view.engine];
    if (!fn) return null;
    try {
      viewObj = fn(host, q, api) || {};
    } catch (e) {
      console.error(e);
    }
    return viewObj;
  }

  function setStep(i) {
    curStep = i;
    document.querySelectorAll('#steps li').forEach((li, k) => li.classList.toggle('is-on', k === i));
    if (viewObj && viewObj.applyStep) { try { viewObj.applyStep(i); } catch (e) { console.warn(e); } }
    if (guide) { try { guide.sync(i); } catch (e) { } }
  }

  function currentId() { return cur && cur.id; }

  /* ---------------- 右栏：默认只留解题路径 ---------------- */
  function setupSideMore() {
    const btn = document.getElementById('side-more');
    const side = document.getElementById('side');
    if (!btn || !side) return;
    let open = false;
    try { open = localStorage.getItem('jw.sideMore') === '1'; } catch (e) { }
    function paint() {
      side.classList.toggle('is-expanded', open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.textContent = (open ? '收起补充材料' : '补充材料 · 知识点 / 同类题 / 为什么') + (open ? ' ˄' : ' ˅');
    }
    btn.addEventListener('click', function () {
      open = !open;
      try { localStorage.setItem('jw.sideMore', open ? '1' : '0'); } catch (e) { }
      paint();
    });
    paint();
  }

  /* ---------------- 启动 ---------------- */
  function boot() {
    if (window.JWImport) { try { JWImport.register(); } catch (e) { console.warn(e); } }
    setupSideMore();
    renderFilters();
    renderList();
    const want = qs('q');
    const first = want ? JW.byId(want) : JW.questions[0];
    if (first) open(first.id);
    const imp = document.querySelector('#btn-import');
    if (imp && window.JWImport) {
      imp.addEventListener('click', function () {
        JWImport.openPanel(function (q, go) {
          setupSideMore();
    renderFilters(); renderList();
          if (go) open(q.id);
        });
      });
    }
    if (qs('import') && window.JWImport) {
      JWImport.openPanel(function (q, go) {
        setupSideMore();
    renderFilters(); renderList();
        if (go) open(q.id);
      });
    }
    if (qs('audit')) document.documentElement.setAttribute('data-audit-ready', '1');
  }
  window.JWApp = {
    open: open, setStep: setStep, renderList: renderList, mountInto: mountInto,
    get current() { return cur; },
    get view() { return viewObj; },
    get lab() { return false; }
  };
  document.addEventListener('DOMContentLoaded', boot);
  $('#btn-check').addEventListener('click', function () {
    if (!cur) return;
    const r = compareAnswer($('#my-answer').value, cur.answer);
    const out = $('#check-out');
    out.textContent = r.msg;
    out.className = r.ok ? 'ok' : 'no';
  });
  $('#my-answer').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); $('#btn-check').click(); }
  });

  $('#btn-answer').addEventListener('click', function () {
    const a = $('#answer'); a.classList.toggle('hidden');
    this.textContent = a.classList.contains('hidden') ? '显示答案' : '收起答案';
  });
})();
