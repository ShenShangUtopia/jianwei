/* 见微 · 析题台 · 导入题目：粘贴题干 → 自动判断题型 → 立刻可视化
   用法：JWImport.openPanel(function (q) { ... })   // 会把题目挂进 JW.questions 并回传
   存储：localStorage['jw.imported']（最多 200 题，本机）
*/
(function () {
  const JW = window.JW, el = JW.el, C = JW.C;
  const KEY = 'jw.imported';
  const SUBJECTS = ['数学', '物理', '化学', '生物', '语文', '英语', '历史', '地理'];

  function load() {
    try { return JSON.parse(localStorage.getItem(KEY) || '[]') || []; } catch (e) { return []; }
  }
  function save(list) {
    try { localStorage.setItem(KEY, JSON.stringify(list.slice(-200))); } catch (e) { }
  }
  function register() {
    const list = load();
    if (list.length) JW.addQuestions(list);
    return list.length;
  }

  /* ---------------- 判断 ---------------- */
  const PHYS = [
    [/平抛|斜抛|抛出|抛体/, 'projectile'],
    [/斜面|倾角/, 'incline'],
    [/弹簧|劲度/, 'spring'],
    [/圆周|向心|绳|摆/, 'circular'],
    [/波|波长|频率|振动/, 'wave'],
    [/折射|全反射|棱镜|玻璃砖|光/, 'optics'],
    [/电路|电阻|电源|电动势|电流/, 'circuit'],
    [/平行板|电场|偏转/, 'efield'],
    [/碰撞|反弹|动量/, 'collision'],
    [/卫星|轨道|万有引力/, 'gravity']
  ];
  const SUBJ = [
    [/遗传|等位基因|表现型|杂交|Aa|基因型/, 'genetics'],
    [/细胞|膜|细胞器|光合|呼吸作用|酶/, 'cell'],
    [/生态|食物链|能量流动|种群/, 'ecology'],
    [/滴定|pH|中和/, 'titration'],
    [/平衡|转化率|平衡常数|K=/, 'equilibrium'],
    [/原电池|电解|电极|电化学/, 'electrochem'],
    [/反应|方程式|配平|mol|氧化|还原/, 'reaction'],
    [/诗|词|意象|颔联|颈联|文言/, 'poem'],
    [/syntax|从句|定语|状语|谓语|英文|English/, 'syntax'],
    [/朝代|变法|革命|条约|世纪|公元|年号|1[0-9]{3}\s*年/, 'timeline'],
    [/经纬|海拔|气候|洋流|河流|地形|降水量|流域|等高线/, 'map']
  ];

  function has(re, s) { return re.test(s); }

  function detect(text) {
    const s = String(text || '');
    if (/椭圆|双曲线|抛物线|离心率|焦点|准线/.test(s) && !/顶点|开口|对称轴/.test(s)) {
      return { engine: 'graph', mode: 'conic' };
    }
    if (/f\s*\(x\)|函数|图象|导数|极值|单调/.test(s)) {
      if (/sin|cos|tan|周期|振幅/.test(s)) return { engine: 'graph', mode: 'trig' };
      if (/绝对值|\|x/.test(s)) return { engine: 'graph', mode: 'piecewise' };
      if (/向量/.test(s)) return { engine: 'graph', mode: 'vec' };
      return { engine: 'graph', mode: 'poly' };
    }
    for (let i = 0; i < PHYS.length; i++) if (has(PHYS[i][0], s)) return { engine: 'physics', kind: PHYS[i][1] };
    if (/正方体|长方体|棱柱|棱锥|棱台|圆柱|圆锥|圆台|三视图|二面角|线面角|截面|体积|表面积/.test(s)) {
      return { engine: 'solid', shape: 'cube' };
    }
    for (let i = 0; i < SUBJ.length; i++) if (has(SUBJ[i][0], s)) return { engine: 'subjects', mode: SUBJ[i][1] };
    return { engine: 'subjects', mode: 'flow' };
  }

  /* ---------------- 抽取数字 ---------------- */
  function grab(s, re, fallback) {
    const m = re.exec(s);
    return m ? parseFloat(m[1]) : fallback;
  }

  function physicsParams(kind, s) {
    const p = {};
    const num = (re, d) => grab(s, re, d);
    if (kind === 'projectile') {
      p.v0 = num(/v_?0?\s*[=:]\s*([\d.]+)/, num(/([\d.]+)\s*m\/s/, 10));
      p.angle = num(/([\d.]+)\s*°/, 0);
      p.h0 = num(/h\s*[=:]\s*([\d.]+)\s*m/, num(/([\d.]+)\s*m\s*高|高\s*([\d.]+)/, 0));
      p.g = 10;
    } else if (kind === 'incline') {
      p.angle = num(/([\d.]+)\s*°/, 30);
      p.m = num(/([\d.]+)\s*kg/, 1);
      p.mu = num(/μ\s*[=:]\s*([\d.]+)/, 0.2);
      p.g = 10;
    } else if (kind === 'circuit') {
      p.Emf = num(/([\d.]+)\s*V/, 12);
      p.R1 = num(/R1?\s*[=:]\s*([\d.]+)/, 4);
      p.R2 = num(/R2\s*[=:]\s*([\d.]+)/, 6);
      p.r0 = num(/r\s*[=:]\s*([\d.]+)/, 1);
    } else if (kind === 'optics') {
      p.n1 = 1; p.n2 = num(/n\s*[=:]\s*([\d.]+)/, 1.5);
      p.theta1 = num(/([\d.]+)\s*°/, 45);
    } else if (kind === 'wave') {
      p.v0 = num(/([\d.]+)\s*m\/s/, 2);
      p.f = num(/([\d.]+)\s*Hz/, 1);
    } else if (kind === 'spring') {
      p.k = num(/k\s*[=:]\s*([\d.]+)/, 200);
      p.m = num(/([\d.]+)\s*kg/, 1);
    } else if (kind === 'circular') {
      p.r = num(/r\s*[=:]\s*([\d.]+)/, 0.5);
      p.v0 = num(/([\d.]+)\s*m\/s/, 2);
      p.m = num(/([\d.]+)\s*kg/, 1);
    } else if (kind === 'efield') {
      p.E = num(/E\s*[=:]\s*([\d.]+)/, 6);
      p.v0 = num(/([\d.]+)\s*m\/s/, 3);
    } else if (kind === 'gravity') {
      p.r = num(/r\s*[=:]\s*([\d.]+)/, 1);
    }
    return p;
  }

  function expression(s) {
    let m = /y\s*=\s*([^，。；\n,;]+)/.exec(s);
    if (!m) m = /([\d.]*\s*(?:sin|cos|tan|ln|exp)\s*\([^)]*\))/.exec(s);
    if (!m) return '';
    return m[1].replace(/π/g, 'pi').replace(/×/g, '*').replace(/÷/g, '/')
      .replace(/[−–]/g, '-').replace(/\s+/g, '');
  }

  function stepsOf(text) {
    const arr = String(text || '').split('\n').map(t => t.trim()).filter(Boolean);
    return arr.slice(0, 6);
  }

  function build(opt) {
    const text = String(opt.text || '').trim();
    const d = opt.engine && opt.engine !== 'auto' ? { engine: opt.engine } : detect(text);
    const id = 'imp-' + Date.now().toString(36);
    const view = { engine: d.engine };
    if (d.engine === 'graph') {
      const mode = d.mode || 'poly';
      let expr = expression(text);
      if (expr) {
        const bare = expr.replace(/sin|cos|tan|sqrt|abs|ln|exp|log|pi/gi, '');
        if (/[a-wyz]/i.test(bare.replace(/x/g, ''))) expr = '';   // 带 a/b/c 这类符号参数，退回模板
      }
      expr = expr || (mode === 'trig' ? 'sin(x)' : mode === 'conic' ? 'x^2/4-y^2/2' : 'x^2');
      view.mode = mode;
      view.expr = expr.indexOf('x') >= 0 ? expr : expr + '*x';
      view.xr = [-6, 6]; view.yr = [-4, 4];
      view.params = mode === 'trig'
        ? [{ k: 'A', label: '振幅 A', min: 0.2, max: 3, step: 0.1, v: 1 },
           { k: 'B', label: '角频率 B', min: 0.2, max: 3, step: 0.1, v: 1 },
           { k: 'H', label: '相位 H', min: -3, max: 3, step: 0.1, v: 0 },
           { k: 'K', label: '上下 K', min: -3, max: 3, step: 0.1, v: 0 }]
        : [{ k: 'A', label: '开口 A', min: 0.2, max: 3, step: 0.1, v: 1 },
           { k: 'B', label: '横向 B', min: 0.5, max: 2, step: 0.1, v: 1 },
           { k: 'H', label: '对称轴 H', min: -4, max: 4, step: 0.1, v: 0 },
           { k: 'K', label: '上下 K', min: -4, max: 4, step: 0.1, v: 0 }];
      view.call = '拖动曲线平移 · 滚轮伸缩 · 拖右环旋转';
      if (mode === 'trig' && expr.indexOf('A') < 0) {
        view.expr = 'A*sin(B*x+H)+K';
        view.ghost = 'sin(x)';
      }
    } else if (d.engine === 'physics') {
      view.kind = d.kind || 'projectile';
      view.params = d.params || physicsParams(view.kind, text);
      view.cue = '这题要算的量';
    } else if (d.engine === 'solid') {
      view.shape = d.shape || 'cube';
      view.size = { a: 2, b: 3, h: 4, r: 1 };
    } else {
      view.mode = d.mode || 'flow';
      view.params = {};
      const lines = stepsOf(opt.steps);
      view.data = { title: text.slice(0, 16) || '导入题', lines: lines.length ? lines : ['读题找条件', '列式或列关系', '代入求解', '回头检验'] };
    }
    const steps = stepsOf(opt.steps);
    return {
      id: id,
      year: '导入',
      paper: opt.paper || '我的题',
      subject: opt.subject || guessSubject(text),
      type: '自定',
      title: text.replace(/\s+/g, '').slice(0, 20) || '导入题',
      stem: text,
      answer: (opt.answer || '（先自己算，再补答案）').trim(),
      steps: steps.length ? steps : ['读题，圈出已知量与所求', '判断用哪个模型 / 哪个公式', '代入数据算到底', '回代检查单位与合理性'],
      points: (opt.points || '导入题目').split(/[，,、\s]+/).filter(Boolean).slice(0, 4),
      why: '自己导入的题，先想“这题在考哪个模型”，再动手。',
      view: view,
      note: '用户导入'
    };
  }

  function guessSubject(s) {
    if (/[A-Za-z]{4,}/.test(s) && !/[\u4e00-\u9fff]/.test(s)) return '英语';
    if (/函数|方程|数列|向量|概率|三角|导数/.test(s)) return '数学';
    if (/电压|电流|力|速度|加速度|能量/.test(s)) return '物理';
    if (/反应|溶液|分子|离子/.test(s)) return '化学';
    if (/细胞|基因|生态/.test(s)) return '生物';
    if (/朝代|变法|战争|条约/.test(s)) return '历史';
    if (/气候|地形|河流|经纬/.test(s)) return '地理';
    return '语文';
  }

  /* ---------------- 面板 ---------------- */
  function openPanel(onDone) {
    const mask = el('div', { class: 'ji-mask' });
    const panel = el('div', { class: 'ji-panel' });
    mask.appendChild(panel);
    panel.innerHTML = [
      '<div class="ji-head"><b>导入题目</b><span>粘贴题干，自动判断题型并出图</span>',
      '<button class="ji-x" title="关闭">×</button></div>',
      '<textarea class="ji-text" rows="6" placeholder="把题目贴进来，例如：从高 h=0.80m 的桌面边缘以 v0=3.0m/s 水平抛出小球，g 取 10 m/s²，求落地点水平距离。"></textarea>',
      '<div class="ji-row"><span class="ji-lb">科目</span><div class="ji-chips ji-subs"></div></div>',
      '<div class="ji-row"><span class="ji-lb">图形</span><div class="ji-chips ji-eng"></div></div>',
      '<details class="ji-more"><summary>补充答案与步骤（可选）</summary>',
      '<input class="ji-ans" placeholder="答案，例如：1.2 m；落地速度 5 m/s">',
      '<textarea class="ji-steps" rows="4" placeholder="每行一步，例如：\n竖直自由落体求时间\n水平匀速求距离\n合成速度"></textarea>',
      '</details>',
      '<div class="ji-preview">将使用：—</div>',
      '<div class="ji-acts"><button class="jw-btn ji-save">存为题目</button>',
      '<button class="jw-btn jw-btn-solid ji-go">生成并打开</button>',
      '<span class="ji-tip">最多存 200 道，保存在本机浏览器</span></div>'
    ].join('');
    document.body.appendChild(mask);

    const $ = s => panel.querySelector(s);
    const ta = $('.ji-text'), ans = $('.ji-ans'), stepsEl = $('.ji-steps'), prev = $('.ji-preview');
    const subsBox = $('.ji-subs'), engBox = $('.ji-eng');
    let subject = '数学', engine = 'auto';

    SUBJECTS.forEach(s => {
      const b = el('button', { class: 'jw-chip' + (s === subject ? ' is-on' : '') }, s);
      b.addEventListener('click', () => {
        subject = s;
        subsBox.querySelectorAll('.jw-chip').forEach(x => x.classList.toggle('is-on', x.textContent === s));
        refresh();
      });
      subsBox.appendChild(b);
    });
    [['auto', '自动'], ['graph', '函数'], ['physics', '物理'], ['subjects', '学科'], ['solid', '立体']].forEach(pair => {
      const b = el('button', { class: 'jw-chip' + (pair[0] === 'auto' ? ' is-on' : '') }, pair[1]);
      b.addEventListener('click', () => {
        engine = pair[0];
        engBox.querySelectorAll('.jw-chip').forEach(x => x.classList.toggle('is-on', x.textContent === pair[1]));
        refresh();
      });
      engBox.appendChild(b);
    });

    function current() {
      return build({ text: ta.value, subject: subject, engine: engine, answer: ans.value, steps: stepsEl.value });
    }
    function refresh() {
      const q = current();
      const v = q.view;
      let line = v.engine;
      if (v.engine === 'graph') line += ' · ' + v.mode + ' · y = ' + v.expr;
      else if (v.engine === 'physics') line += ' · ' + v.kind + ' · ' + JSON.stringify(v.params);
      else if (v.engine === 'subjects') line += ' · ' + v.mode;
      else if (v.engine === 'solid') line += ' · ' + v.shape;
      prev.textContent = '将使用：' + line;
    }
    ta.addEventListener('input', refresh);
    ans.addEventListener('input', refresh);
    stepsEl.addEventListener('input', refresh);

    function close() { mask.remove(); document.removeEventListener('keydown', esc); }
    function esc(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', esc);
    $('.ji-x').addEventListener('click', close);
    mask.addEventListener('click', e => { if (e.target === mask) close(); });

    function commit(open) {
      const q = current();
      if (!q.stem.trim()) { prev.textContent = '先把题干贴进来'; return; }
      const list = load();
      list.push(q);
      save(list);
      JW.addQuestions([q]);
      close();
      if (typeof onDone === 'function') onDone(q, open);
    }
    $('.ji-save').addEventListener('click', () => commit(false));
    $('.ji-go').addEventListener('click', () => commit(true));
    refresh();
    ta.focus();
  }

  window.JWImport = { openPanel: openPanel, register: register, build: build, detect: detect, load: load };
})();
