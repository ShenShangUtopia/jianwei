/* 见微 · 析题台 · 物理过程仿真视图
   契约：JW.registerView('physics', mount) -> {applyStep(i), destroy()}
   十种过程：抛体 / 斜面 / 弹簧振子 / 匀速圆周 / 横波 / 折射 / 电路 / 电场偏转 / 一维碰撞 / 卫星轨道
   仅依赖 window.JW，无外部库、无网络、无 ES module。 */
(function () {
  'use strict';
  const JW = window.JW;
  if (!JW || !JW.registerView) return;

  const C = JW.C, PI = Math.PI, TAU = PI * 2;
  const sin = Math.sin, cos = Math.cos, sqrt = Math.sqrt, abs = Math.abs;
  const min = Math.min, max = Math.max;
  const rad = JW.rad, num = JW.num, clamp = JW.clamp, el = JW.el;
  const DT = 1 / 240;

  function fmt(v, d) {
    if (!isFinite(v)) return '—';
    return num(v, d == null ? 2 : d);
  }

  /* ================= 画布与标注工具 ================= */
  function niceStep(span) {
    const raw = Math.max(1e-9, abs(span) / 7);
    const mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    const n = raw / mag;
    return (n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10) * mag;
  }
  function viewRect(cv, x0, x1, y0, y1, pad, uniform) {
    pad = pad == null ? 0.03 : pad;
    let cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    let hw = max((x1 - x0) / 2, 1e-6) * (1 + pad * 2);
    let hh = max((y1 - y0) / 2, 1e-6) * (1 + pad * 2);
    if (uniform) {
      const ar = max(0.2, cv.w / max(1, cv.h));
      if (hw / hh < ar) hw = hh * ar; else hh = hw / ar;
    }
    cv.setRange([cx - hw, cx + hw], [cy - hh, cy + hh]);
  }
  function gridOf(cv, span, labels) {
    cv.grid(niceStep(span), { grid: C.grid, axis: C.faint, labels: labels !== false });
  }
  function plabel(cv, X, Y, s, o) {
    o = o || {};
    const ctx = cv.ctx;
    ctx.save();
    ctx.font = (o.weight || 600) + ' ' + (o.size || 11) + 'px ' + (o.mono ? C.mono : C.sans);
    ctx.textAlign = o.align || 'left';
    ctx.textBaseline = o.base || 'middle';
    ctx.lineJoin = 'round';
    if (o.halo !== false) {
      ctx.lineWidth = 3.6;
      ctx.strokeStyle = o.haloColor || C.paper;
      ctx.strokeText(s, X, Y);
    }
    ctx.fillStyle = o.color || C.ink;
    ctx.fillText(s, X, Y);
    ctx.restore();
  }
  function label(cv, x, y, s, o) {
    o = o || {};
    plabel(cv, cv.px(x) + (o.ox || 0), cv.py(y) + (o.oy || 0), s, o);
  }
  function polyline(cv, pts, color, w, dash, alpha) {
    if (!pts || pts.length < 2) return;
    const ctx = cv.ctx;
    ctx.save();
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.beginPath();
    ctx.moveTo(cv.px(pts[0][0]), cv.py(pts[0][1]));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(cv.px(pts[i][0]), cv.py(pts[i][1]));
    ctx.strokeStyle = color || C.ink;
    ctx.lineWidth = w || 1.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    if (dash) ctx.setLineDash(dash);
    ctx.stroke();
    ctx.restore();
  }
  function shape(cv, pts, opt) {
    opt = opt || {};
    if (!pts || pts.length < 2) return;
    const ctx = cv.ctx;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(cv.px(pts[0][0]), cv.py(pts[0][1]));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(cv.px(pts[i][0]), cv.py(pts[i][1]));
    ctx.closePath();
    if (opt.fill) {
      ctx.globalAlpha = opt.alpha == null ? 1 : opt.alpha;
      ctx.fillStyle = opt.fill;
      ctx.fill();
    }
    if (opt.stroke) {
      ctx.globalAlpha = 1;
      ctx.strokeStyle = opt.stroke;
      ctx.lineWidth = opt.width || 1.4;
      if (opt.dash) ctx.setLineDash(opt.dash);
      ctx.stroke();
    }
    ctx.restore();
  }
  function dot(cv, x, y, r, fill, stroke, lw) {
    const ctx = cv.ctx;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cv.px(x), cv.py(y), max(0.5, r), 0, TAU);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1.5; ctx.stroke(); }
    ctx.restore();
  }
  function ringWorld(cv, x, y, r, color, w, dash) {
    const ctx = cv.ctx;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cv.px(x), cv.py(y), max(1, r * cv.sx()), 0, TAU);
    ctx.strokeStyle = color;
    ctx.lineWidth = w || 1.2;
    if (dash) ctx.setLineDash(dash);
    ctx.stroke();
    ctx.restore();
  }
  function vec(cv, x, y, dx, dy, color, w, text, o) {
    o = o || {};
    if (abs(dx) < 1e-9 && abs(dy) < 1e-9) return;
    cv.arrow(x, y, x + dx, y + dy, { color: color, width: w || 1.7, head: o.head || 8, dash: o.dash });
    if (text) {
      const ax = dx < 0 ? -1 : 1, ay = dy < 0 ? -1 : 1;
      label(cv, x + dx, y + dy, text, {
        color: color, size: o.size || 10.5, weight: 700,
        align: dx < 0 ? 'right' : 'left',
        ox: dx === 0 ? 6 : ax * 5,
        oy: dy === 0 ? -9 : (dy < 0 ? -9 : 12)
      });
    }
  }
  function dimLine(cv, a, b, text, color, dx, dy) {
    const ctx = cv.ctx;
    const ax = cv.px(a[0]), ay = cv.py(a[1]), bx = cv.px(b[0]), by = cv.py(b[1]);
    ctx.save();
    ctx.strokeStyle = color || C.ink2;
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
    ctx.setLineDash([]);
    const ang = Math.atan2(by - ay, bx - ax);
    const nx = cos(ang + PI / 2) * 4.5, ny = sin(ang + PI / 2) * 4.5;
    ctx.beginPath();
    ctx.moveTo(ax - nx, ay - ny); ctx.lineTo(ax + nx, ay + ny);
    ctx.moveTo(bx - nx, by - ny); ctx.lineTo(bx + nx, by + ny);
    ctx.stroke();
    ctx.restore();
    label(cv, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, text, {
      color: color || C.ink2, size: 10.5, align: 'center',
      ox: dx || 0, oy: dy == null ? 13 : dy
    });
  }
  function angleArc(cv, cx, cy, r, a0, a1, color, text) {
    const ctx = cv.ctx;
    ctx.save();
    ctx.beginPath();
    for (let i = 0; i <= 24; i++) {
      const a = a0 + (a1 - a0) * i / 24;
      const X = cv.px(cx + r * cos(a)), Y = cv.py(cy + r * sin(a));
      if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y);
    }
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.restore();
    if (text) {
      const am = (a0 + a1) / 2;
      label(cv, cx + r * cos(am), cy + r * sin(am), text, {
        color: color, size: 10.5, align: 'center', oy: sin(am) > 0 ? -10 : 12
      });
    }
  }
  function panel(ctx, X, Y, W, H) {
    ctx.save();
    ctx.fillStyle = C.card;
    ctx.strokeStyle = C.line2;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.rect(X + 0.5, Y + 0.5, W, H);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
  function barsPanel(cv, X, Y, W, rows, title) {
    const ctx = cv.ctx;
    const H = 24 + rows.length * 26;
    panel(ctx, X, Y, W, H);
    ctx.save();
    ctx.textBaseline = 'middle';
    ctx.font = '600 9.5px ' + C.sans;
    ctx.fillStyle = C.faint;
    ctx.textAlign = 'left';
    ctx.fillText(title || '', X + 10, Y + 13);
    rows.forEach(function (r, i) {
      const y = Y + 31 + i * 26;
      ctx.font = '10.5px ' + C.sans;
      ctx.fillStyle = C.soft;
      ctx.textAlign = 'left';
      ctx.fillText(r.label, X + 10, y);
      ctx.font = '600 10px ' + C.mono;
      ctx.fillStyle = C.ink;
      ctx.textAlign = 'right';
      ctx.fillText(r.text, X + W - 10, y);
      ctx.fillStyle = C.line2;
      ctx.fillRect(X + 10, y + 7, W - 20, 5);
      ctx.fillStyle = r.color;
      ctx.fillRect(X + 10, y + 7, (W - 20) * clamp(r.frac || 0, 0, 1), 5);
    });
    ctx.restore();
  }
  function springCoil(cv, x1, x2, y, coils, ampPx) {
    const ctx = cv.ctx;
    const X1 = cv.px(x1), X2 = cv.px(x2), Y = cv.py(y);
    const span = X2 - X1;
    if (span < 6) return;
    const n = max(4, coils) * 2;
    const step = span / (n + 2);
    ctx.save();
    ctx.strokeStyle = C.ink2;
    ctx.lineWidth = 1.5;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(X1, Y);
    ctx.lineTo(X1 + step, Y);
    for (let i = 0; i < n; i++) {
      const xx = X1 + step * (i + 1.5);
      ctx.lineTo(xx, Y + (i % 2 ? -ampPx : ampPx));
    }
    ctx.lineTo(X2 - step, Y);
    ctx.lineTo(X2, Y);
    ctx.stroke();
    ctx.restore();
  }

  /* ================= 通用增强工具（新场景共用） ================= */
  function worldPath(cv, pts, opt) {
    if (!pts || pts.length < 2) return;
    opt = opt || {};
    const ctx = cv.ctx;
    ctx.save();
    ctx.globalAlpha = opt.alpha == null ? 1 : opt.alpha;
    ctx.beginPath();
    ctx.moveTo(cv.px(pts[0][0]), cv.py(pts[0][1]));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(cv.px(pts[i][0]), cv.py(pts[i][1]));
    ctx.strokeStyle = opt.color || C.ink2;
    ctx.lineWidth = opt.width || 1.5;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (opt.dash) ctx.setLineDash(opt.dash);
    if (opt.offset) ctx.lineDashOffset = opt.offset;
    ctx.stroke();
    ctx.restore();
  }
  function pathTable(pts) {
    const tab = [0];
    for (let i = 1; i < pts.length; i++) {
      tab.push(tab[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    }
    return tab;
  }
  function pathPoint(pts, tab, f) {
    if (!pts || !pts.length) return [0, 0, 0];
    const total = tab[tab.length - 1] || 0;
    if (pts.length === 1 || total < 1e-9) return [pts[0][0], pts[0][1], 0];
    const s = clamp(f, 0, 1) * total;
    let i = 1;
    while (i < tab.length - 1 && tab[i] < s) i++;
    const a = pts[i - 1], b = pts[i];
    const seg = tab[i] - tab[i - 1] || 1e-9;
    const k = clamp((s - tab[i - 1]) / seg, 0, 1);
    return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, Math.atan2(b[1] - a[1], b[0] - a[0])];
  }
  function flowDots(cv, pts, tab, phase, color, n, r) {
    if (!pts || pts.length < 2) return;
    const total = tab[tab.length - 1] || 0;
    if (total < 8) return;
    for (let i = 0; i < n; i++) {
      const f = ((phase + i / n) % 1 + 1) % 1;
      const p = pathPoint(pts, tab, f);
      dot(cv, p[0], p[1], r || 2, color, null, 0);
    }
  }
  function pArrow(ctx, x1, y1, x2, y2, color, w, head) {
    const ang = Math.atan2(y2 - y1, x2 - x1), L = head || 7;
    ctx.save();
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
    ctx.strokeStyle = color; ctx.lineWidth = w || 1.6; ctx.lineCap = 'round';
    ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - L * cos(ang - .42), y2 - L * sin(ang - .42));
    ctx.lineTo(x2 - L * cos(ang + .42), y2 - L * sin(ang + .42));
    ctx.closePath(); ctx.fillStyle = color; ctx.fill();
    ctx.restore();
  }
  function pFlow(ctx, pts, color, dash, offset, w, alpha) {
    if (!pts || pts.length < 2) return;
    ctx.save();
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.strokeStyle = color || C.ink2; ctx.lineWidth = w || 2;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.setLineDash(dash || []);
    if (offset) ctx.lineDashOffset = offset;
    ctx.stroke();
    ctx.restore();
  }
  function roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r == null ? 2 : r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function dotPx(ctx, x, y, r, fill, stroke, lw) {
    ctx.save();
    ctx.beginPath(); ctx.arc(x, y, max(0.5, r), 0, TAU);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1.4; ctx.stroke(); }
    ctx.restore();
  }
  /* 昼夜两套皮里 C.ink/accent 会变成亮色：按底色亮度自动选反差字色 */
  function isLightColor(col) {
    if (!col) return false;
    let r = 0, g = 0, b = 0;
    if (col.charAt(0) === '#') {
      let h = col.slice(1);
      if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
      r = parseInt(h.slice(0, 2), 16); g = parseInt(h.slice(2, 4), 16); b = parseInt(h.slice(4, 6), 16);
    } else {
      const m = /rgba?\(([^)]+)\)/.exec(col);
      if (!m) return false;
      const p = m[1].split(',').map(Number);
      r = p[0] || 0; g = p[1] || 0; b = p[2] || 0;
    }
    return 0.299 * r + 0.587 * g + 0.114 * b > 158;
  }
  function onColor(col) { return isLightColor(col) ? '#081F5C' : '#FFFFFF'; }
  function tagBox(cv, X, Y, text, color, align) {
    const ctx = cv.ctx;
    ctx.save();
    ctx.font = '600 10px ' + C.sans;
    const tw = ctx.measureText(text).width, w = tw + 14, h = 18;
    const x = X - (align === 'center' ? w / 2 : align === 'right' ? w : 0), y = Y - h / 2;
    roundRect(ctx, x + .5, y + .5, w, h, 2);
    ctx.fillStyle = C.card; ctx.fill();
    ctx.strokeStyle = C.line2; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = color || C.ink2;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(text, x + w / 2, y + h / 2 + .5);
    ctx.restore();
    return { x: x, y: y, w: w, h: h };
  }
  function framePanel(cv, X, Y, W, H, title) {
    const ctx = cv.ctx;
    panel(ctx, X, Y, W, H);
    if (title) {
      ctx.save();
      ctx.font = '600 9px ' + C.sans;
      ctx.fillStyle = C.faint;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(title, X + 9, Y + 11);
      ctx.restore();
    }
    return { x: X + 9, y: Y + 19, w: W - 18, h: max(18, H - 27) };
  }
  /* 等势线：marching squares，返回世界坐标线段 */
  function marchSquares(fn, xr, yr, level, nx, ny) {
    nx = nx || 54; ny = ny || 38;
    const segs = [];
    const dx = (xr[1] - xr[0]) / nx, dy = (yr[1] - yr[0]) / ny;
    const val = [];
    for (let j = 0; j <= ny; j++) {
      val[j] = [];
      for (let i = 0; i <= nx; i++) val[j][i] = fn(xr[0] + i * dx, yr[0] + j * dy) - level;
    }
    function ip(x1, y1, v1, x2, y2, v2) {
      const k = v1 / (v1 - v2);
      return [x1 + (x2 - x1) * k, y1 + (y2 - y1) * k];
    }
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const x0 = xr[0] + i * dx, y0 = yr[0] + j * dy, x1 = x0 + dx, y1 = y0 + dy;
        const v00 = val[j][i], v10 = val[j][i + 1], v11 = val[j + 1][i + 1], v01 = val[j + 1][i];
        const pts = [];
        if ((v00 > 0) !== (v10 > 0)) pts.push(ip(x0, y0, v00, x1, y0, v10));
        if ((v10 > 0) !== (v11 > 0)) pts.push(ip(x1, y0, v10, x1, y1, v11));
        if ((v11 > 0) !== (v01 > 0)) pts.push(ip(x1, y1, v11, x0, y1, v01));
        if ((v01 > 0) !== (v00 > 0)) pts.push(ip(x0, y1, v01, x0, y0, v00));
        if (pts.length === 2) segs.push([pts[0], pts[1]]);
        else if (pts.length === 4) { segs.push([pts[0], pts[1]]); segs.push([pts[2], pts[3]]); }
      }
    }
    return segs;
  }

  /* ================= 1. 抛体 ================= */
  function sceneProjectile() {
    const P = { v0: 20, angle: 45, h0: 0, g: 10 };
    function met() {
      const th = rad(P.angle), v = P.v0, g = P.g;
      const vx = v * cos(th), vy = v * sin(th);
      const Tf = (vy + sqrt(vy * vy + 2 * g * P.h0)) / g;
      return {
        vx: vx, vy: vy, Tf: Tf, R: vx * Tf,
        H: P.h0 + vy * vy / (2 * g), xp: vx * (vy / g)
      };
    }
    return {
      P: P,
      oneShot: true,
      chips: null,
      sliders: [
        { k: 'v0', label: '初速 v₀', min: 5, max: 40, step: 1, dec: 0 },
        { k: 'angle', label: '抛射角 θ', min: 0, max: 85, step: 1, dec: 0 },
        { k: 'h0', label: '高度 h₀', min: 0, max: 20, step: 0.5, dec: 1 }
      ],
      hints: [
        '场景与已知量：初速、抛射角、离地高度，g 取 10 m/s²。',
        '运动分解：水平匀速 v₀cosθ，竖直匀变速 v₀sinθ − gt。',
        '合成两个分量，得到射程、飞行时间与最大高度。'
      ],
      duration: function () { return max(0.5, met().Tf); },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const m = met(), g = P.g;
        const Tf = max(m.Tf, 0.25), R = max(m.R, 0.5), H = max(m.H, 0.5);
        const tt = clamp(t, 0, Tf);
        const vx0 = -0.05 * R, vx1 = 1.05 * R, vy0 = -0.12 * H, vy1 = 1.18 * H;
        viewRect(cv, vx0, vx1, vy0, vy1, 0.01, true);
        const usedFrac = (vy1 - vy0) / max(1e-6, cv.yr[1] - cv.yr[0]);
        if (usedFrac < 0.42) {
          viewRect(cv, vx0, vx1, vy0, vy1, 0.01, false);
          label(cv, cv.xr[0], cv.yr[0], '纵向放大显示', {
            color: C.faint, size: 9.5, weight: 500, ox: 8, oy: -10
          });
        }
        gridOf(cv, R * 1.1);
        cv.line(cv.xr[0], 0, cv.xr[1], 0, { color: C.line, width: 2 });
        label(cv, cv.xr[0], 0, '地面', { color: C.faint, size: 9.5, ox: 8, oy: 11, weight: 500 });
        const full = [];
        for (let i = 0; i <= 60; i++) {
          const s = Tf * i / 60;
          full.push([m.vx * s, P.h0 + m.vy * s - 0.5 * g * s * s]);
        }
        polyline(cv, full, C.data[3], 1.2, [4, 4], 0.9);
        const path = [], n = 48;
        for (let i = 0; i <= n; i++) {
          const s = tt * i / n;
          path.push([m.vx * s, P.h0 + m.vy * s - 0.5 * g * s * s]);
        }
        for (let i = 0; i < n; i++) {
          const s = tt * i / n;
          const px = m.vx * s, py = P.h0 + m.vy * s - 0.5 * g * s * s;
          dot(cv, px, py, 1.4 + 1.2 * i / n, C.ink2, null, 0);
        }
        polyline(cv, path, C.ink2, 1.9);
        const bx = m.vx * tt, by = P.h0 + m.vy * tt - 0.5 * g * tt * tt;
        const ctx = cv.ctx;
        ctx.save();
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = C.line;
        ctx.beginPath();
        ctx.ellipse(cv.px(bx), cv.py(0), 9, 3, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
        const vy = m.vy - g * tt;
        if (lv >= 1) {
          const scale = 0.2 * (cv.xr[1] - cv.xr[0]) / max(P.v0, 1);
          cv.line(bx, by, bx + m.vx * scale, by, { color: C.data[2], width: 1, dash: [3, 3] });
          cv.line(bx, by, bx, by + vy * scale, { color: C.data[2], width: 1, dash: [3, 3] });
          vec(cv, bx, by, m.vx * scale, 0, C.jade, 1.5, 'vx', { size: 10 });
          vec(cv, bx, by, 0, vy * scale, C.jade, 1.5, 'vy', { size: 10 });
          vec(cv, bx, by, m.vx * scale, vy * scale, C.accent, 2, 'v', { size: 10.5 });
          angleArc(cv, 0, P.h0, max(0.06 * R, 0.3), 0, rad(P.angle), C.accent, 'θ');
        }
        dot(cv, bx, by, 5.5, C.ink, C.paper, 1.6);
        if (lv >= 2) {
          dimLine(cv, [0, -0.055 * H], [R, -0.055 * H], '射程 R = ' + fmt(R, 1) + ' m', C.ink2, 0, 15);
          dimLine(cv, [m.xp, 0], [m.xp, m.H], 'H = ' + fmt(m.H, 1) + ' m', C.accent, 8, 0);
          ringWorld(cv, R, 0, 0.014 * R, C.accent, 1.5, [3, 3]);
          label(cv, R, 0, 'T = ' + fmt(Tf, 2) + ' s', { color: C.accent, size: 10.5, ox: -6, oy: 16, align: 'right' });
        } else if (lv === 0) {
          label(cv, 0, P.h0, 'v₀ = ' + fmt(P.v0, 0) + ' m/s', { color: C.soft, size: 10.5, ox: 12, oy: -14 });
          label(cv, 0, P.h0, 'θ = ' + fmt(P.angle, 0) + '°', { color: C.soft, size: 10.5, ox: 12, oy: 0 });
          if (P.h0 > 0.01) label(cv, 0, P.h0, 'h₀ = ' + fmt(P.h0, 1) + ' m', { color: C.soft, size: 10.5, ox: 12, oy: 14 });
        }
      },
      readouts: function (t) {
        const m = met(), Tf = max(m.Tf, 0.25);
        const tt = clamp(t, 0, Tf);
        const vy = m.vy - P.g * tt;
        const vNow = sqrt(m.vx * m.vx + vy * vy);
        const vyEnd = m.vy - P.g * Tf;
        const vEnd = sqrt(m.vx * m.vx + vyEnd * vyEnd);
        return [
          { label: '射程 R', value: fmt(max(m.R, 0), 1), unit: 'm' },
          { label: '飞行时间 T', value: fmt(Tf, 2), unit: 's' },
          { label: '最大高度 H', value: fmt(max(m.H, 0), 1), unit: 'm' },
          { label: '当前速度', value: fmt(vNow, 1), unit: 'm/s' },
          { label: '落地速度', value: fmt(vEnd, 1), unit: 'm/s' }
        ];
      },
      hot: [[3], [3], [0, 1, 2, 4]],
      status: function (t) {
        const m = met(), Tf = max(m.Tf, 0.25);
        if (t >= Tf - 0.015) return '落地';
        const vy = m.vy - P.g * t;
        if (abs(vy) < 0.3) return '最高点';
        return vy > 0 ? '上升' : '下落';
      }
    };
  }

  /* ================= 2. 斜面 ================= */
  function sceneIncline() {
    const P = { angle: 30, mu: 0.2, m: 2, L: 3, g: 10 };
    function dyn() {
      const th = rad(P.angle), s = sin(th), c = cos(th);
      const aRaw = P.g * (s - P.mu * c);
      const moving = aRaw > 1e-6;
      const N = P.m * P.g * c;
      return {
        th: th, s: s, c: c, moving: moving,
        a: max(aRaw, 0), N: N,
        f: moving ? P.mu * N : P.m * P.g * s,
        T: moving ? sqrt(2 * P.L / max(aRaw, 1e-6)) : 0
      };
    }
    return {
      P: P,
      oneShot: true,
      sliders: [
        { k: 'angle', label: '倾角 θ', min: 5, max: 60, step: 1, dec: 0 },
        { k: 'mu', label: '摩擦系数 μ', min: 0, max: 0.6, step: 0.02, dec: 2 },
        { k: 'm', label: '质量 m', min: 0.5, max: 5, step: 0.5, dec: 1 },
        { k: 'L', label: '斜面长 L', min: 1.5, max: 5, step: 0.1, dec: 1 }
      ],
      hints: [
        '先看受力：重力 mg、支持力 N、沿斜面的摩擦力 f。',
        '沿斜面方向列方程：mg sinθ − f = ma，f = μN。',
        '由加速度求出到低端的速度与下滑时间。'
      ],
      aux: function (src) {
        const h = Number(src.h);
        if (isFinite(h) && h > 0 && !isFinite(Number(src.L))) {
          P.L = h / max(0.05, sin(rad(P.angle)));
        }
      },
      duration: function () {
        const d = dyn();
        return d.moving ? max(0.6, d.T) : 1.2;
      },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const d = dyn();
        const H = P.L * d.s, Bx = P.L * d.c;
        /* 静止时裁到 3.6 m 内，避免 6 m 横杆把方块压成一个墨点 */
        const vw = d.moving ? Bx + 0.9 : max(2.6, min(Bx + 0.9, 3.6));
        const vh = d.moving ? H + 0.7 : max(H + 0.55, 1.05);
        viewRect(cv, -0.4, vw, -0.22, vh, 0.03, d.moving);
        gridOf(cv, max(Bx, H, 1) * 2.2);
        cv.line(cv.xr[0], 0, cv.xr[1], 0, { color: C.line, width: 2 });
        shape(cv, [[0, 0], [0, H], [Bx, 0]], { fill: C.grid2, stroke: C.ink2, width: 1.4 });
        const tt = clamp(t, 0, max(d.T, 0.001));
        const dist = d.moving ? min(0.5 * d.a * tt * tt, P.L - 0.36) : 0.3;
        const sz = clamp(0.42 * cv.sx(), 18, 40);
        const off = (sz / 2) / max(1e-6, cv.sx());
        const cx = dist * d.c + off * d.s;
        const cy = H - dist * d.s + off * d.c;
        const X = cv.px(cx), Y = cv.py(cy);
        const ctx = cv.ctx;
        /* 静止场景也让画面“活着”：脉冲圈 + 若无摩擦的虚线对照滑块 */
        if (!d.moving) {
          const k = (sin(TAU * t / 1.2) + 1) / 2;
          ctx.save();
          ctx.beginPath();
          ctx.arc(X, Y, sz * 0.82 + 9 * k, 0, TAU);
          ctx.strokeStyle = C.accent;
          ctx.globalAlpha = 0.14 + 0.34 * (1 - k);
          ctx.lineWidth = 1.4;
          ctx.setLineDash([3, 4]);
          ctx.stroke();
          ctx.restore();
          if (d.s > 0.02) {
            const u = t % 2.4;
            const gt = u < 1.2 ? u : 2.4 - u;
            const gd = min(0.5 * P.g * d.s * gt * gt, P.L - 0.4);
            const gx = gd * d.c + off * d.s, gy = H - gd * d.s + off * d.c;
            ctx.save();
            ctx.translate(cv.px(gx), cv.py(gy));
            ctx.rotate(d.th);
            ctx.strokeStyle = C.accent;
            ctx.globalAlpha = 0.55;
            ctx.lineWidth = 1.2;
            ctx.setLineDash([4, 4]);
            ctx.strokeRect(-sz / 2, -sz / 2, sz, sz);
            ctx.restore();
            label(cv, gx, gy, '若无摩擦', { color: C.accent, size: 9.5, align: 'center', oy: -20 });
          }
          /* 静止时用一枚计时表 + 静摩擦说明填满右侧，画面不再是一根横线 */
          const ckx = cv.w * 0.64, cky = cv.h * 0.26, ckr = 32;
          ctx.save();
          ctx.beginPath(); ctx.arc(ckx, cky, ckr, 0, TAU);
          ctx.fillStyle = C.card; ctx.fill();
          ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.4; ctx.stroke();
          for (let q = 0; q < 4; q++) {
            const aa = -PI / 2 + q * PI / 2;
            ctx.beginPath();
            ctx.moveTo(ckx + cos(aa) * (ckr - 6), cky + sin(aa) * (ckr - 6));
            ctx.lineTo(ckx + cos(aa) * (ckr - 1), cky + sin(aa) * (ckr - 1));
            ctx.strokeStyle = C.faint; ctx.lineWidth = 1; ctx.stroke();
          }
          const ha = -PI / 2 + TAU * ((t % 1.2) / 1.2);
          ctx.beginPath(); ctx.moveTo(ckx, cky); ctx.lineTo(ckx + cos(ha) * (ckr - 7), cky + sin(ha) * (ckr - 7));
          ctx.strokeStyle = C.accent; ctx.lineWidth = 2; ctx.stroke();
          ctx.beginPath(); ctx.arc(ckx, cky, 2.2, 0, TAU); ctx.fillStyle = C.ink; ctx.fill();
          ctx.restore();
          plabel(cv, ckx, cky + ckr + 13, '计时 ' + fmt(t % 1.2, 2) + ' s', { color: C.soft, size: 9.5, align: 'center', weight: 500 });
          const pxx = cv.w * 0.52, pyy = cv.h * 0.52, pww = min(240, cv.w * 0.40), phh = 78;
          const fp = framePanel(cv, pxx, pyy, pww, phh, '静摩擦');
          plabel(cv, pxx + 10, fp.y + 3, 'μ = ' + fmt(P.mu, 2) + '　tanθ = ' + fmt(d.s / max(d.c, 1e-6), 2),
            { color: C.ink, size: 10, weight: 600 });
          plabel(cv, pxx + 10, fp.y + 21, 'μ ≥ tanθ → 保持静止', { color: C.accent, size: 10 });
          plabel(cv, pxx + 10, fp.y + 39, 'f = mg sinθ = ' + fmt(P.m * P.g * d.s, 1) + ' N', { color: C.ink2, size: 10 });
          plabel(cv, pxx + 10, fp.y + 56, 'v = 0，位移保持为 0', { color: C.soft, size: 9.5 });
        }
        ctx.save();
        ctx.translate(X, Y);
        ctx.rotate(d.th);
        ctx.fillStyle = C.ink;
        ctx.fillRect(-sz / 2, -sz / 2, sz, sz);
        ctx.strokeStyle = C.paper;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-sz / 2, -sz / 2, sz, sz);
        ctx.restore();
        const Fg = P.m * P.g, sc = 0.3 * max(H, 1.2) / max(Fg, 1);
        if (lv >= 1) {
          vec(cv, cx, cy, 0, -Fg * sc, C.accent, 2, 'mg', { size: 10 });
          vec(cv, cx, cy, d.s * d.N * sc, d.c * d.N * sc, C.jade, 2, 'N', { size: 10 });
          vec(cv, cx, cy, -d.c * d.f * sc, d.s * d.f * sc, C.gold, 2, 'f', { size: 10 });
          if (d.moving) {
            const net = P.m * d.a;
            vec(cv, cx, cy, d.c * net * sc, -d.s * net * sc, C.ink2, 2.2, 'F合', { dash: [5, 4], size: 10 });
          }
          angleArc(cv, 0, 0, max(0.4, Bx * 0.16), 0, d.th, C.soft, 'θ');
        }
        if (lv >= 2 && d.moving) {
          const v = d.a * tt;
          const vs = 0.4 / max(d.a * max(d.T, 0.4), 0.05);
          vec(cv, cx, cy, d.c * v * vs, -d.s * v * vs, C.accent, 2, 'v', { size: 10 });
          const ox = d.s * 0.32, oy = d.c * 0.32;
          dimLine(cv, [0.35 * d.c + ox, H - 0.35 * d.s + oy],
            [(P.L - 0.3) * d.c + ox, H - (P.L - 0.3) * d.s + oy],
            'L = ' + fmt(P.L, 1) + ' m', C.jade, 0, 12);
          label(cv, Bx * 0.72, H * 0.3, 'a = ' + fmt(d.a, 1) + ' m/s²', { color: C.accent, size: 11, align: 'center' });
          label(cv, Bx * 0.72, H * 0.3, 't = ' + fmt(d.T, 2) + ' s', { color: C.accent, size: 11, align: 'center', oy: 16 });
        } else if (lv === 0) {
          label(cv, cv.xr[0], cv.yr[0], 'θ = ' + fmt(P.angle, 0) + '°  μ = ' + fmt(P.mu, 2) + '  m = ' + fmt(P.m, 1) + ' kg',
            { color: C.soft, size: 10.5, ox: 8, oy: -12 });
        }
      },
      readouts: function (t) {
        const d = dyn();
        const tt = clamp(t, 0, max(d.T, 0.001));
        const v = d.moving ? d.a * tt : 0;
        return [
          { label: '加速度 a', value: fmt(d.a, 2), unit: 'm/s²' },
          { label: '下滑速度', value: fmt(v, 2), unit: 'm/s' },
          { label: '支持力 N', value: fmt(d.N, 1), unit: 'N' },
          { label: '摩擦力 f', value: fmt(d.f, 1), unit: 'N' },
          { label: '下滑时间', value: d.moving ? fmt(d.T, 2) : '—', unit: d.moving ? 's' : '' }
        ];
      },
      hot: [[], [2, 3], [0, 1, 4]],
      status: function (t) {
        const d = dyn();
        if (!d.moving) return '静止（μ ≥ tanθ）';
        if (t >= d.T - 0.01) return '到达底端';
        return '加速下滑';
      }
    };
  }

  /* ================= 3. 弹簧振子 ================= */
  function sceneSpring() {
    const P = { m: 2, k: 200, A: 0.35 };
    function om() { return sqrt(P.k / max(P.m, 0.01)); }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'm', label: '质量 m', min: 0.5, max: 5, step: 0.1, dec: 1 },
        { k: 'k', label: '劲度系数 k', min: 20, max: 400, step: 5, dec: 0 },
        { k: 'A', label: '振幅 A', min: 0.08, max: 0.8, step: 0.01, dec: 2 }
      ],
      hints: [
        '弹簧振子：偏离平衡位置后，弹力 F = −kx 提供恢复力。',
        '动能与弹性势能互相转化，机械能 E = ½kA² 守恒。',
        '由 ω = √(k/m) 得周期 T = 2π√(m/k)。'
      ],
      duration: function () { return TAU / om(); },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const w = om(), Tp = TAU / w;
        const x = P.A * cos(w * t), v = -P.A * w * sin(w * t), a = -w * w * x;
        const KE = 0.5 * P.m * v * v, PE = 0.5 * P.k * x * x, E = KE + PE;
        const L0 = 0.95, wall = -L0;
        viewRect(cv, wall - 0.55, P.A + 0.85, -0.16, 1.1, 0.02, false);
        gridOf(cv, 1.1);
        cv.line(cv.xr[0], 0, cv.xr[1], 0, { color: C.line, width: 2 });
        const ctx = cv.ctx;
        ctx.save();
        ctx.fillStyle = C.data[3];
        ctx.fillRect(cv.px(wall - 0.16), cv.py(0.95), 0.16 * cv.sx(), 0.95 * cv.sy());
        ctx.strokeStyle = C.data[2];
        ctx.strokeRect(cv.px(wall - 0.16), cv.py(0.95), 0.16 * cv.sx(), 0.95 * cv.sy());
        ctx.restore();
        cv.line(0, 0, 0, 0.95, { color: C.data[3], width: 1, dash: [4, 5] });
        label(cv, 0, 0.95, '平衡位置', { color: C.faint, size: 9.5, align: 'center', oy: -9, weight: 500 });
        const half = 0.15;
        springCoil(cv, wall, x - half, 0.15, 13, 7);
        ctx.save();
        ctx.fillStyle = C.ink;
        ctx.fillRect(cv.px(x - half), cv.py(0.15 + half), half * 2 * cv.sx(), half * 2 * cv.sy());
        ctx.strokeStyle = C.paper;
        ctx.lineWidth = 1.4;
        ctx.strokeRect(cv.px(x - half), cv.py(0.15 + half), half * 2 * cv.sx(), half * 2 * cv.sy());
        ctx.restore();
        if (lv >= 1) {
          const sc = 0.62 / max(P.A * w, 0.05);
          vec(cv, x, 0.15, v * sc, 0, C.accent, 2, 'v', { size: 10 });
          const F = -P.k * x, fsc = 0.55 / max(P.k * P.A, 1);
          vec(cv, x, 0.5, F * fsc, 0, C.jade, 2, 'F', { size: 10 });
        }
        barsPanel(cv, cv.w - 168, 44, 152, [
          { label: '动能', text: fmt(KE, 2) + ' J', frac: E > 1e-9 ? KE / E : 0, color: C.ink },
          { label: '弹性势能', text: fmt(PE, 2) + ' J', frac: E > 1e-9 ? PE / E : 0, color: C.data[2] },
          { label: '机械能', text: fmt(E, 2) + ' J', frac: 1, color: C.data[3] }
        ], '能量');
        if (lv >= 2) {
          label(cv, x, 0.15 + half, 'x = ' + fmt(x, 2) + ' m', {
            color: C.accent, size: 10.5, align: 'center', oy: -34
          });
        }
      },
      readouts: function (t) {
        const w = om(), Tp = TAU / w;
        const KE = 0.5 * P.m * Math.pow(P.A * w * sin(w * t), 2);
        const PE = 0.5 * P.k * Math.pow(P.A * cos(w * t), 2);
        const v = -P.A * w * sin(w * t);
        return [
          { label: '周期 T', value: fmt(Tp, 2), unit: 's' },
          { label: '频率 f', value: fmt(1 / Tp, 2), unit: 'Hz' },
          { label: '机械能 E', value: fmt(KE + PE, 2), unit: 'J' },
          { label: '位移 x', value: fmt(P.A * cos(w * t), 2), unit: 'm' },
          { label: '速度 v', value: fmt(v, 2), unit: 'm/s' }
        ];
      },
      hot: [[3, 4], [0, 1, 2], [0, 1, 2, 3, 4]],
      status: function (t) {
        const w = om();
        const v = -P.A * w * sin(w * t), a = -w * w * P.A * cos(w * t);
        let dir = abs(v) < 0.02 ? '到达端点' : (v > 0 ? '向右' : '向左');
        if (abs(v) >= 0.02) dir += v * a > 0 ? ' · 加速' : ' · 减速';
        return dir;
      }
    };
  }

  /* ================= 4. 匀速圆周 ================= */
  function sceneCircular() {
    const P = { r: 0.5, v0: 2, m: 1 };
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'r', label: '半径 r', min: 0.2, max: 1.2, step: 0.02, dec: 2 },
        { k: 'v0', label: '线速度 v', min: 0.5, max: 6, step: 0.1, dec: 1 },
        { k: 'm', label: '质量 m', min: 0.5, max: 3, step: 0.1, dec: 1 }
      ],
      hints: [
        '匀速圆周运动：速度沿切线，方向时刻改变。',
        '向心加速度 a = v²/r，始终指向圆心。',
        '绳张力提供向心力，T = mv²/r = mω²r。'
      ],
      duration: function () { return TAU * P.r / max(P.v0, 0.01); },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const r = P.r, w = P.v0 / r;
        const th = PI / 2 + w * t;
        const x = r * cos(th), y = r * sin(th);
        viewRect(cv, -r * 1.55, r * 1.55, -r * 1.55, r * 1.55, 0.02, true);
        gridOf(cv, r * 1.6, false);
        ringWorld(cv, 0, 0, r, C.data[3], 1.2, [5, 5]);
        dot(cv, 0, 0, 2.6, C.ink, null, 0);
        cv.line(0, 0, x, y, { color: C.gold, width: 2 });
        const vx = -sin(th), vy = cos(th);
        const nx = -x / r, ny = -y / r;
        if (lv >= 1) {
          vec(cv, x, y, vx * r * 0.52, vy * r * 0.52, C.accent, 2, 'v', { size: 10.5 });
          vec(cv, x, y, nx * r * 0.44, ny * r * 0.44, C.jade, 2, 'a', { size: 10.5 });
          if (lv >= 2) {
            vec(cv, x * 0.5, y * 0.5, nx * r * 0.3, ny * r * 0.3, C.gold, 2.4, 'T', { size: 10.5 });
          }
          dot(cv, 0, 0, 3.2, C.ink, C.paper, 1.2);
        }
        dot(cv, x, y, 8, C.ink, C.paper, 1.8);
        if (lv >= 2) {
          label(cv, r * 0.5, 0, 'r = ' + fmt(r, 2) + ' m', { color: C.gold, size: 10.5, align: 'center', oy: -10 });
          label(cv, 0, -r * 0.62, '周期 T = ' + fmt(TAU * r / P.v0, 2) + ' s', {
            color: C.ink2, size: 10.5, align: 'center', oy: 14
          });
        } else if (lv === 0) {
          label(cv, 0, -r * 1.2, 'r = ' + fmt(r, 2) + ' m   v = ' + fmt(P.v0, 1) + ' m/s',
            { color: C.soft, size: 10.5, align: 'center' });
        }
      },
      readouts: function () {
        const w = P.v0 / P.r;
        return [
          { label: '周期 T', value: fmt(TAU / w, 2), unit: 's' },
          { label: '线速度 v', value: fmt(P.v0, 2), unit: 'm/s' },
          { label: '向心加速度', value: fmt(P.v0 * P.v0 / P.r, 2), unit: 'm/s²' },
          { label: '绳张力 T', value: fmt(P.m * P.v0 * P.v0 / P.r, 1), unit: 'N' }
        ];
      },
      hot: [[1], [2], [0, 2, 3]],
      status: function (t) {
        const w = P.v0 / P.r;
        const d = ((w * t / TAU) % 1 + 1) % 1;
        return '匀速圆周 · 转过 ' + fmt(d * 360, 0) + '°';
      }
    };
  }

  /* ================= 5. 横波 ================= */
  function sceneWave() {
    const P = { v0: 2, f: 1, A: 0.35 };
    function lam() { return P.v0 / max(P.f, 0.01); }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'v0', label: '波速 v', min: 0.5, max: 4, step: 0.1, dec: 1 },
        { k: 'f', label: '频率 f', min: 0.2, max: 3, step: 0.1, dec: 1 },
        { k: 'A', label: '振幅 A', min: 0.1, max: 0.8, step: 0.01, dec: 2 }
      ],
      hints: [
        '横波：质点上下振动，波形向右传播，两者方向垂直。',
        '波长、波速、周期满足 λ = vT = v / f。',
        '相邻质点的振动状态相差一个波长，波形重复。'
      ],
      duration: function () { return max(1, 2 / max(P.f, 0.01)); },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const L = lam(), w = TAU * P.f, k = TAU / L;
        const halfH = max(0.55, P.A * 2.4);
        const halfW = halfH * (cv.w / max(1, cv.h));
        viewRect(cv, 0, halfW * 2, -halfH, halfH, 0.02, false);
        cv.grid(1, { grid: C.grid, axis: C.faint, labels: false });
        const xL = cv.xr[0], xR = cv.xr[1];
        const pts = [];
        const n = max(120, min(760, Math.round(cv.w)));
        for (let i = 0; i <= n; i++) {
          const x = xL + (xR - xL) * i / n;
          pts.push([x, P.A * sin(k * x - w * t)]);
        }
        polyline(cv, pts, C.ink2, 2);
        const count = 9;
        for (let i = 1; i <= count; i++) {
          const x = xL + (xR - xL) * i / (count + 1);
          const y = P.A * sin(k * x - w * t);
          dot(cv, x, y, 2.4, C.data[2], null, 0);
          cv.line(x, 0, x, y, { color: C.line2, width: 1 });
        }
        const xp = xL + (xR - xL) * 0.44;
        const yp = P.A * sin(k * xp - w * t);
        if (lv >= 1) {
          cv.line(xp, 0, xp, yp, { color: C.data[3], width: 1, dash: [3, 4] });
          vec(cv, xp, 0, 0, yp, C.accent, 2.2, 'y', { size: 10 });
          dot(cv, xp, yp, 5, C.ink, C.paper, 1.5);
        } else {
          dot(cv, xp, yp, 4, C.ink, C.paper, 1.2);
        }
        cv.arrow(xR - 1.5, halfH * 0.8, xR - 0.2, halfH * 0.8, { color: C.accent, width: 2, head: 8 });
        label(cv, xR - 0.85, halfH * 0.8, '传播方向', { color: C.accent, size: 10, align: 'center', oy: -10 });
        if (lv >= 2) {
          const lamShow = min(L, (xR - xL) * 0.72);
          dimLine(cv, [xL + 0.5, halfH * 0.62], [xL + 0.5 + lamShow, halfH * 0.62],
            'λ = ' + fmt(L, 2) + ' m', C.jade, 0, -13);
          dimLine(cv, [xR - 0.9, -P.A], [xR - 0.9, P.A], 'A', C.gold, 14, 0);
          label(cv, xp, yp, '质点', { color: C.ink, size: 10, ox: 10, oy: -8 });
        } else if (lv === 0) {
          label(cv, xL + 0.5, -halfH * 0.72, 'v = ' + fmt(P.v0, 1) + ' m/s   f = ' + fmt(P.f, 1) + ' Hz',
            { color: C.soft, size: 10.5 });
        }
      },
      readouts: function () {
        const L = lam(), Tp = 1 / max(P.f, 0.01);
        return [
          { label: '波长 λ', value: fmt(L, 2), unit: 'm' },
          { label: '周期 T', value: fmt(Tp, 2), unit: 's' },
          { label: '波速 v', value: fmt(P.v0, 2), unit: 'm/s' },
          { label: '频率 f', value: fmt(P.f, 2), unit: 'Hz' }
        ];
      },
      hot: [[0], [0, 1], [0, 1, 2]],
      status: function () { return '向右传播'; }
    };
  }

  /* ================= 6. 半圆玻璃砖折射 ================= */
  function sceneOptics() {
    const P = { angle: 30, n: 1.5 };
    const R = 1.2;
    function opt() {
      const th = rad(P.angle), s = sin(th);
      const crit = Math.asin(clamp(1 / P.n, -1, 1));
      const tir = s > 1 / P.n + 1e-9;
      const phi = tir ? 0 : Math.asin(clamp(P.n * s, -1, 1));
      return { th: th, s: s, crit: crit, tir: tir, phi: phi };
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'angle', label: '入射角 θ₁', min: 0, max: 80, step: 1, dec: 0 },
        { k: 'n', label: '折射率 n', min: 1.2, max: 2, step: 0.05, dec: 2 }
      ],
      hints: [
        '光线沿半径进入曲面，不发生偏折，直射到平直界面。',
        '斯涅尔定律：n₁sinθ₁ = n₂sinθ₂，此处 n₁ = n，n₂ = 1。',
        '入射角超过临界角 arcsin(1/n) 时发生全反射。'
      ],
      duration: function () { return 2.4; },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const o = opt();
        viewRect(cv, -R * 1.75, R * 1.75, -R * 1.45, R * 1.75, 0.02, true);
        cv.grid(R * 0.4, { grid: C.grid, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        ctx.save();
        ctx.beginPath();
        ctx.arc(cv.px(0), cv.py(0), R * cv.sx(), 0, PI);
        ctx.closePath();
        ctx.fillStyle = C.data[4];
        ctx.globalAlpha = 0.55;
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.strokeStyle = C.data[2];
        ctx.lineWidth = 1.6;
        ctx.stroke();
        ctx.restore();
        cv.line(0, 0, 0, -R, { color: C.data[2], width: 1.2, dash: [4, 4] });
        label(cv, 0, -R * 1.04, '玻璃 n = ' + fmt(P.n, 2), { color: C.data[2], size: 10, align: 'center', oy: 10 });
        const Px = -R * o.s, Py = -R * cos(o.th);
        cv.arrow(Px, Py, 0, 0, { color: C.accent, width: 2, head: 8 });
        label(cv, Px, Py, '入射光线', { color: C.accent, size: 10, align: 'right', ox: -8, oy: -8 });
        cv.line(0, -R * 1.25, 0, R * 1.35, { color: C.faint, width: 1, dash: [4, 5] });
        label(cv, 0, R * 1.3, '法线', { color: C.faint, size: 9.5, align: 'center', oy: -10, weight: 500 });
        const Lout = R * 1.2;
        if (!o.tir) {
          const ex = Lout * sin(o.phi), ey = Lout * cos(o.phi);
          cv.arrow(0, 0, ex, ey, { color: C.jade, width: 2, head: 8 });
          label(cv, ex, ey, '折射光线', { color: C.jade, size: 10, ox: 8, oy: -8 });
          angleArc(cv, 0, 0, R * 0.3, PI / 2 - o.phi, PI / 2, C.jade, 'θ₂');
        } else {
          const qx = R * o.s, qy = -R * cos(o.th);
          cv.arrow(0, 0, qx, qy, { color: C.gold, width: 2, head: 8, dash: [5, 4] });
          cv.arrow(qx, qy, qx + 0.52 * R * o.s, qy - 0.52 * R * cos(o.th), { color: C.gold, width: 2, head: 8 });
          label(cv, qx, qy, '全反射', { color: C.gold, size: 10.5, ox: 8, oy: 14, weight: 700 });
        }
        const qx2 = R * sin(o.crit), qy2 = -R * cos(o.crit);
        cv.line(0, 0, qx2 * 1.65, qy2 * 1.65, { color: C.data[2], width: 1, dash: [2, 5] });
        label(cv, qx2 * 1.55, qy2 * 1.55, '临界角 ' + fmt(o.crit * 180 / PI, 1) + '°',
          { color: C.data[2], size: 9.5, ox: 6, oy: 7, weight: 500 });
        angleArc(cv, 0, 0, R * 0.42, -PI / 2 - o.th, -PI / 2, C.accent, 'θ₁');
        if (o.tir) {
          angleArc(cv, 0, 0, R * 0.3, -PI / 2, o.th - PI / 2, C.gold, 'θᵣ');
          label(cv, R * 0.45, R * 0.6, '无折射光线', { color: C.faint, size: 9.5, align: 'center' });
        }
        const L1 = R, L2 = o.tir ? R * 1.6 : Lout;
        const p = ((t / 2.4) % 1 + 1) % 1;
        const sNow = p * (L1 + L2);
        let bx, by;
        if (sNow <= L1) {
          bx = Px + (0 - Px) * (sNow / L1);
          by = Py + (0 - Py) * (sNow / L1);
        } else {
          const d2 = sNow - L1;
          if (o.tir) { bx = d2 * o.s; by = -d2 * cos(o.th); }
          else { bx = d2 * sin(o.phi); by = d2 * cos(o.phi); }
        }
        ctx.save();
        ctx.globalAlpha = 0.22;
        dot(cv, bx, by, 9, C.accent, null, 0);
        ctx.globalAlpha = 1;
        dot(cv, bx, by, 3.6, C.accent, C.paper, 1.2);
        ctx.restore();
        if (lv >= 1) {
          tagBox(cv, cv.w * 0.5, 18, o.tir ? 'θ₁ > C → 全反射' : 'n sinθ₁ = sinθ₂', C.ink2, 'center');
        }
        if (lv >= 2) {
          label(cv, R * 1.28, R * 0.98,
            o.tir ? '全反射条件' : '斯涅尔定律',
            { color: C.soft, size: 9.5, align: 'center' });
          label(cv, R * 1.28, R * 0.86,
            o.tir ? 'sinθ₁ > 1/n' : 'n sinθ₁ = sinθ₂',
            { color: C.ink2, size: 10, align: 'center' });
          label(cv, R * 1.28, R * 0.73,
            o.tir ? 'θ₁ = ' + fmt(P.angle, 0) + '° > C' : 'θ₂ = ' + fmt(o.phi * 180 / PI, 1) + '°',
            { color: o.tir ? C.accent : C.jade, size: 10.5, align: 'center' });
        }
      },
      readouts: function () {
        const o = opt();
        return [
          { label: '入射角 θ₁', value: fmt(P.angle, 0), unit: '°' },
          { label: '折射角 θ₂', value: o.tir ? '全反射' : fmt(o.phi * 180 / PI, 1), unit: o.tir ? '' : '°' },
          { label: '临界角 C', value: fmt(o.crit * 180 / PI, 1), unit: '°' },
          { label: '折射率 n', value: fmt(P.n, 2), unit: '' }
        ];
      },
      hot: [[0], [0, 1], [1, 2]],
      status: function () {
        const o = opt();
        return o.tir ? '发生全反射' : '折射进入空气';
      }
    };
  }

  /* ================= 7. 串并联电路 ================= */
  function sceneCircuit() {
    const P = { E: 6, r: 0.5, R1: 4, R2: 6 };
    let mode = 0;
    function calc(t) {
      const R3 = 2 + 8 * (0.5 - 0.5 * cos(TAU * t / 8));
      let Rtot, I, U, P1, I1 = 0, I2 = 0;
      if (mode === 0) {
        Rtot = P.R1 + P.R2 + R3 + P.r;
        I = P.E / Rtot;
        U = P.E - I * P.r;
        P1 = I * I * P.R1;
        I1 = I; I2 = I;
      } else {
        const Rp = P.R1 * P.R2 / (P.R1 + P.R2);
        Rtot = Rp + R3 + P.r;
        I = P.E / Rtot;
        U = P.E - I * P.r;
        const Up = I * Rp;
        I1 = Up / P.R1;
        I2 = Up / P.R2;
        P1 = I1 * I1 * P.R1;
      }
      return { R3: R3, Rtot: Rtot, I: I, U: U, P1: P1, I1: I1, I2: I2 };
    }
    function current(t) { return calc(t); }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'E', label: '电动势 E', min: 1.5, max: 12, step: 0.5, dec: 1 },
        { k: 'r', label: '内阻 r', min: 0.1, max: 2, step: 0.1, dec: 1 },
        { k: 'R1', label: '电阻 R₁', min: 1, max: 20, step: 0.5, dec: 1 },
        { k: 'R2', label: '电阻 R₂', min: 1, max: 20, step: 0.5, dec: 1 }
      ],
      chips: [{
        label: '连接方式',
        items: ['串联', '并联'],
        index: 0,
        set: function (i) { mode = i; }
      }],
      hints: [
        '闭合电路欧姆定律：I = E / (R外 + r)。',
        '路端电压 U = E − Ir，外电阻越大，U 越接近 E。',
        '滑动变阻器改变外电阻，电流、电压与功率随之改变。'
      ],
      aux: function (src) {
        const emf = Number(src.Emf != null ? src.Emf : src.emf);
        if (isFinite(emf) && !isFinite(Number(src.E))) P.E = emf;
      },
      duration: function () { return 8; },
      draw: function (cv, t, lv) {
        if (cv.w < 60) return;
        cv.clear(C.paper);
        const ctx = cv.ctx, w = cv.w, h = cv.h;
        ctx.save();
        ctx.strokeStyle = C.grid2;
        ctx.lineWidth = 1;
        for (let x = 20; x < w; x += 40) {
          ctx.beginPath(); ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, h); ctx.stroke();
        }
        for (let y = 20; y < h; y += 40) {
          ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(w, y + 0.5); ctx.stroke();
        }
        ctx.restore();
        const c = current(t);
        const xL = w * 0.16, xR = w * 0.85, yT = h * 0.24, yB = h * 0.8;
        const yMid = (yT + yB) / 2;
        function wire(x1, y1, x2, y2) {
          ctx.save();
          ctx.strokeStyle = C.ink2;
          ctx.lineWidth = 1.8;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
          ctx.restore();
        }
        function flow(x1, y1, x2, y2, amp) {
          if (amp < 1e-9) return;
          const len = Math.hypot(x2 - x1, y2 - y1);
          if (len < 4) return;
          /* 电流读数可能只有 mA 级：按“本电路最大电流”归一，保证仍看得见在流 */
          const rBase = mode === 0 ? P.R1 + P.R2 + P.r : P.R1 * P.R2 / max(P.R1 + P.R2, 1e-6) + P.r;
          const iMax = P.E / max(rBase + 2, 1e-6);
          const n = clamp((amp / iMax) * 1.05, 0.3, 1.2);
          const speed = 12 + 42 * n;
          const spacing = 36 - 12 * n;
          const dashPhase = (t * speed) % 16;
          ctx.save();
          ctx.strokeStyle = C.accent;
          ctx.lineWidth = 2;
          ctx.setLineDash([5, 11]);
          ctx.lineDashOffset = -dashPhase;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
          ctx.setLineDash([]);
          const ux = (x2 - x1) / len, uy = (y2 - y1) / len;
          const off = (t * speed) % spacing;
          for (let s = off; s < len; s += spacing) {
            ctx.beginPath();
            ctx.arc(x1 + ux * s, y1 + uy * s, 2.5, 0, TAU);
            ctx.fillStyle = C.accent; ctx.fill();
          }
          const ang = Math.atan2(y2 - y1, x2 - x1);
          const mx = x1 + (x2 - x1) * 0.56, my = y1 + (y2 - y1) * 0.56;
          ctx.beginPath();
          ctx.moveTo(mx, my);
          ctx.lineTo(mx - 8 * cos(ang - 0.4), my - 8 * sin(ang - 0.4));
          ctx.lineTo(mx - 8 * cos(ang + 0.4), my - 8 * sin(ang + 0.4));
          ctx.closePath();
          ctx.fillStyle = C.accent;
          ctx.fill();
          ctx.restore();
        }
        function resBox(cx, cy, text) {
          const bw = 52, bh = 16;
          ctx.save();
          ctx.fillStyle = C.card;
          ctx.fillRect(cx - bw / 2, cy - bh / 2, bw, bh);
          ctx.strokeStyle = C.ink;
          ctx.lineWidth = 1.6;
          ctx.strokeRect(cx - bw / 2 + 0.5, cy - bh / 2 + 0.5, bw, bh);
          ctx.fillStyle = C.ink;
          ctx.font = '600 11px ' + C.sans;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(text, cx, cy + 1);
          ctx.restore();
        }
        wire(xL, yB, xL, yMid + 8);
        wire(xL, yMid - 8, xL, yT);
        wire(xL, yT, xR, yT);
        wire(xR, yT, xR, yB);
        wire(xL, yB, xR, yB);
        ctx.save();
        ctx.strokeStyle = C.ink;
        ctx.lineWidth = 2.4;
        ctx.beginPath(); ctx.moveTo(xL - 14, yMid - 8); ctx.lineTo(xL + 14, yMid - 8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(xL - 7, yMid + 8); ctx.lineTo(xL + 7, yMid + 8); ctx.stroke();
        ctx.restore();
        ctx.save();
        ctx.fillStyle = C.accent;
        ctx.font = '600 12px ' + C.sans;
        ctx.textAlign = 'right';
        ctx.fillText('+', xL - 20, yMid - 4);
        ctx.fillText('−', xL - 20, yMid + 14);
        ctx.restore();
        const r1x = w * 0.37, r2x = w * 0.63;
        if (mode === 0) {
          wire(xL, yT, r1x - 26, yT);
          resBox(r1x, yT, 'R₁');
          wire(r1x + 26, yT, r2x - 26, yT);
          resBox(r2x, yT, 'R₂');
          wire(r2x + 26, yT, xR, yT);
          flow(xL, yT, r1x - 26, yT, c.I);
          flow(r1x + 26, yT, r2x - 26, yT, c.I);
          flow(r2x + 26, yT, xR, yT, c.I);
          flow(xR, yT, xR, yB, c.I);
          flow(xR, yB, xL, yB, c.I);
          flow(xL, yB, xL, yMid + 8, c.I);
          flow(xL, yMid - 8, xL, yT, c.I);
        } else {
          const xa = w * 0.33, xb = w * 0.71, y2 = yT + h * 0.16, xm = (xa + xb) / 2;
          wire(xL, yT, xa, yT);
          wire(xa, yT, xa, y2);
          wire(xa, yT, xm - 26, yT);
          resBox(xm, yT, 'R₁');
          wire(xm + 26, yT, xb, yT);
          wire(xa, y2, xm - 26, y2);
          resBox(xm, y2, 'R₂');
          wire(xm + 26, y2, xb, y2);
          wire(xb, yT, xb, y2);
          wire(xb, yT, xR, yT);
          flow(xL, yT, xa, yT, c.I);
          flow(xa, yT, xm - 26, yT, c.I1);
          flow(xm + 26, yT, xb, yT, c.I1);
          flow(xa, y2, xm - 26, y2, c.I2);
          flow(xm + 26, y2, xb, y2, c.I2);
          flow(xb, yT, xR, yT, c.I);
          flow(xR, yT, xR, yB, c.I);
          flow(xR, yB, xL, yB, c.I);
          flow(xL, yB, xL, yMid + 8, c.I);
          flow(xL, yMid - 8, xL, yT, c.I);
            ctx.save();
          ctx.font = '600 10px ' + C.mono;
          ctx.fillStyle = C.accent;
          ctx.textAlign = 'center';
          ctx.fillText('I₁=' + fmt(c.I1, 2) + 'A', xm, yT - 18);
          ctx.fillText('I₂=' + fmt(c.I2, 2) + 'A', xm, y2 - 16);
          ctx.restore();
        }
        const boxCx = w * 0.52;
        wire(xL, yB, boxCx - 34, yB);
        wire(boxCx + 34, yB, xR, yB);
        resBox(boxCx, yB, 'R₃');
        const f = clamp((c.R3 - 2) / 8, 0, 1);
        const wx = boxCx - 26 + 52 * f;
        ctx.save();
        ctx.strokeStyle = C.accent;
        ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(wx, yB - 26); ctx.lineTo(wx, yB - 9); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(wx, yB - 8);
        ctx.lineTo(wx - 5, yB - 18);
        ctx.lineTo(wx + 5, yB - 18);
        ctx.closePath();
        ctx.fillStyle = C.accent;
        ctx.fill();
        ctx.restore();
        ctx.save();
        ctx.font = '600 11px ' + C.sans;
        ctx.fillStyle = C.ink;
        ctx.textAlign = 'center';
        ctx.fillText('滑动变阻器 R₃ = ' + fmt(c.R3, 1) + ' Ω', boxCx, yB + 28);
        ctx.fillStyle = C.accent;
        ctx.textAlign = 'left';
        ctx.font = '600 11.5px ' + C.mono;
        ctx.fillText('I = ' + fmt(c.I, 3) + ' A', xR * 0.55, yB - 82);
        ctx.fillStyle = C.jade;
        ctx.fillText('U = ' + fmt(c.U, 2) + ' V', xR * 0.55, yB - 64);
        ctx.restore();
        /* 电流表：指针随电流摆动，作为“读数在变”的第二重视觉 */
        const rBase = mode === 0 ? P.R1 + P.R2 + P.r : P.R1 * P.R2 / max(P.R1 + P.R2, 1e-6) + P.r;
        const iMin = P.E / max(rBase + 10, 1e-6);
        const iMax = P.E / max(rBase + 2, 1e-6);
        const iNorm = clamp((c.I - iMin) / max(iMax - iMin, 1e-9), 0, 1);
        const mA = w * 0.23, mY = yB, mR = 17;
        ctx.save();
        ctx.beginPath(); ctx.arc(mA, mY, mR, 0, TAU);
        ctx.fillStyle = C.card; ctx.fill();
        ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.beginPath(); ctx.arc(mA, mY, mR - 5, -PI / 2 - 0.55, -PI / 2 + 0.55);
        ctx.strokeStyle = C.faint; ctx.lineWidth = 1; ctx.stroke();
        const nAng = -PI / 2 + iNorm * 0.85 - 0.18;
        ctx.beginPath(); ctx.moveTo(mA, mY); ctx.lineTo(mA + cos(nAng) * (mR - 7), mY + sin(nAng) * (mR - 7));
        ctx.strokeStyle = C.accent; ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.arc(mA, mY, 2, 0, TAU); ctx.fillStyle = C.ink; ctx.fill();
        ctx.restore();
        plabel(cv, mA, mY + mR + 11, 'A  ' + fmt(c.I, 3) + ' A', { color: C.ink2, size: 9.5, align: 'center', weight: 600 });
        if (lv >= 1) {
          plabel(cv, xL + 4, yT - 14, 'E = ' + fmt(P.E, 1) + ' V   r = ' + fmt(P.r, 1) + ' Ω',
            { color: C.soft, size: 10 });
          plabel(cv, xR - 4, yT - 14, 'R₁ = ' + fmt(P.R1, 1) + ' Ω   R₂ = ' + fmt(P.R2, 1) + ' Ω',
            { color: C.soft, size: 10, align: 'right' });
        }
        if (lv >= 2) {
          plabel(cv, w * 0.5, h * 0.07, 'P₁ = ' + fmt(c.P1, 2) + ' W   P总 = ' + fmt(P.E * c.I, 2) + ' W',
            { color: C.ink2, size: 10.5, align: 'center' });
        }
      },
      readouts: function (t) {
        const c = calc(t);
        return [
          { label: '总电阻', value: fmt(c.Rtot, 2), unit: 'Ω' },
          { label: '干路电流', value: fmt(c.I, 3), unit: 'A' },
          { label: '路端电压', value: fmt(c.U, 2), unit: 'V' },
          { label: 'R₁ 功率', value: fmt(c.P1, 4), unit: 'W' }
        ];
      },
      hot: [[1], [1, 2], [0, 2, 3]],
      status: function (t) {
        const d = sin(TAU * t / 8);
        if (d > 0.05) return '滑片右移 · R₃ 增大';
        if (d < -0.05) return '滑片左移 · R₃ 减小';
        return '滑片到达端点';
      }
    };
  }

  /* ================= 8. 平行板电场偏转 ================= */
  function sceneEfield() {
    const P = { E: 6, q: 1, m: 2, v0: 3 };
    const LP = 1.0, D = 0.5;
    let sign = 1;
    function flight() {
      const a = sign * P.q * P.E / max(P.m, 1e-6);
      const t1 = LP / max(P.v0, 0.01);
      const y1 = 0.5 * a * t1 * t1;
      const hit = abs(y1) >= D / 2;
      const tHit = abs(a) > 1e-9 ? sqrt(D / abs(a)) : Infinity;
      const T = hit ? min(t1, tHit) : t1;
      return { a: a, t1: t1, y1: y1, hit: hit, T: T, tHit: tHit, vy1: a * t1 };
    }
    return {
      P: P,
      oneShot: true,
      sliders: [
        { k: 'E', label: '电场强度 E', min: 0, max: 30, step: 1, dec: 0 },
        { k: 'q', label: '电荷量 q (µC)', min: 0.5, max: 3, step: 0.1, dec: 2 },
        { k: 'm', label: '质量 m', min: 0.5, max: 3, step: 0.1, dec: 1 },
        { k: 'v0', label: '入射速度 v₀', min: 1.5, max: 5, step: 0.1, dec: 1 }
      ],
      chips: [{
        label: '电荷种类',
        items: ['正电荷', '负电荷'],
        index: 0,
        set: function (i) { sign = i ? -1 : 1; }
      }],
      hints: [
        '粒子以水平初速度进入匀强电场，水平方向匀速。',
        '竖直方向受电场力 qE，加速度 a = qE/m，做类平抛。',
        '由板长求板内时间，再求偏转量与出射偏角。'
      ],
      aux: function (src) {
        const q = Number(src.q);
        if (isFinite(q) && q > 0 && q < 1e-3) P.q = q * 1e6; // 以库仑给出时换算成 µC
      },
      duration: function () {
        const f = flight();
        return f.T + (f.hit ? 0.42 : 0.22);
      },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const f = flight();
        const tNow = clamp(t, 0, f.T + 0.42);
        /* 偏转极小时纵向放大显示，保证“有可见弯曲” */
        const mag = (!f.hit && abs(f.y1) > 1e-12 && abs(f.y1) < 0.14)
          ? min(900, 0.16 / abs(f.y1)) : 1;
        function yd(v) { return v * mag; }
        viewRect(cv, -0.42, LP + 0.62, -D * 0.78, D * 0.78, 0.02, false);
        cv.grid(0.2, { grid: C.grid, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        ctx.save();
        ctx.strokeStyle = C.ink2;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(cv.px(-0.06), cv.py(D / 2));
        ctx.lineTo(cv.px(LP + 0.06), cv.py(D / 2));
        ctx.moveTo(cv.px(-0.06), cv.py(-D / 2));
        ctx.lineTo(cv.px(LP + 0.06), cv.py(-D / 2));
        ctx.stroke();
        ctx.restore();
        for (let i = 0; i < 4; i++) {
          const x = 0.1 + i * (LP - 0.2) / 3;
          label(cv, x, D / 2, '+', { color: C.accent, size: 12, align: 'center', oy: -11, halo: false, weight: 700 });
          label(cv, x, -D / 2, '−', { color: C.jade, size: 12, align: 'center', oy: 11, halo: false, weight: 700 });
          cv.arrow(x, D / 2 - 0.035, x, -D / 2 + 0.035, { color: C.data[3], width: 1, head: 6, dash: [3, 5] });
        }
        label(cv, LP + 0.09, 0, 'E', { color: C.data[2], size: 11, weight: 700 });
        /* 完整理论轨迹（浅） */
        const fullPts = [], nFull = 48;
        const tEnd = f.hit ? f.tHit : f.t1;
        for (let i = 0; i <= nFull; i++) {
          const s = tEnd * i / nFull;
          fullPts.push([P.v0 * s, yd(0.5 * f.a * s * s)]);
        }
        polyline(cv, fullPts, C.data[3], 1.1, [4, 4], 0.85);
        /* 已走过的轨迹 */
        const tTrail = min(tNow, tEnd);
        const path = [], n = 40;
        for (let i = 0; i <= n; i++) {
          const s = tTrail * i / n;
          path.push([P.v0 * s, yd(0.5 * f.a * s * s)]);
        }
        polyline(cv, path, C.ink2, 1.9);
        /* 出射后的直线段 */
        if (!f.hit && tNow > f.t1) {
          const te = min(tNow - f.t1, 0.24);
          const yE = yd(f.y1), vyS = yd(f.a * f.t1);
          const xe = LP + P.v0 * te, ye = yE + vyS * te;
          cv.line(LP, yE, xe, ye, { color: C.ink2, width: 1.9 });
          dot(cv, xe, ye, 4.6, C.ink, C.paper, 1.5);
          label(cv, xe, ye, '出射', { color: C.jade, size: 9.5, ox: 7, oy: -8 });
        }
        cv.arrow(-0.38, 0, -0.06, 0, { color: C.data[2], width: 1.4, head: 7, dash: [4, 4] });
        label(cv, -0.2, 0, 'v₀', { color: C.data[2], size: 10, align: 'center', oy: -10 });
        /* 粒子当前位置 */
        let xe, ye, vvy;
        if (f.hit && tNow >= f.tHit) {
          xe = P.v0 * f.tHit;
          ye = sign * D / 2;
          vvy = f.a * f.tHit;
          const k = clamp((tNow - f.tHit) / 0.42, 0, 1);
          for (let r = 0; r < 3; r++) {
            const rr = 8 + 34 * ((k + r / 3) % 1);
            ctx.save();
            ctx.beginPath(); ctx.arc(cv.px(xe), cv.py(ye), rr, 0, TAU);
            ctx.strokeStyle = C.accent;
            ctx.globalAlpha = 0.55 * (1 - ((k + r / 3) % 1));
            ctx.lineWidth = 1.4; ctx.stroke();
            ctx.restore();
          }
        } else if (tNow <= f.t1) {
          xe = P.v0 * tNow;
          ye = 0.5 * f.a * tNow * tNow;
          vvy = f.a * tNow;
        } else {
          const te = tNow - f.t1;
          xe = P.v0 * tNow;
          ye = f.y1 + f.vy1 * te;
          vvy = f.vy1;
        }
        dot(cv, xe, yd(ye), 5.2, C.ink, C.paper, 1.6);
        if (mag > 1.1) {
          plabel(cv, 14, cv.h - 16, '纵向位移放大 ×' + fmt(mag, 0) + '（便于观察）',
            { color: C.faint, size: 9.5, weight: 500 });
        }
        if (lv >= 1) {
          /* 速度向量改成固定像素长度，撞板时不会被拉成穿过极板的长线 */
          const vtot = sqrt(P.v0 * P.v0 + vvy * vvy) || 1;
          const PX2 = cv.px(xe), PY2 = cv.py(yd(ye));
          const L2 = 30;
          const ux = P.v0 / vtot * L2, uy = vvy / vtot * L2;
          pArrow(ctx, PX2, PY2, PX2 + ux, PY2, C.jade, 1.5, 6);
          pArrow(ctx, PX2, PY2, PX2, PY2 - uy, C.accent, 1.5, 6);
          pArrow(ctx, PX2, PY2, PX2 + ux, PY2 - uy, C.gold, 1.6, 6);
          plabel(cv, PX2 + ux + 4, PY2 - uy - 8, 'v', { color: C.gold, size: 10, weight: 700 });
          label(cv, 0.08, D * 0.70, 'a = ' + fmt(abs(f.a), 1) + ' m/s²', {
            color: C.accent, size: 10.5, ox: 6
          });
          label(cv, 0.08, D * 0.58, 't = ' + fmt(tNow, 2) + ' s', { color: C.soft, size: 9.5, ox: 6 });
        }
        if (lv >= 2) {
          const yShow = f.hit ? sign * D / 2 : f.y1;
          dimLine(cv, [LP, 0], [LP, yd(yShow)], 'y = ' + fmt(abs(yShow) * 1000, 1) + ' mm', C.accent, -12, 0);
          if (!f.hit) {
            label(cv, LP + 0.12, yd(yShow) + 0.05,
              'θ = ' + fmt(Math.atan(abs(f.a) * f.t1 / P.v0) * 180 / PI, 1) + '°',
              { color: C.jade, size: 10.5, align: 'left', oy: -6 });
          } else {
            label(cv, LP * 0.55, sign * D * 0.34, '粒子打在极板上', { color: C.accent, size: 10.5 });
          }
        } else if (lv === 0) {
          label(cv, 0.1, D * 0.66, 'E = ' + fmt(P.E, 0) + '   q = ' + fmt(P.q, 2) + ' µC   m = ' + fmt(P.m, 1),
            { color: C.soft, size: 10 });
        }
      },
      readouts: function (t) {
        const f = flight();
        const tStop = f.hit ? min(t, f.tHit) : min(t, f.t1);
        const y = 0.5 * f.a * tStop * tStop;
        const vy = f.a * tStop;
        return [
          { label: '加速度 a', value: fmt(abs(f.a), 2), unit: 'm/s²' },
          { label: '偏转量 y', value: fmt(abs(y) * 1000, 2), unit: 'mm' },
          { label: '出射速度', value: fmt(f.hit ? sqrt(P.v0 * P.v0 + Math.pow(f.a * f.tHit, 2)) : sqrt(P.v0 * P.v0 + f.vy1 * f.vy1), 2), unit: 'm/s' },
          { label: '偏转角 θ', value: fmt(Math.atan(abs(f.a) * min(tStop, f.t1) / P.v0) * 180 / PI, 1), unit: '°' }
        ];
      },
      hot: [[1], [0], [1, 2, 3]],
      status: function (t) {
        const f = flight();
        if (f.hit && t >= f.tHit) return '粒子撞板 · 偏转结束';
        if (t >= f.t1) return '射出极板 · 匀速直线';
        return '板间偏转 · 类平抛';
      }
    };
  }

  /* ================= 9. 一维碰撞 ================= */
  function sceneCollision() {
    const P = { m1: 2, m2: 1, v1: 4, v2: -1 };
    const X1 = -2.2, X2 = 2.2;
    const E_LIST = [1, 0.6, 0];
    let ei = 0;
    function ev() {
      const e = E_LIST[ei];
      const m1 = P.m1, m2 = P.m2, v1 = P.v1, v2 = P.v2;
      const r1 = 0.16 + 0.05 * m1, r2 = 0.16 + 0.05 * m2;
      const tc = v1 > v2 ? (X2 - r2 - (X1 + r1)) / (v1 - v2) : Infinity;
      const v1p = ((m1 - e * m2) * v1 + (1 + e) * m2 * v2) / (m1 + m2);
      const v2p = ((m2 - e * m1) * v2 + (1 + e) * m1 * v1) / (m1 + m2);
      const p = m1 * v1 + m2 * v2;
      const E0 = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2;
      const E1 = 0.5 * m1 * v1p * v1p + 0.5 * m2 * v2p * v2p;
      return {
        e: e, r1: r1, r2: r2, tc: tc, v1p: v1p, v2p: v2p,
        p: p, E0: E0, E1: E1, dE: max(0, E0 - E1)
      };
    }
    function pos(t) {
      const g = ev();
      const tc = g.tc;
      if (!isFinite(tc) || t <= tc) {
        return { x1: X1 + P.v1 * min(t, isFinite(tc) ? tc : t), x2: X2 + P.v2 * min(t, isFinite(tc) ? tc : t), hit: false };
      }
      const x1c = X1 + P.v1 * tc, x2c = X2 + P.v2 * tc;
      return {
        x1: x1c + g.v1p * (t - tc),
        x2: x2c + g.v2p * (t - tc),
        hit: true
      };
    }
    return {
      P: P,
      oneShot: true,
      sliders: [
        { k: 'm1', label: '质量 m₁', min: 0.5, max: 5, step: 0.1, dec: 1 },
        { k: 'm2', label: '质量 m₂', min: 0.5, max: 5, step: 0.1, dec: 1 },
        { k: 'v1', label: '初速 v₁', min: -6, max: 10, step: 0.5, dec: 1 },
        { k: 'v2', label: '初速 v₂', min: -6, max: 10, step: 0.5, dec: 1 }
      ],
      chips: [{
        label: '碰撞类型',
        items: ['弹性', '非弹性', '完全非弹性'],
        index: 0,
        set: function (i) { ei = i; }
      }],
      hints: [
        '先明确系统：两球组成的系统在水平方向不受外力。',
        '动量守恒 m₁v₁ + m₂v₂ = m₁v₁′ + m₂v₂′。',
        '弹性碰撞动能也守恒；完全非弹性碰撞两球共速。'
      ],
      duration: function () {
        const g = ev();
        return isFinite(g.tc) ? min(4, g.tc + 1.1) : 2.4;
      },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const g = ev();
        const p = pos(t);
        viewRect(cv, -3.2, 3.2, -0.3, 1.25, 0.02, false);
        cv.grid(0.5, { grid: C.grid, axis: C.faint, labels: false });
        cv.line(cv.xr[0], 0, cv.xr[1], 0, { color: C.line, width: 2.5 });
        const y1 = g.r1, y2 = g.r2;
        const ctx = cv.ctx;
        ctx.save();
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = C.line;
        ctx.beginPath();
        ctx.ellipse(cv.px(p.x1), cv.py(0), 14, 3, 0, 0, TAU);
        ctx.ellipse(cv.px(p.x2), cv.py(0), 14, 3, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
        const col1 = C.ink, col2 = C.ink2;
        ctx.save();
        ctx.beginPath();
        ctx.arc(cv.px(p.x1), cv.py(y1), max(6, g.r1 * cv.sx()), 0, TAU);
        ctx.fillStyle = col1;
        ctx.fill();
        ctx.strokeStyle = C.paper;
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(cv.px(p.x2), cv.py(y2), max(6, g.r2 * cv.sx()), 0, TAU);
        ctx.fillStyle = col2;
        ctx.fill();
        ctx.stroke();
        ctx.restore();
        label(cv, p.x1, y1, 'm₁', { color: onColor(col1), size: 9.5, align: 'center', halo: false });
        label(cv, p.x2, y2, 'm₂', { color: onColor(col2), size: 9.5, align: 'center', halo: false });
        if (lv >= 1) {
          const v1 = t <= g.tc ? P.v1 : g.v1p;
          const v2 = t <= g.tc ? P.v2 : g.v2p;
          const sc = 0.34 / max(1, max(abs(P.v1), abs(P.v2), abs(g.v1p), abs(g.v2p)));
          vec(cv, p.x1, y1, v1 * sc, 0, C.accent, 2, 'v₁', { size: 10 });
          vec(cv, p.x2, y2, v2 * sc, 0, C.accent, 2, 'v₂', { size: 10 });
          if (abs(t - g.tc) < 0.05) {
            ringWorld(cv, (p.x1 + p.x2) / 2, 0.35, 0.22, C.accent, 1.4, [3, 3]);
          }
        }
        const curE = t <= g.tc ? g.E0 : g.E1;
        barsPanel(cv, 14, 48, 158, [
          { label: '动量 p', text: fmt(g.p, 1) + ' kg·m/s', frac: 1, color: C.ink },
          { label: '动能 E', text: fmt(curE, 2) + ' J', frac: g.E0 > 1e-9 ? curE / g.E0 : 0, color: C.gold }
        ], '守恒量');
        ctx.save();
        ctx.font = '10px ' + C.sans;
        ctx.fillStyle = C.faint;
        ctx.textAlign = 'left';
        ctx.fillText('碰前动能 ' + fmt(g.E0, 2) + ' J', 14, 118);
        ctx.restore();
        if (lv >= 2) {
          label(cv, 0, 1.05, 'v₁′ = ' + fmt(g.v1p, 2) + ' m/s   v₂′ = ' + fmt(g.v2p, 2) + ' m/s',
            { color: C.ink, size: 10.5, align: 'center' });
          label(cv, 0, 0.9, 'ΔE = ' + fmt(g.dE, 2) + ' J', { color: C.accent, size: 10.5, align: 'center' });
        } else if (lv === 0) {
          label(cv, 0, 1.05, 'm₁ = ' + fmt(P.m1, 1) + ' kg   m₂ = ' + fmt(P.m2, 1) + ' kg',
            { color: C.soft, size: 10.5, align: 'center' });
        }
      },
      readouts: function () {
        const g = ev();
        return [
          { label: '碰后 v₁′', value: fmt(g.v1p, 2), unit: 'm/s' },
          { label: '碰后 v₂′', value: fmt(g.v2p, 2), unit: 'm/s' },
          { label: '总动量 p', value: fmt(g.p, 2), unit: 'kg·m/s' },
          { label: '动能损失', value: fmt(g.dE, 2), unit: 'J' }
        ];
      },
      hot: [[1], [2], [0, 1, 3]],
      status: function (t) {
        const g = ev();
        if (!isFinite(g.tc)) return '两球未相碰';
        if (t < g.tc - 0.03) return '接近中';
        if (abs(t - g.tc) <= 0.03) return '碰撞瞬间';
        return g.e === 0 ? '碰后共速' : '碰后分离';
      }
    };
  }

  /* ================= 10. 卫星圆轨道 ================= */
  function sceneGravity() {
    const P = { r: 12 };
    const GM = 3.986e14, RE = 6.371e6;
    function data() {
      const r = P.r * 1e6;
      const v = sqrt(GM / r);
      return { r: r, v: v, T: TAU * r / v, a: GM / (r * r) };
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'r', label: '轨道半径 r /10⁶m', min: 6.8, max: 42, step: 0.2, dec: 1 }
      ],
      hints: [
        '卫星做匀速圆周运动，万有引力提供向心力。',
        '由 GMm/r² = mv²/r 得 v = √(GM/r)。',
        '周期 T = 2πr/v，轨道越高，线速度越小、周期越长。'
      ],
      aux: function (src) {
        const r = Number(src.r);
        if (isFinite(r) && r > 1e4) P.r = r / 1e6; // 以米给出时换算成 10⁶ m
      },
      duration: function () { return 8; },
      draw: function (cv, t, lv) {
        if (cv.w < 30) return;
        cv.clear(C.paper);
        const d = data();
        const r = d.r;
        viewRect(cv, -r * 1.2, r * 1.2, -r * 1.2, r * 1.2, 0.02, true);
        cv.grid(niceStep(r * 2.4), { grid: C.grid, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        ctx.save();
        ctx.beginPath();
        ctx.arc(cv.px(0), cv.py(0), RE * cv.sx(), 0, TAU);
        ctx.fillStyle = C.data[3];
        ctx.fill();
        ctx.strokeStyle = C.data[2];
        ctx.lineWidth = 1.4;
        ctx.stroke();
        ctx.restore();
        label(cv, 0, 0, '地球', { color: C.ink2, size: 10, align: 'center', halo: false, weight: 700 });
        ringWorld(cv, 0, 0, r, C.data[2], 1.2, [5, 5]);
        const th = -PI / 2 + TAU * t / 8;
        const x = r * cos(th), y = r * sin(th);
        for (let k = 36; k >= 1; k--) {
          const tp = th - k * 0.048;
          const X = cv.px(r * cos(tp)), Y = cv.py(r * sin(tp));
          ctx.save();
          ctx.globalAlpha = 0.34 * (1 - k / 40);
          ctx.beginPath(); ctx.arc(X, Y, 1.9, 0, TAU);
          ctx.fillStyle = C.accent; ctx.fill();
          ctx.restore();
        }
        cv.line(0, 0, x, y, { color: C.data[2], width: 1, dash: [4, 5] });
        label(cv, x / 2, y / 2, 'r = ' + fmt(P.r, 1) + '×10⁶ m', {
          color: C.soft, size: 10, align: 'center', ox: 0, oy: -8
        });
        const tx = -sin(th), ty = cos(th);
        if (lv >= 1) {
          vec(cv, x, y, tx * r * 0.26, ty * r * 0.26, C.accent, 2, 'v', { size: 10.5 });
          vec(cv, x, y, -cos(th) * r * 0.17, -sin(th) * r * 0.17, C.jade, 2, 'a', { size: 10.5 });
        }
        dot(cv, x, y, 5.5, C.ink, C.paper, 1.6);
        if (lv >= 2) {
          label(cv, 0, -r * 1.05, 'v = ' + fmt(d.v / 1000, 2) + ' km/s', {
            color: C.ink2, size: 10.5, align: 'center'
          });
          label(cv, 0, -r * 1.14, 'T = ' + fmt(d.T / 3600, 2) + ' h', {
            color: C.accent, size: 10.5, align: 'center'
          });
        } else if (lv === 0) {
          label(cv, 0, r * 1.06, 'GM = 3.986×10¹⁴ m³/s²', {
            color: C.soft, size: 10, align: 'center'
          });
        }
      },
      readouts: function () {
        const d = data();
        return [
          { label: '线速度 v', value: fmt(d.v / 1000, 2), unit: 'km/s' },
          { label: '周期 T', value: fmt(d.T / 3600, 2), unit: 'h' },
          { label: '轨道半径', value: fmt(d.r / 1000, 0), unit: 'km' },
          { label: '向心加速度', value: fmt(d.a, 2), unit: 'm/s²' }
        ];
      },
      hot: [[2], [0], [0, 1]],
      status: function (t) {
        const deg = ((t / 8) % 1 + 1) % 1 * 360;
        return '圆轨道 · 已转过 ' + fmt(deg, 0) + '°';
      }
    };
  }

  /* ================= 11. 电场线 + 等势面 ================= */
  function sceneEfield2() {
    const P = { q1: 5, q2: 5, qp: 1 };
    const C1 = { x: -1.3, y: 0 }, C2 = { x: 1.3, y: 0 };
    let sign2 = -1, dragIdx = -1;
    const K = 9e9, MU = 1e-6;
    function q2v() { return sign2 * abs(P.q2); }
    function charges() { return [{ x: C1.x, y: C1.y, q: P.q1 }, { x: C2.x, y: C2.y, q: q2v() }]; }
    function fieldAt(x, y) {
      let ex = 0, ey = 0;
      const chs = charges();
      for (let i = 0; i < chs.length; i++) {
        const dx = x - chs[i].x, dy = y - chs[i].y;
        const d2 = dx * dx + dy * dy + 0.012;
        const inv = chs[i].q / (d2 * Math.sqrt(d2));
        ex += dx * inv; ey += dy * inv;
      }
      return [ex, ey];
    }
    function potAt(x, y) {
      let v = 0;
      const chs = charges();
      for (let i = 0; i < chs.length; i++) {
        const dx = x - chs[i].x, dy = y - chs[i].y;
        v += chs[i].q / Math.sqrt(dx * dx + dy * dy + 0.012);
      }
      return v;
    }
    const cache = { key: '', lines: [], tabs: [], probe: null, probeTab: [0, 1], probeLen: 0, contours: [] };
    function ensure(cv) {
      const key = [P.q1, P.q2, sign2, C1.x, C1.y, C2.x, C2.y, cv.w, cv.h].map(function (v) {
        return Number(v).toFixed(3);
      }).join('|');
      if (key === cache.key) return cache;
      cache.key = key;
      const chs = charges(), xr = cv.xr, yr = cv.yr;
      const opposite = q2v() < 0;
      const lines = [], tabs = [];
      /* 异号只从正电荷发出：线自然汇入负电荷；同号两电荷各自发出 */
      const homes = opposite ? [chs[0]] : chs;
      homes.forEach(function (home) {
        const sgn = home.q > 0 ? 1 : -1;
        const count = opposite ? 16 : 11;
        for (let k = 0; k < count; k++) {
          const a = (k + 0.5) / count * TAU;
          let x = home.x + 0.18 * cos(a), y = home.y + 0.18 * sin(a);
          const pts = [[x, y]];
          for (let step = 0; step < 520; step++) {
            const e = fieldAt(x, y), m = Math.sqrt(e[0] * e[0] + e[1] * e[1]);
            if (!isFinite(m) || m < 1e-9) break;
            x += sgn * e[0] / m * 0.035;
            y += sgn * e[1] / m * 0.035;
            if (x < xr[0] - 0.2 || x > xr[1] + 0.2 || y < yr[0] - 0.2 || y > yr[1] + 0.2) break;
            let end = false;
            for (let j = 0; j < chs.length; j++) {
              const dEnd = Math.sqrt(Math.pow(x - chs[j].x, 2) + Math.pow(y - chs[j].y, 2));
              if (j !== 0 || home !== chs[0]) {
                if (chs[j].q * home.q < 0 && dEnd < 0.12) end = true;
              }
            }
            pts.push([x, y]);
            if (end) break;
          }
          if (pts.length > 6) { lines.push(pts); tabs.push(pathTable(pts)); }
        }
      });
      let bi = 0, bl = 0, bestScore = -1;
      tabs.forEach(function (tb, i) {
        const len = tb[tb.length - 1];
        const last = lines[i][lines[i].length - 1];
        let score = len;
        if (opposite) {
          const dEnd = Math.hypot(last[0] - C2.x, last[1] - C2.y);
          /* 异号时优先选“真正连到负电荷”的最短一条，粒子走中间不跑出画框 */
          if (dEnd < 0.45) score = 1000 - len;
        }
        if (score > bestScore) { bestScore = score; bi = i; bl = len; }
      });
      cache.lines = lines; cache.tabs = tabs;
      cache.probe = lines[bi] || [[0, 0], [1, 0]];
      cache.probeTab = tabs[bi] || [0, 1];
      cache.probeLen = bl;
      const sc = max(1, max(P.q1, abs(q2v())));
      const base = [1.2, 2.8, 6.2].map(function (v) { return v * sc / 5; });
      const groups = [];
      base.concat(base.map(function (v) { return -v; })).forEach(function (level, idx) {
        const segs = marchSquares(potAt, xr, yr, level, 46, 32);
        if (segs.length) {
          groups.push({
            segs: segs, color: level > 0 ? C.data[2] : C.jade,
            alpha: idx < base.length ? 0.24 : 0.16,
            rank: idx < base.length ? 1 : 2
          });
        }
      });
      if (opposite) {
        const zs = marchSquares(potAt, xr, yr, 0, 46, 32);
        if (zs.length) groups.push({ segs: zs, color: C.faint, alpha: 0.26, dash: [3, 6], rank: 1 });
      }
      cache.contours = groups;
      return cache;
    }
    function drawCharges(cv) {
      const chs = charges();
      chs.forEach(function (c, i) {
        const X = cv.px(c.x), Y = cv.py(c.y);
        const ctx = cv.ctx, pos = c.q > 0;
        ctx.save();
        ctx.beginPath(); ctx.arc(X, Y, 17, 0, TAU);
        ctx.fillStyle = pos ? 'rgba(180,85,60,.13)' : 'rgba(51,78,172,.13)';
        ctx.fill();
        ctx.beginPath(); ctx.arc(X, Y, 11, 0, TAU);
        ctx.fillStyle = pos ? C.accent : C.ink2; ctx.fill();
        ctx.strokeStyle = C.paper; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = onColor(pos ? C.accent : C.ink2); ctx.font = '700 14px ' + C.sans;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(pos ? '+' : '−', X, Y + 1);
        ctx.restore();
        plabel(cv, X, Y + 26, (i ? 'q₂ = ' : 'q₁ = ') + (pos ? '+' : '−') + fmt(abs(c.q), 1) + ' µC',
          { align: 'center', color: pos ? C.accent : C.ink2, size: 10.5, weight: 700 });
      });
    }
    function readValues() {
      const chs = charges();
      const em = fieldAt(0, 0);
      const eMid = Math.sqrt(em[0] * em[0] + em[1] * em[1]) * K * MU / 1000;
      const vMid = potAt(0, 0) * K * MU / 1000;
      return { eMid: eMid, vMid: vMid, d: Math.sqrt(Math.pow(chs[0].x - chs[1].x, 2) + Math.pow(chs[0].y - chs[1].y, 2)) };
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'q1', label: '电荷 q₁ (µC)', min: 0.5, max: 8, step: 0.5, dec: 1 },
        { k: 'q2', label: '电荷 q₂ (µC)', min: 0.5, max: 8, step: 0.5, dec: 1 },
        { k: 'qp', label: '探针电荷 q (µC)', min: -4, max: 4, step: 0.5, dec: 1 }
      ],
      chips: [{
        label: '电荷组合',
        items: ['异号', '同号'],
        index: 0,
        set: function (i) { sign2 = i ? 1 : -1; }
      }],
      hints: [
        '电场线从正电荷出发、指向负电荷；同号时互相排斥、彼此绕开。',
        '等势面处处与电场线垂直，电势 V = kΣq/r 相同的地方连成一条线。',
        '带电粒子沿电场线方向受 qE 作用；正电荷顺着电场线加速，负电荷反向。'
      ],
      duration: function () { return 5.2; },
      drag: function (phase, x, y) {
        if (phase === 'down') {
          const d1 = Math.hypot(x - C1.x, y - C1.y), d2 = Math.hypot(x - C2.x, y - C2.y);
          dragIdx = d1 <= d2 ? 0 : 1;
          if (Math.min(d1, d2) > 0.62) { dragIdx = -1; return; }
          return;
        }
        if (phase === 'up') { dragIdx = -1; return; }
        if (phase === 'move' && dragIdx >= 0) {
          const c = dragIdx ? C2 : C1, o = dragIdx ? C1 : C2;
          const nx = clamp(x, -3.1, 3.1), ny = clamp(y, -1.9, 1.9);
          if (Math.hypot(nx - o.x, ny - o.y) < 0.5) return;
          c.x = nx; c.y = ny;
        }
      },
      draw: function (cv, t, lv) {
        if (cv.w < 40) return;
        cv.clear(C.paper);
        const c = ensure(cv);
        viewRect(cv, -3.2, 3.2, -2.0, 2.0, 0.02, true);
        cv.grid(niceStep(cv.xr[1] - cv.xr[0]), { grid: C.grid2, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        ctx.save();
        ctx.lineCap = 'round';
        c.contours.forEach(function (g) {
          if (lv < 2 && g.rank > 1) return;
          ctx.beginPath();
          g.segs.forEach(function (s) {
            ctx.moveTo(cv.px(s[0][0]), cv.py(s[0][1]));
            ctx.lineTo(cv.px(s[1][0]), cv.py(s[1][1]));
          });
          ctx.globalAlpha = g.alpha * (lv >= 1 ? 1 : 0.55);
          ctx.strokeStyle = g.color;
          ctx.lineWidth = 1;
          if (g.dash) ctx.setLineDash(g.dash); else ctx.setLineDash([]);
          ctx.stroke();
        });
        ctx.restore();
        c.lines.forEach(function (pts, i) {
          worldPath(cv, pts, { color: C.data[2], width: 1.25, alpha: 0.55 });
          const df = ((t * 0.16 + i * 0.09) % 1 + 1) % 1;
          const dp = pathPoint(pts, c.tabs[i], df);
          dot(cv, dp[0], dp[1], 2.2, C.data[2], null, 0);
          if (lv >= 1 && i % 2 === 0) {
            const p = pathPoint(pts, c.tabs[i], 0.58);
            pArrow(ctx, cv.px(p[0]), cv.py(p[1]),
              cv.px(p[0]) + cos(p[2]) * 7, cv.py(p[1]) - sin(p[2]) * 7, C.data[2], 1.2, 5);
          }
        });
        if (lv >= 1) tagBox(cv, cv.w * 0.5, 18, '实线：电场线　细线：等势面', C.ink2, 'center');
        const dirF = P.qp >= 0 ? 1 : -1;
        const frac = (t / 5.2) % 1;
        const s = frac < 0.5 ? frac * 2 : 2 - frac * 2;
        const f0 = dirF > 0 ? 0 : 1;
        const trail = [];
        for (let i = 0; i <= 72; i++) {
          const f = f0 + (s - f0) * i / 72;
          const pp = pathPoint(c.probe, c.probeTab, f);
          trail.push([pp[0], pp[1]]);
        }
        worldPath(cv, c.probe, { color: C.gold, width: 1, alpha: 0.25 });
        worldPath(cv, trail, { color: C.accent, width: 2, alpha: 0.9 });
        const pp = pathPoint(c.probe, c.probeTab, s);
        const ang = pp[2] + (dirF > 0 ? 0 : PI);
        const PX = cv.px(pp[0]), PY = cv.py(pp[1]);
        pArrow(ctx, PX, PY, PX + cos(ang) * 24, PY - sin(ang) * 24, C.accent, 1.8, 7);
        if (lv >= 2) {
          const e = fieldAt(pp[0], pp[1]);
          const m = Math.sqrt(e[0] * e[0] + e[1] * e[1]) || 1;
          pArrow(ctx, PX, PY, PX + e[0] / m * dirF * 28, PY - e[1] / m * dirF * 28, C.gold, 1.6, 6);
          plabel(cv, PX + 30, PY - 13, 'E', { color: C.gold, size: 10, weight: 700 });
        }
        const ctx2 = cv.ctx;
        ctx2.save();
        ctx2.beginPath(); ctx2.arc(PX, PY, 9, 0, TAU);
        ctx2.fillStyle = 'rgba(180,85,60,.16)'; ctx2.fill();
        ctx2.restore();
        dot(cv, pp[0], pp[1], 4.4, C.accent, C.paper, 1.4);
        plabel(cv, PX + 9, PY - 9, 'q', { color: C.accent, size: 10, weight: 700 });
        drawCharges(cv);
        if (lv === 0) tagBox(cv, 14, cv.h - 22, '拖动电荷可改位置', C.soft);
        if (lv >= 2) {
          const vv = readValues();
          plabel(cv, 14, cv.h - 22, '中点 E = ' + fmt(vv.eMid, 1) + ' kN/C　V = ' + fmt(vv.vMid, 1) + ' kV',
            { color: C.soft, size: 10, weight: 500 });
        }
      },
      readouts: function () {
        const v = readValues();
        return [
          { label: '中点场强 E', value: fmt(v.eMid, 1), unit: 'kN/C' },
          { label: '中点电势 V', value: fmt(v.vMid, 1), unit: 'kV' },
          { label: '电荷间距', value: fmt(v.d, 2), unit: 'm' },
          { label: '探针轨迹长', value: fmt(cache.probeLen, 2), unit: 'm' }
        ];
      },
      hot: [[0, 1], [2], [0, 1, 2, 3]],
      status: function (t) {
        const same = q2v() > 0;
        const frac = (t / 5.2) % 1;
        const s = frac < 0.5 ? frac * 2 : 2 - frac * 2;
        return (same ? '同号相斥' : '异号相吸') + ' · ' + (s < 0.08 ? '出发' : s > 0.92 ? '到达终点' : (frac < 0.5 ? '向远' : '回程'));
      }
    };
  }

  /* ================= 12. 匀强磁场中的圆周与螺旋 ================= */
  function sceneMagnet() {
    const P = { B: 2, v: 2, vp: 0.4 };
    let qsign = 1;
    function rOf() { return max(0.08, P.v / max(abs(P.B), 0.05)); }
    function period() { return TAU / max(abs(P.B), 0.05); }
    function stateAt(t) {
      const r = rOf(), w = abs(P.B), th = -qsign * w * t;
      return { r: r, w: w, th: th, x: r * cos(th), y: r * sin(th) };
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'B', label: '磁感应强度 B (T)', min: 0.8, max: 3.2, step: 0.1, dec: 1 },
        { k: 'v', label: '速率 v (m/s)', min: 1, max: 3.2, step: 0.1, dec: 1 },
        { k: 'vp', label: '轴向速度 v∥ (m/s)', min: 0, max: 2, step: 0.1, dec: 1 }
      ],
      chips: [{
        label: '电荷正负',
        items: ['正电荷', '负电荷'],
        index: 0,
        set: function (i) { qsign = i ? -1 : 1; }
      }],
      hints: [
        '洛伦兹力 F = qvB 始终与速度垂直，只改变方向、不做功。',
        '正电荷绕行方向由右手定则判断，负电荷反向；半径 r = mv/(qB)。',
        '若速度还有沿 B 的分量 v∥，圆周运动叠加匀速直线，轨迹变成螺旋。'
      ],
      duration: period,
      draw: function (cv, t, lv) {
        if (cv.w < 40) return;
        cv.clear(C.paper);
        const st = stateAt(t);
        const half = max(st.r * 1.3, 0.55);
        viewRect(cv, -half, half, -half, half, 0.01, true);
        cv.grid(niceStep(st.r * 2.4), { grid: C.grid2, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        ringWorld(cv, 0, 0, st.r, C.data[2], 1.1, [4, 5]);
        ctx.save();
        for (let X = 22; X < cv.w - 12; X += 42) {
          for (let Y = 46; Y < cv.h - 46; Y += 38) {
            ctx.globalAlpha = 0.15 + 0.06 * sin(t * 1.7 + X * 0.03 + Y * 0.02);
            ctx.beginPath(); ctx.arc(X, Y, 3.2, 0, TAU);
            ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1; ctx.stroke();
            ctx.beginPath(); ctx.arc(X, Y, 1.1, 0, TAU);
            ctx.fillStyle = C.data[2]; ctx.fill();
          }
        }
        ctx.restore();
        for (let k = 38; k >= 1; k--) {
          const thp = st.th + qsign * 0.135 * k;
          const X = cv.px(st.r * cos(thp)), Y = cv.py(st.r * sin(thp));
          ctx.save();
          ctx.globalAlpha = 0.42 * (1 - k / 42);
          ctx.beginPath(); ctx.arc(X, Y, max(1, 2.6 * (1 - k / 52)), 0, TAU);
          ctx.fillStyle = C.accent; ctx.fill();
          ctx.restore();
        }
        const tx = qsign * sin(st.th), ty = -qsign * cos(st.th);
        const vlen = st.r * 0.55;
        const fx = -st.x / max(st.r, 1e-6), fy = -st.y / max(st.r, 1e-6);
        if (lv >= 1) {
          vec(cv, st.x, st.y, tx * vlen, ty * vlen, C.accent, 1.9, 'v', { size: 10.5 });
          vec(cv, st.x, st.y, fx * st.r * 0.42, fy * st.r * 0.42, C.jade, 1.9, 'F', { size: 10.5 });
        }
        dot(cv, 0, 0, 1.8, C.faint, null, 0);
        const ctx3 = cv.ctx;
        ctx3.save();
        ctx3.beginPath(); ctx3.arc(cv.px(st.x), cv.py(st.y), 11, 0, TAU);
        ctx3.fillStyle = 'rgba(180,85,60,.14)'; ctx3.fill();
        ctx3.restore();
        dot(cv, st.x, st.y, 5.2, C.ink, C.paper, 1.5);
        if (lv >= 2) {
          cv.line(0, 0, st.x, st.y, { color: C.data[2], width: 1, dash: [4, 4] });
          label(cv, st.x * 0.5, st.y * 0.5, 'r = ' + fmt(st.r, 2) + ' m', {
            color: C.ink2, size: 10, align: 'center', oy: -9
          });
        }
        tagBox(cv, cv.w * 0.5, 18, '· B 垂直纸面向外', C.ink2, 'center');
        if (P.vp > 0.05) {
          const X = 14, Y = cv.h - 148, W = 206, H = 132;
          const ctxh = cv.ctx;
          ctxh.save();
          ctxh.font = '600 9px ' + C.sans;
          ctxh.fillStyle = C.faint;
          ctxh.textAlign = 'left'; ctxh.textBaseline = 'middle';
          ctxh.fillText('沿 B 方向的螺旋运动', X + 2, Y + 8);
          ctxh.restore();
          const rad = min(13, H * 0.15), span = W - 26, cx = X + 12, cy = Y + 84;
          ctxh.save();
          ctxh.strokeStyle = C.data[2]; ctxh.globalAlpha = 0.35; ctxh.lineWidth = 1; ctxh.setLineDash([3, 5]);
          ctxh.beginPath();
          ctxh.moveTo(cx, cy - rad); ctxh.lineTo(cx + span, cy - rad);
          ctxh.moveTo(cx, cy + rad); ctxh.lineTo(cx + span, cy + rad);
          ctxh.stroke();
          /* 两端圆截面：把正弦样的投影读成“圆柱上的螺旋” */
          [0, span].forEach(function (zx) {
            ctxh.beginPath();
            ctxh.ellipse(cx + zx, cy, rad * 1.12, rad, 0, 0, TAU);
            ctxh.stroke();
          });
          ctxh.setLineDash([]);
          ctxh.globalAlpha = 1;
          ctxh.strokeStyle = C.data[2]; ctxh.lineWidth = 1.45;
          for (let i = 1; i <= 200; i++) {
            const u0 = (i - 1) / 200, u1 = i / 200;
            const a0 = TAU * 6 * u0, a1 = TAU * 6 * u1;
            const X0 = cx + span * u0 + cos(a0) * rad * 1.12;
            const Y0 = cy + sin(a0) * rad;
            const X1 = cx + span * u1 + cos(a1) * rad * 1.12;
            const Y1 = cy + sin(a1) * rad;
            ctxh.globalAlpha = 0.40 + 0.5 * (0.5 + 0.5 * sin(a0));
            ctxh.beginPath(); ctxh.moveTo(X0, Y0); ctxh.lineTo(X1, Y1); ctxh.stroke();
          }
          ctxh.globalAlpha = 1;
          ctxh.restore();
          const u = (t / period()) % 1;
          const ang = TAU * 6 * u;
          const Xp = cx + span * u + cos(ang) * rad * 1.12;
          const Yp = cy + sin(ang) * rad;
          cv.ctx.beginPath(); cv.ctx.arc(Xp, Yp, 3.8, 0, TAU);
          cv.ctx.fillStyle = C.accent; cv.ctx.fill();
          pArrow(cv.ctx, cx + span * 0.62, Y + H - 7, cx + span * 0.62 + 22, Y + H - 7, C.ink2, 1, 5);
          plabel(cv, cx + span * 0.62 + 26, Y + H - 8, 'v∥', { color: C.ink2, size: 9.5, weight: 600 });
        } else if (lv >= 2) {
          tagBox(cv, 14, cv.h - 24, 'v∥ = 0 → 圆轨道', C.soft);
        }
      },
      readouts: function () {
        const T = period();
        return [
          { label: '轨道半径 r', value: fmt(rOf(), 2), unit: 'm' },
          { label: '回旋周期 T', value: fmt(T, 2), unit: 's' },
          { label: '速率 v', value: fmt(P.v, 2), unit: 'm/s' },
          { label: '螺旋螺距', value: fmt(P.vp * T, 2), unit: 'm' }
        ];
      },
      hot: [[0, 1], [2], [0, 1, 2, 3]],
      status: function () {
        return (P.vp > 0.05 ? '螺旋运动' : '匀速圆周') + ' · ' + (qsign > 0 ? '顺时针' : '逆时针');
      }
    };
  }

  /* ================= 13. 导体棒切割磁感线 ================= */
  function sceneInduction() {
    const P = { B: 0.6, L: 0.8, v: 1.2, R: 3 };
    const SPAN = 2.4, RIN = 0.4;
    function duration() { return 2 * SPAN / max(P.v, 0.05); }
    function stateAt(t) {
      const T = duration(), u = (t / T) * 2;
      const f = u < 1 ? u : 2 - u;
      const dir = u < 1 ? 1 : -1;
      const emf = P.B * P.L * P.v;
      const I = emf / (P.R + RIN);
      return { f: f, dir: dir, emf: emf, I: I, flux: P.B * P.L * SPAN * f };
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'B', label: '磁感应强度 B (T)', min: 0.2, max: 1, step: 0.05, dec: 2 },
        { k: 'L', label: '导体棒长 L (m)', min: 0.5, max: 1.2, step: 0.05, dec: 2 },
        { k: 'v', label: '切割速度 v (m/s)', min: 0.4, max: 2, step: 0.1, dec: 1 },
        { k: 'R', label: '外电阻 R (Ω)', min: 1, max: 8, step: 0.2, dec: 1 }
      ],
      hints: [
        '导体棒切割磁感线，回路面积增大，磁通量 Φ = BLx 随之改变。',
        '法拉第定律 E = ΔΦ/Δt = BLv，感应电流 I = E/(R + r)。',
        '楞次定律：感应电流的磁场总要阻碍原磁通量的变化。'
      ],
      duration: duration,
      draw: function (cv, t, lv) {
        if (cv.w < 60) return;
        cv.clear(C.paper);
        const w = cv.w, h = cv.h, ctx = cv.ctx;
        const st = stateAt(t);
        const xL = w * 0.10, xEnd = w * 0.80, yT = h * 0.18, yB = h * 0.72;
        const rodX = xL + st.f * (xEnd - xL);
        ctx.save();
        ctx.fillStyle = C.data[4];
        ctx.globalAlpha = 0.22;
        ctx.fillRect(xL, yT, xEnd - xL, yB - yT);
        ctx.globalAlpha = 0.46;
        ctx.fillRect(xL, yT, rodX - xL, yB - yT);
        ctx.restore();
        ctx.save();
        for (let X = xL + 18, i = 0; X < xEnd - 6; X += 30, i++) {
          for (let Y = yT + 20; Y < yB - 8; Y += 32) {
            ctx.globalAlpha = 0.22 + 0.1 * sin(t * 2 + X * 0.03 + Y * 0.02);
            ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1.1;
            ctx.beginPath();
            ctx.moveTo(X - 4, Y - 4); ctx.lineTo(X + 4, Y + 4);
            ctx.moveTo(X + 4, Y - 4); ctx.lineTo(X - 4, Y + 4);
            ctx.stroke();
          }
        }
        ctx.restore();
        ctx.save();
        ctx.strokeStyle = C.ink2; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(xL, yT); ctx.lineTo(xEnd, yT);
        ctx.moveTo(xL, yB); ctx.lineTo(xEnd, yB);
        ctx.moveTo(xL, yT); ctx.lineTo(xL, yB);
        ctx.stroke();
        ctx.restore();
        const pathCW = [[xL, yT], [rodX, yT], [rodX, yB], [xL, yB], [xL, yT]];
        const path = st.dir > 0 ? pathCW.slice().reverse() : pathCW;
        const tab = pathTable(path);
        const phase = (t * (0.35 + 1.9 * st.I)) % 1;
        pFlow(ctx, path, C.accent, [4, 9], -((t * 34) % 13), 1.8, 0.75);
        for (let i = 0; i < 10; i++) {
          const f = ((phase + i / 10) % 1 + 1) % 1;
          const p = pathPoint(path, tab, f);
          ctx.beginPath(); ctx.arc(p[0], p[1], 2.6, 0, TAU);
          ctx.fillStyle = C.accent; ctx.fill();
        }
        const dirTop = st.dir > 0 ? -1 : 1;
        pArrow(ctx, (xL + rodX) / 2 - dirTop * 12, yT, (xL + rodX) / 2 + dirTop * 18, yT, C.accent, 1.6, 7);
        pArrow(ctx, (xL + rodX) / 2 + dirTop * 12, yB, (xL + rodX) / 2 - dirTop * 18, yB, C.accent, 1.6, 7);
        plabel(cv, (xL + rodX) / 2, yT - 13, 'I', { color: C.accent, size: 10, align: 'center', weight: 700 });
        ctx.save();
        ctx.fillStyle = C.accent;
        roundRect(ctx, rodX - 3, yT - 3, 6, yB - yT + 6, 3); ctx.fill();
        ctx.restore();
        const dirLen = 34;
        pArrow(ctx, rodX + 10, (yT + yB) / 2, rodX + 10 + dirLen * st.dir, (yT + yB) / 2, C.accent, 2, 8);
        plabel(cv, rodX + (st.dir > 0 ? 18 : -18), (yT + yB) / 2 - 13,
          'v = ' + fmt(P.v, 1) + ' m/s', { color: C.accent, size: 10.5, weight: 700, align: st.dir > 0 ? 'left' : 'right' });
        if (lv >= 1) {
          plabel(cv, (xL + rodX) / 2, yT + 16, 'Φ = ' + fmt(st.flux, 2) + ' Wb',
            { color: C.ink2, size: 10, align: 'center', weight: 600 });
          plabel(cv, xL + 4, yB + 16, 'B = ' + fmt(P.B, 2) + ' T　L = ' + fmt(P.L, 2) + ' m',
            { color: C.soft, size: 10, weight: 500 });
        }
        tagBox(cv, cv.w * 0.5, 18, '导体棒切割磁感线 · E = BLv', C.ink2, 'center');
        const xA = xL + (xEnd - xL) * 0.2, yA = yB, rA = 19;
        ctx.save();
        ctx.beginPath(); ctx.arc(xA, yA, rA, 0, TAU);
        ctx.fillStyle = C.card; ctx.fill();
        ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.6; ctx.stroke();
        ctx.beginPath(); ctx.arc(xA, yA, rA - 5, -PI / 2 - 0.85, -PI / 2 + 0.85);
        ctx.strokeStyle = C.faint; ctx.lineWidth = 1; ctx.stroke();
        const nAng = -PI / 2 + clamp(st.I / 0.9, 0, 1) * 0.95 * (st.dir > 0 ? 1 : -1);
        ctx.beginPath(); ctx.moveTo(xA, yA); ctx.lineTo(xA + cos(nAng) * (rA - 7), yA + sin(nAng) * (rA - 7));
        ctx.strokeStyle = C.accent; ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.arc(xA, yA, 2, 0, TAU); ctx.fillStyle = C.ink; ctx.fill();
        ctx.restore();
        plabel(cv, xA, yA + rA + 11, 'A　' + fmt(st.I, 3) + ' A', { color: C.ink2, size: 10, align: 'center', weight: 600 });
        if (lv >= 2) {
          const X = 14, Y = cv.h - 104, W = min(330, w * 0.46), H = 90;
          const p = framePanel(cv, X, Y, W, H, '法拉第电磁感应定律');
          plabel(cv, X + 10, p.y + 4, 'E = BLv = ' + fmt(st.emf, 3) + ' V', { color: C.ink, size: 11, weight: 600 });
          plabel(cv, X + 10, p.y + 22, 'I = E/(R+r) = ' + fmt(st.I, 3) + ' A', { color: C.ink2, size: 10.5 });
          plabel(cv, X + 10, p.y + 40, 'Φ = BLx = ' + fmt(st.flux, 2) + ' Wb', { color: C.ink2, size: 10 });
          plabel(cv, X + 10, p.y + 58, st.dir > 0 ? '磁通增大 → 电流逆时针' : '磁通减小 → 电流顺时针',
            { color: C.accent, size: 10 });
        }
      },
      readouts: function (t) {
        const st = stateAt(t);
        return [
          { label: '磁通量 Φ', value: fmt(st.flux, 2), unit: 'Wb' },
          { label: '电动势 E', value: fmt(st.emf, 3), unit: 'V' },
          { label: '感应电流 I', value: fmt(st.I, 3), unit: 'A' },
          { label: '电功率 P', value: fmt(st.emf * st.I, 3), unit: 'W' }
        ];
      },
      hot: [[1], [0, 2], [0, 1, 2, 3]],
      status: function (t) {
        const st = stateAt(t);
        if (st.f < 0.02) return '在最左端 · 即将向右';
        if (st.f > 0.98) return '在最右端 · 即将向左';
        return st.dir > 0 ? '向右切割 · 磁通增大' : '向左切割 · 磁通减小';
      }
    };
  }

  /* ================= 14. 卫星轨道与变轨 ================= */
  function sceneGravity2() {
    const P = { r1: 11000, r2: 15000 };
    let mode = 0; // 0 椭圆变轨，1 稳定圆轨道
    const GM = 398600.4418, RE = 6371;
    const cache = { key: '', d: null };
    function build() {
      const key = [P.r1, P.r2, mode].join('|');
      if (cache.key === key) return cache.d;
      cache.key = key;
      const r1 = max(P.r1, RE + 1200);
      const r2 = max(P.r2, r1 + 800);
      const T1 = TAU * Math.sqrt(r1 * r1 * r1 / GM);
      const T2 = TAU * Math.sqrt(r2 * r2 * r2 / GM);
      const aT = (r1 + r2) / 2;
      const Ttr = PI * Math.sqrt(aT * aT * aT / GM);
      let t1 = 0, t2 = 0, t3 = 0, t4 = 0, total = T1;
      if (mode === 0) {
        t1 = 0.20 * T1;
        t2 = t1 + Ttr;
        t3 = t2 + 0.20 * T2;
        t4 = t3 + Ttr;
        total = t4 + 0.60 * T1;
      }
      const N = 1500, dt = total / N;
      let x = r1, y = 0, vx = 0, vy = Math.sqrt(GM / r1);
      const pts = [], burnI = [-1, -1, -1, -1], bt = [t1, t2, t3, t4];
      for (let i = 0; i <= N; i++) {
        const tt = i * dt;
        if (mode === 0) {
          for (let b = 0; b < 4; b++) {
            if (burnI[b] < 0 && tt >= bt[b] - 1e-9) {
              burnI[b] = i;
              const rr = Math.sqrt(x * x + y * y), sp = Math.sqrt(vx * vx + vy * vy) || 1;
              const target = (b === 1 || b === 3) ? Math.sqrt(GM / rr)
                : Math.sqrt(GM * (2 / rr - 1 / aT));
              vx *= target / sp; vy *= target / sp;
            }
          }
        }
        pts.push({ x: x, y: y, vx: vx, vy: vy, t: tt });
        const rr = Math.sqrt(x * x + y * y) || 1;
        const ax = -GM * x / (rr * rr * rr), ay = -GM * y / (rr * rr * rr);
        x += vx * dt + 0.5 * ax * dt * dt;
        y += vy * dt + 0.5 * ay * dt * dt;
        const rn = Math.sqrt(x * x + y * y) || 1;
        const ax2 = -GM * x / (rn * rn * rn), ay2 = -GM * y / (rn * rn * rn);
        vx += 0.5 * (ax + ax2) * dt;
        vy += 0.5 * (ay + ay2) * dt;
      }
      const areas = [0];
      for (let i = 1; i <= N; i++) {
        areas.push(areas[i - 1] + 0.5 * Math.abs(pts[i - 1].x * pts[i].y - pts[i - 1].y * pts[i].x));
      }
      const d = { pts: pts, N: N, total: total, dt: dt, burnI: burnI, areas: areas, r1: r1, r2: r2, aT: aT, T1: T1, T2: T2, Ttr: Ttr, mode: mode };
      cache.d = d;
      return d;
    }
    function idxAt(t) {
      const d = build();
      return clamp(Math.round((t / 12) * d.N), 0, d.N);
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'r1', label: '低轨半径 r₁ (km)', min: 8000, max: 14000, step: 200, dec: 0 },
        { k: 'r2', label: '高轨半径 r₂ (km)', min: 12000, max: 22000, step: 200, dec: 0 }
      ],
      chips: [{
        label: '轨道任务',
        items: ['椭圆变轨', '圆轨道'],
        index: 0,
        set: function (i) { mode = i; }
      }],
      hints: [
        '卫星做圆周运动时，万有引力提供向心力：GMm/r² = mv²/r。',
        '在低轨加速，速度超过该高度圆轨道速度，轨道拉长成椭圆；到远地点再加速即可圆化。',
        '开普勒第二定律：卫星与地心连线在相等时间内扫过相等面积，所以近地点快、远地点慢。'
      ],
      duration: function () { return 12; },
      draw: function (cv, t, lv) {
        if (cv.w < 40) return;
        cv.clear(C.paper);
        const d = build();
        const idx = idxAt(t);
        const p = d.pts[idx];
        const rNow = Math.sqrt(p.x * p.x + p.y * p.y);
        const vNow = Math.sqrt(p.vx * p.vx + p.vy * p.vy) / 1000;
        const half = max(d.r2 * 1.32, d.r1 * 1.32);
        viewRect(cv, -half, half, -half, half, 0.01, true);
        cv.grid(niceStep(half * 2), { grid: C.grid2, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        const full = d.pts.map(function (q) { return [q.x, q.y]; });
        worldPath(cv, full, { color: C.data[3], width: 1.1, alpha: 0.75, dash: [3, 6] });
        const trail = d.pts.slice(max(0, idx - 110), idx + 1).map(function (q) { return [q.x, q.y]; });
        worldPath(cv, trail, { color: C.accent, width: 1.8, alpha: 0.85 });
        if (mode === 0) {
          [[d.burnI[0], d.burnI[1]], [d.burnI[2], d.burnI[3]]].forEach(function (seg) {
            const i0 = seg[0], i1 = seg[1];
            if (i0 < 0 || i1 <= i0) return;
            const nW = 10;
            for (let k = 0; k < nW; k++) {
              const a = Math.round(i0 + (i1 - i0) * k / nW);
              const b = Math.round(i0 + (i1 - i0) * (k + 1) / nW);
              if (idx < a) continue;
              const end = min(idx, b);
              ctx.beginPath();
              ctx.moveTo(cv.px(0), cv.py(0));
              for (let j = a; j <= end; j++) ctx.lineTo(cv.px(d.pts[j].x), cv.py(d.pts[j].y));
              ctx.closePath();
              ctx.globalAlpha = idx >= b ? (lv >= 1 ? 0.22 : 0.12) : (lv >= 1 ? 0.11 : 0.05);
              ctx.fillStyle = k % 2 ? C.data[2] : C.data[4];
              ctx.fill();
            }
            ctx.globalAlpha = 1;
            if (lv >= 1) {
              for (let k = 0; k <= nW; k++) {
                const j = Math.round(i0 + (i1 - i0) * k / nW);
                const q = d.pts[j];
                ctx.beginPath();
                ctx.moveTo(cv.px(0), cv.py(0));
                ctx.lineTo(cv.px(q.x), cv.py(q.y));
                ctx.strokeStyle = C.data[2]; ctx.lineWidth = 0.8; ctx.globalAlpha = 0.35;
                ctx.stroke();
              }
            }
            ctx.globalAlpha = 1;
          });
        }
        if (mode === 0) {
          for (let b = 0; b < 4; b++) {
            const bi = d.burnI[b];
            if (bi < 0) continue;
            const q = d.pts[bi];
            const dtSim = (idx - bi) * d.dt;
            if (dtSim >= 0 && dtSim < 2200) {
              const k = dtSim / 2200;
              ctx.beginPath(); ctx.arc(cv.px(q.x), cv.py(q.y), 6 + 26 * k, 0, TAU);
              ctx.strokeStyle = C.accent; ctx.globalAlpha = 1 - k; ctx.lineWidth = 1.6; ctx.stroke();
              ctx.globalAlpha = 1;
            }
            if (lv >= 1) {
              ctx.beginPath(); ctx.arc(cv.px(q.x), cv.py(q.y), 3, 0, TAU);
              ctx.fillStyle = C.accent; ctx.fill();
            }
          }
        }
        /* 地球最后画：盖住扫过面积扇形的内部，只留轨道带上的等面积区 */
        ctx.save();
        ctx.beginPath(); ctx.arc(cv.px(0), cv.py(0), RE * cv.sx(), 0, TAU);
        ctx.fillStyle = C.data[3]; ctx.fill();
        ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1.4; ctx.stroke();
        ctx.restore();
        label(cv, 0, 0, '地球', { color: C.ink2, size: 10, align: 'center', halo: false, weight: 700 });
        const wx = cv.px(p.x), wy = cv.py(p.y);
        ctx.beginPath(); ctx.arc(wx, wy, 9, 0, TAU);
        ctx.fillStyle = 'rgba(180,85,60,.16)'; ctx.fill();
        dot(cv, p.x, p.y, 4.6, C.ink, C.paper, 1.5);
        if (lv >= 1) {
          const sc = half * 0.17 / max(vNow, 1e-6);
          vec(cv, p.x, p.y, p.vx / 1000 * sc, p.vy / 1000 * sc, C.accent, 1.8, 'v', { size: 10 });
          cv.line(0, 0, p.x, p.y, { color: C.data[2], width: 1, dash: [4, 5] });
          label(cv, p.x * 0.5, p.y * 0.5, 'r', { color: C.soft, size: 9.5, align: 'center', oy: -8, weight: 500 });
        }
        if (lv >= 2) {
          tagBox(cv, cv.w * 0.5, 18, '等时间内扫过相等面积', C.ink2, 'center');
          const p2 = framePanel(cv, 14, cv.h - 92, min(292, cv.w * 0.45), 78, '开普勒第二定律');
          plabel(cv, 24, p2.y + 4, 'a = (r₁ + r₂)/2 = ' + fmt(d.aT, 0) + ' km', { color: C.ink, size: 10.5, weight: 600 });
          plabel(cv, 24, p2.y + 22, 'T = 2π√(a³/GM)', { color: C.ink2, size: 10 });
          plabel(cv, 24, p2.y + 40, '近地点快 · 远地点慢', { color: C.accent, size: 10 });
        } else if (lv === 0) {
          tagBox(cv, cv.w * 0.5, 18, '卫星绕地球运行', C.soft, 'center');
        }
      },
      readouts: function (t) {
        const d = build();
        const idx = idxAt(t), p = d.pts[idx];
        const r = Math.sqrt(p.x * p.x + p.y * p.y);
        const v = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
        const rate = 0.5 * Math.abs(p.x * p.vy - p.y * p.vx);
        const inTransfer = mode === 0 && ((idx >= d.burnI[0] && idx < d.burnI[1]) || (idx >= d.burnI[2] && idx < d.burnI[3]));
        return [
          { label: '当前半径 r', value: fmt(r, 0), unit: 'km' },
          { label: '轨道速度 v', value: fmt(v, 2), unit: 'km/s' },
          { label: '半长轴 a', value: fmt(inTransfer ? d.aT : r, 0), unit: 'km' },
          { label: '面积速率', value: fmt(rate, 0), unit: 'km²/s' }
        ];
      },
      hot: [[0, 1], [2], [0, 1, 3]],
      status: function (t) {
        if (mode === 1) return '圆轨道 · 匀速圆周运动';
        const d = build(), idx = idxAt(t), bi = d.burnI;
        if (idx < bi[0]) return '低轨圆轨道 · 准备加速';
        if (idx < bi[1]) return '近地点加速 · 转移椭圆';
        if (idx < bi[2]) return '高轨圆轨道 · 远地点加速完成';
        if (idx < bi[3]) return '远地点减速 · 返回椭圆';
        return '回到低轨 · 圆轨道';
      }
    };
  }

  /* ================= 15. 简谐运动（弹簧 / 单摆） ================= */
  function sceneShm() {
    const P = { A: 0.22, m: 1, k: 16, L: 1.0 };
    let mode = 0; // 0 弹簧振子，1 单摆
    const G = 9.8;
    function omega() { return mode === 0 ? sqrt(P.k / max(P.m, 0.01)) : sqrt(G / max(P.L, 0.05)); }
    function period() { return TAU / omega(); }
    function stateAt(t) {
      const w = omega(), ph = w * t;
      if (mode === 0) {
        const x = P.A * cos(ph), v = -P.A * w * sin(ph), a = -w * w * x;
        const KE = 0.5 * P.m * v * v, PE = 0.5 * P.k * x * x;
        return { x: x, v: v, a: a, KE: KE, PE: PE, E: KE + PE, thmax: 0, amp: max(P.A, 1e-6) };
      }
      const thmax = min(rad(32), P.A / max(P.L, 0.1));
      const ang = thmax * cos(ph), wv = -thmax * w * sin(ph);
      const v = wv * P.L;
      const KE = 0.5 * P.m * v * v;
      const PE = P.m * G * P.L * (1 - cos(ang));
      return { ang: ang, v: v, wv: wv, KE: KE, PE: PE, E: KE + PE, thmax: thmax, amp: max(thmax, 1e-6) };
    }
    function coilPx(ctx, x1, x2, y, coils, amp) {
      const span = x2 - x1;
      if (span < 8) return;
      const n = max(4, coils) * 2, step = span / (n + 2);
      ctx.beginPath();
      ctx.moveTo(x1, y); ctx.lineTo(x1 + step, y);
      for (let i = 0; i < n; i++) {
        ctx.lineTo(x1 + step * (i + 1.5), y + (i % 2 ? -amp : amp));
      }
      ctx.lineTo(x2 - step, y); ctx.lineTo(x2, y);
      ctx.stroke();
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'A', label: '振幅 A (m)', min: 0.05, max: 0.35, step: 0.01, dec: 2 },
        { k: 'm', label: '质量 m (kg)', min: 0.5, max: 2, step: 0.1, dec: 1 },
        { k: 'k', label: '劲度系数 k (N/m)', min: 8, max: 30, step: 1, dec: 0 },
        { k: 'L', label: '摆长 L (m)', min: 0.4, max: 1.6, step: 0.05, dec: 2 }
      ],
      chips: [{
        label: '振动模型',
        items: ['弹簧振子', '单摆'],
        index: 0,
        set: function (i) { mode = i; }
      }],
      hints: [
        '简谐运动：回复力与位移成正比、方向相反，F = −kx（或 −mg sinθ）。',
        '动能与势能相互转化，机械能守恒；端点处速度为零、加速度最大。',
        '弹簧周期 T = 2π√(m/k)，单摆小角度周期 T = 2π√(L/g)。'
      ],
      duration: function () { return max(0.6, period()); },
      draw: function (cv, t, lv) {
        if (cv.w < 50) return;
        cv.clear(C.paper);
        const w = cv.w, h = cv.h, ctx = cv.ctx;
        const st = stateAt(t), T = period();
        const leftW = w * 0.63;
        const rightX = w * 0.655, rightW = w * 0.325;
        const energyY = h * 0.10;
        const graphY = h * 0.43, graphH = h * 0.44;
        ctx.save();
        ctx.fillStyle = 'rgba(208,227,255,.18)';
        ctx.fillRect(0, 0, leftW, h);
        ctx.restore();
        /* 参考圆：把简谐运动画成旋转矢量在 x 轴上的投影，填补左上留白 */
        (function () {
          const pr = min(58, h * 0.10), pcx = leftW * 0.21, pcy = h * 0.37;
          const ph = -omega() * t;
          ctx.save();
          ctx.strokeStyle = C.data[2]; ctx.globalAlpha = 0.6; ctx.lineWidth = 1.2; ctx.setLineDash([3, 4]);
          ctx.beginPath(); ctx.arc(pcx, pcy, pr, 0, TAU); ctx.stroke();
          ctx.globalAlpha = 1;
          ctx.setLineDash([]);
          ctx.strokeStyle = C.line2; ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pcx - pr - 6, pcy); ctx.lineTo(pcx + pr + 6, pcy);
          ctx.moveTo(pcx, pcy - pr - 6); ctx.lineTo(pcx, pcy + pr + 6);
          ctx.stroke();
          const X = pcx + cos(ph) * pr, Y = pcy + sin(ph) * pr;
          ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1.8;
          ctx.beginPath(); ctx.moveTo(pcx, pcy); ctx.lineTo(X, Y); ctx.stroke();
          ctx.strokeStyle = C.faint; ctx.setLineDash([3, 4]);
          ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(X, pcy); ctx.stroke();
          ctx.setLineDash([]);
          dotPx(ctx, X, Y, 4, C.accent);
          ctx.restore();
          if (lv >= 1) plabel(cv, pcx, pcy + pr + 14, mode === 0 ? '参考圆 · 投影即 x' : '参考圆 · 投影即 θ', { color: C.faint, size: 9, align: 'center', weight: 500 });
        })();
        if (mode === 0) {
          const floorY = h * 0.68;
          const wallX = w * 0.055;
          const eqX = leftW * 0.58;
          const ampPx = leftW * 0.30;
          const scale = ampPx / max(P.A, 0.02);
          const bx = eqX + st.x * scale;
          ctx.save();
          ctx.strokeStyle = C.line; ctx.lineWidth = 2.2;
          ctx.beginPath(); ctx.moveTo(wallX, floorY); ctx.lineTo(leftW * 0.96, floorY); ctx.stroke();
          ctx.fillStyle = C.data[3]; ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1.2;
          ctx.fillRect(wallX - 10, floorY - h * 0.34, 10, h * 0.34);
          ctx.strokeRect(wallX - 10, floorY - h * 0.34, 10, h * 0.34);
          ctx.restore();
          ctx.save();
          ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
          coilPx(ctx, wallX, bx - 19, floorY - 25, 13, 9);
          ctx.restore();
          ctx.save();
          ctx.fillStyle = C.ink;
          ctx.fillRect(bx - 19, floorY - 44, 38, 38);
          ctx.strokeStyle = C.paper; ctx.lineWidth = 1.5;
          ctx.strokeRect(bx - 19, floorY - 44, 38, 38);
          ctx.fillStyle = onColor(C.ink); ctx.font = '600 11px ' + C.sans;
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText('m', bx, floorY - 25);
          ctx.restore();
          ctx.save();
          ctx.strokeStyle = C.data[3]; ctx.lineWidth = 1; ctx.setLineDash([4, 5]);
          ctx.beginPath(); ctx.moveTo(eqX, floorY - 74); ctx.lineTo(eqX, floorY + 8); ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(eqX - ampPx, floorY + 10); ctx.lineTo(eqX - ampPx, floorY + 16);
          ctx.moveTo(eqX + ampPx, floorY + 10); ctx.lineTo(eqX + ampPx, floorY + 16);
          ctx.stroke();
          ctx.restore();
          plabel(cv, eqX, floorY + 16, '平衡位置', { color: C.faint, size: 9.5, align: 'center', weight: 500 });
          plabel(cv, eqX - ampPx, floorY + 31, '−A', { color: C.soft, size: 9.5, align: 'center' });
          plabel(cv, eqX + ampPx, floorY + 31, '+A', { color: C.soft, size: 9.5, align: 'center' });
          if (lv >= 1) {
            const vmax = P.A * omega();
            const vl = 42 * clamp(st.v / max(vmax, 1e-6), -1, 1);
            pArrow(ctx, bx, floorY - 56, bx + vl, floorY - 56, C.accent, 2, 7);
            plabel(cv, bx + (vl >= 0 ? 6 : -6), floorY - 68, 'v', { color: C.accent, size: 10.5, weight: 700, align: vl >= 0 ? 'left' : 'right' });
            const fl = 38 * clamp(-st.x / max(P.A, 1e-6), -1, 1);
            pArrow(ctx, bx, floorY - 88, bx + fl, floorY - 88, C.jade, 2, 7);
            plabel(cv, bx + (fl >= 0 ? 6 : -6), floorY - 100, 'F', { color: C.jade, size: 10.5, weight: 700, align: fl >= 0 ? 'left' : 'right' });
          }
          if (lv >= 2) {
            const mid = (eqX + bx) / 2;
            ctx.save(); ctx.strokeStyle = C.gold; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
            ctx.beginPath(); ctx.moveTo(eqX, floorY + 44); ctx.lineTo(bx, floorY + 44); ctx.stroke();
            ctx.restore();
            plabel(cv, mid, floorY + 57, 'x = ' + fmt(st.x, 3) + ' m', { color: C.gold, size: 10, align: 'center', weight: 600 });
            tagBox(cv, leftW * 0.48, 18, 'T = 2π√(m/k) = ' + fmt(T, 2) + ' s', C.ink2, 'center');
          }
        } else {
          const pivotX = leftW * 0.58, pivotY = h * 0.19;
          const Lpix = h * 0.40;
          const thmax = st.thmax, ang = st.ang;
          const bx = pivotX + Lpix * sin(ang), by = pivotY + Lpix * cos(ang);
          ctx.save();
          ctx.strokeStyle = C.data[3]; ctx.lineWidth = 1; ctx.setLineDash([4, 5]);
          ctx.beginPath();
          for (let i = 0; i <= 40; i++) {
            const a = -thmax + 2 * thmax * i / 40;
            const X = pivotX + Lpix * sin(a), Y = pivotY + Lpix * cos(a);
            if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y);
          }
          ctx.stroke();
          ctx.restore();
          ctx.save();
          ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.moveTo(pivotX, pivotY); ctx.lineTo(bx, by); ctx.stroke();
          ctx.beginPath(); ctx.arc(pivotX, pivotY, 4, 0, TAU); ctx.fillStyle = C.ink; ctx.fill();
          ctx.restore();
          ctx.save();
          ctx.beginPath(); ctx.arc(bx, by, 17, 0, TAU);
          ctx.fillStyle = C.ink; ctx.fill();
          ctx.strokeStyle = C.paper; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.fillStyle = onColor(C.ink); ctx.font = '600 11px ' + C.sans;
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('m', bx, by);
          ctx.restore();
          plabel(cv, (pivotX + bx) / 2 + 10, (pivotY + by) / 2, 'L = ' + fmt(P.L, 2) + ' m', { color: C.soft, size: 9.5, weight: 500 });
          if (lv >= 1) {
            const tang = Math.sign(st.wv || 1);
            const tx = cos(ang) * tang, ty = -sin(ang) * tang;
            const vl = 46 * clamp(abs(st.v) / max(P.A * omega(), 1e-6), 0, 1);
            pArrow(ctx, bx, by, bx + tx * vl, by + ty * vl, C.accent, 2, 7);
            plabel(cv, bx + tx * (vl + 10), by + ty * (vl + 10), 'v', { color: C.accent, size: 10.5, weight: 700 });
            pArrow(ctx, bx, by, bx, by + 38, C.jade, 1.8, 7);
            plabel(cv, bx + 7, by + 46, 'mg', { color: C.jade, size: 9.5, weight: 600 });
            ctx.save();
            ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.arc(pivotX, pivotY, 34, PI / 2 - thmax, PI / 2 + ang, ang < 0); ctx.stroke();
            ctx.restore();
            plabel(cv, pivotX + 42, pivotY + 30, 'θ', { color: C.data[2], size: 10, weight: 600 });
          }
          if (lv >= 2) {
            plabel(cv, pivotX, pivotY - 12, 'θ = ' + fmt(ang * 180 / PI, 1) + '°', { color: C.gold, size: 10, align: 'center', weight: 600 });
            tagBox(cv, leftW * 0.48, 18, 'T = 2π√(L/g) = ' + fmt(T, 2) + ' s', C.ink2, 'center');
          }
        }
        barsPanel(cv, rightX, energyY, rightW, [
          { label: '动能', text: fmt(st.KE, 2) + ' J', frac: st.E > 1e-9 ? st.KE / st.E : 0, color: C.ink },
          { label: '势能', text: fmt(st.PE, 2) + ' J', frac: st.E > 1e-9 ? st.PE / st.E : 0, color: C.data[2] },
          { label: '机械能', text: fmt(st.E, 2) + ' J', frac: 1, color: C.data[3] }
        ], mode === 0 ? '能量（弹簧）' : '能量（单摆）');
        const gp = framePanel(cv, rightX, graphY, rightW, graphH, mode === 0 ? 'x–t 同步图' : 'θ–t 同步图');
        const midY = gp.y + gp.h * 0.52;
        const ampPx = gp.h * 0.36;
        const ampMax = mode === 0 ? max(P.A, 1e-6) : max(st.thmax, 1e-6);
        ctx.save();
        ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(gp.x, midY); ctx.lineTo(gp.x + gp.w, midY); ctx.stroke();
        ctx.restore();
        const pts = [];
        for (let i = 0; i <= 140; i++) {
          const tp = t - 2 * T + 2 * T * i / 140;
          const pp = stateAt(tp);
          const val = mode === 0 ? pp.x : pp.ang;
          pts.push([gp.x + gp.w * i / 140, midY - val / ampMax * ampPx]);
        }
        pFlow(ctx, pts, C.ink2, [], 0, 1.8, 0.95);
        const cur = mode === 0 ? st.x : st.ang;
        const cy = midY - cur / ampMax * ampPx;
        ctx.save();
        ctx.strokeStyle = C.accent; ctx.lineWidth = 1; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(gp.x + gp.w, gp.y); ctx.lineTo(gp.x + gp.w, gp.y + gp.h); ctx.stroke();
        ctx.restore();
        dotPx(ctx, gp.x + gp.w, cy, 3.8, C.accent);
        plabel(cv, gp.x + 2, midY - ampPx - 5, (mode === 0 ? '+A' : '+θ'), { color: C.faint, size: 8.5, weight: 500 });
        plabel(cv, gp.x + gp.w - 2, gp.y + gp.h - 5, '-2T', { color: C.faint, size: 8.5, align: 'right', weight: 500 });
        plabel(cv, gp.x + gp.w - 2, gp.y + 2, '现在', { color: C.accent, size: 8.5, align: 'right', weight: 500 });
        if (lv >= 2) {
          const txt = mode === 0 ? 'x = A cos(ωt)' : 'θ = θ₀ cos(ωt)';
          plabel(cv, gp.x + 2, gp.y + gp.h - 5, txt, { color: C.soft, size: 9, weight: 500 });
        }
      },
      readouts: function (t) {
        const st = stateAt(t);
        return [
          { label: '周期 T', value: fmt(period(), 2), unit: 's' },
          mode === 0
            ? { label: '位移 x', value: fmt(st.x, 3), unit: 'm' }
            : { label: '角位移 θ', value: fmt(st.ang * 180 / PI, 1), unit: '°' },
          { label: '速度 v', value: fmt(st.v, 2), unit: 'm/s' },
          { label: '机械能 E', value: fmt(st.E, 2), unit: 'J' }
        ];
      },
      hot: [[0, 2], [1], [0, 1, 2, 3]],
      status: function (t) {
        const st = stateAt(t);
        const edge = mode === 0 ? abs(st.x) > P.A * 0.96 : abs(st.ang) > st.thmax * 0.96;
        if (edge) return '端点 · 速度为零、回复力最大';
        const right = mode === 0 ? st.v > 0 : st.wv > 0;
        const accel = mode === 0 ? st.v * st.a > 0 : (st.v * -st.ang > 0);
        return (right ? '向右' : '向左') + (accel ? ' · 加速' : ' · 减速') + ' · 平衡位置附近最快';
      }
    };
  }

  /* ================= 16. 凸透镜成像 ================= */
  function sceneLens() {
    const P = { f: 0.55, h: 0.3, u: 1.3 };
    const T = 8;
    function uNow(t) { return max(0.18, P.u * (1 + 0.15 * sin(TAU * t / T))); }
    function optics(u) {
      const f = max(P.f, 0.15);
      const near = abs(u - f) < 0.035;
      const v = near ? Infinity : u * f / (u - f);
      return { u: u, f: f, v: v, near: near, m: near ? Infinity : -v / u, hi: near ? 0 : -v / u * P.h };
    }
    function rayPath(cv, pts, color, dash, width) {
      worldPath(cv, pts, { color: color, width: width || 1.3, dash: dash });
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'u', label: '物距 u (m)', min: 0.3, max: 2.6, step: 0.05, dec: 2 },
        { k: 'f', label: '焦距 f (m)', min: 0.3, max: 1, step: 0.05, dec: 2 },
        { k: 'h', label: '物高 h (m)', min: 0.15, max: 0.5, step: 0.01, dec: 2 }
      ],
      hints: [
        '凸透镜三条特殊光线：平行主轴的光线过焦点，过光心的光线不改变方向，过焦点的光线出射后平行主轴。',
        '成像公式 1/f = 1/u + 1/v，放大率 m = −v/u（实像倒立、虚像正立）。',
        'u > f 成倒立实像；u < f 成正立放大虚像，光屏接不到，只能透过透镜看到。'
      ],
      duration: function () { return T; },
      draw: function (cv, t, lv) {
        if (cv.w < 50) return;
        cv.clear(C.paper);
        const u = uNow(t), o = optics(u), f = o.f, h = P.h;
        const vShow = o.near ? 0 : clamp(o.v, -6.5, 6.5);
        const far = !o.near && (abs(o.v) > 6.5 || abs(o.hi) > 3.2);
        const y3 = o.near ? h : clamp(h * f / (f - u), -1.4, 1.4);
        const a = clamp(max(abs(y3), h * 1.25, 0.42), 0.42, 1.4);
        let xL = min(-u * 1.18, -f * 1.35) - 0.15;
        let xR = max(0.8, f * 1.45, P.h * 1.2);
        if (!o.near && o.v > 0 && !far) xR = max(xR, o.v * 1.10);
        if (!o.near && o.v < 0 && !far) xL = min(xL, o.v * 1.12);
        const yH = max(a * 1.10, h * 1.12, 0.40, (!far && !o.near && o.v < 0 ? abs(o.hi) * 1.06 : 0));
        viewRect(cv, xL, xR, -yH, yH, 0.02, true);
        cv.grid(0.2, { grid: C.grid2, axis: C.faint, labels: false });
        const ctx = cv.ctx;
        cv.line(cv.xr[0], 0, cv.xr[1], 0, { color: C.line, width: 1.6 });
        label(cv, cv.xr[0], 0, '主光轴', { color: C.faint, size: 9, ox: 8, oy: -8, weight: 500 });
        const lx = cv.px(0), top = cv.py(a), bot = cv.py(-a), bulge = clamp(cv.sx() * 0.09, 8, 22);
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(lx, top);
        ctx.quadraticCurveTo(lx + bulge, cv.py(0), lx, bot);
        ctx.quadraticCurveTo(lx - bulge, cv.py(0), lx, top);
        ctx.closePath();
        ctx.fillStyle = 'rgba(208,227,255,.52)';
        ctx.fill();
        ctx.strokeStyle = C.data[2]; ctx.lineWidth = 1.6; ctx.stroke();
        ctx.restore();
        [[-f, 'F'], [f, "F′"]].forEach(function (it) {
          const X = cv.px(it[0]);
          ctx.save();
          ctx.strokeStyle = C.faint; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(X, cv.py(0) - 4); ctx.lineTo(X, cv.py(0) + 4); ctx.stroke();
          ctx.restore();
          plabel(cv, X, cv.py(0) + 14, it[1], { color: C.soft, size: 9.5, align: 'center', weight: 600 });
        });
        const xEnd = cv.xr[1] - 0.02;
        const ray1 = [[-u, h], [0, h], [xEnd, h - h * xEnd / f]];
        const ray2 = [[-u, h], [0, 0], [xEnd, -h * xEnd / u]];
        rayPath(cv, ray1, C.data[2], null, 1.35);
        rayPath(cv, ray2, C.jade, null, 1.25);
        if (!o.near) {
          const ray3 = [[-u, h], [0, y3], [xEnd, y3]];
          rayPath(cv, ray3, C.gold, null, 1.1);
        }
        if (lv >= 2 && !o.near && !far && o.v < 0) {
          rayPath(cv, [[0, h], [vShow, o.hi]], C.data[2], [4, 4], 1);
          rayPath(cv, [[0, 0], [vShow, o.hi]], C.jade, [4, 4], 1);
          if (lv >= 1) rayPath(cv, [[0, y3], [vShow, y3]], C.gold, [4, 4], 1);
        }
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(cv.px(-u), cv.py(0));
        ctx.lineTo(cv.px(-u), cv.py(h));
        ctx.strokeStyle = C.accent; ctx.lineWidth = 2.4; ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cv.px(-u) - 5, cv.py(h) + 7);
        ctx.lineTo(cv.px(-u), cv.py(h));
        ctx.lineTo(cv.px(-u) + 5, cv.py(h) + 7);
        ctx.stroke();
        ctx.restore();
        plabel(cv, cv.px(-u) + 8, cv.py(h) - 8, '物', { color: C.accent, size: 10, weight: 700 });
        if (!o.near && !far) {
          const isReal = o.v > 0;
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(cv.px(vShow), cv.py(0));
          ctx.lineTo(cv.px(vShow), cv.py(o.hi));
          ctx.strokeStyle = isReal ? C.jade : C.gold;
          ctx.lineWidth = 2.2;
          if (!isReal) ctx.setLineDash([5, 4]);
          ctx.stroke();
          const dir = o.hi >= 0 ? 1 : -1;
          ctx.beginPath();
          ctx.moveTo(cv.px(vShow) - 5, cv.py(o.hi) + dir * 7);
          ctx.lineTo(cv.px(vShow), cv.py(o.hi));
          ctx.lineTo(cv.px(vShow) + 5, cv.py(o.hi) + dir * 7);
          ctx.stroke();
          ctx.restore();
          const ix = cv.px(vShow);
          const rightSide = ix > cv.w * 0.74, leftSide = ix < cv.w * 0.24;
          const labelY = leftSide && !isReal ? cv.py(o.hi * 0.55) : cv.py(o.hi) + (o.hi >= 0 ? -9 : 15);
          plabel(cv, ix + (rightSide ? -8 : 8), labelY, isReal ? '实像' : '虚像',
            { color: isReal ? C.jade : C.gold, size: 10, weight: 700, align: rightSide ? 'right' : 'left' });
        }
        if (o.near) {
          tagBox(cv, cv.w * 0.5, cv.h * 0.38, 'u ≈ f：像在无穷远', C.accent, 'center');
        } else if (far) {
          tagBox(cv, cv.w * 0.5, cv.h * 0.38, '像距超过 6 m（示意截断）', C.soft, 'center');
        }
        const p1 = pathTable(ray1), p2 = pathTable(ray2);
        const ph = (t / 2.2) % 1;
        const q1 = pathPoint(ray1, p1, ph), q2 = pathPoint(ray2, p2, (ph + 0.45) % 1);
        dot(cv, q1[0], q1[1], 3.4, C.accent, C.paper, 1);
        dot(cv, q2[0], q2[1], 3.4, C.ink2, C.paper, 1);
        if (lv >= 1) {
          tagBox(cv, cv.w * 0.5, 18, '平行光 → 过焦点　过光心 → 不偏折', C.ink2, 'center');
        }
        const px0 = 14, py0 = cv.h - 146, pw0 = min(322, cv.w * 0.46), ph0 = 88;
        const lp = framePanel(cv, px0, py0, pw0, ph0, '凸透镜成像');
        if (lv === 0) {
          plabel(cv, px0 + 10, lp.y + 3, 'u = ' + fmt(u, 2) + ' m　v = ' + (o.near ? '∞' : fmt(abs(o.v), 2) + ' m'),
            { color: C.ink, size: 10.5, weight: 600 });
          plabel(cv, px0 + 10, lp.y + 21, '改变物距，物与像同步移动', { color: C.soft, size: 10 });
          plabel(cv, px0 + 10, lp.y + 39, 'u > f 成实像；u < f 成虚像', { color: C.accent, size: 10 });
        } else if (lv === 1) {
          plabel(cv, px0 + 10, lp.y + 2, '① 平行主轴 → 过 F′', { color: C.data[2], size: 10 });
          plabel(cv, px0 + 10, lp.y + 19, '② 过光心 → 方向不变', { color: C.jade, size: 10 });
          plabel(cv, px0 + 10, lp.y + 36, '③ 过 F → 出射平行主轴', { color: C.gold, size: 10 });
          plabel(cv, px0 + 10, lp.y + 53, 'u = ' + fmt(u, 2) + ' m　v = ' + (o.near ? '∞' : fmt(abs(o.v), 2) + ' m'),
            { color: C.ink2, size: 10, weight: 600 });
        } else {
          plabel(cv, px0 + 10, lp.y + 2, '1/f = 1/u + 1/v　m = −v/u',
            { color: C.ink, size: 10.5, weight: 600 });
          plabel(cv, px0 + 10, lp.y + 20, 'u = ' + fmt(u, 2) + ' m　v = ' + (o.near ? '∞' : fmt(abs(o.v), 2) + ' m'),
            { color: C.ink2, size: 10 });
          plabel(cv, px0 + 10, lp.y + 38, '|m| = ' + (o.near ? '—' : fmt(abs(o.v) / u, 2)) +
            '　' + (o.near ? '不成像' : o.v > 0 ? '倒立实像' : '正立放大虚像'),
            { color: C.accent, size: 10 });
          plabel(cv, px0 + 10, lp.y + 56, '三条特殊光线决定像的位置', { color: C.soft, size: 9.5 });
        }
      },
      readouts: function (t) {
        const u = uNow(t), o = optics(u);
        return [
          { label: '物距 u', value: fmt(u, 2), unit: 'm' },
          { label: '像距 v', value: o.near ? '∞' : fmt(abs(o.v), 2), unit: o.near ? '' : 'm' },
          { label: '放大率 |m|', value: o.near ? '—' : fmt(abs(o.v) / u, 2), unit: '' },
          { label: '像的性质', value: o.near ? '不成像' : (o.v > 0 ? '倒立实像' : '正立虚像'), unit: '' }
        ];
      },
      hot: [[0, 1], [2], [3]],
      status: function (t) {
        const u = uNow(t), o = optics(u);
        if (o.near) return '物距 ≈ 焦距 · 折射光近似平行';
        if (o.v > 0) return 'u > f · 倒立' + (abs(o.v) > u ? '放大' : '缩小') + '实像';
        return 'u < f · 正立放大虚像';
      }
    };
  }

  /* ================= 17. 双缝干涉 ================= */
  function sceneInterference() {
    const P = { lam: 550, d: 0.4, L: 1.2 };
    function colorOf(nm) {
      const hue = 270 - 270 * clamp((nm - 380) / 320, 0, 1);
      return 'hsl(' + hue.toFixed(0) + ',72%,46%)';
    }
    function spacingMm() {
      return (P.lam * 1e-9) * P.L / (P.d * 1e-3) * 1000;
    }
    function intensityAt(mm) {
      return Math.pow(cos(PI * P.d * mm * 1000 / (max(P.L, 0.1) * P.lam)), 2);
    }
    return {
      P: P,
      oneShot: false,
      sliders: [
        { k: 'lam', label: '波长 λ (nm)', min: 400, max: 700, step: 5, dec: 0 },
        { k: 'd', label: '双缝间距 d (mm)', min: 0.15, max: 0.8, step: 0.01, dec: 2 },
        { k: 'L', label: '缝到屏距离 L (m)', min: 0.8, max: 2, step: 0.05, dec: 2 }
      ],
      hints: [
        '双缝把同一束光分成两列相干光，屏上某点的光程差决定加强与减弱。',
        '亮纹条件 Δ = d sinθ = kλ；近轴时条纹间距 Δy = λL/d。',
        '缝距越小、波长越长，条纹越稀疏；光强按 cos²(πd y/λL) 分布。'
      ],
      duration: function () { return 4; },
      draw: function (cv, t, lv) {
        if (cv.w < 60) return;
        cv.clear(C.paper);
        const w = cv.w, h = cv.h, ctx = cv.ctx;
        const top = h * 0.11, bot = h * 0.83, y0 = (top + bot) / 2;
        const srcX = w * 0.07, barX = w * 0.34, scrX = w * 0.845;
        const gap = 18 + 24 * clamp((P.d - 0.15) / 0.65, 0, 1);
        const c1 = y0 - gap / 2, c2 = y0 + gap / 2;
        const color = colorOf(P.lam);
        const maxR = scrX - barX + 8;
        const lamPx = 14 + 12 * clamp((P.lam - 400) / 300, 0, 1);
        const phase = (t * 34) % lamPx;
        ctx.save();
        for (let k = 0; k < 16; k++) {
          const rr = phase + k * lamPx;
          if (rr > maxR || rr < 3) continue;
          const alpha = (lv >= 1 ? 0.30 : 0.12) * (1 - rr / maxR);
          ctx.globalAlpha = alpha;
          ctx.strokeStyle = color;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(barX, c1, rr, -PI / 2, PI / 2); ctx.stroke();
          ctx.beginPath(); ctx.arc(barX, c2, rr, -PI / 2, PI / 2); ctx.stroke();
        }
        ctx.restore();
        ctx.save();
        ctx.strokeStyle = C.ink2; ctx.lineWidth = 2.6; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(barX, top); ctx.lineTo(barX, c1 - 3);
        ctx.moveTo(barX, c1 + 3); ctx.lineTo(barX, c2 - 3);
        ctx.moveTo(barX, c2 + 3); ctx.lineTo(barX, bot);
        ctx.stroke();
        ctx.restore();
        plabel(cv, barX - 14, c1, 'S₁', { color: C.ink2, size: 10, align: 'right', weight: 700 });
        plabel(cv, barX - 14, c2, 'S₂', { color: C.ink2, size: 10, align: 'right', weight: 700 });
        plabel(cv, barX - 14, (c1 + c2) / 2 + 2, 'd', { color: C.soft, size: 9.5, align: 'right', weight: 600 });
        ctx.save();
        ctx.strokeStyle = C.soft; ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(barX - 8, c1); ctx.lineTo(barX - 8, c2);
        ctx.moveTo(barX - 11, c1); ctx.lineTo(barX - 5, c1);
        ctx.moveTo(barX - 11, c2); ctx.lineTo(barX - 5, c2);
        ctx.stroke();
        ctx.restore();
        ctx.save();
        ctx.fillStyle = '#0B1836';
        ctx.fillRect(scrX - 8, top, 16, bot - top);
        ctx.restore();
        const yMax = 8;
        for (let Y = top; Y < bot; Y += 2) {
          const mm = (0.5 - (Y - top) / (bot - top)) * 2 * yMax;
          const I = intensityAt(mm);
          ctx.save();
          ctx.globalAlpha = 0.1 + 0.9 * I;
          ctx.fillStyle = color;
          ctx.fillRect(scrX - 7, Y, 14, 2.1);
          ctx.restore();
        }
        ctx.save();
        ctx.strokeStyle = C.line2; ctx.lineWidth = 1;
        ctx.strokeRect(scrX - 8, top, 16, bot - top);
        ctx.restore();
        plabel(cv, scrX, top - 9, '光屏', { color: C.soft, size: 9.5, align: 'center', weight: 600 });
        ctx.save();
        ctx.strokeStyle = C.faint; ctx.lineWidth = 1; ctx.setLineDash([3, 5]);
        ctx.beginPath(); ctx.moveTo(barX, y0); ctx.lineTo(scrX - 10, y0); ctx.stroke();
        ctx.restore();
        const curve = [];
        for (let i = 0; i <= 90; i++) {
          const Y = top + (bot - top) * i / 90;
          const mm = (0.5 - (Y - top) / (bot - top)) * 2 * yMax;
          const I = intensityAt(mm);
          curve.push([scrX - 24 - I * 44, Y]);
        }
        pFlow(ctx, curve, color, [], 0, 1.5, lv >= 1 ? 0.9 : 0.55);
        if (lv >= 1) {
          for (let i = 0; i < curve.length; i += 6) {
            ctx.save();
            ctx.globalAlpha = 0.12;
            ctx.strokeStyle = color; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(curve[i][0], curve[i][1]); ctx.lineTo(scrX - 24, curve[i][1]); ctx.stroke();
            ctx.restore();
          }
          plabel(cv, scrX - 26, top - 9, 'I', { color: color, size: 10, align: 'right', weight: 700 });
          plabel(cv, barX + 8, y0 - 10, '中央亮纹', { color: C.soft, size: 9.5, weight: 500 });
        }
        const probeY = y0 + sin(TAU * t / 4) * (bot - top) * 0.40;
        const probeMm = (0.5 - (probeY - top) / (bot - top)) * 2 * yMax;
        ctx.save();
        ctx.strokeStyle = C.accent; ctx.lineWidth = 1; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(scrX + 10, probeY); ctx.lineTo(scrX + 28, probeY); ctx.stroke();
        ctx.restore();
        dotPx(ctx, scrX + 32, probeY, 3.2, C.accent);
        if (lv >= 2) tagBox(cv, cv.w * 0.5, 18, 'Δy = λL/d = ' + fmt(spacingMm(), 2) + ' mm', C.ink2, 'center');
        if (lv >= 2) {
          const dyPx = spacingMm() / (2 * yMax) * (bot - top);
          if (dyPx > 5 && dyPx < (bot - top) * 0.5) {
            ctx.save();
            ctx.strokeStyle = C.accent; ctx.lineWidth = 1;
            const xMark = scrX - 78;
            ctx.beginPath();
            ctx.moveTo(xMark, y0); ctx.lineTo(xMark, y0 + dyPx);
            ctx.moveTo(xMark - 4, y0); ctx.lineTo(xMark + 4, y0);
            ctx.moveTo(xMark - 4, y0 + dyPx); ctx.lineTo(xMark + 4, y0 + dyPx);
            ctx.stroke();
            ctx.restore();
            plabel(cv, xMark - 5, y0 + dyPx / 2, 'Δy', { color: C.accent, size: 9, align: 'right', weight: 600 });
          }
        }
        if (lv === 0) {
          plabel(cv, 14, cv.h - 20, '扫描点：' + (intensityAt(probeMm) > 0.5 ? '亮纹' : '暗纹'),
            { color: C.soft, size: 9.5, weight: 500 });
        } else {
          plabel(cv, 14, cv.h - 20, 'λ = ' + fmt(P.lam, 0) + ' nm　d = ' + fmt(P.d, 2) + ' mm　I = ' +
            fmt(intensityAt(probeMm), 2), { color: C.soft, size: 9.5, weight: 500 });
        }
        if (lv >= 2) {
          tagBox(cv, 14, h - 44, '亮纹：Δ = kλ　暗纹：Δ = (k+½)λ', C.soft);
        }
        ctx.save();
        ctx.fillStyle = C.accent;
        roundRect(ctx, srcX - 11, y0 - 9, 22, 18, 2); ctx.fill();
        plabel(cv, srcX, y0 + 21, '单色光源', { color: C.soft, size: 9.5, align: 'center', weight: 500 });
        ctx.restore();
        pArrow(ctx, srcX + 13, y0, barX - 6, y0, color, 1.4, 6);
      },
      readouts: function () {
        return [
          { label: '波长 λ', value: fmt(P.lam, 0), unit: 'nm' },
          { label: '双缝间距 d', value: fmt(P.d, 2), unit: 'mm' },
          { label: '条纹间距 Δy', value: fmt(spacingMm(), 2), unit: 'mm' },
          { label: '缝屏距离 L', value: fmt(P.L, 2), unit: 'm' }
        ];
      },
      hot: [[2], [0, 1], [0, 1, 2, 3]],
      status: function (t) {
        const mm = -6.4 * sin(TAU * t / 4);
        const I = intensityAt(mm);
        return '双缝干涉 · 扫描点' + (I > 0.5 ? '亮纹' : '暗纹') + ' · I = ' + fmt(I, 2);
      }
    };
  }

  const SCENES = {
    projectile: sceneProjectile,
    incline: sceneIncline,
    spring: sceneSpring,
    circular: sceneCircular,
    wave: sceneWave,
    optics: sceneOptics,
    circuit: sceneCircuit,
    efield: sceneEfield,
    collision: sceneCollision,
    gravity: sceneGravity,
    efield2: sceneEfield2,
    magnet: sceneMagnet,
    induction: sceneInduction,
    gravity2: sceneGravity2,
    shm: sceneShm,
    lens: sceneLens,
    interference: sceneInterference
  };

  /* ================= 参数注入 ================= */
  function applyParams(scene, src) {
    src = src || {};
    Object.keys(scene.P).forEach(function (k) {
      const v = Number(src[k]);
      if (isFinite(v)) scene.P[k] = v;
    });
    if (typeof scene.aux === 'function') scene.aux(src);
    (scene.sliders || []).forEach(function (s) {
      let v = Number(scene.P[s.k]);
      if (!isFinite(v)) v = s.min;
      scene.P[s.k] = v;
      // 题目给的参数可能落在滑块量程外：向两侧扩量程并留出调节余量
      if (v < s.min) s.min = v >= 0 ? v * 0.6 : v * 1.6;
      if (v > s.max) s.max = v >= 0 ? v * 1.6 : v * 0.6;
      if (!(s.max > s.min)) { s.min = v - 1; s.max = v + 1; }
    });
    if (scene.P.g) scene.P.g = clamp(scene.P.g, 1, 20);
  }

  /* ================= 挂载 ================= */
  function mount(host, q, api) {
    let scene;
    try {
      const view = (q && q.view) || {};
      const kind = SCENES[view.kind] ? view.kind : 'projectile';
      scene = SCENES[kind]();
      scene.kind = kind;
      applyParams(scene, view.params);
      build(host, q, api, scene, view);
    } catch (err) {
      host.innerHTML = '';
      host.appendChild(el('div', { class: 'jw-card', style: 'margin:16px' },
        '<div class="jw-card-h"><h3>物理视图暂时无法加载</h3><div class="jw-card-sub">' +
        (err && err.message ? err.message : '未知错误') + '</div></div>'));
      return {
        applyStep: function () { },
        destroy: function () { host.innerHTML = ''; }
      };
    }
    return scene._handle;
  }

  function build(host, q, api, scene, view) {
    host.innerHTML = '';
    const root = el('div', { class: 'ph-root jw-stage-grid' });
    const plot = el('div', { class: 'jw-plot ph-plot' });
    const ctrl = el('div', { class: 'jw-ctrl ph-ctrl' });
    if (scene.drag) plot.classList.add('ph-drag');
    root.appendChild(plot);
    root.appendChild(ctrl);
    host.appendChild(root);

    const cv = JW.Canvas(plot, { xRange: [-6, 6], yRange: [-4, 4] });
    const hud = el('div', { class: 'ph-hud' }, 't = 0.00 s');
    const hud2 = el('div', { class: 'ph-hud ph-hud-r' }, '状态：—');
    plot.appendChild(hud);
    plot.appendChild(hud2);

    const tl = el('div', { class: 'ph-tl' });
    const track = el('div', { class: 'ph-tl-track' });
    const fill = el('div', { class: 'ph-tl-fill' });
    const knob = el('div', { class: 'ph-tl-knob' });
    const cap = el('div', { class: 'ph-tl-cap' }, '0.00 / 0.00 s');
    track.appendChild(fill);
    track.appendChild(knob);
    tl.appendChild(track);
    tl.appendChild(cap);
    plot.appendChild(tl);

    if (view && view.cue) {
      ctrl.appendChild(el('div', { class: 'ph-cue' }, '求：' + view.cue));
    }

    const row1 = el('div', { class: 'ph-row' });
    const playBtn = el('button', { class: 'jw-btn jw-btn-solid ph-play' }, '暂停');
    const resetBtn = el('button', { class: 'jw-btn ph-reset' }, '重置');
    row1.appendChild(playBtn);
    row1.appendChild(resetBtn);
    ctrl.appendChild(row1);

    const row2 = el('div', { class: 'ph-row' });
    const slowBtn = el('button', { class: 'jw-chip ph-slow' }, '慢放 ×0.5');
    row2.appendChild(slowBtn);
    ctrl.appendChild(row2);
    ctrl.appendChild(el('div', { class: 'ph-ctl-note' }, '拖动时间轴回看 · 空格键暂停/播放'));

    ctrl.appendChild(el('div', { class: 'jw-sec' }, '参数'));
    scene.sliders.forEach(function (s) {
      const r = JW.ui.range({
        label: s.label, min: s.min, max: s.max, step: s.step,
        value: scene.P[s.k], dec: s.dec
      }, function (v) {
        scene.P[s.k] = v;
        onParam();
      });
      ctrl.appendChild(r);
    });

    if (scene.chips && scene.chips.length) {
      scene.chips.forEach(function (c) {
        ctrl.appendChild(el('div', { class: 'jw-sec' }, c.label));
        const row = JW.ui.chips(c.items, c.items[c.index], function (text) {
          const i = c.items.indexOf(text);
          if (i < 0) return;
          c.index = i;
          c.set(i);
          t = 0;
          acc = 0;
          last = 0;
          render();
        });
        ctrl.appendChild(row);
      });
    }

    ctrl.appendChild(el('div', { class: 'jw-sec' }, '读数'));
    const statsBox = el('div', { class: 'ph-stats' });
    ctrl.appendChild(statsBox);

    let t = 0, T = 4, lv = 0, playing = true, speed = 1;
    let last = 0, acc = 0, raf = 0, alive = true;
    let dragging = false, wasPlaying = false, dragCanvas = false;

    let statNodes = [];
    function readRows() {
      try { return scene.readouts(t, lv) || []; } catch (e) { return []; }
    }
    function buildStats() {
      statsBox.innerHTML = '';
      const rows = readRows();
      rows.forEach(function (r) {
        const n = JW.ui.stat(r.label, r.value, r.unit);
        n.className += ' ph-stat';
        statsBox.appendChild(n);
      });
      statNodes = Array.prototype.slice.call(statsBox.children);
    }

    function dur() {
      let d = 0;
      try { d = scene.duration(); } catch (e) { d = 4; }
      return isFinite(d) && d > 0 ? clamp(d, 0.2, 120) : 4;
    }
    function applyHot() {
      const arr = (scene.hot && scene.hot[clamp(lv, 0, 2)]) || [];
      statNodes.forEach(function (n, i) {
        n.classList.toggle('ph-hot', arr.indexOf(i) >= 0);
      });
    }
    function updateStats(full) {
      let rows = readRows();
      if (full || rows.length !== statNodes.length) { buildStats(); rows = readRows(); }
      rows.forEach(function (r, i) {
        const n = statNodes[i];
        if (!n) return;
        const l = n.querySelector('.jw-stat-l');
        if (l) l.textContent = r.label;
        const v = n.querySelector('.jw-stat-v');
        if (v) v.textContent = r.value;
        const u = n.querySelector('.jw-stat-u');
        if (u) u.textContent = r.unit || '';
      });
      applyHot();
    }
    function syncPlay() {
      if (playing) playBtn.textContent = '暂停';
      else if (scene.oneShot && t >= T - 1e-4) playBtn.textContent = '重放';
      else playBtn.textContent = '播放';
    }
    function render() {
      if (!alive || !cv.w || cv.w < 24 || !cv.h || cv.h < 24) return;
      T = dur();
      if (scene.oneShot) t = min(t, T);
      else t = ((t % T) + T) % T;
      try {
        scene.draw(cv, t, lv);
      } catch (e) {
        cv.clear(C.paper);
        plabel(cv, 22, 46, '绘制异常：' + (e && e.message ? e.message : e), { color: C.accent, size: 12 });
        if (window.console) console.warn('[physics] draw', e);
      }
      hud.textContent = 't = ' + t.toFixed(2) + ' s';
      try { hud2.textContent = '状态：' + scene.status(t); } catch (e) { hud2.textContent = '状态：—'; }
      const f = T > 0 ? clamp(t / T, 0, 1) : 0;
      fill.style.width = (f * 100).toFixed(2) + '%';
      knob.style.left = (f * 100).toFixed(2) + '%';
      cap.textContent = t.toFixed(2) + ' / ' + T.toFixed(2) + ' s';
      updateStats(false);
      syncPlay();
    }
    function onParam() {
      T = dur();
      if (scene.oneShot) t = min(t, T);
      else t = ((t % T) + T) % T;
      acc = 0;
      render();
    }
    function loop(now) {
      if (!alive) return;
      raf = window.requestAnimationFrame(loop);
      if (!last) last = now;
      let dt = (now - last) / 1000;
      last = now;
      if (!isFinite(dt) || dt < 0) dt = 0;
      if (dt > 0.12) dt = 0.12;
      if (!playing) return;
      acc += dt * speed;
      let n = 0;
      while (acc >= DT && n < 60) {
        acc -= DT;
        n++;
        t += DT;
        if (t >= T) {
          if (scene.oneShot) { t = T; playing = false; acc = 0; break; }
          t -= T;
        }
      }
      render();
    }
    playBtn.addEventListener('click', function () {
      if (playing) {
        playing = false;
      } else {
        if (scene.oneShot && t >= T - 1e-4) t = 0;
        playing = true;
        last = 0;
        acc = 0;
      }
      render();
    });
    resetBtn.addEventListener('click', function () {
      t = 0;
      acc = 0;
      last = 0;
      render();
    });
    slowBtn.addEventListener('click', function () {
      speed = speed === 1 ? 0.5 : 1;
      slowBtn.classList.toggle('is-on', speed === 0.5);
    });

    /* 时间轴：自己处理 pointer，避免 setPointerCapture 失败时拖不动 */
    function seekFraction(f) {
      T = dur();
      t = clamp(f, 0, 1) * T;
      acc = 0;
      render();
    }
    function trackFraction(e) {
      const r = track.getBoundingClientRect();
      return clamp((e.clientX - r.left) / max(1, r.width), 0, 1);
    }
    function trackDown(e) {
      if (e.button != null && e.button !== 0) return;
      e.preventDefault();
      dragging = true;
      wasPlaying = playing;
      playing = false;
      try { track.setPointerCapture(e.pointerId); } catch (err) { }
      seekFraction(trackFraction(e));
    }
    function winMove(e) {
      if (!dragging) return;
      e.preventDefault();
      seekFraction(trackFraction(e));
    }
    function winUp() {
      if (!dragging) return;
      dragging = false;
      if (wasPlaying) { playing = true; last = 0; acc = 0; }
      render();
    }
    track.addEventListener('pointerdown', trackDown);
    window.addEventListener('pointermove', winMove, { passive: false });
    window.addEventListener('pointerup', winUp);
    window.addEventListener('pointercancel', winUp);

    /* 画面内的可拖动对象（电场电荷） */
    function canvasPos(e) {
      const r = cv.cv.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }
    function canvasDown(e) {
      if (!scene.drag || (e.button != null && e.button !== 0)) return;
      e.preventDefault();
      dragCanvas = true;
      const p = canvasPos(e);
      scene.drag('down', cv.dx(p.x), cv.dy(p.y));
      try { cv.cv.setPointerCapture(e.pointerId); } catch (err) { }
    }
    function canvasMove(e) {
      if (!dragCanvas) return;
      e.preventDefault();
      const p = canvasPos(e);
      scene.drag('move', cv.dx(p.x), cv.dy(p.y));
      render();
    }
    function canvasUp() {
      if (!dragCanvas) return;
      dragCanvas = false;
      if (scene.drag) scene.drag('up', 0, 0);
      render();
    }
    if (scene.drag) {
      cv.cv.addEventListener('pointerdown', canvasDown);
      window.addEventListener('pointermove', canvasMove, { passive: false });
      window.addEventListener('pointerup', canvasUp);
      window.addEventListener('pointercancel', canvasUp);
    }

    function applyStep(i) {
      lv = clamp(i | 0, 0, 2);
      if (api && api.hint) { try { api.hint((scene.hints && scene.hints[lv]) || ''); } catch (e) { } }
      updateStats(true);
      render();
    }

    buildStats();
    applyStep(lv);
    cv.render = function () { render(); };
    raf = window.requestAnimationFrame(loop);
    render();

    scene._handle = {
      applyStep: applyStep,
      setTime: function (tt) {
        T = dur();
        t = clamp(Number(tt) || 0, 0, T);
        playing = false;
        acc = 0;
        last = 0;
        render();
        return t;
      },
      getTime: function () { return t; },
      getDuration: dur,
      getSpeed: function () { return speed; },
      isPlaying: function () { return playing; },
      /* 无头测试用：按当前播放速度推进固定时长（与 rAF 循环同一套积分） */
      advance: function (sec) {
        if (!alive || !playing) return t;
        T = dur();
        const total = max(0, Number(sec) || 0) * speed;
        let steps = min(4000, Math.round(total / DT));
        while (steps-- > 0) {
          t += DT;
          if (t >= T) {
            if (scene.oneShot) { t = T; playing = false; break; }
            t -= T;
          }
        }
        render();
        return t;
      },
      kind: scene.kind,
      destroy: function () {
        alive = false;
        if (raf) window.cancelAnimationFrame(raf);
        cv.render = null;
        track.removeEventListener('pointerdown', trackDown);
        window.removeEventListener('pointermove', winMove);
        window.removeEventListener('pointerup', winUp);
        window.removeEventListener('pointercancel', winUp);
        if (scene.drag) {
          cv.cv.removeEventListener('pointerdown', canvasDown);
          window.removeEventListener('pointermove', canvasMove);
          window.removeEventListener('pointerup', canvasUp);
          window.removeEventListener('pointercancel', canvasUp);
        }
        host.innerHTML = '';
      }
    };
  }

  JW.registerView('physics', function (host, q, api) {
    return mount(host, q, api);
  });
})();
