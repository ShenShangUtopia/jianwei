/* 见微 · 析题台 · 立体几何引擎（solid）
   真 3D：自写 透视/正交投影 + 画家算法（面按深度排序），canvas 2D 绘制。
   契约：JW.registerView('solid', mount)；mount(host, q, api) -> { applyStep(i), destroy() }
   q.view = { engine:'solid', shape, size, marks, ask, cue, section:{through:[...]} }
   无外部库、无网络、无 ES module，file:// 直接可用。 */
(function () {
  'use strict';
  const JW = window.JW;
  if (!JW || !JW.C || !JW.registerView) return;
  const C = JW.C, el = JW.el, clamp = JW.clamp, num = JW.num, fx = JW.fx;
  const TAU = Math.PI * 2, DEG = 180 / Math.PI;

  /* ================= 向量 ================= */
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const vlen = a => Math.sqrt(dot(a, a));
  const unit = a => { const l = vlen(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const mid = (a, b) => mul(add(a, b), .5);
  const dist = (a, b) => vlen(sub(a, b));
  const mean = list => mul(list.reduce((s, p) => add(s, p), [0, 0, 0]), 1 / (list.length || 1));

  /* ================= 名称 ================= */
  const SUBD = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };
  const UNS = { '₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4', '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9' };
  const subTxt = s => String(s).replace(/[0-9]/g, d => SUBD[d]);
  const normName = s => String(s == null ? '' : s).trim().replace(/[₀-₉]/g, c => UNS[c] || c);

  /* ================= 形状参数 ================= */
  const SHAPES = ['cube', 'cuboid', 'prism', 'pyramid', 'cylinder', 'cone', 'sphere', 'frustum'];
  const SNAME = {
    cube: '正方体', cuboid: '长方体', prism: '正三棱柱', pyramid: '正四棱锥',
    cylinder: '圆柱', cone: '圆锥', sphere: '球', frustum: '圆台'
  };
  const STAG = {
    cube: 'ABCD-A₁B₁C₁D₁', cuboid: 'ABCD-A₁B₁C₁D₁', prism: 'ABC-A₁B₁C₁',
    pyramid: 'P-ABCD', cylinder: 'OO₁', cone: 'P-O', sphere: 'O', frustum: 'OO₁'
  };
  const ALIAS = {
    '正方体': 'cube', '立方体': 'cube', 'cube': 'cube', 'box': 'cube',
    '长方体': 'cuboid', 'cuboid': 'cuboid',
    '棱柱': 'prism', '三棱柱': 'prism', '正三棱柱': 'prism', 'prism': 'prism', 'cylinder3': 'prism',
    '棱锥': 'pyramid', '四棱锥': 'pyramid', '正四棱锥': 'pyramid', 'pyramid': 'pyramid', 'cone4': 'pyramid',
    '圆柱': 'cylinder', 'cylinder': 'cylinder',
    '圆锥': 'cone', 'cone': 'cone',
    '球': 'sphere', 'sphere': 'sphere', 'ball': 'sphere',
    '圆台': 'frustum', 'frustum': 'frustum', 'truncated': 'frustum'
  };
  const PARAMS = {
    cube: ['a'], cuboid: ['a', 'b', 'h'], prism: ['a', 'h'], pyramid: ['a', 'h'],
    cylinder: ['r', 'h'], cone: ['r', 'h'], sphere: ['r'], frustum: ['R', 'r', 'h']
  };
  const PDEF = {
    a: { label: '底面棱 a', min: 1, max: 6, step: .1, dec: 1 },
    b: { label: '底宽 b', min: 1, max: 6, step: .1, dec: 1 },
    h: { label: '高 h', min: .8, max: 7, step: .1, dec: 1 },
    r: { label: '半径 r', min: .4, max: 4, step: .1, dec: 1 },
    R: { label: '下底半径 R', min: .6, max: 5, step: .1, dec: 1 }
  };
  const SIZE0 = {
    cube: { a: 2 }, cuboid: { a: 2, b: 3, h: 4 }, prism: { a: 2.2, h: 4 },
    pyramid: { a: 3, h: 3 }, cylinder: { r: 1.2, h: 3 }, cone: { r: 1.3, h: 3 },
    sphere: { r: 1.6 }, frustum: { R: 2, r: 1, h: 3 }
  };
  const fnum = (v, d) => { v = +v; return isFinite(v) && v > .05 && v < 20 ? v : d; };

  /* ================= 几何构建 ================= */
  const NSEG = 44;
  function ring(n, r, y, phase) {
    const o = [];
    for (let i = 0; i < n; i++) { const t = (phase || 0) + TAU * i / n; o.push([r * Math.cos(t), y, r * Math.sin(t)]); }
    return o;
  }
  function strip(A, B) {
    const f = [];
    for (let i = 0; i < A.length; i++) {
      const j = (i + 1) % A.length;
      f.push({ v: [A[i], A[j], B[j], B[i]], cull: true });
    }
    return f;
  }
  function capOf(P) { return { v: P, cull: true }; }
  function chainO(P, closed) { return { pts: P, closed: closed !== false }; }

  function buildBox(kind, s) {
    const a = s.a, b = kind === 'cube' ? s.a : s.b, h = kind === 'cube' ? s.a : s.h;
    const x = a / 2, z = b / 2, y = h / 2;
    const pts = {
      A: [-x, -y, z], B: [x, -y, z], C: [x, -y, -z], D: [-x, -y, -z],
      A1: [-x, y, z], B1: [x, y, z], C1: [x, y, -z], D1: [-x, y, -z]
    };
    const faces = [['A', 'B', 'C', 'D'], ['A1', 'B1', 'C1', 'D1'], ['A', 'B', 'B1', 'A1'],
      ['B', 'C', 'C1', 'B1'], ['C', 'D', 'D1', 'C1'], ['D', 'A', 'A1', 'D1']].map(v => ({ v: v }));
    const Rc = .5 * Math.sqrt(a * a + b * b + h * h);
    return {
      key: kind, curved: false, autoEdges: true, pts: pts, faces: faces,
      labels: ['A', 'B', 'C', 'D', 'A1', 'B1', 'C1', 'D1'].map(k => ({ name: k, text: subTxt(k) })),
      dims: kind === 'cube'
        ? [{ a: 'A', b: 'B', text: 'a=' + num(a, 1) }]
        : [{ a: 'A', b: 'B', text: 'a=' + num(a, 1) }, { a: 'B', b: 'C', text: 'b=' + num(b, 1) }, { a: 'A', b: 'A1', text: 'h=' + num(h, 1) }],
      aux: [],
      diag: { face: [{ a: 'A', b: 'C', t: 'AC' }], body: [{ a: 'A', b: 'C1', t: 'AC₁' }] },
      midEdges: [['A', 'B'], ['A', 'D'], ['A', 'A1']],
      rel: {
        dihedral: { x: 'A1', e1: 'B', e2: 'D', y: 'A', label: 'A₁-BD-A' },
        linePlane: { p: 'A', q: 'C1', plane: ['A', 'B', 'C', 'D'], label: 'AC₁ 与底面 ABCD' },
        skew: { l1: ['A', 'A1'], l2: ['B', 'C1'], n1: 'AA₁', n2: 'BC₁' },
        circum: {
          c: [0, 0, 0], R: Rc,
          tex: kind === 'cube'
            ? 'R=\\frac{√3}{2}a=\\frac{√3}{2}×' + num(a, 1) + '=' + num(Rc, 4)
            : 'R=\\frac{1}{2}\\sqrt{a^2+b^2+h^2}=\\frac{1}{2}\\sqrt{' + num(a * a + b * b + h * h, 2) + '}=' + num(Rc, 4)
        }
      }
    };
  }

  function buildPrism(s) {
    const a = s.a, h = s.h, y = h / 2, R3 = a / Math.sqrt(3);
    const A = [0, -y, R3], B = [-a / 2, -y, -R3 / 2], Cc = [a / 2, -y, -R3 / 2];
    const pts = { A: A, B: B, C: Cc, A1: [0, y, R3], B1: [-a / 2, y, -R3 / 2], C1: [a / 2, y, -R3 / 2] };
    const faces = [['A', 'B', 'C'], ['A1', 'B1', 'C1'], ['A', 'B', 'B1', 'A1'],
      ['B', 'C', 'C1', 'B1'], ['C', 'A', 'A1', 'C1']].map(v => ({ v: v }));
    const Rc = Math.sqrt(a * a / 3 + h * h / 4);
    return {
      key: 'prism', curved: false, autoEdges: true, pts: pts, faces: faces,
      labels: ['A', 'B', 'C', 'A1', 'B1', 'C1'].map(k => ({ name: k, text: subTxt(k) })),
      dims: [{ a: 'A', b: 'B', text: 'a=' + num(a, 1) }, { a: 'A', b: 'A1', text: 'h=' + num(h, 1) }],
      aux: [],
      diag: { face: [{ a: 'A', b: 'B1', t: 'AB₁' }], body: [{ a: 'A', b: 'C1', t: 'AC₁' }] },
      midEdges: [['A', 'B'], ['A', 'C'], ['A', 'A1']],
      rel: {
        dihedral: { x: 'A1', e1: 'B', e2: 'C', y: 'A', label: 'A₁-BC-A' },
        linePlane: { p: 'A', q: 'B1', plane: ['A', 'B', 'C'], label: 'AB₁ 与底面 ABC' },
        skew: { l1: ['A', 'A1'], l2: ['B', 'C1'], n1: 'AA₁', n2: 'BC₁' },
        circum: {
          c: [0, 0, 0], R: Rc,
          tex: 'R=\\sqrt{a^2/3+h^2/4}=\\sqrt{' + num(a * a / 3, 4) + '+' + num(h * h / 4, 4) + '}=' + num(Rc, 4)
        }
      }
    };
  }

  function buildPyramid(s) {
    const a = s.a, h = s.h, y = h / 2, x = a / 2;
    const pts = {
      A: [-x, -y, x], B: [x, -y, x], C: [x, -y, -x], D: [-x, -y, -x], P: [0, y, 0],
      O: [0, -y, 0], M: [x, -y, 0]
    };
    const faces = [['A', 'B', 'C', 'D'], ['P', 'A', 'B'], ['P', 'B', 'C'], ['P', 'C', 'D'], ['P', 'D', 'A']].map(v => ({ v: v }));
    const z0 = (h * h - a * a / 2) / (2 * h);
    const Rc = Math.sqrt(a * a / 2 + z0 * z0);
    return {
      key: 'pyramid', curved: false, autoEdges: true, pts: pts, faces: faces,
      labels: ['A', 'B', 'C', 'D', 'P'].map(k => ({ name: k, text: subTxt(k) })),
      dims: [{ a: 'A', b: 'B', text: 'a=' + num(a, 1) }],
      aux: [
        { a: 'P', b: 'O', text: 'h=' + num(h, 1) },
        { a: 'P', b: 'M', text: '斜高 ' + num(Math.sqrt(h * h + (a / 2) * (a / 2)), 2) }
      ],
      diag: { face: [{ a: 'A', b: 'C', t: 'AC' }], body: [{ a: 'P', b: 'A', t: 'PA' }] },
      midEdges: [['A', 'B'], ['A', 'D'], ['A', 'P']],
      rel: {
        dihedral: { x: 'P', e1: 'B', e2: 'C', y: 'A', label: 'P-BC-A' },
        linePlane: { p: 'P', q: 'A', plane: ['A', 'B', 'C', 'D'], label: '棱 PA 与底面' },
        skew: { l1: ['P', 'A'], l2: ['B', 'C'], n1: 'PA', n2: 'BC' },
        circum: {
          c: [0, -y + z0, 0], R: Rc,
          tex: 'R=\\sqrt{a^2/2+z_0^2}=\\sqrt{' + num(a * a / 2, 4) + '+' + num(z0 * z0, 4) + '}=' + num(Rc, 4)
        }
      }
    };
  }

  function buildCylinder(s) {
    const r = s.r, h = s.h, y = h / 2;
    const B = ring(NSEG, r, -y, 0), T = ring(NSEG, r, y, 0);
    const iF = Math.round(NSEG / 4), iBk = Math.round(NSEG * 3 / 4), iR = 0, iL = Math.round(NSEG / 2);
    const pts = {
      O: [0, -y, 0], O1: [0, y, 0],
      A: B[iF], A1: T[iF], B: B[iBk], C: B[iR], D: B[iL], B1: T[iBk]
    };
    const faces = strip(B, T).concat([capOf(B), capOf(T)]);
    const Rc = Math.sqrt(r * r + h * h / 4);
    return {
      key: 'cylinder', curved: true, autoEdges: false, pts: pts, faces: faces,
      edges: [],
      chains: [chainO(B), chainO(T)],
      labels: [{ name: 'A', text: 'A' }, { name: 'A1', text: 'A₁' }, { name: 'O', text: 'O' }, { name: 'O1', text: 'O₁' }],
      dims: [{ a: 'O', b: 'A', text: 'r=' + num(r, 1) }],
      aux: [{ a: 'O', b: 'O1', text: 'h=' + num(h, 1) }, { a: 'A', b: 'A1', text: '母线 ' + num(h, 2) }],
      sil: function (camW) {
        const ph = Math.atan2(camW[0], camW[2]);
        const out = [];
        [Math.PI / 2, -Math.PI / 2].forEach(function (d) {
          const t = ph + d, x = r * Math.cos(t), z = r * Math.sin(t);
          out.push({ pts: [[x, -y, z], [x, y, z]], force: true });
        });
        return out;
      },
      rel: {
        dihedral: { x: 'O1', e1: 'A', e2: 'B', y: 'C', label: '轴截面与底面' },
        linePlane: { p: 'A', q: 'A1', plane: ['O', 'A', 'C'], label: '母线 AA₁ 与底面' },
        skew: { l1: ['A', 'A1'], l2: ['B', 'D'], n1: 'AA₁', n2: 'BD' },
        circum: {
          c: [0, 0, 0], R: Rc,
          tex: 'R=\\sqrt{r^2+h^2/4}=\\sqrt{' + num(r * r, 4) + '+' + num(h * h / 4, 4) + '}=' + num(Rc, 4)
        }
      }
    };
  }

  function buildCone(s) {
    const r = s.r, h = s.h, y = h / 2;
    const B = ring(NSEG, r, -y, 0);
    const iF = Math.round(NSEG / 4), iBk = Math.round(NSEG * 3 / 4), iR = 0, iL = Math.round(NSEG / 2);
    const pts = { O: [0, -y, 0], P: [0, y, 0], A: B[iF], B: B[iBk], C: B[iR], D: B[iL] };
    const faces = [];
    for (let i = 0; i < NSEG; i++) {
      const j = (i + 1) % NSEG;
      faces.push({ v: [B[i], B[j], pts.P], cull: true });
    }
    faces.push(capOf(B));
    const Rc = (r * r + h * h) / (2 * h);
    return {
      key: 'cone', curved: true, autoEdges: false, pts: pts, faces: faces,
      edges: [], chains: [chainO(B)],
      labels: [{ name: 'A', text: 'A' }, { name: 'P', text: 'P' }, { name: 'O', text: 'O' }],
      dims: [{ a: 'O', b: 'A', text: 'r=' + num(r, 1) }],
      aux: [
        { a: 'P', b: 'O', text: 'h=' + num(h, 1) },
        { a: 'P', b: 'A', text: '母线 ' + num(Math.sqrt(r * r + h * h), 2) }
      ],
      sil: function (camW) {
        const ph = Math.atan2(camW[0], camW[2]), out = [];
        [Math.PI / 2, -Math.PI / 2].forEach(function (d) {
          const t = ph + d, x = r * Math.cos(t), z = r * Math.sin(t);
          out.push({ pts: [[x, -y, z], [0, y, 0]], force: true });
        });
        return out;
      },
      rel: {
        dihedral: { x: 'P', e1: 'A', e2: 'B', y: 'C', label: '轴截面与底面' },
        linePlane: { p: 'P', q: 'A', plane: ['O', 'A', 'C'], label: '母线 PA 与底面' },
        skew: { l1: ['P', 'A'], l2: ['B', 'C'], n1: 'PA', n2: 'BC' },
        circum: {
          c: [0, y - Rc, 0], R: Rc,
          tex: 'R=\\frac{r^2+h^2}{2h}=\\frac{' + num(r * r + h * h, 4) + '}{' + num(2 * h, 4) + '}=' + num(Rc, 4)
        }
      }
    };
  }

  function buildFrustum(s) {
    const R0 = s.R, r0 = s.r, h = s.h, y = h / 2;
    const B = ring(NSEG, R0, -y, 0), T = ring(NSEG, r0, y, 0);
    const iF = Math.round(NSEG / 4), iBk = Math.round(NSEG * 3 / 4), iR = 0, iL = Math.round(NSEG / 2);
    const pts = {
      O: [0, -y, 0], O1: [0, y, 0],
      A: B[iF], A1: T[iF], B: B[iBk], C: B[iR], D: B[iL]
    };
    const faces = strip(B, T).concat([capOf(B), capOf(T)]);
    const z0 = (r0 * r0 + h * h - R0 * R0) / (2 * h);
    const Rc = Math.sqrt(R0 * R0 + z0 * z0);
    return {
      key: 'frustum', curved: true, autoEdges: false, pts: pts, faces: faces,
      edges: [], chains: [chainO(B), chainO(T)],
      labels: [{ name: 'A', text: 'A' }, { name: 'A1', text: 'A₁' }, { name: 'O', text: 'O' }, { name: 'O1', text: 'O₁' }],
      dims: [{ a: 'O', b: 'A', text: 'R=' + num(R0, 1) }, { a: 'O1', b: 'A1', text: 'r=' + num(r0, 1) }],
      aux: [
        { a: 'O', b: 'O1', text: 'h=' + num(h, 1) },
        { a: 'A', b: 'A1', text: '母线 ' + num(Math.sqrt((R0 - r0) * (R0 - r0) + h * h), 2) }
      ],
      sil: function (camW) {
        const ph = Math.atan2(camW[0], camW[2]), out = [];
        [Math.PI / 2, -Math.PI / 2].forEach(function (d) {
          const t = ph + d, x = Math.cos(t), z = Math.sin(t);
          out.push({ pts: [[R0 * x, -y, R0 * z], [r0 * x, y, r0 * z]], force: true });
        });
        return out;
      },
      rel: {
        dihedral: { x: 'O1', e1: 'A', e2: 'B', y: 'C', label: '轴截面与底面' },
        linePlane: { p: 'A', q: 'A1', plane: ['O', 'A', 'C'], label: '母线 AA₁ 与底面' },
        skew: { l1: ['A', 'A1'], l2: ['B', 'D'], n1: 'AA₁', n2: 'BD' },
        circum: {
          c: [0, -y + z0, 0], R: Rc,
          tex: 'R=\\sqrt{R^2+z_0^2}=\\sqrt{' + num(R0 * R0, 4) + '+' + num(z0 * z0, 4) + '}=' + num(Rc, 4)
        }
      }
    };
  }

  function buildSphere(s) {
    const r = s.r, NL = 12, NM = 24;
    const rings = [];
    for (let i = 0; i <= NL; i++) {
      const lat = -Math.PI / 2 + Math.PI * i / NL;
      rings.push(ring(NM, r * Math.cos(lat), r * Math.sin(lat), 0));
    }
    const faces = [];
    for (let i = 0; i < NL; i++) faces.push.apply(faces, strip(rings[i], rings[i + 1]));
    const eq = ring(48, r, 0, 0);
    const mer = [];
    for (let i = 0; i < 48; i++) { const t = TAU * i / 48; mer.push([0, r * Math.cos(t), r * Math.sin(t)]); }
    return {
      key: 'sphere', curved: true, autoEdges: false, pts: { O: [0, 0, 0], N: [0, r, 0], E: [r, 0, 0], W: [-r, 0, 0], S: [0, -r, 0] },
      faces: faces, edges: [],
      chains: [
        { pts: eq, closed: true, surf: true },
        { pts: mer, closed: true, surf: true }
      ],
      labels: [{ name: 'O', text: 'O' }],
      dims: [],
      aux: [],
      diag: { face: [], body: [] },
      sil: function (camW) {
        const d = unit(camW);
        let u = cross(d, [0, 1, 0]);
        if (vlen(u) < 1e-6) u = cross(d, [1, 0, 0]);
        u = unit(u);
        const v = unit(cross(d, u)), pts = [];
        for (let i = 0; i < 72; i++) {
          const t = TAU * i / 72;
          pts.push(add(mul(u, r * Math.cos(t)), mul(v, r * Math.sin(t))));
        }
        return [{ pts: pts, force: true, closed: true }];
      },
      surf: { c: [0, 0, 0], r: r },
      rel: {
        dihedral: { x: 'N', e1: 'E', e2: 'W', y: [0, 0, r], label: '两大圆面夹角' },
        linePlane: { p: 'O', q: 'E', plane: [[r, 0, 0], [r, r, 0], [r, 0, r]], label: '半径 OE 与切平面' },
        skew: {
          l1: [[0, .62 * r, -.8 * r], [0, .62 * r, .8 * r]],
          l2: [[-.8 * r, 0, 0], [.8 * r, 0, 0]], n1: '截面弦', n2: '直径'
        },
        circum: { c: [0, 0, 0], R: r, tex: 'R=r=' + num(r, 4) }
      }
    };
  }

  function build(key, s) {
    try {
      switch (key) {
        case 'cuboid': return buildBox('cuboid', s);
        case 'prism': return buildPrism(s);
        case 'pyramid': return buildPyramid(s);
        case 'cylinder': return buildCylinder(s);
        case 'cone': return buildCone(s);
        case 'sphere': return buildSphere(s);
        case 'frustum': return buildFrustum(s);
        case 'cube': default: return buildBox('cube', s);
      }
    } catch (e) {
      console.warn('[solid] build', e);
      return buildBox('cube', { a: 2 });
    }
  }

  /* ================= 平面 / 截面 / 度量 ================= */
  function planeOf(list) {
    if (!list || list.length < 3) return { n: [0, 1, 0], d: 0 };
    for (let i = 1; i < list.length - 1; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const n0 = cross(sub(list[i], list[0]), sub(list[j], list[0]));
        if (vlen(n0) > 1e-9) { const n = unit(n0); return { n: n, d: dot(n, list[0]) }; }
      }
    }
    return { n: [0, 1, 0], d: dot([0, 1, 0], list[0]) };
  }
  function rp(G, x) {
    if (Array.isArray(x)) return x;
    return G.pts[normName(x)] || [0, 0, 0];
  }
  function polyArea3(P) {
    if (!P || P.length < 3) return 0;
    const c = mean(P), u = unit(sub(P[1], P[0]));
    const nrm = cross(sub(P[1], P[0]), sub(P[2], P[0]));
    if (vlen(nrm) < 1e-9) return 0;
    const v = unit(cross(unit(nrm), u));
    let s = 0;
    for (let i = 0; i < P.length; i++) {
      const a = sub(P[i], c), b = sub(P[(i + 1) % P.length], c);
      s += dot(a, u) * dot(b, v) - dot(b, u) * dot(a, v);
    }
    return Math.abs(s) / 2;
  }
  function polyPerim(P) {
    let s = 0;
    for (let i = 0; i < P.length; i++) s += dist(P[i], P[(i + 1) % P.length]);
    return s;
  }
  function sectionPoly(G, pl) {
    if (!pl) return [];
    const S = G.scale || 1, eps = 1e-5 * S, raw = [];
    G.faces.forEach(function (f) {
      const w = f.v.map(x => rp(G, x));
      for (let i = 0; i < w.length; i++) {
        const p = w[i], q = w[(i + 1) % w.length];
        const dp = dot(pl.n, p) - pl.d, dq = dot(pl.n, q) - pl.d;
        if (Math.abs(dp) < eps) raw.push(p);
        if (dp * dq < 0) raw.push(add(p, mul(sub(q, p), dp / (dp - dq))));
      }
    });
    const uniq = [];
    raw.forEach(function (p) { if (!uniq.some(q => dist(p, q) < 1e-4 * S)) uniq.push(p); });
    if (uniq.length < 3) return [];
    const c = mean(uniq);
    let u = unit(sub(uniq[0], c));
    if (vlen(u) < .5) u = unit(cross(pl.n, [0, 1, 0]));
    const v = unit(cross(pl.n, u));
    return uniq.sort(function (p, q) {
      return Math.atan2(dot(sub(p, c), v), dot(sub(p, c), u)) -
        Math.atan2(dot(sub(q, c), v), dot(sub(q, c), u));
    });
  }
  function perpUnit(A, M, e) {
    const w = sub(A, M), p = sub(w, mul(e, dot(w, e)));
    return vlen(p) < 1e-7 ? null : unit(p);
  }
  function calcDihedral(G, r) {
    if (!r) return null;
    const X = rp(G, r.x), E1 = rp(G, r.e1), E2 = rp(G, r.e2), Y = rp(G, r.y);
    const M = mid(E1, E2), e = unit(sub(E2, E1));
    const u1 = perpUnit(X, M, e), u2 = perpUnit(Y, M, e);
    if (!u1 || !u2) return null;
    const cos = clamp(dot(u1, u2), -1, 1), th = Math.acos(cos);
    return {
      X: X, Y: Y, E1: E1, E2: E2, M: M, e: e, u1: u1, u2: u2,
      n1: unit(cross(e, u1)), n2: unit(cross(e, u2)),
      cos: cos, th: th, deg: th * DEG, label: r.label
    };
  }
  function calcLinePlane(G, r) {
    if (!r) return null;
    const A = rp(G, r.p), B = rp(G, r.q);
    const pl = planeOf((r.plane || []).map(x => rp(G, x)));
    const d = sub(B, A), dl = vlen(d) || 1;
    const sn = Math.abs(dot(d, pl.n)) / dl;
    const th = Math.asin(clamp(sn, 0, 1));
    /* 直线与平面的交点 X（线面角在交点处度量） */
    const dn = dot(d, pl.n);
    let X = dist(A, [0, 0, 0]) < 1e9 && Math.abs(dot(pl.n, A) - pl.d) < 1e-7 ? A : null;
    if (!X) X = Math.abs(dn) > 1e-9 ? add(A, mul(d, (pl.d - dot(pl.n, A)) / dn)) : A;
    const far = dist(A, X) >= dist(B, X) ? A : B;
    let u1 = unit(sub(far, X));
    let up = sub(u1, mul(pl.n, dot(u1, pl.n)));
    const flat = vlen(up) < 1e-6;
    const u2 = flat ? unit(cross(pl.n, [1, 0, 0])) : unit(up);
    const foot = sub(far, mul(pl.n, dot(pl.n, far) - pl.d));
    return {
      A: A, B: B, X: X, far: far, foot: foot, n: pl.n, d: d, dl: dl,
      sin: sn, th: th, deg: th * DEG, flat: flat, u1: u1, u2: u2, plane: pl, label: r.label
    };
  }
  function calcSkew(G, r) {
    if (!r) return null;
    const A1 = rp(G, r.l1[0]), A2 = rp(G, r.l1[1]);
    const B1 = rp(G, r.l2[0]), B2 = rp(G, r.l2[1]);
    const d1 = sub(A2, A1), d2 = sub(B2, B1);
    const n = cross(d1, d2), nl = vlen(n);
    if (nl < 1e-9) return null;
    const dd = Math.abs(dot(sub(B1, A1), n)) / nl;
    const w0 = sub(A1, B1), a = dot(d1, d1), b = dot(d1, d2), c = dot(d2, d2);
    const g = dot(d1, w0), h = dot(d2, w0), den = a * c - b * b;
    let P = mid(A1, A2), Q = mid(B1, B2);
    if (Math.abs(den) > 1e-9) {
      P = add(A1, mul(d1, (b * h - c * g) / den));
      Q = add(B1, mul(d2, (a * h - b * g) / den));
    }
    return { A1: A1, A2: A2, B1: B1, B2: B2, P: P, Q: Q, dist: dd, n: unit(n), label: r.label, h1: r.n1, h2: r.n2 };
  }

  /* ================= 视图注册 ================= */
  JW.registerView('solid', function (host, q, api) {
    if (!host) host = document.createElement('div');
    host.innerHTML = '';
    const view = (q && q.view) || {};

    /* ---- 状态 ---- */
    let shape0 = normName(view.shape || '');
    let shapeKey = ALIAS[shape0] || (SHAPES.indexOf(shape0) >= 0 ? shape0 : 'cube');
    const ask0 = String(view.ask || '');
    let ask = /二面/.test(ask0) ? 'dihedral' : /线面/.test(ask0) ? 'linePlane'
      : /异面/.test(ask0) ? 'skew' : /外接|球半径/.test(ask0) ? 'circum'
        : /体积|表面积/.test(ask0) ? 'volume' : 'dihedral';

    const st = {
      shape: shapeKey, size: {}, yaw: -.64, pitch: .34, zoom: 1, persp: true,
      ask: ask, showDiag: true, step: 0, section: { mode: 'none' }, marks: []
    };
    (Array.isArray(view.marks) ? view.marks : []).slice(0, 10).forEach(function (m) {
      const k = normName(m); if (k) st.marks.push(k);
    });
    function defaults(k) {
      const d = SIZE0[k] || { a: 2 }, o = {};
      PARAMS[k].forEach(function (p) { o[p] = fnum(view.size && view.size[p], d[p]); });
      return o;
    }
    st.size = defaults(shapeKey);

    function setSectionFrom(v) {
      if (!v) return { mode: 'none' };
      if (Array.isArray(v.through) && v.through.length >= 3) {
        return { mode: 'three', through: v.through.slice(0, 3).map(normName) };
      }
      const k = String(v.preset || v.plane || v.kind || '');
      if (/hex|diag/i.test(k)) return { mode: 'hex' };
      if (/mid/i.test(k)) return { mode: 'mid' };
      if (/axis/i.test(k)) return { mode: 'axis' };
      if (/equator|mid-section/i.test(k)) return { mode: 'equator' };
      return { mode: 'none' };
    }
    st.section = setSectionFrom(view.section);

    /* ---- DOM ---- */
    const wrap = el('div', { class: 'jw-stage-grid sd-grid' });
    const plot = el('div', { class: 'jw-plot sd-plot' });
    const ctrl = el('div', { class: 'jw-ctrl sd-ctrl' });
    wrap.appendChild(plot); wrap.appendChild(ctrl);
    const head = el('div', { class: 'sd-head' });
    const read = el('div', { class: 'sd-read' });
    const foot = el('div', { class: 'sd-foot' }, '拖拽旋转 · 滚轮缩放 · 双击复位');
    plot.appendChild(head); plot.appendChild(read); plot.appendChild(foot);
    host.appendChild(wrap);
    const cvv = JW.Canvas(plot);
    let dead = false;

    /* ---- 右栏骨架 ---- */
    ctrl.appendChild(el('div', { class: 'jw-sec' }, '形状'));
    const chipBox = JW.ui.chips(SHAPES.map(k => SNAME[k]), SNAME[st.shape], function (label) {
      const k = SHAPES.filter(x => SNAME[x] === label)[0];
      if (k) setShape(k);
    });
    ctrl.appendChild(chipBox);
    ctrl.appendChild(el('div', { class: 'jw-sec' }, '尺寸'));
    const dimBox = el('div');
    const statBox = el('div', { class: 'sd-stats' });
    ctrl.appendChild(dimBox); ctrl.appendChild(statBox);
    ctrl.appendChild(el('div', { class: 'jw-sec' }, '视角'));
    const rowBtn = el('div', { class: 'sd-row' });
    const btnPersp = el('button', { class: 'jw-btn is-on' }, '透视');
    const btnReset = el('button', { class: 'jw-btn' }, '复位');
    rowBtn.appendChild(btnPersp); rowBtn.appendChild(btnReset);
    ctrl.appendChild(rowBtn);
    const kvView = el('div');
    ctrl.appendChild(kvView);
    ctrl.appendChild(el('div', { class: 'jw-sec' }, '关系'));
    const askBox = JW.ui.chips(['二面角', '线面角', '异面直线距离', '外接球半径', '体积'], askLabel(st.ask), function (v) {
      st.ask = v === '二面角' ? 'dihedral' : v === '线面角' ? 'linePlane'
        : v === '异面直线距离' ? 'skew' : v === '外接球半径' ? 'circum' : 'volume';
      refresh(); draw();
    });
    ctrl.appendChild(askBox);
    if (view.cue) ctrl.appendChild(el('div', { class: 'sd-note' }, String(view.cue)));
    const diagBox = el('div', { class: 'sd-row' });
    const btnDiag = el('button', { class: 'jw-chip is-on' }, '面对角线 / 体对角线');
    diagBox.appendChild(btnDiag);
    ctrl.appendChild(diagBox);
    ctrl.appendChild(el('div', { class: 'jw-sec' }, '截面'));
    const secBox = el('div');
    ctrl.appendChild(secBox);
    ctrl.appendChild(el('div', { class: 'jw-sec' }, '公式'));
    const formBox = el('div', { class: 'jw-form sd-form' });
    ctrl.appendChild(formBox);
    const leg = el('div', { class: 'sd-legend' },
      '<span><i class="acc"></i>所求</span><span><i></i>可见棱</span><span><i class="dash"></i>遮挡</span>');
    ctrl.appendChild(leg);

    function askLabel(k) {
      return k === 'dihedral' ? '二面角' : k === 'linePlane' ? '线面角'
        : k === 'skew' ? '异面直线距离' : k === 'circum' ? '外接球半径' : '体积';
    }

    /* ---- 几何 ---- */
    let G = build(st.shape, st.size);
    function rebuild() {
      G = build(st.shape, st.size);
      G.circum = (G.rel && G.rel.circum) || { c: [0, 0, 0], R: 1, tex: 'R=1' };
      G.scale = 1;
      let R = 1e-6;
      const seen = [];
      function scan(p) { const d = vlen(p); if (d > R) R = d; }
      Object.keys(G.pts).forEach(k => scan(G.pts[k]));
      G.faces.forEach(f => f.v.forEach(x => { if (Array.isArray(x)) scan(x); }));
      (G.chains || []).forEach(c => c.pts.forEach(scan));
      G.scale = R;
      /* 体积图解：最低面作底面，最高点作高 */
      G.vol = null;
      if (G.key === 'sphere' && G.chains && G.chains[0]) {
        G.vol = { base: G.chains[0].pts, mid: [0, 0, 0], top: [0, R, 0] };
      } else if (G.faces && G.faces.length) {
        let low = 1e9, base = null, hi = -1e9;
        G.faces.forEach(function (f) {
          const ps = f.v.map(x => rp(G, x));
          const my = mean(ps)[1];
          if (my < low) { low = my; base = ps; }
          ps.forEach(function (q) { if (q[1] > hi) hi = q[1]; });
        });
        if (base) G.vol = { base: base, mid: [0, low, 0], top: [0, hi, 0] };
      }
    }
    rebuild();

    function setShape(k) {
      st.shape = k; st.size = defaults(k);
      st.section = { mode: 'none' };
      rebuild(); buildDims(); buildSec(); syncChips(); refresh(); draw();
    }
    function syncChips() {
      chipBox.querySelectorAll('.jw-chip').forEach(function (b) {
        b.classList.toggle('is-on', b.textContent === SNAME[st.shape]);
      });
      askBox.querySelectorAll('.jw-chip').forEach(function (b) {
        b.classList.toggle('is-on', b.textContent === askLabel(st.ask));
      });
    }

    /* ---- 尺寸控件 ---- */
    function buildDims() {
      dimBox.innerHTML = '';
      PARAMS[st.shape].forEach(function (k) {
        const d = PDEF[k];
        dimBox.appendChild(JW.ui.range({
          label: d.label, min: d.min, max: d.max, step: d.step, dec: d.dec, value: st.size[k]
        }, function (v) {
          st.size[k] = v; rebuild(); buildStats(); refresh(); draw();
        }));
      });
      buildStats();
    }
    function buildStats() {
      statBox.innerHTML = '';
      const s = st.size, v = volSurf(st.shape, s);
      const t = el('div');
      t.appendChild(JW.ui.stat('体积 V', num(v[0], 3), ''));
      statBox.appendChild(t);
      const a2 = el('div');
      a2.appendChild(JW.ui.stat('表面积 S', num(v[1], 3), ''));
      statBox.appendChild(a2);

    }
    function volSurf(k, s) {
      const P = Math.PI;
      switch (k) {
        case 'cube': return [Math.pow(s.a, 3), 6 * s.a * s.a];
        case 'cuboid': return [s.a * s.b * s.h, 2 * (s.a * s.b + s.a * s.h + s.b * s.h)];
        case 'prism': {
          const A = Math.sqrt(3) / 4 * s.a * s.a;
          return [A * s.h, 2 * A + 3 * s.a * s.h];
        }
        case 'pyramid': {
          const l = Math.sqrt(s.h * s.h + s.a * s.a / 4);
          return [s.a * s.a * s.h / 3, s.a * s.a + 2 * s.a * l];
        }
        case 'cylinder': return [P * s.r * s.r * s.h, 2 * P * s.r * (s.r + s.h)];
        case 'cone': {
          const l = Math.sqrt(s.r * s.r + s.h * s.h);
          return [P * s.r * s.r * s.h / 3, P * s.r * (s.r + l)];
        }
        case 'sphere': return [4 / 3 * P * Math.pow(s.r, 3), 4 * P * s.r * s.r];
        case 'frustum': {
          const l = Math.sqrt((s.R - s.r) * (s.R - s.r) + s.h * s.h);
          return [P * s.h * (s.R * s.R + s.R * s.r + s.r * s.r) / 3,
            P * (s.R * s.R + s.r * s.r + (s.R + s.r) * l)];
        }
        default: return [0, 0];
      }
    }

    /* ---- 截面控件 ---- */
    function buildSec() {
      secBox.innerHTML = '';
      const curved = G.curved;
      const boxy = (st.shape === 'cube' || st.shape === 'cuboid');
      const list = curved ? ['无', '轴截面', '中截面', '三点']
        : boxy ? ['无', '体对角线', '棱中点', '三点'] : ['无', '棱中点', '三点'];
      const cur = st.section.mode === 'none' ? '无'
        : st.section.mode === 'three' ? '三点'
          : st.section.mode === 'hex' ? '体对角线'
            : st.section.mode === 'axis' ? '轴截面'
              : st.section.mode === 'mid' ? '棱中点' : '中截面';
      secBox.appendChild(JW.ui.chips(list, cur, function (v) {
        st.section = v === '三点' ? { mode: 'three', through: defThrough() }
          : v === '体对角线' ? { mode: 'hex' }
            : v === '棱中点' ? { mode: 'mid' }
              : v === '轴截面' ? { mode: 'axis' }
                : v === '中截面' ? { mode: 'equator' } : { mode: 'none' };
        if (st.section.mode === 'hex' || st.section.mode === 'mid') aimHex();
        buildSec(); refresh(); draw();
      }));
      if (st.section.mode !== 'three') return;
      const names0 = Object.keys(G.pts);
      const ok = (st.section.through || []).every(n => names0.indexOf(normName(n)) >= 0);
      if (!ok || (st.section.through || []).length < 3) st.section.through = defThrough();
      st.section.through = st.section.through.slice(0, 3).map(normName);
      const names = Object.keys(G.pts);
      const pick = el('div', { class: 'sd-pick' });
      const sel = [];
      for (let i = 0; i < 3; i++) {
        const s = el('select');
        names.forEach(function (n) {
          const o = el('option', { value: n }, subTxt(n));
          if (normName(st.section.through[i]) === n) o.selected = true;
          s.appendChild(o);
        });
        s.addEventListener('change', function () {
          st.section.through[i] = s.value; refresh(); draw();
        });
        sel.push(s); pick.appendChild(s);
      }
      secBox.appendChild(pick);
    }
    function aimHex() {
      if (st.shape !== 'cube' && st.shape !== 'cuboid') return;
      const a = G.pts.A, c = G.pts.C1;
      if (!a || !c) return;
      const d = unit(sub(c, a));
      const phi = Math.asin(clamp(d[1], -1, 1)), cp = Math.cos(phi);
      st.pitch = phi;
      st.yaw = cp > 1e-6 ? Math.atan2(-d[0] / cp, d[2] / cp) : st.yaw;
    }
    function defThrough() {
      const names = Object.keys(G.pts);
      const want = ['A', 'C', 'B1'], out = [];
      want.forEach(function (n) { if (G.pts[n]) out.push(n); });
      if (out.length >= 3) return out;
      return names.slice(0, 3);
    }
    function secPlane() {
      const m = st.section;
      if (!m || m.mode === 'none') return null;
      if (m.mode === 'three') {
        const ps = (m.through || []).map(n => G.pts[normName(n)]).filter(Boolean);
        if (ps.length < 3) return null;
        if (vlen(cross(sub(ps[1], ps[0]), sub(ps[2], ps[0]))) < 1e-8) return null;
        return planeOf(ps);
      }
      if (m.mode === 'mid') {
        const E = G.midEdges || [];
        const ps = E.slice(0, 3).map(e => mid(rp(G, e[0]), rp(G, e[1])));
        if (ps.length < 3) return null;
        return planeOf(ps);
      }
      if (m.mode === 'axis') return { n: [1, 0, 0], d: 0 };
      if (m.mode === 'equator') return { n: [0, 1, 0], d: 0 };
      if (m.mode === 'hex') {
        const a = G.pts.A, c = G.pts.C1;
        if (!a || !c) return { n: [0, 1, 0], d: 0 };
        return { n: unit(sub(c, a)), d: 0 };
      }
      return null;
    }

    /* ---- 视图控件 ---- */
    btnPersp.addEventListener('click', function () {
      st.persp = !st.persp;
      btnPersp.classList.toggle('is-on', st.persp);
      btnPersp.textContent = st.persp ? '透视' : '正交';
      refresh(); draw();
    });
    btnReset.addEventListener('click', function () { resetView(); });
    btnDiag.addEventListener('click', function () {
      st.showDiag = !st.showDiag;
      btnDiag.classList.toggle('is-on', st.showDiag);
      refresh(); draw();
    });
    function resetView() {
      st.yaw = -.64; st.pitch = .34; st.zoom = 1; st.persp = true;
      btnPersp.classList.add('is-on'); btnPersp.textContent = '透视';
      refresh(); draw();
    }

    /* ---- 交互 ---- */
    JW.drag(plot, {
      down: function () { plot.style.cursor = 'grabbing'; },
      move: function (p, d) {
        st.yaw += d.x * .009;
        st.pitch = clamp(st.pitch + d.y * .007, -1.42, 1.42);
        refreshView(); draw();
      },
      up: function () { plot.style.cursor = ''; },
      wheel: function (dy) {
        st.zoom = clamp(st.zoom * Math.exp(-dy * .0012), .55, 2.6);
        refreshView(); draw();
      }
    });
    plot.addEventListener('dblclick', function () { resetView(); });

    /* ---- 相机 / 投影 ---- */
    function camera() {
      const cy = Math.cos(st.yaw), sy = Math.sin(st.yaw);
      const cp = Math.cos(st.pitch), sp = Math.sin(st.pitch);
      return {
        T: function (p) {
          const x1 = p[0] * cy + p[2] * sy;
          const z1 = -p[0] * sy + p[2] * cy;
          return [x1, p[1] * cp - z1 * sp, p[1] * sp + z1 * cp];
        },
        camW: [-cp * sy, sp, cp * cy]
      };
    }

    /* ---- 主绘制 ---- */
    function draw() {
      if (dead) return;
      const ctx = cvv.ctx, w = cvv.w, h = cvv.h;
      ctx.setTransform(cvv.dpr, 0, 0, cvv.dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = C.paper; ctx.fillRect(0, 0, w, h);

      const cam = camera(), T = cam.T, camW = cam.camW;
      let Rw = 1e-6;
      Object.keys(G.pts).forEach(k => { const d = vlen(G.pts[k]); if (d > Rw) Rw = d; });
      (G.chains || []).forEach(c => c.pts.forEach(p => { const d = vlen(p); if (d > Rw) Rw = d; }));
      Rw = Math.max(Rw, .5);

      const base = Math.min(w, h) * .405 / Rw * st.zoom;
      const D = 10 * Rw;
      const cx = w * .5, cyy = h * .5 + h * .002;
      function pj(c) {
        const k = st.persp ? base * D / Math.max(D - c[2], D * .22) : base;
        return { x: cx + c[0] * k, y: cyy - c[1] * k };
      }
      function SC(p) { return pj(T(p)); }
      const CEN = SC([0, 0, 0]);

      /* 面：相机空间 + 正反面 + 深度 */
      const faces = [];
      G.faces.forEach(function (f) {
        const w3 = f.v.map(x => rp(G, x));
        const c3 = w3.map(T);
        const s2 = c3.map(pj);
        const n0 = cross(sub(c3[1], c3[0]), sub(c3[2], c3[0]));
        const nl = vlen(n0);
        if (nl < 1e-9) return;
        const cen = mean(c3);
        /* 凸体且含原点：外法向必背离原点，与顶点绕序无关 */
        let n = mul(n0, 1 / nl);
        if (dot(n, cen) < 0) n = mul(n, -1);
        const front = dot(n, sub([0, 0, D], cen)) > 0;
        let bx0 = 1e9, bx1 = -1e9, by0 = 1e9, by1 = -1e9;
        s2.forEach(function (p) {
          if (p.x < bx0) bx0 = p.x; if (p.x > bx1) bx1 = p.x;
          if (p.y < by0) by0 = p.y; if (p.y > by1) by1 = p.y;
        });
        faces.push({
          s2: s2, c3: c3, c0: c3[0], n: n,
          front: front, z: cen[2], cull: !!f.cull, up: nwY(w3), bbox: [bx0, bx1, by0, by1]
        });
      });
      function nwY(w3) {
        const nn = cross(sub(w3[1], w3[0]), sub(w3[2], w3[0]));
        if (vlen(nn) < 1e-9) return 0;
        const u = unit(nn);
        return dot(u, mean(w3)) < 0 ? -u[1] : u[1];
      }

      /* 画家算法：远→近 */
      faces.sort((a, b) => a.z - b.z);
      faces.forEach(function (f) {
        if (f.cull && !f.front) return;
        const a = (f.front ? .062 : .03) + Math.max(0, f.up) * .018;
        ctx.beginPath();
        ctx.moveTo(f.s2[0].x, f.s2[0].y);
        for (let i = 1; i < f.s2.length; i++) ctx.lineTo(f.s2[i].x, f.s2[i].y);
        ctx.closePath();
        ctx.fillStyle = 'rgba(8,31,92,' + a.toFixed(3) + ')';
        ctx.fill();
      });

      /* 遮挡判定 */
      const eps = Rw * .016;
      const frontFaces = faces.filter(f => f.front);
      function inPoly(x, y, P) {
        let c = false;
        for (let i = 0, j = P.length - 1; i < P.length; j = i++) {
          if (((P[i].y > y) !== (P[j].y > y)) &&
            (x < (P[j].x - P[i].x) * (y - P[i].y) / ((P[j].y - P[i].y) || 1e-9) + P[i].x)) c = !c;
        }
        return c;
      }
      function occ(p) {
        const c = T(p), s = pj(c);
        for (let i = 0; i < frontFaces.length; i++) {
          const f = frontFaces[i], b = f.bbox;
          if (s.x < b[0] || s.x > b[1] || s.y < b[2] || s.y > b[3]) continue;
          if (!inPoly(s.x, s.y, f.s2)) continue;
          if (dot(f.n, sub(c, f.c0)) < -eps) return true;
        }
        return false;
      }

      /* 线段收集：遮挡 = 虚线 */
      const runsV = [], runsH = [];
      function collect(list, closed, force, visFn) {
        const n = closed ? list.length : list.length - 1;
        let cur = null, curH = null;
        for (let i = 0; i < n; i++) {
          const a = list[i], b = list[(i + 1) % list.length];
          let hid = false;
          if (!force) {
            const m = mid(a, b);
            hid = visFn ? !visFn(m) : occ(m);
          }
          const pa = SC(a), pb = SC(b);
          if (cur && curH === hid) cur.push(pb);
          else { cur = [pa, pb]; curH = hid; (hid ? runsH : runsV).push(cur); }
        }
      }

      /* 棱 */
      if (G.autoEdges && !G.edges) {
        const seen = {}, E = [];
        G.faces.forEach(function (f) {
          const v = f.v;
          for (let i = 0; i < v.length; i++) {
            const a = v[i], b = v[(i + 1) % v.length];
            const k = [String(a), String(b)].sort().join('|');
            if (seen[k]) continue; seen[k] = 1; E.push([a, b]);
          }
        });
        G.edges = E;
      }
      (G.edges || []).forEach(function (e) {
        collect([rp(G, e[0]), rp(G, e[1])], false, false);
      });
      /* 曲面轮廓 / 大圆 */
      (G.chains || []).forEach(function (c) {
        const vis = c.surf && G.surf
          ? function (p) { return dot(sub(p, G.surf.c), sub(camW, p)) > 0; }
          : null;
        collect(c.pts, c.closed, false, vis);
      });
      (G.sil ? G.sil(camW) : []).forEach(function (s) {
        collect(s.pts, s.closed === true, true);
      });

      /* 被遮挡的棱：虚线；可见棱：实线 */
      ctx.save();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.setLineDash([4, 3.6]);
      ctx.strokeStyle = 'rgba(51,78,172,.55)';
      ctx.lineWidth = 1.15;
      runsH.forEach(function (r) { paint(r); });
      ctx.setLineDash([]);
      ctx.strokeStyle = C.ink;
      ctx.lineWidth = 1.45;
      runsV.forEach(function (r) { paint(r); });
      ctx.restore();
      function paint(r) {
        ctx.beginPath(); ctx.moveTo(r[0].x, r[0].y);
        for (let i = 1; i < r.length; i++) ctx.lineTo(r[i].x, r[i].y);
        ctx.stroke();
      }

      /* ---- 叠加层 ---- */
      const S = { SC: SC, T: T, Rw: Rw, base: base, ctx: ctx, camW: camW, occ: occ, CEN: CEN };
      drawAux(S);
      drawSection(S);
      const rel = drawRel(S);
      if (secLabel) chip(S, secLabel.x, secLabel.y, secLabel.t, C.jade, 11);
      drawLabels(S);
      refreshReadout(S, rel);
    }

    /* ---- 线 / 箭头 / 文字（叠加层，不再做遮挡） ---- */
    function seg(S, a, b, o) {
      o = o || {};
      const A = S.SC(a), B = S.SC(b), ctx = S.ctx;
      ctx.save();
      ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y);
      ctx.strokeStyle = o.color || C.ink2;
      ctx.lineWidth = o.width || 1.3;
      if (o.dash) ctx.setLineDash(o.dash);
      ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
      ctx.lineCap = 'round';
      ctx.stroke(); ctx.restore();
    }
    function arrow(S, a, b, color, dash) {
      const A = S.SC(a), B = S.SC(b), ctx = S.ctx;
      const ang = Math.atan2(B.y - A.y, B.x - A.x), L = 6.5;
      ctx.save();
      ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y);
      ctx.strokeStyle = color; ctx.lineWidth = 1.15;
      if (dash) ctx.setLineDash(dash);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(B.x, B.y);
      ctx.lineTo(B.x - L * Math.cos(ang - .42), B.y - L * Math.sin(ang - .42));
      ctx.lineTo(B.x - L * Math.cos(ang + .42), B.y - L * Math.sin(ang + .42));
      ctx.closePath(); ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }
    function chip(S, x, y, txt, color, size) {
      const ctx = S.ctx, fs = size || 11;
      ctx.save();
      ctx.font = '700 ' + fs + 'px ' + C.sans;
      const w = ctx.measureText(txt).width + 9, h = fs + 6.5;
      const r = 2.5, x0 = x - w / 2, y0 = y - h / 2;
      ctx.beginPath();
      ctx.moveTo(x0 + r, y0);
      ctx.lineTo(x0 + w - r, y0); ctx.quadraticCurveTo(x0 + w, y0, x0 + w, y0 + r);
      ctx.lineTo(x0 + w, y0 + h - r); ctx.quadraticCurveTo(x0 + w, y0 + h, x0 + w - r, y0 + h);
      ctx.lineTo(x0 + r, y0 + h); ctx.quadraticCurveTo(x0, y0 + h, x0, y0 + h - r);
      ctx.lineTo(x0, y0 + r); ctx.quadraticCurveTo(x0, y0, x0 + r, y0);
      ctx.closePath();
      ctx.fillStyle = 'rgba(247,242,235,.9)';
      ctx.fill();
      ctx.fillStyle = color; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(txt, x, y);
      ctx.restore();
    }
    function text(S, x, y, s, o) {
      o = o || {};
      const ctx = S.ctx;
      ctx.save();
      ctx.font = (o.weight || 600) + ' ' + (o.size || 11) + 'px ' + (o.font || C.sans);
      ctx.textAlign = o.align || 'center';
      ctx.textBaseline = o.base || 'middle';
      if (o.halo !== false) {
        ctx.strokeStyle = C.paper; ctx.lineWidth = 3.2; ctx.lineJoin = 'round';
        ctx.strokeText(s, x, y);
      }
      ctx.fillStyle = o.color || C.ink;
      ctx.fillText(s, x, y);
      ctx.restore();
    }

    /* ---- 辅助线 / 尺寸 ---- */
    function drawAux(S) {
      if (st.step < 1) return;
      /* 尺寸（棱长） */
      G.dims.forEach(function (d) {
        const a = rp(G, d.a), b = rp(G, d.b);
        const m = mid(a, b);
        const q = S.SC(m);
        let ux = q.x - S.CEN.x, uy = q.y - S.CEN.y;
        const L = Math.hypot(ux, uy) || 1;
        text(S, q.x + ux / L * 15, q.y + uy / L * 15, d.text, { size: 10, color: C.ink2, weight: 600 });
      });
      /* 高 / 斜高 / 母线 */
      G.aux.forEach(function (a) {
        const p = rp(G, a.a), q = rp(G, a.b);
        const hidden = S.occ(mid(p, q));
        seg(S, p, q, { color: C.ink2, width: 1.1, dash: hidden ? [5, 4] : [6, 4] });
        seg(S, p, q, { color: 'rgba(51,78,172,.0)', width: 0 });
        const m = add(p, mul(sub(q, p), .58));
        const s = S.SC(m);
        text(S, s.x + 12, s.y - 8, a.text, { size: 10, color: C.ink2 });
      });
      /* 球：半径随视角 */
      if (G.surf && !(st.ask === 'circum' && st.step >= 2)) {
        const p = mul(unit(S.camW), G.surf.r);
        seg(S, G.surf.c, p, { color: C.ink2, width: 1.2 });
        seg(S, G.surf.c, mul(p, -1), { color: C.ink2, width: 1, dash: [5, 4] });
        const mp = S.SC(mul(p, .58));
        text(S, mp.x + 13, mp.y - 8, 'r=' + num(G.surf.r, 1), { size: 10, color: C.ink2 });
      }
      /* 面对角线 / 体对角线（可切换） */
      if (st.showDiag && G.diag) {
        (G.diag.face || []).forEach(function (e) {
          const a = rp(G, e.a), b = rp(G, e.b);
          seg(S, a, b, { color: C.jade, width: 1.2, dash: [5, 4] });
          const m = S.SC(mid(a, b));
          text(S, m.x, m.y + 11, (e.t ? e.t + '=' : '') + num(dist(a, b), 2), { size: 10, color: C.jade, weight: 600 });
        });
        (G.diag.body || []).forEach(function (e) {
          const a = rp(G, e.a), b = rp(G, e.b);
          seg(S, a, b, { color: C.jade, width: 1.4, dash: [7, 4] });
          const m = S.SC(mid(a, b));
          text(S, m.x, m.y - 10, (e.t ? e.t + '=' : '') + num(dist(a, b), 2), { size: 10, color: C.jade, weight: 600 });
        });
      }
    }

    /* ---- 截面 ---- */
    let secCache = { poly: [], area: 0, perim: 0 }, secLabel = null;
    function drawSection(S) {
      secLabel = null;
      const pl = secPlane();
      const poly = sectionPoly(G, pl);
      secCache = { poly: poly, area: polyArea3(poly), perim: polyPerim(poly), on: st.step >= 2 };
      if (st.step < 2 || poly.length < 3) return;
      const ctx = S.ctx, pts = poly.map(S.SC);
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.closePath();
      ctx.fillStyle = 'rgba(63,111,98,.13)';
      ctx.fill();
      ctx.strokeStyle = C.jade; ctx.lineWidth = 1.7; ctx.lineJoin = 'round';
      ctx.stroke();
      ctx.restore();
      if (pts.length <= 8) {
        pts.forEach(function (p) {
          ctx.beginPath(); ctx.arc(p.x, p.y, 2.1, 0, TAU);
          ctx.fillStyle = C.jade; ctx.fill();
        });
      }
      secLabel = st.step >= 3 ? { x: S.SC(mean(poly)).x, y: S.SC(mean(poly)).y, t: 'S=' + num(secCache.area, 2) } : null;
    }

    /* ---- 角与距离 ---- */
    let relCache = null;
    function drawRel(S) {
      relCache = null;
      if (st.step < 2) return null;
      const R = G.rel || {};
      const ctx = S.ctx;
      if (st.ask === 'dihedral') {
        const m = calcDihedral(G, R.dihedral);
        if (!m) return null;
        relCache = { kind: 'dihedral', m: m };
        seg(S, m.E1, m.E2, { color: C.ink, width: 2.1 });
        const L = .58 * S.Rw;
        seg(S, m.M, add(m.M, mul(m.u1, L)), { color: C.ink2, width: 1, dash: [3, 3], alpha: .55 });
        seg(S, m.M, add(m.M, mul(m.u2, L)), { color: C.ink2, width: 1, dash: [3, 3], alpha: .55 });
        arrow(S, m.M, add(m.M, mul(m.n1, .40 * S.Rw)), C.ink2, [4, 3]);
        arrow(S, m.M, add(m.M, mul(m.n2, .40 * S.Rw)), C.ink2, [4, 3]);
        /* 角弧 */
        let wv = sub(m.u2, mul(m.u1, dot(m.u1, m.u2)));
        if (vlen(wv) < 1e-6) { wv = cross(m.n1, m.u1); }
        wv = unit(wv);
        const r0 = .27 * S.Rw, arc = [];
        for (let i = 0; i <= 24; i++) {
          const t = m.th * i / 24;
          arc.push(add(m.M, add(mul(m.u1, r0 * Math.cos(t)), mul(wv, r0 * Math.sin(t)))));
        }
        for (let i = 0; i < arc.length - 1; i++) seg(S, arc[i], arc[i + 1], { color: C.accent, width: 1.9 });
        if (st.step >= 3) {
          const t = m.th / 2;
          const lp = add(m.M, add(mul(m.u1, r0 * 1.38 * Math.cos(t)), mul(wv, r0 * 1.38 * Math.sin(t))));
          const sp = S.SC(lp);
          chip(S, sp.x, sp.y, num(m.deg, 2) + '°', C.accent, 12);
        }
        return relCache;
      }
      if (st.ask === 'linePlane') {
        const m = calcLinePlane(G, R.linePlane);
        if (!m) return null;
        relCache = { kind: 'linePlane', m: m };
        seg(S, m.A, m.B, { color: C.ink2, width: 1.8, dash: [6, 4] });
        if (dist(m.far, m.foot) > 1e-6) {
          seg(S, m.far, m.foot, { color: C.ink2, width: 1, dash: [4, 4], alpha: .85 });
          seg(S, m.X, m.foot, { color: C.ink2, width: 1.5, alpha: .8 });
        }
        const u1 = m.u1, u2 = m.u2;
        let wv = sub(u2, mul(u1, dot(u1, u2)));
        if (vlen(wv) < 1e-6) wv = cross(m.n, u1);
        wv = unit(wv);
        const r0 = .22 * S.Rw;
        if (m.flat) {
          /* 线面垂直：直角符号 */
          const a = r0 * .85;
          const p1 = add(m.X, mul(u1, a)), p2 = add(add(m.X, mul(u1, a)), mul(u2, a)), p3 = add(m.X, mul(u2, a));
          seg(S, p1, p2, { color: C.accent, width: 1.6 });
          seg(S, p2, p3, { color: C.accent, width: 1.6 });
        } else {
          const arc = [];
          for (let i = 0; i <= 20; i++) {
            const t = m.th * i / 20;
            arc.push(add(m.X, add(mul(u1, r0 * Math.cos(t)), mul(wv, r0 * Math.sin(t)))));
          }
          for (let i = 0; i < arc.length - 1; i++) seg(S, arc[i], arc[i + 1], { color: C.accent, width: 1.9 });
        }
        if (st.step >= 3) {
          const t = m.th / 2, lp = m.flat
            ? add(add(m.X, mul(u1, r0 * .8)), mul(u2, r0 * 1.5))
            : add(m.X, add(mul(u1, r0 * 1.55 * Math.cos(t)), mul(wv, r0 * 1.55 * Math.sin(t))));
          const sp = S.SC(lp);
          chip(S, sp.x, sp.y, num(m.deg, 2) + '°', C.accent, 12);
        }
        return relCache;
      }
      if (st.ask === 'skew') {
        const m = calcSkew(G, R.skew);
        if (!m) return null;
        relCache = { kind: 'skew', m: m };
        seg(S, m.A1, m.A2, { color: C.ink2, width: 1.4, dash: [6, 4] });
        seg(S, m.B1, m.B2, { color: C.ink2, width: 1.4, dash: [6, 4] });
        seg(S, m.P, m.Q, { color: C.accent, width: 2.1 });
        if (st.step >= 3) {
          const sp = S.SC(mid(m.P, m.Q));
          chip(S, sp.x, sp.y - 13, 'd=' + num(m.dist, 4), C.accent, 11.5);
        }
        return relCache;
      }
      /* 体积：底面积 × 高 */
      if (st.ask === 'volume') {
        const vv = G.vol;
        if (!vv) return null;
        relCache = { kind: 'volume' };
        const bp = vv.base.map(x => rp(G, x));
        const s2 = bp.map(S.SC);
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(s2[0].x, s2[0].y);
        for (let i = 1; i < s2.length; i++) ctx.lineTo(s2[i].x, s2[i].y);
        ctx.closePath();
        ctx.fillStyle = 'rgba(63,111,98,.11)';
        ctx.fill();
        ctx.strokeStyle = 'rgba(63,111,98,.72)';
        ctx.lineWidth = 1.2; ctx.setLineDash([5, 4]);
        ctx.stroke();
        ctx.restore();
        seg(S, vv.mid, vv.top, { color: C.ink2, width: 1.5, dash: [6, 4] });
        const hh = Math.abs(vv.top[1] - vv.mid[1]);
        const mp = S.SC(add(vv.mid, mul(sub(vv.top, vv.mid), .62)));
        chip(S, mp.x + 34, mp.y, 'h=' + num(hh, 2), C.ink2, 11);
        if (st.step >= 3) {
          const q = S.SC(add(vv.mid, mul(sub(vv.top, vv.mid), .3)));
          chip(S, q.x - 42, q.y, 'V=' + num(volSurf(st.shape, st.size)[0], 3), C.accent, 12);
        }
        return relCache;
      }
      /* 外接球 */
      const cu = G.circum;
      if (!cu) return null;
      relCache = { kind: 'circum', m: cu };
      const d = unit(S.camW);
      let u = cross(d, [0, 1, 0]);
      if (vlen(u) < 1e-6) u = cross(d, [1, 0, 0]);
      u = unit(u);
      const v = unit(cross(d, u)), ring = [];
      for (let i = 0; i <= 72; i++) {
        const t = TAU * i / 72;
        ring.push(add(cu.c, add(mul(u, cu.R * Math.cos(t)), mul(v, cu.R * Math.sin(t)))));
      }
      for (let i = 0; i < ring.length - 1; i++) seg(S, ring[i], ring[i + 1], { color: C.ink2, width: 1, dash: [4, 4], alpha: .75 });
      const sp = S.SC(cu.c);
      S.ctx.beginPath(); S.ctx.arc(sp.x, sp.y, 2.4, 0, TAU);
      S.ctx.fillStyle = C.ink; S.ctx.fill();
      const top = add(cu.c, [0, cu.R, 0]);
      seg(S, cu.c, top, { color: C.accent, width: 1.9 });
      if (st.step >= 3) {
        const mp = S.SC(add(cu.c, [0, cu.R * .55, 0]));
        chip(S, mp.x + 34, mp.y, 'R=' + num(cu.R, 4), C.accent, 11.5);
      }
      return relCache;
    }

    /* ---- 标签（防压） ---- */
    function drawLabels(S) {
      const ctx = S.ctx, items = [];
      ctx.save();
      ctx.font = '600 11px ' + C.sans;
      (G.labels || []).forEach(function (l) {
        const p = G.pts[l.name];
        if (!p) return;
        const q = S.SC(p);
        let ux = q.x - S.CEN.x, uy = q.y - S.CEN.y;
        if (Math.hypot(ux, uy) < 1) { ux = 0; uy = -1; }
        const d = Math.hypot(ux, uy) || 1;
        const isMark = st.marks.indexOf(l.name) >= 0;
        items.push({
          x: q.x + ux / d * 15, y: q.y + uy / d * 15, text: l.text,
          w: ctx.measureText(l.text).width, mark: isMark
        });
      });
      for (let pass = 0; pass < 4; pass++) {
        for (let i = 0; i < items.length; i++) {
          for (let j = i + 1; j < items.length; j++) {
            const a = items[i], b = items[j];
            if (Math.abs(a.x - b.x) < (a.w + b.w) / 2 + 3 && Math.abs(a.y - b.y) < 12) {
              const dir = a.y <= b.y ? -1 : 1;
              a.y += dir * 2.4; b.y -= dir * 2.4;
            }
          }
        }
      }
      items.forEach(function (it) {
        const x = clamp(it.x, 12, cvv.w - 12), y = clamp(it.y, 12, cvv.h - 12);
        if (it.mark) {
          ctx.beginPath(); ctx.arc(x, y, 2.4, 0, TAU);
          ctx.fillStyle = C.accent; ctx.fill();
        }
        text(S, x, y, it.text, { size: 11, color: it.mark ? C.accent : C.ink, weight: 700 });
      });
      ctx.restore();
    }

    /* ---- 读数 ---- */
    function refreshReadout(S, rel) {
      if (st.step < 3) { read.innerHTML = ''; return; }
      let rows = [];
      if (rel && rel.kind === 'dihedral') rows.push([num(rel.m.deg, 2) + '°', '二面角 ' + rel.m.label]);
      else if (rel && rel.kind === 'linePlane') rows.push([num(rel.m.deg, 2) + '°', '线面角 ' + rel.m.label]);
      else if (rel && rel.kind === 'skew') rows.push([num(rel.m.dist, 4), '异面直线距离']);
      else if (rel && rel.kind === 'circum') rows.push([num(rel.m.R, 4), '外接球半径 R']);
      else if (rel && rel.kind === 'volume') {
        const vv2 = volSurf(st.shape, st.size);
        rows.push([num(vv2[0], 3), '体积 V']);
        rows.push([num(vv2[1], 3), '表面积 S']);
      }
      if (secCache.poly.length >= 3) rows.push([num(secCache.area, 3), '截面面积 · 周长 ' + num(secCache.perim, 3)]);
      if (!rows.length) { read.innerHTML = ''; return; }
      read.innerHTML = '<i>步骤 3 · 结论</i>' + rows.map(function (r) {
        return '<b>' + r[0] + '</b><span>' + r[1] + '</span>';
      }).join('');
    }

    /* ---- 面板刷新 ---- */
    function refreshView() {
      kvView.innerHTML = '';
      kvView.appendChild(el('div', { class: 'sd-kv' },
        '<span>偏转 ' + Math.round(st.yaw * DEG) + '° · 俯仰 ' + Math.round(st.pitch * DEG) +
        '°</span><b>' + num(st.zoom, 2) + '×</b>'));
    }
    function refresh() {
      const tags = { 0: '实体', 1: '辅助线', 2: '截面 / 角', 3: '结论' };
      head.innerHTML = '<b>' + SNAME[st.shape] + '</b><span>' + STAG[st.shape] +
        ' · ' + (tags[st.step] || '实体') + '</span>';
      refreshView();
      refreshFormula();
      syncChips();
    }

    /* ---- 公式区 ---- */
    function refreshFormula() {
      let html = '';
      const S3 = st.step >= 3;
      if (st.ask === 'dihedral') {
        const m = calcDihedral(G, G.rel.dihedral);
        if (m) {
          html += '<em>二面角 ' + m.label + '</em><br>';
          html += fx('cos\\theta=\\frac{u_1\\cdot u_2}{|u_1||u_2|}');
          if (S3) html += '<br>' + fx('= ' + num(m.cos, 4) + '  ⇒  ') + '<b>' + num(m.deg, 2) + '°</b>';
        }
      } else if (st.ask === 'linePlane') {
        const m = calcLinePlane(G, G.rel.linePlane);
        if (m) {
          html += '<em>线面角 ' + m.label + '</em><br>';
          html += fx('sin\\theta=\\frac{|d\\cdot n|}{|d||n|}');
          if (S3) html += '<br>' + fx('= ' + num(m.sin, 4) + '  ⇒  ') + '<b>' + num(m.deg, 2) + '°</b>';
        }
      } else if (st.ask === 'skew') {
        const m = calcSkew(G, G.rel.skew);
        if (m) {
          html += '<em>异面直线 ' + (G.rel.skew.n1 || '') + ' 与 ' + (G.rel.skew.n2 || '') + '</em><br>';
          html += fx('d=\\frac{|(P_2-P_1)\\cdot(d_1\\times d_2)|}{|d_1\\times d_2|}');
          if (S3) html += '<br><b>' + 'd=' + num(m.dist, 4) + '</b>';
        }
      } else if (st.ask === 'volume') {
        const vt = volTex(st.shape, st.size), vr = volSurf(st.shape, st.size);
        html += '<em>体积 V</em><br>' + fx(vt[0]);
        if (S3) html += '=<b>' + num(vr[0], 3) + '</b>';
        if (S3) html += '<br><em>表面积 S</em><br>' + fx(vt[1]) + '=<b>' + num(vr[1], 3) + '</b>';
      } else {
        const cs = String(G.circum.tex || 'R=r').split('=');
        html += '<em>外接球半径 R</em><br>';
        if (S3) html += fx(cs.slice(0, -1).join('=')) + '=<b>' + num(G.circum.R, 4) + '</b>';
        else html += fx(cs[0] + '=' + (cs[1] || ''));
      }
      const pl = secPlane(), poly = sectionPoly(G, pl);
      if (poly.length >= 3 && S3) {
        html += '<br><em>截面</em><br><b>S=' + num(polyArea3(poly), 3) + '</b>'
          + '，C=' + num(polyPerim(poly), 3);
      }
      formBox.innerHTML = html || '<em>选择形状与关系</em>';
    }

    function volTex(k, s) {
      const P = 'π', n = num;
      switch (k) {
        case 'cube': return ['V=a^3=' + n(s.a, 1) + '^3', 'S=6a^2=6×' + n(s.a * s.a, 2)];
        case 'cuboid': return ['V=abh=' + n(s.a, 1) + '×' + n(s.b, 1) + '×' + n(s.h, 1), 'S=2(ab+ah+bh)'];
        case 'prism': return ['V=\\frac{√3}{4}a^2h=' + n(Math.sqrt(3) / 4 * s.a * s.a, 3) + '×' + n(s.h, 1),
          'S=\\frac{√3}{2}a^2+3ah'];
        case 'pyramid': return ['V=\\frac{1}{3}a^2h=\\frac{1}{3}×' + n(s.a * s.a * s.h, 3),
          'S=a^2+2a·l'];
        case 'cylinder': return ['V=' + P + 'r^2h=' + P + '×' + n(s.r * s.r, 2) + '×' + n(s.h, 1),
          'S=2' + P + 'r(r+h)'];
        case 'cone': return ['V=\\frac{1}{3}' + P + 'r^2h=\\frac{1}{3}×' + P + '×' + n(s.r * s.r, 2) + '×' + n(s.h, 1),
          'S=' + P + 'r(r+l)'];
        case 'sphere': return ['V=\\frac{4}{3}' + P + 'r^3=\\frac{4}{3}×' + P + '×' + n(Math.pow(s.r, 3), 2),
          'S=4' + P + 'r^2'];
        case 'frustum': return ['V=\\frac{1}{3}' + P + 'h(R^2+Rr+r^2)',
          'S=' + P + '(R^2+r^2+(R+r)l)'];
        default: return ['V=0', 'S=0'];
      }
    }

    function sectionTex() {
      const k = st.shape;
      if (st.section.mode === 'hex') return '平面⊥ 体对角线，过中心';
      if (st.section.mode === 'mid') return '平面过三条棱的中点';
      if (st.section.mode === 'axis') return '轴截面：过轴线的平面';
      if (st.section.mode === 'equator') return '中截面：过球心且垂直于轴';
      if (k && st.section.mode === 'three') return '过三点 ' + st.section.through.map(subTxt).join('');
      return '';
    }

    /* ---- 生命周期 ---- */
    function applyStep(i) {
      if (dead) return;
      st.step = clamp(Math.round(i || 0), 0, 3);
      refresh();
      draw();
    }
    function destroy() {
      if (dead) return;
      dead = true;
      cvv.render = null;
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
      host.innerHTML = '';
    }
    cvv.render = draw;
    if (st.section.mode === 'hex' || st.section.mode === 'mid') aimHex();
    buildDims(); buildSec(); refresh();
    draw();
    return { applyStep: applyStep, destroy: destroy };
  });
})();
