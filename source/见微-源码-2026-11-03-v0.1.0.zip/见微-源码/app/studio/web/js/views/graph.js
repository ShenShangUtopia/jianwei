/* 见微 · 析题台 · 函数变换视图（graph）
   三件手势：拖曲线平移 · 滚轮伸缩 · 拖右环旋转
   契约：JW.registerView('graph', mountFn)；mountFn(host, q, api) -> { applyStep(i), destroy() }
*/
(function () {
  'use strict';
  const JW = window.JW;
  if (!JW || !JW.C || !JW.registerView) return;
  const C = JW.C;
  const el = JW.el;
  const PI = Math.PI, TAU = PI * 2;

  /* ================= 模式与函数族 ================= */
  const FAMILIES = {
    sin: { label: '正弦 sin x', tex: 'sin t', f: function (t) { return Math.sin(t); } },
    quad: { label: '二次 x²', tex: 't^2', f: function (t) { return t * t; } },
    cubic: { label: '三次 x³', tex: 't^3', f: function (t) { return t * t * t; } },
    inv: { label: '倒数 1/x', tex: '\\frac{1}{t}', f: function (t) { return 1 / t; } },
    sqrt: { label: '根式 √x', tex: '\\sqrt{t}', f: function (t) { return t < 0 ? NaN : Math.sqrt(t); } },
    exp: { label: '指数 e^x', tex: 'e^t', f: function (t) { return Math.exp(t); } },
    ln: { label: '对数 ln x', tex: 'ln t', f: function (t) { return t <= 0 ? NaN : Math.log(t); } },
    circle: { label: '圆 x²+y²=1', tex: '(cos t, sin t)', circle: true }
  };

  const MODES = {
    trig: {
      name: '三角', expr: 'A*sin(B*x+H)+K', ghost: 'sin(x)',
      xr: [-6.6, 6.6], yr: [-3.6, 3.6],
      params: [
        { k: 'A', label: '振幅 A', min: 0.2, max: 3, step: 0.1, v: 2 },
        { k: 'B', label: '横向伸缩 B', min: 0.3, max: 3, step: 0.1, v: 2 },
        { k: 'H', label: '相位 H', min: -6.3, max: 6.3, step: 0.05, v: PI / 3 },
        { k: 'K', label: '纵移 K', min: -3, max: 3, step: 0.1, v: -1 }
      ],
      neutral: { A: 1, B: 1, H: 0, K: 0 },
      call: '左加右减：相位 H 越大，曲线越靠左。',
      legend: '拖曲线平移 · 滚轮横向伸缩 · Shift+滚轮纵向伸缩 · 拖右环旋转'
    },
    poly: {
      name: '二次', expr: 'A*((x-H)/B)^2+K', ghost: 'x^2',
      xr: [-6.6, 6.6], yr: [-3.6, 3.6],
      params: [
        { k: 'A', label: '开口 A', min: -2, max: 2, step: 0.1, v: 0.8 },
        { k: 'B', label: '横向伸缩 B', min: 0.3, max: 3, step: 0.1, v: 1 },
        { k: 'H', label: '顶点横标 H', min: -5, max: 5, step: 0.1, v: 1 },
        { k: 'K', label: '顶点纵标 K', min: -3.5, max: 3.5, step: 0.1, v: -1.6 }
      ],
      neutral: { A: 1, B: 1, H: 0, K: 0 },
      call: '顶点在 (H, K)，A 定开口，B 管胖瘦。',
      legend: '拖曲线平移 · 滚轮横向伸缩 · Shift+滚轮纵向伸缩 · 拖右环旋转'
    },
    conic: {
      name: '圆锥曲线', expr: '', ghost: '',
      xr: [-6.6, 6.6], yr: [-3.6, 3.6],
      params: [
        { k: 'A', label: '实半轴 A', min: 0.4, max: 3, step: 0.1, v: 2 },
        { k: 'B', label: '虚半轴 B', min: 0.3, max: 3, step: 0.1, v: 1.2 },
        { k: 'H', label: '中心横标 H', min: -4, max: 4, step: 0.1, v: 0 },
        { k: 'K', label: '中心纵标 K', min: -3, max: 3, step: 0.1, v: 0 }
      ],
      neutral: { A: 1, B: 1, H: 0, K: 0 },
      call: '双曲线：两支各自逼近渐近线，准线左右对称。',
      legend: '拖中心平移 · 滚轮改实半轴 · Shift+滚轮改虚半轴 · 拖右环旋转'
    },
    piecewise: {
      name: '分段', expr: 'A*abs(B*(x-H))+K', ghost: 'abs(x)',
      xr: [-6.6, 6.6], yr: [-3.6, 3.6],
      params: [
        { k: 'A', label: '斜率 A', min: 0.2, max: 3, step: 0.1, v: 1 },
        { k: 'B', label: '横向伸缩 B', min: 0.3, max: 3, step: 0.1, v: 1 },
        { k: 'H', label: '拐点横标 H', min: -5, max: 5, step: 0.1, v: 0.5 },
        { k: 'K', label: '拐点纵标 K', min: -3, max: 3, step: 0.1, v: -0.8 }
      ],
      neutral: { A: 1, B: 1, H: 0, K: 0 },
      call: '两段直线拼成 V 形，拐点是 (H, K)。',
      legend: '拖曲线平移 · 滚轮横向伸缩 · Shift+滚轮纵向伸缩 · 拖右环旋转'
    },
    vec: {
      name: '向量', expr: '', ghost: '',
      xr: [-4.6, 4.6], yr: [-3.2, 3.2],
      params: [
        { k: 'A', label: 'u 横分量', min: -3, max: 3, step: 0.1, v: 2.4 },
        { k: 'H', label: 'u 纵分量', min: -3, max: 3, step: 0.1, v: 1.2 },
        { k: 'B', label: 'v 横分量', min: -3, max: 3, step: 0.1, v: 1.2 },
        { k: 'K', label: 'v 纵分量', min: -3, max: 3, step: 0.1, v: -1.6 }
      ],
      neutral: { A: 0, B: 0, H: 0, K: 0 },
      call: 'u 与 v 首尾相接得到 u+v；拖箭头改分量。',
      legend: '拖箭头改分量 · 滚轮改 v 的横分量 · Shift+滚轮改 u 的横分量 · 拖右环旋转'
    },
    lab: {
      name: '实验室', expr: '', ghost: '',
      xr: [-6.6, 6.6], yr: [-3.6, 3.6],
      params: [
        { k: 'A', label: '纵向伸缩 A', min: 0.2, max: 3, step: 0.1, v: 1.2 },
        { k: 'B', label: '横向伸缩 B', min: 0.2, max: 3, step: 0.1, v: 1.5 },
        { k: 'H', label: '横移 H', min: -5, max: 5, step: 0.1, v: 0.6 },
        { k: 'K', label: '纵移 K', min: -3, max: 3, step: 0.1, v: 0.3 }
      ],
      neutral: { A: 1, B: 1, H: 0, K: 0 },
      call: '选函数族，看矩阵 M 与平移向量 T 怎么改图形。',
      legend: '拖曲线平移 · 滚轮横向伸缩 · Shift+滚轮纵向伸缩 · 拖右环旋转'
    }
  };

  /* ================= 小工具 ================= */
  function near(a, b) { return Math.abs(a - b) < 1e-6; }
  function clampNum(v, a, b) { return v < a ? a : v > b ? b : v; }
  function fxNum(v, d) {
    if (!isFinite(v)) return '0';
    const t = JW.num(Math.abs(v), d == null ? 2 : d);
    return (v < 0 && parseFloat(t) > 0 ? '−' : '') + t;
  }
  function term(v, fn, pad) {
    if (Math.abs(v) < 1e-9) return '';
    const sign = v < 0 ? (pad ? ' − ' : '−') : (pad ? ' + ' : '+');
    return sign + fn(Math.abs(v));
  }
  function piParts(v) {
    if (Math.abs(v) < 5e-4) return null;
    const r = v / PI;
    for (let q = 1; q <= 12; q++) {
      const n = Math.round(r * q);
      if (n !== 0 && Math.abs(r * q - n) < 1e-7) return { n: n, q: q };
    }
    return null;
  }
  function piVal(v) {
    const p = piParts(v);
    if (!p) return fxNum(v);
    const a = Math.abs(p.n), num = a === 1 ? 'π' : a + 'π';
    return (p.n < 0 ? '−' : '') + (p.q === 1 ? num : num + '/' + p.q);
  }
  function piPlain(v) {
    const p = piParts(v);
    if (!p) return fxNum(v);
    const a = Math.abs(p.n), num = a === 1 ? 'π' : a + 'π';
    return (p.n < 0 ? '−' : '') + (p.q === 1 ? num : num + '/' + p.q);
  }
  function n2(v) {
    if (!isFinite(v)) return '0.00';
    const r = Math.abs(v) < 0.005 ? 0 : v;
    return (r < 0 ? '−' : '') + Math.abs(r).toFixed(2);
  }
  function stepFor(span) {
    const raw = Math.abs(span) / 8 || 1;
    const p = Math.pow(10, Math.floor(Math.log10(raw)));
    const n = raw / p;
    const m = n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10;
    return m * p;
  }
  function pair(v, d) {
    if (Array.isArray(v) && v.length >= 2) {
      const a = +v[0], b = +v[1];
      if (isFinite(a) && isFinite(b) && b > a) return [a, b];
    }
    return d.slice();
  }
  function acosh(x) {
    x = Math.max(1, x);
    return Math.log(x + Math.sqrt(x * x - 1));
  }

  /* ================= 注册视图 ================= */
  JW.registerView('graph', function (host, q, api) {
    if (!host) return { applyStep: function () { }, destroy: function () { } };

    /* ---------- 题目配置 ---------- */
    const qv = q && q.view ? q.view : null;
    const rawMode = qv ? String(qv.mode || '').toLowerCase() : '';
    const isLab = !qv || qv.lab === true || rawMode === 'lab';
    let mode = isLab ? 'lab' : (MODES[rawMode] ? rawMode : 'trig');
    if (!MODES[mode]) mode = 'trig';
    const def = MODES[mode];
    const spec = qv || {};

    const expr = isLab ? '' : String(spec.expr || def.expr || '');
    const xr = pair(spec.xr, def.xr);
    const yr = pair(spec.yr, def.yr);

    const srcParams = Array.isArray(spec.params) && spec.params.length ? spec.params : def.params;
    const params = srcParams.map(function (raw, i) {
      raw = raw || {};
      const base = def.params.filter(function (d) { return d.k === raw.k; })[0] || {};
      const step = isFinite(+raw.step) && +raw.step > 0 ? +raw.step : (base.step || 0.1);
      const min = isFinite(+raw.min) ? +raw.min : (isFinite(base.min) ? base.min : -5);
      const max = isFinite(+raw.max) ? +raw.max : (isFinite(base.max) ? base.max : 5);
      let v = isFinite(+raw.v) ? +raw.v : (isFinite(base.v) ? base.v : 0);
      v = Math.max(min, Math.min(max, v));
      return {
        k: String(raw.k || base.k || ('p' + i)),
        label: String(raw.label || base.label || ('参数 ' + (raw.k || i))),
        min: min, max: max, step: step, v: v,
        dec: step < 0.1 ? 3 : step < 1 ? 2 : 1,
        neutral: isFinite(+raw.neutral) ? +raw.neutral : null,
        input: null, vEl: null, wrap: null, timer: 0
      };
    });

    const S = { theta: 0 };
    params.forEach(function (p) { S[p.k] = p.v; });
    if (isLab && spec.theta != null && isFinite(+spec.theta)) {
      S.theta = clampNum(+spec.theta * PI / 180, -PI, PI);
    }
    let family = isLab ? String(spec.family || 'sin') : '';
    if (!FAMILIES[family]) family = 'sin';

    const ghostSrc = !isLab && spec.ghost ? String(spec.ghost) : (!isLab ? def.ghost : '');
    const ghostFn = ghostSrc ? JW.compile(ghostSrc) : null;

    let destroyed = false;
    let cv = null, ctx = null;
    let hitPts = [];
    let drag = null;
    let ghost = null;
    let stepNote = '';
    let tipTimer = 0, demoRAF = 0, demoBase = null;
    let fnCacheKey = '', fnCache = null;
    let formEl = null, callEl = null, matKEl = null, matVEl = null, matTEl = null;
    let kv1L = null, kv1V = null, kv2L = null, kv2V = null;
    const chipsRef = {};

    function paramOf(k) {
      for (let i = 0; i < params.length; i++) if (params[i].k === k) return params[i];
      return null;
    }
    function clampP(k, v) {
      const p = paramOf(k);
      if (!p) return v;
      return Math.max(p.min, Math.min(p.max, v));
    }
    function clampTheta(v) { return Math.max(-PI, Math.min(PI, v)); }

    /* ---------- 顶栏 ---------- */
    const root = el('div', { class: 'gx-root' });
    const top = el('div', { class: 'gx-top' });
    const eq = el('div', { class: 'gx-eq' });
    const kick = el('div', { class: 'gx-kicker' });
    const kickL = el('span', { class: 'gx-kick-l' }, isLab ? '函数族' : '解析式');
    kick.appendChild(kickL);
    let familySel = null;
    if (isLab) {
      familySel = el('select', { class: 'gx-sel' });
      Object.keys(FAMILIES).forEach(function (key) {
        familySel.appendChild(el('option', { value: key }, FAMILIES[key].label));
      });
      familySel.value = family;
      familySel.addEventListener('change', function () {
        family = FAMILIES[familySel.value] ? familySel.value : 'sin';
        stopDemo(false);
        ghost = null;
        updateText();
        draw();
      });
      kick.appendChild(familySel);
    } else {
      kick.appendChild(el('span', { class: 'gx-kick-m' }, def.name));
    }
    formEl = el('div', { class: 'jw-form gx-form' });
    callEl = el('div', { class: 'gx-call' });
    eq.appendChild(kick);
    eq.appendChild(formEl);
    eq.appendChild(callEl);

    const mat = el('div', { class: 'gx-mat' });
    matKEl = el('div', { class: 'gx-mat-k' });
    matVEl = el('div', { class: 'gx-mat-v' });
    matTEl = el('div', { class: 'gx-mat-t' });
    mat.appendChild(matKEl);
    mat.appendChild(matVEl);
    mat.appendChild(matTEl);

    top.appendChild(eq);
    top.appendChild(mat);

    /* ---------- 画布与控制列 ---------- */
    const grid = el('div', { class: 'jw-stage-grid gx-grid' });
    const plot = el('div', { class: 'jw-plot gx-plot' });
    const side = el('div', { class: 'jw-ctrl gx-side' });

    const chips = JW.ui.chips(['平移', '伸缩', '旋转'], '平移', function (name) {
      markChip(name);
      demo(name);
    });
    chipsRef.row = chips;
    side.appendChild(chips);

    side.appendChild(el('div', { class: 'jw-sec' }, '参数'));

    const ctlBox = el('div', { class: 'gx-ctls' });
    params.forEach(function (p) {
      const o = {
        label: p.label, min: p.min, max: p.max, step: p.step,
        value: S[p.k], dec: p.dec
      };
      const wrap = JW.ui.range(o, function (v) {
        stopDemo(true);
        S[p.k] = v;
        updateText();
        draw();
      });
      p.input = o.input;
      p.vEl = wrap.querySelector('.jw-ctl-v');
      p.wrap = wrap;
      ctlBox.appendChild(wrap);
    });
    side.appendChild(ctlBox);

    side.appendChild(el('div', { class: 'gx-sep' }));
    const stats = el('div', { class: 'gx-stats' });
    function statRow() {
      const row = el('div', { class: 'jw-kv gx-kv' });
      const l = el('span', {}, '');
      const v = el('b', {}, '');
      row.appendChild(l); row.appendChild(v);
      stats.appendChild(row);
      return { l: l, v: v };
    }
    const s1 = statRow(), s2 = statRow();
    kv1L = s1.l; kv1V = s1.v; kv2L = s2.l; kv2V = s2.v;
    side.appendChild(stats);

    const resetBtn = el('button', { class: 'jw-btn gx-reset', type: 'button' }, '复位');
    resetBtn.addEventListener('click', doReset);
    side.appendChild(resetBtn);

    const legend = el('div', { class: 'gx-legend' }, def.legend || '');
    const tip = el('div', { class: 'gx-tip' });
    plot.appendChild(legend);
    plot.appendChild(tip);

    grid.appendChild(plot);
    grid.appendChild(side);
    root.appendChild(top);
    root.appendChild(grid);

    host.appendChild(root);

    cv = JW.Canvas(plot, { xRange: xr, yRange: yr });
    cv.cv.setAttribute('aria-label', '函数变换画布');
    ctx = cv.ctx;
    cv.render = function () { draw(); };

    /* ---------- 表达式与采样 ---------- */
    function substitute(src) {
      let s = String(src);
      Object.keys(S).forEach(function (k) {
        if (k === 'theta' || k === 'x' || k === 'y' || k === 't') return;
        const v = S[k];
        if (typeof v !== 'number' || !isFinite(v)) return;
        s = s.replace(new RegExp('\\b' + k + '\\b', 'g'), '(' + v + ')');
      });
      return s;
    }
    function currentFn() {
      if (!expr) return function () { return NaN; };
      const key = expr + '|' + Object.keys(S).map(function (k) { return S[k]; }).join(',');
      if (key !== fnCacheKey) {
        fnCacheKey = key;
        fnCache = JW.compile(substitute(expr));
      }
      return fnCache;
    }
    function sampleFn(f, a, b, n) {
      const segs = [];
      let seg = [], prev = null;
      for (let i = 0; i <= n; i++) {
        const x = a + (b - a) * i / n;
        let y;
        try { y = f(x); } catch (e) { y = NaN; }
        if (typeof y !== 'number' || !isFinite(y) || Math.abs(y) > 1e7) {
          if (seg.length > 1) segs.push(seg);
          seg = []; prev = null; continue;
        }
        const Y = cv.py(y);
        if (prev != null && Math.abs(Y - prev) > cv.h * 0.6) {
          if (seg.length > 1) segs.push(seg);
          seg = [];
        }
        seg.push([x, y]);
        prev = Y;
      }
      if (seg.length > 1) segs.push(seg);
      return segs;
    }
    function conicSegs() {
      const A = Math.max(0.05, Math.abs(S.A)), B = Math.max(0.05, Math.abs(S.B));
      const H = S.H, K = S.K;
      const far = Math.max(Math.abs(xr[0] - H), Math.abs(xr[1] - H));
      const tmax = Math.min(3.4, Math.max(1.2, acosh(far / A + 0.3)));
      const n = 360, right = [], left = [];
      for (let i = 0; i <= n; i++) {
        const t = -tmax + 2 * tmax * i / n;
        const ch = Math.cosh(t), sh = Math.sinh(t);
        right.push([H + A * ch, K + B * sh]);
        left.push([H - A * ch, K + B * sh]);
      }
      return [right, left];
    }
    function vecSegs() {
      const u = [S.A, S.H], v = [S.B, S.K], r = [S.A + S.B, S.H + S.K];
      return [[[0, 0], u], [[0, 0], v], [[0, 0], r]];
    }
    function labBaseSegs() {
      const fam = FAMILIES[family];
      if (fam.circle) {
        const pts = [];
        for (let i = 0; i <= 260; i++) {
          const t = i / 260 * TAU;
          pts.push([Math.cos(t), Math.sin(t)]);
        }
        return [pts];
      }
      const b = Math.abs(S.B) < 0.05 ? 0.05 : S.B;
      let t0 = (xr[0] - 6) / b, t1 = (xr[1] + 6) / b;
      if (t1 < t0) { const tmp = t0; t0 = t1; t1 = tmp; }
      const fn = fam.f;
      return sampleFn(fn, t0, t1, 1100);
    }
    function labSegs() {
      const th = S.theta, c = Math.cos(th), s = Math.sin(th);
      const base = labBaseSegs();
      return base.map(function (seg) {
        return seg.map(function (p) {
          const X = S.B * p[0], Y = S.A * p[1];
          return [c * X - s * Y + S.H, s * X + c * Y + S.K];
        });
      });
    }
    function currentSegs() {
      if (isLab) return labSegs();
      if (mode === 'conic') return conicSegs();
      if (mode === 'vec') return vecSegs();
      return sampleFn(currentFn(), xr[0], xr[1], Math.max(500, Math.min(1500, Math.round(cv.w * 1.3))));
    }
    function rotPt(p, th) {
      if (!th) return [p[0], p[1]];
      const c = Math.cos(th), s = Math.sin(th);
      return [p[0] * c - p[1] * s, p[0] * s + p[1] * c];
    }
    function invRotPt(p, th) {
      const c = Math.cos(th), s = Math.sin(th);
      return [p[0] * c + p[1] * s, -p[0] * s + p[1] * c];
    }
    function rotSegs(segs, th) {
      if (!th) return segs;
      return segs.map(function (seg) {
        const out = [];
        for (let i = 0; i < seg.length; i++) out.push(rotPt(seg[i], th));
        return out;
      });
    }

    /* ---------- 画布基础 ---------- */
    function label(x, y, text, o) {
      o = o || {};
      ctx.save();
      ctx.font = (o.weight || 400) + ' ' + (o.size || 10) + 'px ' + (o.font || C.sans);
      ctx.textAlign = o.align || 'left';
      ctx.textBaseline = o.base || 'middle';
      ctx.lineJoin = 'round';
      if (o.halo !== false) {
        ctx.lineWidth = 3.2;
        ctx.strokeStyle = C.paper;
        ctx.strokeText(text, x, y);
      }
      ctx.fillStyle = o.color || C.ink;
      ctx.fillText(text, x, y);
      ctx.restore();
    }
    function dot(x, y, r, fill, stroke) {
      ctx.save();
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
      ctx.fillStyle = fill || C.ink; ctx.fill();
      if (stroke) { ctx.lineWidth = 1.4; ctx.strokeStyle = stroke; ctx.stroke(); }
      ctx.restore();
    }
    function paint(segs, color, width, dash, alpha) {
      if (!segs || !segs.length) return;
      ctx.save();
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.strokeStyle = color || C.ink; ctx.lineWidth = width || 1.5;
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      if (dash) ctx.setLineDash(dash);
      ctx.beginPath();
      for (let s = 0; s < segs.length; s++) {
        const seg = segs[s];
        for (let i = 0; i < seg.length; i++) {
          const X = cv.px(seg[i][0]), Y = cv.py(seg[i][1]);
          if (i === 0) ctx.moveTo(X, Y); else ctx.lineTo(X, Y);
        }
      }
      ctx.stroke();
      ctx.restore();
    }
    function toScreen(p) { return [cv.px(p[0]), cv.py(p[1])]; }
    function inCanvas(X, Y, m) {
      m = m == null ? 8 : m;
      return X > -m && X < cv.w + m && Y > -m && Y < cv.h + m;
    }

    /* ---------- 网格 ---------- */
    function drawGrid() {
      cv.grid(stepFor(xr[1] - xr[0]), { labels: true });
    }

    /* ---------- 参考原曲线 ---------- */
    function drawRefGhost() {
      if (!ghostFn) return;
      const segs = sampleFn(ghostFn, xr[0], xr[1], 700);
      paint(segs, C.data[2], 1.2, [4, 5], 0.55);
      let pick = null;
      for (let s = 0; s < segs.length && !pick; s++) {
        const seg = segs[s];
        for (let i = seg.length - 1; i >= 0; i--) {
          const X = cv.px(seg[i][0]), Y = cv.py(seg[i][1]);
          if (X > cv.w * 0.55 && X < cv.w - 16 && Y > 24 && Y < cv.h - 42) { pick = [X, Y]; break; }
        }
      }
      if (pick) label(pick[0] + 6, pick[1] - 9, '原函数', { size: 9.5, color: C.data[2] });
    }

    /* ---------- 辅助线 ---------- */
    function drawGuides() {
      if (isLab || mode === 'vec') return;
      if (mode === 'poly') {
        const a = rotPt([S.H, yr[0]], S.theta), b = rotPt([S.H, yr[1]], S.theta);
        paint([[a, b]], C.grid, 1, [3, 5], 1);
      }
      if (mode === 'conic') {
        const A = Math.max(0.05, Math.abs(S.A)), B = Math.max(0.05, Math.abs(S.B));
        const H = S.H, K = S.K, m = B / A;
        const c = Math.sqrt(A * A + B * B);
        const L = Math.max(Math.abs(xr[0]), Math.abs(xr[1])) + 4;
        const asym = [
          [rotPt([H - L, K - m * L], S.theta), rotPt([H + L, K + m * L], S.theta)],
          [rotPt([H - L, K + m * L], S.theta), rotPt([H + L, K - m * L], S.theta)]
        ];
        paint(asym, C.data[2], 1, [5, 5], 0.8);
        const dx = A * A / c;
        const directs = [
          [rotPt([H + dx, yr[0]], S.theta), rotPt([H + dx, yr[1]], S.theta)],
          [rotPt([H - dx, yr[0]], S.theta), rotPt([H - dx, yr[1]], S.theta)]
        ];
        paint(directs, C.ink2, 1, [2, 4], 0.55);
        const la = toScreen(rotPt([H + L * 0.72, K + m * L * 0.72], S.theta));
        if (inCanvas(la[0], la[1], -6)) label(la[0] - 12, la[1] - 10, '渐近线', { size: 9, color: C.data[2], align: 'right' });
        const ld = toScreen(rotPt([H + dx, yr[1]], S.theta));
        if (inCanvas(ld[0], ld[1], 0)) label(ld[0] + 4, ld[1] + 12, '准线', { size: 9, color: C.ink2 });
      }
    }

    /* ---------- 主曲线 ---------- */
    function drawCurve(segs) {
      paint(segs, C.ink, 2.2);
      hitPts = [];
      for (let s = 0; s < segs.length; s++) {
        const seg = segs[s];
        for (let i = 0; i < seg.length; i += 2) hitPts.push([cv.px(seg[i][0]), cv.py(seg[i][1])]);
      }
    }

    function drawVectors(segs) {
      if (segs.length < 3) return;
      const u = segs[0][1], v = segs[1][1], r = segs[2][1];
      const o = [0, 0];
      paint([[[u[0], u[1]], [r[0], r[1]]], [[v[0], v[1]], [r[0], r[1]]]], C.data[3], 1, [3, 4], 1);
      cv.arrow(o[0], o[1], u[0], u[1], { color: C.ink, width: 2, head: 9 });
      cv.arrow(o[0], o[1], v[0], v[1], { color: C.ink2, width: 2, head: 9 });
      cv.arrow(o[0], o[1], r[0], r[1], { color: C.accent, width: 1.7, head: 10 });
      const su = toScreen(u), sv = toScreen(v), sr = toScreen(r);
      dot(su[0], su[1], 2.6, C.ink);
      dot(sv[0], sv[1], 2.6, C.ink2);
      dot(sr[0], sr[1], 3, C.accent);
      label(su[0] + 8, su[1] - 10, 'u', { size: 11, weight: 600, color: C.ink });
      label(sv[0] + 8, sv[1] - 10, 'v', { size: 11, weight: 600, color: C.ink2 });
      label(sr[0] + 8, sr[1] + 14, 'u + v', { size: 10.5, weight: 600, color: C.accent });
      dot(cv.px(0), cv.py(0), 2.4, C.ink);
      hitPts = [];
      for (let s = 0; s < segs.length; s++) {
        for (let i = 0; i < segs[s].length; i += 1) {
          hitPts.push([cv.px(segs[s][i][0]), cv.py(segs[s][i][1])]);
        }
      }
    }

    /* ---------- 标注 ---------- */
    function drawMarks() {
      const marks = Array.isArray(spec.marks) ? spec.marks : [];
      for (let i = 0; i < marks.length; i++) {
        const m = marks[i] || {};
        const mx = +m.x, my = +m.y;
        if (!isFinite(mx) || !isFinite(my)) continue;
        const p = rotPt([mx, my], S.theta);
        const X = cv.px(p[0]), Y = cv.py(p[1]);
        if (!inCanvas(X, Y, 20)) continue;
        dot(X, Y, 3.6, C.ink2, C.card);
        if (m.label) label(X + 7, Y - 9, String(m.label), { size: 9.5, color: C.ink });
      }
    }

    function trigKeys() {
      const B = Math.abs(S.B) < 1e-6 ? 1e-6 : S.B;
      const H = S.H, A = S.A, K = S.K;
      const xc = (xr[0] + xr[1]) / 2;
      const n0 = Math.round((B * xc + H) / (PI / 2)) - 2;
      const pts = [];
      for (let j = 0; j < 5; j++) {
        const n = n0 + j;
        const m = ((n % 4) + 4) % 4;
        const x = (n * PI / 2 - H) / B;
        let y = K, kind = 'zero';
        if (m === 1) { y = K + A; kind = A >= 0 ? 'peak' : 'trough'; }
        if (m === 3) { y = K - A; kind = A >= 0 ? 'trough' : 'peak'; }
        pts.push({ x: x, y: y, kind: kind });
      }
      return pts;
    }

    function drawTrigKeys() {
      const keys = trigKeys();
      const T = TAU / Math.max(1e-6, Math.abs(S.B));
      const zeros = [];
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        const p = rotPt([k.x, k.y], S.theta);
        const X = cv.px(p[0]), Y = cv.py(p[1]);
        if (!inCanvas(X, Y, 4)) continue;
        if (k.kind === 'zero') {
          dot(X, Y, 2.7, C.card, C.ink2);
          zeros.push(k.x);
        } else {
          dot(X, Y, 3.1, C.accent, C.card);
          label(X, Y + (k.kind === 'peak' ? -13 : 15), k.kind === 'peak' ? '峰' : '谷',
            { size: 9.5, color: C.accent, align: 'center' });
        }
      }
      if (Math.abs(S.theta) > 1e-3 || zeros.length < 2) return;
      const x1 = zeros[0], x2 = zeros[1];
      const X1 = cv.px(x1), X2 = cv.px(x2);
      if (X1 < 4 || X2 > cv.w - 4 || X2 - X1 < 18) return;
      const yb = cv.h - 42;
      ctx.save();
      ctx.strokeStyle = C.ink2; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(X1, yb - 4); ctx.lineTo(X1, yb + 4);
      ctx.moveTo(X2, yb - 4); ctx.lineTo(X2, yb + 4);
      ctx.moveTo(X1, yb); ctx.lineTo(X2, yb);
      ctx.stroke();
      ctx.restore();
      label((X1 + X2) / 2, yb + 15, 'T = ' + piPlain(T), { size: 9.5, color: C.faint, align: 'center' });
    }

    function drawPolyKeys() {
      const A = S.A, B = S.B, H = S.H, K = S.K;
      const vp = rotPt([H, K], S.theta);
      const vX = cv.px(vp[0]), vY = cv.py(vp[1]);
      if (inCanvas(vX, vY, 20)) {
        dot(vX, vY, 3.4, C.accent, C.card);
        label(vX + 8, vY - 11, '顶点 (' + fxNum(H) + ', ' + fxNum(K) + ')', { size: 9.5, color: C.ink });
      }
      if (Math.abs(A) > 1e-6) {
        const q = -K / A;
        if (q >= 0) {
          const d = Math.abs(B) * Math.sqrt(q);
          [H - d, H + d].forEach(function (x) {
            const p = rotPt([x, 0], S.theta);
            const X = cv.px(p[0]), Y = cv.py(p[1]);
            if (!inCanvas(X, Y, 20)) return;
            dot(X, Y, 2.8, C.card, C.ink2);
            label(X, Y - 12, '(' + fxNum(x) + ', 0)', { size: 9, color: C.ink2, align: 'center' });
          });
        }
      }
    }

    function drawPieceKeys() {
      const p = rotPt([S.H, S.K], S.theta);
      const X = cv.px(p[0]), Y = cv.py(p[1]);
      if (!inCanvas(X, Y, 20)) return;
      dot(X, Y, 3.4, C.accent, C.card);
      label(X + 8, Y - 12, '拐点 (' + fxNum(S.H) + ', ' + fxNum(S.K) + ')', { size: 9.5, color: C.ink });
    }

    function drawConicKeys() {
      const p = rotPt([S.H, S.K], S.theta);
      const X = cv.px(p[0]), Y = cv.py(p[1]);
      if (inCanvas(X, Y, 20)) {
        dot(X, Y, 3.2, C.accent, C.card);
        label(X + 8, Y - 11, '中心', { size: 9.5, color: C.ink });
      }
    }

    function drawAnnotations() {
      if (isLab) { drawMarks(); return; }
      if (mode === 'trig') drawTrigKeys();
      else if (mode === 'poly') drawPolyKeys();
      else if (mode === 'conic') drawConicKeys();
      else if (mode === 'piecewise') drawPieceKeys();
      drawMarks();
    }

    /* ---------- 手柄与角度弧 ---------- */
    function drawHandle() {
      const hx = cv.w - 38, hy = cv.h * 0.5;
      ctx.save();
      ctx.beginPath(); ctx.arc(hx, hy, 20, 0, TAU);
      ctx.fillStyle = C.card; ctx.fill();
      ctx.strokeStyle = C.accent; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.beginPath(); ctx.arc(hx, hy, 10.5, -2.55, 0.65);
      ctx.strokeStyle = C.accent; ctx.lineWidth = 1.2; ctx.stroke();
      const ea = 0.65;
      ctx.beginPath();
      ctx.moveTo(hx + Math.cos(ea) * 13.4, hy + Math.sin(ea) * 13.4);
      ctx.lineTo(hx + Math.cos(ea - 0.62) * 6.4, hy + Math.sin(ea - 0.62) * 6.4);
      ctx.lineTo(hx + Math.cos(ea - 0.62) * 13.6, hy + Math.sin(ea - 0.62) * 13.6);
      ctx.closePath(); ctx.fillStyle = C.accent; ctx.fill();
      ctx.beginPath(); ctx.arc(hx, hy, 1.6, 0, TAU); ctx.fillStyle = C.accent; ctx.fill();
      ctx.restore();
      label(hx, hy + 32, '旋转', { size: 9.5, color: C.faint, align: 'center' });
      if (Math.abs(S.theta) > 1e-3) drawThetaArc(S.theta);
    }

    function drawThetaArc(to) {
      const ox = cv.px(0), oy = cv.py(0);
      if (!inCanvas(ox, oy, 0)) return;
      const r = Math.min(82, Math.max(42, Math.min(cv.w, cv.h) * 0.17));
      ctx.save();
      ctx.beginPath(); ctx.arc(ox, oy, r, 0, -to, to > 0);
      ctx.strokeStyle = C.accent; ctx.lineWidth = 1.3; ctx.setLineDash([3, 4]);
      ctx.stroke();
      const ea = -to;
      const ex = ox + Math.cos(ea) * r, ey = oy + Math.sin(ea) * r;
      const dir = to > 0 ? 1 : -1;
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(ex, ey);
      ctx.lineTo(ex - 7 * Math.cos(ea - dir * 0.38), ey - 7 * Math.sin(ea - dir * 0.38));
      ctx.lineTo(ex - 7 * Math.cos(ea + dir * 0.38), ey - 7 * Math.sin(ea + dir * 0.38));
      ctx.closePath(); ctx.fillStyle = C.accent; ctx.fill();
      ctx.restore();
      const mid = -to / 2;
      label(ox + Math.cos(mid) * (r + 16), oy + Math.sin(mid) * (r + 16),
        'θ ' + JW.num(Math.abs(to * 180 / PI), 0) + '°',
        { size: 9, color: C.accent, align: 'center' });
    }

    /* ---------- 拖动痕迹（原曲线 / 箭头） ---------- */
    function drawGhost() {
      if (!ghost) return;
      if (ghost.segs) paint(ghost.segs, C.accent, 1.3, [4, 5], 0.55);
      if (ghost.arrow) {
        cv.arrow(ghost.arrow.from[0], ghost.arrow.from[1], ghost.arrow.to[0], ghost.arrow.to[1],
          { color: C.accent, width: 1.3, head: 8 });
        label(ghost.arrow.from[0] + 9, ghost.arrow.from[1] - 11, '原曲线',
          { size: 9, color: C.accent });
      }
      if (ghost.thetaFrom != null) {
        const a = ghost.thetaFrom, b = S.theta;
        if (Math.abs(b - a) > 1e-4) {
          const ox = cv.px(0), oy = cv.py(0);
          if (inCanvas(ox, oy, 0)) {
            const r = Math.min(96, Math.max(52, Math.min(cv.w, cv.h) * 0.2));
            ctx.save();
            ctx.beginPath(); ctx.arc(ox, oy, r, -a, -b, b > a);
            ctx.strokeStyle = C.accent; ctx.lineWidth = 1.2; ctx.setLineDash([2, 4]);
            ctx.stroke(); ctx.restore();
          }
        }
      }
    }

    /* ---------- 绘制主流程 ---------- */
    function draw() {
      if (destroyed || !cv || !ctx) return;
      if (cv.w < 40 || cv.h < 40) return;
      cv.clear(C.card);
      drawGrid();
      drawRefGhost();
      drawGuides();
      const pre = currentSegs();
      const rotated = isLab ? pre : rotSegs(pre, S.theta);
      if (mode === 'vec' && !isLab) drawVectors(rotated);
      else drawCurve(rotated);
      drawAnnotations();
      drawGhost();
      drawHandle();
    }

    /* ---------- 公式 ---------- */
    function trigEq() {
      const A = S.A, B = S.B, H = S.H, K = S.K;
      const inner = (near(B, 1) ? 'x' : fxNum(B) + 'x') + term(H, piVal, false);
      const head = near(A, 1) ? '' : near(A, -1) ? '−' : fxNum(A);
      return 'y = ' + head + 'sin(' + inner + ')' + term(K, fxNum, true);
    }
    function polyEq() {
      const A = S.A, B = S.B, H = S.H, K = S.K;
      const xp = near(H, 0) ? 'x' : '(x' + term(-H, function (v) { return fxNum(v); }, true) + ')';
      let sq;
      if (near(B, 1)) sq = xp + '^2';
      else sq = '(\\frac{' + xp + '}{' + fxNum(B) + '})^2';
      const head = near(A, 1) ? '' : near(A, -1) ? '−' : fxNum(A);
      return 'y = ' + head + sq + term(K, fxNum, true);
    }
    function pieceEq() {
      const A = S.A, B = S.B, H = S.H, K = S.K;
      const xp = near(H, 0) ? 'x' : 'x' + term(-H, function (v) { return fxNum(v); }, true);
      const inner = near(B, 1) ? xp : fxNum(B) + '(' + xp + ')';
      const head = near(A, 1) ? '' : fxNum(A);
      return 'y = ' + head + '|' + inner + '|' + term(K, fxNum, true);
    }
    function conicEq() {
      const A = Math.abs(S.A), B = Math.abs(S.B), H = S.H, K = S.K;
      const nx = near(H, 0) ? 'x^2' : '(x' + term(-H, function (v) { return fxNum(v); }, true) + ')^2';
      const ny = near(K, 0) ? 'y^2' : '(y' + term(-K, function (v) { return fxNum(v); }, true) + ')^2';
      return '\\frac{' + nx + '}{' + fxNum(A) + '^2} − \\frac{' + ny + '}{' + fxNum(B) + '^2} = 1';
    }
    function vecEq() {
      return 'u = (' + fxNum(S.A) + ', ' + fxNum(S.H) + ')，v = (' + fxNum(S.B) + ', ' +
        fxNum(S.K) + ')，u + v = (' + fxNum(S.A + S.B) + ', ' + fxNum(S.H + S.K) + ')';
    }
    function labEq() {
      const fam = FAMILIES[family];
      if (fam.circle) return 'p(t) = M·(cos t, sin t) + T';
      return 'p(t) = M·(t, ' + fam.tex + ') + T';
    }
    function eqText() {
      if (isLab) return labEq();
      // 题目带了 expr：直接显示代入当前参数后的真实解析式
      if (expr) return exprDisplay();
      if (mode === 'conic') return conicEq();
      if (mode === 'vec') return vecEq();
      if (mode === 'poly') return polyEq();
      if (mode === 'piecewise') return pieceEq();
      return trigEq();
    }

    /* ---------- 由 expr + 当前参数求值 ---------- */
    function substDisplay() {
      let s = String(expr);
      Object.keys(S).forEach(function (k) {
        if (k === 'theta' || k === 'x' || k === 'y' || k === 't') return;
        const v = S[k];
        if (typeof v !== 'number' || !isFinite(v)) return;
        const txt = v < 0 ? '(' + fxNum(v) + ')' : fxNum(v);
        s = s.replace(new RegExp('\\b' + k + '\\b', 'g'), txt);
      });
      s = s.replace(/\*\*/g, '^');
      s = s.replace(/(\d)\*([a-zA-Z(√])/g, '$1$2');
      s = s.replace(/\b1\(/g, '(');
      s = s.replace(/\/1\)/g, ')');
      s = s.replace(/\+\([−-]([\d.]+)\)/g, ' − $1');
      s = s.replace(/[−-]\([−-]([\d.]+)\)/g, '+ $1');
      s = s.replace(/\+0(?![\d.])/g, '');
      s = s.replace(/\(\(([^()]*)\)\)/g, '($1)');
      s = s.replace(/([0-9a-zA-Z)])[−-]([0-9a-zA-Z(])/g, '$1−$2');
      s = s.replace(/^[−-]/, '−');
      return s;
    }
    function exprDisplay() {
      return 'y = ' + substDisplay();
    }

    function samplesOf(n) {
      const f = currentFn();
      const a = cv.xr[0], b = cv.xr[1];
      const xs = [], ys = [];
      for (let i = 0; i <= n; i++) {
        const x = a + (b - a) * i / n;
        let y = NaN;
        try { y = f(x); } catch (e) { y = NaN; }
        xs.push(x); ys.push(y);
      }
      return { f: f, a: a, b: b, xs: xs, ys: ys };
    }
    function quadVertex() {
      // 三点定二次：顶点由 expr 实算，不再照抄画布里的 H/K
      const s = samplesOf(12);
      const pick = function (i) { return [s.xs[i], s.ys[i]]; };
      const p1 = pick(3), p2 = pick(6), p3 = pick(9);
      if (![p1[1], p2[1], p3[1]].every(isFinite)) return null;
      const x1 = p1[0], x2 = p2[0], x3 = p3[0];
      const y1 = p1[1], y2 = p2[1], y3 = p3[1];
      const den = (x1 - x2) * (x1 - x3) * (x2 - x3);
      if (Math.abs(den) < 1e-12) return null;
      const A = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / den;
      const B = (x3 * x3 * (y1 - y2) + x2 * x2 * (y3 - y1) + x1 * x1 * (y2 - y3)) / den;
      const Cc = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + x1 * x2 * (x1 - x2) * y3) / den;
      if (Math.abs(A) < 1e-7) return null;
      return { x: -B / (2 * A), y: Cc - B * B / (4 * A), up: A > 0 };
    }
    function extremaInfo() {
      const s = samplesOf(1600);
      const ys = s.ys;
      const max = [];
      let lo = Infinity, hi = -Infinity;
      for (let i = 1; i < ys.length - 1; i++) {
        const v = ys[i];
        if (!isFinite(v)) continue;
        lo = Math.min(lo, v); hi = Math.max(hi, v);
        if (v > ys[i - 1] && v >= ys[i + 1]) max.push(s.xs[i]);
      }
      let period = null;
      const gaps = [];
      for (let i = 1; i < max.length; i++) gaps.push(max[i] - max[i - 1]);
      if (gaps.length) {
        gaps.sort(function (a, b) { return a - b; });
        const med = gaps[Math.floor(gaps.length / 2)];
        if (med > 1e-3) period = med;
      }
      return { lo: lo, hi: hi, amp: (hi - lo) / 2, period: period };
    }

    /* ---------- 矩阵 ---------- */
    function matrixInfo() {
      const c = Math.cos(S.theta), s = Math.sin(S.theta);
      if (isLab) {
        return { kicker: '变换矩阵 M', a: c * S.B, b: -s * S.A, c: s * S.B, d: c * S.A, trans: true };
      }
      if (mode === 'vec') {
        return {
          kicker: '向量矩阵 R·M',
          a: c * S.A - s * S.H, b: c * S.B - s * S.K,
          c: s * S.A + c * S.H, d: s * S.B + c * S.K, trans: false
        };
      }
      return { kicker: '旋转矩阵 R', a: c, b: -s, c: s, d: c, trans: false };
    }
    function renderMatrix() {
      const m = matrixInfo();
      const deg = Math.round(S.theta * 180 / PI);
      matKEl.innerHTML = '<span class="gx-mat-l">' + m.kicker + '</span>' +
        '<span class="gx-mat-th">θ ' + (deg < 0 ? '−' + Math.abs(deg) : deg) + '°</span>';
      matVEl.innerHTML = '[[' + n2(m.a) + ', ' + n2(m.b) + ']<br>[' + n2(m.c) + ', ' + n2(m.d) + ']]';
      if (m.trans) {
        matTEl.style.display = '';
        matTEl.textContent = 'T = (' + fxNum(S.H) + ', ' + fxNum(S.K) + ')';
      } else {
        matTEl.style.display = 'none';
        matTEl.textContent = '';
      }
    }

    /* ---------- 侧栏读数 ---------- */
    function renderStats() {
      if (isLab) {
        kv1L.textContent = 'det M';
        kv1V.textContent = fxNum(S.A * S.B);
        kv2L.textContent = '平移 T';
        kv2V.textContent = '(' + fxNum(S.H) + ', ' + fxNum(S.K) + ')';
        return;
      }
      if (mode === 'trig') {
        const e = expr ? extremaInfo() : null;
        kv1L.textContent = '周期 T';
        kv1V.textContent = (e && e.period)
          ? fxNum(e.period, 2)
          : piPlain(TAU / Math.max(1e-6, Math.abs(S.B)));
        kv2L.textContent = e ? '振幅' : '横移';
        kv2V.textContent = e
          ? fxNum(e.amp, 2)
          : piPlain(-S.H / (Math.abs(S.B) < 1e-6 ? 1e-6 : S.B));
        return;
      }
      if (mode === 'poly') {
        const q = expr ? quadVertex() : null;
        kv1L.textContent = '顶点';
        kv1V.textContent = q
          ? '(' + fxNum(q.x, 2) + ', ' + fxNum(q.y, 2) + ')'
          : '(' + fxNum(S.H) + ', ' + fxNum(S.K) + ')';
        kv2L.textContent = '开口';
        kv2V.textContent = q ? (q.up ? '向上' : '向下') : (S.A >= 0 ? '向上' : '向下');
        return;
      }
      if (mode === 'piecewise') {
        kv1L.textContent = '拐点';
        kv1V.textContent = '(' + fxNum(S.H) + ', ' + fxNum(S.K) + ')';
        kv2L.textContent = '两段斜率';
        kv2V.textContent = '±' + fxNum(Math.abs(S.A * S.B));
        return;
      }
      if (mode === 'conic') {
        const A = Math.abs(S.A), B = Math.abs(S.B);
        kv1L.textContent = '中心';
        kv1V.textContent = '(' + fxNum(S.H) + ', ' + fxNum(S.K) + ')';
        kv2L.textContent = '离心率 e';
        kv2V.textContent = fxNum(Math.sqrt(A * A + B * B) / Math.max(1e-6, A));
        return;
      }
      kv1L.textContent = '合成 u + v';
      kv1V.textContent = '(' + fxNum(S.A + S.B) + ', ' + fxNum(S.H + S.K) + ')';
      kv2L.textContent = '模长';
      kv2V.textContent = fxNum(Math.sqrt(Math.pow(S.A + S.B, 2) + Math.pow(S.H + S.K, 2)));
    }

    /* ---------- 文案 ---------- */
    function defaultCall() {
      if (isLab) return '选函数族，拖曲线平移，滚轮伸缩，拖右环旋转。';
      return def.call || '';
    }
    function renderCall() {
      if (stepNote) {
        callEl.textContent = stepNote;
        callEl.className = 'gx-call gx-call-step';
      } else {
        callEl.textContent = (spec.call != null && spec.call !== '') ? String(spec.call) : defaultCall();
        callEl.className = 'gx-call';
      }
    }
    function updateText() {
      if (destroyed) return;
      formEl.innerHTML = JW.fx(eqText());
      renderMatrix();
      renderStats();
      renderCall();
    }

    function syncSliders() {
      params.forEach(function (p) {
        if (!p.input) return;
        p.input.value = S[p.k];
        if (p.vEl) p.vEl.textContent = JW.num(S[p.k], p.dec);
      });
    }
    function syncAll() {
      syncSliders();
      updateText();
      draw();
    }

    /* ---------- 提示与闪烁 ---------- */
    function showTip(text, p) {
      tip.textContent = text;
      tip.style.left = Math.max(8, Math.min(cv.w - 168, p.x + 14)) + 'px';
      tip.style.top = Math.max(8, p.y - 36) + 'px';
      tip.classList.add('is-on');
      clearTimeout(tipTimer);
      tipTimer = setTimeout(function () {
        if (!destroyed) tip.classList.remove('is-on');
      }, 1300);
    }
    function hideTip() {
      clearTimeout(tipTimer);
      if (tip) tip.classList.remove('is-on');
    }
    function flash(k) {
      const p = paramOf(k);
      if (!p || !p.wrap) return;
      p.wrap.classList.add('gx-hit');
      clearTimeout(p.timer);
      p.timer = setTimeout(function () {
        if (!destroyed) p.wrap.classList.remove('gx-hit');
      }, 460);
    }
    function markChip(name) {
      if (!chipsRef.row) return;
      const list = chipsRef.row.querySelectorAll('.jw-chip');
      for (let i = 0; i < list.length; i++) list[i].classList.toggle('is-on', list[i].textContent === name);
    }

    /* ---------- 演示动画 ---------- */
    function stopDemo(restore) {
      if (demoRAF) { cancelAnimationFrame(demoRAF); demoRAF = 0; }
      if (restore && demoBase) {
        Object.keys(demoBase).forEach(function (k) { S[k] = demoBase[k]; });
        syncAll();
      }
      demoBase = null;
    }
    function demo(name) {
      stopDemo(true);
      const base = { theta: S.theta };
      params.forEach(function (p) { base[p.k] = S[p.k]; });
      demoBase = base;
      const t0 = (window.performance && performance.now) ? performance.now() : Date.now();
      const dur = 560;
      function frame(now) {
        if (destroyed) return;
        const t = Math.min(1, (now - t0) / dur);
        const w = Math.sin(PI * t);
        if (name === '平移') {
          if ('H' in base) S.H = clampP('H', base.H + (mode === 'trig' ? -0.85 : 0.85) * w);
          if ('K' in base) S.K = clampP('K', base.K + 0.55 * w);
        } else if (name === '伸缩') {
          if ('B' in base) S.B = clampP('B', base.B * (1 + 0.45 * w));
          if ('A' in base) S.A = clampP('A', base.A * (1 + 0.32 * w));
        } else {
          S.theta = clampTheta(base.theta + (30 * PI / 180) * w);
        }
        syncAll();
        if (t < 1) demoRAF = requestAnimationFrame(frame);
        else { demoRAF = 0; demoBase = null; }
      }
      demoRAF = requestAnimationFrame(frame);
    }

    /* ---------- 拖动映射 ---------- */
    function probeRatio(letter) {
      if (!expr) return null;
      let src = String(expr);
      let used = false;
      Object.keys(S).forEach(function (k) {
        if (k === letter || k === 'theta' || k === 'x' || k === 'y' || k === 't') return;
        const v = S[k];
        if (typeof v !== 'number' || !isFinite(v)) return;
        const re = new RegExp('\\b' + k + '\\b', 'g');
        if (re.test(src)) used = true;
        src = src.replace(re, '(' + v + ')');
      });
      if (!new RegExp('\\b' + letter + '\\b').test(src)) return null;
      src = src.replace(new RegExp('\\b' + letter + '\\b', 'g'), 't');
      const f = JW.compile(src);
      const h = 1e-3;
      try {
        if (letter === 'K') {
          const x = 0.8;
          const fk = (f(x, 0, S.K + h) - f(x, 0, S.K - h)) / (2 * h);
          if (!isFinite(fk) || Math.abs(fk) < 1e-6) return null;
          return clampNum(1 / fk, -20, 20);
        }
        let bx = 0, bd = 0;
        [0.4, 1.1, 1.9, 2.7].forEach(function (x) {
          const fh = (f(x, 0, S.H + h) - f(x, 0, S.H - h)) / (2 * h);
          if (Math.abs(fh) > Math.abs(bd)) { bd = fh; bx = x; }
        });
        if (!bx || Math.abs(bd) < 1e-6) return null;
        const fx = (f(bx + h, 0, S.H) - f(bx - h, 0, S.H)) / (2 * h);
        if (!isFinite(fx)) return null;
        return clampNum(-fx / bd, -20, 20);
      } catch (e) {
        return null;
      }
    }
    function shiftCoefs() {
      const out = { h: 1, k: 1 };
      if (isLab || mode === 'conic') return out;
      if (/\bH\b/.test(expr)) {
        const c = probeRatio('H');
        out.h = c == null ? 1 : c;   // 探针失败也让拖动能用
      } else out.h = 0;
      if (/\bK\b/.test(expr)) {
        const c = probeRatio('K');
        out.k = c == null ? 1 : c;
      } else out.k = 0;
      return out;
    }

    function nearestScreen(segs, p) {
      let best = null, bd = Infinity;
      for (let s = 0; s < segs.length; s++) {
        const seg = segs[s];
        for (let i = 0; i < seg.length; i += 2) {
          const X = cv.px(seg[i][0]), Y = cv.py(seg[i][1]);
          const dx = X - p.x, dy = Y - p.y, d = dx * dx + dy * dy;
          if (d < bd) { bd = d; best = seg[i]; }
        }
      }
      return best;
    }
    function distScreen(a, b) {
      const X = cv.px(a[0]), Y = cv.py(a[1]);
      const dx = X - b.x, dy = Y - b.y;
      return Math.sqrt(dx * dx + dy * dy);
    }
    function pointerAngle(p) {
      const ox = cv.px(0), oy = cv.py(0);
      return Math.atan2(-(p.y - oy), p.x - ox);
    }
    function nearHandle(p) {
      const hx = cv.w - 38, hy = cv.h * 0.5;
      const dx = p.x - hx, dy = p.y - hy;
      return dx * dx + dy * dy <= 32 * 32;
    }
    function nearCurve(p) {
      for (let i = 0; i < hitPts.length; i++) {
        const dx = hitPts[i][0] - p.x, dy = hitPts[i][1] - p.y;
        if (dx * dx + dy * dy < 144) return true;
      }
      return false;
    }
    function nearVecTip(p) {
      const u = rotPt([S.A, S.H], S.theta), v = rotPt([S.B, S.K], S.theta);
      return { u: distScreen(u, p) < 22, v: distScreen(v, p) < 22, du: distScreen(u, p), dv: distScreen(v, p) };
    }

    /* ---------- 手势 ---------- */
    function startPan(p) {
      const pre = currentSegs();
      const now = isLab ? pre : rotSegs(pre, S.theta);
      const nearPoint = nearestScreen(now, p);
      const data = [cv.dx(p.x), cv.dy(p.y)];
      const base = nearPoint ? [nearPoint[0], nearPoint[1]] : data;
      const anchor = isLab ? base : invRotPt(base, S.theta);
      const c = shiftCoefs();
      drag = {
        kind: 'pan', theta: S.theta, H0: S.H, K0: S.K,
        cH: c.h, cK: c.k, anchor: anchor, acc: { x: 0, y: 0 }
      };
      ghost = { segs: now, arrow: null, thetaFrom: null };
      markChip('平移');
    }
    function startRot(p) {
      const now = rotSegs(currentSegs(), S.theta);
      drag = { kind: 'rot', theta0: S.theta, ang0: pointerAngle(p) };
      ghost = { segs: now, arrow: null, thetaFrom: S.theta };
      markChip('旋转');
    }
    function startVec(p) {
      const tip = nearVecTip(p);
      const which = tip.du <= tip.dv ? 'u' : 'v';
      const now = rotSegs(currentSegs(), S.theta);
      const old = which === 'u' ? rotPt([S.A, S.H], S.theta) : rotPt([S.B, S.K], S.theta);
      const os = toScreen(old);
      drag = {
        kind: 'vec', which: which, theta: S.theta,
        A0: S.A, H0: S.H, B0: S.B, K0: S.K, acc: { x: 0, y: 0 }
      };
      ghost = { segs: now, arrow: { from: os, to: os }, thetaFrom: null };
      markChip('平移');
    }
    function onDown(p) {
      stopDemo(true);
      hideTip();
      if (nearHandle(p)) { startRot(p); return; }
      if (isLab) { startPan(p); return; }
      if (mode === 'vec') { startVec(p); return; }
      startPan(p);
    }
    function onMove(p, d) {
      if (!drag) return;
      if (drag.kind === 'rot') {
        let diff = pointerAngle(p) - drag.ang0;
        diff = Math.atan2(Math.sin(diff), Math.cos(diff));
        S.theta = clampTheta(drag.theta0 + diff);
        if (ghost) {
          ghost.thetaFrom = drag.theta0;
          ghost.arrow = null;
        }
        updateText();
        draw();
        return;
      }
      if (drag.kind === 'pan') {
        drag.acc.x += d.x; drag.acc.y += d.y;
        const dx = drag.acc.x / cv.w * (xr[1] - xr[0]);
        const dy = -drag.acc.y / cv.h * (yr[1] - yr[0]);
        if (drag.cH) S.H = clampP('H', drag.H0 + drag.cH * dx);
        if (drag.cK) S.K = clampP('K', drag.K0 + drag.cK * dy);
        const adx = drag.cH ? (S.H - drag.H0) / drag.cH : 0;
        const ady = drag.cK ? (S.K - drag.K0) / drag.cK : 0;
        const a = drag.anchor, b = [a[0] + adx, a[1] + ady];
        if (ghost) {
          if (isLab) {
            ghost.arrow = { from: toScreen(a), to: toScreen(b) };
          } else {
            ghost.arrow = {
              from: toScreen(rotPt(a, drag.theta)),
              to: toScreen(rotPt(b, drag.theta))
            };
          }
        }
        updateText();
        draw();
        return;
      }
      if (drag.kind === 'vec') {
        drag.acc.x += d.x; drag.acc.y += d.y;
        const dx = drag.acc.x / cv.w * (xr[1] - xr[0]);
        const dy = -drag.acc.y / cv.h * (yr[1] - yr[0]);
        if (drag.which === 'u') {
          S.A = clampP('A', drag.A0 + dx);
          S.H = clampP('H', drag.H0 + dy);
        } else {
          S.B = clampP('B', drag.B0 + dx);
          S.K = clampP('K', drag.K0 + dy);
        }
        const tip = rotPt(drag.which === 'u' ? [S.A, S.H] : [S.B, S.K], S.theta);
        if (ghost) ghost.arrow = { from: ghost.arrow ? ghost.arrow.from : toScreen(tip), to: toScreen(tip) };
        updateText();
        draw();
      }
    }
    function onUp() { drag = null; }

    function onHover(p) {
      if (drag || !cv) return;
      let cursor = 'default';
      if (nearHandle(p)) cursor = 'grab';
      else if (mode === 'vec' && !isLab) {
        const t = nearVecTip(p);
        if (t.u || t.v) cursor = 'grab';
      } else if (nearCurve(p)) cursor = 'grab';
      cv.cv.style.cursor = cursor;
    }

    function onWheel(delta, p, e) {
      if (!delta) return;
      stopDemo(true);
      hideTip();
      const shift = !!(e && e.shiftKey);
      const key = shift ? 'A' : 'B';
      if (!paramOf(key)) return;
      const f = Math.exp(-delta * 0.0016);
      S[key] = clampP(key, S[key] * f);
      syncAll();
      const name = shift ? '纵向伸缩 A ' : '横向伸缩 B ';
      showTip(name + JW.num(S[key], 2) + (shift ? '（Shift + 滚轮）' : '（滚轮）'), p);
      flash(key);
      markChip('伸缩');
    }

    /* ---------- 触屏工具条：希沃白板/触摸屏上不依赖滚轮和键盘 ---------- */
    const touch = el('div', { class: 'gx-touch' });
    function holdBtn(labelText, hint, act) {
      const b = el('button', { class: 'gx-tb', type: 'button', title: hint }, labelText);
      let delay = 0, timer = 0;
      const stop = function () { clearTimeout(delay); clearInterval(timer); delay = 0; timer = 0; };
      b.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        act();
        delay = setTimeout(function () { timer = setInterval(act, 90); }, 400);
      });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) { b.addEventListener(ev, stop); });
      return b;
    }
    function nudge(k, f) {
      if (!paramOf(k)) return;
      stopDemo(true); hideTip();
      S[k] = clampP(k, S[k] * f);
      syncAll(); flash(k); markChip('伸缩');
    }
    function rotBy(deg) {
      stopDemo(true); hideTip();
      S.theta = clampTheta(S.theta + deg * PI / 180);
      updateText(); draw(); markChip('旋转');
    }
    touch.appendChild(holdBtn('横缩', '横向压缩', function () { nudge('B', 1 / 1.1); }));
    touch.appendChild(holdBtn('横放', '横向拉伸', function () { nudge('B', 1.1); }));
    touch.appendChild(holdBtn('纵缩', '纵向压缩', function () { nudge('A', 1 / 1.1); }));
    touch.appendChild(holdBtn('纵放', '纵向拉伸', function () { nudge('A', 1.1); }));
    touch.appendChild(holdBtn('左转', '逆时针 15°', function () { rotBy(-15); }));
    touch.appendChild(holdBtn('右转', '顺时针 15°', function () { rotBy(15); }));
    const reset2 = el('button', { class: 'gx-tb gx-tb-reset', type: 'button', title: '恢复初始参数' }, '复位');
    reset2.addEventListener('click', function (e) { e.preventDefault(); doReset(); });
    touch.appendChild(reset2);
    const touchNote = el('div', { class: 'gx-touch-note' },
      '触屏：拖曲线平移 · 双指捏合缩放 · 上方按钮微调（不需要滚轮和键盘）');
    root.appendChild(touch);
    root.appendChild(touchNote);

    /* 双指捏合：横向距离比 → B，纵向距离比 → A */
    let pinch = null;
    const fingers = new Map();
    function twoSpan() {
      const it = Array.from(fingers.values());
      if (it.length < 2) return null;
      return { dx: Math.abs(it[0].x - it[1].x), dy: Math.abs(it[0].y - it[1].y) };
    }
    cv.cv.addEventListener('pointerdown', function (e) {
      fingers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (fingers.size >= 2) { pinch = twoSpan(); drag = null; }
    });
    cv.cv.addEventListener('pointermove', function (e) {
      if (!fingers.has(e.pointerId)) return;
      fingers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (fingers.size < 2 || !pinch) return;
      const now = twoSpan();
      if (now && pinch) {
        if (now.dx > 10 && pinch.dx > 10 && paramOf('B')) {
          const f = now.dx / pinch.dx;
          if (Math.abs(f - 1) > 0.002) S.B = clampP('B', S.B / f);
        }
        if (now.dy > 10 && pinch.dy > 10 && paramOf('A')) {
          const f = now.dy / pinch.dy;
          if (Math.abs(f - 1) > 0.002) S.A = clampP('A', S.A / f);
        }
        pinch = now; syncAll(); markChip('伸缩');
      }
    });
    const liftFinger = function (e) { fingers.delete(e.pointerId); if (fingers.size < 2) pinch = null; };
    cv.cv.addEventListener('pointerup', liftFinger);
    cv.cv.addEventListener('pointercancel', liftFinger);

    JW.drag(cv.cv, {
      down: onDown,
      move: onMove,
      up: onUp,
      hover: onHover,
      wheel: onWheel
    });

    /* ---------- 步骤 ---------- */
    function neutralFor(k) {
      const p = paramOf(k);
      if (p && p.neutral != null) return p.neutral;
      if (def.neutral && Object.prototype.hasOwnProperty.call(def.neutral, k)) return def.neutral[k];
      if (p) {
        if (p.min <= 0 && p.max >= 0) return 0;
        return p.min > 0 ? Math.max(p.min, 1) : p.max;
      }
      return 0;
    }
    function normStep(s) {
      if (!s || typeof s !== 'object') return null;
      let op = String(s.op || s.type || '').toLowerCase();
      if (op === '平移' || op === 'translate' || op === 'pan' || op === 'shift') op = 'shift';
      else if (op === '伸缩' || op === 'scale' || op === 'stretch') op = 'scale';
      else if (op === '旋转' || op === 'rotate' || op === 'rot') op = 'rotate';
      else if (op === '参数' || op === 'param') op = 'param';
      let axis = String(s.axis || '').toLowerCase();
      if (axis === '横' || axis === '水平') axis = 'x';
      if (axis === '纵' || axis === '竖直') axis = 'y';
      let v = s.v != null ? s.v : s.value;
      if (op === 'param') {
        if (!s.k) return null;
        return { op: op, k: String(s.k), axis: axis, v: v, note: s.note || '' };
      }
      if (op !== 'shift' && op !== 'scale' && op !== 'rotate') return null;
      return { op: op, k: s.k ? String(s.k) : '', axis: axis, v: v, note: s.note || '' };
    }
    function buildSteps() {
      if (Array.isArray(spec.steps) && spec.steps.length) {
        const list = [];
        spec.steps.forEach(function (s) { const n = normStep(s); if (n) list.push(n); });
        if (list.length) return list;
      }
      return params.map(function (p) {
        return { op: 'param', k: p.k, v: p.v, note: p.label + ' = ' + JW.num(p.v, p.dec) };
      });
    }
    const steps = buildSteps();

    function applyOne(s) {
      if (!s) return;
      const v = +s.v;
      if (!isFinite(v)) return;
      if (s.op === 'param') { if (s.k in S) S[s.k] = clampP(s.k, v); return; }
      if (s.op === 'shift') {
        if (s.axis === 'y') S.K = clampP('K', v);
        else if (s.axis === 'x') S.H = clampP('H', v);
        else { S.H = clampP('H', v); S.K = clampP('K', v); }
        return;
      }
      if (s.op === 'scale') {
        if (s.axis === 'y') S.A = clampP('A', v);
        else if (s.axis === 'x') S.B = clampP('B', v);
        else { S.A = clampP('A', v); S.B = clampP('B', v); }
        return;
      }
      if (s.op === 'rotate') S.theta = clampTheta(v * PI / 180);
    }
    function describeStep(s) {
      if (!s) return '';
      if (s.note) return s.note;
      if (s.op === 'param') {
        const p = paramOf(s.k);
        return (p ? p.label : s.k) + ' = ' + JW.num(+s.v, 2);
      }
      if (s.op === 'shift') {
        if (s.axis === 'x') return '横向平移 H = ' + fxNum(+s.v);
        if (s.axis === 'y') return '纵向平移 K = ' + fxNum(+s.v);
        return '平移 ' + fxNum(+s.v);
      }
      if (s.op === 'scale') {
        if (s.axis === 'x') return '横向伸缩 B = ' + fxNum(+s.v);
        if (s.axis === 'y') return '纵向伸缩 A = ' + fxNum(+s.v);
        return '伸缩 ' + fxNum(+s.v);
      }
      return '旋转 ' + fxNum(+s.v) + '°';
    }
    function applyStep(i) {
      if (destroyed) return;
      stopDemo(false);
      hideTip();
      ghost = null;
      drag = null;
      const n = Math.max(0, Math.min(steps.length, i | 0));
      params.forEach(function (p) { S[p.k] = neutralFor(p.k); });
      S.theta = 0;
      let note = '';
      for (let j = 0; j < n; j++) {
        applyOne(steps[j]);
        note = describeStep(steps[j]);
      }
      stepNote = n === 0 ? '第一步：原始函数，还没做变换' : '第 ' + n + ' 步 · ' + note;
      syncAll();
      markChip('平移');
    }

    function doReset() {
      stopDemo(false);
      hideTip();
      drag = null;
      ghost = null;
      stepNote = '';
      S.theta = 0;
      params.forEach(function (p) { S[p.k] = p.v; });
      syncSliders();
      updateText();
      draw();
      markChip('平移');
    }

    /* ---------- 启动 ---------- */
    updateText();
    draw();

    host.__gx = {
      range: function () { return { xr: cv.xr.slice(), yr: cv.yr.slice() }; },
      setRange: function (xr, yr) { cv.setRange(xr, yr); updateText(); draw(); },
      fn: function () { return currentFn(); },
      params: function () { return Object.assign({}, S); },
      plot: function () { return plot; },
      canvas: function () { return cv; },
      spec: function () { return { expr: expr, mode: mode, lab: isLab }; },
      viewHeight: function () { return cv.h; }
    };

    /* 引导层用：给出当前步骤在画布上的聚焦位置 */
    function keyPoints() {
      const fn = currentFn();
      const a = cv.xr[0], b = cv.xr[1], N = 260, h = (b - a) / N;
      let minP = null, maxP = null, prevY = null, prevX = null;
      const zeros = [];
      for (let i = 0; i <= N; i++) {
        const x = a + h * i;
        let y;
        try { y = fn(x); } catch (e) { y = NaN; }
        if (!isFinite(y)) { prevX = null; prevY = null; continue; }
        if (!minP || y < minP.y) minP = { x: x, y: y };
        if (!maxP || y > maxP.y) maxP = { x: x, y: y };
        if (prevY !== null && prevY * y < 0) {
          let lo = prevX, hi = x, flo = prevY;
          for (let k = 0; k < 28; k++) {
            const m = (lo + hi) / 2;
            const fm = fn(m);
            if (!isFinite(fm)) break;
            if (flo * fm <= 0) { hi = m; } else { lo = m; flo = fm; }
          }
          zeros.push((lo + hi) / 2);
        }
        prevX = x; prevY = y;
      }
      return { minP: minP, maxP: maxP, zeros: zeros };
    }

    function focus(i) {
      if (!cv) return null;
      const kp = keyPoints();
      const fn = currentFn();
      let x, label;
      if (i === 0) {
        const v = (kp.minP && kp.maxP && kp.maxP.y > -kp.minP.y) ? kp.maxP : kp.minP;
        if (!v) return null;
        x = v.x; label = '关键点';
      } else if (kp.zeros[i - 1] !== undefined) {
        x = kp.zeros[i - 1]; label = '零点 ' + (Math.round(x * 100) / 100);
      } else {
        const a = cv.xr[0], b = cv.xr[1];
        x = a + (b - a) * (0.25 + 0.5 * Math.min(1, (i - 1) / 4));
        label = '这一段';
      }
      let y;
      try { y = fn(x); } catch (e) { y = NaN; }
      if (!isFinite(y)) return null;
      return { x: cv.px(x), y: cv.py(y), r: 24, label: label, labelSide: 'above' };
    }

    return {
      applyStep: applyStep,
      focus: focus,
      destroy: function () {
        destroyed = true;
        stopDemo(false);
        hideTip();
        params.forEach(function (p) { clearTimeout(p.timer); });
        drag = null;
        ghost = null;
        try { host.innerHTML = ''; } catch (e) { }
        cv = null; ctx = null;
      },
      state: S,
      redraw: draw
    };
  });
})();
