/* 见微 · 析题台 · 跨学科题目视图（subjects）
   14 个 mode：reaction / titration / equilibrium / electrochem / genetics / cell
                ecology / timeline / map / syntax / poem / composition / flow / data
   契约：JW.registerView('subjects', mount)；mount(host, q, api) -> {applyStep(i), destroy()}
   坐标全部按容器实时测量，SVG viewBox 跟随尺寸；无外部库。 */
(function () {
  'use strict';
  const JW = window.JW;
  if (!JW) return;
  const C = JW.C, NS = 'http://www.w3.org/2000/svg';
  const el = JW.el, clamp = JW.clamp, num = JW.num;
  const TAU = Math.PI * 2;

  /* ---------------- SVG 基础 ---------------- */
  function f2(n) { return Math.round(n * 100) / 100; }
  function sv(tag, attrs) {
    const n = document.createElementNS(NS, tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null) continue;
      if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v);
    }
    return n;
  }
  function put(p, tag, attrs, text) {
    const n = sv(tag, attrs);
    if (text != null) n.textContent = text;
    p.appendChild(n);
    return n;
  }
  function line(p, x1, y1, x2, y2, o) {
    o = o || {};
    return put(p, 'line', {
      x1: f2(x1), y1: f2(y1), x2: f2(x2), y2: f2(y2),
      stroke: o.stroke || C.line, 'stroke-width': o.width == null ? 1 : o.width,
      'stroke-dasharray': o.dash || null, 'stroke-linecap': o.cap || 'round',
      opacity: o.opacity == null ? 1 : o.opacity
    });
  }
  function rect(p, x, y, w, h, o) {
    o = o || {};
    return put(p, 'rect', {
      x: f2(x), y: f2(y), width: f2(Math.max(0, w)), height: f2(Math.max(0, h)),
      rx: o.rx == null ? 0 : o.rx, fill: o.fill || 'none',
      stroke: o.stroke || null, 'stroke-width': o.width == null ? 1 : o.width,
      'stroke-dasharray': o.dash || null, opacity: o.opacity == null ? 1 : o.opacity
    });
  }
  function circ(p, cx, cy, r, o) {
    o = o || {};
    return put(p, 'circle', {
      cx: f2(cx), cy: f2(cy), r: f2(Math.max(0, r)),
      fill: o.fill || 'none', stroke: o.stroke || null,
      'stroke-width': o.width == null ? 1 : o.width,
      'stroke-dasharray': o.dash || null, opacity: o.opacity == null ? 1 : o.opacity
    });
  }
  function path(p, d, o) {
    o = o || {};
    return put(p, 'path', {
      d: d, fill: o.fill || 'none', stroke: o.stroke || null,
      'stroke-width': o.width == null ? 1.2 : o.width, 'stroke-dasharray': o.dash || null,
      'stroke-linecap': o.cap || 'round', 'stroke-linejoin': 'round',
      opacity: o.opacity == null ? 1 : o.opacity
    });
  }
  function txt(p, x, y, s, o) {
    o = o || {};
    const t = sv('text', {
      x: f2(x), y: f2(y), fill: o.fill || C.ink, 'font-size': o.size || 12,
      'font-family': o.serif ? C.serif : C.sans, 'font-weight': o.weight || 400,
      'text-anchor': o.anchor || 'start', 'dominant-baseline': o.base || 'middle',
      'letter-spacing': o.ls == null ? null : o.ls,
      opacity: o.opacity == null ? 1 : o.opacity
    });
    if (s != null) t.textContent = String(s);
    p.appendChild(t);
    return t;
  }
  function arrowHead(p, x, y, ang, size, color, op) {
    const L = size || 7;
    put(p, 'path', {
      d: 'M' + f2(x) + ' ' + f2(y) +
        'L' + f2(x - L * Math.cos(ang - .42)) + ' ' + f2(y - L * Math.sin(ang - .42)) +
        'L' + f2(x - L * Math.cos(ang + .42)) + ' ' + f2(y - L * Math.sin(ang + .42)) + 'Z',
      fill: color || C.ink2, opacity: op == null ? 1 : op
    });
  }
  function arrow(p, x1, y1, x2, y2, o) {
    o = o || {};
    line(p, x1, y1, x2, y2, { stroke: o.stroke || C.ink2, width: o.width || 1.3, dash: o.dash, opacity: o.opacity });
    arrowHead(p, x2, y2, Math.atan2(y2 - y1, x2 - x1), o.size || 7, o.stroke || C.ink2, o.opacity);
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function tw(s, size) {
    const str = String(s == null ? '' : s);
    let w = 0;
    for (let i = 0; i < str.length; i++) {
      const c = str.charCodeAt(i);
      w += c > 0x2e7f ? 1 : (c === 32 ? .3 : .56);
    }
    return w * size;
  }
  function wrapText(s, maxW, size) {
    const str = String(s == null ? '' : s), out = [];
    // 拉丁文按词折行，中文按字折行——否则英文会被拦腰截断
    if (/[A-Za-z]/.test(str) && !/[\u4e00-\u9fff]/.test(str) && str.indexOf(' ') >= 0) {
      let cur = '';
      str.split(/\s+/).forEach(function (word) {
        const next = cur ? cur + ' ' + word : word;
        if (cur && tw(next, size) > maxW) { out.push(cur); cur = word; } else cur = next;
      });
      if (cur) out.push(cur);
      return out;
    }
    let cur = '';
    for (let i = 0; i < str.length; i++) {
      const ch = str[i];
      if (ch === '\n') { out.push(cur); cur = ''; continue; }
      if (cur && tw(cur + ch, size) > maxW) { out.push(cur); cur = ch; } else cur += ch;
    }
    if (cur) out.push(cur);
    return out;
  }
  const SUB = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };
  function subNum(s) { return String(s).replace(/[0-9]/g, d => SUB[d]); }
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { const t = b; b = a % b; a = t; } return a || 1; }

  /* ---------------- 画布外壳 ---------------- */
  function Widget(host, q, api, opt) {
    opt = opt || {};
    if (!host) host = document.createElement('div');
    host.innerHTML = '';
    const wrap = el('div', { class: 'sb-grid' });
    const draw = el('div', { class: 'sb-draw' + (opt.scroll ? ' sb-scroll' : '') });
    const ctrl = el('div', { class: 'sb-ctrl' });
    wrap.appendChild(draw); wrap.appendChild(ctrl); host.appendChild(wrap);
    const svg = sv('svg', { class: 'sb-svg', xmlns: NS });
    draw.appendChild(svg);
    const isScroll = !!opt.scroll;
    const W = {
      host: host, q: q || {}, api: api || {}, wrap: wrap, draw: draw, ctrl: ctrl, svg: svg,
      w: 800, h: 440, view: (q && q.view) || {}, step: 0, dead: false, renderFn: null, cleanups: []
    };
    W.P = W.view.params || {};
    W.D = Object.assign({}, W.view, W.view.data || {});
    W.redraw = function () {
      if (W.dead) return;
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      svg.setAttribute('width', W.w);
      svg.setAttribute('height', W.h);
      svg.setAttribute('viewBox', '0 0 ' + W.w + ' ' + W.h);
      if (W.renderFn) { try { W.renderFn(W.w, W.h); } catch (e) { console.warn('[subjects]', e); } }
    };
    W.fit = function () {
      if (W.dead) return;
      const r = draw.getBoundingClientRect();
      const w = Math.round(r.width), h = Math.round(r.height);
      W.w = w > 40 ? w : 780;
      W.h = h > 40 ? h : 420;
      W.redraw();
    };
    W.set = function (fn) { W.renderFn = fn; W.fit(); };
    W.addSteps = function (labels) {
      const row = el('div', { class: 'sb-steps' });
      const cells = labels.map(function () {
        const i = el('i'); row.appendChild(i); return i;
      });
      W.ctrl.appendChild(row);
      W.syncSteps = function (i) {
        cells.forEach(function (c, k) { c.className = k <= i ? 'on' : ''; });
      };
      W.syncSteps(0);
      return row;
    };
    W.applyStep = function (i) {
      W.step = Math.max(0, Math.round(i || 0));
      if (W.syncSteps) W.syncSteps(W.step);
      W.redraw();
    };
    W.onCleanup = function (fn) { W.cleanups.push(fn); };
    W.destroy = function () {
      if (W.dead) return;
      W.dead = true;
      if (W._ro) { try { W._ro.disconnect(); } catch (e) { } }
      if (W._raf) cancelAnimationFrame(W._raf);
      W.cleanups.forEach(function (fn) { try { fn(); } catch (e) { } });
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
    };
    if (window.ResizeObserver) {
      W._ro = new ResizeObserver(function () { W.fit(); });
      W._ro.observe(draw);
    }
    return W;
  }

  /* ---------------- 右侧栏小件 ---------------- */
  function modeHead(ctrl, title, sub) {
    const h = el('div', { class: 'sb-hd' });
    h.appendChild(el('b', {}, title));
    h.appendChild(el('span', {}, sub || ''));
    ctrl.appendChild(h);
  }
  function csec(parent, title) {
    const d = el('div', { class: 'jw-sec' }, title);
    parent.appendChild(d);
    return d;
  }
  function ckv(parent, k, v) {
    const d = el('div', { class: 'jw-kv' });
    d.appendChild(el('span', {}, k));
    const b = el('b', {}, v == null ? '—' : v);
    d.appendChild(b);
    parent.appendChild(d);
    return b;
  }
  function cstat(parent, label, value, unit) {
    const n = JW.ui.stat(label, value == null ? '—' : value, unit || '');
    parent.appendChild(n);
    return n.querySelector('.jw-stat-v');
  }
  function cnote(parent, html) {
    const d = el('div', { class: 'sb-note' });
    d.innerHTML = html;
    parent.appendChild(d);
    return d;
  }
  function clegend(parent, items) {
    const box = el('div', { class: 'sb-legend' });
    items.forEach(function (it) {
      const row = el('div');
      const sw = el('i');
      sw.style.background = it.color;
      row.appendChild(sw);
      row.appendChild(el('span', {}, it.label));
      box.appendChild(row);
    });
    parent.appendChild(box);
    return box;
  }
  function cbutton(parent, label, cb) {
    const b = el('button', { class: 'jw-btn' }, label);
    b.addEventListener('click', cb);
    parent.appendChild(b);
    return b;
  }

  /* ===================== 1. 化学方程式 ===================== */
  function parseFormula(f) {
    let s = String(f || '').replace(/\s+/g, '')
      .replace(/\((s|l|g|aq)\)/gi, '').replace(/\[(s|l|g|aq)\]/gi, '')
      .replace(/（(s|l|g|aq)）/gi, '');
    const stack = [{}];
    let i = 0;
    while (i < s.length) {
      const ch = s[i];
      if (ch === '(' || ch === '（') { stack.push({}); i++; continue; }
      if (ch === ')' || ch === '）') {
        i++;
        let d = '';
        while (i < s.length && /[0-9]/.test(s[i])) d += s[i++];
        const m = d ? +d : 1;
        const group = stack.pop() || {};
        const up = stack[stack.length - 1] || {};
        for (const k in group) up[k] = (up[k] || 0) + group[k] * m;
        continue;
      }
      if (/[A-Z]/.test(ch)) {
        let sym = ch; i++;
        while (i < s.length && /[a-z]/.test(s[i])) sym += s[i++];
        let d = '';
        while (i < s.length && /[0-9]/.test(s[i])) d += s[i++];
        const top = stack[stack.length - 1];
        top[sym] = (top[sym] || 0) + (d ? +d : 1);
        continue;
      }
      i++;
    }
    return stack[0] || {};
  }
  function parseEq(str) {
    const s = String(str || '').replace(/\s+/g, '');
    const parts = s.split(/->|→|=>|⇌|=|⟶/);
    if (parts.length < 2) return null;
    function side(t) {
      return t.split('+').filter(Boolean).map(function (term) {
        const m = /^([0-9]*)(.*)$/.exec(term);
        const coef = m[1] ? Math.max(1, +m[1]) : 1;
        const formula = m[2] || term;
        return { coef: coef, formula: formula, atoms: parseFormula(formula) };
      });
    }
    const left = side(parts[0]), right = side(parts[1]);
    if (!left.length || !right.length) return null;
    const okA = left.every(t => Object.keys(t.atoms).length), okB = right.every(t => Object.keys(t.atoms).length);
    if (!okA || !okB) return null;
    return { left: left, right: right };
  }
  function atomTotals(list) {
    const o = {};
    list.forEach(function (t) { for (const k in t.atoms) o[k] = (o[k] || 0) + t.atoms[k] * t.coef; });
    return o;
  }
  function balanceSolve(left, right) {
    const all = left.concat(right), n = all.length;
    if (n < 2 || n > 5) return null;
    const els = [];
    all.forEach(t => Object.keys(t.atoms).forEach(k => { if (els.indexOf(k) < 0) els.push(k); }));
    if (!els.length) return null;
    const pick = new Array(n).fill(1);
    let best = null;
    function ok() {
      for (let e = 0; e < els.length; e++) {
        const k = els[e];
        let s = 0;
        for (let i = 0; i < n; i++) {
          const c = (all[i].atoms[k] || 0) * pick[i];
          s += i < left.length ? c : -c;
        }
        if (s !== 0) return false;
      }
      return true;
    }
    (function rec(i) {
      if (best && best.sum <= n) return;
      if (i === n) {
        if (ok()) {
          const sum = pick.reduce((a, b) => a + b, 0);
          if (!best || sum < best.sum) best = { sum: sum, c: pick.slice() };
        }
        return;
      }
      for (let c = 1; c <= 8; c++) { pick[i] = c; rec(i + 1); }
    })(0);
    return best ? best.c : null;
  }
  function eqString(parsed, hide) {
    const term = t => (hide || t.coef === 1 ? '' : t.coef) + subNum(t.formula);
    return parsed.left.map(term).join(' + ') + ' → ' + parsed.right.map(term).join(' + ');
  }
  function mountReaction(host, q, api) {
    const W = new Widget(host, q, api);
    const S = {
      step: 0, cond: W.D.cond || W.P.cond || '点燃', showCoef: true,
      parsed: parseEq(W.D.eq || W.P.eq || '2H2+O2->2H2O') || parseEq('2H2+O2->2H2O'),
      note: '', solving: false
    };
    modeHead(W.ctrl, '方程式配平', '反应物 → 条件 → 产物 · 原子账本');
    W.addSteps(['反应物', '条件', '产物', '账本']);
    csec(W.ctrl, '读数');
    const vL = cstat(W.ctrl, '左侧原子', '—', '');
    const vR = cstat(W.ctrl, '右侧原子', '—', '');
    const vB = cstat(W.ctrl, '守恒', '—', '');
    const kvEls = ckv(W.ctrl, '元素', '—');
    let noteEl = cnote(W.ctrl, '点步骤推进：先数反应物，再看条件与产物，最后核对原子账本。');
    csec(W.ctrl, '条件标注');
    const chipsWrap = el('div', { class: 'sb-chiprow' });
    W.ctrl.appendChild(chipsWrap);
    const condChips = JW.ui.chips(['点燃', '加热', '催化剂', '电解'], S.cond, function (v) {
      S.cond = v; W.redraw();
    });
    chipsWrap.appendChild(condChips);
    csec(W.ctrl, '显示');
    W.ctrl.appendChild(JW.ui.toggle('显示化学计量数', true, function (on) {
      S.showCoef = on; W.redraw();
    }));
    const btnRow = el('div', { class: 'sb-btnrow' });
    W.ctrl.appendChild(btnRow);
    const btn = el('button', { class: 'jw-btn jw-btn-solid' }, '自动配平');
    btn.addEventListener('click', function () {
      const sol = balanceSolve(S.parsed.left, S.parsed.right);
      if (sol) {
        S.parsed.left.concat(S.parsed.right).forEach((t, i) => { t.coef = sol[i]; });
        S.note = '已配平：最小整数系数 ' + sol.join(' : ');
        noteEl.innerHTML = '已配平，系数 <em>' + sol.join(' : ') + '</em>；左右原子数逐元素相等。';
        W.redraw();
      } else {
        S.note = '该式未搜到 1–8 的整数系数解';
        noteEl.innerHTML = '未找到 1–8 的整数系数解，可能式中有错或需要更复杂的配平思路。';
        W.redraw();
      }
    });
    btnRow.appendChild(btn);
    const reset = el('button', { class: 'jw-btn' }, '还原');
    reset.addEventListener('click', function () {
      S.parsed = parseEq(W.D.eq || '2H2+O2->2H2O') || parseEq('2H2+O2->2H2O');
      noteEl.innerHTML = '已回到原始方程式。';
      W.redraw();
    });
    btnRow.appendChild(reset);

    W.set(function (w, h) {
      const root = W.svg, p = S.parsed;
      const P = 22;
      const L = atomTotals(p.left), R = atomTotals(p.right);
      const els = [];
      Object.keys(L).concat(Object.keys(R)).forEach(function (k) { if (els.indexOf(k) < 0) els.push(k); });
      const sum = o => Object.keys(o).reduce((a, k) => a + o[k], 0);
      const totL = sum(L), totR = sum(R);
      const balanced = els.every(k => (L[k] || 0) === (R[k] || 0));
      const step = W.step;
      const dim = need => step >= need ? 1 : .24;
      const midY = Math.max(96, h * .30);
      const boxH = 50, plusW = 22, gap = 24;

      /* 标题与总量 */
      txt(root, P, 24, '化学方程式 · 反应流程', { size: 12.5, weight: 700, fill: C.ink, ls: .6 });
      txt(root, w - P, 24, '左 ' + totL + ' 原子  ·  右 ' + totR + ' 原子', {
        size: 11, anchor: 'end', fill: balanced ? C.soft : C.accent
      });
      line(root, P, 36, w - P, 36, { stroke: C.line2 });

      /* 反应物与产物 */
      let size = 13;
      const mk = (list, hide) => list.map(function (t) {
        const str = (hide || t.coef === 1 ? '' : t.coef + '') + subNum(t.formula);
        return { str: str, w: Math.max(56, tw(str, size) + 26) };
      });
      let li = mk(p.left, !S.showCoef), ri = mk(p.right, !S.showCoef);
      let leftW = li.reduce((a, b) => a + b.w, 0) + plusW * (li.length - 1);
      let rightW = ri.reduce((a, b) => a + b.w, 0) + plusW * (ri.length - 1);
      if (leftW + rightW + gap * 2 + 54 > w - 2 * P) {
        size = 11;
        li = mk(p.left, !S.showCoef); ri = mk(p.right, !S.showCoef);
        leftW = li.reduce((a, b) => a + b.w, 0) + plusW * (li.length - 1);
        rightW = ri.reduce((a, b) => a + b.w, 0) + plusW * (ri.length - 1);
      }
      const boxes = [];
      function drawRow(list, metrics, x0, op) {
        let x = x0;
        list.forEach(function (t, i) {
          const m = metrics[i];
          const active = step === 0 && op === 1;
          rect(root, x, midY - boxH / 2, m.w, boxH, {
            rx: 3, fill: active ? C.card : C.grid2,
            stroke: active ? C.ink2 : C.line,
            width: active ? 1.3 : 1, opacity: op
          });
          txt(root, x + m.w / 2, midY - 2, m.str, {
            size: size, weight: 600, anchor: 'middle', fill: C.ink, opacity: op
          });
          boxes.push({ x: x, w: m.w });
          x += m.w;
          if (i < list.length - 1) {
            txt(root, x + plusW / 2, midY, '+', { size: 12, anchor: 'middle', fill: C.faint, opacity: op });
            x += plusW;
          }
        });
        return x;
      }
      const leftOp = dim(0), rightOp = dim(2);
      drawRow(p.left, li, P, leftOp);
      const rightStart = w - P - rightW;
      drawRow(p.right, ri, rightStart, rightOp);

      /* 箭头与条件 */
      const ax1 = P + leftW + gap, ax2 = rightStart - gap;
      const aOp = dim(1);
      line(root, ax1, midY, ax2, midY, { stroke: C.ink2, width: 1.4, opacity: aOp });
      arrowHead(root, ax2, midY, 0, 7, C.ink2, aOp);
      const cx = (ax1 + ax2) / 2;
      txt(root, cx, midY - 16, S.cond, { size: 11.5, anchor: 'middle', fill: C.ink, opacity: aOp, weight: 600 });
      txt(root, cx, midY + 15, '条件', { size: 9.5, anchor: 'middle', fill: C.faint, opacity: aOp, ls: 1.5 });
      if (step === 1) {
        rect(root, cx - tw(S.cond, 11.5) / 2 - 8, midY - 27, tw(S.cond, 11.5) + 16, 21, {
          rx: 10, stroke: C.accent, width: 1
        });
      }
      txt(root, P, midY - boxH / 2 - 12, '反应物', { size: 10, fill: C.faint, opacity: leftOp, ls: 1.5 });
      txt(root, w - P, midY - boxH / 2 - 12, '产物', { size: 10, fill: C.faint, anchor: 'end', opacity: rightOp, ls: 1.5 });

      /* 原子账本 */
      const ly = midY + boxH / 2 + 54;
      const rows = Math.max(1, els.length);
      const rowH = clamp((h - ly - 26) / rows, 22, 40);
      const lOp = dim(3);
      txt(root, P, ly - 22, '原子账本', { size: 11.5, weight: 700, fill: C.ink, opacity: lOp, ls: .5 });
      txt(root, w - P, ly - 22, balanced ? '左右守恒' : '尚未守恒', {
        size: 10.5, anchor: 'end', fill: balanced ? C.jade : C.accent, opacity: lOp
      });
      line(root, P, ly - 10, w - P, ly - 10, { stroke: C.line2, opacity: lOp });
      txt(root, P + 4, ly + 6, '元素', { size: 9.5, fill: C.faint, opacity: lOp, ls: 1 });
      txt(root, w * .28, ly + 6, '反应物侧', { size: 9.5, fill: C.faint, opacity: lOp, ls: 1 });
      txt(root, w * .27 + 2, ly + 6, '', { size: 9 });
      txt(root, w * .55, ly + 6, '产物侧', { size: 9.5, fill: C.faint, opacity: lOp, ls: 1 });
      const dotR = Math.min(3.4, rowH * .12), dg = 9.4;
      const maxDots = Math.max(4, Math.floor((w * .25) / dg) - 1);
      els.forEach(function (k, i) {
        const y = ly + 28 + i * rowH;
        const lv = L[k] || 0, rv = R[k] || 0, good = lv === rv;
        txt(root, P + 6, y, k, { size: 12, weight: 700, fill: C.ink, opacity: lOp });
        for (let d = 0; d < Math.min(lv, maxDots); d++) {
          circ(root, w * .15 + d * dg, y, dotR, { fill: C.data[1], opacity: lOp });
        }
        if (lv > maxDots) txt(root, w * .15 + maxDots * dg, y, '+' + (lv - maxDots), { size: 9.5, fill: C.soft, opacity: lOp });
        txt(root, w * .15 + Math.min(lv, maxDots) * dg + 6, y, '×' + lv, {
          size: 10.5, fill: C.soft, opacity: lOp, weight: 600
        });
        for (let d = 0; d < Math.min(rv, maxDots); d++) {
          circ(root, w * .58 + d * dg, y, dotR, { fill: C.data[2], opacity: lOp });
        }
        if (rv > maxDots) txt(root, w * .58 + maxDots * dg, y, '+' + (rv - maxDots), { size: 9.5, fill: C.soft, opacity: lOp });
        txt(root, w * .58 + Math.min(rv, maxDots) * dg + 6, y, '×' + rv, {
          size: 10.5, fill: C.soft, opacity: lOp, weight: 600
        });
        txt(root, w * .46, y, good ? '=' : '≠', {
          size: 12, anchor: 'middle', fill: good ? C.faint : C.accent, opacity: lOp, weight: 700
        });
        if (!good && step >= 3) {
          txt(root, w * .43, y + 13, '差 ' + Math.abs(lv - rv), { size: 9, anchor: 'end', fill: C.accent, opacity: lOp });
        }
      });

      /* 读数 */
      vL.textContent = String(totL);
      vR.textContent = String(totR);
      vB.textContent = balanced ? '守恒' : '不守恒';
      vB.style.color = balanced ? C.ink : C.accent;
      kvEls.textContent = els.join(' · ') || '—';
      if (step === 3) noteEl.innerHTML = balanced
        ? '逐元素比对：' + els.map(k => k + ' ' + (L[k] || 0) + '=' + (R[k] || 0)).join('，') + '。'
        : '逐元素比对：' + els.filter(k => (L[k] || 0) !== (R[k] || 0))
          .map(k => k + ' 左 ' + (L[k] || 0) + ' / 右 ' + (R[k] || 0)).join('，') + '。';
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 2. 滴定曲线 ===================== */
  function mountTitration(host, q, api) {
    const W = new Widget(host, q, api);
    const P = W.P, D = W.D;
    const S = {
      step: 0, pKa: P.pKa != null ? +P.pKa : (P.Ka ? -Math.log10(+P.Ka) : 4.76),
      c: P.c != null ? +P.c : .1, V0: P.V0 != null ? +P.V0 : 25, cb: P.cb != null ? +P.cb : .1,
      V: 0, ind: 0, drag: false, geo: null
    };
    const INDS = [
      { name: '酚酞', lo: 8.2, hi: 10.0 },
      { name: '甲基橙', lo: 3.1, hi: 4.4 },
      { name: '石蕊', lo: 5.0, hi: 8.0 }
    ];
    let curve = [], Vmax = 50, veq = 25;
    function phAt(V) {
      const Ka = Math.pow(10, -S.pKa), Kw = 1e-14;
      const vt = S.V0 + V, ct = S.c * S.V0 / vt, cn = S.cb * V / vt;
      const f = function (ph) {
        const H = Math.pow(10, -ph);
        return H + cn - Kw / H - ct * Ka / (Ka + H);
      };
      let lo = 0, hi = 14;
      for (let k = 0; k < 50; k++) {
        const m = (lo + hi) / 2;
        if (f(m) > 0) lo = m; else hi = m;
      }
      return (lo + hi) / 2;
    }
    function build() {
      veq = S.c * S.V0 / S.cb;
      Vmax = Math.max(.8, veq * 2);
      curve = [];
      if (D.curve && D.curve.length) {
        D.curve.forEach(function (pt) {
          if (Array.isArray(pt)) curve.push({ v: +pt[0], ph: +pt[1] });
          else curve.push({ v: +pt.v, ph: +pt.ph });
        });
        Vmax = Math.max(.8, curve[curve.length - 1].v);
      } else {
        for (let i = 0; i <= 300; i++) {
          const v = Vmax * i / 300;
          curve.push({ v: v, ph: phAt(v) });
        }
      }
      S.V = clamp(S.V, 0, Vmax);
    }
    build();

    modeHead(W.ctrl, '酸碱滴定曲线', 'pH–V 计算 · 突跃与指示剂');
    W.addSteps(['曲线', '突跃', '等当点', '读数']);
    csec(W.ctrl, '读数');
    const vV = cstat(W.ctrl, '滴定体积', '0', 'mL');
    const vPh = cstat(W.ctrl, 'pH', '0', '');
    const vDv = cstat(W.ctrl, '距等当点', '0', 'mL');
    ckv(W.ctrl, '等当点', '—');
    const kvEq = W.ctrl.querySelectorAll('.jw-kv b')[0];
    ckv(W.ctrl, '突跃 pH', '—');
    const kvJump = W.ctrl.querySelectorAll('.jw-kv b')[1];
    ckv(W.ctrl, '指示剂', '—');
    const kvInd = W.ctrl.querySelectorAll('.jw-kv b')[2];

    csec(W.ctrl, '参数');
    W.ctrl.appendChild(JW.ui.range({ label: 'pKa', min: 2, max: 9, step: .05, value: S.pKa, dec: 2 }, function (v) {
      S.pKa = v; build(); W.redraw();
    }));
    W.ctrl.appendChild(JW.ui.range({ label: 'c(酸) / mol·L⁻¹', min: .02, max: .3, step: .01, value: S.c, dec: 2 }, function (v) {
      S.c = v; build(); W.redraw();
    }));
    const indRow = el('div', { class: 'sb-chiprow' });
    W.ctrl.appendChild(indRow);
    indRow.appendChild(JW.ui.chips(INDS.map(i => i.name), INDS[S.ind].name, function (name) {
      S.ind = INDS.findIndex(i => i.name === name); W.redraw();
    }));

    function jumpRange() {
      let maxS = 0, mi = 1;
      for (let i = 1; i < curve.length; i++) {
        const dv = curve[i].v - curve[i - 1].v;
        if (dv <= 0) continue;
        const s = Math.abs(curve[i].ph - curve[i - 1].ph) / dv;
        if (s > maxS) { maxS = s; mi = i; }
      }
      const th = maxS * .3;
      let a = mi, b = mi;
      while (a > 1 && Math.abs(curve[a].ph - curve[a - 1].ph) / Math.max(1e-9, curve[a].v - curve[a - 1].v) > th) a--;
      while (b < curve.length - 1 && Math.abs(curve[b + 1].ph - curve[b].ph) / Math.max(1e-9, curve[b + 1].v - curve[b].v) > th) b++;
      return { v0: curve[a].v, v1: curve[b].v, ph0: curve[a].ph, ph1: curve[b].ph };
    }

    W.set(function (w, h) {
      const L = 46, R = 18, T = 26, B = 40;
      const iw = w - L - R, ih = h - T - B;
      const x = v => L + (v / Vmax) * iw;
      const y = ph => T + (1 - ph / 14) * ih;
      S.geo = { L: L, R: R, T: T, B: B, iw: iw, ih: ih, pt: 8 };
      const step = W.step;
      const ind = INDS[S.ind];
      const jump = jumpRange();
      const eqPh = curve.reduce((best, pt) => Math.abs(pt.v - veq) < Math.abs(best.v - veq) ? pt : best, curve[0]);
      const readPh = curve.reduce((best, pt) => Math.abs(pt.v - S.V) < Math.abs(best.v - S.V) ? pt : best, curve[0]).ph;

      /* 网格 */
      for (let ph = 0; ph <= 14; ph += 2) {
        line(W.svg, L, y(ph), w - R, y(ph), { stroke: ph === 7 ? C.line : C.grid2 });
        txt(W.svg, L - 8, y(ph), ph, { size: 9.5, anchor: 'end', fill: C.faint });
      }
      const vStep = Vmax > 40 ? 10 : 5;
      for (let v = 0; v <= Vmax + .01; v += vStep) {
        line(W.svg, x(v), T, x(v), T + ih, { stroke: C.grid2 });
        txt(W.svg, x(v), h - B + 14, num(v, 0), { size: 9.5, anchor: 'middle', fill: C.faint });
      }
      line(W.svg, L, T + ih, w - R, T + ih, { stroke: C.faint, width: 1 });
      line(W.svg, L, T, L, T + ih, { stroke: C.faint, width: 1 });
      txt(W.svg, L - 8, T - 12, 'pH', { size: 10, anchor: 'end', fill: C.soft });
      txt(W.svg, w - R, h - 10, 'V(NaOH) / mL', { size: 10, anchor: 'end', fill: C.soft });

      /* 突跃带 */
      if (step >= 1) {
        rect(W.svg, x(jump.v0), y(jump.ph1), x(jump.v1) - x(jump.v0), y(jump.ph0) - y(jump.ph1), {
          fill: C.data[4], opacity: .7
        });
        line(W.svg, x(jump.v0), y(jump.ph1), x(jump.v1), y(jump.ph1), { stroke: C.data[2], dash: '3 3', opacity: .7 });
        line(W.svg, x(jump.v0), y(jump.ph0), x(jump.v1), y(jump.ph0), { stroke: C.data[2], dash: '3 3', opacity: .7 });
        txt(W.svg, x((jump.v0 + jump.v1) / 2), y(jump.ph1) - 8, '突跃 ' + num(jump.ph0, 1) + '–' + num(jump.ph1, 1), {
          size: 10, anchor: 'middle', fill: C.soft
        });
      }

      /* 指示剂变色带 */
      if (step >= 2) {
        rect(W.svg, L, y(ind.hi), iw, y(ind.lo) - y(ind.hi), { fill: C.data[4], opacity: .55 });
        line(W.svg, L, y(ind.lo), w - R, y(ind.lo), { stroke: C.data[3], dash: '4 3' });
        line(W.svg, L, y(ind.hi), w - R, y(ind.hi), { stroke: C.data[3], dash: '4 3' });
        txt(W.svg, w - R - 4, y(ind.hi) - 8, ind.name + ' ' + num(ind.lo, 1) + '–' + num(ind.hi, 1), {
          size: 10, anchor: 'end', fill: C.soft
        });
      }

      /* 曲线 */
      let d = '';
      curve.forEach(function (pt, i) { d += (i ? 'L' : 'M') + f2(x(pt.v)) + ' ' + f2(y(pt.ph)); });
      path(W.svg, d, { stroke: C.ink2, width: 1.9 });

      /* 等当点 */
      if (step >= 2) {
        line(W.svg, x(veq), T, x(veq), T + ih, { stroke: C.ink2, dash: '3 4', opacity: .65 });
        circ(W.svg, x(veq), y(eqPh.ph), 3.6, { fill: C.ink });
        txt(W.svg, x(veq) + 7, y(eqPh.ph) - 12, '等当点 ' + num(veq, 1) + ' mL · pH ' + num(eqPh.ph, 2), {
          size: 10, fill: C.ink, weight: 600
        });
      }

      /* 读数游标 */
      const cursorColor = step >= 3 ? C.accent : C.ink2;
      const cx = x(S.V);
      line(W.svg, cx, T, cx, T + ih, { stroke: cursorColor, width: step >= 3 ? 1.6 : 1.2, opacity: step >= 3 ? 1 : .55 });
      circ(W.svg, cx, y(readPh), 4, { fill: C.card, stroke: cursorColor, width: 1.6 });
      put(W.svg, 'rect', {
        x: clamp(cx - 34, L, w - R - 68), y: T + 4, width: 68, height: 20, rx: 2,
        fill: C.card, stroke: C.line, opacity: .95
      });
      txt(W.svg, clamp(cx, L + 34, w - R - 34), T + 14, 'pH ' + num(readPh, 2), {
        size: 10.5, anchor: 'middle', fill: C.ink, weight: 700
      });
      if (step >= 3) {
        txt(W.svg, cx + 6, T + ih - 8, '可拖动', { size: 9.5, fill: C.accent, anchor: cx > w - 80 ? 'end' : 'start' });
      }

      /* 读数面板 */
      vV.textContent = num(S.V, 1);
      vPh.textContent = num(readPh, 2);
      vDv.textContent = num(S.V - veq, 1);
      kvEq.textContent = num(veq, 1) + ' mL · pH ' + num(eqPh.ph, 2);
      kvJump.textContent = num(jump.ph0, 1) + '–' + num(jump.ph1, 1);
      kvInd.textContent = ind.name + (readPh < ind.lo ? ' 未变色' : readPh > ind.hi ? ' 已变色' : ' 变色中');
    });

    /* 拖动读数竖线 */
    const drag = JW.drag(W.svg, {
      down: function (p) { S.drag = true; readAt(p.x); },
      move: function (p) { if (S.drag) readAt(p.x); },
      up: function () { S.drag = false; }
    });
    W.onCleanup(function () { W.svg.style.touchAction = ''; });
    function readAt(px) {
      const g = S.geo;
      if (!g) return;
      const v = clamp((px - g.L) / g.iw, 0, 1) * Vmax;
      S.V = v;
      W.redraw();
    }
    W.svg.style.cursor = 'crosshair';
    W.applyStep(0);
    return W;
  }

  /* ===================== 3. 化学平衡 ===================== */
  function mountEquilibrium(host, q, api) {
    const W = new Widget(host, q, api);
    const P = W.P;
    const S = {
      step: 0,
      K: P.K != null ? +P.K : 2.5,
      A0: P.cA != null ? +P.cA : (P.A0 != null ? +P.A0 : 1),
      B0: P.cB != null ? +P.cB : (P.B0 != null ? +P.B0 : 0),
      t: 2.4, T: 10, tau: 1.6
    };
    function eqState() {
      const Ct = S.A0 + S.B0;
      const A = Ct / (1 + S.K), B = S.K * Ct / (1 + S.K);
      return { A: A, B: B, Ct: Ct };
    }
    function conc(t) {
      const e = eqState(), k = Math.exp(-t / S.tau);
      return { A: e.A + (S.A0 - e.A) * k, B: e.B + (S.B0 - e.B) * k };
    }
    modeHead(W.ctrl, '化学平衡', '浓度–时间 · Q 与 K 判定方向');
    W.addSteps(['初始', '趋向', 'Q 与 K', '平衡']);
    const form = el('div', { class: 'jw-form' });
    form.innerHTML = 'A ⇌ B&nbsp;&nbsp; K = ' + JW.fx('\\frac{[B]}{[A]}');
    form.style.marginTop = '10px';
    W.ctrl.appendChild(form);
    csec(W.ctrl, '读数');
    const vA = cstat(W.ctrl, '[A]', '—', 'M');
    const vB = cstat(W.ctrl, '[B]', '—', 'M');
    const vQ = cstat(W.ctrl, 'Q', '—', '');
    const vK = cstat(W.ctrl, 'K', '—', '');
    ckv(W.ctrl, '方向', '—');
    const kvDir = W.ctrl.querySelectorAll('.jw-kv b')[0];
    ckv(W.ctrl, '平衡 [A] / [B]', '—');
    const kvEq = W.ctrl.querySelectorAll('.jw-kv b')[1];

    csec(W.ctrl, '可调参数');
    W.ctrl.appendChild(JW.ui.range({ label: '平衡常数 K', min: .2, max: 8, step: .1, value: S.K, dec: 1 }, function (v) { S.K = v; W.redraw(); }));
    W.ctrl.appendChild(JW.ui.range({ label: '初始 [A]₀', min: .2, max: 2, step: .05, value: S.A0, dec: 2 }, function (v) { S.A0 = v; W.redraw(); }));
    W.ctrl.appendChild(JW.ui.range({ label: '初始 [B]₀', min: 0, max: 1, step: .05, value: S.B0, dec: 2 }, function (v) { S.B0 = v; W.redraw(); }));
    W.ctrl.appendChild(JW.ui.range({ label: '时间 t / s', min: 0, max: S.T, step: .1, value: S.t, dec: 1 }, function (v) { S.t = v; W.redraw(); }));
    cnote(W.ctrl, 'K 越大平衡越靠右；Q = [B]/[A]，Q < K 时正向进行。');

    W.set(function (w, h) {
      const L = 48, R = 74, T = 34, B = 42;
      const iw = w - L - R, ih = h - T - B;
      const x = t => L + (t / S.T) * iw;
      const e = eqState(), c = conc(S.t);
      const ymax = Math.max(S.A0, S.B0, e.Ct) * 1.18 + .05;
      const y = v => T + (1 - v / ymax) * ih;
      const Q = c.A > 1e-9 ? c.B / c.A : Infinity;
      const step = W.step;
      const dim = need => step >= need ? 1 : .3;

      for (let i = 0; i <= 5; i++) {
        const v = ymax * i / 5;
        line(W.svg, L, y(v), w - R, y(v), { stroke: C.grid2 });
        txt(W.svg, L - 8, y(v), num(v, 2), { size: 9.5, anchor: 'end', fill: C.faint });
      }
      for (let t = 0; t <= S.T; t += 2) {
        line(W.svg, x(t), T, x(t), T + ih, { stroke: C.grid2 });
        txt(W.svg, x(t), T + ih + 14, t, { size: 9.5, anchor: 'middle', fill: C.faint });
      }
      line(W.svg, L, T + ih, w - R, T + ih, { stroke: C.faint });
      line(W.svg, L, T, L, T + ih, { stroke: C.faint });
      txt(W.svg, L - 8, T - 14, 'c / mol·L⁻¹', { size: 10, anchor: 'start', fill: C.soft });
      txt(W.svg, w - R, h - 10, 't / s', { size: 10, anchor: 'end', fill: C.soft });

      /* 曲线 */
      function curveOf(fn, color, op, label) {
        let d = '';
        for (let i = 0; i <= 220; i++) {
          const t = S.T * i / 220, v = fn(t);
          d += (i ? 'L' : 'M') + f2(x(t)) + ' ' + f2(y(v));
        }
        path(W.svg, d, { stroke: color, width: 1.9, opacity: op });
        const endV = fn(S.T);
        txt(W.svg, x(S.T) + 8, y(endV), label, { size: 11, fill: color, weight: 700, opacity: op });
      }
      const opCurve = dim(1);
      curveOf(t => conc(t).A, C.ink, opCurve, 'A');
      curveOf(t => conc(t).B, C.data[1], opCurve, 'B');

      /* 平衡虚线 */
      const opEq = dim(3);
      if (step >= 1) {
        [['A', e.A, C.ink], ['B', e.B, C.data[1]]].forEach(function (it) {
          line(W.svg, L, y(it[1]), w - R, y(it[1]), {
            stroke: C.faint, dash: '3 4', opacity: step >= 3 ? .9 : .3
          });
          txt(W.svg, w - R + 8, y(it[1]), '平衡 ' + num(it[1], 2), {
            size: 9.5, fill: step >= 3 ? C.ink : C.faint, opacity: step >= 3 ? 1 : .5
          });
        });
      }

      /* 当前时刻 */
      line(W.svg, x(S.t), T, x(S.t), T + ih, { stroke: C.ink2, width: 1, dash: '2 3', opacity: .6 });
      circ(W.svg, x(S.t), y(c.A), 3.4, { fill: C.ink });
      circ(W.svg, x(S.t), y(c.B), 3.4, { fill: C.data[1] });
      txt(W.svg, x(S.t) + 7, y(c.A) - 10, '[A] ' + num(c.A, 2), { size: 9.5, fill: C.ink });
      txt(W.svg, x(S.t) + 7, y(c.B) + 12, '[B] ' + num(c.B, 2), { size: 9.5, fill: C.data[1] });

      /* Q vs K 判定 */
      if (step >= 2) {
        const dir = Q < S.K * .995 ? 1 : Q > S.K * 1.005 ? -1 : 0;
        const bx = w - R - 96, by = T + 10;
        rect(W.svg, bx, by, 96, 34, { rx: 2, fill: C.card, stroke: C.line2, opacity: .96 });
        txt(W.svg, bx + 48, by + 11, 'Q = ' + num(Q, 2) + '   K = ' + num(S.K, 2), {
          size: 9.5, anchor: 'middle', fill: C.soft
        });
        const label = dir > 0 ? '正向进行 →' : dir < 0 ? '← 逆向进行' : '已达平衡';
        txt(W.svg, bx + 48, by + 25, label, { size: 10.5, anchor: 'middle', fill: dir ? C.ink : C.jade, weight: 600 });
        if (dir) {
          arrow(W.svg, bx + 34, by + 44, bx + (dir > 0 ? 76 : 12), by + 44, { stroke: C.accent, width: 1.2, size: 5 });
          txt(W.svg, bx + 48, by + 56, '净反应方向', { size: 8.5, anchor: 'middle', fill: C.faint });
        }
      }

      /* 读数 */
      vA.textContent = num(c.A, 2);
      vB.textContent = num(c.B, 2);
      vQ.textContent = isFinite(Q) ? num(Q, 2) : '∞';
      vK.textContent = num(S.K, 2);
      kvDir.textContent = Q < S.K * .995 ? '正向（Q<K）' : Q > S.K * 1.005 ? '逆向（Q>K）' : '平衡（Q≈K）';
      kvEq.textContent = num(e.A, 2) + ' / ' + num(e.B, 2);
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 4. 原电池 / 电解池 ===================== */
  function polyLen(pts) {
    let L = 0;
    for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    return L;
  }
  function polyAt(pts, f) {
    const total = polyLen(pts);
    let target = ((f % 1) + 1) % 1 * total;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i];
      const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (target <= L) {
        const t = L ? target / L : 0;
        return { x: a[0] + (b[0] - a[0]) * t, y: a[1] + (b[1] - a[1]) * t };
      }
      target -= L;
    }
    return { x: pts[pts.length - 1][0], y: pts[pts.length - 1][1] };
  }
  function mountElectrochem(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const L0 = Object.assign({ metal: 'Zn', ion: 'Zn²⁺', sol: 'ZnSO₄ 溶液', e: -.76 }, D.left || D.anode || P.left || {});
    const R0 = Object.assign({ metal: 'Cu', ion: 'Cu²⁺', sol: 'CuSO₄ 溶液', e: .34 }, D.right || D.cathode || P.right || {});
    const S = {
      step: 0, closed: false, phase: 0, w: 800, h: 440,
      emf: +(D.emf != null ? D.emf : (R0.e - L0.e)).toFixed(2),
      showIons: true
    };
    modeHead(W.ctrl, '原电池装置', '两极 · 电子流向 · 离子迁移');
    W.addSteps(['装置', '电子', '离子', '电极反应']);
    csec(W.ctrl, '读数');
    const vE = cstat(W.ctrl, '电动势', num(S.emf, 2), 'V');
    const vLoop = cstat(W.ctrl, '回路', '断开', '');
    ckv(W.ctrl, '负极（氧化）', L0.metal);
    const kvA = W.ctrl.querySelectorAll('.jw-kv b')[0];
    ckv(W.ctrl, '正极（还原）', R0.metal);
    const kvC = W.ctrl.querySelectorAll('.jw-kv b')[1];
    csec(W.ctrl, '电极反应');
    const eA = el('div', { class: 'sb-eq' }, L0.metal + ' − 2e⁻ → ' + L0.ion);
    const eC = el('div', { class: 'sb-eq' }, R0.ion + ' + 2e⁻ → ' + R0.metal);
    W.ctrl.appendChild(eA); W.ctrl.appendChild(eC);
    csec(W.ctrl, '控制');
    const swBtn = el('button', { class: 'jw-btn jw-btn-solid' }, '合上开关');
    W.ctrl.appendChild(swBtn);
    const ionRow = el('div', { class: 'sb-chiprow' });
    W.ctrl.appendChild(ionRow);
    ionRow.appendChild(JW.ui.toggle('显示离子迁移', true, function (on) { S.showIons = on; W.redraw(); }));
    cnote(W.ctrl, '电子由负极经导线流向正极；盐桥中阳离子向正极、阴离子向负极迁移。');

    function setClosed(v) {
      S.closed = v;
      swBtn.textContent = v ? '断开开关' : '合上开关';
      swBtn.classList.toggle('is-on', v);
      vLoop.textContent = v ? '闭合' : '断开';
      vLoop.style.color = v ? C.ink : C.faint;
      W.redraw();
    }
    swBtn.addEventListener('click', function () { setClosed(!S.closed); });
    setClosed(false);

    W.set(function (w, h) {
      S.w = w; S.h = h;
      const step = W.step;
      const dim = need => step >= need ? 1 : .34;
      const xL = w * .27, xR = w * .73;
      const bw = Math.min(112, w * .17), bh = Math.min(104, h * .26);
      const by = h * .66;
      const eTop = h * .40, eBot = by + bh - 14;
      const railY = h * .17;
      const electrodeW = 11;

      /* 导线 */
      const wire = [[xL, eTop], [xL, railY], [xR, railY], [xR, eTop]];
      for (let i = 1; i < wire.length; i++) {
        line(W.svg, wire[i - 1][0], wire[i - 1][1], wire[i][0], wire[i][1], {
          stroke: C.ink2, width: 1.6, opacity: 1
        });
      }

      /* 开关 */
      const swx = w * .38, contact = 9;
      line(W.svg, swx - 22, railY, swx - 6, railY, { stroke: C.ink2, width: 1.6 });
      line(W.svg, swx + 6, railY, swx + 22, railY, { stroke: C.ink2, width: 1.6 });
      circ(W.svg, swx - 6, railY, 2.6, { fill: C.ink });
      circ(W.svg, swx + 6, railY, 2.6, { fill: C.ink });
      if (S.closed) {
        line(W.svg, swx - 6, railY, swx + 6, railY, { stroke: C.ink, width: 2.2 });
      } else {
        line(W.svg, swx - 6, railY, swx + 4, railY - contact, { stroke: C.ink, width: 2.2 });
      }
      txt(W.svg, swx, railY - 22, '开关', { size: 9.5, anchor: 'middle', fill: C.faint, ls: 1 });

      /* 电压表（并联在导线下方） */
      const mx = w * .55, mr = Math.min(19, h * .048);
      const my = railY + 38;
      line(W.svg, mx, railY, mx, my - mr, { stroke: C.ink2, width: 1.2 });
      circ(W.svg, mx, my, mr, { fill: C.card, stroke: C.ink2, width: 1.3 });
      txt(W.svg, mx, my - 3, 'V', { size: 8.5, anchor: 'middle', fill: C.faint });
      txt(W.svg, mx, my + 7, S.closed ? num(S.emf, 2) : '—', { size: 9, anchor: 'middle', fill: C.ink, weight: 700 });

      /* 烧杯与溶液 */
      const beakers = [
        { x: xL, label: '负极 · ' + L0.metal, sol: L0.sol, op: dim(0), metal: L0.metal, color: C.ink },
        { x: xR, label: '正极 · ' + R0.metal, sol: R0.sol, op: dim(0), metal: R0.metal, color: C.data[1] }
      ];
      beakers.forEach(function (b) {
        const x0 = b.x - bw / 2;
        path(W.svg, 'M' + f2(x0) + ' ' + f2(by - 10) + 'V' + f2(by + bh) + 'H' + f2(x0 + bw) + 'V' + f2(by - 10), {
          stroke: C.line, width: 1.4, opacity: 1
        });
        rect(W.svg, x0 + 1, by + 6, bw - 2, bh - 6, { fill: C.data[4], opacity: .45 });
        line(W.svg, x0 + 1, by + 6, x0 + bw - 1, by + 6, { stroke: C.data[2], opacity: .5 });
        txt(W.svg, b.x, by + bh - 12, b.sol, { size: 9.5, anchor: 'middle', fill: C.soft, opacity: b.op });
        txt(W.svg, b.x, by + bh + 20, b.label, { size: 10.5, anchor: 'middle', fill: C.ink, weight: 600, opacity: b.op });
        rect(W.svg, b.x - electrodeW / 2, eTop, electrodeW, eBot - eTop, {
          fill: b.color, opacity: b.op
        });
        txt(W.svg, b.x, eTop - 12, b.metal, { size: 10.5, anchor: 'middle', fill: b.color, weight: 700, opacity: b.op });
      });

      /* 盐桥 */
      const sbY = by - 24;
      path(W.svg, 'M' + f2(xL + bw * .32) + ' ' + f2(sbY + 6) +
        'C' + f2(xL + bw * .5) + ' ' + f2(sbY - 34) + ' ' + f2(xR - bw * .5) + ' ' + f2(sbY - 34) +
        ' ' + f2(xR - bw * .32) + ' ' + f2(sbY + 6), {
        stroke: C.data[3], width: 12, opacity: .65, cap: 'round'
      });
      path(W.svg, 'M' + f2(xL + bw * .32) + ' ' + f2(sbY + 6) +
        'C' + f2(xL + bw * .5) + ' ' + f2(sbY - 34) + ' ' + f2(xR - bw * .5) + ' ' + f2(sbY - 34) +
        ' ' + f2(xR - bw * .32) + ' ' + f2(sbY + 6), {
        stroke: C.data[2], width: 1, dash: '2 4', opacity: .8
      });
      txt(W.svg, (xL + xR) / 2, sbY - 40, '盐桥', { size: 9.5, anchor: 'middle', fill: C.faint, ls: 1.5 });

      /* 离子迁移 */
      if (S.showIons) {
        const io = dim(2);
        arrow(W.svg, (xL + xR) / 2 - 26, sbY - 20, (xL + xR) / 2 + 8, sbY - 20, { stroke: C.data[2], width: 1.1, size: 5, opacity: io });
        txt(W.svg, (xL + xR) / 2 - 6, sbY - 32, 'K⁺ → 正极', { size: 9, anchor: 'middle', fill: C.soft, opacity: io });
        arrow(W.svg, (xL + xR) / 2 + 22, sbY - 6, (xL + xR) / 2 - 12, sbY - 6, { stroke: C.soft, width: 1.1, size: 5, opacity: io });
        txt(W.svg, (xL + xR) / 2 + 6, sbY + 6, '← Cl⁻ 负极', { size: 9, anchor: 'middle', fill: C.soft, opacity: io });
      }

      /* 电极反应（图上标注） */
      const ro = dim(3);
      txt(W.svg, xL, by + bh + 42, L0.metal + ' − 2e⁻ → ' + L0.ion, {
        size: 10, anchor: 'middle', fill: C.ink, opacity: ro, weight: 600
      });
      txt(W.svg, xR, by + bh + 42, R0.ion + ' + 2e⁻ → ' + R0.metal, {
        size: 10, anchor: 'middle', fill: C.ink, opacity: ro, weight: 600
      });

      /* 电子 / 电流方向 */
      const eo = dim(1);
      arrow(W.svg, xL + 34, railY + 17, xL + 72, railY + 17, { stroke: C.ink2, width: 1, size: 4, opacity: eo * .8 });
      txt(W.svg, xL + 80, railY + 17, '电子 e⁻', { size: 9, fill: C.soft, opacity: eo });
      txt(W.svg, xL, railY - 12, '−', { size: 12, anchor: 'middle', fill: C.ink, weight: 700, opacity: eo });
      txt(W.svg, xR, railY - 12, '+', { size: 12, anchor: 'middle', fill: C.ink, weight: 700, opacity: eo });

      /* 电子点 */
      const pts = [[xL, eTop], [xL, railY], [xR, railY], [xR, eTop]];
      const dots = [];
      const N = 9;
      for (let i = 0; i < N; i++) {
        const frac = i / N;
        const p = polyAt(pts, frac);
        const op = S.closed ? eo : .18;
        dots.push(circ(W.svg, p.x, p.y, 3.1, { fill: C.accent, opacity: op }));
      }
      W._ePts = pts; W._eDots = dots;

      /* 状态文字 */
      if (!S.closed) {
        txt(W.svg, mx, my + mr + 13, '回路断开 · 无电流', { size: 9, anchor: 'middle', fill: C.faint });
      }
      eA.style.opacity = step >= 3 ? 1 : .5;
      eC.style.opacity = step >= 3 ? 1 : .5;
      vE.textContent = num(S.emf, 2);
      kvA.textContent = L0.metal + ' / ' + L0.ion;
      kvC.textContent = R0.metal + ' / ' + R0.ion;
    });

    /* 电子动画 */
    let last = 0;
    function loop(ts) {
      if (W.dead) return;
      const dt = last ? Math.min(64, ts - last) : 16;
      last = ts;
      if (S.closed && W._ePts && W._eDots) {
        S.phase = (S.phase + dt * .00016) % 1;
        W._eDots.forEach(function (d, i) {
          const p = polyAt(W._ePts, (S.phase + i / W._eDots.length) % 1);
          d.setAttribute('cx', f2(p.x));
          d.setAttribute('cy', f2(p.y));
        });
      }
      W._raf = requestAnimationFrame(loop);
    }
    W._raf = requestAnimationFrame(loop);
    W.onCleanup(function () { if (W._raf) cancelAnimationFrame(W._raf); });
    W.applyStep(0);
    return W;
  }

  /* ===================== 5. 遗传图解 ===================== */
  function parseGenotype(str) {
    const map = {}, order = [];
    String(str || 'Aa').replace(/[^A-Za-z]/g, '').split('').forEach(function (ch) {
      const k = ch.toUpperCase();
      if (!map[k]) { map[k] = []; order.push(k); }
      map[k].push(ch);
    });
    return order.map(function (k) {
      const arr = map[k];
      const dom = arr.some(c => c === k);
      const rec = arr.some(c => c === c.toLowerCase());
      const pair = dom && rec ? [k, k.toLowerCase()] : dom ? [k, k] : [k.toLowerCase(), k.toLowerCase()];
      return { key: k, pair: pair, gametes: dom && rec ? [k, k.toLowerCase()] : [pair[0]] };
    });
  }
  function crossGametes(genes) {
    let out = [''];
    genes.forEach(function (gene) {
      const next = [];
      out.forEach(function (pre) { gene.gametes.forEach(function (a) { next.push(pre + a); }); });
      out = next;
    });
    return out;
  }
  function phenoOf(geno) {
    let pheno = '', doms = [], key = '';
    for (let i = 0; i < geno.length; i += 2) {
      const a = geno[i], b = geno[i + 1];
      const up = a === a.toUpperCase() ? a : b;
      const hasDom = a === a.toUpperCase() || b === b.toUpperCase();
      key += hasDom ? up + '_' : a.toLowerCase() + a.toLowerCase();
      if (hasDom) doms.push(up);
    }
    return { key: key, doms: doms };
  }
  function mountGenetics(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    let raw1 = 'AaBb', raw2 = 'AaBb';
    const cr = D.cross != null ? D.cross : (P.cross != null ? P.cross : null);
    if (typeof cr === 'string') {
      const parts = cr.split(/[×✕xX*]/);
      raw1 = parts[0] || raw1; raw2 = parts[1] || raw1;
    } else if (cr && typeof cr === 'object') {
      raw1 = cr.p1 || cr.mother || raw1; raw2 = cr.p2 || cr.father || raw1;
    } else if (D.p1 || D.p2) {
      raw1 = D.p1 || raw1; raw2 = D.p2 || raw1;
    }
    const genes1 = parseGenotype(raw1), genes2 = parseGenotype(raw2);
    const geneCount = Math.min(2, Math.max(genes1.length, genes2.length));
    const S = { step: 0, pair: geneCount, pick: -1, model: null };
    function model() {
      const n = Math.min(S.pair, geneCount);
      const a = genes1.slice(0, n), b = genes2.slice(0, n);
      const g1 = crossGametes(a), g2 = crossGametes(b);
      const cells = [];
      const groups = {}, order = [];
      for (let r = 0; r < g1.length; r++) {
        for (let c = 0; c < g2.length; c++) {
          let geno = '';
          for (let i = 0; i < n; i++) {
            const ca = g1[r][i], cb = g2[c][i];
            geno += ca === ca.toUpperCase() ? ca + cb.toLowerCase() : cb + ca.toLowerCase();
          }
          const ph = phenoOf(geno);
          const cell = { r: r, c: c, geno: geno, pheno: ph };
          cells.push(cell);
          if (!groups[ph.key]) { groups[ph.key] = { key: ph.key, doms: ph.doms, n: 0, cells: [] }; order.push(ph.key); }
          groups[ph.key].n++;
          groups[ph.key].cells.push(cell);
        }
      }
      const list = order.map(k => groups[k]);
      list.sort((x, y) => y.n - x.n);
      const g = list.reduce((acc, it) => gcd(acc, it.n), 0) || 1;
      list.forEach(it => { it.ratio = it.n / g; });
      return { g1: g1, g2: g2, cells: cells, groups: list, gcd: g, n: n };
    }
    S.model = model();

    function groupLabel(gr) {
      const n = S.model.n;
      if (n === 1) return gr.doms.length ? '显性' : '隐性';
      if (gr.doms.length === 0) return '双隐';
      if (gr.doms.length === n) return '双显';
      return '单显 ' + gr.doms.join('');
    }
    function shade(k) { return ['.10', '.18', '.27', '.36'][k % 4]; }

    modeHead(W.ctrl, '遗传图解', '亲本配子 · Punnett 棋盘 · 表现型比例');
    W.addSteps(['亲本', '配子', '子代', '比例']);
    csec(W.ctrl, '亲本与配子');
    const kvP = ckv(W.ctrl, 'P', '—');
    const kvG = ckv(W.ctrl, '配子', '—');
    const kvN = ckv(W.ctrl, '组合数', '—');
    const kvR = ckv(W.ctrl, '表现型比', '—');
    csec(W.ctrl, '表现型');
    const legendBox = el('div', { class: 'sb-legend' });
    W.ctrl.appendChild(legendBox);
    const pickBox = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(pickBox);
    if (geneCount > 1) {
      csec(W.ctrl, '等位基因');
      const row = el('div', { class: 'sb-chiprow' });
      W.ctrl.appendChild(row);
      row.appendChild(JW.ui.chips(['一对', '两对'], '两对', function (v) {
        S.pair = v === '一对' ? 1 : 2;
        S.pick = -1;
        S.model = model();
        W.redraw();
      }));
    }
    cnote(W.ctrl, '棋盘行列是双亲配子；格子内为子代基因型，底色按表现型分组。点格子可查看。');

    function rebuildCtrl() {
      const M = S.model;
      kvP.textContent = raw1 + ' × ' + raw2;
      kvG.textContent = M.g1.join(' / ') + '  ·  ' + M.g2.join(' / ');
      kvN.textContent = String(M.cells.length);
      kvR.textContent = M.groups.map(g => g.ratio).join(' : ');
      legendBox.innerHTML = '';
      M.groups.forEach(function (g, i) {
        const row = el('div');
        const sw = el('i');
        sw.style.background = C.data[1];
        sw.style.opacity = String(.14 + i * .17);
        sw.style.height = '9px';
        sw.style.borderRadius = '1px';
        row.appendChild(sw);
        row.appendChild(el('span', {}, groupLabel(g) + '  ' + g.n + '/' + M.cells.length + '  (' + g.ratio + ')'));
        legendBox.appendChild(row);
      });
      if (S.pick >= 0 && M.cells[S.pick]) {
        const c = M.cells[S.pick];
        pickBox.innerHTML = '<b>' + esc(c.geno) + '</b><span>' + esc(groupLabel(M.groups.find(g => g.key === c.pheno.key) || { doms: c.pheno.doms }))
          + ' · ' + esc(c.pheno.key) + '</span><em>子代 ' + (c.r + 1) + ' 行 ' + (c.c + 1) + ' 列</em>';
      } else {
        pickBox.innerHTML = '<b>—</b><span>点棋盘格读取基因型与表现型</span>';
      }
    }
    rebuildCtrl();

    W.set(function (w, h) {
      const M = S.model;
      const step = W.step;
      const P = 20;
      const headH = 52, gw = 62, gh = 26;
      const cols = M.g2.length, rows = M.g1.length;
      const availW = w - P * 2 - gw - 6;
      const availH = h - headH - gh - 52;
      const size = Math.max(26, Math.min(availW / cols, availH / rows));
      const x0 = P + gw + 6 + Math.max(0, (availW - cols * size) / 2), y0 = headH + gh;
      const gx = x0;
      S.grid = { x0: x0, y0: y0, size: size, cols: cols, rows: rows };

      /* 标题 */
      txt(W.svg, P, 22, 'Punnett 棋盘', { size: 12, weight: 700, fill: C.ink, ls: .6 });
      txt(W.svg, w - P, 22, raw1 + ' × ' + raw2, { size: 11, anchor: 'end', fill: C.soft });
      txt(W.svg, P, headH - 10, '配子', { size: 9.5, fill: C.faint, ls: 1.5 });
      txt(W.svg, P + gw - 6, headH - 10, M.g1.join(' / '), { size: 9.5, anchor: 'end', fill: C.faint });

      /* 表头 + 网格 */
      const headOp = step >= 1 ? 1 : .45;
      if (step >= 2) {
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const cell = M.cells[r * cols + c];
            const grp = M.groups.findIndex(g => g.key === cell.pheno.key);
            if (step >= 3) {
              rect(W.svg, gx + c * size, y0 + r * size, size, size, {
                fill: C.data[1], opacity: shade(grp)
              });
            }
          }
        }
      }
      line(W.svg, x0 - 2, y0, x0 - 2, y0 + rows * size, { stroke: C.line });
      line(W.svg, gx, y0 - 2, gx + cols * size, y0 - 2, { stroke: C.line });
      for (let r = 0; r <= rows; r++) line(W.svg, x0 - 2, y0 + r * size, x0 + cols * size, y0 + r * size, { stroke: C.line });
      for (let c = 0; c <= cols; c++) line(W.svg, x0 + c * size, y0 - 2, x0 + c * size, y0 + rows * size, { stroke: C.line });

      /* 行列表头 */
      M.g2.forEach(function (g, c) {
        txt(W.svg, x0 + c * size + size / 2, y0 - 14, g, {
          size: 11.5, anchor: 'middle', weight: 700, fill: C.ink, opacity: headOp
        });
      });
      M.g1.forEach(function (g, r) {
        txt(W.svg, x0 - 12, y0 + r * size + size / 2, g, {
          size: 11.5, anchor: 'end', weight: 700, fill: C.ink, opacity: headOp
        });
      });

      /* 格内基因型 */
      if (step >= 2) {
        M.cells.forEach(function (cell, k) {
          const r = cell.r, c = cell.c;
          const cx = x0 + c * size + size / 2, cy = y0 + r * size + size / 2;
          if (S.pick === k) {
            rect(W.svg, x0 + c * size + 1, y0 + r * size + 1, size - 2, size - 2, {
              fill: 'none', stroke: C.accent, width: 1.6
            });
          }
          txt(W.svg, cx, cy, cell.geno, {
            size: Math.max(9.5, Math.min(12, size * .25)), anchor: 'middle',
            fill: C.ink, weight: 500
          });
        });
      }

      /* 亲本 */
      const pOp = step >= 0 ? 1 : .4;
      txt(W.svg, x0 + cols * size / 2, h - 22, 'P：' + raw1 + '（♀）× ' + raw2 + '（♂）', {
        size: 10.5, anchor: 'middle', fill: C.soft, opacity: pOp
      });

      /* 比例条 */
      if (step >= 3) {
        let bx = P;
        const by = y0 + rows * size + 24;
        const total = M.groups.reduce((a, g) => a + g.n, 0);
        M.groups.forEach(function (g, i) {
          const bw = (g.n / total) * (w - P * 2);
          rect(W.svg, bx, by, bw, 5, { fill: C.data[1], opacity: shade(i) });
          if (bw > 34) {
            txt(W.svg, bx + bw / 2, by + 15, g.n / M.gcd, {
              size: 9.5, anchor: 'middle', fill: C.soft
            });
          }
          bx += bw;
        });
        txt(W.svg, P, by - 7, '表现型分离比 ' + M.groups.map(g => g.ratio).join(' : '), {
          size: 9.5, fill: C.faint
        });
      }
      rebuildCtrl();
    });

    /* 点击格子 */
    W.svg.style.cursor = 'default';
    W.svg.addEventListener('click', function (e) {
      const M = S.model, G = S.grid;
      if (!G) return;
      const rectR = W.svg.getBoundingClientRect();
      const px = e.clientX - rectR.left, py = e.clientY - rectR.top;
      const { x0, y0, size, cols, rows } = G;
      if (px >= x0 && py >= y0 && px <= x0 + cols * size && py <= y0 + rows * size) {
        const c = Math.floor((px - x0) / size), r = Math.floor((py - y0) / size);
        const k = r * cols + c;
        if (k >= 0 && k < M.cells.length) {
          S.pick = S.pick === k ? -1 : k;
          W.redraw();
        }
      }
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 6. 细胞结构 ===================== */
  function mountCell(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const isPlant = (D.type || P.type || 'animal') === 'plant';
    const ORGS = [
      { key: 'membrane', name: '细胞膜', desc: '磷脂双分子层，控制物质进出，进行细胞间的信息交流。' },
      { key: 'nucleus', name: '细胞核', desc: '遗传信息库，DNA 复制与转录的场所，控制细胞的代谢与遗传。' },
      { key: 'mito', name: '线粒体', desc: '有氧呼吸的主要场所，内膜折叠成嵴，为细胞提供 ATP。' },
      { key: 'er', name: '内质网', desc: '与核膜相连的膜性管网，负责蛋白质与脂质的合成、加工与运输。' },
      { key: 'golgi', name: '高尔基体', desc: '对来自内质网的蛋白质进行分类、包装与发送。' },
      { key: 'ribo', name: '核糖体', desc: '蛋白质合成的机器，游离或附着在内质网上。' }
    ];
    if (isPlant) {
      ORGS.push({ key: 'wall', name: '细胞壁', desc: '主要成分是纤维素，起支持和保护作用，全透性。' });
      ORGS.push({ key: 'chloro', name: '叶绿体', desc: '光合作用的场所，含叶绿素，把光能转变成化学能。' });
      ORGS.push({ key: 'vacuole', name: '液泡', desc: '贮存细胞液，含糖类、色素等，维持细胞的渗透压。' });
    }
    const S = { step: 0, sel: 'nucleus' };
    const stepSel = ['', 'nucleus', 'mito', 'membrane'];
    modeHead(W.ctrl, '细胞结构', isPlant ? '植物细胞 · 点选结构看功能' : '动物细胞 · 点选结构看功能');
    W.addSteps(['整体', '细胞核', '细胞器', '细胞膜']);
    csec(W.ctrl, '已选结构');
    const detail = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(detail);
    csec(W.ctrl, '结构列表');
    const listBox = el('div', { class: 'sb-orglist' });
    W.ctrl.appendChild(listBox);
    const rows = {};
    ORGS.forEach(function (o) {
      const row = el('div', { class: 'sb-org' }, o.name);
      row.addEventListener('click', function () { S.sel = o.key; select(); });
      listBox.appendChild(row);
      rows[o.key] = row;
    });
    cnote(W.ctrl, '点击图上任一结构或左侧列表，查看它的功能与位置。');

    function select() {
      const o = ORGS.find(x => x.key === S.sel);
      detail.innerHTML = o ? '<b>' + esc(o.name) + '</b><span>' + esc(o.desc) + '</span>' : '<b>—</b><span>点选结构</span>';
      ORGS.forEach(function (x) { rows[x.key].classList.toggle('is-on', x.key === S.sel); });
      W.redraw();
    }

    W.set(function (w, h) {
      const step = W.step;
      const cx = w * .45, cy = h * .52;
      const rx = Math.min(w * .34, (h - 64) * .62), ry = rx * .66;
      const ink2 = C.ink2;
      const baseW = 1.3;
      const selW = 1.9;
      const st = key => S.sel === key ? C.accent : ink2;
      const sw = key => S.sel === key ? selW : baseW;
      const fo = key => S.sel === key ? .28 : .14;

      /* 细胞边界 */
      if (isPlant) {
        rect(W.svg, cx - rx - 13, cy - ry - 13, (rx + 13) * 2, (ry + 13) * 2, {
          rx: 20, fill: 'none', stroke: st('wall'), width: sw('wall') + 1.4
        });
        rect(W.svg, cx - rx, cy - ry, rx * 2, ry * 2, {
          rx: 14, fill: C.data[4], stroke: st('membrane'), width: sw('membrane')
        });
        txt(W.svg, cx - rx - 8, cy - ry - 22, '细胞壁', { size: 10, fill: st('wall'), anchor: 'start' });
      } else {
        put(W.svg, 'ellipse', {
          cx: cx, cy: cy, rx: rx, ry: ry,
          fill: C.data[4], stroke: st('membrane'), 'stroke-width': sw('membrane')
        });
        line(W.svg, cx, cy - ry, cx, cy - ry - 16, { stroke: st('membrane'), width: .9 });
        txt(W.svg, cx + 4, cy - ry - 22, '细胞膜', { size: 10, fill: st('membrane') });
      }

      function hit(g, key) {
        g.style.cursor = 'pointer';
        g.addEventListener('click', function (e) { e.stopPropagation(); S.sel = key; select(); });
        return g;
      }
      function label(x, y, s, key, anchor) {
        txt(W.svg, clamp(x, 34, w - 34), clamp(y, 14, h - 12), s, {
          size: 10, fill: st(key), anchor: anchor || 'middle', weight: S.sel === key ? 600 : 400
        });
      }

      /* 细胞核 */
      const nx = cx - rx * .26, ny = cy - ry * .22, nr = Math.min(rx, ry) * .30;
      const gN = sv('g');
      circ(gN, nx, ny, nr, { fill: C.card, stroke: st('nucleus'), width: sw('nucleus'), opacity: .95 });
      circ(gN, nx + nr * .18, ny - nr * .1, nr * .3, {
        fill: C.data[4], stroke: C.data[1], width: .9
      });
      W.svg.appendChild(hit(gN, 'nucleus'));
      txt(W.svg, nx, ny + nr + 13, '细胞核', { size: 10, anchor: 'middle', fill: st('nucleus') });

      /* 内质网 */
      const ex = cx - rx * .46, ey = cy + ry * .05;
      const gE = sv('g');
      for (let k = 0; k < 3; k++) {
        path(gE, 'M' + f2(ex + k * 9) + ' ' + f2(ey - 26 + k * 4) +
          'q' + f2(13) + ' ' + f2(9) + ' 0 ' + f2(18) +
          'q' + f2(-11) + ' ' + f2(9) + ' 0 ' + f2(18), {
          stroke: st('er'), width: sw('er'), opacity: .85
        });
      }
      W.svg.appendChild(hit(gE, 'er'));
      label(ex + 14, ey + 42, '内质网', 'er');

      /* 高尔基体 */
      const gx = cx + rx * .16, gy = cy + ry * .52;
      const gG = sv('g');
      for (let k = 0; k < 3; k++) {
        path(gG, 'M' + f2(gx - 24 + k * 3) + ' ' + f2(gy - k * 7) +
          'q' + f2(24 - k * 3) + ' ' + f2(-8) + ' ' + f2(48 - k * 6) + ' 0', {
          stroke: st('golgi'), width: sw('golgi'), opacity: .9
        });
      }
      W.svg.appendChild(hit(gG, 'golgi'));
      label(gx, gy + 18, '高尔基体', 'golgi');

      /* 线粒体 */
      function mito(x, y, rxx, ryy, rot) {
        const g = sv('g', { transform: 'rotate(' + rot + ' ' + f2(x) + ' ' + f2(y) + ')' });
        put(g, 'ellipse', {
          cx: x, cy: y, rx: rxx, ry: ryy, fill: C.card, stroke: st('mito'), 'stroke-width': sw('mito')
        });
        path(g, 'M' + f2(x - rxx * .62) + ' ' + f2(y) + 'q' + f2(rxx * .2) + ' ' + f2(-ryy * .8) + ' ' +
          f2(rxx * .38) + ' 0 q' + f2(rxx * .2) + ' ' + f2(ryy * .8) + ' ' + f2(rxx * .38) + ' 0', {
          stroke: st('mito'), width: .9, opacity: .8
        });
        W.svg.appendChild(hit(g, 'mito'));
        return g;
      }
      mito(cx + rx * .5, cy - ry * .28, Math.min(28, rx * .17), Math.min(13, ry * .17), -18);
      label(cx + rx * .5, cy - ry * .28 - 22, '线粒体', 'mito');
      mito(cx + rx * .1, cy - ry * .62, Math.min(20, rx * .12), Math.min(9, ry * .12), 12);

      /* 核糖体 */
      const gR = sv('g');
      const rp = [[.62, .28], [.7, .4], [.58, .46], [.76, .18], [.5, .62], [.32, .56]];
      rp.forEach(function (pt) {
        circ(gR, cx + rx * pt[0], cy + ry * pt[1], 2.4, { fill: st('ribo') });
        circ(gR, cx + rx * pt[0] + 6, cy + ry * pt[1] + 4, 2.4, { fill: st('ribo') });
      });
      W.svg.appendChild(hit(gR, 'ribo'));
      label(cx + rx * .66, cy + ry * .32, '核糖体', 'ribo', 'start');

      if (isPlant) {
        /* 叶绿体 */
        const cg = sv('g', { transform: 'rotate(14 ' + f2(cx + rx * .2) + ' ' + f2(cy - ry * .62) + ')' });
        put(cg, 'ellipse', {
          cx: cx + rx * .2, cy: cy - ry * .62, rx: Math.min(28, rx * .18), ry: Math.min(13, ry * .17),
          fill: C.data[4], stroke: st('chloro'), 'stroke-width': sw('chloro')
        });
        for (let k = -2; k <= 2; k++) {
          line(cg, cx + rx * .2 + k * 6, cy - ry * .62 - 7, cx + rx * .2 + k * 6, cy - ry * .62 + 7, {
            stroke: st('chloro'), width: .8, opacity: .7
          });
        }
        W.svg.appendChild(hit(cg, 'chloro'));
        label(cx + rx * .2, cy - ry * .62 - 20, '叶绿体', 'chloro');

        /* 液泡 */
        const vg = sv('g');
        put(vg, 'ellipse', {
          cx: cx + rx * .42, cy: cy + ry * .1, rx: rx * .26, ry: ry * .3,
          fill: C.card, stroke: st('vacuole'), 'stroke-width': sw('vacuole'), opacity: .9
        });
        W.svg.appendChild(hit(vg, 'vacuole'));
        label(cx + rx * .42, cy + ry * .1 + ry * .3 + 12, '液泡', 'vacuole');
      }

      /* 整体提示 */
      txt(W.svg, 18, h - 16, step >= 1 ? '点选结构高亮，右侧看功能' : '选择一种结构', {
        size: 9.5, fill: C.faint
      });
      if (S.sel) {
        const o = ORGS.find(x => x.key === S.sel);
        if (o) detail.innerHTML = '<b>' + esc(o.name) + '</b><span>' + esc(o.desc) + '</span>';
      }
    });

    W.applyStep = function (i) {
      W.step = Math.max(0, Math.round(i || 0));
      if (W.syncSteps) W.syncSteps(W.step);
      const key = stepSel[Math.min(W.step, stepSel.length - 1)];
      if (key) S.sel = key;
      select();
    };
    select();
    W.applyStep(0);
    return W;
  }

  /* ===================== 7. 生态：食物网 + 能量金字塔 ===================== */
  function mountEcology(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const DEF_NODES = [
      { id: '草', label: '草', level: 0 }, { id: '兔', label: '兔', level: 1 },
      { id: '鼠', label: '鼠', level: 1 }, { id: '狐', label: '狐', level: 2 },
      { id: '蛇', label: '蛇', level: 2 }, { id: '鹰', label: '鹰', level: 3 }
    ];
    const DEF_LINKS = [['草', '兔'], ['草', '鼠'], ['兔', '狐'], ['鼠', '蛇'], ['蛇', '鹰'], ['狐', '鹰']];
    const nodes = (D.nodes && D.nodes.length ? D.nodes : DEF_NODES).map(function (n) {
      return { id: n.id || n.label, label: n.label || n.id, level: n.level == null ? 0 : +n.level };
    });
    const links = (D.links && D.links.length ? D.links : DEF_LINKS).map(function (l) {
      return { a: l[0] != null ? l[0] : l.from, b: l[1] != null ? l[1] : l.to };
    });
    const levelE = D.energy || [10000, 1000, 100, 10];
    const S = { step: 0, sel: nodes[nodes.length - 1].id, hover: null };
    const consumers = {};
    links.forEach(function (l) {
      const A = nodes.find(n => n.id === l.a), B = nodes.find(n => n.id === l.b);
      if (!A || !B) return;
      const lo = A.level <= B.level ? A : B, hi = A.level <= B.level ? B : A;
      (consumers[lo.id] = consumers[lo.id] || []).push(hi.id);
    });
    function reach(id) {
      const seen = { }, q2 = [id], order = [id];
      while (q2.length) {
        const cur = q2.shift();
        (consumers[cur] || []).forEach(function (nxt) {
          if (!seen[nxt]) { seen[nxt] = 1; order.push(nxt); q2.push(nxt); }
        });
      }
      return order;
    }
    modeHead(W.ctrl, '生态系统', '能量金字塔 · 食物网路径');
    W.addSteps(['金字塔', '10% 传递', '食物网', '路径']);
    csec(W.ctrl, '读数');
    const vSel = cstat(W.ctrl, '选中', '—', '');
    const vLvl = cstat(W.ctrl, '营养级', '—', '');
    const vEn = cstat(W.ctrl, '能量', '—', 'kJ');
    ckv(W.ctrl, '捕食者', '—');
    const kvUp = W.ctrl.querySelectorAll('.jw-kv b')[0];
    ckv(W.ctrl, '传递效率', '10%');
    cnote(W.ctrl, '能量沿食物链单向流动、逐级递减；点节点高亮它到顶级消费者的路径。');

    W.set(function (w, h) {
      const step = W.step;
      const P = 18;
      const pw = Math.min(w * .34, 250);
      const px = P + pw * .45, baseY = h - 56, topY = 62;
      const bh = (baseY - topY) / 4;
      const maxW = pw * .72;
      const levels = ['生产者', '初级消费', '次级消费', '三级消费'];

      txt(W.svg, P, 22, '能量金字塔', { size: 12, weight: 700, fill: C.ink, ls: .6 });
      txt(W.svg, P, 38, '宽度按能量对数示意', { size: 9.5, fill: C.faint });
      for (let k = 0; k < 4; k++) {
        const wb = maxW * (4 - k) / 4, wt = maxW * (4 - k - 1) / 4;
        const yTop = baseY - (k + 1) * bh, yBot = baseY - k * bh;
        const op = step >= 1 ? (k === 0 ? .34 : .24) : .12;
        path(W.svg, 'M' + f2(px - wb / 2) + ' ' + f2(yBot) + 'L' + f2(px - wt / 2) + ' ' + f2(yTop) +
          'L' + f2(px + wt / 2) + ' ' + f2(yTop) + 'L' + f2(px + wb / 2) + ' ' + f2(yBot) + 'Z', {
          fill: C.data[1], opacity: op, stroke: C.data[2], width: .8
        });
        const midY = (yTop + yBot) / 2;
        txt(W.svg, px, midY - 6, levels[k], { size: 9.5, anchor: 'middle', fill: C.ink, opacity: .9 });
        txt(W.svg, px, midY + 8, String(levelE[k] || 0), { size: 10.5, anchor: 'middle', fill: C.ink, weight: 700 });
        if (k > 0) {
          const ay = yBot;
          arrow(W.svg, px + wb / 2 + 10, ay + 6, px + wb / 2 + 10, ay - 14, {
            stroke: C.data[2], width: 1, size: 5, opacity: step >= 1 ? .9 : .25
          });
          txt(W.svg, px + wb / 2 + 16, ay - 4, '10%', { size: 9, fill: C.soft, opacity: step >= 1 ? 1 : .3 });
        }
      }
      txt(W.svg, P, h - 26, '单位：kJ / (m²·a)', { size: 9, fill: C.faint });

      /* 食物网 */
      const wx0 = P + pw + 30, wx1 = w - 20;
      const wy0 = h - 56, wy1 = 56;
      txt(W.svg, wx0, 22, '食物网', { size: 12, weight: 700, fill: C.ink, ls: .6 });
      const byLevel = {};
      nodes.forEach(function (n) { (byLevel[n.level] = byLevel[n.level] || []).push(n); });
      const pos = {};
      Object.keys(byLevel).forEach(function (lv) {
        const arr = byLevel[lv];
        arr.forEach(function (n, i) {
          const x = wx0 + (arr.length === 1 ? .5 : (i + .5) / arr.length) * (wx1 - wx0);
          const y = wy0 + (wy1 - wy0) * (clamp(+lv, 0, 3) / 3);
          pos[n.id] = { x: x, y: y };
        });
      });
      const pathNodes = step >= 3 ? reach(S.sel) : [];
      const onPath = id => pathNodes.indexOf(id) >= 0;
      links.forEach(function (l) {
        const A = pos[l.a], B = pos[l.b];
        if (!A || !B) return;
        const hi = (nodes.find(n => n.id === l.a).level <= nodes.find(n => n.id === l.b).level) ? l.b : l.a;
        const from = hi === l.b ? A : B, to = hi === l.b ? B : A;
        const lit = step >= 3 && onPath(l.a) && onPath(l.b);
        line(W.svg, from.x, from.y - 13, to.x, to.y + 13, {
          stroke: lit ? C.accent : C.data[2], width: lit ? 1.8 : 1, opacity: step >= 2 ? (lit ? 1 : .55) : .2
        });
      });
      nodes.forEach(function (n) {
        const p = pos[n.id];
        const lit = step >= 3 && onPath(n.id);
        const sel = n.id === S.sel;
        circ(W.svg, p.x, p.y, 14, {
          fill: sel || lit ? C.card : C.grid2,
          stroke: sel || lit ? C.accent : C.ink2, width: sel || lit ? 1.8 : 1, opacity: step >= 2 ? 1 : .55
        });
        txt(W.svg, p.x, p.y, n.label, { size: 10.5, anchor: 'middle', fill: C.ink, weight: sel ? 700 : 500 });
        txt(W.svg, p.x, p.y + 23, '第' + (n.level + 1) + '营养级', { size: 8.5, anchor: 'middle', fill: C.faint, opacity: step >= 2 ? 1 : .3 });
      });

      /* 读数 */
      const selN = nodes.find(n => n.id === S.sel);
      if (selN) {
        vSel.textContent = selN.label;
        vLvl.textContent = '第 ' + (selN.level + 1) + ' 营养级';
        vEn.textContent = String(levelE[selN.level] || 0);
        kvUp.textContent = (consumers[selN.id] || []).map(id => (nodes.find(n => n.id === id) || {}).label).join('、') || '无（顶级）';
      }
    });

    W.svg.style.cursor = 'pointer';
    W.svg.addEventListener('click', function (e) {
      const r = W.svg.getBoundingClientRect();
      const px = e.clientX - r.left, py = e.clientY - r.top;
      const w = W.w, h = W.h, P = 18;
      const pw = Math.min(w * .34, 250), wx0 = P + pw + 30, wx1 = w - 20;
      const wy0 = h - 56, wy1 = 56;
      const byLevel = {};
      nodes.forEach(function (n) { (byLevel[n.level] = byLevel[n.level] || []).push(n); });
      let best = null, bd = 1e9;
      Object.keys(byLevel).forEach(function (lv) {
        const arr = byLevel[lv];
        arr.forEach(function (n, i) {
          const x = wx0 + (arr.length === 1 ? .5 : (i + .5) / arr.length) * (wx1 - wx0);
          const y = wy0 + (wy1 - wy0) * (clamp(+lv, 0, 3) / 3);
          const d = Math.hypot(px - x, py - y);
          if (d < bd) { bd = d; best = n; }
        });
      });
      if (best && bd < 26) { S.sel = best.id; W.redraw(); }
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 8. 历史时间轴 ===================== */
  function mountTimeline(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const DEF = [
      { t: -221, label: '秦统一六国', desc: '建立中央集权制度，统一文字、度量衡。' },
      { t: 105, label: '蔡伦改进造纸术', desc: '书写材料成本大幅下降，推动文化传播。' },
      { t: 618, label: '唐朝建立', desc: '制度完备、丝路畅通，形成开放的文化格局。' },
      { t: 960, label: '北宋建立', desc: '商品经济与市民文化兴起，科举规模扩大。' },
      { t: 1405, label: '郑和下西洋', desc: '远洋航行展示国力，促进中外交流。' },
      { t: 1840, label: '鸦片战争', desc: '国门被迫打开，中国近代史开端。' },
      { t: 1911, label: '辛亥革命', desc: '推翻君主专制，建立共和政体。' },
      { t: 1949, label: '中华人民共和国成立', desc: '民族独立与人民解放，进入新阶段。' }
    ];
    const evs = (D.events && D.events.length ? D.events : DEF).map(function (e) {
      return { t: +(e.t != null ? e.t : e.year), label: e.label || e.title || '', desc: e.desc || '' };
    }).sort((a, b) => a.t - b.t);
    const links = (D.links && D.links.length ? D.links : [[0, 1], [1, 2], [2, 3], [4, 5], [5, 6], [6, 7]]);
    const S = { step: 0, sel: 0, drag: false, geo: null };
    modeHead(W.ctrl, '历史时间轴', '年代轴 · 事件卡 · 因果连线');
    W.addSteps(['年代轴', '事件', '因果', '定位']);
    csec(W.ctrl, '读数');
    const vY = cstat(W.ctrl, '年代', '—', '');
    const vE = cstat(W.ctrl, '定位事件', '—', '');
    ckv(W.ctrl, '跨度', '—');
    const kvSp = W.ctrl.querySelectorAll('.jw-kv b')[0];
    ckv(W.ctrl, '因果链', '—');
    const kvL = W.ctrl.querySelectorAll('.jw-kv b')[1];
    const descBox = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(descBox);
    cnote(W.ctrl, '拖动轴上竖线定位事件；事件卡上下交错，虚线表示因果关联。');

    W.set(function (w, h) {
      const step = W.step;
      const P = 22, axisY = h * .52;
      const x0 = P + 8, x1 = w - P - 8;
      const t0 = evs[0].t, t1 = evs[evs.length - 1].t;
      const span = Math.max(1, t1 - t0);
      const tx = t => x0 + ((t - t0) / span) * (x1 - x0);
      const cardW = clamp((x1 - x0) / evs.length - 6, 62, 104);
      const minGap = cardW + 6;
      const cxs = [];
      evs.forEach(function (e, i) {
        let x = tx(e.t);
        if (i) x = Math.max(x, cxs[i - 1] + minGap);
        cxs.push(x);
      });
      const shift = cxs[cxs.length - 1] - (x1 - cardW / 2);
      if (shift > 0) for (let i = 0; i < cxs.length; i++) cxs[i] -= shift;
      S.geo = { P: P, axisY: axisY, x0: x0, x1: x1, t0: t0, t1: t1, tx: tx, cardXs: cxs };

      txt(W.svg, P, 22, '历史时间轴', { size: 12, weight: 700, fill: C.ink, ls: .6 });
      txt(W.svg, w - P, 22, evs[0].t + ' — ' + evs[evs.length - 1].t, { size: 10, anchor: 'end', fill: C.soft });

      /* 年代轴 */
      line(W.svg, x0 - 10, axisY, x1 + 10, axisY, { stroke: C.faint, width: 1 });
      arrowHead(W.svg, x1 + 12, axisY, 0, 5, C.faint);
      for (let k = 0; k <= 5; k++) {
        const t = Math.round(t0 + span * k / 5);
        const x = tx(t);
        line(W.svg, x, axisY - 4, x, axisY + 4, { stroke: C.faint });
        txt(W.svg, x, axisY + 17, t < 0 ? '前' + (-t) : t, { size: 9, anchor: 'middle', fill: C.faint });
      }

      /* 因果连线 */
      if (step >= 2) {
        links.forEach(function (l) {
          const a = evs[l[0]], b = evs[l[1]];
          if (!a || !b) return;
          const ax = cxs[l[0]], bx = cxs[l[1]];
          const upA = l[0] % 2 === 0, upB = l[1] % 2 === 0;
          const ay = upA ? axisY - 68 : axisY + 68;
          const by = upB ? axisY - 68 : axisY + 68;
          path(W.svg, 'M' + f2(ax) + ' ' + f2(ay) + 'C' + f2(ax + 20) + ' ' + f2((ay + by) / 2) +
            ' ' + f2(bx - 20) + ' ' + f2((ay + by) / 2) + ' ' + f2(bx) + ' ' + f2(by), {
            stroke: C.data[2], width: 1, dash: '3 4', opacity: .7
          });
          arrowHead(W.svg, bx, by, Math.atan2(by - ay, bx - ax), 5, C.data[2], .8);
        });
      }

      /* 事件卡 */
      evs.forEach(function (e, i) {
        const cx = cxs[i];
        const up = i % 2 === 0;
        const ch = 56;
        const cy = up ? axisY - 34 - ch : axisY + 34;
        const active = i === S.sel;
        if (step >= 1) {
          line(W.svg, cx, up ? cy + ch : cy, cx, axisY, { stroke: C.line, width: 1 });
          circ(W.svg, cx, axisY, 2.6, { fill: active ? C.accent : C.ink2 });
          rect(W.svg, cx - cardW / 2, cy, cardW, ch, {
            rx: 2, fill: C.card, stroke: active ? C.accent : C.line, width: active ? 1.4 : 1
          });
          txt(W.svg, cx - cardW / 2 + 7, cy + 13, e.t < 0 ? '前' + (-e.t) : String(e.t), {
            size: 9.5, fill: active ? C.accent : C.faint, weight: 600
          });
          const lines = wrapText(e.label, cardW - 14, 10.5).slice(0, 3);
          lines.forEach(function (ln, k) {
            txt(W.svg, cx - cardW / 2 + 7, cy + 28 + k * 13, ln, { size: 10.5, fill: C.ink });
          });
        } else {
          circ(W.svg, cx, axisY, 2.2, { fill: C.ink2, opacity: .5 });
        }
      });

      /* 游标 */
      const cur = evs[S.sel] || evs[0];
      const cxp = cxs[S.sel] || x0;
      line(W.svg, cxp, axisY - 20, cxp, axisY + 20, {
        stroke: step >= 3 ? C.accent : C.ink2, width: step >= 3 ? 1.6 : 1, opacity: step >= 3 ? 1 : .6
      });
      put(W.svg, 'path', {
        d: 'M' + f2(cxp - 5) + ' ' + f2(axisY - 24) + 'L' + f2(cxp + 5) + ' ' + f2(axisY - 24) +
          'L' + f2(cxp) + ' ' + f2(axisY - 18) + 'Z',
        fill: step >= 3 ? C.accent : C.ink2, opacity: .9
      });

      /* 读数 */
      vY.textContent = (cur.t < 0 ? '前' + (-cur.t) : cur.t) + ' 年';
      vE.textContent = cur.label;
      kvSp.textContent = (evs[0].t < 0 ? '前' + (-evs[0].t) : evs[0].t) + ' — ' + evs[evs.length - 1].t + ' 年';
      kvL.textContent = links.length + ' 条';
      descBox.innerHTML = '<b>' + esc(cur.label) + '</b><span>' + esc(cur.desc || '（暂无说明）') + '</span>';
    });

    function pickAt(px) {
      if (!S.geo) return;
      let best = 0, bd = 1e9;
      const xs = S.geo.cardXs || [];
      xs.forEach(function (x, i) {
        const d = Math.abs(px - x);
        if (d < bd) { bd = d; best = i; }
      });
      S.sel = best;
      W.redraw();
    }
    JW.drag(W.svg, {
      down: function (p) { S.drag = true; pickAt(p.x); },
      move: function (p) { if (S.drag) pickAt(p.x); },
      up: function () { S.drag = false; }
    });
    W.svg.style.cursor = 'ew-resize';
    W.applyStep(0);
    return W;
  }

  /* ===================== 9. 地理简图 ===================== */
  function mountMap(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const LON0 = 73, LON1 = 135, LAT0 = 54, LAT1 = 17;
    const DEF_POINTS = [
      { label: '北京', lon: 116.4, lat: 39.9 },
      { label: '上海', lon: 121.5, lat: 31.2 },
      { label: '广州', lon: 113.3, lat: 23.1 },
      { label: '成都', lon: 104.1, lat: 30.6 },
      { label: '武汉', lon: 114.3, lat: 30.6 },
      { label: '西安', lon: 108.9, lat: 34.3 },
      { label: '乌鲁木齐', lon: 87.6, lat: 43.8 }
    ];
    const pts = (D.points && D.points.length ? D.points : DEF_POINTS).map(function (p) {
      return {
        label: p.label || p.name || '',
        lon: p.lon != null ? +p.lon : 100,
        lat: p.lat != null ? +p.lat : 30,
        note: p.note || '',
        nx: p.x, ny: p.y
      };
    });
    const arrows = (D.arrows && D.arrows.length ? D.arrows : [
      { x1: .78, y1: .18, x2: .55, y2: .42, label: '夏季风' },
      { x1: .72, y1: .30, x2: .50, y2: .55, label: '夏季风' },
      { x1: .82, y1: .52, x2: .74, y2: .30, label: '沿岸流' }
    ]).map(function (a) {
      if (a.x1 != null) return { x1: +a.x1, y1: +a.y1, x2: +a.x2, y2: +a.y2, label: a.label || '' };
      if (a.lon1 != null) return {
        x1: (a.lon1 - LON0) / (LON1 - LON0), y1: (LAT0 - a.lat1) / (LAT0 - LAT1),
        x2: (a.lon2 - LON0) / (LON1 - LON0), y2: (LAT0 - a.lat2) / (LAT0 - LAT1), label: a.label || ''
      };
      const x = a.x != null ? +a.x : .5, y = a.y != null ? +a.y : .4;
      return { x1: x, y1: y, x2: a.x2 != null ? +a.x2 : x + .12, y2: a.y2 != null ? +a.y2 : y - .12, label: a.label || '' };
    });
    const S = { step: 0, sel: -1, grid: true };
    const OUTLINE = [
      [73.5, 39], [80, 45], [87, 49], [96, 49], [105, 47.5], [116, 49.5], [123, 53], [127, 50],
      [130, 48], [134, 48.5], [131, 45], [128, 42.5], [124, 40.5], [122, 39], [121.5, 37],
      [119, 35], [121, 31.5], [120, 27], [118, 24], [115, 22.5], [110, 21.5], [108, 18.5],
      [102, 22], [99, 24.5], [97, 28], [92, 28], [88, 27], [82, 30], [78, 33], [75, 37]
    ];
    modeHead(W.ctrl, '区域地理简图', '经纬网 · 地形水系 · 风向洋流');
    W.addSteps(['轮廓', '城市', '地形', '气流']);
    csec(W.ctrl, '读数');
    const vN = cstat(W.ctrl, '标记点', '—', '个');
    const vA = cstat(W.ctrl, '箭头', '—', '条');
    ckv(W.ctrl, '经度范围', '73°E — 135°E');
    ckv(W.ctrl, '纬度范围', '17°N — 54°N');
    const detail = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(detail);
    const gridRow = el('div', { class: 'sb-chiprow' });
    W.ctrl.appendChild(gridRow);
    gridRow.appendChild(JW.ui.toggle('经纬网', true, function (on) { S.grid = on; W.redraw(); }));
    cnote(W.ctrl, '轮廓为示意简图；点城市标记可读取经纬度。');

    W.set(function (w, h) {
      const M = 26, T = 30, R = w - 22, B = h - 34;
      const iw = R - M, ih = B - T;
      const px = lon => M + (lon - LON0) / (LON1 - LON0) * iw;
      const py = lat => T + (LAT0 - lat) / (LAT0 - LAT1) * ih;
      const nx = v => M + clamp(v, 0, 1) * iw;
      const ny = v => T + clamp(v, 0, 1) * ih;
      const step = W.step;

      /* 经纬网 */
      if (S.grid) {
        for (let lon = 80; lon <= 130; lon += 10) {
          line(W.svg, px(lon), T, px(lon), B, { stroke: C.grid2 });
          txt(W.svg, px(lon), T - 10, lon + '°E', { size: 8.5, anchor: 'middle', fill: C.faint });
        }
        for (let lat = 20; lat <= 50; lat += 10) {
          line(W.svg, M, py(lat), R, py(lat), { stroke: C.grid2 });
          txt(W.svg, M - 6, py(lat), lat + '°N', { size: 8.5, anchor: 'end', fill: C.faint });
        }
      }

      /* 轮廓 */
      let d = '';
      OUTLINE.forEach(function (pt, i) { d += (i ? 'L' : 'M') + f2(px(pt[0])) + ' ' + f2(py(pt[1])); });
      d += 'Z';
      path(W.svg, d, { fill: C.data[4], stroke: C.data[1], width: 1.2, opacity: .95 });
      put(W.svg, 'ellipse', {
        cx: px(121.2), cy: py(23.7), rx: 5, ry: 9, fill: C.data[4], stroke: C.data[1], 'stroke-width': .9
      });
      put(W.svg, 'ellipse', {
        cx: px(110), cy: py(19.4), rx: 7, ry: 4, fill: C.data[4], stroke: C.data[1], 'stroke-width': .9
      });
      txt(W.svg, R + 4, B - 8, '海', { size: 9, fill: C.faint, anchor: 'end' });

      /* 地形与水系 */
      if (step >= 2) {
        const ridges = [
          [88, 34], [92, 36], [96, 37], [100, 35], [104, 33], [97, 32], [101, 30]
        ];
        ridges.forEach(function (pt) {
          const x = px(pt[0]), y = py(pt[1]);
          path(W.svg, 'M' + f2(x - 7) + ' ' + f2(y + 4) + 'L' + f2(x) + ' ' + f2(y - 5) + 'L' + f2(x + 7) + ' ' + f2(y + 4), {
            stroke: C.data[2], width: .9
          });
        });
        txt(W.svg, px(88), py(35) - 14, '青藏高原', { size: 9, fill: C.soft, anchor: 'middle' });
        txt(W.svg, px(105.5), py(29.5), '四川盆地', { size: 8.5, fill: C.soft, anchor: 'middle' });
        txt(W.svg, px(116.5), py(37.5), '华北平原', { size: 8.5, fill: C.soft, anchor: 'middle' });
        /* 长江 */
        path(W.svg, 'M' + f2(px(91)) + ' ' + f2(py(33)) + 'C' + f2(px(100)) + ' ' + f2(py(31)) +
          ' ' + f2(px(108)) + ' ' + f2(py(30.5)) + ' ' + f2(px(115)) + ' ' + f2(py(30.5)) +
          'C' + f2(px(119)) + ' ' + f2(py(31)) + ' ' + f2(px(120.5)) + ' ' + f2(py(31.5)) + ' ' + f2(px(121.8)) + ' ' + f2(py(31.4)), {
          stroke: C.data[1], width: 1.2
        });
        txt(W.svg, px(112), py(29.2), '长江', { size: 8.5, fill: C.soft });
        /* 黄河 */
        path(W.svg, 'M' + f2(px(96)) + ' ' + f2(py(35)) + 'C' + f2(px(103)) + ' ' + f2(py(33.5)) +
          ' ' + f2(px(108)) + ' ' + f2(py(37)) + ' ' + f2(px(114)) + ' ' + f2(py(35.5)) +
          'C' + f2(px(117)) + ' ' + f2(py(35)) + ' ' + f2(px(118.5)) + ' ' + f2(py(36.5)) + ' ' + f2(px(119.2)) + ' ' + f2(py(37.6)), {
          stroke: C.data[2], width: 1
        });
        txt(W.svg, px(104), py(32.2), '黄河', { size: 8.5, fill: C.soft });
      }

      /* 城市点 */
      if (step >= 1) {
        pts.forEach(function (p, i) {
          const x = p.nx != null ? nx(p.nx) : px(p.lon);
          const y = p.ny != null ? ny(p.ny) : py(p.lat);
          const sel = i === S.sel;
          circ(W.svg, x, y, sel ? 4.4 : 3.2, {
            fill: sel ? C.accent : C.ink, stroke: C.card, width: sel ? 1.4 : .8
          });
          txt(W.svg, x + 7, y - 7, p.label, { size: 10, fill: sel ? C.accent : C.ink, weight: sel ? 700 : 500 });
        });
      }

      /* 风 / 洋流箭头 */
      if (step >= 3) {
        arrows.forEach(function (a) {
          const ax = nx(a.x1), ay = ny(a.y1), bx = nx(a.x2), by = ny(a.y2);
          const mx = (ax + bx) / 2 + 10, my = (ay + by) / 2 - 12;
          path(W.svg, 'M' + f2(ax) + ' ' + f2(ay) + 'Q' + f2(mx) + ' ' + f2(my) + ' ' + f2(bx) + ' ' + f2(by), {
            stroke: C.data[1], width: 1.2
          });
          arrowHead(W.svg, bx, by, Math.atan2(by - my, bx - mx), 6, C.data[1]);
          if (a.label) txt(W.svg, ax + 4, ay - 8, a.label, { size: 9, fill: C.soft });
        });
      }

      /* 图例 */
      const lgx = M, lgy = h - 12;
      line(W.svg, lgx, lgy, lgx + 14, lgy, { stroke: C.data[1] });
      txt(W.svg, lgx + 19, lgy, '轮廓', { size: 8.5, fill: C.faint });
      circ(W.svg, lgx + 62, lgy, 2.6, { fill: C.ink });
      txt(W.svg, lgx + 69, lgy, '城市', { size: 8.5, fill: C.faint });
      line(W.svg, lgx + 108, lgy, lgx + 122, lgy, { stroke: C.data[2] });
      txt(W.svg, lgx + 127, lgy, '水系', { size: 8.5, fill: C.faint });
      arrow(W.svg, lgx + 164, lgy, lgx + 184, lgy, { stroke: C.data[1], width: 1, size: 4 });
      txt(W.svg, lgx + 189, lgy, '气流', { size: 8.5, fill: C.faint });

      vN.textContent = String(pts.length);
      vA.textContent = String(arrows.length);
      detail.innerHTML = S.sel >= 0 && pts[S.sel]
        ? '<b>' + esc(pts[S.sel].label) + '</b><span>' + esc(pts[S.sel].note || (num(pts[S.sel].lat, 1) + '°N · ' + num(pts[S.sel].lon, 1) + '°E')) + '</span>'
        : '<b>—</b><span>点城市标记读取经纬度</span>';
    });
    W.svg.style.cursor = 'pointer';
    W.svg.addEventListener('click', function (e) {
      const r = W.svg.getBoundingClientRect();
      const px0 = e.clientX - r.left, py0 = e.clientY - r.top;
      const M = 26, T = 30, R = W.w - 22, B = W.h - 34;
      const iw = R - M, ih = B - T;
      let best = -1, bd = 1e9;
      pts.forEach(function (p, i) {
        const x = p.nx != null ? M + p.nx * iw : M + (p.lon - LON0) / (LON1 - LON0) * iw;
        const y = p.ny != null ? T + p.ny * ih : T + (LAT0 - p.lat) / (LAT0 - LAT1) * ih;
        const d = Math.hypot(px0 - x, py0 - y);
        if (d < bd) { bd = d; best = i; }
      });
      if (best >= 0 && bd < 18) { S.sel = best; W.redraw(); }
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 10. 英语长难句 ===================== */
  function defaultSyntax() {
    return [
      {
        role: '主语', text: 'The scientist', main: true, children: [
          {
            role: '定语从句', text: 'who discovered the vaccine', children: [
              { role: '主', text: 'who' }, { role: '谓', text: 'discovered' }, { role: '宾', text: 'the vaccine' }
            ]
          }
        ]
      },
      { role: '谓语', text: 'said', main: true },
      {
        role: '宾语从句', text: 'that the results were convincing', main: true, children: [
          { role: '引导', text: 'that' }, { role: '主', text: 'the results' },
          { role: '系动词', text: 'were' }, { role: '表语', text: 'convincing' }
        ]
      }
    ];
  }
  function guessSyntax(sentence) {
    const s = String(sentence || '').replace(/\s+/g, ' ').trim();
    if (!s) return defaultSyntax();
    const VERB = ['is', 'are', 'was', 'were', 'has', 'have', 'had', 'said', 'says', 'discovered', 'found',
      'shows', 'show', 'proves', 'prove', 'makes', 'make', 'becomes', 'become', 'believes', 'believe',
      'thinks', 'think', 'argues', 'argue', 'allows', 'allow', 'helps', 'help', 'causes', 'cause',
      'leads', 'lead', 'means', 'mean', 'keeps', 'keep', 'can', 'could', 'will', 'would'];
    const MARK = /^(that|which|who|whom|whose|because|although|when|if|while|where|as)\b/i;
    const words = s.replace(/[.,;:!?]$/, '').split(' ');
    const clauses = [];
    let cur = [];
    words.forEach(function (w, i) {
      if (i > 0 && MARK.test(w)) { clauses.push(cur); cur = [w]; }
      else cur.push(w);
    });
    if (cur.length) clauses.push(cur);
    function clauseNode(arr, k) {
      const words2 = arr.slice();
      let vi = -1;
      for (let i = 0; i < words2.length; i++) {
        if (VERB.indexOf(words2[i].toLowerCase()) >= 0) { vi = i; break; }
      }
      const marker = words2.length && MARK.test(words2[0]) ? words2[0] : '';
      const lead = marker ? 1 : 0;
      const subj = words2.slice(lead, vi > lead ? vi : lead + 1).join(' ');
      const verb = vi >= 0 ? words2[vi] : '';
      const obj = words2.slice(vi + 1).join(' ');
      const role = marker
        ? (/^(who|which|whose|whom)$/i.test(marker) ? '定语从句' : /^(that)$/i.test(marker) ? '从句' : '状语从句')
        : '分句 ' + (k + 1);
      const kids = [];
      if (subj) kids.push({ role: '主', text: subj });
      if (verb) kids.push({ role: '谓', text: verb });
      if (obj) kids.push({ role: '宾/表', text: obj });
      return { role: role, text: arr.join(' '), main: k === 0, children: kids };
    }
    return clauses.map(clauseNode);
  }
  function mountSyntax(host, q, api) {
    const W = new Widget(host, q, api, { scroll: true });
    const D = W.D, P = W.P;
    const sentence = D.sentence || P.sentence || 'The scientist who discovered the vaccine said that the results were convincing.';
    const tree = (D.tree && D.tree.length ? D.tree : (D.sentence ? guessSyntax(sentence) : defaultSyntax()));
    const S = { step: 0, closed: {}, open: {} };
    let uid = 0;
    (function mark(list, parent) {
      list.forEach(function (n) {
        n.id = 'n' + (++uid);
        n.parent = parent;
        n.children = n.children || [];
        if (n.children.length) mark(n.children, n.id);
      });
    })(tree, null);
    let total = 0, clauses = 0;
    (function count(list, depth) {
      list.forEach(function (n) {
        total++;
        if (/从句/.test(n.role)) clauses++;
        count(n.children, depth + 1);
      });
    })(tree, 0);
    modeHead(W.ctrl, '长难句结构树', '主干 / 从句分层 · 可收起');
    W.addSteps(['主干', '一层', '两层', '全开']);
    const sentBox = el('div', { class: 'sb-sent' }, sentence);
    W.ctrl.appendChild(sentBox);
    csec(W.ctrl, '读数');
    const vW = cstat(W.ctrl, '节点', String(total), '');
    const vC = cstat(W.ctrl, '从句', String(clauses), '');
    ckv(W.ctrl, '主干', '主 + 谓 + 宾');
    cnote(W.ctrl, '点带 +/− 的节点逐层展开或收起；主干用朱砂括号标出。');
    const legend = clegend(W.ctrl, [
      { label: '主干（主谓宾）', color: C.accent },
      { label: '从句与修饰', color: C.data[2] }
    ]);
    legend.style.marginTop = '12px';

    function canSeeChildren(n, depth) {
      if (S.closed[n.id]) return false;
      return depth + 1 <= S.step || !!S.open[n.id];
    }
    function rowsOf(limit) {
      const out = [];
      (function walk(list, depth, px, py) {
        list.forEach(function (n) {
          const row = { n: n, depth: depth, x: 0, y: 0, parentX: px, parentY: py };
          out.push(row);
          if (canSeeChildren(n, depth)) walk(n.children, depth + 1, 0, 0);
        });
      })(tree, 0, 0, 0);
      return out;
    }
    W.set(function (w, h) {
      const P = 18;
      const rowH = 24;
      const top = 62;
      const rows = rowsOf(W.step);
      const needH = top + rows.length * rowH + 20;
      const H = Math.max(h, needH);
      W.svg.setAttribute('height', H);
      W.svg.setAttribute('viewBox', '0 0 ' + W.w + ' ' + H);
      S.rows = rows;
      S.rowH = rowH; S.top = top; S.H = H;

      txt(W.svg, P, 22, '句子结构树', { size: 12, weight: 700, fill: C.ink, ls: .6 });
      const sl = wrapText(sentence, w - P * 2 - 10, 10.5).slice(0, 2);
      sl.forEach(function (ln, i) {
        txt(W.svg, P, 39 + i * 14, ln, { size: 10.5, fill: C.soft });
      });
      line(W.svg, P, top - 13, w - P, top - 13, { stroke: C.line2 });

      /* 主干括号 */
      const mainRows = rows.filter(r => r.n.main);
      if (mainRows.length) {
        const y0 = top + rows.indexOf(mainRows[0]) * rowH - 10;
        const y1 = top + rows.indexOf(mainRows[mainRows.length - 1]) * rowH + 10;
        line(W.svg, P - 6, y0, P - 6, y1, { stroke: C.accent, width: 2 });
        line(W.svg, P - 6, y0, P - 2, y0, { stroke: C.accent, width: 2 });
        line(W.svg, P - 6, y1, P - 2, y1, { stroke: C.accent, width: 2 });
        txt(W.svg, P + 2, y0 - 10, '主干', { size: 9, fill: C.accent, ls: 1 });
      }

      /* 连线 */
      rows.forEach(function (r, i) {
        const x = 24 + r.depth * 26;
        const y = top + i * rowH + 8;
        r.x = x; r.y = y;
        if (r.depth > 0) {
          const pRow = rows.find(o => o.n.id === r.n.parent);
          if (pRow) {
            const py = pRow.y;
            line(W.svg, pRow.x + 9, py + 9, pRow.x + 9, y, { stroke: C.line, width: 1 });
            line(W.svg, pRow.x + 9, y, x - 5, y, { stroke: C.line, width: 1 });
          }
        }
        const hasKids = r.n.children.length > 0;
        if (hasKids) {
          const open = canSeeChildren(r.n, r.depth);
          rect(W.svg, x - 15, y - 5, 10, 10, { rx: 1, fill: C.card, stroke: C.line, width: .9 });
          txt(W.svg, x - 10, y, open ? '−' : '+', { size: 9, anchor: 'middle', fill: C.soft });
        }
        const isMain = !!r.n.main;
        const roleColor = isMain ? C.ink : C.data[2];
        txt(W.svg, x, y, '[' + r.n.role + ']', { size: 9.5, fill: C.faint });
        const roleW = tw('[' + r.n.role + ']', 9.5) + 5;
        txt(W.svg, x + roleW, y, r.n.text, {
          size: 11.5, fill: isMain ? C.ink : C.ink2, weight: isMain ? 600 : 400
        });
        if (S.closed[r.n.id] && r.n.children.length) {
          txt(W.svg, x + roleW + tw(r.n.text, 11.5) + 6, y, '… ' + r.n.children.length, { size: 9, fill: C.faint });
        }
      });

      vW.textContent = String(total);
      vC.textContent = String(clauses);
    });
    W.svg.style.cursor = 'default';
    W.svg.addEventListener('click', function (e) {
      const r = W.svg.getBoundingClientRect();
      const py = e.clientY - r.top;
      const rows = S.rows || [];
      for (let i = 0; i < rows.length; i++) {
        const y = S.top + i * S.rowH + 8;
        if (Math.abs(py - y) <= 11) {
          const n = rows[i].n;
          if (!n.children.length) return;
          if (canSeeChildren(n, rows[i].depth)) {
            S.closed[n.id] = true;
            delete S.open[n.id];
          } else {
            delete S.closed[n.id];
            S.open[n.id] = true;
          }
          W.redraw();
          return;
        }
      }
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 11. 古诗结构 ===================== */
  function mountPoem(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const DEF = {
      title: '春望', author: '杜甫',
      lines: ['国破山河在', '城春草木深', '感时花溅泪', '恨别鸟惊心', '烽火连三月', '家书抵万金', '白头搔更短', '浑欲不胜簪'],
      emotion: [.82, .70, .48, .40, .28, .22, .46, .58],
      sections: [{ name: '起', a: 0, b: 1 }, { name: '承', a: 2, b: 3 }, { name: '转', a: 4, b: 5 }, { name: '合', a: 6, b: 7 }],
      images: [
        { word: '山河', line: 0 }, { word: '草木', line: 1 }, { word: '花', line: 2 }, { word: '鸟', line: 3 },
        { word: '烽火', line: 4 }, { word: '家书', line: 5 }, { word: '白头', line: 6 }
      ]
    };
    const PM = (D.poem && typeof D.poem === 'object') ? D.poem : {};
    let lines = PM.lines || D.lines || DEF.lines;
    if (typeof lines === 'string') lines = lines.split(/\n|\/|，|。/).filter(Boolean);
    if (lines.length > 10) lines = lines.slice(0, 10);
    const title = PM.title || D.title || DEF.title;
    const author = PM.author || D.author || DEF.author;
    const emotion = (PM.emotion || DEF.emotion).slice(0, lines.length);
    const sections = PM.sections || DEF.sections;
    const images = (PM.images || D.images || DEF.images).filter(im => im.line >= 0 && im.line < lines.length);
    const S = { step: 0, sel: images.length ? 0 : -1 };
    modeHead(W.ctrl, '诗歌结构', '起承转合 · 意象 · 情感曲线');
    W.addSteps(['起', '承', '转', '合']);
    csec(W.ctrl, '作品');
    ckv(W.ctrl, '题目', title);
    ckv(W.ctrl, '作者', author);
    ckv(W.ctrl, '句数', lines.length + ' 句');
    csec(W.ctrl, '意象');
    const imgBox = el('div', { class: 'sb-orglist' });
    W.ctrl.appendChild(imgBox);
    const detail = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(detail);
    cnote(W.ctrl, '点意象查看对应诗句；四段用同样的浅色带标在情感曲线下。');

    function renderImgList() {
      imgBox.innerHTML = '';
      images.forEach(function (im, i) {
        const row = el('div', { class: 'sb-org' + (i === S.sel ? ' is-on' : '') });
        row.textContent = im.word + '　“' + (lines[im.line] || '').slice(0, 8) + '”';
        row.addEventListener('click', function () { S.sel = S.sel === i ? -1 : i; renderImgList(); W.redraw(); });
        imgBox.appendChild(row);
      });
    }
    renderImgList();

    W.set(function (w, h) {
      const P = 20;
      const step = W.step;
      const sec = sections[Math.min(step, sections.length - 1)] || sections[0];
      const secIdx = Math.min(step, sections.length - 1);

      /* 标题 */
      txt(W.svg, P, 26, title, { size: 17, weight: 700, fill: C.ink, serif: true, ls: 2 });
      txt(W.svg, P + tw(title, 17) + 14, 27, author, { size: 10, fill: C.soft, serif: true });
      txt(W.svg, w - P, 26, '起 · 承 · 转 · 合', { size: 9.5, anchor: 'end', fill: C.faint, ls: 1.5 });
      line(W.svg, P, 40, w - P, 40, { stroke: C.line2 });

      /* 诗句：两列四行 */
      const colX = [P + 34, w * .52 + 12];
      const rowH = 30, startY = 66;
      const lineW = Math.max(90, w * .38);
      lines.forEach(function (ln, i) {
        const col = i < 4 ? 0 : 1;
        const row = i % 4;
        const x = colX[col], y = startY + row * rowH;
        const inSec = i >= sec.a && i <= sec.b;
        const lit = S.sel >= 0 && images[S.sel] && images[S.sel].line === i;
        if (inSec) {
          rect(W.svg, x - 6, y - 14, Math.min(lineW, tw(ln, 14) + 12), 26, {
            fill: C.data[4], opacity: .6, rx: 2
          });
        }
        txt(W.svg, x, y, ln, {
          size: 14, serif: true, fill: lit ? C.accent : inSec ? C.ink : C.ink2,
          weight: lit ? 700 : 400, ls: 1.2
        });
        if (lit) {
          line(W.svg, x, y + 12, x + tw(ln, 14), y + 12, { stroke: C.accent, width: 1.2 });
        }
      });
      /* 四段标 */
      sections.forEach(function (s2, k) {
        const col = s2.a < 4 ? 0 : 1;
        const rowA = s2.a % 4;
        const x = colX[col] - 24;
        const y0 = startY + rowA * rowH - 12;
        const y1 = y0 + ((s2.b - s2.a) * rowH) + 12;
        line(W.svg, x, y0, x, y1, {
          stroke: k === secIdx ? C.accent : C.line, width: k === secIdx ? 2 : 1
        });
        txt(W.svg, x - 6, (y0 + y1) / 2, s2.name, {
          size: 11, anchor: 'middle', serif: true,
          fill: k === secIdx ? C.accent : C.faint, weight: k === secIdx ? 700 : 400
        });
      });

      /* 情感曲线 */
      const cy0 = h * .60, cy1 = h - 46;
      const cx0 = P + 6, cx1 = w - P;
      const n = lines.length;
      const ex = i => cx0 + (n === 1 ? .5 : (i + .5) / n) * (cx1 - cx0);
      const ey = v => cy1 - (v || 0) * (cy1 - cy0);
      txt(W.svg, P, cy0 - 12, '情感走向', { size: 9.5, fill: C.faint, ls: 1 });
      sections.forEach(function (s2, k) {
        const a = ex(s2.a) - (n === 1 ? 0 : (cx1 - cx0) / n / 2);
        const b = ex(s2.b) + (n === 1 ? 0 : (cx1 - cx0) / n / 2);
        rect(W.svg, a, cy0, Math.max(0, b - a), cy1 - cy0, {
          fill: C.data[1], opacity: k === secIdx ? .08 : .03
        });
        line(W.svg, a, cy0, a, cy1, { stroke: C.line2 });
        txt(W.svg, (a + b) / 2, cy1 + 14, s2.name, { size: 9.5, anchor: 'middle', fill: C.faint });
      });
      line(W.svg, cx0, cy1, cx1, cy1, { stroke: C.line });
      let d = '';
      for (let i = 0; i < n; i++) d += (i ? 'L' : 'M') + f2(ex(i)) + ' ' + f2(ey(emotion[i] == null ? .4 : emotion[i]));
      path(W.svg, d, { stroke: C.data[1], width: 1.8 });
      for (let i = 0; i < n; i++) {
        const lit = S.sel >= 0 && images[S.sel] && images[S.sel].line === i;
        circ(W.svg, ex(i), ey(emotion[i] == null ? .4 : emotion[i]), lit ? 4.6 : 2.8, {
          fill: lit ? C.accent : C.ink2, stroke: C.card, width: 1
        });
      }

      /* 意象节点 */
      images.forEach(function (im, i) {
        const x = ex(im.line), y = ey(emotion[im.line] == null ? .4 : emotion[im.line]);
        const up = i % 2 === 0;
        const ly = up ? y - 17 : y + 19;
        const lit = i === S.sel;
        line(W.svg, x, y + (up ? -5 : 5), x, ly + (up ? 7 : -7), { stroke: lit ? C.accent : C.data[2], width: .8, opacity: .7 });
        rect(W.svg, x - tw(im.word, 10) / 2 - 5, ly - 8, tw(im.word, 10) + 10, 16, {
          rx: 2, fill: lit ? C.accent : C.card, stroke: lit ? C.accent : C.line
        });
        txt(W.svg, x, ly, im.word, {
          size: 10, anchor: 'middle', fill: lit ? C.card : C.ink
        });
      });

      /* 读数 */
      if (S.sel >= 0 && images[S.sel]) {
        const im = images[S.sel];
        detail.innerHTML = '<b>“' + esc(im.word) + '”</b><span>对应第 ' + (im.line + 1) + ' 句：' +
          esc(lines[im.line]) + '。情感值 ' + num(emotion[im.line] || 0, 2) + '（越低越沉郁）。</span>';
      } else {
        detail.innerHTML = '<b>—</b><span>点意象节点，右侧与诗句同步高亮</span>';
      }
    });

    W.svg.style.cursor = 'pointer';
    W.svg.addEventListener('click', function (e) {
      const r = W.svg.getBoundingClientRect();
      const px = e.clientX - r.left, py = e.clientY - r.top;
      const w = W.w, h = W.h, P = 20;
      const cx0 = P + 6, cx1 = w - P, n = lines.length;
      const cy0 = h * .60, cy1 = h - 46;
      const ex = i => cx0 + (n === 1 ? .5 : (i + .5) / n) * (cx1 - cx0);
      const ey = v => cy1 - (v || 0) * (cy1 - cy0);
      for (let i = 0; i < images.length; i++) {
        const im = images[i];
        const x = ex(im.line), y = ey(emotion[im.line] == null ? .4 : emotion[im.line]);
        const ly = i % 2 === 0 ? y - 17 : y + 19;
        if (Math.abs(px - x) < 26 && Math.abs(py - ly) < 11) {
          S.sel = i; renderImgList(); W.redraw(); return;
        }
      }
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 12. 议论文结构 ===================== */
  function mountComposition(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const DEF = {
      thesis: '数字时代的阅读，需要“深读”而非“刷读”',
      points: [
        { text: '深读重建注意力的连续性', evidences: ['持续阅读训练工作记忆的实验', '纸质书与屏幕阅读的对照'] },
        { text: '深读保留怀疑与对话的空间', evidences: ['慢读批注的经典案例', '课堂共读的讨论记录'] },
        { text: '深读沉淀可迁移的知识结构', evidences: ['主题阅读的笔记网络', '跨文本比较的写作'] }
      ]
    };
    const src = D.outline || D.composition || DEF;
    const thesis = src.thesis || src.argument || DEF.thesis;
    const points = (src.points || src.branches || DEF.points).slice(0, 3);
    const nodes = {};
    const order1 = [], evOrder = {};
    nodes.t = { id: 't', level: 0, role: '中心论点', text: thesis, parent: null };
    points.forEach(function (p, i) {
      const id = 'p' + i;
      const text = typeof p === 'string' ? p : (p.text || p.title || '分论点');
      const evs = (typeof p === 'string' ? [] : (p.evidences || p.evidence || [])) || [];
      nodes[id] = { id: id, level: 1, role: '分论点 ' + (i + 1), text: text, parent: 't' };
      order1.push(id);
      evOrder[id] = [];
      evs.slice(0, 2).forEach(function (e, k) {
        const eid = id + '_' + k;
        nodes[eid] = { id: eid, level: 2, role: '论据', text: typeof e === 'string' ? e : (e.text || ''), parent: id };
        evOrder[id].push(eid);
      });
    });
    const S = { step: 0, sel: 't', pos: {}, order1: order1, evOrder: evOrder, drag: null };
    modeHead(W.ctrl, '议论文结构', '论点 — 分论点 — 论据 · 可拖动重排');
    W.addSteps(['论点', '分论点', '论据', '论证链']);
    csec(W.ctrl, '结构读数');
    const vN = cstat(W.ctrl, '分论点', String(order1.length), '');
    const vE = cstat(W.ctrl, '论据', String(Object.keys(nodes).filter(k => nodes[k].level === 2).length), '');
    const detail = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(detail);
    cnote(W.ctrl, '拖动分论点或论据改变顺序，松手后自动重排并重连。');
    const resetBtn = el('button', { class: 'jw-btn' }, '恢复原顺序');
    resetBtn.style.marginTop = '8px';
    resetBtn.addEventListener('click', function () {
      S.order1 = order1.slice();
      Object.keys(evOrder).forEach(k => { S.evOrder[k] = evOrder[k].slice(); });
      W.redraw();
    });
    W.ctrl.appendChild(resetBtn);

    /* 节点层 */
    W.svg.style.position = 'absolute';
    W.svg.style.left = '0'; W.svg.style.top = '0';
    W.svg.style.pointerEvents = 'none';
    const layer = el('div', { class: 'sb-nodes' });
    W.draw.appendChild(layer);

    function textLines(text, width, size, maxLines) {
      return wrapText(text, width - 14, size).slice(0, maxLines || 3);
    }
    function layout(w, h) {
      const pad = 16, gap = 12;
      const pos = {};
      const rootW = Math.min(w * .58, 470);
      const headLines = wrapText(nodes.t.text, rootW - 18, 12).length;
      const rootH = clamp(22 + headLines * 17, 44, 92);
      pos.t = { x: (w - rootW) / 2, y: 22, w: rootW, h: rootH };
      const bw = (w - pad * 2 - gap * (order1.length - 1)) / order1.length;
      const bh = 74, by = Math.max(pos.t.y + rootH + 26, h * .31);
      S.order1.forEach(function (id, i) {
        pos[id] = { x: pad + i * (bw + gap), y: by, w: bw, h: bh };
      });
      const eh = 84, ey = Math.max(by + bh + 46, h * .63);
      const maxE = Math.max(1, ...Object.keys(S.evOrder).map(k => S.evOrder[k].length));
      S.order1.forEach(function (pid, i) {
        const kids = S.evOrder[pid] || [];
        const cw = (bw - (kids.length > 1 ? 8 : 0)) / Math.max(1, kids.length);
        kids.forEach(function (id, k) {
          pos[id] = { x: pad + i * (bw + gap) + k * (cw + 8), y: ey, w: cw, h: eh };
        });
      });
      // 内容整体垂直居中，别让下半屏空着
      let maxY = 0;
      Object.keys(pos).forEach(function (k) { maxY = Math.max(maxY, pos[k].y + pos[k].h); });
      const shift = (h - maxY - 20) / 2;
      if (shift > 0) {
        Object.keys(pos).forEach(function (k) { pos[k].y += shift; });
      }
      S.pos = pos;
      return pos;
    }
    function drawLinks(pos, w, h) {
      const step = W.step;
      function link(a, b, k) {
        const pa = pos[a], pb = pos[b];
        if (!pa || !pb) return;
        const x1 = pa.x + pa.w / 2, y1 = pa.y + pa.h;
        const x2 = pb.x + pb.w / 2, y2 = pb.y;
        const my = (y1 + y2) / 2;
        path(W.svg, 'M' + f2(x1) + ' ' + f2(y1) + 'C' + f2(x1) + ' ' + f2(my) +
          ' ' + f2(x2) + ' ' + f2(my) + ' ' + f2(x2) + ' ' + f2(y2), {
          stroke: k === 3 ? C.ink2 : C.line,
          width: k === 3 ? 1.4 : 1,
          dash: k >= 3 ? null : '2 3',
          opacity: k === 3 ? .85 : .9
        });
        arrowHead(W.svg, x2, y2 - 1, Math.PI / 2, 4.5, k === 3 ? C.ink2 : C.data[2], k === 3 ? .85 : .5);
      }
      S.order1.forEach(function (id) { link('t', id, step); });
      if (step >= 2) {
        S.order1.forEach(function (pid) {
          (S.evOrder[pid] || []).forEach(function (eid) { link(pid, eid, step); });
        });
      }
    }
    function buildNodes(pos, w, h) {
      layer.innerHTML = '';
      Object.keys(nodes).forEach(function (id) {
        const n = nodes[id], p = pos[id];
        if (!p) return;
        const div = el('div', {
          class: 'sb-node' + (S.sel === id ? ' is-sel' : '') +
            (W.step >= n.level ? '' : ' is-dim')
        });
        div.style.left = p.x + 'px'; div.style.top = p.y + 'px';
        div.style.width = p.w + 'px'; div.style.height = p.h + 'px';
        const b = el('b', {}, n.role);
        div.appendChild(b);
        const size = n.level === 0 ? 12 : n.level === 1 ? 11 : 10;
        const lines = textLines(n.text, p.w, size, n.level === 2 ? 4 : 3);
        lines.forEach(function (ln) {
          div.appendChild(el('div', {
            style: 'font-size:' + size + 'px;line-height:1.4;overflow:hidden'
          }, ln));
        });
        layer.appendChild(div);
        n.el = div;
        if (n.level === 0) {
          div.style.cursor = 'pointer';
          div.addEventListener('click', function () { S.sel = id; updateDetail(); W.redraw(); });
          return;
        }
        JW.drag(div, {
          down: function () { S.drag = { id: id, moved: false }; },
          move: function (pt, d) {
            if (!S.drag) return;
            S.drag.moved = S.drag.moved || Math.abs(d.x) + Math.abs(d.y) > 2;
            const band = n.level === 1 ? [Math.max(100, h * .30), Math.max(120, h * .44)]
              : [Math.max(180, h * .60), h - 60];
            const x = clamp(parseFloat(div.style.left) + d.x, 4, w - p.w - 4);
            const y = clamp(parseFloat(div.style.top) + d.y, band[0], band[1]);
            div.style.left = x + 'px'; div.style.top = y + 'px';
            S.pos[id].x = x; S.pos[id].y = y;
            S.pos[id].w = p.w; S.pos[id].h = p.h;
            while (W.svg.firstChild) W.svg.removeChild(W.svg.firstChild);
            drawLinks(S.pos, w, h);
          },
          up: function () {
            if (!S.drag) return;
            const moved = S.drag.moved;
            S.drag = null;
            if (!moved) { S.sel = id; updateDetail(); W.redraw(); return; }
            if (n.level === 1) {
              S.order1.sort(function (a, b) { return S.pos[a].x - S.pos[b].x; });
            } else if (n.level === 2) {
              const arr = S.evOrder[n.parent];
              arr.sort(function (a, b) { return S.pos[a].x - S.pos[b].x; });
            }
            W.redraw();
          }
        });
      });
    }
    function updateDetail() {
      const n = nodes[S.sel];
      if (!n) { detail.innerHTML = '<b>—</b><span>点节点查看内容</span>'; return; }
      const kids = n.level === 0 ? S.order1.length : n.level === 1 ? (S.evOrder[n.id] || []).length : 0;
      detail.innerHTML = '<b>' + esc(n.role) + '</b><span>' + esc(n.text) +
        (kids ? '（下辖 ' + kids + ' 项）' : '') + '</span>';
    }
    W.set(function (w, h) {
      const pos = layout(w, h);
      drawLinks(pos, w, h);
      buildNodes(pos, w, h);
      updateDetail();
      vN.textContent = String(S.order1.length);
      vE.textContent = String(Object.keys(nodes).filter(k => nodes[k].level === 2).length);
    });
    W.applyStep(0);
    return W;
  }

  /* ===================== 13. 通用流程 / 因果链 ===================== */
  function mountFlow(host, q, api, meta) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    const src = (q && q.view) || {};
    let title = D.title || src.title || (q && q.title) || '通用解释';
    const teach = (q && q.steps) || null;
    let lines = (teach && teach.length >= 2) ? teach : (D.lines || D.chain || D.nodes || null);
    if (!lines || !lines.length) lines = ['识别条件', '建立模型', '推导求解', '检验结论'];
    if (typeof lines === 'string') lines = lines.split(/→|->|\n|；|;/).filter(Boolean);
    const extra = (D.lines && D.lines.length) ? D.lines : [];
    const steps = lines.slice(0, 8).map(function (n, i) {
      if (n && typeof n === 'object') {
        return { label: n.label || n.title || n.text || '', desc: n.desc || n.note || '' };
      }
      return { label: String(n), desc: extra[i] && String(extra[i]) !== String(n) ? String(extra[i]) : '' };
    });
    const S = { step: 0 };
    modeHead(W.ctrl, meta && meta.unknown ? '通用解释卡' : '讲解顺序',
      meta && meta.unknown ? '未识别的 mode：' + (meta.mode || '') : '逐节点推进');
    W.addSteps(steps.slice(0, 4).map((s, i) => '步骤' + (i + 1)));
    const form = el('div', { class: 'sb-detail' });
    form.innerHTML = '<b>' + esc(title) + '</b><span>' + steps.length + ' 个节点</span>';
    W.ctrl.appendChild(form);
    csec(W.ctrl, '节点');
    const vI = cstat(W.ctrl, '当前', '1 / ' + steps.length, '');
    const listBox = el('div', { class: 'sb-orglist' });
    W.ctrl.appendChild(listBox);
    steps.forEach(function (s, i) {
      const row = el('div', { class: 'sb-org' }, (i + 1) + '　' + s.label);
      row.addEventListener('click', function () {
        if (window.JWApp && JWApp.setStep) { JWApp.setStep(i); }
        else { S.step = i; W.redraw(); }
      });
      listBox.appendChild(row);
      s.row = row;
    });
    const descBox = el('div', { class: 'sb-detail' });
    W.ctrl.appendChild(descBox);
    cnote(W.ctrl, (meta && meta.unknown)
      ? '这个题型还没有专属视图，先用讲解顺序顶上；点行看细节。'
      : '点一行或按“解题路径”，画面上的聚光会跟过去。');

    let rowsY = [];

    W.set(function (w, h) {
      const step = W.step;
      const P = 26;
      const top = 74;
      const n = steps.length;
      const gap = Math.max(42, Math.min(78, (h - top - 26) / Math.max(1, n)));
      rowsY = [];

      txt(W.svg, P, 30, title, { size: 14, weight: 700, fill: C.ink, ls: .4 });
      txt(W.svg, w - P, 30, n + ' 步 · 按顺序读', { size: 9.5, anchor: 'end', fill: C.faint });

      steps.forEach(function (s, i) {
        const y = top + i * gap;
        rowsY.push(y);
        const lit = i <= step;
        const active = i === step;

        if (active) {
          rect(W.svg, P - 12, y - 16, w - P * 2 + 24, 34, { rx: 8, fill: C.accent, opacity: .07 });
          rect(W.svg, P - 12, y - 10, 3, 18, { rx: 1.5, fill: C.accent });
        }

        circ(W.svg, P + 2, y, 9.5, {
          fill: lit ? (active ? C.accent : C.ink2) : 'none',
          stroke: lit ? (active ? C.accent : C.ink2) : C.line, width: 1.2
        });
        txt(W.svg, P + 2, y, String(i + 1), {
          size: 9.5, anchor: 'middle', weight: 600,
          fill: lit ? C.card : C.faint
        });

        const size = active ? 14 : 12.5;
        const cx = P + 26;
        const lines = wrapText(s.label, w - cx - P - 10, size).slice(0, active ? 3 : 2);
        lines.forEach(function (ln, k) {
          txt(W.svg, cx, y + (k - (lines.length - 1) / 2) * (size + 5), ln, {
            size: size,
            weight: active ? 700 : 500,
            fill: lit ? (active ? C.ink : C.ink2) : C.faint
          });
        });

        if (i < n - 1) {
          line(W.svg, cx, y + gap - 14, w - P, y + gap - 14, {
            stroke: C.line, width: 1, opacity: lit ? .5 : .25
          });
        }
      });

      steps.forEach(function (s, i) { s.row.classList.toggle('is-on', i === step); });
      vI.textContent = (step + 1) + ' / ' + n;
      const cur = steps[step] || steps[0];
      descBox.innerHTML = '<b>第 ' + (step + 1) + ' 步</b><span>' + esc(cur.desc || cur.label) + '</span>';
    });

    // 引导层聚光：定位到当前行
    W.focus = function (i) {
      const y = rowsY[Math.max(0, Math.min(rowsY.length - 1, i))];
      if (y == null) return null;
      return { x: 44, y: y, r: 20, label: '第 ' + (i + 1) + ' 步', labelSide: 'above' };
    };

    W.applyStep(0);
    return W;
  }

  /* ===================== 14. 通用数据图 ===================== */
  function mountData(host, q, api) {
    const W = new Widget(host, q, api);
    const D = W.D, P = W.P;
    let series = [], kind = 'line';
    if (D.rows && D.rows.length) {
      kind = 'bar';
      series = [{ name: D.title || '数值', rows: D.rows.map(r => ({ label: r.label || r.name || '', value: +(r.value != null ? r.value : r.v) || 0 })) }];
    } else if (D.series && D.series.length) {
      series = D.series.map(function (s, i) {
        return {
          name: s.name || s.label || ('序列 ' + (i + 1)),
          values: (s.values || s.data || []).map(Number).filter(v => isFinite(v)),
          labels: s.labels || null
        };
      });
      kind = series[0].values && series[0].values.length ? 'line' : 'bar';
    } else if (D.curve && D.curve.length) {
      series = [{ name: '曲线', points: D.curve.map(function (pt) {
        return Array.isArray(pt) ? { x: +pt[0], y: +pt[1] } : { x: +pt.x, y: +pt.y };
      }) }];
      kind = 'xy';
    } else {
      series = [{ name: '样本得分', rows: [
        { label: '阅读', value: 82 }, { label: '计算', value: 74 }, { label: '写作', value: 88 },
        { label: '实验', value: 66 }, { label: '表达', value: 79 }
      ] }];
      kind = 'bar';
    }
    const S = { step: 0 };
    modeHead(W.ctrl, '数据图', '自动刻度 · 逐序列读数');
    W.addSteps(['坐标', '数据', '读数', '对比']);
    csec(W.ctrl, '读数');
    const vMax = cstat(W.ctrl, '最大', '—', '');
    const vMin = cstat(W.ctrl, '最小', '—', '');
    const vAvg = cstat(W.ctrl, '均值', '—', '');
    const legendBox = el('div', { class: 'sb-legend' });
    W.ctrl.appendChild(legendBox);
    cnote(W.ctrl, '点右侧序列名或按步骤切换，图中其余序列退为淡色。');

    W.set(function (w, h) {
      const L = 46, R = 22, T = 32, B = 48;
      const iw = w - L - R, ih = h - T - B;
      const step = W.step;
      const rows = kind === 'bar' ? series[0].rows : null;
      const vals = [];
      if (rows) rows.forEach(r => vals.push(r.value));
      else series.forEach(s => (s.values || []).forEach(v => vals.push(v)));
      let vmax = Math.max(1, ...vals), vmin = Math.min(0, ...vals);
      if (vmin > 0) vmin = 0;
      const padY = (vmax - vmin) * .12 || 1;
      vmax += padY;
      if (kind !== 'bar') vmin -= padY;
      const y = v => T + (1 - (v - vmin) / (vmax - vmin)) * ih;

      for (let k = 0; k <= 4; k++) {
        const v = vmin + (vmax - vmin) * k / 4;
        line(W.svg, L, y(v), w - R, y(v), { stroke: C.grid2 });
        txt(W.svg, L - 8, y(v), num(v, v >= 10 ? 0 : 1), { size: 9.5, anchor: 'end', fill: C.faint });
      }
      line(W.svg, L, T + ih, w - R, T + ih, { stroke: C.faint });
      line(W.svg, L, T, L, T + ih, { stroke: C.faint });
      txt(W.svg, L - 8, T - 12, '数值', { size: 9.5, anchor: 'end', fill: C.soft });

      if (kind === 'bar') {
        const n = rows.length;
        const bw = Math.min(48, (iw / n) * .52);
        rows.forEach(function (r, i) {
          const cx = L + (i + .5) * iw / n;
          const sel = i === step % Math.max(1, n);
          rect(W.svg, cx - bw / 2, y(r.value), bw, y(vmin) - y(r.value), {
            fill: sel ? C.accent : C.data[2], opacity: sel ? 1 : .78
          });
          txt(W.svg, cx, y(r.value) - 7, num(r.value, 0), {
            size: 9.5, anchor: 'middle', fill: sel ? C.accent : C.soft, weight: sel ? 700 : 400
          });
          const lab = wrapText(r.label, iw / n - 6, 10)[0] || '';
          txt(W.svg, cx, T + ih + 16, lab, { size: 10, anchor: 'middle', fill: C.soft });
        });
        const r0 = rows[step % Math.max(1, rows.length)];
        vMax.textContent = num(Math.max(...vals), 1);
        vMin.textContent = num(Math.min(...vals), 1);
        vAvg.textContent = num(vals.reduce((a, b) => a + b, 0) / vals.length, 1);
        legendBox.innerHTML = '<div><i style="background:' + C.accent + '"></i><span>' + esc(r0.label || '') + ' · ' + r0.value + '</span></div>';
        stepBlurb(rows[step % rows.length] && rows[step % rows.length].label);
      } else if (kind === 'xy') {
        const pts = series[0].points;
        const xmax = Math.max(...pts.map(p => p.x)), xmin = Math.min(...pts.map(p => p.x));
        const X = v => L + (xmax === xmin ? .5 : (v - xmin) / (xmax - xmin)) * iw;
        pts.forEach(p => { if (p.y > vmax || p.y < vmin) { vmax = Math.max(vmax, p.y); } });
        let d = '';
        pts.forEach(function (p, i) { d += (i ? 'L' : 'M') + f2(X(p.x)) + ' ' + f2(y(p.y)); });
        path(W.svg, d, { stroke: C.ink2, width: 1.8 });
        pts.forEach(function (p, i) {
          const sel = i === step % Math.max(1, pts.length);
          circ(W.svg, X(p.x), y(p.y), sel ? 4 : 2.4, { fill: sel ? C.accent : C.ink2 });
        });
        const sel = pts[step % pts.length] || pts[0];
        vMax.textContent = num(Math.max(...pts.map(p => p.y)), 1);
        vMin.textContent = num(Math.min(...pts.map(p => p.y)), 1);
        vAvg.textContent = num(pts.reduce((a, p) => a + p.y, 0) / pts.length, 1);
        legendBox.innerHTML = '<div><i style="background:' + C.accent + '"></i><span>选中点 (' + num(sel.x, 2) + ', ' + num(sel.y, 2) + ')</span></div>';
        stepBlurb('x = ' + num(sel.x, 2));
      } else {
        const nMax = Math.max(...series.map(s => s.values.length));
        const X = (i, n) => L + (n <= 1 ? .5 : i / (n - 1)) * iw;
        const shades = [C.ink, C.data[1], C.data[2], C.data[3]];
        series.forEach(function (s, si) {
          const active = (step % series.length) === si;
          let d = '';
          s.values.forEach(function (v, i) { d += (i ? 'L' : 'M') + f2(X(i, s.values.length)) + ' ' + f2(y(v)); });
          path(W.svg, d, {
            stroke: active ? C.ink : shades[si % 4], width: active ? 2 : 1.2,
            opacity: active ? 1 : .35
          });
          s.values.forEach(function (v, i) {
            if (active) circ(W.svg, X(i, s.values.length), y(v), 2.6, { fill: C.ink });
          });
        });
        const cur = series[step % series.length];
        const av = cur.values;
        vMax.textContent = num(Math.max(...av), 1);
        vMin.textContent = num(Math.min(...av), 1);
        vAvg.textContent = num(av.reduce((a, b) => a + b, 0) / av.length, 1);
        legendBox.innerHTML = '';
        series.forEach(function (s, si) {
          const c = (step % series.length) === si ? C.accent : shades[si % 4];
          const row = el('div');
          const sw = el('i'); sw.style.background = c;
          row.appendChild(sw);
          row.appendChild(el('span', {}, s.name + '（' + s.values.length + ' 点）'));
          legendBox.appendChild(row);
        });
        stepBlurb(cur.name);
      }
      function stepBlurb(label) {
        txt(W.svg, w - R, h - 10, '当前：' + (label || '—'), { size: 9.5, anchor: 'end', fill: C.faint });
      }
      txt(W.svg, 16, 22, D.title || '数据概览', { size: 12, weight: 700, fill: C.ink, ls: .5 });
    });
    W.applyStep(0);
    return W;
  }

  /* ---------------- 注册 ---------------- */
  const MOUNTS = {
    reaction: mountReaction, titration: mountTitration, equilibrium: mountEquilibrium,
    electrochem: mountElectrochem, genetics: mountGenetics, cell: mountCell,
    ecology: mountEcology, timeline: mountTimeline, map: mountMap,
    syntax: mountSyntax, poem: mountPoem, composition: mountComposition,
    flow: mountFlow, data: mountData
  };
  JW.registerView('subjects', function (host, q, api) {
    q = q || {};
    const view = q.view || {};
    const mode = String(view.mode || '').toLowerCase();
    const fn = MOUNTS[mode];
    let W = null;
    try {
      W = fn(host, q, api, { mode: mode, unknown: !fn });
    } catch (e) {
      console.warn('[subjects] mode ' + mode + ' failed', e);
      try { host.innerHTML = ''; W = mountFlow(host, q, api, { mode: mode, unknown: true, error: e }); } catch (e2) { W = null; }
    }
    return {
      applyStep: function (i) {
        if (W && W.applyStep) { try { W.applyStep(i); } catch (e) { console.warn('[subjects] step', e); } }
      },
      focus: function (i) {
        try { return (W && typeof W.focus === 'function') ? W.focus(i) : null; } catch (e) { return null; }
      },
      destroy: function () {
        if (W && W.destroy) { try { W.destroy(); } catch (e) { } }
      }
    };
  });
})();
