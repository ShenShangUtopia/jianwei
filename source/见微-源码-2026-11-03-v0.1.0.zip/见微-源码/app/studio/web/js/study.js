/* 见微 · 析题台 · 学习助手
   三件事：知识卡抽屉 / 错题本 / 提示阶梯。
   只依赖 window.JW 与 window.JWApp 的公开接口，DOM 全部自己创建，
   不改动 app.js、index.html、studio.css 等任何既有文件。 */
(function () {
  'use strict';
  if (window.__JW_STUDY__) return;
  window.__JW_STUDY__ = true;

  var VERSION = '2026.10';
  var STAR_KEY = 'jw.stars';

  /* ==================================================================
     一 · 知识卡内容（高频考点；d=一句话定义 f=公式/结论 p=两个常见坑）
     ================================================================== */
  var CARDS = [

    /* ---------------- 数学 ---------------- */
    { n: '函数单调性', s: '数学',
      k: ['单调', '单调性', '单调区间', '增函数', '减函数', '复合函数单调性', '指数函数单调性'],
      d: '区间内 x 增大时 y 同向变化；先定定义域，再用定义、导数或复合规律判断。',
      f: ["f'(x)>0 ⇒ f(x) 在此区间递增", 'y=f(g(x))：内外层同增或同减，整体递增'],
      p: ['把两个相邻单调区间用 ∪ 并成一个区间——错，必须分开叙述。',
          '跳过定义域直接求导，写出的单调区间超出函数本身的范围。'] },

    { n: '函数周期性', s: '数学',
      k: ['周期', '周期性', '最小正周期', '函数周期性'],
      d: '存在 T≠0 使 f(x+T)=f(x) 恒成立，最小的正 T 就是最小正周期。',
      f: ['f(x+T)=f(x) ⇒ T 为周期', 'f(x+a)=−f(x) ⇒ T=2a'],
      p: ['凭图象“看起来重复”就报周期，没有验证恒等关系。',
          '把周期与对称轴间距混为一谈：对称轴间距是 T/2，不是 T。'] },

    { n: '对称轴与对称中心', s: '数学',
      k: ['对称轴', '对称中心', '轴对称', '中心对称', '图象对称'],
      d: '轴对称看 f(a+x)=f(a−x)，中心对称看 f(a+x)+f(a−x)=2b。',
      f: ['轴对称 x=a ⇔ f(a+x)=f(a−x)', '中心对称 (a,b) ⇔ f(a+x)+f(a−x)=2b'],
      p: ['把对称轴的横坐标 a 当成自变量直接代入，符号写反。',
          '忽略“两条对称轴可推周期”的二级结论，白算一轮。'] },

    { n: '圆锥曲线离心率', s: '数学',
      k: ['离心率', '椭圆离心率', '双曲线离心率', 'e='],
      d: 'e=c/a：椭圆 0<e<1，双曲线 e>1；范围题抓 a、b、c 的几何关系。',
      f: ['e=\\frac{c}{a}', '椭圆 a^2=b^2+c^2；双曲线 c^2=a^2+b^2'],
      p: ['把椭圆与双曲线的 a、b、c 关系混用，e 的范围正好反过来。',
          '只列一个等式就定 e，漏掉“存在点”带来的不等关系。'] },

    { n: '圆锥曲线综合', s: '数学',
      k: ['韦达定理', '弦长', '椭圆标准方程', '双曲线', '抛物线', '联立'],
      d: '联立直线与曲线得二次方程，用 x1+x2、x1x2 把几何条件代数化。',
      f: ['x_1+x_2=−\\frac{b}{a}，x_1x_2=\\frac{c}{a}', '弦长 |AB|=\\sqrt{1+k^2}|x_1−x_2|'],
      p: ['联立后忘记检验 Δ>0，答案多出一支。',
          '设 y=kx+m 却漏掉斜率不存在的那条直线。'] },

    { n: '数列求和', s: '数学',
      k: ['数列求和', '前 n 项和', '等差数列前 n 项和', '等比数列', '错位相减', '裂项'],
      d: '等差乘等比用错位相减，分式型用裂项相消；先看通项结构再选方法。',
      f: ['S_n=\\frac{n(a_1+a_n)}{2}', '\\frac{1}{n(n+1)}=\\frac{1}{n}−\\frac{1}{n+1}'],
      p: ['错位相减后忘记除以 (1−q)，q=1 也没有单独讨论。',
          '裂项后正负项没全部抵消就下结论，项数算错。'] },

    { n: '古典概型与条件概率', s: '数学',
      k: ['古典概型', '概率计算', '概率', '独立重复试验', '条件概率'],
      d: '样本点等可能时 P=有利数/总数；条件概率在缩小后的样本空间里重新数。',
      f: ['P(A)=\\frac{m}{n}', 'P(B|A)=\\frac{P(AB)}{P(A)}'],
      p: ['样本点并不等可能，仍按个数比算概率。',
          '条件概率的分母仍用原样本空间，而不是 A 的样本空间。'] },

    { n: '离散型随机变量的期望', s: '数学',
      k: ['期望', '方差', '分布列', '离散型随机变量的期望', '随机变量'],
      d: '先列分布列，再用 E(X)=Σx_ip_i；方差用 E(X²)−E(X)² 更稳。',
      f: ['E(X)=Σ x_ip_i', 'D(X)=E(X^2)−[E(X)]^2'],
      p: ['分布列概率和不为 1 就往下算。',
          '求 E(aX+b) 时只乘了 a，忘记加 b。'] },

    { n: '导数与切线', s: '数学',
      k: ['导数', '切线', '导数的几何意义', '极值', '单调区间'],
      d: '导数是切线斜率：f′(x₀) 给斜率，f(x₀) 给切点，两者缺一不可。',
      f: ["k=f'(x_0)", "切线 y−f(x_0)=f'(x_0)(x−x_0)"],
      p: ['“过某点的切线”与“在该点处的切线”当成一回事。',
          '求单调区间只解 f′(x)>0，漏掉定义域与不可导点。'] },

    { n: '三角恒等变换', s: '数学',
      k: ['二倍角公式', '恒等变换', '诱导公式', '辅助角', '三角恒等', '整体代换'],
      d: '角的统一优先：二倍角、辅助角把和差化成一个三角函数，再谈性质。',
      f: ['sin2α=2sinαcosα', 'a sinx+b cosx=\\sqrt{a^2+b^2} sin(x+φ)'],
      p: ['辅助角 φ 的象限凭感觉写，符号跟着错。',
          '二倍角选错平方形式，次数越化越高。'] },

    { n: '三角函数图象与性质', s: '数学',
      k: ['三角函数', '正切函数图象', '图象变换', '振幅', '五点法'],
      d: '先化 y=A sin(ωx+φ)+B，再用整体代换求单调、最值、对称。',
      f: ['T=\\frac{2π}{|ω|}', '对称轴 ωx+φ=\\frac{π}{2}+kπ'],
      p: ['平移时没把 ω 提出来，左右移错了 1/ω 倍。',
          '求单调区间不解整体不等式，直接把 x 的范围代进去。'] },

    { n: '解三角形', s: '数学',
      k: ['正余弦定理', '正弦定理', '余弦定理', '解三角形', '边角互化', '面积公式'],
      d: '两角一边用正弦定理，两边夹角用余弦定理，面积配 1/2·ab·sinC。',
      f: ['\\frac{a}{sinA}=\\frac{b}{sinB}', 'c^2=a^2+b^2−2ab cosC'],
      p: ['正弦定理解出两个角时不做取舍，出现增根。',
          '边角互化时把 sinA 当 a 直接约掉，忘了同除的前提。'] },

    { n: '立体几何与空间角', s: '数学',
      k: ['立体几何', '线面角', '二面角', '母线长', '体积', '空间向量', '外接球'],
      d: '平行垂直走判定与性质定理；求角用向量或作垂线，两条路都要写清依据。',
      f: ['sinθ=\\frac{|n·l|}{|n||l|}', 'V=\\frac{1}{3}Sh'],
      p: ['用向量算出角却不说明是线面角还是二面角。',
          '作辅助线时默认“显然垂直”，缺定理依据。'] },

    { n: '直线与圆的位置关系', s: '数学',
      k: ['直线与圆的位置关系', '切线长', '点到直线距离', '点到直线的距离', '圆的方程', '弦长'],
      d: '比较圆心距 d 与半径 r 判断位置；切线问题抓“圆心到直线距离等于 r”。',
      f: ['d=\\frac{|Ax_0+By_0+C|}{\\sqrt{A^2+B^2}}', '切线长 t=\\sqrt{d^2−r^2}'],
      p: ['切线斜率不存在的情况没讨论，漏掉一条切线。',
          '弦长公式里把 r²−d² 写成 d²−r²。'] },

    { n: '平面向量数量积', s: '数学',
      k: ['平面向量', '数量积', '数量积的坐标运算', '向量', '模的性质', '夹角'],
      d: '数量积既能算角也能算投影；坐标法与几何法按已知条件挑一个。',
      f: ['a·b=|a||b|cosθ', 'a·b=x_1x_2+y_1y_2'],
      p: ['把 a·b 当普通乘法直接约掉（向量没有消去律）。',
          '用坐标算模忘记开方，或漏掉平方。'] },

    { n: '复数运算', s: '数学',
      k: ['复数', '复数的模', '复数的四则运算'],
      d: '复数运算按 i²=−1 处理，除法乘共轭，模用 |z|²=z·z̄。',
      f: ['\\frac{a+bi}{c+di}=\\frac{(a+bi)(c−di)}{c^2+d^2}', '|z|=\\sqrt{a^2+b^2}'],
      p: ['除法分母乘了共轭，却忘记分子同步乘。',
          '把 |z|² 与 z² 混为一谈。'] },

    { n: '排列组合与二项式', s: '数学',
      k: ['排列组合', '二项式', '计数原理', '分组'],
      d: '先分类再分步；有序用排列、无序用组合，二项式抓通项。',
      f: ['C_n^m=\\frac{n!}{m!(n−m)!}', 'C_n^0+C_n^1+…+C_n^n=2^n'],
      p: ['分组问题忘记除以组数的阶乘，出现重复计数。',
          '二项式求系数时漏掉符号 (−1)ʳ。'] },

    { n: '指对运算与比大小', s: '数学',
      k: ['对数运算', '指数', '比大小', '对数函数', '幂函数'],
      d: '同底化同底，不同底找中间量 0、1，或构造函数比单调。',
      f: ['log_aM+log_aN=log_a(MN)', 'a^log = N 型：先取对数再化'],
      p: ['对数真数不检验大于 0，出现增根。',
          '比大小只估数，不说明单调性依据。'] },

    { n: '恒成立与参数范围', s: '数学',
      k: ['恒成立问题', '参数范围', '分离参数', '最值'],
      d: '恒成立转最值：a≥f(x) 恒成立等价于 a≥f(x) 的最大值；能分离先分离。',
      f: ['a≥f(x) ⇔ a≥f(x) 的最大值', 'a≤f(x) ⇔ a≤f(x) 的最小值'],
      p: ['最值取不到时写“≥”，没有检验等号成立的条件。',
          '分离参数时除的式子符号未定，不等号方向反了。'] },

    { n: '集合与常用逻辑', s: '数学',
      k: ['集合', '充分必要条件', '充要条件', '命题', '子集', '逻辑'],
      d: '交并补先画数轴或韦恩图；充要条件看两个方向能否互推。',
      f: ['A⊆B ⇔ x∈A ⇒ x∈B', 'p⇒q 且 q⇒p ⇔ 充要'],
      p: ['空集是任何集合的子集，讨论子集时漏掉空集。',
          '只验证一个方向就说“充要”，把充分当充要。'] },

    /* ---------------- 物理 ---------------- */
    { n: '牛顿第二定律', s: '物理',
      k: ['牛顿第二定律', '受力分析', '斜面受力分析', '摩擦力', '正交分解', '连接体', '整体法'],
      d: '先受力分析再分解，合力方向决定加速度，别把运动方向当合力方向。',
      f: ['F合=ma', 'f=μN，方向沿接触面反向'],
      p: ['斜面题把重力沿斜面分量写成 mg cosθ。',
          '摩擦力方向不判，或用动摩擦因数去算静摩擦。'] },

    { n: '平抛运动', s: '物理',
      k: ['平抛运动', '水平位移', '运动的分解', '速度的合成', '类平抛'],
      d: '水平匀速 + 竖直自由落体，时间只由高度决定，两方向互不干扰。',
      f: ['t=\\sqrt{2h/g}', 'x=v_0t，v_y=gt'],
      p: ['把落地速度当成竖直分速度，忘记合成。',
          '用水平距离反推时间却不检验是否已落地。'] },

    { n: '圆周运动', s: '物理',
      k: ['圆周运动', '竖直圆周运动', '向心力', '临界速度', '圆锥摆'],
      d: '向心力是合力的径向分量，不是额外多出来的一个力；竖直圆抓最高点临界。',
      f: ['F_n=m\\frac{v^2}{r}=mω^2r', '竖直圆最高点 mg=m\\frac{v^2}{r}'],
      p: ['受力图上再加一个“向心力”，多算一次。',
          '绳与杆的临界条件混用：杆可以支撑到速度为零。'] },

    { n: '机械能守恒与动能定理', s: '物理',
      k: ['机械能守恒', '动能定理', '功能关系', '摩擦力做功', '功率'],
      d: '只有重力、弹力做功时机械能守恒；有摩擦就改用动能定理算总功。',
      f: ['E_k+E_p 守恒（初=末）', 'W合=ΔE_k'],
      p: ['有摩擦还写机械能守恒，漏掉产生的内能。',
          '重力做功的正负与高度差方向写反。'] },

    { n: '动量守恒与碰撞', s: '物理',
      k: ['动量守恒', '弹性碰撞', '碰后速度公式', '动量定理', '碰撞'],
      d: '系统合外力为零、或碰撞瞬间可忽略时动量守恒；再按弹性/非弹性补能量关系。',
      f: ["m_1v_1+m_2v_2=m_1v_1'+m_2v_2'", "弹性碰撞 v_1'=\\frac{m_1−m_2}{m_1+m_2}v_1"],
      p: ['把动量守恒当动能守恒用，非弹性碰撞算出错误速度。',
          '没统一正方向，速度符号带得一团乱。'] },

    { n: '电场力做功与电势能', s: '物理',
      k: ['电场力做功', '电势能', '电势差', '电场强度', '等势面', '点电荷场强', '电场的叠加'],
      d: '电场力做功只看电势差，与路径无关；电势能变化与电场力做功符号相反。',
      f: ['W=qU：与路径无关', 'U=φA−φB（沿场强方向电势降低）'],
      p: ['正负电荷套 W=qU 时符号搞反，电势能增减判错。',
          '把场强方向与电势降低方向当成两个独立依据。'] },

    { n: '闭合电路欧姆定律', s: '物理',
      k: ['闭合电路欧姆定律', '欧姆定律', '电源效率', '动态电路', '电路', '内阻'],
      d: '电动势等于内外电压之和；动态分析按“局部—整体—局部”走。',
      f: ['I=\\frac{E}{R+r}', 'U=E−Ir'],
      p: ['把路端电压当电动势，忽略内阻压降。',
          '滑动变阻器变化后不重新判断串并联关系。'] },

    { n: '带电粒子在电场中偏转', s: '物理',
      k: ['带电粒子偏转', '类平抛', '加速电场', '偏转电场', '示波管'],
      d: '加速用动能定理，偏转按类平抛分解，出电场后匀速直线。',
      f: ['qU=\\frac{1}{2}mv^2', 'y=\\frac{qUL^2}{2mdv_0^2}'],
      p: ['偏转公式里板长 L 与板间距 d 的位置写反。',
          '出电场后仍按匀加速算，忘记改匀速。'] },

    { n: '光的折射', s: '物理',
      k: ['光的折射', '折射率与光速', '全反射', '临界角', '折射定律'],
      d: '折射率 n=c/v=sin i/sin r，全反射临界角 sinC=1/n。',
      f: ['n=\\frac{sin i}{sin r}=\\frac{c}{v}', '全反射 sinC=\\frac{1}{n}'],
      p: ['光从介质射向空气时角度关系写反。',
          '不判断是否满足全反射条件就套临界角。'] },

    { n: '简谐运动', s: '物理',
      k: ['简谐运动', '单摆', '振动图象', '回复力', '振幅'],
      d: '回复力与位移成正比反向，周期由系统决定；位移与路程不能混。',
      f: ['F=−kx', 'T=2π\\sqrt{m/k}'],
      p: ['把位移大小当路程，来回一趟算成一半。',
          '用 x=A sin(ωt) 时初相写错，起点运动方向反了。'] },

    { n: '万有引力与卫星', s: '物理',
      k: ['万有引力', '开普勒第三定律', '卫星', '宇宙速度', '天体运动'],
      d: '万有引力提供向心力，卫星的 a、v、T 只由轨道半径决定。',
      f: ['G\\frac{Mm}{r^2}=m\\frac{v^2}{r}', 'r^3/T^2=k'],
      p: ['把“贴近地面”的轨道半径直接写 R+h 却仍用 g 算。',
          '混淆发射速度与环绕速度。'] },

    { n: '电磁感应', s: '物理',
      k: ['电磁感应', '楞次定律', '感应电流方向', '安培力', '磁通量'],
      d: '磁通量变化产生感应电动势，方向由楞次定律判，大小看 ε=nΔΦ/Δt。',
      f: ['ε=n\\frac{ΔΦ}{Δt}', 'ε=Blv'],
      p: ['楞次定律只记住“阻碍”，忘了还要看原磁场方向。',
          '切割磁感线的有效长度取错。'] },

    { n: '机械波', s: '物理',
      k: ['机械波', '波的传播', '波长', '干涉', '衍射', '波速'],
      d: '波传播的是振动形式与能量，质点并不随波迁移；v=λ/T=λf。',
      f: ['v=\\frac{λ}{T}=λf', '相邻同相点距离为 λ'],
      p: ['把波形平移当质点迁移，方向判断反了。',
          '用 v=λf 时频率取错（频率由波源决定）。'] },

    /* ---------------- 化学 ---------------- */
    { n: '化学反应速率', s: '化学',
      k: ['化学反应速率', '速率', '催化剂', '活化能'],
      d: '速率用浓度变化除以时间与系数；影响因素看浓度、温度、压强、催化剂与接触面积。',
      f: ['v=\\frac{Δc}{Δt}', 'v(A):v(B)=m:n（系数比）'],
      p: ['用物质的量变化代替浓度变化算速率。',
          '把催化剂说成“提高平衡转化率”。'] },

    { n: '化学平衡与平衡常数', s: '化学',
      k: ['平衡常数', '化学平衡', '转化率', '勒夏特列', '平衡移动'],
      d: 'K 只与温度有关；用浓度商 Q 与 K 比较判断移动方向，转化率是已反应量占比。',
      f: ['K=\\frac{c(C)^p·c(D)^q}{c(A)^m·c(B)^n}', 'Q<K ⇒ 正向进行；Q>K ⇒ 逆向'],
      p: ['把增大压强当成一定使 K 变大。',
          '把固体、纯液体写进 K 的表达式。'] },

    { n: '电化学', s: '化学',
      k: ['电化学', '电解池', '原电池', '离子迁移方向', '电极反应', '电子转移'],
      d: '原电池负极失电子、电解池阳极失电子；电子只走外电路，离子在电解质中迁移。',
      f: ['阴极还原、阳极氧化', 'Q=It=n·F·电子数'],
      p: ['把原电池与电解池的阴阳极判断规则混用。',
          '电解质溶液中阳离子移向阴极这一点写反。'] },

    { n: '离子共存与离子方程式', s: '化学',
      k: ['离子共存', '离子方程式', '难溶物不拆', '电荷守恒', '离子反应'],
      d: '共存看是否生成沉淀、气体、弱电解质或发生氧化还原；方程式按“难溶、弱、气体不拆”。',
      f: ['强酸强碱可溶盐才拆成离子', '电荷守恒 Σc(正)=Σc(负)'],
      p: ['难溶物、弱电解质照拆，方程式不守恒。',
          '忽略隐含条件（无色、酸性、能大量共存）。'] },

    { n: '氧化还原反应', s: '化学',
      k: ['氧化还原', '电子转移计算', '电子守恒', '氧化还原配平', '化合价'],
      d: '升失氧、降得还；配平先配电子守恒，再配原子与电荷。',
      f: ['n(电子)=n(氧化剂)×得电子数', '得失电子总数相等'],
      p: ['只配原子不配电子，方程式看着平了却电荷不平。',
          '把化合价升降方向当成电子转移方向。'] },

    { n: '电离平衡与盐类水解', s: '化学',
      k: ['弱电解质的电离', '盐类水解', '电离常数', '电离平衡', 'pH'],
      d: '弱电解质部分电离，加水稀释促进电离但浓度降低；水解规律“谁弱谁水解”。',
      f: ['K_a=\\frac{c(H^+)c(A^-)}{c(HA)}', '越弱越水解'],
      p: ['把“稀释后电离程度增大”当成 c(H⁺) 增大。',
          '强酸强碱盐也说水解，忽略“谁弱谁水解”。'] },

    { n: '元素周期律与化学键', s: '化学',
      k: ['元素周期律', '化学键', '周期表', '元素推断', '原子结构'],
      d: '同周期左到右金属性减弱，同主族上到下金属性增强；化学键按成键微粒判断。',
      f: ['原子半径：同周期左大右小', '非金属性越强，最高价含氧酸酸性越强'],
      p: ['只看最外层电子数比非金属性，忽略电子层数。',
          '把“离子化合物一定含金属”当规律。'] },

    { n: '无机物转化与检验', s: '化学',
      k: ['实验装置分析', '气体检验', '铁与水蒸气反应', '碳酸盐与硅酸盐', '碳单质', '无机', '实验原理'],
      d: '常见物质按“色、态、溶、性”四步识别；气体检验先除杂再检验。',
      f: ['CO_2 用澄清石灰水，SO_2 用品红', 'NH_3 用湿润红色石蕊试纸'],
      p: ['检验前不除杂，SO₂ 也能让石灰水变浑。',
          '把 CO₃²⁻ 与 HCO₃⁻ 的检验顺序颠倒。'] },

    { n: '物质的量与阿伏加德罗常数', s: '化学',
      k: ['阿伏加德罗常数', '气体摩尔体积', '物质的量', '摩尔质量'],
      d: 'n=m/M=V/Vm=N/N_A；用 22.4 L/mol 前必须确认标况与气态。',
      f: ['n=\\frac{m}{M}=\\frac{V}{V_m}', 'N=nN_A'],
      p: ['非标况直接套 22.4 L/mol。',
          '忽略溶液中离子水解，粒子数算多。'] },

    /* ---------------- 生物 ---------------- */
    { n: '基因分离定律', s: '生物',
      k: ['分离定律', '纯合子判断', '基因型推断', '表现型比例', '测交'],
      d: '一对等位基因随同源染色体分开而分离；3:1 的前提是配子等可能、受精随机。',
      f: ['Aa×Aa ⇒ 3:1', '测交 Aa×aa ⇒ 1:1'],
      p: ['不先判断显隐性、不判断纯合杂合就算比例。',
          '忽略致死或配子不育，仍套默认比例。'] },

    { n: '基因自由组合定律', s: '生物',
      k: ['基因自由组合定律', '自由组合', '表现型比例', '两对相对性状'],
      d: '两对及以上等位基因位于非同源染色体上时独立分配，比例可拆成乘法。',
      f: ['AaBb 自交 ⇒ 9:3:3:1', '重组型 = 1 − 亲本型'],
      p: ['两对基因连锁时仍按自由组合算。',
          '问“表现型种类”却答成基因型种类。'] },

    { n: '细胞呼吸', s: '生物',
      k: ['细胞呼吸', '有氧呼吸', '无氧呼吸', 'ATP', '线粒体'],
      d: '有氧呼吸三阶段，无氧呼吸只在细胞质基质；产物与场所要一起记。',
      f: ['葡萄糖+6O_2 → 6CO_2+6H_2O', '无氧：→ 乳酸 或 → 酒精+CO_2'],
      p: ['把“无氧呼吸产生 CO₂”套到乳酸发酵上。',
          '混淆呼吸作用释放能量与 ATP 生成量。'] },

    { n: '光合作用', s: '生物',
      k: ['光合作用', '光反应', '暗反应', '净光合', '叶绿体'],
      d: '光反应在类囊体膜产 ATP 与 NADPH，暗反应在基质固定 CO₂；净光合=总光合−呼吸。',
      f: ['6CO_2+6H_2O → 有机物+6O_2', '净光合=总光合−呼吸'],
      p: ['把净光合速率当总光合速率代入计算。',
          '光照突然减弱时 C₃、C₅ 的变化方向判反。'] },

    { n: '生态系统能量流动', s: '生物',
      k: ['能量流动', '营养结构', '生态系统的营养结构', '能量传递效率', '生态位'],
      d: '能量单向流动、逐级递减，传递效率约 10%–20%；营养级越高得到的能量越少。',
      f: ['传递效率=\\frac{下一营养级同化量}{本营养级同化量}', '能量金字塔不会倒置'],
      p: ['用摄入量代替同化量算传递效率。',
          '把能量流动与物质循环的特点混为一谈。'] },

    { n: '种群增长与物质循环', s: '生物',
      k: ['种群增长曲线', '限制种群增长的因素', '种群', '碳循环', '物质循环', 'J型', 'S型'],
      d: '资源有限时呈 S 型增长，K/2 处增长最快；碳在群落与无机环境间以 CO₂ 形式循环。',
      f: ['S 型：K/2 时增长最快', '碳循环以 CO_2 形式在群落与无机环境间往返'],
      p: ['把 K 值当固定不变，忽略环境改变。',
          '以为能量也能循环利用。'] },

    { n: '蛋白质与脂质', s: '生物',
      k: ['蛋白质', '蛋白质与氨基酸', '氨基酸', '脂质的种类与元素', '脱水缩合'],
      d: '氨基酸脱水缩合形成肽键；蛋白质多样性由种类、数目、排列与空间结构决定。',
      f: ['肽键数=氨基酸数−肽链数', 'n 个氨基酸成 m 条链，脱水 n−m'],
      p: ['环状肽的肽键数仍按链状公式算。',
          '忽略二硫键形成时脱去的氢。'] },

    /* ---------------- 语文 ---------------- */
    { n: '文言实词与句式', s: '语文',
      k: ['文言实词', '文言', '词类活用', '句式', '翻译', '虚词'],
      d: '实词看语境与词性活用；句式抓判断、被动、宾语前置、状语后置四类标志。',
      f: ['之：助词/代词/取消独立性', '以：介词/连词，按前后词性判'],
      p: ['按现代汉语词义直译，不结合上下文。',
          '翻译漏掉省略成分，句子不成句。'] },

    { n: '古诗意象与情感', s: '语文',
      k: ['古诗意象', '意象解读', '情感表达', '诗歌鉴赏', '手法'],
      d: '先找意象与画面，再由景入情；答题按“手法—内容—情感”三段写。',
      f: ['月/雁/柳：思乡与离别', '答题=手法+诗句内容+情感'],
      p: ['只贴“思乡”标签，不结合具体诗句。',
          '把表现手法与修辞手法混为一谈。'] },

    { n: '材料作文审题', s: '语文',
      k: ['材料作文审题', '材料作文', '多材料作文', '思辨论证', '科技与人文', '故事与表达', '论点'],
      d: '先找材料的核心矛盾与关键词，再定论点；题目要求决定文体与论证方式。',
      f: ['审题=对象+关系+倾向', '论点句：观点+范围+判断'],
      p: ['脱离材料自说自话，写成话题作文。',
          '只抓一个关键词，忽略材料里的转折与限定。'] },

    { n: '论证结构与层次', s: '语文',
      k: ['论证层次', '议论文', '分论点', '论证结构'],
      d: '议论文按“提出—分析—解决”展开，段与段之间要有递进或对照关系。',
      f: ['分论点并列或递进，不重复', '每段=观点+论据+分析'],
      p: ['三个分论点意思重复，只换了说法。',
          '论据堆砌不分析，论点与例子脱节。'] },

    { n: '长难句与现代文阅读', s: '语文',
      k: ['长难句', '句子成分', '压缩语段', '现代文', '信息筛选'],
      d: '先抓主干（谁做什么），再剥离定语状语；信息题回原文定位。',
      f: ['主干=主语+谓语+宾语', '压缩：删定状补，留主谓宾'],
      p: ['把修饰成分当主干，整句理解跑偏。',
          '凭印象作答，不回原文核对范围与程度。'] },

    /* ---------------- 英语 ---------------- */
    { n: '定语从句', s: '英语',
      k: ['定语从句', '关系代词', '关系副词', '从句'],
      d: '先找先行词，再看从句缺什么：缺主宾用 which/that/who，缺状语用 where/when/why。',
      f: ['先行词+关系词+从句', '非限制性从句不用 that'],
      p: ['从句成分齐全仍用 that/which，本该用关系副词。',
          '逗号后的非限制性定语从句用 that。'] },

    { n: '非谓语动词', s: '英语',
      k: ['非谓语动词', '分词', '不定式', '动名词'],
      d: '一个句子只有一个谓语，其余动词按主动/被动、进行/完成选 doing、done 或 to do。',
      f: ['主动进行 → doing', '被动完成 → done'],
      p: ['两个谓语并列却不用连词。',
          '只看“被”字就选 done，忽略 by 后面的施动者。'] },

    { n: '时态与虚拟语气', s: '英语',
      k: ['过去完成时', '时态', '虚拟语气', '完成时'],
      d: '时态看时间状语与上下文；虚拟语气看与事实相反的时态后移。',
      f: ['过去完成：had done', '与过去相反：had done, would have done'],
      p: ['过去完成时与一般过去时混用。',
          '虚拟条件句主从句时态不对称。'] },

    { n: '应用文结构', s: '英语',
      k: ['应用文写作', '应用文结构', '邀请信结构', '约稿信', '书信', '礼貌表达'],
      d: '书信/邀请/约稿按“称呼—目的—细节—礼貌收尾—署名”组织，语气得体。',
      f: ['开门见山：I am writing to...', '结尾：Looking forward to your reply.'],
      p: ['只写套话，缺时间、地点等具体信息。',
          '语气过于随意，与题设身份不符。'] },

    /* ---------------- 历史 ---------------- */
    { n: '朝代更替与制度演变', s: '历史',
      k: ['朝代更替', '科举制', '宋代政治', '土地制度', '君主专制', '中央集权'],
      d: '制度演变抓“背景—内容—影响”，中央与地方、君权与相权是两条主线。',
      f: ['中央：三公九卿→三省六部→内阁军机', '选官：察举→九品中正→科举'],
      p: ['只背时间，不说明制度变化的原因。',
          '把不同朝代的机构职能张冠李戴。'] },

    { n: '史料实证', s: '历史',
      k: ['史料实证', '史料', '实证', '家国情怀', '历史解释'],
      d: '史料分一手/二手，价值看来源、目的与时间；论从史出，孤证不立。',
      f: ['一手史料：实物、档案、当时记载', '孤证不立，需多源互证'],
      p: ['把文学作品当信史直接引用。',
          '只引一条史料就下结论。'] },

    { n: '近代经济结构变动', s: '历史',
      k: ['近代经济结构', '自然经济解体', '工业革命', '小农经济', '近代化'],
      d: '自然经济逐步解体，民族资本主义在夹缝中发展，工业革命推动世界市场形成。',
      f: ['解体：纺与织分离、农副产品商品化', '民族资本：先天不足、后天畸形'],
      p: ['把自然经济解体等同于完全消失。',
          '忽略列强侵略与国内政策双重作用。'] },

    { n: '唯物史观与社会流动', s: '历史',
      k: ['经济基础与上层建筑', '唯物史观', '社会流动', '文化自信'],
      d: '经济基础决定上层建筑，阶级与制度变化要放回生产力水平中理解。',
      f: ['生产力→生产关系→上层建筑', '社会流动：科举、城市化、工业化'],
      p: ['用今天的价值观直接评判古代制度。',
          '把思想文化的变化说成唯一原因。'] },

    /* ---------------- 地理 ---------------- */
    { n: '洋流', s: '地理',
      k: ['洋流', '寒流', '暖流', '渔场', '大洋环流'],
      d: '中低纬大洋环流呈“北顺南逆”，寒暖流交汇与上升补偿流处多渔场。',
      f: ['暖流：由低纬流向高纬', '渔场：寒暖流交汇或上升补偿流'],
      p: ['把洋流方向与风向混为一谈。',
          '忽略洋流对沿岸气候的增温增湿/降温减湿作用。'] },

    { n: '气候成因', s: '地理',
      k: ['气候成因', '地中海气候', '气压带风带', '气候类型', '季风'],
      d: '从纬度、大气环流、海陆位置、地形、洋流五个角度归因，先定气候类型。',
      f: ['地中海气候：副高与西风交替', '季风：海陆热力性质差异'],
      p: ['只答纬度，漏掉地形与洋流。',
          '气候类型判断错，后面成因全错。'] },

    { n: '河流水文特征', s: '地理',
      k: ['河流水文特征', '含沙量', '径流', '地形与含沙量', '气候与径流', '水文'],
      d: '水文看流量、汛期、含沙量、结冰期、流速；水系看流向、支流、流域面积。',
      f: ['含沙量高：植被少、降水集中、地形陡', '汛期：雨水补给为主'],
      p: ['把水文特征与水系特征答混。',
          '只答自然因素，忽略上游水库与调水。'] },

    { n: '城市化与区位', s: '地理',
      k: ['城市化', '区位', '风能区位', '资源跨区域调配', '人口迁移'],
      d: '城市化看人口与用地比重，问题抓交通、住房、环境；区位从自然与社会经济两侧列。',
      f: ['城市化率=\\frac{城镇人口}{总人口}', '区位=自然+交通+市场+政策'],
      p: ['把城市化水平等同于城市面积。',
          '区位分析只列因素，不结合具体产业。'] }
  ];

  /* 匹配不到时的兜底卡 */
  var GENERIC = {
    n: '通用审题卡', s: '通用', k: [],
    d: '没有命中专门的知识卡时按三步审题：圈已知（数量、单位、条件）、圈所求（问的是哪个量）、找关系（连接已知与所求的公式或模型）。',
    f: ['已知 → 所求 → 关系式'],
    p: ['读完题干直接套最近做过的题，忽略条件差别（光滑/粗糙、是否计阻力）。',
        '单位没统一就代数字，长度用 cm、速度用 m/s 混算。']
  };

  /* ==================================================================
     二 · 小工具与状态
     ================================================================== */
  function doc() { return document; }
  function qs(sel) { return document.querySelector(sel); }
  function qsa(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }
  function on(el, ev, fn) { if (el) el.addEventListener(ev, fn); }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function fx(s) {
    return (window.JW && window.JW.fx) ? window.JW.fx(s) : esc(s);
  }
  function el(tag, attrs, html) {
    if (window.JW && window.JW.el) return window.JW.el(tag, attrs, html);
    var n = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      if (k === 'class') n.className = attrs[k];
      else n.setAttribute(k, attrs[k]);
    }
    if (html != null) n.innerHTML = html;
    return n;
  }
  function norm(s) {
    return String(s == null ? '' : s).toLowerCase()
      .replace(/[\s·・、，,。；;：:（）()《》「」“”"'‘’\-—_+－]/g, '');
  }
  function cut(s, n) {
    s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n) + '…' : s;
  }
  function curQ() {
    var A = window.JWApp;
    return (A && A.current) || null;
  }
  function allQ() {
    return (window.JW && window.JW.questions) || [];
  }

  function svgStar(filled) {
    return '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.7l1.93 3.9 4.3.63-3.11 3.03.73 4.28L8 11.53l-3.85 2.01.73-4.28L1.77 6.23l4.3-.63z" fill="' +
      (filled ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/></svg>';
  }
  function svgClose() {
    return '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 1l10 10M11 1L1 11" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round"/></svg>';
  }

  var drawer = null, dTag = null, dName = null, dDef = null, dForm = null,
    dPits = null, dQs = null, dCnt = null;
  var starBtn = null, starChip = null;
  var hintBox = null, hintBtns = [], hintLevel = 0;
  var stars = [], starMode = false, renderingList = false;
  var built = false, mounted = false;

  /* ==================================================================
     三 · 知识卡匹配
     ================================================================== */
  function matchCard(text) {
    var t = norm(text);
    if (!t) return GENERIC;
    var best = null, bestScore = 0;
    for (var i = 0; i < CARDS.length; i++) {
      var c = CARDS[i], sc = 0, cn = norm(c.n);
      if (cn === t) sc = 1000;
      else if (cn.indexOf(t) >= 0 || t.indexOf(cn) >= 0) sc = 400 + Math.min(cn.length, t.length);
      for (var j = 0; j < c.k.length; j++) {
        var kk = norm(c.k[j]);
        if (!kk) continue;
        if (kk === t) sc = Math.max(sc, 900);
        else if (t.indexOf(kk) >= 0 || kk.indexOf(t) >= 0) {
          var len = Math.min(kk.length, t.length);
          if (len >= 2) sc = Math.max(sc, 200 + len * 10 + (kk.length >= 4 ? 30 : 0));
        }
      }
      if (sc > bestScore) { bestScore = sc; best = c; }
    }
    return best || GENERIC;
  }

  function pointHit(pt, card, chip) {
    var p = norm(pt), c = norm(chip);
    if (!p) return false;
    if (c && (p === c || p.indexOf(c) >= 0 || c.indexOf(p) >= 0)) return true;
    for (var i = 0; i < card.k.length; i++) {
      var kk = norm(card.k[i]);
      if (!kk || kk.length < 2) continue;
      if (p.indexOf(kk) >= 0 || kk.indexOf(p) >= 0) return true;
    }
    return false;
  }

  function related(card, chip) {
    var list = allQ().filter(function (q) {
      var pts = q.points || [];
      for (var i = 0; i < pts.length; i++) if (pointHit(pts[i], card, chip)) return true;
      return false;
    });
    if (!list.length && card === GENERIC) {
      var cq = curQ();
      if (cq) list = [cq];
    }
    return list;
  }

  /* ==================================================================
     四 · 知识卡抽屉
     ================================================================== */
  function buildDrawer() {
    if (drawer) return;
    drawer = el('div', { class: 'st-drawer', 'aria-hidden': 'true' });
    var inner = el('aside', { class: 'st-dw-in', role: 'dialog', 'aria-label': '知识卡' });
    var head = el('div', { class: 'st-dw-head' });
    var kick = el('div', { class: 'st-dw-kicker' });
    kick.innerHTML = '知识卡<span class="st-dw-tag"></span>';
    var close = el('button', { class: 'st-dw-close', type: 'button', title: '关闭（Esc）', 'aria-label': '关闭知识卡' });
    close.innerHTML = svgClose();
    on(close, 'click', closeDrawer);
    head.appendChild(kick);
    head.appendChild(close);

    var body = el('div', { class: 'st-dw-body' });
    dName = el('h2', { class: 'st-dw-name' });
    dDef = el('p', { class: 'st-dw-def' });
    var secF = el('div', { class: 'st-dw-sec' }, '常见公式 / 结论');
    dForm = el('div', { class: 'st-dw-f st-fx' });
    var secP = el('div', { class: 'st-dw-sec' }, '两个常见坑');
    dPits = el('ol', { class: 'st-dw-pits' });
    var secQ = el('div', { class: 'st-dw-sec' }, '用这个知识点的题');
    dCnt = el('span', { class: 'st-dw-cnt' });
    secQ.appendChild(dCnt);
    dQs = el('div', { class: 'st-dw-qs' });

    body.appendChild(dName);
    body.appendChild(dDef);
    body.appendChild(secF);
    body.appendChild(dForm);
    body.appendChild(secP);
    body.appendChild(dPits);
    body.appendChild(secQ);
    body.appendChild(dQs);
    inner.appendChild(head);
    inner.appendChild(body);
    drawer.appendChild(inner);
    document.body.appendChild(drawer);
    dTag = drawer.querySelector('.st-dw-tag');
  }

  function openCard(text, chipEl) {
    if (!drawer) return;
    var card = matchCard(text);
    qsa('#points span.st-pick').forEach(function (n) { n.classList.remove('st-pick'); });
    if (chipEl) chipEl.classList.add('st-pick');

    dTag.textContent = card.s || '通用';
    dName.textContent = card.n;
    dDef.innerHTML = fx(card.d);

    dForm.innerHTML = '';
    (card.f && card.f.length ? card.f : []).forEach(function (t) {
      dForm.appendChild(el('div', {}, fx(t)));
    });
    if (!dForm.firstChild) {
      dForm.appendChild(el('div', {}, '这张卡没有固定公式，按定义与审题顺序走。'));
    }

    dPits.innerHTML = '';
    (card.p || []).forEach(function (t) {
      dPits.appendChild(el('li', { class: 'st-dw-pit' }, fx(t)));
    });

    var list = related(card, text);
    dCnt.textContent = ' · ' + list.length + ' 题';
    dQs.innerHTML = '';
    if (!list.length) {
      dQs.appendChild(el('div', { class: 'st-dw-empty' }, '题库里暂时没有直接考它的题，先把公式和两个坑记住。'));
    } else {
      list.slice(0, 10).forEach(function (q) {
        var b = el('button', { class: 'st-dw-q', type: 'button', title: '打开这道题' });
        b.appendChild(el('span', { class: 'st-dw-qt' }, esc(q.title || String(q.stem || '').slice(0, 18))));
        b.appendChild(el('span', { class: 'st-dw-qm' },
          [q.year ? q.year + ' 年' : '', q.subject, q.paper].filter(Boolean).join(' · ')));
        on(b, 'click', function () {
          closeDrawer();
          if (window.JWApp && window.JWApp.open) window.JWApp.open(q.id);
        });
        dQs.appendChild(b);
      });
    }

    drawer.classList.add('is-open');
    drawer.setAttribute('aria-hidden', 'false');
  }

  function closeDrawer() {
    if (!drawer) return;
    drawer.classList.remove('is-open');
    drawer.setAttribute('aria-hidden', 'true');
    qsa('#points span.st-pick').forEach(function (n) { n.classList.remove('st-pick'); });
  }

  function onDocClick(e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var chip = t.closest('#points span');
    if (chip) openCard(String(chip.textContent || '').trim(), chip);
  }

  /* ==================================================================
     五 · 错题本
     ================================================================== */
  function loadStars() {
    try {
      var a = JSON.parse(window.localStorage.getItem(STAR_KEY) || '[]');
      return Array.isArray(a) ? a.filter(function (x) { return typeof x === 'string' && x; }) : [];
    } catch (e) { return []; }
  }
  function saveStars() {
    try { window.localStorage.setItem(STAR_KEY, JSON.stringify(stars)); } catch (e) { /* file:// 也能用；失败就只在内存里 */ }
  }

  function buildStar() {
    if (starBtn) return;
    starBtn = el('button', { class: 'st-star', type: 'button', title: '把当前题标为错题' });
    starBtn.innerHTML = '<span class="st-star-ic">' + svgStar(false) + '</span>' +
      '<span class="st-star-t">标为错题</span><span class="st-star-n">0</span>';
    on(starBtn, 'click', toggleStar);
    var side = qs('#side');
    if (side) side.insertBefore(starBtn, side.firstChild);
  }

  function buildChip() {
    var box = qs('#filters');
    if (!box || box.querySelector('.st-chip')) { starChip = box && box.querySelector('.st-chip'); return; }
    starChip = el('button', { class: 'st-chip' + (starMode ? ' is-on' : ''), type: 'button', title: '只看我标过的错题' });
    starChip.innerHTML = '<span class="st-chip-ic">' + svgStar(starMode) + '</span>' +
      '<span class="st-chip-t">错题本</span><span class="st-chip-n">' + stars.length + '</span>';
    on(starChip, 'click', function () { setStarMode(!starMode); });
    box.appendChild(starChip);
  }

  function paintStar() {
    if (!starBtn) return;
    var q = curQ(), isOn = !!(q && q.id && stars.indexOf(q.id) >= 0);
    starBtn.classList.toggle('is-on', isOn);
    starBtn.setAttribute('title', isOn ? '取消这道题的错题标记' : '把当前题标为错题');
    starBtn.querySelector('.st-star-ic').innerHTML = svgStar(isOn);
    starBtn.querySelector('.st-star-t').textContent = isOn ? '已标错题 · 点击取消' : '标为错题';
    starBtn.querySelector('.st-star-n').textContent = stars.length;
    if (starChip) {
      starChip.querySelector('.st-chip-n').textContent = stars.length;
      starChip.querySelector('.st-chip-ic').innerHTML = svgStar(starMode);
      starChip.classList.toggle('is-on', starMode);
    }
  }

  function toggleStar() {
    var q = curQ();
    if (!q || !q.id) return;
    var i = stars.indexOf(q.id);
    if (i >= 0) stars.splice(i, 1); else stars.push(q.id);
    saveStars();
    paintStar();
    if (starMode) renderStarList();
  }

  function renderStarList() {
    var box = qs('#qlist');
    if (!box) return;
    renderingList = true;
    box.setAttribute('data-st', '1');
    box.innerHTML = '';
    var list = allQ().filter(function (q) { return stars.indexOf(q.id) >= 0; });
    if (!list.length) {
      box.appendChild(el('div', { class: 'jw-empty st-empty' }, '错题本还是空的：打开一道题，点右上角的星标。'));
    } else {
      var years = [], seen = {};
      list.forEach(function (q) {
        if (!seen[q.year]) { seen[q.year] = 1; years.push(q.year); }
      });
      years.sort(function (a, b) { return b - a; });
      var cq = curQ();
      years.forEach(function (y) {
        box.appendChild(el('div', { class: 'yr' }, y + ' 年'));
        list.filter(function (q) { return q.year === y; }).forEach(function (q) {
          var b = el('button', { class: 'qi st-qi' + (cq && cq.id === q.id ? ' is-on' : ''), type: 'button' });
          b.innerHTML = '<span class="t">' + esc(q.title || String(q.stem || '').slice(0, 18)) + '</span>' +
            '<span class="m"><b>' + esc(q.subject) + '</b> · ' + esc(q.paper) + ' · ' + esc(q.type) + '</span>';
          on(b, 'click', function () {
            if (window.JWApp && window.JWApp.open) window.JWApp.open(q.id);
          });
          box.appendChild(b);
        });
      });
    }
    renderingList = false;
  }

  function setStarMode(on2) {
    starMode = !!on2;
    paintStar();
    var box = qs('#qlist');
    if (!box) return;
    if (starMode) {
      renderStarList();
    } else {
      box.removeAttribute('data-st');
      if (window.JWApp && window.JWApp.renderList) window.JWApp.renderList();
    }
  }

  function watchFilters() {
    var box = qs('#filters');
    if (!box) return;
    buildChip();
    new MutationObserver(function () {
      if (!box.querySelector('.st-chip')) { starChip = null; buildChip(); paintStar(); }
    }).observe(box, { childList: true });
    on(box, 'click', function (e) {
      var t = e.target;
      if (t && t.closest && t.closest('.jw-chip') && starMode) setStarMode(false);
    });
  }

  function watchList() {
    var box = qs('#qlist');
    if (!box) return;
    new MutationObserver(function () {
      if (!starMode || renderingList) return;
      if (box.getAttribute('data-st') !== '1') return;
      if (box.querySelector('.st-qi') || box.querySelector('.st-empty')) return;
      renderStarList();
    }).observe(box, { childList: true });
  }

  /* ==================================================================
     六 · 提示阶梯
     ================================================================== */
  function asksOf(q) {
    var s = String(q.stem || '');
    var segs = s.split(/[。；;?？]/).map(function (x) { return x.trim(); }).filter(Boolean);
    var want = segs.filter(function (x) { return /求|则|是|判断|说明|多少|哪|试|写出/.test(x); });
    var last = want.length ? want[want.length - 1] : (segs.length ? segs[segs.length - 1] : s);
    return cut(last, 52);
  }

  function hRow(k, v, plain) {
    return '<div class="st-hint-row"><span class="st-hint-k">' + k + '</span>' +
      '<span class="st-hint-v st-fx">' + (plain ? esc(v) : fx(v)) + '</span></div>';
  }

  function hintHTML(level, q) {
    if (!q) return '<div class="st-hint-row"><span class="st-hint-v">还没有打开题目。</span></div>';
    var out = [];
    if (level >= 1) {
      var stem = String(q.stem || '').replace(/\s+/g, ' ').trim();
      out.push(hRow('给了', cut(stem, 76), true));
      out.push(hRow('要求', asksOf(q), true));
      out.push('<div class="st-hint-foot">先圈已知量与单位，再确认问的是哪个量。</div>');
    }
    if (level >= 2) {
      var pts = (q.points || []).slice(0, 3);
      if (!pts.length) {
        out.push(hRow('模型', '题干没标知识点：先写已知、待求，再找把它们连起来的公式。', true));
      } else {
        var card = matchCard(pts[0]);
        out.push(hRow('模型', pts.join('、'), true));
        out.push(hRow('公式', (card.f && card.f[0]) ? card.f[0]
          : '这张卡没有固定公式，按「' + card.n + '」的顺序走。'));
      }
    }
    if (level >= 3) {
      var step = (q.steps || [])[0];
      out.push(hRow('第一步', step || '这题没有拆步，先写出你认定的第一条关系式。', !step));
      out.push('<div class="st-hint-foot">只到这里，剩下的自己写；答案按钮先别按。</div>');
    }
    return out.join('');
  }

  function paintHints() {
    if (!hintBox) return;
    for (var i = 0; i < hintBtns.length; i++) hintBtns[i].classList.toggle('is-on', (i + 1) <= hintLevel);
    if (!hintLevel) {
      hintBox.classList.remove('is-on');
      hintBox.innerHTML = '';
      return;
    }
    hintBox.innerHTML = hintHTML(hintLevel, curQ());
    hintBox.classList.add('is-on');
  }

  function toggleHint(n) {
    hintLevel = (hintLevel === n) ? 0 : n;
    paintHints();
  }

  function buildHints() {
    var foot = qs('#qfoot');
    if (!foot || foot.querySelector('.st-hints')) {
      hintBox = foot && foot.querySelector('.st-hint-box');
      hintBtns = foot ? Array.prototype.slice.call(foot.querySelectorAll('.st-hint-btn')) : [];
      return;
    }
    var wrap = el('div', { class: 'st-hints' });
    var row = el('div', { class: 'st-hint-btns' });
    var names = ['审题', '方法', '关键一步'];
    names.forEach(function (name, i) {
      var b = el('button', {
        class: 'st-hint-btn', type: 'button', 'data-lv': String(i + 1),
        title: '第 ' + (i + 1) + ' 级：' + name
      }, '提示 ' + (i + 1));
      on(b, 'click', function () { toggleHint(i + 1); });
      row.appendChild(b);
    });
    hintBox = el('div', { class: 'st-hint-box' });
    wrap.appendChild(row);
    wrap.appendChild(hintBox);
    foot.appendChild(wrap);
    hintBtns = Array.prototype.slice.call(wrap.querySelectorAll('.st-hint-btn'));
  }

  /* ==================================================================
     七 · 切题时重置
     ================================================================== */
  function onQuestionChange() {
    hintLevel = 0;
    paintHints();
    paintStar();
  }

  function watchQuestion() {
    var meta = qs('#qmeta');
    if (!meta) return;
    new MutationObserver(onQuestionChange).observe(meta, { childList: true, characterData: true, subtree: true });
    onQuestionChange();
  }

  /* ==================================================================
     八 · 挂载
     ================================================================== */
  function mount() {
    if (mounted) return true;
    if (!window.JW || !window.JW.el) return false;
    if (!qs('#side') || !qs('#qfoot') || !qs('#qlist') || !qs('#filters')) return false;

    stars = loadStars();
    buildDrawer();
    buildStar();
    buildHints();
    watchFilters();
    watchList();
    watchQuestion();

    on(document, 'click', onDocClick);
    on(document, 'keydown', function (e) {
      if ((e.key === 'Escape' || e.keyCode === 27) && drawer && drawer.classList.contains('is-open')) closeDrawer();
    });

    paintStar();
    mounted = true;
    built = true;
    return true;
  }

  function boot() {
    var tries = 0;
    function attempt() {
      if (document.readyState === 'loading') return;
      if (mount()) return;
      if (++tries > 100) { console.warn('[study] 未能挂载：缺少 #side/#qfoot/#qlist 或 JW'); return; }
      setTimeout(attempt, 50);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', attempt);
    attempt();
  }

  boot();

  /* 调试/测试用小出口，不影响页面 */
  window.JWStudy = {
    version: VERSION,
    cards: CARDS,
    match: matchCard,
    openCard: function (text) { openCard(text, null); },
    close: closeDrawer,
    isOpen: function () { return !!(drawer && drawer.classList.contains('is-open')); },
    hintLevel: function () { return hintLevel; },
    setHint: function (n) { toggleHint(n); },
    starList: function () { return stars.slice(); },
    toggleStar: toggleStar,
    mounted: function () { return built; }
  };
})();
