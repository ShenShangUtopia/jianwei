/* 见微 · 析题台 · 讲解播放器
   自挂载：在 #stage 与 #qfoot 之间插入一条播放条；无解题步骤时整条隐藏，不留空隙。
   对外：window.JWPlayer = {mount,play,pause,toggle,next,prev,replay,setStep,setSpeed,exportPNG,save,state}
   依赖：window.JWApp.setStep(i) / window.JWApp.current；DOM 缺失时自动重试。
*/
(function () {
  'use strict';

  var SPEEDS = [0.6, 1, 1.6];
  var BASE_MS = 2800;
  var SYSTEM_FONT = "'Microsoft YaHei UI','PingFang SC','Segoe UI',sans-serif";
  var NS = 'http://www.w3.org/2000/svg';

  var S = {
    root: null, playing: false, idx: -1, n: 0, speed: 1, qid: '',
    timer: 0, syncTimer: 0, toastTimer: 0, bootTimer: 0, attempts: 0,
    mounted: false, exporting: false, obs: null, btnPlay: null, btnPrev: null,
    btnNext: null, btnSave: null, dots: null, curEl: null, totalEl: null,
    spdBtns: [], toast: null
  };

  /* ---------------- 样式自注入 ---------------- */
  function scriptBase() {
    var src = '';
    try { src = (document.currentScript && document.currentScript.src) || ''; } catch (e) { }
    return src.replace(/js\/player\.js(?:[?#].*)?$/, '');
  }
  function injectCSS() {
    if (document.getElementById('jw-player-css')) return;
    var links = document.querySelectorAll('link[rel="stylesheet"]');
    for (var i = 0; i < links.length; i++) {
      var href = links[i].getAttribute('href') || '';
      if (/(^|\/)css\/player\.css(?:[?#]|$)/.test(href)) {
        links[i].id = 'jw-player-css';
        return;
      }
    }
    var l = document.createElement('link');
    l.id = 'jw-player-css';
    l.rel = 'stylesheet';
    l.href = scriptBase() + 'css/player.css';
    (document.head || document.documentElement).appendChild(l);
  }

  /* ---------------- 小工具 ---------------- */
  function mk(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function pad2(v) { return (v < 10 ? '0' : '') + v; }
  function $(id) { return document.getElementById(id); }
  function lis() {
    var ol = $('steps');
    return ol ? ol.querySelectorAll('li') : [];
  }
  function currentQuestion() {
    try {
      var a = window.JWApp;
      return (a && a.current) || null;
    } catch (e) { return null; }
  }
  function currentQid() { var q = currentQuestion(); return (q && q.id) || ''; }
  function activeIndex() {
    var list = lis();
    for (var i = 0; i < list.length; i++) if (list[i].classList.contains('is-on')) return i;
    return -1;
  }
  function viewHost() { return $('view-host'); }

  function icon(name) {
    var body = {
      play: '<path d="M5.2 3.1v9.8L13 8z"/>',
      pause: '<path d="M4.6 3.1h2.3v9.8H4.6zM9.1 3.1h2.3v9.8H9.1z"/>',
      prev: '<path d="M4 3.2h1.6v9.6H4zM12.6 3.2v9.6L5.8 8z"/>',
      next: '<path d="M12.4 3.2H11v9.6h1.4zM3.4 3.2v9.6L10.2 8z"/>',
      replay: '<path d="M13 8a5 5 0 1 1-1.6-3.7"/><path d="M13 2.6V6h-3.4"/>',
      save: '<path d="M8 2.8v7.2"/><path d="M5.2 7.4 8 10.2l2.8-2.8"/><path d="M3 12.6h10"/>'
    }[name];
    var stroke = name === 'replay' || name === 'save';
    return '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"' +
      (stroke ? ' fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"' : '') +
      '>' + body + '</svg>';
  }
  function btn(cls, html, label) {
    var b = mk('button', cls);
    b.type = 'button';
    b.innerHTML = html;
    b.title = label;
    b.setAttribute('aria-label', label);
    return b;
  }
  function showToast(msg, ms) {
    if (!S.toast) return;
    S.toast.textContent = msg;
    S.toast.classList.add('pl-on');
    clearTimeout(S.toastTimer);
    S.toastTimer = setTimeout(function () { S.toast.classList.remove('pl-on'); }, ms || 2200);
  }

  /* ---------------- 构建 ---------------- */
  function build() {
    var root = mk('div', 'pl-bar');
    root.id = 'jw-player';
    root.setAttribute('role', 'group');
    root.setAttribute('aria-label', '讲解播放器');

    var left = mk('div', 'pl-left');
    S.btnPrev = btn('pl-ico pl-prev', icon('prev'), '上一步（←）');
    S.btnPlay = btn('pl-play', icon('play'), '播放（空格）');
    S.btnNext = btn('pl-ico pl-next', icon('next'), '下一步（→）');
    var replay = btn('pl-ico pl-replay', icon('replay'), '重播（R）');
    S.btnPrev.addEventListener('click', prev);
    S.btnPlay.addEventListener('click', toggle);
    S.btnNext.addEventListener('click', next);
    replay.addEventListener('click', replayPlay);
    left.appendChild(S.btnPrev);
    left.appendChild(S.btnPlay);
    left.appendChild(S.btnNext);
    left.appendChild(replay);

    var mid = mk('div', 'pl-mid');
    S.dots = mk('div', 'pl-dots');
    S.dots.setAttribute('role', 'group');
    S.dots.setAttribute('aria-label', '解题步骤');
    var count = mk('div', 'pl-count');
    S.curEl = mk('b', null, '00');
    S.totalEl = mk('span', null, ' / 00');
    count.appendChild(S.curEl);
    count.appendChild(S.totalEl);
    mid.appendChild(S.dots);
    mid.appendChild(count);

    var right = mk('div', 'pl-right');
    var keys = mk('span', 'pl-keys', '← → 空格 R');
    keys.title = '← → 上一步/下一步 · 空格 播放/暂停 · R 重播';

    var spd = mk('div', 'pl-spd');
    spd.setAttribute('role', 'group');
    spd.setAttribute('aria-label', '播放速度');
    S.spdBtns = SPEEDS.map(function (v) {
      var b = mk('button', 'pl-spd-btn', v === 1 ? '1×' : v + '×');
      b.type = 'button';
      b.dataset.speed = String(v);
      if (v === 1) b.classList.add('pl-on');
      b.addEventListener('click', function () { setSpeed(v); });
      spd.appendChild(b);
      return b;
    });

    S.btnSave = btn('pl-save', icon('save') + '<span>存图</span>', '把当前题目与步骤导出为 PNG');
    S.btnSave.addEventListener('click', savePNG);

    right.appendChild(keys);
    right.appendChild(spd);
    right.appendChild(S.btnSave);

    S.toast = mk('div', 'pl-toast');
    S.toast.setAttribute('role', 'status');
    S.toast.setAttribute('aria-live', 'polite');

    root.appendChild(left);
    root.appendChild(mid);
    root.appendChild(right);
    root.appendChild(S.toast);
    root.hidden = true;
    S.root = root;
  }

  function buildDots(stepLis) {
    S.dots.innerHTML = '';
    for (var i = 0; i < stepLis.length; i++) {
      (function (i) {
        var d = mk('button', 'pl-dot');
        d.type = 'button';
        d.dataset.step = String(i);
        var txt = (stepLis[i].textContent || '').replace(/\s+/g, ' ').trim();
        d.title = '第 ' + (i + 1) + ' 步' + (txt ? '：' + txt.slice(0, 36) : '');
        d.setAttribute('aria-label', '跳到第 ' + (i + 1) + ' 步');
        d.addEventListener('click', function () {
          applyStep(i);
          if (S.playing) arm();
        });
        S.dots.appendChild(d);
      })(i);
    }
  }

  /* ---------------- 挂载 / 同步 ---------------- */
  function mount() {
    if (S.root && document.documentElement.contains(S.root)) { sync(); return S.root; }
    var stage = $('stage');
    var wrap = $('stage-wrap');
    if (!stage || !wrap) return null;
    if (!S.root) build();
    wrap.insertBefore(S.root, stage.nextSibling);
    S.mounted = true;
    watch();
    syncNow();
    return S.root;
  }

  function hide() {
    if (!S.root) return;
    S.root.hidden = true;
    S.root.setAttribute('aria-hidden', 'true');
  }
  function show() {
    if (!S.root) return;
    S.root.hidden = false;
    S.root.removeAttribute('aria-hidden');
  }

  function watch() {
    if (S.obs) S.obs.disconnect();
    var ol = $('steps');
    if (!ol) return;
    S.obs = new MutationObserver(scheduleSync);
    S.obs.observe(ol, {
      childList: true, subtree: true, attributes: true, attributeFilter: ['class']
    });
    var qt = $('qtitle');
    if (qt) S.obs.observe(qt, { childList: true, characterData: true, subtree: true });
  }

  function scheduleSync() {
    clearTimeout(S.syncTimer);
    sync();
  }

  function syncNow() { clearTimeout(S.syncTimer); sync(); }

  function sync() {
    if (!S.root) return;
    var stepLis = lis();
    var n = stepLis.length;
    var qid = currentQid();
    var changed = (n !== S.n) || (qid !== S.qid);

    if (!n) {
      S.n = 0; S.qid = qid; S.idx = -1;
      pause();
      hide();
      update();
      return;
    }

    show();
    if (changed) {
      S.n = n; S.qid = qid; S.idx = -1;
      pause();
      buildDots(stepLis);
    } else {
      S.n = n; S.qid = qid;
    }

    var act = -1;
    for (var i = 0; i < stepLis.length; i++) {
      if (stepLis[i].classList.contains('is-on')) { act = i; break; }
    }
    if (act !== S.idx) {
      S.idx = act;
      if (S.playing) arm();
    }
    update();
  }

  function update() {
    if (!S.root) return;
    var cur = S.idx >= 0 ? S.idx + 1 : 0;
    if (S.curEl) S.curEl.textContent = pad2(cur);
    if (S.totalEl) S.totalEl.textContent = ' / ' + pad2(S.n);

    var dots = S.dots ? S.dots.children : [];
    for (var i = 0; i < dots.length; i++) {
      dots[i].classList.toggle('pl-on', i === S.idx);
      dots[i].classList.toggle('pl-done', i < S.idx);
    }
    if (S.btnPlay) {
      S.btnPlay.innerHTML = icon(S.playing ? 'pause' : 'play');
      S.btnPlay.title = S.playing ? '暂停（空格）' : '播放（空格）';
      S.btnPlay.setAttribute('aria-label', S.btnPlay.title);
      S.btnPlay.classList.toggle('pl-playing', S.playing);
      S.btnPlay.setAttribute('aria-pressed', S.playing ? 'true' : 'false');
    }
    if (S.btnPrev) S.btnPrev.disabled = S.n < 1 || S.idx <= 0;
    if (S.btnNext) S.btnNext.disabled = S.n < 1 || S.idx >= S.n - 1;
  }

  /* ---------------- 播放 ---------------- */
  function setPlaying(on) {
    S.playing = !!on;
    if (!S.playing) clearTimeout(S.timer);
    update();
  }
  function pause() { setPlaying(false); }
  function play() {
    if (!S.n) return false;
    if (S.playing) return true;
    if (S.idx < 0 || S.idx >= S.n - 1) applyStep(0);
    setPlaying(true);
    arm();
    return true;
  }
  function toggle() { if (S.playing) pause(); else play(); }
  function arm() {
    clearTimeout(S.timer);
    if (!S.playing) return;
    S.timer = setTimeout(tick, BASE_MS / S.speed);
  }
  function tick() {
    if (!S.playing) return;
    if (S.idx >= S.n - 1) { pause(); return; }
    applyStep(S.idx + 1);
    if (S.idx >= S.n - 1) pause(); else arm();
  }
  function next() {
    if (!S.n) return;
    if (S.idx < S.n - 1) {
      applyStep(S.idx + 1);
      if (S.playing) arm();
    } else if (S.playing) pause();
  }
  function prev() {
    if (!S.n) return;
    if (S.idx > 0) {
      applyStep(S.idx - 1);
      if (S.playing) arm();
    } else if (S.idx < 0) {
      applyStep(0);
    }
  }
  function replayPlay() {
    if (!S.n) return;
    applyStep(0);
    S.playing = true;
    update();
    arm();
  }
  function setSpeed(v) {
    v = parseFloat(v);
    if (SPEEDS.indexOf(v) < 0) return;
    S.speed = v;
    for (var i = 0; i < S.spdBtns.length; i++) {
      S.spdBtns[i].classList.toggle('pl-on', parseFloat(S.spdBtns[i].dataset.speed) === v);
    }
    if (S.playing) arm();
  }

  function applyStep(i) {
    var stepLis = lis();
    var n = stepLis.length;
    if (!n) return false;
    i = parseInt(i, 10);
    if (!isFinite(i)) i = 0;
    i = Math.max(0, Math.min(n - 1, i));
    S.idx = i; S.n = n;
    var ok = false;
    try {
      if (window.JWApp && typeof window.JWApp.setStep === 'function') {
        window.JWApp.setStep(i);
        ok = true;
      }
    } catch (e) {
      console.warn('[JWPlayer] setStep 失败：', e);
    }
    if (!ok) {
      for (var k = 0; k < stepLis.length; k++) stepLis[k].classList.toggle('is-on', k === i);
    }
    update();
    return true;
  }

  /* ---------------- 键盘 ---------------- */
  function inField(t) {
    if (!t) return false;
    var tag = (t.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
    if (t.isContentEditable) return true;
    return !!(t.closest && t.closest('input,textarea,select,[contenteditable=""],[contenteditable="true"]'));
  }
  function onKey(e) {
    if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;
    if (inField(e.target)) return;
    if (!S.root || S.root.hidden || !S.n) return;
    var k = e.key;
    if (k === 'ArrowLeft') { e.preventDefault(); prev(); }
    else if (k === 'ArrowRight') { e.preventDefault(); next(); }
    else if (k === ' ' || k === 'Spacebar' || e.code === 'Space') { e.preventDefault(); toggle(); }
    else if (k === 'r' || k === 'R') { e.preventDefault(); replayPlay(); }
  }

  /* ---------------- 导出 PNG ---------------- */
  function pickCanvas(host) {
    var all = host.querySelectorAll('canvas'), best = null, area = 0;
    for (var i = 0; i < all.length; i++) {
      var c = all[i];
      var a = c.width * c.height;
      if (c.width > 8 && c.height > 8 && a > area) { area = a; best = c; }
    }
    return best;
  }
  function pickSvg(host) {
    var all = host.querySelectorAll('svg'), best = null, area = 0;
    for (var i = 0; i < all.length; i++) {
      var r = all[i].getBoundingClientRect();
      var a = r.width * r.height;
      if (r.width > 8 && r.height > 8 && a > area) { area = a; best = all[i]; }
    }
    if (!best && all.length) best = all[0];
    return best;
  }
  function numAttr(v) {
    if (v == null) return NaN;
    v = String(v).trim();
    if (!/^\d+(\.\d+)?(px)?$/.test(v)) return NaN;
    return parseFloat(v);
  }
  function svgSize(svg) {
    var w = numAttr(svg.getAttribute('width'));
    var h = numAttr(svg.getAttribute('height'));
    var vb = svg.viewBox && svg.viewBox.baseVal;
    if (!(w > 1 && h > 1) && vb && vb.width > 1 && vb.height > 1) {
      w = vb.width; h = vb.height;
    }
    if (!(w > 1 && h > 1)) {
      var r = svg.getBoundingClientRect();
      w = r.width; h = r.height;
    }
    return { w: Math.max(60, Math.round(w || 800)), h: Math.max(40, Math.round(h || 560)) };
  }

  var SVG_PROPS = [
    'fill', 'fill-opacity', 'fill-rule', 'stroke', 'stroke-width', 'stroke-opacity',
    'stroke-dasharray', 'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin',
    'opacity', 'font-size', 'font-weight', 'font-style', 'letter-spacing',
    'text-anchor', 'dominant-baseline', 'alignment-baseline', 'paint-order',
    'visibility', 'display', 'transform', 'transform-origin', 'transform-box',
    'clip-path', 'mask', 'filter'
  ];
  function inlineSvg(source, clone) {
    var srcs = [source].concat(Array.prototype.slice.call(source.querySelectorAll('*')));
    var dsts = [clone].concat(Array.prototype.slice.call(clone.querySelectorAll('*')));
    for (var i = 0; i < srcs.length; i++) {
      var cs = window.getComputedStyle(srcs[i]);
      var st = dsts[i].style;
      for (var p = 0; p < SVG_PROPS.length; p++) {
        var v = cs.getPropertyValue(SVG_PROPS[p]);
        if (v) st.setProperty(SVG_PROPS[p], v);
      }
      st.removeProperty('font-family');
    }
    clone.style.setProperty('font-family', SYSTEM_FONT);
  }
  function svgImage(svg, size) {
    return new Promise(function (resolve, reject) {
      try {
        var clone = svg.cloneNode(true);
        clone.setAttribute('xmlns', NS);
        clone.setAttribute('width', String(size.w));
        clone.setAttribute('height', String(size.h));
        inlineSvg(svg, clone);
        var xml = new XMLSerializer().serializeToString(clone);
        var url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml);
        var img = new Image();
        img.onload = function () { resolve(img); };
        img.onerror = function () { reject(new Error('SVG 转图失败')); };
        img.src = url;
      } catch (e) { reject(e); }
    });
  }

  function fitText(ctx, text, max) {
    text = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
    if (!text) return '';
    if (ctx.measureText(text).width <= max) return text;
    while (text.length > 1 && ctx.measureText(text + '…').width > max) {
      text = text.slice(0, -1);
    }
    return text + '…';
  }

  function compose(source, meta) {
    var W = 1180, HEAD = 60, PAD = 30, FOOT = 34, MAX_H = 880;
    var avail = W - PAD * 2;
    var scale = avail / source.w;
    if (source.h * scale > MAX_H) scale = MAX_H / source.h;
    var imgW = Math.round(source.w * scale);
    var imgH = Math.round(source.h * scale);
    var H = HEAD + PAD + imgH + PAD + FOOT;

    var out = document.createElement('canvas');
    var ss = 2;
    out.width = W * ss;
    out.height = H * ss;
    var ctx = out.getContext('2d');
    ctx.scale(ss, ss);

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, W, H);

    /* 顶部条：墨蓝 + 题目 + 步骤 */
    ctx.fillStyle = '#081F5C';
    ctx.fillRect(0, 0, W, HEAD);
    ctx.fillStyle = '#B4553C';
    ctx.fillRect(PAD, HEAD - 3, 26, 2);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '600 20px ' + SYSTEM_FONT;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    var title = fitText(ctx, meta.title, W - PAD * 2 - 190);
    ctx.fillText(title, PAD, HEAD / 2 + 1);

    ctx.font = '12px ' + SYSTEM_FONT;
    ctx.fillStyle = 'rgba(255,255,255,.78)';
    ctx.textAlign = 'right';
    ctx.fillText(meta.stepText, W - PAD, HEAD / 2 + 2);

    /* 图形 */
    var ix = Math.round((W - imgW) / 2);
    var iy = HEAD + PAD;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(ix, iy, imgW, imgH);
    ctx.drawImage(source.el, 0, 0, source.w, source.h, ix, iy, imgW, imgH);
    ctx.strokeStyle = '#EEF1F7';
    ctx.lineWidth = 1;
    ctx.strokeRect(ix + .5, iy + .5, imgW - 1, imgH - 1);

    /* 页脚 */
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'left';
    ctx.font = '11px ' + SYSTEM_FONT;
    ctx.fillStyle = '#93A0B8';
    if (meta.meta) ctx.fillText(meta.meta, PAD, H - 24);
    ctx.textAlign = 'right';
    ctx.fillText('见微 · 析题台', W - PAD, H - 24);
    return out;
  }

  function toBlob(cv) {
    return new Promise(function (resolve, reject) {
      try {
        cv.toBlob(function (b) {
          if (b) resolve(b);
          else reject(new Error('toBlob 返回空'));
        }, 'image/png');
      } catch (e) { reject(e); }
    });
  }

  function exportPNG() {
    if (S.exporting) return Promise.reject(new Error('正在生成上一张图'));
    S.exporting = true;
    return (async function () {
      try {
        var host = viewHost();
        if (!host) throw new Error('找不到视图区域');
        var q = currentQuestion();
        var n = lis().length;
        var act = activeIndex();
        var stepIdx = act >= 0 ? act : S.idx;
        var titleEl = $('qtitle');
        var meta = {
          title: (q && (q.title || q.stem)) || (titleEl && titleEl.textContent) || '题目',
          stepText: stepIdx >= 0 ? '第 ' + (stepIdx + 1) + ' / ' + Math.max(1, n) + ' 步' : '共 ' + n + ' 步',
          meta: q ? [q.year ? q.year + ' 年' : '', q.paper || '', q.subject || ''].filter(Boolean).join(' · ') : ''
        };
        var cv = pickCanvas(host);
        var source;
        if (cv) {
          source = { el: cv, w: cv.width, h: cv.height };
        } else {
          var svg = pickSvg(host);
          if (!svg) throw new Error('当前视图没有可导出的图形');
          var size = svgSize(svg);
          var img = await svgImage(svg, size);
          source = { el: img, w: size.w, h: size.h };
        }
        var out = compose(source, meta);
        var blob = await toBlob(out);
        if (!blob) throw new Error('生成 PNG 失败');
        return blob;
      } finally {
        S.exporting = false;
      }
    })();
  }

  function download(blob, name) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      URL.revokeObjectURL(url);
      if (a.parentNode) a.parentNode.removeChild(a);
    }, 1200);
  }

  function savePNG() {
    if (S.exporting) { showToast('正在生成图片…'); return Promise.resolve(null); }
    var q = currentQuestion();
    var id = (q && q.id) ? String(q.id).replace(/[^\w.-]+/g, '_') : 'question';
    var act = activeIndex();
    var stepIdx = act >= 0 ? act : S.idx;
    var name = '见微-' + id + (stepIdx >= 0 ? '-第' + (stepIdx + 1) + '步' : '') + '.png';
    if (S.btnSave) { S.btnSave.disabled = true; S.btnSave.classList.add('pl-busy'); }
    showToast('正在生成 PNG…', 4000);
    return exportPNG().then(function (blob) {
      download(blob, name);
      showToast('已导出 ' + name, 2600);
      return blob;
    }).catch(function (err) {
      console.warn('[JWPlayer] 导出失败：', err);
      showToast((err && err.message) || '导出失败', 3000);
      return null;
    }).then(function (blob) {
      if (S.btnSave) { S.btnSave.disabled = false; S.btnSave.classList.remove('pl-busy'); }
      return blob;
    });
  }

  /* ---------------- 生命周期 ---------------- */
  function init() {
    if (S.mounted) { sync(); return; }
    if (!$('stage')) {
      if (S.attempts++ > 120) return;
      S.bootTimer = setTimeout(init, 50);
      return;
    }
    mount();
  }

  function destroy() {
    clearTimeout(S.timer);
    clearTimeout(S.syncTimer);
    clearTimeout(S.bootTimer);
    clearTimeout(S.toastTimer);
    if (S.obs) { S.obs.disconnect(); S.obs = null; }
    document.removeEventListener('keydown', onKey, true);
    if (S.root && S.root.parentNode) S.root.parentNode.removeChild(S.root);
    S.root = null; S.mounted = false; S.playing = false; S.idx = -1; S.n = 0;
  }

  injectCSS();
  document.addEventListener('keydown', onKey, true);
  window.addEventListener('pagehide', function () { clearTimeout(S.timer); });

  if ($('stage')) {
    init();
  } else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 0);
  }

  window.JWPlayer = {
    version: '2026.10',
    mount: init,
    destroy: destroy,
    play: play,
    pause: pause,
    toggle: toggle,
    next: next,
    prev: prev,
    replay: replayPlay,
    setStep: applyStep,
    setSpeed: setSpeed,
    exportPNG: exportPNG,
    save: savePNG,
    get state() {
      return {
        mounted: !!S.root, hidden: !!(S.root && S.root.hidden),
        playing: S.playing, idx: S.idx, steps: lis().length,
        speed: S.speed, qid: currentQid()
      };
    }
  };
})();
