/* 见微 · 析题台 · 共享内核
   契约：
   - JW.registerView(engine, mountFn)；mountFn(host, question, api) -> {applyStep?(i), destroy?()}
   - api = { C, onStep(cb), hint(text), resize(cb) }
   - 题目对象：{id,year,paper,subject,type,title,stem,answer,points[],steps[],view{engine,...}}
*/
(function () {
  const JW = window.JW = window.JW || {};
  JW.questions = [];
  JW.views = {};
  JW.version = '2026.10';

  JW.registerView = function (engine, mountFn) { JW.views[engine] = mountFn; };

  /* ---------- 色板：青瓷蓝 · 数据风 ---------- */
  JW.C = {
    paper: '#F7F2EB', card: '#FFFFFF', ink: '#081F5C', ink2: '#334EAC',
    data: ['#081F5C', '#334EAC', '#7096D1', '#BAD6EB', '#D0E3FF'],
    line: '#DDE4F0', line2: '#EEF1F7', soft: '#6B7A99', faint: '#93A0B8',
    accent: '#B4553C', jade: '#3F6F62', gold: '#9A7B34',
    grid: '#E8EDF6', grid2: '#F2F5FA',
    sans: "'Microsoft YaHei UI','PingFang SC','Segoe UI',sans-serif",
    serif: "Georgia,'Times New Roman',serif",
    mono: "Consolas,'Cascadia Mono',monospace"
  };

  /* ---------- 小工具 ---------- */
  JW.el = function (tag, attrs, html) {
    const n = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      if (k === 'class') n.className = attrs[k];
      else if (k === 'style') n.style.cssText = attrs[k];
      else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    }
    if (html != null) n.innerHTML = html;
    return n;
  };
  JW.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  JW.lerp = (a, b, t) => a + (b - a) * t;
  JW.num = function (v, d) {
    if (!isFinite(v)) return '—';
    const r = Math.abs(v) < 1e-9 ? 0 : v;
    return (Math.round(r * Math.pow(10, d == null ? 2 : d)) / Math.pow(10, d == null ? 2 : d)).toString();
  };
  JW.deg = r => r * 180 / Math.PI;
  JW.rad = d => d * Math.PI / 180;

  /* ---------- 安全表达式求值 ---------- */
  const FN = {
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos,
    atan: Math.atan, sqrt: Math.sqrt, abs: Math.abs, ln: Math.log, log: Math.log10,
    exp: Math.exp, floor: Math.floor, ceil: Math.ceil, sign: Math.sign
  };
  JW.compile = function (expr) {
    if (typeof expr === 'function') return expr;
    let s = String(expr || '0');
    s = s.replace(/\^/g, '**').replace(/π/g, 'PI').replace(/×/g, '*')
      .replace(/(\d)([a-zA-Z(])/g, '$1*$2')
      .replace(/\)([a-zA-Z0-9(])/g, ')*$1');
    try {
      // 关键：把 sin/cos/abs/sqrt… 显式解构进作用域，否则表达式里的函数全是 ReferenceError
      const g = new Function('__F', 'x', 'y', 't', 'PI', 'E',
        'const {' + Object.keys(FN).join(',') + '} = __F; return (' + s + ');');
      return (x, y, t) => {
        try { return g(FN, x, y, t, Math.PI, Math.E); } catch (e) { return NaN; }
      };
    } catch (e) {
      return () => NaN;
    }
  };

  /* ---------- 公式排版（极简 TeX 子集 → HTML） ---------- */
  JW.fx = function (tex) {
    let s = String(tex == null ? '' : tex);
    s = s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    s = s.replace(/\\(frac|dfrac)\{([^{}]*)\}\{([^{}]*)\}/g, '<span class="fr"><span>$2</span><span>$3</span></span>');
    s = s.replace(/\\sqrt\{([^{}]*)\}/g, '√<span class="sq">$1</span>');
    s = s.replace(/\\pi/g, 'π').replace(/\\alpha/g, 'α').replace(/\\beta/g, 'β').replace(/\\theta/g, 'θ')
      .replace(/\\omega/g, 'ω').replace(/\\varphi/g, 'φ').replace(/\\phi/g, 'φ').replace(/\\Delta/g, 'Δ')
      .replace(/\\mu/g, 'μ').replace(/\\lambda/g, 'λ').replace(/\\times/g, '×').replace(/\\cdot/g, '·')
      .replace(/\\pm/g, '±').replace(/\\le/g, '≤').replace(/\\ge/g, '≥').replace(/\\neq/g, '≠')
      .replace(/\\Rightarrow/g, '⇒').replace(/\\to/g, '→').replace(/\\infty/g, '∞').replace(/\\angle/g, '∠')
      .replace(/\\circ/g, '°').replace(/\\left|\\right/g, '');
    s = s.replace(/\^(-?\d+|.)/g, '<sup>$1</sup>').replace(/_(\d+|.)/g, '<sub>$1</sub>');
    return s;
  };

  /* ---------- 画布：HiDPI + 数据坐标 ---------- */
  JW.Canvas = function (host, opt) {
    opt = opt || {};
    const cv = document.createElement('canvas');
    cv.className = 'jw-cv';
    host.appendChild(cv);
    const ctx = cv.getContext('2d');
    const self = {
      cv: cv, ctx: ctx,
      xr: opt.xRange || [-6.6, 6.6], yr: opt.yRange || [-4, 4],
      dpr: 1, w: 1, h: 1, pad: opt.pad || 0
    };
    function resize() {
      const r = cv.parentNode.getBoundingClientRect();
      self.dpr = Math.min(2.5, window.devicePixelRatio || 1);
      self.w = Math.max(80, r.width); self.h = Math.max(80, r.height);
      cv.width = Math.round(self.w * self.dpr); cv.height = Math.round(self.h * self.dpr);
      cv.style.width = self.w + 'px'; cv.style.height = self.h + 'px';
      ctx.setTransform(self.dpr, 0, 0, self.dpr, 0, 0);
      if (self.onresize) self.onresize();
    }
    self.resize = resize;
    self.setRange = function (xr, yr) {
      if (xr) self.xr = xr; if (yr) self.yr = yr;
    };
    self.px = x => (x - self.xr[0]) / (self.xr[1] - self.xr[0]) * self.w;
    self.py = y => self.h - (y - self.yr[0]) / (self.yr[1] - self.yr[0]) * self.h;
    self.dx = px => (px / self.w) * (self.xr[1] - self.xr[0]) + self.xr[0];
    self.dy = py => ((self.h - py) / self.h) * (self.yr[1] - self.yr[0]) + self.yr[0];
    self.sx = () => self.w / (self.xr[1] - self.xr[0]);
    self.sy = () => self.h / (self.yr[1] - self.yr[0]);
    self.clear = function (fill) {
      ctx.save(); ctx.setTransform(self.dpr, 0, 0, self.dpr, 0, 0);
      ctx.clearRect(0, 0, self.w, self.h);
      if (fill) { ctx.fillStyle = fill; ctx.fillRect(0, 0, self.w, self.h); }
      ctx.restore();
    };
    self.grid = function (step, style) {
      const C = JW.C;
      step = step || 1;
      ctx.save();
      ctx.strokeStyle = (style && style.grid) || C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      const x0 = Math.ceil(self.xr[0] / step) * step, x1 = self.xr[1];
      for (let x = x0; x <= x1; x += step) {
        const X = Math.round(self.px(x)) + .5;
        ctx.moveTo(X, 0); ctx.lineTo(X, self.h);
      }
      const y0 = Math.ceil(self.yr[0] / step) * step, y1 = self.yr[1];
      for (let y = y0; y <= y1; y += step) {
        const Y = Math.round(self.py(y)) + .5;
        ctx.moveTo(0, Y); ctx.lineTo(self.w, Y);
      }
      ctx.stroke();
      // 轴
      ctx.strokeStyle = (style && style.axis) || '#9FB0C9'; ctx.lineWidth = 1.2;
      ctx.beginPath();
      const yAx = JW.clamp(self.py(0), 0, self.h), xAx = JW.clamp(self.px(0), 0, self.w);
      ctx.moveTo(0, yAx); ctx.lineTo(self.w, yAx);
      ctx.moveTo(xAx, 0); ctx.lineTo(xAx, self.h);
      ctx.stroke();
      // 刻度数字
      if (style && style.labels !== false) {
        ctx.fillStyle = C.faint; ctx.font = '10px ' + C.sans; ctx.textAlign = 'center';
        for (let x = x0; x <= x1; x += step * Math.ceil(1 / (step * 1.4))) {
          if (Math.abs(x) < 1e-9) continue;
          ctx.fillText(JW.num(x, 1), self.px(x), JW.clamp(yAx + 13, 12, self.h - 2));
        }
        ctx.textAlign = 'right';
        for (let y = y0; y <= y1; y += step * Math.ceil(1 / (step * 1.4))) {
          if (Math.abs(y) < 1e-9) continue;
          ctx.fillText(JW.num(y, 1), xAx - 6, self.py(y) + 3);
        }
        ctx.textAlign = 'right'; ctx.fillText('x', self.w - 4, JW.clamp(yAx - 6, 12, self.h - 4));
        ctx.textAlign = 'left'; ctx.fillText('y', xAx + 5, 12);
      }
      ctx.restore();
    };
    self.plot = function (fn, style) {
      style = style || {};
      const n = style.n || Math.min(1400, Math.round(self.w * 1.4));
      ctx.save();
      ctx.beginPath(); ctx.strokeStyle = style.color || JW.C.ink;
      ctx.lineWidth = style.width || 2; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      if (style.dash) ctx.setLineDash(style.dash);
      let pen = false, prevY = null;
      for (let i = 0; i <= n; i++) {
        const x = self.xr[0] + (self.xr[1] - self.xr[0]) * i / n;
        const y = fn(x);
        if (!isFinite(y) || Math.abs(y) > 1e6) { pen = false; prevY = null; continue; }
        const X = self.px(x), Y = self.py(y);
        if (prevY != null && Math.abs(Y - prevY) > self.h * .6) pen = false;
        if (!pen) { ctx.moveTo(X, Y); pen = true; } else ctx.lineTo(X, Y);
        prevY = Y;
      }
      ctx.stroke();
      ctx.restore();
    };
    self.dot = function (x, y, style) {
      style = style || {};
      ctx.save();
      ctx.beginPath(); ctx.arc(self.px(x), self.py(y), style.r || 4, 0, 7);
      ctx.fillStyle = style.fill || JW.C.ink; ctx.fill();
      if (style.stroke) { ctx.strokeStyle = style.stroke; ctx.lineWidth = style.w || 1.5; ctx.stroke(); }
      ctx.restore();
    };
    self.line = function (x1, y1, x2, y2, style) {
      style = style || {};
      ctx.save();
      ctx.beginPath(); ctx.moveTo(self.px(x1), self.py(y1)); ctx.lineTo(self.px(x2), self.py(y2));
      ctx.strokeStyle = style.color || JW.C.ink2; ctx.lineWidth = style.width || 1.4;
      if (style.dash) ctx.setLineDash(style.dash);
      ctx.stroke(); ctx.restore();
    };
    self.arrow = function (x1, y1, x2, y2, style) {
      style = style || {};
      const a = { x: self.px(x1), y: self.py(y1) }, b = { x: self.px(x2), y: self.py(y2) };
      const ang = Math.atan2(b.y - a.y, b.x - a.x), L = style.head || 9;
      ctx.save();
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
      ctx.strokeStyle = style.color || JW.C.ink2; ctx.lineWidth = style.width || 1.6;
      if (style.dash) ctx.setLineDash(style.dash);
      ctx.stroke();
      if (style.head !== 0) {
        ctx.beginPath(); ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - L * Math.cos(ang - .42), b.y - L * Math.sin(ang - .42));
        ctx.lineTo(b.x - L * Math.cos(ang + .42), b.y - L * Math.sin(ang + .42));
        ctx.closePath(); ctx.fillStyle = style.color || JW.C.ink2; ctx.fill();
      }
      ctx.restore();
    };
    self.label = function (x, y, text, style) {
      style = style || {};
      ctx.save();
      ctx.font = (style.weight || 600) + ' ' + (style.size || 11) + 'px ' + (style.font || JW.C.sans);
      ctx.fillStyle = style.color || JW.C.ink;
      ctx.textAlign = style.align || 'left'; ctx.textBaseline = style.base || 'middle';
      ctx.fillText(text, self.px(x) + (style.ox || 0), self.py(y) + (style.oy || 0));
      ctx.restore();
    };
    self.copy = function () { return { xr: self.xr.slice(), yr: self.yr.slice() }; };
    new ResizeObserver(() => { resize(); self.render && self.render(); }).observe(cv.parentNode);
    resize();
    return self;
  };

  /* ---------- 控件 ---------- */
  JW.ui = {
    card: function (title, sub) {
      const n = JW.el('div', { class: 'jw-card' });
      if (title) n.appendChild(JW.el('div', { class: 'jw-card-h' }, JW.el('h3', {}, title).outerHTML + '<div class="jw-card-sub">' + (sub || '') + '</div>'));
      return n;
    },
    range: function (o, onChange) {
      const wrap = JW.el('label', { class: 'jw-ctl' });
      wrap.appendChild(JW.el('div', { class: 'jw-ctl-top' },
        '<span class="jw-ctl-n">' + o.label + '</span><span class="jw-ctl-v">' + JW.num(o.value, o.dec) + '</span>'));
      const inp = JW.el('input', { type: 'range', min: o.min, max: o.max, step: o.step || .1, value: o.value });
      const val = wrap.querySelector('.jw-ctl-v');
      inp.addEventListener('input', () => {
        const v = parseFloat(inp.value);
        val.textContent = JW.num(v, o.dec);
        onChange(v, wrap);
      });
      wrap.appendChild(inp);
      o.input = inp;
      return wrap;
    },
    toggle: function (label, on, cb) {
      const b = JW.el('button', { class: 'jw-btn' + (on ? ' is-on' : '') }, label);
      b.addEventListener('click', () => { on = !on; b.classList.toggle('is-on', on); cb(on); });
      return b;
    },
    chips: function (items, cur, cb) {
      const row = JW.el('div', { class: 'jw-chips' });
      items.forEach(function (it) {
        const b = JW.el('button', { class: 'jw-chip' + (it === cur ? ' is-on' : '') }, it);
        b.addEventListener('click', () => {
          row.querySelectorAll('.jw-chip').forEach(x => x.classList.remove('is-on'));
          b.classList.add('is-on'); cb(it);
        });
        row.appendChild(b);
      });
      return row;
    },
    stat: function (label, value, unit) {
      return JW.el('div', { class: 'jw-stat' },
        '<span class="jw-stat-l">' + label + '</span><span class="jw-stat-v">' + value + '</span><span class="jw-stat-u">' + (unit || '') + '</span>');
    }
  };

  /* ---------- 鼠标拖拽 ---------- */
  JW.drag = function (target, handlers) {
    let on = false, sx = 0, sy = 0, lx = 0, ly = 0;
    function pos(e) {
      const r = target.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }
    target.style.touchAction = 'none';
    target.addEventListener('pointerdown', function (e) {
      on = true; lx = e.clientX; ly = e.clientY; const p = pos(e); sx = p.x; sy = p.y;
      target.setPointerCapture && target.setPointerCapture(e.pointerId);
      handlers.down && handlers.down(p, e);
    });
    target.addEventListener('pointermove', function (e) {
      const p = pos(e);
      if (!on) { handlers.hover && handlers.hover(p, e); return; }
      handlers.move && handlers.move(p, { x: e.clientX - lx, y: e.clientY - ly }, e);
      lx = e.clientX; ly = e.clientY;
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) {
      target.addEventListener(ev, function (e) {
        if (!on) return; on = false;
        handlers.up && handlers.up(pos(e), e);
      });
    });
    target.addEventListener('wheel', function (e) {
      if (!handlers.wheel) return;
      e.preventDefault();
      handlers.wheel(e.deltaY, pos(e), e);
    }, { passive: false });
  };

  /* ---------- 步骤高亮 API ---------- */
  JW.makeApi = function (ctx) {
    const subs = [];
    return {
      C: JW.C, ctx: ctx,
      onStep: fn => subs.push(fn),
      emitStep: i => subs.forEach(fn => { try { fn(i); } catch (e) { console.warn(e); } }),
      hint: function (t) {
        const h = ctx.host.querySelector('.jw-hint');
        if (h) h.textContent = t;
      }
    };
  };

  /* ---------- 题目注册 ---------- */
  JW.addQuestions = function (list) {
    (list || []).forEach(function (q) {
      if (!q || !q.id) return;
      if (JW.questions.some(x => x.id === q.id)) return;
      JW.questions.push(q);
    });
  };
  JW.byId = id => JW.questions.filter(q => q.id === id)[0];
  JW.subjects = function () {
    const s = [];
    JW.questions.forEach(q => { if (s.indexOf(q.subject) < 0) s.push(q.subject); });
    return s;
  };
})();
