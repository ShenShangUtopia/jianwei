/* 见微 · 析题台 · 昼夜两套皮
   白天：青瓷蓝 · 纸底；夜晚：Nocturne Glassmorphism（无色玻璃 + 深夜光源 + 香槟金）。
   画布也换皮：夜间纸底透明、笔画转亮色；切主题会重挂当前视图。 */
(function () {
  const KEY = 'jw.theme';
  const NIGHT = {
    paper: 'rgba(0,0,0,0)', card: 'rgba(255,255,255,0.07)',
    ink: '#EAF1FA', ink2: '#9CC1EA',
    soft: 'rgba(234,241,250,0.66)', faint: 'rgba(234,241,250,0.44)',
    line: 'rgba(255,255,255,0.16)', line2: 'rgba(255,255,255,0.09)',
    grid: 'rgba(255,255,255,0.075)', grid2: 'rgba(255,255,255,0.05)',
    accent: '#E4B863', jade: '#7FD1B9', gold: '#E4B863',
    data: ['#E4B863', '#9CC1EA', '#6E93C4', '#3C5C86', '#22344F']
  };
  let saved = null;

  function read() { try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; } }
  function resolve() {
    const t = read();
    if (t === 'day' || t === 'night') return t;
    const h = new Date().getHours();
    return (h >= 7 && h < 19) ? 'day' : 'night';
  }
  function save(t) { try { localStorage.setItem(KEY, t); } catch (e) { } }

  function paint(theme) {
    const JW = window.JW;
    if (!JW || !JW.C) return false;
    const C = JW.C;
    if (!saved) {
      saved = {
        paper: C.paper, card: C.card, ink: C.ink, ink2: C.ink2, soft: C.soft, faint: C.faint,
        line: C.line, line2: C.line2, grid: C.grid, grid2: C.grid2,
        accent: C.accent, jade: C.jade, gold: C.gold, data: (C.data || []).slice()
      };
    }
    if (theme === 'night') {
      Object.keys(NIGHT).forEach(function (k) { C[k] = NIGHT[k]; });
    } else {
      Object.keys(saved).forEach(function (k) { C[k] = saved[k]; });
    }
    return true;
  }

  function remount() {
    try {
      const cur = window.JWApp && window.JWApp.current;
      if (cur && window.JWApp.open) window.JWApp.open(cur.id);
    } catch (e) { }
  }

  function apply(theme, rerender) {
    document.documentElement.dataset.theme = theme;
    const meta = document.querySelector('meta[name="color-scheme"]');
    if (meta) meta.setAttribute('content', theme === 'night' ? 'dark' : 'light');
    const ok = paint(theme);
    if (!ok) {
      let n = 0;
      const t = setInterval(function () { if (paint(theme) || ++n > 60) clearInterval(t); }, 20);
    }
    if (rerender) setTimeout(remount, 60);
    updateToggle(theme);
    try { document.dispatchEvent(new CustomEvent('jw-theme', { detail: { theme: theme } })); } catch (e) { }
  }

  /* 顶栏切换按钮（白天/夜晚） */
  function updateToggle(theme) {
    const b = document.getElementById('btn-theme');
    if (!b) return;
    b.textContent = theme === 'night' ? '白昼' : '夜晚';
    b.title = theme === 'night' ? '切换到白天配色' : '切换到夜晚配色';
    b.classList.toggle('is-night', theme === 'night');
  }
  function mountToggle() {
    const box = document.getElementById('top-right');
    if (!box || document.getElementById('btn-theme')) return;
    const b = document.createElement('button');
    b.id = 'btn-theme';
    b.type = 'button';
    b.className = 'jw-btn nv-theme-btn';
    b.addEventListener('click', function () {
      const next = document.documentElement.dataset.theme === 'night' ? 'day' : 'night';
      save(next);
      apply(next, true);
    });
    box.insertBefore(b, box.firstChild);
    updateToggle(document.documentElement.dataset.theme || resolve());
  }

  function ensureScene() {
    if (document.getElementById('nv-scene') || !document.body) return;
    const d = document.createElement('div');
    d.id = 'nv-scene';
    d.setAttribute('aria-hidden', 'true');
    document.body.insertBefore(d, document.body.firstChild);
  }

  // 首屏：先把 class/dataset 定下来，避免闪白
  const forced = (function () { const m = /[?&]theme=(day|night)/.exec(location.search); return m ? m[1] : ''; })();
  if (forced) save(forced);
  const initial = forced || resolve();
  document.documentElement.dataset.theme = initial;
  paint(initial);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { ensureScene(); mountToggle(); paint(initial); });
  } else {
    ensureScene();
    mountToggle();
  }
  // 顶栏被重建时补挂按钮
  setInterval(function () { mountToggle(); updateToggle(document.documentElement.dataset.theme || resolve()); }, 2500);

  window.JWTheme = { get: function () { return document.documentElement.dataset.theme || resolve(); }, set: function (t) { save(t); apply(t, true); } };
})();
