/* 2025 题库 */
(function () {
  JW.addQuestions([
    {
      id:'m-2025-nh1-03', year:2025, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'双曲线虚轴与离心率',
      stem:'若双曲线 C 的虚轴长是实轴长的 √7 倍，则 C 的离心率为（　）',
      answer:'2√2',
      steps:[
        '实轴长 2a、虚轴长 2b，得 b=√7a',
        'c^2=a^2+b^2=8a^2',
        'e=c/a=2√2'
      ],
      points:['双曲线的几何性质','a、b、c 的关系','离心率'],
      why:'虚轴长是 2b 不是 b，先把系数 2 约掉再平方，最不容易错',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'a、b、c 关系', lines:['b=√7a','c^2=a^2+b^2=8a^2','e=c/a=2√2'], steps:['先把轴长换成 a、b','再用 c^2=a^2+b^2','最后开方求 e']}
      }
    },
    {
      id:'m-2025-nh1-04', year:2025, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'正切函数图象的对称中心',
      stem:'点 (a,0)（a>0）是函数 y=2tan(x−π/3) 图象的一个对称中心，则 a 的最小值为（　）',
      answer:'π/3',
      steps:[
        '正切函数的对称中心横坐标满足 x=kπ/2',
        '令 x−π/3=kπ/2，得 a=π/3+kπ/2',
        'a>0 时取 k=0，最小值为 π/3'
      ],
      points:['正切函数图象','对称中心','参数取值'],
      why:'tan 的对称中心包含渐近线与 x 轴交点，别只记 kπ 那一类',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'对称中心的通式',
          lines:['对称中心横坐标 x=π/3+kπ/2','k=0 时 a=π/3 是最小正值','a>0 决定 k 从 0 起取'],
          steps:['写出 tan 的对称中心式','代入相位解出 a','挑出最小的正值']
        }
      }
    },
    {
      id:'m-2025-nh1-05', year:2025, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'周期偶函数求函数值',
      stem:'f(x) 是定义在 R 上、周期为 2 的偶函数，当 2≤x≤3 时 f(x)=5−2x，则 f(−3/4)=（　）',
      answer:'−1/2',
      steps:[
        '偶函数给出 f(−3/4)=f(3/4)',
        '周期 2 给出 f(3/4)=f(3/4+2)=f(11/4)',
        '11/4 落在 [2,3]，代入得 5−11/2=−1/2'
      ],
      points:['函数的奇偶性','函数的周期性','分段函数求值'],
      why:'先对称再平移，两次变形把自变量送进已知区间，顺序不能乱',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'两步进区间', lines:['f(−3/4)=f(3/4)','f(3/4)=f(11/4)','f(11/4)=5−11/2=−1/2'], steps:['先用偶性去掉负号','再用周期加 2','代入已知区间']}
      }
    },
    {
      id:'m-2025-nh1-07', year:2025, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'圆上到直线距离为 1 的点',
      stem:'若圆 x^2+(y+2)^2=r^2（r>0）上到直线 y=√3x+2 的距离为 1 的点有且仅有 2 个，则 r 的取值范围是（　）',
      answer:'(1,3)',
      steps:[
        '圆心 (0,−2) 到直线 √3x−y+2=0 的距离为 2',
        '距离为 1 的点在距直线 1 和 3 的两条平行线上',
        '圆与近线相交、与远线相离时恰有 2 个点',
        '得 1<r<3'
      ],
      points:['点到直线的距离','直线与圆的位置关系','分类讨论'],
      why:'把到直线距离为 1 翻成两条平行线，问题立刻变成圆与线的位置关系',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'两条平行线', lines:['圆心到直线距离 d=2','两条平行线距圆心 1 和 3','1<r<3 时恰好 2 个点'], steps:['先求 d','再把距离条件翻成平行线','最后比较 r 与 1、3']}
      }
    },
    {
      id:'m-2025-nh1-08', year:2025, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'对数式比大小',
      stem:'若实数 x、y、z 满足 2+log_2 x=3+log_3 y=5+log_5 z，则 x、y、z 的大小关系不可能是（　）',
      answer:'x>z>y',
      steps:[
        '设公共值为 m，把 x、y、z 都写成以 m 为指数的幂',
        '取 m=2：x=1，y=1/3，z=1/125，得 x>y>z',
        '取 m=5：x=8，y=9，z=1，得 y>x>z',
        '取 m=8：x=64，y=243，z=125，得 y>z>x',
        '三种都可能，故 x>z>y 不可能'
      ],
      points:['对数运算','指数函数单调性','特殊值排除'],
      why:'同一个 m 下比较三个指数式，取几个好算的 m 就能排除三个选项',
      view:{
        engine:'subjects', mode:'data', params:{},
        data:{
          title:'三组取值',
          lines:['m=2：1、1/3、1/125','m=5：8、9、1','m=8：64、243、125'],
          rows:[{label:'m=2 的 x',value:1},{label:'m=5 的 y',value:9},{label:'m=8 的 y',value:243}]
        }
      }
    },
    {
      id:'m-2025-nh1-14', year:2025, paper:'新课标Ⅰ卷', subject:'数学', type:'填空',
      title:'有放回取球的期望',
      stem:'箱中有 5 个相同的小球，标号 1~5。每次取一个，有放回地取三次，记至少被取出一次的球的个数为 X，则 E(X)=______。',
      answer:'61/25',
      steps:[
        '对第 i 号球设指示变量，取到过记 1，否则记 0',
        '三次都没取到它的概率为 (4/5)^3=64/125',
        '故每个指示变量的期望为 61/125',
        'E(X)=5×61/125=61/25'
      ],
      points:['离散型随机变量的期望','指示变量法','独立重复试验'],
      why:'列分布列要分三类，用指示变量把期望拆成五个 0-1 变量',
      view:{
        engine:'subjects', mode:'data', params:{},
        data:{
          title:'期望拆解',
          lines:['每个球被取到的概率 61/125','五个球相加'],
          rows:[{label:'单个球的贡献',value:0.488},{label:'E(X)',value:2.44}]
        }
      }
    },
    {
      id:'p-2025-qgj-15', year:2025, paper:'全国甲卷', subject:'物理', type:'解答',
      title:'竖直圆周运动的临界',
      stem:'质量 m=0.5 kg 的小球用长 L=0.4 m 的细绳系住在竖直平面内做圆周运动，g 取 10 m/s^2。小球恰能通过最高点，求最高点的速度和最低点时绳的张力。',
      answer:'最高点 2.0 m/s；最低点张力 30 N',
      steps:[
        '恰能过最高点：重力提供向心力，mg=mv^2/L',
        '得最高点速度 v=√(gL)=2.0 m/s',
        '最高点到最低点机械能守恒，v_低^2=v^2+4gL=20',
        '最低点 T−mg=mv_低^2/L，得 T=30 N'
      ],
      points:['竖直圆周运动','向心力','机械能守恒'],
      why:'恰能通过就是绳张力为零，最高点速度由 gL 唯一确定',
      note:'改编自 2025 年全国甲卷圆周运动同型题',
      view:{engine:'physics', kind:'circular', params:{m:0.5,r:0.4,g:10,v0:2}, cue:'最高点速度与最低点绳张力'}
    },
    {
      id:'p-2025-xkb-18', year:2025, paper:'新课标卷', subject:'物理', type:'解答',
      title:'弹性正碰的速度',
      stem:'质量 m_1=1.0 kg 的小球以 v_0=4.0 m/s 的速度与静止的质量 m_2=3.0 kg 的小球发生弹性正碰，求碰后两球的速度。',
      answer:'v_1=−2.0 m/s，v_2=2.0 m/s',
      steps:[
        '动量守恒：m_1v_0=m_1v_1+m_2v_2',
        '弹性碰撞中接近速度等于分离速度',
        '联立得 v_1=(m_1−m_2)v_0/(m_1+m_2)=−2.0 m/s',
        'v_2=2m_1v_0/(m_1+m_2)=2.0 m/s'
      ],
      points:['动量守恒','弹性碰撞','碰后速度公式'],
      why:'弹性碰撞直接套两个结论式，比联立二次方程省一半时间',
      note:'改编自 2025 年新课标卷碰撞同型题',
      view:{engine:'physics', kind:'collision', params:{m1:1,m2:3,m:1,v1:4,v2:0}, cue:'碰后两球速度'}
    },
    {
      id:'p-2025-qgy-16', year:2025, paper:'全国乙卷', subject:'物理', type:'解答',
      title:'等量异种电荷中点场强',
      stem:'真空中两个等量异种点电荷相距 0.20 m，电荷量大小均为 1.0×10^−8 C，静电力常量 k=9.0×10^9 N·m^2/C^2。求两电荷连线中点的电场强度。',
      answer:'1.8×10^4 N/C，由正电荷指向负电荷',
      steps:[
        '中点到每个电荷的距离 r=0.10 m',
        '每个电荷在中点产生 E=kq/r^2=9.0×10^3 N/C',
        '两个场强方向相同，直接相加',
        'E=1.8×10^4 N/C，方向由正电荷指向负电荷'
      ],
      points:['点电荷场强','电场的叠加','方向判断'],
      why:'等量异种电荷中点是最简单的叠加模型：同向相加，不用分解',
      note:'改编自 2025 年全国乙卷电场叠加同型题',
      view:{engine:'physics', kind:'efield', params:{E:18000,q:1e-8,r:0.1}, cue:'连线中点场强大小与方向'}
    },
    {
      id:'c-2025-xkb-09', year:2025, paper:'新课标卷', subject:'化学', type:'解答',
      title:'电解硫酸铜的阳极产物',
      stem:'用惰性电极电解 0.50 L 0.20 mol/L 的 CuSO_4 溶液，当阴极析出 1.6 g 铜时，阳极产生标准状况下 O_2 的体积是多少？（Cu 的相对原子质量取 64）',
      answer:'0.28 L',
      steps:[
        '阴极：Cu^2++2e^−=Cu，1.6 g 铜为 0.025 mol',
        '所以转移电子 0.05 mol',
        '阳极：4OH^−−4e^−=O_2↑+2H_2O，O_2 为 0.0125 mol',
        '标准状况下体积 0.0125×22.4=0.28 L'
      ],
      points:['电解池','电子守恒','气体摩尔体积'],
      why:'电解计算只需一条电子守恒线，两极各自配平后按电子数对接',
      note:'改编自 2025 年全国甲卷电解计算同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'两极反应',
          lines:['阴极：Cu2++2e−=Cu','阳极：4OH−−4e−=O2↑+2H2O','电子守恒：转移 0.05 mol'],
          steps:['先算转移电子','再按半反应求 O2','最后换标准状况体积']
        }
      }
    },
    {
      id:'c-2025-qgy-13', year:2025, paper:'全国乙卷', subject:'化学', type:'解答',
      title:'由 pH 求电离常数',
      stem:'常温下，0.10 mol/L 的 CH_3COOH 溶液的 pH 约为 3.0。求该温度下 CH_3COOH 的电离常数 K_a（保留 1 位有效数字）。',
      answer:'K_a≈1×10^−5',
      steps:[
        'pH=3.0 给出 c(H^+)=1.0×10^−3 mol/L',
        '弱酸电离度很小，平衡浓度约等于 0.10 mol/L',
        'K_a=c(H^+)^2/c=1.0×10^−6/0.10',
        '得 K_a≈1×10^−5'
      ],
      points:['弱电解质的电离','pH 与氢离子浓度','电离常数'],
      why:'弱酸近似处理的前提是电离度小，先估 α 再决定能不能近似',
      note:'改编自 2025 年全国乙卷电离常数同型题',
      view:{
        engine:'subjects', mode:'titration', params:{c:0.1,pKa:5,V0:20},
        data:{title:'pH 与 Ka', lines:['c(H+)=10^-3 mol/L','Ka≈c(H+)^2/c=1×10^-5']}
      }
    },
    {
      id:'b-2025-qgj-29', year:2025, paper:'全国甲卷', subject:'生物', type:'解答',
      title:'净光合与真正光合',
      stem:'将某植物叶片置于密闭容器中，黑暗条件下 CO_2 释放速率为 4 mg/(h·100 cm^2)，适宜光照下 CO_2 吸收速率为 6 mg/(h·100 cm^2)。求光照下叶片的真正光合速率。',
      answer:'10 mg/(h·100 cm^2)',
      steps:[
        '黑暗下 CO_2 释放速率即呼吸速率 4',
        '光照下 CO_2 吸收速率是净光合速率 6',
        '真正光合=净光合+呼吸',
        '得 6+4=10 mg/(h·100 cm^2)'
      ],
      points:['光合作用','细胞呼吸','净光合与真光合'],
      why:'密闭容器里测到的是净量，问真正光合就必须把呼吸加回去',
      note:'改编自 2025 年全国甲卷光合同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'三个速率', lines:['呼吸速率：4','净光合速率：6','真正光合速率：10'], steps:['先分清测得的是净量','再把呼吸加回']}
      }
    },
    {
      id:'b-2025-xkb-32', year:2025, paper:'新课标卷', subject:'生物', type:'解答',
      title:'红绿色盲的再生育概率',
      stem:'人类红绿色盲由 X 染色体上的隐性基因控制。一对表现型正常的夫妇生了一个色盲男孩，若再生育一个孩子，该孩子是色盲的概率是多少？',
      answer:'1/4（已知是男孩时为 1/2）',
      steps:[
        '色盲男孩基因型 X^bY，其 X^b 来自母亲',
        '父亲正常为 X^BY，母亲表现正常为 X^BX^b',
        '子代色盲只能是 X^bY，概率 1/2×1/2=1/4',
        '若已知是男孩，则概率为 1/2'
      ],
      points:['伴性遗传','基因型推断','概率计算'],
      why:'已生色盲男孩只用来推母亲基因型，不能把已有孩子的概率算进去',
      note:'改编自 2025 年新课标卷伴性遗传同型题',
      view:{
        engine:'subjects', mode:'genetics', params:{},
        data:{cross:{father:'XBY',mother:'XBXb',trait:'红绿色盲',dominant:'B'}}
      }
    },
    {
      id:'y-2025-nh1-23', year:2025, paper:'新课标Ⅰ卷', subject:'语文', type:'材料',
      title:'从沉默到歌唱',
      stem:'他想要给孩子们唱上一段，可是心里直翻腾，开不了口。（老舍《鼓书艺人》）假如我是一只鸟，我也应该用嘶哑的喉咙歌唱。（艾青《我爱这土地》）我要以带血的手和你们一一拥抱，因为一个民族已经起来。（穆旦《赞美》）以上材料引发了你怎样的联想与思考？请写一篇文章。',
      answer:'立意：从沉默到发声，个体与民族的精神觉醒',
      steps:[
        '三则材料是一条线：欲言、发声、拥抱',
        '辨析开不了口的原因：苦难压住了表达',
        '再论嘶哑地歌唱：表达本身就是担当',
        '收束到民族觉醒与个体选择的共振'
      ],
      points:['多材料作文','意象解读','家国情怀'],
      why:'三则材料不是并列而是递进：由压抑到发声再到行动',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'发声',
          material:'老舍、艾青、穆旦三则材料构成递进',
          tasks:['自拟标题','不少于 800 字','结合三则材料'],
          angles:['沉默与呐喊','个体表达与时代','以行动完成表达'],
          outline:{thesis:'从沉默到发声，是个体与民族的共同觉醒', points:[
            {text:'沉默源于苦难的重量',evidences:['老舍笔下欲唱又止的艺人','压抑之下的失语']},
            {text:'歌唱是明知嘶哑仍要表达',evidences:['艾青用嘶哑的喉咙歌唱','表达本身就是担当']},
            {text:'拥抱把表达变成行动',evidences:['穆旦带血的手与拥抱','民族起来后的相互确认']}
          ]}
        }
      }
    },
    {
      id:'e-2025-nh1-46', year:2025, paper:'新课标Ⅰ卷', subject:'英语', type:'材料',
      title:'英语报专栏约稿',
      stem:'假定你是李华，你校英文报将开设 My Hometown 专栏。请给外教 Chris 写一封邮件，邀请他撰写一篇介绍其家乡的短文，并说明字数与截稿时间。词数 80 左右。',
      answer:'Email inviting Chris to write',
      steps:[
        '开头说明专栏开设与写信目的',
        '介绍专栏主题与读者对象',
        '说明要求：150 词左右，本月底截稿',
        '结尾感谢并期待回复'
      ],
      points:['应用文写作','约稿信','信息完整'],
      why:'约稿信的关键是把写什么、写多长、什么时候交说清楚',
      note:'改编自 2025 年新课标Ⅰ卷应用文同型题',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'A column invitation',
          material:'Invite Chris to write about his hometown for the school newspaper',
          tasks:['about 80 words','give length and deadline'],
          angles:['state purpose','clear requirements','polite closing'],
          outline:{thesis:'A good invitation states purpose, requirements and deadline clearly', points:[
            {text:'Introduce the column',evidences:['My Hometown for the school paper','Readers are students and teachers']},
            {text:'Explain what to write',evidences:['About 150 words on his hometown','Photos are welcome']},
            {text:'Give the deadline',evidences:['By the end of this month','Looking forward to his reply']}
          ]}
        }
      }
    },
    {
      id:'h-2025-xkz-30', year:2025, paper:'新课标卷', subject:'历史', type:'材料',
      title:'科举制与社会流动',
      stem:'阅读材料：宋代科举“取士不问家世”，寒门子弟通过考试入仕者明显增多，士人阶层迅速扩大。结合所学，说明科举制对宋代社会的影响。',
      answer:'扩大统治基础，促进社会流动，也造成冗官',
      steps:[
        '科举以考试成绩取人，打破门第限制',
        '寒门入仕增多，社会流动性增强',
        '士人阶层扩大，推动文化教育',
        '官员数量膨胀，带来冗官与财政负担'
      ],
      points:['科举制','宋代政治','社会流动'],
      why:'影响题要一分为二：制度进步与行政成本同时说',
      note:'改编自 2025 年新课标卷文综同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:960,title:'北宋建立',note:'重文轻武'},
          {year:977,title:'扩大取士',note:'录取名额大增'},
          {year:1071,title:'王安石变法',note:'改革科举内容'}
        ]}
      }
    },
    {
      id:'g-2025-xkz-37', year:2025, paper:'新课标卷', subject:'地理', type:'材料',
      title:'地中海气候的成因',
      stem:'某地位于大陆西岸 30°~40° 之间，夏季炎热干燥，冬季温和多雨。判断该地气候类型并说明成因。',
      answer:'地中海气候；副高与西风带交替控制',
      steps:[
        '纬度 30°~40° 大陆西岸，指向地中海气候',
        '夏季气压带风带北移，受副热带高压控制，炎热干燥',
        '冬季西风带南移控制该地，温和多雨',
        '成因核心是气压带风带的季节移动'
      ],
      points:['地中海气候','气压带风带','气候成因'],
      why:'气候成因题先定位纬度与海陆位置，再落到控制该地的气压带风带',
      note:'改编自 2025 年新课标卷气候同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.35,y:0.35,label:'该地'},
            {x:0.58,y:0.2,label:'副高（夏）'},
            {x:0.6,y:0.72,label:'西风带（冬）'}
          ],
          arrows:[
            {x1:0.58,y1:0.2,x2:0.35,y2:0.35,label:'夏季控制'},
            {x1:0.6,y1:0.72,x2:0.35,y2:0.35,label:'冬季控制'}
          ]
        }
      }
    }
  ]);
})();
