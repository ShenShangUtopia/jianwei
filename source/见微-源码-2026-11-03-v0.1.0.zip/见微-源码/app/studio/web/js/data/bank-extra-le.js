/* 补充题库：语文 / 英语 / 历史 / 地理（2023—2025）
   视图数据约定：
   - poem：顶层 lines/images/emotion 供查看，情感曲线实际读 data.poem.emotion，故两处同步；
   - syntax：tree 用节点数组 [{role,text,main,children}]，视图按数组逐层渲染；
   - timeline：events 的 desc 用于事件说明，note 为简短标签；
   - data：使用 rows（现有 data 视图只认 rows），不是 series。 */
(function () {
  JW.addQuestions([
    /* ==================== 语文 ==================== */
    {
      id:'y-2023-b-01', year:2023, paper:'全国乙卷', subject:'语文', type:'单选',
      title:'文言实词：劝学四词辨析',
      stem:'下列对《劝学》中加点词语的解释，不正确的一项是（　）A．假舟楫者，非能水也　假：借助 B．而绝江河　绝：横渡 C．锲而不舍　锲：雕刻 D．金石可镂　镂：镶嵌',
      answer:'D（“镂”意为雕刻，不是镶嵌）',
      steps:[
        '假：借助舟船，与“假舆马者”同义',
        '绝：横渡，如“横绝峨眉巅”',
        '锲：用刀雕刻，锲而不舍即不停雕刻',
        '镂：也是雕刻，D 释为“镶嵌”错误'
      ],
      points:['文言实词','语境推断','课内互证'],
      why:'四个词都在《劝学》里，用课内注释互证最快',
      note:'改编自 2023 年全国乙卷文言实词同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'实词四步推断', lines:['先看词性','再代入语境','课内例句互证','排除不合语境项']}
      }
    },
    {
      id:'y-2024-b-02', year:2024, paper:'新课标Ⅰ卷', subject:'语文', type:'单选',
      title:'文言断句：师者三处断',
      stem:'文中画波浪线的部分需要断句，正确的一项是（　）原句：师者所以传道受业解惑也人非生而知之者孰能无惑 A．师者所以／传道受业解惑也／人非生而知之者孰／能无惑 B．师者／所以传道受业解惑也／人非生而知之者／孰能无惑 C．师者所以传道／受业解惑也人非／生而知之者／孰能无惑 D．师者／所以传道受业／解惑也人非生／而知之者孰能无惑',
      answer:'B',
      steps:[
        '先找主谓：“师者”是主语，后接判断谓语',
        '“所以……也”是固定判断句式，整体不断',
        '“人非生而知之者”主谓宾完整，独立成句',
        '“孰能无惑”以疑问代词领起，单独成句'
      ],
      points:['文言断句','固定句式','主谓分析'],
      why:'断句先抓主谓与固定句式，“……也”后多是句末',
      note:'改编自 2024 年新课标Ⅰ卷文言断句同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'断句四看', lines:['看主谓','看虚词','看固定句式','通读验证']}
      }
    },
    {
      id:'y-2024-b-03', year:2024, paper:'全国甲卷', subject:'语文', type:'简答',
      title:'登高颔联的写景艺术',
      stem:'阅读杜甫《登高》，赏析颔联“无边落木萧萧下，不尽长江滚滚来”的写景艺术。',
      answer:'落木与长江对举，时空交织，境界阔大，为下文悲秋蓄势。',
      steps:[
        '落木写秋山，长江写流水，一纵一横',
        '“无边”“不尽”拓展空间与时间的纵深',
        '萧萧、滚滚叠词摹声摹态，声势逼人',
        '阔大之景反衬“悲秋作客”的孤苦'
      ],
      points:['意象组合','叠词炼字','以景衬情'],
      why:'写景题先拆意象与时空，再落到它对情感的作用',
      note:'改编自 2024 年全国甲卷古诗鉴赏同型题',
      view:{
        engine:'subjects', mode:'poem', params:{},
        data:{
          title:'登高', author:'杜甫',
          lines:['风急天高猿啸哀','渚清沙白鸟飞回','无边落木萧萧下','不尽长江滚滚来','万里悲秋常作客','百年多病独登台','艰难苦恨繁霜鬓','潦倒新停浊酒杯'],
          images:[{word:'落木',line:2},{word:'长江',line:3},{word:'猿啸',line:0},{word:'霜鬓',line:6}],
          emotion:[0.40,0.35,0.25,0.30,0.18,0.12,0.15,0.20],
          poem:{emotion:[0.40,0.35,0.25,0.30,0.18,0.12,0.15,0.20]}
        }
      }
    },
    {
      id:'y-2025-b-04', year:2025, paper:'新课标Ⅰ卷', subject:'语文', type:'简答',
      title:'山居秋暝的“诗中有画”',
      stem:'王维《山居秋暝》中“明月松间照，清泉石上流”与“竹喧归浣女，莲动下渔舟”如何体现“诗中有画”？',
      answer:'以月、松、泉、石构成静景，以竹喧、莲动引入人事，动静相衬，画面清幽。',
      steps:[
        '前联取月、松、泉、石，色彩清冷',
        '月光自上而下，泉水自石上流，有层次',
        '后联以竹喧、莲动写人，先声后人',
        '动静相衬，画面因此活起来'
      ],
      points:['意象','动静结合','诗中有画'],
      why:'“诗中有画”要答出画面层次与动静关系，不能只说很美',
      note:'改编自 2025 年新课标Ⅰ卷古诗鉴赏同型题',
      view:{
        engine:'subjects', mode:'poem', params:{},
        data:{
          title:'山居秋暝', author:'王维',
          lines:['空山新雨后','天气晚来秋','明月松间照','清泉石上流','竹喧归浣女','莲动下渔舟','随意春芳歇','王孙自可留'],
          images:[{word:'明月',line:2},{word:'清泉',line:3},{word:'竹喧',line:4},{word:'莲动',line:5},{word:'王孙',line:7}],
          emotion:[0.72,0.68,0.80,0.78,0.85,0.83,0.70,0.75],
          poem:{emotion:[0.72,0.68,0.80,0.78,0.85,0.83,0.70,0.75]}
        }
      }
    },
    {
      id:'y-2025-b-05', year:2025, paper:'新课标Ⅰ卷', subject:'语文', type:'简答',
      title:'语用：成分残缺与语序',
      stem:'下面语段有两处语病，请找出并修改。①通过这次社区志愿活动，使我体会到基层工作的不易。②志愿者为老人不仅整理了房间，而且陪他们聊天，倾听他们的故事。③活动结束后，大家纷纷表示要把志愿精神带到日常生活中去。',
      answer:'①删去“通过”或“使”；②“不仅”移到“为老人”之前。',
      steps:[
        '①“通过……使……”让句子丢了主语',
        '删“通过”让“这次活动”作主语，或删“使”',
        '②前后分句主语都是“志愿者”，关联词应紧随主语',
        '改为“志愿者不仅为老人整理了房间”'
      ],
      points:['成分残缺','关联词位置','病句修改'],
      why:'病句先查主干，主语被介词吞掉是最常见的残缺',
      note:'改编自 2025 年新课标Ⅰ卷语言文字运用同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'病句两步走', lines:['压缩找主干','查搭配与语序','补出残缺成分']}
      }
    },
    {
      id:'y-2023-b-06', year:2023, paper:'新课标Ⅰ卷', subject:'语文', type:'简答',
      title:'语用：长句化短句',
      stem:'把下面的长句改写成四个语意连贯的短句，可调整语序、增删少量词语，不得改变原意。原句：那是一个被夜雨洗过的、弥漫着青草气息的、安静得能听见露珠坠落的清晨。',
      answer:'那是一个清晨。夜雨刚洗过，空气里弥漫着青草的气息。四周安静得能听见露珠坠落。',
      steps:[
        '先抽主干：那是一个清晨',
        '把三个定语拆成独立分句',
        '按“雨后—气味—声音”排序，语意递进',
        '补主语“空气”“四周”，保证句子完整'
      ],
      points:['长句化短句','定语拆分','语意连贯'],
      why:'拆长句先提主干，再让每个定语都能独立成句',
      note:'改编自 2023 年新课标Ⅰ卷语言文字运用同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'长句化短句', lines:['提出主干','定语变分句','补出主语','按逻辑排序']}
      }
    },
    {
      id:'y-2024-b-07', year:2024, paper:'新课标Ⅰ卷', subject:'语文', type:'简答',
      title:'信息类文本：古籍数字化',
      stem:'阅读材料，概括数字技术让古籍“活起来”的三个层面。材料：高清扫描与数据库建设，使孤本善本得以永久保存；知识标引与检索工具，让普通读者也能按需查找；虚拟现实与短视频，则把静态文字转成可感可知的场景。',
      answer:'保存层面（数字化存续）、传播层面（检索与共享）、阐释层面（场景化呈现）。',
      steps:[
        '材料三句对应三个层面，逐句提取核心动词',
        '第一层是扫描入库，解决“存”的问题',
        '第二层是标引检索，解决“用”的问题',
        '第三层是场景转化，解决“懂”的问题'
      ],
      points:['信息筛选','层次概括','数字人文'],
      why:'概括题先看材料分几层，每层抓一个核心动词',
      note:'改编自 2024 年新课标Ⅰ卷信息类文本同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'三个层面', lines:['数字化保存','知识标引与共享','场景化阐释']}
      }
    },
    {
      id:'y-2025-b-08', year:2025, paper:'新课标Ⅰ卷', subject:'语文', type:'简答',
      title:'阅读调查数据的论证作用',
      stem:'材料引用某市中学生课外阅读调查：每天阅读不足 30 分钟占 52%，30—60 分钟占 31%，60 分钟以上占 17%。作者引用这组数据意在说明什么？请简要分析。',
      answer:'用数据说明中学生课外阅读时间普遍不足，为下文倡导“每天读一点”提供事实依据。',
      steps:[
        '三项相加为 100%，先看分布重心',
        '52% 集中在不足 30 分钟，问题在“量”',
        '60 分钟以上仅 17%，对照出差距',
        '数据作论据，支撑“阅读时间不足”的判断'
      ],
      points:['数据论证','信息类文本','观点与材料'],
      why:'数据题不能只复述数字，要答出它支撑了什么观点',
      note:'数据为示例，改编自 2025 年新课标Ⅰ卷信息类文本同型题',
      view:{
        engine:'subjects', mode:'data', params:{},
        data:{
          title:'每日课外阅读时长占比（%）',
          rows:[{label:'不足30分钟',value:52},{label:'30—60分钟',value:31},{label:'60分钟以上',value:17}]
        }
      }
    },
    {
      id:'y-2023-b-09', year:2023, paper:'新课标Ⅱ卷', subject:'语文', type:'材料',
      title:'青少年需要自己的空间',
      stem:'本试卷语言文字运用Ⅱ提到的“安静一下不被打扰”的想法，在当代青少年中也不鲜见。青少年在学习、生活中，有时希望有一个自己的空间，放松，沉淀，成长。请结合以上材料写一篇文章。',
      answer:'立意：给成长留一处安静的空间，在独处中放松、沉淀、成长。',
      steps:[
        '抓关键词：自己的空间、放松、沉淀、成长',
        '辨析“空间”既是物理的，也是心理的',
        '论证独处不是逃避，而是自我整理',
        '落到分寸：安静与交往、自由与责任'
      ],
      points:['材料作文','独处与成长','思辨'],
      why:'材料给了“放松—沉淀—成长”的递进，文章要写出层次',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'安静的空间',
          material:'青少年希望有一个自己的空间，放松、沉淀、成长',
          tasks:['自拟标题','不少于 800 字','结合材料'],
          angles:['独处的价值','安静与交往的平衡','成长的自我整理'],
          outline:{thesis:'给成长留一处安静的空间', points:[
            {text:'空间让情绪得以放松',evidences:['独处时的自我对话','暂时退出比较场']},
            {text:'空间让经验得以沉淀',evidences:['写日记整理一天的感受','读书时不被消息打断']},
            {text:'空间最终指向成长',evidences:['安静之后的主动选择','独处与交往相互补充']}
          ]}
        }
      }
    },
    {
      id:'y-2024-b-10', year:2024, paper:'新课标Ⅱ卷', subject:'语文', type:'材料',
      title:'抵达未知之境',
      stem:'本试卷现代文阅读Ⅰ提到，长久以来，人们只能看到月球固定朝向地球的一面，“嫦娥四号”探月任务揭开了月背的神秘面纱；随着“天问一号”飞离地球，航天人的目光又投向遥远的深空……正如人类的太空之旅，我们每个人也都在不断抵达未知之境。这引发了你怎样的联想与思考？请写一篇文章。',
      answer:'立意：探索未知，是人和社会前行的动力。',
      steps:[
        '材料由航天探索引到“每个人”的未知之境',
        '明确“未知”既指外部世界，也指自我边界',
        '论证抵达未知需要好奇、勇气与准备',
        '收束：探索不是冒险，而是有准备的出发'
      ],
      points:['材料作文','探索精神','类比论证'],
      why:'材料用航天类比个人，文章不能只写航天',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'未知之境',
          material:'从月背探测到深空飞行，人类不断抵达未知之境',
          tasks:['自拟标题','不少于 800 字','结合材料'],
          angles:['探索的勇气','未知与已知的边界','有准备的出发'],
          outline:{thesis:'抵达未知，是人与世界共同生长的方式', points:[
            {text:'未知召唤好奇心',evidences:['月背曾是不可见的一面','提问先于答案']},
            {text:'抵达需要勇气与准备',evidences:['航天工程的长期积累','失败后的再次出发']},
            {text:'个人的未知同样值得抵达',evidences:['走出熟悉的学习区','在尝试中重画能力边界']}
          ]}
        }
      }
    },
    {
      id:'y-2025-b-11', year:2025, paper:'新课标Ⅰ卷', subject:'语文', type:'简答',
      title:'书愤尾联的用典与情感',
      stem:'阅读陆游《书愤》，分析尾联“出师一表真名世，千载谁堪伯仲间”的用典意图与情感。',
      answer:'借诸葛亮《出师表》自况，抒发报国无门的悲愤与不甘。',
      steps:[
        '尾联用诸葛亮上《出师表》北伐的典故',
        '“真名世”赞其名垂后世，是仰慕',
        '“谁堪伯仲间”反问，暗指当世无人',
        '以古人之壮反衬自身之衰，悲愤更深'
      ],
      points:['用典','对比','爱国情怀'],
      why:'用典题要答出“借谁”和“反衬什么”，不能只翻译典故',
      note:'改编自 2024 年全国甲卷古诗鉴赏同型题',
      view:{
        engine:'subjects', mode:'poem', params:{},
        data:{
          title:'书愤', author:'陆游',
          lines:['早岁那知世事艰','中原北望气如山','楼船夜雪瓜洲渡','铁马秋风大散关','塞上长城空自许','镜中衰鬓已先斑','出师一表真名世','千载谁堪伯仲间'],
          images:[{word:'中原',line:1},{word:'楼船',line:2},{word:'铁马',line:3},{word:'长城',line:4},{word:'衰鬓',line:5},{word:'出师表',line:6}],
          emotion:[0.75,0.78,0.86,0.90,0.40,0.28,0.45,0.50],
          poem:{emotion:[0.75,0.78,0.86,0.90,0.40,0.28,0.45,0.50]}
        }
      }
    },

    /* ==================== 英语 ==================== */
    {
      id:'e-2024-b-01', year:2024, paper:'新课标Ⅰ卷', subject:'英语', type:'填空',
      title:'语法填空：故宫三空',
      stem:'在空白处填入 1 个适当的单词或括号内单词的正确形式：The Forbidden City, ___ (complete) in 1420, served as the home of emperors for nearly 500 years. Today it ___ (visit) by millions of people every year, ___ (attract) tourists from all over the world.',
      answer:'completed；is visited；attracting',
      steps:[
        '第一空与主语是被动关系，用过去分词 completed',
        '第二空讲现在常态，主语 it 与 visit 是被动',
        '第三空作伴随状语，主动关系用现在分词 attracting',
        '先判成分，再定时态语态，最后查主被动'
      ],
      points:['非谓语动词','被动语态','现在分词作状语'],
      why:'语法填空先判句子成分，再定主被动与时态',
      note:'改编自 2024 年新课标Ⅰ卷语法填空同型题',
      view:{
        engine:'subjects', mode:'syntax', params:{},
        data:{
          sentence:'The Forbidden City, completed in 1420, served as the home of emperors for nearly 500 years.',
          tree:[
            {role:'主语',text:'The Forbidden City',main:true,children:[{role:'非谓语',text:'completed in 1420'}]},
            {role:'谓语',text:'served',main:true},
            {role:'表语',text:'as the home of emperors',main:true},
            {role:'状语',text:'for nearly 500 years',main:true}
          ]
        }
      }
    },
    {
      id:'e-2024-b-02', year:2024, paper:'新课标Ⅰ卷', subject:'英语', type:'简答',
      title:'三个从句套叠的长句',
      stem:'分析句子结构并说明主干：What makes the discovery so remarkable is that it challenges the assumption that early humans lived in isolated groups.',
      answer:'主干是 What 引导的主语从句 + is + that 引导的表语从句；assumption 后接同位语从句。',
      steps:[
        '全句主干是“主语从句 + is + 表语从句”',
        'What makes the discovery so remarkable 作主语',
        'that it challenges the assumption 作表语',
        'assumption 后的 that 从句解释其内容，是同位语从句'
      ],
      points:['主语从句','表语从句','同位语从句'],
      why:'先找系动词 is，它两边各是一个从句，主干立刻清楚',
      note:'改编自 2024 年新课标Ⅰ卷阅读长难句同型题',
      view:{
        engine:'subjects', mode:'syntax', params:{},
        data:{
          sentence:'What makes the discovery so remarkable is that it challenges the assumption that early humans lived in isolated groups.',
          tree:[
            {role:'主语从句',text:'What makes the discovery so remarkable',main:true,children:[
              {role:'谓',text:'makes'},{role:'宾',text:'the discovery'},{role:'宾补',text:'so remarkable'}
            ]},
            {role:'系动词',text:'is',main:true},
            {role:'表语从句',text:'that it challenges the assumption',main:true,children:[
              {role:'主',text:'it'},{role:'谓',text:'challenges'},{role:'宾',text:'the assumption'},
              {role:'同位语从句',text:'that early humans lived in isolated groups'}
            ]}
          ]
        }
      }
    },
    {
      id:'e-2025-b-03', year:2025, paper:'新课标Ⅰ卷', subject:'英语', type:'填空',
      title:'语法填空：高铁三空',
      stem:"在空白处填入 1 个适当的单词或括号内单词的正确形式：China's high-speed railway network, ___ (stretch) over 40,000 kilometres, is the longest in the world. It ___ (build) at an astonishing speed since 2008, ___ (make) travel much easier for ordinary people.",
      answer:'stretching；has been built；making',
      steps:[
        '第一空说明网络延伸，主动关系用现在分词',
        'since 2008 提示现在完成时，网络是被建的',
        '第三空作结果状语，用现在分词 making',
        '先判成分，再定时态，最后查主被动'
      ],
      points:['现在分词','现在完成时的被动','结果状语'],
      why:'三个空分别考非谓语、时态语态和状语，逐空判成分',
      note:'改编自 2025 年新课标Ⅰ卷语法填空同型题',
      view:{
        engine:'subjects', mode:'syntax', params:{},
        data:{
          sentence:"China's high-speed railway network, stretching over 40,000 kilometres, is the longest in the world.",
          tree:[
            {role:'主语',text:"China's high-speed railway network",main:true,children:[{role:'非谓语',text:'stretching over 40,000 kilometres'}]},
            {role:'系动词',text:'is',main:true},
            {role:'表语',text:'the longest',main:true,children:[{role:'范围',text:'in the world'}]}
          ]
        }
      }
    },
    {
      id:'e-2025-b-04', year:2025, paper:'新课标Ⅰ卷', subject:'英语', type:'单选',
      title:'七选五：段中句选择',
      stem:'阅读下面短文，从 A—E 中选出能填入空白处的最佳选项（节选）。Many students find it hard to start studying after a long break. ___ They wait until they feel ready, and that moment rarely comes. A simple way out is to begin with a task that takes only five minutes. A. This is why they often put things off. B. They believe they need perfect conditions. C. Others prefer to study in groups. D. However, short tasks can also be boring. E. The habit matters more than the mood.',
      answer:'B',
      steps:[
        '看空格后 They wait until they feel ready',
        '空处应解释“为什么要等”，与后句构成因果',
        'B 项“需要完美条件”与“等状态”同义复现',
        '代入通读，逻辑与代词指代都通顺'
      ],
      points:['七选五','逻辑衔接','同义复现'],
      why:'七选五先看空格前后连接词，再找同义复现和代词线索',
      note:'改编自 2025 年新课标Ⅰ卷七选五同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'七选五四步', lines:['看空格位置','抓连接词','找同义复现','代入通读']}
      }
    },
    {
      id:'e-2024-b-05', year:2024, paper:'新课标Ⅱ卷', subject:'英语', type:'材料',
      title:'邀请外教体验端午',
      stem:'假定你是李华，你校将于下周六举办端午文化体验活动。请给外教 Chris 写一封邮件，邀请他参加，并介绍活动内容与时间地点。词数 80 左右。',
      answer:'邀请邮件：说明活动、内容与期待。',
      steps:[
        '开头问候并说明写信目的：invite him',
        '交代时间地点：next Saturday, school hall',
        '介绍活动：make zongzi, watch dragon boat race',
        '结尾期待回复并表达欢迎'
      ],
      points:['应用文写作','邀请信','文化介绍'],
      why:'邀请信把“什么事、何时何地、为什么值得来”说清即可',
      note:'改编自 2024 年新课标Ⅱ卷应用文同型题',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'A Dragon Boat Festival invitation',
          material:'Invite Chris to a Dragon Boat Festival activity',
          tasks:['about 80 words','cover time, place and activities'],
          angles:['purpose first','clear information','warm tone'],
          outline:{thesis:'A good invitation is clear about what, when and why', points:[
            {text:'State the purpose',evidences:['Invite him to the festival activity','Say why his presence matters']},
            {text:'Give the details',evidences:['Next Saturday, school hall','Make zongzi and watch a dragon boat race']},
            {text:'Close warmly',evidences:['Ask for a reply','Express thanks in advance']}
          ]}
        }
      }
    },
    {
      id:'e-2025-b-06', year:2025, paper:'新课标Ⅰ卷', subject:'英语', type:'材料',
      title:'回信介绍课外活动',
      stem:'假定你是李华，外教 Chris 来信询问中国中学生的课外活动。请给他回信，介绍你们学校的两项课外活动，并说明你从中获得的收获。词数 80 左右。',
      answer:'回信：介绍社团与志愿服务，写出收获。',
      steps:[
        '开头感谢来信并点明回信目的',
        '介绍活动一：社团活动，如英语角',
        '介绍活动二：志愿服务，如社区助老',
        '写收获：时间管理、沟通与责任'
      ],
      points:['应用文写作','回信','要点完整'],
      why:'回信先回应对方问题，再补自己的感受，信息才完整',
      note:'改编自 2025 年新课标Ⅰ卷应用文同型题',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'A reply about after-class activities',
          material:'Chris asks about after-class activities in Chinese schools',
          tasks:['about 80 words','cover two activities and your gains'],
          angles:['answer the question','specific examples','personal reflection'],
          outline:{thesis:'A good reply answers the question and adds personal experience', points:[
            {text:'Answer with two activities',evidences:['English corner every Friday','Volunteering in a community centre']},
            {text:'Give concrete details',evidences:['Practise speaking with friends','Help elderly people with housework']},
            {text:'Share what you gain',evidences:['Better time management','Communication and responsibility']}
          ]}
        }
      }
    },
    {
      id:'e-2023-b-07', year:2023, paper:'新课标Ⅰ卷', subject:'英语', type:'单选',
      title:'阅读主旨：修复文化',
      stem:'阅读短文，选出最佳标题。In many cities, repair cafés are opening in libraries and community centres. People bring broken lamps, chairs and radios, and volunteers help them fix the items instead of throwing them away. The idea is simple: keeping things in use saves money, reduces waste and teaches skills that are in danger of being lost. A. Repair Cafés: Fixing Things and Habits B. How Libraries Changed C. The Cost of New Furniture D. Why Volunteers Are Needed',
      answer:'A',
      steps:[
        '首句给对象：repair cafés 在社区出现',
        '中间讲做法：志愿者帮人修旧物',
        '末句讲意义：省钱、减废、传技艺',
        '三项都围绕“修复”，标题选 A'
      ],
      points:['主旨大意','标题概括','说明文'],
      why:'标题要覆盖对象与主旨，B、C、D 都只抓了一个细节',
      note:'改编自 2023 年新课标Ⅰ卷阅读同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'主旨三步', lines:['抓对象','看做法与意义','排除细节项']}
      }
    },
    {
      id:'e-2024-b-08', year:2024, paper:'新课标Ⅰ卷', subject:'英语', type:'单选',
      title:'阅读主旨：睡眠与记忆',
      stem:'阅读短文，回答主旨问题。During deep sleep, the brain replays what we learned during the day, strengthening the connections between nerve cells. Students who sleep well after studying remember more than those who stay up late. Sleep is therefore not a break from learning but part of it. Question: What is the main idea of the passage? A. Sleep helps turn learning into memory. B. Students should sleep longer than adults. C. Deep sleep is the same as dreaming. D. Staying up late is a bad habit.',
      answer:'A',
      steps:[
        '首句讲深度睡眠重放白天所学',
        '第二句用对比说明睡眠与记忆的关系',
        '末句点题：睡眠是学习的一部分',
        '主旨落在“睡眠促进记忆”，选 A'
      ],
      points:['段落主旨','对比论证','说明文'],
      why:'末句常有 therefore 这类总结词，是主旨的直接提示',
      note:'改编自 2024 年新课标Ⅰ卷阅读同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'找主旨', lines:['看首句对象','看对比结果','抓总结句']}
      }
    },
    {
      id:'e-2023-b-09', year:2023, paper:'新课标Ⅰ卷', subject:'英语', type:'简答',
      title:'Not until 引起的倒装',
      stem:'分析句子结构并译出主干：Not until the vaccine had been tested on thousands of volunteers did the researchers feel confident enough to announce the result.',
      answer:'Not until 状语置于句首，主句部分倒装；主干是 the researchers felt confident enough to announce the result。',
      steps:[
        'Not until 引导的时间状语放在句首',
        '主句用部分倒装：did + 主语 + 动词原形',
        '还原后是 the researchers felt confident enough',
        '不定式 to announce the result 作结果状语'
      ],
      points:['部分倒装','时间状语从句','不定式作状语'],
      why:'否定词置句首要倒装，先把 did 找出来再还原语序',
      note:'改编自 2023 年新课标Ⅰ卷阅读长难句同型题',
      view:{
        engine:'subjects', mode:'syntax', params:{},
        data:{
          sentence:'Not until the vaccine had been tested on thousands of volunteers did the researchers feel confident enough to announce the result.',
          tree:[
            {role:'状语',text:'Not until the vaccine had been tested on thousands of volunteers',main:false,children:[
              {role:'主',text:'the vaccine'},{role:'谓',text:'had been tested'},{role:'状',text:'on thousands of volunteers'}
            ]},
            {role:'谓语',text:'did',main:true},
            {role:'主语',text:'the researchers',main:true},
            {role:'谓语',text:'feel',main:true},
            {role:'宾语',text:'confident enough',main:true},
            {role:'状语',text:'to announce the result',main:true}
          ]
        }
      }
    },
    {
      id:'e-2025-b-10', year:2025, paper:'新课标Ⅱ卷', subject:'英语', type:'填空',
      title:'语法填空：熊猫三空',
      stem:'在空白处填入 1 个适当的单词或括号内单词的正确形式：The giant panda, ___ (list) as a vulnerable species, is still threatened by habitat loss. Its population ___ (grow) steadily since the 1980s, and in 2016 it ___ (move) from “endangered” to “vulnerable”.',
      answer:'listed；has grown；was moved',
      steps:[
        '第一空与 panda 是被动关系，用过去分词 listed',
        'since the 1980s 提示现在完成时，用 has grown',
        '2016 是过去时间，且是被降级，用 was moved',
        '逐空先判成分，再定时态语态'
      ],
      points:['过去分词','现在完成时','一般过去时的被动'],
      why:'时间状语是时态最硬的线索，先圈出 since 和 2016',
      note:'改编自 2025 年新课标Ⅱ卷语法填空同型题',
      view:{
        engine:'subjects', mode:'syntax', params:{},
        data:{
          sentence:'The giant panda, listed as a vulnerable species, is still threatened by habitat loss.',
          tree:[
            {role:'主语',text:'The giant panda',main:true,children:[{role:'非谓语',text:'listed as a vulnerable species'}]},
            {role:'系动词',text:'is',main:true},
            {role:'状语',text:'still',main:true},
            {role:'谓语',text:'threatened',main:true},
            {role:'状语',text:'by habitat loss',main:true}
          ]
        }
      }
    },
    {
      id:'e-2023-b-11', year:2023, paper:'新课标Ⅰ卷', subject:'英语', type:'材料',
      title:'推荐一位中国历史人物',
      stem:'假定你是李华，你的英国朋友 Chris 想了解一位中国历史人物。请给他写一封邮件，推荐一位人物，并说明推荐理由。词数 80 左右。',
      answer:'推荐邮件：人物、事迹与推荐理由。',
      steps:[
        '开头点明写信目的：recommend a figure',
        '交代人物与时代：如张骞出使西域',
        '写理由：开拓交流、坚韧不拔',
        '结尾欢迎追问并期待回信'
      ],
      points:['应用文写作','推荐信','人物介绍'],
      why:'推荐信要有具体事迹支撑理由，避免只贴“伟大”标签',
      note:'改编自 2023 年新课标Ⅰ卷应用文同型题',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'Recommending a Chinese historical figure',
          material:'Chris wants to know about a Chinese historical figure',
          tasks:['about 80 words','name the figure and give reasons'],
          angles:['specific deeds','clear reasons','friendly tone'],
          outline:{thesis:'A good recommendation rests on specific deeds', points:[
            {text:'Name the figure and his time',evidences:['Zhang Qian of the Han Dynasty','A pioneer of the Silk Road']},
            {text:'Give one or two deeds',evidences:['Travelled west on diplomatic missions','Opened trade and cultural exchanges']},
            {text:'Explain why he matters',evidences:['Courage in the unknown','Long-term influence on exchanges']}
          ]}
        }
      }
    },

    /* ==================== 历史 ==================== */
    {
      id:'h-2023-b-01', year:2023, paper:'全国甲卷', subject:'历史', type:'材料',
      title:'地方行政制度的三次转折',
      stem:'阅读材料，概括中国古代地方行政制度的主要演变，并说明其趋势。材料：西周“封邦建国”，诸侯世袭；秦“分天下以为三十六郡”，郡守由中央任免；汉初“郡国并行”，后经推恩令逐步削藩。',
      answer:'分封制→郡县制→郡国并行到单一郡县；趋势是中央集权不断加强。',
      steps:[
        '西周分封，诸侯在封地内世袭统治',
        '秦废分封行郡县，郡守县令由中央任免',
        '汉初郡国并行，王国势力威胁中央',
        '推恩令后王国削弱，中央集权加强'
      ],
      points:['分封制','郡县制','中央集权'],
      why:'制度演变题抓“谁任免、谁世袭”，集权程度自然清楚',
      note:'改编自 2023 年全国甲卷制度演变同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:-1046,title:'西周分封',note:'诸侯世袭',desc:'周王将土地人民分封给诸侯，诸侯在封地内世袭统治'},
          {year:-221,title:'秦行郡县',note:'中央任免',desc:'废分封行郡县，郡守县令由中央任免，不得世袭'},
          {year:-154,title:'七国之乱',note:'郡国并行之弊',desc:'王国势力坐大，叛乱被平定后中央加紧削藩'},
          {year:-127,title:'推恩令',note:'王国越分越小',desc:'诸侯王诸子分封，王国越分越小，中央集权加强'}
        ]}
      }
    },
    {
      id:'h-2024-b-02', year:2024, paper:'新课标卷', subject:'历史', type:'材料',
      title:'中日近代化的分岔',
      stem:'阅读材料，比较 19 世纪中后期中国洋务运动与日本明治维新的不同结局，并分析原因。材料：两国几乎同时面对西方冲击，中国以“中体西用”创办军事民用工业，日本则废藩置县、殖产兴业、文明开化。',
      answer:'中国只学器物不改制度，日本全面改革制度；结果甲午一战见分晓。',
      steps:[
        '背景相同：黑船与鸦片战争后被迫开国',
        '中国洋务运动以“中体西用”为原则',
        '日本明治维新废藩置县、殖产兴业',
        '制度改革的深浅，决定甲午战争结局'
      ],
      points:['洋务运动','明治维新','中外关联'],
      why:'比较题先列相同背景，再从改革深度找差异',
      note:'改编自 2024 年新课标卷中外关联同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:1853,title:'黑船来航',note:'日本被迫开国',desc:'美国舰队叩关，日本结束锁国，民族危机加深'},
          {year:1861,title:'洋务运动',note:'中体西用',desc:'创办军事民用工业，学习西方技术而不改制度'},
          {year:1868,title:'明治维新',note:'全面改革',desc:'废藩置县、殖产兴业、文明开化，走上资本主义道路'},
          {year:1894,title:'甲午战争',note:'一战见分晓',desc:'北洋水师覆没，洋务运动成果化为泡影'}
        ]}
      }
    },
    {
      id:'h-2025-b-03', year:2025, paper:'新课标卷', subject:'历史', type:'材料',
      title:'选官制度的三级跳',
      stem:'阅读材料，概括中国古代选官制度的变化，并说明科举制的影响。材料：汉代察举孝廉，魏晋九品中正“上品无寒门”，隋唐以降以考试取士，宋代扩大录取，明清行八股取士。',
      answer:'察举制→九品中正制→科举制；科举扩大统治基础，也强化思想控制。',
      steps:[
        '汉察举以品德名声推荐，标准主观',
        '魏晋九品中正被门阀把持，重门第',
        '隋唐科举以考试成绩取士，相对公平',
        '科举扩大统治基础，明清八股束缚思想'
      ],
      points:['察举制','九品中正制','科举制'],
      why:'选官制度看“选拔标准”，从品德到门第再到考试成绩',
      note:'改编自 2025 年新课标卷制度演变同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'选官标准之变', lines:['汉代察举：重德行','魏晋中正：重门第','隋唐科举：重考试成绩','明清八股：重格式']}
      }
    },
    {
      id:'h-2024-b-04', year:2024, paper:'新课标卷', subject:'历史', type:'材料',
      title:'画像石牛耕图的史料价值',
      stem:'材料：山东出土的汉代画像石上，刻有一人扶犁、一牛拉犁的耕作图，旁有禾苗与农舍。请说明该画像石的史料价值，使用时应注意什么。',
      answer:'一手实物史料，可证汉代牛耕与农事；需与文献互证，注意艺术夸张。',
      steps:[
        '画像石是考古出土的实物，属一手史料',
        '图像可直接证明汉代已用牛耕',
        '禾苗农舍反映当时农事与居住形态',
        '画像有艺术加工，需与文献互证'
      ],
      points:['史料实证','一手史料','图文互证'],
      why:'史料价值题先定类型，再说能证什么、不能证什么',
      note:'改编自 2024 年新课标卷史料分析同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'史料价值两步', lines:['先判史料类型','再问能证明什么','最后说局限']}
      }
    },
    {
      id:'h-2023-b-05', year:2023, paper:'全国甲卷', subject:'历史', type:'材料',
      title:'三省六部制的运行',
      stem:'阅读材料，说明唐代三省六部制的运行程序，并分析其作用。材料：中书省草拟诏令，门下省审核封驳，尚书省负责执行，下设六部分理政务。',
      answer:'中书拟诏—门下审核—尚书执行；分割相权，提高行政效率。',
      steps:[
        '中书省负责草拟诏令，出政策',
        '门下省审核，可封驳退回，形成制衡',
        '尚书省总领六部，负责具体执行',
        '相权一分为三，皇权加强，决策更审慎'
      ],
      points:['三省六部制','相权分割','行政效率'],
      why:'制度运行题按“决策—审核—执行”三段时间顺序说',
      note:'改编自 2023 年全国甲卷制度同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'三省运行', lines:['中书草拟','门下封驳','尚书执行','六部分工']}
      }
    },
    {
      id:'h-2025-b-06', year:2025, paper:'新课标卷', subject:'历史', type:'材料',
      title:'近代化探索的三层递进',
      stem:'阅读材料，概括近代中国向西方学习经历的层次变化，并各举一例。材料：从“师夷长技”到“变法图强”，再到“民主科学”，学习内容不断深入。',
      answer:'器物（洋务运动）→制度（戊戌变法、辛亥革命）→思想（新文化运动）。',
      steps:[
        '器物层：洋务运动办军事民用工业',
        '制度层：戊戌变法尝试君主立宪',
        '制度层：辛亥革命建立共和政体',
        '思想层：新文化运动倡民主与科学'
      ],
      points:['洋务运动','戊戌变法','新文化运动'],
      why:'三层递进的关键词是器物、制度、思想，答例要一一对应',
      note:'改编自 2025 年新课标卷近代史同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:1861,title:'洋务运动',note:'器物层面',desc:'学习西方军事与工业技术，未触动制度'},
          {year:1898,title:'戊戌变法',note:'制度层面',desc:'尝试君主立宪，因守旧势力反扑而失败'},
          {year:1911,title:'辛亥革命',note:'制度层面',desc:'推翻君主专制，建立民主共和政体'},
          {year:1915,title:'新文化运动',note:'思想层面',desc:'倡民主与科学，批判旧礼教与旧文学'}
        ]}
      }
    },
    {
      id:'h-2024-b-07', year:2024, paper:'新课标卷', subject:'历史', type:'材料',
      title:'经济重心南移的三阶段',
      stem:'阅读材料，概括中国古代经济重心南移的过程，并分析南宋时完成南移的原因。材料：魏晋以来北人南迁，唐安史之乱后江南赋税渐重，南宋时“苏湖熟，天下足”。',
      answer:'魏晋奠基、唐中后期加速、南宋完成；北人南迁带来劳动力与技术。',
      steps:[
        '魏晋南北朝：北人南迁，江南初步开发',
        '唐安史之乱后：北方战乱，经济重心开始南移',
        '南宋：南方赋税与粮食地位全面超过北方',
        '原因：劳动力、技术、相对安定的环境'
      ],
      points:['经济重心南移','人口南迁','区域开发'],
      why:'南移题要答“时间节点+迁移要素”，不能只说南方变富',
      note:'改编自 2024 年新课标卷经济史同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'南移三阶段', lines:['魏晋奠基','唐中后期加速','南宋完成','劳动力与技术南来']}
      }
    },
    {
      id:'h-2023-b-08', year:2023, paper:'全国乙卷', subject:'历史', type:'材料',
      title:'古希腊罗马政治坐标',
      stem:'阅读材料，比较雅典民主政治与罗马共和国的权力结构，并说明二者的共同局限。材料：雅典公民大会、五百人议事会与陪审法庭分权；罗马设执政官、元老院与公民大会。',
      answer:'雅典直接民主、罗马贵族共和；共同局限是妇女、奴隶与外邦人被排除。',
      steps:[
        '雅典：公民大会最高权力，抽签轮流',
        '罗马：执政官掌军政，元老院掌财政外交',
        '二者都强调分权与制衡，防止专断',
        '共同局限：奴隶、妇女、外邦人无权'
      ],
      points:['雅典民主','罗马共和','古代政治'],
      why:'比较古代政体，先看权力归属，再看谁被排除在外',
      note:'改编自 2023 年全国乙卷世界史同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:-594,title:'梭伦改革',note:'按财产分等',desc:'按财产多少划分公民等级，扩大参政范围'},
          {year:-509,title:'罗马共和国',note:'贵族共和',desc:'执政官、元老院与公民大会分享权力'},
          {year:-462,title:'雅典民主扩展',note:'削弱贵族院',desc:'厄菲阿尔特改革限制贵族院权力，民主更激进'},
          {year:-27,title:'罗马帝国',note:'共和转向帝制',desc:'屋大维称奥古斯都，共和外衣下集权于一人'}
        ]}
      }
    },
    {
      id:'h-2025-b-09', year:2025, paper:'新课标卷', subject:'历史', type:'材料',
      title:'明清市镇与白银流通',
      stem:'阅读材料，概括明清时期商品经济发展的表现，并说明其影响。材料：江南市镇密布，棉布丝绸远销各地；白银成为主要流通货币；雇工按日计酬，“机户出资，机工出力”。',
      answer:'市镇兴起、白银货币化、雇佣关系出现；推动手工业发展，但受制度束缚。',
      steps:[
        '市镇密布，专业化的棉布丝绸生产',
        '白银成为主要货币，长途贸易便利',
        '机户出资、机工出力，出现雇佣关系',
        '受重农抑商与闭关政策束缚，未成气候'
      ],
      points:['商品经济','白银货币化','雇佣关系'],
      why:'材料里“雇工按日计酬”是判断雇佣关系的关键证据',
      note:'改编自 2025 年新课标卷明清经济同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'商品化的三条线', lines:['市镇专业化','白银货币化','雇佣关系出现']}
      }
    },
    {
      id:'h-2024-b-10', year:2024, paper:'新课标卷', subject:'历史', type:'材料',
      title:'新中国外交的关键节点',
      stem:'阅读材料，概括新中国成立后外交格局的变化，并说明 1971 年与 1972 年两个事件的意义。材料：建国初期“一边倒”，1953 年提出和平共处五项原则，1971 年恢复联合国合法席位，1972 年中美关系正常化。',
      answer:'从“一边倒”到独立自主的和平外交；重返联合国与中美缓和打开外交新局面。',
      steps:[
        '建国初期“一边倒”，与苏联等建交',
        '1953 年和平共处五项原则，超越意识形态',
        '1971 年恢复联合国合法席位，国际地位提升',
        '1972 年尼克松访华，中美关系开始正常化'
      ],
      points:['独立自主','和平共处五项原则','中美关系'],
      why:'两个年份要分别答“多边舞台”与“双边突破”，别混在一起',
      note:'改编自 2024 年新课标卷新中国外交同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:1949,title:'建国初外交',note:'一边倒',desc:'与苏联等社会主义国家建交，打破孤立'},
          {year:1953,title:'五项原则',note:'和平共处',desc:'提出和平共处五项原则，成为处理国际关系的基本准则'},
          {year:1971,title:'重返联合国',note:'多边突破',desc:'恢复在联合国的合法席位，国际地位显著提升'},
          {year:1972,title:'尼克松访华',note:'双边突破',desc:'中美关系开始正常化，带动建交热潮'}
        ]}
      }
    },
    {
      id:'h-2025-b-11', year:2025, paper:'新课标卷', subject:'历史', type:'材料',
      title:'工业革命与马克思主义诞生',
      stem:'阅读材料，说明工业革命与马克思主义诞生的关系，并指出《共产党宣言》的核心主张。材料：机器大工业使社会分裂为两大对立阶级，周期性经济危机反复出现；1848 年《共产党宣言》发表。',
      answer:'工业革命暴露资本主义矛盾，为马克思主义提供社会条件；《宣言》主张阶级斗争与无产阶级解放。',
      steps:[
        '工业革命使生产社会化，矛盾集中',
        '工人贫困与周期危机，暴露制度弊端',
        '三大来源批判继承，形成科学理论',
        '1848 年《宣言》标志马克思主义诞生'
      ],
      points:['工业革命','马克思主义','《共产党宣言》'],
      why:'关系题要答“工业革命提供条件，理论回应问题”',
      note:'改编自 2025 年新课标卷中外关联同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'从机器到宣言', lines:['机器大工业','社会矛盾尖锐','批判继承理论','1848 宣言发表']}
      }
    },

    /* ==================== 地理 ==================== */
    {
      id:'g-2023-b-01', year:2023, paper:'全国甲卷', subject:'地理', type:'简答',
      title:'塔里木盆地干旱的成因',
      stem:'读我国西北地区简图，分析塔里木盆地气候干旱的成因。',
      answer:'深居内陆、距海遥远；四周高山阻挡水汽；常年受大陆气团控制。',
      steps:[
        '位置深居内陆，海洋水汽难以到达',
        '北有天山、南有昆仑山，地形封闭',
        '盆地地形使水汽难以进入，也难散失',
        '终年受大陆气团控制，降水稀少'
      ],
      points:['区域定位','气候成因','地形闭塞'],
      why:'干旱成因按“距海—地形—大气环流”三条线答',
      note:'改编自 2023 年全国甲卷气候成因同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.17,y:0.39,label:'塔里木盆地',note:'深居内陆，周围高山环抱'},
            {x:0.20,y:0.29,label:'天山',note:'北侧屏障，阻挡北来水汽'},
            {x:0.13,y:0.50,label:'昆仑山',note:'南侧屏障，阻挡印度洋水汽'},
            {x:0.86,y:0.50,label:'太平洋水汽',note:'远距离输送，难以到达盆地'}
          ],
          arrows:[{x1:0.88,y1:0.50,x2:0.32,y2:0.42,label:'水汽受阻'}]
        }
      }
    },
    {
      id:'g-2024-b-02', year:2024, paper:'新课标卷', subject:'地理', type:'简答',
      title:'荆江河段曲流的成因',
      stem:'读长江中游示意图，分析荆江河段“九曲回肠”多曲流的原因，并说明曲流带来的问题。',
      answer:'地势平坦、流速慢，侧蚀强，凹岸侵蚀凸岸堆积；易淤积、行洪不畅。',
      steps:[
        '出三峡后进入平原，落差小、流速慢',
        '河流以侧蚀为主，凹岸侵蚀、凸岸堆积',
        '长期侧蚀使河道弯曲，形成曲流',
        '曲流排水不畅，泥沙淤积，洪涝风险大'
      ],
      points:['曲流','流水侵蚀','洪涝'],
      why:'曲流是“侧蚀+堆积”的结果，先看地形再讲过程',
      note:'改编自 2024 年新课标卷水文同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.45,y:0.52,label:'宜昌',note:'出三峡，进入平原'},
            {x:0.55,y:0.55,label:'荆州',note:'荆江河段，曲流发育'},
            {x:0.63,y:0.66,label:'洞庭湖',note:'吞吐长江洪水'},
            {x:0.68,y:0.52,label:'武汉',note:'下游干流节点'}
          ],
          arrows:[
            {x1:0.45,y1:0.52,x2:0.55,y2:0.55,label:'荆江'},
            {x1:0.55,y1:0.55,x2:0.68,y2:0.52,label:'干流'}
          ]
        }
      }
    },
    {
      id:'g-2025-b-03', year:2025, paper:'新课标卷', subject:'地理', type:'简答',
      title:'热带雨林气候的非地带性',
      stem:'马达加斯加岛东部终年高温多雨，形成热带雨林气候。分析其成因。',
      answer:'纬度低、东南信风迎风坡、沿岸暖流增温增湿、地形抬升多雨。',
      steps:[
        '纬度低，全年高温，热量充足',
        '东南信风从海洋吹来，带来水汽',
        '岛屿中部山地抬升，形成地形雨',
        '沿岸暖流增温增湿，降水更丰沛'
      ],
      points:['热带雨林气候','地形雨','洋流'],
      why:'非地带性气候要找“信风+地形+暖流”三个加湿条件',
      note:'改编自 2025 年新课标卷气候同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'四处加湿', lines:['纬度低，热量足','东南信风带来水汽','山地抬升成地形雨','暖流增温增湿']}
      }
    },
    {
      id:'g-2024-b-04', year:2024, paper:'新课标卷', subject:'地理', type:'简答',
      title:'秦岭—淮河线的地理意义',
      stem:'读中国东部示意图，说明秦岭—淮河一线的主要地理意义。',
      answer:'1 月 0℃ 等温线、800 mm 年等降水量线、亚热带与暖温带分界、水田与旱地分界。',
      steps:[
        '与 1 月 0℃ 等温线大体一致',
        '与 800 mm 年等降水量线吻合',
        '亚热带与暖温带、湿润与半湿润分界',
        '水田与旱地、稻作与麦作的分界'
      ],
      points:['秦岭—淮河线','气候分界','农业分界'],
      why:'这条线是气候与农业的分界，按温度、降水、耕作逐条答',
      note:'改编自 2024 年新课标卷区域地理同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.52,y:0.42,label:'秦岭',note:'东西走向，冬季阻挡冷空气'},
            {x:0.63,y:0.47,label:'淮河',note:'与秦岭共同构成南北分界'},
            {x:0.55,y:0.55,label:'汉中',note:'秦岭以南，亚热带'},
            {x:0.68,y:0.50,label:'蚌埠',note:'淮河沿岸，南北过渡带'}
          ],
          arrows:[{x1:0.52,y1:0.42,x2:0.63,y2:0.47,label:'分界线'}]
        }
      }
    },
    {
      id:'g-2023-b-05', year:2023, paper:'全国甲卷', subject:'地理', type:'材料',
      title:'中国城镇化的阶段特征',
      stem:'读我国城镇化率变化数据，描述 1949—2023 年我国城镇化的阶段特征，并分析 1978 年后加速的原因。',
      answer:'1949—1978 缓慢，1978 年后快速提升，2023 年达 66.2%；工业化与改革推动。',
      steps:[
        '1949 年约 10.6%，起点低',
        '1949—1978 年升到 17.9%，进程缓慢',
        '1978 年后快速上升，2020 年 63.9%',
        '工业化、市场化与户籍松动共同推动'
      ],
      points:['城镇化','阶段特征','工业化'],
      why:'描述数据先分段看斜率，再解释每段背后的制度与产业',
      note:'改编自 2023 年全国甲卷城镇化同型题',
      view:{
        engine:'subjects', mode:'data', params:{},
        data:{
          title:'中国城镇化率（%）',
          rows:[
            {label:'1949',value:10.6},{label:'1978',value:17.9},{label:'2000',value:36.2},
            {label:'2010',value:50.0},{label:'2020',value:63.9},{label:'2023',value:66.2}
          ]
        }
      }
    },
    {
      id:'g-2025-b-06', year:2025, paper:'新课标卷', subject:'地理', type:'材料',
      title:'城市人口密度的空间分布',
      stem:'读某城市人口密度随距市中心距离变化的数据，描述其分布特征，并分析原因。',
      answer:'总体由中心向外递减，卫星城出现次高峰；地价、交通与住宅新区布局共同作用。',
      steps:[
        '市中心密度最高，向外总体递减',
        '卫星城出现次高峰，多为住宅新区',
        '地租随距离下降，中心区多为商业',
        '交通与产业外迁，卫星城承接人口'
      ],
      points:['城市内部空间结构','人口密度','地租'],
      why:'密度曲线要抓“递减+次高峰”，再用地租与交通解释',
      note:'数据为示例，改编自 2025 年新课标卷城市同型题',
      view:{
        engine:'subjects', mode:'data', params:{},
        data:{
          title:'人口密度（万人/km²）',
          rows:[
            {label:'市中心',value:4.2},{label:'近郊',value:2.5},
            {label:'卫星城',value:3.0},{label:'远郊',value:0.7}
          ]
        }
      }
    },
    {
      id:'g-2024-b-07', year:2024, paper:'新课标卷', subject:'地理', type:'简答',
      title:'河流阶地的形成过程',
      stem:'读某河谷剖面，说明河流阶地的形成过程。',
      answer:'地壳稳定时河流侧蚀展宽河谷，地壳抬升后河流下切，旧河漫滩高出洪水位成阶地。',
      steps:[
        '地壳稳定，河流以侧蚀为主，河谷展宽',
        '泥沙在河漫滩堆积，形成平坦面',
        '地壳抬升，河流落差增大，下切侵蚀',
        '旧河漫滩高出洪水位，成为阶地'
      ],
      points:['河流阶地','地壳运动','流水侵蚀'],
      why:'阶地是“侧蚀—堆积—抬升下切”三步留下的地形',
      note:'改编自 2024 年新课标卷地貌同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'阶地四步', lines:['地壳稳定，侧蚀展宽','河漫滩堆积','地壳抬升','河流下切，阶地形成']}
      }
    },
    {
      id:'g-2023-b-08', year:2023, paper:'全国甲卷', subject:'地理', type:'简答',
      title:'喀斯特地貌的形成条件',
      stem:'说明我国西南地区喀斯特地貌发育的条件。',
      answer:'可溶性石灰岩广布、气候湿热降水多、地形起伏大、流水溶蚀强。',
      steps:[
        '石灰岩广布，岩石可溶性强',
        '亚热带季风气候，高温多雨',
        '地形起伏大，流水下渗与流动快',
        '流水溶蚀长期作用，形成峰林溶洞'
      ],
      points:['喀斯特地貌','流水溶蚀','岩石条件'],
      why:'喀斯特要同时满足“可溶岩石+丰沛降水”，缺一不可',
      note:'改编自 2023 年全国甲卷地貌同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'四个条件', lines:['石灰岩广布','高温多雨','地形起伏大','流水溶蚀强']}
      }
    },
    {
      id:'g-2025-b-09', year:2025, paper:'新课标卷', subject:'地理', type:'简答',
      title:'三江平原商品粮基地',
      stem:'读东北地区简图，分析三江平原成为我国重要商品粮基地的区位条件。',
      answer:'地形平坦、黑土肥沃、地广人稀、机械化程度高、政策支持。',
      steps:[
        '三江冲积平原，地势平坦开阔',
        '黑土广布，土壤有机质含量高',
        '地广人稀，人均耕地多，商品率高',
        '机械化与政策支持，商品粮输出稳定'
      ],
      points:['商品粮基地','农业区位','东北平原'],
      why:'商品粮基地的关键是“余粮多”，要从人均耕地和机械化答',
      note:'改编自 2025 年新课标卷农业区位同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.88,y:0.20,label:'三江平原',note:'黑龙江、松花江、乌苏里江冲积'},
            {x:0.80,y:0.27,label:'松嫩平原',note:'黑土集中，商品粮主产区'},
            {x:0.76,y:0.36,label:'辽河平原',note:'纬度较低，热量条件较好'}
          ],
          arrows:[{x1:0.76,y1:0.36,x2:0.88,y2:0.20,label:'东北平原'}]
        }
      }
    },
    {
      id:'g-2024-b-10', year:2024, paper:'新课标卷', subject:'地理', type:'简答',
      title:'青海湖成为咸水湖',
      stem:'说明青海湖由外流湖演变为内流咸水湖的过程。',
      answer:'地壳抬升阻断外流通道，湖水只进不出，蒸发旺盛，盐分累积成咸水湖。',
      steps:[
        '早期青海湖有外流通道，属淡水湖',
        '地壳抬升，出口被阻断，变为内流湖',
        '流域降水与冰雪融水补给，盐分随水进入',
        '蒸发旺盛，盐分不断累积，湖水变咸'
      ],
      points:['内流湖','盐分累积','地壳运动'],
      why:'咸水湖的关键是“无出口+蒸发强”，盐分只进不出',
      note:'改编自 2024 年新课标卷湖泊水文同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'由淡变咸', lines:['外流通道被阻断','变为内流湖','盐分随水汇入','蒸发使盐分累积']}
      }
    },
    {
      id:'g-2023-b-11', year:2023, paper:'全国甲卷', subject:'地理', type:'简答',
      title:'横断山区垂直带谱丰富',
      stem:'读西南地区简图，分析横断山区垂直自然带谱丰富的原因。',
      answer:'纬度低、相对高度大、西南季风带来丰沛降水，水热组合多样。',
      steps:[
        '纬度低，山麓热量充足，基带丰富',
        '相对高度大，从河谷到山顶温差大',
        '西南季风迎风坡，降水随高度变化',
        '水热组合多样，垂直带谱复杂'
      ],
      points:['垂直地带性','相对高度','水热组合'],
      why:'垂直带谱看“纬度定基带、高度定带数、降水定类型”',
      note:'改编自 2023 年全国甲卷区域地理同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.42,y:0.70,label:'横断山区',note:'山河相间，相对高度大'},
            {x:0.48,y:0.78,label:'昆明',note:'低纬高原，四季如春'},
            {x:0.50,y:0.63,label:'成都',note:'四川盆地西缘'}
          ],
          arrows:[{x1:0.27,y1:0.86,x2:0.42,y2:0.70,label:'西南季风'}]
        }
      }
    }
  ]);
})();
