/* 见微 · 立体几何题（2023–2025 同型/改编，标注见 note） */
(function () {
  JW.addQuestions([
    {
      id: 's-2024-b-01', year: 2024, paper: '新课标Ⅰ卷', subject: '数学', type: '单选',
      title: '正方体对角线与底面所成角',
      stem: '正方体 ABCD-A₁B₁C₁D₁ 的棱长为 2，求体对角线 AC₁ 与底面 ABCD 所成角的正弦值。',
      answer: '√3/3',
      steps: [
        '体对角线 AC₁ 在底面的投影是 AC',
        '棱长 2：AC=2√2，CC₁=2，AC₁=2√3',
        '线面角的正弦 = 竖直棱 / 体对角线 = 2/(2√3)',
        '化简得 √3/3'
      ],
      points: ['线面角', '正方体', '空间向量'],
      why: '线面角的正弦＝垂直于面的那条棱比斜线段，不必建系也能一步出答案',
      note: '改编自 2024 年新课标Ⅰ卷立体几何同型题',
      view: { engine: 'solid', shape: 'cube', size: { a: 2 }, ask: '线面角', cue: '求 AC₁ 与底面 ABCD 所成角的正弦', section: { through: ['A', 'C', 'C1'] } }
    },
    {
      id: 's-2023-b-02', year: 2023, paper: '全国甲卷', subject: '数学', type: '解答',
      title: '正四棱锥体积',
      stem: '正四棱锥 S-ABCD 的底面边长为 2，侧棱长为 2，求它的体积。',
      answer: '4√2/3',
      steps: [
        '底面对角线 AC=2√2，中心 O 到顶点距离 √2',
        '在 △SOA 中：SO=√(SA²-AO²)=√(4-2)=√2',
        '底面积 S=2×2=4',
        'V=S·h/3=4×√2/3'
      ],
      points: ['棱锥体积', '勾股定理', '正四棱锥'],
      why: '正棱锥先找高落在底面中心，再用半对角线求高',
      note: '改编自 2023 年全国甲卷立体几何同型题',
      view: { engine: 'solid', shape: 'pyramid', size: { a: 2, h: 1.414 }, ask: '体积' }
    },
    {
      id: 's-2023-b-03', year: 2023, paper: '新课标Ⅱ卷', subject: '数学', type: '填空',
      title: '圆柱的外接球',
      stem: '圆柱的底面半径为 1，高为 2，求它的外接球半径。',
      answer: '√2',
      steps: [
        '外接球球心在上下底面圆心连线的中点',
        '球心到底面圆心距离 1（半高）',
        '球心到底面圆上一点：√(1²+1²)=√2',
        '外接球半径 R=√2'
      ],
      points: ['外接球', '圆柱', '勾股定理'],
      why: '旋转体的外接球，先定球心在轴上，再用“半径²=轴向²+底面半径²”',
      note: '改编自 2023 年新课标Ⅱ卷立体几何同型题',
      view: { engine: 'solid', shape: 'cylinder', size: { r: 1, h: 2 }, ask: '外接球' }
    },
    {
      id: 's-2025-b-04', year: 2025, paper: '新课标Ⅰ卷', subject: '数学', type: '解答',
      title: '圆锥的体积',
      stem: '圆锥的底面半径为 3，母线长为 5，求它的体积。',
      answer: '12π',
      steps: [
        '由母线、半径求高：h=√(5²-3²)=4',
        '底面积 S=π×3²=9π',
        'V=S·h/3=9π×4/3',
        '得 V=12π'
      ],
      points: ['圆锥体积', '母线', '勾股定理'],
      why: '母线不是高；先补出轴截面里的直角三角形',
      note: '改编自 2025 年新课标Ⅰ卷立体几何同型题',
      view: { engine: 'solid', shape: 'cone', size: { r: 3, h: 4 }, ask: '体积' }
    },
    {
      id: 's-2024-b-05', year: 2024, paper: '新课标Ⅰ卷', subject: '数学', type: '填空',
      title: '球的表面积与体积',
      stem: '球的半径为 2，求它的表面积与体积。',
      answer: '表面积 16π，体积 32π/3',
      steps: [
        '表面积公式 S=4πR²',
        '代入 R=2：S=16π',
        '体积公式 V=4πR³/3',
        '代入 R=2：V=32π/3'
      ],
      points: ['球的表面积', '球的体积', '公式记忆'],
      why: '球的表面积是 4πR²，体积是 4πR³/3——被积关系别记反',
      note: '基础同型题',
      view: { engine: 'solid', shape: 'sphere', size: { r: 2 }, ask: '体积' }
    },
    {
      id: 's-2023-b-06', year: 2023, paper: '新课标Ⅰ卷', subject: '数学', type: '解答',
      title: '正方体中的二面角',
      stem: '正方体 ABCD-A₁B₁C₁D₁ 的棱长为 1，求二面角 A₁-BD-C 的大小。',
      answer: 'arctan√2（约 54.7°）',
      steps: [
        'BD ⊥ 面 ACC₁A₁，取 BD 中点 O',
        '∠A₁OC 就是二面角的平面角',
        'AO=√2/2，A₁O=√(1+1/2)=√6/2',
        'tan∠A₁OC=AA₁/AO=1/(√2/2)=√2'
      ],
      points: ['二面角', '正方体', '线面垂直'],
      why: '二面角先找垂直于棱的平面，把空间角压成平面角',
      note: '改编自 2023 年新课标Ⅰ卷立体几何同型题',
      view: { engine: 'solid', shape: 'cube', size: { a: 1 }, ask: '二面角', cue: '求二面角 A₁-BD-C' }
    }
  ]);
})();
