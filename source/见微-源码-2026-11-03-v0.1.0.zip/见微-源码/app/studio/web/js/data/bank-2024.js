/* 2024 题库 */
(function () {
  JW.addQuestions([
    {
      id:'m-2024-nh1-03', year:2024, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'向量垂直求参数',
      stem:'已知向量 a=(0,1)，b=(2,x)，若 b⊥(b−4a)，则 x=（　）',
      answer:'2',
      steps:[
        '垂直就是数量积为零：b·(b−4a)=0',
        'b·b=4+x^2，a·b=x',
        '代入得 4+x^2−4x=0，即 (x−2)^2=0',
        '解得 x=2'
      ],
      points:['向量垂直','数量积的坐标运算','方程思想'],
      why:'垂直翻译成点积为零，剩下的就是解一个完全平方的方程',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'垂直条件展开', lines:['b·(b−4a)=|b|^2−4a·b','4+x^2−4x=0','(x−2)^2=0，得 x=2'], steps:['先写点积为零','再代坐标','最后解方程']}
      }
    },
    {
      id:'m-2024-nh1-04', year:2024, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'和差角与正切关系',
      stem:'已知 cos(α+β)=m，tanαtanβ=2，则 cos(α−β)=（　）',
      answer:'−3m',
      steps:[
        'tanαtanβ=2 即 sinαsinβ=2cosαcosβ',
        '设 cosαcosβ=t，则 sinαsinβ=2t',
        'cos(α+β)=t−2t=−t=m，故 t=−m',
        'cos(α−β)=t+2t=3t=−3m'
      ],
      points:['两角和差余弦','同角三角函数关系','整体代换'],
      why:'把 cosαcosβ 看作整体，两个展开式只差一个符号',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'整体代换', lines:['设 cosαcosβ=t','sinαsinβ=2t','cos(α+β)=−t=m'], steps:['把正切关系化成正弦余弦','用一个字母表示整体','两个展开式相加减']}
      }
    },
    {
      id:'m-2024-nh1-05', year:2024, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'圆柱圆锥侧面积相等',
      stem:'圆柱和圆锥的底面半径相等，侧面积相等，且它们的高均为 √3，则圆锥的体积为（　）',
      answer:'3√3π',
      steps:[
        '设底面半径为 r，圆柱侧面积 2πr√3',
        '圆锥母线 l=√(r^2+3)，侧面积 πrl',
        '由 2√3=√(r^2+3) 得 r=3',
        'V=(1/3)πr^2√3=3√3π'
      ],
      points:['圆柱圆锥侧面积','母线长','圆锥体积'],
      why:'侧面积相等先化成同一个 r 的方程，母线是圆锥独有的变量',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'侧面积等式', lines:['圆柱：2πr√3','圆锥：πr√(r^2+3)','相等得 r=3'], steps:['写出两个侧面积','消去 πr','解出半径再求体积']}
      }
    },
    {
      id:'m-2024-nh1-13', year:2024, paper:'新课标Ⅰ卷', subject:'数学', type:'填空',
      title:'公切线求参数',
      stem:'若曲线 y=e^x+x 在点 (0,1) 处的切线也是曲线 y=ln(x+1)+a 的切线，则 a=______。',
      answer:'ln2',
      steps:[
        'y′=e^x+1，x=0 处斜率为 2',
        '切线方程为 y=2x+1',
        '对 y=ln(x+1)+a 令 1/(x+1)=2，得 x=−1/2',
        '切点纵坐标 −ln2+a 在切线上，解得 a=ln2'
      ],
      points:['导数的几何意义','公切线','对数运算'],
      why:'公切线只抓两件事：斜率相等、切点在两条曲线上',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'两条曲线一个斜率', lines:['第一条：斜率 2，切线 y=2x+1','第二条：1/(x+1)=2','切点代入求 a'], steps:['先求第一条切线','再让第二条斜率等于 2','切点坐标代入切线']}
      }
    },
    {
      id:'m-2024-nh1-15', year:2024, paper:'新课标Ⅰ卷', subject:'数学', type:'解答',
      title:'解三角形求角与边',
      stem:'记 △ABC 的内角 A、B、C 的对边分别为 a、b、c，已知 sinC=√2cosB，a^2+b^2−c^2=√2ab。(1) 求 B；(2) 若 △ABC 的面积为 3+√3，求 c。',
      answer:'B=π/3；c=2√2',
      steps:[
        '余弦定理得 cosC=√2/2，故 C=π/4',
        '由 sinC=√2cosB 得 cosB=1/2，B=π/3',
        'A=5π/12，用正弦定理把 a、b 用 c 表示',
        '面积 S=(3+√3)c^2/8=3+√3，解得 c=2√2'
      ],
      points:['正余弦定理','三角形面积公式','边角互化'],
      why:'两条条件一条定角一条定边，先定角再定边，顺序反了会绕远',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'先角后边', lines:['cosC=√2/2 得 C=π/4','sinC=√2cosB 得 B=π/3','面积反解 c=2√2'], steps:['余弦定理定 C','正弦关系定 B','面积公式定 c']}
      }
    },
    {
      id:'m-2024-nh1-16', year:2024, paper:'新课标Ⅰ卷', subject:'数学', type:'解答',
      title:'椭圆离心率与面积',
      stem:'已知 A(0,3)、P(3,3/2) 两点在椭圆 C: x^2/a^2+y^2/b^2=1 (a>b>0) 上。(1) 求 C 的离心率；(2) 过 P 的直线 l 交 C 于另一点 B，若 △ABP 的面积为 9，求 l 的方程。',
      answer:'e=1/2；l: y=x/2 或 y=3x/2−3',
      steps:[
        'A 在椭圆上，得 b=3',
        '代入 P 得 9/a^2+1/4=1，a^2=12，c=√3',
        'e=c/a=1/2',
        '面积 9 给出 B 到 AP 的距离 12/√5',
        '解得 B(−3,−3/2) 或 (0,−3)，写出两条直线'
      ],
      points:['椭圆标准方程','离心率','点到直线距离与面积'],
      why:'面积条件换成点到直线距离，B 就被钉在两个具体点上',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'面积转距离', lines:['b=3，a^2=12，e=1/2','AP: x+2y−6=0','|x+2y−6|=12 得两个 B'], steps:['代点求 a、b','算 AP 方程','面积化距离解出 B']}
      }
    },
    {
      id:'p-2024-xkb-15', year:2024, paper:'新课标卷', subject:'物理', type:'单选',
      title:'弹射小车动能与射程',
      stem:'配重小车被弹射器从航母甲板上水平弹出后落到海面。调整装置使小车水平离开甲板时的动能变为原来的 4 倍，忽略空气阻力，则小车落点与离开甲板处的水平距离变为原来的（　）',
      answer:'2 倍',
      steps:[
        '平抛飞行时间只由甲板高度决定，保持不变',
        '动能变 4 倍，由 Ek=mv^2/2 知速度变 2 倍',
        '水平距离 x=v_0t，也变 2 倍',
        '结论与小车质量无关'
      ],
      points:['平抛运动','动能与速度','水平位移'],
      why:'动能翻四倍只说明速度翻倍，飞行时间没变，这一层最容易漏',
      view:{engine:'physics', kind:'projectile', params:{v0:10,h0:5,g:10,angle:0}, cue:'水平距离变为原来的几倍'}
    },
    {
      id:'p-2024-xkb-16', year:2024, paper:'新课标卷', subject:'物理', type:'单选',
      title:'开普勒定律估恒星质量',
      stem:'某红矮星的行星 GJ1002c 做圆周运动，轨道半径约为日地距离的 0.07 倍，周期约为 0.06 年，则该红矮星质量约为太阳质量的（　）',
      answer:'0.1 倍',
      steps:[
        '万有引力提供向心力，得 M 正比于 r^3/T^2',
        '代入 0.07^3/0.06^2≈3.4×10^−4/3.6×10^−3',
        '比值约为 0.095',
        '与太阳的 1 相比约 0.1 倍'
      ],
      points:['万有引力定律','开普勒第三定律','中心天体质量'],
      why:'绕同一中心天体才有 r^3/T^2 定值，比值法把 G 和 π 全约掉',
      view:{engine:'physics', kind:'gravity', params:{r:12}, cue:'中心天体质量与太阳之比'}
    },
    {
      id:'p-2024-xkb-17', year:2024, paper:'新课标卷', subject:'物理', type:'单选',
      title:'蓝光红光的光子性质',
      stem:'两种量子点分别发出蓝光和红光。下列说法正确的是（　）A.蓝光光子能量大于红光 B.蓝光光子动量小于红光 C.在玻璃中蓝光速度大于红光 D.蓝光在玻璃中的频率小于在空气中的',
      answer:'A',
      steps:[
        'E=hν=hc/λ，蓝光波长短，光子能量大',
        'p=h/λ，蓝光动量更大，B 错',
        '玻璃对蓝光折射率更大，v=c/n 更小，C 错',
        '频率由光源决定，进出介质不变，D 错'
      ],
      points:['光子能量','光子动量','折射率与光速'],
      why:'四个选项考四个不同公式，逐个对照比凭感觉选颜色可靠',
      view:{engine:'physics', kind:'optics', params:{n:1.5,angle:30,n1:1.5,n2:1,theta1:30}, cue:'折射率与光速的关系'}
    },
    {
      id:'p-2024-xkb-22', year:2024, paper:'新课标卷', subject:'物理', type:'实验',
      title:'验证动量守恒的实验条件',
      stem:'用斜槽、白纸和复写纸验证动量守恒：小球 a 从斜槽上某处静止释放，记录落点 P；把与 a 等大的 b 放在轨道末端，再次释放 a，记录两球落点 M、N，测得到 O 点的距离 x_P、x_M、x_N。(1) 应满足 m_a ______ m_b；(2) 写出应验证的关系式，并说明用水平位移代替速度的依据。',
      answer:'(1) >；(2) m_a x_P=m_a x_M+m_b x_N，平抛时间相同',
      steps:[
        '碰后 a 不能反弹，必须 m_a>m_b',
        '两球下落高度相同，飞行时间相同',
        '水平位移与平抛初速度成正比',
        '把速度换成位移得 m_a x_P=m_a x_M+m_b x_N'
      ],
      points:['动量守恒','平抛运动','实验原理'],
      why:'位移替代速度只在等高平抛时成立，这是本实验的隐含前提',
      view:{engine:'physics', kind:'collision', params:{m1:0.02,m2:0.01,m:0.02,v1:1.5,v2:0}, cue:'碰前碰后的动量守恒'}
    },
    {
      id:'p-2024-xkb-23', year:2024, paper:'新课标卷', subject:'物理', type:'实验',
      title:'电压表内阻的测量',
      stem:'待测电压表 V（量程 3 V）与定值电阻 R_0=800 Ω 串联，测得串联部分总电压 U_1=4.20 V，待测表两端电压 U=2.78 V。求待测电压表的内阻 R_V（保留 3 位有效数字）。',
      answer:'1.57 kΩ',
      steps:[
        '串联电流相等，I=(U_1−U)/R_0',
        '代入得 I=(4.20−2.78)/800=1.78×10^−3 A',
        'R_V=U/I=2.78/1.78×10^−3',
        '约 1.57×10^3 Ω，即 1.57 kΩ'
      ],
      points:['串联电路','欧姆定律','有效数字'],
      why:'电压表本身就是电阻，用串联分压反推内阻，别当理想表',
      view:{engine:'physics', kind:'circuit', params:{E:5,r:0.5,R1:800,R2:1566,Emf:5,r0:0}, cue:'待测电压表内阻'}
    },
    {
      id:'p-2024-xkb-24', year:2024, paper:'新课标卷', subject:'物理', type:'解答',
      title:'双绳拉重物与总功',
      stem:'质量 m=42 kg 的重物用两根绳 P、Q 拉住缓慢竖直下降。某时刻 P 绳与竖直方向夹角 37°，Q 绳与竖直方向夹角 53°，g 取 10 m/s^2，sin37°=0.6。(1) 求 P 绳拉力大小；(2) 重物从 h=10 m 高处缓慢降到地面，求两绳拉力对重物做的总功。',
      answer:'(1) 336 N；(2) −4200 J',
      steps:[
        '水平方向：T_P sin37°=T_Q sin53°',
        '竖直方向：T_P cos37°+T_Q cos53°=mg',
        '解得 T_P=336 N，T_Q=252 N',
        '缓慢下降动能不变，拉力总功与重力功抵消，W=−4200 J'
      ],
      points:['共点力平衡','正交分解','动能定理'],
      why:'“缓慢”意味着处处平衡，求功时用动能定理可以绕开变力',
      view:{engine:'physics', kind:'incline', params:{m:42,angle:37,h:10,g:10,mu:0}, cue:'绳拉力与拉力总功'}
    },
    {
      id:'c-2024-xkb-07', year:2024, paper:'新课标卷', subject:'化学', type:'单选',
      title:'文房四宝的材料成分',
      stem:'文房四宝是中华传统文化的瑰宝。下列有关叙述错误的是（　）A.羊毛可用于制毛笔，主要成分为蛋白质 B.松木可用于制墨，墨的主要成分是单质碳 C.竹子可用于造纸，纸的主要成分是纤维素 D.大理石可用于制砚台，主要成分为硅酸盐',
      answer:'D（大理石主要成分是碳酸钙）',
      steps:[
        '羊毛是动物蛋白，A 正确',
        '墨的主要成分是炭黑，属于单质碳，B 正确',
        '纸的主要成分是纤维素，C 正确',
        '大理石是碳酸钙，属碳酸盐而非硅酸盐，D 错误'
      ],
      points:['蛋白质','碳单质','碳酸盐与硅酸盐'],
      why:'四个选项各考一类物质，认准“主要成分”就不会被工艺细节带偏',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'成分对照', lines:['羊毛：蛋白质','墨：炭黑（单质碳）','纸：纤维素','大理石：碳酸钙'], steps:['逐项判断成分','注意碳酸盐与硅酸盐的区别']}
      }
    },
    {
      id:'c-2024-xkb-09', year:2024, paper:'新课标卷', subject:'化学', type:'单选',
      title:'铁与水蒸气反应装置',
      stem:'用湿棉花、还原铁粉和肥皂液验证铁与水蒸气反应。下列说法错误的是（　）A.反应为 3Fe+4H_2O(g)=Fe_3O_4+4H_2 B.酒精灯移至湿棉花下方实验效果更好 C.用木条点燃肥皂泡可检验氢气 D.用硬质玻璃试管盛装还原铁粉',
      answer:'B（加热点应在铁粉处）',
      steps:[
        '高温下铁与水蒸气反应生成 Fe_3O_4 和 H_2',
        '湿棉花提供水蒸气，加热点必须在铁粉处',
        '氢气密度小，肥皂泡点燃有爆鸣声',
        '硬质玻璃耐高温，防止试管炸裂'
      ],
      points:['铁与水蒸气反应','实验装置分析','气体检验'],
      why:'装置题先看每个部件的作用，再看加热位置是否服务于主反应',
      view:{
        engine:'subjects', mode:'reaction', params:{},
        data:{eq:'3Fe+4H2O->Fe3O4+4H2', steps:['湿棉花提供水蒸气','酒精灯加热铁粉','肥皂泡检验氢气']}
      }
    },
    {
      id:'c-2024-xkb-10', year:2024, paper:'新课标卷', subject:'化学', type:'单选',
      title:'离子方程式正误判断',
      stem:'下列过程的离子方程式正确的是（　）A.银镜用稀硝酸清洗：Ag+2H^++NO_3^−=Ag^++NO_2↑+H_2O B.含 Pb^2+ 废水用 FeS 处理：Pb^2++S^2−=PbS↓ C.海水提溴时 Br_2 被 SO_2 吸收：Br_2+SO_2+2H_2O=2Br^−+SO_4^2−+4H^+ D.草酸标准液测高锰酸钾：2MnO_4^−+5C_2O_4^2−+16H^+=2Mn^2++10CO_2↑+8H_2O',
      answer:'C',
      steps:[
        'A 中稀硝酸应生成 NO，且电子得失不守恒',
        'B 中 FeS 难溶，不能拆成 S^2−',
        'C 中 Br_2 氧化 SO_2，原子与电荷都守恒',
        'D 中草酸是弱酸，应写化学式 H_2C_2O_4'
      ],
      points:['离子方程式','氧化还原配平','难溶物不拆'],
      why:'离子方程式先查拆不拆，再查电荷守恒，两关都过才是对的',
      view:{
        engine:'subjects', mode:'reaction', params:{},
        data:{eq:'Br2+SO2+2H2O->2HBr+H2SO4', steps:['Br2 得电子被还原','SO2 失电子被氧化','弱酸与难溶物不拆']}
      }
    },
    {
      id:'c-2024-xkb-12', year:2024, paper:'新课标卷', subject:'化学', type:'单选',
      title:'血糖微型电池的电子转移',
      stem:'一种植入式微型电池通过 CuO 催化消耗血糖发电：a 极为正极，O_2 得电子；b 极上 Cu_2O 失电子生成 CuO，葡萄糖被 CuO 氧化为葡萄糖酸。下列说法错误的是（　）A.总反应为 2C_6H_12O_6+O_2=2C_6H_12O_7 B.CuO 通过 Cu(II) 与 Cu(I) 互变起催化作用 C.消耗 18 mg 葡萄糖，a 极有 0.4 mmol 电子流入 D.血液中的 Na^+ 由 b 极向 a 极迁移',
      answer:'C（应为 0.2 mmol）',
      steps:[
        '葡萄糖被氧化为葡萄糖酸，每个分子失去 2 个电子',
        '18 mg 葡萄糖为 0.1 mmol，转移 0.2 mmol 电子',
        '电子由负极 b 经外电路流向正极 a',
        '原电池中阳离子向正极移动，Na^+ 由 b 到 a'
      ],
      points:['原电池原理','电子转移计算','离子迁移方向'],
      why:'先写总反应再数转移电子，别把葡萄糖分子里的碳全算上',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'两极反应',
          lines:['正极 a：O2+4e−+2H2O=4OH−','负极 b：Cu2O−2e−+2OH−=2CuO+H2O','电子由 b 经外电路流向 a'],
          steps:['先定正负极','再写半反应','最后数电子']
        }
      }
    },
    {
      id:'b-2024-xkb-01', year:2024, paper:'新课标卷', subject:'生物', type:'单选',
      title:'大豆成分的元素与营养',
      stem:'大豆是我国重要的粮食作物。下列叙述错误的是（　）A.大豆油含不饱和脂肪酸，熔点较低，室温时呈液态 B.大豆的蛋白质、脂肪和淀粉可在人体内分解产生能量 C.大豆中的蛋白质含有人体细胞不能合成的必需氨基酸 D.大豆中的脂肪和磷脂均含有碳、氢、氧、磷 4 种元素',
      answer:'D（脂肪只含 C、H、O）',
      steps:[
        '植物脂肪多含不饱和脂肪酸，室温呈液态',
        '蛋白质、脂肪、淀粉都可氧化供能',
        '必需氨基酸人体不能合成，需从食物获取',
        '脂肪只含 C、H、O，磷脂才含 P，D 错误'
      ],
      points:['脂质的种类与元素','蛋白质与氨基酸','能源物质'],
      why:'元素组成题最容易混的就是脂肪与磷脂，记住磷脂才含磷',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'成分与元素', lines:['脂肪：C、H、O','磷脂：C、H、O、P','蛋白质：含 N，可能含 S'], steps:['先看元素种类','再判断有机物类别']}
      }
    },
    {
      id:'b-2024-xkb-04', year:2024, paper:'新课标卷', subject:'生物', type:'单选',
      title:'稻田养蟹的生态位',
      stem:'稻田养蟹的生态农业模式既可提高水稻产量又可收获螃蟹。下列叙述错误的是（　）A.该模式中水稻属于第一营养级 B.该模式中水稻和螃蟹处于相同生态位 C.该模式可促进水稻对二氧化碳的吸收 D.该模式中碳循环在无机环境和生物间进行',
      answer:'B（两者生态位不同）',
      steps:[
        '水稻是生产者，处于第一营养级',
        '螃蟹是消费者，取食范围与水稻不同',
        '生态位包括食物与栖息空间，两者不重合',
        '碳在无机环境与生物群落间循环'
      ],
      points:['生态系统的营养结构','生态位','碳循环'],
      why:'同一片稻田不等于同一生态位，关键看资源与角色是否重合',
      view:{
        engine:'subjects', mode:'ecology', params:{},
        data:{title:'稻田养蟹', lines:['水稻：生产者，第一营养级','螃蟹：消费者','碳循环：无机环境与生物群落']}
      }
    },
    {
      id:'b-2024-xkb-06', year:2024, paper:'新课标卷', subject:'生物', type:'单选',
      title:'细菌种群增长的四个时期',
      stem:'用一定量液体培养基培养某种细菌，活菌数随时间变化分为 I~IV 四个时期。下列叙述错误的是（　）A.培养基中的细菌不能通过有丝分裂增殖 B.II 期细菌数量增长快，存在“J”形增长阶段 C.III 期细菌没有增殖和死亡，总数保持相对稳定 D.IV 期细菌数量下降主要因营养物质匮乏',
      answer:'C（增殖与死亡速率基本相等）',
      steps:[
        '细菌是原核生物，靠二分裂增殖，不行有丝分裂',
        'II 期资源充足，可出现近似“J”形增长',
        'III 期增殖与死亡速率大致相等，总数稳定',
        'IV 期营养耗尽、代谢产物积累，数量下降'
      ],
      points:['种群增长曲线','原核细胞增殖','限制种群增长的因素'],
      why:'稳定期不是不生不死，而是出生率与死亡率打平',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'四个时期', lines:['I 期：调整适应','II 期：对数增长','III 期：增殖与死亡打平','IV 期：营养耗尽而衰退'], steps:['按时间轴读活菌数','再看各期的出生与死亡']}
      }
    },
    {
      id:'y-2024-nh1-23', year:2024, paper:'新课标Ⅰ卷', subject:'语文', type:'材料',
      title:'答案易得，问题会变少吗',
      stem:'随着互联网的普及、人工智能的应用，越来越多的问题能很快得到答案。那么，我们的问题是否会越来越少？以上材料引发了你怎样的联想与思考？请写一篇文章。',
      answer:'立意：答案易得，提问的能力更珍贵',
      steps:[
        '拆出两层：获取答案变易，问题数量是否减少',
        '辨析：被回答的是既有问题，提问才产生新问题',
        '举例：科学史上是新工具带来新问题',
        '收束：守住提问能力，才是人区别于工具之处'
      ],
      points:['材料作文审题','思辨论证','科技与人文'],
      why:'这题真正考的是能否识破“问题会变少”这个诱人的伪命题',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'问题与答案',
          material:'互联网与人工智能让答案唾手可得，我们的问题是否会越来越少',
          tasks:['自拟标题','不少于 800 字','结合材料'],
          angles:['提问比回答更难','工具扩展问题边界','警惕思维惰性'],
          outline:{thesis:'答案越易得，提问能力越珍贵', points:[
            {text:'工具解决的是既有问题',evidences:['搜索引擎只回应已表述的疑问','AI 的回答依赖提问质量']},
            {text:'新问题来自新的实践',evidences:['天文学因望远镜而改写','显微镜打开细胞世界']},
            {text:'提问是人区别于工具之处',evidences:['价值判断无法外包','问题决定方向']}
          ]}
        }
      }
    },
    {
      id:'y-2024-qgj-23', year:2024, paper:'全国甲卷', subject:'语文', type:'材料',
      title:'坦诚交流才能相遇',
      stem:'每个人都要学习与他人相处。有时，我们为避免冲突而不愿表达自己的想法。其实，坦诚交流才有可能迎来真正的相遇。以上材料引发了你怎样的联想与思考？请写一篇文章。',
      answer:'立意：坦诚交流是化解隔阂的前提',
      steps:[
        '抓矛盾：回避冲突与真实表达之间的取舍',
        '说清代价：沉默省事，却让关系停在表面',
        '举例要具体，如团队协作中的一次坦诚沟通',
        '落到“相遇”：理解建立在真实信息之上'
      ],
      points:['材料作文','人际与表达','论证层次'],
      why:'材料给的是回避冲突的惯性，文章要正面回应这种心理',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'坦诚与相遇',
          material:'为避免冲突而不愿表达，坦诚交流才可能真正相遇',
          tasks:['自拟标题','不少于 800 字','联系现实'],
          angles:['沉默的成本','冲突与真诚','理解的条件'],
          outline:{thesis:'坦诚交流才是真正相遇的前提', points:[
            {text:'回避冲突让关系停在表面',evidences:['团队里没人说真话的代价','家庭中的沉默成本']},
            {text:'坦诚需要方法与分寸',evidences:['对事不对人的表达','先听后说的顺序']},
            {text:'相遇建立在真实信息之上',evidences:['误解源于信息缺口','信任来自可验证的表达']}
          ]}
        }
      }
    },
    {
      id:'e-2024-nh1-46', year:2024, paper:'新课标Ⅰ卷', subject:'英语', type:'材料',
      title:'分享公园美术课',
      stem:'假定你是李华，上周五你班在公园上了一节美术课。请给外国朋友 Chris 写一封邮件，分享这次经历，内容包括：活动过程、你的感受。词数 80 左右。',
      answer:'Email sharing the art class',
      steps:[
        '开头问候并点明写信目的',
        '按时间顺序写活动：集合、写生、点评',
        '写感受：从自然中取材，观察更细',
        '结尾询问对方近况并期待回信'
      ],
      points:['应用文写作','叙事顺序','情感表达'],
      why:'分享类邮件的得分点是细节具体、语气自然，而非高级词堆砌',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'An art class in the park',
          material:'Share last Friday art class in the park with Chris',
          tasks:['about 80 words','cover process and feelings'],
          angles:['clear timeline','specific details','friendly tone'],
          outline:{thesis:'A vivid sharing email needs a clear timeline and specific details', points:[
            {text:'Open with the purpose',evidences:['Greet Chris and state why you write','Mention last Friday art class']},
            {text:'Describe the process in order',evidences:['Gathering and choosing a spot','Sketching and teacher comments']},
            {text:'Close with feelings and a question',evidences:['What you learned from nature','Ask about his weekend']}
          ]}
        }
      }
    },
    {
      id:'e-2024-nh1-45', year:2024, paper:'新课标Ⅰ卷', subject:'英语', type:'填空',
      title:'语法填空：茶与丝路',
      stem:'阅读短文，在空白处填入 1 个适当的单词或括号内单词的正确形式：Tea, first ___(grow) in southwest China, travelled along the Silk Road. By the 18th century it ___(become) a daily drink in Britain. Today, tea culture, ___ dates back thousands of years, still connects people.',
      answer:'grown；had become；which',
      steps:[
        '第一空作后置定语，茶被种植，用过去分词 grown',
        '第二空前有 By the 18th century，用过去完成时 had become',
        '第三空引导非限制性定语从句，指代 tea culture，用 which',
        '填空先判成分，再定时态与语态'
      ],
      points:['非谓语动词','过去完成时','定语从句'],
      why:'语法填空的每个空都是一个语法点，先判成分再定时态',
      note:'改编自 2024 年新课标Ⅰ卷语法填空同型题',
      view:{
        engine:'subjects', mode:'syntax', params:{},
        data:{
          sentence:'Tea culture, which dates back thousands of years, still connects people.',
          tree:{root:'connects', subject:'Tea culture', modifier:'which dates back thousands of years', object:'people'}
        }
      }
    },
    {
      id:'h-2024-xkz-42', year:2024, paper:'新课标卷', subject:'历史', type:'材料',
      title:'技术变革与社会结构',
      stem:'阅读材料，完成要求。材料：19 世纪中后期，蒸汽机、铁路与电报相继普及，工厂规模扩大，城市人口迅速增加，有限责任公司与证券交易所成为经济生活的常态。结合材料与所学，围绕“技术变革与社会结构”自拟论题，并加以阐述。',
      answer:'论题示例：技术变革重塑社会结构（言之成理即可）',
      steps:[
        '提炼材料主线：技术、生产组织、社会结构',
        '拟论题要含两个要素，如蒸汽动力推动城市化',
        '史实选工业革命：工厂制、城市化、工人阶级',
        '结论回扣：技术通过改变生产组织改变社会'
      ],
      points:['工业革命','城市化','唯物史观'],
      why:'开放论述题先搭因果链，再填史实，避免堆砌知识点',
      note:'改编自 2024 年新课标卷文综论述题同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:1765,title:'珍妮纺纱机',note:'棉纺织业机械化起步'},
          {year:1825,title:'英国铁路通车',note:'交通运输革命'},
          {year:1851,title:'伦敦世博会',note:'工业文明集中展示'}
        ]}
      }
    },
    {
      id:'g-2024-xkz-36', year:2024, paper:'新课标卷', subject:'地理', type:'材料',
      title:'风电基地区位分析',
      stem:'某地位于我国西北内陆，地势平坦开阔，人口稀少，煤炭资源丰富但水资源短缺。近年来该地建设大型风电基地，并通过特高压线路向东送电。分析该地发展风电的有利区位条件。',
      answer:'风能丰富、土地廉价、政策支持、外送通道完善',
      steps:[
        '靠近冬季风源地，地形平坦，风能资源丰富',
        '地广人稀，土地租金低，适合连片布局',
        '国家能源转型政策与补贴支持',
        '特高压外送通道解决本地消纳不足'
      ],
      points:['风能区位','资源跨区域调配','区域可持续发展'],
      why:'区位题按资源、土地、市场、政策四条线找，别只答自然条件',
      note:'改编自 2024 年新课标卷地理综合题同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.2,y:0.35,label:'风电场'},
            {x:0.55,y:0.5,label:'换流站'},
            {x:0.85,y:0.62,label:'东部负荷中心'}
          ],
          arrows:[
            {x1:0.2,y1:0.35,x2:0.55,y2:0.5,label:'集电'},
            {x1:0.55,y1:0.5,x2:0.85,y2:0.62,label:'特高压'}
          ]
        }
      }
    },
    {
      id:'g-2024-xkz-37', year:2024, paper:'新课标卷', subject:'地理', type:'材料',
      title:'产业转移对转入地的影响',
      stem:'近年来，我国东部沿海部分劳动密集型产业向中西部转移。说明这种产业转移对中西部地区的影响。',
      answer:'增加就业与税收，也带来污染和土地压力',
      steps:[
        '有利：增加就业岗位，促进工业化和城镇化',
        '有利：带来资金、技术与管理经验',
        '不利：承接污染环节，环境压力增大',
        '不利：用地紧张，产业层次偏低'
      ],
      points:['产业转移','区域发展','可持续发展'],
      why:'影响题必须两面答，且要落到转入地的具体要素上',
      note:'改编自 2024 年新课标卷地理综合题同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{title:'转入地影响', lines:['就业与税收增加','技术与管理的溢出','环境与土地压力上升'], steps:['先答有利面','再答不利面','最后给对策']}
      }
    }
  ]);
})();
