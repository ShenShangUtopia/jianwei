/* 2023 题库 */
(function () {
  JW.addQuestions([
    {
      id:'m-2023-nh1-04', year:2023, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'复合函数单调性求参数',
      stem:'设函数 f(x)=2^u，其中 u=x^2−ax。若 f(x) 在区间 (0,1) 上单调递减，则 a 的取值范围是（　）',
      answer:'a≥2，即 [2,+∞)',
      steps:[
        '外层 y=2^u 递增，整体递减要靠内层 u 递减',
        'u=x^2−ax 的对称轴是 x=a/2',
        '要求 u′=2x−a 在 (0,1) 上恒不超过 0',
        '端点处 2−a≤0，得 a≥2'
      ],
      points:['复合函数单调性','二次函数对称轴','恒成立问题'],
      why:'外层递增时只有内层递减才能整体递减，别只盯开口方向',
      view:{
        engine:'graph', mode:'poly', expr:'A*((x-H)/B)^2+K',
        params:[
          {k:'A',label:'开口 A',min:0.5,max:2,step:0.1,v:1},
          {k:'B',label:'横向伸缩 B',min:0.5,max:2,step:0.1,v:1},
          {k:'H',label:'对称轴 x=H',min:0,max:4,step:0.1,v:1},
          {k:'K',label:'顶点纵标 K',min:-4,max:0,step:0.1,v:-1}
        ],
        xr:[-1,5], yr:[-4,6], ghost:'x^2-2*x',
        marks:[{x:1,y:-1,label:'(1,1−a)'}],
        call:'拖动 H 移动对称轴 · 看它何时越过 x=1'
      }
    },
    {
      id:'m-2023-nh1-06', year:2023, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'圆的切线夹角求正弦',
      stem:'过点 (0,−2) 与圆 x^2+y^2−4x−1=0 相切的两条直线的夹角为 α，则 sinα=（　）',
      answer:'√15/4',
      steps:[
        '配方得圆心 (2,0)，半径 r=√5',
        '点到圆心距离 d=√(4+4)=2√2',
        '半角满足 sin(α/2)=r/d=√10/4',
        'cosα=1−2sin^2(α/2)=−1/4',
        '故 sinα=√(1−1/16)=√15/4'
      ],
      points:['直线与圆的位置关系','二倍角公式','切线长'],
      why:'两条切线的夹角，换到外点与切点构成的直角三角形里最好算',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'半角与二倍角',
          lines:['sin(α/2)=r/d=√10/4','cosα=1−2sin^2(α/2)=−1/4','sinα=√(1−cos^2α)=√15/4'],
          steps:['先求圆心与半径','再把夹角拆成半角','最后用二倍角回到 α']
        }
      }
    },
    {
      id:'m-2023-nh1-07', year:2023, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'等差数列与 Sn/n 的判定',
      stem:'记 S_n 为数列 {a_n} 的前 n 项和。甲：{a_n} 为等差数列；乙：{S_n/n} 为等差数列。则甲是乙的（　）',
      answer:'充要条件',
      steps:[
        '甲推乙：S_n=na_1+n(n−1)d/2，除以 n 是一次式',
        '乙推甲：设 S_n/n=cn+b，则 S_n=cn^2+bn',
        '由前 n 项和相减，n≥2 时 a_n=2cn−c+b',
        '两个方向都成立，所以是充要条件'
      ],
      points:['等差数列前 n 项和','an 与 Sn 的关系','充分必要条件'],
      why:'乙的说法本质仍是 Sn 为二次式，抓住这个等价形式就一眼看穿',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'判定链',
          lines:['a_n 等差 推 S_n 为二次式','S_n/n 等差 推 S_n 为二次式','两个方向都成立 得充要'],
          steps:['写出 S_n 的表达式','除以 n 看一次式','反过来由 S_n 求 a_n']
        }
      }
    },
    {
      id:'m-2023-nh1-08', year:2023, paper:'新课标Ⅰ卷', subject:'数学', type:'单选',
      title:'和差角求二倍角余弦',
      stem:'已知 sin(α−β)=1/3，cosαsinβ=1/6，则 cos(2α+2β)=（　）',
      answer:'1/9',
      steps:[
        '展开 sin(α−β)=sinαcosβ−cosαsinβ',
        '代入得 sinαcosβ=1/3+1/6=1/2',
        '相加得 sin(α+β)=1/2+1/6=2/3',
        'cos(2α+2β)=1−2×(2/3)^2=1/9'
      ],
      points:['两角和差的正弦','二倍角公式','整体代换'],
      why:'已知两式的和与差正好凑出 α+β 的正弦，不必单独解角',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'凑出 α+β',
          lines:['sinαcosβ=1/3+1/6=1/2','sin(α+β)=1/2+1/6=2/3','cos(2α+2β)=1−2sin^2(α+β)=1/9'],
          steps:['展开已知式','求出 sinαcosβ','相加后整体用二倍角']
        }
      }
    },
    {
      id:'p-2023-qgj-14', year:2023, paper:'全国甲卷', subject:'物理', type:'单选',
      title:'桌面平抛求水平距离',
      stem:'从高 h=0.80 m 的水平桌面边缘，以 v_0=3.0 m/s 水平抛出小球，g 取 10 m/s^2，不计空气阻力。求落地点到桌边的水平距离和落地速度大小。',
      answer:'水平距离 1.2 m；落地速度 5.0 m/s',
      steps:[
        '竖直自由落体：h=gt^2/2，得 t=0.40 s',
        '水平匀速：x=v_0t=1.2 m',
        '落地竖直分速度 v_y=gt=4.0 m/s',
        '合速度 v=√(3^2+4^2)=5.0 m/s'
      ],
      points:['平抛运动','运动的分解','速度的合成'],
      why:'平抛只拆两个方向，飞行时间由高度唯一决定，与水平速度无关',
      note:'改编自 2023 年全国甲卷平抛运动同型题',
      view:{engine:'physics', kind:'projectile', params:{v0:3,h0:0.8,g:10,angle:0}, cue:'水平位移与落地速度'}
    },
    {
      id:'p-2023-qgy-16', year:2023, paper:'全国乙卷', subject:'物理', type:'单选',
      title:'简谐运动位移与路程',
      stem:'一弹簧振子做简谐运动，周期 T=0.4 s，振幅 A=5 cm。从振子经过平衡位置向右运动开始计时，求 t=0.5 s 时振子的位移和通过的路程。',
      answer:'位移 +5 cm；路程 25 cm',
      steps:[
        '0.5 s=1.25T，先拆成 1 个周期加 1/4 周期',
        '一个周期路程 4A=20 cm，回到平衡位置',
        '剩下 T/4 从平衡位置走到正向最大位移',
        '位移取 +5 cm，路程 20+5=25 cm'
      ],
      points:['简谐运动','周期与路程','位移与路程'],
      why:'算路程按整周期拆，最后一段千万别把位移当成路程',
      note:'改编自 2023 年全国乙卷简谐运动同型题',
      view:{engine:'physics', kind:'spring', params:{m:0.1,k:24.7,A:0.05}, cue:'0.5 s 时的位移与路程'}
    },
    {
      id:'p-2023-qgj-20', year:2023, paper:'全国甲卷', subject:'物理', type:'解答',
      title:'斜面下滑求底端速度',
      stem:'质量 m=1.0 kg 的物块从倾角 37° 的斜面顶端由静止下滑，斜面长 L=4.0 m，动摩擦因数 μ=0.50，g 取 10 m/s^2。求物块滑到斜面底端时的速度大小。',
      answer:'4.0 m/s',
      steps:[
        '下滑高度 h=Lsin37°=2.4 m，重力做功 24 J',
        '摩擦力 f=μmgcos37°=4.0 N，做功 −16 J',
        '动能定理：24−16=mv^2/2=8 J',
        '解得 v=4.0 m/s'
      ],
      points:['动能定理','斜面受力分析','摩擦力做功'],
      why:'斜面题先算高度和摩擦力两笔功，比列牛顿定律再积分快得多',
      note:'改编自 2023 年全国甲卷斜面同型题',
      view:{engine:'physics', kind:'incline', params:{m:1,angle:37,mu:0.5,h:2.4,g:10}, cue:'滑到底端的速度'}
    },
    {
      id:'c-2023-qgj-08', year:2023, paper:'全国甲卷', subject:'化学', type:'单选',
      title:'阿伏加德罗常数正误',
      stem:'设 N_A 为阿伏加德罗常数的值。下列说法正确的是（　）A.1 mol N_2 与 3 mol H_2 充分反应，转移电子数为 6N_A B.标准状况下 22.4 L CCl_4 含分子数为 N_A C.1 L 0.1 mol/L Na_2CO_3 溶液中 CO_3^2− 数目为 0.1N_A D.1 mol 乙烯含碳碳双键数为 N_A',
      answer:'D',
      steps:[
        '合成氨可逆，1 mol N_2 不能完全转化，电子数小于 6N_A',
        '标准状况下 CCl_4 是液体，不能用 22.4 L/mol',
        'CO_3^2− 会水解，其数目小于 0.1N_A',
        '乙烯含 1 个碳碳双键，1 mol 即 N_A 个'
      ],
      points:['阿伏加德罗常数','可逆反应','盐类水解'],
      why:'NA 题的四个选项通常各埋一个坑：可逆、状态、水解、结构',
      note:'改编自 2023 年全国甲卷 NA 同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'四个坑',
          lines:['可逆反应：不能按完全转化算','物质状态：CCl4 标况为液体','盐类水解：离子数偏小','结构：乙烯只有 1 个 C=C'],
          steps:['先逐一排除','再确认 D 的结构计数']
        }
      }
    },
    {
      id:'c-2023-qgy-13', year:2023, paper:'全国乙卷', subject:'化学', type:'解答',
      title:'恒容平衡常数与转化率',
      stem:'恒温下向 2 L 密闭容器中充入 2 mol SO_2 和 1 mol O_2，发生反应 2SO_2(g)+O_2(g)⇌2SO_3(g)，平衡时生成 1.6 mol SO_3。求 SO_2 的转化率和该温度下的平衡常数 K。',
      answer:'转化率 80%；K=160',
      steps:[
        '三段式：SO_2 由 2 减到 0.4 mol，O_2 减到 0.2 mol',
        '平衡浓度：0.2、0.1、0.8 mol/L',
        '转化率 α=1.6/2=80%',
        'K=0.8^2/(0.2^2×0.1)=160'
      ],
      points:['化学平衡三段式','平衡常数','转化率'],
      why:'平衡计算先写三段式再除以体积，浓度和物质的量别混着用',
      note:'改编自 2023 年全国乙卷平衡常数同型题',
      view:{
        engine:'subjects', mode:'flow', params:{},
        data:{
          title:'三段式',
          lines:['起始：2、1、0 mol','变化：1.6、0.8、1.6 mol','平衡：0.4、0.2、1.6 mol'],
          steps:['写出三段式','除以体积得浓度','代入 K 表达式']
        }
      }
    },
    {
      id:'b-2023-qgj-32', year:2023, paper:'全国甲卷', subject:'生物', type:'解答',
      title:'两对等位基因决定花色',
      stem:'某二倍体植物花色由两对独立遗传的等位基因控制，同时含 A 和 B 时开紫花，其余开白花。基因型 AaBb 的植株自交，求 F_1 的表现型及比例；F_1 紫花中纯合子所占比例。',
      answer:'紫花:白花=9:7；紫花中纯合子占 1/9',
      steps:[
        'AaBb 自交，子代按 9:3:3:1 分布',
        '只有 A 与 B 同时存在才开紫花，占 9/16',
        '其余 7/16 开白花，故紫花:白花=9:7',
        '紫花中纯合 AABB 占 1/16，故为 1/9'
      ],
      points:['基因自由组合定律','表现型比例','纯合子判断'],
      why:'9:7 是 9:3:3:1 的合并，先认清哪一类才表现显性性状',
      note:'改编自 2023 年全国甲卷自由组合同型题',
      view:{
        engine:'subjects', mode:'genetics', params:{},
        data:{cross:{father:'AaBb',mother:'AaBb',trait:'花色',dominant:'A_B_'}}
      }
    },
    {
      id:'y-2023-nh1-23', year:2023, paper:'新课标Ⅰ卷', subject:'语文', type:'材料',
      title:'故事的力量',
      stem:'好的故事，可以帮我们更好地表达和沟通，可以触动心灵、启迪智慧；好的故事，可以改变一个人的命运，可以展现一个民族的形象……故事是有力量的。以上材料引发了你怎样的联想和思考？请写一篇文章。',
      answer:'立意：故事何以有力量，如何讲好故事',
      steps:[
        '抓住材料三层：表达沟通、触动心灵、塑造形象',
        '把“力量”具体化：故事降低理解成本、传递价值',
        '选例一古一今，避免堆砌名人名言',
        '结尾回到“讲好故事”的能力与责任'
      ],
      points:['材料作文审题','故事与表达','文化自信'],
      why:'材料给了三层递进，高下在于能否说清“力量”的机制',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'故事的力量',
          material:'好的故事可以表达沟通、触动心灵、展现民族形象',
          tasks:['自拟标题','不少于 800 字','不要套作'],
          angles:['故事的共情机制','讲好中国故事','个人叙事与时代'],
          outline:{thesis:'故事的力量来自共情与共识', points:[
            {text:'故事降低理解成本',evidences:['用具体人物代替抽象说理','日常经验的重新讲述']},
            {text:'故事传递价值与认同',evidences:['民族叙事中的共同记忆','经典文本的反复讲述']},
            {text:'讲好故事是一种能力',evidences:['真实细节优先','克制抒情，留白给读者']}
          ]}
        }
      }
    },
    {
      id:'e-2023-nh1-46', year:2023, paper:'新课标Ⅰ卷', subject:'英语', type:'材料',
      title:'邀请外教担任评委',
      stem:'假定你是李华，你校英语演讲比赛将于下周五举行。请给外教 Chris 写一封邮件，邀请他担任评委，并说明比赛时间、地点与评分要点。词数 80 左右。',
      answer:'Invitation email: time, place, duties',
      steps:[
        '开头点明写信目的：invite him to be a judge',
        '交代时间地点：next Friday, school hall',
        '说明职责：score content, fluency and delivery',
        '结尾表达期待并请对方回复'
      ],
      points:['应用文写作','邀请信结构','礼貌表达'],
      why:'应用文得分点在信息完整与语气得体，不在词藻华丽',
      note:'改编自 2023 年新课标Ⅰ卷应用文同型题',
      view:{
        engine:'subjects', mode:'composition', params:{},
        data:{
          title:'Invitation email',
          material:'Invite foreign teacher Chris to judge an English speech contest',
          tasks:['about 80 words','cover time, place and duties'],
          angles:['purpose first','clear information','polite tone'],
          outline:{thesis:'A good invitation covers purpose, information and tone', points:[
            {text:'State the purpose first',evidences:['Mention the speech contest directly','Say why his judging matters']},
            {text:'Give time, place and duties',evidences:['Next Friday, school hall','Score content, fluency and delivery']},
            {text:'Close politely',evidences:['Express thanks in advance','Ask for a reply']}
          ]}
        }
      }
    },
    {
      id:'h-2023-qgj-24', year:2023, paper:'全国甲卷', subject:'历史', type:'单选',
      title:'商鞅变法与土地私有',
      stem:'商鞅变法“废井田，开阡陌”，允许土地买卖。这一措施最深远的影响是（　）',
      answer:'确立土地私有制，推动封建生产关系形成',
      steps:[
        '井田制下土地名义上归国家所有',
        '开阡陌承认私田合法，土地可以买卖',
        '土地私有激发生产积极性，新兴地主壮大',
        '经济基础变化推动郡县制等上层建筑变革'
      ],
      points:['商鞅变法','土地制度','经济基础与上层建筑'],
      why:'“最深远”要答制度层面的变化，而不是一时的富国强兵',
      note:'改编自 2023 年全国甲卷商鞅变法同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:356,title:'商鞅变法',note:'废井田、开阡陌'},
          {year:221,title:'秦统一',note:'郡县制推行全国'},
          {year:202,title:'汉初休养生息',note:'土地兼并渐起'}
        ]}
      }
    },
    {
      id:'h-2023-qgy-30', year:2023, paper:'全国乙卷', subject:'历史', type:'材料',
      title:'五口通商与自然经济解体',
      stem:'1842 年《南京条约》开放广州、厦门、福州、宁波、上海五处为通商口岸。结合所学，说明五口通商对中国经济结构最直接的影响。',
      answer:'东南沿海自然经济开始解体，被卷入世界市场',
      steps:[
        '通商口岸集中在东南沿海，交通便利',
        '外国商品涌入，手工棉纺织业首先受冲击',
        '农产品出口增加，农业生产商品化',
        '自然经济开始解体，中国经济被卷入世界市场'
      ],
      points:['南京条约','自然经济解体','近代经济结构'],
      why:'“最直接”限定在经济结构，不要答成政治或思想影响',
      note:'改编自 2023 年全国乙卷同型题',
      view:{
        engine:'subjects', mode:'timeline', params:{},
        data:{events:[
          {year:1842,title:'《南京条约》',note:'五口通商'},
          {year:1861,title:'洋务运动起步',note:'近代工业出现'},
          {year:1895,title:'《马关条约》',note:'允许设厂，资本输出'}
        ]}
      }
    },
    {
      id:'g-2023-qgj-37', year:2023, paper:'全国甲卷', subject:'地理', type:'材料',
      title:'河流水文特征分析',
      stem:'读某河流域示意图（源头海拔高、中下游地势平坦、流域内降水集中在夏季），说明该河的水文特征并分析原因。',
      answer:'流量较大且季节变化大，含沙量小，无结冰期',
      steps:[
        '降水集中夏季，流量季节变化大',
        '中下游地势平坦，流速慢，泥沙易沉积',
        '流域植被覆盖较好，含沙量小',
        '地处亚热带，最冷月均温高于 0℃，无结冰期'
      ],
      points:['河流水文特征','气候与径流','地形与含沙量'],
      why:'水文特征从流量、汛期、含沙量、结冰期四条线分别找依据',
      note:'改编自 2023 年全国甲卷河流水文同型题',
      view:{
        engine:'subjects', mode:'map', params:{},
        data:{
          points:[
            {x:0.22,y:0.78,label:'源头'},
            {x:0.52,y:0.5,label:'中游'},
            {x:0.82,y:0.22,label:'入海口'}
          ],
          arrows:[
            {x1:0.22,y1:0.78,x2:0.52,y2:0.5,label:'干流'},
            {x1:0.52,y1:0.5,x2:0.82,y2:0.22,label:'下游'}
          ]
        }
      }
    }
  ]);
})();
