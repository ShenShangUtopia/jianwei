"""见微 · 五个页面：今日 / 观澜 / 倒计时 / 析题台 / 设置。"""
from __future__ import annotations

import math
import os
import subprocess
from datetime import date, datetime

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QPainter
from PySide6.QtWidgets import (
    QCheckBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QScrollArea, QSizePolicy,
    QSlider, QVBoxLayout, QWidget,
)

import store
from countdown import draw_pill
from ui_kit import Btn, C, Card, Chip, Dot, TickRow, divider, f, kicker, label, row, serif

WEEK_CN = "一二三四五六日"


def _clip(text: str, n: int = 56) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= n else text[: n - 1] + "…"


def scroll(widget: QWidget) -> QScrollArea:
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QScrollArea.Shape.NoFrame)
    area.setWidget(widget)
    area.setStyleSheet("QScrollArea{background:transparent;border:none;}")
    return area


class Page(QWidget):
    def __init__(self, ctx, kick: str, title: str, sub: str = ""):
        super().__init__()
        self.ctx = ctx
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        inner = QWidget()
        self.body = QVBoxLayout(inner)
        self.body.setContentsMargins(30, 24, 30, 28)
        self.body.setSpacing(15)
        self.body.addWidget(kicker(kick))
        head = QHBoxLayout()
        head.setSpacing(10)
        t = QLabel(title)
        t.setFont(f(21, 600, 0.3))
        t.setStyleSheet("color:#081F5C;background:transparent;")
        head.addWidget(t)
        if sub:
            s = QLabel(sub)
            s.setFont(f(11))
            s.setStyleSheet("color:#93A0B8;background:transparent;")
            head.addWidget(s, 0, Qt.AlignmentFlag.AlignBottom)
        head.addStretch(1)
        self.head = head
        self.body.addLayout(head)
        self.body.addWidget(divider())
        self.body.addSpacing(2)
        self.inner = inner
        outer.addWidget(scroll(inner))

    def add(self, w):
        if isinstance(w, QWidget):
            self.body.addWidget(w)
        else:
            self.body.addLayout(w)
        return w


# ------------------------------------------------------------------ 今日
def _hero(ctx) -> Card:
    cfg = ctx.cfg
    now = datetime.now()
    target = store.target_dt(cfg)
    start = store.start_dt(cfg)
    secs = max(0.0, (target - now).total_seconds())
    days = int(secs // 86400)
    weeks_total = max(1, math.ceil((target - start).days / 7))
    weeks_left = max(0, math.ceil(secs / 604800))
    progress = min(1.0, max(0.0, 1 - secs / max(1.0, (target - start).total_seconds())))

    card = Card("", pad=(26, 22, 26, 20))
    top = QHBoxLayout()
    top.setSpacing(30)
    left = QVBoxLayout()
    left.setSpacing(2)
    left.addWidget(kicker(f"{cfg.get('year', '2027')} 届 · 距{cfg.get('label', '高考')}"))
    num_row = QHBoxLayout()
    num_row.setSpacing(8)
    num = QLabel(str(days))
    num.setFont(serif(58, 600))
    num.setStyleSheet("color:#081F5C;background:transparent;")
    unit = QLabel("天")
    unit.setFont(f(13))
    unit.setStyleSheet("color:#5F6E8C;background:transparent;")
    num_row.addWidget(num, 0, Qt.AlignmentFlag.AlignBottom)
    num_row.addWidget(unit, 0, Qt.AlignmentFlag.AlignBottom)
    num_row.addSpacing(12)
    target_lab = QLabel(f"{target:%Y.%m.%d} 09:00 · 北京时间")
    target_lab.setFont(f(11))
    target_lab.setStyleSheet("color:#93A0B8;background:transparent;")
    num_row.addWidget(target_lab, 0, Qt.AlignmentFlag.AlignBottom)
    num_row.addStretch(1)
    left.addLayout(num_row)
    top.addLayout(left, 1)

    right = QVBoxLayout()
    right.setSpacing(6)
    rowk = QHBoxLayout()
    rk = QLabel("本学期刻度")
    rk.setFont(f(10.5, 600, 1.6))
    rk.setStyleSheet("color:#93A0B8;background:transparent;")
    rowk.addWidget(rk)
    rowk.addStretch(1)
    rv = QLabel(f"已过 {int(progress * 100)}%")
    rv.setFont(serif(13, 600))
    rv.setStyleSheet("color:#334EAC;background:transparent;")
    rowk.addWidget(rv)
    right.addLayout(rowk)
    bars = TickRow(weeks_total, int(progress * weeks_total), f"剩 {weeks_left} 周")
    right.addWidget(bars)
    rsub = QLabel(f"每格 = 1 周 · 共 {weeks_total} 周 · 今天周{WEEK_CN[now.weekday()]}")
    rsub.setFont(f(10.5))
    rsub.setStyleSheet("color:#93A0B8;background:transparent;")
    right.addWidget(rsub)
    top.addLayout(right, 1)
    card.body.addLayout(top)
    return card


def _today_question_card(ctx) -> Card:
    q = store.question_of_day()
    card = Card("今日一题", "每天换一道，来自 2023—2025 真题")
    if not q:
        card.add(label("题库尚未就绪", 12, C.FAINT, wrap=True))
        return card
    meta = QLabel(f"{q['subject']} · {q['year']} 年 · {q['paper']}")
    meta.setFont(f(10.5, 600, 1.2))
    meta.setStyleSheet("color:#334EAC;background:transparent;")
    card.add(meta)
    t = QLabel(q["title"])
    t.setFont(f(15, 600))
    t.setWordWrap(True)
    t.setStyleSheet("color:#081F5C;background:transparent;")
    card.add(t)
    stem = QLabel(_clip(q["stem"], 76))
    stem.setFont(f(11.5))
    stem.setWordWrap(True)
    stem.setStyleSheet("color:#5F6E8C;background:transparent;")
    card.add(stem)
    card.body.addStretch(1)
    btn = Btn("打开解析 →", "primary")
    btn.setFixedWidth(112)
    btn.clicked.connect(lambda: ctx.open_question(q["id"]))
    card.add(row(btn, None))
    return card


def _guanlan_card(ctx) -> Card:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    card = Card("观澜 · 今日焦点", store.guanlan_date() or "等待今日版")
    t = QLabel(_clip(lead.get("title", ""), 46) or "今日版尚未生成")
    t.setFont(f(14.5, 600))
    t.setWordWrap(True)
    t.setStyleSheet("color:#081F5C;background:transparent;")
    card.add(t)
    if lead.get("summary"):
        s = QLabel(_clip(lead["summary"], 78))
        s.setFont(f(11.5))
        s.setWordWrap(True)
        s.setStyleSheet("color:#5F6E8C;background:transparent;")
        card.add(s)
    for i, st in enumerate(stories[1:4], start=2):
        line = QLabel(f"{i:02d}　{_clip(st['title'], 34)}")
        line.setFont(f(11))
        line.setStyleSheet("color:#44557A;background:transparent;")
        card.add(line)
    card.body.addStretch(1)
    btn = Btn("打开浮窗", "soft", "在桌面上打开观澜浮窗")
    btn.setFixedWidth(96)
    btn.clicked.connect(ctx.toggle_guanlan)
    more = QLabel(f"共 {len(stories)} 条 · 约 15 分钟")
    more.setFont(f(10.5))
    more.setStyleSheet("color:#93A0B8;background:transparent;")
    card.add(row(btn, more, None))
    return card


def _modules_card(ctx) -> Card:
    card = Card("模块", "三个入口，一个托盘")
    rows = [
        ("观澜视界", "桌面浮窗 · 每日 7 条世界线索", "打开", ctx.toggle_guanlan),
        ("倒计时胶囊", "置顶磨砂胶囊 · 点击穿透可选", "显示", ctx.toggle_pill),
        ("习题台", "题目可视化 · 引导动画 / 作图讲解", "进入", lambda: ctx.goto("studio")),
    ]
    for name, desc, act, fn in rows:
        line = QHBoxLayout()
        line.setSpacing(10)
        line.addWidget(Dot(C.JADE if name != "析题台" else C.ACCENT), 0, Qt.AlignmentFlag.AlignVCenter)
        n = QLabel(name)
        n.setFont(f(12.5, 600))
        n.setStyleSheet("color:#081F5C;background:transparent;")
        n.setFixedWidth(96)
        line.addWidget(n)
        d = QLabel(desc)
        d.setFont(f(11))
        d.setStyleSheet("color:#93A0B8;background:transparent;")
        line.addWidget(d, 1)
        b = Btn(act, "soft")
        b.setFixedWidth(64)
        b.clicked.connect(fn)
        line.addWidget(b)
        card.body.addLayout(line)
    return card


def build_overview(ctx) -> QWidget:
    now = datetime.now()
    page = Page(ctx, "见微 · 高考学习舱", "今日", f"{now:%Y 年 %m 月 %d 日} · 周{WEEK_CN[now.weekday()]}")
    page.add(_hero(ctx))
    grid = QGridLayout()
    grid.setSpacing(15)
    grid.addWidget(_today_question_card(ctx), 0, 0)
    grid.addWidget(_guanlan_card(ctx), 0, 1)
    grid.setColumnStretch(0, 1)
    grid.setColumnStretch(1, 1)
    page.add(grid)
    page.add(_modules_card(ctx))
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 观澜
def build_guanlan(ctx) -> QWidget:
    lead = store.guanlan_lead()
    stories = store.guanlan_stories()
    page = Page(ctx, "观澜 · 每日世界线索", "观澜视界", "深色浮窗 · 暮省长卷")
    lead_card = Card("", pad=(24, 20, 24, 20))
    lead_card.add(kicker(f"今日焦点 · {store.guanlan_date() or '—'}"))
    t = QLabel(lead.get("title", "") or "今日版尚未生成")
    t.setFont(f(23, 600, 0.2))
    t.setWordWrap(True)
    t.setStyleSheet("color:#081F5C;background:transparent;")
    lead_card.add(t)
    if lead.get("summary"):
        s = QLabel(lead["summary"])
        s.setFont(f(12.5))
        s.setWordWrap(True)
        s.setStyleSheet("color:#5F6E8C;background:transparent;")
        lead_card.add(s)
    page.add(lead_card)

    if stories:
        list_card = Card("今日线索", f"共 {len(stories)} 条 · 约 15 分钟")
        for i, st in enumerate(stories, 1):
            line = QHBoxLayout()
            line.setSpacing(12)
            idx = QLabel(f"{i:02d}")
            idx.setFont(serif(12, 600))
            idx.setStyleSheet("color:#B9C3D6;background:transparent;")
            idx.setFixedWidth(22)
            line.addWidget(idx, 0, Qt.AlignmentFlag.AlignTop)
            col = QVBoxLayout()
            col.setSpacing(1)
            tt = QLabel(st["title"])
            tt.setFont(f(12.5, 500))
            tt.setWordWrap(True)
            tt.setStyleSheet("color:#081F5C;background:transparent;")
            col.addWidget(tt)
            meta = " · ".join(x for x in [st.get("source", ""),
                                          (f"{st['minutes']} 分钟" if st.get("minutes") else "")] if x)
            if meta:
                m = QLabel(meta)
                m.setFont(f(10.5))
                m.setStyleSheet("color:#93A0B8;background:transparent;")
                col.addWidget(m)
            line.addLayout(col, 1)
            list_card.body.addLayout(line)
            if i < len(stories):
                list_card.body.addWidget(divider())
        page.add(list_card)

    acts = QHBoxLayout()
    acts.setSpacing(8)
    b1 = Btn("打开观澜浮窗", "primary")
    b1.clicked.connect(ctx.toggle_guanlan)
    b2 = Btn("暮省全屏")
    b2.clicked.connect(ctx.evening)
    b3 = Btn("刷新内容")
    b3.clicked.connect(ctx.refresh_guanlan)
    acts.addWidget(b1)
    acts.addWidget(b2)
    acts.addWidget(b3)
    acts.addStretch(1)
    note = QLabel("内容每天 07:15 由观澜抓取；刷新需要网络，约 30 秒")
    note.setFont(f(10.5))
    note.setStyleSheet("color:#93A0B8;background:transparent;")
    acts.addWidget(note)
    page.add(acts)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 实验室
def build_lab(ctx) -> QWidget:
    page = Page(ctx, "变换实验室 · 自由操作", "变换实验室",
                "数学作图与变换 · 物理自由搭场景")
    intro = QLabel("这里不是题目讲解，而是一张可以自由动手的台面：数学画板做点线圆与函数，"
                   "再用平移、旋转、缩放、对称去改；物理工作台从物体库里拖东西出来，改参数看它怎么动。")
    intro.setWordWrap(True)
    intro.setFont(f(12))
    intro.setStyleSheet("color:#5F6E8C;background:transparent;")
    page.add(intro)

    grid = QHBoxLayout()
    grid.setSpacing(15)

    math = Card("数学画板", "坐标系 · 函数 · 变换")
    math.add(label("点、线、圆、多边形、函数曲线都能画；选中之后做平移 / 旋转 / 缩放 / 对称，"
                   "原图留虚线，像用实线，右侧给出变换矩阵。", 12, C.SOFT, wrap=True))
    math.add(kicker("适合：函数图象、解析几何、变换综合题"))
    mb = Btn("打开数学画板", "primary")
    mb.clicked.connect(lambda: ctx.open_lab("math"))
    math.add(mb)

    phys = Card("物理工作台", "物体库 · 参数 · 仿真")
    phys.add(label("小车、斜面、弹簧、单摆、带电粒子、透镜、波源、卫星……从库里拖到台面上，"
                   "改质量、电荷、初速，直接看受力、轨迹与读数。", 12, C.SOFT, wrap=True))
    phys.add(kicker("适合：受力分析、电磁场、光学、振动与波、天体运动"))
    pb = Btn("打开物理工作台", "primary")
    pb.clicked.connect(lambda: ctx.open_lab("physics"))
    phys.add(pb)

    grid.addWidget(math, 1)
    grid.addWidget(phys, 1)
    page.add(grid)

    tips = Card("操作提示", "触摸屏也能用")
    tips.add(label("拖动空白平移画布，滚轮或双指捏合缩放；点选对象后在右侧改参数。"
                   "画板会记住上次的内容，导出按钮可以把画面存成 PNG。", 11.5, C.SOFT, wrap=True))
    page.add(tips)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 倒计时
class PillPreview(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setFixedHeight(132)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._t = QTimer(self)
        self._t.timeout.connect(self.update)
        self._t.start(1000)

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.fillRect(self.rect(), C.CARD)
        w = min(self.width() - 56, 700)
        scale = w / 700.0
        h = 52 * scale
        x = (self.width() - w) / 2
        y = (self.height() - h) / 2
        p.translate(x, y)
        p.scale(scale, scale)
        draw_pill(p, 700, 52, self.ctx.cfg, datetime.now(), None, 0.7)
        p.end()


def _slider(ctx, label_text: str, key: str, lo: int, hi: int, fmt=lambda v: str(v)) -> QWidget:
    box = QWidget()
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(3)
    top = QHBoxLayout()
    n = QLabel(label_text)
    n.setFont(f(11))
    n.setStyleSheet("color:#5F6E8C;background:transparent;")
    v = QLabel(fmt(ctx.cfg.get(key)))
    v.setFont(serif(12, 600))
    v.setStyleSheet("color:#081F5C;background:transparent;")
    top.addWidget(n)
    top.addStretch(1)
    top.addWidget(v)
    s = QSlider(Qt.Orientation.Horizontal)
    s.setRange(lo, hi)
    s.setValue(int(ctx.cfg.get(key, lo)))
    s.setCursor(Qt.CursorShape.PointingHandCursor)

    def on_change(val):
        v.setText(fmt(val))
        ctx.cfg[key] = val if isinstance(ctx.cfg.get(key), int) else val
        ctx.apply_pill()

    s.valueChanged.connect(on_change)
    lay.addLayout(top)
    lay.addWidget(s)
    return box


def build_countdown(ctx) -> QWidget:
    page = Page(ctx, "倒计时 · 屏幕顶端胶囊", "高考倒计时", "置顶悬浮 · 磨砂玻璃")
    preview = Card("", pad=(16, 14, 16, 14))
    preview.add(PillPreview(ctx))
    cap = QLabel("预览为无背景版本；桌面上的胶囊会实时折射屏幕底下的画面")
    cap.setFont(f(10.5))
    cap.setStyleSheet("color:#93A0B8;background:transparent;")
    preview.add(cap)
    page.add(preview)

    ctrl = Card("外观与行为", "改动立即生效，自动保存")
    date_row = QHBoxLayout()
    date_row.setSpacing(8)
    dl = QLabel("目标时刻")
    dl.setFont(f(11))
    dl.setStyleSheet("color:#5F6E8C;background:transparent;")
    date_row.addWidget(dl)
    edit = QLineEdit(ctx.cfg.get("target", "2027-06-07 09:00:00"))
    edit.setFixedWidth(190)
    date_row.addWidget(edit)
    ok = Btn("应用")
    ok.setFixedWidth(56)

    def apply_date():
        txt = edit.text().strip()
        try:
            datetime.strptime(txt, "%Y-%m-%d %H:%M:%S")
            ctx.cfg["target"] = txt
            ctx.apply_pill()
            ctx.save()
            ctx.toast("目标时刻已更新")
        except Exception:
            ctx.toast("格式应为 2027-06-07 09:00:00")

    ok.clicked.connect(apply_date)
    date_row.addWidget(ok)
    date_row.addStretch(1)
    ctrl.body.addLayout(date_row)

    sliders = QGridLayout()
    sliders.setHorizontalSpacing(22)
    sliders.setVerticalSpacing(2)
    sliders.addWidget(_slider(ctx, "宽度", "width", 640, 1200), 0, 0)
    sliders.addWidget(_slider(ctx, "高度", "height", 52, 88), 0, 1)
    sliders.addWidget(_slider(ctx, "距顶部", "marginTop", 0, 160), 1, 0)
    sliders.addWidget(_slider(ctx, "极光", "aurora", 0, 90), 1, 1)
    ctrl.body.addLayout(sliders)

    checks = QHBoxLayout()
    checks.setSpacing(18)
    for text, key in (("显示秒", "showSeconds"), ("显示日期", "showDate"),
                      ("点击穿透", "clickThrough"), ("启动时显示", "showPill")):
        cb = QCheckBox(text)
        cb.setChecked(bool(ctx.cfg.get(key)))
        cb.toggled.connect(lambda v, k=key: (ctx.cfg.__setitem__(k, v), ctx.apply_pill(), ctx.save()))
        checks.addWidget(cb)
    top_cb = QCheckBox("置顶显示")
    top_cb.setChecked(str(ctx.cfg.get("zorder", "bottom")) == "top")
    top_cb.setToolTip("默认沉在最底层：只在壁纸上可见，任何窗口都能压住它")
    top_cb.toggled.connect(lambda v: (ctx.cfg.__setitem__("zorder", "top" if v else "bottom"),
                                      ctx.apply_pill(), ctx.save()))
    checks.addWidget(top_cb)
    checks.addStretch(1)
    ctrl.body.addLayout(checks)

    btns = QHBoxLayout()
    btns.setSpacing(8)
    b_show = Btn("显示胶囊", "primary")
    b_show.clicked.connect(lambda: ctx.show_pill(True))
    b_hide = Btn("隐藏胶囊")
    b_hide.clicked.connect(lambda: ctx.show_pill(False))
    b_center = Btn("回到顶部居中")
    b_center.clicked.connect(ctx.center_pill)
    for b in (b_show, b_hide, b_center):
        btns.addWidget(b)
    btns.addStretch(1)
    pre = QLabel("预设")
    pre.setFont(f(10.5))
    pre.setStyleSheet("color:#93A0B8;background:transparent;")
    btns.addWidget(pre)
    for name, (w, h) in (("极简", (720, 56)), ("标准", (880, 64)), ("影院", (1060, 72))):
        b = Btn(name, "soft")
        b.clicked.connect(lambda _=False, w=w, h=h: ctx.preset_pill(w, h))
        btns.addWidget(b)
    ctrl.body.addLayout(btns)
    page.add(ctrl)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 析题台
def build_studio(ctx) -> QWidget:
    qs = store.questions()
    subjects = []
    for q in qs:
        if q["subject"] and q["subject"] not in subjects:
            subjects.append(q["subject"])
    page = Page(ctx, "习题台 · 题目可视化", "习题台",
                f"{len(qs)} 题 · 2023—2025 真题")
    top = QHBoxLayout()
    top.setSpacing(8)
    b1 = Btn("打开习题台", "primary")
    b1.clicked.connect(lambda: ctx.open_studio(""))
    b2 = Btn("随机一题")
    b2.clicked.connect(ctx.random_question)
    b3 = Btn("变换实验室 · 数学")
    b3.clicked.connect(lambda: ctx.open_lab("math"))
    b3b = Btn("变换实验室 · 物理")
    b3b.clicked.connect(lambda: ctx.open_lab("physics"))
    b4 = Btn("导入题目")
    b4.clicked.connect(lambda: ctx.studio.open(imp=True))
    for b in (b1, b2, b3, b3b, b4):
        top.addWidget(b)
    top.addStretch(1)
    note = QLabel("习题台：一题一图，引导动画讲过程　实验室：自由作图 / 自由搭场景")
    note.setFont(f(10.5))
    note.setStyleSheet("color:#93A0B8;background:transparent;")
    top.addWidget(note)
    page.add(top)

    chips = QHBoxLayout()
    chips.setSpacing(6)
    state = {"cur": "全部"}

    holder = Card("题目索引", "按科目筛选")
    grid = QVBoxLayout()
    grid.setSpacing(0)
    holder.body.addLayout(grid)

    def fill():
        while grid.count():
            item = grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        cur = state["cur"]
        shown = [q for q in qs if cur == "全部" or q["subject"] == cur]
        if not shown:
            grid.addWidget(label("这个科目还没有题目", 12, C.FAINT))
        for q in shown:
            line = QHBoxLayout()
            line.setSpacing(10)
            subj = QLabel(q["subject"])
            subj.setFont(f(10.5, 600))
            subj.setStyleSheet("color:#334EAC;background:transparent;")
            subj.setFixedWidth(30)
            line.addWidget(subj)
            yr = QLabel(f"{q['year']}")
            yr.setFont(serif(11, 600))
            yr.setStyleSheet("color:#B9C3D6;background:transparent;")
            yr.setFixedWidth(34)
            line.addWidget(yr)
            t = QLabel(_clip(q["title"], 46))
            t.setFont(f(12))
            t.setStyleSheet("color:#081F5C;background:transparent;")
            line.addWidget(t, 1)
            p = QLabel(q["paper"])
            p.setFont(f(10.5))
            p.setStyleSheet("color:#93A0B8;background:transparent;")
            line.addWidget(p)
            open_btn = Btn("解析", "soft")
            open_btn.setFixedWidth(54)
            open_btn.clicked.connect(lambda _=False, qid=q["id"]: ctx.open_question(qid))
            line.addWidget(open_btn)
            wrap = QWidget()
            wrap.setLayout(line)
            grid.addWidget(wrap)
        grid.addStretch(1)

    chip_widgets: list[Chip] = []

    def set_subject(name: str) -> None:
        state["cur"] = name
        for c in chip_widgets:
            c.setChecked(c.text() == name)
        fill()

    for name in ["全部"] + subjects:
        ch = Chip(name)
        ch.setChecked(name == "全部")
        ch.clicked.connect(lambda _=False, n=name: set_subject(n))
        chip_widgets.append(ch)
        chips.addWidget(ch)
    chips.addStretch(1)
    page.add(chips)
    fill()
    page.add(holder)
    page.body.addStretch(1)
    return page


# ------------------------------------------------------------------ 设置
def build_settings(ctx) -> QWidget:
    page = Page(ctx, "见微 · 设置", "设置", "本地运行 · 不上传任何数据")
    startup = Card("启动与托盘")
    cb1 = QCheckBox("开机自动启动（随 Windows 登录，静默驻留托盘）")
    cb1.setChecked(ctx.autostart_enabled())
    cb1.toggled.connect(ctx.set_autostart)
    cb2 = QCheckBox("关闭窗口时最小化到托盘，而不是退出")
    cb2.setChecked(bool(ctx.cfg.get("closeToTray", True)))
    cb2.toggled.connect(lambda v: (ctx.cfg.__setitem__("closeToTray", v), ctx.save()))
    cb3 = QCheckBox("启动时直接进入托盘（不显示主窗口）")
    cb3.setChecked(bool(ctx.cfg.get("startMinimized", False)))
    cb3.toggled.connect(lambda v: (ctx.cfg.__setitem__("startMinimized", v), ctx.save()))
    for cb in (cb1, cb2, cb3):
        startup.add(cb)
    page.add(startup)

    daily = Card("每日节律", "由见微接管，不依赖原版观澜进程")
    cb4 = QCheckBox("启动时打开观澜浮窗（侧边窗口）")
    cb4.setChecked(bool(ctx.cfg.get("showGuanlanOnStart", True)))
    cb4.toggled.connect(lambda v: (ctx.cfg.__setitem__("showGuanlanOnStart", v), ctx.save()))
    cb5 = QCheckBox("每天 07:15 自动更新世界线索")
    cb5.setChecked(bool(ctx.cfg.get("autoFetch", True)))
    cb5.toggled.connect(lambda v: (ctx.cfg.__setitem__("autoFetch", v), ctx.save()))
    cb6 = QCheckBox("每天 22:20 自动生成并全屏播放暮省")
    cb6.setChecked(bool(ctx.cfg.get("autoEvening", True)))
    cb6.toggled.connect(lambda v: (ctx.cfg.__setitem__("autoEvening", v), ctx.save()))
    for cb in (cb4, cb5, cb6):
        daily.add(cb)
    acts = QHBoxLayout()
    b_now = Btn("现在生成暮省")
    b_now.clicked.connect(ctx.evening)
    b_fetch = Btn("现在就抓取")
    b_fetch.clicked.connect(ctx.refresh_guanlan)
    acts.addWidget(b_now)
    acts.addWidget(b_fetch)
    acts.addStretch(1)
    daily.add(acts)
    page.add(daily)

    data = Card("数据与题库")
    data.add(label(f"数据目录：{store.HOME}", 11, C.SOFT, wrap=True))
    data.add(label(f"析题台：{store.WEB_DIR}", 11, C.SOFT, wrap=True))
    qs = store.questions()
    data.add(label(f"本地题库：{len(qs)} 题（2023—2025 高考真题）。题目可视化在浏览器内核里运行，不联网。",
                   11, C.SOFT, wrap=True))
    btns = QHBoxLayout()
    open_dir = Btn("打开数据目录")
    open_dir.clicked.connect(lambda: subprocess.Popen(["explorer", str(store.HOME)]))
    rescan = Btn("重新扫描题库")
    rescan.clicked.connect(ctx.rescan_bank)
    btns.addWidget(open_dir)
    btns.addWidget(rescan)
    btns.addStretch(1)
    data.add(btns)
    page.add(data)

    about = Card("关于")
    about.add(label(f"见微 · 高考学习舱　v{store.VERSION}", 13, C.INK, 600))
    about.add(label("一个托盘 + 三个模块：观澜视界（每日世界线索）、倒计时胶囊（屏幕顶端）、析题台（题目可视化）。"
                    "界面遵循青瓷蓝：纸底、墨蓝、单色相阶梯，数字用衬线。", 11.5, C.SOFT, wrap=True))
    about.add(label("开发约定：全程不弹任何窗口；截图验证一律无头模式。", 10.5, C.FAINT, wrap=True))
    page.add(about)
    page.body.addStretch(1)
    return page
