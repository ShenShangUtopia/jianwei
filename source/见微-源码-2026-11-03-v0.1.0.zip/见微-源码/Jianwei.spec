# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = ['core.paths', 'core.evening', 'core.curator', 'core.autostart']
hiddenimports += collect_submodules('core')
hiddenimports += collect_submodules('ui')


a = Analysis(
    ['C:/Users/Administrator/Documents/deepseek-harness/default-workspace/10-projects/jianwei/app/main.py'],
    pathex=['C:/Users/Administrator/Documents/deepseek-harness/default-workspace/10-projects/jianwei/app/guanlan'],
    binaries=[],
    datas=[('C:/Users/Administrator/Documents/deepseek-harness/default-workspace/10-projects/jianwei/app/studio/web', 'studio/web'), ('C:/Users/Administrator/Documents/deepseek-harness/default-workspace/10-projects/jianwei/app/guanlan', 'guanlan'), ('C:/Users/Administrator/Documents/deepseek-harness/default-workspace/10-projects/jianwei/app/assets', 'assets')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Jianwei',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:/Users/Administrator/Documents/deepseek-harness/default-workspace/10-projects/jianwei/app/assets/icon.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Jianwei',
)
