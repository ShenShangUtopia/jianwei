"""见微 · 建桌面快捷方式（用 UTF-16LE 的 VBScript，彻底绕开中文编码坑）。

PowerShell 的 -Command/-File 在本机 CP936 控制台下会把「见微」写坏，
WScript.Shell 走 UTF-16LE 的 VBS 才稳定。
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXE = ROOT / "dist" / "Jianwei" / "Jianwei.exe"
LNK = Path.home() / "Desktop" / "见微.lnk"

VBS = f'''Set sh = CreateObject("WScript.Shell")
Set s = sh.CreateShortcut("{LNK}")
s.TargetPath = "{EXE}"
s.WorkingDirectory = "{EXE.parent}"
s.IconLocation = "{EXE}"
s.Description = "见微 · 高考学习舱"
s.Save
WScript.Echo "shortcut ok"
'''


def main() -> int:
    if not EXE.exists():
        print("先运行 build.py 打包：", EXE)
        return 1
    vbs = ROOT / "tmp" / "make_shortcut.vbs"
    vbs.parent.mkdir(parents=True, exist_ok=True)
    vbs.write_bytes(b"\xff\xfe" + VBS.encode("utf-16-le"))
    subprocess.run(["cscript", "//nologo", str(vbs)],
                   capture_output=True, text=True, errors="replace")
    ok = LNK.exists()
    print("桌面快捷方式：", LNK, "→", "已生成" if ok else "失败")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
