# 见微 · 源码包（2026-11-03）

这是「见微 · 高考学习舱」的 Python + PySide6 源码，可自行构建发行版。

## 结构

```
见微-源码/
├─ app/
│  ├─ main.py              程序入口（参数解析、主题、单实例）
│  ├─ shell.py             主窗口、托盘、页面路由、每日节律
│  ├─ pages.py             各页面 UI
│  ├─ ui_kit.py            主题与 QSS（白天/夜间）
│  ├─ scheduler.py         07:15 抓取 / 22:20 暮省
│  ├─ studio_server.py     习题台本地服务与页面打开
│  ├─ store.py             配置读写
│  ├─ guanlan_host.py      内嵌观澜：路径、数据目录、浮窗与胶囊
│  ├─ assets/              图标等
│  ├─ guanlan/             观澜源码（新闻抓取、暮省渲染、浮窗）
│  │  └─ core/evening.py   暮省页生成 + 全屏启动
│  └─ studio/
│     └─ web/              习题台与实验室的静态页面（HTML/CSS/JS）
│        ├─ index.html     习题台
│        ├─ lab.html       变换实验室
│        ├─ js/  css/      各视图与样式
│        └─ js/data/       2023–2025 题库
├─ build.py                PyInstaller 打包脚本
├─ Jianwei.spec            打包配置
├─ make_shortcut.py        生成桌面快捷方式
├─ switch_to_jianwei.py    开发用：切换运行目标
├─ tools/                  审计与页面接线工具
├─ HANDOFF.md              逐次改动记录（排查问题先看这里）
└─ README-使用说明.md       面向使用者的说明（同绿色版）
```

## 构建

```powershell
python -m venv .venv
.venv\Scripts\pip install PySide6 pyinstaller
.venv\Scripts\python build.py
# 产物：dist\Jianwei\Jianwei.exe（onedir，带 _internal）
```

构建后可以：

```powershell
dist\Jianwei\Jianwei.exe --background     # 只进托盘
dist\Jianwei\Jianwei.exe --evening        # 手动跑一次暮省
dist\Jianwei\Jianwei.exe --evening-no-open # 只生成暮省页，不弹窗
```

## 开发要点

- **主题**：`html[data-theme]` + CSS 变量；白天/夜间共用骨架，只换配色。切主题派发 `jw-theme` 事件。
- **习题台/实验室**：静态页，`window.JW` 命名空间；视图通过 `JW.registerView(engine, mountFn)` 注册。
- **暮省**：先生成单文件 HTML，再用 Edge kiosk 打开；本机 UAC 关闭时 Chromium 沙箱起不来，
  启动参数必须带 `--no-sandbox`（见 `HANDOFF.md` §20），并配 `evening.lock` 防重复触发。
- **无头验证**：`msedge --headless=new --screenshot=...`；不要在前台弹测试窗口。

## 依赖

- Windows 10/11 64 位
- Python 3.12+（本机为 3.14）
- PySide6 6.12、PyInstaller
- 运行期需要 Edge 或 Chrome（打开习题台/实验室/暮省页）

更细的改动史、每个坑的定位过程都在 `HANDOFF.md`。
