"""课件自测（离屏、不联网、不需要 Office）：内置排版、播放、笔迹、框选、黑板、存取。

用法：python -m native.lecture.selftest <输出目录>
"""
from __future__ import annotations

import os
import sys
import time
import zipfile
from pathlib import Path

CT = '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/></Types>'
NS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'
RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
LAST_FAILS = []


def _timing(effects):
    """PowerPoint 存的动画时间树：[(spid, 节点类型, 动画 XML)]。"""
    clicks, group, nid = "", "", [2]

    def i():
        nid[0] += 1
        return nid[0]

    def close():
        nonlocal clicks, group
        if group:
            clicks += f'<p:par><p:cTn id="{i()}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/></p:stCondLst><p:childTnLst><p:par><p:cTn id="{i()}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>{group}</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>'
            group = ""
    for spid, node, cls, filt, para in effects:
        if node == "clickEffect":
            close()
        tgt = f'<p:spTgt spid="{spid}"><p:txEl><p:pRg st="{para}" end="{para}"/></p:txEl></p:spTgt>' if para is not None else f'<p:spTgt spid="{spid}"/>'
        vis = "hidden" if cls == "exit" else "visible"
        group += (f'<p:par><p:cTn id="{i()}" presetID="10" presetClass="{cls}" presetSubtype="0" fill="hold" nodeType="{node}"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'
                  f'<p:set><p:cBhvr><p:cTn id="{i()}" dur="1" fill="hold"/><p:tgtEl>{tgt}</p:tgtEl><p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr><p:to><p:strVal val="{vis}"/></p:to></p:set>'
                  f'<p:animEffect transition="{"out" if cls == "exit" else "in"}" filter="{filt}"><p:cBhvr><p:cTn id="{i()}" dur="300"/><p:tgtEl>{tgt}</p:tgtEl></p:cBhvr></p:animEffect></p:childTnLst></p:cTn></p:par>')
    close()
    return f'<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst><p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>{clicks}</p:childTnLst></p:cTn></p:seq></p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>'


def _slide(title, body, tail="", attr=""):
    ids = iter((2, 3))

    def sp(x, y, w, h, sz, text, fill=""):
        return f'<p:sp><p:nvSpPr><p:cNvPr id="{next(ids)}" name="t"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>{fill}</p:spPr><p:txBody><a:bodyPr/><a:p><a:r><a:rPr sz="{sz}"/><a:t>{text}</a:t></a:r></a:p></p:txBody></p:sp>'
    fill = '<a:solidFill><a:srgbClr val="DCE8FF"/></a:solidFill>'
    return f'<?xml version="1.0" encoding="UTF-8"?><p:sld {NS}{attr}><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>{sp(600000, 400000, 8000000, 1000000, 3600, title)}{sp(600000, 1800000, 8000000, 2600000, 2400, body, fill)}</p:spTree></p:cSld>{tail}</p:sld>'


def make_pptx(path, n=4, extras=None):
    """extras：{第几张: (tail XML, 属性)}。"""
    extras = extras or {}
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("[Content_Types].xml", CT)
        z.writestr("_rels/.rels", f'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="{RT}/officeDocument" Target="ppt/presentation.xml"/></Relationships>')
        ids = "".join(f'<p:sldId id="{256 + i}" r:id="rId{i + 1}"/>' for i in range(n))
        z.writestr("ppt/presentation.xml", f'<?xml version="1.0"?><p:presentation {NS}><p:sldIdLst>{ids}</p:sldIdLst><p:sldSz cx="9144000" cy="5143500"/></p:presentation>')
        rels = "".join(f'<Relationship Id="rId{i + 1}" Type="{RT}/slide" Target="slides/slide{i + 1}.xml"/>' for i in range(n))
        z.writestr("ppt/_rels/presentation.xml.rels", f'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rels}</Relationships>')
        for i in range(n):
            z.writestr(f"ppt/slides/slide{i + 1}.xml", _slide(f"第 {i + 1} 页 比较优势", "比较优势是指一个国家生产某种产品的机会成本较低。", *extras.get(i + 1, ("", ""))))


def make_docx(path):
    w = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    paras = "".join(f"<w:p><w:r><w:t>第 {i} 段：光合作用把光能转化为化学能，储存在有机物中。这一段用来撑满页面，检查分页是否正常。</w:t></w:r></w:p>" for i in range(1, 80))
    table = "<w:tbl><w:tr><w:tc><w:p><w:r><w:t>光反应</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>暗反应</w:t></w:r></w:p></w:tc></w:tr></w:tbl>"
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("[Content_Types].xml", CT)
        z.writestr("_rels/.rels", f'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="{RT}/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr("word/document.xml", f'<?xml version="1.0"?><w:document {w}><w:body><w:p><w:r><w:rPr><w:b/><w:sz w:val="44"/></w:rPr><w:t>第一章 光合作用</w:t></w:r></w:p>{table}{paras}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>')


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    out = Path(argv.pop(0) if argv else "lecture-out")
    out.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("JIANWEI_HOME", str(out / "home"))
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    if os.path.isdir(r"C:\Windows\Fonts"):
        os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    from PySide6.QtCore import QEvent, QPoint, QPointF, QRectF, Qt
    from PySide6.QtGui import QImage, QKeyEvent, QMouseEvent, QWheelEvent
    from PySide6.QtWidgets import QApplication, QFileDialog
    app = QApplication.instance() or QApplication(sys.argv[:1])
    QFileDialog.getSaveFileName = staticmethod(lambda *_a, **_k: ("", ""))
    from . import builtin, convert, library, lookup
    from .page import LecturePage
    from .player import LecturePlayer

    fails = []

    def check(name, ok, info=""):
        print(("ok  " if ok else "FAIL"), name, info if not ok else "", flush=True)
        if not ok:
            fails.append(name)

    def spin(sec):
        t = time.perf_counter()
        while time.perf_counter() - t < sec:
            app.processEvents()
            time.sleep(0.004)

    # ---- 文件 → 库（内置排版，不依赖本机软件）
    px, dx = out / "fixture.pptx", out / "fixture.docx"
    make_pptx(px)
    make_docx(dx)
    m1 = library.import_file(px, use_com=False)
    m2 = library.import_file(dx, use_com=False)
    check("PPT 导入", m1["kind"] == "slides" and m1["pages"] == 4, m1)
    check("Word 导入并分页", m2["kind"] == "doc" and m2["pages"] >= 2, m2)
    check("重复导入不产生新份", library.import_file(px, use_com=False).get("existing") is True)
    check("缩略图", (library.folder(m1["id"]) / "thumb.png").is_file())
    try:
        library.import_file(out / "fixture.xyz", use_com=False)
        check("不支持的类型要报错", False)
    except convert.ConvertError as e:
        check("不支持的类型要报错", "PPT" in str(e))
    bad = out / "bad.pptx"
    bad.write_bytes(b"not a zip")
    try:
        library.import_file(bad, use_com=False)
        check("坏文件要报错", False)
    except convert.ConvertError as e:
        check("坏文件要报错", "损坏" in str(e), str(e))
    check("失败不留残骸", len(library.all_lectures()) == 2 and sum(1 for d in library.root().iterdir()) == 2)
    old = out / "old.ppt"
    old.write_bytes(b"x")
    try:
        library.import_file(old, use_com=False)
        check("坏的旧格式要报错", False)
    except convert.ConvertError as e:
        check("坏的旧格式要报错", "打不开" in str(e), str(e))
    # ---- 库页面
    lp = LecturePage()
    lp.resize(1200, 760)
    lp.show()
    app.processEvents()
    check("库里两张卡片", lp.grid.count() == 2, lp.grid.count())
    lp.grab().save(str(out / "library.png"))

    # ---- 播放
    w = LecturePlayer(m1)
    w.resize(1600, 900)
    w.show()
    spin(0.1)
    v = w.view

    def key(k, mod=Qt.KeyboardModifier.NoModifier):
        w.keyPressEvent(QKeyEvent(QEvent.Type.KeyPress, k, mod))

    def mouse(kind, pos, btn=Qt.MouseButton.LeftButton, target=None):
        target = target or v
        pos = QPointF(pos)
        held = Qt.MouseButton.NoButton if kind == QEvent.Type.MouseButtonRelease else btn
        e = QMouseEvent(kind, pos, target.mapToGlobal(pos), btn, held, Qt.KeyboardModifier.NoModifier)
        {QEvent.Type.MouseButtonPress: target.mousePressEvent, QEvent.Type.MouseMove: target.mouseMoveEvent, QEvent.Type.MouseButtonRelease: target.mouseReleaseEvent}[kind](e)

    def drag(a, b, n=12, target=None):
        mouse(QEvent.Type.MouseButtonPress, a, target=target)
        for i in range(1, n + 1):
            mouse(QEvent.Type.MouseMove, QPointF(a.x() + (b.x() - a.x()) * i / n, a.y() + (b.y() - a.y()) * i / n), target=target)
        mouse(QEvent.Type.MouseButtonRelease, b, target=target)

    r = v.page_rect()
    check("铺满而不变形", abs(r.width() / r.height() - 16 / 9) < 0.01 and r.width() <= 1600.5, r)
    key(Qt.Key.Key_Right)
    check("→ 下一页", v.page == 1)
    key(Qt.Key.Key_Left)
    check("← 上一页", v.page == 0)
    key(Qt.Key.Key_End)
    check("End 最后一页", v.page == 3)
    key(Qt.Key.Key_Right)
    check("最后一页不越界", v.page == 3)
    key(Qt.Key.Key_Home)
    mouse(QEvent.Type.MouseButtonPress, QPointF(800, 450))
    mouse(QEvent.Type.MouseButtonRelease, QPointF(800, 450))
    check("单击下一页", v.page == 1)
    v.go(0)
    # 笔
    key(Qt.Key.Key_P)
    check("P 选笔", v.tool == "pen" and w.tools["pen"].isChecked())
    drag(QPointF(300, 300), QPointF(900, 420))
    check("画一笔", len(v.history().strokes) == 1)
    st = v.history().strokes[0]
    check("笔迹存页面坐标", all(0 <= q[0] <= v.page_size()[0] and 0 <= q[1] <= v.page_size()[1] for q in st["pts"]) and len(st["pts"]) > 3)
    key(Qt.Key.Key_H)
    drag(QPointF(300, 500), QPointF(1000, 500))
    check("荧光笔", v.history().strokes[1]["tool"] == "marker")
    im0 = w.grab().toImage()
    check("笔迹画出来了", im0.pixelColor(QPoint(600, 360)) != QColor0(v, w), "")
    key(Qt.Key.Key_Z, Qt.KeyboardModifier.ControlModifier)
    check("撤销", len(v.history().strokes) == 1)
    key(Qt.Key.Key_Y, Qt.KeyboardModifier.ControlModifier)
    check("重做", len(v.history().strokes) == 2)
    key(Qt.Key.Key_E)
    drag(QPointF(600, 480), QPointF(600, 520))
    check("橡皮擦掉碰到的笔画", len(v.history().strokes) == 1, len(v.history().strokes))
    key(Qt.Key.Key_Z, Qt.KeyboardModifier.ControlModifier)
    check("橡皮可撤销", len(v.history().strokes) == 2)
    v.go(1)
    check("笔迹按页分开", len(v.history().strokes) == 0)
    v.go(0)
    check("回来笔迹还在", len(v.history().strokes) == 2)
    # 缩放后笔迹跟着页面
    p0 = v.to_view(QPointF(st["pts"][0][0], st["pts"][0][1]))
    v.set_zoom(2.0, QPointF(800, 450))
    spin(0.2)
    p1 = v.to_view(QPointF(st["pts"][0][0], st["pts"][0][1]))
    check("缩放后笔迹跟着放大", abs(v.page_rect().width() - r.width() * 2) < 1 and (p1 - p0).manhattanLength() > 10)
    w.grab().save(str(out / "zoom.png"))
    v.set_zoom(1.0)
    spin(0.2)
    # 框选
    key(Qt.Key.Key_S)
    check("S 选框选", v.tool == "select")
    a, b = QPointF(60, 180), QPointF(1100, 520)
    drag(a, b)
    check("框选成立", v.sel is not None and w.acts.isVisible())
    w.grab().save(str(out / "select.png"))
    sel = QRectF(v.sel)
    text = v.selection_text(sel)
    check("从文字层取到框内文字", "比较优势" in text, repr(text))
    outside = v.selection_text(QRectF(0, 0, 5, 5))
    check("框外文字不算", outside == "", repr(outside))
    cap = v.capture(sel)
    check("截图清晰度", max(cap.width(), cap.height()) >= 1500, (cap.width(), cap.height()))
    check("截图包含笔迹", cap.format() is not None and has_color(cap, lambda c: c.red() > 170 and c.green() < 110 and c.blue() < 110))
    drag(QPointF(100, 100), QPointF(103, 102))
    check("太小的框不算", v.sel is None and not w.acts.isVisible())
    drag(a, b)
    # 带入黑板
    btns = w.acts.findChildren(type(w.num_btn))
    next(x for x in btns if x.text() == "带入黑板").click()
    spin(0.15)
    c = w.board.canvas
    check("黑板收到截图", len(c.board["items"]) == 1 and c.board["items"][0]["type"] == "image")
    check("图按黑板视野放大小", c.board["items"][0]["w"] > c.width() * 0.4 and c.to_view_rect(QRectF(c.board["items"][0]["x"], 0, c.board["items"][0]["w"], 1)).left() >= 0, (c.board["items"][0]["w"], c.width()))
    check("自动分屏", w.view_mode == "split" and w.board.isVisible() and v.isVisible())
    check("选区清掉", v.sel is None and not w.acts.isVisible())
    item = c.board["items"][0]
    file = library.folder(m1["id"]) / "board" / item["file"]
    check("截图存到课件目录", file.is_file())
    w.grab().save(str(out / "split.png"))
    # 黑板
    x0 = item["x"]
    center = c.to_view_rect(QRectF(item["x"], item["y"], item["w"], item["h"])).center()
    drag(center, center + QPointF(60, 30), target=c)
    check("拖动图片", abs(item["x"] - x0 - 60 / c.scale) < 2, item["x"] - x0)
    vr = c.to_view_rect(QRectF(item["x"], item["y"], item["w"], item["h"]))
    w0 = item["w"]
    drag(vr.bottomRight(), vr.bottomRight() + QPointF(-40, -10), target=c)
    check("拉角缩放且保持比例", abs(item["w"] - (w0 - 40 / c.scale)) < 2 and abs(item["w"] / item["h"] - cap.width() / cap.height()) < 0.03)
    w.board.tools["chalk"].click()
    drag(QPointF(50, 40), QPointF(350, 60), target=c)
    check("粉笔写字", len(c.board["strokes"]) == 1 and c.board["strokes"][0]["tool"] == "chalk")
    c.undo()
    check("黑板撤销", len(c.board["strokes"]) == 0)
    c.redo()
    check("黑板重做", len(c.board["strokes"]) == 1)
    w.board.tools["eraser"].click()
    drag(QPointF(200, 30), QPointF(200, 70), target=c)
    check("板擦", len(c.board["strokes"]) == 0)
    c.undo()
    check("板擦可撤销", len(c.board["strokes"]) == 1)
    c.add_text("机会成本：放弃的最大收益")
    check("写文字", c.board["items"][-1]["type"] == "text")
    c.add_board()
    check("第二块黑板", len(c.boards) == 2 and c.cur == 1 and not c.board["items"])
    c.go_board(-1)
    check("回第一块", c.cur == 0 and len(c.board["items"]) == 2)
    ex = c.render_image()
    check("黑板存图", not ex.isNull() and ex.width() > 100)
    key(Qt.Key.Key_B)
    check("B 只看黑板", w.view_mode == "board" and not v.isVisible())
    w.grab().save(str(out / "board.png"))
    key(Qt.Key.Key_B)
    check("B 回课件", w.view_mode == "slide" and not w.board.isVisible())
    # 独立窗口
    w.toggle_detach()
    spin(0.05)
    check("黑板成独立窗口", w.detached is not None and w.detached.isVisible() and w.board.window() is w.detached)
    c.add_text("独立窗口里也能写")
    w.toggle_detach()
    spin(0.05)
    check("放回播放器", w.detached is None and w.board.window() is w and w.view_mode == "split")
    w.set_view("slide")
    # 目录
    key(Qt.Key.Key_G)
    check("目录打开", w.grid is not None and w.grid.isVisible())
    spin(0.25)
    check("目录有缩略图", not w.grid.item(0).icon().isNull())
    w.grid.setCurrentRow(2)
    key(Qt.Key.Key_Return)
    check("目录跳页", v.page == 2 and not w.grid.isVisible())
    # 查询面板（换假来源，不联网）
    fake = [("假来源", lambda q: "x", None)]
    orig_fetch, orig_ai = lookup.fetch, lookup._ai_ready
    lookup.fetch = lambda _n, _m, _p, q, timeout=5.0: [dict(title=f"{q} 的资料", url="https://example.com/a", snippet="一段摘要", source="假来源")]
    lookup._ai_ready = lambda: False
    pnl = w.panel
    pnl.engine.start = lambda q, sources=fake, use_ai=False, s=lookup.Lookup.start, e=pnl.engine: s(e, q, fake, False)
    v.go(0)
    key(Qt.Key.Key_S)
    drag(a, b)
    key(Qt.Key.Key_Q)
    check("Q 打开查询", pnl.isVisible() and v.sel is None)
    check("文字层的文字直接当搜索词", "比较优势" in pnl.edit.text(), pnl.edit.text())
    spin(0.3)
    check("资料卡片出来了", pnl.n == 1 and pnl.first_at is not None and pnl.first_at < 2.0, (pnl.n, pnl.first_at))
    check("显示用时", "秒" in pnl.time_label.text())
    w.grab().save(str(out / "lookup.png"))
    n0 = len(c.board["items"])
    check("工具条不被面板挡住", w.bar.geometry().right() <= pnl.geometry().left())
    pnl.to_board.emit("一段摘要")
    spin(0.1)
    check("资料写上黑板", len(c.board["items"]) == n0 + 1)
    w.set_view("slide")
    # 图片没有文字层：走识别
    pnl.ocr.read = lambda _im, wait=1.5: "暗反应"
    blank = QImage(200, 100, QImage.Format.Format_RGB32)
    blank.fill(Qt.GlobalColor.white)
    pnl.start(blank, "")
    spin(0.3)
    check("图片走文字识别", pnl.edit.text() == "暗反应" and pnl.n == 1, pnl.edit.text())
    pnl.ocr.read = lambda _im, wait=1.5: ""
    pnl.start(blank, "", "光合作用")
    spin(0.15)
    check("读不到文字时让人输入", "没有读到" in pnl.note.text())
    lookup.fetch = lambda *_a, **_k: []
    pnl.edit.setText("查不到的东西")
    pnl.search_now()
    spin(0.25)
    check("查不到有提示", "没有查到" in pnl.note.text(), pnl.note.text())
    def boom(*_a, **_k):
        raise OSError("断网")
    lookup.fetch = boom
    pnl.edit.setText("断网")
    pnl.search_now()
    spin(0.25)
    check("断网不崩，有提示", "没有查到" in pnl.note.text(), pnl.note.text())
    lookup.fetch, lookup._ai_ready = orig_fetch, orig_ai
    # Esc 一层层退
    key(Qt.Key.Key_S)
    drag(a, b)
    key(Qt.Key.Key_Escape)
    check("Esc 先取消选区", v.sel is None and w.isVisible())
    key(Qt.Key.Key_Escape)
    check("Esc 再关查询", not pnl.isVisible())
    key(Qt.Key.Key_Escape)
    check("Esc 再回指针", v.tool == "pointer" and w.isVisible())
    v.go(0)
    strokes_before = len(v.history().strokes)
    key(Qt.Key.Key_Escape)
    check("Esc 最后退出", not w.isVisible())
    # 存取
    w2 = LecturePlayer(library.read_json(library.folder(m1["id"]) / "meta.json"))
    w2.resize(1280, 720)
    w2.show()
    spin(0.05)
    check("重开笔迹还在", len(w2.view.history(0).strokes) == strokes_before and strokes_before > 0, strokes_before)
    check("重开黑板还在", len(w2.board.canvas.boards) == 2 and len(w2.board.canvas.boards[0]["items"]) >= 3)
    w2.close()
    # Word：滚动翻页
    d = LecturePlayer(m2)
    d.resize(1600, 900)
    d.show()
    spin(0.05)
    v = d.view
    r = v.page_rect()
    check("文档按宽度铺开", r.height() > 900, r)
    d.repaint()
    shot = d.grab().toImage()
    check("文档页面是白底", shot.pixelColor(int(r.x()) + 8, 12).lightness() > 240, shot.pixelColor(int(r.x()) + 8, 12).name())

    def wheel(dy):
        pos = QPointF(800, 450)
        v.wheelEvent(QWheelEvent(pos, v.mapToGlobal(pos), QPoint(0, 0), QPoint(0, dy), Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier, Qt.ScrollPhase.NoScrollPhase, False))
    y0 = v.page_rect().y()
    wheel(-240)
    check("滚轮向下滚", v.page_rect().y() < y0)
    for _ in range(60):
        wheel(-240)
        v._flip_t = 0
        if v.page == 1:
            break
    check("滚到底翻到下一页顶部", v.page == 1 and v.page_rect().y() >= -1, v.page)
    v._flip_t = 0
    wheel(240)
    check("往回滚到上一页底部", v.page == 0 and v.page_rect().bottom() <= 901, (v.page, v.page_rect()))
    d.grab().save(str(out / "doc.png"))
    t = time.perf_counter()
    v.cache.clear()
    v.cache_order.clear()
    d.repaint()
    print("整页渲染", round((time.perf_counter() - t) * 1000, 1), "ms", flush=True)
    d.close()
    # ---- 动画（内置排版，不需要 Office）
    from . import anim
    ax = out / "animated.pptx"
    make_pptx(ax, 5, {2: (_timing([(3, "clickEffect", "entr", "fade", None), (2, "clickEffect", "emph", "fade", None)]), ""),
                      3: ('<p:transition spd="fast"><p:fade/></p:transition>' + _timing([(3, "afterEffect", "entr", "wipe(left)", None), (2, "clickEffect", "exit", "fade", None)]), ""),
                      4: ("", ' show="0"'),
                      5: ('<p:transition advTm="300"><p:cut/></p:transition>', "")})
    plan = anim.parse(ax)
    check("读出动画画面", [len(x["frames"]) for x in plan["slides"]] == [1, 3, 3, 1], [len(x["frames"]) for x in plan["slides"]])
    check("隐藏的幻灯片不放", plan["hidden"] == [4] and anim.needs_steps(plan))
    check("一开始隐藏要进入的形状", plan["slides"][1]["frames"][0]["hide"] == [(3, None)], plan["slides"][1]["frames"][0]["hide"])
    check("退出后隐藏", (2, None) in plan["slides"][2]["frames"][2]["hide"])
    check("读出效果", plan["slides"][2]["frames"][1]["effects"][0]["effect"] == "wipe" and plan["slides"][2]["frames"][1]["effects"][0]["dir"] == "l")
    check("切换效果", plan["slides"][2]["transition"]["kind"] == "fade" and plan["slides"][3]["adv"] == 0.3)
    m3 = library.import_file(ax, use_com=False)
    check("动画课件导入（没有 Office）", m3["pages"] == 4 and m3["steps"] == 4 and (library.folder(m3["id"]) / "anim.json").is_file(), m3)
    a = LecturePlayer(m3)
    a.resize(1280, 720)
    a.show()
    spin(0.05)
    v = a.view
    v.go(1)
    spin(0.05)
    check("动画没开始时正文不出现", "机会成本" not in v.doc.getAllText(v.pdf).text())

    def key2(k):
        a.keyPressEvent(QKeyEvent(QEvent.Type.KeyPress, k, Qt.KeyboardModifier.NoModifier))
    before = a.grab().toImage()
    key2(Qt.Key.Key_Right)
    check("点一下开始放动画", v.run is not None and v.frame == v.slides[1]["first"] + 1)
    check("页码显示动画进度", "动画 1/2" in a.num_btn.text(), a.num_btn.text())
    t = time.perf_counter()
    while v.run is not None and time.perf_counter() - t < 2:
        app.processEvents()
    check("动画放完自己停", v.run is None)
    after = a.grab().toImage()
    check("动画后画面变了", before != after)
    check("动画后正文出现", "机会成本" in v.doc.getAllText(v.pdf).text())
    v.set_tool("pen")
    from . import ink as ink_mod
    st2 = ink_mod.new_stroke("pen", "#ff0000", 2)
    ink_mod.add_point(st2, 10, 10)
    ink_mod.add_point(st2, 90, 60)
    v.history().add(st2)
    key2(Qt.Key.Key_Right)
    check("强调动画算一步", v.run is not None)
    key2(Qt.Key.Key_Right)
    check("放动画时再点就放完，不跳步", v.run is None and v.page == 1 and v.frame == v.slides[1]["last"])
    check("笔迹跟着这张幻灯片，换动画步骤还在", len(v.history().strokes) == 1)
    v.set_tool("pointer")
    key2(Qt.Key.Key_Left)
    check("往回退一步，不放动画", v.run is None and v.frame == v.slides[1]["last"] - 1)
    key2(Qt.Key.Key_Right)
    spin(0.7)
    key2(Qt.Key.Key_Right)
    check("下一张有切换效果", v.run is not None and v.run.transition is not None and v.page == 2, (v.page, v.run))
    spin(0.95)
    check("自动动画接着放", v.frame == v.slides[2]["first"] + 1, v.frame)
    spin(0.5)
    key2(Qt.Key.Key_Right)
    spin(0.5)
    key2(Qt.Key.Key_Right)
    check("跳过隐藏的幻灯片", v.page == 3, v.page)
    v.go(0)
    v.prev()
    check("第一张不能再退", v.page == 0)
    v.go(1, at_end=True)
    check("往回翻停在放完的样子", v.frame == v.slides[1]["last"])
    key2(Qt.Key.Key_Left)
    v.go(0)
    key2(Qt.Key.Key_G)
    spin(0.2)
    check("目录按张数", a.grid.count() == 4)
    key2(Qt.Key.Key_Escape)
    a.close()
    spin(0.05)
    # ---- 自动换片
    m5 = dict(m3)
    b2 = LecturePlayer(m5)
    b2.resize(800, 450)
    b2.show()
    b2.view.page, b2.view.frame = 2, b2.view.slides[2]["last"]
    b2.view.next()
    spin(0.5)
    check("到了设了自动换片的那张", b2.view.page == 3)
    b2.close()
    # ---- 旧格式：没有 Office 也不报「需要 Office」
    rtf = out / "note.rtf"
    rtf.write_bytes(b"{\\rtf1\\ansi\\ansicpg936 {\\fonttbl{\\f0\\fcharset134 SimSun;}} \\f0 \\'b9\\'e2\\'ba\\'cf\\'d7\\'f7\\'d3\\'c3\\par abc\\par}")
    m6 = library.import_file(rtf, use_com=False)
    d6 = LecturePlayer(m6)
    check("RTF 不靠 Office", m6["engine"] == "简化显示" and "光合作用" in d6.doc.getAllText(0).text(), d6.doc.getAllText(0).text()[:30])
    d6.close()
    # ---- DeepSeek 核查
    r = lookup.parse_verdict('{"items":[{"n":1,"verdict":"keep","reason":"教材"},{"n":2,"verdict":"drop","reason":"广告"},{"n":9,"verdict":"keep","reason":"没有这条"},{"n":3,"verdict":"瞎写","reason":""}],"conflict":"","summary":"是这样[1]，也有人说[2][7]。"}', 3)
    check("读出核查结果，对不上的丢掉", r is not None and sorted(r["items"]) == [1, 2], r)
    check("读不懂的回复不当结果", lookup.parse_verdict("不是 JSON", 3) is None and lookup.parse_verdict('{"items":[]}', 3) is None)
    check("结论不能引用被筛掉的资料", lookup.strip_citations(r["summary"], {2}, 3) == "是这样[1]，也有人说。", lookup.strip_citations(r["summary"], {2}, 3))
    p2 = LecturePlayer(m2)
    p2.resize(1400, 800)
    p2.show()
    pn = p2.panel
    pn.show()
    p2._place()
    lookup._ai_ready = lambda: True
    pn.job = 7
    pn.engine.job = 7
    pn.t0 = time.perf_counter()
    its = [dict(title=f"资料 {i}", url=f"https://e.com/{i}", snippet="摘要", source="假", n=i) for i in (1, 2, 3)]
    pn._on_results(7, its, 0.2)
    check("结果先显示，核查进行中", pn.n == 3 and pn.ai_box.isVisibleTo(pn) and "核查" in pn.ai_tag.text())
    pn._on_verdict(7, "https://e.com/1", "drop", "广告")
    pn._on_verdict(7, "https://e.com/2", "doubt", "个人博客")
    pn._on_verdict(7, "https://e.com/3", "keep", "教材")
    pn._on_ai(7, "结论[3]")
    pn._on_checked(7, dict(ok=True, kept=1, doubt=1, dropped=1, total=3, conflict=""))
    spin(0.02)
    check("可靠的排最前", pn.list.itemAt(1).widget().item["n"] == 3 and pn.list.itemAt(2).widget().item["n"] == 2, pn.list.itemAt(1).widget().item)
    gone = next(c for c in pn.cards if c.verdict == "drop")
    check("筛掉的收起来", not gone.isVisibleTo(pn) and pn.fold.isVisibleTo(pn) and "1 条" in pn.fold.text())
    pn.fold.click()
    check("点开能看被筛掉的和原因", gone.isVisibleTo(pn) and "广告" in gone.reason.text())
    check("写清只看了摘要", "摘要" in pn.ai_tag.text())
    p2.grab().save(str(out / "verified.png"))
    n1 = len(pn.cards)
    pn._on_verdict(99, "https://e.com/2", "drop", "旧查询")
    check("旧查询的结果不算数", pn.cards[1].verdict != "drop" and len(pn.cards) == n1)
    pn._reset()
    pn.job = 8
    pn._on_results(8, its[:1], 0.1)
    pn._on_checked(8, dict(ok=False, why="连接 DeepSeek 失败"))
    spin(0.02)
    check("核查失败时说清楚，结果还在", "没能核查" in pn.note.text() and pn.n == 1 and pn.cards[0].isVisibleTo(pn))
    lookup._ai_ready = lambda: False
    pn._reset()
    pn.job = 9
    pn._on_results(9, its[:1], 0.1)
    check("没密钥时提示没核查", "没有经过核查" in pn.note.text())
    lookup._ai_ready = orig_ai
    p2.close()
    # 文字处理
    check("去掉中文之间的空格", lookup.clean_text("比 较 优 势\nabc def") == "比较优势 abc def", lookup.clean_text("比 较 优 势\nabc def"))
    long_q = lookup.make_query("比较优势是指一个国家生产某种产品的机会成本较低。" * 6)
    check("长文字截成搜索词", 12 <= len(long_q) <= 60, long_q)
    class _R:
        status_code, url, encoding, text = 200, "https://qcaptcha.so.com/?x=1", "utf-8", ""
    get0 = lookup._session.get
    lookup._session.get = lambda *_a, **_k: _R()
    got0 = lookup.fetch(*("测试源", lambda q: "x", lambda t: []), "x")
    lookup._session.get = get0
    check("要求验证的来源先歇着，不去绕", got0 == [] and "测试源" not in [x[0] for x in lookup.available_sources([("测试源", None, None), ("别的", None, None)])])
    html = '{"title":"<em>比较优势</em>入门","x":1,"abstract":"机会成本较低","article_url":"https:\\/\\/e.com\\/a"}'
    tt = lookup.parse_toutiao(html)
    check("解析头条结果", len(tt) == 1 and tt[0]["title"] == "比较优势入门" and tt[0]["url"] == "https://e.com/a", tt)
    check("相关性过滤", lookup.relevance("比较优势 定义", dict(title="抖音-记录美好生活", snippet="")) < 0.3 <= lookup.relevance("比较优势 定义", dict(title="比较优势_百科", snippet="定义")))
    lp.shutdown()
    print("LECTURE", "FAIL " + ",".join(fails) if fails else "OK", flush=True)
    LAST_FAILS[:] = fails
    _ = (builtin,)
    return 1 if fails else 0


def QColor0(v, w):
    """页面上同一点没有笔迹时的颜色：用白底判断即可。"""
    from PySide6.QtGui import QColor
    return QColor(255, 255, 255)


def has_color(im, test) -> bool:
    for y in range(0, im.height(), 4):
        for x in range(0, im.width(), 4):
            if test(im.pixelColor(x, y)):
                return True
    return False


if __name__ == "__main__":
    code = main()
    os._exit(code)
