"""把 Word / PPT 转成 PDF。本机有 Office 或 WPS 就用（版式最准），没有就用内置排版，都能放。

统一转成 PDF：翻页快、缩放清晰，还保留文字层——框选后可以直接取到文字，不必识别图片。
PPT 的每个动画步骤是 PDF 的一页（见 anim.py），放映时比较前后两页来做效果。
转换在隔离的 PowerShell 进程里跑，超时只放弃不硬杀 Office；打开文件时禁用宏，原文件不改动。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from ..kit.home import home

SLIDES = {".pptx", ".ppt", ".pptm", ".ppsx", ".pps", ".dps"}
DOCS = {".docx", ".doc", ".docm", ".rtf", ".wps"}
SUPPORTED = SLIDES | DOCS | {".pdf"}
ZIP_SLIDES = {".pptx", ".pptm", ".ppsx"}
FILTER = "课件 (*.pptx *.ppt *.pptm *.ppsx *.pps *.dps *.docx *.doc *.docm *.rtf *.wps *.pdf);;所有文件 (*)"
TIMEOUT = 120
NO_WINDOW = 0x08000000
PLAIN_ENGINES = ("内置排版", "简化显示")

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$src = $env:JW_SRC; $out = $env:JW_PDF; $engine = $env:JW_ENGINE; $mode = $env:JW_MODE; $planFile = $env:JW_PLAN
$proc = @{ 'PowerPoint.Application'='POWERPNT'; 'KWPP.Application'='wpp'; 'Word.Application'='WINWORD'; 'KWPS.Application'='wps' }[$engine]
$isPres = $engine -in 'PowerPoint.Application', 'KWPP.Application'
$running = @(Get-Process $proc -ErrorAction SilentlyContinue).Count -gt 0
$app = $null; $doc = $null; $code = 1

function Find-Shape($slide, $id, $name) {
  foreach ($s in $slide.Shapes) { if ($s.Id -eq $id) { return $s } }
  foreach ($s in $slide.Shapes) { if ($name -and $s.Name -eq $name) { return $s } }
  foreach ($s in $slide.Shapes) {
    if ($s.Type -eq 6) { foreach ($g in $s.GroupItems) { if ($g.Id -eq $id -or ($name -and $g.Name -eq $name)) { return $g } } }
  }
  return $null
}
function Apply-Frame($slide, $frame) {
  foreach ($h in @($frame.shapes)) { $s = Find-Shape $slide $h.id $h.name; if ($s) { $s.Visible = 0 } }
  foreach ($h in @($frame.paras)) {
    $s = Find-Shape $slide $h.id $h.name
    if ($s) {
      foreach ($n in @($h.n)) {
        # 段落设成全透明而不是删掉：版面不变，后面的文字不会往上跑
        try { $s.TextFrame2.TextRange.Paragraphs($n + 1).Font.Fill.Transparency = 1 }
        catch { $s.TextFrame.TextRange.Paragraphs($n + 1).Font.Color.RGB = $slide.Background.Fill.ForeColor.RGB }
      }
    }
  }
}
try {
  $app = New-Object -ComObject $engine
  try { $app.DisplayAlerts = 0 } catch {}
  try { $app.AutomationSecurity = 3 } catch {}
  if ($isPres) {
    $doc = $app.Presentations.Open($src, -1, 0, 0)
    if ($mode -eq 'pptx') {
      $doc.SaveCopyAs($out, 24)
    } else {
      if ($planFile) {
        $plan = [IO.File]::ReadAllText($planFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        $items = @($plan.slides) | Sort-Object { $_.index } -Descending
        $all = @(@($items | ForEach-Object { @{ i = $_.index; s = $_ } }) + @(@($plan.delete) | Where-Object { $_ } | ForEach-Object { @{ i = $_; s = $null } })) | Sort-Object { $_.i } -Descending
        foreach ($e in $all) {
          $slide = $doc.Slides.Item($e.i)
          if ($null -eq $e.s) { $slide.Delete(); continue }
          $frames = @($e.s.frames)
          for ($k = $frames.Count - 1; $k -ge 1; $k--) {
            $d = $slide.Duplicate()
            Apply-Frame $d.Item(1) $frames[$k]
          }
          Apply-Frame $slide $frames[0]
        }
      }
      $doc.SaveAs($out, 32)
    }
  } else {
    try { $app.Visible = $false } catch {}
    $doc = $app.Documents.Open($src, $false, $true, $false, '')
    $doc.ExportAsFixedFormat($out, 17)
  }
  $code = 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
} finally {
  try { if ($doc) { if ($isPres) { $doc.Saved = -1; $doc.Close() } else { $doc.Close(0) } } } catch {}
  try {
    $open = if ($isPres) { $app.Presentations.Count } else { $app.Documents.Count }
    # 只收拾自己启动的实例：用户本来就开着、或还有别的文档时不退出
    if ($app -and -not $running -and $open -eq 0) { $app.Quit() }
  } catch {}
  try { if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) } } catch {}
  [GC]::Collect()
}
exit $code
"""


class ConvertError(Exception):
    pass


def kind_of(path) -> str:
    ext = Path(path).suffix.lower()
    return "slides" if ext in SLIDES else "doc" if ext in DOCS else "pdf"


def has_com(progid: str) -> bool:
    if sys.platform != "win32":
        return False
    import winreg
    try:
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid + "\\CLSID"))
        return True
    except OSError:
        return False


def _prefs_file() -> Path:
    return home() / "lecture-engines.json"


def engines_for(ext: str) -> list:
    """先试上次成功的那个：某个 Office 打不开文件时，不用每次都等它失败。"""
    # Word 排在 WPS 后面：装了但没激活的 Word 打开文件会失败，还会留下一个退不掉的后台进程
    names = ["PowerPoint.Application", "KWPP.Application"] if ext in SLIDES else ["KWPS.Application", "Word.Application"]
    names = [n for n in names if has_com(n)]
    try:
        last = json.loads(_prefs_file().read_text(encoding="utf-8")).get("slides" if ext in SLIDES else "doc")
    except (OSError, ValueError):
        last = None
    if last in names:
        names.remove(last)
        names.insert(0, last)
    return names


def _remember(ext: str, engine: str) -> None:
    key = "slides" if ext in SLIDES else "doc"
    try:
        data = json.loads(_prefs_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    data[key] = engine
    try:
        _prefs_file().write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


def _com(src: Path, out: Path, engine: str, timeout: int, mode: str = "pdf", plan=None) -> str:
    """跑一次转换；成功返回空串，失败返回原因。"""
    tmp = Path(tempfile.mkdtemp(prefix="jw-conv-"))
    try:
        script = tmp / "convert.ps1"
        script.write_bytes(b"\xef\xbb\xbf" + SCRIPT.encode("utf-8"))
        env = dict(os.environ, JW_SRC=str(src), JW_PDF=str(out), JW_ENGINE=engine, JW_MODE=mode, JW_PLAN="")
        if plan is not None:
            pf = tmp / "plan.json"
            pf.write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
            env["JW_PLAN"] = str(pf)
        env.pop("QT_QPA_PLATFORM", None)
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                               env=env, capture_output=True, timeout=timeout, creationflags=NO_WINDOW if sys.platform == "win32" else 0)
        except subprocess.TimeoutExpired:
            return f"超过 {timeout} 秒没有完成（文件可能设了密码，或者 Office 弹出了对话框）"
        except OSError as e:
            return str(e)
        if out.is_file() and out.stat().st_size > 200:
            return ""
        return r.stderr.decode("utf-8", "replace").strip()[:200] or f"退出码 {r.returncode}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


LABEL = {"PowerPoint.Application": "PowerPoint", "KWPP.Application": "WPS 演示", "Word.Application": "Word", "KWPS.Application": "WPS 文字"}


def pdf_pages(path) -> int:
    from PySide6.QtPdf import QPdfDocument
    d = QPdfDocument()
    d.load(str(path))
    n = d.pageCount()
    d.close()
    return n


def _save_timeline(pdf: Path, plan) -> None:
    from . import anim
    target = pdf.parent / "anim.json"
    if plan is not None and anim.has_motion(plan):
        target.write_text(json.dumps(anim.timeline(plan), ensure_ascii=False), encoding="utf-8")
    else:
        target.unlink(missing_ok=True)


def _parse_plan(path):
    from . import anim
    try:
        return anim.parse(path)
    except Exception:  # noqa: BLE001  动画读不懂也要能放，只是没有动画
        return None


def _slides(src: Path, pdf: Path, say, timeout, use_com, errors) -> str:
    from . import anim
    ext = src.suffix.lower()
    plan = _parse_plan(src) if ext in ZIP_SLIDES else None
    for engine in (engines_for(ext) if use_com else []):
        t = time.perf_counter()
        work, tmp, eng_plan = src, None, plan
        try:
            if ext not in ZIP_SLIDES:   # 旧格式先转存成 pptx，才读得到动画
                say(f"正在用 {LABEL[engine]} 读取旧格式…")
                tmp = Path(tempfile.mkdtemp(prefix="jw-ppt-"))
                work = tmp / "deck.pptx"
                why = _com(src, work, engine, timeout, "pptx")
                if why:
                    errors.append(f"{LABEL[engine]}：{why}")
                    continue
                eng_plan = _parse_plan(work)
            steps = eng_plan is not None and anim.needs_steps(eng_plan)
            say(f"正在用 {LABEL[engine]} 转换" + ("（含动画，每一步都要出图）…" if steps else "…"))
            pdf.unlink(missing_ok=True)
            why = _com(work, pdf, engine, timeout, "pdf", anim.com_plan(eng_plan) if steps else None)
            if not why:
                pages = pdf_pages(pdf)
                if eng_plan is not None and pages != anim.frame_count(eng_plan):
                    why = f"页数不对（{pages} / {anim.frame_count(eng_plan)}）"
            if not why:
                _remember(ext, engine)
                _save_timeline(pdf, eng_plan)
                say(f"{LABEL[engine]} 转换完成（{time.perf_counter() - t:.1f} 秒）")
                return LABEL[engine]
            errors.append(f"{LABEL[engine]}：{why}")
        finally:
            if tmp is not None:
                shutil.rmtree(tmp, ignore_errors=True)
    if ext in ZIP_SLIDES:
        say("正在用内置排版转换…")
        from . import builtin
        pdf.unlink(missing_ok=True)
        builtin.pptx_to_pdf(src, pdf, plan)
        _save_timeline(pdf, plan)
        return "内置排版"
    say("没有 Office / WPS，正在按简化方式读取旧格式…")
    from . import legacy
    pdf.unlink(missing_ok=True)
    legacy.ppt_to_pdf(src, pdf)
    return "简化显示"


def _docs(src: Path, pdf: Path, say, timeout, use_com, errors) -> str:
    ext = src.suffix.lower()
    for engine in (engines_for(ext) if use_com else []):
        say(f"正在用 {LABEL[engine]} 转换…")
        t = time.perf_counter()
        pdf.unlink(missing_ok=True)
        why = _com(src, pdf, engine, timeout)
        if not why:
            _remember(ext, engine)
            say(f"{LABEL[engine]} 转换完成（{time.perf_counter() - t:.1f} 秒）")
            return LABEL[engine]
        errors.append(f"{LABEL[engine]}：{why}")
    pdf.unlink(missing_ok=True)
    if ext in (".docx", ".docm"):
        say("正在用内置排版转换…")
        from . import builtin
        builtin.docx_to_pdf(src, pdf)
        return "内置排版"
    say("没有 Office / WPS，正在按简化方式读取…")
    from . import legacy
    (legacy.rtf_to_pdf if ext == ".rtf" else legacy.doc_to_pdf)(src, pdf)
    return "简化显示"


def to_pdf(src, pdf, status=None, timeout: int = TIMEOUT, use_com: bool = True) -> str:
    """src → pdf，返回所用引擎的名字；失败抛 ConvertError。"""
    src, pdf = Path(src), Path(pdf)
    ext = src.suffix.lower()
    if ext not in SUPPORTED:
        raise ConvertError(f"不支持 {ext or '这种'} 文件。可以导入 PPT、Word 和 PDF。")
    say = status or (lambda _s: None)
    if ext == ".pdf":
        shutil.copyfile(src, pdf)
        return "PDF"
    errors = []
    try:
        return (_slides if ext in SLIDES else _docs)(src, pdf, say, timeout, use_com, errors)
    except Exception as e:  # noqa: BLE001  坏文件什么异常都可能有，要给人读得懂的原因
        errors.append(f"读取：{e}")
    raise ConvertError("这个文件打不开，可能已损坏或设了密码。（" + "；".join(errors) + "）")
