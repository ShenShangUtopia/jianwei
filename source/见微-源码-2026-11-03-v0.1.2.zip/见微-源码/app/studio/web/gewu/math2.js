'use strict';
/* ======================= 数学（补充：空间向量、条件概率） ======================= */

/* ---------- 空间向量求角与距离 ---------- */
Lab.reg({
  id: 'm-spacevec', subj: 'math', book: 2, unit: '空间向量与立体几何', title: '空间向量求角与距离', kw: '空间直角坐标系 法向量 异面直线所成角 线面角 二面角 点到平面距离 长方体 正方体',
  info: `<p>以 D 为原点，DA、DC、DD₁ 分别为 x、y、z 轴建立空间直角坐标系。选择点构成直线和平面，右侧给出完整的向量计算过程。</p>
  <p class="fb">异面直线所成角：cos θ = |u·v| / (|u||v|)，θ ∈ (0, π/2]<br>直线与平面所成角：sin θ = |u·n| / (|u||n|)<br>二面角：cos⟨n₁, n₂⟩ = n₁·n₂ / (|n₁||n₂|)，二面角为 ⟨n₁,n₂⟩ 或 π − ⟨n₁,n₂⟩（结合图形判断锐钝）<br>点 P 到平面距离：d = |AP·n| / |n|</p>
  <p>平面的法向量 n 由平面内两个不共线向量的叉积求得，也可以设 n = (x, y, z) 列方程组求解。</p>`,
  tasks: ['正方体中求异面直线 A₁B 与 B₁C 所成的角。', '求直线 A₁C 与平面 ABCD 所成角的正弦值。', '求点 A 到平面 A₁BD 的距离（棱长为 2）。', '把正方体改成长方体，重新计算上一题。'],
  init(L) {
    const c = L.canvas(), cam = new Cam3({ yaw: -0.5, pitch: 0.38, persp: 0.06 });
    L.orbit(c, cam);
    const p = L.params({ a: ['DA 长 a（x 方向）', 1, 4, 0.5, 2], b: ['DC 长 b（y 方向）', 1, 4, 0.5, 2], cc: ['DD₁ 长 c（z 方向）', 1, 4, 0.5, 2] });
    const V0 = { 'A': [1, 0, 0], 'B': [1, 1, 0], 'C': [0, 1, 0], 'D': [0, 0, 0], 'A₁': [1, 0, 1], 'B₁': [1, 1, 1], 'C₁': [0, 1, 1], 'D₁': [0, 0, 1] };
    const E = [['A', 'B'], ['B', 'C'], ['C', 'D'], ['D', 'A'], ['A₁', 'B₁'], ['B₁', 'C₁'], ['C₁', 'D₁'], ['D₁', 'A₁'], ['A', 'A₁'], ['B', 'B₁'], ['C', 'C₁'], ['D', 'D₁']];
    const PT = { ...V0 }; E.forEach(([u, w]) => PT[u + w + '中点'] = V0[u].map((x, i) => (x + V0[w][i]) / 2)); PT['中心 O'] = [0.5, 0.5, 0.5];
    ['ABCD', 'A₁B₁C₁D₁', 'ABB₁A₁', 'DCC₁D₁', 'ADD₁A₁', 'BCC₁B₁'].forEach(f => { const ks = f.match(/[A-D]₁?/g); PT['面' + f + '中心'] = [0, 1, 2].map(i => ks.reduce((s, k) => s + V0[k][i], 0) / 4); });
    const names = Object.keys(PT);
    L.group('问题类型');
    const kind = L.select('', [['ll', '异面直线所成角'], ['lp', '直线与平面所成角'], ['pp', '二面角（两平面法向量夹角）'], ['dist', '点到平面的距离']], 'lp', () => { sync(); L.draw(); });
    L.group('选点');
    const s1 = L.select('直线 1 起点', names, 'A₁'), s2 = L.select('直线 1 终点', names, 'C');
    const s3 = L.select('直线 2 起点', names, 'B₁'), s4 = L.select('直线 2 终点', names, 'C');
    const pa = L.select('平面 α 点 1', names, 'A'), pb = L.select('平面 α 点 2', names, 'B'), pc = L.select('平面 α 点 3', names, 'C');
    const qa = L.select('平面 β 点 1', names, 'A₁'), qb = L.select('平面 β 点 2', names, 'B'), qc = L.select('平面 β 点 3', names, 'D');
    const sp = L.select('点 P', names, 'A');
    const out = L.out();
    function sync() { const k = kind.v, sh = (s, on) => s.el.parentElement.hidden = !on; [s1, s2].forEach(s => sh(s, k === 'll' || k === 'lp')); [s3, s4].forEach(s => sh(s, k === 'll')); [pa, pb, pc].forEach(s => sh(s, k !== 'll')); [qa, qb, qc].forEach(s => sh(s, k === 'pp')); sh(sp, k === 'dist'); }
    sync();
    const r3 = v => v.map(x => +x.toFixed(3)), S = v => `(${r3(v).join(', ')})`, ang = x => fmt(x * 180 / PI, 2) + '°';
    L.onDraw(() => {
      c.clear(); const { a, b, cc } = p, P = k => [PT[k][0] * a, PT[k][1] * b, PT[k][2] * cc];
      const toCam = q => [q[1] - b / 2, q[2] - cc / 2, q[0] - a / 2];
      const s = Math.min(c.w, c.h) / (1.9 * Math.max(a, b, cc));
      drawMesh(c, cam, meshBox(b, cc, a), s, T.c1);
      const g = c.g, pr = q => cam.proj(toCam(q), c, s);
      const ax = [[a + 0.8, 0, 0, 'x'], [0, b + 0.8, 0, 'y'], [0, 0, cc + 0.8, 'z']]; const O = pr([0, 0, 0]);
      ax.forEach(([x, y, z, n]) => { const q = pr([x, y, z]); D.arrow(g, O[0], O[1], q[0], q[1], alpha(T.muted, 0.7), 1.2, 7); D.text(g, n, q[0] + 4, q[1], T.muted, { size: 12 }); });
      const plane = (ks, col) => { const q = ks.map(k => P(k)); D.poly(g, q.map(pr), alpha(col, 0.22), col, 1.6); };
      const seg = (k1, k2, col) => { const A1 = pr(P(k1)), B1 = pr(P(k2)); D.line(g, A1[0], A1[1], B1[0], B1[1], col, 3); };
      const k = kind.v, rows = [];
      const nrm = (x, y, z) => { const n = v3.cross(v3.sub(P(y), P(x)), v3.sub(P(z), P(x))); return n; };
      const simp = n => { const m = Math.max(...n.map(Math.abs)) || 1; return n.map(x => x / m); };
      if (k === 'll') {
        seg(s1.v, s2.v, T.c2); seg(s3.v, s4.v, T.c3);
        const u = v3.sub(P(s2.v), P(s1.v)), w = v3.sub(P(s4.v), P(s3.v)), cs = Math.abs(v3.dot(u, w)) / (v3.len(u) * v3.len(w) || 1);
        rows.push([`u = ${s1.v}${s2.v}`, S(u)], [`v = ${s3.v}${s4.v}`, S(w)], ['u·v', fmt(v3.dot(u, w), 4)], ['|u| , |v|', `${fmt(v3.len(u), 4)} , ${fmt(v3.len(w), 4)}`], ['cos θ = |u·v|/(|u||v|)', fmt(cs, 4)], ['所成角 θ', ang(Math.acos(clamp(cs, 0, 1)))]);
      }
      if (k === 'lp' || k === 'dist' || k === 'pp') plane([pa.v, pb.v, pc.v], T.c4);
      if (k === 'pp') plane([qa.v, qb.v, qc.v], T.c5);
      const n1 = nrm(pa.v, pb.v, pc.v);
      if (k === 'lp') {
        seg(s1.v, s2.v, T.c2);
        const u = v3.sub(P(s2.v), P(s1.v)), sn = Math.abs(v3.dot(u, n1)) / (v3.len(u) * v3.len(n1) || 1);
        rows.push([`方向向量 u = ${s1.v}${s2.v}`, S(u)], ['平面 α 法向量 n', S(simp(n1))], ['sin θ = |u·n|/(|u||n|)', fmt(sn, 4)], ['线面角 θ', v3.len(n1) ? ang(Math.asin(clamp(sn, 0, 1))) : '三点共线，不能确定平面']);
      }
      if (k === 'pp') {
        const n2 = nrm(qa.v, qb.v, qc.v), cs = v3.dot(n1, n2) / (v3.len(n1) * v3.len(n2) || 1), t = Math.acos(clamp(cs, -1, 1));
        rows.push(['n₁（平面 α）', S(simp(n1))], ['n₂（平面 β）', S(simp(n2))], ['cos⟨n₁,n₂⟩', fmt(cs, 4)], ['⟨n₁,n₂⟩', ang(t)], ['二面角', `${ang(t)} 或 ${ang(PI - t)}（结合图形判断）`]);
      }
      if (k === 'dist') {
        const q = pr(P(sp.v)); D.circle(g, q[0], q[1], 6, T.c2, T.stage, 2);
        const ap = v3.sub(P(sp.v), P(pa.v)), d = Math.abs(v3.dot(ap, n1)) / (v3.len(n1) || 1);
        const foot = v3.sub(P(sp.v), v3.mul(n1, v3.dot(ap, n1) / (v3.dot(n1, n1) || 1))), f = pr(foot); D.line(g, q[0], q[1], f[0], f[1], T.c2, 2, [5, 3]); D.circle(g, f[0], f[1], 4, T.c2);
        rows.push(['平面 α 法向量 n', S(simp(n1))], [`向量 ${pa.v}P`, S(ap)], ['d = |AP·n| / |n|', fmt(d, 4)], ['垂足坐标', S(foot)]);
      }
      Object.keys(V0).forEach(kk => { const q = pr(P(kk)); D.circle(g, q[0], q[1], 3, T.fg); D.text(g, kk, q[0] + 6, q[1] - 8, T.fg, { size: 13, bold: true }); });
      [s1, s2, s3, s4, pa, pb, pc, qa, qb, qc, sp].forEach(sl => { if (sl.el.parentElement.hidden || V0[sl.v]) return; const q = pr(P(sl.v)); D.circle(g, q[0], q[1], 3.5, T.c2); D.text(g, sl.v.replace('中点', '中').replace('面', '').replace('中心', '心'), q[0] + 6, q[1] + 10, T.c2, { size: 11 }); });
      rows.unshift(['坐标', `A(${a},0,0) C(0,${b},0) D₁(0,0,${cc})`]);
      out.set(rows);
    });
  }
});

/* ---------- 条件概率与全概率公式 ---------- */
Lab.reg({
  id: 'm-condprob', subj: 'math', book: 4, unit: '随机变量及其分布 · 条件概率', title: '条件概率、全概率与贝叶斯公式', kw: '条件概率 乘法公式 全概率公式 贝叶斯公式 树状图 独立事件 假阳性',
  info: `<p class="fb">条件概率 P(B|A) = P(AB)/P(A)　乘法公式 P(AB) = P(A)P(B|A)<br>全概率公式：P(B) = Σ P(Aᵢ)P(B|Aᵢ)（A₁, A₂, … 构成样本空间的一个划分）<br>贝叶斯公式：P(Aᵢ|B) = P(Aᵢ)P(B|Aᵢ) / P(B)</p>
  <p>左边是树状图，右边是面积图：每一列宽度为 P(Aᵢ)，阴影高度为 P(B|Aᵢ)，阴影总面积就是 P(B)；已知 B 发生时，某一列阴影占总阴影的比例就是 P(Aᵢ|B)。</p>`,
  tasks: ['「三家工厂」情境：随机取一件是次品的概率是多少？这件次品来自甲厂的概率呢？', '「疾病检测」情境：患病率 1%，检测阳性者真正患病的概率是多少？为什么这么低？', '把患病率改为 20%，阳性者患病的概率怎样变化？'],
  init(L) {
    const c = L.canvas();
    const P = {
      fac: { n: 3, A: ['甲厂', '乙厂', '丙厂'], B: '次品', pa: [0.25, 0.35, 0.4], pb: [0.05, 0.04, 0.02] },
      med: { n: 2, A: ['患病', '未患病'], B: '检测阳性', pa: [0.01, 0.99], pb: [0.99, 0.05] },
      ball: { n: 2, A: ['第一次摸到红球', '第一次摸到白球'], B: '第二次摸到红球', pa: [0.6, 0.4], pb: [5 / 9, 6 / 9] }
    };
    let sc = P.fac, sim = null;
    L.group('情境');
    L.select('', [['fac', '三家工厂生产同一种产品'], ['med', '疾病检测（假阳性）'], ['ball', '袋中 6 红 4 白，不放回摸两次']], 'fac', k => { sc = JSON.parse(JSON.stringify(P[k])); load(); });
    L.group('概率');
    const q = L.params({ a1: ['P(A₁)', 0, 1, 0.01, 0.25], a2: ['P(A₂)', 0, 1, 0.01, 0.35], b1: ['P(B|A₁)', 0, 1, 0.005, 0.05], b2: ['P(B|A₂)', 0, 1, 0.005, 0.04], b3: ['P(B|A₃)', 0, 1, 0.005, 0.02] }, () => { sim = null; L.draw(); });
    L.button('随机模拟 10000 次', () => { const pa = probs(), N = 10000, cnt = new Array(sc.n).fill(0), cb = new Array(sc.n).fill(0); for (let i = 0; i < N; i++) { let r = Math.random(), k = 0; while (k < sc.n - 1 && (r -= pa[k]) > 0) k++; cnt[k]++; if (Math.random() < pb()[k]) cb[k]++; } sim = { N, cnt, cb }; L.draw(); }, true);
    const out = L.out();
    function load() { q.$a1.set(sc.pa[0], true); q.$a2.set(sc.pa[1], true); q.$b1.set(sc.pb[0], true); q.$b2.set(sc.pb[1], true); q.$b3.set(sc.pb[2] ?? 0, true); q.$a2.el.hidden = sc.n < 2; q.$b3.el.hidden = sc.n < 3; sim = null; L.draw(); }
    const probs = () => sc.n === 3 ? [q.a1, q.a2, Math.max(0, 1 - q.a1 - q.a2)] : [q.a1, 1 - q.a1];
    const pb = () => [q.b1, q.b2, q.b3].slice(0, sc.n);
    load();
    L.onDraw(() => {
      c.clear(); const g = c.g, pa = probs(), pbv = pb(), joint = pa.map((x, i) => x * pbv[i]), PB = joint.reduce((s, x) => s + x, 0);
      // 树状图
      const tw = c.w * 0.48, x0 = 30, xm = x0 + tw * 0.42, x1 = x0 + tw * 0.92, H = c.h - 40;
      D.circle(g, x0, c.h / 2, 5, T.fg);
      pa.forEach((p1, i) => {
        const y = 20 + (i + 0.5) * H / sc.n; D.line(g, x0, c.h / 2, xm, y, T.c[i], 2); D.text(g, fmt(p1, 3), (x0 + xm) / 2 - 10, (c.h / 2 + y) / 2 - 10, T.c[i], { size: 12, mono: true });
        D.text(g, sc.A[i], xm + 4, y - 12, T.fg, { size: 12, bold: true });
        [[pbv[i], sc.B, -1], [1 - pbv[i], '非' + sc.B, 1]].forEach(([p2, nm, sd]) => { const yy = y + sd * H / sc.n * 0.22; D.line(g, xm, y, x1, yy, sd < 0 ? T.c2 : T.grid2, sd < 0 ? 2 : 1.4); D.text(g, fmt(p2, 3), (xm + x1) / 2, (y + yy) / 2 - 9, T.muted, { size: 11, mono: true, align: 'center' }); D.text(g, nm, x1 + 4, yy, sd < 0 ? T.c2 : T.muted, { size: 11 }); if (sd < 0) D.text(g, '= ' + fmt(p1 * p2, 4), x1 + 4, yy + 14, T.c2, { size: 11, mono: true }); });
      });
      // 面积图
      const ax = c.w * 0.55, aw = c.w - ax - 20, ay = 30, ah = c.h - 70; let xx = ax;
      pa.forEach((p1, i) => { const w = p1 * aw; D.rect(g, xx, ay, w, ah, alpha(T.c[i], 0.12), T.line, 1); D.rect(g, xx, ay + ah * (1 - pbv[i]), w, ah * pbv[i], alpha(T.c2, 0.55)); if (w > 30) D.text(g, sc.A[i], xx + w / 2, ay + ah + 14, T.c[i], { align: 'center', size: 11 }); xx += w; });
      D.text(g, `阴影总面积 = P(${sc.B}) = ${fmt(PB, 4)}`, ax, 16, T.c2, { size: 12 });
      const rows = [[`P(${sc.B})（全概率）`, `${joint.map(fmt4).join(' + ')} = ${fmt(PB, 4)}`]];
      pa.forEach((p1, i) => rows.push([`P(${sc.A[i]}|${sc.B})`, PB ? `${fmt4(joint[i])} / ${fmt4(PB)} = ${fmt(joint[i] / PB, 4)}` : '—']));
      if (sim) { rows.push(['<i>模拟 10000 次</i>', '']); rows.push([`${sc.B} 的频率`, fmt(sim.cb.reduce((s, x) => s + x, 0) / sim.N, 4)]); const tb = sim.cb.reduce((s, x) => s + x, 0); sim.cb.forEach((x, i) => rows.push([`${sc.B}中来自「${sc.A[i]}」`, tb ? fmt(x / tb, 4) : '—'])); }
      out.set(rows);
    });
    function fmt4(x) { return fmt(x, 4); }
  }
});
