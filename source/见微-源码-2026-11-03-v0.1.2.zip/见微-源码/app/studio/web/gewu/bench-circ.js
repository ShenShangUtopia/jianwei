'use strict';
/* ================= 自由工作台 · 电路 =================
   元件放在两个格点之间。用节点电压法求解：每个元件化成电导（必要时并联电流源）——
   导线、电流表、闭合的开关取 0.1 mΩ，电压表取 10 MΩ；电池是电动势 E 串联内阻 r（诺顿等效）；
   电容器用后向欧拉伴随模型随时间充放电；二极管按导通（Vf + 5 Ω）/截止分段线性迭代。 */
(() => {
const CT = {
  wire: { n: '导线', d: {} },
  bat: { n: '电池', d: { E: 3, r: .5 } },
  res: { n: '定值电阻', d: { R: 10 } },
  rh: { n: '滑动变阻器', d: { Rmax: 20, k: .5 } },
  rh3: { n: '变阻器（三接线柱）', d: { Rmax: 20, k: .5 } },
  bulb: { n: '小灯泡', d: { R: 10, P0: .9 } },
  led: { n: '发光二极管', d: { Vf: 2, col: '#ff4a3d' } },
  cap: { n: '电容器', d: { C: 4700 } },
  sw: { n: '开关', d: { on: false } },
  am: { n: '电流表', d: {} },
  vm: { n: '电压表', d: {} }
};
const GW = 1e4; // 导线等的电导（S）
const nf = (v, d = 3) => Math.abs(v) < 1e-6 ? '0' : Math.abs(v) < 1e-3 ? v.toExponential(1) : fmt(v, d); // 画布上的数字
function gauss(A, b) {
  const n = b.length;
  for (let i = 0; i < n; i++) {
    let p = i; for (let r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
    [A[i], A[p]] = [A[p], A[i]]; [b[i], b[p]] = [b[p], b[i]];
    const d = A[i][i] || 1e-30;
    for (let r = i + 1; r < n; r++) { const f = A[r][i] / d; if (!f) continue; for (let k = i; k < n; k++) A[r][k] -= f * A[i][k]; b[r] -= f * b[i]; }
  }
  const x = new Float64Array(n);
  for (let i = n - 1; i >= 0; i--) { let s = b[i]; for (let k = i + 1; k < n; k++) s -= A[i][k] * x[k]; x[i] = s / (A[i][i] || 1e-30); }
  return x;
}
const ART = `<svg viewBox="0 0 160 110"><g fill="none" stroke="currentColor" stroke-width="2.2">
  <path d="M30 26H130V84H30z"/></g><rect x="22" y="44" width="16" height="22" fill="var(--surface,#fff)"/>
  <path d="M22 50h16M26 60h8" stroke="currentColor" stroke-width="2.6"/>
  <circle cx="80" cy="26" r="20" fill="#ffd34d" opacity=".45"/><circle cx="80" cy="26" r="11" fill="var(--surface,#fff)" stroke="currentColor" stroke-width="2.2"/><path d="M72 18l16 16M88 18L72 34" stroke="currentColor" stroke-width="2"/>
  <rect x="64" y="77" width="32" height="14" fill="var(--surface,#fff)" stroke="currentColor" stroke-width="2.2"/>
  <circle cx="130" cy="55" r="11" fill="var(--surface,#fff)" stroke="currentColor" stroke-width="2.2"/><text x="130" y="60" font-size="13" text-anchor="middle" fill="currentColor" font-weight="700">A</text>
  ${[0, 1, 2, 3, 4, 5].map(i => `<circle cx="${40 + i * 15}" cy="84" r="2.4" fill="#d99a00"/>`).join('')}</svg>`;

Bench.reg({
  id: 'circ', subj: 'phys', short: '电路', title: '电路实验板', sub: '电池 · 电阻 · 灯泡 · 开关 · 变阻器 · 电表 · 电容 · 二极管',
  desc: '在格点上拖出导线和元件，连成任意电路。实时求解每个元件的电压和电流，灯泡按功率发光，电流用流动的光点表示，可以做串并联、伏安法、测电源电动势和电容充放电。',
  art: ART,
  init(B) {
    const L = B.L, c = L.canvas();
    let comps = [], sel = null, tool = 'select', uid = 0, simT = 0, ui = {}, preview = null;
    const opt = { flow: true, pot: false, tags: true };
    const cnt = {};
    let G = 40, ox = 30, oy = 30;
    const layout = () => { G = clamp(Math.round(Math.min(c.w / 17, c.h / 13)), 30, 48); ox = G * .8; oy = G * .8; };
    const X = i => ox + i * G, Y = j => oy + j * G;
    const snap = (x, y) => [Math.round((x - ox) / G), Math.round((y - oy) / G)];
    const mk = (t, a, b, o = {}) => { cnt[t] = (cnt[t] || 0) + 1; return { t, id: ++uid, name: CT[t].n + (t === 'wire' ? '' : ' ' + cnt[t]), a, b, I: 0, U: 0, P: 0, ph: 0, v: 0, ...structuredClone(CT[t].d), ...o }; };
    const same = (p, q) => p[0] === q[0] && p[1] === q[1];
    // 三接线柱变阻器的滑片接线柱：在元件中点旁边一格
    const cPt = q => [Math.round((q.a[0] + q.b[0]) / 2) + Math.sign(q.b[1] - q.a[1]), Math.round((q.a[1] + q.b[1]) / 2) - Math.sign(q.b[0] - q.a[0])];
    const R1 = q => Math.max(.05, q.Rmax * q.k), R2 = q => Math.max(.05, q.Rmax * (1 - q.k));

    /* ---- 求解 ---- */
    let pot = new Map(), vmin = 0, vmax = 1, lastSig = '';
    function solve(dt) {
      const nodes = new Map(), id = p => { const k = p[0] + ',' + p[1]; if (!nodes.has(k)) nodes.set(k, nodes.size); return nodes.get(k); };
      for (const q of comps) { q.na = id(q.a); q.nb = id(q.b); if (q.t === 'rh3') q.nc = id(cPt(q)); }
      const n = nodes.size; if (!n) return;
      let V = null;
      for (let it = 0; it < 12; it++) {
        const A = Array.from({ length: n }, () => new Float64Array(n)), J = new Float64Array(n);
        const st = (a, b, g) => { A[a][a] += g; A[b][b] += g; A[a][b] -= g; A[b][a] -= g; };
        const src = (a, b, i) => { J[a] -= i; J[b] += i; };
        for (const q of comps) {
          const a = q.na, b = q.nb; if (a === b) continue;
          switch (q.t) {
            case 'wire': case 'am': st(a, b, GW); break;
            case 'sw': st(a, b, q.on ? GW : 1e-10); break;
            case 'vm': st(a, b, 1e-7); break;
            case 'res': st(a, b, 1 / q.R); break;
            case 'bulb': st(a, b, q.blown ? 1e-10 : 1 / q.R); break;
            case 'rh': st(a, b, 1 / Math.max(.05, q.Rmax * q.k)); break;
            case 'rh3': st(a, q.nc, 1 / R1(q)); st(q.nc, b, 1 / R2(q)); break;
            case 'bat': { const g = 1 / Math.max(q.r, 1e-3); st(a, b, g); src(a, b, q.E * g); break; }
            case 'cap': { const g = q.C * 1e-6 / dt; st(a, b, g); src(b, a, g * q.v); break; }
            case 'led': { const g = q.on ? .2 : 1e-9; st(a, b, g); if (q.on) src(b, a, g * q.Vf); break; }
          }
        }
        for (let i = 0; i < n; i++) A[i][i] += 1e-9;
        V = gauss(A, J);
        let ch = false;
        for (const q of comps) if (q.t === 'led') { const u = V[q.na] - V[q.nb], on = q.on ? (u - q.Vf) * .2 > 0 : u > q.Vf; if (on !== !!q.on) { q.on = on; ch = true; } }
        if (!ch) break;
      }
      const bat = comps.find(q => q.t === 'bat'), ref = bat ? V[bat.na] : Math.min(...V);
      pot = new Map(); vmin = Infinity; vmax = -Infinity;
      for (const [k, i] of nodes) { const v = V[i] - ref; pot.set(k, v); vmin = Math.min(vmin, v); vmax = Math.max(vmax, v); }
      if (vmax - vmin < 1e-6) vmax = vmin + 1;
      for (const q of comps) {
        const u = q.na === q.nb ? 0 : V[q.na] - V[q.nb];
        let i = 0;
        switch (q.t) {
          case 'wire': case 'am': i = u * GW; break;
          case 'sw': i = u * (q.on ? GW : 1e-10); break;
          case 'vm': i = u * 1e-7; break;
          case 'res': i = u / q.R; break;
          case 'bulb': i = q.blown ? 0 : u / q.R; break;
          case 'rh': i = u / Math.max(.05, q.Rmax * q.k); break;
          case 'rh3': { const vc = V[q.nc]; i = (V[q.na] - vc) / R1(q); q.I2 = (vc - V[q.nb]) / R2(q); q.Uc = V[q.nc] - V[q.nb]; break; }
          case 'bat': { const g = 1 / Math.max(q.r, 1e-3); i = g * u + q.E * g; break; }
          case 'cap': { const g = q.C * 1e-6 / dt; i = g * u - g * q.v; q.v = u; break; }
          case 'led': i = q.on ? (u - q.Vf) * .2 : 0; break;
        }
        q.U = u; q.I = i; q.P = q.t === 'bat' ? -u * i : q.t === 'rh3' ? i * i * R1(q) + q.I2 * q.I2 * R2(q) : u * i;
        if (q.t === 'bulb' && !q.blown) { if (q.P > 2.6 * q.P0) { q.over = (q.over || 0) + dt; if (q.over > .4) { q.blown = true; B.toast(`${q.name}烧坏了：实际功率远大于额定功率`); if (sel === q) inspect(); } } else q.over = 0; }
      }
    }

    /* ---- 绘制 ---- */
    const potCol = v => { const t = clamp((v - vmin) / (vmax - vmin), 0, 1), a = hexv(T.c1), b = hexv(T.c2); return `rgb(${lerp(a[0], b[0], t) | 0},${lerp(a[1], b[1], t) | 0},${lerp(a[2], b[2], t) | 0})`; };
    const hexv = h => { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
    const wireCol = (q, end) => opt.pot ? potCol(pot.get((end || q.a).join(',')) ?? 0) : alpha(T.fg, .82);
    function lab(g, q, s, col, side = -1) {
      const ax = X(q.a[0]), ay = Y(q.a[1]), bx = X(q.b[0]), by = Y(q.b[1]), L2 = Math.hypot(bx - ax, by - ay) || 1;
      let nx = -(by - ay) / L2, ny = (bx - ax) / L2; if (ny > 0 || (ny === 0 && nx > 0)) { nx = -nx; ny = -ny; }
      g.font = `600 11.5px ${MONO}`; const w = g.measureText(s).width + 10;
      const dd = 16 + Math.abs(nx) * w / 2 + Math.abs(ny) * 8, d = side < 0 ? dd : -dd, mx = clamp((ax + bx) / 2 + nx * d, w / 2 + 2, c.w - w / 2 - 2), my = clamp((ay + by) / 2 + ny * d, 11, c.h - 11);
      D.rrect(g, mx - w / 2, my - 9, w, 18, 4, alpha(T.surface, .92), alpha(col, .6), 1);
      D.text(g, s, mx, my + .5, col, { size: 11.5, align: 'center', mono: true, bold: true });
    }
    function drawComp(g, q) {
      const ax = X(q.a[0]), ay = Y(q.a[1]), bx = X(q.b[0]), by = Y(q.b[1]), Lp = Math.hypot(bx - ax, by - ay);
      if (Lp < 1) return;
      const ux = (bx - ax) / Lp, uy = (by - ay) / Lp, mx = (ax + bx) / 2, my = (ay + by) / 2, hs = q.t === 'wire' ? 0 : q.t === 'rh3' ? Math.max(15, Lp / 2 - 8) : Math.min(18, Lp / 2 - 2);
      let cl = null;
      if (q.t === 'rh3') { // 滑片接线柱：局部坐标与引线
        const cp = cPt(q), cx = X(cp[0]), cy = Y(cp[1]), dx = cx - mx, dy = cy - my;
        cl = { x: dx * ux + dy * uy, y: -dx * uy + dy * ux, cx, cy, col: wireCol(q, cp) };
      }
      if (sel === q) { g.lineCap = 'round'; D.line(g, ax, ay, bx, by, alpha(T.accent, .28), 12); if (cl) D.line(g, mx, my, cl.cx, cl.cy, alpha(T.accent, .28), 12); g.lineCap = 'butt'; }
      g.lineWidth = 2.4; g.lineCap = 'round';
      D.line(g, ax, ay, mx - ux * hs, my - uy * hs, wireCol(q, q.a), 2.4);
      D.line(g, mx + ux * hs, my + uy * hs, bx, by, wireCol(q, q.b), 2.4);
      g.lineCap = 'butt';
      if (opt.flow && Math.abs(q.I) > 2e-4 && q.t !== 'vm' && !(q.t === 'sw' && !q.on)) {
        const sp = 14, off = ((q.ph % sp) + sp) % sp;
        g.fillStyle = alpha(T.c4, clamp(.45 + Math.abs(q.I) * .4, .45, .95));
        for (let s = off; s < Lp; s += sp) { g.beginPath(); g.arc(ax + ux * s, ay + uy * s, 2.3, 0, TAU); g.fill(); }
      }
      if (q.t === 'wire') return;
      g.save(); g.translate(mx, my); g.rotate(Math.atan2(uy, ux));
      const fg = T.fg, bg = T.stage;
      switch (q.t) {
        case 'bat':
          D.rect(g, -hs, -16, 2 * hs, 32, bg); D.line(g, -hs, 0, -4, 0, fg, 2.4); D.line(g, 4, 0, hs, 0, fg, 2.4);
          D.line(g, -4, -8, -4, 8, fg, 5); D.line(g, 4, -15, 4, 15, fg, 2.2);
          D.text(g, '+', 11, -12, T.c2, { size: 12, bold: true, align: 'center' }); D.text(g, '−', -11, -12, T.c1, { size: 12, bold: true, align: 'center' });
          break;
        case 'res': case 'rh':
          D.rect(g, -15, -6, 30, 12, bg, fg, 2);
          if (q.t === 'rh') { D.arrow(g, -13, 11, 15, -12, T.accent, 1.6, 7); D.line(g, -15 + 30 * q.k, -6, -15 + 30 * q.k, -12, T.accent, 2); }
          break;
        case 'rh3': {
          const sd = Math.sign(cl.y) || -1, wx = -hs + 2 * hs * q.k;
          D.rect(g, -hs, -6, 2 * hs, 12, bg, fg, 2);
          for (let x = -hs + 5; x < hs - 2; x += 5) D.line(g, x, -5, x, 5, alpha(fg, .25), 1); // 电阻丝
          g.lineCap = 'round'; g.strokeStyle = cl.col; g.lineWidth = 2.4; g.beginPath(); g.moveTo(cl.x, cl.y); g.lineTo(cl.x, sd * 17); g.lineTo(wx, sd * 17); g.stroke(); g.lineCap = 'butt';
          D.arrow(g, wx, sd * 17, wx, sd * 7, T.accent, 2, 8);
          D.circle(g, cl.x, cl.y, 3.5, T.stage, fg, 1.6);
          break;
        }
        case 'bulb': {
          const br = q.blown ? 0 : clamp(q.P / q.P0, 0, 1.6);
          if (br > .02) { const r = 14 + 30 * Math.sqrt(br), gl = g.createRadialGradient(0, 0, 3, 0, 0, r); gl.addColorStop(0, `rgba(255,230,120,${.95 * Math.min(1, br)})`); gl.addColorStop(.4, `rgba(255,200,70,${.5 * Math.min(1, br)})`); gl.addColorStop(1, 'rgba(255,190,60,0)'); g.fillStyle = gl; g.fillRect(-r, -r, 2 * r, 2 * r); }
          D.circle(g, 0, 0, 12, br > .02 ? `rgba(255,240,170,${.35 + .6 * Math.min(1, br)})` : bg, q.blown ? T.muted : fg, 2);
          const d = 8.2; if (q.blown) { D.line(g, -d, -d, -2, -2, T.muted, 1.8); D.line(g, 2, 2, d, d, T.muted, 1.8); D.line(g, -d, d, d, -d, T.muted, 1.8); } else { D.line(g, -d, -d, d, d, fg, 1.8); D.line(g, -d, d, d, -d, fg, 1.8); }
          break;
        }
        case 'led': {
          const lit = q.on && q.I > 1e-3;
          if (lit) { const r = 30, gl = g.createRadialGradient(0, 0, 2, 0, 0, r); gl.addColorStop(0, alpha(q.col, .85)); gl.addColorStop(1, alpha(q.col, 0)); g.fillStyle = gl; g.fillRect(-r, -r, 2 * r, 2 * r); }
          D.rect(g, -hs, -12, 2 * hs, 24, lit ? 'transparent' : bg);
          D.poly(g, [[-8, -9], [-8, 9], [7, 0]], lit ? q.col : bg, fg, 1.8); D.line(g, 8, -9, 8, 9, fg, 2.2);
          D.line(g, -8, 0, -hs, 0, fg, 2.4); D.line(g, 8, 0, hs, 0, fg, 2.4);
          D.arrow(g, 1, -11, 8, -18, lit ? q.col : T.muted, 1.2, 5); D.arrow(g, 6, -9, 13, -16, lit ? q.col : T.muted, 1.2, 5);
          break;
        }
        case 'cap': {
          D.rect(g, -hs, -14, 2 * hs, 28, bg); D.line(g, -hs, 0, -4, 0, fg, 2.4); D.line(g, 4, 0, hs, 0, fg, 2.4);
          D.line(g, -4, -12, -4, 12, fg, 2.6); D.line(g, 4, -12, 4, 12, fg, 2.6);
          const qn = clamp(Math.abs(q.U) / 3, 0, 1);
          if (qn > .03) { const pa = q.U > 0 ? -1 : 1; g.globalAlpha = .4 + .6 * qn; D.text(g, '+', -9 * -pa, -16, T.c2, { size: 11, bold: true, align: 'center' }); D.text(g, '−', 9 * -pa, -16, T.c1, { size: 11, bold: true, align: 'center' }); g.globalAlpha = 1; }
          break;
        }
        case 'sw':
          D.rect(g, -hs, -14, 2 * hs, 22, bg); D.line(g, -hs, 0, -12, 0, fg, 2.4); D.line(g, 12, 0, hs, 0, fg, 2.4);
          D.circle(g, -12, 0, 3, bg, fg, 1.8); D.circle(g, 12, 0, 3, bg, fg, 1.8);
          g.lineCap = 'round'; if (q.on) D.line(g, -12, 0, 12, -1, T.accent, 2.6); else D.line(g, -12, 0, 9, -12, fg, 2.6); g.lineCap = 'butt';
          break;
        case 'am': case 'vm':
          D.circle(g, 0, 0, 13, bg, fg, 2);
          g.rotate(-Math.atan2(uy, ux)); D.text(g, q.t === 'am' ? 'A' : 'V', 0, 1, q.t === 'am' ? T.c1 : T.c5, { size: 14, bold: true, align: 'center' });
          break;
      }
      g.restore();
      if (sel === q) for (const p of [q.a, q.b]) D.circle(g, X(p[0]), Y(p[1]), 5.5, T.stage, T.accent, 2);
      if (!opt.tags) return;
      if (q.t === 'am') lab(g, q, `${nf(Math.abs(q.I), 3)} A`, T.c1);
      else if (q.t === 'vm') lab(g, q, `${nf(Math.abs(q.U), 3)} V`, T.c5);
      else if (q.t === 'bat') { lab(g, q, `${nf(q.E, 1)} V  r=${nf(q.r, 1)} Ω`, T.muted); if (Math.abs(q.I) > 3) lab(g, q, `短路！${nf(Math.abs(q.I), 1)} A`, T.bad, 1); }
      else if (q.t === 'res') lab(g, q, `${nf(q.R, 1)} Ω`, T.muted);
      else if (q.t === 'rh') lab(g, q, `${nf(q.Rmax * q.k, 1)} Ω`, T.muted);
      else if (q.t === 'rh3') lab(g, q, `${nf(q.Rmax, 0)} Ω  滑片 ${Math.round(q.k * 100)}%`, T.muted, 1);
      else if (q.t === 'bulb') lab(g, q, q.blown ? '已烧坏' : `${nf(q.P, 2)} W`, q.blown ? T.bad : T.muted);
      else if (q.t === 'cap') lab(g, q, `${nf(q.C, 0)} μF ${nf(Math.abs(q.U), 2)} V`, T.muted);
      else if (q.t === 'sw') lab(g, q, q.on ? '闭合' : '断开', q.on ? T.accent : T.muted);
    }
    L.onDraw(() => {
      layout(); const g = c.g; c.clear();
      const ni = Math.floor((c.w - ox) / G), nj = Math.floor((c.h - oy - 18) / G);
      // 电路板底板：圆角板面 + 每 5 格一条辅助线 + 格点
      const bx0 = X(0) - G * .55, by0 = Y(0) - G * .55, bw = ni * G + G * 1.1, bh = nj * G + G * 1.1;
      const bgr = g.createLinearGradient(0, by0, 0, by0 + bh);
      bgr.addColorStop(0, alpha(T.chem, T.dark ? .07 : .05)); bgr.addColorStop(1, alpha(T.chem, T.dark ? .12 : .09));
      D.rrect(g, bx0, by0, bw, bh, 12, bgr, alpha(T.chem, .25), 1);
      g.strokeStyle = alpha(T.chem, .08); g.lineWidth = 1; g.beginPath();
      for (let i = 5; i < ni; i += 5) { g.moveTo(X(i), by0 + 6); g.lineTo(X(i), by0 + bh - 6); }
      for (let j = 5; j < nj; j += 5) { g.moveTo(bx0 + 6, Y(j)); g.lineTo(bx0 + bw - 6, Y(j)); }
      g.stroke();
      g.fillStyle = alpha(T.fg, .22);
      for (let i = 0; i <= ni; i++) for (let j = 0; j <= nj; j++) { g.beginPath(); g.arc(X(i), Y(j), 1.5, 0, TAU); g.fill(); }
      const order = [...comps].sort((p, q) => (p.t !== 'wire') - (q.t !== 'wire'));
      for (const q of order) drawComp(g, q);
      // 节点（3 个及以上元件相接处画实心点）
      const deg = new Map(); for (const q of comps) for (const p of q.t === 'rh3' ? [q.a, q.b, cPt(q)] : [q.a, q.b]) { const k = p.join(','); deg.set(k, (deg.get(k) || 0) + 1); }
      for (const [k, d] of deg) if (d >= 3) { const [i, j] = k.split(',').map(Number); D.circle(g, X(i), Y(j), 4, opt.pot ? potCol(pot.get(k) ?? 0) : T.fg); }
      if (preview && preview.b && !same(preview.a, preview.b)) { g.globalAlpha = .55; drawComp(g, { ...mk(tool, preview.a, preview.b), id: -1 }); cnt[tool]--; g.globalAlpha = 1; }
      if (preview) D.circle(g, X(preview.a[0]), Y(preview.a[1]), 5, T.accent);
      const tip = tool === 'select' ? '选择 / 移动：点元件选中，拖动元件移动，拖动端点改接线，点开关切换通断' : `放置${CT[tool].n}：在两个格点之间拖动；按 Esc 回到选择`;
      D.text(g, tip, 10, c.h - 12, T.muted, { size: 12 });
      if (!comps.length) D.text(g, '从左侧选一个示例电路，或选「导线」在格点间拖动连线', c.w / 2, c.h * .42, T.muted, { size: 15, align: 'center' });
    });

    /* ---- 交互 ---- */
    const dseg = (px, py, q) => { const ax = X(q.a[0]), ay = Y(q.a[1]), bx = X(q.b[0]), by = Y(q.b[1]), dx = bx - ax, dy = by - ay, t = clamp(((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy || 1), 0, 1); return Math.hypot(px - ax - t * dx, py - ay - t * dy); };
    function hitComp(x, y) {
      const list = [...comps].sort((p, q) => (q.t !== 'wire') - (p.t !== 'wire'));
      return list.find(q => dseg(x, y, q) < (q.t === 'wire' ? 7 : 14) || (q.t === 'rh3' && Math.hypot(x - X(cPt(q)[0]), y - Y(cPt(q)[1])) < 12)) || null;
    }
    L.interact(c, {
      hit: (x, y) => {
        if (tool !== 'select') return { t: 'draw', a: snap(x, y) };
        if (sel) for (const w of ['a', 'b']) if (Math.hypot(x - X(sel[w][0]), y - Y(sel[w][1])) < 9) return { t: 'end', q: sel, w };
        const q = hitComp(x, y); return q ? { t: 'comp', q, g0: snap(x, y), a0: [...q.a], b0: [...q.b] } : null;
      },
      down: (x, y, h) => { if (!h) return; if (h.t === 'draw') preview = { a: h.a }; else select(h.q); },
      drag: (h, x, y) => {
        const p = snap(x, y);
        if (h.t === 'draw') { h.b = p; preview.b = p; }
        else if (h.t === 'end') { if (!same(p, h.q[h.w === 'a' ? 'b' : 'a'])) h.q[h.w] = p; }
        else if (h.t === 'comp') { const di = p[0] - h.g0[0], dj = p[1] - h.g0[1]; h.q.a = [h.a0[0] + di, h.a0[1] + dj]; h.q.b = [h.b0[0] + di, h.b0[1] + dj]; }
      },
      up: h => {
        if (h && h.t === 'draw') { if (h.b && !same(h.a, h.b)) { const q = mk(tool, h.a, h.b); comps.push(q); if (tool !== 'wire') select(q); } preview = null; }
        if (h && h.t !== 'draw' && sel) refresh();
      },
      click: (x, y, h) => {
        if (!h) { select(null); return; }
        if (h.t === 'draw') { if (tool !== 'wire') { const q = mk(tool, h.a, [h.a[0] + 2, h.a[1]]); comps.push(q); select(q); } preview = null; return; }
        if (h.t === 'comp' && h.q.t === 'sw') { h.q.on = !h.q.on; inspect(); }
      }
    });
    function setTool(t) { tool = t; B.active(t === 'select' ? 'tool-select' : 'tool-' + t); preview = null; L.draw(); }
    const rotate = q => { const dx = q.b[0] - q.a[0], dy = q.b[1] - q.a[1]; q.b = [q.a[0] - dy, q.a[1] + dx]; };
    const remove = q => { comps = comps.filter(r => r !== q); if (sel === q) { sel = null; inspect(); } };
    const onKey = e => {
      if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
      if (e.key === 'Escape') setTool('select');
      else if ((e.key === 'Delete' || e.key === 'Backspace') && sel) { remove(sel); e.preventDefault(); }
      else if ((e.key === 'r' || e.key === 'R') && sel) rotate(sel);
    };
    addEventListener('keydown', onKey); L.disp.push(() => removeEventListener('keydown', onKey));

    /* ---- 示例电路 ---- */
    function build(list) {
      comps = []; sel = null; for (const k in cnt) delete cnt[k];
      for (const [t, x1, y1, x2, y2, o] of list) comps.push(mk(t, [x1, y1], [x2, y2], o));
      setTool('select'); inspect();
    }
    const W = (x1, y1, x2, y2) => ['wire', x1, y1, x2, y2];
    const PRE = [
      ['串联电路', '两只灯泡串联，电压表测 L1 两端电压', () => build([
        ['bat', 2, 8, 2, 5], W(2, 5, 2, 2), ['sw', 2, 2, 5, 2], W(5, 2, 6, 2), ['bulb', 6, 2, 8, 2], W(8, 2, 10, 2), ['bulb', 10, 2, 12, 2], W(12, 2, 14, 2),
        W(14, 2, 14, 4), ['am', 14, 4, 14, 6], W(14, 6, 14, 8), W(14, 8, 2, 8), W(6, 2, 6, 4), W(8, 2, 8, 4), ['vm', 6, 4, 8, 4]])],
      ['并联电路', '两条支路各接一只电流表', () => build([
        ['bat', 2, 9, 2, 6], W(2, 6, 2, 2), ['sw', 2, 2, 4, 2], W(4, 2, 7, 2), W(7, 2, 12, 2), ['am', 7, 2, 7, 4], ['bulb', 7, 4, 7, 6], W(7, 6, 7, 9),
        W(12, 2, 12, 4), ['bulb', 12, 4, 12, 6, { R: 20 }], ['am', 12, 6, 12, 8], W(12, 8, 12, 9), W(12, 9, 7, 9), W(7, 9, 2, 9)])],
      ['伏安法测电阻', '电流表外接，滑动变阻器限流', () => build([
        ['bat', 2, 9, 2, 6, { E: 6, r: .5 }], W(2, 6, 2, 2), ['sw', 2, 2, 4, 2], ['rh', 4, 2, 7, 2, { Rmax: 50, k: .4 }], W(7, 2, 8, 2), ['am', 8, 2, 10, 2], W(10, 2, 10, 4),
        ['res', 10, 4, 10, 7, { R: 20, name: '待测电阻 Rx' }], W(10, 7, 10, 9), W(10, 9, 2, 9), W(10, 4, 13, 4), ['vm', 13, 4, 13, 7], W(13, 7, 10, 7)])],
      ['测电源的电动势和内阻', '改变变阻器，记录 U、I 作 U–I 图', () => build([
        ['bat', 3, 8, 3, 5, { E: 1.5, r: 1 }], W(3, 5, 3, 2), ['sw', 3, 2, 6, 2], ['am', 6, 2, 9, 2], W(9, 2, 12, 2), ['rh', 12, 2, 12, 8, { Rmax: 20, k: .5 }], W(12, 8, 3, 8),
        W(3, 5, 1, 5), W(3, 8, 1, 8), ['vm', 1, 5, 1, 8]])],
      ['电容器的充电和放电', '先合 S1 充电，再断开 S1、合上 S2 放电', () => build([
        ['bat', 2, 8, 2, 5, { E: 6, r: .2 }], W(2, 5, 2, 2), ['sw', 2, 2, 5, 2, { name: '开关 S1' }], ['res', 5, 2, 8, 2, { R: 200 }], W(8, 2, 10, 2), ['am', 10, 2, 10, 4], ['cap', 10, 4, 10, 6, { C: 4700 }], W(10, 6, 10, 8), W(10, 8, 2, 8),
        W(10, 2, 15, 2), ['sw', 15, 2, 15, 5, { name: '开关 S2' }], ['bulb', 15, 5, 15, 8, { R: 100, P0: .4 }], W(15, 8, 10, 8), W(10, 4, 13, 4), ['vm', 13, 4, 13, 6], W(13, 6, 10, 6)])],
      ['二极管的单向导电性', '两只二极管方向相反，只有一只发光', () => build([
        ['bat', 2, 8, 2, 5, { E: 5, r: .5 }], W(2, 5, 2, 2), ['sw', 2, 2, 5, 2], W(5, 2, 7, 2), W(7, 2, 12, 2), ['led', 7, 2, 7, 5], ['res', 7, 5, 7, 8, { R: 100 }], W(7, 8, 2, 8),
        ['led', 12, 5, 12, 2, { col: '#2fbf5f' }], ['res', 12, 5, 12, 8, { R: 100 }], W(12, 8, 7, 8)])],
      ['滑动变阻器的分压接法', '灯泡两端电压可以从 0 调起', () => build([
        ['bat', 2, 9, 2, 6, { E: 6, r: .3 }], W(2, 6, 2, 3), ['sw', 2, 3, 5, 3], W(5, 3, 6, 3), ['rh3', 6, 3, 10, 3, { Rmax: 20, k: .5 }], W(10, 3, 12, 3), W(12, 3, 12, 9), W(12, 9, 2, 9),
        W(8, 2, 8, 1), W(8, 1, 14, 1), ['am', 14, 1, 14, 3], ['bulb', 14, 3, 14, 6, { R: 12, P0: 3 }], W(14, 6, 14, 9), W(14, 9, 12, 9), W(14, 3, 16, 3), ['vm', 16, 3, 16, 6], W(16, 6, 14, 6)])],
      ['空白电路板', '', () => build([])]
    ];

    /* ---- 检查器 ---- */
    function select(q) { if (sel !== q) { sel = q; inspect(); } L.draw(); }
    function inspect() {
      B.clearPanel(); ui = {};
      if (sel) {
        const q = sel, ed = f => v => { f(v); refresh(); };
        L.group(q.name);
        if (q.t === 'bat') { L.slider('电动势 E', 0, 12, .1, q.E, ed(v => q.E = v), 'V'); L.slider('内阻 r', 0, 5, .1, q.r, ed(v => q.r = v), 'Ω'); }
        else if (q.t === 'res') L.slider('电阻 R', 1, 500, 1, q.R, ed(v => q.R = v), 'Ω');
        else if (q.t === 'rh' || q.t === 'rh3') { L.slider(q.t === 'rh' ? '滑片位置（接入比例）' : '滑片位置（从第一个端点算起）', 0, 1, .01, q.k, ed(v => q.k = v)); L.slider('最大阻值', 5, 200, 1, q.Rmax, ed(v => q.Rmax = v), 'Ω'); L.note('鼠标悬停在变阻器上滚动滚轮，也可以移动滑片。'); }
        else if (q.t === 'bulb') { L.slider('灯丝电阻 R', 1, 200, 1, q.R, ed(v => q.R = v), 'Ω'); L.slider('额定功率', .05, 5, .05, q.P0, ed(v => q.P0 = v), 'W'); if (q.blown) L.button('换一只新灯泡', () => { q.blown = false; q.over = 0; inspect(); }, true); }
        else if (q.t === 'cap') L.slider('电容 C', 100, 20000, 100, q.C, ed(v => q.C = v), 'μF');
        else if (q.t === 'led') { L.slider('导通电压', 1.5, 3.5, .1, q.Vf, ed(v => q.Vf = v), 'V'); L.select('颜色', [['#ff4a3d', '红'], ['#2fbf5f', '绿'], ['#3d8bff', '蓝'], ['#ffd23d', '黄']], q.col, v => q.col = v); }
        else if (q.t === 'sw') L.button(q.on ? '断开' : '闭合', () => { q.on = !q.on; inspect(); }, true);
        ui.out = L.out();
        if (q.t !== 'wire') L.button('旋转 90°', () => rotate(q));
        L.button('删除', () => remove(q));
      }
      L.group('电表读数'); ui.meters = L.out();
      L.group('显示');
      L.check('电流流动（光点从高电势流向低电势）', opt.flow, v => opt.flow = v);
      L.check('按电势给导线着色（蓝低红高）', opt.pot, v => opt.pot = v);
      L.check('显示数值标签', opt.tags, v => opt.tags = v);
      L.note('快捷键：Esc 回到选择，Delete 删除，R 旋转。电压表、电流表视为理想电表。');
      refresh();
    }
    function refresh() {
      if (ui.out && sel) {
        const q = sel, I = Math.abs(q.I), U = Math.abs(q.U), rows = [];
        if (q.t === 'bat') { const term = -q.U; rows.push(['电流', `${nf(q.I, 3)} A`], ['端电压 U', `${nf(term, 3)} V`], ['内电压 Ir', `${nf(q.I * q.r, 3)} V`], ['总功率 EI', `${nf(q.E * q.I, 3)} W`], ['输出功率 UI', `${nf(term * q.I, 3)} W`]); if (q.E * q.I > 1e-6) rows.push(['效率 U/E', `${nf(term / q.E * 100, 1)} %`]); }
        else if (q.t === 'am') rows.push(['示数', `${nf(I, 4)} A`]);
        else if (q.t === 'vm') rows.push(['示数', `${nf(U, 4)} V`]);
        else if (q.t === 'sw' || q.t === 'wire') rows.push(['电流', `${nf(I, 4)} A`]);
        else {
          rows.push(['电压 U', `${nf(U, 3)} V`], ['电流 I', `${nf(I, 4)} A`], ['功率 P', `${nf(Math.abs(q.P), 3)} W`]);
          if (q.t === 'rh') rows.push(['接入电阻', `${nf(q.Rmax * q.k, 2)} Ω`]);
          if (q.t === 'rh3') rows.push(['滑片两侧电阻', `${nf(R1(q), 2)} Ω / ${nf(R2(q), 2)} Ω`], ['滑片与第二端之间电压', `${nf(Math.abs(q.Uc || 0), 3)} V`], ['滑片引出电流', `${nf(Math.abs(q.I - (q.I2 || 0)), 4)} A`]);
          if (q.t === 'cap') rows.push(['电荷量 Q = CU', `${nf(q.C * U, 1)} μC`], ['时间常数参考 τ = RC', '与串联电阻有关']);
          if (q.t === 'bulb') rows.push(['亮度（P/P额）', q.blown ? '烧坏' : `${nf(Math.abs(q.P) / q.P0 * 100, 0)} %`]);
          if (q.t === 'led') rows.push(['状态', q.on && q.I > 1e-3 ? '导通发光' : '截止']);
        }
        ui.out.set(rows);
      }
      if (ui.meters) {
        const m = comps.filter(q => q.t === 'am' || q.t === 'vm');
        ui.meters.set(m.length ? m.map(q => [q.name, q.t === 'am' ? `${nf(Math.abs(q.I), 4)} A` : `${nf(Math.abs(q.U), 4)} V`]) : '<div class="note">电路里还没有电表。</div>');
      }
    }
    L.every(200, refresh);

    /* ---- 素材栏 ---- */
    const svg = s => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">${s}</svg>`;
    const ICON = {
      select: svg('<path d="M6 3l12 9-5.5 1L15 20l-2.5 1-2.5-6.5L6 18z" fill="currentColor" stroke="none"/>'),
      wire: svg('<path d="M3 17h7V7h11"/><circle cx="3" cy="17" r="1.6" fill="currentColor"/><circle cx="21" cy="7" r="1.6" fill="currentColor"/>'),
      bat: svg('<path d="M2 12h7M15 12h7"/><path d="M9 8v8" stroke-width="3.4"/><path d="M15 4v16"/>'),
      res: svg('<path d="M2 12h4M18 12h4"/><rect x="6" y="8.5" width="12" height="7"/>'),
      rh: svg('<path d="M2 12h4M18 12h4"/><rect x="6" y="8.5" width="12" height="7"/><path d="M5 19L19 5M15 5h4v4"/>'),
      bulb: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#ffd34d" opacity=".35"/><circle cx="12" cy="12" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M7.4 7.4l9.2 9.2M16.6 7.4l-9.2 9.2" stroke="currentColor" stroke-width="1.4"/></svg>',
      led: '<svg viewBox="0 0 24 24"><path d="M6 6v12l10-6z" fill="#ff4a3d"/><path d="M17 6v12M2 12h4M17 12h5" stroke="currentColor" stroke-width="1.6"/><path d="M12 5l3-3M15 7l3-3" stroke="#ff4a3d" stroke-width="1.3"/></svg>',
      cap: svg('<path d="M2 12h8M14 12h8M10 5v14M14 5v14" />'),
      sw: svg('<path d="M2 15h4M18 15h4"/><circle cx="7" cy="15" r="1.6"/><circle cx="17" cy="15" r="1.6"/><path d="M8 14l8-7"/>'),
      am: svg('<circle cx="12" cy="12" r="8"/><path d="M9 16l3-8 3 8M10 13.5h4"/>'),
      vm: svg('<circle cx="12" cy="12" r="8"/><path d="M9 8l3 8 3-8"/>'),
      rh3: svg('<path d="M1 14h3M20 14h3"/><rect x="4" y="11" width="16" height="6"/><path d="M12 3v5"/><path d="M10 6.5l2 3 2-3" fill="currentColor"/>'),
      demo: svg('<rect x="3" y="5" width="18" height="14" rx="1"/><circle cx="12" cy="5" r="2.6" fill="#ffd34d"/>')
    };
    const tItem = (t, sub) => ({ id: 'tool-' + t, icon: ICON[t], label: CT[t].n, sub, click: () => setTool(t), drop: (x, y) => { const a = snap(x, y), q = mk(t, a, [a[0] + 2, a[1]]); comps.push(q); select(q); } });
    B.palette([
      { title: '示例电路', items: PRE.map(([n, s, f]) => ({ icon: ICON.demo, label: n, sub: s, click: f })) },
      { title: '工具', items: [{ id: 'tool-select', icon: ICON.select, label: '选择 / 移动', sub: 'Esc', click: () => setTool('select') }, tItem('wire', '在格点间拖动')] },
      { title: '电源和开关', items: [tItem('bat', '3 V，内阻 0.5 Ω'), tItem('sw', '点击切换通断')] },
      { title: '用电器', items: [tItem('res', '10 Ω'), tItem('rh', '0~20 Ω'), tItem('rh3', '分压接法用'), tItem('bulb', '3 V 0.9 W'), tItem('led', '单向导电'), tItem('cap', '4700 μF')] },
      { title: '电表', items: [tItem('am', '理想电流表'), tItem('vm', '理想电压表')] }
    ]);
    B.foot.append(el('section', 'info-tips', `<h3>怎么用</h3><ol>
      <li>先在左侧选一种元件（或导线），然后在电路板的两个格点之间<b>拖动</b>，就放好了一个元件；单击格点会放一个两格长的元件。</li>
      <li>回到<b>选择 / 移动</b>：点元件选中，拖动它整体移动，拖动两端的圆点改接到别的格点。端点落在同一个格点上就连通了。</li>
      <li>点击开关切换通断；右侧可以改电动势、内阻、电阻、滑片位置、电容等，读数实时更新。</li>
      <li>灯泡亮度按实际功率显示，功率远超额定值会烧坏；电池电流过大会提示短路。</li></ol>`),
      el('section', 'info-tips', `<h3>可以试试</h3><ol>
      <li>串联电路中拧下（删除）一只灯泡，另一只会怎样？并联电路呢？</li>
      <li>伏安法：把电流表改成内接，比较两种接法测得的 R = U/I 与真实值的偏差。</li>
      <li>测电源电动势和内阻：多次改变滑片，记录 U、I，看 U = E − Ir。</li>
      <li>电容器充放电：观察电流表示数从大到小、放电时方向反向，灯泡逐渐变暗。</li></ol>`));

    /* ---- 主循环 ---- */
    L.loop(dt => {
      simT += dt;
      // 电路没有变化、也没有随时间变化的元件时不必重新求解
      const sig = comps.map(q => [q.t, q.a, q.b, q.E, q.r, q.R, q.Rmax, q.k, q.on, q.blown, q.C, q.Vf].join()).join('|');
      if (sig !== lastSig || comps.some(q => q.t === 'cap' || q.over > 0)) { solve(Math.max(dt, 1e-3)); lastSig = sig; }
      for (const q of comps) { const s = Math.sign(q.I) * Math.min(150, 70 * Math.sqrt(Math.abs(q.I))); q.ph += s * dt; }
      L.draw();
    });
    // 滚轮移动变阻器滑片
    c.cv.addEventListener('wheel', e => {
      const r = c.cv.getBoundingClientRect(), q = hitComp(e.clientX - r.left, e.clientY - r.top);
      if (!q || (q.t !== 'rh' && q.t !== 'rh3')) return;
      e.preventDefault(); q.k = clamp(Math.round((q.k - Math.sign(e.deltaY) * .02) * 100) / 100, 0, 1);
      if (sel === q) inspect(); else select(q);
    }, { passive: false });
    PRE[0][2]();
  }
});
})();
