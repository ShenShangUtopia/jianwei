'use strict';
/* ======================= 数学 ======================= */

/* ---------- 函数图像实验室 ---------- */
Lab.reg({
  id: 'm-func', subj: 'math', book: 0, unit: '函数的概念与性质 · 幂指对函数', title: '函数图像实验室', kw: '函数 图像 切线 零点 极值 反函数',
  info: `<p>输入最多三个函数，用参数 <span class="f">a b c</span> 实时变形图像。支持 <span class="f">+ - * / ^ ( ) |x|</span>，函数 <span class="f">sin cos tan sqrt abs exp ln lg log(a,x) arcsin</span> 等，常数 <span class="f">pi e</span>；<span class="f">2x</span>、<span class="f">ax</span> 这类省略乘号的写法也能识别。</p>
  <p>导数按中心差商 <span class="f">f′(x)≈[f(x+h)−f(x−h)]/2h</span> 计算；零点、极值点由扫描变号后用二分法细化得到。</p>
  <p class="fb">切线方程：y − f(x₀) = f′(x₀)(x − x₀)</p>`,
  tasks: ['选「指数与对数」预设，改变 a，观察 y=aˣ 与 y=logₐx 关于 y=x 对称，以及 0<a<1 与 a>1 的区别。', '在「幂函数」预设里让 a 取 −1、0.5、1、2、3，比较图像过的定点与单调性。', '选「切线放缩」，把 x₀ 拖到 0，验证 eˣ ≥ x+1 在 x=0 处取等号。', '自行输入 x^3-3*a*x，调 a 的正负，看极值点何时出现。'],
  init(L) {
    const c = L.canvas(), v = new View(c, -8, 8, -5, 5, { equal: true });
    const V = ['x', 'a', 'b', 'c'], fs = [null, null, null];
    L.group('函数表达式');
    const names = ['f(x) =', 'g(x) =', 'h(x) ='];
    const ins = names.map((n, i) => {
      const s = L.input(n, '', (val, s) => { try { fs[i] = val.trim() ? compileExpr(val, V) : null; s.err(''); } catch (e) { fs[i] = null; s.err(e.message); } L.draw(); });
      s.el.style.borderLeft = `4px solid var(--c${i + 1})`; return s;
    });
    const presets = {
      '一次与二次函数': ['a*x+b', 'a*x^2+b*x+c', '', 1, 1, -2],
      '幂函数 y=xᵃ': ['x^a', 'x', '', 0.5, 1, 0],
      '指数与对数（互为反函数）': ['a^x', 'log(a,x)', 'x', 2, 1, 0],
      '三角函数': ['sin(x)', 'cos(x)', 'tan(x)', 1, 1, 0],
      'y = a·sin(bx + c)': ['a*sin(b*x+c)', 'sin(x)', '', 2, 2, 1],
      '对勾函数 y = x + a/x': ['x+a/x', '', '', 1, 1, 0],
      '绝对值函数': ['|x-a|+|x+b|', '', '', 1, 2, 0],
      '函数零点 ln x + 2x − 6': ['ln(x)+2x-6', '', '', 1, 1, 0],
      '三次函数的极值': ['x^3-3a*x+b', '', '', 1, 0, 0],
      '切线放缩 eˣ 与 ln x': ['e^x', 'x+1', 'ln(x)', 1, 1, 0]
    };
    let p;
    L.select('预设', Object.keys(presets), '一次与二次函数', k => {
      const [f, g, h, a, b, cc] = presets[k];
      ins[0].set(f); ins[1].set(g); ins[2].set(h); p.$a.set(a, true); p.$b.set(b, true); p.$c.set(cc, true); L.draw();
    });
    L.group('参数');
    p = L.params({ a: ['a', -5, 5, 0.1, 1], b: ['b', -5, 5, 0.1, 1], c: ['c', -5, 5, 0.1, -2] });
    L.group('分析 f(x)');
    const tan = L.check('画 x₀ 处的切线', true), der = L.check('画导函数 f′(x)（虚线）', false), crit = L.check('标出零点和极值点', true);
    const x0 = L.slider('x₀', -8, 8, 0.05, 1);
    const out = L.out();
    L.note('拖动画布平移，滚轮缩放，双击复位。');
    L.interact(c, { view: v });
    ins[0].set('a*x+b'); ins[1].set('a*x^2+b*x+c');
    const bis = (F, a, b) => { let fa = F(a); for (let k = 0; k < 50; k++) { const m = (a + b) / 2, fm = F(m); if (fa * fm <= 0) b = m; else { a = m; fa = fm; } } return (a + b) / 2; };
    L.onDraw(() => {
      v.begin();
      const A = p.a, B = p.b, C = p.c;
      fs.forEach((f, i) => { if (f) v.plot(x => f(x, A, B, C), T.c[i], 2.2); });
      const f = fs[0];
      if (!f) { out.set([['f(x)', '未输入']]); return; }
      const F = x => f(x, A, B, C), d = x => (F(x + 1e-5) - F(x - 1e-5)) / 2e-5;
      if (der.v) v.plot(d, T.c[0], 1.4, [6, 4]);
      const zs = [], mx = [], mn = [];
      if (crit.v) {
        const N = 800, dx = (v.x1 - v.x0) / N;
        let xa = v.x0, fa = F(xa), da = d(xa);
        for (let k = 1; k <= N; k++) {
          const xb = v.x0 + k * dx, fb = F(xb), db = d(xb);
          if (isFinite(fa) && isFinite(fb) && fa * fb <= 0 && fa !== fb) { const r = bis(F, xa, xb); if (Math.abs(F(r)) < 1e-6 && zs.length < 8 && !zs.some(z => Math.abs(z - r) < 1e-6)) zs.push(r); }
          if (isFinite(da) && isFinite(db) && da * db < 0) { const r = bis(d, xa, xb), y = F(r); if (isFinite(y) && Math.abs(y) < 1e6) (da > 0 ? mx : mn).push(r); }
          xa = xb; fa = fb; da = db;
        }
        zs.forEach(z => v.dot(z, 0, T.c[0], 4, true));
        mx.forEach(z => { v.dot(z, F(z), T.bad, 4.5, true); v.label('极大', z, F(z), T.bad, { size: 11, dx: -10, dy: -14 }); });
        mn.forEach(z => { v.dot(z, F(z), T.ok, 4.5, true); v.label('极小', z, F(z), T.ok, { size: 11, dx: -10, dy: 16 }); });
      }
      const X = x0.v, Y = F(X), k = d(X);
      if (tan.v && isFinite(Y) && isFinite(k)) { v.plot(x => Y + k * (x - X), T.muted, 1.3, [4, 3]); v.dot(X, Y, T.c[0], 5, true); }
      const lst = a => a.length ? a.slice(0, 4).map(z => fmt(z, 3)).join(', ') + (a.length > 4 ? ' …' : '') : '无';
      out.set([['f(x₀)', fmt(Y, 4)], ['f′(x₀)', fmt(k, 4)], ['切线', isFinite(k) ? `y = ${fmt(k, 3)}x ${Y - k * X >= 0 ? '+' : '−'} ${fmt(Math.abs(Y - k * X), 3)}` : '—'],
        ['零点（视野内）', lst(zs)], ['极大值点', lst(mx)], ['极小值点', lst(mn)]]);
    });
  }
});

/* ---------- 二分法 ---------- */
Lab.reg({
  id: 'm-bisect', subj: 'math', book: 0, unit: '函数的应用 · 二分法', title: '二分法求方程近似解', kw: '零点存在定理 近似解',
  info: `<p><b>函数零点存在定理</b>：若 f(x) 在 [a,b] 上图像连续，且 f(a)·f(b) &lt; 0，则 f(x) 在 (a,b) 内至少有一个零点。</p>
  <p>二分法每一步取中点 m=(a+b)/2，根据 f(a)·f(m) 的符号保留含零点的一半区间。区间长度每步减半，n 步后为 (b−a)/2ⁿ。当区间长度小于精度 ε 时，区间内任一点都可作为近似解。</p>`,
  tasks: ['对 f(x)=ln x+2x−6 在 [2,3] 上二分，精确到 0.01 需要几步？与公式 n > log₂((b−a)/ε) 对照。', '把区间改成 f(a)、f(b) 同号的区间，观察二分法为何无法开始。'],
  init(L) {
    const c = L.canvas(), v = new View(c, 0, 5, -6, 6, { pad: [0, 0, 0, 0] });
    let F = null, st = null;
    L.group('函数与区间');
    const fin = L.input('f(x) =', 'ln(x)+2x-6', (val, s) => { try { F = compileExpr(val); s.err(''); reset(); } catch (e) { F = null; s.err(e.message); } });
    const pa = L.slider('a', -5, 5, 0.1, 2, () => reset()), pb = L.slider('b', -5, 8, 0.1, 3, () => reset());
    const eps = L.select('精度 ε', ['0.1', '0.01', '0.001', '0.0001'], '0.01', () => L.draw());
    L.group('操作');
    L.button('二分一步', () => step(), true); L.button('一直到满足精度', () => { for (let i = 0; i < 60 && st && st.ok && st.b - st.a >= +eps.v; i++) step(); }); L.button('重置', () => reset());
    const out = L.out();
    L.group('迭代记录'); const log = L.out();
    function reset() { st = F ? { a: pa.v, b: pb.v, rows: [], ok: F(pa.v) * F(pb.v) < 0 } : null; L.draw(); }
    function step() {
      if (!st || !st.ok || st.b - st.a < +eps.v) return;
      const m = (st.a + st.b) / 2, fm = F(m);
      st.rows.push([st.a, st.b, m, fm]);
      if (F(st.a) * fm <= 0) st.b = m; else st.a = m; L.draw();
    }
    F = compileExpr('ln(x)+2x-6'); reset();
    L.interact(c, { view: v });
    L.onDraw(() => {
      v.begin(); if (!F) return;
      if (st) {
        const g = c.g; g.fillStyle = alpha(T.accent || T.c1, 0.12);
        g.fillRect(v.X(st.a), v.oy, v.X(st.b) - v.X(st.a), v.H);
        v.seg(st.a, v.y0, st.a, v.y1, T.c2, 1.2, [4, 3]); v.seg(st.b, v.y0, st.b, v.y1, T.c2, 1.2, [4, 3]);
        st.rows.forEach(r => v.dot(r[2], r[3], T.muted, 3));
      }
      v.plot(F, T.c1, 2.4);
      if (!st) return;
      v.dot(st.a, F(st.a), T.c2, 5, true); v.dot(st.b, F(st.b), T.c2, 5, true);
      v.label('a', st.a, 0, T.c2, { dy: 14 }); v.label('b', st.b, 0, T.c2, { dy: 14 });
      const len = st.b - st.a, done = len < +eps.v;
      out.set([['f(a)·f(b)', st.ok ? '< 0，可以二分' : '≥ 0，换一个区间'], ['当前区间', `[${fmt(st.a, 5)}, ${fmt(st.b, 5)}]`], ['区间长度', fmt(len, 6)], ['已迭代', st.rows.length + ' 次'],
        ['结论', done ? `近似解 x ≈ ${fmt((st.a + st.b) / 2, 4)}` : '尚未达到精度']]);
      log.set(`<div class="kv"><span>n &nbsp; 中点 m</span><b>f(m)</b></div>` + st.rows.slice(-10).map((r, i) => `<div class="kv"><span>${st.rows.length - Math.min(10, st.rows.length) + i + 1} &nbsp; ${fmt(r[2], 5)}</span><b>${fmt(r[3], 4)}</b></div>`).join(''));
    });
  }
});

/* ---------- 基本不等式 ---------- */
Lab.reg({
  id: 'm-ineq', subj: 'math', book: 0, unit: '一元二次函数、方程和不等式', title: '基本不等式的几何解释', kw: '均值不等式 算术平均 几何平均',
  info: `<p>以 AB = a + b 为直径作半圆，C 在 AB 上且 AC=a，CB=b。过 C 作垂线交半圆于 D，由射影定理 <span class="f">CD² = AC·CB</span>，所以 CD = √(ab)，而半径 = (a+b)/2。</p>
  <p class="fb">√(ab) ≤ (a+b)/2，当且仅当 a = b 时取等号</p>
  <p>图中还画出了调和平均 2ab/(a+b) 与平方平均 √((a²+b²)/2)，得到完整的不等式链：调和 ≤ 几何 ≤ 算术 ≤ 平方。</p>`,
  tasks: ['拖动滑块使 a=b，四条线段长度有什么关系？', '固定 a+b=10（和定），ab 何时最大？固定 ab=16（积定），a+b 何时最小？'],
  init(L) {
    const c = L.canvas(), v = new View(c, -1, 13, -2, 7.5, { equal: true });
    const p = L.params({ a: ['a', 0.2, 10, 0.1, 7], b: ['b', 0.2, 10, 0.1, 3] });
    const out = L.out();
    L.legend([[T.c1, '几何平均 √ab'], [T.c2, '算术平均 (a+b)/2'], [T.c3, '调和平均'], [T.c4, '平方平均']]);
    L.onDraw(() => {
      v.begin({ grid: false });
      const { a, b } = p, R = (a + b) / 2, O = R, Cx = a, D = Math.sqrt(a * b);
      const g = c.g; g.strokeStyle = T.fg; g.lineWidth = 1.6; g.beginPath();
      g.arc(v.X(O), v.Y(0), R * v.sx, PI, 0); g.stroke();
      v.seg(0, 0, a + b, 0, T.fg, 1.6);
      v.seg(Cx, 0, Cx, D, T.c1, 3); v.seg(O, 0, Cx, D, T.c2, 3);
      // 调和平均：D 到 OD 的垂足 E，DE = 2ab/(a+b)
      const ux = (Cx - O) / R, uy = D / R, t = (Cx - O) * ux + D * uy, Hm = 2 * a * b / (a + b);
      const Ex = O + ux * (R - Hm), Ey = uy * (R - Hm);
      v.seg(Cx, 0, Ex, Ey, T.muted, 1, [3, 3]); v.seg(Ex, Ey, Cx, D, T.c3, 3);
      // 平方平均：O 处作垂线，取 OF = R，CF = √((a²+b²)/2)
      v.seg(O, 0, O, R, T.muted, 1, [3, 3]); v.seg(Cx, 0, O, R, T.c4, 3);
      [['A', 0, 0], ['B', a + b, 0], ['C', Cx, 0], ['O', O, 0], ['D', Cx, D], ['F', O, R]].forEach(([n, x, y]) => { v.dot(x, y, T.fg, 3); v.label(n, x, y, T.fg, { dy: y ? -12 : 14, dx: -4 }); });
      v.label('a', a / 2, 0, T.muted, { dy: 14 }); v.label('b', a + b / 2, 0, T.muted, { dy: 14 });
      out.set([['调和平均 2ab/(a+b)', fmt(Hm, 4)], ['几何平均 √(ab)', fmt(D, 4)], ['算术平均 (a+b)/2', fmt(R, 4)], ['平方平均 √((a²+b²)/2)', fmt(Math.sqrt((a * a + b * b) / 2), 4)],
        ['是否取等', Math.abs(a - b) < 1e-9 ? '是（a = b）' : '否']]);
      void t;
    });
  }
});

/* ---------- 三角函数 ---------- */
Lab.reg({
  id: 'm-trig', subj: 'math', book: 0, unit: '三角函数', title: '单位圆与正弦型函数', kw: '三角函数 单位圆 周期 振幅 相位 五点作图',
  info: `<p><b>单位圆定义</b>：角 α 的终边与单位圆交于 P(x, y)，则 <span class="f">sin α = y，cos α = x，tan α = y/x</span>。把 P 的纵坐标随 α 展开，就得到正弦曲线。</p>
  <p><b>y = A sin(ωx + φ) + B</b>：振幅 |A|，周期 <span class="f">T = 2π/|ω|</span>，初相 φ，频率 f = 1/T。由 y = sin x 得到它的一种变换顺序：</p>
  <ol><li>向左（φ&gt;0）平移 |φ| 个单位：y = sin(x + φ)</li><li>横坐标变为原来的 1/ω：y = sin(ωx + φ)</li><li>纵坐标变为原来的 A 倍，再上移 B：y = A sin(ωx+φ)+B</li></ol>
  <p>五点作图法取 ωx + φ = 0, π/2, π, 3π/2, 2π。</p>`,
  tasks: ['在单位圆模式播放动画，观察 α 每增加 2π，sin α 重复一次。', '打开「显示变换过程」，比较先平移后伸缩与先伸缩后平移（平移量 φ/ω）的区别。', '令 A=2, ω=2, φ=π/3，写出对称轴方程，再用图像验证。'],
  init(L) {
    const c = L.canvas();
    const vc = new View(c, -1.6, 1.6, -1.6, 1.6, { equal: true }), vg = new View(c, -0.3, 4 * PI, -1.6, 1.6);
    let mode = 'circle';
    L.group('模式');
    L.seg('', [['circle', '单位圆'], ['trans', '图像变换']], 'circle', m => { mode = m; g1.hidden = m !== 'circle'; g2.hidden = m !== 'trans'; L.draw(); });
    const g1 = L.group('角 α');
    const al = L.slider('α', 0, 4 * PI, 0.01, PI / 3, null, v => `${fmt(v, 3)} rad = ${fmt(v * 180 / PI, 1)}°`);
    const cosOn = L.check('同时画余弦 cos x', false), tanOn = L.check('画正切线', true);
    let anim = null; L.button('播放 / 暂停', () => { anim.toggle(); });
    const o1 = L.out();
    const g2 = L.group('y = A sin(ωx + φ) + B'); g2.hidden = true;
    const p = L.params({ A: ['A', -3, 3, 0.1, 2], w: ['ω', 0.2, 4, 0.1, 2], ph: ['φ', -PI, PI, PI / 12, PI / 3, '', 3], B: ['B', -2, 2, 0.1, 0] });
    const steps = L.check('显示变换过程', false), five = L.check('标出五点作图的点', true);
    const o2 = L.out();
    anim = L.loop(dt => { al.set((al.v + dt * 0.8) % (4 * PI)); }, false);
    L.onDraw(() => {
      c.clear();
      if (mode === 'circle') {
        const side = Math.min(c.w * 0.42, c.h);
        vc.pad = [0, c.w - side, (c.h - side) / 2, (c.h - side) / 2]; vg.pad = [side + 10, 10, (c.h - side) / 2, (c.h - side) / 2];
        vg.r = [-0.3, 4 * PI + 0.2, -1.6, 1.6];
        vc.fit(); vg.fit(); vc.grid({ ticks: false }); vg.grid({ piX: true });
        const g = c.g, a = al.v, x = Math.cos(a), y = Math.sin(a);
        D.circle(g, vc.X(0), vc.Y(0), vc.sx, null, T.fg, 1.5);
        g.strokeStyle = T.c4; g.lineWidth = 2; g.beginPath(); g.arc(vc.X(0), vc.Y(0), 0.3 * vc.sx, 0, -(a % TAU), true); g.stroke();
        vc.seg(0, 0, x, y, T.fg, 1.8); vc.seg(x, 0, x, y, T.c1, 3); vc.seg(0, 0, x, 0, T.c2, 3);
        if (tanOn.v && Math.abs(x) > 0.05) { const t = y / x; if (Math.abs(t) < 3) { vc.seg(1, 0, 1, t, T.c3, 3); vc.seg(0, 0, 1, t, T.c3, 1, [3, 3]); } }
        vc.dot(x, y, T.fg, 4.5, true); vc.label('P', x, y, T.fg);
        vg.plot(Math.sin, T.c1, 2.2); if (cosOn.v) vg.plot(Math.cos, T.c2, 2);
        vg.dot(a, y, T.c1, 5, true);
        D.line(g, vc.X(x), vc.Y(y), vg.X(a), vg.Y(y), T.c1, 1, [4, 4]);
        if (cosOn.v) vg.dot(a, x, T.c2, 4.5, true);
        const tn = Math.abs(x) < 1e-9 ? '不存在' : fmt(y / x, 4);
        const q = ['第一象限', '第二象限', '第三象限', '第四象限'][Math.floor((a % TAU) / (PI / 2)) % 4];
        o1.set([['sin α', fmt(y, 4)], ['cos α', fmt(x, 4)], ['tan α', tn], ['sin²α + cos²α', fmt(x * x + y * y, 4)], ['终边位置', Math.abs((a % (PI / 2))) < 1e-6 ? '坐标轴上' : q]]);
        D.text(g, '正弦线', 12, 20, T.c1, { size: 12 }); D.text(g, '余弦线', 62, 20, T.c2, { size: 12 }); if (tanOn.v) D.text(g, '正切线', 112, 20, T.c3, { size: 12 });
      } else {
        vg.pad = [0, 0, 0, 0]; const ym = Math.max(3.2, Math.abs(p.A) + Math.abs(p.B) + 0.6); vg.r = [-PI, 3 * PI, -ym, ym];
        vg.fit(); vg.grid({ piX: true });
        const { A, w, ph, B } = p;
        vg.plot(Math.sin, T.muted, 1.4, [5, 4]);
        if (steps.v) { vg.plot(x => Math.sin(x + ph), T.c3, 1.5, [2, 3]); vg.plot(x => Math.sin(w * x + ph), T.c4, 1.5, [2, 3]); }
        vg.plot(x => A * Math.sin(w * x + ph) + B, T.c1, 2.6);
        if (five.v) [0, PI / 2, PI, 1.5 * PI, 2 * PI].forEach(u => { const x = (u - ph) / w; vg.dot(x, A * Math.sin(u) + B, T.c2, 4.5, true); });
        const Tp = TAU / w;
        o2.set([['振幅', fmt(Math.abs(A), 3)], ['周期 T = 2π/ω', fmt(Tp, 4)], ['频率 f', fmt(1 / Tp, 4)], ['初相 φ', fmt(ph, 4)], ['最大值 / 最小值', `${fmt(B + Math.abs(A), 3)} / ${fmt(B - Math.abs(A), 3)}`],
          ['对称轴', `x = (kπ + π/2 − φ)/ω`], ['对称中心', `((kπ − φ)/ω, ${fmt(B, 2)})`]]);
        if (steps.v) { D.text(c.g, 'sin(x+φ)', 12, 18, T.c3); D.text(c.g, 'sin(ωx+φ)', 90, 18, T.c4); }
      }
    });
  }
});

/* ---------- 平面向量 ---------- */
Lab.reg({
  id: 'm-vec', subj: 'math', book: 1, unit: '平面向量及其应用', title: '平面向量运算', kw: '向量 加法 减法 数量积 投影 夹角',
  info: `<p>拖动向量 <b>a</b>、<b>b</b> 的箭头端点。</p>
  <p class="fb">a + b：平行四边形法则 / 三角形法则<br>a·b = |a||b|cos θ = x₁x₂ + y₁y₂<br>a 在 b 上的投影向量 = (a·b / |b|²) b<br>a ⊥ b ⇔ x₁x₂ + y₁y₂ = 0；a ∥ b ⇔ x₁y₂ − x₂y₁ = 0</p>`,
  tasks: ['拖动使 a·b = 0，此时夹角是多少？', '让 a、b 共线，观察平行四边形退化，并验证 x₁y₂ − x₂y₁ = 0。', '打开数乘，令 λ 取负值，看 λa 的方向。'],
  init(L) {
    const c = L.canvas(), v = new View(c, -7, 7, -5, 5, { equal: true });
    const P = { a: [3, 1], b: [1, 3] };
    L.group('显示');
    const sum = L.check('a + b（平行四边形）', true), dif = L.check('a − b', false), pr = L.check('a 在 b 上的投影', true), sc = L.check('数乘 λa', false);
    const lam = L.slider('λ', -3, 3, 0.1, 1.5);
    const out = L.out();
    L.interact(c, {
      hit: (x, y) => ['a', 'b'].find(k => Math.hypot(v.X(P[k][0]) - x, v.Y(P[k][1]) - y) < 14),
      drag: (k, x, y) => { P[k] = [Math.round(v.ix(x) * 2) / 2, Math.round(v.iy(y) * 2) / 2]; }
    });
    L.onDraw(() => {
      v.begin();
      const [ax, ay] = P.a, [bx, by] = P.b, dot = ax * bx + ay * by, la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
      if (sum.v) { v.seg(ax, ay, ax + bx, ay + by, T.muted, 1, [4, 3]); v.seg(bx, by, ax + bx, ay + by, T.muted, 1, [4, 3]); v.vec(0, 0, ax + bx, ay + by, T.c3, 2.6); v.label('a+b', ax + bx, ay + by, T.c3); }
      if (dif.v) { v.vec(bx, by, ax, ay, T.c4, 2.6); v.label('a−b', (ax + bx) / 2, (ay + by) / 2, T.c4); }
      if (sc.v) { v.vec(0, 0, lam.v * ax, lam.v * ay, T.c5, 4); v.label('λa', lam.v * ax, lam.v * ay, T.c5); }
      if (pr.v && lb > 0) { const k = dot / (lb * lb); v.seg(ax, ay, k * bx, k * by, T.muted, 1, [3, 3]); v.vec(0, 0, k * bx, k * by, T.c6, 4); }
      v.vec(0, 0, ax, ay, T.c1, 2.8); v.vec(0, 0, bx, by, T.c2, 2.8);
      v.label('a', ax, ay, T.c1, { bold: true, size: 14 }); v.label('b', bx, by, T.c2, { bold: true, size: 14 });
      v.dot(ax, ay, T.c1, 6, true); v.dot(bx, by, T.c2, 6, true);
      const th = la && lb ? Math.acos(clamp(dot / la / lb, -1, 1)) : NaN;
      const g = c.g; if (isFinite(th)) { const a1 = Math.atan2(ay, ax), a2 = Math.atan2(by, bx); g.strokeStyle = T.muted; g.lineWidth = 1.2; g.beginPath(); let d = a2 - a1; while (d > PI) d -= TAU; while (d < -PI) d += TAU; g.arc(v.X(0), v.Y(0), 26, -a1, -(a1 + d), d > 0); g.stroke(); }
      const cr = ax * by - ay * bx;
      out.set([['a', `(${ax}, ${ay})`], ['b', `(${bx}, ${by})`], ['|a| , |b|', `${fmt(la, 3)} , ${fmt(lb, 3)}`], ['a + b', `(${ax + bx}, ${ay + by})`], ['a − b', `(${ax - bx}, ${ay - by})`],
        ['a·b', fmt(dot, 3)], ['夹角 θ', isFinite(th) ? `${fmt(th * 180 / PI, 2)}°` : '—'], ['投影向量', lb ? `(${fmt(dot / lb / lb * bx, 3)}, ${fmt(dot / lb / lb * by, 3)})` : '—'],
        ['位置关系', Math.abs(dot) < 1e-9 ? 'a ⊥ b' : Math.abs(cr) < 1e-9 ? 'a ∥ b' : '一般']]);
    });
  }
});

/* ---------- 复数 ---------- */
Lab.reg({
  id: 'm-cplx', subj: 'math', book: 1, unit: '复数', title: '复平面上的复数运算', kw: '复数 模 辐角 共轭 三角形式',
  info: `<p>复数 z = a + bi 与复平面上的点 Z(a, b)、向量 OZ 一一对应。</p>
  <p class="fb">|z| = √(a²+b²)　共轭 z̄ = a − bi<br>z = r(cos θ + i sin θ)<br>z₁z₂ = r₁r₂[cos(θ₁+θ₂) + i sin(θ₁+θ₂)]　模相乘，辐角相加<br>z₁/z₂ = (r₁/r₂)[cos(θ₁−θ₂) + i sin(θ₁−θ₂)]</p>
  <p>乘方模式画出 z, z², z³ …，|z|=1 时它们落在单位圆上，体现「乘以单位复数就是旋转」。</p>`,
  tasks: ['把 z₂ 拖到 i（0,1），观察 z₁·i 相当于把 z₁ 逆时针旋转 90°。', '乘方模式下把 z₁ 拖到单位圆上 72° 处，z⁵ 等于多少？', '验证 z·z̄ = |z|²。'],
  init(L) {
    const c = L.canvas(), v = new View(c, -4, 4, -3, 3, { equal: true });
    const Z = { z1: [1.5, 1], z2: [0.5, 1.2] };
    L.group('运算');
    const op = L.seg('', [['add', '加法'], ['sub', '减法'], ['mul', '乘法'], ['div', '除法'], ['conj', '共轭'], ['pow', '乘方']], 'mul');
    const n = L.slider('乘方次数 n', 2, 12, 1, 6);
    const snap = L.check('吸附到 0.1 网格', true);
    const out = L.out();
    L.interact(c, {
      hit: (x, y) => ['z1', 'z2'].find(k => Math.hypot(v.X(Z[k][0]) - x, v.Y(Z[k][1]) - y) < 14),
      drag: (k, x, y) => { let a = v.ix(x), b = v.iy(y); if (snap.v) { a = Math.round(a * 10) / 10; b = Math.round(b * 10) / 10; } Z[k] = [a, b]; }
    });
    const S = (a, b) => `${fmt(a, 3)} ${b < 0 ? '−' : '+'} ${fmt(Math.abs(b), 3)}i`;
    const tri = (a, b) => `${fmt(Math.hypot(a, b), 3)}(cos ${fmt(Math.atan2(b, a) * 180 / PI, 1)}° + i sin …)`;
    L.onDraw(() => {
      v.begin({ xl: '实轴', yl: '虚轴' });
      D.circle(c.g, v.X(0), v.Y(0), v.sx, null, T.grid2, 1);
      const [a, b] = Z.z1, [cc, d] = Z.z2;
      let r = null, rows = [];
      const m = op.v;
      if (m === 'add') { r = [a + cc, b + d]; v.seg(a, b, r[0], r[1], T.muted, 1, [4, 3]); v.seg(cc, d, r[0], r[1], T.muted, 1, [4, 3]); }
      if (m === 'sub') r = [a - cc, b - d];
      if (m === 'mul') r = [a * cc - b * d, a * d + b * cc];
      if (m === 'div') { const q = cc * cc + d * d; r = q ? [(a * cc + b * d) / q, (b * cc - a * d) / q] : null; }
      if (m === 'conj') { r = [a, -b]; v.seg(a, b, a, -b, T.muted, 1, [4, 3]); }
      if (m === 'pow') {
        let x = 1, y = 0; const pts = [[1, 0]];
        for (let k = 1; k <= n.v; k++) { [x, y] = [x * a - y * b, x * b + y * a]; pts.push([x, y]); }
        c.g.strokeStyle = T.c3; c.g.lineWidth = 1.4; c.g.beginPath(); pts.forEach((p, i) => i ? c.g.lineTo(v.X(p[0]), v.Y(p[1])) : c.g.moveTo(v.X(p[0]), v.Y(p[1]))); c.g.stroke();
        pts.slice(1).forEach((p, i) => { v.dot(p[0], p[1], T.c3, 4); v.label('z' + (i + 1 > 1 ? sup(i + 1) : ''), p[0], p[1], T.c3, { size: 11 }); });
        r = pts[pts.length - 1];
        rows = [['z', S(a, b)], ['|z| , arg z', `${fmt(Math.hypot(a, b), 4)} , ${fmt(Math.atan2(b, a) * 180 / PI, 2)}°`], [`zⁿ (n=${n.v})`, S(r[0], r[1])], ['|zⁿ| = |z|ⁿ', fmt(Math.hypot(a, b) ** n.v, 4)], ['arg zⁿ = n·arg z', fmt(n.v * Math.atan2(b, a) * 180 / PI, 2) + '°']];
      }
      v.vec(0, 0, a, b, T.c1, 2.6); v.dot(a, b, T.c1, 6, true); v.label('z₁', a, b, T.c1, { bold: true, size: 13 });
      if (m !== 'conj' && m !== 'pow') { v.vec(0, 0, cc, d, T.c2, 2.6); v.dot(cc, d, T.c2, 6, true); v.label('z₂', cc, d, T.c2, { bold: true, size: 13 }); }
      if (r && m !== 'pow') { v.vec(0, 0, r[0], r[1], T.c3, 3); v.label('结果', r[0], r[1], T.c3, { bold: true }); }
      if (m !== 'pow') {
        const sym = { add: 'z₁ + z₂', sub: 'z₁ − z₂', mul: 'z₁ · z₂', div: 'z₁ / z₂', conj: 'z̄₁' }[m];
        rows = [['z₁', S(a, b)], ['z₂', S(cc, d)], [sym, r ? S(r[0], r[1]) : '除数为 0'], ['|z₁| , arg z₁', `${fmt(Math.hypot(a, b), 3)} , ${fmt(Math.atan2(b, a) * 180 / PI, 1)}°`], ['|z₂| , arg z₂', `${fmt(Math.hypot(cc, d), 3)} , ${fmt(Math.atan2(d, cc) * 180 / PI, 1)}°`]];
        if (r) rows.push(['结果的模 , 辐角', `${fmt(Math.hypot(r[0], r[1]), 3)} , ${fmt(Math.atan2(r[1], r[0]) * 180 / PI, 1)}°`]);
        if (m === 'mul') rows.push(['检验', '模相乘、辐角相加']);
      }
      out.set(rows); void tri;
    });
    function sup(k) { return String(k).split('').map(ch => '⁰¹²³⁴⁵⁶⁷⁸⁹'[ch]).join(''); }
  }
});

/* ---------- 立体几何 ---------- */
function meshPrism(n, r1, r2, h, rot = 0, smooth = false) { // 底面半径 r1，顶面半径 r2（0 为棱锥）
  const V = [], F = [], lat = [];
  for (let i = 0; i < n; i++) { const t = rot + TAU * i / n; V.push([r1 * Math.cos(t), -h / 2, r1 * Math.sin(t)]); }
  if (r2 > 0) { for (let i = 0; i < n; i++) { const t = rot + TAU * i / n; V.push([r2 * Math.cos(t), h / 2, r2 * Math.sin(t)]); } }
  else V.push([0, h / 2, 0]);
  F.push([...Array(n).keys()]);
  if (r2 > 0) { F.push([...Array(n).keys()].map(i => n + i)); for (let i = 0; i < n; i++) { lat.push(F.length); F.push([i, (i + 1) % n, n + (i + 1) % n, n + i]); } }
  else for (let i = 0; i < n; i++) { lat.push(F.length); F.push([i, (i + 1) % n, n]); }
  return { V, F, lat: new Set(lat), smooth };
}
function meshBox(a, b, c) {
  const V = [], s = [-1, 1];
  for (const x of s) for (const y of s) for (const z of s) V.push([x * a / 2, y * b / 2, z * c / 2]);
  const F = [[0, 1, 3, 2], [4, 5, 7, 6], [0, 1, 5, 4], [2, 3, 7, 6], [0, 2, 6, 4], [1, 3, 7, 5]];
  return { V, F, lat: new Set(), smooth: false };
}
function drawMesh(c, cam, M, s, col) {
  const g = c.g, P = M.V.map(p => cam.proj(p, c, s));
  const cen = M.V.reduce((a, p) => v3.add(a, p), [0, 0, 0]).map(x => x / M.V.length);
  const front = M.F.map(f => {
    let n = [0, 0, 0];
    for (let i = 0; i < f.length; i++) { const a = M.V[f[i]], b = M.V[f[(i + 1) % f.length]]; n = v3.add(n, [(a[1] - b[1]) * (a[2] + b[2]), (a[2] - b[2]) * (a[0] + b[0]), (a[0] - b[0]) * (a[1] + b[1])]); }
    const fc = f.reduce((a, i) => v3.add(a, M.V[i]), [0, 0, 0]).map(x => x / f.length);
    if (v3.dot(n, v3.sub(fc, cen)) < 0) n = v3.mul(n, -1);
    return cam.rot(n)[2] > 0;
  });
  M.F.forEach((f, i) => { if (front[i]) D.poly(g, f.map(k => P[k]), alpha(col, 0.07)); });
  const E = new Map();
  M.F.forEach((f, fi) => f.forEach((a, i) => { const b = f[(i + 1) % f.length], k = a < b ? a + '-' + b : b + '-' + a; if (!E.has(k)) E.set(k, []); E.get(k).push(fi); }));
  for (const [k, fs] of E) {
    const [a, b] = k.split('-').map(Number), nf = fs.filter(i => front[i]).length;
    const smooth = M.smooth && fs.every(i => M.lat.has(i));
    if (smooth) { if (nf === 1) D.line(g, P[a][0], P[a][1], P[b][0], P[b][1], T.fg, 1.8); continue; }
    if (nf > 0) D.line(g, P[a][0], P[a][1], P[b][0], P[b][1], T.fg, 1.8);
    else D.line(g, P[a][0], P[a][1], P[b][0], P[b][1], T.muted, 1.2, [5, 4]);
  }
  return P;
}
Lab.reg({
  id: 'm-solid', subj: 'math', book: 1, unit: '立体几何初步', title: '空间几何体与正方体截面', kw: '棱柱 棱锥 圆柱 圆锥 圆台 球 体积 表面积 截面 直观图',
  info: `<p>拖动画布旋转，滚轮缩放。看不见的棱按教材惯例画成虚线。</p>
  <p class="fb">柱体 V = Sh　锥体 V = ⅓Sh　台体 V = ⅓(S′ + √(S′S) + S)h<br>球 V = ⁴⁄₃πR³，S = 4πR²<br>圆柱侧面积 2πrh　圆锥侧面积 πrl　圆台侧面积 π(r + r′)l</p>
  <p><b>正方体截面</b>：平面与正方体相交，截面可能是三角形、四边形、五边形或六边形，但不可能是七边形及以上（正方体只有 6 个面）。法向量取 (1,1,1) 且过中心时得到正六边形。</p>`,
  tasks: ['在截面模式下，调节偏移量从 −1 到 1，截面依次经历哪些形状？', '能否截出正五边形？为什么不能？', '比较同底等高的圆柱与圆锥体积之比。'],
  init(L) {
    const c = L.canvas(), cam = new Cam3({ yaw: -0.7, pitch: 0.42, persp: 0.06 });
    L.orbit(c, cam);
    L.group('几何体');
    const kind = L.select('', [['cube', '正方体（截面）'], ['box', '长方体'], ['prism', '正棱柱'], ['pyr', '正棱锥'], ['frus', '正棱台'], ['cyl', '圆柱'], ['cone', '圆锥'], ['ftc', '圆台'], ['sph', '球']], 'cube', () => { sync(); L.draw(); });
    const p = L.params({ n: ['底面边数 n', 3, 8, 1, 4], a: ['棱长 / 底边 a', 0.5, 4, 0.1, 2], b: ['宽 b', 0.5, 4, 0.1, 1.5], r: ['半径 r', 0.3, 2.5, 0.05, 1.2], r2: ['上底半径 r′', 0.1, 2.4, 0.05, 0.6], h: ['高 h', 0.5, 4, 0.1, 2] });
    const gs = L.group('截面（正方体）');
    const q = L.params({ th: ['法向量 θ（与竖直方向夹角）', 0, 90, 1, 54.7, '°'], ph: ['法向量 φ（水平方位）', 0, 360, 1, 45, '°'], d: ['偏移量（−1 到 1）', -1, 1, 0.01, 0] });
    L.button('正六边形', () => { q.$th.set(54.7, true); q.$ph.set(45, true); q.d = 0; });
    L.button('正三角形', () => { q.$th.set(54.7, true); q.$ph.set(45, true); q.d = 0.6; });
    L.button('矩形', () => { q.$th.set(45, true); q.$ph.set(0, true); q.d = 0.2; });
    L.group('度量'); const out = L.out();
    function sync() {
      const k = kind.v, show = { n: ['prism', 'pyr', 'frus'], a: ['cube', 'box', 'prism', 'pyr', 'frus'], b: ['box'], r: ['cyl', 'cone', 'ftc', 'sph'], r2: ['ftc', 'frus'], h: ['box', 'prism', 'pyr', 'frus', 'cyl', 'cone', 'ftc'] };
      for (const key in show) p['$' + key].el.hidden = !show[key].includes(k);
      gs.hidden = k !== 'cube';
    }
    sync();
    L.onDraw(() => {
      c.clear(); const k = kind.v, { n, a, b, r, r2, h } = p;
      const s = Math.min(c.w, c.h) / 6.2, col = T.accent || T.c1;
      const Rn = a / (2 * Math.sin(PI / n)), S = n * a * a / (4 * Math.tan(PI / n));
      let M, rows = [];
      if (k === 'cube') M = meshBox(a, a, a);
      if (k === 'box') M = meshBox(a, h, b);
      if (k === 'prism') M = meshPrism(n, Rn, Rn, h, PI / 2 + PI / n);
      if (k === 'pyr') M = meshPrism(n, Rn, 0, h, PI / 2 + PI / n);
      if (k === 'frus') { const ratio = Math.min(0.95, r2 / 2.4); M = meshPrism(n, Rn, Rn * ratio, h, PI / 2 + PI / n); }
      if (k === 'cyl') M = meshPrism(64, r, r, h, 0, true);
      if (k === 'cone') M = meshPrism(64, r, 0, h, 0, true);
      if (k === 'ftc') M = meshPrism(64, r, Math.min(r2, r * 0.98), h, 0, true);
      if (k === 'sph') {
        const [cx, cy] = cam.proj([0, 0, 0], c, s), R = r * s * cam.scale;
        D.circle(c.g, cx, cy, R, alpha(col, 0.07), T.fg, 1.8);
        const eq = [...Array(97).keys()].map(i => { const t = TAU * i / 96; return [r * Math.cos(t), 0, r * Math.sin(t)]; });
        for (let i = 0; i < 96; i++) { const A = cam.proj(eq[i], c, s), B = cam.proj(eq[i + 1], c, s); A[2] + B[2] > 0 ? D.line(c.g, A[0], A[1], B[0], B[1], T.fg, 1.4) : D.line(c.g, A[0], A[1], B[0], B[1], T.muted, 1, [5, 4]); }
        const O = cam.proj([0, 0, 0], c, s), E = cam.proj([r, 0, 0], c, s); D.circle(c.g, O[0], O[1], 3, T.fg); D.line(c.g, O[0], O[1], E[0], E[1], T.c2, 1.6); D.text(c.g, 'R', (O[0] + E[0]) / 2, (O[1] + E[1]) / 2 - 10, T.c2);
        rows = [['体积 ⁴⁄₃πR³', fmt(4 / 3 * PI * r ** 3, 4)], ['表面积 4πR²', fmt(4 * PI * r * r, 4)]];
      }
      if (M) drawMesh(c, cam, M, s, col);
      if (k === 'cube') {
        const th = q.th * PI / 180, ph = q.ph * PI / 180, nv = [Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph)];
        const dmax = a / 2 * (Math.abs(nv[0]) + Math.abs(nv[1]) + Math.abs(nv[2])), dd = q.d * dmax;
        const pts = [], E = new Set();
        M.F.forEach(f => f.forEach((i, j) => { const k2 = f[(j + 1) % f.length]; E.add(Math.min(i, k2) + '-' + Math.max(i, k2)); }));
        for (const e of E) {
          const [i, j] = e.split('-').map(Number), A = M.V[i], B = M.V[j], sa = v3.dot(nv, A) - dd, sb = v3.dot(nv, B) - dd;
          if (sa * sb < 0 || Math.abs(sa) < 1e-9) { const t = sa / (sa - sb || 1); const X = v3.add(A, v3.mul(v3.sub(B, A), Math.abs(sa) < 1e-9 ? 0 : t)); if (!pts.some(p2 => v3.len(v3.sub(p2, X)) < 1e-6)) pts.push(X); }
        }
        let name = '无交', area = 0;
        if (pts.length >= 3) {
          const C = pts.reduce((s2, p2) => v3.add(s2, p2), [0, 0, 0]).map(x => x / pts.length);
          let u = v3.cross(nv, Math.abs(nv[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0]); u = v3.mul(u, 1 / v3.len(u)); const w = v3.cross(nv, u);
          pts.sort((P1, P2) => Math.atan2(v3.dot(v3.sub(P1, C), w), v3.dot(v3.sub(P1, C), u)) - Math.atan2(v3.dot(v3.sub(P2, C), w), v3.dot(v3.sub(P2, C), u)));
          const uv = pts.map(P1 => [v3.dot(v3.sub(P1, C), u), v3.dot(v3.sub(P1, C), w)]);
          for (let i = 0; i < uv.length; i++) { const A = uv[i], B = uv[(i + 1) % uv.length]; area += A[0] * B[1] - A[1] * B[0]; } area = Math.abs(area) / 2;
          D.poly(c.g, pts.map(P1 => cam.proj(P1, c, s)), alpha(T.c2, 0.35), T.c2, 2.2);
          const sides = pts.map((P1, i) => v3.len(v3.sub(pts[(i + 1) % pts.length], P1)));
          const eqS = sides.every(x => Math.abs(x - sides[0]) < 1e-3 * a);
          const ang = i => { const A = pts[(i + pts.length - 1) % pts.length], B = pts[i], C2 = pts[(i + 1) % pts.length]; return Math.abs(v3.dot(v3.sub(A, B), v3.sub(C2, B))) < 1e-4 * a * a; };
          const m = pts.length;
          if (m === 3) name = eqS ? '正三角形' : (Math.abs(sides[0] - sides[1]) < 1e-3 || Math.abs(sides[1] - sides[2]) < 1e-3 || Math.abs(sides[0] - sides[2]) < 1e-3) ? '等腰三角形' : '三角形';
          else if (m === 4) { const rt = [0, 1, 2, 3].every(ang); const par = Math.abs(sides[0] - sides[2]) < 1e-3 && Math.abs(sides[1] - sides[3]) < 1e-3; name = rt ? (eqS ? '正方形' : '矩形') : eqS ? '菱形' : par ? '平行四边形' : '梯形'; }
          else name = (eqS ? '正' : '') + ['', '', '', '', '', '五边形', '六边形'][m];
        }
        rows = [['正方体体积 a³', fmt(a ** 3, 4)], ['表面积 6a²', fmt(6 * a * a, 4)], ['截面形状', name], ['截面边数', pts.length >= 3 ? pts.length : 0], ['截面面积', fmt(area, 4)]];
      }
      if (k === 'box') rows = [['体积 abh', fmt(a * b * h, 4)], ['表面积', fmt(2 * (a * b + a * h + b * h), 4)], ['体对角线', fmt(Math.hypot(a, b, h), 4)]];
      if (k === 'prism') rows = [['底面积 S', fmt(S, 4)], ['体积 Sh', fmt(S * h, 4)], ['表面积', fmt(2 * S + n * a * h, 4)]];
      if (k === 'pyr') { const ap = Math.hypot(h, a / (2 * Math.tan(PI / n))); rows = [['底面积 S', fmt(S, 4)], ['体积 ⅓Sh', fmt(S * h / 3, 4)], ['斜高', fmt(ap, 4)], ['表面积', fmt(S + n * a * ap / 2, 4)]]; }
      if (k === 'frus') { const ratio = Math.min(0.95, r2 / 2.4), S2 = S * ratio * ratio; rows = [['下底面积 S', fmt(S, 4)], ['上底面积 S′', fmt(S2, 4)], ['体积 ⅓(S′+√(S′S)+S)h', fmt((S2 + Math.sqrt(S * S2) + S) * h / 3, 4)]]; }
      if (k === 'cyl') rows = [['体积 πr²h', fmt(PI * r * r * h, 4)], ['侧面积 2πrh', fmt(TAU * r * h, 4)], ['表面积', fmt(TAU * r * h + TAU * r * r, 4)]];
      if (k === 'cone') { const l = Math.hypot(r, h); rows = [['母线 l', fmt(l, 4)], ['体积 ⅓πr²h', fmt(PI * r * r * h / 3, 4)], ['侧面积 πrl', fmt(PI * r * l, 4)], ['侧面展开扇形圆心角', fmt(360 * r / l, 2) + '°'], ['表面积', fmt(PI * r * l + PI * r * r, 4)]]; }
      if (k === 'ftc') { const r3 = Math.min(r2, r * 0.98), l = Math.hypot(r - r3, h); rows = [['母线 l', fmt(l, 4)], ['体积', fmt(PI * h * (r * r + r * r3 + r3 * r3) / 3, 4)], ['侧面积 π(r+r′)l', fmt(PI * (r + r3) * l, 4)]]; }
      out.set(rows);
    });
  }
});

/* ---------- 直线、圆与圆锥曲线 ---------- */
Lab.reg({
  id: 'm-conic', subj: 'math', book: 2, unit: '直线和圆的方程 · 圆锥曲线的方程', title: '圆锥曲线与直线', kw: '椭圆 双曲线 抛物线 离心率 焦点 准线 渐近线 弦长 直线与圆',
  info: `<p>动点 P 沿曲线移动，实时显示定义中的距离关系。</p>
  <p class="fb">椭圆 x²/a² + y²/b² = 1：|PF₁| + |PF₂| = 2a，c² = a² − b²<br>双曲线 x²/a² − y²/b² = 1：||PF₁| − |PF₂|| = 2a，c² = a² + b²，渐近线 y = ±(b/a)x<br>抛物线 y² = 2px：|PF| = P 到准线 x = −p/2 的距离<br>离心率 e = c/a；圆锥曲线统一定义：|PF| / d = e</p>
  <p>直线 y = kx + m 与曲线联立消元，得一元二次方程，用判别式 Δ 判断交点个数，弦长 |AB| = √(1+k²)·|x₁ − x₂|。</p>`,
  tasks: ['固定 a，让 b 逐渐接近 a，椭圆离心率如何变化？形状如何变化？', '双曲线中，让直线斜率 k 等于 b/a，交点个数会怎样？', '在抛物线上让 P 移动，验证 |PF| 等于到准线的距离。', '圆模式中调 m，观察 d 与 r 比较时的三种位置关系。'],
  init(L) {
    const c = L.canvas(), v = new View(c, -8, 8, -6, 6, { equal: true });
    L.group('曲线');
    const kind = L.seg('', [['ell', '椭圆'], ['hyp', '双曲线'], ['par', '抛物线'], ['cir', '圆']], 'ell', () => { sync(); L.draw(); });
    const p = L.params({ a: ['a', 0.5, 6, 0.1, 4], b: ['b', 0.5, 6, 0.1, 2.5], p: ['p', 0.2, 6, 0.1, 2], x0: ['圆心 x₀', -4, 4, 0.1, 0], y0: ['圆心 y₀', -4, 4, 0.1, 0], r: ['半径 r', 0.5, 5, 0.1, 3] });
    const t = L.slider('动点 P 的参数 t', 0, TAU, 0.01, 1);
    let anim = null; L.button('P 沿曲线运动', () => anim.toggle());
    L.group('直线 y = kx + m');
    const ln = L.check('显示直线', true);
    const q = L.params({ k: ['k', -4, 4, 0.05, 0.5], m: ['m', -6, 6, 0.1, 1] });
    L.group('数据'); const out = L.out();
    L.interact(c, { view: v });
    function sync() { const k = kind.v; p.$a.el.hidden = p.$b.el.hidden = !(k === 'ell' || k === 'hyp'); p.$p.el.hidden = k !== 'par'; p.$x0.el.hidden = p.$y0.el.hidden = p.$r.el.hidden = k !== 'cir'; }
    sync();
    anim = L.loop(dt => t.set((t.v + dt * 0.7) % TAU), false);
    L.onDraw(() => {
      v.begin();
      const { a, b, x0, y0, r } = p, pp = p.p, K = kind.v, tt = t.v;
      const { k, m } = q; let rows = [], xs = [];
      if (K === 'ell') {
        const A = Math.max(a, b), longX = a >= b, cc = Math.sqrt(Math.abs(a * a - b * b)), e = cc / A;
        v.curve(u => a * Math.cos(u), u => b * Math.sin(u), 0, TAU, 300, T.c1, 2.4);
        const F1 = longX ? [-cc, 0] : [0, -cc], F2 = longX ? [cc, 0] : [0, cc], P = [a * Math.cos(tt), b * Math.sin(tt)];
        v.seg(...F1, ...P, T.c2, 1.6); v.seg(...F2, ...P, T.c3, 1.6);
        const d1 = Math.hypot(P[0] - F1[0], P[1] - F1[1]), d2 = Math.hypot(P[0] - F2[0], P[1] - F2[1]);
        if (e > 0) { const dx = A * A / cc; if (longX) { v.seg(dx, v.y0, dx, v.y1, T.muted, 1, [5, 4]); v.seg(-dx, v.y0, -dx, v.y1, T.muted, 1, [5, 4]); } else { v.seg(v.x0, dx, v.x1, dx, T.muted, 1, [5, 4]); v.seg(v.x0, -dx, v.x1, -dx, T.muted, 1, [5, 4]); } }
        [F1, F2].forEach((F, i) => { v.dot(...F, T.fg, 4); v.label('F' + '₁₂'[i], ...F, T.fg, { dy: 14 }); });
        v.dot(...P, T.c1, 6, true); v.label('P', ...P, T.c1);
        const A2 = b * b + a * a * k * k, B2 = 2 * a * a * k * m, C2 = a * a * (m * m - b * b); xs = quad(A2, B2, C2);
        rows = [['方程', `x²/${fmt(a * a, 2)} + y²/${fmt(b * b, 2)} = 1`], ['焦点在', longX ? 'x 轴' : 'y 轴'], ['c', fmt(cc, 4)], ['离心率 e', fmt(e, 4)], ['|PF₁|', fmt(d1, 3)], ['|PF₂|', fmt(d2, 3)], ['|PF₁| + |PF₂|', `${fmt(d1 + d2, 4)}（= 2·${fmt(A, 2)}）`]];
      }
      if (K === 'hyp') {
        const cc = Math.hypot(a, b), e = cc / a;
        v.curve(u => a / Math.cos(u), u => b * Math.tan(u), -1.45, 1.45, 300, T.c1, 2.4);
        v.curve(u => -a / Math.cos(u), u => b * Math.tan(u), -1.45, 1.45, 300, T.c1, 2.4);
        v.plot(x => b / a * x, T.muted, 1, [6, 4]); v.plot(x => -b / a * x, T.muted, 1, [6, 4]);
        const dx = a * a / cc; v.seg(dx, v.y0, dx, v.y1, T.grid2, 1, [3, 4]); v.seg(-dx, v.y0, -dx, v.y1, T.grid2, 1, [3, 4]);
        const u = (tt / TAU) * 2.8 - 1.4, side = 1, P = [side * a / Math.cos(u), b * Math.tan(u)];
        const F1 = [-cc, 0], F2 = [cc, 0], d1 = Math.hypot(P[0] + cc, P[1]), d2 = Math.hypot(P[0] - cc, P[1]);
        v.seg(...F1, ...P, T.c2, 1.6); v.seg(...F2, ...P, T.c3, 1.6);
        [F1, F2].forEach((F, i) => { v.dot(...F, T.fg, 4); v.label('F' + '₁₂'[i], ...F, T.fg, { dy: 14 }); });
        v.dot(...P, T.c1, 6, true); v.label('P', ...P, T.c1);
        xs = quad(b * b - a * a * k * k, -2 * a * a * k * m, -a * a * (m * m + b * b));
        rows = [['方程', `x²/${fmt(a * a, 2)} − y²/${fmt(b * b, 2)} = 1`], ['c', fmt(cc, 4)], ['离心率 e', fmt(e, 4)], ['渐近线', `y = ±${fmt(b / a, 3)}x`], ['|PF₁| − |PF₂|', `${fmt(d1 - d2, 4)}（= 2·${fmt(a, 2)}）`]];
      }
      if (K === 'par') {
        v.curve(u => u * u / (2 * pp), u => u, -10, 10, 300, T.c1, 2.4);
        v.seg(-pp / 2, v.y0, -pp / 2, v.y1, T.muted, 1.2, [5, 4]); v.label('准线', -pp / 2, v.y1 - 0.3, T.muted, { dy: 0 });
        const yy = (tt / TAU) * 12 - 6, P = [yy * yy / (2 * pp), yy], F = [pp / 2, 0];
        v.seg(...F, ...P, T.c2, 1.6); v.seg(-pp / 2, yy, ...P, T.c3, 1.6);
        v.dot(...F, T.fg, 4); v.label('F', ...F, T.fg, { dy: 14 }); v.dot(...P, T.c1, 6, true); v.label('P', ...P, T.c1);
        xs = quad(k * k, 2 * k * m - 2 * pp, m * m);
        rows = [['方程', `y² = ${fmt(2 * pp, 2)}x`], ['焦点', `(${fmt(pp / 2, 3)}, 0)`], ['准线', `x = ${fmt(-pp / 2, 3)}`], ['离心率 e', '1'], ['|PF|', fmt(Math.hypot(P[0] - F[0], P[1]), 4)], ['P 到准线距离', fmt(P[0] + pp / 2, 4)]];
      }
      if (K === 'cir') {
        v.curve(u => x0 + r * Math.cos(u), u => y0 + r * Math.sin(u), 0, TAU, 200, T.c1, 2.4);
        v.dot(x0, y0, T.fg, 4); v.label('C', x0, y0, T.fg);
        const d = Math.abs(k * x0 - y0 + m) / Math.hypot(k, 1);
        if (ln.v) { const fx = (k * (y0 - m) + x0) / (k * k + 1); v.seg(x0, y0, fx, k * fx + m, T.c3, 1.4, [4, 3]); }
        xs = quad(1 + k * k, 2 * (k * (m - y0) - x0), x0 * x0 + (m - y0) ** 2 - r * r);
        rows = [['方程', `(x−${fmt(x0, 2)})² + (y−${fmt(y0, 2)})² = ${fmt(r * r, 2)}`], ['圆心到直线距离 d', fmt(d, 4)], ['位置关系', Math.abs(d - r) < 0.02 ? '相切 d = r' : d < r ? '相交 d < r' : '相离 d > r']];
      }
      if (ln.v) {
        v.plot(x => k * x + m, T.c4, 2);
        xs.forEach(x => v.dot(x, k * x + m, T.c4, 5, true));
        const D2 = xs.disc;
        rows.push(['联立后 Δ', isFinite(D2) ? fmt(D2, 3) : '一次方程'], ['交点个数', xs.length]);
        if (xs.length === 2) rows.push(['弦长 |AB|', fmt(Math.sqrt(1 + k * k) * Math.abs(xs[0] - xs[1]), 4)], ['弦中点', `(${fmt((xs[0] + xs[1]) / 2, 3)}, ${fmt(k * (xs[0] + xs[1]) / 2 + m, 3)})`]);
      }
      out.set(rows);
    });
    function quad(A, B, C) {
      let r;
      if (Math.abs(A) < 1e-9) { r = Math.abs(B) < 1e-9 ? [] : [-C / B]; r.disc = NaN; return r; }
      const d = B * B - 4 * A * C; r = d < -1e-9 ? [] : d < 1e-9 ? [-B / 2 / A] : [(-B - Math.sqrt(d)) / 2 / A, (-B + Math.sqrt(d)) / 2 / A]; r.disc = d; return r;
    }
  }
});

/* ---------- 数列 ---------- */
Lab.reg({
  id: 'm-seq', subj: 'math', book: 3, unit: '数列', title: '数列与前 n 项和', kw: '等差数列 等比数列 递推 蛛网图 求和',
  info: `<p class="fb">等差：aₙ = a₁ + (n−1)d，Sₙ = n(a₁ + aₙ)/2 = na₁ + n(n−1)d/2<br>等比：aₙ = a₁qⁿ⁻¹，Sₙ = a₁(1 − qⁿ)/(1 − q)（q ≠ 1）<br>|q| &lt; 1 时 Sₙ → a₁/(1 − q)</p>
  <p>等差数列的点 (n, aₙ) 在一条直线上，Sₙ 是关于 n 的二次函数（d≠0）；等比数列的点在指数型曲线 y = (a₁/q)·qˣ 上。递推模式用「蛛网图」展示 aₙ₊₁ = f(aₙ) 的迭代是否收敛到不动点。</p>`,
  tasks: ['等差数列中让 d < 0，Sₙ 在第几项取最大值？与 aₙ 何时变号对照。', '等比数列取 q = −0.5，观察摆动收敛；取 q = 1.1 观察发散。', '递推模式输入 a/2 + 1/a（求 √2 的牛顿迭代），观察收敛速度。'],
  init(L) {
    const c = L.canvas(), v = new View(c, 0, 21, -10, 30), vw = new View(c, -1, 4, -1, 4, { equal: true });
    L.group('数列类型');
    const kind = L.seg('', [['ari', '等差'], ['geo', '等比'], ['rec', '递推']], 'ari', () => { sync(); L.draw(); });
    const p = L.params({ a1: ['首项 a₁', -10, 10, 0.5, 2], d: ['公差 d', -3, 3, 0.1, 1.5], q: ['公比 q', -2, 2, 0.05, 0.8], n: ['项数 n', 1, 40, 1, 12] });
    let F = compileExpr('a/2+1/a', ['a']);
    const fin = L.input('aₙ₊₁ = f(a)，用 a 表示 aₙ', 'a/2+1/a', (s, o) => { try { F = compileExpr(s, ['a']); o.err(''); } catch (e) { F = null; o.err(e.message); } L.draw(); });
    const out = L.out();
    function sync() { const k = kind.v; p.$d.el.hidden = k !== 'ari'; p.$q.el.hidden = k !== 'geo'; fin.el.parentElement.hidden = k !== 'rec'; }
    sync();
    L.onDraw(() => {
      const { a1, d, q, n } = p, k = kind.v; c.clear(); const g = c.g;
      const terms = [];
      for (let i = 1; i <= n; i++) terms.push(k === 'ari' ? a1 + (i - 1) * d : k === 'geo' ? a1 * q ** (i - 1) : i === 1 ? a1 : (F ? F(terms[i - 2]) : NaN));
      const S = []; terms.reduce((s, x, i) => (S[i] = s + x, s + x), 0);
      if (k === 'rec') {
        const lo = Math.min(0, ...terms.filter(isFinite)) - 1, hi = Math.max(4, ...terms.filter(isFinite).map(x => Math.min(x, 1e3))) + 1;
        vw.r = [lo, hi, lo, hi]; vw.pad = [0, c.w * 0.45, 0, 0]; v.pad = [c.w * 0.58, 10, 20, 20]; vw.fit(); vw.grid({ xl: 'aₙ', yl: 'aₙ₊₁' });
        vw.plot(x => x, T.muted, 1.2, [5, 4]); if (F) vw.plot(x => F(x), T.c1, 2.2);
        g.strokeStyle = T.c2; g.lineWidth = 1.4; g.beginPath(); g.moveTo(vw.X(terms[0]), vw.Y(0));
        for (let i = 0; i < terms.length - 1; i++) { if (!isFinite(terms[i + 1])) break; g.lineTo(vw.X(terms[i]), vw.Y(terms[i + 1])); g.lineTo(vw.X(terms[i + 1]), vw.Y(terms[i + 1])); }
        g.stroke();
      } else v.pad = [40, 16, 20, 30];
      const fin2 = terms.filter(isFinite), ymin = Math.min(0, ...fin2, ...(k !== 'rec' ? S : [])), ymax = Math.max(1, ...fin2, ...(k !== 'rec' ? S : []));
      v.r = [0, n + 1, ymin - (ymax - ymin) * 0.08, ymax + (ymax - ymin) * 0.08]; v.fit(); v.grid({ xl: 'n', yl: '' });
      const bw = Math.max(2, Math.min(18, v.sx * 0.5));
      terms.forEach((x, i) => { if (!isFinite(x)) return; const X = v.X(i + 1); D.rect(g, X - bw / 2, Math.min(v.Y(0), v.Y(x)), bw, Math.abs(v.Y(x) - v.Y(0)), alpha(T.c1, 0.7)); });
      if (k !== 'rec') { g.strokeStyle = T.c2; g.lineWidth = 2; g.beginPath(); S.forEach((s, i) => i ? g.lineTo(v.X(i + 1), v.Y(s)) : g.moveTo(v.X(1), v.Y(s))); g.stroke(); S.forEach((s, i) => v.dot(i + 1, s, T.c2, 3)); }
      D.text(g, '■ aₙ', v.ox + 8, v.oy + 10, T.c1); if (k !== 'rec') D.text(g, '● Sₙ', v.ox + 60, v.oy + 10, T.c2);
      const an = terms[n - 1], Sn = S[n - 1];
      const rows = [['aₙ（n=' + n + '）', fmt(an, 4)]];
      if (k === 'ari') rows.push(['通项', `aₙ = ${fmt(a1, 2)} + (n−1)·${fmt(d, 2)}`], ['Sₙ', fmt(Sn, 4)], ['Sₙ 最值', d === 0 ? '—' : (d < 0 ? '最大值 ' : '最小值 ') + fmt(Math.max(...S.map(x => d < 0 ? x : -x)) * (d < 0 ? 1 : -1), 3)]);
      if (k === 'geo') rows.push(['通项', `aₙ = ${fmt(a1, 2)}·${fmt(q, 2)}ⁿ⁻¹`], ['Sₙ', fmt(Sn, 4)], ['极限 a₁/(1−q)', Math.abs(q) < 1 ? fmt(a1 / (1 - q), 4) : '|q| ≥ 1，不收敛']);
      if (k === 'rec') rows.push(['前几项', terms.slice(0, 6).map(x => fmt(x, 4)).join(', ')], ['收敛判断', Math.abs(terms[n - 1] - terms[n - 2]) < 1e-6 ? '已收敛于 ' + fmt(terms[n - 1], 6) : '未收敛']);
      out.set(rows);
    });
  }
});

/* ---------- 杨辉三角 ---------- */
Lab.reg({
  id: 'm-pascal', subj: 'math', book: 4, unit: '计数原理', title: '杨辉三角与二项式定理', kw: '排列 组合 二项式 系数',
  info: `<p class="fb">Aₙᵐ = n!/(n−m)!　Cₙᵐ = n!/[m!(n−m)!]<br>Cₙᵐ = Cₙⁿ⁻ᵐ　Cₙ₊₁ᵐ = Cₙᵐ + Cₙᵐ⁻¹<br>(a + b)ⁿ = Σ Cₙᵏ aⁿ⁻ᵏ bᵏ，二项式系数之和 = 2ⁿ</p>
  <p>杨辉三角第 n 行（从 0 数起）就是 (a+b)ⁿ 的二项式系数，每个数等于肩上两数之和。按奇偶染色会出现谢尔宾斯基三角形。</p>`,
  tasks: ['验证第 n 行各数之和为 2ⁿ，奇数项系数和等于偶数项系数和。', '把染色改成「被 3 整除」，图案有什么变化？', '计算 (2x − 1)⁶ 展开式中 x³ 的系数。'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ n: ['行数 n', 1, 32, 1, 10], k: ['高亮第 k 项', 0, 32, 1, 3] });
    const col = L.select('染色', [['none', '不染色'], ['2', '奇偶（mod 2）'], ['3', '被 3 整除（mod 3）'], ['5', '被 5 整除（mod 5）']], 'none');
    L.group('计算器'); const q = L.params({ N: ['n', 0, 30, 1, 6], M: ['m', 0, 30, 1, 2] });
    const out = L.out();
    L.onDraw(() => {
      c.clear(); const g = c.g, n = p.n, k = Math.min(p.k, n), rows = n + 1;
      const cell = Math.min((c.w - 20) / rows, (c.h - 40) / rows * 1.15), hh = cell / 1.15;
      for (let i = 0; i <= n; i++) for (let j = 0; j <= i; j++) {
        const x = c.w / 2 + (j - i / 2) * cell, y = 20 + i * hh + hh / 2, val = comb(i, j);
        let fill = alpha(T.c1, 0.08);
        if (col.v !== 'none') fill = val % +col.v ? alpha(T.c1, 0.75) : alpha(T.muted, 0.08);
        if (i === n) fill = j === k ? T.c2 : alpha(T.c2, 0.25);
        D.rrect(g, x - cell / 2 + 1, y - hh / 2 + 1, cell - 2, hh - 2, 3, fill);
        if (cell > 22) D.text(g, val > 99999 ? sciShort(val) : String(val), x, y, T.fg, { size: Math.min(13, cell / (String(val).length * 0.62 + 0.5)), align: 'center', mono: true });
      }
      const terms = [];
      for (let j = 0; j <= Math.min(n, 6); j++) terms.push(`${comb(n, j) > 1 ? comb(n, j) : ''}${n - j ? 'a' + (n - j > 1 ? sup(n - j) : '') : ''}${j ? 'b' + (j > 1 ? sup(j) : '') : ''}`);
      const { N, M } = q;
      out.set([['(a+b)ⁿ 展开', terms.join(' + ') + (n > 6 ? ' + …' : '')], [`第 ${k + 1} 项 Tₖ₊₁`, `C(${n},${k}) a${sup(n - k)}b${sup(k)} = ${comb(n, k)}·a${sup(n - k)}b${sup(k)}`], ['系数和 2ⁿ', 2 ** n],
        [`A(${N},${M})`, M <= N ? fmtBig(perm(N, M)) : '—'], [`C(${N},${M})`, M <= N ? fmtBig(comb(N, M)) : '—'], [`${N}!`, fmtBig(perm(N, N))]]);
    });
    const sup = k => String(k).split('').map(ch => '⁰¹²³⁴⁵⁶⁷⁸⁹'[ch]).join('');
    const sciShort = v => v.toExponential(1).replace('e+', 'e');
    const fmtBig = v => v < 1e15 ? v.toLocaleString('en-US') : sci(v, 3);
  }
});

/* ---------- 随机试验与高尔顿板 ---------- */
Lab.reg({
  id: 'm-galton', subj: 'math', book: 1, unit: '概率 · 频率的稳定性', title: '高尔顿板与频率稳定性', kw: '随机事件 频率 概率 二项分布 正态分布 大数定律',
  info: `<p><b>高尔顿板</b>：小球每遇到一个钉子，以概率 p 向右、1−p 向左。经过 n 排钉子后落入第 k 个槽的概率为二项分布 <span class="f">P(X=k) = Cₙᵏ pᵏ(1−p)ⁿ⁻ᵏ</span>。球数很多时，直方图接近正态曲线。</p>
  <p><b>频率的稳定性</b>：在大量重复试验中，事件 A 发生的频率 fₙ(A) 会逐渐稳定在概率 P(A) 附近。试验次数越多，偏离越小，但每次具体结果仍随机。</p>`,
  tasks: ['p=0.5、10 排钉子，落入中间槽的理论概率是多少？放 500 个球后比较频率。', '改变 p 为 0.3，分布的峰值向哪边移动？均值 np 是多少？', '频率模式下连续做 10 次「抛 100 次」，记录频率的波动范围；再试「抛 10000 次」。'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['g', '高尔顿板'], ['f', '频率稳定性']], 'g', m => { G1.hidden = m !== 'g'; G2.hidden = m !== 'f'; L.draw(); });
    const G1 = L.group('高尔顿板');
    const p = L.params({ n: ['钉子排数 n', 4, 16, 1, 10], p: ['向右概率 p', 0.1, 0.9, 0.05, 0.5], sp: ['速度', 1, 10, 1, 4] }, k => { if (k !== 'sp') reset(); });
    const theo = L.check('显示理论分布', true);
    L.button('放 1 个球', () => spawn(1)); L.button('连续放球', b => { auto = !auto; b.setAttribute('aria-pressed', auto); }); L.button('一次 500 个', () => { for (let i = 0; i < 500; i++) drop(); L.draw(); }); L.button('清空', () => reset());
    const out = L.out();
    const G2 = L.group('频率稳定性'); G2.hidden = true;
    const ev = L.select('事件', [['0.5', '抛硬币，正面朝上（P=1/2）'], ['0.16667', '掷骰子，点数为 6（P=1/6）'], ['0.16667b', '掷两枚骰子，点数和为 7（P=1/6）'], ['0.25', '抽扑克，抽到红桃（P=1/4）']], '0.5', () => { hist = []; L.draw(); });
    L.button('做 100 次', () => trials(100)); L.button('做 1000 次', () => trials(1000)); L.button('做 10000 次', () => trials(10000)); L.button('清空', () => { hist = []; L.draw(); });
    const out2 = L.out();
    let balls = [], bins = [], total = 0, auto = false, hist = [];
    function reset() { balls = []; bins = new Array(p.n + 1).fill(0); total = 0; L.draw(); }
    function drop() { let k = 0; for (let i = 0; i < p.n; i++) if (Math.random() < p.p) k++; bins[k]++; total++; }
    function spawn(m) { for (let i = 0; i < m; i++) balls.push({ row: 0, col: 0, t: -i * 0.4, path: [...Array(p.n)].map(() => Math.random() < p.p ? 1 : 0) }); }
    function trials(m) {
      const pr = parseFloat(ev.v), two = ev.v.endsWith('b');
      let h = hist.length ? hist[hist.length - 1] : [0, 0];
      for (let i = 0; i < m; i++) {
        const hit = two ? (Math.ceil(Math.random() * 6) + Math.ceil(Math.random() * 6) === 7) : Math.random() < pr;
        h = [h[0] + 1, h[1] + (hit ? 1 : 0)]; if (h[0] <= 200 || h[0] % Math.ceil(h[0] / 400) === 0) hist.push(h);
      }
      hist.push(h); L.draw();
    }
    reset();
    let acc = 0;
    L.loop(dt => {
      if (mode.v !== 'g') return;
      if (auto) { acc += dt * p.sp * 3; while (acc > 1) { spawn(1); acc--; } }
      for (const b of balls) { b.t += dt * p.sp * 2.5; while (b.t >= 1 && b.row < p.n) { b.col += b.path[b.row]; b.row++; b.t -= 1; } }
      balls = balls.filter(b => { if (b.row >= p.n && b.t >= 1) { bins[b.col]++; total++; return false; } return true; });
      L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g;
      if (mode.v === 'g') {
        const n = p.n, top = 30, bottom = c.h * 0.42, dx = Math.min(c.w / (n + 3), 46), dy = (bottom - top) / n, cx = c.w / 2;
        for (let i = 0; i < n; i++) for (let j = 0; j <= i; j++) D.circle(g, cx + (j - i / 2) * dx, top + i * dy + dy / 2, 3, T.muted);
        for (const b of balls) { if (b.t < 0) continue; const nc = b.col + (b.row < n ? b.path[b.row] : 0), t = Math.min(1, b.t); const x0 = cx + (b.col - b.row / 2) * dx, x1 = cx + (nc - (b.row + 1) / 2) * dx; D.circle(g, lerp(x0, x1, t), top + (b.row + t) * dy - dy / 2 + dy / 2 - Math.sin(t * PI) * dy * 0.25, 4.5, T.c2); }
        const by = c.h - 30, bh = by - bottom - 30, mx = Math.max(1, ...bins), pr = [...Array(n + 1).keys()].map(k => comb(n, k) * p.p ** k * (1 - p.p) ** (n - k)), mxp = Math.max(...pr);
        const scale = Math.max(mx, total * mxp) || 1;
        for (let k = 0; k <= n; k++) { const x = cx + (k - n / 2) * dx; D.line(g, x - dx / 2, by, x - dx / 2, bottom + 10, T.grid2, 1); const h = bins[k] / scale * bh; D.rect(g, x - dx / 2 + 2, by - h, dx - 4, h, alpha(T.c1, 0.75)); D.text(g, k, x, by + 12, T.muted, { align: 'center', size: 11, mono: true }); }
        D.line(g, cx - (n / 2 + 0.5) * dx, by, cx + (n / 2 + 0.5) * dx, by, T.axis, 1.2);
        if (theo.v && total > 0) { g.strokeStyle = T.c2; g.lineWidth = 2; g.beginPath(); pr.forEach((q, k) => { const x = cx + (k - n / 2) * dx, y = by - q * total / scale * bh; k ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke(); }
        const mean = total ? bins.reduce((s, b, k) => s + b * k, 0) / total : 0, vr = total ? bins.reduce((s, b, k) => s + b * (k - mean) ** 2, 0) / total : 0;
        out.set([['已落球数', total], ['样本均值', fmt(mean, 3)], ['理论均值 np', fmt(n * p.p, 3)], ['样本方差', fmt(vr, 3)], ['理论方差 np(1−p)', fmt(n * p.p * (1 - p.p), 3)], ['中间槽理论概率', fmt(pr[Math.round(n * p.p)], 4)]]);
      } else {
        const pr = parseFloat(ev.v), v = new View(c, 0, 1, 0, 1, { pad: [50, 20, 20, 36] });
        const N = hist.length ? hist[hist.length - 1][0] : 100; v.r = [0, N, Math.max(0, pr - 0.5), Math.min(1, pr + 0.5)]; v.fit(); v.grid({ xl: '试验次数 n', yl: '频率' });
        v.seg(0, pr, N, pr, T.c2, 1.6, [6, 4]); v.label('P = ' + fmt(pr, 4), N, pr, T.c2, { align: 'right', dx: -4 });
        g.strokeStyle = T.c1; g.lineWidth = 1.8; g.beginPath(); hist.forEach((h, i) => { const x = v.X(h[0]), y = v.Y(h[1] / h[0]); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke();
        const last = hist[hist.length - 1];
        out2.set(last ? [['试验次数', last[0]], ['事件发生次数', last[1]], ['频率', fmt(last[1] / last[0], 4)], ['与概率之差', fmt(last[1] / last[0] - pr, 4)]] : [['提示', '点击上方按钮开始试验']]);
      }
    });
  }
});

/* ---------- 概率分布 ---------- */
function erf(x) { const s = Math.sign(x); x = Math.abs(x); const t = 1 / (1 + 0.3275911 * x); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return s * y; }
const Phi = z => 0.5 * (1 + erf(z / Math.SQRT2));
Lab.reg({
  id: 'm-dist', subj: 'math', book: 4, unit: '随机变量及其分布', title: '二项、超几何与正态分布', kw: '分布列 期望 方差 正态 3σ 原则',
  info: `<p class="fb">二项分布 X ~ B(n, p)：P(X=k) = Cₙᵏpᵏ(1−p)ⁿ⁻ᵏ，E(X)=np，D(X)=np(1−p)<br>超几何分布：N 件中有 M 件次品，抽 n 件，P(X=k) = C(M,k)C(N−M,n−k)/C(N,n)，E(X)=nM/N<br>正态分布 X ~ N(μ, σ²)：f(x) = 1/(σ√2π)·e^(−(x−μ)²/2σ²)</p>
  <p><b>3σ 原则</b>：P(μ−σ ≤ X ≤ μ+σ) ≈ 0.6827，P(μ−2σ ≤ X ≤ μ+2σ) ≈ 0.9545，P(μ−3σ ≤ X ≤ μ+3σ) ≈ 0.9973。</p>`,
  tasks: ['二项分布中，n 固定时 p 取何值方差最大？', '比较 N 很大时的超几何分布与二项分布 B(n, M/N)，两者有什么关系？', '正态分布中把区间设为 [μ−2σ, μ+2σ]，验证概率约为 0.9545。'],
  init(L) {
    const c = L.canvas();
    L.group('分布');
    const kind = L.seg('', [['bin', '二项'], ['hyp', '超几何'], ['nor', '正态']], 'bin', () => { sync(); L.draw(); });
    const p = L.params({ n: ['n（试验/抽取次数）', 1, 40, 1, 10], p: ['p', 0.01, 0.99, 0.01, 0.4], N: ['总数 N', 5, 100, 1, 30], M: ['次品数 M', 1, 100, 1, 8], mu: ['μ', -5, 5, 0.1, 0], sg: ['σ', 0.2, 3, 0.05, 1] });
    L.group('区间概率 P(a ≤ X ≤ b)');
    const q = L.params({ a: ['a', -10, 40, 0.1, 2], b: ['b', -10, 40, 0.1, 5] });
    L.button('μ ± σ', () => setAB(1)); L.button('μ ± 2σ', () => setAB(2)); L.button('μ ± 3σ', () => setAB(3));
    const cmp = L.check('超几何同时画二项 B(n, M/N) 比较', true);
    const out = L.out();
    function setAB(k) { q.$a.set(p.mu - k * p.sg, true); q.$b.set(p.mu + k * p.sg); }
    function sync() { const k = kind.v; p.$n.el.hidden = k === 'nor'; p.$p.el.hidden = k !== 'bin'; p.$N.el.hidden = p.$M.el.hidden = k !== 'hyp'; p.$mu.el.hidden = p.$sg.el.hidden = k !== 'nor'; }
    sync();
    L.onDraw(() => {
      c.clear(); const g = c.g, k = kind.v, { a, b } = q;
      const v = new View(c, 0, 1, 0, 1, { pad: [46, 16, 20, 30] });
      if (k === 'nor') {
        const { mu, sg } = p, f = x => Math.exp(-((x - mu) ** 2) / (2 * sg * sg)) / (sg * Math.sqrt(TAU));
        v.r = [mu - 4.2 * sg, mu + 4.2 * sg, 0, f(mu) * 1.15]; v.fit(); v.grid({ yl: 'f(x)' });
        g.fillStyle = alpha(T.c2, 0.3); g.beginPath(); const lo = Math.max(a, v.x0), hi = Math.min(b, v.x1);
        if (hi > lo) { g.moveTo(v.X(lo), v.Y(0)); for (let i = 0; i <= 100; i++) { const x = lo + (hi - lo) * i / 100; g.lineTo(v.X(x), v.Y(f(x))); } g.lineTo(v.X(hi), v.Y(0)); g.fill(); }
        v.plot(f, T.c1, 2.4); v.seg(mu, 0, mu, f(mu), T.muted, 1, [4, 3]);
        [-3, -2, -1, 1, 2, 3].forEach(z => v.seg(mu + z * sg, 0, mu + z * sg, f(mu + z * sg), T.grid2, 1));
        const P = Phi((b - mu) / sg) - Phi((a - mu) / sg);
        out.set([['E(X) = μ', fmt(mu, 3)], ['D(X) = σ²', fmt(sg * sg, 4)], ['P(a ≤ X ≤ b)', fmt(Math.max(0, P), 5)], ['最高点', `(${fmt(mu, 2)}, ${fmt(f(mu), 4)})`]]);
        return;
      }
      const n = k === 'hyp' ? Math.min(p.n, p.N) : p.n, M = Math.min(p.M, p.N);
      const pmf = [...Array(n + 1).keys()].map(j => k === 'bin' ? comb(n, j) * p.p ** j * (1 - p.p) ** (n - j) : comb(M, j) * comb(p.N - M, n - j) / comb(p.N, n));
      const bpm = k === 'hyp' && cmp.v ? [...Array(n + 1).keys()].map(j => comb(n, j) * (M / p.N) ** j * (1 - M / p.N) ** (n - j)) : null;
      v.r = [-0.8, n + 0.8, 0, Math.max(...pmf, ...(bpm || [0])) * 1.15]; v.fit(); v.grid({ xl: 'k', yl: 'P(X=k)', xstep: n > 20 ? 5 : n > 10 ? 2 : 1 });
      const bw = Math.min(30, v.sx * 0.7); let P = 0, E = 0, E2 = 0;
      pmf.forEach((pr, j) => { const inside = j >= a - 1e-9 && j <= b + 1e-9; if (inside) P += pr; E += j * pr; E2 += j * j * pr; D.rect(g, v.X(j) - bw / 2, v.Y(pr), bw, v.Y(0) - v.Y(pr), inside ? alpha(T.c2, 0.8) : alpha(T.c1, 0.55)); });
      if (bpm) { g.strokeStyle = T.c4; g.lineWidth = 2; g.beginPath(); bpm.forEach((pr, j) => j ? g.lineTo(v.X(j), v.Y(pr)) : g.moveTo(v.X(j), v.Y(pr))); g.stroke(); }
      const rows = [['E(X)', fmt(E, 4)], ['D(X)', fmt(E2 - E * E, 4)], ['P(a ≤ X ≤ b)', fmt(P, 5)], ['最可能取值', pmf.indexOf(Math.max(...pmf))]];
      if (k === 'bin') rows.push(['公式 np , np(1−p)', `${fmt(n * p.p, 3)} , ${fmt(n * p.p * (1 - p.p), 3)}`]);
      else rows.push(['公式 nM/N', fmt(n * M / p.N, 4)]);
      out.set(rows);
    });
  }
});

/* ---------- 统计：直方图 ---------- */
Lab.reg({
  id: 'm-stat', subj: 'math', book: 1, unit: '统计', title: '样本数据与频率分布直方图', kw: '平均数 中位数 众数 方差 标准差 百分位数 组距',
  info: `<p>纵轴是 <b>频率/组距</b>，所以每个小矩形的面积等于该组频率，所有矩形面积之和为 1。</p>
  <p class="fb">用直方图估计：平均数 ≈ Σ(组中值 × 频率)；中位数是使左右两侧面积都为 0.5 的横坐标；众数取最高矩形的组中值<br>方差 s² = (1/n)Σ(xᵢ − x̄)²<br>第 p 百分位数：计算 i = n·p%，i 非整数则取第 ⌈i⌉ 项，i 为整数则取第 i 项与第 i+1 项的平均</p>`,
  tasks: ['用右偏分布抽样，比较平均数与中位数的大小。', '改变组距，直方图形状与估计值如何变化？', '求第 25、75 百分位数，它们之间包含了多少比例的数据？'],
  init(L) {
    const c = L.canvas();
    let data = [];
    L.group('抽样');
    const dist = L.select('总体分布', [['n', '近似正态（如身高）'], ['r', '右偏（如收入）'], ['u', '均匀'], ['b', '双峰']], 'n', () => sample());
    const n = L.slider('样本量 n', 20, 2000, 10, 200, () => sample());
    L.button('重新抽样', () => sample(), true);
    L.group('直方图');
    const w = L.slider('组距', 1, 20, 0.5, 5);
    const pc = L.slider('百分位 p', 1, 99, 1, 75, null, '%');
    const out = L.out();
    function sample() {
      const N = n.v; data = [];
      for (let i = 0; i < N; i++) {
        let x;
        if (dist.v === 'n') x = 165 + 7 * gauss();
        if (dist.v === 'r') x = 140 + Math.exp(3 + 0.6 * gauss());
        if (dist.v === 'u') x = rnd(140, 190);
        if (dist.v === 'b') x = Math.random() < 0.5 ? 155 + 5 * gauss() : 178 + 5 * gauss();
        data.push(Math.round(x * 10) / 10);
      }
      data.sort((a, b) => a - b); L.draw();
    }
    sample();
    L.onDraw(() => {
      c.clear(); const g = c.g, N = data.length, W = w.v;
      const lo = Math.floor(data[0] / W) * W, hi = Math.ceil((data[N - 1] + 1e-9) / W) * W, K = Math.max(1, Math.round((hi - lo) / W));
      const cnt = new Array(K).fill(0); data.forEach(x => cnt[Math.min(K - 1, Math.floor((x - lo) / W))]++);
      const den = cnt.map(k => k / N / W), v = new View(c, lo, hi, 0, Math.max(...den) * 1.18, { pad: [52, 16, 18, 30] }); v.fit(); v.grid({ xl: '数据', yl: '频率/组距', xstep: W * Math.max(1, Math.round(60 / (W * v.sx))) });
      den.forEach((d, i) => D.rect(g, v.X(lo + i * W), v.Y(d), W * v.sx, v.Y(0) - v.Y(d), alpha(T.c1, 0.6), T.c1, 1));
      const mean = data.reduce((s, x) => s + x, 0) / N, med = N % 2 ? data[(N - 1) / 2] : (data[N / 2 - 1] + data[N / 2]) / 2;
      const vr = data.reduce((s, x) => s + (x - mean) ** 2, 0) / N;
      const hMean = cnt.reduce((s, k, i) => s + (lo + (i + 0.5) * W) * k / N, 0);
      let accp = 0, hMed = lo; for (let i = 0; i < K; i++) { const f = cnt[i] / N; if (accp + f >= 0.5) { hMed = lo + i * W + (0.5 - accp) / f * W; break; } accp += f; }
      const mi = cnt.indexOf(Math.max(...cnt)), hMode = lo + (mi + 0.5) * W;
      const ii = N * pc.v / 100, pv = Number.isInteger(ii) ? (data[ii - 1] + data[Math.min(N - 1, ii)]) / 2 : data[Math.ceil(ii) - 1];
      const mark = (x, col, t, row) => { v.seg(x, 0, x, v.y1, col, 1.8, [6, 3]); D.text(g, t, v.X(x) + 4, v.oy + 12 + row * 15, col, { size: 11.5 }); };
      mark(mean, T.c2, '平均数', 0); mark(med, T.c3, '中位数', 1); mark(hMode, T.c4, '众数', 2); mark(pv, T.c5, `P${pc.v}`, 3);
      out.set([['样本量', N], ['平均数 x̄', fmt(mean, 2)], ['中位数', fmt(med, 2)], ['方差 s²', fmt(vr, 2)], ['标准差 s', fmt(Math.sqrt(vr), 2)], [`第 ${pc.v} 百分位数`, fmt(pv, 2)], ['极差', fmt(data[N - 1] - data[0], 1)],
        ['<i>由直方图估计</i>', ''], ['平均数', fmt(hMean, 2)], ['中位数', fmt(hMed, 2)], ['众数', fmt(hMode, 2)]]);
    });
  }
});

/* ---------- 成对数据：回归与独立性检验 ---------- */
Lab.reg({
  id: 'm-reg', subj: 'math', book: 4, unit: '成对数据的统计分析', title: '一元线性回归与独立性检验', kw: '最小二乘 相关系数 残差 决定系数 卡方 列联表',
  info: `<p class="fb">b̂ = Σ(xᵢ−x̄)(yᵢ−ȳ) / Σ(xᵢ−x̄)²，â = ȳ − b̂x̄，回归直线必过样本中心 (x̄, ȳ)<br>r = Σ(xᵢ−x̄)(yᵢ−ȳ) / √[Σ(xᵢ−x̄)²·Σ(yᵢ−ȳ)²]，|r| 越接近 1 线性相关越强<br>R² = 1 − Σ(yᵢ−ŷᵢ)² / Σ(yᵢ−ȳ)²</p>
  <p><b>独立性检验</b>：χ² = n(ad − bc)² / [(a+b)(c+d)(a+c)(b+d)]。临界值：α=0.1 → 2.706，0.05 → 3.841，0.01 → 6.635，0.005 → 7.879，0.001 → 10.828。</p>`,
  tasks: ['点击画布添加点，拖动一个点远离直线（离群点），看 r 和回归直线如何变化。', '把所有点排成一条直线，r 等于多少？', '独立性检验：改变 a、d 让 ad 与 bc 接近，χ² 如何变化？'],
  init(L) {
    const c = L.canvas(), v = new View(c, 0, 10, 0, 10, { pad: [36, 14, 14, 30] });
    let pts = [[1, 2.1], [2, 2.9], [3, 3.2], [4, 4.8], [5, 5.1], [6, 5.9], [7, 7.4], [8, 7.6], [9, 8.9]];
    L.group('模式');
    const mode = L.seg('', [['r', '线性回归'], ['x', '独立性检验']], 'r', m => { G1.hidden = m !== 'r'; G2.hidden = m !== 'x'; L.draw(); });
    const G1 = L.group('回归');
    const res = L.check('画残差', true);
    L.button('随机生成', () => { const k = rnd(-1, 1.2), b = rnd(1, 4), s = rnd(0.3, 1.8); pts = [...Array(14)].map(() => { const x = rnd(0.5, 9.5); return [x, clamp(b + k * x * 0.7 + s * gauss(), 0.2, 9.8)]; }); L.draw(); });
    L.button('删最后一个点', () => { pts.pop(); L.draw(); }); L.button('清空', () => { pts = []; L.draw(); });
    L.note('点击空白处添加点，拖动已有点。');
    const out = L.out();
    const G2 = L.group('2×2 列联表'); G2.hidden = true;
    L.note('例：是否吸烟与是否患病');
    const t = L.params({ a: ['a 吸烟·患病', 0, 200, 1, 60], b: ['b 吸烟·未患病', 0, 200, 1, 40], c: ['c 不吸烟·患病', 0, 200, 1, 30], d: ['d 不吸烟·未患病', 0, 200, 1, 70] });
    const out2 = L.out();
    L.interact(c, {
      hit: (x, y) => { if (mode.v !== 'r') return null; const i = pts.findIndex(p => Math.hypot(v.X(p[0]) - x, v.Y(p[1]) - y) < 10); return i >= 0 ? { i } : null; },
      drag: (o, x, y) => { pts[o.i] = [clamp(v.ix(x), 0, 10), clamp(v.iy(y), 0, 10)]; },
      click: (x, y, o) => { if (mode.v === 'r' && !o) { pts.push([clamp(v.ix(x), 0, 10), clamp(v.iy(y), 0, 10)]); } }
    });
    L.onDraw(() => {
      c.clear(); const g = c.g;
      if (mode.v === 'r') {
        v.fit(); v.grid();
        const n = pts.length; let rows = [['点数', n]];
        if (n >= 2) {
          const mx = pts.reduce((s, p) => s + p[0], 0) / n, my = pts.reduce((s, p) => s + p[1], 0) / n;
          let sxy = 0, sxx = 0, syy = 0; pts.forEach(([x, y]) => { sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; syy += (y - my) ** 2; });
          const b = sxx ? sxy / sxx : 0, a = my - b * mx, r = sxx && syy ? sxy / Math.sqrt(sxx * syy) : 0;
          const sse = pts.reduce((s, [x, y]) => s + (y - a - b * x) ** 2, 0), R2 = syy ? 1 - sse / syy : 1;
          if (res.v) pts.forEach(([x, y]) => v.seg(x, y, x, a + b * x, T.c2, 1.2));
          v.plot(x => a + b * x, T.c1, 2.4); v.dot(mx, my, T.c4, 6, true); v.label('(x̄, ȳ)', mx, my, T.c4);
          rows.push(['回归方程', `ŷ = ${fmt(b, 3)}x ${a >= 0 ? '+' : '−'} ${fmt(Math.abs(a), 3)}`], ['x̄ , ȳ', `${fmt(mx, 3)} , ${fmt(my, 3)}`], ['相关系数 r', fmt(r, 4)], ['相关性', Math.abs(r) > 0.75 ? (r > 0 ? '强正相关' : '强负相关') : Math.abs(r) > 0.3 ? (r > 0 ? '正相关' : '负相关') : '相关性弱'], ['残差平方和', fmt(sse, 4)], ['决定系数 R²', fmt(R2, 4)]);
        }
        pts.forEach(([x, y]) => v.dot(x, y, T.fg, 4.5, true));
        out.set(rows);
      } else {
        const { a, b, c: cc, d } = t, n = a + b + cc + d, chi = (a + b) * (cc + d) * (a + cc) * (b + d) ? n * (a * d - b * cc) ** 2 / ((a + b) * (cc + d) * (a + cc) * (b + d)) : 0;
        const crit = [[0.1, 2.706], [0.05, 3.841], [0.01, 6.635], [0.005, 7.879], [0.001, 10.828]];
        const pass = crit.filter(x => chi >= x[1]);
        const W = Math.min(c.w - 80, 420), x0 = (c.w - W) / 2, y0 = 50, H = c.h - 120, bw = W / 2 - 40;
        [[a, b, '吸烟'], [cc, d, '不吸烟']].forEach(([p1, p2, lab], i) => {
          const s = p1 + p2 || 1, x = x0 + i * (W / 2) + 20;
          D.rect(g, x, y0, bw, H * p1 / s, alpha(T.c2, 0.75)); D.rect(g, x, y0 + H * p1 / s, bw, H * p2 / s, alpha(T.c1, 0.5));
          D.text(g, `患病 ${fmt(p1 / s * 100, 1)}%`, x + bw / 2, y0 + H * p1 / s / 2, T.fg, { align: 'center' });
          D.text(g, lab, x + bw / 2, y0 + H + 16, T.fg, { align: 'center', bold: true });
        });
        D.text(g, '等高堆积条形图：两组中「患病」所占比例差别越大，越可能有关联', c.w / 2, 24, T.muted, { align: 'center' });
        out2.set([['n', n], ['ad − bc', a * d - b * cc], ['χ²', fmt(chi, 4)], ['结论', pass.length ? `在 α = ${pass[pass.length - 1][0]} 水平下认为两者有关联` : '没有充分证据认为有关联（α = 0.1）']]);
      }
    });
  }
});

/* ---------- 导数：割线到切线 ---------- */
Lab.reg({
  id: 'm-deriv', subj: 'math', book: 3, unit: '一元函数的导数及其应用', title: '割线逼近切线与单调性', kw: '导数 瞬时变化率 平均变化率 切线 单调区间 极值',
  info: `<p><b>平均变化率</b> Δy/Δx = [f(x₀+Δx) − f(x₀)]/Δx 是割线斜率。当 Δx → 0 时它的极限就是导数 f′(x₀)，割线趋于切线。</p>
  <p class="fb">f′(x) &gt; 0 的区间上 f(x) 单调递增；f′(x) &lt; 0 的区间上单调递减<br>f′(x₀) = 0 且两侧异号 ⇒ x₀ 为极值点</p>
  <p>下方小图是导函数 f′(x)，上方 x 轴上的色带表示单调性（绿：增，红：减）。</p>`,
  tasks: ['点「让 Δx → 0」，记录割线斜率的变化，看它趋于多少。', '对 x³ 在 x₀=0 处观察：f′(0)=0 但 0 不是极值点，为什么？', '比较 sin x 与它的导函数 cos x 的图像关系。'],
  init(L) {
    const c = L.canvas(), v = new View(c, -4, 4, -4, 4), v2 = new View(c, -4, 4, -4, 4);
    let F = null, src = 'x^3-3x';
    L.group('函数');
    const fin = L.input('f(x) =', src, (s, o) => { try { F = compileExpr(s); o.err(''); } catch (e) { F = null; o.err(e.message); } L.draw(); });
    L.select('预设', ['x^3-3x', 'x^2', 'x^3', 'sin(x)', 'e^x', 'ln(x)', '1/x', 'x*e^(-x)'], 'x^3-3x', s => fin.set(s));
    const p = L.params({ x0: ['x₀', -3.5, 3.5, 0.05, 0.8], h: ['Δx', -2.5, 2.5, 0.01, 1.5] });
    let tw = null;
    L.button('让 Δx → 0', () => { tw = true; }, true); L.button('Δx 复原', () => { tw = null; p.h = 1.5; });
    const mono = L.check('显示单调性色带', true);
    const out = L.out();
    F = compileExpr(src);
    L.loop(dt => { if (tw) { const nh = p.h * Math.pow(0.25, dt); if (Math.abs(nh) < 0.001) { tw = null; p.$h.set(Math.sign(p.h) * 0.001); } else p.$h.set(nh); } });
    L.onDraw(() => {
      c.clear(); const H = c.h; v.pad = [0, 0, 0, H * 0.34]; v2.pad = [0, 0, H * 0.7, 0];
      v.fit(); v.grid(); if (!F) return;
      const d = x => (F(x + 1e-5) - F(x - 1e-5)) / 2e-5, { x0, h } = p, y0 = F(x0), y1 = F(x0 + h), k = (y1 - y0) / h, kt = d(x0);
      const g = c.g;
      if (mono.v) { for (let px = 0; px < c.w; px += 3) { const dd = d(v.ix(px)); if (!isFinite(dd)) continue; g.fillStyle = dd > 0 ? alpha(T.ok, 0.55) : alpha(T.bad, 0.55); g.fillRect(px, v.oy + v.H - 6, 3, 6); } }
      v.plot(F, T.c1, 2.4);
      v.plot(x => y0 + k * (x - x0), T.c2, 1.6); v.plot(x => y0 + kt * (x - x0), T.c3, 1.6, [6, 4]);
      v.seg(x0, y0, x0 + h, y0, T.muted, 1.2, [3, 3]); v.seg(x0 + h, y0, x0 + h, y1, T.muted, 1.2, [3, 3]);
      v.label('Δx', x0 + h / 2, y0, T.muted, { dy: 12 }); v.label('Δy', x0 + h, (y0 + y1) / 2, T.muted);
      v.dot(x0, y0, T.c1, 5, true); v.dot(x0 + h, y1, T.c2, 5, true);
      D.line(g, 0, v2.oy - 8, c.w, v2.oy - 8, T.line, 1);
      v2.r = [v.r[0], v.r[1], -6, 6]; v2.fit(); v2.grid({ yl: "f′(x)" }); v2.plot(d, T.c3, 2); v2.dot(x0, kt, T.c3, 4.5, true);
      out.set([['f(x₀)', fmt(y0, 4)], ['割线斜率 Δy/Δx', fmt(k, 5)], ['切线斜率 f′(x₀)', fmt(kt, 5)], ['两者之差', fmt(k - kt, 5)], ['x₀ 处单调性', kt > 1e-6 ? '递增' : kt < -1e-6 ? '递减' : '导数为 0']]);
      D.text(g, '— 割线', 10, 16, T.c2); D.text(g, '- - 切线', 70, 16, T.c3);
    });
  }
});
