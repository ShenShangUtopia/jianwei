'use strict';
/* ================= 通用工具 ================= */
const PI = Math.PI, TAU = 2 * Math.PI;
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const rnd = (a = 0, b = 1) => a + Math.random() * (b - a);
const gauss = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * v); };
const FONT = '"PingFang SC","Microsoft YaHei","Noto Sans SC",system-ui,sans-serif';
const MONO = '"IBM Plex Mono",ui-monospace,Consolas,monospace';

function sci(v, d = 2) {
  if (v === 0) return '0';
  let e = Math.floor(Math.log10(Math.abs(v))), m = +(v / 10 ** e).toFixed(d);
  if (Math.abs(m) >= 10) { m = +(m / 10).toFixed(d); e++; }
  return `${m}×10<sup>${e}</sup>`;
}
function fmt(v, d = 2) {
  if (v == null || !isFinite(v)) return '—';
  const a = Math.abs(v);
  if (a !== 0 && (a >= 1e6 || a < 1e-3)) return sci(v, d);
  const r = +v.toFixed(d);
  return (Object.is(r, -0) ? 0 : r).toString();
}
function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; }
function comb(n, k) { if (k < 0 || k > n) return 0; k = Math.min(k, n - k); let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); }
function perm(n, k) { if (k < 0 || k > n) return 0; let r = 1; for (let i = 0; i < k; i++) r *= n - i; return r; }

/* ================= 主题色 ================= */
const T = {};
function readTheme() {
  const cs = getComputedStyle(document.body);
  ['stage', 'fg', 'muted', 'line', 'grid', 'grid2', 'axis', 'surface', 'bg', 'accent', 'ok', 'bad',
    'c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'math', 'phys', 'chem', 'bio'].forEach(k => T[k] = cs.getPropertyValue('--' + k).trim());
  T.dark = isDark();
  T.c = [T.c1, T.c2, T.c3, T.c4, T.c5, T.c6];
}
function isDark() {
  const t = document.documentElement.dataset.theme;
  if (t) return t === 'dark';
  return matchMedia('(prefers-color-scheme: dark)').matches;
}
function alpha(c, a) { // 给 #rrggbb 加透明度
  if (c[0] !== '#') return c;
  const n = parseInt(c.slice(1), 16);
  return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`;
}

/* ================= 画图工具 ================= */
const D = {
  line(g, x1, y1, x2, y2, c, w = 1.5, dash) {
    g.strokeStyle = c; g.lineWidth = w; g.setLineDash(dash || []);
    g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); g.setLineDash([]);
  },
  circle(g, x, y, r, fill, stroke, w = 1.5) {
    g.beginPath(); g.arc(x, y, Math.max(0, r), 0, TAU);
    if (fill) { g.fillStyle = fill; g.fill(); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = w; g.stroke(); }
  },
  rect(g, x, y, w, h, fill, stroke, lw = 1.5) {
    if (fill) { g.fillStyle = fill; g.fillRect(x, y, w, h); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = lw; g.strokeRect(x, y, w, h); }
  },
  rrect(g, x, y, w, h, r, fill, stroke, lw = 1.5) {
    g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h);
    if (fill) { g.fillStyle = fill; g.fill(); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = lw; g.stroke(); }
  },
  poly(g, pts, fill, stroke, w = 1.5, close = true) {
    if (!pts.length) return;
    g.beginPath(); g.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
    if (close) g.closePath();
    if (fill) { g.fillStyle = fill; g.fill(); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = w; g.lineJoin = 'round'; g.stroke(); }
  },
  text(g, s, x, y, c, o = {}) {
    g.fillStyle = c || T.fg;
    g.font = `${o.bold ? '600 ' : ''}${o.size || 12}px ${o.mono ? MONO : FONT}`;
    g.textAlign = o.align || 'left'; g.textBaseline = o.base || 'middle';
    g.fillText(s, x, y);
  },
  arrow(g, x1, y1, x2, y2, c, w = 2, head = 9) {
    const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy);
    if (L < 0.5) return;
    const ux = dx / L, uy = dy / L, h = Math.min(head, L * 0.6);
    D.line(g, x1, y1, x2 - ux * h * 0.7, y2 - uy * h * 0.7, c, w);
    g.fillStyle = c; g.beginPath(); g.moveTo(x2, y2);
    g.lineTo(x2 - ux * h - uy * h * 0.45, y2 - uy * h + ux * h * 0.45);
    g.lineTo(x2 - ux * h + uy * h * 0.45, y2 - uy * h - ux * h * 0.45); g.closePath(); g.fill();
  },
  spring(g, x1, y1, x2, y2, coils, amp, c, w = 1.5) {
    const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L;
    g.strokeStyle = c; g.lineWidth = w; g.beginPath(); g.moveTo(x1, y1);
    const n = coils * 2, lead = L * 0.08;
    g.lineTo(x1 + ux * lead, y1 + uy * lead);
    for (let i = 1; i < n; i++) {
      const t = lead + (L - 2 * lead) * i / n, s = (i % 2 ? 1 : -1) * amp;
      g.lineTo(x1 + ux * t - uy * s, y1 + uy * t + ux * s);
    }
    g.lineTo(x2 - ux * lead, y2 - uy * lead); g.lineTo(x2, y2); g.stroke();
  },
  // 曲线面板（时间序列等）：pts 为 [x,y]，自动缩放
  chart(g, x, y, w, h, series, o = {}) {
    D.rect(g, x, y, w, h, o.bg || null, T.line, 1);
    let xmin = o.xmin, xmax = o.xmax, ymin = o.ymin, ymax = o.ymax;
    const all = series.flatMap(s => s.pts);
    if (xmin == null) xmin = Math.min(...all.map(p => p[0]), 0);
    if (xmax == null) xmax = Math.max(...all.map(p => p[0]), 1);
    if (ymin == null) ymin = Math.min(...all.map(p => p[1]), 0);
    if (ymax == null) ymax = Math.max(...all.map(p => p[1]), 1e-9) * 1.1;
    if (xmax === xmin) xmax = xmin + 1; if (ymax === ymin) ymax = ymin + 1;
    const X = v => x + (v - xmin) / (xmax - xmin) * w, Y = v => y + h - (v - ymin) / (ymax - ymin) * h;
    if (ymin < 0 && ymax > 0) D.line(g, x, Y(0), x + w, Y(0), T.grid2, 1);
    for (const s of series) {
      if (s.pts.length < 2) continue;
      g.strokeStyle = s.color; g.lineWidth = s.w || 1.8; g.setLineDash(s.dash || []); g.beginPath();
      s.pts.forEach((p, i) => i ? g.lineTo(X(p[0]), Y(p[1])) : g.moveTo(X(p[0]), Y(p[1]))); g.stroke(); g.setLineDash([]);
    }
    if (o.title) D.text(g, o.title, x + 6, y + 10, T.muted, { size: 11 });
    if (o.xl) D.text(g, o.xl, x + w - 4, y + h - 8, T.muted, { size: 11, align: 'right' });
    if (o.yticks !== false) {
      D.text(g, fmt(ymax, 2), x - 4, y + 6, T.muted, { size: 10, align: 'right', mono: true });
      D.text(g, fmt(ymin, 2), x - 4, y + h - 4, T.muted, { size: 10, align: 'right', mono: true });
    }
    return { X, Y, xmin, xmax, ymin, ymax };
  }
};
function niceStep(raw) {
  const e = 10 ** Math.floor(Math.log10(raw)), f = raw / e;
  return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * e;
}

/* ================= 二维坐标视图 ================= */
class View {
  constructor(c, xmin, xmax, ymin, ymax, o = {}) {
    this.c = c; this.home = [xmin, xmax, ymin, ymax]; this.r = [xmin, xmax, ymin, ymax];
    this.equal = !!o.equal; this.pad = o.pad || [0, 0, 0, 0]; this.o = o; this.fit();
  }
  reset() { this.r = this.home.slice(); }
  fit() {
    const [pl, pr, pt, pb] = this.pad, W = Math.max(10, this.c.w - pl - pr), H = Math.max(10, this.c.h - pt - pb);
    let [x0, x1, y0, y1] = this.r;
    if (this.equal) {
      const s = Math.min(W / (x1 - x0), H / (y1 - y0)), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      x0 = cx - W / s / 2; x1 = cx + W / s / 2; y0 = cy - H / s / 2; y1 = cy + H / s / 2;
    }
    Object.assign(this, { x0, x1, y0, y1, W, H, ox: pl, oy: pt, sx: W / (x1 - x0), sy: H / (y1 - y0) });
  }
  X(x) { return this.ox + (x - this.x0) * this.sx; }
  Y(y) { return this.oy + (this.y1 - y) * this.sy; }
  P(x, y) { return [this.X(x), this.Y(y)]; }
  ix(px) { return this.x0 + (px - this.ox) / this.sx; }
  iy(py) { return this.y1 - (py - this.oy) / this.sy; }
  begin(o = {}) {
    this.fit(); const { c } = this, g = c.g; c.clear();
    if (o.grid !== false) this.grid(o);
    return g;
  }
  grid(o = {}) {
    const g = this.c.g, { x0, x1, y0, y1 } = this;
    const sx = o.xstep || (o.piX ? PI / 2 * Math.max(1, Math.round(niceStep(80 / this.sx) / (PI / 2))) : niceStep(80 / this.sx));
    const sy = o.ystep || niceStep(60 / this.sy);
    g.lineWidth = 1;
    for (let k = Math.ceil(x0 / sx * 5); k <= x1 / sx * 5; k++) { const x = Math.round(this.X(k * sx / 5)) + .5; g.strokeStyle = k % 5 ? T.grid : T.grid2; g.beginPath(); g.moveTo(x, this.oy); g.lineTo(x, this.oy + this.H); g.stroke(); }
    for (let k = Math.ceil(y0 / sy * 5); k <= y1 / sy * 5; k++) { const y = Math.round(this.Y(k * sy / 5)) + .5; g.strokeStyle = k % 5 ? T.grid : T.grid2; g.beginPath(); g.moveTo(this.ox, y); g.lineTo(this.ox + this.W, y); g.stroke(); }
    if (o.axes === false) return;
    const ax = clamp(this.Y(0), this.oy, this.oy + this.H), ay = clamp(this.X(0), this.ox, this.ox + this.W);
    D.arrow(g, this.ox, ax, this.ox + this.W, ax, T.axis, 1.2, 7);
    D.arrow(g, ay, this.oy + this.H, ay, this.oy, T.axis, 1.2, 7);
    D.text(g, o.xl || 'x', this.ox + this.W - 4, ax - 10, T.muted, { align: 'right', size: 12 });
    D.text(g, o.yl || 'y', ay + 8, this.oy + 8, T.muted, { size: 12 });
    if (o.ticks === false) return;
    for (let k = Math.ceil(x0 / sx); k <= x1 / sx; k++) {
      if (!k) continue; const x = this.X(k * sx);
      const lab = o.piX ? piLabel(k * sx) : fmt(k * sx, 3);
      D.line(g, x, ax - 3, x, ax + 3, T.axis, 1); D.text(g, lab, x, ax + 12, T.muted, { align: 'center', size: 10.5, mono: !o.piX });
    }
    for (let k = Math.ceil(y0 / sy); k <= y1 / sy; k++) {
      if (!k) continue; const y = this.Y(k * sy);
      D.line(g, ay - 3, y, ay + 3, y, T.axis, 1); D.text(g, fmt(k * sy, 3), ay - 6, y, T.muted, { align: 'right', size: 10.5, mono: true });
    }
    D.text(g, 'O', ay - 5, ax + 10, T.muted, { align: 'right', size: 11 });
  }
  plot(f, color, w = 2, dash) {
    const g = this.c.g; g.strokeStyle = color; g.lineWidth = w; g.setLineDash(dash || []); g.beginPath();
    let pen = false, py = 0;
    for (let px = this.ox; px <= this.ox + this.W; px += 1) {
      let y; try { y = f(this.ix(px)); } catch (e) { y = NaN; }
      const sy = this.Y(y);
      if (!isFinite(sy) || Math.abs(sy) > 1e5) { pen = false; continue; }
      if (pen && Math.abs(sy - py) > this.H * 1.5) pen = false;
      pen ? g.lineTo(px, sy) : g.moveTo(px, sy); pen = true; py = sy;
    }
    g.stroke(); g.setLineDash([]);
  }
  curve(fx, fy, t0, t1, n, color, w = 2, dash) { // 参数曲线
    const g = this.c.g; g.strokeStyle = color; g.lineWidth = w; g.setLineDash(dash || []); g.beginPath();
    let pen = false;
    for (let i = 0; i <= n; i++) {
      const t = t0 + (t1 - t0) * i / n, x = this.X(fx(t)), y = this.Y(fy(t));
      if (!isFinite(x) || !isFinite(y) || Math.abs(x) > 1e5 || Math.abs(y) > 1e5) { pen = false; continue; }
      pen ? g.lineTo(x, y) : g.moveTo(x, y); pen = true;
    }
    g.stroke(); g.setLineDash([]);
  }
  seg(x1, y1, x2, y2, c, w, dash) { D.line(this.c.g, this.X(x1), this.Y(y1), this.X(x2), this.Y(y2), c, w, dash); }
  vec(x1, y1, x2, y2, c, w = 2.2) { D.arrow(this.c.g, this.X(x1), this.Y(y1), this.X(x2), this.Y(y2), c, w, 10); }
  dot(x, y, c, r = 4.5, ring) { D.circle(this.c.g, this.X(x), this.Y(y), r, c, ring ? T.stage : null, 2); }
  label(s, x, y, c, o = {}) { D.text(this.c.g, s, this.X(x) + (o.dx ?? 6), this.Y(y) + (o.dy ?? -10), c, o); }
}
function piLabel(v) {
  const k = Math.round(v / (PI / 2));
  if (!k) return '0';
  const n = k % 2 === 0 ? k / 2 : k, d = k % 2 === 0 ? '' : '/2';
  const s = n === 1 ? 'π' : n === -1 ? '-π' : n + 'π';
  return s + d;
}

/* ================= 三维向量与相机（正交+轻透视） ================= */
const v3 = { sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], len: a => Math.hypot(...a), add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul: (a, k) => [a[0] * k, a[1] * k, a[2] * k] };
class Cam3 {
  constructor(o = {}) { this.yaw = o.yaw ?? -0.6; this.pitch = o.pitch ?? 0.35; this.scale = o.scale ?? 1; this.persp = o.persp ?? 0.08; }
  rot(p) {
    const cy = Math.cos(this.yaw), sy = Math.sin(this.yaw), cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    const x = p[0] * cy + p[2] * sy, z = -p[0] * sy + p[2] * cy, y = p[1];
    return [x, y * cp - z * sp, y * sp + z * cp];
  }
  proj(p, c, s) {
    const [x, y, z] = this.rot(p), f = 1 / (1 - z * this.persp);
    return [c.w / 2 + x * s * this.scale * f, c.h / 2 - y * s * this.scale * f, z, f];
  }
}

/* ================= 表达式解析（安全，不执行任意代码） ================= */
const MF = {
  sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan,
  arcsin: Math.asin, arccos: Math.acos, arctan: Math.atan, sqrt: Math.sqrt, abs: Math.abs, exp: Math.exp,
  ln: Math.log, lg: Math.log10, log: (a, b) => b === undefined ? Math.log10(a) : Math.log(b) / Math.log(a),
  floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign, max: Math.max, min: Math.min,
  pow: Math.pow, cbrt: Math.cbrt, cot: x => 1 / Math.tan(x), sec: x => 1 / Math.cos(x), csc: x => 1 / Math.sin(x),
  fact: n => { if (n < 0 || n % 1) return NaN; let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
};
const MCONST = { pi: 'Math.PI', e: 'Math.E' };
function compileExpr(src, vars = ['x']) {
  let s = String(src).trim().replace(/π/g, 'pi').replace(/[×·]/g, '*').replace(/÷/g, '/').replace(/（/g, '(').replace(/）/g, ')').replace(/，/g, ',').replace(/²/g, '^2').replace(/³/g, '^3').replace(/√/g, 'sqrt');
  s = s.replace(/^\s*(y|f\s*\(\s*x\s*\)|g\s*\(\s*x\s*\)|h\s*\(\s*x\s*\))\s*=/, '');
  if (!s.trim()) throw new Error('表达式为空');
  const names = [...Object.keys(MF), ...Object.keys(MCONST), ...vars].sort((a, b) => b.length - a.length);
  const toks = [], re = /\s*(?:(\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)|([a-zA-Z_]+)|(.))/y;
  let m;
  while (re.lastIndex < s.length && (m = re.exec(s))) {
    if (m[1]) toks.push({ t: 'n', v: m[1] });
    else if (m[2]) { // 把 "ax"、"sinx" 拆成已知名字
      let w = m[2];
      while (w) {
        const hit = names.find(n => w.startsWith(n));
        if (!hit) throw new Error(`不认识的符号「${w}」`);
        toks.push(MF[hit] ? { t: 'f', v: hit } : { t: 'v', v: hit }); w = w.slice(hit.length);
      }
    } else if (m[3].trim()) {
      if (!'+-*/^(),!|'.includes(m[3])) throw new Error(`不支持的字符「${m[3]}」`);
      toks.push({ t: 'o', v: m[3] });
    }
  }
  let i = 0; const peek = () => toks[i], eat = v => { if (toks[i] && toks[i].v === v) { i++; return true; } return false; };
  const startsPrimary = t => t && (t.t === 'n' || t.t === 'v' || t.t === 'f' || t.v === '(');
  function expr() { let a = term(); for (; ;) { if (eat('+')) a = `(${a}+${term()})`; else if (eat('-')) a = `(${a}-${term()})`; else return a; } }
  function term() {
    let a = unary();
    for (; ;) {
      if (eat('*')) a = `(${a}*${unary()})`; else if (eat('/')) a = `(${a}/${unary()})`;
      else if (startsPrimary(peek())) a = `(${a}*${unary()})`; else return a;
    }
  }
  function unary() { if (eat('-')) return `(-${unary()})`; if (eat('+')) return unary(); return power(); }
  function power() { const b = postfix(); if (eat('^')) return `Math.pow(${b},${unary()})`; return b; }
  function postfix() { let a = primary(); while (eat('!')) a = `F.fact(${a})`; return a; }
  function primary() {
    const t = toks[i++];
    if (!t) throw new Error('表达式不完整');
    if (t.t === 'n') return `(${t.v})`;
    if (t.t === 'v') return MCONST[t.v] || t.v;
    if (t.t === 'f') {
      if (eat('(')) { const args = [expr()]; while (eat(',')) args.push(expr()); if (!eat(')')) throw new Error('缺少右括号'); return `F.${t.v}(${args.join(',')})`; }
      return `F.${t.v}(${power()})`;
    }
    if (t.v === '(') { const a = expr(); if (!eat(')')) throw new Error('缺少右括号'); return a; }
    if (t.v === '|') { const a = expr(); if (!eat('|')) throw new Error('缺少绝对值右竖线'); return `Math.abs(${a})`; }
    throw new Error(`此处不能出现「${t.v}」`);
  }
  const code = expr();
  if (i < toks.length) throw new Error(`多余的「${toks[i].v}」`);
  return new Function('F', `return function(${vars.join(',')}){return ${code};}`)(MF);
}

/* ================= 实验上下文（每次打开实验新建） ================= */
class Ctx {
  constructor(stage, panel) {
    this.stage = stage; this.panel = panel; this.box = null; this.disp = []; this.drawFn = null; this._q = 0;
    this.ctrls = []; this._gt = '';
  }
  // 控件登记：供「题目导入」按名称读取和设置
  reg(kind, label, o) {
    let name = (label || this._gt || kind).replace(/<[^>]+>/g, '').trim();
    if (this.ctrls.some(c => c.name === name)) { let k = 2; while (this.ctrls.some(c => c.name === name + ' #' + k)) k++; name += ' #' + k; }
    const c = { kind, name, group: this._gt, ...o }; this.ctrls.push(c); return c;
  }
  canvas() {
    const cv = el('canvas'); this.stage.appendChild(cv);
    const g = cv.getContext('2d'), c = { cv, g, w: 0, h: 0 };
    const fit = () => {
      const r = this.stage.getBoundingClientRect(), d = window.devicePixelRatio || 1;
      c.w = Math.max(10, r.width); c.h = Math.max(10, r.height);
      cv.width = Math.round(c.w * d); cv.height = Math.round(c.h * d);
      cv.style.width = c.w + 'px'; cv.style.height = c.h + 'px'; g.setTransform(d, 0, 0, d, 0, 0);
    };
    fit();
    const ro = new ResizeObserver(() => { fit(); this.draw(); }); ro.observe(this.stage);
    this.disp.push(() => ro.disconnect());
    c.clear = () => { g.setTransform(window.devicePixelRatio || 1, 0, 0, window.devicePixelRatio || 1, 0, 0); g.fillStyle = T.stage; g.fillRect(0, 0, c.w, c.h); };
    return c;
  }
  tall() { this.stage.classList.add('tall'); }
  overlay(html) { const o = el('div', 'ov', html); this.stage.appendChild(o); return o; }
  onDraw(fn) { this.drawFn = fn; }
  draw() { if (!this.drawFn || this._q) return; this._q = requestAnimationFrame(() => { this._q = 0; this.drawFn && this.drawFn(); }); }
  loop(fn, autoplay = true) {
    let last = performance.now(), id, run = autoplay, dead = false;
    const step = t => { if (dead) return; const dt = clamp((t - last) / 1000, 0, 0.05); last = t; if (run) fn(dt); id = requestAnimationFrame(step); };
    id = requestAnimationFrame(step);
    const o = {
      get running() { return run; },
      pause() { run = false; }, play() { run = true; last = performance.now(); },
      toggle() { run ? o.pause() : o.play(); return run; }
    };
    this.disp.push(() => { dead = true; cancelAnimationFrame(id); });
    return o;
  }
  every(ms, fn) { const id = setInterval(fn, ms); this.disp.push(() => clearInterval(id)); return id; }
  dispose() { this.disp.forEach(f => { try { f(); } catch (e) { } }); this.disp = []; this.drawFn = null; cancelAnimationFrame(this._q); }

  /* ---- 控件 ---- */
  group(title) { const g = el('div', 'grp'); if (title) g.appendChild(el('h4', '', title)); this.panel.appendChild(g); this.box = g; this._gt = title || ''; return g; }
  _box() { return this.box || this.group(); }
  slider(label, min, max, step, value, cb, unit = '', digits) {
    const lab = el('label', 'sl'), sp = el('span', '', label), out = el('output'), inp = el('input');
    inp.type = 'range'; inp.min = min; inp.max = max; inp.step = step; inp.value = value; inp.id = 'sl-' + (++Ctx.uid);
    const dg = digits ?? Math.max(0, Math.min(4, -Math.floor(Math.log10(step) + 1e-9)));
    const s = { v: +value };
    const show = () => {
      out.innerHTML = (typeof unit === 'function' ? unit(s.v) : fmt(s.v, dg) + (unit ? ' ' + unit : ''));
      inp.style.setProperty('--p', ((s.v - inp.min) / ((inp.max - inp.min) || 1) * 100).toFixed(1) + '%'); // 已填充部分
    };
    inp.oninput = () => { s.v = +inp.value; show(); cb ? cb(s.v) : this.draw(); };
    s.set = (v, silent) => { s.v = clamp(+v, +min, +max); inp.value = s.v; show(); if (!silent) cb ? cb(s.v) : this.draw(); };
    s.setRange = (a, b) => { inp.min = min = a; inp.max = max = b; s.set(clamp(s.v, a, b), true); show(); };
    s.el = lab; show(); lab.append(sp, out, inp); this._box().appendChild(lab);
    this.reg('slider', label, { min: +min, max: +max, step: +step, unit: typeof unit === 'string' ? unit : '', get: () => s.v, set: v => s.set(+v), el: lab, minF: () => +inp.min, maxF: () => +inp.max });
    return s;
  }
  params(spec, cb) {
    const o = {};
    for (const k in spec) {
      const [label, min, max, step, val, unit, dg] = spec[k];
      const s = this.slider(label, min, max, step, val, v => cb ? cb(k, v) : this.draw(), unit, dg);
      Object.defineProperty(o, k, { get: () => s.v, set: v => s.set(v), enumerable: true });
      o['$' + k] = s;
    }
    return o;
  }
  select(label, opts, value, cb) {
    const f = el('label', 'fld'), sel = el('select'); sel.id = 'se-' + (++Ctx.uid);
    opts.forEach(o => { const [v, t] = Array.isArray(o) ? o : [o, o]; const op = el('option', '', t); op.value = v; sel.appendChild(op); });
    sel.value = value; if (label) f.appendChild(el('span', '', label)); f.appendChild(sel); this._box().appendChild(f);
    const s = { get v() { return sel.value; }, set: v => { sel.value = v; cb ? cb(sel.value) : this.draw(); }, el: sel };
    sel.onchange = () => cb ? cb(sel.value) : this.draw();
    this.reg('select', label, { options: () => [...sel.options].map(o => ({ value: o.value, text: o.textContent })), get: () => sel.value, set: v => s.set(v), el: f });
    return s;
  }
  input(label, value, cb, o = {}) {
    const f = el('label', 'fld'), inp = el(o.area ? 'textarea' : 'input'), msg = el('div', 'msg');
    if (!o.area) inp.type = o.type || 'text'; else inp.rows = o.rows || 3;
    inp.id = 'in-' + (++Ctx.uid); inp.value = value; inp.spellcheck = false; if (o.ph) inp.placeholder = o.ph;
    if (label) f.appendChild(el('span', '', label)); f.append(inp, msg); this._box().appendChild(f);
    const s = { get v() { return inp.value; }, set(v) { inp.value = v; run(); }, err(m) { msg.textContent = m || ''; }, el: inp };
    let t; const run = () => { clearTimeout(t); t = setTimeout(() => cb(inp.value, s), 120); };
    inp.addEventListener('input', run);
    this.reg('text', label, { get: () => inp.value, set: v => s.set(String(v)), el: f });
    return s;
  }
  button(label, cb, pri) {
    let row = this._box().lastElementChild;
    if (!row || !row.classList.contains('row')) { row = el('div', 'row'); this._box().appendChild(row); }
    const b = el('button', 'btn' + (pri ? ' pri' : ''), label); b.type = 'button'; b.onclick = () => cb(b); row.appendChild(b);
    this.reg('button', label, { press: () => b.click(), el: b }); return b;
  }
  toggle(label, on, cb) { // 按钮式开关
    const b = this.button(label, () => { s.v = !s.v; b.setAttribute('aria-pressed', s.v); cb ? cb(s.v) : this.draw(); });
    const s = { v: !!on, el: b, set(v) { s.v = v; b.setAttribute('aria-pressed', v); } }; b.setAttribute('aria-pressed', s.v); return s;
  }
  seg(label, opts, value, cb) { // 单选按钮组
    if (label) this._box().appendChild(el('div', 'note', label));
    const row = el('div', 'row'); this._box().appendChild(row);
    const s = { v: value, btns: {} };
    opts.forEach(o => {
      const [v, t] = Array.isArray(o) ? o : [o, o];
      const b = el('button', 'btn', t); b.type = 'button'; s.btns[v] = b;
      b.onclick = () => { s.set(v); }; row.appendChild(b);
    });
    s.set = (v, silent) => { s.v = v; for (const k in s.btns) s.btns[k].setAttribute('aria-pressed', k == v); if (!silent) cb ? cb(v) : this.draw(); };
    s.set(value, true);
    this.reg('choice', label, { options: () => opts.map(o => Array.isArray(o) ? { value: o[0], text: s.btns[o[0]].textContent } : { value: o, text: o }), get: () => s.v, set: v => s.set(v), el: row });
    return s;
  }
  check(label, value, cb) {
    const l = el('label', 'ck'), inp = el('input'); inp.type = 'checkbox'; inp.checked = value; inp.id = 'ck-' + (++Ctx.uid);
    l.append(inp, document.createTextNode(label)); this._box().appendChild(l);
    const s = { get v() { return inp.checked; }, set(v) { inp.checked = v; } };
    inp.onchange = () => cb ? cb(inp.checked) : this.draw();
    this.reg('check', label, { get: () => inp.checked, set: v => { inp.checked = v === true || v === 'true' || v === 1 || v === '是'; inp.onchange(); }, el: l });
    return s;
  }
  out() {
    const o = el('div', 'out'); this._box().appendChild(o);
    return { el: o, set(rows) { o.innerHTML = typeof rows === 'string' ? rows : rows.map(r => r == null ? '' : Array.isArray(r) ? `<div class="kv"><span>${r[0]}</span><b>${r[1]}</b></div>` : r).join(''); } };
  }
  note(html) { const n = el('div', 'note', html); this._box().appendChild(n); return n; }
  legend(items) { const n = el('div', 'legend', items.map(([c, t]) => `<span><i style="background:${c}"></i>${t}</span>`).join('')); this._box().appendChild(n); return n; }

  /* ---- 交互 ---- */
  // hit(x,y) 返回被拖对象；drag(obj,x,y,dx,dy)；无命中时若给 view 则平移
  interact(c, o = {}) {
    const cv = c.cv; cv.style.touchAction = 'none';
    let cur = null, last = null, moved = false;
    const pos = e => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    cv.addEventListener('pointerdown', e => {
      const [x, y] = pos(e); cur = o.hit ? o.hit(x, y) : null; last = [x, y]; moved = false;
      if (!cur && o.view) cur = '__pan'; if (!cur && !o.click) return;
      cv.setPointerCapture(e.pointerId); o.down && o.down(x, y, cur);
    });
    cv.addEventListener('pointermove', e => {
      const [x, y] = pos(e);
      if (!last) { if (o.hover) o.hover(x, y); if (o.hit) cv.style.cursor = o.hit(x, y) ? 'grab' : (o.view ? 'move' : 'default'); return; }
      const dx = x - last[0], dy = y - last[1]; if (Math.abs(dx) + Math.abs(dy) > 1) moved = true; last = [x, y];
      if (cur === '__pan') { const v = o.view, kx = dx / v.sx, ky = dy / v.sy; v.r[0] -= kx; v.r[1] -= kx; v.r[2] += ky; v.r[3] += ky; this.draw(); o.pan && o.pan(); }
      else if (cur) { o.drag && o.drag(cur, x, y, dx, dy); this.draw(); }
    });
    const up = e => { if (!last) return; const [x, y] = pos(e); if (!moved && o.click) o.click(x, y, cur); o.up && o.up(cur); cur = null; last = null; this.draw(); };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    if (o.view) {
      cv.addEventListener('wheel', e => {
        e.preventDefault(); const v = o.view, [x, y] = pos(e), wx = v.ix(x), wy = v.iy(y), k = Math.exp(e.deltaY * 0.0012);
        v.r = [wx + (v.r[0] - wx) * k, wx + (v.r[1] - wx) * k, wy + (v.r[2] - wy) * k, wy + (v.r[3] - wy) * k]; this.draw(); o.pan && o.pan();
      }, { passive: false });
      cv.addEventListener('dblclick', () => { o.view.reset(); this.draw(); o.pan && o.pan(); });
    }
  }
  orbit(c, cam) {
    const cv = c.cv; cv.style.touchAction = 'none'; cv.style.cursor = 'grab'; let last = null;
    cv.addEventListener('pointerdown', e => { last = [e.clientX, e.clientY]; cv.setPointerCapture(e.pointerId); });
    cv.addEventListener('pointermove', e => {
      if (!last) return; cam.yaw += (e.clientX - last[0]) * 0.01; cam.pitch = clamp(cam.pitch + (e.clientY - last[1]) * 0.01, -1.5, 1.5);
      last = [e.clientX, e.clientY]; this.draw();
    });
    const up = () => last = null; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', e => { e.preventDefault(); cam.scale = clamp(cam.scale * Math.exp(-e.deltaY * 0.001), 0.3, 4); this.draw(); }, { passive: false });
  }
}
Ctx.uid = 0;

/* ================= 实验注册表 ================= */
const Lab = {
  S: {
    math: { name: '数学', books: ['必修第一册', '必修第二册', '选择性必修第一册', '选择性必修第二册', '选择性必修第三册'] },
    phys: { name: '物理', books: ['必修第一册', '必修第二册', '必修第三册', '选择性必修第一册', '选择性必修第二册', '选择性必修第三册'] },
    chem: { name: '化学', books: ['必修第一册', '必修第二册', '选择性必修1 化学反应原理', '选择性必修2 物质结构与性质', '选择性必修3 有机化学基础'] },
    bio: { name: '生物', books: ['必修1 分子与细胞', '必修2 遗传与进化', '选择性必修1 稳态与调节', '选择性必修2 生物与环境', '选择性必修3 生物技术与工程'] }
  },
  list: [], byId: {},
  reg(e) { this.list.push(e); this.byId[e.id] = e; }
};

/* ================= 应用外壳 ================= */
const App = {
  subj: 'math', cur: null, ctx: null,
  init() {
    try { const t = localStorage.getItem('lab-theme'); if (t) document.documentElement.dataset.theme = t; } catch (e) { }
    document.body.dataset.subj = this.subj; readTheme();
    document.querySelectorAll('.tab').forEach(b => b.onclick = () => { this.setSubj(b.dataset.s); location.hash = ''; this.route(); });
    document.getElementById('home').onclick = e => { e.preventDefault(); location.hash = ''; };
    document.getElementById('theme').onclick = () => {
      const next = isDark() ? 'light' : 'dark'; document.documentElement.dataset.theme = next;
      try { localStorage.setItem('lab-theme', next); } catch (e) { }
      readTheme(); this.ctx && this.ctx.draw();
    };
    document.getElementById('menu').onclick = () => document.body.classList.toggle('nav-open');
    const q = document.getElementById('q'); q.oninput = () => this.side(q.value.trim());
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { readTheme(); this.ctx && this.ctx.draw(); });
    addEventListener('hashchange', () => this.route());
    this.route();
  },
  setSubj(s) {
    this.subj = s; document.body.dataset.subj = s; readTheme();
    document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-current', b.dataset.s === s));
    this.side(document.getElementById('q').value.trim());
  },
  side(q) {
    const nav = document.getElementById('side'); nav.innerHTML = '';
    const S = Lab.S[this.subj];
    const items = q ? Lab.list.filter(e => (e.title + e.unit + (e.kw || '') + Lab.S[e.subj].name).includes(q)) : Lab.list.filter(e => e.subj === this.subj);
    if (q) {
      nav.appendChild(el('h5', '', `搜索「${q}」· ${items.length} 项`));
      items.forEach(e => nav.appendChild(this.link(e, Lab.S[e.subj].name + ' · ' + e.unit)));
      return;
    }
    S.books.forEach((b, i) => {
      const es = items.filter(e => e.book === i); if (!es.length) return;
      nav.appendChild(el('h5', '', b));
      es.forEach(e => nav.appendChild(this.link(e, e.unit)));
    });
  },
  link(e, sub) {
    const a = el('a', '', `${e.title}<small>${sub}</small>`); a.href = '#' + e.id;
    if (this.cur && this.cur.id === e.id) a.setAttribute('aria-current', 'true');
    a.onclick = () => document.body.classList.remove('nav-open');
    return a;
  },
  route() {
    const id = location.hash.slice(1), e = Lab.byId[id];
    if (this.ctx) { this.ctx.dispose(); this.ctx = null; }
    this.cur = e || null;
    if (e) { if (e.subj !== this.subj) this.setSubj(e.subj); else this.side(document.getElementById('q').value.trim()); this.open(e); }
    else { this.setSubj(this.subj); this.homePage(); }
    document.getElementById('view').scrollTop = 0;
  },
  homePage() {
    const v = document.getElementById('view'); v.innerHTML = '';
    const counts = Object.keys(Lab.S).map(s => Lab.list.filter(e => e.subj === s).length);
    const hero = el('div', 'hero', `<div><h1>格物 · 高中理科自由实验台</h1>
      <p>依照《普通高中课程标准（2017 年版 2020 年修订）》数学、物理、化学、生物四科的必修与选择性必修模块组织。每个实验都可以自由调参、拖拽和重复，右侧给出实时测量值，下方附原理公式与探究建议。</p></div>
      <div class="stats">${Object.keys(Lab.S).map((s, i) => `<div><b style="color:var(--${s})">${counts[i]}</b><span>${Lab.S[s].name}实验</span></div>`).join('')}</div>`);
    v.appendChild(hero);
    for (const s of Object.keys(Lab.S)) {
      const sec = el('section', 'subj'); sec.style.setProperty('--sc', `var(--${s})`);
      sec.appendChild(el('h2', '', `${Lab.S[s].name}<small>${Lab.list.filter(e => e.subj === s).length} 个实验 · 按教材册次排列</small>`));
      const grid = el('div', 'books');
      Lab.S[s].books.forEach((b, i) => {
        const es = Lab.list.filter(e => e.subj === s && e.book === i); if (!es.length) return;
        const card = el('div', 'book', `<h6>${b}</h6>`);
        es.forEach(e => { const a = el('a', '', `${e.title}<span>${e.unit}</span>`); a.href = '#' + e.id; card.appendChild(a); });
        grid.appendChild(card);
      });
      sec.appendChild(grid); v.appendChild(sec);
    }
  },
  open(e) {
    const v = document.getElementById('view'); v.innerHTML = '';
    const head = el('div', 'ehead', `<h1>${e.title}</h1><span class="chip s">${Lab.S[e.subj].name} · ${Lab.S[e.subj].books[e.book]}</span><span class="chip">${e.unit}</span>`);
    const body = el('div', 'ebody'), stage = el('div', 'stage'), panel = el('div', 'panel');
    body.append(stage, panel); v.append(head, body);
    const info = el('div', 'info');
    info.appendChild(el('section', '', `<h3>原理与公式</h3>${e.info || ''}`));
    if (e.tasks) info.appendChild(el('section', '', `<h3>探究建议</h3><ol>${e.tasks.map(t => `<li>${t}</li>`).join('')}</ol>`));
    v.appendChild(info);
    const L = new Ctx(stage, panel); this.ctx = L;
    try { e.init(L); L.draw(); }
    catch (err) { console.error(err); stage.appendChild(el('div', 'err', '实验加载出错：' + err.message)); }
  }
};
