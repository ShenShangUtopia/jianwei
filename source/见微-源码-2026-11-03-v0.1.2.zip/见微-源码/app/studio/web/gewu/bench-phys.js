'use strict';
/* ================= 自由工作台 · 力学与电磁场 =================
   单位：m、kg、s、C、N/C、T；点电荷 Q 以 nC 计（k = 9×10⁹ N·m²/C²）。
   每帧分成若干子步：先算力（重力、电场力、库仑力、弹簧弹力、空气阻力），
   半步加速 → 在磁场中按洛伦兹力精确旋转速度 → 再半步加速（Boris 方法）→ 位移，
   最后处理绳、杆约束，与地面、斜面、挡板、点电荷的碰撞（含摩擦）以及物体之间的碰撞。 */
(() => {
const KQ = 9; // Q 以 nC 计：kQ = 9×10⁹ × Q×10⁻⁹ = 9Q
const VS = .3; // 速度箭头：每 1 m/s 画 0.3 m
const ART = `<svg viewBox="0 0 160 110"><rect x="0" y="92" width="160" height="18" fill="currentColor" opacity=".08"/>
  <rect x="78" y="10" width="72" height="62" fill="#16968a" opacity=".1" stroke="#16968a" stroke-dasharray="4 3"/>
  ${[0, 1, 2].map(i => [0, 1, 2].map(j => `<circle cx="${92 + i * 22}" cy="${22 + j * 19}" r="5" fill="none" stroke="#16968a" stroke-width="1.4"/><circle cx="${92 + i * 22}" cy="${22 + j * 19}" r="1.5" fill="#16968a"/>`).join('')).join('')}
  <path d="M14 30 Q 50 30 66 60 T 100 92" fill="none" stroke="currentColor" stroke-dasharray="3 4" stroke-width="1.6"/>
  ${[0, 1, 2, 3, 4].map(i => `<circle cx="${14 + i * 13}" cy="${30 + i * i * 2.6}" r="4" fill="#d6522b" opacity="${.3 + i * .15}"/>`).join('')}
  <path d="M14 92 L58 92 L58 66 Z" fill="currentColor" opacity=".18"/><rect x="30" y="74" width="12" height="12" transform="rotate(-31 36 80)" fill="#2c6fd1"/></svg>`;

Bench.reg({
  id: 'phys', subj: 'phys', short: '力学与电磁', title: '力学与电磁场', sub: '物体 · 斜面 · 圆弧 · 弹簧 · 绳 · 滑轮 · 电场 · 磁场 · 点电荷 · 星球',
  desc: '把小球、木块、斜面、圆弧轨道、传送带、弹簧、细绳、定滑轮、匀强电场、匀强（圆形）磁场、点电荷和星球放到场景里，设定初速度后运行，看轨迹、频闪照片、受力分析和 v–t 图。',
  art: ART,
  init(B) {
    const L = B.L, c = L.canvas();
    const view = new View(c, -1, 23, -1.6, 13, { equal: true });
    const env = { grav: true, g: 9.8, ground: true, gmu: 0, air: 0 };
    const show = { trail: true, vel: true, force: false, strobe: false, lines: true, graph: 'v' };
    let objs = [], sel = null, uid = 0, run = false, simT = 0, speed = 1, snap = null, strobeT = 0, held = null, ui = {};
    const cnt = {};
    const nm = k => (cnt[k] = (cnt[k] || 0) + 1, `${k} ${cnt[k]}`);

    /* ---- 对象 ---- */
    const mk = {
      body: o => ({ kind: 'body', id: ++uid, shape: 'ball', name: '', x: 0, y: 0, vx: 0, vy: 0, m: 1, r: .4, q: 0, e: .6, ci: uid % 6, ang: 0, ...o }),
      ramp: o => ({ kind: 'ramp', id: ++uid, name: nm('斜面'), x: 3, ang: 30, len: 8, mu: .2, dir: 1, ...o }),
      wall: o => ({ kind: 'wall', id: ++uid, name: nm('挡板'), x1: 0, y1: 0, x2: 0, y2: 3, mu: 0, ...o }),
      link: o => ({ kind: 'link', id: ++uid, mode: 'spring', ax: 0, ay: 0, a: null, b: null, k: 40, L0: 3, len: 3, damp: 0, ...o }),
      ef: o => ({ kind: 'ef', id: ++uid, name: nm('匀强电场'), x: 5, y: 2, w: 10, h: 7, E: 10, dir: 270, ...o }),
      bf: o => ({ kind: 'bf', id: ++uid, name: nm('匀强磁场'), x: 5, y: 2, w: 10, h: 7, B: 1, ...o }),
      pc: o => ({ kind: 'pc', id: ++uid, name: nm('点电荷'), x: 11, y: 6, Q: 10, ...o }),
      arc: o => ({ kind: 'arc', id: ++uid, name: nm('圆弧轨道'), x: 11, y: 3, R: 3, a0: -90, a1: 90, mu: 0, ...o }),
      pulley: o => ({ kind: 'pulley', id: ++uid, name: nm('定滑轮'), x: 11, y: 8, a: null, b: null, len: 6, ...o }),
      planet: o => ({ kind: 'planet', id: ++uid, name: nm('星球'), x: 11, y: 6, GM: 400, R: 1.5, ...o })
    };
    const ball = o => mk.body({ name: nm(o && o.q ? '带电小球' : '小球'), ...o });
    const block = o => mk.body({ shape: 'block', name: nm('木块'), r: .5, e: 0, ...o });
    const LN = { spring: '弹簧', rope: '细绳', rod: '轻杆' };
    const byId = id => objs.find(o => o.id === id);
    const rampPts = r => { const a = r.ang * PI / 180; return { fx: r.x, tx: r.x + r.dir * r.len * Math.cos(a), ty: r.len * Math.sin(a) }; };
    const inside = (o, x, y) => o.circ ? Math.hypot(x - o.x - o.w / 2, y - o.y - o.h / 2) <= Math.min(o.w, o.h) / 2 : x >= o.x && x <= o.x + o.w && y >= o.y && y <= o.y + o.h;
    // 圆弧：角度（度，逆时针）a 是否落在 [a0, a1] 内
    const onArc = (o, a) => ((a - o.a0) % 360 + 360) % 360 <= Math.min(360, o.a1 - o.a0) + 1e-9;
    const arcEnd = (o, a) => [o.x + o.R * Math.cos(a * PI / 180), o.y + o.R * Math.sin(a * PI / 180)];
    const ends = (k, by) => { const b = by ? by[k.b] : byId(k.b), a = k.a != null ? (by ? by[k.a] : byId(k.a)) : null; return { b, a, ax: a ? a.x : k.ax, ay: a ? a.y : k.ay }; };

    /* ---- 物理 ---- */
    function fieldsAt(x, y) {
      let Ex = 0, Ey = 0, Bz = 0;
      for (const o of objs) {
        if (o.kind === 'ef' && inside(o, x, y)) { const a = o.dir * PI / 180; Ex += o.E * Math.cos(a); Ey += o.E * Math.sin(a); }
        else if (o.kind === 'bf' && inside(o, x, y)) Bz += o.B;
        else if (o.kind === 'pc') { const dx = x - o.x, dy = y - o.y, r = Math.max(.25, Math.hypot(dx, dy)), k = KQ * o.Q / r ** 3; Ex += k * dx; Ey += k * dy; }
      }
      return [Ex, Ey, Bz];
    }
    function contact(b, nx, ny, mu, sx = 0, sy = 0) { // sx、sy：接触面自身的速度（传送带）
      b.touch = [nx, ny];
      const vn = b.vx * nx + b.vy * ny; if (vn >= 0) return;
      const e = -vn > .5 ? b.e : 0, jn = -(1 + e) * vn;
      b.vx += jn * nx; b.vy += jn * ny; b.aN[0] += jn * nx * b.m; b.aN[1] += jn * ny * b.m;
      const tx = -ny, ty = nx, vt = (b.vx - sx) * tx + (b.vy - sy) * ty, jt = Math.min(Math.abs(vt), mu * jn); // 摩擦冲量不超过 μ × 法向冲量
      if (jt > 0) { const s = Math.sign(vt); b.vx -= s * jt * tx; b.vy -= s * jt * ty; b.aF[0] -= s * jt * tx * b.m; b.aF[1] -= s * jt * ty * b.m; }
    }
    function seg(b, x1, y1, x2, y2, mu, belt = 0) {
      const dx = x2 - x1, dy = y2 - y1, L2 = dx * dx + dy * dy || 1e-9, t = clamp(((b.x - x1) * dx + (b.y - y1) * dy) / L2, 0, 1);
      const px = x1 + t * dx, py = y1 + t * dy; let nx = b.x - px, ny = b.y - py; const d = Math.hypot(nx, ny);
      if (d >= b.r || d < 1e-9) return;
      nx /= d; ny /= d; b.x = px + nx * b.r; b.y = py + ny * b.r; const L1 = Math.sqrt(L2); contact(b, nx, ny, mu, belt * dx / L1, belt * dy / L1);
    }
    function step(h) {
      const bs = objs.filter(o => o.kind === 'body'), by = {}; bs.forEach(b => by[b.id] = b);
      const links = objs.filter(o => o.kind === 'link');
      const pls = objs.filter(o => o.kind === 'planet');
      for (const b of bs) {
        b.fx = 0; b.fy = env.grav ? -b.m * env.g : 0; b.fs = [0, 0]; b.fe = [0, 0]; b.fg = [0, 0]; b.bz = 0;
        for (const p of pls) { // 万有引力 F = GMm/r²，指向星球中心
          const dx = b.x - p.x, dy = b.y - p.y, r = Math.max(p.R * .5, Math.hypot(dx, dy)), k = -p.GM * b.m / r ** 3;
          b.fg[0] += k * dx; b.fg[1] += k * dy; b.fx += k * dx; b.fy += k * dy;
        }
      }
      for (const k of links) {
        if (k.mode !== 'spring') continue;
        const { b, a, ax, ay } = ends(k, by); if (!b) continue;
        const dx = b.x - ax, dy = b.y - ay, d = Math.hypot(dx, dy) || 1e-9, ux = dx / d, uy = dy / d;
        let F = -k.k * (d - k.L0);
        if (k.damp) F -= k.damp * ((b.vx - (a ? a.vx : 0)) * ux + (b.vy - (a ? a.vy : 0)) * uy);
        b.fx += F * ux; b.fy += F * uy; b.fs[0] += F * ux; b.fs[1] += F * uy;
        if (a) { a.fx -= F * ux; a.fy -= F * uy; a.fs[0] -= F * ux; a.fs[1] -= F * uy; }
      }
      for (const b of bs) {
        if (b === held) continue;
        if (b.q) { const [Ex, Ey, Bz] = fieldsAt(b.x, b.y); b.fe = [b.q * Ex, b.q * Ey]; b.fx += b.fe[0]; b.fy += b.fe[1]; b.bz = Bz; }
        if (env.air) { b.fx -= env.air * b.vx; b.fy -= env.air * b.vy; }
        const ax = b.fx / b.m, ay = b.fy / b.m;
        b.vx += ax * h / 2; b.vy += ay * h / 2;
        if (b.bz) { const th = -b.q * b.bz / b.m * h, cs = Math.cos(th), sn = Math.sin(th), vx = b.vx; b.vx = vx * cs - b.vy * sn; b.vy = vx * sn + b.vy * cs; }
        b.vx += ax * h / 2; b.vy += ay * h / 2;
        b.x += b.vx * h; b.y += b.vy * h;
      }
      for (let it = 0; it < 2; it++) for (const k of links) {
        if (k.mode === 'spring') continue;
        const { b, a, ax, ay } = ends(k, by); if (!b) continue;
        const dx = b.x - ax, dy = b.y - ay, d = Math.hypot(dx, dy) || 1e-9;
        if (k.mode === 'rope' && d <= k.len) continue;
        const ux = dx / d, uy = dy / d, err = d - k.len, wb = b === held ? 0 : 1 / b.m, wa = a && a !== held ? 1 / a.m : 0, ws = wa + wb;
        if (!ws) continue;
        b.x -= ux * err * wb / ws; b.y -= uy * err * wb / ws; if (a) { a.x += ux * err * wa / ws; a.y += uy * err * wa / ws; }
        const rv = (b.vx - (a ? a.vx : 0)) * ux + (b.vy - (a ? a.vy : 0)) * uy;
        if (k.mode === 'rod' || rv > 0) {
          const j = rv / ws; b.vx -= ux * j * wb; b.vy -= uy * j * wb; b.aT[0] -= ux * j; b.aT[1] -= uy * j;
          if (a) { a.vx += ux * j * wa; a.vy += uy * j * wa; a.aT[0] += ux * j; a.aT[1] += uy * j; }
        }
      }
      for (let it = 0; it < 2; it++) for (const p of objs) { // 定滑轮：两段绳长之和不超过总长，两侧拉力相等
        if (p.kind !== 'pulley') continue;
        const A = by[p.a], Bb = by[p.b]; if (!A || !Bb) continue;
        const d1 = Math.hypot(A.x - p.x, A.y - p.y) || 1e-9, d2 = Math.hypot(Bb.x - p.x, Bb.y - p.y) || 1e-9, err = d1 + d2 - p.len;
        if (err <= 0) continue;
        const u1 = [(A.x - p.x) / d1, (A.y - p.y) / d1], u2 = [(Bb.x - p.x) / d2, (Bb.y - p.y) / d2];
        const wa = A === held ? 0 : 1 / A.m, wb = Bb === held ? 0 : 1 / Bb.m, ws = wa + wb; if (!ws) continue;
        A.x -= u1[0] * err * wa / ws; A.y -= u1[1] * err * wa / ws; Bb.x -= u2[0] * err * wb / ws; Bb.y -= u2[1] * err * wb / ws;
        const rv = A.vx * u1[0] + A.vy * u1[1] + Bb.vx * u2[0] + Bb.vy * u2[1];
        if (rv > 0) {
          const j = rv / ws;
          A.vx -= u1[0] * j * wa; A.vy -= u1[1] * j * wa; Bb.vx -= u2[0] * j * wb; Bb.vy -= u2[1] * j * wb;
          A.aT[0] -= u1[0] * j; A.aT[1] -= u1[1] * j; Bb.aT[0] -= u2[0] * j; Bb.aT[1] -= u2[1] * j;
        }
      }
      for (const b of bs) {
        if (b === held) continue;
        b.touch = null;
        if (env.ground && b.y - b.r < 0) { b.y = b.r; contact(b, 0, 1, env.gmu); }
        for (const o of objs) {
          if (o.kind === 'ramp') { const p = rampPts(o); seg(b, p.fx, 0, p.tx, p.ty, o.mu); seg(b, p.tx, p.ty, p.tx, 0, o.mu); }
          else if (o.kind === 'wall') seg(b, o.x1, o.y1, o.x2, o.y2, o.mu, o.belt || 0);
          else if (o.kind === 'pc' || o.kind === 'planet') { const dx = b.x - o.x, dy = b.y - o.y, d = Math.hypot(dx, dy), R = b.r + (o.kind === 'pc' ? .25 : o.R); if (d < R && d > 1e-9) { b.x = o.x + dx / d * R; b.y = o.y + dy / d * R; contact(b, dx / d, dy / d, o.kind === 'planet' ? .5 : 0); } }
          else if (o.kind === 'arc') { // 圆弧轨道：物体在弧的内侧或外侧都能接触
            const dx = b.x - o.x, dy = b.y - o.y, d = Math.hypot(dx, dy);
            if (d > 1e-9 && onArc(o, Math.atan2(dy, dx) * 180 / PI)) {
              const gap = d - o.R;
              if (Math.abs(gap) < b.r) { const s = gap < 0 ? -1 : 1, nr = o.R + s * b.r; b.x = o.x + dx / d * nr; b.y = o.y + dy / d * nr; contact(b, s * dx / d, s * dy / d, o.mu); }
            } else for (const a of [o.a0, o.a1]) { // 两个端点
              const [ex, ey] = arcEnd(o, a), qx = b.x - ex, qy = b.y - ey, q = Math.hypot(qx, qy);
              if (q < b.r && q > 1e-9) { b.x = ex + qx / q * b.r; b.y = ey + qy / q * b.r; contact(b, qx / q, qy / q, o.mu); }
            }
          }
        }
      }
      for (let i = 0; i < bs.length; i++) for (let j = i + 1; j < bs.length; j++) {
        const p = bs[i], q = bs[j], dx = q.x - p.x, dy = q.y - p.y, d = Math.hypot(dx, dy), R = p.r + q.r;
        if (d >= R || d < 1e-9 || p.nc || q.nc) continue; // nc：带电粒子束，彼此不碰撞
        const nx = dx / d, ny = dy / d, wp = p === held ? 0 : 1 / p.m, wq = q === held ? 0 : 1 / q.m, ws = wp + wq; if (!ws) continue;
        const ov = R - d; p.x -= nx * ov * wp / ws; p.y -= ny * ov * wp / ws; q.x += nx * ov * wq / ws; q.y += ny * ov * wq / ws;
        const rv = (q.vx - p.vx) * nx + (q.vy - p.vy) * ny; if (rv >= 0) continue;
        const J = -(1 + Math.min(p.e, q.e)) * rv / ws;
        p.vx -= J * wp * nx; p.vy -= J * wp * ny; q.vx += J * wq * nx; q.vy += J * wq * ny;
      }
    }
    function energy(b) {
      const Ek = .5 * b.m * (b.vx * b.vx + b.vy * b.vy), Eg = env.grav ? b.m * env.g * b.y : 0;
      let Es = 0, Ee = 0;
      for (const k of objs) if (k.kind === 'link' && k.mode === 'spring' && (k.b === b.id || k.a === b.id)) { const { b: q, ax, ay } = ends(k); if (q) Es += .5 * k.k * (Math.hypot(q.x - ax, q.y - ay) - k.L0) ** 2; }
      if (b.q) for (const o of objs) if (o.kind === 'pc') Ee += KQ * o.Q * b.q / Math.max(.25, Math.hypot(b.x - o.x, b.y - o.y));
      let Ep = 0; // 引力势能（无穷远处为零）
      for (const o of objs) if (o.kind === 'planet') Ep -= o.GM * b.m / Math.max(o.R * .5, Math.hypot(b.x - o.x, b.y - o.y));
      return { Ek, Eg, Es, Ee, Ep };
    }

    /* ---- 快照、播放与编辑 ---- */
    const TRANSIENT = ['trail', 'strobe', 'hist', 'aN', 'aF', 'aT', 'N', 'F', 'Tn', 'fs', 'fe', 'fg', 'fx', 'fy', 'touch', 'bz'];
    const save = () => JSON.stringify({ objs, env }, (k, v) => TRANSIENT.includes(k) ? undefined : v);
    function clearMarks() { for (const o of objs) if (o.kind === 'body') { o.trail = []; o.strobe = []; o.hist = []; } strobeT = 0; }
    function edited() { if (!run) { simT = 0; snap = null; clearMarks(); } }
    function reset() {
      run = false;
      if (snap) { const s = JSON.parse(snap); objs = s.objs; Object.assign(env, s.env); const id = sel && sel.id; sel = id ? byId(id) || null : null; }
      simT = 0; snap = null; clearMarks(); inspect();
    }
    function toggleRun() { if (!run && !snap) snap = save(); run = !run; if (ui.play) ui.play.textContent = run ? '暂停' : '播放'; }
    function frame(sd) {
      const bs = objs.filter(o => o.kind === 'body');
      for (const b of bs) { b.aN = [0, 0]; b.aF = [0, 0]; b.aT = [0, 0]; }
      const n = Math.max(1, Math.ceil(sd / .0015)), h = sd / n;
      for (let i = 0; i < n; i++) {
        step(h); simT += h; strobeT += h;
        if (strobeT >= .1) { strobeT -= .1; for (const b of bs) { b.strobe.push([b.x, b.y, b.ang]); if (b.strobe.length > 120) b.strobe.shift(); } }
      }
      for (const b of bs) {
        b.N = [b.aN[0] / sd, b.aN[1] / sd]; b.F = [b.aF[0] / sd, b.aF[1] / sd]; b.Tn = [b.aT[0] / sd, b.aT[1] / sd];
        const tl = b.trail, lp = tl[tl.length - 1];
        if (!lp || Math.hypot(lp[0] - b.x, lp[1] - b.y) > .03) { tl.push([b.x, b.y]); if (tl.length > 2500) tl.shift(); }
        const E = energy(b); b.hist.push([simT, b.vx, b.vy, Math.hypot(b.vx, b.vy), b.x, b.y, E.Ek, E.Eg + E.Es + E.Ee + E.Ep]);
        if (b.hist.length > 5000) b.hist.shift();
      }
    }

    /* ---- 绘制 ---- */
    const P = (x, y) => [view.X(x), view.Y(y)];
    function drawFields(g) {
      for (const o of objs) {
        if (o.kind !== 'ef' && o.kind !== 'bf') continue;
        const [x0, y1] = P(o.x, o.y + o.h), w = o.w * view.sx, h = o.h * view.sy, col = o.kind === 'ef' ? T.c5 : T.c3;
        const shape = () => { g.beginPath(); if (o.circ) g.arc(x0 + w / 2, y1 + h / 2, Math.min(w, h) / 2, 0, TAU); else g.rect(x0, y1, w, h); };
        shape(); g.fillStyle = alpha(col, sel === o ? .13 : .08); g.fill();
        g.setLineDash([6, 4]); g.strokeStyle = alpha(col, sel === o ? .95 : .6); g.lineWidth = sel === o ? 2 : 1.2; shape(); g.stroke(); g.setLineDash([]);
        if (o.circ && sel === o) { g.setLineDash([2, 4]); g.strokeStyle = alpha(col, .4); g.lineWidth = 1; g.strokeRect(x0, y1, w, h); g.setLineDash([]); }
        g.save(); shape(); g.clip();
        if (o.kind === 'ef') {
          const a = o.dir * PI / 180, ux = Math.cos(a) * .35, uy = Math.sin(a) * .35, st = 1.3;
          if (o.E > 0) for (let x = o.x + st / 2; x < o.x + o.w; x += st) for (let y = o.y + st / 2; y < o.y + o.h; y += st) view.vec(x - ux, y - uy, x + ux, y + uy, alpha(col, .75), 1.4);
        } else if (o.B) {
          const rr = clamp(3 + Math.abs(o.B) * 1.6, 3, 9);
          for (let x = o.x + .5; x < o.x + o.w; x += 1) for (let y = o.y + .5; y < o.y + o.h; y += 1) {
            const [px, py] = P(x, y); D.circle(g, px, py, rr, null, alpha(col, .75), 1.3);
            if (o.B > 0) D.circle(g, px, py, 1.6, alpha(col, .9)); else { const d = rr * .62; D.line(g, px - d, py - d, px + d, py + d, alpha(col, .85), 1.3); D.line(g, px - d, py + d, px + d, py - d, alpha(col, .85), 1.3); }
          }
        }
        g.restore();
        const lab = o.kind === 'ef' ? `E = ${fmt(o.E, 1)} N/C` : `B = ${fmt(Math.abs(o.B), 2)} T ${o.B >= 0 ? '⊙ 向外' : '⊗ 向里'}`;
        if (o.kind === 'ef') D.text(g, lab, x0 + 6, y1 + 12, col, { size: 12, bold: true }); else D.text(g, lab, x0 + 6, y1 + h - 10, col, { size: 12, bold: true });
        if (sel === o) D.rect(g, x0 + w - 6, y1 - 6, 12, 12, T.stage, col, 2);
      }
    }
    let lineCache = { key: '', lines: [] };
    function fieldLines(g) {
      const pcs = objs.filter(o => o.kind === 'pc' && o.Q);
      if (!show.lines || !pcs.length) return;
      // 电场线只和电荷、电场区域、视图范围有关：不变时复用上次的结果
      const key = JSON.stringify([objs.filter(o => o.kind === 'pc' || o.kind === 'ef').map(o => [o.x, o.y, o.Q, o.E, o.dir, o.w, o.h]), view.x0 | 0, view.x1 | 0, view.y0 | 0, view.y1 | 0]);
      if (key !== lineCache.key) {
        const lines = [];
        for (const p of pcs) {
          const sg = Math.sign(p.Q), n = 12;
          for (let i = 0; i < n; i++) {
            let x = p.x + .3 * Math.cos(i / n * TAU + .13), y = p.y + .3 * Math.sin(i / n * TAU + .13);
            const pts = [[x, y]];
            for (let s = 0; s < 360; s++) {
              const [Ex, Ey] = fieldsAt(x, y), m = Math.hypot(Ex, Ey); if (m < 1e-9) break;
              x += sg * Ex / m * .07; y += sg * Ey / m * .07; pts.push([x, y]);
              if (x < view.x0 - 1 || x > view.x1 + 1 || y < view.y0 - 1 || y > view.y1 + 1) break;
              if (pcs.some(q => q !== p && Math.hypot(x - q.x, y - q.y) < .28)) break;
            }
            lines.push({ sg, pts });
          }
        }
        lineCache = { key, lines };
      }
      g.lineWidth = 1.1;
      for (const { sg, pts } of lineCache.lines) {
        {
          g.strokeStyle = alpha(sg > 0 ? T.c2 : T.c1, .38); g.beginPath();
          pts.forEach((q, k) => k ? g.lineTo(view.X(q[0]), view.Y(q[1])) : g.moveTo(view.X(q[0]), view.Y(q[1]))); g.stroke();
          const mid = pts[Math.min(pts.length - 1, 22)], nx = pts[Math.min(pts.length - 1, 23)];
          if (mid && nx && pts.length > 24) { const [a, b2] = sg > 0 ? [mid, nx] : [nx, mid]; D.arrow(g, view.X(a[0]), view.Y(a[1]), view.X(b2[0]), view.Y(b2[1]), alpha(sg > 0 ? T.c2 : T.c1, .6), 1.1, 7); }
        }
      }
    }
    function hatch(g, x1, y1, x2, y2, side = 1) { // 沿线段一侧画短斜线
      const L2 = Math.hypot(x2 - x1, y2 - y1), n = Math.max(1, Math.floor(L2 / 9)), ux = (x2 - x1) / L2, uy = (y2 - y1) / L2, nx = -uy * side, ny = ux * side;
      g.strokeStyle = alpha(T.axis, .55); g.lineWidth = 1; g.beginPath();
      for (let i = 0; i <= n; i++) { const px = x1 + ux * i * 9, py = y1 + uy * i * 9; g.moveTo(px, py); g.lineTo(px + nx * 7 - ux * 5, py + ny * 7 - uy * 5); }
      g.stroke();
    }
    function drawStatic(g) {
      if (env.ground) {
        const y = view.Y(0); g.fillStyle = alpha(T.axis, .07); g.fillRect(0, y, c.w, c.h - y);
        D.line(g, 0, y, c.w, y, T.axis, 2); hatch(g, 0, y, c.w, y, -1);
        if (env.gmu) D.text(g, `地面 μ = ${fmt(env.gmu, 2)}`, c.w - 8, y + 14, T.muted, { size: 11, align: 'right' });
      }
      for (const o of objs) {
        if (o.kind === 'ramp') {
          const p = rampPts(o), A = P(p.fx, 0), Bp = P(p.tx, p.ty), C = P(p.tx, 0);
          D.poly(g, [A, Bp, C], alpha(T.axis, sel === o ? .28 : .18), sel === o ? T.accent : T.axis, sel === o ? 2.2 : 1.6);
          const r0 = 26, a0 = o.dir > 0 ? 0 : PI, a1 = o.dir > 0 ? -o.ang * PI / 180 : PI + o.ang * PI / 180;
          g.beginPath(); g.arc(A[0], A[1], r0, Math.min(a0, a1), Math.max(a0, a1)); g.strokeStyle = T.muted; g.lineWidth = 1; g.stroke();
          D.text(g, `θ=${fmt(o.ang, 0)}°`, A[0] + o.dir * (r0 + 6), A[1] - 9, T.muted, { size: 11, align: o.dir > 0 ? 'left' : 'right' });
          if (o.mu) D.text(g, `μ=${fmt(o.mu, 2)}`, (A[0] + Bp[0]) / 2 + o.dir * 6, (A[1] + Bp[1]) / 2 + 14, T.muted, { size: 11, align: 'center' });
          if (sel === o) D.circle(g, Bp[0], Bp[1], 6, T.stage, T.accent, 2);
        } else if (o.kind === 'wall' && o.belt != null) { // 传送带：两个滚轮 + 移动的带面
          const A = P(o.x1, o.y1), Bp = P(o.x2, o.y2), L1 = Math.hypot(Bp[0] - A[0], Bp[1] - A[1]) || 1, ux = (Bp[0] - A[0]) / L1, uy = (Bp[1] - A[1]) / L1;
          const nx = uy, ny = -ux, r = .28 * view.sx, s = ny > 0 ? 1 : -1, ox = nx * r * s, oy = ny * r * s; // 指向带面下方
          const col = sel === o ? T.accent : T.axis;
          D.line(g, A[0] + 2 * ox, A[1] + 2 * oy, Bp[0] + 2 * ox, Bp[1] + 2 * oy, alpha(col, .6), 2);
          g.setLineDash([8, 6]); g.lineDashOffset = -simT * o.belt * view.sx; D.line(g, A[0], A[1], Bp[0], Bp[1], col, 3.2); g.setLineDash([]); g.lineDashOffset = 0;
          for (const [x, y] of [A, Bp]) { const cx = x + ox, cy = y + oy, a = simT * o.belt / .28; D.circle(g, cx, cy, r, alpha(T.axis, .15), col, 1.6); D.line(g, cx, cy, cx + Math.cos(-a) * r, cy + Math.sin(-a) * r, col, 1.4); }
          D.text(g, `v带 = ${fmt(o.belt, 1)} m/s${o.mu ? `  μ=${fmt(o.mu, 2)}` : ''}`, (A[0] + Bp[0]) / 2, (A[1] + Bp[1]) / 2 + 2 * oy + 14 * Math.sign(oy || 1), T.muted, { size: 11, align: 'center' });
          if (sel === o) { D.circle(g, A[0], A[1], 6, T.stage, T.accent, 2); D.circle(g, Bp[0], Bp[1], 6, T.stage, T.accent, 2); }
        } else if (o.kind === 'wall') {
          const A = P(o.x1, o.y1), Bp = P(o.x2, o.y2);
          g.lineCap = 'round'; D.line(g, A[0], A[1], Bp[0], Bp[1], sel === o ? T.accent : T.axis, 4); g.lineCap = 'butt'; hatch(g, A[0], A[1], Bp[0], Bp[1], 1);
          if (sel === o) { D.circle(g, A[0], A[1], 6, T.stage, T.accent, 2); D.circle(g, Bp[0], Bp[1], 6, T.stage, T.accent, 2); }
        }
      }
      for (const o of objs) {
        if (o.kind === 'arc') { // 圆弧轨道：外侧画短斜线
          const [cx, cy] = P(o.x, o.y), Rp = o.R * view.sx, col = sel === o ? T.accent : T.axis, span = Math.min(360, o.a1 - o.a0);
          g.beginPath(); g.arc(cx, cy, Rp, -o.a0 * PI / 180, -(o.a0 + span) * PI / 180, true); g.strokeStyle = col; g.lineWidth = 4; g.lineCap = 'round'; g.stroke(); g.lineCap = 'butt';
          g.strokeStyle = alpha(T.axis, .5); g.lineWidth = 1; g.beginPath();
          const n = Math.max(4, Math.floor(span * PI / 180 * Rp / 9));
          for (let i = 0; i <= n; i++) { const a = (o.a0 + span * i / n) * PI / 180, ux = Math.cos(a), uy = -Math.sin(a); g.moveTo(cx + ux * (Rp + 2), cy + uy * (Rp + 2)); g.lineTo(cx + ux * (Rp + 8) - uy * 4, cy + uy * (Rp + 8) + ux * 4); }
          g.stroke();
          if (o.mu) D.text(g, `μ=${fmt(o.mu, 2)}`, cx, cy, T.muted, { size: 11, align: 'center' });
          if (sel === o) { D.circle(g, cx, cy, 4, T.accent); D.text(g, `R = ${fmt(o.R, 2)} m`, cx + 8, cy - 10, T.accent, { size: 11 }); }
        } else if (o.kind === 'planet') {
          const [x, y] = P(o.x, o.y), r = o.R * view.sx;
          const gl = g.createRadialGradient(x, y, r * .9, x, y, r * 1.5); gl.addColorStop(0, alpha('#5aa0e8', .35)); gl.addColorStop(1, alpha('#5aa0e8', 0)); g.fillStyle = gl; g.fillRect(x - r * 1.6, y - r * 1.6, r * 3.2, r * 3.2);
          const gr = g.createRadialGradient(x - r * .35, y - r * .35, r * .1, x, y, r); gr.addColorStop(0, '#9fd0ff'); gr.addColorStop(.55, '#3d7fc4'); gr.addColorStop(1, '#1f4f86');
          D.circle(g, x, y, r, gr, sel === o ? T.accent : alpha(T.fg, .3), sel === o ? 2.4 : 1);
          g.save(); g.beginPath(); g.arc(x, y, r, 0, TAU); g.clip(); g.fillStyle = 'rgba(90,170,90,.55)';
          for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(x + Math.cos(i * 2.1) * r * .45, y + Math.sin(i * 1.7) * r * .4, r * .32, r * .18, i, 0, TAU); g.fill(); }
          g.restore();
          D.text(g, `GM = ${fmt(o.GM, 0)} m³/s²`, x + r + 6, y - r - 4, T.muted, { size: 11 });
        } else if (o.kind === 'pulley') {
          const [x, y] = P(o.x, o.y), col = sel === o ? T.accent : T.fg, r = Math.max(7, .3 * view.sx);
          D.line(g, x, y, x, y - r - 14, alpha(T.axis, .8), 2); D.rect(g, x - 12, y - r - 18, 24, 5, alpha(T.axis, .5));
          for (const id of [o.a, o.b]) { const q = byId(id); if (q) { const [qx, qy] = P(q.x, q.y); D.line(g, x, y, qx, qy, col, 1.4); } }
          D.circle(g, x, y, r, T.stage, col, 2); D.circle(g, x, y, 2.4, col);
        }
      }
      fieldLines(g);
      for (const o of objs) if (o.kind === 'pc') {
        const [x, y] = P(o.x, o.y), r = .25 * view.sx, col = o.Q >= 0 ? T.c2 : T.c1;
        const gl = g.createRadialGradient(x, y, 0, x, y, r * 4); gl.addColorStop(0, alpha(col, .35)); gl.addColorStop(1, alpha(col, 0)); g.fillStyle = gl; g.fillRect(x - r * 4, y - r * 4, r * 8, r * 8);
        D.circle(g, x, y, r, col, sel === o ? T.fg : null, 2);
        D.text(g, o.Q >= 0 ? '+' : '−', x, y + 1, '#fff', { size: Math.max(11, r * 1.3), align: 'center', bold: true });
        D.text(g, `${o.Q >= 0 ? '+' : ''}${fmt(o.Q, 0)} nC`, x + r + 4, y - r - 4, col, { size: 11 });
      }
      for (const k of objs) if (k.kind === 'link') {
        const { b, a, ax, ay } = ends(k); if (!b) continue;
        const A = P(ax, ay), Bp = P(b.x, b.y), col = sel === k ? T.accent : T.fg;
        if (k.mode === 'spring') D.spring(g, A[0], A[1], Bp[0], Bp[1], 12, 6, col, 1.6);
        else D.line(g, A[0], A[1], Bp[0], Bp[1], col, k.mode === 'rod' ? 4 : 1.4);
        if (!a) { D.rect(g, A[0] - 9, A[1] - 3, 18, 6, alpha(T.axis, .5)); D.circle(g, A[0], A[1], 3.5, T.stage, col, 1.6); }
      }
    }
    function drawBody(g, b, x, y, ang, ghost) {
      const r = b.r * view.sx, col = T.c[b.ci % 6];
      if (ghost) g.globalAlpha = .28;
      if (b.shape === 'ball') {
        const gr = g.createRadialGradient(x - r * .35, y - r * .35, r * .1, x, y, r); gr.addColorStop(0, alpha('#ffffff', .85)); gr.addColorStop(.25, col); gr.addColorStop(1, col);
        D.circle(g, x, y, r, gr, alpha(T.fg, .5), 1);
      } else {
        g.save(); g.translate(x, y); g.rotate(-ang); D.rrect(g, -r, -r, 2 * r, 2 * r, Math.min(4, r * .2), col, alpha(T.fg, .45), 1);
        if (!ghost && r > 12) D.text(g, `${fmt(b.m, 1)}kg`, 0, 0, '#fff', { size: Math.min(12, r * .55), align: 'center', mono: true });
        g.restore();
      }
      if (b.q && !ghost) D.text(g, b.q > 0 ? '+' : '−', x, y + 1, '#fff', { size: Math.max(11, r), align: 'center', bold: true });
      g.globalAlpha = 1;
    }
    function drawBodies(g) {
      const bs = objs.filter(o => o.kind === 'body');
      if (show.trail) for (const b of bs) { if (b.trail.length < 2) continue; g.strokeStyle = alpha(T.c[b.ci % 6], .55); g.lineWidth = 1.6; g.beginPath(); b.trail.forEach((p, i) => i ? g.lineTo(view.X(p[0]), view.Y(p[1])) : g.moveTo(view.X(p[0]), view.Y(p[1]))); if (!run || b === held) { } g.lineTo(view.X(b.x), view.Y(b.y)); g.stroke(); }
      if (show.strobe) for (const b of bs) for (const s of b.strobe) drawBody(g, b, view.X(s[0]), view.Y(s[1]), s[2], true);
      for (const b of bs) {
        if (b.shape === 'block' && b.touch) { const tgt = Math.atan2(b.touch[0], b.touch[1]); let d = tgt - b.ang; d = Math.atan2(Math.sin(d), Math.cos(d)); b.ang += d * .35; }
        const [x, y] = P(b.x, b.y); drawBody(g, b, x, y, b.ang, false);
        if (sel === b) { g.setLineDash([4, 3]); D.circle(g, x, y, b.r * view.sx + 5, null, T.accent, 1.6); g.setLineDash([]); }
      }
      if (show.vel) for (const b of bs) { const v = Math.hypot(b.vx, b.vy); if (v < .02) continue; view.vec(b.x, b.y, b.x + b.vx * VS, b.y + b.vy * VS, T.c1, 2); if (sel === b) view.label(`v=${fmt(v, 2)} m/s`, b.x + b.vx * VS, b.y + b.vy * VS, T.c1, { size: 11 }); }
      const b = sel && sel.kind === 'body' ? sel : null;
      if (b && !run) {
        const [hx, hy] = vHandle(b), [px, py] = P(hx, hy);
        if (Math.hypot(b.vx, b.vy) < .02) { g.setLineDash([3, 3]); D.line(g, view.X(b.x), view.Y(b.y), px, py, alpha(T.c1, .6), 1.2); g.setLineDash([]); D.text(g, '拖动设置初速度', px + 10, py, T.muted, { size: 11 }); }
        D.circle(g, px, py, 6.5, T.stage, T.c1, 2);
      }
      if (b && show.force) drawForces(g, b);
    }
    function drawForces(g, b) {
      const F = [];
      if (env.grav) F.push(['G', 0, -b.m * env.g, T.c2]);
      if (b.N && Math.hypot(...b.N) > 1e-3) F.push(['N', b.N[0], b.N[1], T.c1]);
      if (b.F && Math.hypot(...b.F) > 1e-3) F.push(['f', b.F[0], b.F[1], T.c4]);
      if (b.Tn && Math.hypot(...b.Tn) > 1e-3) F.push(['T', b.Tn[0], b.Tn[1], T.c3]);
      if (b.fs && Math.hypot(...b.fs) > 1e-3) F.push(['F弹', b.fs[0], b.fs[1], T.c3]);
      if (b.fe && Math.hypot(...b.fe) > 1e-3) F.push(['F电', b.fe[0], b.fe[1], T.c5]);
      if (b.fg && Math.hypot(...b.fg) > 1e-3) F.push(['F引', b.fg[0], b.fg[1], T.c2]);
      if (b.q && b.bz) { const fx = b.q * b.vy * b.bz, fy = -b.q * b.vx * b.bz; if (Math.hypot(fx, fy) > 1e-3) F.push(['F洛', fx, fy, T.c6]); }
      if (!F.length) return;
      const mx = Math.max(...F.map(f => Math.hypot(f[1], f[2]))), k = 2.4 / mx;
      for (const [n, fx, fy, col] of F) {
        view.vec(b.x, b.y, b.x + fx * k, b.y + fy * k, col, 2.4);
        view.label(`${n} ${fmt(Math.hypot(fx, fy), 2)} N`, b.x + fx * k, b.y + fy * k, col, { size: 11, bold: true, dx: 6, dy: fy > 0 ? -8 : 10 });
      }
    }
    function graph(g) {
      const b = sel && sel.kind === 'body' ? sel : null;
      if (!b || show.graph === 'none' || !b.hist || b.hist.length < 3) return;
      const w = Math.min(300, c.w * .44), h = 112, x = c.w - w - 12, y = 36;
      D.rrect(g, x - 34, y - 22, w + 44, h + 46, 6, alpha(T.surface, .92), T.line, 1);
      const H = b.hist, t0 = Math.max(0, H[H.length - 1][0] - 20), pts = i => H.filter(r => r[0] >= t0).map(r => [r[0], r[i]]);
      let ser, title, leg;
      if (show.graph === 'v') { ser = [{ pts: pts(3), color: T.c1 }, { pts: pts(1), color: T.c2, dash: [4, 3], w: 1.4 }, { pts: pts(2), color: T.c3, dash: [4, 3], w: 1.4 }]; title = 'v–t（m/s）'; leg = [['|v|', T.c1], ['vₓ', T.c2], ['v_y', T.c3]]; }
      else if (show.graph === 'x') { ser = [{ pts: pts(4), color: T.c1 }, { pts: pts(5), color: T.c2 }]; title = 'x–t、y–t（m）'; leg = [['x', T.c1], ['y', T.c2]]; }
      else { const tot = H.filter(r => r[0] >= t0).map(r => [r[0], r[6] + r[7]]); ser = [{ pts: pts(6), color: T.c1 }, { pts: pts(7), color: T.c2 }, { pts: tot, color: T.c4, w: 2.2 }]; title = '能量–t（J）'; leg = [['Eₖ', T.c1], ['Eₚ', T.c2], ['总', T.c4]]; }
      const all = ser.flatMap(s => s.pts.map(p => p[1])), lo = Math.min(0, ...all), hi = Math.max(...all, lo + 1e-6);
      D.chart(g, x, y, w, h, ser, { title, xl: 't/s', ymin: lo - (hi - lo) * .05, ymax: hi + (hi - lo) * .08 });
      leg.forEach(([n, col], i) => D.text(g, n, x + w - 8 - (leg.length - 1 - i) * 38, y - 10, col, { size: 11, align: 'right', bold: true }));
    }
    function vHandle(b) { const v = Math.hypot(b.vx, b.vy); return v < .02 ? [b.x + b.r + .7, b.y] : [b.x + b.vx * VS, b.y + b.vy * VS]; }
    let panned = false;
    function homeView() { // 地面贴近底部：按画布宽高比确定显示范围
      const k = c.h / Math.max(1, c.w);
      view.home = 24 * k >= 14.6 ? [-1, 23, -1.4, -1.4 + 24 * k] : [11 - 7.3 / k, 11 + 7.3 / k, -1.4, 13.2];
      if (!panned) view.r = view.home.slice();
    }
    L.onDraw(() => {
      homeView();
      const g = view.begin({ xl: 'x/m', yl: 'y/m' });
      drawFields(g); drawStatic(g); drawBodies(g); graph(g);
      const tl = `t = ${fmt(simT, 2)} s${run ? '' : simT > 0 ? '　已暂停' : '　按「播放」开始'}`; g.font = `600 13px ${MONO}`;
      const tx = clamp(view.X(0) + 44, 8, c.w * .4);
      D.rrect(g, tx, 6, g.measureText(tl).width + 16, 22, 5, alpha(T.surface, .9), T.line, 1);
      D.text(g, tl, tx + 8, 17, run ? T.fg : T.muted, { size: 13, mono: true, bold: true });
      if (!objs.some(o => o.kind === 'body')) D.text(g, '从左侧选一个示例，或拖入小球、木块', c.w / 2, c.h * .4, T.muted, { size: 15, align: 'center' });
    });

    /* ---- 交互 ---- */
    function hitTest(px, py) {
      const wx = view.ix(px), wy = view.iy(py), near = (x, y, r = 9) => Math.hypot(px - view.X(x), py - view.Y(y)) < r;
      if (sel && sel.kind === 'body' && !run) { const [hx, hy] = vHandle(sel); if (near(hx, hy, 10)) return { t: 'vel', o: sel }; }
      if (sel && (sel.kind === 'ef' || sel.kind === 'bf') && near(sel.x + sel.w, sel.y + sel.h, 11)) return { t: 'size', o: sel };
      if (sel && sel.kind === 'ramp') { const p = rampPts(sel); if (near(p.tx, p.ty, 10)) return { t: 'rtop', o: sel }; }
      if (sel && sel.kind === 'wall') { if (near(sel.x1, sel.y1)) return { t: 'w1', o: sel }; if (near(sel.x2, sel.y2)) return { t: 'w2', o: sel }; }
      const bs = objs.filter(o => o.kind === 'body');
      for (let i = bs.length - 1; i >= 0; i--) { const b = bs[i]; if (Math.hypot(wx - b.x, wy - b.y) < b.r + 6 / view.sx) return { t: 'body', o: b, ox: wx - b.x, oy: wy - b.y }; }
      for (const k of objs) if (k.kind === 'link' && k.a == null && near(k.ax, k.ay, 10)) return { t: 'anchor', o: k };
      for (const o of objs) if (o.kind === 'pc' && near(o.x, o.y, .25 * view.sx + 6)) return { t: 'move', o };
      for (const o of objs) if (o.kind === 'pulley' && near(o.x, o.y, Math.max(7, .3 * view.sx) + 5)) return { t: 'move', o };
      for (const o of objs) if (o.kind === 'planet' && Math.hypot(wx - o.x, wy - o.y) < o.R + 4 / view.sx) return { t: 'move', o };
      for (const o of objs) if (o.kind === 'arc') { const d = Math.hypot(wx - o.x, wy - o.y); if ((Math.abs(d - o.R) * view.sx < 8 && onArc(o, Math.atan2(wy - o.y, wx - o.x) * 180 / PI)) || near(o.x, o.y, 8)) return { t: 'move', o }; }
      const dseg = (x1, y1, x2, y2) => { const ax = view.X(x1), ay = view.Y(y1), bx = view.X(x2), by = view.Y(y2), dx = bx - ax, dy = by - ay, t = clamp(((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy || 1), 0, 1); return Math.hypot(px - ax - t * dx, py - ay - t * dy); };
      for (const k of objs) if (k.kind === 'link') { const { b, ax, ay } = ends(k); if (b && dseg(ax, ay, b.x, b.y) < 7) return { t: 'link', o: k }; }
      for (const o of objs) if (o.kind === 'wall' && dseg(o.x1, o.y1, o.x2, o.y2) < 8) return { t: 'move', o };
      for (const o of objs) if (o.kind === 'ramp') { const p = rampPts(o), lo = Math.min(p.fx, p.tx), hi = Math.max(p.fx, p.tx); if (wx >= lo && wx <= hi && wy >= 0 && wy <= p.ty * Math.abs(wx - p.fx) / Math.abs(p.tx - p.fx || 1)) return { t: 'move', o }; }
      for (let i = objs.length - 1; i >= 0; i--) { const o = objs[i]; if ((o.kind === 'ef' || o.kind === 'bf') && inside(o, wx, wy)) return { t: 'move', o }; }
      return null;
    }
    let lastP = null;
    c.cv.addEventListener('wheel', () => panned = true, { passive: true });
    L.interact(c, {
      view, pan: () => { panned = true; },
      hit: hitTest,
      down: (x, y, h) => { if (h && h !== '__pan') { select(h.t === 'link' ? h.o : h.o); if (h.t === 'body' && run) { held = h.o; lastP = [view.ix(x), view.iy(y), performance.now()]; } } },
      drag: (h, x, y, dx, dy) => {
        const o = h.o, wx = view.ix(x), wy = view.iy(y), ddx = dx / view.sx, ddy = -dy / view.sy, sn = v => Math.round(v * 10) / 10;
        switch (h.t) {
          case 'body':
            o.x = wx - h.ox; o.y = Math.max(env.ground ? o.r : -1e9, wy - h.oy);
            if (run) { const now = performance.now(), dtp = Math.max(1, now - lastP[2]) / 1000; o.vx = lerp(o.vx, (wx - lastP[0]) / dtp, .5); o.vy = lerp(o.vy, (wy - lastP[1]) / dtp, .5); lastP = [wx, wy, now]; }
            else { o.vx = o.vx; edited(); }
            break;
          case 'vel': { let vx = (wx - o.x) / VS, vy = (wy - o.y) / VS; if (Math.hypot(vx, vy) < .3) vx = vy = 0; o.vx = Math.round(vx * 10) / 10; o.vy = Math.round(vy * 10) / 10; edited(); refreshProps(); break; }
          case 'size': o.w = Math.max(1, sn(wx - o.x)); o.h = Math.max(1, sn(wy - o.y)); break;
          case 'rtop': { const ddx2 = wx - o.x; o.dir = ddx2 >= 0 ? 1 : -1; o.ang = clamp(Math.round(Math.atan2(Math.max(.1, wy), Math.abs(ddx2)) * 180 / PI), 5, 75); o.len = clamp(sn(Math.hypot(ddx2, wy)), 1, 24); edited(); break; }
          case 'w1': o.x1 = sn(wx); o.y1 = sn(wy); edited(); break;
          case 'w2': o.x2 = sn(wx); o.y2 = sn(wy); edited(); break;
          case 'anchor': o.ax = wx; o.ay = wy; edited(); break;
          case 'link': if (o.a == null) { o.ax += ddx; o.ay += ddy; edited(); } break;
          case 'move':
            if (o.kind === 'ramp') o.x += ddx;
            else if (o.kind === 'wall') { o.x1 += ddx; o.x2 += ddx; o.y1 += ddy; o.y2 += ddy; }
            else { o.x += ddx; o.y += ddy; }
            if (o.kind === 'pulley' && !run) { const A = byId(o.a), Bb = byId(o.b); if (A && Bb) o.len = Math.hypot(A.x - o.x, A.y - o.y) + Math.hypot(Bb.x - o.x, Bb.y - o.y); }
            edited(); break;
        }
      },
      up: h => {
        if (!h || h === '__pan') return;
        if (h.t === 'body' && held === h.o) held = null;
        if (h.t === 'anchor') { const k = h.o, b = objs.find(o => o.kind === 'body' && o.id !== k.b && Math.hypot(o.x - k.ax, o.y - k.ay) < o.r + .2); if (b) { k.a = b.id; B.toast(`${LN[k.mode]}的另一端连到了${b.name}`); } }
        if (h.t === 'move' && h.o.kind === 'wall') { const o = h.o; o.x1 = Math.round(o.x1 * 10) / 10; o.x2 = Math.round(o.x2 * 10) / 10; o.y1 = Math.round(o.y1 * 10) / 10; o.y2 = Math.round(o.y2 * 10) / 10; }
        if (sel === h.o) refreshProps();
      },
      click: (x, y, h) => { if (!h || h === '__pan') select(null); }
    });
    c.cv.addEventListener('dblclick', () => { panned = false; L.draw(); });
    const onKey = e => {
      if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
      if ((e.key === 'Delete' || e.key === 'Backspace') && sel) { remove(sel); e.preventDefault(); }
      else if (e.key === ' ') { toggleRun(); e.preventDefault(); }
    };
    addEventListener('keydown', onKey); L.disp.push(() => removeEventListener('keydown', onKey));

    /* ---- 添加与删除 ---- */
    function place(o) { objs.push(o); if (o.kind === 'body') { o.trail = []; o.strobe = []; o.hist = []; } edited(); select(o); return o; }
    function remove(o) {
      objs = objs.filter(q => q !== o && !((q.kind === 'link' || q.kind === 'pulley') && (q.b === o.id || q.a === o.id)));
      if (sel === o) sel = null; edited(); inspect();
    }
    function addLink(mode, at) {
      let b = null;
      if (at) { let best = 3; for (const o of objs) if (o.kind === 'body') { const d = Math.hypot(o.x - at[0], o.y - at[1]); if (d < best) { best = d; b = o; } } }
      else if (sel && sel.kind === 'body') b = sel;
      if (!b) return B.toast(`先选中一个物体，或把${LN[mode]}拖到物体上`);
      let ax, ay;
      if (at && Math.hypot(at[0] - b.x, at[1] - b.y) > 1.2) [ax, ay] = at;
      else if (mode === 'spring') { ax = b.x - 3; ay = b.y; } else { ax = b.x; ay = b.y + 4; }
      const d = Math.hypot(b.x - ax, b.y - ay);
      place(mk.link({ mode, name: nm(LN[mode]), ax, ay, b: b.id, L0: +d.toFixed(2), len: +d.toFixed(2) }));
      B.toast(`${LN[mode]}一端连在${b.name}上，另一端固定；拖动固定端可以移动，拖到另一个物体上就连接两个物体`);
    }
    function addPulley(at) { // 把离放置点最近的两个物体用跨过定滑轮的细绳连起来
      const bs = objs.filter(o => o.kind === 'body');
      if (bs.length < 2) return B.toast('定滑轮要连接两个物体：先放两个小球或木块');
      const p0 = at || [(bs[0].x + bs[1].x) / 2, Math.max(bs[0].y, bs[1].y) + 3];
      bs.sort((p, q) => Math.hypot(p.x - p0[0], p.y - p0[1]) - Math.hypot(q.x - p0[0], q.y - p0[1]));
      const [A, Bb] = bs, len = Math.hypot(A.x - p0[0], A.y - p0[1]) + Math.hypot(Bb.x - p0[0], Bb.y - p0[1]);
      place(mk.pulley({ x: p0[0], y: p0[1], a: A.id, b: Bb.id, len: +len.toFixed(2) }));
      B.toast(`细绳跨过定滑轮连接${A.name}和${Bb.name}；拖动滑轮可以移动它`);
    }
    const centre = () => [Math.round((view.x0 + view.x1) / 2), Math.round(view.y0 + (view.y1 - view.y0) * .62)];
    const at = (x, y) => [view.ix(x), view.iy(y)];

    /* ---- 示例场景 ---- */
    function preset(fn) {
      run = false; objs = []; sel = null; held = null; snap = null; simT = 0; for (const k in cnt) delete cnt[k];
      Object.assign(env, { grav: true, g: 9.8, ground: true, gmu: 0, air: 0 }); Object.assign(show, { trail: true, vel: true, force: false, strobe: false, lines: true, graph: 'v' });
      const first = fn(); panned = false;
      objs.forEach(o => { if (o.kind === 'body') { o.trail = []; o.strobe = []; o.hist = []; } });
      sel = first || objs.find(o => o.kind === 'body') || null; inspect(); L.draw();
    }
    const PRE = [
      ['平抛运动', '频闪照片：水平匀速、竖直自由落体', () => { show.strobe = true; objs.push(ball({ x: 1, y: 10, vx: 5 })); }],
      ['斜抛运动', '最高点速度水平', () => { show.strobe = true; objs.push(ball({ x: 1, y: .4, vx: 7, vy: 10 })); }],
      ['斜面上的木块', 'μ < tanθ 时加速下滑', () => { const r = mk.ramp({ x: 13, dir: -1, ang: 30, len: 11, mu: .2 }); objs.push(r); const p = rampPts(r), a = 30 * PI / 180; objs.push(block({ x: p.tx + .9 * Math.cos(a) + Math.sin(a) * .5, y: p.ty - .9 * Math.sin(a) + Math.cos(a) * .5 })); show.force = true; }],
      ['单摆', '摆长 7 m，偏角 20°', () => { const L0 = 7, a = 20 * PI / 180, b = ball({ x: 11 + L0 * Math.sin(a), y: 11.5 - L0 * Math.cos(a), e: .3 }); objs.push(b, mk.link({ mode: 'rope', name: nm('细绳'), ax: 11, ay: 11.5, b: b.id, len: L0 })); show.graph = 'E'; }],
      ['竖直面内的圆周运动', '最低点 v₀ = √(5gL) 时恰好过最高点', () => { const L0 = 3.5, b = ball({ x: 11, y: 6.5 - L0, vx: +(Math.sqrt(5 * 9.8 * L0) + .3).toFixed(1), e: 0 }); objs.push(b, mk.link({ mode: 'rope', name: nm('细绳'), ax: 11, ay: 6.5, b: b.id, len: L0 })); env.ground = false; show.force = true; }],
      ['弹簧振子', '光滑水平面，弹簧原长 4 m，拉长 1.5 m 后释放', () => { objs.push(mk.wall({ x1: 2, y1: 0, x2: 2, y2: 3 })); const b = block({ x: 7.5, y: .5, m: 1 }); objs.push(b, mk.link({ mode: 'spring', name: nm('弹簧'), ax: 2, ay: .5, b: b.id, k: 20, L0: 4 })); show.graph = 'x'; }],
      ['水平传送带', '先加速，共速后匀速', () => { objs.push(mk.wall({ name: nm('传送带'), x1: 1, y1: 1.2, x2: 21, y2: 1.2, mu: .3, belt: 4 })); objs.push(block({ x: 2.5, y: 1.7 })); show.graph = 'v'; show.force = true; }],
      ['倾斜传送带', 'μ > tanθ 时物体被带上去', () => { objs.push(mk.wall({ name: nm('传送带'), x1: 2, y1: 1, x2: 19, y2: 8, mu: .6, belt: 3 })); const a = Math.atan2(7, 17); objs.push(block({ x: 3 - Math.sin(a) * .5, y: 1 + Math.tan(a) + Math.cos(a) * .5 })); show.graph = 'v'; show.force = true; }],
      ['两球碰撞', '弹性碰撞，m₂ = 2m₁', () => { objs.push(ball({ x: 4, y: .5, r: .5, vx: 4, e: 1 }), ball({ x: 12, y: .6, r: .6, m: 2, e: 1 })); show.graph = 'v'; }],
      ['电场中的偏转', '类平抛：qE 竖直向下', () => { env.grav = false; env.ground = false; objs.push(mk.ef({ x: 6, y: 1, w: 12, h: 10, E: 6, dir: 270 })); objs.push(ball({ x: 1, y: 9, vx: 6, q: 1 })); show.strobe = true; }],
      ['磁场中的圆周运动', 'r = mv/(qB)', () => { env.grav = false; env.ground = false; objs.push(mk.bf({ x: 3, y: -1, w: 19, h: 13, B: 1 })); objs.push(ball({ x: 6, y: 5, vy: 4, q: 1 })); show.force = true; }],
      ['正负粒子在磁场中', '偏转方向相反', () => { env.grav = false; env.ground = false; objs.push(mk.bf({ x: 8, y: -1, w: 14, h: 13, B: -1 })); objs.push(ball({ x: 1, y: 6, vx: 4, q: 1 }), ball({ x: 1, y: 5, vx: 4, q: -1, ci: 0 })); }],
      ['速度选择器', 'v = E/B 时做匀速直线运动', () => { env.grav = false; env.ground = false; objs.push(mk.ef({ x: 5, y: 2, w: 13, h: 8, E: 4, dir: 270 }), mk.bf({ x: 5, y: 2, w: 13, h: 8, B: -1 })); objs.push(ball({ x: 1, y: 6, vx: 4, q: 1, r: .3 }), ball({ x: 1, y: 7.5, vx: 6, q: 1, r: .3 }), ball({ x: 1, y: 4.5, vx: 2.5, q: 1, r: .3 })); }],
      ['点电荷周围的圆周运动', '库仑力提供向心力', () => { env.grav = false; env.ground = false; objs.push(mk.pc({ x: 11, y: 6, Q: -20 })); objs.push(ball({ x: 11, y: 10, vx: +Math.sqrt(9 * 20 / 4).toFixed(2), q: 1, r: .3 })); show.graph = 'E'; }],
      ['空气阻力中的下落', 'f = kv，最终匀速：v = mg/k', () => { env.air = 2; objs.push(ball({ x: 7, y: 12, m: 1, e: 0 }), ball({ x: 14, y: 12, m: 4, r: .5, e: 0 })); show.graph = 'v'; }],
      ['竖直上抛', '上升、下落时间相等', () => { show.strobe = true; objs.push(ball({ x: 8, y: .4, vy: 13, e: 0 })); show.graph = 'v'; }],
      ['半圆轨道', '从最高点飞出后做平抛', () => { objs.push(mk.arc({ x: 14, y: 3, R: 3, a0: -90, a1: 90 })); objs.push(ball({ x: 3, y: .3, r: .3, vx: 12.5, e: .1 })); show.strobe = true; show.force = true; }],
      ['竖直圆轨道（过山车）', 'h ≥ 2.5R 才能通过最高点', () => { objs.push(mk.arc({ x: 7, y: 7, R: 7, a0: 180, a1: 270 }), mk.arc({ x: 15, y: 2.5, R: 2.5, a0: -90, a1: 220 })); objs.push(ball({ x: .35, y: 6.9, r: .3, e: .1 })); show.graph = 'E'; show.force = true; }],
      ['阿特伍德机', 'a = (m₂−m₁)g/(m₁+m₂)', () => { const A = block({ x: 10.3, y: 6, m: 1, r: .45 }), Bb = block({ x: 11.7, y: 6, m: 2, r: .45 }); objs.push(A, Bb); objs.push(mk.pulley({ x: 11, y: 11.5, a: A.id, b: Bb.id, len: +(Math.hypot(.7, 5.5) * 2).toFixed(3) })); show.graph = 'v'; show.force = true; return Bb; }],
      ['连接体', '光滑桌面 + 定滑轮：a = m₂g/(m₁+m₂)', () => { objs.push(mk.wall({ name: nm('桌面'), x1: 1, y1: 6, x2: 13, y2: 6 })); const A = block({ x: 4, y: 6.5, m: 2 }), Bb = ball({ x: 13.6, y: 3, m: 1, r: .4, e: 0 }); objs.push(A, Bb, mk.pulley({ x: 13.6, y: 6.5, a: A.id, b: Bb.id, len: 9.6 + 3.5 })); show.graph = 'v'; show.force = true; return A; }],
      ['卫星的轨道', '圆轨道与椭圆轨道', () => { env.grav = false; env.ground = false; objs.push(mk.planet({ x: 11, y: 6, GM: 400, R: 1.5 })); const s = ball({ name: nm('卫星'), x: 11, y: 10, vx: -10, r: .25, e: 1 }); objs.push(s, ball({ name: nm('卫星'), x: 11, y: 2, vx: 11, r: .25, e: 1, ci: 3 })); show.graph = 'E'; return s; }],
      ['质谱仪', '加速后进入磁场，r = √(2mU/q)/B', () => { env.grav = false; env.ground = false; objs.push(mk.ef({ x: .5, y: 9, w: 3.5, h: 2.2, E: 8, dir: 0 }), mk.bf({ x: 4, y: -1.5, w: 18, h: 14, B: 2 })); objs.push(ball({ x: .8, y: 10, q: 1, m: 1, r: .18, nc: true }), ball({ x: .8, y: 10.6, q: 1, m: 2, r: .18, nc: true, ci: 3 })); show.lines = false; }],
      ['圆形磁场：磁聚焦', '轨迹半径 = 磁场半径时汇聚于一点', () => { env.grav = false; env.ground = false; objs.push(mk.bf({ x: 7, y: 2, w: 8, h: 8, B: 1, circ: true })); for (let k = -2; k <= 2; k++) objs.push(ball({ x: 1, y: 6 + 1.5 * k, vx: 4, q: 1, r: .15, nc: true, ci: k + 2 })); }],
      ['空白场景', '只有地面', () => { }]
    ];

    /* ---- 检查器 ---- */
    function select(o) { if (sel !== o) { sel = o; inspect(); } L.draw(); }
    function inspect() {
      B.clearPanel(); ui = {};
      L.group('运行');
      ui.play = L.button(run ? '暂停' : '播放', toggleRun, true); L.button('单步', () => { if (!snap) snap = save(); frame(.02 * speed); L.draw(); }); L.button('重置', reset);
      L.seg('倍速', [[.25, '¼×'], [.5, '½×'], [1, '1×'], [2, '2×']], speed, v => speed = +v);
      L.note('空格键播放/暂停。运行中可以用鼠标抓住物体甩出去。');
      if (sel) props(sel);
      L.group('环境');
      L.check('重力', env.grav, v => { env.grav = v; edited(); });
      L.slider('重力加速度 g', 1, 20, .1, env.g, v => { env.g = v; edited(); }, 'm/s²');
      L.check('地面', env.ground, v => { env.ground = v; edited(); });
      L.slider('地面摩擦因数 μ', 0, 1, .05, env.gmu, v => { env.gmu = v; edited(); });
      L.slider('空气阻力系数（f = kv）', 0, 2, .05, env.air, v => { env.air = v; edited(); }, 'kg/s');
      L.group('显示');
      L.check('轨迹', show.trail, v => show.trail = v); L.check('速度矢量', show.vel, v => show.vel = v);
      L.check('受力分析（选中的物体）', show.force, v => show.force = v); L.check('频闪照片（每 0.1 s）', show.strobe, v => show.strobe = v);
      L.check('点电荷的电场线', show.lines, v => show.lines = v);
      L.select('图像（选中的物体）', [['none', '不显示'], ['v', 'v–t 图'], ['x', 'x–t、y–t 图'], ['E', '能量–时间图']], show.graph, v => show.graph = v);
      L.note('拖动空白处平移，滚轮缩放，双击复位视图。');
    }
    function props(o) {
      const ed = f => v => { f(v); edited(); refreshProps(); };
      if (o.kind === 'body') {
        L.group(o.name);
        L.slider('质量 m', .1, 10, .1, o.m, ed(v => o.m = v), 'kg');
        L.slider(o.shape === 'ball' ? '半径' : '半边长', .1, 1.5, .05, o.r, ed(v => o.r = v), 'm');
        L.slider('电荷量 q', -5, 5, .1, o.q, ed(v => o.q = v), 'C');
        L.slider('恢复系数 e（1 为弹性碰撞）', 0, 1, .05, o.e, ed(v => o.e = v));
        ui.vx = L.slider('速度 vₓ', -30, 30, .1, o.vx, ed(v => o.vx = v), 'm/s');
        ui.vy = L.slider('速度 v_y', -30, 30, .1, o.vy, ed(v => o.vy = v), 'm/s');
        ui.out = L.out();
        L.button('删除', () => remove(o)); L.button('清除轨迹', () => { o.trail = []; o.strobe = []; });
      } else if (o.kind === 'ramp') {
        L.group(o.name);
        L.slider('倾角 θ', 5, 75, 1, o.ang, ed(v => o.ang = v), '°');
        L.slider('斜面长度', 1, 24, .1, o.len, ed(v => o.len = v), 'm');
        L.slider('动摩擦因数 μ', 0, 1, .01, o.mu, ed(v => o.mu = v));
        L.seg('朝向', [[1, '右端高'], [-1, '左端高']], o.dir, ed(v => o.dir = +v));
        ui.out = L.out(); L.note('拖动斜面平移，拖动顶点调整倾角和长度。'); L.button('删除', () => remove(o));
      } else if (o.kind === 'wall') {
        L.group(o.name);
        L.slider('摩擦因数 μ', 0, 1, .05, o.mu, ed(v => o.mu = v));
        if (o.belt != null) L.slider('带速（正值：从第一个端点向第二个端点）', -10, 10, .1, o.belt, ed(v => o.belt = v), 'm/s');
        L.note(o.belt != null ? '物体与带面有相对滑动时受滑动摩擦力 μN，与带面共速后一起运动。拖动两端可以把传送带倾斜放置。' : '拖动两端的圆点改变位置和方向。');
        L.button('删除', () => remove(o));
      } else if (o.kind === 'link') {
        L.group(o.name);
        if (o.mode === 'spring') { L.slider('劲度系数 k', 1, 500, 1, o.k, ed(v => o.k = v), 'N/m'); L.slider('原长 L₀', .2, 12, .1, o.L0, ed(v => o.L0 = v), 'm'); L.slider('阻尼', 0, 5, .1, o.damp, ed(v => o.damp = v), 'kg/s'); }
        else L.slider(o.mode === 'rope' ? '绳长' : '杆长', .2, 12, .1, o.len, ed(v => o.len = v), 'm');
        ui.out = L.out();
        if (o.a != null) L.button('改为一端固定', () => { const a = byId(o.a); if (a) { o.ax = a.x; o.ay = a.y + 1.5; } o.a = null; edited(); });
        L.button('删除', () => remove(o));
      } else if (o.kind === 'ef') {
        L.group(o.name);
        L.slider('场强 E', 0, 100, .5, o.E, ed(v => o.E = v), 'N/C');
        L.slider('方向（与 x 轴夹角）', 0, 345, 15, o.dir, ed(v => o.dir = v), '°');
        L.slider('宽度', 1, 30, .5, o.w, ed(v => o.w = v), 'm'); L.slider('高度', 1, 20, .5, o.h, ed(v => o.h = v), 'm');
        L.note('拖动区域平移，拖动右上角改变大小。只对带电物体起作用。'); L.button('删除', () => remove(o));
      } else if (o.kind === 'arc') {
        L.group(o.name);
        L.slider('半径 R', .5, 10, .1, o.R, ed(v => o.R = v), 'm');
        L.slider('起始角（与 x 轴夹角，逆时针）', -180, 360, 5, o.a0, ed(v => { o.a0 = v; if (o.a1 <= v) o.a1 = v + 10; }), '°');
        L.slider('终止角', -180, 540, 5, o.a1, ed(v => o.a1 = Math.max(o.a0 + 10, v)), '°');
        L.slider('动摩擦因数 μ', 0, 1, .01, o.mu, ed(v => o.mu = v));
        ui.out = L.out(); L.note('拖动圆弧或圆心平移。−90° 是最低点，90° 是最高点；起始角 −90°、终止角 90° 就是开口向左的半圆轨道。'); L.button('删除', () => remove(o));
      } else if (o.kind === 'pulley') {
        L.group(o.name);
        L.slider('绳长', .5, 30, .1, o.len, ed(v => o.len = v), 'm');
        ui.out = L.out(); L.note('轻绳、光滑轻质滑轮：两侧绳的拉力大小相等。拖动滑轮移动位置（绳长随之更新）。'); L.button('删除', () => remove(o));
      } else if (o.kind === 'planet') {
        L.group(o.name);
        L.slider('GM（引力常量 × 质量）', 20, 3000, 10, o.GM, ed(v => o.GM = v), 'm³/s²');
        L.slider('半径 R', .3, 4, .1, o.R, ed(v => o.R = v), 'm');
        ui.out = L.out(); L.note('万有引力 F = GMm/r²，星球固定不动。通常关掉「重力」和「地面」再用。'); L.button('删除', () => remove(o));
      } else if (o.kind === 'bf') {
        L.group(o.name);
        L.seg('形状', [[0, '矩形'], [1, '圆形']], o.circ ? 1 : 0, ed(v => o.circ = !!+v));
        L.seg('方向', [[1, '⊙ 垂直纸面向外'], [-1, '⊗ 垂直纸面向里']], o.B >= 0 ? 1 : -1, ed(v => o.B = Math.abs(o.B) * v));
        L.slider('磁感应强度 B', 0, 10, .05, Math.abs(o.B), ed(v => o.B = (o.B >= 0 ? 1 : -1) * v), 'T');
        L.slider('宽度', 1, 30, .5, o.w, ed(v => o.w = v), 'm'); L.slider('高度', 1, 20, .5, o.h, ed(v => o.h = v), 'm');
        L.note('洛伦兹力 F = qvB，始终与速度垂直。'); L.button('删除', () => remove(o));
      } else if (o.kind === 'pc') {
        L.group(o.name);
        L.slider('电荷量 Q', -100, 100, 1, o.Q, ed(v => o.Q = v), 'nC');
        L.note('库仑力 F = kQq/r²，k = 9×10⁹ N·m²/C²。点电荷固定不动。'); L.button('删除', () => remove(o));
      }
      refreshProps();
    }
    function refreshProps() {
      const o = sel; if (!o || !ui.out) return;
      if (o.kind === 'body') {
        const v = Math.hypot(o.vx, o.vy), E = energy(o), rows = [
          ['位置', `(${fmt(o.x, 2)}, ${fmt(o.y, 2)}) m`], ['速度大小', `${fmt(v, 3)} m/s`], ['速度方向', v > .01 ? `${fmt(Math.round(Math.atan2(o.vy, o.vx) * 1800 / PI) / 10, 1)}°` : '—'],
          ['动能 Eₖ', `${fmt(E.Ek, 3)} J`]];
        if (env.grav) rows.push(['重力势能（地面为零）', `${fmt(E.Eg, 3)} J`]);
        if (E.Es) rows.push(['弹性势能', `${fmt(E.Es, 3)} J`]);
        if (E.Ee) rows.push(['电势能', `${fmt(E.Ee, 3)} J`]);
        if (E.Ep) rows.push(['引力势能（无穷远处为零）', `${fmt(E.Ep, 3)} J`]);
        rows.push(['机械能（含以上势能）', `${fmt(E.Ek + E.Eg + E.Es + E.Ee + E.Ep, 3)} J`], ['动量 p', `${fmt(o.m * v, 3)} kg·m/s`]);
        const pl = objs.find(q => q.kind === 'planet');
        if (pl) { const r = Math.hypot(o.x - pl.x, o.y - pl.y); rows.push(['到星球中心 r', `${fmt(r, 3)} m`], ['该处圆轨道速度 √(GM/r)', `${fmt(Math.sqrt(pl.GM / r), 3)} m/s`], ['该处逃逸速度 √(2GM/r)', `${fmt(Math.sqrt(2 * pl.GM / r), 3)} m/s`]); }
        if (o.q) { const [Ex, Ey, Bz] = fieldsAt(o.x, o.y); if (Bz) rows.push(['回旋半径 mv/(|q|B)', `${fmt(o.m * v / Math.abs(o.q * Bz), 3)} m`], ['周期 2πm/(|q|B)', `${fmt(TAU * o.m / Math.abs(o.q * Bz), 3)} s`]); if (Ex || Ey) rows.push(['所在处场强', `${fmt(Math.hypot(Ex, Ey), 3)} N/C`]); }
        ui.out.set(rows);
        const r2 = x => Math.round(x * 100) / 100; if (!ui.vx.el.matches(':active')) ui.vx.set(r2(o.vx), true); if (!ui.vy.el.matches(':active')) ui.vy.set(r2(o.vy), true);
      } else if (o.kind === 'ramp') {
        const a = o.ang * PI / 180; ui.out.set([['tan θ', fmt(Math.tan(a), 3)], ['μ < tan θ 时', '物体会下滑'], ['光滑时下滑加速度 g sin θ', `${fmt(env.g * Math.sin(a), 3)} m/s²`], ['有摩擦时 g(sin θ − μcos θ)', `${fmt(Math.max(0, env.g * (Math.sin(a) - o.mu * Math.cos(a))), 3)} m/s²`]]);
      } else if (o.kind === 'arc') {
        ui.out.set([['最低点', `y = ${fmt(o.y - o.R, 2)} m`], ['小球恰好通过最高点（内侧）', 'v顶 = √(gR)'], ['此时最低点速度', `√(5gR) = ${fmt(Math.sqrt(5 * env.g * o.R), 3)} m/s`]]);
      } else if (o.kind === 'pulley') {
        const A = byId(o.a), Bb = byId(o.b); if (!A || !Bb) return;
        const T1 = A.Tn ? Math.hypot(...A.Tn) : 0; ui.out.set([['连接', `${A.name}（${fmt(A.m, 1)} kg）、${Bb.name}（${fmt(Bb.m, 1)} kg）`], ['绳的拉力', run || simT ? `${fmt(T1, 3)} N` : '—'], ['两侧都竖直悬挂时 a = |m₁−m₂|g/(m₁+m₂)', `${fmt(Math.abs(A.m - Bb.m) * env.g / (A.m + Bb.m), 3)} m/s²`]]);
      } else if (o.kind === 'planet') {
        ui.out.set([['表面重力加速度 GM/R²', `${fmt(o.GM / o.R ** 2, 3)} m/s²`], ['第一宇宙速度 √(GM/R)', `${fmt(Math.sqrt(o.GM / o.R), 3)} m/s`], ['第二宇宙速度 √(2GM/R)', `${fmt(Math.sqrt(2 * o.GM / o.R), 3)} m/s`]]);
      } else if (o.kind === 'link') {
        const { b, ax, ay } = ends(o); if (!b) return; const d = Math.hypot(b.x - ax, b.y - ay);
        ui.out.set(o.mode === 'spring' ? [['当前长度', `${fmt(d, 3)} m`], ['形变量 x', `${fmt(d - o.L0, 3)} m`], ['弹力 kx', `${fmt(o.k * Math.abs(d - o.L0), 3)} N`], ['振动周期 2π√(m/k)', `${fmt(TAU * Math.sqrt(b.m / o.k), 3)} s`]]
          : [['当前长度', `${fmt(d, 3)} m`], ['拉力', b.Tn ? `${fmt(Math.hypot(...b.Tn), 3)} N` : '—'], ['小角度周期 2π√(L/g)', `${fmt(TAU * Math.sqrt(o.len / env.g), 3)} s`]]);
      }
    }
    L.every(150, refreshProps);

    /* ---- 素材栏 ---- */
    const svg = s => `<svg viewBox="0 0 24 24">${s}</svg>`;
    const ICON = {
      ball: svg('<circle cx="12" cy="12" r="7" fill="#d6522b"/>'), block: svg('<rect x="5" y="7" width="14" height="11" rx="1.5" fill="#2c6fd1"/>'),
      pos: svg('<circle cx="12" cy="12" r="7" fill="#d6522b"/><path d="M8.5 12h7M12 8.5v7" stroke="#fff" stroke-width="2"/>'), neg: svg('<circle cx="12" cy="12" r="7" fill="#2c6fd1"/><path d="M8.5 12h7" stroke="#fff" stroke-width="2"/>'),
      ramp: svg('<path d="M3 19h18V7z" fill="currentColor" opacity=".35" stroke="currentColor" stroke-width="1.2"/>'), wall: svg('<path d="M10 3v18" stroke="currentColor" stroke-width="3"/><path d="M12 5l3-3M12 9l3-3M12 13l3-3M12 17l3-3M12 21l3-3" stroke="currentColor" stroke-width="1"/>'),
      belt: svg('<rect x="2.5" y="9" width="19" height="7" rx="3.5" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="6" cy="12.5" r="2" fill="currentColor"/><circle cx="18" cy="12.5" r="2" fill="currentColor"/><path d="M10 6h5l-1.5-1.5M15 6l-1.5 1.5" fill="none" stroke="currentColor" stroke-width="1.2"/>'),
      board: svg('<path d="M3 15L21 9" stroke="currentColor" stroke-width="3"/>'),
      spring: svg('<path d="M2 12h3l1.5-4 3 8 3-8 3 8 3-8 1.5 4h2" fill="none" stroke="currentColor" stroke-width="1.5"/>'), rope: svg('<path d="M6 3h12M12 3v12" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="17" r="3.5" fill="#d6522b"/>'),
      rod: svg('<path d="M6 3h12" stroke="currentColor" stroke-width="1.5"/><path d="M12 3v12" stroke="currentColor" stroke-width="3.5"/><circle cx="12" cy="17" r="3.5" fill="#d6522b"/>'),
      ef: svg('<rect x="3" y="3" width="18" height="18" fill="#8457c4" opacity=".12" stroke="#8457c4" stroke-dasharray="3 2"/><path d="M8 6v10M16 6v10" stroke="#8457c4" stroke-width="1.5"/><path d="M5.5 14L8 18l2.5-4M13.5 14l2.5 4 2.5-4" fill="none" stroke="#8457c4" stroke-width="1.5"/>'),
      bo: svg('<rect x="3" y="3" width="18" height="18" fill="#16968a" opacity=".12" stroke="#16968a" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="5" fill="none" stroke="#16968a" stroke-width="1.5"/><circle cx="12" cy="12" r="1.6" fill="#16968a"/>'),
      bi: svg('<rect x="3" y="3" width="18" height="18" fill="#16968a" opacity=".12" stroke="#16968a" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="5" fill="none" stroke="#16968a" stroke-width="1.5"/><path d="M9.3 9.3l5.4 5.4M14.7 9.3l-5.4 5.4" stroke="#16968a" stroke-width="1.5"/>'),
      qp: svg('<circle cx="12" cy="12" r="5" fill="#d6522b"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l2.8 2.8M16.2 16.2L19 19M19 5l-2.8 2.8M7.8 16.2L5 19" stroke="#d6522b" stroke-width="1.2"/>'),
      qn: svg('<circle cx="12" cy="12" r="5" fill="#2c6fd1"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="#2c6fd1" stroke-width="1.2"/>'),
      arc: svg('<path d="M5 6a8 8 0 0 0 14 9" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="9" cy="14" r="2.2" fill="#d6522b"/>'),
      pulley: svg('<path d="M8 2h8M12 2v5" stroke="currentColor" stroke-width="1.4"/><circle cx="12" cy="10" r="3.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 10v8M15.5 10v5" stroke="currentColor" stroke-width="1.2"/><rect x="6" y="18" width="5" height="4" fill="#2c6fd1"/><circle cx="15.5" cy="17" r="2.4" fill="#d6522b"/>'),
      planet: svg('<circle cx="12" cy="12" r="6" fill="#3d7fc4"/><ellipse cx="12" cy="12" rx="10.5" ry="3.5" fill="none" stroke="currentColor" stroke-width="1.1" transform="rotate(-20 12 12)"/>'),
      bc: svg('<circle cx="12" cy="12" r="9" fill="#16968a" opacity=".12" stroke="#16968a" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="4" fill="none" stroke="#16968a" stroke-width="1.5"/><circle cx="12" cy="12" r="1.4" fill="#16968a"/>'),
      demo: svg('<path d="M5 18c4-12 10-12 14 0" fill="none" stroke="currentColor" stroke-dasharray="2 2.5" stroke-width="1.5"/><circle cx="5" cy="18" r="2" fill="currentColor"/>')
    };
    const obj = (icon, label, sub, make) => ({ icon, label, sub, click: () => { const [x, y] = centre(); place(make(x, y)); }, drop: (px, py) => { const [x, y] = at(px, py); place(make(x, y)); } });
    const lnk = (mode, icon, sub) => ({ icon, label: LN[mode], sub, click: () => addLink(mode), drop: (px, py) => addLink(mode, at(px, py)) });
    B.palette([
      { title: '示例场景', items: PRE.map(([n, s, f]) => ({ icon: ICON.demo, label: n, sub: s, click: () => preset(f) })) },
      { title: '物体', items: [
        obj(ICON.ball, '小球', '1 kg', (x, y) => ball({ x, y: Math.max(.4, y) })),
        obj(ICON.block, '木块', '1 kg', (x, y) => block({ x, y: Math.max(.5, y) })),
        obj(ICON.pos, '带正电小球', 'q = +1 C', (x, y) => ball({ x, y: Math.max(.4, y), q: 1, ci: 1 })),
        obj(ICON.neg, '带负电小球', 'q = −1 C', (x, y) => ball({ x, y: Math.max(.4, y), q: -1, ci: 0 }))] },
      { title: '器材', items: [
        obj(ICON.ramp, '斜面', '可调倾角和摩擦', (x) => mk.ramp({ x: x - 4 })),
        obj(ICON.wall, '竖直挡板', '拖动两端调整', (x) => mk.wall({ x1: x, y1: 0, x2: x, y2: 3 })),
        obj(ICON.belt, '传送带', '带速和摩擦可调', (x, y) => mk.wall({ name: nm('传送带'), x1: x - 4, y1: Math.max(.6, y - 1), x2: x + 4, y2: Math.max(.6, y - 1), mu: .3, belt: 3 })),
        obj(ICON.board, '木板', '可倾斜放置', (x, y) => mk.wall({ name: nm('木板'), x1: x - 3, y1: Math.max(.5, y - 1), x2: x + 3, y2: Math.max(.5, y - 1), mu: .2 })),
        obj(ICON.arc, '圆弧轨道', '半圆、圆环、四分之一圆弧', (x, y) => mk.arc({ x, y: Math.max(3, y) })),
        lnk('spring', ICON.spring, '连到物体上'), lnk('rope', ICON.rope, '只能拉，不能推'), lnk('rod', ICON.rod, '长度不变'),
        { icon: ICON.pulley, label: '定滑轮', sub: '连接最近的两个物体', click: () => addPulley(), drop: (px, py) => addPulley(at(px, py)) }] },
      { title: '场', items: [
        obj(ICON.ef, '匀强电场', '方向可调', (x, y) => mk.ef({ x: x - 5, y: Math.max(0, y - 4) })),
        obj(ICON.bo, '匀强磁场 ⊙', '垂直纸面向外', (x, y) => mk.bf({ x: x - 5, y: Math.max(0, y - 4), B: 1 })),
        obj(ICON.bi, '匀强磁场 ⊗', '垂直纸面向里', (x, y) => mk.bf({ x: x - 5, y: Math.max(0, y - 4), B: -1 })),
        obj(ICON.bc, '圆形磁场区域', '⊙，半径可调', (x, y) => mk.bf({ x: x - 4, y: y - 4, w: 8, h: 8, B: 1, circ: true })),
        obj(ICON.planet, '星球', '万有引力 F = GMm/r²', (x, y) => { env.grav = false; env.ground = false; B.toast('已关闭重力和地面，物体只受星球的引力'); inspect(); return mk.planet({ x, y }); }),
        obj(ICON.qp, '正点电荷', 'Q = +10 nC', (x, y) => mk.pc({ x, y, Q: 10 })),
        obj(ICON.qn, '负点电荷', 'Q = −10 nC', (x, y) => mk.pc({ x, y, Q: -10 }))] }
    ]);
    B.foot.append(el('section', 'info-tips', `<h3>怎么用</h3><ol>
      <li>左侧先选一个<b>示例场景</b>，或者把物体、器材、场拖进画面。</li>
      <li>点选物体后，拖动它旁边的蓝色圆点设定初速度；右侧可以改质量、电荷量、恢复系数等。</li>
      <li>按<b>播放</b>运行，<b>重置</b>回到播放前的状态。打开<b>频闪照片</b>、<b>受力分析</b>和 <b>v–t 图</b>对照讲解。</li>
      <li>弹簧、细绳、轻杆拖到物体上即可连接；把它的固定端拖到另一个物体上，就把两个物体连在一起。</li></ol>`),
      el('section', 'info-tips', `<h3>模型说明</h3><ol>
      <li>物体按质点处理（只平动、不滚动），木块不转动，碰撞时按接触面法线方向计算，摩擦力取 μN。</li>
      <li>绳、杆、滑轮都是轻质的，滑轮光滑，同一根绳上拉力处处相等；星球固定不动。</li>
      <li>电荷量、场强取便于观察的理想化数值；带电物体之间的库仑力不计。</li>
      <li>积分步长约 1.5 ms，长时间运行会有很小的能量误差。</li></ol>`));

    /* ---- 主循环 ---- */
    L.loop(dt => { if (run) frame(dt * speed); L.draw(); });
    Bench.physState = () => ({ objs, simT, env, step: sd => frame(sd), play: toggleRun }); // 供控制台检查
    preset(PRE[0][2]);
  }
});
})();
