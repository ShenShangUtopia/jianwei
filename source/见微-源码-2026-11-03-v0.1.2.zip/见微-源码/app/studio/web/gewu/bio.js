'use strict';
/* ======================= 生物 ======================= */

/* ---------- 物质跨膜运输 ---------- */
Lab.reg({
  id: 'b-osmo', subj: 'bio', book: 0, unit: '细胞的物质输入和输出', title: '质壁分离与跨膜运输方式', kw: '渗透作用 质壁分离 复原 原生质层 自由扩散 协助扩散 主动运输 载体 通道',
  info: `<p><b>渗透作用</b>需要半透膜和膜两侧的浓度差。成熟植物细胞的原生质层（细胞膜、液泡膜及两层膜之间的细胞质）相当于半透膜。外界溶液浓度大于细胞液浓度时细胞失水，原生质层与细胞壁分离（质壁分离）；放回清水中发生复原。</p>
  <p>在一定浓度的 KNO₃ 溶液中，细胞先发生质壁分离，随后 K⁺、NO₃⁻ 被主动吸收，细胞液浓度升高，自动复原。外界浓度过高时细胞会失水过多而死亡，不能复原。</p>
  <p class="fb">自由扩散：顺浓度梯度，不需要载体和能量，速率 ∝ 浓度差<br>协助扩散：顺浓度梯度，需要转运蛋白，有饱和现象<br>主动运输：可逆浓度梯度，需要载体蛋白，消耗能量（ATP），受 O₂ 浓度影响</p>`,
  tasks: ['把外界蔗糖浓度设为 0.3 g/mL，观察质壁分离；再换成清水，观察复原。', '选 KNO₃ 溶液，为什么不用换清水细胞也能复原？', '运输方式模式中，协助扩散的速率为什么在高浓度时不再增加？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['pl', '质壁分离'], ['tr', '运输方式']], 'pl', () => { G1.hidden = mode.v !== 'pl'; G2.hidden = mode.v !== 'tr'; L.draw(); });
    const G1 = L.group('外界溶液');
    const sol = L.select('', [['suc', '蔗糖溶液'], ['kno3', 'KNO₃ 溶液'], ['water', '清水']], 'suc', () => { hist = []; });
    const co = L.slider('浓度', 0, 0.6, 0.01, 0.3, null, 'g/mL');
    L.button('换一个新细胞', () => { st = { v: 1, s: 0.15, dead: false, t: 0 }; hist = []; });
    const out = L.out();
    const G2 = L.group('运输方式'); G2.hidden = true;
    const kind = L.seg('', [['free', '自由扩散'], ['fac', '协助扩散'], ['act', '主动运输']], 'free');
    const q = L.params({ dc: ['膜两侧浓度差（外 − 内）', -10, 10, 0.5, 6], car: ['转运蛋白数量', 1, 10, 1, 4], o2: ['O₂ 浓度（能量供应）', 0, 10, 0.5, 6] });
    const out2 = L.out();
    let st = { v: 1, s: 0.15, dead: false, t: 0 }, hist = [], parts = [];
    for (let i = 0; i < 60; i++) parts.push({ x: rnd(0, 1), y: rnd(0, 1), out: Math.random() < 0.5 });
    L.loop(dt => {
      if (mode.v === 'pl') {
        const ext = sol.v === 'water' ? 0 : co.v, solute = st.s, inside = solute / st.v;
        if (!st.dead) {
          let dv = 0.8 * (inside - ext) * dt; if (st.v >= 1 && dv > 0) dv = 0;
          st.v = clamp(st.v + dv, 0.3, 1);
          if (sol.v === 'kno3' && ext > 0) st.s += 0.012 * ext * dt;
          if (ext > 0.5 && st.v < 0.42) st.dead = true;
        }
        st.t += dt; hist.push([st.t, st.v]); if (hist.length > 600) hist.shift();
      } else {
        const r = rate(), dir = Math.sign(kind.v === 'act' ? 1 : q.dc);
        parts.forEach(p => { p.x += rnd(-1, 1) * dt * 0.3; p.y += rnd(-1, 1) * dt * 0.3; p.x = clamp(p.x, 0, 1); p.y = clamp(p.y, 0, 1); });
        if (Math.random() < Math.abs(r) * dt * 0.8) { const src = parts.filter(p => p.out === (dir > 0)); if (src.length) src[Math.floor(Math.random() * src.length)].out = !(dir > 0); }
      }
      L.drawFn();
    });
    function rate() { const k = kind.v, dc = q.dc; if (k === 'free') return 0.4 * dc; if (k === 'fac') return Math.sign(dc) * q.car * 1.2 * Math.abs(dc) / (Math.abs(dc) + 2); return q.car * 1.2 * q.o2 / (q.o2 + 2) * (q.o2 > 0 ? 1 : 0.15); }
    L.onDraw(() => {
      c.clear(); const g = c.g;
      if (mode.v === 'pl') {
        const W = Math.min(c.w * 0.5, 320), H = W * 0.62, x0 = 30, y0 = (c.h - H) / 2, ext = sol.v === 'water' ? 0 : co.v;
        D.rect(g, 10, 10, c.w * 0.55, c.h - 20, `rgba(120,170,240,${0.06 + ext * 0.5})`);
        D.rrect(g, x0, y0, W, H, 14, null, '#6b8e23', 8);
        const vv = st.v, iw = (W - 16) * Math.sqrt(vv), ih = (H - 16) * Math.sqrt(vv), cx = x0 + W / 2, cy = y0 + H / 2;
        D.rrect(g, cx - iw / 2, cy - ih / 2, iw, ih, 12 * vv, alpha('#7cb342', 0.5), '#558b2f', 2);
        const vac = clamp(st.s / vv / 0.6, 0, 1); D.rrect(g, cx - iw / 2 + 8, cy - ih / 2 + 8, iw - 16, ih - 16, 10 * vv, `rgba(150,40,160,${0.25 + vac * 0.6})`);
        D.circle(g, cx - iw / 2 + 18, cy - ih / 2 + 18, 7, alpha('#33691e', 0.8));
        D.text(g, '细胞壁', x0 + W + 8, y0 + 10, T.muted, { size: 11 }); D.text(g, '原生质层', x0 + W + 8, y0 + 28, T.muted, { size: 11 }); D.text(g, '液泡（紫色细胞液）', x0 + W + 8, y0 + 46, T.muted, { size: 11 });
        if (st.dead) D.text(g, '细胞已失水过多死亡', cx, y0 + H + 22, T.bad, { align: 'center', bold: true });
        const gx = c.w * 0.58, gw = c.w - gx - 20;
        if (hist.length > 1 && gw > 120) D.chart(g, gx, 30, gw, c.h - 70, [{ pts: hist, color: T.c5, w: 2 }], { title: '原生质层相对大小', xl: 't', xmin: hist[0][0], xmax: st.t, ymin: 0.2, ymax: 1.05 });
        const inside = st.s / st.v;
        out.set([['外界溶液浓度', ext + ' g/mL'], ['细胞液浓度（相对）', fmt(inside * 2, 3)], ['原生质层体积', fmt(vv * 100, 1) + ' %'], ['状态', st.dead ? '死亡' : vv < 0.97 ? (inside < ext - 0.005 ? '正在失水，质壁分离' : inside > ext + 0.005 ? '正在吸水，质壁分离复原' : '质壁分离（平衡）') : '正常（紧贴细胞壁）'], ['液泡颜色', vv < 0.97 ? '变深' : '正常']]);
      } else {
        const mx = c.w * 0.27, top = 30, H = c.h - 60;
        D.rect(g, mx - 12, top, 24, H, alpha('#d9a441', 0.35)); for (let y = top; y < top + H; y += 14) { D.circle(g, mx - 9, y + 7, 4, alpha('#d9a441', 0.9)); D.circle(g, mx + 9, y + 7, 4, alpha('#d9a441', 0.9)); }
        if (kind.v !== 'free') for (let k = 0; k < q.car; k++) { const y = top + (k + 0.5) * H / q.car; D.rrect(g, mx - 16, y - 12, 32, 24, 8, kind.v === 'act' ? T.c2 : T.c3); }
        if (kind.v === 'act') D.text(g, 'ATP → ADP + Pi', mx, top + H + 14, T.c2, { align: 'center', size: 11 });
        parts.forEach(p => D.circle(g, p.out ? 20 + p.x * (mx - 50) : mx + 30 + p.x * (mx - 50), top + p.y * H, 4, kind.v === 'act' ? T.c2 : kind.v === 'fac' ? T.c3 : T.c1));
        D.text(g, '膜外', 24, 18, T.muted); D.text(g, '膜内', mx + 30, 18, T.muted);
        const gx = c.w * 0.58, gw = c.w - gx - 20, gh = (c.h - 80) / 2;
        const xs = [...Array(51).keys()].map(i => i / 5);
        const c1 = D.chart(g, gx, 24, gw, gh, [{ pts: xs.map(x => [x, 0.4 * x]), color: T.c1, w: 2 }, { pts: xs.map(x => [x, q.car * 1.2 * x / (x + 2)]), color: T.c3, w: 2 }], { title: '速率 − 浓度差（蓝：自由扩散，绿：协助扩散）', xl: '浓度差', xmin: 0, xmax: 10, ymin: 0, ymax: 13 });
        D.circle(g, c1.X(Math.abs(q.dc)), c1.Y(Math.abs(rate())), 5, T.c2);
        D.chart(g, gx, 50 + gh, gw, gh, [{ pts: xs.map(x => [x, q.car * 1.2 * x / (x + 2) + (x === 0 ? q.car * 0.18 : 0)]), color: T.c2, w: 2 }], { title: '主动运输速率 − O₂ 浓度', xl: 'O₂', xmin: 0, xmax: 10, ymin: 0, ymax: 13 });
        out2.set([['运输方式', { free: '自由扩散（如 O₂、CO₂、甘油）', fac: '协助扩散（如葡萄糖进入红细胞、水通过水通道）', act: '主动运输（如 K⁺ 进入细胞、小肠吸收葡萄糖）' }[kind.v]], ['方向', kind.v === 'act' ? '可逆浓度梯度' : q.dc >= 0 ? '高浓度 → 低浓度（向内）' : '高浓度 → 低浓度（向外）'], ['需要转运蛋白', kind.v === 'free' ? '否' : '是'], ['消耗能量', kind.v === 'act' ? '是' : '否'], ['相对速率', fmt(Math.abs(rate()), 2)]]);
      }
    });
  }
});

/* ---------- 酶的特性 ---------- */
Lab.reg({
  id: 'b-enzyme', subj: 'bio', book: 0, unit: '细胞的能量供应和利用', title: '影响酶活性的因素', kw: '酶 高效性 专一性 最适温度 最适 pH 变性 底物浓度 过氧化氢酶',
  info: `<p>酶是活细胞产生的具有催化作用的有机物，绝大多数是蛋白质。酶的作用机理是<b>降低化学反应的活化能</b>。</p>
  <p class="fb">高效性：与无机催化剂相比，酶降低活化能的作用更显著<br>专一性：每种酶只能催化一种或一类化学反应<br>作用条件温和：有最适温度和最适 pH；高温、过酸、过碱使酶空间结构破坏而永久失活，低温只抑制活性</p>
  <p>底物浓度较低时，反应速率随底物浓度增加而增加；底物足够多时受酶量限制，速率不再增加。</p>`,
  tasks: ['比较唾液淀粉酶和胃蛋白酶的最适 pH。', '勾选「先经过 80 ℃ 处理」，再把温度调回 37 ℃，活性能恢复吗？与 0 ℃ 处理比较。', '高效性模式中，比较三支试管产生气泡的速度。'],
  init(L) {
    const c = L.canvas();
    const E = { amy: ['唾液淀粉酶', 37, 6.8], pep: ['胃蛋白酶', 37, 1.5], try: ['胰蛋白酶', 37, 8.0], cat: ['过氧化氢酶', 37, 7.0] };
    L.group('模式');
    const mode = L.seg('', [['tp', '温度与 pH'], ['s', '底物浓度'], ['eff', '高效性']], 'tp', () => L.draw());
    L.group('条件');
    const en = L.select('酶', Object.entries(E).map(([k, v]) => [k, v[0]]), 'amy');
    const p = L.params({ T: ['温度', 0, 100, 1, 37, '℃'], pH: ['pH', 0, 14, 0.1, 6.8], S: ['底物浓度', 0, 10, 0.1, 4], e: ['酶量（相对）', 0.2, 2, 0.1, 1] });
    const hot = L.check('先经过 80 ℃ 处理（变性）', false), cold = L.check('先经过 0 ℃ 处理', false);
    const out = L.out();
    const actT = (T, opt) => T <= opt ? Math.exp(-(((T - opt) / 22) ** 2)) : Math.exp(-(((T - opt) / 11) ** 2));
    const actP = (pH, opt) => Math.exp(-(((pH - opt) / 1.6) ** 2));
    let t = 0, bub = [];
    L.loop(dt => { t += dt; if (mode.v === 'eff') { [6, 1.2, 0.05].forEach((r, i) => { if (Math.random() < r * dt * 3) bub.push({ i, x: rnd(-14, 14), y: 0 }); }); bub.forEach(b => b.y += dt * 60); bub = bub.filter(b => b.y < 160); L.drawFn(); } });
    L.onDraw(() => {
      c.clear(); const g = c.g, [nm, To, Po] = E[en.v], dead = hot.v, a = dead ? 0 : actT(p.T, To) * actP(p.pH, Po), gw = (c.w - 90) / 2, gh = c.h - 80;
      if (mode.v === 'tp') {
        const Ts = [...Array(101).keys()], ch1 = D.chart(g, 40, 30, gw, gh, [{ pts: Ts.map(x => [x, dead ? 0 : actT(x, To) * actP(p.pH, Po)]), color: T.c2, w: 2.2 }], { title: `${nm} 活性 − 温度（当前 pH ${p.pH}）`, xl: '温度 / ℃', xmin: 0, xmax: 100, ymin: 0, ymax: 1.1 });
        D.circle(g, ch1.X(p.T), ch1.Y(a), 5, T.c2);
        const Ps = [...Array(141).keys()].map(i => i / 10), ch2 = D.chart(g, 60 + gw, 30, gw, gh, [{ pts: Ps.map(x => [x, dead ? 0 : actT(p.T, To) * actP(x, Po)]), color: T.c1, w: 2.2 }], { title: `活性 − pH（当前 ${p.T} ℃）`, xl: 'pH', xmin: 0, xmax: 14, ymin: 0, ymax: 1.1 });
        D.circle(g, ch2.X(p.pH), ch2.Y(a), 5, T.c1);
        Object.entries(E).forEach(([k, v]) => { if (k === en.v) return; g.strokeStyle = alpha(T.muted, 0.5); g.setLineDash([3, 3]); g.beginPath(); Ps.forEach((x, i) => { const y = ch2.Y(actT(p.T, v[1]) * actP(x, v[2])); i ? g.lineTo(ch2.X(x), y) : g.moveTo(ch2.X(x), y); }); g.stroke(); g.setLineDash([]); });
      } else if (mode.v === 's') {
        const Ss = [...Array(101).keys()].map(i => i / 10), V = (S, e) => a * e * 10 * S / (S + 1.5);
        const ch = D.chart(g, 40, 30, c.w - 80, gh, [{ pts: Ss.map(S => [S, V(S, p.e)]), color: T.c3, w: 2.4 }, { pts: Ss.map(S => [S, V(S, p.e * 2)]), color: alpha(T.muted, 0.6), w: 1.4, dash: [5, 4] }], { title: '反应速率 − 底物浓度（虚线：酶量加倍）', xl: '底物浓度', xmin: 0, xmax: 10, ymin: 0, ymax: Math.max(4, a * p.e * 20 * 1.1) });
        D.circle(g, ch.X(p.S), ch.Y(V(p.S, p.e)), 5, T.c2);
      } else {
        const names = ['过氧化氢酶（肝脏研磨液）', 'FeCl₃ 溶液', '蒸馏水（对照）'], xs = [0.2, 0.5, 0.8].map(f => f * c.w), by = c.h - 60;
        xs.forEach((x, i) => { D.rrect(g, x - 24, by - 170, 48, 170, 20, alpha(T.c1, 0.1), T.fg, 1.8); D.rect(g, x - 22, by - 110, 44, 108, alpha(T.c1, 0.15)); D.text(g, names[i], x, by + 18, T.fg, { align: 'center', size: 12 }); });
        bub.forEach(b => D.circle(g, xs[b.i] + b.x * 0.7, by - 10 - b.y * 0.65, 3, null, T.muted, 1));
        D.text(g, '各加 2 mL 3% H₂O₂ 溶液：2H₂O₂ → 2H₂O + O₂↑', c.w / 2, 24, T.muted, { align: 'center' });
      }
      out.set([['酶', nm], ['最适温度 / 最适 pH', `${To} ℃ / ${Po}`], ['当前相对活性', fmt(a * 100, 1) + ' %'], ['状态', dead ? '高温使空间结构破坏，永久失活' : cold.v && p.T > 20 ? '低温处理后已恢复活性' : p.T < 10 ? '低温抑制，结构未破坏' : p.T > 60 ? '高温变性失活' : a > 0.8 ? '接近最适条件' : '活性受抑制']]);
    });
  }
});

/* ---------- 光合作用 ---------- */
Lab.reg({
  id: 'b-photo', subj: 'bio', book: 0, unit: '细胞的能量供应和利用', title: '光合作用与呼吸作用', kw: '光合作用 呼吸作用 光补偿点 光饱和点 净光合速率 CO2 浓度 温度 一昼夜',
  info: `<p class="fb">总（真）光合速率 = 净光合速率 + 呼吸速率<br>光补偿点：光合速率 = 呼吸速率　光饱和点：光合速率不再随光照增强而增加</p>
  <p>光照强度主要影响光反应；CO₂ 浓度主要影响暗反应（卡尔文循环）；温度通过影响酶活性同时影响光合作用与呼吸作用。阴生植物的光补偿点和光饱和点都比阳生植物低。</p>
  <p>「一昼夜」模式模拟密闭玻璃罩内 CO₂ 浓度的变化：曲线的最高点和最低点对应光合速率等于呼吸速率的时刻。</p>`,
  tasks: ['提高 CO₂ 浓度，光补偿点和光饱和点分别怎样移动？', '把温度从 25 ℃ 升到 40 ℃，净光合速率为什么下降？', '一昼夜模式中，24 时的 CO₂ 浓度低于 0 时，说明植物有机物积累了还是减少了？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['lc', '光照强度曲线'], ['day', '一昼夜（密闭容器）']], 'lc', () => L.draw());
    const pt = L.select('植物类型', [['sun', '阳生植物'], ['shade', '阴生植物']], 'sun');
    const p = L.params({ I: ['光照强度', 0, 1500, 10, 600, 'μmol·m⁻²·s⁻¹'], C: ['CO₂ 浓度', 0.01, 0.12, 0.005, 0.04, '%'], T: ['温度', 5, 45, 1, 25, '℃'] });
    const out = L.out();
    const model = (I, C, T) => {
      const sun = pt.v === 'sun', fT = Math.exp(-(((T - 27) / 11) ** 2)), Pm = (sun ? 30 : 12) * C / (C + 0.03) * fT, Ik = sun ? 300 : 90;
      const R = (sun ? 3.2 : 1.2) * 2 ** ((T - 25) / 10), P = Pm * I / (I + Ik);
      return { P, R, net: P - R, Pm, Ik };
    };
    let t = 0; L.loop(dt => { t += dt; if (mode.v === 'lc') L.drawFn(); });
    L.onDraw(() => {
      c.clear(); const g = c.g, m = model(p.I, p.C, p.T);
      if (mode.v === 'lc') {
        const Is = [...Array(151).keys()].map(i => i * 10), lw = Math.min(200, c.w * 0.28);
        const ch = D.chart(g, lw + 60, 30, c.w - lw - 90, c.h - 70, [{ pts: Is.map(I => [I, model(I, p.C, p.T).net]), color: T.c3, w: 2.4 }, { pts: Is.map(I => [I, model(I, p.C, p.T).P]), color: alpha(T.muted, 0.7), w: 1.4, dash: [5, 4] }], { title: '净光合速率（实线）与总光合速率（虚线） − 光照强度', xl: '光照强度', xmin: 0, xmax: 1500, ymin: -6, ymax: 32 });
        D.circle(g, ch.X(p.I), ch.Y(m.net), 5.5, T.c2);
        const comp = m.R < m.Pm ? m.Ik * m.R / (m.Pm - m.R) : null, sat = 19 * m.Ik;
        if (comp) { D.line(g, ch.X(comp), ch.Y(-6), ch.X(comp), ch.Y(0), T.c2, 1.2, [3, 3]); D.text(g, '补偿点', ch.X(comp) + 3, ch.Y(-4), T.c2, { size: 10 }); }
        if (sat < 1500) { D.line(g, ch.X(sat), ch.Y(0), ch.X(sat), ch.Y(model(sat, p.C, p.T).net), T.c4, 1.2, [3, 3]); D.text(g, '饱和点(95%)', ch.X(sat) + 3, ch.Y(model(sat, p.C, p.T).net) - 10, T.c4, { size: 10 }); }
        // 叶片与气体交换
        const lx = 30 + lw / 2, ly = c.h / 2; g.fillStyle = alpha('#5c9d2e', 0.75); g.beginPath(); g.ellipse(lx, ly, lw / 2 - 10, lw / 4, -0.3, 0, TAU); g.fill();
        D.circle(g, lx - 40, ly - 110, 18 + p.I / 60, `rgba(255,200,40,${0.3 + p.I / 2500})`); D.text(g, '光', lx - 40, ly - 110, T.fg, { align: 'center' });
        const k = clamp(Math.abs(m.net) / 25, 0.1, 1), inn = m.net >= 0;
        D.arrow(g, lx + (inn ? -80 : -20), ly + 60, lx + (inn ? -20 : -80), ly + 60, T.c1, 1 + 4 * k); D.text(g, 'CO₂', lx - 50, ly + 76, T.c1, { align: 'center', size: 12 });
        D.arrow(g, lx + (inn ? 20 : 80), ly + 60, lx + (inn ? 80 : 20), ly + 60, T.c2, 1 + 4 * k); D.text(g, 'O₂', lx + 50, ly + 76, T.c2, { align: 'center', size: 12 });
        out.set([['总光合速率', fmt(m.P, 2)], ['呼吸速率', fmt(m.R, 2)], ['净光合速率', fmt(m.net, 2)], ['光补偿点', comp ? fmt(comp, 0) : '无（呼吸大于最大光合）'], ['光饱和点（95%）', fmt(sat, 0)], ['气体交换', m.net > 0 ? '吸收 CO₂，释放 O₂' : m.net < 0 ? '吸收 O₂，释放 CO₂' : '无净交换']]);
      } else {
        const hrs = [...Array(241).keys()].map(i => i / 10), Imax = p.I, light = h => Math.max(0, Imax * Math.sin(PI * (h - 6) / 12));
        let co2 = 1000, series = [], nets = []; for (const h of hrs) { const n = model(light(h), p.C * co2 / 1000, p.T).net; nets.push([h, n]); series.push([h, co2]); co2 = Math.max(80, co2 - n * 2.4); }
        const gh = (c.h - 90) / 2;
        const ch = D.chart(g, 50, 30, c.w - 80, gh, [{ pts: series, color: T.c1, w: 2.4 }], { title: '密闭容器内 CO₂ 浓度（相对）', xl: '时刻 / h', xmin: 0, xmax: 24 });
        const ch2 = D.chart(g, 50, 60 + gh, c.w - 80, gh, [{ pts: nets, color: T.c3, w: 2.2 }, { pts: hrs.map(h => [h, light(h) / Imax * 10]), color: alpha(T.c4, 0.8), w: 1.4, dash: [4, 3] }], { title: '净光合速率（实线）与光照（虚线）', xl: '时刻 / h', xmin: 0, xmax: 24, ymin: Math.min(-5, ...nets.map(q => q[1])), ymax: Math.max(10, ...nets.map(q => q[1])) * 1.1 });
        const ext = []; for (let i = 1; i < nets.length; i++) if (nets[i - 1][1] * nets[i][1] < 0) ext.push(nets[i][0]);
        ext.forEach(h => { D.line(g, ch.X(h), 30, ch.X(h), 60 + 2 * gh, T.c2, 1, [3, 3]); D.text(g, fmt(h, 1) + ' 时', ch.X(h) + 3, 44, T.c2, { size: 10 }); });
        for (let h = 0; h <= 24; h += 6) D.text(g, h, ch2.X(h), 70 + 2 * gh, T.muted, { align: 'center', size: 10, mono: true });
        const d = series[series.length - 1][1] - series[0][1];
        out.set([['光合 = 呼吸的时刻', ext.map(h => fmt(h, 1) + ' 时').join('、') || '无'], ['CO₂ 最低点', ext[1] ? fmt(ext[1], 1) + ' 时' : '—'], ['24 时 − 0 时 CO₂', fmt(d, 0)], ['一昼夜有机物', d < 0 ? '积累（植物能生长）' : '减少（植物不能生长）']]);
      }
    });
  }
});

/* ---------- 细胞分裂（有丝 / 减数） ---------- */
function cellDivision(L, startMode) {
  const c = L.canvas();
  const MIT = ['间期', '前期', '中期', '后期', '末期', '子细胞'];
  const MEI = ['减Ⅰ 前期', '减Ⅰ 中期', '减Ⅰ 后期', '减Ⅰ 末期', '减Ⅱ 前期', '减Ⅱ 中期', '减Ⅱ 后期', '减Ⅱ 末期'];
  // [染色体数, 核 DNA 数, 染色单体数, 同源染色体对数]（2n = 4）
  const CNT = { mit: [[4, '4→8', '0→8', 2], [4, 8, 8, 2], [4, 8, 8, 2], [8, 8, 0, 4], [4, 4, 0, 2], [4, 4, 0, 2]], mei: [[4, 8, 8, 2], [4, 8, 8, 2], [4, 8, 8, 2], [2, 4, 4, 0], [2, 4, 4, 0], [2, 4, 4, 0], [4, 4, 0, 0], [2, 2, 0, 0]] };
  const DNA = { mit: [[0, 4], [0.5, 8], [1, 8], [2, 8], [3, 8], [4, 8], [4.5, 4], [5, 4]], mei: [[0, 8], [3, 8], [3.5, 4], [6, 4], [6.5, 2], [7, 2]] };
  let mode = startMode, stage = 0, orient = [0, 1], cross = false;
  L.group('分裂方式');
  const ms = L.seg('', [['mit', '有丝分裂'], ['mei', '减数分裂']], startMode, m => { mode = m; stage = 0; sl.setRange(0, (m === 'mit' ? MIT : MEI).length - 1); sl.set(0, true); L.draw(); });
  L.group('时期');
  const sl = L.slider('时期', 0, (startMode === 'mit' ? MIT : MEI).length - 1, 1, 0, v => { stage = v; L.draw(); }, v => (mode === 'mit' ? MIT : MEI)[v]);
  let play = null; L.button('上一期', () => sl.set(Math.max(0, stage - 1))); L.button('下一期', () => sl.set(Math.min((mode === 'mit' ? MIT : MEI).length - 1, stage + 1)), true); L.button('自动播放', b => { play.toggle(); b.setAttribute('aria-pressed', play.running); });
  const cr = L.check('减数分裂中发生交叉互换', false, v => { cross = v; L.draw(); });
  L.button('换一种非同源染色体组合', () => { orient = [Math.random() < 0.5 ? 0 : 1, Math.random() < 0.5 ? 0 : 1]; L.draw(); });
  const out = L.out();
  let acc = 0; play = L.loop(dt => { acc += dt; if (acc > 1.6) { acc = 0; const n = (mode === 'mit' ? MIT : MEI).length; sl.set((stage + 1) % n); } }, false);
  void cr; void ms;
  const RED = '#d6453d', BLUE = '#3b6fd8';
  L.onDraw(() => {
    c.clear(); const g = c.g, cw = c.w * 0.62, R = Math.min(cw * 0.36, c.h * 0.36), CX = cw / 2 + 10, CY = c.h / 2;
    const lenA = R * 0.34, lenB = R * 0.2, wd = Math.max(4, R * 0.055);
    const bar = (x, y, len, ang, col, tip) => {
      const dx = Math.cos(ang) * len / 2, dy = Math.sin(ang) * len / 2; g.lineCap = 'round';
      D.line(g, x - dx, y - dy, x + dx, y + dy, col, wd);
      if (tip) D.line(g, x + dx * 0.35, y + dy * 0.35, x + dx, y + dy, tip, wd);
    };
    const X = (x, y, len, ang, col, tips = []) => { const nx = -Math.sin(ang) * wd * 0.55, ny = Math.cos(ang) * wd * 0.55; bar(x - nx, y - ny, len, ang, col, tips[0]); bar(x + nx, y + ny, len, ang, col, tips[1]); D.circle(g, x, y, wd * 0.55, T.fg); };
    const cell = (x, y, r, ry) => { g.beginPath(); g.ellipse(x, y, r, ry || r, 0, 0, TAU); g.fillStyle = alpha('#f4c7b0', T.dark ? 0.12 : 0.35); g.fill(); g.strokeStyle = T.fg; g.lineWidth = 1.8; g.stroke(); };
    const spindle = (x1, y1, x2, y2, targets) => { D.circle(g, x1, y1, 3, T.fg); D.circle(g, x2, y2, 3, T.fg); targets.forEach(([tx, ty, side]) => { if (side <= 0) D.line(g, x1, y1, tx, ty, alpha(T.muted, 0.6), 0.8); if (side >= 0) D.line(g, x2, y2, tx, ty, alpha(T.muted, 0.6), 0.8); }); };
    const chromo = [['A', 0], ['A', 1], ['B', 0], ['B', 1]], colOf = par => par ? BLUE : RED, lenOf = k => k === 'A' ? lenA : lenB;
    const tipFor = (k, par, side) => cross && k === 'A' ? (side === (par ? 0 : 1) ? colOf(1 - par) : null) : null;
    const s = stage;
    if (mode === 'mit') {
      if (s <= 3) cell(CX, CY, R);
      if (s === 0) { g.setLineDash([]); D.circle(g, CX, CY, R * 0.45, alpha(T.c5, 0.08), T.fg, 1.2); chromo.forEach(([k, par], i) => { g.strokeStyle = colOf(par); g.lineWidth = 2; g.beginPath(); for (let j = 0; j < 30; j++) { const a = i * 1.7 + j * 0.35, r = R * (0.08 + 0.3 * (j / 30)); g.lineTo(CX + r * Math.cos(a) + Math.sin(j) * 4, CY + r * Math.sin(a)); } g.stroke(); }); D.text(g, '染色质', CX, CY + R * 0.6, T.muted, { align: 'center', size: 12 }); }
      if (s === 1) { g.setLineDash([5, 6]); D.circle(g, CX, CY, R * 0.5, null, T.muted, 1.2); g.setLineDash([]); spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, []); chromo.forEach(([k, par], i) => X(CX + [-0.2, 0.18, -0.05, 0.25][i] * R, CY + [-0.2, 0.15, 0.25, -0.25][i] * R, lenOf(k), [0.4, 1.9, 2.6, 1][i], colOf(par))); D.text(g, '核膜、核仁消失，出现染色体和纺锤体', CX, CY + R + 20, T.muted, { align: 'center', size: 12 }); }
      if (s === 2) { const ys = [-0.45, -0.15, 0.15, 0.45]; spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, ys.map(y => [CX, CY + y * R, 0])); D.line(g, CX, CY - R * 0.8, CX, CY + R * 0.8, alpha(T.c4, 0.6), 1, [4, 4]); chromo.forEach(([k, par], i) => X(CX, CY + ys[i] * R, lenOf(k), PI / 2 + 0.0, colOf(par))); D.text(g, '着丝粒排列在赤道板上', CX, CY + R + 20, T.muted, { align: 'center', size: 12 }); }
      if (s === 3) { const ys = [-0.45, -0.15, 0.15, 0.45]; spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, []); chromo.forEach(([k, par], i) => { [-1, 1].forEach(sd => { const x = CX + sd * R * 0.5, y = CY + ys[i] * R * 0.7; D.line(g, CX + sd * R * 0.9, CY, x, y, alpha(T.muted, 0.6), 0.8); bar(x + sd * lenOf(k) * 0.3, y, lenOf(k) * 0.9, 0.0, colOf(par)); D.circle(g, x, y, wd * 0.5, T.fg); }); }); D.text(g, '着丝粒分裂，姐妹染色单体分开，移向两极', CX, CY + R + 20, T.muted, { align: 'center', size: 12 }); }
      if (s >= 4) {
        const off = s === 4 ? R * 0.55 : R * 0.75, rr = s === 4 ? R * 0.62 : R * 0.6;
        [-1, 1].forEach(sd => { cell(CX + sd * off, CY, rr, s === 4 ? R * 0.85 : rr); D.circle(g, CX + sd * off, CY, rr * 0.45, alpha(T.c5, 0.08), T.fg, 1); chromo.forEach(([k, par], i) => bar(CX + sd * off + [-0.12, 0.1, -0.05, 0.12][i] * rr, CY + [-0.15, 0.12, 0.2, -0.2][i] * rr, lenOf(k) * 0.6, [0.3, 1.2, 2, 2.6][i], colOf(par))); });
        D.text(g, s === 4 ? '细胞膜从中部向内凹陷（动物细胞），核膜重新出现' : '两个子细胞染色体组成与亲代完全相同', CX, CY + R + 20, T.muted, { align: 'center', size: 12 });
      }
    } else {
      const [oa, ob] = orient;
      if (s <= 2) cell(CX, CY, R);
      if (s === 0) { D.circle(g, CX, CY, R * 0.55, null, alpha(T.muted, 0.6), 1, [4, 4]); [['A', -0.15, -0.2], ['B', 0.2, 0.2]].forEach(([k, x, y]) => { X(CX + x * R - wd * 1.3, CY + y * R, lenOf(k), 1.2, RED, [null, tipFor(k, 0, 1)]); X(CX + x * R + wd * 1.3, CY + y * R, lenOf(k), 1.2, BLUE, [tipFor(k, 1, 0), null]); }); D.text(g, '同源染色体联会，形成 2 个四分体' + (cross ? '，非姐妹染色单体交叉互换' : ''), CX, CY + R + 20, T.muted, { align: 'center', size: 12 }); }
      if (s === 1) { D.line(g, CX, CY - R * 0.8, CX, CY + R * 0.8, alpha(T.c4, 0.6), 1, [4, 4]); spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, [[CX - R * 0.1, CY - R * 0.3, -1], [CX + R * 0.1, CY - R * 0.3, 1], [CX - R * 0.1, CY + R * 0.3, -1], [CX + R * 0.1, CY + R * 0.3, 1]]); [['A', -0.3, oa], ['B', 0.3, ob]].forEach(([k, y, o]) => { X(CX - R * 0.1, CY + y * R, lenOf(k), PI / 2, colOf(o), [o ? tipFor(k, 1, 0) : null, o ? null : tipFor(k, 0, 1)]); X(CX + R * 0.1, CY + y * R, lenOf(k), PI / 2, colOf(1 - o), [o ? null : tipFor(k, 1, 0), o ? tipFor(k, 0, 1) : null]); }); D.text(g, '同源染色体成对排列在赤道板两侧', CX, CY + R + 20, T.muted, { align: 'center', size: 12 }); }
      if (s === 2) { spindle(CX - R * 0.9, CY, CX + R * 0.9, CY, []); [['A', -0.3, oa], ['B', 0.3, ob]].forEach(([k, y, o]) => { X(CX - R * 0.55, CY + y * R, lenOf(k), 1.0, colOf(o)); X(CX + R * 0.55, CY + y * R, lenOf(k), 2.1, colOf(1 - o)); }); D.text(g, '同源染色体分离，非同源染色体自由组合', CX, CY + R + 20, T.muted, { align: 'center', size: 12 }); }
      const cellsII = s >= 3 && s <= 6;
      if (cellsII) {
        const off = R * 0.62, rr = R * 0.5;
        [-1, 1].forEach(sd => {
          const ox = CX + sd * off, set = [['A', sd < 0 ? oa : 1 - oa], ['B', sd < 0 ? ob : 1 - ob]];
          cell(ox, CY, rr, s === 3 ? R * 0.8 : rr * 1.15);
          if (s === 3 || s === 4) set.forEach(([k, par], i) => X(ox + (i ? 0.15 : -0.15) * rr, CY + (i ? 0.25 : -0.25) * rr, lenOf(k), 0.6 + i, colOf(par)));
          if (s === 5) { spindle(ox, CY - rr * 1.05, ox, CY + rr * 1.05, set.map((_, i) => [ox + (i ? 0.25 : -0.25) * rr, CY, 0])); set.forEach(([k, par], i) => X(ox + (i ? 0.25 : -0.25) * rr, CY, lenOf(k) * 0.9, 0, colOf(par))); }
          if (s === 6) set.forEach(([k, par], i) => [-1, 1].forEach(v => { const x = ox + (i ? 0.25 : -0.25) * rr, y = CY + v * rr * 0.6; bar(x, y - v * lenOf(k) * 0.3, lenOf(k) * 0.8, PI / 2, colOf(par)); D.circle(g, x, y, wd * 0.5, T.fg); }));
        });
        D.text(g, ['减Ⅰ 结束：形成 2 个子细胞，染色体数目减半', '减Ⅱ 前期：无同源染色体', '减Ⅱ 中期：着丝粒排列在赤道板上', '减Ⅱ 后期：着丝粒分裂，姐妹染色单体分开'][s - 3], CX, CY + R + 20, T.muted, { align: 'center', size: 12 });
      }
      if (s === 7) {
        const rr = R * 0.42; [[-1, -1], [-1, 1], [1, -1], [1, 1]].forEach(([sx, sy], j) => {
          const ox = CX + sx * R * 0.55, oy = CY + sy * R * 0.52, half = sx < 0 ? 0 : 1, set = [['A', half ? 1 - oa : oa], ['B', half ? 1 - ob : ob]];
          cell(ox, oy, rr); D.circle(g, ox, oy, rr * 0.5, alpha(T.c5, 0.08), T.fg, 1);
          set.forEach(([k, par], i) => { const tip = cross && k === 'A' && (j % 2 === 1) ? colOf(1 - par) : null; bar(ox + (i ? 0.15 : -0.15) * rr, oy, lenOf(k) * 0.75, PI / 2 + (i ? 0.3 : -0.3), colOf(par), tip); });
        });
        D.text(g, '形成 4 个子细胞（精细胞），染色体数目为体细胞的一半', CX, CY + R + 26, T.muted, { align: 'center', size: 12 });
      }
    }
    // 右侧：DNA 含量曲线
    const gx = cw + 20, gw = c.w - gx - 16, names = mode === 'mit' ? MIT : MEI;
    if (gw > 120) {
      const pts = DNA[mode], xmax = mode === 'mit' ? 5 : 7, ch = D.chart(g, gx, 30, gw, c.h * 0.45, [{ pts, color: T.c1, w: 2.2 }], { title: '每个细胞核 DNA 含量（2n = 4）', xmin: 0, xmax, ymin: 0, ymax: 9 });
      const xs = mode === 'mit' ? [0.25, 1.5, 2.5, 3.5, 4.25, 4.8] : [0.5, 1.5, 2.5, 3.25, 4.5, 5.5, 6.25, 6.8];
      D.line(g, ch.X(xs[s]), 30, ch.X(xs[s]), 30 + c.h * 0.45, T.c2, 1.5, [4, 3]);
      names.forEach((n, i) => D.text(g, n.replace('减', ''), ch.X(xs[i]), 30 + c.h * 0.45 + 12 + (i % 2) * 12, i === s ? T.c2 : T.muted, { align: 'center', size: 9.5 }));
    }
    const k = CNT[mode][s];
    out.set([['时期', names[s]], ['染色体数', k[0]], ['核 DNA 分子数', k[1]], ['染色单体数', k[2]], ['同源染色体对数', k[3]], mode === 'mei' && s <= 1 ? ['四分体数', 2] : null, ['图例', '<span style="color:#d6453d">■</span> 来自母方　<span style="color:#3b6fd8">■</span> 来自父方']]);
  });
}
Lab.reg({
  id: 'b-mitosis', subj: 'bio', book: 0, unit: '细胞的生命历程', title: '有丝分裂各时期', kw: '有丝分裂 间期 前期 中期 后期 末期 染色体 染色单体 DNA 纺锤体 赤道板',
  info: `<p>以 2n = 4 的动物细胞为例。红色、蓝色分别表示来自母方和父方的染色体，长、短两种形态代表两对同源染色体。</p>
  <p class="fb">间期：DNA 复制和有关蛋白质合成（DNA 加倍，染色体数不变）<br>前期：膜仁消失显两体　中期：形数清晰赤道齐<br>后期：点裂数增均两极　末期：两消两现重开始</p>
  <p>有丝分裂的意义：亲代细胞的染色体经复制后精确地平均分配到两个子细胞中，保持了遗传性状的稳定性。</p>`,
  tasks: ['在哪个时期染色体数目加倍？加倍的原因是什么？', '染色单体在哪个时期形成、哪个时期消失？', '观察右侧曲线：核 DNA 含量在哪两个时期发生变化？'],
  init(L) { cellDivision(L, 'mit'); }
});
Lab.reg({
  id: 'b-meiosis', subj: 'bio', book: 1, unit: '基因和染色体的关系', title: '减数分裂与配子形成', kw: '减数分裂 联会 四分体 交叉互换 同源染色体分离 自由组合 精子 卵细胞',
  info: `<p>减数分裂中染色体只复制一次，而细胞连续分裂两次，结果子细胞中染色体数目减半。</p>
  <p class="fb">减Ⅰ：同源染色体联会 → 四分体 → 同源染色体分离、非同源染色体自由组合（染色体数目减半发生在减Ⅰ）<br>减Ⅱ：着丝粒分裂，姐妹染色单体分开（类似有丝分裂）</p>
  <p>点击「换一种非同源染色体组合」观察减Ⅰ 中期的不同排列方式：含 n 对同源染色体的个体，理论上可产生 2ⁿ 种配子；但一个精原细胞只能产生 4 个、2 种精细胞（不考虑交叉互换）。勾选交叉互换后，同一个精原细胞可以产生 4 种精细胞。</p>`,
  tasks: ['同源染色体在哪个时期分离？着丝粒在哪个时期分裂？', '2n = 4 的个体，不考虑交叉互换能产生几种配子？', '勾选交叉互换后，减Ⅱ 末期 4 个精细胞的染色体组成有何不同？'],
  init(L) { cellDivision(L, 'mei'); }
});

/* ---------- 孟德尔遗传 ---------- */
Lab.reg({
  id: 'b-mendel', subj: 'bio', book: 1, unit: '遗传因子的发现 · 伴性遗传', title: '分离定律、自由组合定律与伴性遗传', kw: '孟德尔 分离定律 自由组合定律 棋盘法 基因型 表型 性状分离比 伴X隐性 色盲',
  info: `<p class="fb">分离定律：Aa × Aa → AA : Aa : aa = 1 : 2 : 1，显性 : 隐性 = 3 : 1<br>自由组合定律：YyRr × YyRr → 9 : 3 : 3 : 1；测交 YyRr × yyrr → 1 : 1 : 1 : 1<br>伴 X 隐性遗传（红绿色盲）：男性患者多于女性；女病父子病；交叉遗传</p>
  <p>棋盘中每格是一种受精组合，颜色表示表型。点「随机产生后代」可以看到实际统计数与理论比例的偏差。</p>`,
  tasks: ['设两对基因均为杂合（YyRr × YyRr），验证 9 : 3 : 3 : 1。', '做测交：YyRr × yyrr，比例是多少？', '伴性遗传：携带者母亲 × 正常父亲，儿子患病的概率是多少？'],
  init(L) {
    const c = L.canvas(); L.tall();
    L.group('遗传方式');
    const mode = L.seg('', [['auto', '常染色体'], ['x', '伴 X 隐性（色盲）']], 'auto', () => { sync(); sim = null; L.draw(); });
    const G = L.group('亲本基因型');
    const n = L.slider('相对性状对数', 1, 3, 1, 2, () => { sync(); sim = null; L.draw(); });
    const genes = [['Y', 'y', '黄色', '绿色', '子叶'], ['R', 'r', '圆粒', '皱粒', '种子'], ['D', 'd', '高茎', '矮茎', '茎']];
    const pm = [], pf = [];
    genes.forEach(([A, a], i) => { pm.push(L.select(`♀ 第 ${i + 1} 对`, [A + A, A + a, a + a], A + a, () => { sim = null; L.draw(); })); pf.push(L.select(`♂ 第 ${i + 1} 对`, [A + A, A + a, a + a], A + a, () => { sim = null; L.draw(); })); });
    const GX = L.group('伴 X 遗传'); GX.hidden = true;
    const xm = L.select('♀ 母亲', [['BB', 'XᴮXᴮ 正常'], ['Bb', 'XᴮXᵇ 携带者'], ['bb', 'XᵇXᵇ 色盲']], 'Bb', () => { sim = null; L.draw(); });
    const xf = L.select('♂ 父亲', [['B', 'XᴮY 正常'], ['b', 'XᵇY 色盲']], 'B', () => { sim = null; L.draw(); });
    L.group('统计');
    L.button('随机产生 100 个后代', () => { simulate(100); }, true); L.button('1000 个', () => simulate(1000));
    const out = L.out();
    let sim = null;
    function sync() { const x = mode.v === 'x'; G.hidden = x; GX.hidden = !x; pm.forEach((s, i) => { s.el.parentElement.hidden = i >= n.v; pf[i].el.parentElement.hidden = i >= n.v; }); }
    sync();
    function gametes(sels) { let gs = ['']; sels.slice(0, n.v).forEach(s => { const al = [...new Set(s.v.split(''))]; const al2 = s.v[0] === s.v[1] ? [s.v[0]] : s.v.split(''); void al; gs = gs.flatMap(gm => al2.map(x => gm + x)); }); return gs.map(x => [x, 1 / gs.length]).reduce((acc, [x, p]) => { const f = acc.find(q => q[0] === x); f ? f[1] += p : acc.push([x, p]); return acc; }, []); }
    function cross() {
      if (mode.v === 'x') {
        const mg = xm.v === 'BB' ? [['Xᴮ', 1]] : xm.v === 'bb' ? [['Xᵇ', 1]] : [['Xᴮ', 0.5], ['Xᵇ', 0.5]], fg = [[xf.v === 'B' ? 'Xᴮ' : 'Xᵇ', 0.5], ['Y', 0.5]];
        const ph = (a, b) => b === 'Y' ? (a === 'Xᵇ' ? '色盲男性' : '正常男性') : (a === 'Xᵇ' && b === 'Xᵇ' ? '色盲女性' : a === 'Xᵇ' || b === 'Xᵇ' ? '携带者女性' : '正常女性');
        return { mg, fg, geno: (a, b) => b === 'Y' ? a + 'Y' : [a, b].sort().join(''), ph };
      }
      const mg = gametes(pm), fg = gametes(pf);
      const geno = (a, b) => a.split('').map((x, i) => [x, b[i]].sort((u, v) => (u === u.toUpperCase() ? 0 : 1) - (v === v.toUpperCase() ? 0 : 1)).join('')).join('');
      const ph = (a, b) => a.split('').map((x, i) => (x === x.toUpperCase() || b[i] === b[i].toUpperCase()) ? genes[i][2] : genes[i][3]).join('');
      return { mg, fg, geno, ph };
    }
    function simulate(N) { const { mg, fg, ph } = cross(), pick = arr => { let r = Math.random(); for (const [x, p] of arr) { if ((r -= p) <= 0) return x; } return arr[arr.length - 1][0]; }; const cnt = {}; for (let i = 0; i < N; i++) { const k = ph(pick(mg), pick(fg)); cnt[k] = (cnt[k] || 0) + 1; } sim = { N, cnt }; L.draw(); }
    L.onDraw(() => {
      c.clear(); const g = c.g, { mg, fg, geno, ph } = cross();
      const phs = {}, gts = {}; mg.forEach(([a, pa]) => fg.forEach(([b, pb]) => { const k = ph(a, b), gt = geno(a, b); phs[k] = (phs[k] || 0) + pa * pb; gts[gt] = (gts[gt] || 0) + pa * pb; }));
      const keys = Object.keys(phs).sort((a, b) => phs[b] - phs[a]), colOf = k => T.c[keys.indexOf(k) % 6];
      const m = mg.length, f = fg.length, size = Math.min((c.w * 0.62 - 60) / (f + 1), (c.h - 60) / (m + 1), 90), ox = 20, oy = 20;
      D.text(g, '♀ \\ ♂', ox + size / 2, oy + size / 2, T.muted, { align: 'center', size: 12 });
      fg.forEach(([b], j) => D.text(g, b, ox + (j + 1.5) * size, oy + size / 2, T.c2, { align: 'center', bold: true, size: Math.min(16, size * 0.3) }));
      mg.forEach(([a], i) => {
        D.text(g, a, ox + size / 2, oy + (i + 1.5) * size, T.c1, { align: 'center', bold: true, size: Math.min(16, size * 0.3) });
        fg.forEach(([b], j) => { const x = ox + (j + 1) * size, y = oy + (i + 1) * size, k = ph(a, b); D.rect(g, x + 1, y + 1, size - 2, size - 2, alpha(colOf(k), 0.35), T.line, 1); D.text(g, geno(a, b), x + size / 2, y + size / 2, T.fg, { align: 'center', size: Math.min(14, size * 0.24), mono: true }); });
      });
      const gx = c.w * 0.64, gw = c.w - gx - 20;
      const den = Math.min(...Object.values(phs)); let y = 30;
      D.text(g, '表型比例', gx, y, T.muted, { size: 12 }); y += 22;
      keys.forEach(k => { const w = phs[k] * gw; D.rect(g, gx, y - 9, w, 18, alpha(colOf(k), 0.6)); D.text(g, `${k}  ${fmt(phs[k] / den, 2)}（${fmt(phs[k] * 100, 2)}%）`, gx + 4, y, T.fg, { size: 12 }); if (sim) D.text(g, `实际 ${sim.cnt[k] || 0}/${sim.N}`, gx + gw, y, T.muted, { size: 11, align: 'right', mono: true }); y += 26; });
      out.set([['♀ 配子种类', m + ' 种'], ['♂ 配子种类', f + ' 种'], ['受精组合', m * f + ' 种'], ['基因型种类', Object.keys(gts).length], ['表型种类', keys.length], ['表型比', keys.map(k => fmt(phs[k] / den, 2)).join(' : ')]]);
    });
  }
});

/* ---------- 中心法则 ---------- */
const CODON = 'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG';
const AA = { F: '苯丙', L: '亮', I: '异亮', M: '甲硫', V: '缬', S: '丝', P: '脯', T: '苏', A: '丙', Y: '酪', H: '组', Q: '谷酰胺', N: '天冬酰胺', K: '赖', D: '天冬', E: '谷', C: '半胱', W: '色', R: '精', G: '甘' };
const aaName = a => AA[a] + (a === 'Q' || a === 'N' ? '' : '氨酸');
function translate(mrna) {
  const st = mrna.indexOf('AUG'); if (st < 0) return { start: -1, aa: [], stop: false };
  const aa = []; let stop = false, i = st;
  for (; i + 3 <= mrna.length; i += 3) { const cd = mrna.slice(i, i + 3), k = 'UCAG'.indexOf(cd[0]) * 16 + 'UCAG'.indexOf(cd[1]) * 4 + 'UCAG'.indexOf(cd[2]), a = CODON[k]; if (a === '*') { stop = true; break; } aa.push(a); }
  return { start: st, aa, stop, end: i };
}
Lab.reg({
  id: 'b-dogma', subj: 'bio', book: 1, unit: '基因的表达 · 基因突变', title: '转录、翻译与基因突变', kw: '中心法则 转录 翻译 mRNA tRNA 密码子 反密码子 核糖体 基因突变 替换 插入 缺失 移码',
  info: `<p>输入 DNA 的<b>编码链</b>（非模板链，5′→3′）。以另一条<b>模板链</b>为模板，按碱基互补配对原则（A−U、T−A、G−C、C−G）转录出 mRNA；mRNA 上每 3 个相邻碱基构成一个密码子，从起始密码子 AUG 开始翻译，到终止密码子（UAA、UAG、UGA）结束。</p>
  <p class="fb">DNA → RNA → 蛋白质　碱基数 : 氨基酸数 = 6 : 3 : 1（不考虑终止密码子）</p>
  <p><b>基因突变</b>：碱基替换可能不改变氨基酸（密码子简并性），也可能改变一个氨基酸或提前出现终止密码子；插入或缺失一个碱基会造成移码，影响其后所有氨基酸。</p>`,
  tasks: ['把第 6 位的 T 替换为 C，氨基酸序列变了吗？为什么？', '在第 4 位插入一个碱基，比较突变前后的蛋白质。', '找到一处替换，使蛋白质提前终止（无义突变）。'],
  init(L) {
    const c = L.canvas();
    let dna0 = 'ATGGCTAGCAAAGAATTCCTGTGGTAA', dna = dna0;
    L.group('DNA 编码链（5′→3′）');
    const inp = L.input('', dna0, s => { const v = s.toUpperCase().replace(/[^ATCG]/g, ''); if (!v) { inp.err('只能输入 A T C G'); return; } inp.err(''); dna0 = dna = v; pos.setRange(1, dna.length); rib = 0; L.draw(); });
    L.group('基因突变');
    const pos = L.slider('位置', 1, dna0.length, 1, 6);
    const typ = L.select('类型', [['sub', '替换'], ['ins', '插入'], ['del', '缺失']], 'sub');
    const base = L.select('碱基', ['A', 'T', 'C', 'G'], 'C');
    L.button('施加突变', () => { const i = pos.v - 1; dna = typ.v === 'sub' ? dna.slice(0, i) + base.v + dna.slice(i + 1) : typ.v === 'ins' ? dna.slice(0, i) + base.v + dna.slice(i) : dna.slice(0, i) + dna.slice(i + 1); rib = 0; L.draw(); }, true);
    L.button('恢复原序列', () => { dna = dna0; rib = 0; L.draw(); });
    const out = L.out();
    let rib = 0;
    L.loop(dt => { rib += dt * 1.2; L.drawFn(); });
    const comp = { A: 'T', T: 'A', C: 'G', G: 'C' }, colB = b => ({ A: T.c2, T: T.c4, U: T.c5, C: T.c1, G: T.c3 })[b];
    L.onDraw(() => {
      c.clear(); const g = c.g, n = dna.length, bw = Math.min(26, (c.w - 90) / Math.max(n, 1)), x0 = 70;
      const tmpl = dna.split('').map(b => comp[b]).join(''), mrna = dna.replace(/T/g, 'U');
      const row = (s, y, lab, sub) => { D.text(g, lab, 8, y + bw / 2, T.muted, { size: 11 }); if (sub) D.text(g, sub, 8, y + bw / 2 + 13, T.muted, { size: 9.5 }); s.split('').forEach((b, i) => { D.rect(g, x0 + i * bw + 1, y, bw - 2, bw, alpha(colB(b), 0.55)); if (bw > 11) D.text(g, b, x0 + i * bw + bw / 2, y + bw / 2, T.fg, { align: 'center', bold: true, size: Math.min(13, bw * 0.55), mono: true }); }); };
      row(dna, 20, '编码链', "5′→3′"); row(tmpl, 22 + bw, '模板链', "3′→5′");
      for (let i = 0; i < n; i++) D.line(g, x0 + i * bw + bw / 2, 20 + bw, x0 + i * bw + bw / 2, 22 + bw, T.muted, 1);
      if (dna !== dna0) { const i = pos.v - 1; D.rect(g, x0 + i * bw, 17, bw, 2 * bw + 8, null, T.bad, 2); }
      const my = 50 + 3 * bw; D.arrow(g, 30, 30 + 2 * bw, 30, my - 4, T.muted, 1.4); D.text(g, '转录', 36, (30 + 2 * bw + my) / 2, T.muted, { size: 11 });
      row(mrna, my, 'mRNA', "5′→3′");
      const tr = translate(mrna);
      if (tr.start >= 0) {
        const nCod = tr.aa.length + (tr.stop ? 1 : 0), k = Math.floor(rib % (nCod + 3)), shown = Math.min(k, tr.aa.length);
        for (let j = 0; j < nCod; j++) { const x = x0 + (tr.start + 3 * j) * bw; D.line(g, x, my + bw + 2, x + 3 * bw - 2, my + bw + 2, j === tr.aa.length ? T.bad : T.c5, 2); }
        if (k < nCod) {
          const rx = x0 + (tr.start + 3 * k) * bw - 8, ry = my - 16; D.rrect(g, rx, ry, 3 * bw + 16, bw + 34, 14, alpha(T.c4, 0.25), T.c4, 1.5);
          if (k < tr.aa.length) { const cd = mrna.slice(tr.start + 3 * k, tr.start + 3 * k + 3), anti = cd.split('').map(b => ({ A: 'U', U: 'A', C: 'G', G: 'C' })[b]).join(''); D.text(g, 'tRNA 反密码子 ' + anti, rx + 4, my + bw + 30, T.muted, { size: 11 }); }
        }
        const py = my + bw + 60;
        for (let j = 0; j < shown; j++) { const x = x0 + 20 + j * 46, y = py + 20; if (j) D.line(g, x - 46, y, x, y, T.muted, 2); D.circle(g, x, y, 17, alpha(T.c[('FLIMVSPTAYHQNKDECWRG'.indexOf(tr.aa[j])) % 6], 0.6), T.fg, 1); D.text(g, AA[tr.aa[j]].slice(0, 2), x, y, T.fg, { align: 'center', size: 11 }); }
        D.text(g, '肽链：', 8, py + 20, T.muted, { size: 11 });
      } else D.text(g, '没有找到起始密码子 AUG', x0, my + bw + 40, T.bad);
      const t0 = translate(dna0.replace(/T/g, 'U')), seq = a => a.map(aaName).join('—') || '（无）';
      let kind = '无突变';
      if (dna !== dna0) {
        if (dna.length !== dna0.length) kind = (Math.abs(dna.length - dna0.length) % 3 ? '移码突变：' : '插入/缺失 3 的倍数个碱基：') + '影响之后的氨基酸序列';
        else if (tr.aa.join('') === t0.aa.join('')) kind = '同义突变：氨基酸序列不变（密码子简并性）';
        else if (tr.aa.length < t0.aa.length && tr.stop && t0.aa.slice(0, tr.aa.length).join('') === tr.aa.join('')) kind = '无义突变：提前出现终止密码子，肽链变短';
        else kind = '错义突变：改变了氨基酸';
      }
      out.set([['mRNA', mrna], ['密码子', tr.start >= 0 ? mrna.slice(tr.start, tr.end + (tr.stop ? 3 : 0)).match(/.{1,3}/g).join(' ') : '—'], ['氨基酸数', tr.aa.length], ['原蛋白质', seq(t0.aa)], ['当前蛋白质', seq(tr.aa)], ['突变类型', kind]]);
    });
  }
});

/* ---------- 种群基因频率与进化 ---------- */
Lab.reg({
  id: 'b-hw', subj: 'bio', book: 1, unit: '生物的进化', title: '自然选择与遗传漂变', kw: '基因频率 基因型频率 遗传平衡 哈迪-温伯格 自然选择 遗传漂变 种群 适应 进化',
  info: `<p class="fb">基因频率 p + q = 1；遗传平衡时基因型频率 AA : Aa : aa = p² : 2pq : q²<br>遗传平衡条件：种群足够大、随机交配、没有迁入迁出、没有自然选择、没有突变</p>
  <p><b>生物进化的实质是种群基因频率的改变</b>。自然选择使有利基因频率定向升高；种群很小时，偶然因素造成的遗传漂变会使基因频率随机波动，甚至使某个基因丢失或固定。</p>
  <p>每条曲线是一个独立的种群，采用 Wright−Fisher 模型逐代随机抽样。</p>`,
  tasks: ['三种基因型适合度都为 1，种群大小 N = 5000，p 会变化吗？把 N 改为 20 再看。', '让 aa 的适合度为 0.5（不利于隐性纯合子），q 的下降速度如何？为什么很难彻底淘汰 a？', '模拟桦尺蠖：设黑色（A_）适合度为 1，浅色（aa）为 0.7，观察 A 频率的变化。'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ p0: ['初始 A 基因频率 p₀', 0.01, 0.99, 0.01, 0.5], N: ['种群个体数 N', 10, 5000, 10, 500], wAA: ['AA 适合度', 0, 1, 0.05, 1], wAa: ['Aa 适合度', 0, 1, 0.05, 1], waa: ['aa 适合度', 0, 1, 0.05, 1], G: ['代数', 20, 300, 10, 150], R: ['种群数（重复）', 1, 8, 1, 5] }, () => run());
    L.button('重新模拟', () => run(), true);
    L.button('桦尺蠖情境', () => { p.$p0.set(0.05, true); p.$wAA.set(1, true); p.$wAa.set(1, true); p.$waa.set(0.7, true); p.N = 1000; });
    const out = L.out();
    let runs = [], shown = 0;
    function binom(n, q) { if (n < 600) { let k = 0; for (let i = 0; i < n; i++) if (Math.random() < q) k++; return k; } return clamp(Math.round(n * q + Math.sqrt(n * q * (1 - q)) * gauss()), 0, n); }
    function run() {
      runs = []; for (let r = 0; r < p.R; r++) { let x = p.p0; const tr = [[0, x]]; for (let gg = 1; gg <= p.G; gg++) { const y = 1 - x, wb = x * x * p.wAA + 2 * x * y * p.wAa + y * y * p.waa; const xs = wb > 0 ? (x * x * p.wAA + x * y * p.wAa) / wb : x; x = binom(2 * p.N, xs) / (2 * p.N); tr.push([gg, x]); } runs.push(tr); }
      shown = 0; L.draw();
    }
    run();
    L.loop(dt => { if (shown < p.G) { shown = Math.min(p.G, shown + dt * 60); L.drawFn(); } });
    L.onDraw(() => {
      c.clear(); const g = c.g, k = Math.floor(shown), gh = c.h - 120;
      D.chart(g, 50, 24, c.w - 80, gh, runs.map((tr, i) => ({ pts: tr.slice(0, k + 1), color: T.c[i % 6], w: 1.8 })), { title: 'A 基因频率 p − 代数', xl: '代数', xmin: 0, xmax: p.G, ymin: 0, ymax: 1 });
      const tr0 = runs[0], pr = tr0[clamp(k, 0, tr0.length - 1)][1], q = 1 - pr, by = c.h - 70, bw = (c.w - 100) / 3;
      [['AA', pr * pr], ['Aa', 2 * pr * q], ['aa', q * q]].forEach(([n2, f], i) => { const x = 50 + i * (bw + 10); D.rect(g, x, by, bw, 18, alpha(T.muted, 0.12)); D.rect(g, x, by, bw * f, 18, alpha(T.c[i], 0.7)); D.text(g, `${n2} ${fmt(f, 3)}`, x + 4, by + 9, T.fg, { size: 12 }); });
      D.text(g, '种群 1 当前的遗传平衡基因型频率（p²、2pq、q²）', 50, by - 12, T.muted, { size: 11 });
      const fin = runs.map(tr => tr[clamp(k, 0, tr.length - 1)][1]);
      out.set([['当前代数', k], ['各种群 p', fin.map(x => fmt(x, 2)).join(', ')], ['A 被固定', fin.filter(x => x === 1).length + ' 个种群'], ['A 丢失', fin.filter(x => x === 0).length + ' 个种群'], ['平均适合度 w̄（种群 1）', fmt(pr * pr * p.wAA + 2 * pr * q * p.wAa + q * q * p.waa, 3)]]);
    });
  }
});

/* ---------- 动作电位 ---------- */
Lab.reg({
  id: 'b-neuron', subj: 'bio', book: 2, unit: '神经调节', title: '神经纤维上的动作电位', kw: '静息电位 动作电位 钠离子 钾离子 通道 阈值 全或无 兴奋 去极化 复极化',
  info: `<p>采用 Hodgkin−Huxley 模型计算膜电位（膜内相对膜外）。</p>
  <p class="fb">静息电位：K⁺ 外流，外正内负（约 −65 ~ −70 mV）<br>动作电位：受刺激后 Na⁺ 通道打开，Na⁺ 内流，膜电位变为外负内正<br>恢复：Na⁺ 通道失活、K⁺ 通道打开，K⁺ 外流使膜电位恢复；钠钾泵维持离子浓度差</p>
  <p>刺激强度达到阈值才能产生动作电位，且动作电位的幅度不随刺激强度增大而增大（全或无）。降低膜外 Na⁺ 浓度，动作电位峰值降低；升高膜外 K⁺ 浓度，静息电位绝对值减小。</p>`,
  tasks: ['从小到大逐渐增加刺激强度，找出产生动作电位的阈值。', '把刺激强度加倍，动作电位的峰值变大吗？', '降低膜外 Na⁺ 浓度到 0.5 倍，峰值如何变化？阻断 Na⁺ 通道呢？'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ I: ['刺激强度', 0, 40, 0.5, 10, 'μA/cm²'], dur: ['刺激时长', 0.2, 5, 0.1, 1, 'ms'], na: ['膜外 Na⁺ 浓度（相对）', 0.2, 1.5, 0.05, 1], k: ['膜外 K⁺ 浓度（相对）', 0.5, 4, 0.1, 1] });
    const ttx = L.check('阻断 Na⁺ 通道（如河豚毒素）', false);
    L.button('给予刺激', () => { stimEnd = s.t + p.dur; }, true); L.button('连续刺激', b => { rep = !rep; b.setAttribute('aria-pressed', rep); });
    const out = L.out();
    let s = { t: 0, V: -65, m: 0.053, h: 0.596, n: 0.318 }, hist = [], stimEnd = -1, rep = false, peak = -65, lastStim = 0;
    const ex = (a, b) => Math.exp(a / b);
    function step(dt) {
      const { V } = s, an = Math.abs(V + 55) < 1e-6 ? 0.1 : 0.01 * (V + 55) / (1 - Math.exp(-(V + 55) / 10)), bn = 0.125 * ex(-(V + 65), 80);
      const am = Math.abs(V + 40) < 1e-6 ? 1 : 0.1 * (V + 40) / (1 - Math.exp(-(V + 40) / 10)), bm = 4 * ex(-(V + 65), 18), ah = 0.07 * ex(-(V + 65), 20), bh = 1 / (1 + Math.exp(-(V + 35) / 10));
      s.m += dt * (am * (1 - s.m) - bm * s.m); s.h += dt * (ah * (1 - s.h) - bh * s.h); s.n += dt * (an * (1 - s.n) - bn * s.n);
      const ENa = 50 + 25.7 * Math.log(p.na), EK = -77 + 25.7 * Math.log(p.k), gNa = ttx.v ? 0 : 120 * s.m ** 3 * s.h, gK = 36 * s.n ** 4;
      const Ist = s.t < stimEnd ? p.I : 0;
      s.V += dt * (Ist - gNa * (V - ENa) - gK * (V - EK) - 0.3 * (V + 54.387)); s.t += dt; s.gNa = gNa; s.gK = gK; s.Ist = Ist;
    }
    L.loop(dt => {
      const simT = dt * 10; for (let t = 0; t < simT; t += 0.01) step(0.01);
      if (rep && s.t - lastStim > 15) { stimEnd = s.t + p.dur; lastStim = s.t; }
      hist.push([s.t, s.V, s.gNa, s.gK, s.Ist]); while (hist.length && hist[0][0] < s.t - 50) hist.shift();
      peak = Math.max(...hist.map(q => q[1])); L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, gw = c.w - 80, gh = (c.h - 150) * 0.62, t0 = hist.length ? hist[0][0] : 0;
      const ch = D.chart(g, 50, 24, gw, gh, [{ pts: hist.map(q => [q[0], q[1]]), color: T.c2, w: 2.2 }], { title: '膜电位 V（mV）', xl: 't / ms', xmin: t0, xmax: Math.max(t0 + 50, s.t), ymin: -90, ymax: 60 });
      D.line(g, 50, ch.Y(0), 50 + gw, ch.Y(0), T.grid2, 1, [3, 3]); D.text(g, '0 mV', 46, ch.Y(0), T.muted, { size: 10, align: 'right' });
      hist.forEach(q => { if (q[4] > 0) D.line(g, ch.X(q[0]), 24 + gh - 6, ch.X(q[0]), 24 + gh, T.c4, 2); });
      const y2 = 40 + gh, gh2 = (c.h - 150) * 0.38;
      D.chart(g, 50, y2, gw, gh2, [{ pts: hist.map(q => [q[0], q[2]]), color: T.c1, w: 1.8 }, { pts: hist.map(q => [q[0], q[3]]), color: T.c3, w: 1.8 }], { title: '离子通道电导：蓝 Na⁺，绿 K⁺', xmin: t0, xmax: Math.max(t0 + 50, s.t), ymin: 0, ymax: 40 });
      // 膜示意
      const my = c.h - 60, mx0 = 50, mw = gw; D.rect(g, mx0, my - 8, mw, 16, alpha('#d9a441', 0.35));
      D.text(g, s.V > 0 ? '膜外 − − − −' : '膜外 + + + +', mx0, my - 22, T.muted, { size: 11 }); D.text(g, s.V > 0 ? '膜内 + + + +' : '膜内 − − − −', mx0, my + 22, T.muted, { size: 11 });
      const naO = clamp((s.gNa || 0) / 30, 0, 1), kO = clamp((s.gK || 0) / 25, 0, 1);
      for (let i = 0; i < 4; i++) { const x = mx0 + 160 + i * 120; D.rect(g, x, my - 10, 22, 20, alpha(T.c1, 0.3 + naO * 0.6)); D.text(g, 'Na⁺', x + 11, my, T.fg, { align: 'center', size: 9 }); if (naO > 0.2) D.arrow(g, x + 11, my - 30, x + 11, my + 30, T.c1, 1 + naO * 3); const x2 = x + 50; D.rect(g, x2, my - 10, 22, 20, alpha(T.c3, 0.3 + kO * 0.6)); D.text(g, 'K⁺', x2 + 11, my, T.fg, { align: 'center', size: 9 }); if (kO > 0.2) D.arrow(g, x2 + 11, my + 30, x2 + 11, my - 30, T.c3, 1 + kO * 3); }
      const dV = hist.length > 2 ? hist[hist.length - 1][1] - hist[hist.length - 3][1] : 0;
      const phase = s.V < -60 && Math.abs(dV) < 0.2 ? '静息电位' : dV > 0 && s.V > -60 ? '去极化（Na⁺ 内流）' : dV < 0 && s.V > -70 ? '复极化（K⁺ 外流）' : s.V < -66 ? '超极化' : '恢复中';
      out.set([['膜电位', fmt(s.V, 1) + ' mV'], ['所处阶段', phase], ['近 50 ms 峰值', fmt(peak, 1) + ' mV'], ['Na⁺ 平衡电位', fmt(50 + 25.7 * Math.log(p.na), 1) + ' mV'], ['K⁺ 平衡电位', fmt(-77 + 25.7 * Math.log(p.k), 1) + ' mV']]);
    });
  }
});

/* ---------- 血糖调节 ---------- */
Lab.reg({
  id: 'b-glucose', subj: 'bio', book: 2, unit: '体液调节', title: '血糖平衡的调节', kw: '血糖 胰岛素 胰高血糖素 胰岛 B 细胞 A 细胞 糖尿病 反馈调节',
  info: `<p class="fb">血糖正常范围：3.9 ~ 6.1 mmol/L（空腹）<br>胰岛素（胰岛 B 细胞分泌）：促进组织细胞摄取、利用和储存葡萄糖，抑制肝糖原分解和非糖物质转化 —— 唯一降血糖的激素<br>胰高血糖素（胰岛 A 细胞分泌）：促进肝糖原分解和非糖物质转化为葡萄糖 —— 升血糖</p>
  <p>血糖升高 → 胰岛素分泌增加 → 血糖下降，这是<b>负反馈调节</b>。1 型糖尿病主要因胰岛 B 细胞受损、胰岛素分泌不足；2 型糖尿病主要因靶细胞对胰岛素不敏感（胰岛素抵抗）。</p>`,
  tasks: ['正常人进食后，血糖与胰岛素的峰值哪个先出现？', '切换到 1 型糖尿病，进食后血糖如何变化？注射胰岛素有效吗？', '2 型糖尿病患者体内胰岛素水平一定低吗？'],
  init(L) {
    const c = L.canvas();
    const who = L.select('个体', [['n', '健康人'], ['t1', '1 型糖尿病（胰岛 B 细胞受损）'], ['t2', '2 型糖尿病（胰岛素抵抗）']], 'n');
    L.button('进食', () => meals.push(s.t), true); L.button('运动 1 小时', () => ex = s.t + 60); L.button('注射胰岛素', () => s.I += 4); L.button('长时间饥饿', () => fast = !fast);
    const out = L.out();
    let s = { t: 0, G: 5, I: 1, Gn: 0.5 }, meals = [], ex = -1, fast = false, hist = [];
    L.loop(dt => {
      const sim = dt * 8; // 1 秒 = 8 分钟
      for (let k = 0; k < 20; k++) {
        const h = sim / 20, beta = who.v === 't1' ? 0.08 : 1, Si = who.v === 't2' ? 0.004 : 0.01, exer = s.t < ex ? 1 : 0;
        const Ra = meals.reduce((a, t0) => { const u = s.t - t0; return u > 0 ? a + 25 * u / 900 * Math.exp(-u / 30) : a; }, 0) * (fast ? 0 : 1);
        const EGP = 0.05 * (1 + 2 * s.Gn) * (fast ? 0.9 : 1);
        const dG = Ra + EGP - (0.01 + Si * s.I * (1 + exer) + 0.01 * exer) * s.G;
        const dI = beta * 0.1 * Math.max(0, (s.G - 3.5) / 1.5) * (who.v === 't2' ? 1.8 : 1) - 0.1 * s.I;
        const dGn = 0.05 * Math.max(0, (7 - s.G) / 4) * (1 / (1 + s.I * 0.2)) * 1.3 - 0.05 * s.Gn;
        s.G = Math.max(0.5, s.G + dG * h); s.I = Math.max(0, s.I + dI * h); s.Gn = Math.max(0, s.Gn + dGn * h); s.t += h;
      }
      hist.push([s.t / 60, s.G, s.I, s.Gn]); while (hist.length && hist[0][0] < s.t / 60 - 8) hist.shift(); L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, gw = c.w - 80, gh = (c.h - 90) * 0.55, t0 = hist.length ? hist[0][0] : 0, t1 = Math.max(t0 + 8, s.t / 60);
      const ch = D.chart(g, 50, 24, gw, gh, [{ pts: hist.map(q => [q[0], q[1]]), color: T.c2, w: 2.4 }], { title: '血糖浓度（mmol/L）', xl: '时间 / h', xmin: t0, xmax: t1, ymin: 0, ymax: Math.max(14, ...hist.map(q => q[1])) });
      g.fillStyle = alpha(T.ok, 0.1); g.fillRect(50, ch.Y(6.1), gw, ch.Y(3.9) - ch.Y(6.1)); D.text(g, '正常范围', 54, ch.Y(6.1) + 10, T.ok, { size: 10 });
      meals.forEach(m => { const x = ch.X(m / 60); if (x > 50) { D.line(g, x, 24, x, 24 + gh, alpha(T.c4, 0.6), 1, [3, 3]); D.text(g, '进食', x + 3, 34, T.c4, { size: 10 }); } });
      D.chart(g, 50, 50 + gh, gw, (c.h - 90) * 0.45, [{ pts: hist.map(q => [q[0], q[2]]), color: T.c1, w: 2 }, { pts: hist.map(q => [q[0], q[3] * 4]), color: T.c4, w: 2 }], { title: '激素水平（相对）：蓝 胰岛素，黄 胰高血糖素', xl: '时间 / h', xmin: t0, xmax: t1, ymin: 0 });
      out.set([['血糖', fmt(s.G, 2) + ' mmol/L'], ['状态', s.G < 3.9 ? '低血糖' : s.G > 11.1 ? '明显高血糖（糖尿）' : s.G > 6.1 ? '偏高' : '正常'], ['胰岛素（相对）', fmt(s.I, 2)], ['胰高血糖素（相对）', fmt(s.Gn, 2)], ['饥饿', fast ? '是' : '否'], ['运动', s.t < ex ? '进行中' : '否']]);
    });
  }
});

/* ---------- 种群数量变化 ---------- */
Lab.reg({
  id: 'b-pop', subj: 'bio', book: 3, unit: '种群及其动态', title: '种群增长曲线与标记重捕法', kw: 'J 形曲线 S 形曲线 环境容纳量 K 值 K/2 增长速率 种群密度 标记重捕法 捕捞',
  info: `<p class="fb">“J”形增长：Nₜ = N₀λᵗ（理想条件：食物空间充裕、气候适宜、没有天敌）<br>“S”形增长：dN/dt = rN(1 − N/K)，K 为环境容纳量<br>N = K/2 时种群增长速率最大，捕捞后剩余量保持在 K/2 左右可持续获得最大产量</p>
  <p><b>标记重捕法</b>（适用于活动能力强、活动范围大的动物）：第一次捕获 M 只并标记放回，第二次捕获 n 只，其中有标记的 m 只，则估算 N ≈ Mn/m。</p>`,
  tasks: ['观察 S 形曲线中增长速率最大时对应的种群数量。', '加入捕捞，捕捞率为多少时种群仍能维持且年产量最大？', '标记重捕：若标记物易脱落，估算值偏大还是偏小？用模拟验证。'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['g', '增长曲线'], ['m', '标记重捕法']], 'g', () => { G1.hidden = mode.v !== 'g'; G2.hidden = mode.v !== 'm'; L.draw(); });
    const G1 = L.group('参数');
    const p = L.params({ r: ['内禀增长率 r', 0.1, 1.5, 0.05, 0.6, '/年'], K: ['环境容纳量 K', 100, 2000, 50, 1000], N0: ['初始数量 N₀', 2, 200, 1, 10], E: ['捕捞率', 0, 1, 0.01, 0, '/年'], Tm: ['时间', 10, 60, 1, 30, '年'] });
    const out = L.out();
    const G2 = L.group('标记重捕'); G2.hidden = true;
    const M = L.slider('第一次捕获并标记 M', 10, 200, 5, 60), nn = L.slider('第二次捕获 n', 10, 200, 5, 80);
    const loss = L.slider('标记脱落率', 0, 0.5, 0.05, 0);
    L.button('第一次捕获并标记', () => mark(), true); L.button('第二次捕获', () => recap(), true); L.button('换一个池塘', () => pond());
    const out2 = L.out();
    let fish = [], phase = 0, res = null, trueN = 0;
    function pond() { trueN = Math.round(rnd(300, 900)); fish = [...Array(trueN)].map(() => ({ x: rnd(0, 1), y: rnd(0, 1), vx: rnd(-1, 1), vy: rnd(-1, 1), mk: false, cap: false })); phase = 0; res = null; L.draw(); }
    function mark() { fish.forEach(f => { f.mk = false; f.cap = false; }); [...fish].sort(() => Math.random() - 0.5).slice(0, M.v).forEach(f => f.mk = true); fish.forEach(f => { if (f.mk && Math.random() < loss.v) f.mk = false; }); phase = 1; res = null; L.draw(); }
    function recap() { if (phase < 1) return; fish.forEach(f => f.cap = false); const s2 = [...fish].sort(() => Math.random() - 0.5).slice(0, nn.v); s2.forEach(f => f.cap = true); const m = s2.filter(f => f.mk).length; res = { m, est: m ? M.v * nn.v / m : Infinity }; phase = 2; L.draw(); }
    pond();
    L.loop(dt => { if (mode.v !== 'm') return; fish.forEach(f => { f.x += f.vx * dt * 0.05; f.y += f.vy * dt * 0.05; if (f.x < 0 || f.x > 1) f.vx *= -1; if (f.y < 0 || f.y > 1) f.vy *= -1; f.x = clamp(f.x, 0, 1); f.y = clamp(f.y, 0, 1); }); L.drawFn(); });
    L.onDraw(() => {
      c.clear(); const g = c.g;
      if (mode.v === 'g') {
        const { r, K, N0, E, Tm } = p, n = 600, dt = Tm / n; let N = N0, J = N0; const S = [[0, N]], Jp = [[0, J]], R = [[0, r * N * (1 - N / K) - E * N]];
        for (let i = 1; i <= n; i++) { N = Math.max(0, N + (r * N * (1 - N / K) - E * N) * dt); J = J * Math.exp(r * dt); S.push([i * dt, N]); Jp.push([i * dt, J]); R.push([i * dt, r * N * (1 - N / K)]); }
        const gh = (c.h - 80) * 0.6;
        const ch = D.chart(g, 50, 24, c.w - 80, gh, [{ pts: Jp.filter(q => q[1] < K * 1.6), color: alpha(T.muted, 0.8), w: 1.6, dash: [5, 4] }, { pts: S, color: T.c3, w: 2.4 }], { title: '种群数量 N − t（虚线为 J 形）', xl: 't / 年', xmin: 0, xmax: Tm, ymin: 0, ymax: K * 1.5 });
        D.line(g, 50, ch.Y(K), c.w - 30, ch.Y(K), T.c2, 1, [4, 4]); D.text(g, 'K', c.w - 36, ch.Y(K) - 8, T.c2); D.line(g, 50, ch.Y(K / 2), c.w - 30, ch.Y(K / 2), T.grid2, 1, [2, 4]); D.text(g, 'K/2', c.w - 36, ch.Y(K / 2) - 8, T.muted);
        const ch2 = D.chart(g, 50, 50 + gh, c.w - 80, (c.h - 80) * 0.4, [{ pts: R, color: T.c1, w: 2 }], { title: '增长速率 dN/dt − t', xl: 't / 年', xmin: 0, xmax: Tm, ymin: 0 });
        const im = R.reduce((b, q, i) => q[1] > R[b][1] ? i : b, 0); D.circle(g, ch2.X(R[im][0]), ch2.Y(R[im][1]), 4, T.c2);
        const Neq = E < r ? K * (1 - E / r) : 0;
        out.set([['K/2', K / 2], ['增长速率最大时', `t ≈ ${fmt(R[im][0], 1)} 年`], ['最终数量', fmt(S[S.length - 1][1], 0)], ['有捕捞时的平衡数量', fmt(Neq, 0)], ['年捕捞量（平衡时）', fmt(E * Neq, 1)], ['最大持续产量 rK/4', fmt(r * K / 4, 1) + `（捕捞率 ${fmt(r / 2, 2)}）`]]);
      } else {
        const ox = 20, oy = 20, W = c.w - 40, H = c.h - 40;
        g.fillStyle = alpha(T.c1, 0.1); g.beginPath(); g.ellipse(ox + W / 2, oy + H / 2, W / 2, H / 2, 0, 0, TAU); g.fill();
        fish.forEach(f => { const x = ox + W / 2 + (f.x - 0.5) * W * 0.9 * Math.sqrt(1 - ((f.y - 0.5) * 1.8) ** 2 * 0.5), y = oy + H / 2 + (f.y - 0.5) * H * 0.85; D.circle(g, x, y, f.cap ? 4 : 2.6, f.mk ? T.c2 : alpha(T.fg, 0.4), f.cap ? T.c4 : null, 1.5); });
        out2.set([['标记个体', fish.filter(f => f.mk).length], ['第二次捕获', phase >= 2 ? nn.v : '—'], ['其中有标记 m', res ? res.m : '—'], ['估算 N = Mn/m', res ? (isFinite(res.est) ? fmt(res.est, 0) : '无法估算（m = 0）') : '—'], ['真实数量', phase >= 2 ? trueN : '（第二次捕获后揭晓）'], ['相对误差', res && isFinite(res.est) ? fmt((res.est / trueN - 1) * 100, 1) + ' %' : '—']]);
      }
    });
  }
});

/* ---------- 捕食关系 ---------- */
Lab.reg({
  id: 'b-lv', subj: 'bio', book: 3, unit: '群落及其演替', title: '捕食者与被捕食者的数量变化', kw: '捕食 种间关系 周期性波动 Lotka-Volterra 负反馈 猞猁 雪兔',
  info: `<p>以雪兔（被捕食者）和猞猁（捕食者）为例：</p>
  <p class="fb">dx/dt = ax(1 − x/K) − bxy　（被捕食者：繁殖 − 被捕食）<br>dy/dt = cbxy − dy　（捕食者：捕食获得的增长 − 死亡）</p>
  <p>被捕食者增多 → 捕食者食物充足而增多 → 被捕食者减少 → 捕食者减少，两者数量呈周期性波动，且捕食者的峰值滞后于被捕食者。右侧相图中曲线绕平衡点旋转。</p>`,
  tasks: ['在时间图上判断哪条曲线代表捕食者，依据是什么？', '增大被捕食者的环境容纳量 K，波动会怎样变化？', '把捕食者死亡率 d 调得很大，会发生什么？'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ a: ['被捕食者增长率 a', 0.2, 2, 0.05, 1], K: ['被捕食者容纳量 K', 50, 1000, 10, 400], b: ['捕食率 b', 0.002, 0.05, 0.001, 0.02], cc: ['转化效率 c', 0.05, 1, 0.05, 0.3], d: ['捕食者死亡率 d', 0.05, 1.5, 0.05, 0.6], x0: ['雪兔初始', 5, 300, 5, 100], y0: ['猞猁初始', 1, 100, 1, 15], Tm: ['时间', 20, 200, 10, 80] });
    const out = L.out();
    L.onDraw(() => {
      c.clear(); const g = c.g, { a, K, b, cc, d, x0, y0, Tm } = p, n = 4000, h = Tm / n;
      let x = x0, y = y0; const X = [[0, x]], Y = [[0, y]], PH = [[x, y]];
      const f = (x, y) => [a * x * (1 - x / K) - b * x * y, cc * b * x * y - d * y];
      for (let i = 1; i <= n; i++) { const k1 = f(x, y), k2 = f(x + k1[0] * h / 2, y + k1[1] * h / 2), k3 = f(x + k2[0] * h / 2, y + k2[1] * h / 2), k4 = f(x + k3[0] * h, y + k3[1] * h); x = Math.max(0, x + (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]) * h / 6); y = Math.max(0, y + (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]) * h / 6); if (i % 4 === 0) { X.push([i * h, x]); Y.push([i * h, y]); PH.push([x, y]); } }
      const wide = c.w > 640, gw = wide ? c.w * 0.58 : c.w - 80, gh = wide ? c.h - 60 : (c.h - 80) / 2;
      const ymax = Math.max(...X.map(q => q[1]), ...Y.map(q => q[1])) * 1.1;
      D.chart(g, 50, 24, gw, gh, [{ pts: X, color: T.c3, w: 2.2 }, { pts: Y, color: T.c2, w: 2.2 }], { title: '数量 − 时间：绿 雪兔，橙 猞猁', xl: 't', xmin: 0, xmax: Tm, ymin: 0, ymax });
      const px = wide ? 80 + gw : 50, py = wide ? 24 : 54 + gh, pw = wide ? c.w - px - 20 : c.w - 80;
      const ch = D.chart(g, px, py, pw, gh, [{ pts: PH, color: T.c5, w: 1.6 }], { title: '相图：猞猁 − 雪兔', xl: '雪兔', xmin: 0, xmax: Math.max(...PH.map(q => q[0])) * 1.1, ymin: 0, ymax: Math.max(...PH.map(q => q[1])) * 1.1 });
      const xe = d / (cc * b), ye = a / b * (1 - xe / K); if (ye > 0) D.circle(g, ch.X(xe), ch.Y(ye), 4, T.fg);
      out.set([['平衡点 雪兔', ye > 0 ? fmt(xe, 1) : '—'], ['平衡点 猞猁', ye > 0 ? fmt(ye, 1) : '捕食者无法维持'], ['最终 雪兔 / 猞猁', `${fmt(x, 1)} / ${fmt(y, 1)}`]]);
    });
  }
});

/* ---------- 能量流动 ---------- */
Lab.reg({
  id: 'b-energy', subj: 'bio', book: 3, unit: '生态系统及其稳定性', title: '生态系统的能量流动', kw: '能量流动 能量金字塔 传递效率 同化量 呼吸作用 分解者 营养级 单向流动 逐级递减',
  info: `<p class="fb">某营养级同化量 = 呼吸作用散失 + 用于自身生长、发育和繁殖<br>用于生长发育繁殖的能量 = 流入下一营养级 + 流向分解者 + 未被利用<br>相邻营养级传递效率 = 下一营养级同化量 / 上一营养级同化量 ×100%，一般为 10% ~ 20%</p>
  <p>能量流动的特点：<b>单向流动、逐级递减</b>。因此食物链一般不超过 5 个营养级。</p>`,
  tasks: ['生产者固定 10000 kJ，传递效率 10%，三级消费者能得到多少能量？', '增大呼吸散失比例，最多能维持几个营养级？', '为什么能量金字塔不可能倒置，而数量金字塔可以？'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ E: ['生产者固定的太阳能', 1000, 50000, 500, 10000, 'kJ'], eff: ['传递效率', 5, 25, 1, 10, '%'], resp: ['呼吸散失占同化量', 30, 80, 1, 55, '%'], lv: ['营养级数', 2, 5, 1, 4] });
    const out = L.out();
    const names = ['生产者', '初级消费者', '次级消费者', '三级消费者', '四级消费者'];
    L.onDraw(() => {
      c.clear(); const g = c.g, { E, eff, resp, lv } = p, A = [E];
      for (let i = 1; i < lv; i++) A.push(A[i - 1] * Math.min(eff / 100, 1 - resp / 100));
      const pw = c.w * 0.45, ph = (c.h - 40) / lv, cx = 20 + pw / 2;
      A.forEach((a, i) => { const w = Math.max(20, pw * Math.sqrt(a / E)), y = c.h - 20 - (i + 1) * ph; D.rect(g, cx - w / 2, y + 2, w, ph - 4, alpha(T.c[(i + 2) % 6], 0.65)); D.text(g, `${names[i]}  ${fmt(a, 1)} kJ`, cx, y + ph / 2, T.fg, { align: 'center', size: 12, bold: true }); });
      const fx = 40 + pw, fw = c.w - fx - 20;
      if (fw > 200) A.forEach((a, i) => {
        const y = 30 + i * ((c.h - 60) / lv), R = a * resp / 100, grow = a - R, next = A[i + 1] || 0, rest = grow - next;
        D.text(g, names[i], fx, y, T.fg, { bold: true, size: 12 });
        const parts = [['呼吸散失', R, T.c2], ['流向下一营养级', next, T.c3], ['流向分解者', rest * 0.6, T.c4], ['未利用', rest * 0.4, T.muted]];
        let x = fx; parts.forEach(([n2, v, col]) => { const w = v / a * fw; D.rect(g, x, y + 10, w, 16, alpha(col, 0.7)); x += w; });
        D.text(g, parts.map(([n2, v]) => `${n2} ${fmt(v, 1)}`).join('｜'), fx, y + 38, T.muted, { size: 10.5 });
      });
      out.set([...A.map((a, i) => [names[i] + ' 同化量', fmt(a, 2) + ' kJ']), ['最高营养级占生产者的比例', fmt(A[A.length - 1] / E * 100, 4) + ' %'], ['实际传递效率', fmt(Math.min(eff, 100 - resp), 1) + ' %']]);
    });
  }
});

/* ---------- PCR ---------- */
Lab.reg({
  id: 'b-pcr', subj: 'bio', book: 4, unit: '基因工程', title: 'PCR 扩增 DNA', kw: 'PCR 聚合酶链式反应 变性 复性 延伸 引物 耐高温 DNA 聚合酶 Taq 指数增长',
  info: `<p>每个循环分三步：</p>
  <p class="fb">变性 90~95 ℃：DNA 双链解开<br>复性 50~60 ℃：两种引物与两条单链互补结合<br>延伸 72 ℃：耐高温的 DNA 聚合酶从引物 3′ 端开始合成子链</p>
  <p>理论上 n 次循环后 DNA 分子数为 2ⁿ（从 1 个模板开始）。第 3 次循环才首次出现两条链等长、只含目标片段的 DNA，其数目为 2ⁿ − 2n。实际上随引物、原料消耗和酶活性下降，扩增最终进入平台期。</p>`,
  tasks: ['经过 3 次循环，共有几个 DNA 分子？其中有几个是等长的目标 DNA？', '为什么 PCR 需要两种不同的引物？', '勾选「考虑原料消耗」，在第几轮后进入平台期？'],
  init(L) {
    const c = L.canvas();
    const n = L.slider('循环次数', 0, 35, 1, 3, () => L.draw());
    const lim = L.check('考虑原料消耗（平台期）', false), lg = L.check('纵轴取对数', false);
    let run = null; L.button('播放一个循环的温度变化', () => { tt = 0; run.play(); }, true);
    const out = L.out();
    let tt = 0;
    run = L.loop(dt => { tt += dt; if (tt > 6) { run.pause(); n.set(Math.min(35, n.v + 1)); } L.drawFn(); }, false);
    const amount = k => lim.v ? 1e9 / (1 + (1e9 - 1) * Math.pow(2, -k)) : 2 ** k;
    L.onDraw(() => {
      c.clear(); const g = c.g, k = n.v, half = c.h * 0.42;
      // 温度程序
      const prog = [[0, 25], [0.5, 95], [1.8, 95], [2.3, 55], [3.4, 55], [3.8, 72], [5.5, 72], [6, 95]];
      const ch = D.chart(g, 50, 20, c.w * 0.45 - 60, half - 30, [{ pts: prog, color: T.c2, w: 2.2 }], { title: '温度（℃）', xl: '一个循环', xmin: 0, xmax: 6, ymin: 20, ymax: 100 });
      [['变性', 1.1, 95], ['复性', 2.9, 55], ['延伸', 4.6, 72]].forEach(([t2, x, y]) => D.text(g, t2, ch.X(x), ch.Y(y) - 12, T.muted, { align: 'center', size: 11 }));
      if (run.running) { const T2 = (() => { for (let i = 1; i < prog.length; i++) if (tt <= prog[i][0]) { const [x1, y1] = prog[i - 1], [x2, y2] = prog[i]; return y1 + (y2 - y1) * (tt - x1) / (x2 - x1); } return 95; })(); D.circle(g, ch.X(Math.min(tt, 6)), ch.Y(T2), 6, T.c4); }
      // 分子示意（前几轮）
      const sx = c.w * 0.5, sw = c.w - sx - 20, mols = Math.min(2 ** Math.min(k, 4), 16), lh = Math.min(16, (half - 30) / mols);
      D.text(g, `第 ${k} 轮后的 DNA（最多画 16 个）`, sx, 16, T.muted, { size: 11 });
      for (let i = 0; i < mols; i++) { const y = 30 + i * lh, full = i >= 2 * Math.min(k, 4) || k < 3 ? false : true; void full; const isOrig = i === 0; D.line(g, sx, y, sx + sw * (isOrig ? 1 : 0.7), y, isOrig ? T.c1 : T.c3, 3); D.line(g, sx + sw * 0.15, y + 4, sx + sw * (isOrig ? 1 : 0.7), y + 4, isOrig ? T.c1 : T.c2, 3); }
      D.line(g, sx + sw * 0.15, 24, sx + sw * 0.15, 30 + mols * lh, alpha(T.c4, 0.7), 1, [3, 3]); D.line(g, sx + sw * 0.7, 24, sx + sw * 0.7, 30 + mols * lh, alpha(T.c4, 0.7), 1, [3, 3]); D.text(g, '目标片段（两引物之间）', sx + sw * 0.42, 30 + mols * lh + 12, T.c4, { align: 'center', size: 11 });
      const ks = [...Array(36).keys()], y = q => lg.v ? Math.log10(q) : q;
      const ch2 = D.chart(g, 50, half + 30, c.w - 80, c.h - half - 60, [{ pts: ks.map(i => [i, y(amount(i))]), color: T.c1, w: 2.2 }], { title: lg.v ? 'DNA 分子数（lg）' : 'DNA 分子数', xl: '循环次数', xmin: 0, xmax: 35, ymin: 0 });
      D.circle(g, ch2.X(k), ch2.Y(y(amount(k))), 5, T.c2);
      out.set([['循环次数 n', k], ['DNA 分子总数 2ⁿ', k > 40 ? '—' : fmt(2 ** k, 0)], ['等长目标 DNA 2ⁿ − 2n', k >= 3 ? fmt(2 ** k - 2 * k, 0) : 0], ['含原始模板链的 DNA', k ? 2 : 1], ['消耗引物数 2ⁿ⁺¹ − 2', fmt(2 ** (k + 1) - 2, 0)], lim.v ? ['考虑消耗后的分子数', fmt(amount(k), 0)] : null]);
    });
  }
});

/* ---------- 微生物计数 ---------- */
Lab.reg({
  id: 'b-plate', subj: 'bio', book: 4, unit: '发酵工程', title: '稀释涂布平板法计数', kw: '微生物 培养基 稀释涂布平板 梯度稀释 菌落 计数 30-300 无菌操作',
  info: `<p>将菌液进行一系列梯度稀释（每次 1 mL 加入 9 mL 无菌水，稀释 10 倍），取 0.1 mL 涂布到平板上，培养后计数菌落。</p>
  <p class="fb">每毫升样品中的菌数 = (C ÷ V) × M<br>C：某稀释度下平板上的平均菌落数　V：涂布体积（mL）　M：稀释倍数</p>
  <p>应选择菌落数在 <b>30~300</b> 之间的平板计数；每个稀释度至少涂布 3 个平板取平均值。因为两个或多个细胞连在一起时只长成一个菌落，统计值往往比实际值<b>偏小</b>。</p>`,
  tasks: ['先估计哪个稀释度的平板菌落数会落在 30~300 之间，再涂布验证。', '用符合要求的平板计算原菌液浓度，与真实值比较。', '为什么菌落数太多或太少的平板都不适合用来计数？'],
  init(L) {
    const c = L.canvas();
    let C0 = 0, plates = [];
    const dil = L.slider('涂布的稀释度 10⁻ᵏ', 1, 8, 1, 5, () => L.draw(), v => '10⁻' + v);
    L.button('涂布 3 个平板并培养', () => spread(), true); L.button('换一份菌液', () => { C0 = Math.round(rnd(1, 9.9) * 10) / 10 * 10 ** Math.floor(rnd(6, 9)); plates = []; reveal = false; L.draw(); });
    let reveal = false; L.button('揭晓真实浓度', () => { reveal = true; L.draw(); });
    const out = L.out();
    C0 = 3.6e7;
    function pois(lam) { if (lam > 400) return Math.round(lam + Math.sqrt(lam) * gauss()); let L2 = Math.exp(-lam), k = 0, p = 1; do { k++; p *= Math.random(); } while (p > L2); return k - 1; }
    function spread() {
      const k = dil.v, lam = C0 * 10 ** -k * 0.1;
      const ps = [...Array(3)].map(() => { const nc = pois(lam), pts = []; const show = Math.min(nc, 1500); for (let i = 0; i < show; i++) { const r = Math.sqrt(Math.random()) * 0.93, a = rnd(0, TAU), p2 = [r * Math.cos(a), r * Math.sin(a)]; if (!pts.some(q => Math.hypot(q[0] - p2[0], q[1] - p2[1]) < 0.025)) pts.push(p2); } return { k, pts, raw: nc }; });
      plates = plates.filter(q => q.k !== k).concat(ps); L.draw();
    }
    L.onDraw(() => {
      c.clear(); const g = c.g, tubes = 8, tw = Math.min(42, (c.w - 40) / tubes);
      for (let i = 0; i <= tubes; i++) { const x = 20 + i * tw * 1.1, a = 0.75 * Math.max(0.05, 1 - i / 8.5); D.rrect(g, x, 20, tw * 0.7, 70, 8, `rgba(200,170,90,${a})`, T.fg, 1.2); D.text(g, i ? '10⁻' + i : '原液', x + tw * 0.35, 102, i === dil.v ? T.c2 : T.muted, { align: 'center', size: 10.5 }); }
      const ks = [...new Set(plates.map(q => q.k))].sort((a, b) => a - b), R = Math.min(70, (c.w - 60) / 7, (c.h - 160) / (2 * Math.max(1, ks.length)) - 10);
      ks.forEach((k, row) => plates.filter(q => q.k === k).forEach((pl, j) => {
        const cx = 40 + R + j * (2 * R + 24), cy = 140 + R + row * (2 * R + 30);
        D.circle(g, cx, cy, R, alpha('#e8d9a8', T.dark ? 0.15 : 0.6), T.fg, 1.5);
        pl.pts.forEach(p2 => D.circle(g, cx + p2[0] * R, cy + p2[1] * R, Math.max(1.2, R * 0.022), '#f1efe2', '#b8a46a', 0.6));
        const cnt = pl.pts.length, ok = cnt >= 30 && cnt <= 300;
        D.text(g, cnt > 500 ? '多到无法计数' : cnt + ' 个', cx, cy + R + 12, ok ? T.ok : T.muted, { align: 'center', size: 11, bold: ok });
        if (j === 0) D.text(g, '10⁻' + k, 18, cy, T.muted, { size: 11 });
      }));
      const good = ks.filter(k => { const ps = plates.filter(q => q.k === k); return ps.every(q => q.pts.length >= 30 && q.pts.length <= 300); });
      const ests = good.map(k => { const ps = plates.filter(q => q.k === k), avg = ps.reduce((s, q) => s + q.pts.length, 0) / ps.length; return [k, avg, avg / 0.1 * 10 ** k]; });
      out.set([['涂布体积', '0.1 mL'], ...ests.map(([k, avg, e]) => [`10⁻${k} 平均 ${fmt(avg, 1)} 个`, sci(e, 2) + ' 个/mL']), ['可用于计数的稀释度', good.length ? good.map(k => '10⁻' + k).join('、') : '暂无（需要 30~300 个菌落）'], ['真实浓度', reveal ? sci(C0, 2) + ' 个/mL' : '（点击揭晓）']]);
    });
  }
});
