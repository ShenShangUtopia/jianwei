'use strict';
/* ======================= 题目导入：分析 → 选实验 → 配置 → 讲题 ======================= */
const Importer = {
  lesson: null, protocol: null, engines: null,
  sleep: ms => new Promise(r => setTimeout(r, ms)),

  /* ---- 分析引擎：本地 DeepSeek 代理 / claude.ai 内置 Claude / 关键词 ---- */
  async detect() {
    if (this.engines) return this.engines;
    const e = { deepseek: false, claude: null, images: false };
    try { const r = await fetch('api/health', { cache: 'no-store' }); if (r.ok) { const j = await r.json(); e.deepseek = !!j.deepseek; e.model = j.model; } } catch (err) { }
    try {
      if (window.claude && claude.use) { e.claude = await claude.use('sample'); if (e.claude && e.claude.limits) { const lim = await e.claude.limits(); e.images = !!(lim && lim.images); } }
    } catch (err) { e.claude = null; }
    this.engines = e; return e;
  },
  async loadProtocol() {
    if (this.protocol) return this.protocol;
    try { const r = await fetch('skill/protocol.md'); if (r.ok) this.protocol = await r.text(); } catch (e) { }
    return this.protocol || '你是中国高中理科教师。按用户要求只输出 JSON。';
  },
  async ask(engine, user, o = {}) {
    const system = await this.loadProtocol();
    if (engine === 'deepseek' || engine === 'deepseek-r') {
      const model = engine === 'deepseek-r' && !o.fast ? 'deepseek-reasoner' : 'deepseek-chat';
      const r = await fetch('api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system, user, model }) });
      const j = await r.json().catch(() => ({ error: '本地服务返回了无法解析的内容' }));
      if (!r.ok || j.error) throw new Error(j.error || 'DeepSeek 请求失败（' + r.status + '）');
      return j.text;
    }
    if (engine === 'claude') {
      const opts = { modelTier: o.tier || 'default' };
      if (o.images && o.images.length) opts.images = o.images;
      if (o.onText) opts.onText = o.onText;
      try { const r = await this.engines.claude([{ role: 'user', content: system + '\n\n---\n\n' + user }], opts); return r.text; }
      catch (err) { throw new Error(err && err.code === 'not_granted' ? '没有获得调用 Claude 的授权' : err && err.code === 'rate_limited' ? '调用太频繁，请稍后再试' : (err && err.message) || 'Claude 请求失败'); }
    }
    throw new Error('没有可用的分析引擎');
  },
  parse(text) {
    const s = String(text || '').replace(/```(?:json)?/g, ''), a = s.indexOf('{'), b = s.lastIndexOf('}');
    if (a < 0 || b < a) throw new Error('模型没有返回 JSON');
    return JSON.parse(s.slice(a, b + 1));
  },
  catalog() { return Lab.list.map(e => `${e.id}｜${Lab.S[e.subj].name}｜${Lab.S[e.subj].books[e.book]}｜${e.unit}｜${e.title}｜${e.kw || ''}`).join('\n'); },
  controls() {
    return (App.ctx ? App.ctx.ctrls : []).map(c => {
      const o = { name: c.name, kind: c.kind, group: c.group || undefined };
      if (c.kind === 'slider') Object.assign(o, { min: c.minF(), max: c.maxF(), step: c.step, unit: c.unit || undefined, value: c.get() });
      if (c.kind === 'select' || c.kind === 'choice') Object.assign(o, { options: c.options(), value: c.get() });
      if (c.kind === 'check' || c.kind === 'text') o.value = c.get();
      return o;
    });
  },
  async exportCatalog() { // 逐个打开实验收集默认控件，供 Claude Code 技能使用
    const out = [];
    for (const e of Lab.list) {
      location.hash = e.id; App.route(); await this.sleep(200);
      out.push({ id: e.id, subject: Lab.S[e.subj].name, book: Lab.S[e.subj].books[e.book], unit: e.unit, title: e.title, kw: e.kw || '', controls: this.controls() });
    }
    location.hash = ''; return JSON.stringify(out, null, 1);
  },
  async saveCatalog() { // 仅本地 serve.py 可用
    const r = await fetch('api/catalog', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: await this.exportCatalog() });
    return r.json();
  },
  keyword(text) {
    let best = null, bs = 0;
    for (const e of Lab.list) {
      const words = [e.title, e.unit, ...(e.kw || '').split(/\s+/)].join(' ').split(/[\s·、，（）()「」—-]+/).filter(w => w.length >= 2);
      const sc = words.reduce((s, w) => s + (text.includes(w) ? w.length : 0), 0);
      if (sc > bs) { bs = sc; best = e; }
    }
    return best;
  },

  /* ---- 主流程 ---- */
  async analyze(text, images, engine, status) {
    if (engine === 'keyword') {
      const e = this.keyword(text);
      return { problem: text, engine, module: e ? e.id : null, topic: e ? e.unit : '', summary: '按关键词匹配实验，未调用模型，需要手动调节参数。', knowns: [], steps: [], answer: '', settings: [], watch: [], caveats: '' };
    }
    status('第 1 步：解题并选择实验…');
    const A = this.parse(await this.ask(engine, `## 实验目录\n${this.catalog()}\n\n## 题目\n${text || '（见图片）'}\n\n## 任务\n执行协议中的第一步，只输出 JSON。`, { images, tier: 'complex' }));
    if (A.module && !Lab.byId[A.module]) A.module = null;
    return { problem: text, engine, ...A };
  },
  async configure(lesson, status) {
    const e = Lab.byId[lesson.module]; status('第 2 步：配置实验参数…');
    const user = `## 题目\n${lesson.problem || '（见图片）'}\n\n## 第一步结果\n${JSON.stringify({ summary: lesson.summary, knowns: lesson.knowns, steps: lesson.steps, answer: lesson.answer, scenario: lesson.scenario })}\n\n## 实验「${e.title}」原理\n${(e.info || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ')}\n\n## 控件列表\n${JSON.stringify(this.controls())}\n\n## 任务\n执行协议中的第二步，只输出 JSON。`;
    const B = this.parse(await this.ask(lesson.engine, user, { tier: 'default', fast: true }));
    Object.assign(lesson, { settings: B.settings || [], press: B.press || [], watch: B.watch || [], caveats: B.caveats || '' });
  },
  readouts() { // 同步重绘一次再读面板（后台标签页里 requestAnimationFrame 会暂停）
    try { App.ctx && App.ctx.drawFn && App.ctx.drawFn(); } catch (e) { }
    return [...document.querySelectorAll('.panel .out')].map(o => [...o.querySelectorAll('.kv')].map(k => k.innerText.replace(/\s*\n\s*/g, '：')).join('\n') || o.innerText).filter(s => s.trim()).join('\n');
  },
  async verify(lesson, status) {
    status('第 3 步：用实验数据核对答案…');
    let prev = '', same = 0, t0 = Date.now(), minWait = (lesson.press || []).length ? 2500 : 600;
    while (Date.now() - t0 < 9000) { await this.sleep(500); const cur = this.readouts(); same = cur === prev ? same + 1 : 0; prev = cur; if (same >= 2 && Date.now() - t0 >= minWait) break; }
    if (!prev.trim()) { lesson.verify = { consistent: true, check: '实验面板没有可读的数值，未核对。', rows: [] }; return; }
    const base = `## 题目\n${lesson.problem || '（见图片）'}\n\n## 解答\n${JSON.stringify({ steps: lesson.steps, answer: lesson.answer })}\n\n## 实验设置\n${(lesson.applied?.ok || []).join('；')}\n\n## 实验读数\n${prev}`;
    const C = this.parse(await this.ask(lesson.engine, base + '\n\n## 任务\n执行协议中的第三步，只输出 JSON。'));
    // 网页自己比较数值，避免模型「凑数」
    const nums = s => (String(s).replace(/−/g, '-').match(/-?\d+(?:\.\d+)?(?:×10-?\d+)?/g) || []).map(t => { const [m, e] = t.split('×10'); return +m * (e ? 10 ** +e : 1); });
    const lines = prev.split('\n').map(x => { const i = x.indexOf('：'); return i < 0 ? null : [x.slice(0, i).trim(), x.slice(i + 1).trim()]; }).filter(Boolean);
    const rows = [];
    for (const p of C.pairs || []) {
      const hit = lines.find(([k]) => k === p.readout) || lines.find(([k]) => k.includes(p.readout) || String(p.readout).includes(k));
      if (!hit) continue;
      const tail = hit[1].match(/=\s*(-?\d[\d.]*(?:×10-?\d+)?)\s*[^\d=()（）]*$/), mv = tail ? tail[1] : hit[1]; // 「算式 = 结果」只取结果
      let a = Array.isArray(p.answer_value) ? p.answer_value.map(Number) : nums(p.answer_value), m = nums(mv);
      if (!a.length || !m.length) continue;
      if (/[:：]/.test(hit[1]) && a.length === m.length && a.length > 1) { // 比例：与顺序、倍数无关
        const nm = v => { const s = v.reduce((x, y) => x + y, 0) || 1; return v.map(x => x / s).sort((x, y) => x - y); };
        const ok = nm(a).every((x, i) => Math.abs(x - nm(m)[i]) < 0.01);
        rows.push({ quantity: p.quantity, readout: hit[0], answer: a.join(' : '), measured: hit[1], ok }); continue;
      }
      const n = a.length === m.length ? a.length : 1, ok = [...Array(n).keys()].every(i => Math.abs(a[i] - m[i]) <= Math.max(0.02 * Math.max(Math.abs(a[i]), Math.abs(m[i])), 0.005));
      rows.push({ quantity: p.quantity, readout: hit[0], answer: a.slice(0, n).map(x => fmt(x, 4)).join(', '), measured: hit[1], ok });
    }
    lesson.verify = { consistent: rows.every(r => r.ok), rows, check: rows.length ? '' : (C.note || '实验中没有与答案直接对应的读数，未核对。') };
    if (lesson.verify.consistent) return;
    status('数值与实验不符，正在重新检查解答…');
    const bad = rows.filter(r => !r.ok).map(r => `${r.quantity}：原答案换算为 ${r.answer}，实验读数「${r.readout}」为 ${r.measured}`).join('\n');
    const F = this.parse(await this.ask(lesson.engine, base + `\n\n## 不符的项目\n${bad}\n\n## 任务\n执行协议中的第四步，只输出 JSON。`, { tier: 'complex' }));
    lesson.verify.check = F.error || '';
    if (F.answer && F.answer.replace(/\s/g, '') !== String(lesson.answer).replace(/\s/g, '')) { lesson.verify.oldAnswer = lesson.answer; lesson.answer = F.answer; }
    else lesson.verify.disputed = true; // 模型坚持原答案：保留冲突提示，交给老师判断
    if (Array.isArray(F.steps) && F.steps.length) { lesson.steps = F.steps; lesson.shown = 1; }
  },
  async apply(lesson) {
    const ctrls = App.ctx ? App.ctx.ctrls : [], norm = s => String(s).replace(/\s+/g, '').toLowerCase();
    const find = n => ctrls.find(c => c.name === n) || ctrls.find(c => norm(c.name) === norm(n)) || ctrls.find(c => norm(c.name).startsWith(norm(n)));
    const sets = [...(lesson.settings || [])].sort((a, b) => { const r = s => { const c = find(s.name); return c && (c.kind === 'select' || c.kind === 'choice') ? 0 : 1; }; return r(a) - r(b); });
    const ok = [], miss = [];
    for (const s of sets) {
      const c = find(s.name); if (!c || !c.set) { miss.push(s.name); continue; }
      let v = s.value;
      if (c.kind === 'select' || c.kind === 'choice') { const op = c.options().find(o => o.value == v) || c.options().find(o => o.text === v) || c.options().find(o => String(o.text).includes(String(v))); if (!op) { miss.push(s.name); continue; } v = op.value; }
      if (c.kind === 'slider') { v = clamp(+v, c.minF(), c.maxF()); if (!isFinite(v)) { miss.push(s.name); continue; } }
      c.set(v); ok.push(`${c.name} = ${c.kind === 'slider' ? fmt(v, 4) : v}`); await this.sleep(140);
    }
    for (const n of lesson.press || []) { const c = find(n); if (c && c.press) { await this.sleep(200); c.press(); ok.push(`按下「${c.name}」`); } else miss.push(n); }
    lesson.applied = { ok, miss };
  },

  /* ---- 记录（仅本机浏览器） ---- */
  history() { try { return JSON.parse(localStorage.getItem('lab-lessons') || '[]'); } catch (e) { return []; } },
  save(l) { try { const h = this.history().filter(x => x.id !== l.id); h.unshift(l); localStorage.setItem('lab-lessons', JSON.stringify(h.slice(0, 12))); } catch (e) { } },

  /* ---- 题目导入页 ---- */
  async page() {
    const v = document.getElementById('view'); v.innerHTML = '';
    const wrap = el('div', 'imp');
    wrap.innerHTML = `<div class="ehead"><h1>题目导入</h1><span class="chip">粘贴题目 → 自动解题 → 打开对应实验并配置参数 → 分步讲解</span></div>
      <div class="imp-grid">
        <section class="grp">
          <h4>题目</h4>
          <label class="fld"><textarea id="imp-text" rows="9" placeholder="把题目粘贴到这里，例如：从 20 m 高处以 15 m/s 的速度水平抛出一个小球，不计空气阻力，求落地时间和水平位移。"></textarea></label>
          <label class="fld" id="imp-imgwrap" hidden><span>或上传题目图片（只有 Claude 引擎能读图）</span><input id="imp-img" type="file" accept="image/*"></label>
          <div class="row"><label class="fld" style="flex:1"><span>分析引擎</span><select id="imp-engine"></select></label></div>
          <div class="row"><button class="btn pri" id="imp-go" type="button">分析并模拟</button><button class="btn" id="imp-demo" type="button">填入示例题</button></div>
          <div class="note" id="imp-status"></div>
        </section>
        <section class="grp">
          <h4>引擎状态</h4>
          <div class="out" id="imp-eng"><div class="note">正在检测…</div></div>
          <h4>直接导入讲解 JSON</h4>
          <div class="note">把 Claude Code 技能 <b>problem-sim</b> 或其他工具生成的讲解 JSON 粘贴到这里。</div>
          <label class="fld"><textarea id="imp-json" rows="4" placeholder='{"module":"p-proj","steps":[…],"settings":[…]}'></textarea></label>
          <div class="row"><button class="btn" id="imp-jsongo" type="button">导入 JSON</button></div>
          <h4>最近的题目（保存在本机浏览器）</h4>
          <div id="imp-hist" class="out"></div>
        </section>
      </div>
      <div id="imp-result"></div>`;
    v.appendChild(wrap);
    const $ = id => document.getElementById(id), st = m => { const s = $('imp-status'); if (s) s.textContent = m; else this.status(m); };
    const demos = ['从离地 20 m 高处以 15 m/s 的初速度水平抛出一个小球，不计空气阻力，g 取 10 m/s²。求小球落地时间、水平位移和落地速度大小。',
      '已知椭圆 x²/16 + y²/9 = 1，直线 y = x + 1 与椭圆交于 A、B 两点，求弦长 |AB|。',
      '用 0.1000 mol/L NaOH 溶液滴定 20.00 mL 0.1000 mol/L 醋酸溶液，应选用什么指示剂？滴定终点时溶液 pH 约为多少？',
      '在棱长为 2 的正方体 ABCD-A₁B₁C₁D₁ 中，求直线 A₁C 与平面 ABCD 所成角的正弦值。',
      '某种疾病的患病率为 1%，检测方法的灵敏度为 99%，对未患病者误诊为阳性的概率为 5%。某人检测为阳性，求他真正患病的概率。'];
    let di = 0; $('imp-demo').onclick = () => { $('imp-text').value = demos[di++ % demos.length]; };
    const renderHist = () => { const h = this.history(); $('imp-hist').innerHTML = h.length ? '' : '<div class="note">还没有记录。</div>'; h.forEach(l => { const a = el('a', 'kv', `<span>${(l.problem || l.summary || '').slice(0, 34)}…</span><b>${l.module ? Lab.byId[l.module]?.title || '' : '仅解答'}</b>`); a.href = '#'; a.onclick = ev => { ev.preventDefault(); this.open(l); }; $('imp-hist').appendChild(a); }); };
    renderHist();
    $('imp-jsongo').onclick = () => { try { const l = this.parse($('imp-json').value); l.id = Date.now(); l.engine = 'json'; if (l.module && !Lab.byId[l.module]) throw new Error('目录里没有实验 ' + l.module); this.save(l); this.open(l); } catch (e) { st('JSON 有误：' + e.message); } };
    const eng = await this.detect();
    const opts = [];
    if (eng.deepseek) opts.push(['deepseek-r', 'DeepSeek 推理模型（推荐）'], ['deepseek', 'DeepSeek 对话模型（更快，计算易出错）']);
    if (eng.claude) opts.push(['claude', 'Claude（claude.ai 内置）']);
    opts.push(['keyword', '仅关键词匹配实验（不解题）']);
    $('imp-engine').innerHTML = opts.map(([k, t]) => `<option value="${k}">${t}</option>`).join('');
    $('imp-imgwrap').hidden = !eng.images;
    $('imp-eng').innerHTML = [['DeepSeek', eng.deepseek ? '可用（经见微本地服务转发）' : '未配置：在见微「设置 → DeepSeek 题目分析」里填入密钥'], ...(eng.claude ? [['Claude', '可用' + (eng.images ? '，支持图片' : '')]] : []), ['关键词匹配', '始终可用']].map(r => `<div class="kv"><span>${r[0]}</span><b>${r[1]}</b></div>`).join('');
    $('imp-engine').onchange = () => { $('imp-imgwrap').hidden = !(eng.images && $('imp-engine').value === 'claude'); };
    $('imp-engine').onchange();
    $('imp-go').onclick = async () => {
      const text = $('imp-text').value.trim(), file = $('imp-img').files && $('imp-img').files[0], engine = $('imp-engine').value;
      if (!text && !file) { st('请先粘贴题目或上传图片。'); return; }
      $('imp-go').disabled = true;
      try {
        const l = await this.analyze(text, file && engine === 'claude' ? [file] : null, engine, st);
        l.id = Date.now();
        if (l.module && engine !== 'keyword') { try { await this.prepareAndOpen(l, st); } catch (e) { st('配置实验时出错：' + e.message + '，已只显示解答。'); this.save(l); this.open(l); } }
        else { this.save(l); this.open(l); }
      } catch (e) { st('分析失败：' + e.message); }
      if ($('imp-go')) $('imp-go').disabled = false;
    };
  },
  async prepareAndOpen(l, st) { // 先打开实验拿到控件，再做第 2 步
    this.lesson = { ...l, pending: true };
    if (location.hash === '#' + l.module) App.route(); else location.hash = l.module;
    await this.sleep(400);
    this.status('正在根据题目配置实验参数…');
    await this.configure(this.lesson, m => this.status(m));
    delete this.lesson.pending; await this.apply(this.lesson); this.renderCard();
    const cur = this.lesson;
    try { await this.verify(cur, m => this.status(m)); } catch (e) { cur.verify = { consistent: true, check: '核对时出错：' + e.message }; }
    cur.done = true; this.save(cur); if (this.lesson === cur) this.renderCard(); void st;
  },
  open(l) {
    this.lesson = l;
    if (l.module && Lab.byId[l.module]) { if (location.hash === '#' + l.module) App.route(); else location.hash = l.module; }
    else { const r = document.getElementById('imp-result'); if (r) { r.innerHTML = ''; r.appendChild(this.card(l)); } }
  },

  /* ---- 实验页里的讲题卡 ---- */
  afterOpen(e) {
    if (!this.lesson || this.lesson.module !== e.id) return;
    const v = document.getElementById('view'), body = v.querySelector('.ebody');
    const holder = el('div'); holder.id = 'lesson'; v.insertBefore(holder, body);
    this.renderCard();
    if (!this.lesson.pending && (this.lesson.settings || []).length && !this.lesson._applied) { this.lesson._applied = true; this.apply(this.lesson).then(() => this.renderCard()); }
  },
  status(m) { const s = document.querySelector('#lesson .lsn-status'); if (s) s.textContent = m; },
  renderCard() { const h = document.getElementById('lesson'); if (!h || !this.lesson) return; h.innerHTML = ''; h.appendChild(this.card(this.lesson)); },
  card(l) {
    l.shown = l.shown ?? 1;
    const c = el('section', 'lesson'), steps = l.steps || [];
    const esc = s => String(s ?? '').replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[ch]);
    c.innerHTML = `<div class="lsn-head"><h3>讲题 · ${esc(l.topic || l.subject || '')}</h3><div class="row">
        ${steps.length ? `<button class="btn pri" data-a="next" type="button">下一步（${Math.min(l.shown, steps.length)}/${steps.length}）</button><button class="btn" data-a="all" type="button">全部展开</button>` : ''}
        ${l.answer ? `<button class="btn" data-a="ans" type="button">${l.showAns ? '隐藏答案' : '显示答案'}</button>` : ''}
        ${(l.settings || []).length ? '<button class="btn" data-a="re" type="button">重新应用设置</button>' : ''}
        <button class="btn" data-a="hide" type="button">收起</button></div></div>
      ${l.problem ? `<p class="lsn-prob">${esc(l.problem)}</p>` : ''}
      ${l.summary ? `<p><b>题意：</b>${esc(l.summary)}</p>` : ''}
      <div class="lsn-grid"><div>
        ${(l.knowns || []).length ? `<h5>已知</h5><ul>${l.knowns.map(k => `<li>${esc(k)}</li>`).join('')}</ul>` : ''}
        ${steps.length ? `<h5>解题步骤</h5><ol>${steps.slice(0, l.shown).map(k => `<li>${esc(k)}</li>`).join('')}</ol>` : ''}
        ${l.answer && l.showAns ? `<div class="fb">答案：${esc(l.answer)}</div>` : ''}
        ${l.verify ? `<div class="lsn-verify ${l.verify.consistent ? 'ok' : 'fix'}"><b>${l.verify.consistent ? (l.verify.rows?.length ? '答案与实验读数一致' : '未能用实验核对') : l.verify.disputed ? '答案与实验读数不符，模型坚持原答案，请老师核查' : '原解答与实验读数不符，已重新解答'}</b>${l.verify.oldAnswer && l.showAns ? `（原答案：${esc(l.verify.oldAnswer)}）` : ''}
          ${(l.verify.rows || []).map(r => `<div>${r.ok ? '✓' : '✗'} ${esc(r.quantity)}：答案 ${esc(r.answer)}，实验 ${esc(r.measured)}</div>`).join('')}
          ${l.verify.check ? `<div>${l.verify.disputed ? '模型的解释：' : ''}${esc(l.verify.check)}</div>` : ''}
          ${l.verify.disputed && l.engine === 'deepseek' ? '<div>建议换用「DeepSeek 推理模型」重新分析。</div>' : ''}</div>` : ''}
      </div><div>
        ${(l.watch || []).length ? `<h5>在模拟中观察</h5><ul>${l.watch.map(k => `<li>${esc(k)}</li>`).join('')}</ul>` : ''}
        ${l.caveats ? `<h5>模拟说明</h5><p class="note">${esc(l.caveats)}</p>` : ''}
        ${l.applied ? `<h5>已自动设置</h5><p class="note">${esc(l.applied.ok.join('；') || '无')}${l.applied.miss.length ? `<br>未能设置：${esc(l.applied.miss.join('、'))}` : ''}</p>` : ''}
        ${!l.module ? '<p class="note">目录中没有能直接模拟这道题的实验，以上为解答。</p>' : ''}
      </div></div>
      <div class="note lsn-status">${l.pending ? '正在配置实验参数…' : ''}</div>`;
    c.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
      const a = b.dataset.a;
      if (a === 'next') l.shown = Math.min(steps.length, l.shown + 1);
      if (a === 'all') l.shown = steps.length;
      if (a === 'ans') l.showAns = !l.showAns;
      if (a === 'hide') { this.lesson = null; c.remove(); return; }
      if (a === 're') { await this.apply(l); }
      const p = c.parentElement; if (p) { p.innerHTML = ''; p.appendChild(this.card(l)); }
    });
    return c;
  }
};

// 挂到应用外壳上
(() => {
  const route = App.route.bind(App), open = App.open.bind(App);
  App.route = function () {
    if (location.hash === '#import') {
      if (this.ctx) { this.ctx.dispose(); this.ctx = null; }
      this.cur = null; this.side(document.getElementById('q').value.trim()); Importer.page(); document.getElementById('view').scrollTop = 0; return;
    }
    route();
  };
  App.open = function (e) { open(e); Importer.afterOpen(e); };
})();
