'use strict';
/* 见微接入层：
   · #subj/phys 之类的入口（见微实验室页的学科格子）→ 切到该学科的目录；
   · 标签页标题跟着当前实验走，方便在浏览器里和习题台区分。 */
(() => {
  const route = App.route.bind(App);
  App.route = function () {
    const m = /^#subj\/(math|phys|chem|bio)$/.exec(location.hash);
    if (m) {
      this.subj = m[1];
      history.replaceState(null, '', location.pathname + location.search);
      document.body.classList.add('nav-open');
    }
    route();
    const h = location.hash.slice(1);
    let name = '';
    if (h === 'import') name = '导入题目';
    else if (h === 'bench') name = '自由工作台';
    else if (h.startsWith('bench/')) name = (Bench.byId[h.slice(6)] || {}).title || '自由工作台';
    else if (Lab.byId[h]) name = Lab.byId[h].title;
    document.title = name ? `${name} · 见微 · 格物实验台` : '见微 · 格物实验台';
  };
})();
