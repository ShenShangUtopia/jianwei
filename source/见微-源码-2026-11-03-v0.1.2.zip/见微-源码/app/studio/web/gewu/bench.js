'use strict';
/* ================= 自由工作台：外壳、素材栏与拖放 =================
   每个工作台用 Bench.reg 注册：{id, subj, short, title, sub, desc, art, init(B)}。
   B 提供 L（Ctx）、stage、palette()、toast()、clearPanel()、foot 等。 */
const Bench = {
  list: [], byId: {},
  reg(k) { this.list.push(k); this.byId[k.id] = k; },
  open(id) {
    const v = document.getElementById('view'); v.innerHTML = '';
    document.body.classList.add('bench-mode');
    const k = this.byId[id];
    if (!k) { this.home(v); return null; }
    App.setSubj(k.subj);
    const head = el('div', 'ehead bhead', `<h1>${k.title}</h1><span class="chip s">自由工作台</span><span class="chip">${k.sub}</span>`);
    const tabs = el('nav', 'bk-tabs'); tabs.setAttribute('aria-label', '工作台');
    this.list.forEach(o => { const a = el('a', '', o.short); a.href = '#bench/' + o.id; if (o === k) a.setAttribute('aria-current', 'true'); tabs.appendChild(a); });
    head.appendChild(tabs);
    const body = el('div', 'bench'), pal = el('aside', 'pal'), stage = el('div', 'stage bstage'), insp = el('div', 'panel insp');
    pal.setAttribute('aria-label', '器材与药品');
    body.append(pal, stage, insp);
    const foot = el('div', 'bfoot');
    v.append(head, body, foot);
    const L = new Ctx(stage, insp);
    const B = this.api(L, stage, pal, insp, foot);
    try { k.init(B); L.draw(); }
    catch (err) { console.error(err); stage.appendChild(el('div', 'err', '工作台加载出错：' + err.message)); }
    return L;
  },
  home(v) {
    v.appendChild(el('div', 'ehead', `<h1>自由工作台</h1><span class="chip">自己挑选器材和药品，搭建想做的实验</span>`));
    const g = el('div', 'bk-cards');
    this.list.forEach(k => {
      const a = el('a', 'bk-card', `<div class="art">${k.art}</div><div><h3>${k.title}</h3><p>${k.desc}</p></div>`);
      a.href = '#bench/' + k.id; a.style.setProperty('--sc', `var(--${k.subj})`); g.appendChild(a);
    });
    v.appendChild(g);
  },
  banner() {
    const b = el('a', 'bk-banner', `<span class="mini">${this.list.map(k => k.art).join('')}</span><b>自由工作台</b><span>不按教材顺序，自己选药品、器材和场：${this.list.map(k => k.title).join('、')}</span><i>进入 →</i>`);
    b.href = '#bench'; return b;
  },
  api(L, stage, pal, insp, foot) {
    const B = { L, stage, pal, insp, foot, items: {} };
    const toasts = el('div', 'btoast'); toasts.setAttribute('aria-live', 'polite'); stage.appendChild(toasts);
    B.toast = (html, o = {}) => {
      const d = el('div', o.cls || '', html); toasts.prepend(d);
      while (toasts.children.length > 3) toasts.lastChild.remove();
      setTimeout(() => { d.style.opacity = '0'; setTimeout(() => d.remove(), 450); }, o.ms || 2600);
    };
    B.palette = secs => {
      pal.innerHTML = ''; B.items = {};
      for (const s of secs) {
        pal.appendChild(el('h5', '', s.title));
        const box = el('div', 'pal-items'); pal.appendChild(box);
        for (const it of s.items) { const b = this.item(it, B); box.appendChild(b); if (it.id) B.items[it.id] = b; }
      }
    };
    B.active = id => { for (const k in B.items) B.items[k].setAttribute('aria-pressed', k === id); };
    B.clearPanel = () => { insp.innerHTML = ''; L.box = null; L.ctrls = []; L._gt = ''; };
    return B;
  },
  // 素材栏条目：点击执行 click；拖到画布上执行 drop(x, y)
  item(it, B) {
    const b = el('button', 'pal-it', `<span class="ic">${it.icon || ''}</span><span class="tx">${it.label}${it.sub ? `<small>${it.sub}</small>` : ''}</span>`);
    b.type = 'button'; if (it.title) b.title = it.title;
    let ghost = null, used = false;
    b.addEventListener('pointerdown', e => {
      if (e.button || !it.drop) return;
      const sx = e.clientX, sy = e.clientY; used = false;
      const mv = ev => {
        if (!ghost && Math.hypot(ev.clientX - sx, ev.clientY - sy) > 8) { ghost = el('div', 'pal-ghost', b.innerHTML); document.body.appendChild(ghost); }
        if (ghost) { ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px'; }
      };
      const up = ev => {
        removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
        if (!ghost) return; ghost.remove(); ghost = null; used = true;
        if (ev.type === 'pointercancel') return;
        const r = B.stage.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
        if (x >= 0 && y >= 0 && x <= r.width && y <= r.height) it.drop(x, y);
      };
      addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
    });
    b.addEventListener('click', () => { if (used) { used = false; return; } it.click && it.click(); });
    b.addEventListener('dragstart', e => e.preventDefault());
    return b;
  }
};

// 挂到应用外壳上：#bench、#bench/<id>
(() => {
  const route = App.route.bind(App), home = App.homePage.bind(App);
  App.route = function () {
    const h = location.hash;
    if (h === '#bench' || h.startsWith('#bench/')) {
      if (this.ctx) { this.ctx.dispose(); this.ctx = null; }
      this.cur = null; this.ctx = Bench.open(h.slice(7));
      document.getElementById('view').scrollTop = 0; return;
    }
    document.body.classList.remove('bench-mode');
    route();
  };
  App.homePage = function () { home(); const hero = document.querySelector('.hero'); if (hero) hero.after(Bench.banner()); };
})();
