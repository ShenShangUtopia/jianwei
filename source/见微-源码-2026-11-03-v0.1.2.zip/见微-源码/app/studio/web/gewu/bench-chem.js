'use strict';
/* ================= 自由工作台 · 化学 =================
   每个容器记录各物质的总量（mmol）、体积（mL）和温度。每一步：
   1. 先处理与 pH 无关的沉淀（AgI、AgBr、AgCl、BaSO₄，以及微溶的 CaSO₄）；
   2. 用电荷守恒二分求 [H⁺]，同时按溶度积决定氢氧化物（含微溶的 Ca(OH)₂）、碳酸盐沉淀，
      按配合平衡处理铜氨、银氨、锌氨离子和 [Al(OH)₄]⁻、[Zn(OH)₄]²⁻；
   3. 金属与酸、置换、大理石、H₂O₂ 分解、固体溶解等按速率进行，离子间的氧化还原近似瞬时完成。
   溶度积等常数取教材常用值，个别（CaCO₃、Zn(OH)₂ 溶于强碱和氨水）为了现象能演示而做了放大。
   四氯化碳单独记体积（下层），卤素单质在两层之间按分配系数分配。 */
(() => {
const NM = { Na: 'Na⁺', K: 'K⁺', Ca: 'Ca²⁺', Ba: 'Ba²⁺', Mg: 'Mg²⁺', Cu: 'Cu²⁺', Fe2: 'Fe²⁺', Fe3: 'Fe³⁺', Al: 'Al³⁺', Zn: 'Zn²⁺', Ag: 'Ag⁺', Mn: 'Mn²⁺', Cl: 'Cl⁻', Br: 'Br⁻', SO4: 'SO₄²⁻', NO3: 'NO₃⁻', I: 'I⁻', SCN: 'SCN⁻', MnO4: 'MnO₄⁻' };
// 氢氧化物：金属、OH⁻ 个数、Ksp
const HY = [['Fe3', 3, 4e-38], ['Al', 3, 1.3e-33], ['Cu', 2, 2.2e-20], ['Zn', 2, 3e-17], ['Fe2', 2, 4.9e-17], ['Mg', 2, 5.6e-12], ['Ag', 1, 2e-8]];
const KSP = Object.fromEntries(HY.map(h => [h[0], h[2]])), ksp = k => KSP[k];
const PK = ['AgCl', 'AgBr', 'AgI', 'BaSO4', 'CaSO4', 'CaCO3', 'BaCO3', 'CaOH', 'Fe3', 'Al', 'Cu', 'Zn', 'Fe2', 'Mg', 'Ag', 'CuO'];
const PN = { AgCl: 'AgCl', AgBr: 'AgBr', AgI: 'AgI', BaSO4: 'BaSO₄', CaSO4: 'CaSO₄', CaCO3: 'CaCO₃', BaCO3: 'BaCO₃', CaOH: 'Ca(OH)₂', Fe3: 'Fe(OH)₃', Al: 'Al(OH)₃', Cu: 'Cu(OH)₂', Zn: 'Zn(OH)₂', Fe2: 'Fe(OH)₂', Mg: 'Mg(OH)₂', Ag: 'Ag₂O', CuO: 'CuO' };
const PM = { AgCl: 143.3, AgBr: 187.8, AgI: 234.8, BaSO4: 233.4, CaSO4: 136.1, CaCO3: 100.1, BaCO3: 197.3, CaOH: 74.1, Fe3: 106.9, Al: 78, Cu: 97.6, Zn: 99.4, Fe2: 89.9, Mg: 58.3, Ag: 115.9, CuO: 79.5 };
const PC = { AgCl: '#f3f3ef', AgBr: '#efe3a6', AgI: '#ecd468', BaSO4: '#f5f5f2', CaSO4: '#f4f4f0', CaCO3: '#f2f2ee', BaCO3: '#f2f2ee', CaOH: '#f3f3ef', Fe3: '#a5532b', Al: '#e9eef3', Cu: '#4a8edb', Zn: '#f1f1ee', Fe2: '#e4ebdf', Mg: '#f0f1ee', Ag: '#4b3d31', CuO: '#24211f' };
const PD = { AgCl: '生成白色沉淀（不溶于稀硝酸）', AgBr: '生成浅黄色沉淀（不溶于稀硝酸）', AgI: '生成黄色沉淀（不溶于稀硝酸）', BaSO4: '生成白色沉淀（不溶于稀盐酸）', CaSO4: '生成白色沉淀（CaSO₄ 微溶，浓度较大时析出）', CaCO3: '生成白色沉淀', BaCO3: '生成白色沉淀', CaOH: '生成白色沉淀（Ca(OH)₂ 微溶）', Fe3: '生成红褐色沉淀', Al: '生成白色胶状沉淀', Cu: '生成蓝色絮状沉淀', Zn: '生成白色沉淀', Fe2: '生成白色絮状沉淀（在空气中迅速变成灰绿色，最后变成红褐色）', Mg: '生成白色沉淀', Ag: '生成棕褐色沉淀（AgOH 不稳定，转化为 Ag₂O）' };
const PDN = { Ag: '生成白色沉淀（继续滴加氨水，沉淀会溶解）' }; // 用氨水沉淀时的现象
const HF = {
  Fe3: ['Fe³⁺ + 3OH⁻ = Fe(OH)₃↓', 'Fe³⁺ + 3NH₃·H₂O = Fe(OH)₃↓ + 3NH₄⁺'], Al: ['Al³⁺ + 3OH⁻ = Al(OH)₃↓', 'Al³⁺ + 3NH₃·H₂O = Al(OH)₃↓ + 3NH₄⁺'],
  Cu: ['Cu²⁺ + 2OH⁻ = Cu(OH)₂↓', 'Cu²⁺ + 2NH₃·H₂O = Cu(OH)₂↓ + 2NH₄⁺'], Zn: ['Zn²⁺ + 2OH⁻ = Zn(OH)₂↓', 'Zn²⁺ + 2NH₃·H₂O = Zn(OH)₂↓ + 2NH₄⁺'],
  Fe2: ['Fe²⁺ + 2OH⁻ = Fe(OH)₂↓', 'Fe²⁺ + 2NH₃·H₂O = Fe(OH)₂↓ + 2NH₄⁺'], Mg: ['Mg²⁺ + 2OH⁻ = Mg(OH)₂↓', 'Mg²⁺ + 2NH₃·H₂O = Mg(OH)₂↓ + 2NH₄⁺'],
  Ag: ['2Ag⁺ + 2OH⁻ = Ag₂O↓ + H₂O', 'Ag⁺ + NH₃·H₂O = AgOH↓ + NH₄⁺'],
  AgCl: ['Ag⁺ + Cl⁻ = AgCl↓'], AgBr: ['Ag⁺ + Br⁻ = AgBr↓'], AgI: ['Ag⁺ + I⁻ = AgI↓'], BaSO4: ['Ba²⁺ + SO₄²⁻ = BaSO₄↓'], CaSO4: ['Ca²⁺ + SO₄²⁻ = CaSO₄↓'],
  CaCO3: ['Ca²⁺ + CO₃²⁻ = CaCO₃↓'], BaCO3: ['Ba²⁺ + CO₃²⁻ = BaCO₃↓'], CaOH: ['Ca²⁺ + 2OH⁻ = Ca(OH)₂↓']
};
const HD = {
  Fe3: 'Fe(OH)₃ + 3H⁺ = Fe³⁺ + 3H₂O', Al: 'Al(OH)₃ + 3H⁺ = Al³⁺ + 3H₂O', Cu: 'Cu(OH)₂ + 2H⁺ = Cu²⁺ + 2H₂O', Zn: 'Zn(OH)₂ + 2H⁺ = Zn²⁺ + 2H₂O',
  Fe2: 'Fe(OH)₂ + 2H⁺ = Fe²⁺ + 2H₂O', Mg: 'Mg(OH)₂ + 2H⁺ = Mg²⁺ + 2H₂O', Ag: 'Ag₂O + 2H⁺ = 2Ag⁺ + H₂O',
  CaCO3: 'CaCO₃ + 2H⁺ = Ca²⁺ + CO₂↑ + H₂O', BaCO3: 'BaCO₃ + 2H⁺ = Ba²⁺ + CO₂↑ + H₂O'
};
// 一次性事件：[方程式, 现象]
const EV = {
  'm:Na': ['2Na + 2H₂O = 2Na⁺ + 2OH⁻ + H₂↑', '钠浮在水面上，熔成闪亮的小球，四处游动，发出嘶嘶声'],
  'm:Zn-H': ['Zn + 2H⁺ = Zn²⁺ + H₂↑', '锌粒表面产生气泡'],
  'm:Mg-H': ['Mg + 2H⁺ = Mg²⁺ + H₂↑', '反应剧烈，产生大量气泡，容器外壁发热'],
  'm:Fe-H': ['Fe + 2H⁺ = Fe²⁺ + H₂↑', '铁表面缓慢产生气泡，溶液逐渐变为浅绿色'],
  'm:Al-H': ['2Al + 6H⁺ = 2Al³⁺ + 3H₂↑', '铝片表面产生气泡'],
  'm:Al-OH': ['2Al + 2OH⁻ + 6H₂O = 2[Al(OH)₄]⁻ + 3H₂↑', '铝片在碱溶液中溶解，产生气泡（旧教材写作 2Al + 2OH⁻ + 2H₂O = 2AlO₂⁻ + 3H₂↑）'],
  'g:cell': ['', '金属表面析出的铜（或银）与原金属在酸中构成原电池，产生气泡的速率明显加快'],
  'm:CaCO3': ['CaCO₃ + 2H⁺ = Ca²⁺ + CO₂↑ + H₂O', '大理石表面产生大量气泡'],
  'm:CaCO3-HAc': ['CaCO₃ + 2CH₃COOH = Ca²⁺ + 2CH₃COO⁻ + CO₂↑ + H₂O', '产生气泡，比盐酸中慢（醋酸是弱酸）'],
  'm:CaCO3-SO4': ['', '生成的 CaSO₄ 微溶，覆盖在大理石表面，反应逐渐停止'],
  'd:Zn-Cu': ['Zn + Cu²⁺ = Zn²⁺ + Cu', '锌表面析出红色的铜，溶液蓝色变浅'],
  'd:Fe-Cu': ['Fe + Cu²⁺ = Fe²⁺ + Cu', '铁表面析出红色的铜，溶液由蓝色逐渐变为浅绿色'],
  'd:Mg-Cu': ['Mg + Cu²⁺ = Mg²⁺ + Cu', '镁条表面析出红色的铜'],
  'd:Al-Cu': ['2Al + 3Cu²⁺ = 2Al³⁺ + 3Cu', '铝片表面析出红色的铜，溶液蓝色变浅'],
  'd:Cu-Ag': ['Cu + 2Ag⁺ = Cu²⁺ + 2Ag', '铜片表面析出银白色的银，溶液逐渐变蓝'],
  'd:Zn-Ag': ['Zn + 2Ag⁺ = Zn²⁺ + 2Ag', '锌表面析出银白色固体'],
  'd:Fe-Ag': ['Fe + 2Ag⁺ = Fe²⁺ + 2Ag', '铁表面析出银白色固体'],
  'd:Mg-Ag': ['Mg + 2Ag⁺ = Mg²⁺ + 2Ag', '镁条表面析出银白色固体'],
  'd:Al-Ag': ['Al + 3Ag⁺ = Al³⁺ + 3Ag', '铝片表面析出银白色固体'],
  'd:Fe-Fe3': ['Fe + 2Fe³⁺ = 3Fe²⁺', '溶液由黄色变为浅绿色'],
  'd:Cu-Fe3': ['Cu + 2Fe³⁺ = Cu²⁺ + 2Fe²⁺', '铜片被溶解，溶液变为蓝绿色（印刷电路板的腐蚀原理）'],
  'd:Zn-Fe3': ['Zn + 2Fe³⁺ = Zn²⁺ + 2Fe²⁺', '溶液黄色变浅'],
  'd:Mg-Fe3': ['Mg + 2Fe³⁺ = Mg²⁺ + 2Fe²⁺', '溶液黄色变浅'],
  'd:Al-Fe3': ['Al + 3Fe³⁺ = Al³⁺ + 3Fe²⁺', '溶液黄色变浅'],
  'd:Zn-Fe2': ['Zn + Fe²⁺ = Zn²⁺ + Fe', '锌表面附着一层黑色的铁粉，溶液浅绿色逐渐褪去'],
  'd:Mg-Fe2': ['Mg + Fe²⁺ = Mg²⁺ + Fe', '镁条表面附着黑色的铁粉，溶液浅绿色逐渐褪去'],
  'd:Al-Fe2': ['2Al + 3Fe²⁺ = 2Al³⁺ + 3Fe', '铝片表面附着黑色的铁粉'],
  'd:Mg-Zn': ['Mg + Zn²⁺ = Mg²⁺ + Zn', '镁条表面析出银灰色的锌'],
  'd:Al-Zn': ['2Al + 3Zn²⁺ = 2Al³⁺ + 3Zn', '铝片表面析出银灰色的锌'],
  'x:Cu': ['3Cu + 8H⁺ + 2NO₃⁻ = 3Cu²⁺ + 2NO↑ + 4H₂O', '铜片逐渐溶解，溶液变蓝；产生无色气体，在容器口变成红棕色（2NO + O₂ = 2NO₂）'],
  'x:Fe': ['Fe + 4H⁺ + NO₃⁻ = Fe³⁺ + NO↑ + 2H₂O', '铁溶解，溶液变黄，容器口出现红棕色气体'],
  'x:Zn': ['3Zn + 8H⁺ + 2NO₃⁻ = 3Zn²⁺ + 2NO↑ + 4H₂O', '锌溶解但不放出 H₂，容器口出现红棕色气体'],
  'x:Mg': ['3Mg + 8H⁺ + 2NO₃⁻ = 3Mg²⁺ + 2NO↑ + 4H₂O', '镁条溶解，容器口出现红棕色气体'],
  'x:Al': ['Al + 4H⁺ + NO₃⁻ = Al³⁺ + NO↑ + 2H₂O', '铝片溶解，容器口出现红棕色气体'],
  'r:Fe2-HNO3': ['3Fe²⁺ + 4H⁺ + NO₃⁻ = 3Fe³⁺ + NO↑ + 2H₂O', '溶液由浅绿色变为黄色，容器口出现红棕色气体'],
  'h2o2-MnO2': ['2H₂O₂ =MnO₂= 2H₂O + O₂↑', '迅速产生大量气泡，MnO₂ 作催化剂'],
  'h2o2-Fe3': ['2H₂O₂ =Fe³⁺= 2H₂O + O₂↑', '产生大量气泡，Fe³⁺ 起催化作用'],
  'h2o2-heat': ['2H₂O₂ =△= 2H₂O + O₂↑', '受热后 H₂O₂ 分解加快，产生气泡'],
  'r:MnO4-Fe2': ['MnO₄⁻ + 5Fe²⁺ + 8H⁺ = Mn²⁺ + 5Fe³⁺ + 4H₂O', '高锰酸钾的紫红色褪去'],
  'r:MnO4-H2O2': ['2MnO₄⁻ + 5H₂O₂ + 6H⁺ = 2Mn²⁺ + 5O₂↑ + 8H₂O', '紫红色褪去，产生气泡'],
  'r:Cl2-I': ['Cl₂ + 2I⁻ = 2Cl⁻ + I₂', '溶液变为黄褐色'],
  'r:Cl2-Fe2': ['Cl₂ + 2Fe²⁺ = 2Fe³⁺ + 2Cl⁻', '溶液由浅绿色变为黄色'],
  'r:Fe3-I': ['2Fe³⁺ + 2I⁻ = 2Fe²⁺ + I₂', '生成 I₂，溶液颜色加深'],
  'r:H2O2-I': ['H₂O₂ + 2I⁻ + 2H⁺ = I₂ + 2H₂O', '溶液逐渐变为黄褐色'],
  'r:Cl2-Br': ['Cl₂ + 2Br⁻ = 2Cl⁻ + Br₂', '溶液由无色变为橙黄色'],
  'r:Br2-I': ['Br₂ + 2I⁻ = 2Br⁻ + I₂', '溶液由橙黄色变为黄褐色'],
  'r:Br2-Fe2': ['Br₂ + 2Fe²⁺ = 2Fe³⁺ + 2Br⁻', '溴水褪色，溶液变为黄色'],
  'r:bleach': ['Cl₂ + H₂O ⇌ H⁺ + Cl⁻ + HClO', 'HClO 有漂白性，指示剂的颜色逐渐褪去'],
  'r:H2O2-phth': ['', v => v.added.includes('Na₂O₂') ? '溶液先变红，随后红色褪去：Na₂O₂ 与水反应的过程中生成了 H₂O₂，具有强氧化性（漂白作用）' : '酚酞的红色逐渐褪去：H₂O₂ 具有强氧化性（漂白作用）'],
  'r:CO3-H1': ['CO₃²⁻ + H⁺ = HCO₃⁻', '开始时没有气泡：CO₃²⁻ 先与 H⁺ 结合成 HCO₃⁻，H⁺ 再多时才放出 CO₂'],
  'r:NH3': [v => v.added.some(a => /NH₄/.test(a)) ? 'NH₄⁺ + OH⁻ =△= NH₃↑ + H₂O' : 'NH₃·H₂O =△= NH₃↑ + H₂O', '产生有刺激性气味的气体，能使湿润的红色石蕊试纸变蓝（检验 NH₄⁺）'],
  's:Na2O2': ['2Na₂O₂ + 2H₂O = 4Na⁺ + 4OH⁻ + O₂↑', '淡黄色固体溶解，产生大量气泡，放出热量；气体能使带火星的木条复燃'],
  's:CaO': ['CaO + H₂O = Ca(OH)₂', '生石灰与水反应，放出大量的热'],
  's:NaOH': ['', 'NaOH 固体溶于水时放出大量的热，溶液温度明显升高'],
  's:NH4NO3': ['', 'NH₄NO₃ 固体溶于水时吸收热量，溶液温度降低'],
  'k:I2': ['', '振荡后静置：液体分层，下层（CCl₄ 层）呈紫红色，上层颜色变浅。I₂ 在 CCl₄ 中的溶解度比在水中大得多（萃取）'],
  'k:Br2': ['', '振荡后静置：液体分层，下层（CCl₄ 层）呈橙红色，上层颜色变浅（萃取）'],
  'r:Fe(OH)2-air': ['4Fe(OH)₂ + O₂ + 2H₂O = 4Fe(OH)₃', '白色沉淀迅速变成灰绿色，最后变成红褐色'],
  'r:CuO': ['Cu(OH)₂ =△= CuO + H₂O', '蓝色沉淀受热变成黑色'],
  'r:CuO-H': ['CuO + 2H⁺ = Cu²⁺ + H₂O', '黑色固体溶解，溶液变蓝'],
  'r:CO2': [(v, e) => v.T > 60 && e.pH > 6.5 ? '2HCO₃⁻ =△= CO₃²⁻ + CO₂↑ + H₂O' : v.ev.has('r:CO3-H1') || v.added.includes('NaHCO₃') && !v.added.includes('Na₂CO₃') ? 'HCO₃⁻ + H⁺ = CO₂↑ + H₂O' : 'CO₃²⁻ + 2H⁺ = CO₂↑ + H₂O', '产生大量气泡（CO₂）'],
  'r:boil': ['', '溶液沸腾'],
  'c:FeSCN': ['Fe³⁺ + 3SCN⁻ = Fe(SCN)₃', '溶液变成红色（检验 Fe³⁺）'],
  'c:starch': ['', '淀粉遇 I₂ 变蓝'],
  'c:CuN': ['Cu²⁺ + 4NH₃ = [Cu(NH₃)₄]²⁺', '溶液变为深蓝色'],
  'n:s': ['H⁺ + OH⁻ = H₂O', '酸碱中和'], 'n:a': ['CH₃COOH + OH⁻ = CH₃COO⁻ + H₂O', '酸碱中和'],
  'n:b': ['NH₃·H₂O + H⁺ = NH₄⁺ + H₂O', '酸碱中和'], 'n:ab': ['CH₃COOH + NH₃·H₂O = CH₃COO⁻ + NH₄⁺ + H₂O', '酸碱中和']
};

// 试剂：a 为每毫升所含物质的量（mmol），即 mol/L
const RG = [
  { s: 'acid', id: 'HCl', n: '稀盐酸', f: 'HCl', c: '1 mol/L', a: { Cl: 1 } },
  { s: 'acid', id: 'H2SO4', n: '稀硫酸', f: 'H₂SO₄', c: '0.5 mol/L', a: { SO4: .5 } },
  { s: 'acid', id: 'HNO3', n: '稀硝酸', f: 'HNO₃', c: '2 mol/L', a: { NO3: 2 } },
  { s: 'acid', id: 'HAc', n: '醋酸', f: 'CH₃COOH', c: '1 mol/L', a: { A: 1 } },
  { s: 'acid', id: 'NaOH', n: '氢氧化钠溶液', f: 'NaOH', c: '1 mol/L', a: { Na: 1 } },
  { s: 'acid', id: 'NH3', n: '氨水', f: 'NH₃·H₂O', c: '2 mol/L', a: { N: 2 } },
  { s: 'acid', id: 'CaOH2', n: '澄清石灰水', f: 'Ca(OH)₂', c: '0.02 mol/L', a: { Ca: .02 } },
  { s: 'salt', id: 'NaCl', n: '氯化钠溶液', f: 'NaCl', c: '0.5 mol/L', a: { Na: .5, Cl: .5 } },
  { s: 'salt', id: 'Na2CO3', n: '碳酸钠溶液', f: 'Na₂CO₃', c: '0.5 mol/L', a: { Na: 1, C: .5 } },
  { s: 'salt', id: 'NaHCO3', n: '碳酸氢钠溶液', f: 'NaHCO₃', c: '0.5 mol/L', a: { Na: .5, C: .5 } },
  { s: 'salt', id: 'Na2SO4', n: '硫酸钠溶液', f: 'Na₂SO₄', c: '0.5 mol/L', a: { Na: 1, SO4: .5 } },
  { s: 'salt', id: 'NH4Cl', n: '氯化铵溶液', f: 'NH₄Cl', c: '1 mol/L', a: { N: 1, Cl: 1 } },
  { s: 'salt', id: 'CuSO4', n: '硫酸铜溶液', f: 'CuSO₄', c: '0.5 mol/L', a: { Cu: .5, SO4: .5 } },
  { s: 'salt', id: 'ZnSO4', n: '硫酸锌溶液', f: 'ZnSO₄', c: '0.5 mol/L', a: { Zn: .5, SO4: .5005 } },
  { s: 'salt', id: 'FeCl3', n: '氯化铁溶液', f: 'FeCl₃', c: '0.2 mol/L', a: { Fe3: .2, Cl: .7 } },
  { s: 'salt', id: 'FeSO4', n: '硫酸亚铁溶液', f: 'FeSO₄', c: '0.2 mol/L', a: { Fe2: .2, SO4: .205 } },
  { s: 'salt', id: 'AlCl3', n: '氯化铝溶液', f: 'AlCl₃', c: '0.5 mol/L', a: { Al: .5, Cl: 1.52 } },
  { s: 'salt', id: 'MgCl2', n: '氯化镁溶液', f: 'MgCl₂', c: '0.5 mol/L', a: { Mg: .5, Cl: 1 } },
  { s: 'salt', id: 'CaCl2', n: '氯化钙溶液', f: 'CaCl₂', c: '0.5 mol/L', a: { Ca: .5, Cl: 1 } },
  { s: 'salt', id: 'BaCl2', n: '氯化钡溶液', f: 'BaCl₂', c: '0.2 mol/L', a: { Ba: .2, Cl: .4 } },
  { s: 'salt', id: 'AgNO3', n: '硝酸银溶液', f: 'AgNO₃', c: '0.1 mol/L', a: { Ag: .1, NO3: .1 } },
  { s: 'salt', id: 'KBr', n: '溴化钾溶液', f: 'KBr', c: '0.1 mol/L', a: { K: .1, Br: .1 } },
  { s: 'salt', id: 'KI', n: '碘化钾溶液', f: 'KI', c: '0.1 mol/L', a: { K: .1, I: .1 } },
  { s: 'salt', id: 'KSCN', n: '硫氰化钾溶液', f: 'KSCN', c: '0.1 mol/L', a: { K: .1, SCN: .1 } },
  { s: 'redox', id: 'H2O2', n: '过氧化氢溶液', f: 'H₂O₂', c: '3%', a: { H2O2: .9 } },
  { s: 'redox', id: 'KMnO4', n: '酸性高锰酸钾', f: 'KMnO₄', c: '0.02 mol/L，含 H₂SO₄', a: { K: .02, MnO4: .02, SO4: .5 } },
  { s: 'redox', id: 'Cl2', n: '新制氯水', f: 'Cl₂', c: '约 0.04 mol/L', a: { Cl2: .04, Cl: .02 } },
  { s: 'redox', id: 'Br2', n: '溴水', f: 'Br₂', c: '约 0.02 mol/L', a: { Br2: .02 } },
  { s: 'redox', id: 'I2', n: '碘水', f: 'I₂', c: '0.005 mol/L', a: { I2: .005, K: .01, I: .01 } },
  { s: 'ind', id: 'phth', n: '酚酞试液', f: '酚酞', a: { phth: 20 }, drop: true },
  { s: 'ind', id: 'lit', n: '紫色石蕊试液', f: '石蕊', a: { lit: 20 }, drop: true },
  { s: 'ind', id: 'mo', n: '甲基橙试液', f: '甲基橙', a: { mo: 20 }, drop: true },
  { s: 'ind', id: 'starch', n: '淀粉溶液', f: '淀粉', a: { starch: 20 }, drop: true },
  { s: 'gas', id: 'H2O', n: '蒸馏水', f: 'H₂O', a: {} },
  { s: 'gas', id: 'CCl4', n: '四氯化碳', f: 'CCl₄', c: '不溶于水，密度比水大', a: {}, oil: true }
];
const SO = {
  Zn: { n: '锌粒', f: 'Zn', mm: 3, A: 1, M: 65.4, col: '#9aa3a8' },
  Fe: { n: '铁钉', f: 'Fe', mm: 15, A: 1, M: 55.8, col: '#6d747a' },
  Mg: { n: '镁条', f: 'Mg', mm: 2, A: 3, M: 24.3, col: '#c9ced2' },
  Al: { n: '铝片', f: 'Al', mm: 3.5, A: 1.5, M: 27, col: '#d4d8dc' },
  Cu: { n: '铜片', f: 'Cu', mm: 8, A: 1, M: 63.5, col: '#c27140' },
  Na: { n: '金属钠', f: 'Na', mm: 2.2, A: 1, M: 23, col: '#e2e4de' },
  CaCO3: { n: '大理石', f: 'CaCO₃', mm: 10, A: 1.5, M: 100.1, col: '#dedad0' },
  MnO2: { n: '二氧化锰', f: 'MnO₂', mm: 2, A: 1, M: 86.9, col: '#2b2724' },
  Na2O2: { n: '过氧化钠', f: 'Na₂O₂', mm: 3, A: 1, M: 78, col: '#ecd577' },
  CaO: { n: '生石灰', f: 'CaO', mm: 5, A: 1, M: 56.1, col: '#e9e7dc' },
  NaOHs: { n: '氢氧化钠固体', f: 'NaOH(s)', mm: 25, A: 1.2, M: 40, col: '#f4f4f0' },
  NH4NO3: { n: '硝酸铵固体', f: 'NH₄NO₃(s)', mm: 25, A: 1.2, M: 80, col: '#efeee6' }
};
// 能溶于水（或与水反应）的固体：速率、进入溶液的粒子（每 mmol）、放热 J/mmol（负值为吸热）
const DSV = {
  Na2O2: { r: 1, add: { Na: 2 }, H: 143, ev: 's:Na2O2' },
  CaO: { r: .8, add: { Ca: 1 }, H: 65, ev: 's:CaO' },
  NaOHs: { r: 2.5, add: { Na: 1 }, H: 44.5, ev: 's:NaOH' },
  NH4NO3: { r: 2.5, add: { N: 1, NO3: 1 }, H: -25.7, ev: 's:NH4NO3' }
};
const MI = { Zn: 'Zn', Fe: 'Fe2', Mg: 'Mg', Al: 'Al', Cu: 'Cu' };
const COAT = { Cu: '#b4552d', Ag: '#d8dadb', Fe: '#3b3c3e', Zn: '#9ea6ac' }, COATN = { Cu: '铜', Ag: '银', Fe: '铁', Zn: '锌' };
const NIT = { Cu: ['Cu', 2, .06], Fe: ['Fe3', 3, .04], Zn: ['Zn', 2, .1], Mg: ['Mg', 2, .4], Al: ['Al', 3, .04] }; // 稀硝酸：产物离子、失电子数、速率
const HM = { Zn: 153, Fe: 89, Mg: 467, Al: 530 };  // 每 mmol 金属与酸反应放热（J）
const DISP = { // 金属 → [离子, 每 mol 金属消耗的离子, 析出物]
  Zn: [['Cu', 1, 'Cu'], ['Ag', 2, 'Ag'], ['Fe3', 2, null], ['Fe2', 1, 'Fe']], Fe: [['Cu', 1, 'Cu'], ['Ag', 2, 'Ag'], ['Fe3', 2, null]],
  Mg: [['Cu', 1, 'Cu'], ['Ag', 2, 'Ag'], ['Fe3', 2, null], ['Fe2', 1, 'Fe'], ['Zn', 1, 'Zn']],
  Al: [['Cu', 1.5, 'Cu'], ['Ag', 3, 'Ag'], ['Fe3', 3, null], ['Fe2', 1.5, 'Fe'], ['Zn', 1.5, 'Zn']], Cu: [['Ag', 2, 'Ag'], ['Fe3', 2, null]]
};

// 容器内壁轮廓：[半宽, 高]（px，自底向上）
function prof(k) {
  if (k === 'tube') { const r = 13, p = []; for (let i = 0; i <= 8; i++) { const a = i / 8 * PI / 2; p.push([r * Math.sin(a), r - r * Math.cos(a)]); } p.push([r, 165]); return p; }
  if (k === 'beaker') return [[50, 0], [55, 4], [56, 10], [56, 132]];
  return [[54, 0], [59, 4], [60, 10], [20, 94], [16, 106], [16, 152]];
}
const VT = { tube: { n: '试管', cap: 20, full: .9, glass: 8 }, beaker: { n: '烧杯', cap: 200, full: .9, glass: 40 }, flask: { n: '锥形瓶', cap: 250, full: .74, glass: 50 } };
for (const k in VT) {
  const t = VT[k], p = prof(k); t.p = p; t.H = p[p.length - 1][1]; t.W = Math.max(...p.map(q => q[0]));
  t.hw = y => { for (let i = 1; i < p.length; i++) if (y <= p[i][1]) return lerp(p[i - 1][0], p[i][0], (y - p[i - 1][1]) / ((p[i][1] - p[i - 1][1]) || 1)); return p[p.length - 1][0]; };
  const cum = [0]; for (let y = 1; y <= t.H; y++) cum.push(cum[y - 1] + PI * t.hw(y - .5) ** 2);
  const sc = t.cap / cum[Math.round(t.H * t.full)];
  t.lvl = V => { const q = V / sc; if (q <= 0) return 0; for (let y = 1; y <= t.H; y++) if (cum[y] >= q) return y - 1 + (q - cum[y - 1]) / (cum[y] - cum[y - 1]); return t.H; };
}

/* ---------- 溶液平衡 ---------- */
function eqm(t, Vml, pHg, T = 25) {
  const g = k => t[k] > 0 ? t[k] : 0, V = Math.max(Vml, .05);
  const sq = (a, b, k) => Math.max(0, Math.min(a, b, ((a + b) - Math.sqrt((a - b) ** 2 + 4 * k)) / 2));
  let Ag = g('Ag'), I = g('I'), Br = g('Br'), Cl = g('Cl'), Ba = g('Ba'), SO4 = g('SO4');
  const pAgI = Math.min(Ag, I); Ag -= pAgI; I -= pAgI;
  const pAgBr = Math.min(Ag, Br); Ag -= pAgBr; Br -= pAgBr;
  const pAgCl = Math.min(Ag, Cl); Ag -= pAgCl; Cl -= pAgCl;
  const pBaSO4 = Math.min(Ba, SO4); Ba -= pBaSO4; SO4 -= pBaSO4;
  const pCaSO4 = sq(g('Ca'), SO4, 4.9e-5 * V * V); SO4 -= pCaSO4; // CaSO₄ 微溶
  const q0 = g('Na') + g('K') + 2 * g('Mn') - Cl - Br - 2 * SO4 - g('NO3') - I - g('SCN') - g('MnO4');
  const Ct = g('C'), Nt = g('N'), At = g('A'), Ca0 = g('Ca') - pCaSO4;
  const kCa = 5e-5 * 10 ** (-(T - 25) * .014); // Ca(OH)₂ 微溶，溶解度随温度升高而减小
  const M = { Fe3: g('Fe3'), Al: g('Al'), Cu: g('Cu'), Zn: g('Zn'), Fe2: g('Fe2'), Mg: g('Mg'), Ag };
  const K1 = 4.5e-7, K2 = 4.7e-11, KN = 5.6e-10, KA = 1.75e-5;
  const LG = { Cu: [1e15, 4], Zn: [3e11, 4], Ag: [1.7e7, 2] }; // 氨配合物：β、配体数
  const cplx = Nt > 0 && (M.Cu || M.Zn || M.Ag);
  let r = null;
  const f = (h, keep) => {
    const oh = 1e-14 / h;
    let nh3 = 0, nh4 = 0;
    if (cplx) { // 氨的物料守恒：游离 NH₃ + NH₄⁺ + 配位的 NH₃ = 总量
      const used = x => { let s = x * V * (1 + h / KN); for (const k in LG) { const m = M[k]; if (!m) continue; const [b, nl] = LG[k], n = k === 'Ag' ? 1 : 2, cx = 1 + b * x ** nl, d = Math.min(m, ksp(k) / oh ** n * cx * V); s += nl * d * (1 - 1 / cx); } return s; };
      let lo2 = 0, hi2 = Nt / V; for (let i = 0; i < 22; i++) { const m = (lo2 + hi2) / 2; used(m) > Nt ? hi2 = m : lo2 = m; }
      nh3 = lo2; nh4 = nh3 * V * h / KN;
    } else { nh4 = Nt * h / (h + KN); nh3 = (Nt - nh4) / V; }
    const Dn = h * h + h * K1 + K1 * K2, a0 = h * h / Dn, a1 = h * K1 / Dn, a2 = K1 * K2 / Dn;
    const pCa = Ct > 0 && Ca0 > 0 ? sq(Ca0, Ct, 2e-7 * V * V / a2) : 0;
    const pBa = Ct - pCa > 0 && Ba > 0 ? sq(Ba, Ct - pCa, 5e-8 * V * V / a2) : 0;
    const C = Ct - pCa - pBa, ac = At * KA / (h + KA);
    const caF = Ca0 - pCa, dCa = Math.min(caF, kCa / (oh * oh) * V);
    let q = q0 + 2 * dCa + 2 * (Ba - pBa) + nh4 - C * (a1 + 2 * a2) - ac + (h - oh) * V;
    const free = {}, pm = {}; let cuN = 0, agN = 0, znN = 0, alO = 0, znO = 0;
    for (const [k, n, ksp] of HY) {
      const m = M[k]; free[k] = 0; pm[k] = 0; if (!m) continue;
      const fr = ksp / oh ** n;
      let cx = 1; if (k === 'Cu') cx += 1e15 * nh3 ** 4; else if (k === 'Zn') cx += 3e11 * nh3 ** 4; else if (k === 'Ag') cx += 1.7e7 * nh3 ** 2;
      // 两性：Al(OH)₃ + OH⁻ ⇌ [Al(OH)₄]⁻，Zn(OH)₂ + 2OH⁻ ⇌ [Zn(OH)₄]²⁻
      const an = k === 'Al' ? 10 * oh : k === 'Zn' ? 3 * oh * oh : 0, za = k === 'Al' ? 1 : 2;
      const capT = (fr * cx + an) * V, dd = Math.min(m, capT), fc = capT > 0 ? fr * cx / (fr * cx + an) : 1;
      q += dd * (fc * n - (1 - fc) * za); pm[k] = m - dd; free[k] = dd * fc / cx;
      if (keep) { const cn = dd * fc * (1 - 1 / cx); if (k === 'Cu') cuN = cn; else if (k === 'Ag') agN = cn; else if (k === 'Zn') { znN = cn; znO = dd * (1 - fc); } if (k === 'Al') alO = dd * (1 - fc); }
    }
    if (keep) r = {
      h, oh, p: { AgI: pAgI, AgBr: pAgBr, AgCl: pAgCl, BaSO4: pBaSO4, CaSO4: pCaSO4, CaCO3: pCa, BaCO3: pBa, CaOH: caF - dCa, ...pm },
      dis: { Na: g('Na'), K: g('K'), Mn: g('Mn'), Cl, Br, SO4, NO3: g('NO3'), I, SCN: g('SCN'), MnO4: g('MnO4'), Ca: dCa, Ba: Ba - pBa, ...free },
      cuN, agN, znN, alO, znO, h2co3: C * a0, hco3: C * a1, co3: C * a2, nh3: nh3 * V, nh4, hac: At - ac, ac
    };
    return q;
  };
  let lo = -16, hi = 1.5, it = 46;
  if (pHg != null && isFinite(pHg)) { const a = -pHg - .5, b = -pHg + .5; if (f(10 ** a) < 0 && f(10 ** b) > 0) { lo = a; hi = b; it = 20; } }
  if (f(10 ** hi) < 0) lo = hi; else if (f(10 ** lo) > 0) hi = lo;
  else for (let i = 0; i < it; i++) { const m = (lo + hi) / 2; f(10 ** m) > 0 ? hi = m : lo = m; }
  const h = 10 ** ((lo + hi) / 2); f(h, true); r.pH = -Math.log10(h);
  return r;
}
Bench.chemEqm = eqm; // 供控制台检查溶液模型

/* ---------- 颜色 ---------- */
const hx = c => { const n = parseInt(c.slice(1), 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; };
const css = (c, a = 1) => `rgba(${Math.round(c[0] * 255)},${Math.round(c[1] * 255)},${Math.round(c[2] * 255)},${a})`;
const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
function ramp(stops, x) {
  if (x <= stops[0][0]) return stops[0][1];
  for (let i = 1; i < stops.length; i++) if (x <= stops[i][0]) return mix3(stops[i - 1][1], stops[i][1], (x - stops[i - 1][0]) / (stops[i][0] - stops[i - 1][0]));
  return stops[stops.length - 1][1];
}
const LIT = [[4.5, [.92, .33, .38]], [6.5, [.62, .42, .78]], [8.5, [.32, .48, .95]]];
const MO = [[3.1, [.95, .28, .26]], [3.75, [1, .58, .24]], [4.4, [1, .86, .32]]];
const PHP = [[1, '#d7262b'], [3, '#f0702b'], [5, '#f2c230'], [7, '#5ea93c'], [9, '#23908a'], [11, '#2b5ea8'], [13, '#4a368e']].map(([p, c]) => [p, hx(c)]);
function tint(t, Vml, e, aq = 1, aqB = aq) { // 溶液对 r、g、b 的透射率；aq、aqB：I₂、Br₂ 留在水层的比例
  const V = Math.max(Vml, .05); let r = 1, g = 1, b = 1;
  const ap = (T, s) => { if (!(s > 1e-3)) return; s = Math.min(s, 6); r *= T[0] ** s; g *= T[1] ** s; b *= T[2] ** s; };
  const d = k => (e.dis[k] || 0) / V;
  ap([.55, .78, .96], d('Cu') / .1); ap([.2, .3, .9], e.cuN / V / .02);
  ap([.99, .8, .38], d('Fe3') / .1); ap([.86, .97, .84], d('Fe2') / .1);
  ap([.85, .12, .1], Math.min(d('Fe3'), d('SCN')) / .004);
  ap([.62, .12, .62], d('MnO4') / .0015);
  const i2 = (t.I2 || 0) * aq / V;
  if ((t.starch || 0) > .05) ap([.12, .16, .5], i2 / .0004); else ap([.96, .66, .24], i2 / .004);
  ap([.99, .76, .4], (t.Br2 || 0) * aqB / V / .005);
  ap([.93, .98, .72], (t.Cl2 || 0) / V / .04);
  const s = u => Math.min(3, (u || 0) * 3 / Math.sqrt(Vml + 1));
  if (t.phth > .05) ap([.98, .3, .62], 1.4 * s(t.phth) * clamp((e.pH - 8.2) / 1.8, 0, 1));
  if (t.lit > .05) ap(ramp(LIT, e.pH), s(t.lit));
  if (t.mo > .05) ap(ramp(MO, e.pH), s(t.mo));
  return [r, g, b];
}
function tintOil(i2, br2, Vo) { // CCl₄ 层：I₂ 紫红色，Br₂ 橙红色
  let r = 1, g = 1, b = 1; const V = Math.max(Vo, .05);
  const ap = (T, s) => { if (!(s > 1e-3)) return; s = Math.min(s, 6); r *= T[0] ** s; g *= T[1] ** s; b *= T[2] ** s; };
  ap([.8, .3, .72], i2 / V / .006); ap([.97, .52, .26], br2 / V / .012);
  return [r, g, b];
}
const KD = { I2: 85, Br2: 27 }; // 卤素单质在 CCl₄ 与水之间的分配系数
function swatch(r) {
  if (r.oil) return 'rgba(225,232,236,.75)';
  const tt = {}; for (const k in r.a) tt[k] = r.a[k] * 2;
  const c = tint(tt, 2, eqm(tt, 2));
  return c[0] + c[1] + c[2] > 2.9 ? 'rgba(150,195,220,.4)' : css(c);
}

/* ---------- 图标 ---------- */
const ic = {
  tube: '<svg viewBox="0 0 24 24"><path d="M10 2.5h4M10.6 3v15a1.4 1.4 0 0 0 2.8 0V3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M10.6 12h2.8v6a1.4 1.4 0 0 1-2.8 0z" fill="#6fb6e0"/></svg>',
  beaker: '<svg viewBox="0 0 24 24"><path d="M5 4h14M6 4v15a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V4" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M6.7 12h10.6v7.3H6.7z" fill="#6fb6e0"/></svg>',
  flask: '<svg viewBox="0 0 24 24"><path d="M9.5 3h5M10 3v6l-5 10a1 1 0 0 0 1 1.4h12a1 1 0 0 0 1-1.4l-5-10V3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M7.4 15h9.2l2.2 4.6H5.2z" fill="#6fb6e0"/></svg>',
  lamp: '<svg viewBox="0 0 24 24"><path d="M12 3c2 3 2.4 4.6 0 7-2.4-2.4-2-4 0-7z" fill="#f29a2e"/><path d="M11 10h2v3h-2zM7 15a5 4 0 0 1 10 0v5H7z" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',
  bottle: c => `<svg viewBox="0 0 24 24"><path d="M9.5 2.5h5v3l2.5 3.5v11a1.5 1.5 0 0 1-1.5 1.5h-7A1.5 1.5 0 0 1 7 20V9l2.5-3.5z" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M7.7 11.5h8.6v8.3a.9.9 0 0 1-.9.9H8.6a.9.9 0 0 1-.9-.9z" fill="${c}"/></svg>`,
  dropper: c => `<svg viewBox="0 0 24 24"><path d="M10 2.5h4v5h-4z" fill="#b54a3c"/><path d="M10.6 7.5v9.5L12 21l1.4-4V7.5" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M10.9 12h2.2v4.6L12 19.6l-1.1-3z" fill="${c}"/></svg>`,
  solid: c => `<svg viewBox="0 0 24 24"><path d="M5 15l4-6 6-1 4 5-2 6-8 1z" fill="${c}" stroke="currentColor" stroke-width="1.1"/></svg>`,
  gas: '<svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="3" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="15" cy="9" r="4" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="16" cy="18" r="2" fill="none" stroke="currentColor" stroke-width="1.3"/></svg>'
};

const ART = `<svg viewBox="0 0 160 110"><rect x="0" y="92" width="160" height="18" fill="currentColor" opacity=".08"/>
  <path d="M30 26h40M34 26v62a4 4 0 0 0 4 4h24a4 4 0 0 0 4-4V26" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M35.5 58h29v29.5a3 3 0 0 1-3 3h-23a3 3 0 0 1-3-3z" fill="#4a8edb" opacity=".75"/>
  <circle cx="44" cy="70" r="2.4" fill="#fff" opacity=".8"/><circle cx="52" cy="62" r="1.6" fill="#fff" opacity=".8"/>
  <path d="M100 14h16M102 14v28l-18 40a5 5 0 0 0 5 7h38a5 5 0 0 0 5-7l-18-40V14" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M92 66h32l9 19a3 3 0 0 1-3 4H86a3 3 0 0 1-3-4z" fill="#e85a9a" opacity=".7"/>
  <path d="M136 10v34" stroke="currentColor" stroke-width="1.6"/><circle cx="136" cy="50" r="2.2" fill="#e85a9a"/></svg>`;

Bench.reg({
  id: 'chem', subj: 'chem', short: '化学', title: '化学工作台', sub: '试剂 · 器材 · 反应现象与方程式',
  desc: '试管、烧杯、锥形瓶、酒精灯，三十多种试剂和十余种固体。滴加、倾倒、加热、萃取、检验气体，自动显示沉淀、气泡、颜色变化、温度、pH 和离子方程式。',
  art: ART,
  init(B) {
    const L = B.L, c = L.canvas();
    const st = { amt: 2, speed: 1 };
    const objs = [], cnt = { tube: 0, beaker: 0, flask: 0 }, log = [];
    let sel = null, uid = 0, S = 1, TY = 0, clock = 0, ui = null;
    const vessels = () => objs.filter(o => o.kind === 'v'), lamps = () => objs.filter(o => o.kind === 'lamp');
    const layout = () => { S = clamp(Math.min(c.h / 460, c.w / 500), .62, 1.6); TY = c.h - 66 * S; };
    const add = (t, k, x) => { t[k] = (t[k] || 0) + x; };

    /* ---- 对象 ---- */
    const outerW = v => (VT[v.type].W + 3) * S;
    const halfW = o => o.kind === 'lamp' ? Math.max(52 * S, o.v ? outerW(o.v) : 0) : outerW(o);
    const base = v => (v.lamp ? TY - (v.type === 'tube' ? 84 : 112) * S : TY) - v.lift;
    const topY = v => base(v) - VT[v.type].H * S;
    const okX = (o, x) => { const hw = halfW(o); if (x < hw + 6 || x > c.w - hw - 6) return false; return objs.every(u => u === o || u === o.v || u === o.lamp || (u.kind === 'v' && u.lamp) || Math.abs(u.x - x) > hw + halfW(u) + 8 * S); };
    const nearFree = (o, x0) => { for (let d = 0; d < c.w; d += 6) { if (okX(o, x0 - d)) return x0 - d; if (okX(o, x0 + d)) return x0 + d; } return clamp(x0, 40, c.w - 40); };
    function newV(type, x) {
      if (vessels().length >= 8) { B.toast('台面上最多放 8 个容器'); return null; }
      cnt[type]++;
      const v = { kind: 'v', id: ++uid, type, x: 0, name: VT[type].n + ' ' + cnt[type], tot: {}, V: 0, T: 25, solids: [], pp: {}, bub: [], ev: new Set(), gas: { H2: 0, O2: 0, CO2: 0, NO: 0, NH3: 0 }, bacc: 0, tacc: 0, added: [], ind: {}, feed: [], anims: [], lamp: null, lift: 0, foam: 0, last: '', stir: 0, test: null, pour: null, oil: 0, ex: 0, prevA: {} };
      v.e = eqm(v.tot, 0); objs.push(v); v.x = nearFree(v, x ?? c.w / 2); return v;
    }
    function newLamp(x) {
      if (lamps().length >= 3) { B.toast('最多放 3 盏酒精灯'); return null; }
      const o = { kind: 'lamp', id: ++uid, x: 0, lit: false, v: null }; objs.push(o); o.x = nearFree(o, x ?? c.w / 2); return o;
    }
    function select(o) { if (sel !== o) { sel = o; inspect(); } L.draw(); }
    function remove(o) {
      if (o.kind === 'v' && o.lamp) o.lamp.v = null;
      if (o.kind === 'lamp' && o.v) { o.v.lamp = null; o.v.x = nearFree(o.v, o.x + 80 * S); }
      objs.splice(objs.indexOf(o), 1); if (sel === o) { sel = null; inspect(); }
    }
    function empty(v) {
      Object.assign(v, { tot: {}, V: 0, T: 25, solids: [], pp: {}, bub: [], added: [], ind: {}, feed: [], foam: 0, last: '', oil: 0, ex: 0, prevA: {} });
      v.ev.clear(); v.gas = { H2: 0, O2: 0, CO2: 0, NO: 0, NH3: 0 }; v.e = eqm(v.tot, 0);
    }
    const liq = v => v.V + (v.oil || 0); // 水层 + CCl₄ 层的总体积
    const lvl = v => VT[v.type].lvl(liq(v));
    const aqF = (v, k) => { const o = v.oil || 0; if (o <= 0 || !v.ex) return 1; const D = KD[k]; return 1 - v.ex * D * o / (D * o + Math.max(v.V, .05)); };
    const note = (v, f) => { const i = v.added.indexOf(f); if (i >= 0) v.added.splice(i, 1); v.added.push(f); if (v.added.length > 6) v.added.shift(); };

    /* ---- 记录与事件 ---- */
    const logBox = el('section', 'rlog', '<h3>反应记录</h3><ol></ol><p class="note">还没有发生反应。往容器里加试剂试试。</p>');
    const tips = el('section', 'info-tips', `<h3>可以试试</h3><ol>
      <li>试管里加硫酸铜溶液，再逐滴（2 滴）加氢氧化钠溶液；然后加稀硫酸。</li>
      <li>氯化铝溶液里逐滴加氢氧化钠溶液至过量；换一支试管改用氨水，对比现象。</li>
      <li>澄清石灰水中反复通入 CO₂，先浑浊后澄清；再放到酒精灯上加热。</li>
      <li>硫酸亚铁溶液中加氢氧化钠溶液，把时间调到 20×，看沉淀颜色的变化。</li>
      <li>铁钉放进硫酸铜溶液；铜片放进硝酸银溶液或氯化铁溶液。</li>
      <li>锥形瓶里放氢氧化钠溶液和酚酞，再分次加入稀盐酸，注意颜色和温度。</li>
      <li>过氧化氢溶液中加二氧化锰，用带火星的木条检验；锌粒与稀盐酸，用燃着的木条检验。</li>
      <li>FeCl₃ 溶液滴入 KSCN；FeSO₄ 溶液先加 KSCN，再加氯水。</li>
      <li>烧杯里加水和酚酞，放入一小块金属钠。</li>
      <li>大理石分别放入稀盐酸、稀硫酸和醋酸中，比较反应快慢。</li></ol>`);
    B.foot.append(logBox, tips);
    function renderLog() {
      const ol = logBox.querySelector('ol'); logBox.querySelector('p').hidden = log.length > 0;
      ol.innerHTML = log.map(r => `<li>${r.eq ? `<b class="eq">${r.eq}</b>` : ''}<span><em>${r.v}</em>${r.ph}</span></li>`).join('');
    }
    function say(v, eq, ph) {
      log.unshift({ v: v.name, eq, ph }); if (log.length > 80) log.pop();
      B.toast(`${eq ? `<b class="eq">${eq}</b>` : ''}<span>${v.name}：${ph}</span>`, { ms: 4800 }); renderLog();
    }
    function ev(v, key) {
      if (v.ev.has(key)) return; v.ev.add(key);
      const d = EV[key], f = x => typeof x === 'function' ? x(v, v.e) : x;
      if (d) say(v, f(d[0]), f(d[1]));
    }
    function pptOn(v, k, e) {
      if (k === 'CuO') return;
      if (k === 'Fe3' && (e.p.Fe2 > .002 || v.ev.has('r:Fe(OH)2-air'))) return;
      if (k === 'CaCO3' && v.T > 60 && v.added.includes('CO₂')) return say(v, 'Ca(HCO₃)₂ =△= CaCO₃↓ + CO₂↑ + H₂O', '受热后溶液又变浑浊');
      if (k === 'CaCO3' && v.last === 'CO2') return say(v, 'CO₂ + Ca²⁺ + 2OH⁻ = CaCO₃↓ + H₂O', '澄清石灰水变浑浊');
      if (k === 'CaOH' && v.last === 'CaO') return say(v, '', '生成的 Ca(OH)₂ 微溶，液体变浑浊（石灰乳）');
      if (k === 'CaOH' && v.T > 33 && !['NaOH', 'NaOHs', 'Na', 'Na2O2'].includes(v.last)) return say(v, '', '溶液变浑浊：Ca(OH)₂ 的溶解度随温度升高而减小');
      // [Al(OH)₄]⁻、[Zn(OH)₄]²⁻ 遇酸或 CO₂ 重新生成沉淀
      if (k === 'Al' && (v.prevA.Al || 0) > .002) return say(v, v.last === 'CO2' ? '[Al(OH)₄]⁻ + CO₂ = Al(OH)₃↓ + HCO₃⁻' : '[Al(OH)₄]⁻ + H⁺ = Al(OH)₃↓ + H₂O', '生成白色胶状沉淀' + (v.last === 'CO2' ? '（CO₂ 过量时沉淀也不溶解）' : '（酸过量时沉淀又会溶解）'));
      if (k === 'Zn' && (v.prevA.Zn || 0) > .002) return say(v, '[Zn(OH)₄]²⁻ + 2H⁺ = Zn(OH)₂↓ + 2H₂O', '生成白色沉淀');
      // Al³⁺、Fe³⁺ 与 HCO₃⁻、CO₃²⁻ 相互促进水解
      const ib = v.added.lastIndexOf('NaHCO₃'), ic = v.added.lastIndexOf('Na₂CO₃');
      if ((k === 'Al' || k === 'Fe3') && (ib >= 0 || ic >= 0) && !v.ev.has('dh')) {
        v.ev.add('dh'); v.ev.add('r:CO2'); const M = k === 'Al' ? 'Al' : 'Fe', P = k === 'Al' ? '白色沉淀' : '红褐色沉淀';
        return say(v, ib > ic ? `${M}³⁺ + 3HCO₃⁻ = ${M}(OH)₃↓ + 3CO₂↑` : `2${M}³⁺ + 3CO₃²⁻ + 3H₂O = 2${M}(OH)₃↓ + 3CO₂↑`, `生成${P}，同时产生大量气泡：两种离子的水解相互促进${k === 'Al' && ib > ic ? '（泡沫灭火器的原理）' : ''}`);
      }
      const f = HF[k]; if (!f) return;
      const nh = v.last === 'NH3' && f[1];
      say(v, f[nh ? 1 : 0], nh && PDN[k] || PD[k]);
    }
    function pptOff(v, k, e) {
      if (v.V < .05) return;
      if (k === 'Fe2' && e.p.Fe3 > .002) return;
      if (k === 'Cu' && (v.tot.CuO || 0) > .002) return;
      if (k === 'Al' && e.pH > 9) return say(v, 'Al(OH)₃ + OH⁻ = [Al(OH)₄]⁻', '白色沉淀溶解：Al(OH)₃ 是两性氢氧化物（旧教材写作 Al(OH)₃ + OH⁻ = AlO₂⁻ + 2H₂O）');
      if (k === 'Cu' && e.cuN > .001) { v.ev.add('c:CuN'); return say(v, 'Cu(OH)₂ + 4NH₃ = [Cu(NH₃)₄]²⁺ + 2OH⁻', '蓝色沉淀溶解，得到深蓝色溶液'); }
      if (k === 'Ag' && e.agN > .001) return say(v, 'AgOH + 2NH₃·H₂O = [Ag(NH₃)₂]⁺ + OH⁻ + 2H₂O', '沉淀恰好溶解，得到银氨溶液');
      if (k === 'Zn' && e.znN > .001) return say(v, 'Zn(OH)₂ + 4NH₃ = [Zn(NH₃)₄]²⁺ + 2OH⁻', '白色沉淀溶解');
      if (k === 'Zn' && e.znO > .001 && e.pH > 9) return say(v, 'Zn(OH)₂ + 2OH⁻ = [Zn(OH)₄]²⁻', '白色沉淀溶解：Zn(OH)₂ 也是两性氢氧化物');
      if (k === 'CaOH') return say(v, '', '浑浊消失：Ca(OH)₂ 溶解');
      if (k === 'CaCO3' && v.last === 'CO2') return say(v, 'CaCO₃ + CO₂ + H₂O = Ca(HCO₃)₂', '浑浊消失，溶液重新变澄清');
      if (HD[k] && e.pH < 7) return say(v, HD[k], k.endsWith('CO3') ? '沉淀溶解，产生气泡' : '沉淀溶解');
      say(v, '', PN[k] + ' 沉淀溶解');
    }
    function indicators(v, e) {
      const t = v.tot, s = v.ind, V = v.V;
      if (V < .05) return;
      if (t.phth > .05) { const n = e.pH > 9 ? 'r' : e.pH < 8.2 ? 'n' : s.phth; if (n !== s.phth) { if (n === 'r') say(v, '', '酚酞变红：溶液呈碱性（pH > 8.2）'); else if (s.phth === 'r') say(v, '', '红色褪去：溶液不再呈碱性'); s.phth = n; } }
      if (t.lit > .05) { const n = e.pH < 5 ? 'r' : e.pH > 8 ? 'b' : 'p'; if (n !== s.lit) { if (n === 'r') say(v, '', '石蕊变红：溶液呈酸性'); else if (n === 'b') say(v, '', '石蕊变蓝：溶液呈碱性'); else if (s.lit) say(v, '', '石蕊呈紫色：溶液接近中性'); s.lit = n; } }
      if (t.mo > .05) { const n = e.pH < 3.1 ? 'r' : e.pH > 4.4 ? 'y' : 'o'; if (n !== s.mo) { say(v, '', n === 'r' ? '甲基橙变红（pH < 3.1）' : n === 'y' ? '甲基橙呈黄色（pH > 4.4）' : '甲基橙呈橙色（pH 3.1~4.4）'); s.mo = n; } }
    }
    const flag = (v, key, on, off) => { if (on) ev(v, key); else if (off) v.ev.delete(key); };

    /* ---- 加入、混合与倾倒 ---- */
    const heatCap = v => v.V * 4.18 + (v.oil || 0) * 1.35 + VT[v.type].glass;
    const acidBase = (e, V) => [e.h * V + e.hac, e.oh * V + e.nh3];
    // 中和热（kJ/mol）：弱酸、弱碱电离要吸热，放出的热量比强酸强碱少
    const DH = { 'n:s': 57.3, 'n:a': 56.1, 'n:b': 52.2, 'n:ab': 50.4 };
    function mix(v, tt, mL, T) {
      const V0 = v.V, e0 = eqm(v.tot, V0, null, v.T), er = eqm(tt, mL, null, T);
      const [a0, b0] = V0 > 0 ? acidBase(e0, V0) : [0, 0], [ar, br] = acidBase(er, mL);
      const C0 = heatCap(v), Cr = mL * 4.18;
      for (const k in tt) add(v.tot, k, tt[k]);
      v.T = (C0 * v.T + Cr * T) / (C0 + Cr); v.V += mL;
      const e1 = v.e = eqm(v.tot, v.V, null, v.T), [a1, b1] = acidBase(e1, v.V);
      const nW = Math.max(0, Math.min(a0 + ar, b0 + br, (a0 + ar + b0 + br - a1 - b1) / 2));
      if (nW < .03) return null;
      const wa = (V0 > 0 ? e0.hac : 0) + er.hac > (V0 > 0 ? e0.h * V0 : 0) + er.h * mL, wb = (V0 > 0 ? e0.nh3 : 0) + er.nh3 > (V0 > 0 ? e0.oh * V0 : 0) + er.oh * mL;
      const k = wa && wb ? 'n:ab' : wa ? 'n:a' : wb ? 'n:b' : 'n:s', dT = DH[k] * nW / heatCap(v); v.T += dT;
      return { dT, k };
    }
    function neutral(v, r) {
      if (!r || r.dT < .3) return; // 例如向 Na₂CO₃ 溶液中加酸：中和的只是少量 OH⁻，不单独提示
      if (!v.ev.has(r.k)) { v.ev.add(r.k); say(v, EV[r.k][0], `酸碱中和，放出热量，温度升高 ${fmt(r.dT, 1)} °C` + (r.k === 'n:s' ? '' : '（有弱酸或弱碱参加，电离要吸热，中和放出的热量比强酸与强碱少）')); }
      else if (r.dT >= .5) B.toast(`${v.name}：中和放热，温度升高 ${fmt(r.dT, 1)} °C`);
    }
    const queued = v => v.anims.reduce((s, a) => s + (a.mL || 0), 0);
    function addReagent(v, r) {
      if (r.id === 'CO2') {
        if (v.V + queued(v) < .5) return B.toast('容器里没有水溶液，CO₂ 无处吸收');
        v.anims.push({ k: 'gas', t: 0, go: () => { v.feed.push({ k: 'C', rate: .3, left: .3 }); v.last = 'CO2'; note(v, 'CO₂'); } }); return;
      }
      const cap = VT[v.type].cap; let mL = r.drop ? .1 : st.amt;
      if (liq(v) + queued(v) + mL > cap + 1e-9) { mL = cap - liq(v) - queued(v); if (mL < .01) return B.toast(`${v.name} 已经满了`); B.toast(`${v.name} 只能再装 ${fmt(mL, 1)} mL`); }
      if (r.oil) return v.anims.push({ k: mL < .5 ? 'drip' : 'stream', t: 0, mL, col: swatch(r), go: () => {
        const first = !v.oil; v.oil += mL; v.T = (heatCap(v) * v.T - mL * 1.35 * (v.T - 25)) / heatCap(v); v.last = r.id; note(v, r.f);
        if (first) say(v, '', v.V > .3 ? 'CCl₄ 与水互不相溶，密度比水大，沉在下层。点「振荡 / 搅拌」让两层充分接触' : 'CCl₄ 是无色油状液体，不溶于水');
      } });
      const tt = {}; for (const k in r.a) tt[k] = r.a[k] * mL;
      v.anims.push({ k: mL < .5 ? 'drip' : 'stream', t: 0, mL, col: swatch(r), go: () => { v.last = r.id; note(v, r.f); neutral(v, mix(v, tt, mL, 25)); } });
    }
    function addSolid(v, k) {
      if (v.solids.length + v.anims.filter(a => a.k === 'solid').length >= 4) return B.toast('一个容器里最多放 4 块固体');
      const d = SO[k], s = { k, n: d.mm, n0: d.mm, coat: {}, lx: rnd(-.5, .5), seed: rnd(0, 100), vx: 0 };
      v.anims.push({ k: 'solid', t: 0, s, go: () => { v.solids.push(s); note(v, d.f); v.last = k; if (k === 'Na' && v.V < .3) B.toast('钠要放进水里才会反应'); } });
    }
    function transfer(v, u, fr) {
      const Lq = liq(v); if (Lq <= 1e-6 || fr <= 0) return true;
      const room = VT[u.type].cap - liq(u), mL = Math.min(Lq * fr, room);
      if (mL <= 1e-6) return false;
      const k = mL / Lq, tt = {}, Vw = v.V * k, Vo = (v.oil || 0) * k;
      for (const s in v.tot) { tt[s] = v.tot[s] * k; v.tot[s] -= tt[s]; }
      v.V -= Vw; v.oil -= Vo; if (liq(v) < 1e-4) { v.V = 0; v.oil = 0; for (const s in v.tot) v.tot[s] = 0; }
      for (const a of v.added) note(u, a);
      if (Vo > 0) { u.ex = u.oil > 0 ? Math.min(u.ex, v.ex) : v.ex; u.oil += Vo; }
      u.last = v.last; const r = mix(u, tt, Vw, v.T); v.e = eqm(v.tot, v.V, null, v.T);
      if (r && v.pour) { v.pour.dT = (v.pour.dT || 0) + r.dT; v.pour.k = r.k; } else neutral(u, r);
      return mL >= Lq * fr - 1e-6;
    }
    function startPour(v, u) {
      if (liq(v) < .01) { B.toast(`${v.name} 是空的`); v.lift = 0; v.x = nearFree(v, v.homeX ?? v.x); return; }
      if (v.lamp) { v.lamp.v = null; v.lamp = null; }
      v.pour = { to: u, t: 0, done: 0, full: false };
    }

    /* ---- 反应 ---- */
    const BF = { H2: 90, O2: 260, CO2: 110, NO: 140 };
    function spawn(v, src) {
      const t = VT[v.type], lv = lvl(v); if (lv < 3 || v.bub.length > 180) return;
      let x, y;
      if (src && src.k) { [x, y] = solidPos(v, src, lv); x += rnd(-4, 4); y += rnd(0, 5); }
      else if (src === 'tube') { x = t.hw(8) * .45; y = 7; }
      else { y = src === 'w' ? rnd(2, lv * .8) : rnd(1, 6); x = rnd(-1, 1) * Math.max(0, t.hw(y) - 3); }
      v.bub.push({ x, y: Math.min(y, lv - 1), r: rnd(1.2, 3), vy: rnd(35, 80), w: rnd(0, TAU) });
    }
    function gas(v, k, n, src) { v.gas[k] += n; v.bacc += n * BF[k]; let m = 0; while (v.bacc >= 1 && m++ < 8) { v.bacc -= 1; spawn(v, src); } if (v.bacc > 3) v.bacc = 3; }
    function solidPos(v, s, lv) {
      const t = VT[v.type], hw = Math.max(0, t.hw(5) - 9);
      if (s.k === 'Na') return [s.lx * hw, lv > 3 ? lv - 2.5 : 3];
      return [s.lx * hw, 3];
    }
    function react(v, h) {
      const t = v.tot, e = v.e = eqm(t, v.V, v.e && v.e.pH, v.T), V = Math.max(v.V, .05), wet = v.V > .3, Tf = 2 ** ((v.T - 25) / 10);
      const hac = e.hac / V, acid = e.h * V + e.hac, d = e.dis;
      let heat = 0, co2src = null;
      for (const f of v.feed) { const x = Math.min(f.left, f.rate * h); f.left -= x; add(t, f.k, x); }
      if (v.feed.length) v.feed = v.feed.filter(f => f.left > 1e-7);
      if (wet) for (const s of v.solids) {
        if (s.n <= 1e-6) continue;
        const A = SO[s.k].A * Math.cbrt((s.n / s.n0) ** 2);
        if (s.k === 'Na') { const x = Math.min(s.n, 1.2 * A * h); s.n -= x; add(t, 'Na', x); gas(v, 'H2', x / 2, s); heat += 184 * x; ev(v, 'm:Na'); continue; }
        const ds = DSV[s.k];
        if (ds) { // 溶解或与水反应的固体
          const x = Math.min(s.n, ds.r * A * h); s.n -= x; for (const k in ds.add) add(t, k, ds.add[k] * x); heat += ds.H * x;
          if (s.k === 'Na2O2') { gas(v, 'O2', .35 * x, s); add(t, 'H2O2', .3 * x); } // 2Na₂O₂ + 2H₂O：部分先生成 H₂O₂
          if (x / h > 1e-3) ev(v, ds.ev);
          continue;
        }
        if (s.k === 'CaCO3') {
          const pass = (d.SO4 || 0) / V > .05;
          const x = Math.min(s.n, .08 * (e.h + .05 * hac) * A * Tf * (pass ? .06 : 1) * h, .3 * acid / 2);
          if (x > 0) { s.n -= x; add(t, 'Ca', x); add(t, 'C', x); heat += 15 * x; co2src = s; if (x / h > 4e-3) { ev(v, hac > e.h * 5 ? 'm:CaCO3-HAc' : 'm:CaCO3'); } if (pass && x / h < 2e-3 && v.ev.has('m:CaCO3')) ev(v, 'm:CaCO3-SO4'); }
          continue;
        }
        if (d.NO3 / V > .3 && e.h > .1 && NIT[s.k]) { // 稀硝酸把金属氧化，放出 NO 而不是 H₂
          const [ion, z, k] = NIT[s.k], x = Math.min(s.n, k * e.h * A * Tf * h, .3 * e.h * V * 3 / (4 * z));
          if (x > 1e-9) { s.n -= x; add(t, ion, x); add(t, 'NO3', -z * x / 3); gas(v, 'NO', z * x / 3, s); heat += 120 * x; if (x / h > 5e-4) ev(v, 'x:' + s.k); }
          continue;
        }
        const km = { Zn: .1, Fe: .03, Mg: .6, Al: .05 }[s.k];
        if (km) {
          const z = s.k === 'Al' ? 3 : 2, cell = (s.coat.Cu || 0) + (s.coat.Ag || 0) > .02 ? 4 : 1; // 析出的铜与原金属构成原电池
          const x = Math.min(s.n, km * cell * (e.h + .05 * hac) * A * Tf * h, .3 * acid / z);
          if (x > 1e-9) { s.n -= x; add(t, MI[s.k], x); gas(v, 'H2', x * z / 2, s); heat += HM[s.k] * x; if (x / h > 1e-3) { ev(v, 'm:' + s.k + '-H'); if (cell > 1) ev(v, 'g:cell'); } }
          if (s.k === 'Al' && e.oh > .01) { const y = Math.min(s.n, .04 * e.oh * A * Tf * h, .3 * e.oh * V); if (y > 0) { s.n -= y; add(t, 'Al', y); gas(v, 'H2', 1.5 * y, s); heat += 400 * y; if (y / h > 1e-3) ev(v, 'm:Al-OH'); } }
        }
        const dl = DISP[s.k];
        if (dl) for (const [ion, nu, dep] of dl) {
          const av = ion === 'Cu' ? d.Cu + e.cuN : ion === 'Ag' ? d.Ag + e.agN : ion === 'Zn' ? d.Zn + e.znN : d[ion];
          if (!(av > 1e-7) || ion === 'Fe2' && d.Fe3 > 1e-5) continue; // Fe³⁺ 先被还原
          const kr = ion === 'Fe2' || ion === 'Zn' ? .06 : .2;
          const x = Math.min(s.n, kr * av / V * A * Tf * h / nu, .5 * av / nu);
          if (x <= 0) continue;
          s.n -= x; add(t, MI[s.k], x); add(t, ion, -nu * x);
          if (dep) s.coat[dep] = (s.coat[dep] || 0) + nu * x; else add(t, 'Fe2', nu * x);
          heat += 60 * x; if (x / h > 3e-4) ev(v, 'd:' + s.k + '-' + ion);
        }
      }
      const hp = t.H2O2 || 0;
      if (hp > 1e-6 && wet) {
        const mn = v.solids.find(s => s.k === 'MnO2'), fe = d.Fe3 / V, kc = (mn ? .08 : 0) + 3 * fe, k = (kc + 3e-4) * Tf;
        const x = Math.min(hp, hp * k * h); add(t, 'H2O2', -x); gas(v, 'O2', x / 2, mn || 'w'); heat += 98 * x;
        if (x / h > 2e-3) ev(v, mn ? 'h2o2-MnO2' : kc > 3e-4 * Tf ? 'h2o2-Fe3' : 'h2o2-heat');
      }
      const fr = Math.min(1, 10 * h);
      if (e.h > 1e-3 && d.MnO4 > 1e-8) {
        const x = Math.min(d.MnO4, d.Fe2 / 5) * fr;
        if (x > 1e-9) { add(t, 'MnO4', -x); add(t, 'Mn', x); add(t, 'Fe2', -5 * x); add(t, 'Fe3', 5 * x); ev(v, 'r:MnO4-Fe2'); }
        const y = Math.min((t.MnO4 || 0) / 2, (t.H2O2 || 0) / 5) * fr;
        if (y > 1e-9) { add(t, 'MnO4', -2 * y); add(t, 'Mn', 2 * y); add(t, 'H2O2', -5 * y); gas(v, 'O2', 5 * y, 'w'); ev(v, 'r:MnO4-H2O2'); }
      }
      if ((t.Cl2 || 0) > 1e-8) {
        let x = Math.min(t.Cl2, d.I / 2) * fr;
        if (x > 1e-9) { add(t, 'Cl2', -x); add(t, 'I', -2 * x); add(t, 'I2', x); add(t, 'Cl', 2 * x); ev(v, 'r:Cl2-I'); }
        x = Math.min(t.Cl2, Math.min(d.Fe2, t.Fe2 || 0) / 2) * fr;
        if (x > 1e-9) { add(t, 'Cl2', -x); add(t, 'Fe2', -2 * x); add(t, 'Fe3', 2 * x); add(t, 'Cl', 2 * x); ev(v, 'r:Cl2-Fe2'); }
        x = Math.min(t.Cl2, (d.Br || 0) / 2) * fr; // 还原性 I⁻ > Fe²⁺ > Br⁻
        if (x > 1e-9 && !(d.I > 1e-6) && !(d.Fe2 > 1e-6)) { add(t, 'Cl2', -x); add(t, 'Br', -2 * x); add(t, 'Br2', x); add(t, 'Cl', 2 * x); ev(v, 'r:Cl2-Br'); }
        if (t.Cl2 / V > 2e-3) for (const k of ['phth', 'lit', 'mo']) if (t[k] > .05) { t[k] *= Math.exp(-.5 * h); ev(v, 'r:bleach'); }
      }
      if ((t.Br2 || 0) > 1e-8) {
        let x = Math.min(t.Br2, d.I / 2) * fr;
        if (x > 1e-9) { add(t, 'Br2', -x); add(t, 'I', -2 * x); add(t, 'I2', x); add(t, 'Br', 2 * x); ev(v, 'r:Br2-I'); }
        x = Math.min(t.Br2, Math.min(d.Fe2, t.Fe2 || 0) / 2) * fr;
        if (x > 1e-9) { add(t, 'Br2', -x); add(t, 'Fe2', -2 * x); add(t, 'Fe3', 2 * x); add(t, 'Br', 2 * x); ev(v, 'r:Br2-Fe2'); }
      }
      // H₂O₂ 在强碱性溶液中使酚酞褪色（Na₂O₂ 与水的实验）
      if ((t.H2O2 || 0) / V > 4e-3 && e.pH > 11.5 && t.phth > .05 && wet) { t.phth *= Math.exp(-.12 * h); if (t.phth < .5) ev(v, 'r:H2O2-phth'); }
      // 氨的挥发：受热时加快（铵盐与碱共热放出 NH₃）
      if (e.nh3 > 1e-6 && wet) {
        const x = e.nh3 * .0015 * 2 ** ((v.T - 25) / 10) * h; add(t, 'N', -x); v.gas.NH3 += x;
        if (v.T > 50 && x / h > 1e-3) ev(v, 'r:NH3');
      }
      if (d.NO3 / V > .3 && e.h > .1 && d.Fe2 > 1e-7) { const x = d.Fe2 * Math.min(1, 1.5 * h) / 3; add(t, 'Fe2', -3 * x); add(t, 'Fe3', 3 * x); add(t, 'NO3', -x); gas(v, 'NO', x, 'w'); if (x / h > 1e-4) ev(v, 'r:Fe2-HNO3'); }
      const fi = Math.min(d.Fe3, d.I, t.I || 0) * Math.min(1, 1.5 * h) / 2;
      if (fi > 1e-9) { add(t, 'Fe3', -2 * fi); add(t, 'Fe2', 2 * fi); add(t, 'I', -2 * fi); add(t, 'I2', fi); if (fi / h > 1e-4) ev(v, 'r:Fe3-I'); }
      if (e.h > 1e-2 && (t.H2O2 || 0) > 1e-7 && d.I > 1e-7) { const x = .3 * Math.min(t.H2O2, d.I / 2) * h; add(t, 'H2O2', -x); add(t, 'I', -2 * x); add(t, 'I2', x); if (x / h > 1e-4) ev(v, 'r:H2O2-I'); }
      if (e.p.Fe2 > 1e-6) { const x = e.p.Fe2 * .05 * Tf * h; add(t, 'Fe2', -x); add(t, 'Fe3', x); if (e.p.Fe2 > .004 && e.p.Fe3 > .15 * e.p.Fe2) ev(v, 'r:Fe(OH)2-air'); }
      if (v.T > 75 && e.p.Cu > 1e-6) { const x = e.p.Cu * .3 * h; add(t, 'Cu', -x); add(t, 'CuO', x); if (e.p.Cu > .004) ev(v, 'r:CuO'); }
      if ((t.CuO || 0) > 1e-7 && e.h > 1e-3) { const x = Math.min(t.CuO, (.3 * t.CuO + .01) * h, .3 * e.h * V / 2); add(t, 'CuO', -x); add(t, 'Cu', x); if (x / h > 1e-3) ev(v, 'r:CuO-H'); }
      // CO₂ 逸出
      const c0 = e.h2co3 / V, sat = .034 * clamp(1.4 - v.T / 60, .15, 1);
      let xc = c0 > sat ? (c0 - sat) * V * Math.min(1, 4 * h) : c0 * V * .003 * Tf * h;
      if (v.T > 95) xc += c0 * V * .2 * h;
      if (xc > 0 && wet) { add(t, 'C', -xc); gas(v, 'CO2', xc, co2src || (c0 > sat ? 'w' : 'b')); if (xc / h > 3e-3 && !co2src && v.last !== 'CO2' && !v.feed.length && !((t.Al > .01 || t.Fe3 > .01) && v.added.some(a => a === 'NaHCO₃' || a === 'Na₂CO₃'))) ev(v, 'r:CO2'); }
      // 温度
      const C = heatCap(v);
      v.T += heat / C;
      if (v.lamp && v.lamp.lit) v.T += 60 * h / C;
      v.T -= (v.T - 25) * .004 * h * (v.type === 'tube' ? 2 : 1);
      if (v.T > 100 && v.V > 0) { const ex = (v.T - 100) * C; v.T = 100; v.V = Math.max(0, v.V - ex / 2260); if (v.V > 0) ev(v, 'r:boil'); }
      if (v.T > 300) v.T = 300;
      if (v.oil > 0 && v.T > 76) { v.oil = Math.max(0, v.oil - .02 * (v.T - 76) * h); if (!v.ev.has('w:CCl4')) { v.ev.add('w:CCl4'); B.toast(`${v.name}：CCl₄ 沸点约 77 °C，受热挥发（蒸气有毒，实验中不要加热）`, { ms: 5000 }); } }
      for (const k in t) if (t[k] < 0) t[k] = 0;
    }
    function after(v, sd, dt) {
      const e = v.e = eqm(v.tot, v.V, v.e && v.e.pH, v.T), t = v.tot, V = Math.max(v.V, .05), d = e.dis;
      // 萃取：振荡时卤素单质很快在两层间达到分配平衡，静置时很慢
      if (v.oil > 0 && v.V > .1) {
        v.ex += (1 - v.ex) * (1 - Math.exp(-(v.stir > 0 ? 2.5 : .01) * dt));
        if (v.ex > .85 && v.stir <= 0) { if ((t.I2 || 0) > 2e-4) ev(v, 'k:I2'); if ((t.Br2 || 0) > 2e-4) ev(v, 'k:Br2'); }
      }
      // 向 Na₂CO₃ 溶液中逐滴加酸：先生成 HCO₃⁻
      if (v.added.includes('Na₂CO₃') && ['HCl', 'H2SO4', 'HNO3', 'HAc'].includes(v.last) && e.hco3 > .6 * (e.hco3 + e.co3 + e.h2co3) && e.hco3 > .05 && !v.ev.has('r:CO2')) ev(v, 'r:CO3-H1');
      const decay = Math.exp(-sd / 5);
      for (const k of PK) {
        const a = k === 'CuO' ? (t.CuO || 0) : (e.p[k] || 0), o = v.pp[k] || (v.pp[k] = { amt: 0, sus: 0 });
        if (a > o.amt) o.sus += a - o.amt; else o.sus = o.amt > 0 ? o.sus * a / o.amt : 0;
        o.amt = a; o.sus = Math.min(o.sus * decay, a);
        if (a > .004 && !v.ev.has('p:' + k)) { v.ev.add('p:' + k); pptOn(v, k, e); }
        else if (a < .002 && v.ev.has('p:' + k)) { v.ev.delete('p:' + k); pptOff(v, k, e); }
      }
      v.prevA = { Al: e.alO, Zn: e.znO };
      const fs = Math.min(d.Fe3, d.SCN) / V;
      flag(v, 'c:FeSCN', fs > 3e-4, fs < 1e-4);
      flag(v, 'c:starch', (t.starch || 0) > .05 && (t.I2 || 0) / V > 3e-5, (t.I2 || 0) / V < 1e-5);
      flag(v, 'c:CuN', e.cuN / V > 5e-3 && !(e.p.Cu > .004), e.cuN / V < 1e-3);
      if (v.T < 95) v.ev.delete('r:boil');
      indicators(v, e);
      for (const k in v.gas) v.gas[k] *= Math.exp(-dt / 12);
      // 气泡与泡沫（按真实时间）
      const lv = lvl(v);
      if (v.feed.length) { v.tacc += dt * 30; while (v.tacc > 1) { v.tacc--; spawn(v, 'tube'); } }
      if (v.T > 99 && v.V > .3 && v.lamp && v.lamp.lit) { v.tacc += dt * 26; while (v.tacc > 1) { v.tacc--; spawn(v, 'b'); } }
      let pop = 0;
      for (const b of v.bub) { b.y += b.vy * dt; b.w += dt * 6; b.x += Math.sin(b.w) * .3; if (b.y >= lv - 1) pop++; }
      v.bub = v.bub.filter(b => b.y < lv - 1);
      v.foam = Math.min(1, v.foam * Math.exp(-dt * 1.5) + pop * .015);
      const hw = Math.max(1, VT[v.type].hw(Math.max(lv, 5)) - 9);
      for (const s of v.solids) if (s.k === 'Na' && s.n > 1e-4 && v.V > .3) { s.vx += rnd(-1, 1) * 260 * dt; s.vx *= Math.exp(-dt * 1.2); s.lx += s.vx * dt / hw; if (Math.abs(s.lx) > .85) { s.lx = Math.sign(s.lx) * .85; s.vx *= -.6; } }
      v.solids = v.solids.filter(s => s.n > s.n0 * .004 || Object.values(s.coat).some(x => x > .01) || s.k === 'MnO2');
      if (v.stir > 0) { v.stir -= dt; for (const k in v.pp) v.pp[k].sus = v.pp[k].amt; }
      if (v.test) { v.test.t += dt; if (v.test.t > 2.2) v.test = null; }
    }

    /* ---- 检验与操作 ---- */
    function test(v, k) {
      const g = v.gas, th = .012; let res, msg;
      if (k === 'burn') {
        if (g.H2 > th) { res = 'pop'; msg = '气体被点燃，发出轻微的“噗”声：是 H₂（若听到尖锐的爆鸣声，说明 H₂ 中混有空气，点燃前必须验纯）'; }
        else if (g.O2 > th) { res = 'bright'; msg = '木条燃烧得更旺：气体是 O₂（助燃）'; }
        else if (g.CO2 > th) { res = 'out'; msg = '燃着的木条熄灭：气体不支持燃烧，可能是 CO₂（N₂ 等也能使木条熄灭，要用澄清石灰水确认）'; }
        else { res = 'none'; msg = '木条照常燃烧：容器口没有收集到明显的气体'; }
      } else if (k === 'lime') {
        if (g.CO2 > th) { res = 'cloudy'; msg = '澄清石灰水变浑浊：气体是 CO₂（CO₂ + Ca(OH)₂ = CaCO₃↓ + H₂O）'; }
        else { res = 'clear'; msg = '澄清石灰水没有变浑浊：容器口没有 CO₂'; }
      } else if (k === 'litmus') {
        if (g.NH3 > .004) { res = 'blue'; msg = '湿润的红色石蕊试纸变蓝：气体是 NH₃（NH₃ + H₂O ⇌ NH₃·H₂O，溶液显碱性）'; }
        else { res = 'red'; msg = '湿润的红色石蕊试纸不变色：没有检出 NH₃'; }
      } else {
        if (g.O2 > th) { res = 'relight'; msg = '带火星的木条复燃：气体是 O₂'; }
        else { res = 'ember'; msg = '木条没有复燃'; }
      }
      v.test = { k, t: 0, res }; say(v, '', msg);
    }
    function onLamp(v) {
      const lp = lamps().find(l => !l.v);
      if (!lp) return B.toast(lamps().length ? '酒精灯上已经有容器了' : '先从左侧添加一盏酒精灯');
      if (v.lamp) return;
      v.lamp = lp; lp.v = v; v.x = lp.x; v.lift = 0; inspect();
    }
    function toggleLamp(l) { l.lit = !l.lit; B.toast(l.lit ? '点燃酒精灯（用火柴点燃，不能用另一盏酒精灯引燃）' : '用灯帽盖灭酒精灯'); if (sel === l || (sel && sel.lamp === l)) inspect(); }

    /* ---- 绘制 ---- */
    function pcol(k, v) {
      if (k === 'Fe2') { const a = v.pp.Fe2 ? v.pp.Fe2.amt : 0, b = v.pp.Fe3 ? v.pp.Fe3.amt : 0; return mix3(hx(PC.Fe2), [.43, .5, .38], clamp(b / (a + b + 1e-9) * 3, 0, 1)); }
      return hx(PC[k]);
    }
    const mixc = list => { let w = 0, r = [0, 0, 0]; for (const [c, k] of list) { w += k; r = [r[0] + c[0] * k, r[1] + c[1] * k, r[2] + c[2] * k]; } return w ? r.map(x => x / w) : [1, 1, 1]; };
    function room(g) {
      // 墙面：上浅下深的渐变 + 瓷砖缝
      const wall = g.createLinearGradient(0, 0, 0, TY);
      wall.addColorStop(0, T.stage); wall.addColorStop(1, T.dark ? '#141c19' : '#eef2f0');
      g.fillStyle = wall; g.fillRect(0, 0, c.w, TY);
      g.strokeStyle = T.grid; g.lineWidth = 1; const tile = 48 * S;
      for (let y = TY - tile, r = 0; y > 0; y -= tile, r++) {
        g.beginPath(); g.moveTo(0, y); g.lineTo(c.w, y);
        for (let x = (r % 2) * tile / 2; x < c.w; x += tile) { g.moveTo(x, y); g.lineTo(x, y + tile); }
        g.stroke();
      }
      // 台面：木纹渐变、前缘高光和阴影
      const wood = T.dark ? ['#3c322a', '#221c17'] : ['#e8dbc2', '#c9b48d'];
      const gr = g.createLinearGradient(0, TY, 0, c.h); gr.addColorStop(0, wood[0]); gr.addColorStop(1, wood[1]);
      g.fillStyle = gr; g.fillRect(0, TY, c.w, c.h - TY);
      g.strokeStyle = alpha(T.dark ? '#000000' : '#8c7651', .08); g.lineWidth = 1;
      for (let i = 1; i < 5; i++) { const y = TY + (c.h - TY) * i / 5; g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(c.w * .3, y + 3, c.w * .7, y - 3, c.w, y); g.stroke(); }
      D.line(g, 0, TY + .5, c.w, TY + .5, T.dark ? '#5d4e40' : '#f6ecd9', 2);
      D.line(g, 0, TY + 2.5, c.w, TY + 2.5, alpha('#000000', T.dark ? .35 : .08), 2);
      for (const l of lamps()) if (l.lit) { const gl = g.createRadialGradient(l.x, TY, 4, l.x, TY, 120 * S); gl.addColorStop(0, 'rgba(255,170,70,.22)'); gl.addColorStop(1, 'rgba(255,170,70,0)'); g.fillStyle = gl; g.fillRect(l.x - 120 * S, TY - 120 * S, 240 * S, 240 * S); }
      // 器材在台面上的影子
      g.fillStyle = alpha('#000000', T.dark ? .35 : .12);
      for (const o of objs) {
        if (o.kind === 'v' && (o.lamp || o.pour || o.lift > 2)) continue;
        g.beginPath(); g.ellipse(o.x, TY + 2 * S, (o.kind === 'lamp' ? 50 : VT[o.type].W + 6) * S, 5 * S, 0, 0, TAU); g.fill();
      }
    }
    function drawLamp(g, l) {
      const x = l.x, s = S, ty = TY - 112 * s, metal = T.dark ? '#8a949c' : '#5b636a';
      if (l.v && l.v.type === 'tube') { // 试管直接在外焰上加热，用试管夹夹持
        const tb = base(l.v), hy = tb - VT.tube.H * s * .78;
        g.lineCap = 'round'; D.line(g, x + 14 * s, hy, x + 120 * s, hy + 26 * s, '#a87a45', 6 * s); D.line(g, x + 14 * s, hy - 4 * s, x + 60 * s, hy + 6 * s, '#8c6236', 2 * s); g.lineCap = 'butt';
        D.rect(g, x - 16 * s, hy - 5 * s, 30 * s, 10 * s, null, '#8c6236', 2 * s);
      } else {
      g.lineCap = 'round';
      D.line(g, x - 40 * s, ty, x - 50 * s, TY, metal, 3 * s); D.line(g, x + 40 * s, ty, x + 50 * s, TY, metal, 3 * s);
      D.line(g, x + 3 * s, ty, x + 6 * s, TY - 4 * s, alpha(metal, .45), 2.4 * s);
      D.line(g, x - 46 * s, ty, x + 46 * s, ty, metal, 3 * s);
      // 陶土网
      D.rect(g, x - 44 * s, ty - 4 * s, 88 * s, 4 * s, T.dark ? '#59605f' : '#a7aba6');
      g.strokeStyle = alpha(T.dark ? '#c9cfcc' : '#ffffff', .35); g.lineWidth = 1;
      for (let i = -40; i <= 40; i += 6) { g.beginPath(); g.moveTo(x + i * s, ty - 4 * s); g.lineTo(x + i * s, ty); g.stroke(); }
      g.lineCap = 'butt';
      }
      // 灯体
      const by = TY, bw = 27 * s, bh = 40 * s;
      g.beginPath(); g.moveTo(x - bw, by); g.lineTo(x - bw, by - bh * .45); g.quadraticCurveTo(x - bw, by - bh, x - 8 * s, by - bh); g.lineTo(x + 8 * s, by - bh); g.quadraticCurveTo(x + bw, by - bh, x + bw, by - bh * .45); g.lineTo(x + bw, by); g.closePath();
      g.fillStyle = T.dark ? 'rgba(180,210,230,.08)' : 'rgba(200,225,240,.35)'; g.fill();
      g.save(); g.clip(); g.fillStyle = T.dark ? 'rgba(120,170,220,.28)' : 'rgba(110,160,210,.3)'; g.fillRect(x - bw, by - bh * .5, 2 * bw, bh); g.restore();
      g.strokeStyle = alpha(T.fg, .5); g.lineWidth = 1.6; g.stroke();
      D.rect(g, x - 7 * s, by - bh - 8 * s, 14 * s, 8 * s, T.dark ? '#7b8288' : '#8f979d');
      D.rect(g, x - 1.6 * s, by - bh - 15 * s, 3.2 * s, 7 * s, '#3b302a');
      if (l.lit) {
        const f = 1 + .08 * Math.sin(clock * 17) + .05 * Math.sin(clock * 29), fy = by - bh - 14 * s, fh = 34 * s * f, fw = 9 * s;
        const glow = g.createRadialGradient(x, fy - fh * .4, 2, x, fy - fh * .4, 60 * s); glow.addColorStop(0, 'rgba(255,170,60,.28)'); glow.addColorStop(1, 'rgba(255,170,60,0)');
        g.fillStyle = glow; g.fillRect(x - 60 * s, fy - fh - 50 * s, 120 * s, 120 * s);
        const fl = (w, hh, col) => { g.beginPath(); g.moveTo(x, fy - hh); g.bezierCurveTo(x + w * 1.1, fy - hh * .45, x + w, fy, x, fy); g.bezierCurveTo(x - w, fy, x - w * 1.1, fy - hh * .45, x, fy - hh); g.fillStyle = col; g.fill(); };
        fl(fw, fh, 'rgba(255,140,40,.85)'); fl(fw * .62, fh * .72, 'rgba(255,214,90,.95)'); fl(fw * .3, fh * .32, 'rgba(110,150,255,.8)');
      }
    }
    function drawSolid(g, v, s, lv) {
      const d = SO[s.k], f = Math.cbrt(Math.max(s.n, 0) / s.n0), [x, y] = solidPos(v, s, lv);
      const cs = Object.entries(s.coat).sort((p, q) => q[1] - p[1]), ctot = cs.reduce((m, p) => m + p[1], 0), ca = Math.min(.9, ctot * 1.2), cc = cs.length ? COAT[cs[0][0]] : '#000';
      const blob = (r, fill, cy) => { g.beginPath(); for (let i = 0; i < 9; i++) { const a = i / 9 * TAU, q = r * (.8 + .22 * Math.sin(s.seed + i * 2.3)); i ? g.lineTo(x + Math.cos(a) * q, cy - Math.sin(a) * q * .8) : g.moveTo(x + Math.cos(a) * q, cy - Math.sin(a) * q * .8); } g.closePath(); g.fillStyle = fill; g.fill(); };
      const shape = (fill, a) => {
        g.globalAlpha = a;
        if (s.k === 'Zn') blob(6 * f + 2, fill, -(y + 4 * f + 1));
        else if (s.k === 'CaCO3') blob(9 * f + 2.5, fill, -(y + 6 * f + 1));
        else if (s.k === 'CaO') blob(7 * f + 1.5, fill, -(y + 5 * f + 1));
        else if (s.k === 'NaOHs') for (let i = 0; i < 4; i++) D.circle(g, x + (i - 1.5) * 6 * f, -(y + 2.2 * f), 2.6 * f + .6, fill);
        else if (s.k === 'Na') { D.circle(g, x, -y, 4.5 * f + 1.2, fill); }
        else if (s.k === 'MnO2' || s.k === 'Na2O2' || s.k === 'NH4NO3') { const k = s.k === 'MnO2' ? 1 : f; g.fillStyle = fill; g.beginPath(); const w = (VT[v.type].hw(3) - 2) * (s.k === 'MnO2' ? 1 : .35 + .65 * k); g.moveTo(-w, 0); for (let i = 0; i <= 10; i++) g.lineTo(-w + 2 * w * i / 10, -(3 + 1.2 * Math.sin(s.seed + i)) * k * (1 + 1.6 * Math.sin(PI * i / 10) * (s.k === 'MnO2' ? 0 : 1))); g.lineTo(w, 0); g.closePath(); g.fill(); }
        else {
          const ln = s.k === 'Fe' ? Math.min(VT[v.type].H * .5, 72) : s.k === 'Cu' ? 38 : s.k === 'Mg' ? 36 * f + 6 : 18 * f + 4;
          const lean = v.type === 'tube' ? 1.38 : s.k === 'Cu' ? 1.25 : .16, wd = s.k === 'Fe' ? 3.6 : s.k === 'Cu' ? 4.5 : s.k === 'Mg' ? 2.2 : 3;
          const x2 = x + Math.cos(lean) * ln, y2 = -(y + Math.sin(lean) * ln);
          g.lineCap = 'round'; D.line(g, x, -y - 1, x2, y2, fill, wd); g.lineCap = 'butt';
          if (s.k === 'Fe') D.line(g, x2 - 4, y2, x2 + 4, y2, fill, 3);
        }
        g.globalAlpha = 1;
      };
      shape(d.col, 1); if (ca > .02) shape(cc, ca);
      if (s.k === 'Na' && s.n > 1e-4 && v.V > .3) { for (let i = 0; i < 5; i++) D.circle(g, x + rnd(-7, 7), -y - rnd(0, 3), rnd(.8, 1.8), 'rgba(255,255,255,.7)'); }
    }
    function drawVessel(g, v, X, Yb, ang) {
      const t = VT[v.type], P = t.p, H = t.H, e = v.e, lv = lvl(v);
      g.save(); g.translate(X, Yb); if (ang) g.rotate(ang); g.scale(S, S);
      const path = () => { g.beginPath(); g.moveTo(-P[P.length - 1][0], -H); for (let i = P.length - 1; i >= 0; i--) g.lineTo(-P[i][0], -P[i][1]); for (let i = 0; i < P.length; i++) g.lineTo(P[i][0], -P[i][1]); };
      g.save(); path(); g.clip();
      g.fillStyle = T.dark ? 'rgba(160,200,225,.05)' : 'rgba(120,170,205,.07)'; g.fillRect(-t.W - 4, -H - 2, 2 * t.W + 8, H + 4);
      if (lv > .4) {
        const fI = aqF(v, 'I2'), fB = aqF(v, 'Br2');
        const tr = tint(v.tot, v.V, e, fI, fB), lc = [tr[0] * .66, tr[1] * .84, tr[2] * .97];
        const a = Math.min(.92, .3 + .6 * (1 - (tr[0] + tr[1] + tr[2]) / 3));
        const fillLiq = col => { if (ang) { g.save(); g.rotate(-ang); g.fillStyle = col; g.fillRect(-400, Math.max(-lv, -H * Math.cos(ang) - 8), 800, 800); g.restore(); } else { g.fillStyle = col; g.fillRect(-t.W - 3, -lv, 2 * t.W + 6, lv + 3); } };
        fillLiq(css(lc, a));
        if (!ang && v.oil > .01) { // 下层 CCl₄
          const lo = t.lvl(v.oil), to = tintOil((v.tot.I2 || 0) * (1 - fI), (v.tot.Br2 || 0) * (1 - fB), v.oil), oc = [to[0] * .7, to[1] * .78, to[2] * .9];
          g.fillStyle = css(oc, Math.min(.94, .38 + .6 * (1 - (to[0] + to[1] + to[2]) / 3))); g.fillRect(-t.W - 3, -lo, 2 * t.W + 6, lo + 3);
          if (v.V > .1) { const sw = t.hw(lo); D.line(g, -sw, -lo, sw, -lo, 'rgba(255,255,255,.4)', 1); }
        }
        let sus = 0; const sl = [];
        for (const k in v.pp) { const o = v.pp[k]; if (o.sus > 1e-5) { sus += o.sus; sl.push([pcol(k, v), o.sus]); } }
        if (sus > 1e-5) {
          const sc = mixc(sl), cs = sus / Math.max(v.V, .1);
          fillLiq(css(sc, Math.min(.86, 1 - Math.exp(-cs * 25))));
          if (!ang) { // 悬浮的颗粒
            const n = Math.min(110, Math.round(cs * 3000) + 6), fr = q => q - Math.floor(q);
            g.fillStyle = css(sc.map(x => x * .62), .6);
            for (let i = 0; i < n; i++) {
              const y = ((fr(Math.sin(i * 78.233 + v.id) * 12345.678) * lv - clock * 2.5 * (1 + i % 3)) % lv + lv) % lv;
              const x = (fr(Math.sin(i * 12.9898 + v.id) * 43758.5453) * 2 - 1) * Math.max(0, t.hw(y) - 2);
              g.fillRect(x - .8, -y - .8, 1.6, 1.6);
            }
          }
        }
        if (!ang) {
          const sw = t.hw(lv);
          D.line(g, -sw, -lv, sw, -lv, 'rgba(255,255,255,.55)', 1.2);
          if (v.foam > .05) for (let i = -sw + 3; i < sw - 2; i += 4) D.circle(g, i + Math.sin(i * 7.3) * 1.2, -lv - 1, 1.2 + v.foam * 1.6 * (.6 + .4 * Math.sin(i * 3.1 + clock * 3)), 'rgba(255,255,255,.5)');
        }
      }
      // 沉在底部的沉淀
      let set = 0; const sl2 = [];
      for (const k in v.pp) { const o = v.pp[k], s = o.amt - o.sus; if (s > 1e-5) { set += s; sl2.push([pcol(k, v), s]); } }
      if (set > 2e-4) {
        const w = t.hw(3) + 2, hg = Math.min(lv > 2 ? Math.max(lv * .7, 3) : 24, 1.5 + 9 * Math.sqrt(set) * 14 / Math.max(14, t.hw(3)));
        const col = mixc(sl2);
        g.beginPath(); g.moveTo(-w, 2);
        for (let i = 0; i <= 14; i++) g.lineTo(-w + 2 * w * i / 14, -hg * (.78 + .22 * Math.sin(i * 1.7 + v.id)));
        g.lineTo(w, 2); g.closePath(); g.fillStyle = css(col, .95); g.fill(); g.strokeStyle = css(col.map(x => x * .62), .9); g.lineWidth = 1; g.stroke();
        g.fillStyle = css(col.map(x => x * .78), .9);
        for (let i = 0; i < 18; i++) { const px = -w + (Math.sin(i * 12.9898 + v.id) * .5 + .5) * 2 * w, py = -(Math.sin(i * 78.233) * .5 + .5) * hg * .8; g.fillRect(px, py, 1.4, 1.4); }
      }
      for (const s of v.solids) drawSolid(g, v, s, lv);
      for (const b of v.bub) { g.beginPath(); g.arc(b.x, -b.y, b.r, 0, TAU); g.fillStyle = 'rgba(255,255,255,.18)'; g.fill(); g.strokeStyle = 'rgba(255,255,255,.75)'; g.lineWidth = .8; g.stroke(); }
      g.restore();
      // 玻璃
      const selc = sel === v;
      if (selc) { g.save(); g.shadowColor = T.accent; g.shadowBlur = 12; path(); g.strokeStyle = alpha(T.accent, .9); g.lineWidth = 3.2; g.stroke(); g.restore(); }
      path(); g.strokeStyle = T.dark ? 'rgba(210,228,238,.62)' : 'rgba(60,80,92,.62)'; g.lineWidth = 2; g.stroke();
      const rimW = P[P.length - 1][0];
      D.line(g, -rimW - 3, -H, rimW + 3, -H, T.dark ? 'rgba(210,228,238,.7)' : 'rgba(60,80,92,.7)', 2.4);
      g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 2.4; g.beginPath(); for (let y = H * .16; y <= H * .84; y += 3) { const x = -t.hw(y) + 5; y === H * .16 ? g.moveTo(x, -y) : g.lineTo(x, -y); } g.stroke();
      if (v.type === 'beaker') {
        g.beginPath(); g.moveTo(-rimW - 3, -H); g.quadraticCurveTo(-rimW - 9, -H - 2, -rimW - 10, -H - 6); g.strokeStyle = T.dark ? 'rgba(210,228,238,.62)' : 'rgba(60,80,92,.62)'; g.lineWidth = 2; g.stroke();
        for (let m = 50; m <= 150; m += 50) { const y = t.lvl(m); D.line(g, rimW - 14, -y, rimW - 2, -y, alpha(T.fg, .45), 1); D.text(g, String(m), rimW - 16, -y, alpha(T.fg, .5), { size: 8, align: 'right', mono: true }); }
      }
      g.restore();
    }
    function drawAnims(g, v) {
      const X = v.x, top = topY(v), surf = base(v) - lvl(v) * S;
      for (const a of v.anims) {
        if (a.k === 'drip') {
          const tip = top - 10 * S, p = clamp(a.t / .45, 0, 1);
          D.rrect(g, X - 4 * S, tip - 44 * S, 8 * S, 12 * S, 3 * S, '#b54a3c');
          D.rect(g, X - 2.5 * S, tip - 32 * S, 5 * S, 30 * S, T.dark ? 'rgba(200,220,235,.25)' : 'rgba(150,190,215,.35)', alpha(T.fg, .5), 1);
          if (p < 1) D.circle(g, X, lerp(tip, surf, p * p), 2.6 * S, a.col);
        } else if (a.k === 'stream') {
          const bx = X + 26 * S, by = top - 30 * S;
          g.save(); g.translate(bx, by); g.rotate(-2.1); D.rrect(g, -9 * S, -26 * S, 18 * S, 30 * S, 3 * S, T.dark ? 'rgba(200,220,235,.2)' : 'rgba(255,255,255,.6)', alpha(T.fg, .5), 1.2); D.rect(g, -8 * S, -12 * S, 16 * S, 15 * S, a.col); g.restore();
          if (a.t < .55) { g.strokeStyle = a.col; g.lineWidth = 3 * S; g.beginPath(); g.moveTo(bx - 14 * S, by + 6 * S); g.quadraticCurveTo(X + 4 * S, by + 10 * S, X + 2 * S, surf); g.stroke(); }
        } else if (a.k === 'solid') {
          const p = clamp(a.t / .5, 0, 1), y = lerp(top - 26 * S, base(v) - 6 * S, p * p);
          D.circle(g, X, y, 4 * S, SO[a.s.k].col, alpha(T.fg, .4), 1);
        }
      }
      if (v.gas.NO > .003) { // NO 在容器口遇空气变成红棕色的 NO₂
        const k = clamp(v.gas.NO * 25, .15, 1);
        for (let i = 0; i < 5; i++) { const p = (clock * .35 + i / 5) % 1, sx = X + Math.sin(clock * 1.3 + i * 1.7) * 10 * S * p; D.circle(g, sx, top - 4 * S - p * 50 * S, (5 + p * 12) * S, `rgba(176,84,34,${(1 - p) * .5 * k})`); }
      }
      if (v.T > 70 && v.V > .05) { // 水蒸气
        const k = clamp((v.T - 70) / 30, 0, 1);
        for (let i = 0; i < 4; i++) { const p = (clock * .45 + i / 4) % 1, sx = X + Math.sin(clock * 1.7 + i * 2) * 8 * S * p; D.circle(g, sx, top - 6 * S - p * 60 * S, (4 + p * 10) * S, `rgba(${T.dark ? "220,228,235" : "140,152,162"},${(1 - p) * .45 * k})`); }
      }
      if (v.feed.length) { const tx = X + VT[v.type].hw(8) * .45 * S; D.line(g, tx, top - 40 * S, tx, base(v) - 7 * S, T.dark ? 'rgba(210,228,238,.6)' : 'rgba(60,80,92,.55)', 3 * S); D.text(g, 'CO₂', tx + 6 * S, top - 34 * S, T.muted, { size: 11 }); }
      if (v.stir > 0) { const sx = X + Math.sin(clock * 9) * VT[v.type].hw(10) * .5 * S; D.line(g, sx - 8 * S, top - 30 * S, sx, base(v) - 6 * S, T.dark ? 'rgba(220,235,245,.75)' : 'rgba(80,100,112,.7)', 3 * S); }
      if (v.test && (v.test.k === 'lime' || v.test.k === 'litmus')) {
        const q = v.test, mx = X + 4 * S, my = top - 8 * S, p = clamp((q.t - .3) / .9, 0, 1);
        if (q.k === 'lime') { // 蘸有澄清石灰水的玻璃片
          D.rect(g, mx - 26 * S, my - 3 * S, 52 * S, 4 * S, T.dark ? 'rgba(200,225,240,.35)' : 'rgba(170,205,225,.55)', alpha(T.fg, .45), 1);
          const w = q.res === 'cloudy' ? p : 0; g.beginPath(); g.ellipse(mx, my + 2.5 * S, 9 * S, 3 * S, 0, 0, TAU); g.fillStyle = `rgba(${lerp(190, 248, w)},${lerp(220, 248, w)},${lerp(240, 244, w)},${.55 + .4 * w})`; g.fill();
        } else { // 湿润的红色石蕊试纸
          const c0 = [214, 72, 82], c1 = [62, 98, 214], w = q.res === 'blue' ? p : 0;
          D.line(g, mx + 30 * S, my - 34 * S, mx + 4 * S, my - 2 * S, '#b88a52', 2.4 * S);
          g.save(); g.translate(mx, my); g.rotate(-.9); D.rect(g, -4 * S, -2 * S, 22 * S, 7 * S, `rgb(${c0.map((x, i) => Math.round(lerp(x, c1[i], w))).join(',')})`); g.restore();
        }
      } else if (v.test) {
        const q = v.test, mx = X + 6 * S, my = top - 4 * S, ex = mx + 70 * S, ey = my - 46 * S;
        g.lineCap = 'round'; D.line(g, ex, ey, mx, my, '#b88a52', 3.2 * S); g.lineCap = 'butt';
        const lit = q.res === 'bright' || q.res === 'none' || q.res === 'relight' && q.t > .5 || q.res === 'pop' && q.t > .6;
        if (q.res === 'pop' && q.t > .25 && q.t < .6) { const r = (q.t - .25) * 120 * S; D.circle(g, mx, my, r, `rgba(255,220,120,${.6 - (q.t - .25)})`); }
        if (lit) { const k = q.res === 'bright' ? 1.8 : q.res === 'relight' ? 1.3 : 1; const fh = 14 * S * k * (1 + .1 * Math.sin(clock * 20)); g.beginPath(); g.moveTo(mx, my - fh); g.quadraticCurveTo(mx + 6 * S * k, my - fh * .3, mx, my + 2); g.quadraticCurveTo(mx - 6 * S * k, my - fh * .3, mx, my - fh); g.fillStyle = 'rgba(255,160,50,.9)'; g.fill(); }
        else { D.circle(g, mx, my, 2.4 * S, q.res === 'out' ? '#555' : '#ff6a2a'); if (q.res === 'out') for (let i = 0; i < 4; i++) D.circle(g, mx + Math.sin(q.t * 3 + i) * 4 * S, my - (q.t * 30 + i * 8) * S, 3 * S, 'rgba(150,150,150,.3)'); }
      }
    }
    function pourPose(v) { // 倾倒时源容器的位置与角度
      const u = v.pour.to, p = v.pour, H = VT[v.type].H * S, ang = (u.x >= v.homeX ? 1 : -1) * 1.85 * clamp(p.t / .4, 0, 1) ** .7;
      const mx = u.x - Math.sign(ang || 1) * outerW(u) * .35, my = topY(u) - 10 * S;
      return { X: mx - H * Math.sin(ang), Y: my + H * Math.cos(ang), ang, mx, my };
    }
    L.onDraw(() => {
      layout(); const g = c.g; c.clear(); room(g);
      for (const l of lamps()) drawLamp(g, l);
      const vs = vessels().filter(v => !v.pour).sort((a, b) => (a === sel) - (b === sel));
      for (const v of vs) { v.x = clamp(v.x, outerW(v) + 4, c.w - outerW(v) - 4); drawVessel(g, v, v.x, base(v), 0); drawAnims(g, v); }
      for (const v of vessels()) if (v.pour) {
        const q = pourPose(v); drawVessel(g, v, q.X, q.Y, q.ang);
        if (v.pour.t > .35 && v.pour.t < 1.15 && liq(v) > .01) { const u = v.pour.to, sy = base(u) - lvl(u) * S; g.strokeStyle = css(tint(v.tot, v.V, v.e).map((x, i) => x * [.66, .84, .97][i]), .85); g.lineWidth = 4 * S; g.beginPath(); g.moveTo(q.mx, q.my); g.lineTo(q.mx + (u.x - q.mx) * .2, sy); g.stroke(); }
      }
      g.textBaseline = 'middle';
      for (const v of vessels()) {
        if (v.pour || v.lift > 2) continue;
        const ly = TY + 17 * S;
        D.text(g, v.name, v.x, ly, sel === v ? T.accent : T.fg, { size: 12.5 * S, align: 'center', bold: true });
        const sub = v.added.slice(-3).join(' + ') || '空';
        D.text(g, sub.length > 22 ? '…' + sub.slice(-21) : sub, v.x, ly + 16 * S, T.muted, { size: 11 * S, align: 'center' });
        D.text(g, `${fmt(liq(v), 1)} mL · ${fmt(v.T, 0)} °C`, v.x, ly + 31 * S, v.T > 40 ? T.bad : T.muted, { size: 10.5 * S, align: 'center', mono: true });
        if (v.lamp) { /* 酒精灯上，标签放在灯下 */ }
      }
      for (const l of lamps()) if (!l.v) D.text(g, '酒精灯' + (l.lit ? '（燃着）' : ''), l.x, TY + 17 * S, sel === l ? T.accent : T.muted, { size: 12 * S, align: 'center' });
      if (!vessels().length) D.text(g, '从左侧添加试管、烧杯或锥形瓶', c.w / 2, c.h * .42, T.muted, { size: 15, align: 'center' });
    });

    /* ---- 交互 ---- */
    function hitObj(x, y) {
      for (let i = objs.length - 1; i >= 0; i--) { const o = objs[i]; if (o.kind === 'v' && !o.pour && Math.abs(x - o.x) < outerW(o) + 6 && y > topY(o) - 12 && y < base(o) + 6) return o; }
      for (const o of objs) if (o.kind === 'lamp' && Math.abs(x - o.x) < 50 * S && y > TY - 118 * S && y < TY + 4) return o;
      return null;
    }
    const vesselAt = (x, y) => vessels().find(v => !v.pour && Math.abs(x - v.x) < outerW(v) + 22 * S && y < base(v) + 40 * S && y > topY(v) - 90 * S);
    function settle(v) {
      const tgt = vessels().find(u => u !== v && !u.pour && Math.abs(u.x - v.x) < (outerW(u) + outerW(v)) * .8 && v.lift > 25 * S && base(v) < topY(u) + 36 * S);
      if (tgt) { startPour(v, tgt); return; }
      v.lift = 0;
      const lp = lamps().find(l => !l.v && Math.abs(l.x - v.x) < 46 * S);
      if (lp) { v.lamp = lp; lp.v = v; v.x = lp.x; inspect(); return; }
      v.x = nearFree(v, v.x);
    }
    L.interact(c, {
      hit: (x, y) => { const o = hitObj(x, y); return o ? { o, ox: x - o.x, y0: y, b0: o.kind === 'v' ? base(o) : 0, moved: false } : null; },
      down: (x, y, h) => { if (h) select(h.o); },
      drag: (h, x, y) => {
        const o = h.o; if (o.pour) return;
        if (!h.moved) { h.moved = true; if (o.kind === 'v') { o.homeX = o.x; if (o.lamp) { o.lamp.v = null; o.lamp = null; inspect(); } } }
        if (o.kind === 'v') { o.x = clamp(x - h.ox, 20, c.w - 20); o.lift = Math.max(0, TY - (h.b0 + y - h.y0)); }
        else { o.x = clamp(x - h.ox, 40, c.w - 40); if (o.v) o.v.x = o.x; }
      },
      up: h => { if (!h || !h.moved) return; if (h.o.kind === 'v') settle(h.o); else { h.o.x = nearFree(h.o, h.o.x); if (h.o.v) h.o.v.x = h.o.x; } },
      click: (x, y, h) => { if (!h) { select(null); return; } if (h.o.kind === 'lamp') toggleLamp(h.o); }
    });
    const onKey = e => { if ((e.key === 'Delete' || e.key === 'Backspace') && sel && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { remove(sel); e.preventDefault(); } };
    addEventListener('keydown', onKey); L.disp.push(() => removeEventListener('keydown', onKey));

    /* ---- 检查器 ---- */
    /* ---- 示例实验：摆好容器和药品，提示下一步 ---- */
    let tip = '';
    function scene(p) {
      objs.length = 0; for (const k in cnt) cnt[k] = 0; sel = null; log.length = 0; renderLog();
      st.amt = p.amt ?? 2; st.speed = p.speed ?? 1; tip = p.tip || ''; layout();
      const n = p.v.length, vs = [];
      p.v.forEach((d, i) => {
        const x = c.w * (i + .7) / (n + .4);
        if (d.lamp) { newLamp(x); return; }
        const v = newV(d.t, x); vs.push(v);
        for (const [id, mL] of d.r || []) { const r = RG.find(q => q.id === id), tt = {}; if (r.oil) { v.oil += mL; note(v, r.f); continue; } for (const k in r.a) tt[k] = r.a[k] * mL; mix(v, tt, mL, 25); note(v, r.f); v.last = id; }
        for (const k of d.s || []) { v.solids.push({ k, n: SO[k].mm, n0: SO[k].mm, coat: {}, lx: rnd(-.4, .4), seed: rnd(0, 100), vx: 0 }); note(v, SO[k].f); }
        v.e = eqm(v.tot, v.V);
      });
      if (vs.length) select(vs[0]); else inspect();
      if (tip) B.toast(`<b>下一步</b><span>${tip}</span>`, { ms: 9000 });
    }
    const T1 = (r, s) => ({ t: 'tube', r, s });
    const PRE = [
      ['铜盐与碱、氨水', '氨水过量时沉淀溶解', { amt: 1, v: [T1([['CuSO4', 2]]), T1([['CuSO4', 2]])], tip: '试管 1 每次加入 1 mL 氢氧化钠溶液，试管 2 每次加入 1 mL 氨水，都加到过量，比较两支试管的现象。' }],
      ['氢氧化铝的两性', 'NaOH 过量时沉淀溶解', { amt: 1, v: [T1([['AlCl3', 2]]), T1([['AlCl3', 2]])], tip: '试管 1 逐次加入氢氧化钠溶液，试管 2 逐次加入氨水，各加 5 次以上，看沉淀能否溶解。' }],
      ['石灰水与 CO₂', '浑浊 → 澄清 → 加热又浑浊', { speed: 5, v: [T1([['CaOH2', 10]]), { lamp: 1 }], tip: '选中试管，多次点击「通入 CO₂」；溶液重新澄清后，点「放到酒精灯上」并点燃酒精灯。' }],
      ['中和反应与指示剂', '颜色、pH 和温度', { amt: 1, v: [{ t: 'flask', r: [['NaOH', 10], ['phth', .1]] }], tip: '每次加入 1 mL 稀盐酸，注意溶液颜色、pH 和温度；红色恰好褪去时接近中和点。' }],
      ['金属活动性顺序', '四组置换反应对比', { speed: 5, v: [T1([['CuSO4', 5]], ['Zn']), T1([['CuSO4', 5]], ['Fe']), T1([['AgNO3', 5]], ['Cu']), T1([['FeSO4', 5]], ['Cu'])], tip: '观察哪些金属表面有固体析出、溶液颜色怎样变化；铜放进硫酸亚铁溶液里有没有变化？' }],
      ['气体的制取与检验', 'H₂、O₂、CO₂', { v: [T1([['HCl', 5]], ['Zn']), T1([['H2O2', 5]], ['MnO2']), { t: 'beaker', r: [['HCl', 20]], s: ['CaCO3'] }], tip: '依次选中三个容器，用「燃着的木条」和「带火星的木条」检验产生的气体。' }],
      ['Fe²⁺ 和 Fe³⁺ 的检验', 'KSCN 与氯水', { amt: .1, v: [T1([['FeCl3', 2]]), T1([['FeSO4', 2]])], tip: '两支试管各加入硫氰化钾溶液；再向试管 2 加入新制氯水，观察颜色变化。' }],
      ['亚铁盐与碱', '白色 → 灰绿 → 红褐', { speed: 20, v: [T1([['FeSO4', 2]])], tip: '加入 2 mL 氢氧化钠溶液。时间已调到 20×，注意沉淀颜色的变化。' }],
      ['钠与水', '浮、熔、游、响、红', { v: [{ t: 'beaker', r: [['H2O', 50], ['phth', .1]] }], tip: '选中烧杯，放入一块金属钠。' }],
      ['铜与稀硝酸', '无色 NO 在管口变红棕色', { speed: 5, v: [T1([['HNO3', 5]], ['Cu'])], tip: '观察铜片溶解、溶液变蓝，以及试管口气体颜色的变化。' }],
      ['卤素的氧化性', 'Cl₂ 把 I⁻ 氧化成 I₂', { amt: .1, v: [T1([['KI', 2], ['starch', .1]])], tip: '向试管中加入新制氯水，观察溶液颜色。' }],
      ['大理石与三种酸', '盐酸、硫酸、醋酸对比', { v: [T1([['HCl', 6]], ['CaCO3']), T1([['H2SO4', 6]], ['CaCO3']), T1([['HAc', 6]], ['CaCO3'])], speed: 5, tip: '比较三支试管中气泡的多少；稀硫酸中的反应为什么会逐渐停止？' }],
      ['卤素单质的氧化性', 'Cl₂ > Br₂ > I₂', { amt: 1, v: [T1([['KBr', 3]]), T1([['KI', 3]]), T1([['KI', 3]])], tip: '试管 1、2 各加 1 mL 新制氯水，试管 3 加 1 mL 溴水；再各加 1 mL 四氯化碳，点「振荡 / 搅拌」，比较下层的颜色。' }],
      ['萃取碘水中的碘', 'CCl₄ 层变紫红色', { amt: 2, v: [T1([['I2', 10]])], tip: '加入 2 mL 四氯化碳，观察分层；点「振荡 / 搅拌」后静置，比较上下两层的颜色。' }],
      ['卤化银沉淀', 'AgCl 白、AgBr 浅黄、AgI 黄', { amt: .1, v: [T1([['NaCl', 2]]), T1([['KBr', 2]]), T1([['KI', 2]])], tip: '三支试管各滴加 2 滴硝酸银溶液，比较沉淀颜色；再加入稀硝酸，沉淀溶解吗？' }],
      ['碳酸钠与盐酸', '滴加顺序不同，现象不同', { amt: 1, v: [T1([['Na2CO3', 4]]), T1([['HCl', 4]])], tip: '试管 1：每次加 1 mL 稀盐酸，开始时有没有气泡？试管 2：每次加 1 mL 碳酸钠溶液，立刻就有气泡。' }],
      ['过氧化钠与水', '放出 O₂，酚酞先红后褪', { v: [{ t: 'beaker', r: [['H2O', 30], ['phth', .1]] }], speed: 5, tip: '放入过氧化钠，观察气泡和温度；用带火星的木条检验气体；注意酚酞颜色的变化。' }],
      ['铵盐的检验', 'NH₄⁺ 与碱共热放出 NH₃', { speed: 5, v: [T1([['NH4Cl', 3], ['NaOH', 3]]), { lamp: 1 }], tip: '把试管放到酒精灯上并点燃，温度升高后用「湿润的红色石蕊试纸」检验管口的气体。' }],
      ['溶解时的热效应', 'NaOH 放热、NH₄NO₃ 吸热', { v: [{ t: 'beaker', r: [['H2O', 20]] }, { t: 'beaker', r: [['H2O', 20]] }], tip: '烧杯 1 放入氢氧化钠固体，烧杯 2 放入硝酸铵固体，比较温度变化。' }],
      ['Al³⁺ 与 HCO₃⁻', '泡沫灭火器原理', { amt: 5, v: [T1([['AlCl3', 3]])], tip: '加入 5 mL 碳酸氢钠溶液，观察沉淀和气泡。' }],
      ['氢氧化锌的两性', '溶于强碱，也溶于氨水', { amt: 1, v: [T1([['ZnSO4', 2]]), T1([['ZnSO4', 2]])], tip: '试管 1 每次加 1 mL 氢氧化钠溶液，试管 2 每次加 1 mL 氨水，各加到过量。' }],
      ['原电池加快反应', '锌粒表面析出铜', { speed: 5, amt: .1, v: [T1([['H2SO4', 8]], ['Zn']), T1([['H2SO4', 8]], ['Zn'])], tip: '向试管 2 滴加 2 滴硫酸铜溶液，比较两支试管产生气泡的快慢。' }],
      ['锌置换铁', '活动性 Zn > Fe > Cu', { speed: 20, v: [T1([['FeSO4', 6]], ['Zn']), T1([['FeSO4', 6]], ['Cu'])], tip: '观察锌粒、铜片表面的变化；时间已调到 20×。' }]
    ];
    function inspect() {
      B.clearPanel(); ui = null;
      if (tip) { L.group('实验提示'); L.note(tip); }
      if (sel && sel.kind === 'v') {
        const v = sel;
        L.group(v.name); ui = { v, m: L.out() };
        L.group('溶液中的主要粒子'); ui.sp = L.out();
        L.group('沉淀与固体'); ui.pp = L.out();
        L.group('检验与操作');
        L.button('燃着的木条', () => test(v, 'burn')); L.button('带火星的木条', () => test(v, 'glow'));
        L.button('澄清石灰水', () => test(v, 'lime')); L.button('湿润的红色石蕊试纸', () => test(v, 'litmus'));
        L.button('振荡 / 搅拌', () => { v.stir = 1.2; });
        if (v.lamp) L.button(v.lamp.lit ? '熄灭酒精灯' : '点燃酒精灯', () => toggleLamp(v.lamp)); else L.button('放到酒精灯上', () => onLamp(v));
        const others = vessels().filter(u => u !== v);
        if (others.length) {
          const s = L.select('倒入另一个容器（也可以直接把容器拖到另一个容器上方）', others.map(u => [u.id, u.name]), others[0].id, () => { });
          L.button('倒入', () => { const u = objs.find(o => o.id == s.v); if (u) { v.homeX = v.x; startPour(v, u); } });
        }
        L.button('清空', () => empty(v)); L.button('移走', () => remove(v));
      } else if (sel && sel.kind === 'lamp') {
        L.group('酒精灯');
        L.note('点击酒精灯可以点燃或熄灭。试管可以用试管夹夹持，直接在外焰上加热；烧杯、锥形瓶要垫陶土网加热。水温最高到 100 °C 并逐渐蒸发。');
        L.button(sel.lit ? '熄灭' : '点燃', () => toggleLamp(sel), true); L.button('移走', () => remove(sel));
      } else {
        L.group('使用方法');
        L.note('<b>选容器</b>：点击台面上的容器。<br><b>加药品</b>：点左侧的试剂加入选中的容器，或把试剂拖到任意容器上。<br><b>倾倒</b>：把一个容器拖到另一个容器上方后松开。<br><b>加热</b>：把容器拖到酒精灯上，点击酒精灯点燃。<br>选中后按 Delete 可移走。');
      }
      L.group('每次加入的液体');
      L.seg('', [[.1, '2 滴'], [1, '1 mL'], [2, '2 mL'], [5, '5 mL'], [20, '20 mL']], st.amt, x => { st.amt = +x; });
      L.note('指示剂每次固定加 2 滴。');
      L.group('时间');
      L.seg('', [[1, '1×'], [5, '5×'], [20, '20×']], st.speed, x => { st.speed = +x; });
      refresh();
    }
    const fc = x => (x >= .01 ? fmt(x, 3) : sci(x, 1)) + ' mol/L';
    function refresh() {
      if (!ui) return;
      const v = ui.v, e = v.e, V = v.V, t = v.tot;
      ui.m.set([
        ['体积', v.oil > .01 ? `水层 ${fmt(V, 1)} + CCl₄ ${fmt(v.oil, 1)} mL` : `${fmt(V, 1)} / ${VT[v.type].cap} mL`],
        ['温度', `${fmt(v.T, 1)} °C`],
        ['pH 计', V > .05 ? fmt(e.pH, 2) : '—'],
        V > .05 ? `<div class="kv"><span>pH 试纸</span><b><i class="phchip" style="background:${css(ramp(PHP, e.pH))}"></i>约 ${Math.round(clamp(e.pH, 0, 14))}</b></div>` : null
      ]);
      if (V < .05) ui.sp.set(`<div class="note">${v.oil > .01 ? '只有四氯化碳，没有水溶液。' : '容器里没有液体。'}</div>`);
      else {
        const rows = [], put = (n, mm) => { const x = mm / V; if (x > 1e-4) rows.push([n, x]); };
        for (const k in NM) put(NM[k], e.dis[k] || 0);
        if (e.h > 1e-4) rows.push(['H⁺', e.h]); if (e.oh > 1e-4) rows.push(['OH⁻', e.oh]);
        put('[Cu(NH₃)₄]²⁺', e.cuN); put('[Ag(NH₃)₂]⁺', e.agN); put('[Zn(NH₃)₄]²⁺', e.znN); put('[Al(OH)₄]⁻', e.alO); put('[Zn(OH)₄]²⁻', e.znO);
        put('NH₃·H₂O', e.nh3); put('NH₄⁺', e.nh4); put('CH₃COOH', e.hac); put('CH₃COO⁻', e.ac);
        put('H₂CO₃', e.h2co3); put('HCO₃⁻', e.hco3); put('CO₃²⁻', e.co3);
        put('H₂O₂', t.H2O2 || 0); put('I₂', (t.I2 || 0) * aqF(v, 'I2')); put('Br₂', (t.Br2 || 0) * aqF(v, 'Br2')); put('Cl₂', t.Cl2 || 0);
        const out = rows.sort((a, b) => b[1] - a[1]).slice(0, 12).map(([n, x]) => [n, fc(x)]);
        const ind = [];
        if (t.phth > .05) ind.push('酚酞' + (e.pH > 9 ? '（红）' : e.pH > 8.2 ? '（浅红）' : '（无色）'));
        if (t.lit > .05) ind.push('石蕊' + (e.pH < 5 ? '（红）' : e.pH > 8 ? '（蓝）' : '（紫）'));
        if (t.mo > .05) ind.push('甲基橙' + (e.pH < 3.1 ? '（红）' : e.pH > 4.4 ? '（黄）' : '（橙）'));
        if (t.starch > .05) ind.push('淀粉' + ((t.I2 || 0) / V > 3e-5 ? '（蓝）' : ''));
        if (ind.length) out.push(['指示剂', ind.join(' ')]);
        if (v.oil > .01) { const ci = (t.I2 || 0) * (1 - aqF(v, 'I2')) / v.oil, cb = (t.Br2 || 0) * (1 - aqF(v, 'Br2')) / v.oil; out.push(['CCl₄ 层', ci > 1e-4 || cb > 1e-4 ? [ci > 1e-4 ? 'I₂ ' + fc(ci) : '', cb > 1e-4 ? 'Br₂ ' + fc(cb) : ''].filter(Boolean).join('，') : '无色']); }
        ui.sp.set(out.length ? out : '<div class="note">只有水。</div>');
      }
      const pr = [];
      for (const k of PK) { const o = v.pp[k]; if (o && o.amt > .002) pr.push(`<div class="kv"><span><i class="phchip" style="background:${css(pcol(k, v))}"></i>${PN[k]}${k === 'CuO' ? '' : ' ↓'}</span><b>${fmt(o.amt * PM[k], 1)} mg</b></div>`); }
      for (const s of v.solids) { const ct = Object.keys(s.coat).filter(k => s.coat[k] > .01).map(k => COATN[k]); pr.push(`<div class="kv"><span><i class="phchip" style="background:${SO[s.k].col}"></i>${SO[s.k].n}${ct.length ? `（表面附着${ct.join('、')}）` : ''}</span><b>${fmt(s.n * SO[s.k].M / 1000, 3)} g</b></div>`); }
      ui.pp.set(pr.length ? pr : '<div class="note">没有沉淀或固体。</div>');
    }
    L.every(250, refresh);

    /* ---- 素材栏 ---- */
    const target = () => sel && sel.kind === 'v' ? sel : null;
    const rItem = r => ({
      icon: r.drop ? ic.dropper(swatch(r)) : ic.bottle(swatch(r)), label: r.n, sub: `${r.f}${r.c ? ' · ' + r.c : ''}`,
      click: () => { const v = target(); if (!v) return B.toast('先点选一个容器，或把试剂拖到容器上'); addReagent(v, r); },
      drop: (x, y) => { const v = vesselAt(x, y); if (!v) return B.toast('把试剂拖到容器上'); select(v); addReagent(v, r); }
    });
    const sItem = k => ({
      icon: ic.solid(SO[k].col), label: SO[k].n, sub: SO[k].f,
      click: () => { const v = target(); if (!v) return B.toast('先点选一个容器'); addSolid(v, k); },
      drop: (x, y) => { const v = vesselAt(x, y); if (!v) return B.toast('把固体拖到容器上'); select(v); addSolid(v, k); }
    });
    const vItem = (type, sub) => ({ icon: ic[type], label: VT[type].n, sub, click: () => { const v = newV(type, c.w / 2); if (v) select(v); }, drop: x => { const v = newV(type, x); if (v) select(v); } });
    const demoIc = '<svg viewBox="0 0 24 24"><path d="M9 3h6M10 3v6l-5 9a1.4 1.4 0 0 0 1.2 2.1h11.6A1.4 1.4 0 0 0 19 18l-5-9V3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M7.3 14h9.4l1.6 3H5.7z" fill="#e85a9a"/></svg>';
    B.palette([
      { title: '示例实验', items: PRE.map(([n, s, p]) => ({ icon: demoIc, label: n, sub: s, click: () => scene(p) })) },
      { title: '器材', items: [vItem('tube', '20 mL'), vItem('beaker', '200 mL'), vItem('flask', '250 mL'), { icon: ic.lamp, label: '酒精灯', sub: '带三脚架和陶土网', click: () => { const l = newLamp(c.w * .8); if (l) select(l); }, drop: x => { const l = newLamp(x); if (l) select(l); } },
        { icon: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>', label: '清空台面', sub: '恢复空的试管、烧杯、锥形瓶', click: () => scene({ v: [{ t: 'tube' }, { t: 'beaker' }, { t: 'flask' }, { lamp: 1 }] }) }] },
      { title: '酸和碱', items: RG.filter(r => r.s === 'acid').map(rItem) },
      { title: '盐溶液', items: RG.filter(r => r.s === 'salt').map(rItem) },
      { title: '氧化剂和还原剂', items: RG.filter(r => r.s === 'redox').map(rItem) },
      { title: '指示剂', items: RG.filter(r => r.s === 'ind').map(rItem) },
      { title: '固体', items: Object.keys(SO).map(sItem) },
      { title: '水、溶剂和气体', items: [...RG.filter(r => r.s === 'gas').map(rItem), { icon: ic.gas, label: '通入 CO₂', sub: '每次约 0.3 mmol', click: () => { const v = target(); if (!v) return B.toast('先点选一个容器'); addReagent(v, { id: 'CO2' }); }, drop: (x, y) => { const v = vesselAt(x, y); if (!v) return B.toast('拖到容器上'); select(v); addReagent(v, { id: 'CO2' }); } }] }
    ]);

    /* ---- 主循环 ---- */
    L.loop(dt => {
      clock += dt;
      const sd = dt * st.speed, n = Math.max(1, Math.ceil(sd / .05)), h = sd / n;
      for (const v of vessels()) {
        for (const a of v.anims) { a.t += dt; const due = a.k === 'drip' ? .45 : a.k === 'stream' ? .3 : a.k === 'gas' ? .35 : .5; if (!a.done && a.t >= due) { a.done = true; a.go(); } }
        v.anims = v.anims.filter(a => a.t < (a.k === 'stream' ? .6 : .55));
        if (v.pour) {
          const p = v.pour; p.t += dt;
          const want = clamp((p.t - .35) / .7, 0, 1);
          if (want > p.done && !p.full) { const fr = (want - p.done) / (1 - p.done || 1); if (!transfer(v, p.to, fr)) { p.full = true; B.toast(`${p.to.name} 装满了`); } p.done = want; }
          if (p.t > 1.4) { v.pour = null; v.lift = 0; v.x = nearFree(v, v.homeX ?? v.x); if (p.dT) neutral(p.to, { dT: p.dT, k: p.k }); }
        }
        for (let i = 0; i < n; i++) react(v, h);
        after(v, sd, dt);
      }
      L.draw();
    });

    // 初始台面
    layout();
    scene({ v: [{ t: 'tube' }, { t: 'beaker' }, { t: 'flask' }, { lamp: 1 }] });
    select(objs[0]);
  }
});
})();
