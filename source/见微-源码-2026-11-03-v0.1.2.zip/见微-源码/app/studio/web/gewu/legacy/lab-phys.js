/* 见微 · 变换实验室 · 物理工作台
   自由搭建的物理场景：左侧物体库 → 画布拖放 → 右栏属性检查器 → 1/240 s 定步长仿真。
   契约：window.JWLabPhys = { mount(shell) -> api }
   api: { resize(), activate(), exportPNG(), start(), pause(), reset() }
   画布取色统一走 JW.C（跟随昼夜自动换皮），DOM 走 CSS 变量 --t-*。
   仅依赖 window.JW，无外部库、无 ES module、无网络。 */
(function () {
  'use strict';
  const JW = window.JW;
  if (!JW || !JW.Canvas) return;

  const C = JW.C, PI = Math.PI, TAU = PI * 2;
  const el = JW.el, num = JW.num, clamp = JW.clamp, rad = JW.rad, deg = JW.deg;
  const DT = 1 / 240;          // 固定子步
  const ORBIT_UNIT = 1e7;      // 引力场景：1 世界单位 = 10^7 m（≈ 1.6 个地球半径）
  const ORBIT_SCALE = 1200;    // 轨道演示的时间倍率（读数是真实量纲）

  let S = null;                // 当前引擎状态（每次 mount 重建）
  let cv = null, ctx = null;
  let cam = { x: 0, y: 1.4, scale: 70 };
  let seq = 0;
  const errors = [];

  function noteError(e) {
    const msg = e && e.message ? String(e.message) : String(e);
    if (errors.indexOf(msg) < 0) errors.push(msg);
    if (window.console && console.warn) console.warn('[lab-phys]', e);
  }
  window.addEventListener('error', function (e) { noteError(e.error || e.message); });
  window.addEventListener('unhandledrejection', function (e) { noteError(e.reason); });

  /* ================= 一、坐标、画笔与通用小工具 ================= */
  function px(x) { return (x - cam.x) * cam.scale + cv.w / 2; }
  function py(y) { return cv.h / 2 - (y - cam.y) * cam.scale; }
  function wx(p) { return (p - cv.w / 2) / cam.scale + cam.x; }
  function wy(p) { return (cv.h / 2 - p) / cam.scale + cam.y; }
  function sp(m) { return m * cam.scale; }
  function halfW() { return cv.w / (2 * cam.scale); }
  function halfH() { return cv.h / (2 * cam.scale); }
  function fmt(v, d) { return isFinite(v) ? num(v, d == null ? 2 : d) : '—'; }

  function withAlpha(col, a) {
    if (!col) return 'rgba(0,0,0,' + a + ')';
    if (col.charAt(0) === '#') {
      let h = col.slice(1);
      if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
      const n = parseInt(h, 16);
      return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
    }
    const m = /rgba?\(([^)]+)\)/.exec(col);
    if (m) {
      const p = m[1].split(',').map(parseFloat);
      return 'rgba(' + p[0] + ',' + p[1] + ',' + p[2] + ',' + a + ')';
    }
    return col;
  }

  function lineW(pts, color, w, dash, alpha) {
    if (!pts || pts.length < 2) return;
    ctx.save();
    if (alpha != null) ctx.globalAlpha = alpha;
    ctx.beginPath();
    ctx.moveTo(px(pts[0][0]), py(pts[0][1]));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(px(pts[i][0]), py(pts[i][1]));
    ctx.strokeStyle = color || C.ink;
    ctx.lineWidth = w || 1.5;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (dash) ctx.setLineDash(dash);
    ctx.stroke();
    ctx.restore();
  }
  function polyW(pts, fill, stroke, w, alpha, dash) {
    if (!pts || pts.length < 2) return;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(px(pts[0][0]), py(pts[0][1]));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(px(pts[i][0]), py(pts[i][1]));
    ctx.closePath();
    if (fill) {
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.fillStyle = fill; ctx.fill();
      ctx.globalAlpha = 1;
    }
    if (stroke) {
      ctx.strokeStyle = stroke; ctx.lineWidth = w || 1.4;
      ctx.lineJoin = 'round';
      if (dash) ctx.setLineDash(dash);
      ctx.stroke();
    }
    ctx.restore();
  }
  function circleP(X, Y, R, fill, stroke, w, dash) {
    if (!isFinite(X) || !isFinite(Y) || !isFinite(R) || R <= 0) return;
    ctx.save();
    ctx.beginPath(); ctx.arc(X, Y, R, 0, TAU);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) {
      ctx.strokeStyle = stroke; ctx.lineWidth = w || 1.4;
      if (dash) ctx.setLineDash(dash);
      ctx.stroke();
    }
    ctx.restore();
  }
  function circleW(x, y, rM, fill, stroke, w, dash) {
    circleP(px(x), py(y), Math.max(1.2, sp(rM)), fill, stroke, w, dash);
  }
  function rectW(x, y, wM, hM, fill, stroke, lw, dash) {
    const X = px(x), Y = py(y + hM), W = sp(wM), H = sp(hM);
    ctx.save();
    ctx.beginPath(); ctx.rect(X, Y, W, H);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) {
      ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1.4;
      if (dash) ctx.setLineDash(dash);
      ctx.stroke();
    }
    ctx.restore();
  }
  function roundRectP(X, Y, W, H, r, fill, stroke, lw, dash) {
    r = Math.min(r, W / 2, H / 2);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(X + r, Y);
    ctx.arcTo(X + W, Y, X + W, Y + H, r);
    ctx.arcTo(X + W, Y + H, X, Y + H, r);
    ctx.arcTo(X, Y + H, X, Y, r);
    ctx.arcTo(X, Y, X + W, Y, r);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) {
      ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1.4;
      if (dash) ctx.setLineDash(dash);
      ctx.stroke();
    }
    ctx.restore();
  }
  function arrowP(X, Y, X2, Y2, color, w, head) {
    const dx = X2 - X, dy = Y2 - Y, L = Math.hypot(dx, dy);
    if (L < 1.2) return;
    const a = Math.atan2(dy, dx), h = Math.min(head || 8, L * 0.45);
    ctx.save();
    ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(X2, Y2);
    ctx.strokeStyle = color || C.ink2; ctx.lineWidth = w || 1.6; ctx.lineCap = 'round';
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(X2, Y2);
    ctx.lineTo(X2 - h * Math.cos(a - 0.42), Y2 - h * Math.sin(a - 0.42));
    ctx.lineTo(X2 - h * Math.cos(a + 0.42), Y2 - h * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fillStyle = color || C.ink2; ctx.fill();
    ctx.restore();
  }
  function arrowW(x, y, dx, dy, color, w, head, label) {
    const X = px(x), Y = py(y), X2 = px(x + dx), Y2 = py(y + dy);
    if (Math.hypot(X2 - X, Y2 - Y) < 1.2) return;
    arrowP(X, Y, X2, Y2, color, w, head);
    if (label) {
      const right = X2 >= X;
      txtP(X2 + (right ? 5 : -5), Y2 + (dy >= 0 ? -10 : 11), label, {
        color: color, size: 10, weight: 700, align: right ? 'left' : 'right', halo: true
      });
    }
  }
  function txtP(X, Y, s, o) {
    o = o || {};
    ctx.save();
    ctx.font = (o.weight || 600) + ' ' + (o.size || 11) + 'px ' + (o.mono ? C.mono : C.sans);
    ctx.textAlign = o.align || 'left';
    ctx.textBaseline = o.base || 'middle';
    ctx.lineJoin = 'round';
    if (o.halo !== false) {
      ctx.lineWidth = 3.4;
      ctx.strokeStyle = o.haloColor || S.bg;
      ctx.strokeText(s, X, Y);
    }
    ctx.fillStyle = o.color || C.ink;
    ctx.fillText(s, X, Y);
    ctx.restore();
  }
  function txt(x, y, s, o) {
    txtP(px(x) + ((o && o.ox) || 0), py(y) + ((o && o.oy) || 0), s, o);
  }
  function arcW(cx, cy, rM, a0, a1, color, w, dash) {
    const R = Math.max(2, sp(rM));
    ctx.save();
    ctx.beginPath();
    for (let i = 0; i <= 40; i++) {
      const a = a0 + (a1 - a0) * i / 40;
      const X = px(cx + rM * Math.cos(a)), Y = py(cy + rM * Math.sin(a));
      if (i) ctx.lineTo(X, Y); else ctx.moveTo(X, Y);
    }
    ctx.strokeStyle = color; ctx.lineWidth = w || 1.2;
    if (dash) ctx.setLineDash(dash);
    ctx.stroke();
    ctx.restore();
  }
  function tagP(X, Y, s, color, align) {
    ctx.save();
    ctx.font = '600 10px ' + C.sans;
    const w = ctx.measureText(s).width + 12, h = 17;
    const x = X - (align === 'center' ? w / 2 : align === 'right' ? w : 0), y = Y - h / 2;
    roundRectP(x, y, w, h, 5, withAlpha(S.bg, 0.86), withAlpha(color, 0.5), 1);
    ctx.fillStyle = color; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(s, x + 6, Y + 0.5);
    ctx.restore();
  }

  function pushTrail(o, x, y, dt, gap) {
    if (!S.show.trail) return;
    o.trail = o.trail || [];
    o._tt = (o._tt || 0) + dt;
    if (o._tt < (gap || 0.05)) return;
    o._tt = 0;
    o.trail.push([x, y]);
    if (o.trail.length > 1600) o.trail.shift();
  }
  function drawTrail(o, color, alpha) {
    if (!S.show.trail || !o.trail || o.trail.length < 2) return;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(px(o.trail[0][0]), py(o.trail[0][1]));
    for (let i = 1; i < o.trail.length; i++) ctx.lineTo(px(o.trail[i][0]), py(o.trail[i][1]));
    ctx.strokeStyle = withAlpha(color || C.accent, alpha == null ? 0.5 : alpha);
    ctx.lineWidth = 1.6; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }
  function velArrow(x, y, vx, vy, label, color, k) {
    if (!S.show.vectors) return;
    const s = k == null ? 0.24 : k;
    arrowW(x, y, vx * s, vy * s, color || C.accent, 1.8, 8, label);
  }
  function forceArrow(x, y, ax, ay, label, color) {
    if (!S.show.vectors) return;
    const k = 0.06;
    arrowW(x, y, ax * k, ay * k, color || C.jade, 1.5, 7, label);
  }

  /* ================= 二、物体类型注册表 ================= */
  const TYPES = {};
  function def(type, spec) { spec.type = type; TYPES[type] = spec; return spec; }
  const GROUPS = [
    { key: 'kin', name: '运动学' },
    { key: 'mech', name: '力学' },
    { key: 'elec', name: '电学' },
    { key: 'mag', name: '磁场' },
    { key: 'efield', name: '电场' },
    { key: 'optics', name: '光学' },
    { key: 'wave', name: '波' },
    { key: 'grav', name: '万有引力' }
  ];
  function typesOfGroup(g) {
    return Object.keys(TYPES).filter(function (k) { return TYPES[k].group === g; });
  }

  /* ---------- 运动学 ---------- */
  def('car', {
    name: '小车', group: 'kin', z: 3, hit: 0.6, desc: '地面上的小车，受动摩擦减速',
    snapY: 0,
    params: [
      { k: 'm', label: '质量 m', unit: 'kg', min: 0.2, max: 10, step: 0.1, def: 1, dec: 1 },
      { k: 'v0', label: '初速 v₀', unit: 'm/s', min: -8, max: 8, step: 0.1, def: 2, dec: 1 },
      { k: 'mu', label: '动摩擦 μ', unit: '', min: 0, max: 0.8, step: 0.01, def: 0.12, dec: 2 }
    ],
    init(o) { o.s.rx = 0; o.s.v = o.p.v0; o.trail = []; o._tt = 0; },
    onParam(o, k) { if (k === 'v0') o.s.v = o.p.v0; },
    step(o, dt) {
      const mu = o.p.mu, g = S.g;
      let v = o.s.v;
      if (Math.abs(v) > 1e-3) {
        const nv = v - Math.sign(v) * mu * g * dt;
        v = (Math.sign(nv) !== Math.sign(v)) ? 0 : nv;
      }
      o.s.v = v;
      o.s.rx += v * dt;
      pushTrail(o, o.x + o.s.rx, o.y + 0.3, dt, 0.06);
    },
    bounds(o) { return { x0: o.x + o.s.rx - 0.62, x1: o.x + o.s.rx + 0.62, y0: o.y - 0.06, y1: o.y + 0.8 }; },
    draw(o) {
      const x = o.x + o.s.rx, y = o.y;
      drawTrail(o, C.ink2, 0.3);
      // 车身
      roundRectP(px(x) - sp(0.45), py(y + 0.48), sp(0.9), sp(0.3), 5,
        withAlpha(C.ink2, 0.2), C.ink, 1.4);
      roundRectP(px(x) - sp(0.2), py(y + 0.62), sp(0.34), sp(0.14), 4,
        withAlpha(C.accent, 0.22), withAlpha(C.accent, 0.7), 1.1);
      // 车轮
      circleW(x - 0.27, y + 0.13, 0.11, withAlpha(C.ink, 0.18), C.ink, 1.3);
      circleW(x + 0.27, y + 0.13, 0.11, withAlpha(C.ink, 0.18), C.ink, 1.3);
      circleW(x - 0.27, y + 0.13, 0.04, C.ink, null, 0);
      circleW(x + 0.27, y + 0.13, 0.04, C.ink, null, 0);
      if (S.show.vectors) {
        velArrow(x, y + 0.42, o.s.v, 0, 'v');
        if (Math.abs(o.s.v) > 0.05) {
          forceArrow(x, y + 0.2, -Math.sign(o.s.v) * o.p.mu * S.g, 0, 'f');
        }
      }
      txt(x, y + 0.92, '小车 m=' + fmt(o.p.m, 1) + ' kg', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const a = Math.abs(o.s.v) > 1e-3 ? -Math.sign(o.s.v) * o.p.mu * S.g : 0;
      return [
        ['速度 v', fmt(o.s.v, 2), 'm/s'],
        ['加速度 a', fmt(a, 2), 'm/s²'],
        ['位移 x', fmt(o.s.rx, 2), 'm'],
        ['动能 Ek', fmt(0.5 * o.p.m * o.s.v * o.s.v, 2), 'J']
      ];
    }
  });

  def('projectile', {
    name: '抛体小球', group: 'kin', z: 4, hit: 0.32, desc: '斜抛 / 平抛小球，落地会反弹',
    params: [
      { k: 'm', label: '质量 m', unit: 'kg', min: 0.1, max: 5, step: 0.1, def: 1, dec: 2 },
      { k: 'v0', label: '初速 v₀', unit: 'm/s', min: 0, max: 20, step: 0.5, def: 8, dec: 1 },
      { k: 'th', label: '抛射角 θ', unit: '°', min: 0, max: 90, step: 1, def: 45, dec: 0 }
    ],
    init(o) {
      const a = rad(o.p.th);
      o.s.rx = 0; o.s.ry = 0; o.s.landed = false;
      o.s.vx = o.p.v0 * Math.cos(a);
      o.s.vy = o.p.v0 * Math.sin(a);
      o.trail = []; o._tt = 0;
    },
    onParam(o) { this.init(o); },
    step(o, dt) {
      if (o.s.landed) return;
      o.s.vy -= S.g * dt;
      o.s.rx += o.s.vx * dt;
      o.s.ry += o.s.vy * dt;
      if (S.show.ground && o.y + o.s.ry < 0.16) {
        o.s.ry = 0.16 - o.y;
        o.s.vy = -o.s.vy * 0.55;
        o.s.vx *= 0.92;
        if (Math.abs(o.s.vy) < 0.7) { o.s.vy = 0; o.s.landed = true; }
      }
      pushTrail(o, o.x + o.s.rx, o.y + o.s.ry, dt, 0.035);
    },
    bounds(o) { return { x0: o.x + o.s.rx - 0.3, x1: o.x + o.s.rx + 0.3, y0: o.y + o.s.ry - 0.3, y1: o.y + o.s.ry + 0.3 }; },
    draw(o) {
      const x = o.x + o.s.rx, y = o.y + o.s.ry;
      drawTrail(o, C.accent, 0.45);
      circleW(x, y, 0.155, withAlpha(C.accent, 0.85), C.ink, 1.2);
      circleW(x - 0.045, y + 0.045, 0.04, withAlpha('#FFFFFF', 0.45), null, 0);
      if (S.show.vectors && !o.s.landed) {
        const k = 0.16;
        lineW([[x, y], [x + o.s.vx * k, y]], withAlpha(C.ink2, 0.45), 1, [3, 4]);
        lineW([[x + o.s.vx * k, y], [x + o.s.vx * k, y + o.s.vy * k]], withAlpha(C.ink2, 0.45), 1, [3, 4]);
        velArrow(x, y, o.s.vx, o.s.vy, 'v', C.accent, k);
        forceArrow(x, y, 0, -S.g * o.p.m, 'mg');
      }
      txt(x + 0.24, y + 0.58, '抛体 v₀=' + fmt(o.p.v0, 1) + ' m/s', { align: 'left', size: 10.5, color: C.ink2 });
    },
    read(o) {
      return [
        ['速度 v', fmt(Math.hypot(o.s.vx, o.s.vy), 2), 'm/s'],
        ['水平分量 vx', fmt(o.s.vx, 2), 'm/s'],
        ['竖直分量 vy', fmt(o.s.vy, 2), 'm/s'],
        ['高度 y', fmt(o.y + o.s.ry, 2), 'm'],
        ['加速度 a', fmt(S.g, 2), 'm/s²']
      ];
    }
  });

  def('circular', {
    name: '圆周运动小球', group: 'kin', z: 4, hit: 0.4, desc: '匀速圆周运动，向心加速度可读',
    params: [
      { k: 'm', label: '质量 m', unit: 'kg', min: 0.1, max: 5, step: 0.1, def: 0.5, dec: 2 },
      { k: 'v', label: '线速度 v', unit: 'm/s', min: 0.4, max: 8, step: 0.1, def: 2.4, dec: 1 },
      { k: 'R', label: '半径 R', unit: 'm', min: 0.4, max: 3, step: 0.05, def: 1.2, dec: 2 }
    ],
    init(o) { o.s.th = 0; o.trail = []; o._tt = 0; },
    onParam(o, k) { if (k === 'R') o.s.th = 0; },
    step(o, dt) {
      const w = o.p.v / Math.max(0.05, o.p.R);
      o.s.th += w * dt;
      const x = o.x + o.p.R * Math.cos(o.s.th), y = o.y + o.p.R * Math.sin(o.s.th);
      pushTrail(o, x, y, dt, 0.05);
    },
    bounds(o) { return { x0: o.x - o.p.R - 0.3, x1: o.x + o.p.R + 0.3, y0: o.y - o.p.R - 0.3, y1: o.y + o.p.R + 0.3 }; },
    selRing(o) { return o.p.R + 0.16; },
    draw(o) {
      const R = o.p.R, th = o.s.th;
      circleW(o.x, o.y, R, null, withAlpha(C.ink2, 0.55), 1.3, [5, 5]);
      circleW(o.x, o.y, 0.05, C.ink, null, 0);
      const x = o.x + R * Math.cos(th), y = o.y + R * Math.sin(th);
      drawTrail(o, C.jade, 0.5);
      lineW([[o.x, o.y], [x, y]], withAlpha(C.ink2, 0.4), 1, [3, 4]);
      circleW(x, y, 0.15, withAlpha(C.accent, 0.85), C.ink, 1.2);
      if (S.show.vectors) {
        const vx = -Math.sin(th) * o.p.v, vy = Math.cos(th) * o.p.v;
        velArrow(x, y, vx, vy, 'v');
        forceArrow(x, y, -Math.cos(th) * o.p.v * o.p.v / R * 0.25,
          -Math.sin(th) * o.p.v * o.p.v / R * 0.25, 'a向心');
      }
      txt(o.x, o.y + R + 0.45, '圆周 R=' + fmt(R, 2) + ' m', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const R = o.p.R, v = o.p.v, w = v / R;
      return [
        ['线速度 v', fmt(v, 2), 'm/s'],
        ['角速度 ω', fmt(w, 2), 'rad/s'],
        ['向心加速度', fmt(v * v / R, 2), 'm/s²'],
        ['周期 T', fmt(TAU / w, 2), 's'],
        ['向心力 F', fmt(o.p.m * v * v / R, 2), 'N']
      ];
    }
  });

  def('belt', {
    name: '传送带', group: 'kin', z: 2, hit: 0.45, desc: '匀速传送带，表面速度可调',
    snapY: 0.24,
    params: [
      { k: 'v', label: '带速 v', unit: 'm/s', min: 0, max: 4, step: 0.1, def: 1.6, dec: 1 },
      { k: 'L', label: '长度 L', unit: 'm', min: 1, max: 6, step: 0.1, def: 3.6, dec: 1 },
      { k: 'mu', label: '带面 μ', unit: '', min: 0, max: 0.9, step: 0.01, def: 0.3, dec: 2 }
    ],
    init(o) { o.s.phase = 0; },
    step(o, dt) { o.s.phase = (o.s.phase + o.p.v * dt / Math.max(0.2, o.p.L)) % 1; },
    bounds(o) { return { x0: o.x - 0.35, x1: o.x + o.p.L + 0.35, y0: o.y - 0.45, y1: o.y + 0.45 }; },
    draw(o) {
      const L = o.p.L, y = o.y;
      const x0 = o.x + 0.26, x1 = o.x + L;
      circleW(x0, y, 0.22, withAlpha(C.ink2, 0.12), C.ink2, 1.3);
      circleW(x1, y, 0.22, withAlpha(C.ink2, 0.12), C.ink2, 1.3);
      circleW(x0, y, 0.05, C.ink, null, 0);
      circleW(x1, y, 0.05, C.ink, null, 0);
      lineW([[x0, y + 0.22], [x1, y + 0.22]], C.ink, 2);
      lineW([[x0, y - 0.22], [x1, y - 0.22]], C.ink, 2);
      // 带面流动刻线
      for (let i = 0; i < 12; i++) {
        const f = ((i / 12) + o.s.phase) % 1;
        const X = px(x0) + f * sp(L - 0.26);
        if (X > px(x0) + 2 && X < px(x1) - 2) {
          ctx.save();
          ctx.strokeStyle = withAlpha(C.accent, 0.75);
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(X - 3, py(y + 0.22) - 5);
          ctx.lineTo(X + 2, py(y + 0.22));
          ctx.lineTo(X - 3, py(y + 0.22) + 5);
          ctx.stroke();
          ctx.restore();
        }
      }
      if (S.show.vectors) velArrow(o.x + 0.7, y + 0.42, o.p.v, 0, 'v带');
      txt(o.x + L / 2, y + 0.62, '传送带 v=' + fmt(o.p.v, 1) + ' m/s', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const T = o.p.v > 0.01 ? o.p.L / o.p.v : Infinity;
      return [
        ['带速 v', fmt(o.p.v, 2), 'm/s'],
        ['长度 L', fmt(o.p.L, 2), 'm'],
        ['周期 T', isFinite(T) ? fmt(T, 2) : '—', 's'],
        ['带面摩擦 μ', fmt(o.p.mu, 2), '']
      ];
    }
  });

  /* ---------- 力学 ---------- */
  def('incline', {
    name: '斜面', group: 'mech', z: 2, hit: 0.8, desc: '斜面 + 滑块，含摩擦与倾角',
    snapY: 0,
    params: [
      { k: 'th', label: '倾角 θ', unit: '°', min: 5, max: 70, step: 1, def: 30, dec: 0 },
      { k: 'mu', label: '动摩擦 μ', unit: '', min: 0, max: 0.9, step: 0.01, def: 0.2, dec: 2 },
      { k: 'm', label: '滑块质量 m', unit: 'kg', min: 0.2, max: 5, step: 0.1, def: 1, dec: 2 },
      { k: 'L', label: '斜面长 L', unit: 'm', min: 1, max: 5, step: 0.1, def: 3, dec: 1 },
      { k: 'v0', label: '初速 v₀', unit: 'm/s', min: 0, max: 4, step: 0.1, def: 0, dec: 1 }
    ],
    init(o) { o.s.s = 0; o.s.v = o.p.v0; },
    onParam(o) { o.s.s = 0; o.s.v = o.p.v0; },
    step(o, dt) {
      const th = rad(o.p.th), L = o.p.L;
      let a = S.g * (Math.sin(th) - o.p.mu * Math.cos(th));
      if (Math.abs(o.s.v) < 1e-3 && Math.tan(th) <= o.p.mu) a = 0;
      let v = o.s.v + a * dt;
      if (v < 0) v = 0;
      o.s.v = v;
      o.s.s += v * dt;
      if (o.s.s > L - 0.3) { o.s.s = L - 0.3; o.s.v = 0; }
    },
    bounds(o) {
      const th = rad(o.p.th), L = o.p.L;
      return { x0: o.x - 0.2, x1: o.x + L * Math.cos(th) + 0.25, y0: o.y - 0.15, y1: o.y + L * Math.sin(th) + 0.35 };
    },
    draw(o) {
      const th = rad(o.p.th), L = o.p.L;
      const A = [o.x, o.y], B = [o.x + L * Math.cos(th), o.y], Cc = [o.x, o.y + L * Math.sin(th)];
      polyW([A, B, Cc], withAlpha(C.ink2, 0.1), C.ink, 1.6);
      lineW([Cc, B], C.ink, 2);
      // 倾角标注
      arcW(B[0], B[1], 0.72, PI - th, PI, withAlpha(C.accent, 0.8), 1.3);
      // 滑块
      const along = o.s.s + 0.16;
      const P = [Cc[0] + along * Math.cos(th), Cc[1] - along * Math.sin(th)];
      const nx = Math.sin(th), ny = Math.cos(th);
      const bc = [P[0] + nx * 0.17, P[1] + ny * 0.17];
      ctx.save();
      ctx.translate(px(bc[0]), py(bc[1]));
      ctx.rotate(-th);
      roundRectP(-sp(0.26), -sp(0.17), sp(0.52), sp(0.34), 4,
        withAlpha(C.accent, 0.75), C.ink, 1.2);
      ctx.restore();
      // 速度矢量沿斜面向下
      if (S.show.vectors && o.s.v > 0.01) {
        velArrow(bc[0], bc[1], o.s.v * Math.cos(th) * 0.24, -o.s.v * Math.sin(th) * 0.24, 'v');
        forceArrow(bc[0], bc[1] - 0.1, 0, -o.p.m * S.g, 'mg');
      }
      txt(o.x + L * Math.cos(th) * 0.5, o.y + L * Math.sin(th) + 0.34,
        '斜面 θ=' + fmt(o.p.th, 0) + '° μ=' + fmt(o.p.mu, 2),
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const th = rad(o.p.th);
      const a = S.g * (Math.sin(th) - o.p.mu * Math.cos(th));
      return [
        ['加速度 a', fmt(a, 2), 'm/s²'],
        ['速度 v', fmt(o.s.v, 2), 'm/s'],
        ['下滑位移 s', fmt(o.s.s, 2), 'm'],
        ['支持力 N', fmt(o.p.m * S.g * Math.cos(th), 2), 'N'],
        ['摩擦力 f', fmt(o.p.mu * o.p.m * S.g * Math.cos(th), 2), 'N']
      ];
    }
  });

  def('spring', {
    name: '弹簧振子', group: 'mech', z: 3, hit: 0.7, desc: '水平弹簧振子，简谐振动',
    snapY: 0,
    params: [
      { k: 'k', label: '劲度 k', unit: 'N/m', min: 2, max: 80, step: 1, def: 20, dec: 1 },
      { k: 'm', label: '质量 m', unit: 'kg', min: 0.2, max: 3, step: 0.1, def: 0.5, dec: 2 },
      { k: 'A', label: '振幅 A', unit: 'm', min: 0.1, max: 0.9, step: 0.05, def: 0.45, dec: 2 }
    ],
    init(o) { o.s.x = o.p.A; o.s.v = 0; o.trail = []; o._tt = 0; },
    onParam(o) { this.init(o); },
    step(o, dt) {
      const a = -o.p.k / o.p.m * o.s.x;
      o.s.v += a * dt;
      o.s.x += o.s.v * dt;
      pushTrail(o, o.x + o.s.x, o.y + 0.22, dt, 0.04);
    },
    bounds(o) { return { x0: o.x - 1.4, x1: o.x + 0.55, y0: o.y - 0.15, y1: o.y + 0.7 }; },
    draw(o) {
      const baseY = o.y + 0.2, wallX = o.x - 1.25;
      // 墙
      lineW([[wallX, baseY - 0.3], [wallX, baseY + 0.45]], C.ink, 3);
      for (let i = 0; i < 5; i++) {
        lineW([[wallX, baseY - 0.3 + i * 0.16], [wallX - 0.14, baseY - 0.4 + i * 0.16]], withAlpha(C.ink2, 0.5), 1);
      }
      // 地面
      lineW([[wallX, o.y], [o.x + 0.7, o.y]], withAlpha(C.ink2, 0.35), 1.2);
      const bx = o.x + o.s.x;
      const left = bx - 0.24, right = bx + 0.24;
      // 弹簧线圈
      const X0 = px(wallX), X1 = px(left), Y = py(baseY);
      const n = 9, span = X1 - X0;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(X0, Y);
      for (let i = 0; i <= n; i++) {
        const xx = X0 + span * (i + 0.5) / (n + 1);
        ctx.lineTo(xx, Y + (i % 2 ? -8 : 8));
      }
      ctx.lineTo(X1, Y);
      ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
      ctx.stroke();
      ctx.restore();
      // 平衡位置
      lineW([[o.x, o.y], [o.x, baseY + 0.42]], withAlpha(C.accent, 0.5), 1, [4, 4]);
      // 滑块
      roundRectP(px(left), py(o.y + 0.44), sp(0.48), sp(0.44), 4,
        withAlpha(C.accent, 0.65), C.ink, 1.2);
      drawTrail(o, C.jade, 0.35);
      if (S.show.vectors) {
        velArrow(bx, baseY + 0.28, o.s.v * 0.5, 0, 'v');
        forceArrow(bx, baseY + 0.28, -o.p.k * o.s.x, 0, 'F');
      }
      txt(o.x, o.y + 0.9, '弹簧 k=' + fmt(o.p.k, 0) + ' N/m', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const w = Math.sqrt(o.p.k / o.p.m);
      return [
        ['位移 x', fmt(o.s.x, 2), 'm'],
        ['速度 v', fmt(o.s.v, 2), 'm/s'],
        ['加速度 a', fmt(-o.p.k / o.p.m * o.s.x, 2), 'm/s²'],
        ['周期 T', fmt(TAU / w, 2), 's'],
        ['总能量 E', fmt(0.5 * o.p.k * o.p.A * o.p.A, 2), 'J']
      ];
    }
  });

  def('pendulum', {
    name: '单摆', group: 'mech', z: 4, hit: 0.6, desc: '单摆，小角度近简谐，可加阻尼',
    params: [
      { k: 'L', label: '摆长 L', unit: 'm', min: 0.4, max: 2.4, step: 0.05, def: 1.2, dec: 2 },
      { k: 'm', label: '摆球质量 m', unit: 'kg', min: 0.1, max: 3, step: 0.1, def: 0.5, dec: 2 },
      { k: 'th0', label: '初始摆角 θ₀', unit: '°', min: 5, max: 75, step: 1, def: 35, dec: 0 },
      { k: 'damp', label: '阻尼 ζ', unit: '', min: 0, max: 0.12, step: 0.005, def: 0.015, dec: 3 }
    ],
    init(o) { o.s.th = rad(o.p.th0); o.s.w = 0; o.trail = []; o._tt = 0; },
    onParam(o) { o.s.th = rad(o.p.th0); o.s.w = 0; },
    step(o, dt) {
      const al = -(S.g / o.p.L) * Math.sin(o.s.th) - o.p.damp * o.s.w;
      o.s.w += al * dt;
      o.s.th += o.s.w * dt;
      pushTrail(o, o.x + o.p.L * Math.sin(o.s.th), o.y - o.p.L * Math.cos(o.s.th), dt, 0.035);
    },
    bounds(o) {
      const L = o.p.L, bx = o.x + L * Math.sin(o.s.th);
      return {
        x0: Math.min(o.x, bx) - 0.32, x1: Math.max(o.x, bx) + 0.32,
        y0: o.y - L - 0.28, y1: o.y + 0.24
      };
    },
    draw(o) {
      const L = o.p.L, th = o.s.th;
      const bx = o.x + L * Math.sin(th), by = o.y - L * Math.cos(th);
      // 悬挂点
      lineW([[o.x - 0.35, o.y + 0.04], [o.x + 0.35, o.y + 0.04]], C.ink, 2.4);
      for (let i = 0; i < 5; i++) {
        lineW([[o.x - 0.32 + i * 0.16, o.y + 0.04], [o.x - 0.4 + i * 0.16, o.y + 0.14]], withAlpha(C.ink2, 0.5), 1);
      }
      // 摆动轨迹
      arcW(o.x, o.y, L, -PI / 2 - rad(o.p.th0), -PI / 2 + rad(o.p.th0), withAlpha(C.ink2, 0.3), 1, [3, 5]);
      lineW([[o.x, o.y], [bx, by]], withAlpha(C.ink, 0.65), 1.4);
      drawTrail(o, C.accent, 0.4);
      circleW(bx, by, 0.13, withAlpha(C.accent, 0.85), C.ink, 1.2);
      // 摆角
      if (Math.abs(th) > 0.03) {
        arcW(o.x, o.y, 0.32, -PI / 2, -PI / 2 + th, withAlpha(C.accent, 0.8), 1.2);
      }
      if (S.show.vectors) {
        const vx = L * o.s.w * Math.cos(th), vy = L * o.s.w * Math.sin(th);
        velArrow(bx, by, vx * 1.2, vy * 1.2, 'v');
        forceArrow(bx, by, 0, -o.p.m * S.g, 'mg');
      }
      txt(bx, by + 0.42, '单摆 L=' + fmt(L, 2) + ' m', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const th = o.s.th, L = o.p.L;
      const v = L * o.s.w;
      const T = o.p.damp > 0.001 ? TAU / Math.sqrt(S.g / L) : TAU * Math.sqrt(L / S.g);
      return [
        ['摆角 θ', fmt(deg(th), 1), '°'],
        ['角速度 ω', fmt(o.s.w, 2), 'rad/s'],
        ['线速度 v', fmt(v, 2), 'm/s'],
        ['周期 T', fmt(TAU * Math.sqrt(L / S.g), 2), 's'],
        ['回复力 F', fmt(-o.p.m * S.g * Math.sin(th), 2), 'N']
      ];
    }
  });

  def('collision', {
    name: '两个碰撞球', group: 'mech', z: 4, hit: 0.7, desc: '一维碰撞，恢复系数可调',
    snapY: 0.3,
    params: [
      { k: 'm1', label: '左球质量 m₁', unit: 'kg', min: 0.2, max: 5, step: 0.1, def: 2, dec: 1 },
      { k: 'm2', label: '右球质量 m₂', unit: 'kg', min: 0.2, max: 5, step: 0.1, def: 1, dec: 1 },
      { k: 'v1', label: '左球初速 v₁', unit: 'm/s', min: -6, max: 6, step: 0.1, def: 2.2, dec: 1 },
      { k: 'v2', label: '右球初速 v₂', unit: 'm/s', min: -6, max: 6, step: 0.1, def: -1.2, dec: 1 },
      { k: 'e', label: '恢复系数 e', unit: '', min: 0, max: 1, step: 0.01, def: 0.9, dec: 2 }
    ],
    init(o) {
      o.s.x1 = -0.62; o.s.x2 = 0.62;
      o.s.v1 = o.p.v1; o.s.v2 = o.p.v2;
    },
    onParam(o) { this.init(o); },
    step(o, dt) {
      const R2 = 0.56;
      o.s.x1 += o.s.v1 * dt;
      o.s.x2 += o.s.v2 * dt;
      if (o.s.x2 - o.s.x1 < R2) {
        const m1 = o.p.m1, m2 = o.p.m2, e = o.p.e;
        const u1 = o.s.v1, u2 = o.s.v2;
        o.s.v1 = ((m1 - e * m2) * u1 + (1 + e) * m2 * u2) / (m1 + m2);
        o.s.v2 = ((m2 - e * m1) * u2 + (1 + e) * m1 * u1) / (m1 + m2);
        const over = R2 - (o.s.x2 - o.s.x1);
        o.s.x1 -= over / 2 + 1e-3;
        o.s.x2 += over / 2 + 1e-3;
      }
    },
    bounds(o) { return { x0: o.x - 1.35, x1: o.x + 1.35, y0: o.y - 0.45, y1: o.y + 0.55 }; },
    draw(o) {
      const y = o.y, R = 0.28;
      const x1 = o.x + o.s.x1, x2 = o.x + o.s.x2;
      lineW([[o.x - 1.2, y - R - 0.12], [o.x + 1.2, y - R - 0.12]], withAlpha(C.ink2, 0.45), 1.2);
      circleW(x1, y, R, withAlpha(C.ink2, 0.25), C.ink, 1.5);
      circleW(x2, y, R, withAlpha(C.accent, 0.28), C.accent, 1.5);
      txt(x1, y, 'm₁', { align: 'center', size: 11, weight: 700, color: C.ink });
      txt(x2, y, 'm₂', { align: 'center', size: 11, weight: 700, color: C.accent });
      if (S.show.vectors) {
        velArrow(x1, y + 0.42, o.s.v1 * 0.3, 0, 'v₁', C.ink2);
        velArrow(x2, y + 0.42, o.s.v2 * 0.3, 0, 'v₂', C.accent);
      }
      txt(o.x, y + 0.78, '碰撞 e=' + fmt(o.p.e, 2), { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const p = o.p.m1 * o.s.v1 + o.p.m2 * o.s.v2;
      const ek = 0.5 * o.p.m1 * o.s.v1 * o.s.v1 + 0.5 * o.p.m2 * o.s.v2 * o.s.v2;
      return [
        ['左球 v₁', fmt(o.s.v1, 2), 'm/s'],
        ['右球 v₂', fmt(o.s.v2, 2), 'm/s'],
        ['总动量 p', fmt(p, 2), 'kg·m/s'],
        ['总动能 Ek', fmt(ek, 2), 'J']
      ];
    }
  });

  def('atwood', {
    name: '连接体（滑轮）', group: 'mech', z: 3, hit: 0.8, desc: '定滑轮连接两物块，绳不可伸长',
    params: [
      { k: 'm1', label: '左物块 m₁', unit: 'kg', min: 0.2, max: 5, step: 0.1, def: 1, dec: 2 },
      { k: 'm2', label: '右物块 m₂', unit: 'kg', min: 0.2, max: 5, step: 0.1, def: 1.6, dec: 2 }
    ],
    init(o) { o.s.s = 0; o.s.v = 0; },
    onParam(o) { o.s.s = 0; o.s.v = 0; },
    step(o, dt) {
      const m1 = o.p.m1, m2 = o.p.m2;
      const a = S.g * (m2 - m1) / (m1 + m2);
      o.s.v += a * dt;
      o.s.s += o.s.v * dt;
      if (Math.abs(o.s.s) > 0.62) { o.s.s = Math.sign(o.s.s) * 0.62; o.s.v = 0; }
    },
    bounds(o) { return { x0: o.x - 0.55, x1: o.x + 0.55, y0: o.y - 1.85, y1: o.y + 0.65 }; },
    draw(o) {
      const R = 0.3, y = o.y, s = o.s.s;
      const y1 = y - 1.15 + s, y2 = y - 1.15 - s;
      circleW(o.x, y, R, withAlpha(C.ink2, 0.1), C.ink, 1.8);
      circleW(o.x, y, 0.04, C.ink, null, 0);
      // 绳：绕过滑轮上半圈后竖直垂下
      lineW([[o.x - R, y], [o.x - R, y1 + 0.16]], C.ink2, 1.4);
      lineW([[o.x + R, y], [o.x + R, y2 + 0.16]], C.ink2, 1.4);
      arcW(o.x, y, R, 0, PI, C.ink2, 1.4);
      // 支架
      lineW([[o.x, y + R], [o.x, y + 0.55]], C.ink, 2);
      lineW([[o.x - 0.34, y + 0.55], [o.x + 0.34, y + 0.55]], C.ink, 2);
      // 物块
      roundRectP(px(o.x - R) - sp(0.16), py(y1 + 0.16), sp(0.32), sp(0.32), 4,
        withAlpha(C.ink2, 0.18), C.ink, 1.3);
      roundRectP(px(o.x + R) - sp(0.16), py(y2 + 0.16), sp(0.32), sp(0.32), 4,
        withAlpha(C.accent, 0.22), C.accent, 1.3);
      txt(o.x - R, y1, 'm₁', { align: 'center', size: 10, color: C.ink });
      txt(o.x + R, y2, 'm₂', { align: 'center', size: 10, color: C.accent });
      if (S.show.vectors) {
        velArrow(o.x - R, y1 - 0.3, 0, o.s.v * 0.4, '', C.ink2);
        velArrow(o.x + R, y2 - 0.3, 0, -o.s.v * 0.4, '', C.accent);
      }
      txt(o.x, y + 0.78, '连接体 m₁=' + fmt(o.p.m1, 1) + ' m₂=' + fmt(o.p.m2, 1),
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const m1 = o.p.m1, m2 = o.p.m2;
      const a = S.g * (m2 - m1) / (m1 + m2);
      return [
        ['加速度 a', fmt(a, 2), 'm/s²'],
        ['速度 v', fmt(o.s.v, 2), 'm/s'],
        ['绳张力 T', fmt(2 * m1 * m2 * S.g / (m1 + m2), 2), 'N'],
        ['位移 s', fmt(o.s.s, 2), 'm']
      ];
    }
  });

  /* ---------- 万有引力 ---------- */
  function muUnits(b) {
    let M = 1;
    if (b && b.p && b.p.M != null) M = b.p.M;
    else if (S) {
      for (let i = 0; i < S.objects.length; i++) {
        const o = S.objects[i];
        if (o.type === 'body' && o.visible) { M = o.p.M; break; }
      }
    }
    // 地球 μ = 3.986e14 m³/s²，换算到 (10^7 m, s)
    return 3.986e14 / Math.pow(ORBIT_UNIT, 3) * M;
  }
  function centerBody(o) {
    let best = null, bd = Infinity;
    for (let i = 0; i < S.objects.length; i++) {
      const b = S.objects[i];
      if (b.type !== 'body' || !b.visible) continue;
      const d = Math.hypot(b.x - o.x, b.y - o.y);
      if (d < bd) { bd = d; best = b; }
    }
    return best;
  }

  def('body', {
    name: '中心天体', group: 'grav', z: 2, hit: 0.5, desc: '引力中心，质量以地球质量为单位',
    params: [
      { k: 'M', label: '质量 M', unit: 'M⊕', min: 0.2, max: 8, step: 0.1, def: 1, dec: 2 }
    ],
    init(o) { },
    draw(o) {
      const R = 0.42;
      circleW(o.x, o.y, R + 0.18, withAlpha(C.gold, 0.08), null, 0);
      circleW(o.x, o.y, R, withAlpha(C.ink2, 0.35), C.ink, 1.6);
      circleW(o.x, o.y, R * 0.66, null, withAlpha(C.ink, 0.25), 1);
      circleW(o.x, o.y, R * 0.33, null, withAlpha(C.ink, 0.16), 1);
      circleW(o.x - R * 0.3, o.y + R * 0.32, R * 0.16, withAlpha(C.ink2, 0.4), null, 0);
      txt(o.x, o.y - R - 0.32, '中心天体 M=' + fmt(o.p.M, 2) + ' M⊕',
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      return [['质量 M', fmt(o.p.M, 2), 'M⊕'],
      ['引力参数 GM', fmt(3.986e14 * o.p.M, 2), 'm³/s²']];
    }
  });

  def('satellite', {
    name: '卫星 / 行星', group: 'grav', z: 4, hit: 0.32, desc: '绕中心天体运行，自动圆轨道速度',
    params: [
      { k: 'v', label: '初速 v（0=圆轨道）', unit: 'km/s', min: 0, max: 7, step: 0.1, def: 0, dec: 1 }
    ],
    init(o) {
      const b = centerBody(o);
      const cx = b ? b.x : o.x - 1.6, cy = b ? b.y : o.y;
      const dx = o.x - cx, dy = o.y - cy;
      const r = Math.max(0.25, Math.hypot(dx, dy));
      const vc = Math.sqrt(muUnits(b) / r);
      const v = o.p.v > 0 ? o.p.v * 1000 / ORBIT_UNIT : vc;
      o.s.rx = 0; o.s.ry = 0;
      o.s.vx = -dy / r * v;
      o.s.vy = dx / r * v;
      o.trail = []; o._tt = 0;
    },
    onParam(o) { this.init(o); },
    step(o, dt) {
      const b = centerBody(o);
      if (!b) return;
      const x = o.x + o.s.rx - b.x, y = o.y + o.s.ry - b.y;
      const r2 = Math.max(1e-6, x * x + y * y);
      const r = Math.sqrt(r2);
      const mu = muUnits(b);
      const a = -mu / (r2 * r);
      const dte = dt * ORBIT_SCALE;
      o.s.vx += a * x * dte;
      o.s.vy += a * y * dte;
      o.s.rx += o.s.vx * dte;
      o.s.ry += o.s.vy * dte;
      if (Math.hypot(o.s.rx + o.x - b.x, o.s.ry + o.y - b.y) < 0.5) {
        // 撞上天体：停在表面，避免数值穿透
        o.s.rx = (o.x + o.s.rx - b.x) / r * 0.5 - o.x + b.x;
        o.s.ry = (o.y + o.s.ry - b.y) / r * 0.5 - o.y + b.y;
        o.s.vx = 0; o.s.vy = 0;
      }
      pushTrail(o, o.x + o.s.rx, o.y + o.s.ry, dt, 0.05);
    },
    bounds(o) { return { x0: o.x + o.s.rx - 0.28, x1: o.x + o.s.rx + 0.28, y0: o.y + o.s.ry - 0.28, y1: o.y + o.s.ry + 0.28 }; },
    draw(o) {
      const b = centerBody(o);
      const x = o.x + o.s.rx, y = o.y + o.s.ry;
      if (b) {
        const r = Math.hypot(x - b.x, y - b.y);
        circleW(b.x, b.y, r, null, withAlpha(C.ink2, 0.28), 1, [4, 6]);
        const v = Math.hypot(o.s.vx, o.s.vy);
        if (S.show.vectors && v > 1e-8) {
          arrowW(x, y, o.s.vx / v * Math.max(0.25, r * 0.3), o.s.vy / v * Math.max(0.25, r * 0.3),
            C.accent, 1.7, 8, 'v');
          arrowW(x, y, (b.x - x) / r * 0.45, (b.y - y) / r * 0.45, C.jade, 1.4, 6, '');
        }
      }
      drawTrail(o, C.ink2, 0.45);
      circleW(x, y, 0.12, withAlpha(C.accent, 0.9), C.ink, 1.2);
      // 太阳能板
      lineW([[x - 0.5, y], [x - 0.12, y]], withAlpha(C.ink, 0.6), 1.2);
      lineW([[x + 0.12, y], [x + 0.5, y]], withAlpha(C.ink, 0.6), 1.2);
      lineW([[x - 0.5, y - 0.1], [x - 0.5, y + 0.1]], withAlpha(C.ink, 0.6), 2);
      lineW([[x + 0.5, y - 0.1], [x + 0.5, y + 0.1]], withAlpha(C.ink, 0.6), 2);
      txt(x, y - 0.46, '卫星 ' + fmt(Math.hypot(o.s.vx, o.s.vy) * ORBIT_UNIT / 1000, 1) + ' km/s',
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const b = centerBody(o);
      const x = o.x + o.s.rx - (b ? b.x : 0), y = o.y + o.s.ry - (b ? b.y : 0);
      const r = Math.hypot(x, y);
      const v = Math.hypot(o.s.vx, o.s.vy);
      const vr = v * ORBIT_UNIT, vk = vr / 1000;
      const T = r > 1e-6 ? TAU * r / v : Infinity;
      return [
        ['轨道半径 r', fmt(r, 2), '×10⁷ m'],
        ['速度 v', fmt(vk, 2), 'km/s'],
        ['周期 T', isFinite(T) ? fmt(T / 3600, 2) : '—', 'h'],
        ['向心加速度', fmt(muUnits(b) / Math.max(1e-9, r * r) * ORBIT_UNIT, 2), 'm/s²'],
        ['演示时间倍率', '×' + ORBIT_SCALE, '']
      ];
    }
  });

  /* ---------- 电学 ---------- */
  function circuitInfo() {
    let bat = null;
    const rs = [], sws = [];
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      if (!o.visible) continue;
      if (o.type === 'battery' && !bat) bat = o;
      else if (o.type === 'resistor') rs.push(o);
      else if (o.type === 'switch') sws.push(o);
    }
    if (!bat) return { I: 0, closed: false, R: Infinity, U: 0 };
    let closed = true;
    for (let i = 0; i < sws.length; i++) if (!sws[i].p.closed) closed = false;
    let R = bat.p.r;
    for (let i = 0; i < rs.length; i++) R += rs[i].p.R;
    const I = (closed && rs.length) ? bat.p.U / R : 0;
    return { I: I, closed: closed, R: R, U: bat.p.U, hasRes: rs.length > 0 };
  }

  def('battery', {
    name: '电源', group: 'elec', z: 2, hit: 0.5, desc: '直流电源：电动势与内阻',
    params: [
      { k: 'U', label: '电动势 E', unit: 'V', min: 1, max: 24, step: 0.5, def: 6, dec: 1 },
      { k: 'r', label: '内阻 r', unit: 'Ω', min: 0.1, max: 5, step: 0.1, def: 0.5, dec: 1 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.55, x1: o.x + 0.55, y0: o.y - 0.32, y1: o.y + 0.32 }; },
    draw(o) {
      const x = o.x, y = o.y;
      roundRectP(px(x) - sp(0.36), py(y + 0.26), sp(0.72), sp(0.52), 6,
        withAlpha(C.ink2, 0.14), C.ink, 1.5);
      lineW([[x - 0.5, y], [x - 0.36, y]], C.ink, 2);
      lineW([[x + 0.36, y], [x + 0.5, y]], C.ink, 2);
      ctx.save();
      ctx.strokeStyle = C.ink; ctx.lineWidth = 1.6;
      // 电池符号：短横长横
      ctx.beginPath();
      ctx.moveTo(px(x - 0.12), py(y - 0.16)); ctx.lineTo(px(x - 0.12), py(y + 0.16));
      ctx.moveTo(px(x + 0.1), py(y - 0.09)); ctx.lineTo(px(x + 0.1), py(y + 0.09));
      ctx.stroke();
      ctx.restore();
      txt(x + 0.2, y - 0.18, '+', { size: 11, weight: 700, color: C.accent });
      txt(x - 0.22, y - 0.18, '−', { size: 12, weight: 700, color: C.ink2 });
      txt(x, y + 0.47, '电源 E=' + fmt(o.p.U, 1) + ' V', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const c = circuitInfo();
      return [['电动势 E', fmt(o.p.U, 2), 'V'],
      ['内阻 r', fmt(o.p.r, 2), 'Ω'],
      ['回路电流 I', fmt(c.I, 3), 'A']];
    }
  });

  def('resistor', {
    name: '电阻', group: 'elec', z: 2, hit: 0.45, desc: '定值电阻，串联回路读数',
    params: [
      { k: 'R', label: '阻值 R', unit: 'Ω', min: 1, max: 100, step: 1, def: 10, dec: 0 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.64, x1: o.x + 0.64, y0: o.y - 0.22, y1: o.y + 0.22 }; },
    draw(o) {
      const x = o.x, y = o.y;
      lineW([[x - 0.62, y], [x - 0.4, y]], C.ink2, 1.8);
      lineW([[x + 0.4, y], [x + 0.62, y]], C.ink2, 1.8);
      rectW(x - 0.4, y - 0.17, 0.8, 0.34, withAlpha(C.ink2, 0.1), C.ink, 1.5);
      // 色环
      const bands = [C.ink, C.accent, C.ink2];
      for (let i = 0; i < 3; i++) {
        lineW([[x - 0.22 + i * 0.14, y - 0.16], [x - 0.22 + i * 0.14, y + 0.16]], bands[i], 2.4);
      }
      txt(x, y + 0.43, 'R=' + fmt(o.p.R, 0) + ' Ω', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const c = circuitInfo();
      const U = c.I * o.p.R;
      return [['阻值 R', fmt(o.p.R, 0), 'Ω'],
      ['电流 I', fmt(c.I, 3), 'A'],
      ['电压 U=IR', fmt(U, 2), 'V'],
      ['功率 P', fmt(c.I * c.I * o.p.R, 2), 'W']];
    }
  });

  def('wire', {
    name: '导线', group: 'elec', z: 1, hit: 0.35, desc: '理想导线，可旋转摆放',
    params: [
      { k: 'L', label: '长度 L', unit: 'm', min: 0.4, max: 4, step: 0.1, def: 1.2, dec: 1 },
      { k: 'ang', label: '方向 φ', unit: '°', min: 0, max: 360, step: 5, def: 0, dec: 0 }
    ],
    init(o) { },
    bounds(o) {
      const a = rad(o.p.ang), L = o.p.L;
      const x2 = o.x + L * Math.cos(a), y2 = o.y + L * Math.sin(a);
      return { x0: Math.min(o.x, x2) - 0.1, x1: Math.max(o.x, x2) + 0.1, y0: Math.min(o.y, y2) - 0.1, y1: Math.max(o.y, y2) + 0.1 };
    },
    draw(o) {
      const a = rad(o.p.ang), L = o.p.L;
      const x2 = o.x + L * Math.cos(a), y2 = o.y + L * Math.sin(a);
      lineW([[o.x, o.y], [x2, y2]], C.ink, 2.2);
      circleW(o.x, o.y, 0.045, C.ink2, null, 0);
      circleW(x2, y2, 0.045, C.ink2, null, 0);
      if (circuitInfo().I > 0.001) {
        txt((o.x + x2) / 2, (o.y + y2) / 2 + 0.18, 'I=' + fmt(circuitInfo().I, 2) + ' A',
          { align: 'center', size: 9.5, color: C.accent });
      }
    },
    read(o) {
      const c = circuitInfo();
      return [['长度 L', fmt(o.p.L, 2), 'm'], ['电流 I', fmt(c.I, 3), 'A'], ['电阻', '≈0', 'Ω']];
    }
  });

  def('ammeter', {
    name: '电流表', group: 'elec', z: 3, hit: 0.42, desc: '串联电流表，指针随电流偏转',
    params: [
      { k: 'scale', label: '量程', unit: 'A', min: 0.2, max: 5, step: 0.1, def: 3, dec: 1 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.4, x1: o.x + 0.4, y0: o.y - 0.4, y1: o.y + 0.4 }; },
    draw(o) {
      const x = o.x, y = o.y, R = 0.34;
      const c = circuitInfo();
      circleW(x, y, R, withAlpha(C.ink2, 0.08), C.ink, 1.6);
      const f = clamp(c.I / Math.max(0.1, o.p.scale), 0, 1);
      const a = -PI / 2 + f * 1.25;
      arrowP(px(x), py(y), px(x) + sp(R - 0.06) * Math.cos(a), py(y) - sp(R - 0.06) * Math.sin(a),
        C.accent, 1.6, 6);
      txt(x, y - R - 0.2, 'A', { align: 'center', size: 11, weight: 700, color: C.ink2 });
      txt(x, y + R + 0.24, 'I=' + fmt(c.I, 2) + ' A', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const c = circuitInfo();
      return [['电流 I', fmt(c.I, 3), 'A'], ['量程', fmt(o.p.scale, 1), 'A'],
      ['指针位置', fmt(clamp(c.I / Math.max(0.1, o.p.scale), 0, 1) * 100, 0), '%']];
    }
  });

  def('switch', {
    name: '开关', group: 'elec', z: 2, hit: 0.38, desc: '单刀开关，闭合后回路导通',
    params: [
      { k: 'closed', label: '闭合', unit: '', kind: 'bool', def: false }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.62, x1: o.x + 0.62, y0: o.y - 0.12, y1: o.y + 0.42 }; },
    draw(o) {
      const x = o.x, y = o.y, on = o.p.closed;
      lineW([[x - 0.6, y], [x - 0.28, y]], C.ink, 2);
      lineW([[x + 0.28, y], [x + 0.6, y]], C.ink, 2);
      circleW(x - 0.28, y, 0.05, C.ink, null, 0);
      circleW(x + 0.28, y, 0.05, C.ink, null, 0);
      lineW([[x - 0.28, y], [x + (on ? 0.3 : 0.34), y + (on ? 0 : 0.34)]],
        on ? C.accent : C.ink, 2.4);
      txt(x, y + 0.55, on ? '开关 · 闭合' : '开关 · 断开', { align: 'center', size: 10.5, color: on ? C.accent : C.ink2 });
    },
    read(o) {
      const c = circuitInfo();
      return [['状态', o.p.closed ? '闭合' : '断开', ''], ['回路电流 I', fmt(c.I, 3), 'A']];
    }
  });

  def('capacitor', {
    name: '电容器', group: 'elec', z: 2, hit: 0.4, desc: '平行板电容器：Q、E、储能',
    params: [
      { k: 'C', label: '电容 C', unit: 'μF', min: 10, max: 500, step: 10, def: 100, dec: 0 },
      { k: 'U', label: '电压 U', unit: 'V', min: 2, max: 30, step: 1, def: 6, dec: 1 },
      { k: 'd', label: '板距 d', unit: 'm', min: 0.05, max: 0.4, step: 0.01, def: 0.2, dec: 2 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.88, x1: o.x + 0.88, y0: o.y - 0.38, y1: o.y + 0.38 }; },
    draw(o) {
      const x = o.x, y = o.y, d = o.p.d, h = 0.34;
      lineW([[x - 0.85, y], [x - d / 2, y]], C.ink, 2);
      lineW([[x + d / 2, y], [x + 0.85, y]], C.ink, 2);
      lineW([[x - d / 2, y - h], [x - d / 2, y + h]], C.ink, 2.6);
      lineW([[x + d / 2, y - h], [x + d / 2, y + h]], C.ink, 2.6);
      if (S.show.field) {
        for (let i = -1; i <= 1; i++) {
          arrowW(x - d / 2 + 0.02, y + i * 0.16, d - 0.04, 0, withAlpha(C.accent, 0.65), 1.1, 5, '');
        }
      }
      txt(x, y + 0.55, 'C=' + fmt(o.p.C, 0) + ' μF · U=' + fmt(o.p.U, 1) + ' V',
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const Q = o.p.C * o.p.U / 1e6 * 1e6; // μF·V → μC
      const E = o.p.U / Math.max(0.01, o.p.d);
      return [['电压 U', fmt(o.p.U, 1), 'V'],
      ['电荷量 Q=CU', fmt(Q, 1), 'μC'],
      ['场强 E=U/d', fmt(E, 1), 'V/m'],
      ['储能 W', fmt(0.5 * o.p.C * 1e-6 * o.p.U * o.p.U * 1e6, 2), 'μJ']];
    }
  });

  /* ---------- 磁场 ---------- */
  def('bfield', {
    name: '匀强磁场区', group: 'mag', z: 1, hit: 0.6, desc: '矩形区域的匀强磁场，可换方向',
    params: [
      { k: 'B', label: '磁感应强度 B', unit: 'T', min: 0, max: 2, step: 0.05, def: 0.8, dec: 2 },
      {
        k: 'dir', label: '方向', unit: '', kind: 'enum', def: 1,
        options: [{ v: 1, label: '向外' }, { v: -1, label: '向里' }]
      },
      { k: 'w', label: '宽 w', unit: 'm', min: 0.8, max: 6, step: 0.1, def: 3.2, dec: 1 },
      { k: 'h', label: '高 h', unit: 'm', min: 0.8, max: 4, step: 0.1, def: 2.6, dec: 1 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - o.p.w / 2, x1: o.x + o.p.w / 2, y0: o.y - o.p.h / 2, y1: o.y + o.p.h / 2 }; },
    draw(o) {
      const w = o.p.w, h = o.p.h, x0 = o.x - w / 2, y0 = o.y - h / 2;
      rectW(x0, y0, w, h, withAlpha(C.ink2, 0.05), withAlpha(C.ink2, 0.55), 1.3, [6, 5]);
      if (S.show.field) {
        const step = Math.max(0.35, 42 / cam.scale);
        const cols = Math.floor(w / step), rows = Math.floor(h / step);
        const ox = x0 + (w - (cols - 1) * step) / 2, oy = y0 + (h - (rows - 1) * step) / 2;
        for (let i = 0; i < cols; i++) {
          for (let j = 0; j < rows; j++) {
            const X = px(ox + i * step), Y = py(oy + j * step);
            if (o.p.dir > 0) {
              circleP(X, Y, 2, C.ink2, null, 0);
              circleP(X, Y, 4.2, null, withAlpha(C.ink2, 0.55), 1);
            } else {
              const r = 4;
              ctx.save();
              ctx.strokeStyle = withAlpha(C.ink2, 0.75); ctx.lineWidth = 1.3;
              ctx.beginPath();
              ctx.moveTo(X - r, Y - r); ctx.lineTo(X + r, Y + r);
              ctx.moveTo(X + r, Y - r); ctx.lineTo(X - r, Y + r);
              ctx.stroke();
              ctx.restore();
            }
          }
        }
      }
      tagP(px(x0) + 2, py(y0 + h) - 11,
        'B=' + fmt(o.p.B, 2) + ' T · ' + (o.p.dir > 0 ? '垂直纸面向外' : '垂直纸面向里'), C.ink2);
    },
    read(o) {
      return [['磁感应强度 B', fmt(o.p.B, 2), 'T'],
      ['方向', o.p.dir > 0 ? '垂直纸面向外' : '垂直纸面向里', ''],
      ['区域', fmt(o.p.w, 1) + ' × ' + fmt(o.p.h, 1), 'm']];
    }
  });

  def('magnet', {
    name: '磁体', group: 'mag', z: 2, hit: 0.5, desc: '条形磁体，N/S 极与磁感线',
    params: [
      { k: 'B', label: '磁感应强度 B', unit: 'T', min: 0.05, max: 1, step: 0.05, def: 0.4, dec: 2 },
      { k: 'L', label: '长度 L', unit: 'm', min: 0.6, max: 2.4, step: 0.1, def: 1.2, dec: 1 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - o.p.L / 2 - 0.12, x1: o.x + o.p.L / 2 + 0.12, y0: o.y - 0.3, y1: o.y + 0.3 }; },
    draw(o) {
      const L = o.p.L, h = 0.34, x0 = o.x - L / 2;
      rectW(x0, o.y - h / 2, L / 2, h, withAlpha(C.ink2, 0.28), C.ink, 1.2);
      rectW(o.x, o.y - h / 2, L / 2, h, withAlpha(C.accent, 0.3), C.accent, 1.2);
      txt(x0 + L * 0.25, o.y, 'S', { align: 'center', size: 12, weight: 700, color: C.ink });
      txt(x0 + L * 0.75, o.y, 'N', { align: 'center', size: 12, weight: 700, color: C.accent });
      if (S.show.field) {
        const N = [x0 + L * 0.95, o.y], Sp = [x0 + L * 0.05, o.y];
        for (let k = 1; k <= 4; k++) {
          const lift = 0.34 + k * 0.3;
          const bend = L * 0.5 + k * 0.22;
          ctx.save();
          ctx.strokeStyle = withAlpha(C.ink2, 0.45 - k * 0.06);
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(px(N[0]), py(o.y + h / 2));
          ctx.bezierCurveTo(px(N[0] + bend * 0.5), py(o.y + h / 2 + lift),
            px(Sp[0] - bend * 0.5), py(o.y + h / 2 + lift), px(Sp[0]), py(o.y + h / 2));
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(px(N[0]), py(o.y - h / 2));
          ctx.bezierCurveTo(px(N[0] + bend * 0.5), py(o.y - h / 2 - lift),
            px(Sp[0] - bend * 0.5), py(o.y - h / 2 - lift), px(Sp[0]), py(o.y - h / 2));
          ctx.stroke();
          ctx.restore();
        }
        arrowW(o.x + L * 0.34, o.y + h / 2 + 0.62, -0.42, 0, withAlpha(C.ink2, 0.7), 1.2, 5, '');
        arrowW(o.x + L * 0.34, o.y - h / 2 - 0.62, -0.42, 0, withAlpha(C.ink2, 0.7), 1.2, 5, '');
      }
      txt(o.x, o.y + 0.75, '磁体 B=' + fmt(o.p.B, 2) + ' T', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      return [['磁场 B', fmt(o.p.B, 2), 'T'], ['极距', fmt(o.p.L, 2), 'm'],
      ['磁极', 'N → S（外部）', '']];
    }
  });

  function bAt(x, y) {
    let Bz = 0;
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      if (!o.visible || o.type !== 'bfield') continue;
      if (Math.abs(x - o.x) <= o.p.w / 2 && Math.abs(y - o.y) <= o.p.h / 2) {
        Bz += o.p.B * o.p.dir;
      }
    }
    return Bz;
  }
  function eAt(x, y) {
    let Ex = 0, Ey = 0, phi = 0;
    const k = 8.99e9;
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      if (!o.visible) continue;
      if (o.type === 'pointcharge') {
        let dx = x - o.x, dy = y - o.y;
        let r2 = dx * dx + dy * dy;
        if (r2 < 0.004) { r2 = 0.004; }
        const r = Math.sqrt(r2);
        const E = k * o.p.Q * 1e-9 / r2;
        Ex += E * dx / r; Ey += E * dy / r;
        phi += k * o.p.Q * 1e-9 / r;
      } else if (o.type === 'plates') {
        const len = o.p.len, d = o.p.d;
        if (Math.abs(x - o.x) <= len / 2 && Math.abs(y - o.y) <= d / 2) {
          const E = o.p.U / d;
          Ey += -E * o.p.pol;
          phi += -E * (y - o.y) * o.p.pol;
        }
      }
    }
    return { Ex: Ex, Ey: Ey, phi: phi };
  }

  def('particle', {
    name: '带电粒子', group: 'mag', z: 5, hit: 0.3, desc: '受电场力与洛伦兹力，轨迹可留影',
    params: [
      { k: 'q', label: '电荷量 q', unit: 'μC', min: -3, max: 3, step: 0.1, def: 1, dec: 1 },
      { k: 'm', label: '质量 m', unit: 'mg', min: 0.2, max: 5, step: 0.1, def: 1, dec: 1 },
      { k: 'v0', label: '初速 v₀', unit: 'm/s', min: 0, max: 5, step: 0.1, def: 1.2, dec: 1 },
      { k: 'th', label: '入射角 θ', unit: '°', min: -180, max: 180, step: 5, def: 0, dec: 0 }
    ],
    init(o) {
      const a = rad(o.p.th);
      o.s.rx = 0; o.s.ry = 0;
      o.s.vx = o.p.v0 * Math.cos(a);
      o.s.vy = o.p.v0 * Math.sin(a);
      o.trail = []; o._tt = 0;
    },
    onParam(o) { this.init(o); },
    step(o, dt) {
      if (Math.abs(o.p.q) < 1e-6) { o.s.rx += o.s.vx * dt; o.s.ry += o.s.vy * dt; return; }
      const x = o.x + o.s.rx, y = o.y + o.s.ry;
      const E = eAt(x, y);
      const Bz = bAt(x, y);
      const ratio = o.p.q / o.p.m; // (μC / mg) = C/kg 的等价比
      const ax = ratio * (E.Ex + o.s.vy * Bz);
      const ay = ratio * (E.Ey - o.s.vx * Bz);
      o.s.vx += ax * dt; o.s.vy += ay * dt;
      o.s.rx += o.s.vx * dt; o.s.ry += o.s.vy * dt;
      pushTrail(o, o.x + o.s.rx, o.y + o.s.ry, dt, 0.02);
    },
    bounds(o) { return { x0: o.x + o.s.rx - 0.3, x1: o.x + o.s.rx + 0.3, y0: o.y + o.s.ry - 0.3, y1: o.y + o.s.ry + 0.3 }; },
    draw(o) {
      const x = o.x + o.s.rx, y = o.y + o.s.ry;
      drawTrail(o, C.accent, 0.55);
      const pos = o.p.q >= 0;
      circleW(x, y, 0.14, withAlpha(pos ? C.accent : C.ink2, 0.85), C.ink, 1.2);
      lineW([[x - 0.075, y], [x + 0.075, y]], S.bg, 1.4);
      if (pos) lineW([[x, y - 0.075], [x, y + 0.075]], S.bg, 1.4);
      if (S.show.vectors) {
        const v = Math.hypot(o.s.vx, o.s.vy);
        if (v > 1e-6) velArrow(x, y, o.s.vx / v * Math.min(0.9, v * 0.4), o.s.vy / v * Math.min(0.9, v * 0.4), 'v');
        const E = eAt(x, y), Bz = bAt(x, y);
        const fx = o.p.q * (E.Ex + o.s.vy * Bz);
        const fy = o.p.q * (E.Ey - o.s.vx * Bz);
        const fm = Math.hypot(fx, fy);
        if (fm > 1e-9) arrowW(x, y, fx / fm * 0.5, fy / fm * 0.5, C.jade, 1.5, 7, '');
      }
      let lx = x + 0.28, ly = y - 0.44, align = 'left';
      for (let i = 0; i < S.objects.length; i++) {
        const pl = S.objects[i];
        if (!pl.visible || pl.type !== 'plates') continue;
        if (Math.abs(x - pl.x) <= pl.p.len / 2 && Math.abs(y - pl.y) <= pl.p.d / 2) {
          lx = x; ly = pl.y - pl.p.d / 2 - 0.34; align = 'center';
          break;
        }
      }
      txt(lx, ly, '带电粒子 q=' + fmt(o.p.q, 1) + ' μC', { align: align, size: 10.5, color: C.ink2 });
    },
    read(o) {
      const x = o.x + o.s.rx, y = o.y + o.s.ry;
      const E = eAt(x, y), Bz = bAt(x, y);
      const v = Math.hypot(o.s.vx, o.s.vy);
      const ratio = o.p.q / o.p.m;
      const ax = ratio * (E.Ex + o.s.vy * Bz);
      const ay = ratio * (E.Ey - o.s.vx * Bz);
      const rows = [
        ['速度 v', fmt(v, 2), 'm/s'],
        ['加速度 a', fmt(Math.hypot(ax, ay), 2), 'm/s²'],
        ['电场 E', fmt(Math.hypot(E.Ex, E.Ey), 1), 'V/m'],
        ['磁感强度 B', fmt(Bz, 2), 'T']
      ];
      if (Math.abs(Bz) > 1e-6 && Math.abs(o.p.q) > 1e-6) {
        const R = Math.abs(o.p.m / o.p.q) * v / Math.abs(Bz);
        const T = TAU * Math.abs(o.p.m / o.p.q) / Math.abs(Bz);
        rows.push(['回旋半径 R', fmt(R, 2), 'm']);
        rows.push(['回旋周期 T', fmt(T, 2), 's']);
      }
      if (Math.abs(E.phi) > 1e-6) rows.push(['电势能 Ep', fmt(o.p.q * E.phi, 2), 'μJ']);
      return rows;
    }
  });

  /* ---------- 电场 ---------- */
  def('pointcharge', {
    name: '点电荷', group: 'efield', z: 1, hit: 0.4, desc: '点电荷：电场线与等势线',
    params: [
      { k: 'Q', label: '电荷量 Q', unit: 'nC', min: -10, max: 10, step: 0.5, def: 2, dec: 1 }
    ],
    init(o) { },
    draw(o) {
      const pos = o.p.Q >= 0;
      if (S.show.field) {
        const Rmax = 2.4;
        for (let i = 0; i < 18; i++) {
          const a = i / 18 * TAU;
          const x1 = o.x + Math.cos(a) * 0.2, y1 = o.y + Math.sin(a) * 0.2;
          const x2 = o.x + Math.cos(a) * Rmax, y2 = o.y + Math.sin(a) * Rmax;
          lineW([[x1, y1], [x2, y2]], withAlpha(C.ink2, 0.17), 1);
          if (i % 2 === 0) {
            const r = pos ? 1.1 : 0.5;
            const hx = o.x + Math.cos(a) * r, hy = o.y + Math.sin(a) * r;
            const dir = pos ? 1 : -1;
            arrowW(hx, hy, Math.cos(a) * 0.18 * dir, Math.sin(a) * 0.18 * dir,
              withAlpha(C.ink2, 0.7), 1.1, 5, '');
          }
        }
        for (let k = 1; k <= 3; k++) {
          circleW(o.x, o.y, 0.45 * k, null, withAlpha(C.jade, 0.28), 1, [3, 5]);
        }
        txt(o.x + 1.55, o.y + 0.12, '等势线', { size: 9.5, color: withAlpha(C.jade, 0.85) });
      }
      circleW(o.x, o.y, 0.17, withAlpha(pos ? C.accent : C.ink2, 0.9), C.ink, 1.3);
      txt(o.x, o.y, pos ? '+' : '−', { align: 'center', size: 13, weight: 700, color: S.bg, halo: false });
      txt(o.x, o.y + 0.42, '点电荷 Q=' + (o.p.Q >= 0 ? '+' : '') + fmt(o.p.Q, 1) + ' nC',
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      return [['电荷量 Q', fmt(o.p.Q, 1), 'nC'],
      ['1 m 处场强', fmt(8.99 * Math.abs(o.p.Q), 1), 'V/m'],
      ['符号', o.p.Q >= 0 ? '正电荷' : '负电荷', '']];
    }
  });

  def('plates', {
    name: '平行板电容器', group: 'efield', z: 1, hit: 0.55, desc: '板间匀强电场，可调电压与板距',
    params: [
      { k: 'U', label: '电压 U', unit: 'V', min: 0, max: 40, step: 1, def: 10, dec: 1 },
      { k: 'd', label: '板距 d', unit: 'm', min: 0.2, max: 1.2, step: 0.05, def: 0.5, dec: 2 },
      { k: 'len', label: '板长 L', unit: 'm', min: 0.4, max: 2.4, step: 0.1, def: 1.2, dec: 1 },
      {
        k: 'pol', label: '上板极性', unit: '', kind: 'enum', def: 1,
        options: [{ v: 1, label: '上正下负' }, { v: -1, label: '上负下正' }]
      }
    ],
    init(o) { },
    bounds(o) {
      return { x0: o.x - o.p.len / 2, x1: o.x + o.p.len / 2, y0: o.y - o.p.d / 2 - 0.2, y1: o.y + o.p.d / 2 + 0.2 };
    },
    draw(o) {
      const d = o.p.d, len = o.p.len;
      const xL = o.x - len / 2, xR = o.x + len / 2;
      const yT = o.y + d / 2, yB = o.y - d / 2;
      lineW([[xL, yT], [xR, yT]], C.ink, 2.6);
      lineW([[xL, yB], [xR, yB]], C.ink, 2.6);
      txt(xL - 0.16, yT, o.p.pol > 0 ? '+' : '−', { align: 'right', size: 13, weight: 700, color: o.p.pol > 0 ? C.accent : C.ink2 });
      txt(xL - 0.16, yB, o.p.pol > 0 ? '−' : '+', { align: 'right', size: 13, weight: 700, color: o.p.pol > 0 ? C.ink2 : C.accent });
      if (S.show.field && o.p.U > 0) {
        const n = 4;
        for (let i = 0; i < n; i++) {
          const X = xL + len * (i + 0.5) / n;
          if (o.p.pol > 0) arrowW(X, yT - 0.02, 0, -d + 0.04, withAlpha(C.ink2, 0.55), 1.1, 5, '');
          else arrowW(X, yB + 0.02, 0, d - 0.04, withAlpha(C.ink2, 0.55), 1.1, 5, '');
        }
      }
      txt(o.x, yT + 0.28, '平行板 U=' + fmt(o.p.U, 1) + ' V · E=' + fmt(o.p.U / Math.max(0.01, d), 1) + ' V/m',
        { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const E = o.p.U / Math.max(0.01, o.p.d);
      return [['电压 U', fmt(o.p.U, 1), 'V'], ['板距 d', fmt(o.p.d, 2), 'm'],
      ['场强 E=U/d', fmt(E, 1), 'V/m'],
      ['方向', o.p.pol > 0 ? '上板 → 下板' : '下板 → 上板', '']];
    }
  });

  /* ---------- 光学 ---------- */
  function findLight() {
    for (let i = 0; i < S.objects.length; i++) {
      if (S.objects[i].type === 'lightsrc' && S.objects[i].visible) return S.objects[i];
    }
    return null;
  }
  function findLens() {
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      if (o.visible && (o.type === 'convex' || o.type === 'concave')) return o;
    }
    return null;
  }
  function findScreen() {
    for (let i = 0; i < S.objects.length; i++) {
      if (S.objects[i].type === 'screen' && S.objects[i].visible) return S.objects[i];
    }
    return null;
  }
  function findMirror() {
    for (let i = 0; i < S.objects.length; i++) {
      if (S.objects[i].type === 'mirror' && S.objects[i].visible) return S.objects[i];
    }
    return null;
  }
  function objHeight(src) { return src.p.h == null ? 0.5 : src.p.h; }
  function tipOf(src) { return [src.x, src.y + objHeight(src)]; }
  function rayToEdge(x, y, dx, dy, color, dash) {
    const L = Math.hypot(dx, dy);
    if (L < 1e-9) return;
    dx /= L; dy /= L;
    let t = 1e9;
    const hw = halfW(), hh = halfH();
    if (Math.abs(dx) > 1e-9) {
      const t1 = (cam.x + hw - x) / dx, t2 = (cam.x - hw - x) / dx;
      if (t1 > 0) t = Math.min(t, t1);
      if (t2 > 0) t = Math.min(t, t2);
    }
    if (Math.abs(dy) > 1e-9) {
      const t1 = (cam.y + hh - y) / dy, t2 = (cam.y - hh - y) / dy;
      if (t1 > 0) t = Math.min(t, t1);
      if (t2 > 0) t = Math.min(t, t2);
    }
    if (!isFinite(t) || t > 1e6) t = hw * 2;
    lineW([[x, y], [x + dx * t, y + dy * t]], color, 1.3, dash);
  }
  function opticsInfo() {
    const src = findLight(), lens = findLens();
    if (!src || !lens) return null;
    const f = lens.type === 'convex' ? lens.p.f : -Math.abs(lens.p.f);
    const u = lens.x - src.x;
    if (u <= 0.02) return null;
    const v = 1 / (1 / f - 1 / u);
    const m = -v / u;
    const tip = tipOf(src);
    return {
      src: src, lens: lens, f: f, u: u, v: v, m: m,
      tip: tip,
      H: 0.92,
      img: { x: lens.x + v, y: lens.y + m * objHeight(src) }
    };
  }

  def('lightsrc', {
    name: '光源', group: 'optics', z: 3, hit: 0.4, desc: '点光源 + 物高箭头，供透镜/平面镜成像',
    params: [
      { k: 'h', label: '物高 h', unit: 'm', min: 0.1, max: 0.9, step: 0.05, def: 0.5, dec: 2 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.25, x1: o.x + 0.25, y0: o.y - 0.1, y1: o.y + objHeight(o) + 0.25 }; },
    draw(o) {
      const h = objHeight(o), x = o.x, y = o.y;
      circleW(x, y, 0.08, withAlpha(C.accent, 0.9), C.ink, 1.2);
      lineW([[x, y], [x, y + h]], C.accent, 2);
      arrowP(px(x), py(y + h) + 7, px(x), py(y + h), C.accent, 2, 8);
      for (let i = 0; i < 8; i++) {
        const a = i / 8 * TAU;
        lineW([[x + Math.cos(a) * 0.14, y + Math.sin(a) * 0.14],
        [x + Math.cos(a) * 0.22, y + Math.sin(a) * 0.22]], withAlpha(C.accent, 0.55), 1);
      }
      txt(x, y - 0.28, '光源', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      return [['物高 h', fmt(objHeight(o), 2), 'm'], ['位置 x', fmt(o.x, 2), 'm']];
    }
  });

  function drawLensBody(o, convex) {
    const H = 0.92, X = px(o.x), Yt = py(o.y + H), Yb = py(o.y - H);
    const bulge = sp(convex ? 0.17 : 0.13);
    ctx.save();
    ctx.beginPath();
    if (convex) {
      ctx.moveTo(X, Yt);
      ctx.quadraticCurveTo(X + bulge * 1.7, py(o.y), X, Yb);
      ctx.quadraticCurveTo(X - bulge * 1.7, py(o.y), X, Yt);
    } else {
      ctx.moveTo(X - bulge, Yt);
      ctx.lineTo(X + bulge, Yt);
      ctx.quadraticCurveTo(X - bulge * 0.3, py(o.y), X + bulge, Yb);
      ctx.lineTo(X - bulge, Yb);
      ctx.quadraticCurveTo(X + bulge * 0.3, py(o.y), X - bulge, Yt);
    }
    ctx.closePath();
    ctx.fillStyle = withAlpha(C.ink2, 0.12);
    ctx.fill();
    ctx.strokeStyle = C.ink2; ctx.lineWidth = 1.4; ctx.stroke();
    ctx.restore();
    // 光轴与焦点
    lineW([[o.x - 2.6, o.y], [o.x + 2.6, o.y]], withAlpha(C.ink2, 0.35), 1, [4, 5]);
    const f = convex ? o.p.f : -Math.abs(o.p.f);
    [-1, 1].forEach(function (s) {
      const fx = o.x + s * Math.abs(f);
      lineW([[fx, o.y - 0.1], [fx, o.y + 0.1]], withAlpha(C.accent, 0.9), 1.6);
      txt(fx, o.y - 0.24, s > 0 ? "F′" : 'F', { align: 'center', size: 9.5, color: C.accent });
    });
    circleW(o.x, o.y, 0.035, C.ink2, null, 0);
  }

  def('convex', {
    name: '凸透镜', group: 'optics', z: 2, hit: 0.5, desc: '凸透镜成像，三条特殊光线',
    params: [
      { k: 'f', label: '焦距 f', unit: 'm', min: 0.3, max: 3, step: 0.05, def: 0.9, dec: 2 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.3, x1: o.x + 0.3, y0: o.y - 1.05, y1: o.y + 1.05 }; },
    draw(o) {
      if (S.show.rays) drawLensRays(o);
      drawLensBody(o, true);
      txt(o.x, o.y + 1.22, '凸透镜 f=' + fmt(o.p.f, 2) + ' m', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const info = opticsInfo();
      if (!info) return [['焦距 f', fmt(o.p.f, 2), 'm'], ['需要', '光源 + 凸透镜', '']];
      return [['焦距 f', fmt(o.p.f, 2), 'm'], ['物距 u', fmt(info.u, 2), 'm'],
      ['像距 v', fmt(info.v, 2), 'm'], ['放大率 m', fmt(info.m, 2), ''],
      ['像', info.v > 0 ? '实像（倒立）' : '虚像（正立）', '']];
    }
  });

  def('concave', {
    name: '凹透镜', group: 'optics', z: 2, hit: 0.5, desc: '凹透镜，成正立缩小虚像',
    params: [
      { k: 'f', label: '焦距 |f|', unit: 'm', min: 0.3, max: 3, step: 0.05, def: 0.8, dec: 2 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.3, x1: o.x + 0.3, y0: o.y - 1.05, y1: o.y + 1.05 }; },
    draw(o) {
      if (S.show.rays) drawLensRays(o);
      drawLensBody(o, false);
      txt(o.x, o.y + 1.22, '凹透镜 |f|=' + fmt(o.p.f, 2) + ' m', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const info = opticsInfo();
      if (!info) return [['焦距 |f|', fmt(o.p.f, 2), 'm'], ['需要', '光源 + 凹透镜', '']];
      return [['焦距 |f|', fmt(o.p.f, 2), 'm'], ['物距 u', fmt(info.u, 2), 'm'],
      ['像距 v', fmt(info.v, 2), 'm'], ['放大率 m', fmt(info.m, 2), ''],
      ['像', '虚像（正立缩小）', '']];
    }
  });

  function drawLensRays(lens) {
    const info = opticsInfo();
    if (!info || info.lens !== lens) return;
    const lx = lens.x, ly = lens.y, H = info.H;
    const tip = info.tip, I = info.img;
    const rays = [];
    // ① 平行于主光轴
    if (Math.abs(tip[1] - ly) < H * 1.1) {
      let dx = I.x - lx, dy = I.y - (tip[1]);
      if (info.v < 0) { dx = -dx; dy = -dy; }
      rays.push({ from: tip, at: [lx, tip[1]], dir: [dx, dy] });
    }
    // ② 过光心
    {
      const dx = lx - tip[0], dy = ly - tip[1];
      rays.push({ from: tip, at: [lx, ly], dir: [dx, dy] });
    }
    // ③ 过焦点
    {
      const fx = lx - info.f;
      if (Math.abs(fx - tip[0]) > 1e-3) {
        const t = (lx - tip[0]) / (fx - tip[0]);
        const yl = tip[1] + t * (ly - tip[1]);
        if (Math.abs(yl - ly) < H * 1.15) {
          rays.push({ from: tip, at: [lx, yl], dir: [1, 0] });
        }
      }
    }
    for (let i = 0; i < rays.length; i++) {
      const r = rays[i];
      const col = i === 0 ? C.accent : i === 1 ? C.ink2 : C.jade;
      lineW([r.from, r.at], withAlpha(col, 0.9), 1.3);
      if (Math.hypot(r.dir[0], r.dir[1]) > 1e-9) {
        rayToEdge(r.at[0], r.at[1], r.dir[0], r.dir[1], withAlpha(col, 0.62), null);
      }
    }
    // 像
    if (isFinite(I.x) && isFinite(I.y)) {
      const real = info.v > 0;
      lineW([[I.x, ly], [I.x, I.y]], withAlpha(real ? C.accent : C.ink2, 0.9), 1.6, real ? null : [4, 4]);
      circleP(px(I.x), py(I.y), 2.6, real ? C.accent : C.ink2, null, 0);
      txt(I.x, I.y + (I.y > ly ? 0.26 : -0.26), (real ? '实像' : '虚像'),
        { align: 'center', size: 9.5, color: real ? C.accent : C.ink2 });
      const scr = findScreen();
      if (scr && real && Math.abs(scr.x - I.x) < 0.12) {
        circleP(px(scr.x), py(I.y), 5, withAlpha(C.accent, 0.35), null, 0);
        circleP(px(scr.x), py(I.y), 2.4, C.accent, null, 0);
        txt(scr.x, I.y + 0.3, '屏上成像', { align: 'center', size: 9.5, color: C.accent });
      }
    }
  }

  def('mirror', {
    name: '平面镜', group: 'optics', z: 2, hit: 0.55, desc: '平面镜反射，等距等大虚像',
    params: [
      { k: 'L', label: '镜长 L', unit: 'm', min: 0.8, max: 3, step: 0.1, def: 2, dec: 1 },
      { k: 'ang', label: '倾角 φ', unit: '°', min: 0, max: 180, step: 5, def: 0, dec: 0 }
    ],
    init(o) { },
    bounds(o) {
      const a = rad(o.p.ang), L = o.p.L;
      const ex = Math.abs(Math.sin(a)) * L / 2, ey = Math.abs(Math.cos(a)) * L / 2;
      return { x0: o.x - ex - 0.28, x1: o.x + ex + 0.28, y0: o.y - ey - 0.2, y1: o.y + ey + 0.2 };
    },
    draw(o) {
      const a = rad(o.p.ang), L = o.p.L;
      const u = [Math.sin(a), Math.cos(a)];
      const n = [Math.cos(a), -Math.sin(a)];
      const p1 = [o.x - u[0] * L / 2, o.y - u[1] * L / 2];
      const p2 = [o.x + u[0] * L / 2, o.y + u[1] * L / 2];
      // 背面斜线
      for (let i = 1; i < 10; i++) {
        const f = i / 10;
        const px0 = p1[0] + (p2[0] - p1[0]) * f, py0 = p1[1] + (p2[1] - p1[1]) * f;
        lineW([[px0, py0], [px0 - n[0] * 0.16, py0 - n[1] * 0.16]], withAlpha(C.ink2, 0.45), 1);
      }
      lineW([p1, p2], C.ink, 2.2);
      const src = findLight();
      if (S.show.rays && src) {
        const tip = tipOf(src);
        const rel = [tip[0] - o.x, tip[1] - o.y];
        const d = rel[0] * n[0] + rel[1] * n[1];
        const virt = [tip[0] - 2 * d * n[0], tip[1] - 2 * d * n[1]];
        [-0.26, 0.16].forEach(function (f) {
          const hp = [o.x + u[0] * L * f, o.y + u[1] * L * f];
          lineW([tip, hp], withAlpha(C.ink2, 0.55), 1.1);
          const vx = hp[0] - tip[0], vy = hp[1] - tip[1];
          const dd = vx * n[0] + vy * n[1];
          rayToEdge(hp[0], hp[1], vx - 2 * dd * n[0], vy - 2 * dd * n[1], withAlpha(C.accent, 0.55), null);
          lineW([virt, hp], withAlpha(C.ink2, 0.2), 1, [3, 5]);
        });
        const baseY = src.y, topY = src.y + objHeight(src);
        arrowP(px(virt[0]), py(baseY), px(virt[0]), py(topY), withAlpha(C.ink2, 0.8), 1.4, 7);
        txt(virt[0], topY + 0.24, '虚像', { align: 'center', size: 9.5, color: C.ink2 });
      }
      txt(o.x, o.y + L / 2 + 0.3, '平面镜 L=' + fmt(o.p.L, 1) + ' m', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const src = findLight();
      if (!src) return [['镜长 L', fmt(o.p.L, 2), 'm'], ['像', '需要光源', '']];
      const a = rad(o.p.ang);
      const n = [Math.cos(a), -Math.sin(a)];
      const tip = tipOf(src);
      const d = (tip[0] - o.x) * n[0] + (tip[1] - o.y) * n[1];
      return [['物距 u', fmt(Math.abs(d), 2), 'm'], ['像距 v', fmt(Math.abs(d), 2), 'm'],
      ['像高', fmt(objHeight(src), 2), 'm'], ['放大率', '1.00', '']];
    }
  });

  def('screen', {
    name: '光屏', group: 'optics', z: 1, hit: 0.4, desc: '承接实像的光屏',
    params: [
      { k: 'L', label: '屏高 L', unit: 'm', min: 0.4, max: 2, step: 0.1, def: 1.2, dec: 1 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.2, x1: o.x + 0.2, y0: o.y - o.p.L / 2, y1: o.y + o.p.L / 2 }; },
    draw(o) {
      const L = o.p.L;
      lineW([[o.x, o.y - L / 2], [o.x, o.y + L / 2]], C.ink, 2.2);
      for (let i = 0; i < 12; i++) {
        const f = i / 11;
        const yy = o.y - L / 2 + L * f;
        lineW([[o.x, yy], [o.x - 0.1, yy + 0.06]], withAlpha(C.ink2, 0.5), 1);
      }
      txt(o.x - 0.12, o.y + L / 2 + 0.22, '光屏', { align: 'right', size: 10.5, color: C.ink2 });
    },
    read(o) {
      const info = opticsInfo();
      if (!info) return [['屏高 L', fmt(o.p.L, 2), 'm'], ['像距', '—', '']];
      return [['屏高 L', fmt(o.p.L, 2), 'm'],
      ['与透镜距离', fmt(Math.abs(o.x - info.lens.x), 2), 'm'],
      ['是否成像', info.v > 0 && Math.abs(o.x - info.img.x) < 0.12 ? '是' : '否', '']];
    }
  });

  def('glass', {
    name: '玻璃砖', group: 'optics', z: 2, hit: 0.5, desc: '矩形玻璃砖，斯涅尔定律折射',
    params: [
      { k: 'n', label: '折射率 n', unit: '', min: 1.05, max: 2, step: 0.01, def: 1.5, dec: 2 },
      { k: 'w', label: '宽 w', unit: 'm', min: 0.4, max: 1.6, step: 0.05, def: 1, dec: 2 },
      { k: 'h', label: '高 h', unit: 'm', min: 0.6, max: 2.4, step: 0.1, def: 1.6, dec: 1 },
      { k: 'th', label: '入射角 θ₁', unit: '°', min: 0, max: 70, step: 1, def: 40, dec: 0 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - o.p.w / 2 - 0.05, x1: o.x + o.p.w / 2 + 0.05, y0: o.y - o.p.h / 2 - 0.05, y1: o.y + o.p.h / 2 + 0.05 }; },
    draw(o) {
      const w = o.p.w, h = o.p.h, n = o.p.n, th1 = rad(o.p.th);
      const x0 = o.x - w / 2, x1 = o.x + w / 2, y0 = o.y - h / 2, y1 = o.y + h / 2;
      rectW(x0, y0, w, h, withAlpha(C.ink2, 0.08), withAlpha(C.ink2, 0.7), 1.4);
      txt(o.x, o.y - h / 2 - 0.22, '玻璃砖 n=' + fmt(n, 2), { align: 'center', size: 10.5, color: C.ink2 });
      if (!S.show.rays) return;
      const yIn = o.y + 0.18;
      const d = [Math.cos(th1), -Math.sin(th1)];
      const P0 = [x0, yIn];
      const st = [P0[0] - d[0] * 1.4, P0[1] - d[1] * 1.4];
      lineW([st, P0], withAlpha(C.ink, 0.7), 1.2);
      // 法线
      lineW([[x0 - 0.5, yIn], [x0 + 0.5, yIn]], withAlpha(C.ink2, 0.35), 1, [3, 4]);
      const sin2 = Math.sin(th1) / n;
      const th2 = Math.asin(clamp(sin2, -1, 1));
      const d2 = [Math.cos(th2), -Math.sin(th2)];
      const tIn = w / Math.max(0.05, d2[0]);
      const P1 = [P0[0] + d2[0] * tIn, P0[1] + d2[1] * tIn];
      lineW([P0, P1], withAlpha(C.accent, 0.85), 1.3);
      lineW([[x1 - 0.5, P1[1]], [x1 + 0.5, P1[1]]], withAlpha(C.ink2, 0.35), 1, [3, 4]);
      const d3 = [Math.cos(th1), -Math.sin(th1)];
      rayToEdge(P1[0], P1[1], d3[0], d3[1], withAlpha(C.accent, 0.6), [5, 4]);
      txt(st[0] + 0.1, st[1] + 0.2, '入射 θ₁=' + fmt(o.p.th, 0) + '°', { size: 9.5, color: C.ink2 });
      txt(P0[0] + 0.16, P0[1] - 0.24, '折射 θ₂=' + fmt(deg(th2), 1) + '°', { size: 9.5, color: C.accent });
    },
    read(o) {
      const th1 = rad(o.p.th);
      const th2 = Math.asin(clamp(Math.sin(th1) / o.p.n, -1, 1));
      const shift = o.p.h / Math.cos(th2) * Math.sin(th1 - th2);
      return [['折射率 n', fmt(o.p.n, 2), ''],
      ['入射角 θ₁', fmt(o.p.th, 0), '°'],
      ['折射角 θ₂', fmt(deg(th2), 1), '°'],
      ['侧移 Δ', fmt(Math.abs(shift), 2), 'm']];
    }
  });

  /* ---------- 波 ---------- */
  def('wavesrc', {
    name: '波源', group: 'wave', z: 3, hit: 0.35, desc: '上下振动产生横波，给绳/弦供波',
    params: [
      { k: 'f', label: '频率 f', unit: 'Hz', min: 0.2, max: 3, step: 0.1, def: 1.2, dec: 1 },
      { k: 'A', label: '振幅 A', unit: 'm', min: 0.05, max: 0.5, step: 0.01, def: 0.3, dec: 2 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.32, x1: o.x + 0.32, y0: o.y - 0.6, y1: o.y + 0.55 }; },
    draw(o) {
      const yv = o.y + o.p.A * Math.sin(TAU * o.p.f * S.t);
      lineW([[o.x, o.y - 0.44], [o.x, yv]], C.ink2, 1.6);
      circleW(o.x, yv, 0.09, withAlpha(C.accent, 0.9), C.ink, 1.2);
      lineW([[o.x, o.y - 0.44], [o.x, o.y - 0.54]], C.ink2, 2);
      lineW([[o.x - 0.28, o.y - 0.54], [o.x + 0.28, o.y - 0.54]], C.ink, 2.2);
      if (S.show.vectors) {
        arrowW(o.x + 0.2, yv, 0, -o.p.A, withAlpha(C.accent, 0.85), 1.2, 6, 'A');
      }
      txt(o.x, o.y + 0.56, '波源 f=' + fmt(o.p.f, 1) + ' Hz', { align: 'center', size: 10.5, color: C.ink2 });
    },
    read(o) {
      return [['频率 f', fmt(o.p.f, 2), 'Hz'], ['周期 T', fmt(1 / o.p.f, 2), 's'],
      ['振幅 A', fmt(o.p.A, 2), 'm']];
    }
  });

  def('string', {
    name: '绳 / 弦', group: 'wave', z: 2, hit: 0.4, desc: '横波沿绳传播，显示波前',
    params: [
      { k: 'L', label: '绳长 L', unit: 'm', min: 1, max: 8, step: 0.1, def: 5, dec: 1 },
      { k: 'lam', label: '波长 λ', unit: 'm', min: 0.3, max: 2.4, step: 0.05, def: 1.1, dec: 2 }
    ],
    init(o) { },
    bounds(o) { return { x0: o.x - 0.15, x1: o.x + o.p.L + 0.15, y0: o.y - 0.52, y1: o.y + 0.52 }; },
    draw(o) {
      const L = o.p.L, lam = o.p.lam;
      let src = null, bd = Infinity;
      for (let i = 0; i < S.objects.length; i++) {
        const s = S.objects[i];
        if (s.type !== 'wavesrc' || !s.visible) continue;
        const d = Math.hypot(s.x - o.x, s.y - o.y);
        if (d < bd) { bd = d; src = s; }
      }
      const useSrc = src && bd < 1.6;
      const f = useSrc ? src.p.f : 1.2;
      const A = useSrc ? src.p.A : 0.2;
      const v = lam * f;
      const front = Math.min(L, v * S.t);
      const pts = [];
      if (useSrc && front > 0.01) {
        const n = Math.max(40, Math.round(front / lam * 90));
        for (let i = 0; i <= n; i++) {
          const s = front * i / n;
          pts.push([o.x + s, o.y + A * Math.sin(TAU * (f * S.t - s / lam))]);
        }
      } else {
        pts.push([o.x, o.y], [o.x + L, o.y]);
      }
      lineW([[o.x, o.y], [o.x + L, o.y]], withAlpha(C.ink2, 0.28), 1, [3, 5]);
      lineW(pts, C.ink2, 1.8);
      // 端点
      circleW(o.x, o.y, 0.05, C.ink2, null, 0);
      circleW(o.x + L, o.y, 0.05, C.ink2, null, 0);
      if (useSrc && front > 0.02 && front < L) {
        lineW([[o.x + front, o.y - 0.5], [o.x + front, o.y + 0.5]],
          withAlpha(C.accent, 0.75), 1.3, [4, 4]);
        txt(o.x + front + 0.08, o.y + 0.58, '波前', { align: 'left', size: 9.5, color: C.accent });
        arrowW(o.x + front - 0.05, o.y + 0.3, 0.4, 0, withAlpha(C.ink2, 0.55), 1.2, 6, '');
      }
      if (useSrc) {
        txt(o.x + 0.08, o.y + 0.86, '绳波 λ=' + fmt(lam, 2) + ' m · v=λf=' + fmt(v, 2) + ' m/s',
          { align: 'left', size: 10.5, color: C.ink2 });
      } else {
        txt(o.x + L / 2, o.y + 0.55, '需要波源（放在绳左端）', { align: 'center', size: 10.5, color: C.faint });
      }
    },
    read(o) {
      let src = null;
      for (let i = 0; i < S.objects.length; i++) {
        const s = S.objects[i];
        if (s.type === 'wavesrc' && s.visible) { src = s; break; }
      }
      const f = src ? src.p.f : 1.2;
      const v = o.p.lam * f;
      return [['波长 λ', fmt(o.p.lam, 2), 'm'], ['频率 f', fmt(f, 2), 'Hz'],
      ['波速 v=λf', fmt(v, 2), 'm/s'],
      ['波前位置', fmt(Math.min(o.p.L, v * S.t), 2), 'm']];
    }
  });

  /* ================= 三、场景、仿真与预设 ================= */
  function defaultShow() {
    return {
      grid: true, scale: true, vectors: true, trail: true,
      field: true, rays: true, ground: false
    };
  }
  function newScene() {
    return {
      objects: [], sel: null, t: 0, playing: false, speed: 1, g: 9.8,
      show: defaultShow(), preset: 'projectile', theme: 'day',
      bg: '#F7F2EB', ready: false, active: true, seeking: false,
      stage: null, left: null, right: null, shell: null, bar: null
    };
  }

  function spawn(type, x, y) {
    const T = TYPES[type];
    if (!T) return null;
    const o = {
      id: 'ob' + (++seq), type: type, x: x, y: y,
      p: {}, s: {}, visible: true, trail: [], _tt: 0
    };
    T.params.forEach(function (d) { o.p[d.k] = d.def; });
    if (arguments[3]) {
      const pr = arguments[3];
      Object.keys(pr).forEach(function (k) { if (o.p[k] !== undefined) o.p[k] = pr[k]; });
    }
    try { if (T.init) T.init(o); } catch (e) { noteError(e); }
    S.objects.push(o);
    return o;
  }

  function addObject(type, at) {
    const T = TYPES[type];
    if (!T) return null;
    let x = cam.x, y = cam.y;
    if (at) { x = at.x; y = at.y; }
    else if (T.snapY != null) { x = cam.x; y = T.snapY; }
    if (S.objects.some(function (o) { return Math.abs(o.x - x) < 0.18 && Math.abs(o.y - y) < 0.18; })) {
      x += 0.7;
    }
    const o = spawn(type, x, y);
    if (!o) return null;
    if (type === 'satellite' && !centerBody(o)) {
      spawn('body', x - 1.7, y);
      try { TYPES.satellite.init(o); } catch (e) { noteError(e); }
    }
    S.sel = o;
    S.preset = '';
    refreshAll();
    render();
    if (S.shell) S.shell.toast('已添加 ' + T.name);
    return o;
  }

  function removeObject(o) {
    const i = S.objects.indexOf(o);
    if (i < 0) return;
    S.objects.splice(i, 1);
    if (S.sel === o) S.sel = null;
    S.preset = '';
    refreshAll();
    render();
    if (S.shell) S.shell.toast('已删除 ' + TYPES[o.type].name);
  }

  function duplicateObject(o) {
    if (!o) return;
    const n = spawn(o.type, o.x + 0.6, o.y + 0.15);
    if (!n) return;
    Object.keys(o.p).forEach(function (k) { n.p[k] = o.p[k]; });
    try { TYPES[n.type].init(n); } catch (e) { noteError(e); }
    S.sel = n; S.preset = '';
    refreshAll(); render();
    if (S.shell) S.shell.toast('已复制 ' + TYPES[n.type].name);
  }

  function clearScene() {
    S.objects = [];
    S.sel = null;
    S.t = 0;
    S.playing = false;
    S.preset = '';
  }

  function setParam(o, k, v) {
    const T = TYPES[o.type];
    if (!T) return;
    const d = T.params.filter(function (x) { return x.k === k; })[0];
    if (!d) return;
    if (d.kind === 'num' || (!d.kind && d.min != null)) {
      v = parseFloat(v);
      if (!isFinite(v)) return;
      v = clamp(v, d.min, d.max);
    }
    o.p[k] = v;
    o.trail = []; o._tt = 0;
    try {
      if (T.onParam) T.onParam.call(T, o, k, v);
      else if (T.init) T.init(o);
    } catch (e) { noteError(e); }
    S.preset = '';
  }

  function simStep(dt) {
    S.dt = dt;
    S.t += dt;
    S.circ = circuitInfo();
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      if (!o.visible) continue;
      const T = TYPES[o.type];
      if (T && T.step) {
        try { T.step(o, dt); } catch (e) { noteError(e); }
      }
    }
  }
  function tick(dt) {
    if (!S || !S.playing) return;
    let remain = dt * S.speed, guard = 0;
    while (remain > 1e-9 && guard++ < 900) {
      const h = Math.min(DT, remain);
      simStep(h);
      remain -= h;
    }
  }
  function resetScene() {
    S.t = 0;
    S.playing = false;
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      o.trail = []; o._tt = 0;
      try { if (TYPES[o.type].init) TYPES[o.type].init(o); } catch (e) { noteError(e); }
    }
    S.circ = circuitInfo();
  }
  function seekTo(target) {
    target = clamp(target, 0, 20);
    S.t = 0;
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      o.trail = []; o._tt = 0;
      try { if (TYPES[o.type].init) TYPES[o.type].init(o); } catch (e) { noteError(e); }
    }
    let guard = 0;
    while (S.t < target - 1e-9 && guard++ < 9000) simStep(Math.min(DT, target - S.t));
    S.circ = circuitInfo();
  }
  function stepOnce() {
    if (!S) return;
    S.playing = false;
    for (let i = 0; i < 12; i++) simStep(DT);
    refreshDynamicUI();
    render();
  }
  function setPlaying(v) {
    if (!S) return;
    S.playing = !!v;
    refreshDynamicUI();
  }
  function togglePlay() { setPlaying(!S.playing); }

  /* ---------- 预设 ---------- */
  const PRESETS = [
    {
      id: 'freefall', name: '自由落体', select: 'projectile',
      cam: { x: 0, y: 3.4, scale: 66 }, show: { ground: true },
      build() { spawn('projectile', -0.6, 7.4, { v0: 0, th: 90, m: 1 }); }
    },
    {
      id: 'incline', name: '斜面下滑', select: 'incline',
      cam: { x: 0.4, y: 1.05, scale: 92 }, show: { ground: true },
      build() { spawn('incline', -1.9, 0, { th: 32, mu: 0.15, m: 1, L: 3.4, v0: 0 }); }
    },
    {
      id: 'projectile', name: '平抛运动', select: 'projectile',
      cam: { x: -1.3, y: 2.6, scale: 104 }, show: { ground: true },
      build() { spawn('projectile', -3.4, 3.0, { v0: 7, th: 0, m: 1 }); }
    },
    {
      id: 'pendulum', name: '单摆', select: 'pendulum',
      cam: { x: 0, y: 1.35, scale: 120 }, show: { ground: false },
      build() { spawn('pendulum', 0, 2.9, { L: 1.45, th0: 40, m: 0.5, damp: 0.01 }); }
    },
    {
      id: 'circular', name: '圆周运动', select: 'circular',
      cam: { x: 0, y: 1.5, scale: 115 }, show: { ground: false },
      build() { spawn('circular', 0, 1.5, { R: 1.15, v: 2.2, m: 0.5 }); }
    },
    {
      id: 'collision', name: '两球碰撞', select: 'collision',
      cam: { x: 0, y: 0.95, scale: 112 }, show: { ground: true },
      build() { spawn('collision', -1.4, 0.3, { m1: 2, m2: 1, v1: 2.2, v2: -1.2, e: 0.9 }); }
    },
    {
      id: 'bfield', name: '磁场回旋', select: 'particle',
      cam: { x: 0.1, y: 1.9, scale: 96 }, show: { ground: false },
      build() {
        spawn('bfield', 0.15, 1.9, { B: 0.8, dir: -1, w: 3.4, h: 2.8 });
        spawn('particle', -2.45, 1.05, { q: 1, m: 1, v0: 1.2, th: 0 });
      }
    },
    {
      id: 'plates', name: '平行板偏转', select: 'particle',
      cam: { x: 0, y: 1.95, scale: 150 }, show: { ground: false },
      build() {
        spawn('plates', 0.2, 1.8, { U: 10, d: 0.6, len: 1.6, pol: 1 });
        spawn('particle', -2.1, 2.05, { q: 0.12, m: 1, v0: 2.4, th: 0 });
      }
    },
    {
      id: 'lens', name: '凸透镜成像', select: 'convex',
      cam: { x: 0.2, y: 1.55, scale: 104 }, show: { ground: false, vectors: false },
      build() {
        spawn('lightsrc', -1.6, 1.45, { h: 0.55 });
        spawn('convex', 0.2, 1.45, { f: 0.9 });
        spawn('screen', 2.0, 1.45, { L: 1.4 });
      }
    },
    {
      id: 'mirror', name: '平面镜反射', select: 'mirror',
      cam: { x: 0.2, y: 1.5, scale: 108 }, show: { ground: false, vectors: false },
      build() {
        spawn('mirror', 0.2, 1.5, { L: 2.2, ang: 0 });
        spawn('lightsrc', -1.4, 1.05, { h: 0.55 });
      }
    },
    {
      id: 'wave', name: '绳波传播', select: 'string',
      cam: { x: 0, y: 1.35, scale: 92 }, show: { ground: false, vectors: false },
      build() {
        spawn('wavesrc', -2.6, 1.16, { f: 1.2, A: 0.3 });
        spawn('string', -2.6, 1.16, { L: 5.2, lam: 1.1 });
      }
    },
    {
      id: 'orbit', name: '卫星圆轨道', select: 'satellite',
      cam: { x: 0, y: 1.8, scale: 118 }, show: { ground: false, field: false },
      build() {
        spawn('body', 0, 1.8, { M: 1 });
        spawn('satellite', 1.75, 1.8, { v: 0 });
      }
    }
  ];

  function pickSel(P) {
    if (P) {
      if (P.select) {
        for (let i = 0; i < S.objects.length; i++) if (S.objects[i].type === P.select) return S.objects[i];
      }
      return S.objects[0] || null;
    }
    for (let i = S.objects.length - 1; i >= 0; i--) {
      if (TYPES[S.objects[i].type].step) return S.objects[i];
    }
    return S.objects[0] || null;
  }

  function loadPreset(id, opts) {
    opts = opts || {};
    const P = PRESETS.filter(function (p) { return p.id === id; })[0];
    if (!P) return false;
    S.objects = []; S.sel = null; S.t = 0; S.playing = false;
    S.g = P.g || 9.8;
    S.show = Object.assign(defaultShow(), P.show || {});
    cam = { x: P.cam.x, y: P.cam.y, scale: P.cam.scale };
    try { P.build(); } catch (e) { noteError(e); }
    S.preset = id;
    S.sel = pickSel(P);
    S.circ = circuitInfo();
    if (opts.advance) {
      let guard = 0, target = opts.advance;
      while (S.t < target - 1e-9 && guard++ < 5000) simStep(Math.min(DT, target - S.t));
    }
    S.playing = !!opts.autoplay;
    if (S.ready) { refreshAll(); render(); }
    return true;
  }

  /* ---------- 场景序列化（自检临时用） ---------- */
  function serializeScene() {
    return {
      cam: { x: cam.x, y: cam.y, scale: cam.scale },
      g: S.g,
      show: Object.assign({}, S.show),
      t: S.t,
      selId: S.sel ? S.sel.id : null,
      preset: S.preset,
      objs: S.objects.map(function (o) {
        return { type: o.type, x: o.x, y: o.y, p: Object.assign({}, o.p), visible: o.visible };
      })
    };
  }
  function restoreScene(snap) {
    if (!snap) return;
    S.objects = []; S.sel = null; S.t = 0; S.playing = false;
    S.g = snap.g;
    S.show = Object.assign(defaultShow(), snap.show);
    cam = { x: snap.cam.x, y: snap.cam.y, scale: snap.cam.scale };
    snap.objs.forEach(function (o) {
      const n = spawn(o.type, o.x, o.y, o.p);
      if (n) n.visible = o.visible;
    });
    S.preset = snap.preset || '';
    let guard = 0, target = snap.t || 0;
    while (S.t < target - 1e-9 && guard++ < 5000) simStep(Math.min(DT, target - S.t));
    S.sel = pickSel(null);
    S.circ = circuitInfo();
    if (S.ready) { refreshAll(); render(); }
  }

  /* ================= 四、画布绘制 ================= */
  function niceStep(target) {
    const mag = Math.pow(10, Math.floor(Math.log(target) / Math.LN10));
    const n = target / mag;
    return (n < 1.5 ? 1 : n < 3.5 ? 2 : n < 7.5 ? 5 : 10) * mag;
  }
  function drawGrid() {
    const step = niceStep(68 / cam.scale);
    const x0 = Math.floor((cam.x - halfW()) / step) * step;
    const x1 = cam.x + halfW();
    const y0 = Math.floor((cam.y - halfH()) / step) * step;
    const y1 = cam.y + halfH();
    ctx.save();
    ctx.strokeStyle = C.grid; ctx.lineWidth = 1; ctx.beginPath();
    for (let x = x0; x <= x1 + 1e-9; x += step) {
      const X = Math.round(px(x)) + 0.5;
      ctx.moveTo(X, 0); ctx.lineTo(X, cv.h);
    }
    for (let y = y0; y <= y1 + 1e-9; y += step) {
      const Y = Math.round(py(y)) + 0.5;
      ctx.moveTo(0, Y); ctx.lineTo(cv.w, Y);
    }
    ctx.stroke();
    ctx.restore();
    const ax = Math.abs(cam.x) < halfW() ? px(0) : null;
    const ay = Math.abs(cam.y) < halfH() ? py(0) : null;
    ctx.save();
    ctx.strokeStyle = withAlpha(C.ink2, 0.3); ctx.lineWidth = 1;
    if (ax != null) { ctx.beginPath(); ctx.moveTo(ax, 0); ctx.lineTo(ax, cv.h); ctx.stroke(); }
    if (ay != null) { ctx.beginPath(); ctx.moveTo(0, ay); ctx.lineTo(cv.w, ay); ctx.stroke(); }
    ctx.restore();
    const lab = step * Math.max(1, Math.round(150 / (step * cam.scale)));
    ctx.save();
    ctx.font = '9.5px ' + C.sans; ctx.fillStyle = C.faint;
    if (ay != null) {
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      const ly = clamp(ay + 4, 4, cv.h - 14);
      for (let x = Math.ceil((cam.x - halfW()) / lab) * lab; x <= cam.x + halfW(); x += lab) {
        if (Math.abs(x) < 1e-9) continue;
        const X = px(x);
        if (X < 18 || X > cv.w - 18) continue;
        ctx.fillText(fmt(x, 1), X, ly);
      }
    }
    if (ax != null) {
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      const lx = clamp(ax - 5, 22, cv.w - 4);
      for (let y = Math.ceil((cam.y - halfH()) / lab) * lab; y <= cam.y + halfH(); y += lab) {
        if (Math.abs(y) < 1e-9) continue;
        const Y = py(y);
        if (Y < 13 || Y > cv.h - 13) continue;
        ctx.fillText(fmt(y, 1), lx, Y);
      }
    }
    ctx.restore();
  }
  function drawGround() {
    if (Math.abs(cam.y) > halfH() + 0.3) return;
    const step = niceStep(68 / cam.scale);
    lineW([[cam.x - halfW(), 0], [cam.x + halfW(), 0]], withAlpha(C.ink, 0.42), 1.4);
    for (let x = Math.ceil((cam.x - halfW()) / step) * step; x <= cam.x + halfW(); x += step) {
      lineW([[x, 0], [x - 0.1, -0.1]], withAlpha(C.ink2, 0.4), 1);
    }
    txt(cam.x + halfW() - 0.15, -0.24, '地面', { align: 'right', size: 9.5, color: C.faint });
  }
  function drawScaleBar() {
    const step = niceStep(92 / cam.scale);
    const W = step * cam.scale;
    const X0 = 16, Y = cv.h - 22;
    ctx.save();
    ctx.strokeStyle = withAlpha(C.ink, 0.55); ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(X0, Y); ctx.lineTo(X0 + W, Y);
    ctx.moveTo(X0, Y - 4); ctx.lineTo(X0, Y + 4);
    ctx.moveTo(X0 + W, Y - 4); ctx.lineTo(X0 + W, Y + 4);
    ctx.stroke();
    ctx.restore();
    txtP(X0 + W + 7, Y, step + ' m', { size: 10, color: C.faint });
  }
  function drawEmptyHint() {
    const W = Math.min(470, cv.w * 0.68), H = 96;
    const X = (cv.w - W) / 2, Y = (cv.h - H) / 2;
    roundRectP(X, Y, W, H, 16, withAlpha(S.bg, 0.92), withAlpha(C.ink2, 0.18), 1);
    txtP(cv.w / 2, cv.h / 2 - 15, '空场景', { align: 'center', size: 21, weight: 700, color: C.ink2 });
    txtP(cv.w / 2, cv.h / 2 + 20, '从左侧物体库点选或拖入物体，也可以在右栏载入预设',
      { align: 'center', size: 11.5, color: C.faint });
  }
  function drawSelection(o) {
    const T = TYPES[o.type];
    const col = withAlpha(C.accent, 0.85);
    if (T.selRing) {
      // 圆周这类“环形”物体：用虚线圆框住，避免大方框喧宾夺主
      let R = 12;
      try { R = Math.max(12, sp(T.selRing(o))); } catch (e) { }
      ctx.save();
      ctx.setLineDash([4, 5]);
      ctx.strokeStyle = col; ctx.lineWidth = 1.15;
      ctx.beginPath(); ctx.arc(px(o.x), py(o.y), R, 0, TAU); ctx.stroke();
      ctx.restore();
      return;
    }
    let b;
    try { b = T.bounds ? T.bounds(o) : { x0: o.x - 0.5, x1: o.x + 0.5, y0: o.y - 0.5, y1: o.y + 0.5 }; }
    catch (e) { b = { x0: o.x - 0.5, x1: o.x + 0.5, y0: o.y - 0.5, y1: o.y + 0.5 }; }
    const X0 = px(b.x0) - 6, X1 = px(b.x1) + 6, Y0 = py(b.y1) - 6, Y1 = py(b.y0) + 6;
    roundRectP(X0, Y0, Math.max(10, X1 - X0), Math.max(10, Y1 - Y0), 10,
      null, withAlpha(C.accent, 0.5), 1.1, [4, 5]);
  }
  function render() {
    if (!S || !cv || !ctx) return;
    ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
    ctx.clearRect(0, 0, cv.w, cv.h);
    if (S.show.grid) drawGrid();
    if (S.show.ground) drawGround();
    const list = S.objects.filter(function (o) { return o.visible; });
    list.sort(function (a, b) { return (TYPES[a.type].z || 2) - (TYPES[b.type].z || 2); });
    for (let i = 0; i < list.length; i++) {
      try { TYPES[list[i].type].draw(list[i]); } catch (e) { noteError(e); }
    }
    if (S.sel && S.sel.visible) drawSelection(S.sel);
    if (!S.objects.length) drawEmptyHint();
    if (S.show.scale) drawScaleBar();
  }

  /* ================= 五、界面 ================= */
  function refreshObjectList() {
    const box = S.objList;
    if (!box) return;
    box.innerHTML = '';
    const head = el('div', { class: 'lab-sec-h' });
    head.innerHTML = '场景对象<i></i><em class="lp-count">' + S.objects.length + '</em>';
    box.appendChild(head);
    if (!S.objects.length) {
      box.appendChild(el('div', { class: 'lp-empty' }, '场景还是空的'));
      return;
    }
    S.objects.forEach(function (o) {
      const T = TYPES[o.type];
      const row = el('div', { class: 'lp-obj' + (S.sel === o ? ' on' : '') + (o.visible ? '' : ' off') });
      const name = el('button', { class: 'lp-objname', type: 'button', title: T.desc || T.name }, T.name);
      name.addEventListener('click', function () { selectObject(o); });
      const eye = el('button', { class: 'lp-eye', type: 'button', title: o.visible ? '隐藏' : '显示' });
      eye.innerHTML = o.visible
        ? '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1.5 8s2.5-4.2 6.5-4.2S14.5 8 14.5 8 12 12.2 8 12.2 1.5 8 1.5 8z"/><circle cx="8" cy="8" r="1.7"/></svg>'
        : '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1.5 8s2.5-4.2 6.5-4.2S14.5 8 14.5 8 12 12.2 8 12.2 1.5 8 1.5 8z"/><line x1="2.4" y1="13.6" x2="13.6" y2="2.4"/></svg>';
      eye.addEventListener('click', function (ev) {
        ev.stopPropagation();
        o.visible = !o.visible;
        render();
        refreshObjectList();
      });
      row.appendChild(name);
      row.appendChild(eye);
      box.appendChild(row);
    });
  }

  function selectObject(o) {
    S.sel = o;
    refreshObjectList();
    refreshInspector();
    render();
  }

  function paramRow(o, d) {
    const row = el('div', { class: 'lp-param' });
    const top = el('div', { class: 'lp-param-top' });
    top.appendChild(el('span', { class: 'lp-pl' }, d.label));
    const val = el('span', { class: 'lp-pv' });
    top.appendChild(val);
    row.appendChild(top);
    if (d.kind === 'bool') {
      val.textContent = o.p[d.k] ? '开' : '关';
      const b = el('button', { class: 'lab-btn lp-toggle' + (o.p[d.k] ? ' on' : ''), type: 'button' },
        o.p[d.k] ? '已闭合' : '已断开');
      b.addEventListener('click', function () {
        setParam(o, d.k, !o.p[d.k]);
        b.classList.toggle('on', !!o.p[d.k]);
        b.textContent = o.p[d.k] ? '已闭合' : '已断开';
        val.textContent = o.p[d.k] ? '开' : '关';
        updateReadouts();
        render();
      });
      row.appendChild(b);
      return row;
    }
    if (d.kind === 'enum') {
      const seg = el('div', { class: 'lp-seg' });
      d.options.forEach(function (op) {
        const b = el('button', { class: 'lab-btn' + (o.p[d.k] === op.v ? ' on' : ''), type: 'button' }, op.label);
        b.addEventListener('click', function () {
          setParam(o, d.k, op.v);
          seg.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
          b.classList.add('on');
          val.textContent = op.label;
          updateReadouts();
          render();
        });
        seg.appendChild(b);
      });
      row.appendChild(seg);
      const cur = d.options.filter(function (op) { return op.v === o.p[d.k]; })[0];
      val.textContent = cur ? cur.label : '';
      return row;
    }
    const dec = d.dec == null ? 2 : d.dec;
    function show(v) { val.textContent = fmt(v, dec) + (d.unit ? ' ' + d.unit : ''); }
    show(o.p[d.k]);
    const line = el('div', { class: 'lp-param-line' });
    const range = el('input', {
      class: 'lp-range', type: 'range', min: d.min, max: d.max,
      step: d.step, value: o.p[d.k], 'aria-label': d.label
    });
    const numIn = el('input', {
      class: 'lp-num', type: 'number', min: d.min, max: d.max,
      step: d.step, value: o.p[d.k], 'aria-label': d.label
    });
    function apply(v) {
      setParam(o, d.k, v);
      const nv = o.p[d.k];
      show(nv);
      range.value = nv;
      numIn.value = nv;
      updateReadouts();
      render();
    }
    range.addEventListener('input', function () { apply(parseFloat(range.value)); });
    numIn.addEventListener('change', function () { apply(parseFloat(numIn.value)); });
    line.appendChild(range);
    line.appendChild(numIn);
    row.appendChild(line);
    return row;
  }

  function refreshInspector() {
    const box = S.insp;
    if (!box) return;
    box.innerHTML = '';
    const o = S.sel;
    S.readBox = null;
    if (!o) {
      const h = el('div', { class: 'lab-sec-h' });
      h.innerHTML = '属性检查器<i></i>';
      box.appendChild(h);
      box.appendChild(el('div', { class: 'lab-empty' }, '点选画布上的物体<br>即可调整参数与读实时读数'));
      return;
    }
    const T = TYPES[o.type];
    const head = el('div', { class: 'lp-objhead' });
    head.innerHTML = '<span class="lp-oname">' + T.name + '</span><span class="lp-oid">' +
      (o.visible ? '属性检查器' : '已隐藏') + '</span>';
    box.appendChild(head);
    const form = el('div', { class: 'lp-form' });
    T.params.forEach(function (d) { form.appendChild(paramRow(o, d)); });
    box.appendChild(form);
    const acts = el('div', { class: 'lp-acts' });
    const bCopy = el('button', { class: 'lab-btn', type: 'button' }, '复制');
    bCopy.addEventListener('click', function () { duplicateObject(o); });
    const bDel = el('button', { class: 'lab-btn', type: 'button' }, '删除');
    bDel.addEventListener('click', function () { removeObject(o); });
    acts.appendChild(bCopy);
    acts.appendChild(bDel);
    box.appendChild(acts);
    const rh = el('div', { class: 'lab-sec-h' });
    rh.innerHTML = '实时读数<i></i>';
    box.appendChild(rh);
    const rd = el('div', { class: 'lp-reads' });
    box.appendChild(rd);
    S.readBox = rd;
    updateReadouts();
  }

  function updateReadouts() {
    if (!S || !S.readBox || !S.sel) return;
    const T = TYPES[S.sel.type];
    let rows = [];
    try { rows = T.read ? T.read(S.sel) : []; } catch (e) { noteError(e); rows = []; }
    if (!rows.length) { S.readBox.innerHTML = '<div class="lab-hint">该对象暂无实时读数</div>'; return; }
    let html = '';
    for (let i = 0; i < rows.length; i++) {
      html += '<div class="lp-kv"><span>' + rows[i][0] + '</span><b>' + rows[i][1] +
        '</b><i>' + (rows[i][2] || '') + '</i></div>';
    }
    S.readBox.innerHTML = html;
  }

  function refreshSettings() {
    if (!S || !S.togRefs) return;
    Object.keys(S.togRefs).forEach(function (k) {
      S.togRefs[k].classList.toggle('on', !!S.show[k]);
    });
    if (S.gRange) { S.gRange.value = S.g; S.gVal.textContent = fmt(S.g, 1) + ' m/s²'; }
  }

  function buildLeft() {
    const L = S.left;
    if (!L) return;
    L.innerHTML = '';
    const lib = el('div', { class: 'lp-lib' });
    const h = el('div', { class: 'lab-sec-h' });
    h.innerHTML = '物体库<i></i>';
    lib.appendChild(h);
    GROUPS.forEach(function (g) {
      const box = el('div', { class: 'lp-group' });
      box.appendChild(el('div', { class: 'lp-gname' }, g.name));
      const grid = el('div', { class: 'lp-cat' });
      typesOfGroup(g.key).forEach(function (tk) {
        const T = TYPES[tk];
        const b = el('button', { class: 'lp-catbtn', type: 'button', title: T.desc || T.name }, T.name);
        b.addEventListener('pointerdown', function (ev) { startCatalogDrag(ev, tk); });
        // 键盘 / 程序化点击同样可放置（指针拖放后会由 catGuard 去重）
        b.addEventListener('click', function () {
          if (S.catGuard && Date.now() - S.catGuard < 400) return;
          addObject(tk);
        });
        grid.appendChild(b);
      });
      box.appendChild(grid);
      lib.appendChild(box);
    });
    L.appendChild(lib);
    S.objList = el('div', { class: 'lp-objs' });
    L.appendChild(S.objList);
    refreshObjectList();
  }

  function startCatalogDrag(ev, type) {
    if (ev.button != null && ev.button !== 0) return;
    // 触摸/触控笔保留列表滚动：点一下即可落到画布中央，不进入拖放
    if (ev.pointerType && ev.pointerType !== 'mouse') return;
    ev.preventDefault();
    const sx0 = ev.clientX, sy0 = ev.clientY;
    let moved = false, ghost = null;
    function move(e2) {
      if (!moved && Math.hypot(e2.clientX - sx0, e2.clientY - sy0) > 8) {
        moved = true;
        ghost = el('div', { class: 'lp-ghost' }, TYPES[type].name);
        document.body.appendChild(ghost);
      }
      if (ghost) {
        ghost.style.left = (e2.clientX + 14) + 'px';
        ghost.style.top = (e2.clientY + 14) + 'px';
      }
    }
    function up(e2) {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      document.removeEventListener('pointercancel', up);
      if (ghost) ghost.remove();
      const r = S.stage.getBoundingClientRect();
      const inside = e2.clientX >= r.left && e2.clientX <= r.right && e2.clientY >= r.top && e2.clientY <= r.bottom;
      if (moved && inside) {
        addObject(type, { x: wx(e2.clientX - r.left), y: wy(e2.clientY - r.top) });
        S.catGuard = Date.now();
      } else if (!moved) {
        addObject(type);
        S.catGuard = Date.now();
      }
    }
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
    document.addEventListener('pointercancel', up);
  }

  function buildRight() {
    const R = S.right;
    if (!R) return;
    R.innerHTML = '';
    // 预设
    const psec = el('div', { class: 'lab-sec' });
    const ph = el('div', { class: 'lab-sec-h' });
    ph.innerHTML = '预设场景<i></i>';
    psec.appendChild(ph);
    const pgrid = el('div', { class: 'lp-presets' });
    PRESETS.forEach(function (p) {
      const b = el('button', { class: 'lab-btn lp-preset', type: 'button', title: '载入「' + p.name + '」' }, p.name);
      b.addEventListener('click', function () {
        loadPreset(p.id, { autoplay: true });
        if (S.shell) S.shell.toast('已载入：' + p.name);
      });
      pgrid.appendChild(b);
    });
    psec.appendChild(pgrid);
    R.appendChild(psec);
    // 检查器
    S.insp = el('div', { class: 'lp-insp' });
    R.appendChild(S.insp);
    // 设置
    const sec = el('div', { class: 'lab-sec' });
    const h = el('div', { class: 'lab-sec-h' });
    h.innerHTML = '场景设置<i></i>';
    sec.appendChild(h);
    const grow = el('div', { class: 'lp-grow' });
    grow.appendChild(el('span', { class: 'lp-pl' }, '重力 g'));
    S.gVal = el('b', { class: 'lp-val' }, fmt(S.g, 1) + ' m/s²');
    grow.appendChild(S.gVal);
    sec.appendChild(grow);
    S.gRange = el('input', { class: 'lp-range', type: 'range', min: 0, max: 20, step: 0.1, value: S.g });
    S.gRange.addEventListener('input', function () {
      S.g = parseFloat(S.gRange.value);
      S.gVal.textContent = fmt(S.g, 1) + ' m/s²';
    });
    sec.appendChild(S.gRange);
    const togs = el('div', { class: 'lp-togs' });
    S.togRefs = {};
    [['grid', '网格'], ['vectors', '矢量'], ['trail', '轨迹'],
    ['field', '场线'], ['rays', '光路'], ['scale', '比例尺'], ['ground', '地面']].forEach(function (it) {
      const b = el('button', { class: 'lab-btn' + (S.show[it[0]] ? ' on' : ''), type: 'button' }, it[1]);
      b.addEventListener('click', function () {
        S.show[it[0]] = !S.show[it[0]];
        b.classList.toggle('on', !!S.show[it[0]]);
        render();
      });
      S.togRefs[it[0]] = b;
      togs.appendChild(b);
    });
    sec.appendChild(togs);
    const acts = el('div', { class: 'lp-acts' });
    const bExp = el('button', { class: 'lab-btn', type: 'button' }, '导出 PNG');
    bExp.addEventListener('click', function () {
      const url = doExport(true);
      if (url && S.shell) S.shell.toast('已导出 PNG');
    });
    const bClr = el('button', { class: 'lab-btn', type: 'button' }, '清空场景');
    bClr.addEventListener('click', function () {
      clearScene();
      refreshAll();
      render();
      if (S.shell) S.shell.toast('场景已清空');
    });
    acts.appendChild(bExp);
    acts.appendChild(bClr);
    sec.appendChild(acts);
    R.appendChild(sec);
    refreshInspector();
    refreshSettings();
  }

  function refreshAll() {
    refreshObjectList();
    refreshInspector();
    refreshSettings();
    refreshDynamicUI();
  }

  function refreshDynamicUI() {
    if (!S) return;
    if (S.playBtn) {
      S.playBtn.textContent = S.playing ? '暂停' : '播放';
      S.playBtn.classList.toggle('on', !!S.playing);
    }
    if (S.tLabel) S.tLabel.textContent = 't = ' + fmt(S.t, 2) + ' s';
    if (S.timeRange && !S.seeking) S.timeRange.value = Math.min(20, S.t);
    if (S.speedBtn) S.speedBtn.textContent = S.speed + '×';
    if (S.shell) S.shell.setTitle('物理 · ' + S.objects.length + ' 个对象 · t=' + fmt(S.t, 1) + 's');
    updateReadouts();
  }

  function buildTimeline() {
    if (S.bar && S.bar.parentNode) { S.bar.style.display = ''; return; }
    const bar = S.shell.float('bl');
    bar.classList.add('lp-timeline');
    S.bar = bar;
    S.tLabel = el('span', { class: 'lp-t' }, 't = 0.00 s');
    bar.appendChild(S.tLabel);
    S.playBtn = el('button', { class: 'lp-tbtn', type: 'button', title: '播放 / 暂停（空格）' }, '播放');
    S.playBtn.addEventListener('click', togglePlay);
    bar.appendChild(S.playBtn);
    const bStep = el('button', { class: 'lp-tbtn', type: 'button', title: '单步（→）' }, '单步');
    bStep.addEventListener('click', stepOnce);
    bar.appendChild(bStep);
    const bReset = el('button', { class: 'lp-tbtn', type: 'button', title: '复位到 t=0' }, '复位');
    bReset.addEventListener('click', function () {
      resetScene();
      refreshAll();
      render();
    });
    bar.appendChild(bReset);
    S.speedBtn = el('button', { class: 'lp-tbtn', type: 'button', title: '播放倍速' }, S.speed + '×');
    S.speedBtn.addEventListener('click', function () {
      const list = [0.25, 0.5, 1, 2, 4];
      const i = list.indexOf(S.speed);
      S.speed = list[(i + 1) % list.length];
      refreshDynamicUI();
    });
    bar.appendChild(S.speedBtn);
    S.timeRange = el('input', {
      class: 'lp-time', type: 'range', min: 0, max: 20, step: 0.05, value: 0, 'aria-label': '时间轴'
    });
    S.timeRange.addEventListener('pointerdown', function () {
      S.seeking = true;
      S._wasPlaying = S.playing;
      S.playing = false;
    });
    S.timeRange.addEventListener('input', function () {
      seekTo(parseFloat(S.timeRange.value));
      updateReadouts();
      refreshDynamicUI();
      render();
    });
    function endSeek() {
      if (!S.seeking) return;
      S.seeking = false;
      S.playing = !!S._wasPlaying;
      refreshDynamicUI();
    }
    S.timeRange.addEventListener('pointerup', endSeek);
    S.timeRange.addEventListener('change', endSeek);
    S.timeRange.addEventListener('pointercancel', endSeek);
    window.addEventListener('pointerup', endSeek);
    bar.appendChild(S.timeRange);
    const end = el('span', { class: 'lp-tend' }, '20 s');
    bar.appendChild(end);
    refreshDynamicUI();
  }

  /* ---------- 画布交互 ---------- */
  function pickAt(X, Y) {
    let best = null, bestArea = Infinity;
    for (let i = 0; i < S.objects.length; i++) {
      const o = S.objects[i];
      if (!o.visible) continue;
      const T = TYPES[o.type];
      let b;
      try { b = T.bounds ? T.bounds(o) : { x0: o.x - 0.5, x1: o.x + 0.5, y0: o.y - 0.5, y1: o.y + 0.5 }; }
      catch (e) { continue; }
      const X0 = px(b.x0) - 6, X1 = px(b.x1) + 6;
      const Y0 = py(b.y1) - 6, Y1 = py(b.y0) + 6;
      if (X >= X0 && X <= X1 && Y >= Y0 && Y <= Y1) {
        const area = Math.max(1, (X1 - X0) * (Y1 - Y0));
        if (area < bestArea) { bestArea = area; best = o; }
      }
    }
    return best;
  }
  function setupCanvasEvents() {
    const c = cv.cv;
    const pointers = new Map();
    let drag = null, pinch = null;
    function local(e) {
      const r = c.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }
    function pinchState() {
      const pts = Array.from(pointers.values());
      if (pts.length < 2) return null;
      return {
        d: Math.max(1, Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y)),
        mx: (pts[0].x + pts[1].x) / 2,
        my: (pts[0].y + pts[1].y) / 2
      };
    }
    c.addEventListener('pointerdown', function (e) {
      if (e.button != null && e.button !== 0) return;
      try { c.setPointerCapture(e.pointerId); } catch (err) { }
      const p = local(e);
      pointers.set(e.pointerId, p);
      if (pointers.size === 2) { pinch = pinchState(); drag = null; return; }
      if (pointers.size > 2) return;
      const hit = pickAt(p.x, p.y);
      if (hit) {
        selectObject(hit);
        drag = { mode: 'obj', o: hit, lx: p.x, ly: p.y };
      } else {
        if (S.sel) { S.sel = null; refreshObjectList(); refreshInspector(); render(); }
        drag = { mode: 'pan', lx: p.x, ly: p.y };
      }
    });
    c.addEventListener('pointermove', function (e) {
      const p = local(e);
      if (S.shell) S.shell.coord('x ' + fmt(wx(p.x), 2) + ' m · y ' + fmt(wy(p.y), 2) + ' m');
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, p);
      if (pointers.size >= 2) {
        if (!pinch) pinch = pinchState();
        const ns = pinchState();
        if (ns) {
          const wx0 = wx(pinch.mx), wy0 = wy(pinch.my);
          cam.scale = clamp(cam.scale * (ns.d / pinch.d), 10, 420);
          cam.x = wx0 - (ns.mx - cv.w / 2) / cam.scale;
          cam.y = wy0 + (ns.my - cv.h / 2) / cam.scale;
          pinch = ns;
          render();
        }
        return;
      }
      if (!drag) return;
      const dx = p.x - drag.lx, dy = p.y - drag.ly;
      drag.lx = p.x; drag.ly = p.y;
      if (drag.mode === 'pan') {
        cam.x -= dx / cam.scale;
        cam.y += dy / cam.scale;
      } else {
        drag.o.x += dx / cam.scale;
        drag.o.y -= dy / cam.scale;
        drag.o.trail = []; drag.o._tt = 0;
        updateReadouts();
      }
      render();
    });
    function up(e) {
      pointers.delete(e.pointerId);
      if (pointers.size < 2) pinch = null;
      if (pointers.size === 0) drag = null;
    }
    c.addEventListener('pointerup', up);
    c.addEventListener('pointercancel', up);
    c.addEventListener('pointerleave', function (e) { if (!pointers.size) return; });
    c.addEventListener('wheel', function (e) {
      e.preventDefault();
      const p = local(e);
      const wx0 = wx(p.x), wy0 = wy(p.y);
      cam.scale = clamp(cam.scale * Math.exp(-e.deltaY * 0.0016), 10, 420);
      cam.x = wx0 - (p.x - cv.w / 2) / cam.scale;
      cam.y = wy0 + (p.y - cv.h / 2) / cam.scale;
      render();
    }, { passive: false });
  }

  function setupKeys() {
    window.addEventListener('keydown', function (ev) {
      if (!S || !S.stage || S.stage.offsetParent === null) return;
      const tag = (ev.target && ev.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'select' || tag === 'textarea') {
        if (ev.key === 'Escape' && ev.target.blur) ev.target.blur();
        return;
      }
      if (ev.key === 'Escape') {
        if (S.sel) { S.sel = null; refreshObjectList(); refreshInspector(); render(); }
      } else if (ev.key === 'Delete' || ev.key === 'Backspace') {
        if (S.sel) { ev.preventDefault(); removeObject(S.sel); }
      } else if (ev.code === 'Space') {
        ev.preventDefault(); togglePlay();
      } else if (ev.key === 'ArrowRight') {
        ev.preventDefault(); stepOnce();
      }
    });
  }

  /* ---------- 导出 ---------- */
  function doExport(download) {
    if (!cv) return '';
    const w = cv.cv.width, h = cv.cv.height;
    const off = document.createElement('canvas');
    off.width = w; off.height = h;
    const c = off.getContext('2d');
    c.fillStyle = C.paper || (S.theme === 'night' ? '#0B1322' : '#FBF8F3');
    c.fillRect(0, 0, w, h);
    c.drawImage(cv.cv, 0, 0);
    c.save();
    const fs = Math.max(12, Math.round(13 * cv.dpr));
    c.font = '600 ' + fs + 'px ' + C.sans;
    c.fillStyle = S.theme === 'night' ? 'rgba(234,241,250,.7)' : 'rgba(8,31,92,.55)';
    c.textBaseline = 'top';
    c.fillText('见微 · 格物实验台 · 场景搭建', 16 * cv.dpr, 14 * cv.dpr);
    c.textBaseline = 'bottom';
    c.fillText('t = ' + fmt(S.t, 2) + ' s', 16 * cv.dpr, h - 12 * cv.dpr);
    c.restore();
    let url = '';
    try { url = off.toDataURL('image/png'); } catch (e) { noteError(e); return ''; }
    if (download) {
      try {
        const a = document.createElement('a');
        a.href = url;
        a.download = 'jianwei-phys-' + Date.now() + '.png';
        document.body.appendChild(a);
        a.click();
        a.remove();
      } catch (e) { noteError(e); }
    }
    return url;
  }

  /* ================= 六、自检 ================= */
  function runSelfTest() {
    const checks = [];
    function add(name, pass, detail) {
      checks.push({ name: name, pass: !!pass, detail: detail == null ? '' : String(detail) });
    }
    if (!S) return { ok: false, checks: [], errors: ['引擎尚未挂载'] };
    const snap = serializeScene();
    try {
      // ① 放置 8 类对象
      clearScene();
      ['car', 'projectile', 'incline', 'pendulum', 'resistor', 'bfield', 'convex', 'wavesrc'].forEach(function (t, i) {
        spawn(t, cam.x + (i % 4 - 1.5) * 1.2, t === 'car' || t === 'incline' ? 0 : cam.y);
      });
      add('放置 8 类对象', S.objects.length === 8, 'objectCount=' + S.objects.length);

      // ② 参数改动重算（弹簧周期随 k 变化）
      clearScene();
      const spring = spawn('spring', 0, 0, { k: 20, m: 0.5, A: 0.4 });
      function springT() {
        const rows = TYPES.spring.read(spring);
        for (let i = 0; i < rows.length; i++) if (rows[i][0].indexOf('周期') >= 0) return parseFloat(rows[i][1]);
        return NaN;
      }
      const T1 = springT();
      setParam(spring, 'k', 60);
      const T2 = springT();
      add('参数改动重算', isFinite(T1) && isFinite(T2) && Math.abs(T1 - T2) > 0.05 && spring.p.k === 60,
        '周期 ' + T1 + ' s → ' + T2 + ' s');

      // ③ 播放 1 秒：t 与位置变化
      loadPreset('projectile', { autoplay: false });
      const proj = S.objects.filter(function (o) { return o.type === 'projectile'; })[0];
      const t0 = S.t, x0 = proj.s.rx, y0 = proj.s.ry;
      S.speed = 1;
      S.playing = true;
      tick(1);
      const moved = Math.abs(proj.s.rx - x0) > 0.01 || Math.abs(proj.s.ry - y0) > 0.01;
      add('播放 1 秒后 t 与位置变化', Math.abs(S.t - t0 - 1) < 0.02 && moved,
        'Δt=' + fmt(S.t - t0, 3) + ' s, Δx=' + fmt(proj.s.rx - x0, 2) + ' m');

      // ④ 暂停后不变
      S.playing = false;
      const ta = S.t, xa = proj.s.rx, ya = proj.s.ry;
      tick(0.5);
      add('暂停后不变', S.t === ta && proj.s.rx === xa && proj.s.ry === ya,
        't=' + fmt(S.t, 3) + ' s');

      // ⑤ 复位归零
      resetScene();
      const proj2 = S.objects.filter(function (o) { return o.type === 'projectile'; })[0];
      add('复位归零', Math.abs(S.t) < 1e-9 && Math.abs(proj2.s.rx) < 1e-9 && Math.abs(proj2.s.ry) < 1e-9,
        't=' + S.t + ', x=' + proj2.s.rx + ', y=' + proj2.s.ry);

      // ⑥ 载入 3 个预设
      const e0 = errors.length;
      ['incline', 'lens', 'orbit'].forEach(function (id) {
        loadPreset(id, { autoplay: false });
        S.playing = true;
        tick(0.2);
      });
      const okPreset = S.objects.length > 0 && errors.length === e0;
      add('载入 3 个预设不报错', okPreset,
        'objects=' + S.objects.length + ', newErrors=' + (errors.length - e0));

      // ⑦ 导出可用
      const url = doExport(false);
      add('导出 PNG 可用', typeof url === 'string' && url.indexOf('data:image/png') === 0 && url.length > 2000,
        'dataURL length=' + (url ? url.length : 0));
    } catch (e) {
      noteError(e);
      add('自检过程未抛异常', false, e && e.message ? e.message : String(e));
    } finally {
      try { restoreScene(snap); } catch (e) { noteError(e); }
    }
    const ok = checks.length > 0 && checks.every(function (c) { return c.pass; }) && errors.length === 0;
    return { ok: ok, checks: checks, errors: errors.slice() };
  }
  window.__labPhysTest = runSelfTest;

  /* ================= 七、挂载 ================= */
  function mount(shell) {
    S = newScene();
    S.shell = shell;
    S.stage = shell.stage;
    S.left = shell.left;
    S.right = shell.right;
    S.theme = shell.themeOf ? shell.themeOf() : 'day';
    S.bg = C.paper || (S.theme === 'night' ? '#0B1322' : '#F7F2EB');

    cv = new JW.Canvas(shell.stage, {});
    ctx = cv.ctx;

    const my = S;
    let lastTs = 0, uiTs = 0;
    function frame(ts) {
      if (S !== my) return;
      requestAnimationFrame(frame);
      const hidden = !S.stage || S.stage.offsetParent === null;
      if (S.bar) S.bar.style.display = hidden ? 'none' : '';
      if (hidden || document.hidden) { lastTs = ts; return; }
      let dt = (ts - lastTs) / 1000;
      lastTs = ts;
      if (!isFinite(dt) || dt < 0) dt = 1 / 60;
      dt = Math.min(0.05, dt);
      if (S.playing) tick(dt);
      render();
      if (ts - uiTs > 130) { uiTs = ts; refreshDynamicUI(); }
    }

    buildLeft();
    buildRight();
    buildTimeline();
    setupCanvasEvents();
    setupKeys();

    shell.onTheme(function (theme) {
      if (!S) return;
      S.theme = theme;
      S.bg = C.paper || (theme === 'night' ? '#0B1322' : '#F7F2EB');
      render();
    });
    if (shell.status) {
      shell.status('拖动空白平移 · 滚轮或双指缩放 · 空格播放 · Delete 删除 · Esc 取消');
    }

    let qp = '';
    try { qp = (new URLSearchParams(location.search)).get('preset') || ''; } catch (e) { }
    let qt = NaN;
    try { qt = parseFloat((new URLSearchParams(location.search)).get('t')); } catch (e) { }
    const hit = PRESETS.some(function (p) { return p.id === qp; });
    loadPreset(hit ? qp : 'projectile', {
      advance: hit ? 0 : 0.55,
      autoplay: !!hit && !(isFinite(qt) && qt > 0)
    });
    if (hit && isFinite(qt) && qt > 0) { seekTo(qt); S.playing = false; }
    S.ready = true;
    refreshAll();
    render();
    requestAnimationFrame(frame);

    const api = {
      resize: function () {
        try { cv.resize(); } catch (e) { noteError(e); }
        render();
      },
      activate: function () {
        S.active = true;
        if (S.bar) S.bar.style.display = '';
        if (S.left && !S.left.querySelector('.lp-lib')) buildLeft();
        if (S.right && !S.right.querySelector('.lp-presets')) buildRight();
        buildTimeline();
        refreshAll();
        try { cv.resize(); } catch (e) { }
        render();
      },
      exportPNG: function () { return doExport(true); },
      start: function () { setPlaying(true); },
      pause: function () { setPlaying(false); },
      reset: function () { resetScene(); refreshAll(); render(); }
    };
    window.__labPhysApi = api;
    return api;
  }

  window.JWLabPhys = { mount: mount };
})();
