'use strict';
/* ================= 见微原「变换实验室」两个引擎 → 自由工作台 =================
   legacy/lab-math.js（几何画板：点线圆、函数、仿射变换）与 legacy/lab-phys.js（场景搭建：光学、波、天体、碰撞……）
   原本挂在 lab.html 的三栏外壳上，接口是 engine.mount(shell)。这里给它们一份等价的 shell：
   左栏 = 素材栏，中间 = 画布，右栏 = 检查器。引擎只挂载一次，之后切走/切回只搬 DOM，状态不丢。 */
(() => {
  const JW = window.JW;
  if (!JW) return;

  // 引擎画布取色走 JW.C：从格物的 CSS 变量映射过去，切主题时原地改值（lab-phys 持有 JW.C 的引用）
  function syncPalette() {
    const cs = getComputedStyle(document.body), v = k => cs.getPropertyValue('--' + k).trim();
    const dark = isDark();
    Object.assign(JW.C, {
      paper: v('stage'), card: v('surface'), ink: v('fg'), ink2: v('math'),
      data: [v('math'), v('c1'), v('c3'), v('c4'), v('c5')],
      line: v('line'), line2: v('grid'), soft: v('muted'), faint: v('axis'),
      accent: v('phys'), jade: v('chem'), gold: v('c4'),
      grid: v('grid'), grid2: dark ? v('grid') : alpha(v('grid'), .55)
    });
    return dark ? 'night' : 'day';
  }

  const ART = {
    draw: `<svg viewBox="0 0 160 110"><g fill="none" stroke="currentColor" stroke-width="2.2">
      <path d="M14 92H150M24 102V8" stroke-width="1.4" opacity=".5"/>
      <path d="M40 84L70 30L104 78Z" stroke-dasharray="5 4" opacity=".55"/>
      <path d="M66 74L104 26L134 80Z" fill="currentColor" fill-opacity=".12"/>
      <path d="M78 58q16-26 34-18" stroke-width="1.6"/><path d="M108 36l5 4-6 3" stroke-width="1.6"/></g>
      <g fill="currentColor"><circle cx="66" cy="74" r="4"/><circle cx="104" cy="26" r="4"/><circle cx="134" cy="80" r="4"/></g></svg>`,
    scene: `<svg viewBox="0 0 160 110"><g fill="none" stroke="currentColor" stroke-width="2.2">
      <path d="M80 12q10 43 0 86q-10-43 0-86z" fill="currentColor" fill-opacity=".1"/>
      <path d="M14 34L80 55L146 78M14 55H146M14 76L80 55L146 32" stroke-width="1.5" opacity=".75"/>
      <path d="M8 55H152" stroke-width="1" stroke-dasharray="3 4" opacity=".45"/></g>
      <path d="M14 34v42" stroke="#d99a00" stroke-width="4" stroke-linecap="round"/>
      <path d="M140 46v18" stroke="currentColor" stroke-width="2.6"/><path d="M134 50l6-6 6 6" fill="none" stroke="currentColor" stroke-width="2"/></svg>`
  };

  function makeLegacy(id, engineName, cls, foot) {
    const st = { mounted: false, active: false, api: null, B: null, fns: [], boxes: null, theme: 'day' };

    // 引擎往 window/document 上挂的键盘、指针监听，只在本工作台打开时才放行
    const ALWAYS = new Set(['beforeunload', 'pagehide', 'error', 'unhandledrejection']);
    function gated(type, fn) {
      if (typeof fn !== 'function' || ALWAYS.has(type)) return fn;
      return function (ev) { if (st.active) return fn.call(this, ev); };
    }
    function mountEngine() {
      const eng = window[engineName];
      const left = el('div', 'lg-left'), right = el('div', 'lg-right'), stage = el('div', 'lg-stage');
      st.boxes = { left, right, stage };
      const shell = {
        mode: id, stage, left, right,
        status: t => { const n = st.B && st.B.foot.querySelector('.lg-st'); if (n) n.textContent = t || ''; },
        coord: t => { const n = st.B && st.B.foot.querySelector('.lg-co'); if (n) n.textContent = t || ''; },
        setTitle: t => { const n = st.B && st.B.foot.querySelector('.lg-ti'); if (n) n.textContent = t || ''; },
        themeOf: () => st.theme,
        onTheme: fn => { st.fns.push(fn); try { fn(st.theme); } catch (e) { console.warn(e); } },
        toast: (t, ms) => st.B && st.B.toast(String(t).replace(/[<&]/g, c => c === '<' ? '&lt;' : '&amp;'), { ms: ms || 2000 }),
        float: pos => {
          const b = el('div', 'lab-float');
          Object.assign(b.style, pos === 'tl' ? { left: '10px', top: '10px' } : pos === 'tr' ? { right: '10px', top: '10px' } :
            pos === 'bl' ? { left: '10px', bottom: '10px' } : { right: '10px', bottom: '10px' });
          stage.appendChild(b); return b;
        },
        clearPanels: () => { left.innerHTML = ''; right.innerHTML = ''; }
      };
      if (!eng || typeof eng.mount !== 'function') { stage.appendChild(el('div', 'err', '引擎没有加载')); st.mounted = true; return; }
      const wAdd = window.addEventListener, dAdd = document.addEventListener;
      window.addEventListener = function (t, fn, o) { return wAdd.call(window, t, gated(t, fn), o); };
      document.addEventListener = function (t, fn, o) { return dAdd.call(document, t, gated(t, fn), o); };
      try { st.api = eng.mount(shell) || {}; }
      catch (err) { console.error(err); stage.appendChild(el('div', 'err', '加载出错：' + err.message)); }
      finally { window.addEventListener = wAdd; document.addEventListener = dAdd; }
      st.mounted = true;
    }
    function applyTheme() {
      const t = syncPalette(); if (t === st.theme && st._painted) return;
      st.theme = t; st._painted = true;
      st.fns.forEach(fn => { try { fn(t); } catch (e) { console.warn(e); } });
    }
    new MutationObserver(() => { if (st.mounted) applyTheme(); }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (st.mounted) applyTheme(); });

    return function init(B) {
      st.B = B;
      B.pal.parentNode.classList.add('lg-bench', cls);
      B.insp.classList.add('lg-insp');
      B.foot.innerHTML = `<section class="lg-bar"><span class="lg-ti"></span><span class="lg-st"></span><span class="lg-co"></span></section>
        <section><h3>怎么用</h3><ol>${foot.map(t => `<li>${t}</li>`).join('')}</ol></section>`;
      st.theme = syncPalette();
      if (!st.mounted) mountEngine();
      const { left, right, stage } = st.boxes;
      B.pal.appendChild(left); B.insp.appendChild(right); B.stage.appendChild(stage);
      st.active = true; st._painted = false; applyTheme();
      requestAnimationFrame(() => {
        try { st.api && st.api.resize && st.api.resize(); } catch (e) { }
        try { st.api && st.api.activate && st.api.activate(); } catch (e) { }
      });
      const ro = new ResizeObserver(() => { try { st.api && st.api.resize && st.api.resize(); } catch (e) { } });
      ro.observe(B.stage);
      B.L.disp.push(() => { ro.disconnect(); st.active = false; left.remove(); right.remove(); stage.remove(); });
      window.__legacy = window.__legacy || {}; window.__legacy[id] = st;
    };
  }

  Bench.reg({
    id: 'draw', subj: 'math', short: '几何画板', title: '几何画板', sub: '点 · 线 · 圆 · 多边形 · 向量 · 函数 · 平移 / 旋转 / 缩放 / 对称',
    desc: '像 GeoGebra 一样自由作图：画点、线段、圆、多边形和 y = f(x)，拖点联动；选中后做平移、旋转、缩放、点对称、线对称，原像留虚线，右侧给出变换矩阵；可量距离、角度、面积，自动保存。',
    art: ART.draw,
    init: makeLegacy('draw', 'JWLabMath', 'lg-math', [
      '左上工具条选工具：点、线段、直线、圆、多边形、向量；在画布上点击作图，拖动顶点会联动。',
      '选中图形后在右栏选「变换」：平移、旋转、缩放、点对称、线对称，可以连续叠加，右栏显示累计矩阵 M。',
      '拖动空白处平移视野，滚轮缩放；左栏「预设」有三角形四连变换、二次函数、三角函数、圆与切线。',
      '画板内容会自动保存在本机，下次打开还在。'
    ])
  });
  Bench.reg({
    id: 'scene', subj: 'phys', short: '场景搭建', title: '物理场景搭建', sub: '运动学 · 力学 · 电学 · 磁场 · 电场 · 光学 · 波 · 万有引力',
    desc: '从八个章节的物体库里点选物体放到画布上：小车、单摆、带电粒子、透镜、平面镜、波源、卫星……改质量、电荷、初速和焦距，播放、单步、拖时间轴，看轨迹、矢量与实时读数。',
    art: ART.scene,
    init: makeLegacy('scene', 'JWLabPhys', 'lg-phys', [
      '左栏按章节列出 30 类物体，点一下放到画布中央；左下「预设」是 12 个现成场景（透镜成像、双缝、卫星变轨……）。',
      '点选画布上的物体，右栏修改参数，读数实时更新。',
      '画布底部的时间轴：播放 / 单步 / 复位 / 倍速，也可以直接拖动进度。',
      '右栏「场景设置」里可开关矢量、轨迹、网格和比例尺，导出 PNG。'
    ])
  });
})();
