'use strict';
/* ======================= 物理（选择性必修） ======================= */

function waveRGB(nm) { // 可见光波长 → [r,g,b] 0..1
  let r = 0, g = 0, b = 0;
  if (nm >= 380 && nm < 440) { r = -(nm - 440) / 60; b = 1; } else if (nm < 490) { g = (nm - 440) / 50; b = 1; }
  else if (nm < 510) { g = 1; b = -(nm - 510) / 20; } else if (nm < 580) { r = (nm - 510) / 70; g = 1; }
  else if (nm < 645) { r = 1; g = -(nm - 645) / 65; } else if (nm <= 780) r = 1;
  let f = nm < 380 || nm > 780 ? 0 : nm < 420 ? 0.3 + 0.7 * (nm - 380) / 40 : nm > 700 ? 0.3 + 0.7 * (780 - nm) / 80 : 1;
  return [r * f, g * f, b * f];
}
const waveCSS = (nm, a = 1) => { const [r, g, b] = waveRGB(nm); if (r + g + b === 0) return `rgba(150,150,170,${a})`; return `rgba(${r * 255 | 0},${g * 255 | 0},${b * 255 | 0},${a})`; };

/* ---------- 动量守恒：碰撞 ---------- */
Lab.reg({
  id: 'p-collide', subj: 'phys', book: 3, unit: '动量守恒定律', title: '一维碰撞与动量守恒', kw: '动量 冲量 弹性碰撞 非弹性碰撞 恢复系数',
  info: `<p class="fb">p = mv　动量守恒：m₁v₁ + m₂v₂ = m₁v₁′ + m₂v₂′<br>恢复系数 e = (v₂′ − v₁′)/(v₁ − v₂)<br>弹性碰撞 e = 1，动能守恒：v₁′ = [(m₁−m₂)v₁ + 2m₂v₂]/(m₁+m₂)<br>完全非弹性碰撞 e = 0，碰后共速，动能损失最大</p>`,
  tasks: ['m₁ = m₂、弹性碰撞、B 静止：碰后两车速度如何？', '大质量车撞小质量静止车（弹性），小车速度最多接近多少？', '完全非弹性碰撞中，动能损失占初动能的比例与质量比有什么关系？'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ m1: ['A 质量 m₁', 0.5, 5, 0.1, 2, 'kg'], m2: ['B 质量 m₂', 0.5, 5, 0.1, 1, 'kg'], v1: ['A 初速度 v₁', -4, 6, 0.1, 3, 'm/s'], v2: ['B 初速度 v₂', -4, 4, 0.1, 0, 'm/s'], e: ['恢复系数 e', 0, 1, 0.05, 1] }, () => reset());
    L.button('弹性', () => p.e = 1); L.button('非弹性 e=0.5', () => p.e = 0.5); L.button('完全非弹性', () => p.e = 0);
    L.group('运行');
    const run = L.loop(dt => { step(dt); L.drawFn(); }, false);
    L.button('开始 / 暂停', () => run.toggle(), true); L.button('重置', () => { reset(); run.pause(); });
    const out = L.out();
    let s;
    function reset() { s = { x1: -2.5, x2: 1, u1: p.v1, u2: p.v2, hit: false, t: 0 }; L.draw(); }
    reset();
    const w = m => 0.35 + Math.cbrt(m) * 0.35;
    function step(dt) {
      s.t += dt; s.x1 += s.u1 * dt; s.x2 += s.u2 * dt;
      if (!s.hit && s.x2 - s.x1 <= (w(p.m1) + w(p.m2)) / 2 && s.u1 > s.u2) {
        const { m1, m2, e } = p, P = m1 * s.u1 + m2 * s.u2, d = s.u1 - s.u2;
        s.u1 = (P - m2 * e * d) / (m1 + m2); s.u2 = (P + m1 * e * d) / (m1 + m2); s.hit = true;
      }
      if (Math.abs(s.x1) > 9 && Math.abs(s.x2) > 9) run.pause();
    }
    L.onDraw(() => {
      c.clear(); const g = c.g, sc = c.w / 14, cx = c.w / 2, ty = c.h * 0.32;
      D.line(g, 0, ty + 2, c.w, ty + 2, T.axis, 2);
      [[s.x1, p.m1, T.c1, 'A', s.u1], [s.x2, p.m2, T.c2, 'B', s.u2]].forEach(([x, m, col, n, u]) => {
        const ww = w(m) * sc, hh = ww * 0.6, X = cx + x * sc;
        D.rrect(g, X - ww / 2, ty - hh, ww, hh, 4, col); D.text(g, `${n}  ${m}kg`, X, ty - hh / 2, '#fff', { align: 'center', bold: true, size: 12 });
        D.arrow(g, X, ty - hh - 14, X + u * 18, ty - hh - 14, col, 2.4);
      });
      const { m1, m2 } = p, pb = [m1 * p.v1, m2 * p.v2], pa = [m1 * s.u1, m2 * s.u2], kb = [0.5 * m1 * p.v1 ** 2, 0.5 * m2 * p.v2 ** 2], ka = [0.5 * m1 * s.u1 ** 2, 0.5 * m2 * s.u2 ** 2];
      // 柱状图
      const by = c.h * 0.55, bh = c.h * 0.38, bw = 28, groups = [['动量 p（kg·m/s）', pb, pa], ['动能 Eₖ（J）', kb, ka]];
      const pm = Math.max(1, ...pb.map(Math.abs), ...pa.map(Math.abs), Math.abs(pb[0] + pb[1])), km = Math.max(1, kb[0] + kb[1]);
      groups.forEach(([title, b, a], gi) => {
        const gx = c.w * (gi ? 0.56 : 0.08), mx = gi ? km : pm, zero = gi ? by + bh : by + bh / 2, sclv = (gi ? bh : bh / 2) / mx * 0.9;
        D.text(g, title, gx, by - 10, T.muted, { size: 12 });
        D.line(g, gx - 6, zero, gx + 7 * (bw + 6), zero, T.axis, 1);
        [[b, '碰前'], [a, '碰后']].forEach(([arr, lab], k) => {
          const x0 = gx + k * 3.6 * (bw + 6);
          [[arr[0], T.c1], [arr[1], T.c2], [arr[0] + arr[1], T.c3]].forEach(([val, col], j) => { const h = val * sclv; D.rect(g, x0 + j * (bw + 4), Math.min(zero, zero - h), bw, Math.abs(h), col); });
          D.text(g, lab, x0 + 1.5 * bw, by + bh + 14, T.muted, { align: 'center', size: 11 });
        });
      });
      D.text(g, '■ A  ■ B  ■ 合计', 12, c.h - 10, T.muted, { size: 11 });
      out.set([['碰前总动量', fmt(pb[0] + pb[1], 3)], ['碰后总动量', s.hit ? fmt(pa[0] + pa[1], 3) : '尚未碰撞'], ['碰后 v₁′ , v₂′', s.hit ? `${fmt(s.u1, 3)} , ${fmt(s.u2, 3)} m/s` : '—'], ['碰前总动能', fmt(kb[0] + kb[1], 3) + ' J'], ['碰后总动能', s.hit ? fmt(ka[0] + ka[1], 3) + ' J' : '—'], ['动能损失', s.hit ? fmt(kb[0] + kb[1] - ka[0] - ka[1], 3) + ' J' : '—']]);
    });
  }
});

/* ---------- 机械振动 ---------- */
Lab.reg({
  id: 'p-shm', subj: 'phys', book: 3, unit: '机械振动', title: '简谐运动、单摆与受迫振动', kw: '弹簧振子 周期 单摆 阻尼 共振 振动图像',
  info: `<p class="fb">简谐运动 F = −kx，x = A sin(ωt + φ)，弹簧振子 T = 2π√(m/k)<br>单摆（小角度）T = 2π√(l/g)，与振幅、摆球质量无关<br>受迫振动的频率等于驱动力频率；驱动频率等于固有频率时振幅最大，称为共振</p>
  <p>单摆模式按精确方程 θ″ = −(g/l)sin θ 积分，摆角大时实测周期会略大于小角度公式。</p>`,
  tasks: ['弹簧振子：振幅加倍，周期变吗？质量变为 4 倍呢？', '单摆从 5° 和 60° 释放，比较实测周期与公式值。', '受迫振动：慢慢调节驱动频率，在共振曲线上找到峰值；加大阻尼，峰会怎样变化？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['spr', '弹簧振子'], ['pen', '单摆'], ['frc', '受迫振动']], 'spr', () => { sync(); reset(); });
    const p = L.params({ k: ['劲度系数 k', 5, 100, 1, 20, 'N/m'], m: ['质量 m', 0.1, 4, 0.1, 1, 'kg'], A: ['初始位移 A', 0.05, 0.5, 0.01, 0.3, 'm'], b: ['阻尼系数 b', 0, 3, 0.05, 0, 'kg/s'], l: ['摆长 l', 0.2, 3, 0.05, 1, 'm'], th: ['摆角 θ₀', 1, 80, 1, 10, '°'], fd: ['驱动频率 f', 0.1, 2, 0.01, 0.5, 'Hz'], F0: ['驱动力幅值 F₀', 0.5, 5, 0.1, 1, 'N'] }, k => { if (k !== 'fd' && k !== 'F0' && k !== 'b') reset(); else L.draw(); });
    L.button('重新开始', () => reset(), true);
    const out = L.out();
    let s;
    function sync() { const m = mode.v; ['k', 'm', 'A'].forEach(k => p['$' + k].el.hidden = m === 'pen'); p.$A.el.hidden = m !== 'spr'; p.$l.el.hidden = p.$th.el.hidden = m !== 'pen'; p.$fd.el.hidden = p.$F0.el.hidden = m !== 'frc'; p.$b.el.hidden = m === 'pen'; }
    function reset() { s = { x: mode.v === 'pen' ? p.th * PI / 180 : mode.v === 'spr' ? p.A : 0, v: 0, t: 0, hist: [], cross: [] }; L.draw(); }
    sync(); reset();
    const acc = (x, v, t) => { const m = mode.v; if (m === 'pen') return -9.8 / p.l * Math.sin(x); let a = (-p.k * x - p.b * v) / p.m; if (m === 'frc') a += p.F0 / p.m * Math.cos(TAU * p.fd * t); return a; };
    L.loop(dt => {
      const n = 20, h = dt / n;
      for (let i = 0; i < n; i++) {
        const { x, v, t } = s, k1v = acc(x, v, t), k1x = v, k2v = acc(x + k1x * h / 2, v + k1v * h / 2, t + h / 2), k2x = v + k1v * h / 2, k3v = acc(x + k2x * h / 2, v + k2v * h / 2, t + h / 2), k3x = v + k2v * h / 2, k4v = acc(x + k3x * h, v + k3v * h, t + h), k4x = v + k3v * h;
        const nx = x + (k1x + 2 * k2x + 2 * k3x + k4x) * h / 6; s.v = v + (k1v + 2 * k2v + 2 * k3v + k4v) * h / 6;
        if (x < 0 && nx >= 0) s.cross.push(t); s.x = nx; s.t = t + h;
      }
      s.hist.push([s.t, s.x]); if (s.hist.length > 600) s.hist.shift(); L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, m = mode.v, top = c.h * 0.48;
      let rows = [];
      if (m === 'pen') {
        const px = c.w / 2, py = 24, Lp = Math.min(top - 50, 60 + p.l * 50), bx = px + Lp * Math.sin(s.x), by = py + Lp * Math.cos(s.x);
        D.line(g, px - 50, py, px + 50, py, T.fg, 3); D.line(g, px, py, px, py + Lp + 10, T.grid2, 1, [3, 4]);
        D.line(g, px, py, bx, by, T.fg, 1.5); D.circle(g, bx, by, 12, T.c1, T.fg, 1.2);
        const T0 = TAU * Math.sqrt(p.l / 9.8), cr = s.cross, Tm = cr.length > 1 ? (cr[cr.length - 1] - cr[0]) / (cr.length - 1) : NaN;
        rows = [['摆角 θ', fmt(s.x * 180 / PI, 2) + '°'], ['小角度公式 T = 2π√(l/g)', fmt(T0, 4) + ' s'], ['实测周期', isFinite(Tm) ? fmt(Tm, 4) + ' s' : '测量中…'], ['偏差', isFinite(Tm) ? fmt((Tm / T0 - 1) * 100, 2) + ' %' : '—']];
      } else {
        const wx = 40, cx = c.w / 2, sc = (c.w / 2 - 80) / 0.6, bx = cx + s.x * sc, by = top * 0.6;
        D.rect(g, wx - 10, by - 40, 10, 60, alpha(T.muted, 0.4)); D.line(g, wx, by + 22, c.w - 20, by + 22, T.axis, 1.5);
        D.spring(g, wx, by, bx - 22, by, 14, 10, T.fg, 1.5); D.rrect(g, bx - 22, by - 20, 44, 40, 4, T.c1);
        D.line(g, cx, by - 30, cx, by + 30, T.grid2, 1, [3, 3]); D.text(g, 'O', cx, by + 38, T.muted, { align: 'center' });
        if (m === 'frc') { const F = p.F0 * Math.cos(TAU * p.fd * s.t); D.arrow(g, bx, by - 30, bx + F * 20, by - 30, T.c2, 2.2); D.text(g, '驱动力', bx + 26, by - 42, T.c2, { size: 11 }); }
        const w0 = Math.sqrt(p.k / p.m), T0 = TAU / w0;
        rows = [['位移 x', fmt(s.x, 3) + ' m'], ['速度 v', fmt(s.v, 3) + ' m/s'], ['回复力 −kx', fmt(-p.k * s.x, 3) + ' N'], ['固有周期 2π√(m/k)', fmt(T0, 4) + ' s'], ['固有频率', fmt(1 / T0, 4) + ' Hz'], ['机械能', fmt(0.5 * p.k * s.x ** 2 + 0.5 * p.m * s.v ** 2, 4) + ' J']];
        if (m === 'frc') {
          const amp = f => { const w = TAU * f; return p.F0 / p.m / Math.sqrt((w0 * w0 - w * w) ** 2 + (p.b * w / p.m) ** 2 + 1e-12); };
          const fs = [...Array(200).keys()].map(i => 0.1 + i * 0.0095), gw = c.w / 2 - 50;
          const ch = D.chart(g, c.w / 2 + 30, top + 20, gw, c.h - top - 50, [{ pts: fs.map(f => [f, Math.min(amp(f), 2)]), color: T.c3, w: 2 }], { title: '共振曲线 A − f', xl: 'f / Hz', xmin: 0.1, xmax: 2, ymin: 0 });
          D.circle(g, ch.X(p.fd), ch.Y(Math.min(amp(p.fd), 2)), 5, T.c2); D.line(g, ch.X(1 / T0), top + 20, ch.X(1 / T0), c.h - 30, T.muted, 1, [4, 4]);
          rows.push(['驱动频率', fmt(p.fd, 3) + ' Hz'], ['稳态振幅（理论）', fmt(amp(p.fd), 4) + ' m']);
        }
      }
      const hw = m === 'frc' ? c.w / 2 - 50 : c.w - 70;
      if (s.hist.length > 1) D.chart(g, 40, top + 20, hw, c.h - top - 50, [{ pts: s.hist, color: T.c1, w: 2 }], { title: m === 'pen' ? '振动图像 θ − t（rad）' : '振动图像 x − t（m）', xl: 't / s', xmin: s.hist[0][0], xmax: Math.max(s.hist[0][0] + 1, s.t), ymin: -Math.max(...s.hist.map(q => Math.abs(q[1])), 0.01) * 1.1, ymax: Math.max(...s.hist.map(q => Math.abs(q[1])), 0.01) * 1.1 });
      out.set(rows);
    });
  }
});

/* ---------- 机械波 ---------- */
Lab.reg({
  id: 'p-wave', subj: 'phys', book: 3, unit: '机械波', title: '机械波：传播、干涉与多普勒效应', kw: '横波 波长 频率 波速 驻波 干涉 多普勒 波动图像 振动图像',
  info: `<p class="fb">v = λf = λ/T　质点只在平衡位置附近振动，不随波迁移<br>两列相干波叠加：路程差 Δr = nλ 处振动加强，Δr = (n+½)λ 处减弱<br>多普勒效应：波源靠近观察者时接收频率 f′ = fv/(v − vₛ) 变高，远离时变低</p>
  <p>横波模式中，红点是选中的质点，下方是它的振动图像（y − t），上方是某一时刻的波动图像（y − x）。注意区分这两种图像。</p>`,
  tasks: ['横波模式：用「同侧法」判断选中质点此刻的速度方向，再观察验证。', '驻波模式：相邻两个波节之间的距离是多少个波长？', '干涉模式：增大两波源间距，减弱区（暗线）条数如何变化？', '多普勒模式：让波源速度超过波速，会出现什么？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['tr', '横波'], ['st', '驻波'], ['in', '干涉'], ['dp', '多普勒']], 'tr', () => { sync(); t = 0; fronts = []; L.draw(); });
    const p = L.params({ A: ['振幅 A', 5, 40, 1, 20, 'cm'], lam: ['波长 λ', 40, 300, 5, 160, 'px'], f: ['频率 f', 0.1, 2, 0.05, 0.5, 'Hz'], idx: ['选中质点位置', 0, 1, 0.01, 0.35], d: ['两波源间距', 20, 300, 5, 120, 'px'], vs: ['波源速度 / 波速', 0, 1.5, 0.05, 0.5] });
    const run = L.loop(dt => { t += dt; L.drawFn(); });
    L.button('暂停 / 继续', () => run.toggle()); L.button('从头开始', () => { t = 0; fronts = []; hist = []; });
    const out = L.out();
    let t = 0, fronts = [], hist = [], lastEmit = 0;
    function sync() { const m = mode.v; p.$idx.el.hidden = m !== 'tr'; p.$d.el.hidden = m !== 'in'; p.$vs.el.hidden = m !== 'dp'; p.$A.el.hidden = m === 'in' || m === 'dp'; }
    sync();
    const off = document.createElement('canvas');
    L.onDraw(() => {
      c.clear(); const g = c.g, m = mode.v, w = TAU * p.f, k = TAU / p.lam, v = p.lam * p.f, A = p.A;
      let rows = [['波长 λ', p.lam + ' px'], ['周期 T', fmt(1 / p.f, 3) + ' s'], ['波速 v = λf', fmt(v, 1) + ' px/s']];
      if (m === 'tr' || m === 'st') {
        const y0 = c.h * 0.36, x0 = 30, x1 = c.w - 30, n = Math.floor((x1 - x0) / 8);
        D.line(g, x0, y0, x1, y0, T.grid2, 1, [4, 4]);
        const Y = x => { const xx = x - x0; if (m === 'tr') return xx > v * t ? 0 : A * Math.sin(w * t - k * xx); return 2 * A * Math.sin(k * xx) * Math.cos(w * t); };
        if (m === 'st') { [1, -1].forEach(sg => { g.strokeStyle = alpha(T.c3, 0.5); g.setLineDash([4, 4]); g.beginPath(); for (let x = x0; x <= x1; x += 2) { const yy = sg * 2 * A * Math.sin(k * (x - x0)); x === x0 ? g.moveTo(x, y0 - yy) : g.lineTo(x, y0 - yy); } g.stroke(); g.setLineDash([]); }); }
        g.strokeStyle = T.c1; g.lineWidth = 2; g.beginPath(); for (let x = x0; x <= x1; x += 2) { const yy = Y(x); x === x0 ? g.moveTo(x, y0 - yy) : g.lineTo(x, y0 - yy); } g.stroke();
        for (let i = 0; i <= n; i++) { const x = x0 + i * 8; D.circle(g, x, y0 - Y(x), 2.4, T.fg); }
        if (m === 'tr') {
          const sx = x0 + p.idx * (x1 - x0), sy = Y(sx), vy = (Y(sx) - (sx - x0 > v * (t - 0.01) ? 0 : A * Math.sin(w * (t - 0.01) - k * (sx - x0)))) / 0.01;
          D.circle(g, sx, y0 - sy, 6, T.c2, T.stage, 2); if (Math.abs(vy) > 1) D.arrow(g, sx + 14, y0 - sy, sx + 14, y0 - sy - Math.sign(vy) * 22, T.c2, 2);
          D.arrow(g, x1 - 80, y0 - A - 30, x1 - 20, y0 - A - 30, T.muted, 1.6); D.text(g, '传播方向', x1 - 80, y0 - A - 44, T.muted, { size: 11 });
          hist.push([t, sy]); while (hist.length && hist[0][0] < t - 3 / p.f) hist.shift();
          D.chart(g, 40, c.h * 0.62, c.w - 80, c.h * 0.32, [{ pts: hist, color: T.c2, w: 2 }], { title: '选中质点的振动图像 y − t', xl: 't / s', xmin: Math.max(0, t - 3 / p.f), xmax: Math.max(t, 3 / p.f), ymin: -A * 1.2, ymax: A * 1.2 });
          rows.push(['选中质点位移', fmt(sy, 1) + ' cm'], ['速度方向', Math.abs(vy) < 1 ? '静止 / 最大位移处' : vy > 0 ? '向上' : '向下'], ['波已传到', fmt(Math.min(v * t, x1 - x0), 0) + ' px']);
        } else {
          for (let x = x0, i = 0; x <= x1; x += p.lam / 2, i++) { D.text(g, 'N', x, y0 + 2 * A + 20, T.c3, { align: 'center', bold: true, size: 11 }); D.line(g, x, y0 - 4, x, y0 + 4, T.c3, 2); }
          rows.push(['波节间距', 'λ/2 = ' + p.lam / 2 + ' px'], ['波腹振幅', '2A = ' + 2 * A + ' cm']);
        }
      }
      if (m === 'in') {
        const res = 3, nx = Math.ceil(c.w / res), ny = Math.ceil(c.h / res); off.width = nx; off.height = ny;
        const og = off.getContext('2d'), img = og.createImageData(nx, ny), s1 = [c.w * 0.18, c.h / 2 - p.d / 2], s2 = [c.w * 0.18, c.h / 2 + p.d / 2];
        const base = T.dark ? [13, 19, 17] : [252, 253, 252], hi = T.dark ? [106, 166, 255] : [44, 111, 209];
        for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
          const x = i * res, y = j * res, r1 = Math.hypot(x - s1[0], y - s1[1]), r2 = Math.hypot(x - s2[0], y - s2[1]);
          const a1 = r1 < v * t ? Math.sin(w * t - k * r1) / Math.sqrt(1 + r1 / 80) : 0, a2 = r2 < v * t ? Math.sin(w * t - k * r2) / Math.sqrt(1 + r2 / 80) : 0, z = clamp((a1 + a2) * 0.5, -1, 1), q = (z + 1) / 2, o = 4 * (j * nx + i);
          img.data[o] = base[0] + (hi[0] - base[0]) * q; img.data[o + 1] = base[1] + (hi[1] - base[1]) * q; img.data[o + 2] = base[2] + (hi[2] - base[2]) * q; img.data[o + 3] = 255;
        }
        og.putImageData(img, 0, 0); g.imageSmoothingEnabled = true; g.drawImage(off, 0, 0, nx * res, ny * res);
        [s1, s2].forEach(s => D.circle(g, s[0], s[1], 5, T.c2, T.stage, 2));
        const nWeak = Math.floor(p.d / p.lam + 0.5) * 2;
        rows.push(['波源间距 d', p.d + ' px = ' + fmt(p.d / p.lam, 2) + 'λ'], ['减弱线条数（理论）', nWeak], ['中垂线上', '路程差 0，振动加强']);
      }
      if (m === 'dp') {
        const vsrc = p.vs * v, sx = c.w * 0.15 + ((vsrc * t) % (c.w * 0.7)), sy = c.h / 2;
        if (t - lastEmit >= 1 / p.f || t < lastEmit) { fronts.push([sx, sy, t]); lastEmit = t; }
        fronts = fronts.filter(f2 => v * (t - f2[2]) < c.w * 1.5);
        fronts.forEach(f2 => D.circle(g, f2[0], f2[1], v * (t - f2[2]), null, alpha(T.c1, 0.7), 1.4));
        D.circle(g, sx, sy, 7, T.c2, T.stage, 2); D.arrow(g, sx, sy - 18, sx + 30, sy - 18, T.c2, 1.8);
        D.text(g, '前方观察者', c.w - 90, sy - 30, T.muted, { size: 11 }); D.circle(g, c.w - 60, sy, 6, T.c3);
        const ff = p.vs < 1 ? p.f / (1 - p.vs) : Infinity, fb = p.f / (1 + p.vs);
        rows.push(['波源频率 f', fmt(p.f, 3) + ' Hz'], ['前方接收频率', isFinite(ff) ? fmt(ff, 3) + ' Hz' : '超过波速，形成激波'], ['后方接收频率', fmt(fb, 3) + ' Hz']);
      }
      out.set(rows);
    });
  }
});

/* ---------- 光的折射与全反射 ---------- */
Lab.reg({
  id: 'p-refract', subj: 'phys', book: 3, unit: '光', title: '光的折射与全反射', kw: '折射定律 折射率 临界角 全反射 光密 光疏',
  info: `<p class="fb">折射定律 n₁ sin θ₁ = n₂ sin θ₂　n = c/v<br>光从光密介质射向光疏介质（n₁ &gt; n₂），入射角 ≥ 临界角 C 时发生全反射，sin C = n₂/n₁</p>
  <p>光线粗细表示能量占比（按菲涅耳公式估算）：入射角越大，反射光越强、折射光越弱；接近临界角时折射光几乎消失。拖动光源可改变入射角。</p>`,
  tasks: ['从水射向空气，找出临界角，并与 arcsin(1/1.33) 比较。', '从空气射入玻璃，入射角从 0° 增加到 90°，折射角最大能到多少？', '为什么光纤要用折射率较大的内芯？'],
  init(L) {
    const c = L.canvas(), media = [['1.00', '空气 1.00'], ['1.33', '水 1.33'], ['1.50', '玻璃 1.50'], ['2.42', '金刚石 2.42']];
    const n1s = L.select('上方介质 n₁（入射）', media, '1.50', () => L.draw()), n2s = L.select('下方介质 n₂', media, '1.00', () => L.draw());
    L.button('交换介质', () => { const a = n1s.v; n1s.el.value = n2s.v; n2s.el.value = a; L.draw(); });
    const th = L.slider('入射角 θ₁', 0, 89, 0.5, 35, null, '°');
    const out = L.out();
    L.note('也可以直接拖动光源。');
    L.interact(c, { hit: (x, y) => { const R = Math.min(c.w, c.h) * 0.42, a = th.v * PI / 180; return Math.hypot(c.w / 2 - R * Math.sin(a) - x, c.h / 2 - R * Math.cos(a) - y) < 20 ? 1 : null; }, drag: (o, x, y) => { const a = Math.atan2(c.w / 2 - x, c.h / 2 - y) * 180 / PI; th.set(clamp(a, 0, 89)); } });
    L.onDraw(() => {
      c.clear(); const g = c.g, cx = c.w / 2, cy = c.h / 2, R = Math.min(c.w, c.h) * 0.42, n1 = +n1s.v, n2 = +n2s.v, a = th.v * PI / 180;
      D.rect(g, 0, cy, c.w, c.h - cy, alpha(T.c1, 0.06 + (n2 - 1) * 0.1)); D.rect(g, 0, 0, c.w, cy, alpha(T.c1, 0.06 + (n1 - 1) * 0.1));
      D.line(g, 0, cy, c.w, cy, T.axis, 1.5); D.line(g, cx, cy - R - 10, cx, cy + R + 10, T.muted, 1, [5, 4]);
      D.text(g, `n₁ = ${n1}`, 14, 18, T.fg); D.text(g, `n₂ = ${n2}`, 14, cy + 18, T.fg);
      const sin2 = n1 * Math.sin(a) / n2, tir = sin2 > 1, b = tir ? null : Math.asin(sin2);
      let Rf = 1;
      if (!tir) { const ci = Math.cos(a), ct = Math.cos(b), rs = ((n1 * ci - n2 * ct) / (n1 * ci + n2 * ct)) ** 2, rp = ((n1 * ct - n2 * ci) / (n1 * ct + n2 * ci)) ** 2; Rf = (rs + rp) / 2; }
      const sx = cx - R * Math.sin(a), sy = cy - R * Math.cos(a);
      const beam = (x1, y1, x2, y2, I) => { D.line(g, x1, y1, x2, y2, alpha(T.c2, 0.25 + 0.75 * I), 1 + 5 * I); D.arrow(g, (x1 * 0.45 + x2 * 0.55), (y1 * 0.45 + y2 * 0.55), (x1 * 0.4 + x2 * 0.6), (y1 * 0.4 + y2 * 0.6), alpha(T.c2, 0.4 + 0.6 * I), 2, 10); };
      beam(sx, sy, cx, cy, 1); beam(cx, cy, cx + R * Math.sin(a), cy - R * Math.cos(a), Rf);
      if (!tir) beam(cx, cy, cx + R * Math.sin(b), cy + R * Math.cos(b), 1 - Rf);
      D.circle(g, sx, sy, 9, T.c4, T.fg, 1.2);
      g.strokeStyle = T.fg; g.lineWidth = 1; g.beginPath(); g.arc(cx, cy, 40, -PI / 2, -PI / 2 - a, true); g.stroke(); D.text(g, 'θ₁', cx - 30 * Math.sin(a / 2) - 14, cy - 54, T.fg);
      if (!tir) { g.beginPath(); g.arc(cx, cy, 40, PI / 2, PI / 2 - b, true); g.stroke(); D.text(g, 'θ₂', cx + 30 * Math.sin(b / 2) + 4, cy + 56, T.fg); }
      const C = n1 > n2 ? Math.asin(n2 / n1) * 180 / PI : null;
      out.set([['入射角 θ₁', fmt(th.v, 1) + '°'], ['折射角 θ₂', tir ? '无（全反射）' : fmt(b * 180 / PI, 2) + '°'], ['临界角 C', C ? fmt(C, 2) + '°' : '光疏→光密，不会全反射'], ['反射光能量占比', fmt(Rf * 100, 1) + ' %'], ['介质 1 中光速', fmt(3e8 / n1 / 1e8, 3) + '×10⁸ m/s'], ['现象', tir ? '全反射' : '反射 + 折射']]);
    });
  }
});

/* ---------- 双缝干涉与单缝衍射 ---------- */
Lab.reg({
  id: 'p-young', subj: 'phys', book: 3, unit: '光', title: '双缝干涉与单缝衍射', kw: '杨氏双缝 条纹间距 衍射 波长 白光',
  info: `<p class="fb">双缝干涉相邻亮（暗）条纹间距 Δx = Lλ/d<br>屏上某点到两缝的路程差 Δr = nλ 为亮纹，(n + ½)λ 为暗纹<br>单缝衍射中央亮纹宽度 ≈ 2Lλ/a，缝越窄衍射越明显</p>
  <p>白光模式按 400~700 nm 的各色光叠加：中央亮纹为白色，两侧出现彩色条纹，红光条纹间距最大。</p>`,
  tasks: ['把波长从紫光调到红光，条纹间距如何变化？', '双缝间距 d 减半，Δx 变为原来几倍？', '单缝模式减小缝宽 a，中央亮纹如何变化？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['ds', '双缝干涉'], ['ss', '单缝衍射']], 'ds');
    const p = L.params({ lam: ['波长 λ', 380, 750, 5, 550, 'nm'], d: ['双缝间距 d', 0.1, 1, 0.01, 0.3, 'mm'], a: ['缝宽 a', 0.02, 0.3, 0.005, 0.06, 'mm'], Lm: ['缝到屏距离 L', 0.3, 2, 0.05, 1, 'm'] });
    const white = L.check('白光', false);
    const out = L.out();
    const sinc = u => Math.abs(u) < 1e-9 ? 1 : Math.sin(u) / u;
    L.onDraw(() => {
      c.clear(); const g = c.g, ds = mode.v === 'ds', { lam, d, a, Lm } = p, span = 20; // 屏上 ±20 mm
      const I = (x, nm) => { const s = x * 1e-3 / Lm, l = nm * 1e-9, beta = PI * a * 1e-3 * s / l, env = sinc(beta) ** 2; return ds ? env * Math.cos(PI * d * 1e-3 * s / l) ** 2 : env; };
      const sx = c.w * 0.42, sw = 46, top = 20, H = c.h - 40;
      // 示意图
      const mx = 30, my = c.h / 2; D.circle(g, mx, my, 9, white.v ? '#ffffff' : waveCSS(lam), T.fg, 1);
      D.line(g, mx + 50, top + 20, mx + 50, my - 4, T.fg, 3); D.line(g, mx + 50, my + 4, mx + 50, top + H - 20, T.fg, 3);
      const bx = mx + 120; if (ds) { D.line(g, bx, top + 20, bx, my - 14, T.fg, 3); D.line(g, bx, my - 8, bx, my + 8, T.fg, 3); D.line(g, bx, my + 14, bx, top + H - 20, T.fg, 3); }
      D.text(g, '单缝', mx + 50, top + 10, T.muted, { align: 'center', size: 11 }); if (ds) D.text(g, '双缝', bx, top + 10, T.muted, { align: 'center', size: 11 });
      D.line(g, bx + 8, my, sx - 6, my, T.grid2, 1, [4, 4]); D.text(g, 'L', (bx + sx) / 2, my - 10, T.muted);
      // 屏
      const img = g.createImageData(Math.max(1, Math.round(sw * (window.devicePixelRatio || 1))), 1);
      for (let j = 0; j < H; j++) {
        const x = (j / H - 0.5) * 2 * span; let r = 0, gg = 0, b = 0;
        if (white.v) { let nn = 0; for (let nm = 400; nm <= 700; nm += 10) { const [rr, g2, b2] = waveRGB(nm), q = I(x, nm); r += rr * q; gg += g2 * q; b += b2 * q; nn++; } r = r / nn * 2.6; gg = gg / nn * 2.6; b = b / nn * 2.6; }
        else { const [rr, g2, b2] = waveRGB(lam), q = I(x, lam); r = rr * q; gg = g2 * q; b = b2 * q; }
        g.fillStyle = `rgb(${clamp(r, 0, 1) * 255 | 0},${clamp(gg, 0, 1) * 255 | 0},${clamp(b, 0, 1) * 255 | 0})`; g.fillRect(sx, top + j, sw, 1.2);
      }
      void img;
      D.rect(g, sx, top, sw, H, null, T.line, 1);
      // 光强曲线
      const gx = sx + sw + 30, gw = c.w - gx - 20;
      g.strokeStyle = white.v ? T.fg : waveCSS(lam); g.lineWidth = 2; g.beginPath();
      for (let j = 0; j <= H; j += 1) { const x = (j / H - 0.5) * 2 * span; let q; if (white.v) { q = 0; for (let nm = 400; nm <= 700; nm += 20) q += I(x, nm); q /= 16; } else q = I(x, lam); const px = gx + q * gw; j ? g.lineTo(px, top + j) : g.moveTo(px, top + j); }
      g.stroke(); D.line(g, gx, top, gx, top + H, T.axis, 1); D.text(g, '光强', gx + gw - 30, top + 10, T.muted, { size: 11 });
      for (let mm = -span; mm <= span; mm += 5) { const y = top + (mm / span / 2 + 0.5) * H; D.line(g, sx - 6, y, sx, y, T.axis, 1); D.text(g, mm + '', sx - 8, y, T.muted, { align: 'right', size: 10, mono: true }); }
      D.text(g, 'mm', sx - 8, top + H + 12, T.muted, { align: 'right', size: 10 });
      const dx = Lm * lam * 1e-9 / (d * 1e-3) * 1e3, w0 = 2 * Lm * lam * 1e-9 / (a * 1e-3) * 1e3;
      out.set(ds ? [['条纹间距 Δx = Lλ/d', fmt(dx, 3) + ' mm'], ['屏上 ±20 mm 内亮纹数', 2 * Math.floor(20 / dx) + 1], ['单缝包络中央宽度', fmt(w0, 2) + ' mm'], ['光的颜色', white.v ? '白光' : lam < 450 ? '紫' : lam < 495 ? '蓝' : lam < 570 ? '绿' : lam < 590 ? '黄' : lam < 620 ? '橙' : '红']]
        : [['中央亮纹宽度 ≈ 2Lλ/a', fmt(w0, 3) + ' mm'], ['缝宽 a / 波长', fmt(a * 1e-3 / (lam * 1e-9), 1)]]);
      p.$d.el.hidden = !ds;
    });
  }
});

/* ---------- 电磁感应：导轨上的导体棒 ---------- */
Lab.reg({
  id: 'p-induct', subj: 'phys', book: 4, unit: '电磁感应', title: '导轨上的导体棒（电磁感应）', kw: '感应电动势 楞次定律 右手定则 安培力 收尾速度 能量转化',
  info: `<p>磁场垂直纸面向里（×），导体棒在恒力 F 作用下沿光滑导轨运动，左端接电阻 R。</p>
  <p class="fb">E = BLv　I = E/R = BLv/R　安培力 F 安 = BIL = B²L²v/R（阻碍相对运动）<br>a = (F − B²L²v/R)/m，速度增大时加速度减小，最终匀速：v_m = FR/(B²L²)<br>匀速时外力的功率全部转化为电阻上的焦耳热：Fv_m = I²R</p>`,
  tasks: ['F = 0，给棒一个初速度，它最终停下来时，动能去哪里了？', '加倍 B，收尾速度变为原来的几倍？', '用右手定则判断棒中电流方向，与图中箭头比较。'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ B: ['磁感应强度 B', 0.1, 2, 0.05, 1, 'T'], Lr: ['导轨间距 L', 0.2, 1, 0.05, 0.5, 'm'], R: ['电阻 R', 0.2, 5, 0.1, 1, 'Ω'], m: ['棒的质量 m', 0.05, 1, 0.05, 0.2, 'kg'], F: ['外力 F', 0, 3, 0.05, 1, 'N'], v0: ['初速度 v₀', 0, 10, 0.5, 0, 'm/s'] }, k => { if (k === 'v0') reset(); else L.draw(); });
    L.button('重新开始', () => reset(), true); const run = L.loop(dt => { step(dt); L.drawFn(); }); L.button('暂停 / 继续', () => run.toggle());
    const out = L.out();
    let s;
    function reset() { s = { x: 0, v: p.v0, t: 0, hist: [[0, p.v0]], Q: 0, W: 0 }; L.draw(); }
    reset();
    function step(dt) {
      const n = 10, h = dt / n;
      for (let i = 0; i < n; i++) { const Fa = p.B ** 2 * p.Lr ** 2 * s.v / p.R, a = (p.F - Fa) / p.m; s.Q += Fa * s.v * h; s.W += p.F * s.v * h; s.v += a * h; s.x += s.v * h; s.t += h; }
      s.hist.push([s.t, s.v]); if (s.hist.length > 800) s.hist.shift();
    }
    L.onDraw(() => {
      c.clear(); const g = c.g, top = 30, H = c.h * 0.42, y1 = top + 20, y2 = top + H - 20;
      for (let x = 30; x < c.w; x += 34) for (let y = top + 6; y < top + H; y += 34) D.text(g, '×', x, y, alpha(T.muted, 0.7), { align: 'center', size: 13 });
      D.line(g, 50, y1, c.w - 10, y1, T.fg, 3); D.line(g, 50, y2, c.w - 10, y2, T.fg, 3);
      resistor(g, 50, y1, 50, y2, 'R', T.c4);
      const rx = 120 + ((s.x * 60) % (c.w - 180) + (c.w - 180)) % (c.w - 180);
      D.rect(g, rx - 5, y1 - 8, 10, y2 - y1 + 16, T.c1);
      const E = p.B * p.Lr * s.v, I = E / p.R, Fa = p.B * I * p.Lr;
      if (Math.abs(I) > 1e-3) { const up = s.v > 0; D.arrow(g, rx + 18, up ? y2 - 20 : y1 + 20, rx + 18, up ? y1 + 20 : y2 - 20, T.c2, 2.4); D.text(g, 'I', rx + 26, (y1 + y2) / 2, T.c2, { bold: true }); }
      const fy = (y1 + y2) / 2 + 30;
      if (p.F > 0) { D.arrow(g, rx, fy, rx + p.F * 30, fy, T.c3, 2.4); D.text(g, 'F', rx + p.F * 30 + 4, fy - 10, T.c3, { bold: true }); }
      if (Math.abs(Fa) > 1e-3) { D.arrow(g, rx, fy + 22, rx - Fa * 30, fy + 22, T.c5, 2.4); D.text(g, 'F 安', rx - Fa * 30 - 30, fy + 12, T.c5, { bold: true }); }
      D.arrow(g, rx, top + 12, rx + s.v * 8, top + 12, T.fg, 2); D.text(g, 'v', rx + s.v * 8 + 4, top + 4, T.fg);
      const vm = p.F * p.R / (p.B * p.Lr) ** 2;
      const ch = D.chart(g, 50, top + H + 30, c.w - 80, c.h - top - H - 60, [{ pts: s.hist, color: T.c1, w: 2.2 }], { title: 'v − t 图像（m/s）', xl: 't / s', xmin: s.hist[0][0], xmax: Math.max(1, s.t), ymin: 0, ymax: Math.max(vm, p.v0, 0.5) * 1.15 });
      if (p.F > 0) { D.line(g, 50, ch.Y(vm), c.w - 30, ch.Y(vm), T.muted, 1, [5, 4]); D.text(g, '收尾速度', c.w - 34, ch.Y(vm) - 8, T.muted, { align: 'right', size: 11 }); }
      out.set([['速度 v', fmt(s.v, 3) + ' m/s'], ['感应电动势 BLv', fmt(E, 3) + ' V'], ['感应电流 I', fmt(I, 3) + ' A'], ['安培力 BIL', fmt(Fa, 3) + ' N'], ['加速度', fmt((p.F - Fa) / p.m, 3) + ' m/s²'], ['收尾速度 FR/(B²L²)', p.F > 0 ? fmt(vm, 3) + ' m/s' : '0（最终停下）'], ['焦耳热 Q', fmt(s.Q, 3) + ' J'], ['外力做功 W', fmt(s.W, 3) + ' J'], ['W − Q = ΔEₖ', fmt(s.W - s.Q, 3) + ' J']]);
    });
  }
});

/* ---------- 交变电流与变压器 ---------- */
Lab.reg({
  id: 'p-ac', subj: 'phys', book: 4, unit: '交变电流', title: '交流发电机、变压器与远距离输电', kw: '交变电流 中性面 峰值 有效值 变压器 匝数比 输电损耗',
  info: `<p class="fb">从中性面开始计时：e = Eₘ sin ωt，Eₘ = NBSω<br>正弦交流有效值 E = Eₘ/√2，T = 2π/ω<br>理想变压器：U₁/U₂ = n₁/n₂，I₁/I₂ = n₂/n₁，P₁ = P₂<br>输电线损耗 P 损 = I²r = (P/U)²r，电压提高到 k 倍，损耗降为 1/k²</p>
  <p>线圈平面与磁感线垂直时为中性面：磁通量最大，感应电动势为零；线圈平面与磁感线平行时磁通量为零，电动势最大。</p>`,
  tasks: ['在发电机模式暂停在中性面位置，读出 Φ 和 e。', '变压器：n₁ = 1100、n₂ = 55、U₁ = 220 V，副线圈电压是多少？负载变小时原线圈电流如何变化？', '输电：把输电电压从 10 kV 提到 100 kV，损耗变为原来的多少？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['gen', '发电机'], ['tr', '变压器'], ['tx', '远距离输电']], 'gen', () => { sync(); L.draw(); });
    const p = L.params({ N: ['线圈匝数 N', 10, 200, 10, 100], B: ['B', 0.05, 1, 0.05, 0.2, 'T'], S: ['线圈面积 S', 0.01, 0.1, 0.005, 0.05, 'm²'], f: ['转速（频率）', 0.1, 2, 0.05, 0.5, 'Hz'],
      n1: ['原线圈匝数 n₁', 100, 2000, 50, 1100], n2: ['副线圈匝数 n₂', 10, 2000, 5, 55], U1: ['原线圈电压 U₁', 10, 400, 10, 220, 'V'], RL: ['负载电阻 R', 1, 100, 1, 10, 'Ω'],
      P: ['输送功率 P', 10, 1000, 10, 200, 'kW'], Ut: ['输电电压 U', 1, 500, 1, 10, 'kV'], r: ['输电线电阻 r', 1, 50, 1, 10, 'Ω'] });
    const run = L.loop(dt => { t += dt; hist.push([t, 0]); L.drawFn(); });
    L.button('暂停 / 继续', () => run.toggle());
    const out = L.out();
    let t = 0, hist = [];
    function sync() { const m = mode.v, show = { gen: ['N', 'B', 'S', 'f'], tr: ['n1', 'n2', 'U1', 'RL'], tx: ['P', 'Ut', 'r'] }[m]; ['N', 'B', 'S', 'f', 'n1', 'n2', 'U1', 'RL', 'P', 'Ut', 'r'].forEach(k => p['$' + k].el.hidden = !show.includes(k)); }
    sync();
    L.onDraw(() => {
      c.clear(); const g = c.g, m = mode.v; let rows = [];
      if (m === 'gen') {
        const w = TAU * p.f, th = w * t, Em = p.N * p.B * p.S * w, cx = c.w * 0.25, cy = c.h * 0.32, R = Math.min(c.w * 0.18, c.h * 0.22);
        D.rect(g, cx - R - 50, cy - R - 10, 30, 2 * R + 20, alpha(T.c2, 0.8)); D.text(g, 'N', cx - R - 35, cy, '#fff', { align: 'center', bold: true });
        D.rect(g, cx + R + 20, cy - R - 10, 30, 2 * R + 20, alpha(T.c1, 0.8)); D.text(g, 'S', cx + R + 35, cy, '#fff', { align: 'center', bold: true });
        for (let k = -3; k <= 3; k++) D.arrow(g, cx - R - 20, cy + k * R / 3.4, cx + R + 18, cy + k * R / 3.4, alpha(T.muted, 0.45), 1, 6);
        const hw = R * Math.abs(Math.cos(th)), front = Math.cos(th) >= 0;
        // 俯视：线圈绕竖直轴转动，线圈平面与磁场夹角为 θ+90°（t=0 时垂直磁感线，即中性面）
        const ex = R * Math.sin(th), ez = R * Math.cos(th);
        D.line(g, cx - ex * 0.9, cy - R * 0.8, cx + ex * 0.9, cy - R * 0.8, T.fg, 1); void hw; void front; void ez;
        D.poly(g, [[cx - ex, cy - R * 0.75], [cx + ex, cy - R * 0.75], [cx + ex, cy + R * 0.75], [cx - ex, cy + R * 0.75]], alpha(T.c4, 0.25), T.c4, 3);
        D.line(g, cx, cy - R - 20, cx, cy + R + 20, T.muted, 1, [4, 4]);
        D.text(g, '线圈（正视，绕虚线转动）', cx, cy + R + 34, T.muted, { align: 'center', size: 11 });
        const Phi = p.B * p.S * Math.cos(th), e = Em * Math.sin(th);
        const ts = [...Array(200).keys()].map(i => t - 2 / p.f + i * (2 / p.f) / 199);
        const gx = c.w * 0.52, gw = c.w - gx - 20, gh = c.h * 0.4 - 30;
        D.chart(g, gx, 20, gw, gh, [{ pts: ts.map(x => [x, p.B * p.S * Math.cos(w * x)]), color: T.c3, w: 2 }], { title: '磁通量 Φ − t（Wb）', xmin: ts[0], xmax: t, ymin: -p.B * p.S * 1.2, ymax: p.B * p.S * 1.2 });
        D.chart(g, gx, gh + 50, gw, gh, [{ pts: ts.map(x => [x, Em * Math.sin(w * x)]), color: T.c2, w: 2 }], { title: '电动势 e − t（V）', xl: 't / s', xmin: ts[0], xmax: t, ymin: -Em * 1.2, ymax: Em * 1.2 });
        const ph = ((th % TAU) + TAU) % TAU, nearN = Math.abs(Math.sin(ph)) < 0.08;
        rows = [['峰值 Eₘ = NBSω', fmt(Em, 3) + ' V'], ['有效值 Eₘ/√2', fmt(Em / Math.SQRT2, 3) + ' V'], ['周期 T', fmt(1 / p.f, 3) + ' s'], ['瞬时 Φ', fmt(Phi, 4) + ' Wb'], ['瞬时 e', fmt(e, 3) + ' V'], ['位置', nearN ? '中性面附近' : Math.abs(Math.cos(ph)) < 0.08 ? '与磁感线平行' : '—']];
        D.text(g, `e = ${fmt(Em, 2)} sin(${fmt(w, 2)}t) V`, 16, c.h - 16, T.fg, { mono: true });
      }
      if (m === 'tr') {
        const U2 = p.U1 * p.n2 / p.n1, I2 = U2 / p.RL, I1 = I2 * p.n2 / p.n1, cx = c.w / 2, cy = c.h * 0.42, cw = Math.min(260, c.w * 0.4), ch = Math.min(200, c.h * 0.5);
        D.rect(g, cx - cw / 2, cy - ch / 2, cw, ch, null, T.muted, 22); D.rect(g, cx - cw / 2, cy - ch / 2, cw, ch, null, T.stage, 0);
        const coil = (x, n, col) => { const k = Math.max(3, Math.min(24, Math.round(n / 60))); for (let i = 0; i < k; i++) { const y = cy - ch * 0.35 + i * ch * 0.7 / (k - 1 || 1); D.line(g, x - 18, y, x + 18, y + 3, col, 2.2); } return k; };
        coil(cx - cw / 2, p.n1, T.c1); coil(cx + cw / 2, p.n2, T.c2);
        wire(g, [[cx - cw / 2 - 18, cy - ch * 0.35], [cx - cw / 2 - 80, cy - ch * 0.35], [cx - cw / 2 - 80, cy + ch * 0.35], [cx - cw / 2 - 18, cy + ch * 0.35]]);
        D.circle(g, cx - cw / 2 - 80, cy, 14, T.stage, T.fg); D.text(g, '~', cx - cw / 2 - 80, cy, T.fg, { align: 'center', size: 18 });
        wire(g, [[cx + cw / 2 + 18, cy - ch * 0.35], [cx + cw / 2 + 80, cy - ch * 0.35], [cx + cw / 2 + 80, cy + ch * 0.35], [cx + cw / 2 + 18, cy + ch * 0.35]]);
        D.rect(g, cx + cw / 2 + 70, cy - 22, 20, 44, T.stage, T.c4, 2); D.text(g, 'R', cx + cw / 2 + 96, cy, T.fg);
        D.text(g, `n₁ = ${p.n1}`, cx - cw / 2, cy + ch / 2 + 26, T.c1, { align: 'center' }); D.text(g, `n₂ = ${p.n2}`, cx + cw / 2, cy + ch / 2 + 26, T.c2, { align: 'center' });
        rows = [['变压比 n₁ : n₂', `${p.n1} : ${p.n2}`], ['类型', p.n2 > p.n1 ? '升压变压器' : p.n2 < p.n1 ? '降压变压器' : '1 : 1'], ['副线圈电压 U₂', fmt(U2, 3) + ' V'], ['副线圈电流 I₂', fmt(I2, 3) + ' A'], ['原线圈电流 I₁', fmt(I1, 4) + ' A'], ['输入功率 = 输出功率', fmt(U2 * I2, 3) + ' W']];
      }
      if (m === 'tx') {
        const P = p.P * 1e3, U = p.Ut * 1e3, I = P / U, loss = I * I * p.r, eta = 1 - loss / P;
        const Us = [...Array(100).keys()].map(i => 1 + i * 5);
        const chh = D.chart(g, 60, 40, c.w - 100, c.h - 100, [{ pts: Us.map(u => [u, Math.min(100, (P / (u * 1e3)) ** 2 * p.r / P * 100)]), color: T.c2, w: 2.2 }], { title: '损耗占输送功率的百分比（%）', xl: '输电电压 / kV', xmin: 1, xmax: 500, ymin: 0, ymax: 100 });
        D.circle(g, chh.X(p.Ut), chh.Y(Math.min(100, loss / P * 100)), 6, T.c1);
        rows = [['输电电流 I = P/U', fmt(I, 3) + ' A'], ['线路损耗 I²r', fmt(loss / 1e3, 4) + ' kW'], ['线路压降 Ir', fmt(I * p.r, 2) + ' V'], ['输电效率', eta > 0 ? fmt(eta * 100, 3) + ' %' : '损耗超过输送功率'], ['电压升高 10 倍后损耗', fmt(loss / 100 / 1e3, 5) + ' kW']];
      }
      out.set(rows);
      if (hist.length > 10) hist.shift();
    });
  }
});

/* ---------- 带电粒子在电磁场中的运动 ---------- */
Lab.reg({
  id: 'p-charge', subj: 'phys', book: 4, unit: '安培力与洛伦兹力', title: '带电粒子在电场和磁场中的运动', kw: '洛伦兹力 示波管 偏转 圆周运动 速度选择器 质谱仪 回旋加速器 加速电场',
  info: `<p class="fb">电场中偏转（类平抛）：a = qU/(md)，飞出时偏移 y = qUL²/(2mdv₀²)<br>洛伦兹力 F = qvB，匀强磁场中做匀速圆周运动：r = mv/(qB)，T = 2πm/(qB)（与速度无关）<br>速度选择器：qE = qvB，只有 v = E/B 的粒子沿直线通过<br>质谱仪：先经电压 U 加速，r = (1/B)√(2mU/q)，不同质量落点不同<br>回旋加速器：交变电压频率 f = qB/(2πm)，最大动能 Eₖ = q²B²R²/(2m)，与加速电压无关</p>`,
  tasks: ['偏转模式：找出电子恰好打在极板边缘时的偏转电压。', '磁场模式：只改变速度，粒子在磁场中运动的时间变吗？', '速度选择器：让 E 加倍，要让同一粒子仍直线通过，B 应怎样调？', '回旋加速器：减小加速电压，粒子最终动能变吗？加速次数呢？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.select('', [['def', '电场中的加速与偏转'], ['mag', '匀强磁场中的圆周运动'], ['sel', '速度选择器'], ['ms', '质谱仪'], ['cyc', '回旋加速器']], 'def', () => { sync(); reset(); });
    const p = L.params({
      U: ['偏转电压 U', 0, 400, 5, 120, 'V'], v0: ['入射速度 v₀', 0.5, 4, 0.05, 1.5, '×10⁷ m/s'],
      B: ['磁感应强度 B', 0.2, 5, 0.05, 1.5, 'mT'], th: ['入射方向与边界夹角', 10, 170, 1, 90, '°'], sg: ['粒子电性', -1, 1, 2, -1, '', 0],
      E: ['电场强度 E', 1, 40, 0.5, 15, '×10³ V/m'], Bs: ['B（选择器）', 0.5, 5, 0.05, 1, 'mT'],
      Ua: ['加速电压 U', 100, 2000, 50, 1000, 'V'], Bm: ['B（质谱仪）', 0.05, 0.5, 0.01, 0.2, 'T'],
      Uc: ['D 形盒间电压', 0.2, 3, 0.1, 1, '×相对'], Rc: ['D 形盒半径', 0.5, 1, 0.05, 0.9, '×相对']
    }, () => reset());
    const out = L.out();
    let path = [], tAnim = 0, extra = {};
    const qe = 1.602e-19, me = 9.109e-31, u = 1.6605e-27;
    function sync() { const m = mode.v, show = { def: ['U', 'v0'], mag: ['B', 'v0', 'th', 'sg'], sel: ['E', 'Bs'], ms: ['Ua', 'Bm'], cyc: ['Uc', 'Rc'] }[m]; ['U', 'v0', 'B', 'th', 'sg', 'E', 'Bs', 'Ua', 'Bm', 'Uc', 'Rc'].forEach(k => p['$' + k].el.hidden = !show.includes(k)); }
    function reset() { tAnim = 0; compute(); L.draw(); }
    function compute() {
      const m = mode.v; path = []; extra = {};
      if (m === 'def') { // 电子，极板长 5 cm，间距 2 cm，屏距板右端 10 cm
        const Lp = 0.05, d = 0.02, Ls = 0.10, v0 = p.v0 * 1e7, a = qe * p.U / (me * d), tL = Lp / v0;
        let hit = null; for (let i = 0; i <= 60; i++) { const t = tL * i / 60, y = 0.5 * a * t * t; if (y > d / 2) { hit = [v0 * t, d / 2]; break; } path.push([v0 * t, y]); }
        if (!hit) { const y1 = 0.5 * a * tL * tL, vy = a * tL; for (let i = 1; i <= 40; i++) { const t = Ls / v0 * i / 40; path.push([Lp + v0 * t, y1 + vy * t]); } extra = { y1, Y: y1 + vy * Ls / v0, ang: Math.atan(vy / v0) }; }
        else { path.push(hit); extra = { hit: true }; }
        extra.Lp = Lp; extra.d = d; extra.Ls = Ls;
      }
      if (m === 'mag') { // 电子或正电子，磁场在 x>0 区域，垂直纸面向里
        const q = p.sg * qe, v = p.v0 * 1e7, B = p.B * 1e-3, r = me * v / (Math.abs(q) * B), ang = p.th * PI / 180;
        let x = 0, y = 0, vx = v * Math.sin(ang), vy = v * Math.cos(ang), dt = 2 * PI * me / (Math.abs(q) * B) / 400;
        path.push([x, y]);
        for (let i = 0; i < 800; i++) { const ax = q / me * (vy * -B) * 1, ay = q / me * (-vx * -B); // v × B，B = (0,0,−B)
          vx += ax * dt; vy += ay * dt; const n = Math.hypot(vx, vy); vx *= v / n; vy *= v / n; x += vx * dt; y += vy * dt; path.push([x, y]); if (x < 0) break; }
        extra = { r, T: 2 * PI * me / (Math.abs(q) * B), frac: (path.length - 1) / 400 };
      }
      if (m === 'sel') { extra.v0 = p.E * 1e3 / (p.Bs * 1e-3); }
      if (m === 'ms') { extra.ions = [12, 13, 14].map(A => { const mm = A * u, v = Math.sqrt(2 * qe * p.Ua / mm); return { A, r: mm * v / (qe * p.Bm), v }; }); }
      if (m === 'cyc') { // 相对单位：qB/m = 1，每次过缝获得动能 Uc
        const R = p.Rc, dU = p.Uc * 0.004; let vv = 0.02, x = 0, y = 0, dir = 1, k = 0; path.push([0, 0]);
        while (k < 400) { const r = vv; const cx = x, cy = y + dir * r; for (let i = 1; i <= 30; i++) { const a = PI * i / 30; path.push([cx + dir * r * Math.sin(a) * 1, cy - dir * r * Math.cos(a)]); }
          x = path[path.length - 1][0]; y = path[path.length - 1][1]; if (r >= R) break; vv = Math.sqrt(vv * vv + 2 * dU); dir = -dir; k++; }
        extra = { passes: k, R };
      }
    }
    sync(); compute();
    L.loop(dt => { tAnim += dt; L.drawFn(); });
    L.onDraw(() => {
      c.clear(); const g = c.g, m = mode.v; let rows = [];
      const dotAlong = (P, X, Y, col, speed = 60) => { const n = Math.min(P.length, Math.floor(tAnim * speed) + 1); D.poly(g, P.slice(0, n).map(q => [X(q[0]), Y(q[1])]), null, col, 2, false); const e = P[n - 1]; if (e) D.circle(g, X(e[0]), Y(e[1]), 5, col, T.stage, 1.5); };
      if (m === 'def') {
        const { Lp, d, Ls } = extra, sc = (c.w - 80) / (Lp + Ls), X = x => 40 + x * sc, Y = y => c.h / 2 - y * sc;
        D.rect(g, X(0), Y(d / 2) - 8, Lp * sc, 8, T.c2); D.rect(g, X(0), Y(-d / 2), Lp * sc, 8, T.c1);
        D.text(g, '+', X(Lp / 2), Y(d / 2) - 18, T.c2, { align: 'center', bold: true }); D.text(g, '−', X(Lp / 2), Y(-d / 2) + 20, T.c1, { align: 'center', bold: true });
        D.line(g, X(Lp + Ls), 20, X(Lp + Ls), c.h - 20, T.fg, 4); D.text(g, '荧光屏', X(Lp + Ls) - 8, 20, T.muted, { align: 'right', size: 11 });
        D.line(g, X(0) - 30, Y(0), X(Lp + Ls), Y(0), T.grid2, 1, [4, 4]);
        dotAlong(path, X, Y, T.c3, 40);
        rows = [['粒子', '电子（向正极板偏转）'], ['极板长 / 间距', '5 cm / 2 cm'], ['飞出偏移 y', extra.hit ? '打在极板上' : fmt(extra.y1 * 100, 3) + ' cm'], ['偏转角', extra.hit ? '—' : fmt(extra.ang * 180 / PI, 2) + '°'], ['屏上偏移', extra.hit ? '—' : fmt(extra.Y * 100, 3) + ' cm'], ['恰好飞出的电压', fmt(me * (p.v0 * 1e7) ** 2 * d * d / (qe * Lp * Lp), 1) + ' V']];
      }
      if (m === 'mag') {
        const r = extra.r, sc = Math.min((c.w - 80) / (2.4 * r), (c.h - 40) / (2.4 * r)), ys = path.map(q => q[1]), yc = (Math.min(...ys) + Math.max(...ys)) / 2, X = x => 40 + x * sc, Y = y => c.h / 2 - (y - yc) * sc;
        D.rect(g, X(0), 0, c.w - X(0), c.h, alpha(T.c1, 0.06)); for (let x = X(0) + 20; x < c.w; x += 32) for (let y = 16; y < c.h; y += 32) D.text(g, '×', x, y, alpha(T.muted, 0.6), { align: 'center' });
        D.line(g, X(0), 0, X(0), c.h, T.fg, 1.5);
        dotAlong(path, X, Y, p.sg > 0 ? T.c2 : T.c3, 120);
        const chord = path.length > 1 ? Math.hypot(path[path.length - 1][0], path[path.length - 1][1]) : 0;
        rows = [['粒子', p.sg > 0 ? '正电子（+e）' : '电子（−e）'], ['半径 r = mv/(qB)', fmt(r * 100, 3) + ' cm'], ['周期 T = 2πm/(qB)', sci(extra.T, 3) + ' s'], ['在磁场中转过', fmt(extra.frac * 360, 1) + '°'], ['在磁场中的时间', sci(extra.frac * extra.T, 3) + ' s'], ['出射点与入射点距离', fmt(chord * 100, 3) + ' cm']];
      }
      if (m === 'sel') {
        const x0 = 40, x1 = c.w - 40, yt = c.h / 2 - 50, yb = c.h / 2 + 50, Ev = p.E * 1e3, Bv = p.Bs * 1e-3, v0 = extra.v0;
        D.rect(g, x0 + 60, yt - 8, x1 - x0 - 120, 8, T.c2); D.rect(g, x0 + 60, yb, x1 - x0 - 120, 8, T.c1);
        for (let x = x0 + 80; x < x1 - 60; x += 32) { D.text(g, '×', x, c.h / 2 - 25, alpha(T.muted, 0.7), { align: 'center' }); D.text(g, '×', x, c.h / 2 + 25, alpha(T.muted, 0.7), { align: 'center' }); }
        D.rect(g, x1 - 50, c.h / 2 - 50, 6, 44, T.fg); D.rect(g, x1 - 50, c.h / 2 + 6, 6, 44, T.fg);
        [0.6, 0.8, 1, 1.25, 1.6].forEach((k, i) => { // 质子，无量纲：板长 1，E/B = 1，qE/m = K（放大偏转便于观察）
          const K = 0.8, sc = (x1 - x0 - 120), pts = []; let x = 0, y = 0, vx = k, vy = 0; const dt = 1 / k / 300;
          for (let j = 0; j < 600 && x < 1; j++) { const ax = -K * vy, ay = -K + K * vx; vx += ax * dt; vy += ay * dt; x += vx * dt; y += vy * dt; pts.push([x0 + 60 + x * sc, c.h / 2 - y * sc]); if (Math.abs(y * sc) > 50) break; }
          D.poly(g, [[x0, c.h / 2], ...pts], null, T.c[i], k === 1 ? 2.6 : 1.4, false);
          const e = pts[pts.length - 1]; D.text(g, `${k}v₀`, e[0] + 6, e[1], T.c[i], { size: 11 });
        });
        void Ev; void Bv;
        rows = [['粒子', '质子（多种速度）'], ['可通过的速度 v = E/B', sci(v0, 3) + ' m/s'], ['电场力方向', '向下'], ['洛伦兹力方向（v 向右）', '向上'], ['说明', '速度大于 E/B 的向洛伦兹力方向偏，小于的向电场力方向偏']];
      }
      if (m === 'ms') {
        const ions = extra.ions, rmax = Math.max(...ions.map(i => i.r)), sc = Math.min((c.w - 120) / (2 * rmax), (c.h - 120) / rmax), ox = 60, oy = 60;
        D.rect(g, 0, oy, c.w, c.h - oy, alpha(T.c1, 0.06)); D.line(g, 0, oy, c.w, oy, T.fg, 3);
        D.text(g, `加速电场 U = ${p.Ua} V`, ox + 10, 24, T.muted, { size: 12 }); D.line(g, ox - 10, 8, ox - 10, oy - 6, T.fg, 2); D.line(g, ox + 10, 8, ox + 10, oy - 6, T.fg, 2);
        ions.forEach((ion, i) => { const pts = []; for (let k = 0; k <= 60; k++) { const a = PI * k / 60; pts.push([ox + ion.r * sc * (1 - Math.cos(a)), oy + ion.r * sc * Math.sin(a)]); } const n = Math.min(61, Math.floor(tAnim * 30) + 1); D.poly(g, pts.slice(0, n), null, T.c[i + 1], 2, false); D.circle(g, ox + 2 * ion.r * sc, oy, 4, T.c[i + 1]); D.text(g, `¹${['²', '³', '⁴'][i]}C⁺`, ox + 2 * ion.r * sc, oy - 14, T.c[i + 1], { align: 'center', size: 12 }); });
        rows = ions.map(i => [`¹${['²', '³', '⁴'][i.A - 12]}C⁺ 半径`, fmt(i.r * 100, 3) + ' cm']); rows.push(['落点间距（12→13）', fmt(2 * (ions[1].r - ions[0].r) * 100, 3) + ' cm'], ['规律', 'r ∝ √m，质量越大半径越大']);
      }
      if (m === 'cyc') {
        const sc = Math.min(c.w, c.h) * 0.45, cx = c.w / 2, cy = c.h / 2, R = extra.R * sc, gap = 6;
        g.fillStyle = alpha(T.c1, 0.12); g.beginPath(); g.arc(cx - gap, cy, R, PI / 2, PI * 1.5); g.fill(); g.beginPath(); g.arc(cx + gap, cy, R, -PI / 2, PI / 2); g.fill();
        g.strokeStyle = T.fg; g.lineWidth = 1.5; g.beginPath(); g.arc(cx - gap, cy, R, PI / 2, PI * 1.5); g.closePath(); g.stroke(); g.beginPath(); g.arc(cx + gap, cy, R, -PI / 2, PI / 2); g.closePath(); g.stroke();
        const ys = path.map(q => q[1]), yc = (Math.min(...ys) + Math.max(...ys)) / 2;
        dotAlong(path, x => cx + x * sc, y => cy + (y - yc) * sc, T.c2, 240);
        rows = [['加速次数（过缝）', extra.passes], ['交变电压频率', 'f = qB/(2πm)，与回旋频率相同'], ['最大动能', 'Eₖ = q²B²R²/(2m)'], ['现象', '电压越小，加速次数越多，但最终动能不变']];
      }
      out.set(rows);
    });
  }
});

/* ---------- 气体实验定律 ---------- */
Lab.reg({
  id: 'p-gas', subj: 'phys', book: 5, unit: '气体、固体和液体', title: '气体实验定律与分子运动', kw: '玻意耳定律 查理定律 盖-吕萨克定律 理想气体状态方程 等温 等压 等容 p-V 图',
  info: `<p class="fb">玻意耳定律（等温）pV = C　查理定律（等容）p/T = C　盖-吕萨克定律（等压）V/T = C<br>理想气体状态方程 pV/T = C</p>
  <p>微观解释：温度越高分子平均动能越大，撞击器壁越猛烈；体积越小单位体积分子数越多，单位时间撞击次数越多。两者都会使压强增大。</p>
  <p>p − V 图中的虚线是不同温度的等温线（双曲线），温度越高越远离原点。</p>`,
  tasks: ['等温压缩到一半体积，压强变为多少？分子运动快慢变吗？', '等容加热从 27 ℃ 到 127 ℃，压强变为原来的几倍？', '在 p − V 图上依次做等压膨胀、等容降温，画出一个循环。'],
  init(L) {
    const c = L.canvas(), N = 70, nR = 1 * 1 / 300; // p(atm)·V(L)/T(K)
    L.group('过程');
    const mode = L.seg('', [['T', '等温'], ['p', '等压'], ['V', '等容']], 'T', () => { trace = [[st.V, st.p]]; sync(); });
    const sV = L.slider('体积 V', 0.3, 3, 0.01, 1, v => { if (mode.v === 'T') { st.V = v; st.p = nR * st.T / v; } push(); }, 'L');
    const sT = L.slider('温度 T', 100, 900, 1, 300, v => { const r = Math.sqrt(v / st.T); parts.forEach(q => { q.vx *= r; q.vy *= r; }); st.T = v; if (mode.v === 'p') { st.V = nR * v / st.p; sV.set(st.V, true); } else st.p = nR * v / st.V; push(); }, v => `${v} K（${v - 273} ℃）`);
    L.button('清除轨迹', () => { trace = [[st.V, st.p]]; L.draw(); }); L.button('恢复初态', () => { st = { V: 1, T: 300, p: 1 }; sV.set(1, true); sT.set(300, true); initParts(); trace = [[1, 1]]; L.draw(); });
    const out = L.out();
    let st = { V: 1, T: 300, p: 1 }, trace = [[1, 1]], parts = [];
    function sync() { sV.el.hidden = mode.v !== 'T'; sT.el.hidden = mode.v === 'T'; }
    function push() { trace.push([st.V, st.p]); if (trace.length > 2000) trace.shift(); }
    function initParts() { parts = [...Array(N)].map(() => { const sp = Math.sqrt(st.T / 300) * 120 * Math.sqrt(-2 * Math.log(Math.random() || 1e-9)) * 0.8, a = rnd(0, TAU); return { x: rnd(0, 1), y: rnd(0, 1), vx: sp * Math.cos(a), vy: sp * Math.sin(a) }; }); }
    sync(); initParts();
    let hits = 0, hitRate = 0, acc = 0;
    L.loop(dt => {
      const bw = 160, bh = st.V / 3 * (c.h - 80);
      for (const q of parts) {
        q.x += q.vx * dt / bw; q.y += q.vy * dt / bh;
        if (q.x < 0) { q.x = -q.x; q.vx = -q.vx; } if (q.x > 1) { q.x = 2 - q.x; q.vx = -q.vx; }
        if (q.y < 0) { q.y = -q.y; q.vy = -q.vy; hits += Math.abs(q.vy); } if (q.y > 1) { q.y = 2 - q.y; q.vy = -q.vy; }
      }
      acc += dt; if (acc > 0.5) { hitRate = hits / acc; hits = 0; acc = 0; }
      L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, bx = 40, bw = 160, by = c.h - 40, bh = st.V / 3 * (c.h - 80);
      D.rect(g, bx - 4, 30, bw + 8, by - 30 + 4, null, T.fg, 2); D.rect(g, bx, by - bh - 14, bw, 14, T.muted); D.rect(g, bx + bw / 2 - 5, 30, 10, by - bh - 44, T.muted);
      D.rect(g, bx, by - bh, bw, bh, alpha(T.c2, Math.min(0.25, (st.T - 100) / 3200)));
      parts.forEach(q => D.circle(g, bx + q.x * bw, by - q.y * bh, 3, T.c1));
      const gx = bx + bw + 60, gw = c.w - gx - 20;
      if (gw > 120) {
        const gh = (c.h - 80) / (mode.v === 'T' ? 1 : 2) - (mode.v === 'T' ? 0 : 20);
        const ch = D.chart(g, gx, 30, gw, gh, [], { title: 'p − V 图（atm, L）', xl: 'V', xmin: 0, xmax: 3.2, ymin: 0, ymax: 4 });
        [200, 300, 450, 600, 900].forEach(TT => { g.strokeStyle = alpha(T.muted, 0.5); g.setLineDash([3, 4]); g.beginPath(); for (let V = 0.15; V <= 3.2; V += 0.02) { const pp = nR * TT / V; if (pp > 4) continue; const X = ch.X(V), Y = ch.Y(pp); V < 0.16 || g.lineTo === null ? g.moveTo(X, Y) : g.lineTo(X, Y); } g.stroke(); g.setLineDash([]); D.text(g, TT + 'K', ch.X(Math.min(3.1, nR * TT / 0.5 > 4 ? 3.1 : 3.1)), ch.Y(nR * TT / 3.1), T.muted, { size: 10 }); });
        g.strokeStyle = T.c2; g.lineWidth = 2.2; g.beginPath(); trace.forEach((q, i) => { const X = ch.X(q[0]), Y = ch.Y(Math.min(q[1], 4)); i ? g.lineTo(X, Y) : g.moveTo(X, Y); }); g.stroke();
        D.circle(g, ch.X(st.V), ch.Y(Math.min(st.p, 4)), 5, T.c2);
        if (mode.v !== 'T') {
          const isP = mode.v === 'p', yv = isP ? st.V : st.p, mx = isP ? 3.2 : 4;
          const ch2 = D.chart(g, gx, 30 + gh + 40, gw, gh, [{ pts: [[-273, 0], [627, nR * 900 / (isP ? st.p : st.V)]], color: alpha(T.muted, 0.7), dash: [4, 4], w: 1.2 }], { title: (isP ? 'V − t 图（L, ℃）' : 'p − t 图（atm, ℃）'), xl: 't / ℃', xmin: -273, xmax: 627, ymin: 0, ymax: mx });
          D.circle(g, ch2.X(st.T - 273), ch2.Y(Math.min(yv, mx)), 5, T.c2); D.text(g, '−273 ℃', ch2.X(-273) + 2, ch2.Y(0) - 10, T.muted, { size: 10 });
        }
      }
      out.set([['压强 p', fmt(st.p, 4) + ' atm'], ['体积 V', fmt(st.V, 4) + ' L'], ['温度 T', st.T + ' K'], ['pV/T', fmt(st.p * st.V / st.T * 300, 4) + ' / 300'], ['分子平均速率（相对 300 K）', fmt(Math.sqrt(st.T / 300), 3)], ['单位体积分子数（相对）', fmt(1 / st.V, 3)]]);
      void hitRate;
    });
  }
});

/* ---------- 光电效应 ---------- */
Lab.reg({
  id: 'p-photo', subj: 'phys', book: 5, unit: '原子结构和波粒二象性', title: '光电效应', kw: '光电效应 逸出功 截止频率 遏止电压 饱和电流 爱因斯坦光电效应方程 光子',
  info: `<p class="fb">光子能量 ε = hν　h = 6.63×10⁻³⁴ J·s<br>爱因斯坦光电效应方程 Eₖ = hν − W₀<br>遏止电压 eU_c = Eₖ　截止频率 ν_c = W₀/h</p>
  <p>能否发生光电效应只取决于光的频率，与光强无关；光强只决定单位时间内逸出的光电子数，也就是饱和电流的大小。Eₖ − ν 图像是一条斜率为 h 的直线，横截距是截止频率。</p>`,
  tasks: ['用钠做阴极，从红光开始减小波长，在多少纳米时开始有光电子？', '保持频率不变，只增大光强，遏止电压变吗？饱和电流呢？', '比较不同金属的 Eₖ − ν 图线，它们的斜率有什么共同点？'],
  init(L) {
    const c = L.canvas(), metals = [['2.13', '铷 Rb 2.13 eV'], ['2.25', '钾 K 2.25 eV'], ['2.29', '钠 Na 2.29 eV'], ['3.20', '钙 Ca 3.20 eV'], ['4.54', '钨 W 4.54 eV']];
    const mt = L.select('阴极金属（逸出功）', metals, '2.29', () => L.draw());
    const p = L.params({ lam: ['入射光波长 λ', 200, 700, 1, 400, 'nm'], I: ['光强', 0, 100, 1, 60, '%'], U: ['两极电压 U（阳极 − 阴极）', -4, 4, 0.05, 1, 'V'] });
    const out = L.out();
    let els = [], acc = 0;
    L.loop(dt => {
      const W = +mt.v, E = 1240 / p.lam, Ek = E - W;
      acc += dt * p.I * 0.6;
      while (acc > 1) { acc--; if (Ek > 0) { const e = Ek * Math.random(); els.push({ x: 0, y: rnd(0.15, 0.85), v: Math.sqrt(e) * 1.2 + 0.05, vy: rnd(-0.1, 0.1) }); } }
      els.forEach(e => { e.v += p.U * 0.5 * dt; e.x += e.v * dt * 0.8; e.y += e.vy * dt; });
      els = els.filter(e => e.x >= 0 && e.x <= 1 && e.y > 0 && e.y < 1);
      L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, W = +mt.v, E = 1240 / p.lam, Ek = E - W, Uc = Math.max(0, Ek), Isat = p.I / 100 * 10;
      const cur = U => { if (Ek <= 0) return 0; if (U >= 0) return Isat * (1 - 0.3 * Math.exp(-3 * U)); return U <= -Uc ? 0 : Isat * 0.7 * (1 - (-U) / Uc) ** 1.5; };
      const tx = 40, tw = Math.min(c.w * 0.45, 360), ty = 40, th = c.h * 0.42;
      D.rrect(g, tx, ty, tw, th, 40, alpha(T.muted, 0.06), T.fg, 1.5);
      const cx = tx + 40, ax = tx + tw - 40;
      D.rect(g, cx - 6, ty + 20, 10, th - 40, T.c1); D.rect(g, ax - 4, ty + 20, 10, th - 40, T.c2);
      D.text(g, 'K 阴极', cx, ty + th + 14, T.c1, { align: 'center', size: 11 }); D.text(g, 'A 阳极', ax, ty + th + 14, T.c2, { align: 'center', size: 11 });
      const col = waveCSS(p.lam, 0.9);
      for (let k = 0; k < Math.round(p.I / 20); k++) { const y = ty + 30 + k * 20; g.strokeStyle = col; g.lineWidth = 1.6; g.beginPath(); for (let x = 0; x < 70; x += 2) g.lineTo(cx - 80 + x + 6, y - 30 + x * 0.5 + Math.sin(x * 0.6) * 3); g.stroke(); }
      D.text(g, p.lam < 380 ? '紫外线' : '', cx - 70, ty + 12, T.muted, { size: 11 });
      els.forEach(e => D.circle(g, cx + e.x * (ax - cx), ty + 20 + e.y * (th - 40), 2.5, T.c3));
      const gx = tx + tw + 50, gw = c.w - gx - 20;
      if (gw > 140) {
        const Us = [...Array(161).keys()].map(i => -4 + i * 0.05);
        const ch = D.chart(g, gx, 30, gw, c.h * 0.42 - 20, [{ pts: Us.map(u => [u, cur(u)]), color: T.c1, w: 2.2 }], { title: 'I − U 曲线（相对）', xl: 'U / V', xmin: -4, xmax: 4, ymin: 0, ymax: 11 });
        D.circle(g, ch.X(p.U), ch.Y(cur(p.U)), 5, T.c2); D.line(g, ch.X(0), 30, ch.X(0), 30 + c.h * 0.42 - 20, T.grid2, 1);
      }
      const nus = [0, 15], ch2 = D.chart(g, 40, c.h * 0.58, c.w - 80, c.h * 0.38, metals.map(([w2], i) => ({ pts: nus.map(n => [n, Math.max(-5, 4.1357 * n / 10 - +w2)]), color: +w2 === W ? T.c2 : alpha(T.muted, 0.6), w: +w2 === W ? 2.4 : 1.2 })), { title: 'Eₖ − ν 图像（eV，×10¹⁴ Hz）', xl: 'ν', xmin: 0, xmax: 15, ymin: -5, ymax: 4 });
      const nu = 3e8 / (p.lam * 1e-9) / 1e14; D.circle(g, ch2.X(nu), ch2.Y(Math.max(-5, Ek)), 5, T.c2);
      out.set([['光子能量 hν', fmt(E, 3) + ' eV'], ['频率 ν', fmt(nu, 3) + '×10¹⁴ Hz'], ['截止频率 ν_c', fmt(W / 4.1357 * 10, 3) + '×10¹⁴ Hz'], ['截止波长', fmt(1240 / W, 1) + ' nm'], ['最大初动能 Eₖ', Ek > 0 ? fmt(Ek, 3) + ' eV' : '不发生光电效应'], ['遏止电压 U_c', Ek > 0 ? fmt(Uc, 3) + ' V' : '—'], ['当前光电流（相对）', fmt(cur(p.U), 3)]]);
    });
  }
});

/* ---------- 氢原子能级 ---------- */
Lab.reg({
  id: 'p-bohr', subj: 'phys', book: 5, unit: '原子结构和波粒二象性', title: '氢原子能级跃迁与光谱', kw: '玻尔模型 能级 跃迁 光谱 巴耳末系 电离 光子',
  info: `<p class="fb">Eₙ = E₁/n²，E₁ = −13.6 eV　轨道半径 rₙ = n²r₁<br>跃迁放出（吸收）光子：hν = E_m − E_n　λ = hc/ΔE ≈ 1240/ΔE（nm，ΔE 以 eV 为单位）<br>一群处于第 n 能级的氢原子向低能级跃迁，最多可发出 Cₙ² 种频率的光</p>
  <p>跃迁到 n = 1 的谱线属于赖曼系（紫外），到 n = 2 的属于巴耳末系（其中 4 条在可见光区），到 n = 3 的属于帕邢系（红外）。</p>`,
  tasks: ['从 n = 3 跃迁到 n = 2，放出光子的波长是多少？是什么颜色？', '一群处于 n = 4 的原子，最多能发出几种光？其中能量最大的是哪一条？', '用 12.09 eV 的光子照射基态氢原子，它能跃迁到第几能级？'],
  init(L) {
    const c = L.canvas(), E = n => -13.6 / (n * n);
    const p = L.params({ hi: ['初态 n（高能级）', 2, 7, 1, 3], lo: ['末态 n（低能级）', 1, 6, 1, 2] }, () => { if (p.lo >= p.hi) p.$lo.set(p.hi - 1, true); t0 = performance.now(); L.draw(); });
    const all = L.check(`显示一群原子的全部谱线`, false);
    const out = L.out();
    let t0 = performance.now();
    L.loop(() => L.drawFn());
    L.onDraw(() => {
      c.clear(); const g = c.g, lx = 50, lw = Math.min(c.w * 0.45, 360), top = 30, H = c.h - 140, Y = e => top + (e / -13.6) * H * 0.98 + 0 * H;
      const YY = e => top + H - (e + 13.6) / 13.6 * H;
      for (let n = 1; n <= 7; n++) { const y = YY(E(n)); D.line(g, lx, y, lx + lw, y, n === p.hi || n === p.lo ? T.fg : T.grid2, n === p.hi || n === p.lo ? 2 : 1.2); D.text(g, `n=${n}`, lx - 6, y, T.muted, { align: 'right', size: 11 }); D.text(g, fmt(E(n), 2) + ' eV', lx + lw + 6, y, T.muted, { size: 10.5, mono: true }); }
      D.line(g, lx, YY(0), lx + lw, YY(0), T.muted, 1, [4, 3]); D.text(g, 'n=∞  0 eV', lx + lw + 6, YY(0) - 10, T.muted, { size: 10.5 });
      const lines = [];
      if (all.v) { for (let a = 2; a <= p.hi; a++) for (let b = 1; b < a; b++) lines.push([a, b]); } else lines.push([p.hi, p.lo]);
      lines.forEach(([a, b], i) => { const dE = E(a) - E(b), nm = 1240 / dE, x = lx + 30 + (i + 0.5) * (lw - 60) / lines.length; D.arrow(g, x, YY(E(a)), x, YY(E(b)), nm >= 380 && nm <= 750 ? waveCSS(nm) : T.muted, 2.2); });
      // 光谱条
      const sy = c.h - 80, sx0 = 40, sw = c.w - 80, X = nm => sx0 + (nm - 90) / (1900 - 90) * sw;
      for (let nm = 380; nm <= 750; nm += 2) { g.fillStyle = waveCSS(nm, 0.25); g.fillRect(X(nm), sy, X(nm + 2) - X(nm) + 0.5, 28); }
      D.rect(g, sx0, sy, sw, 28, null, T.line, 1);
      for (let a = 2; a <= 7; a++) for (let b = 1; b < a; b++) { const nm = 1240 / (E(a) - E(b)); if (nm > 1900) continue; const on = lines.some(l => l[0] === a && l[1] === b); D.line(g, X(nm), sy, X(nm), sy + 28, on ? (nm >= 380 && nm <= 750 ? waveCSS(nm) : T.fg) : alpha(T.muted, 0.35), on ? 3 : 1); }
      [[100, '赖曼系（紫外）'], [420, '巴耳末系'], [1000, '帕邢系（红外）']].forEach(([nm, t]) => D.text(g, t, X(nm), sy + 42, T.muted, { size: 11 }));
      [100, 400, 700, 1000, 1500, 1875].forEach(nm => D.text(g, nm + 'nm', X(nm), sy - 8, T.muted, { size: 10, align: 'center', mono: true }));
      // 玻尔轨道
      const ox = lx + lw + 130, oy = top + H / 2;
      if (c.w - ox > 120) {
        const rmax = Math.min(c.w - ox - 20, H / 2), r = n => rmax * n * n / 49;
        for (let n = 1; n <= 7; n++) D.circle(g, ox, oy, r(n), null, n === p.hi || n === p.lo ? T.fg : T.grid2, 1);
        D.circle(g, ox, oy, 5, T.c2);
        const tt = (performance.now() - t0) / 1000, cycle = tt % 3, n = cycle < 1.5 ? p.hi : p.lo, ang = tt * 2;
        D.circle(g, ox + r(n) * Math.cos(ang), oy + r(n) * Math.sin(ang), 4, T.c1);
      }
      const [a, b] = [p.hi, p.lo], dE = E(a) - E(b), nm = 1240 / dE;
      out.set([['跃迁', `n=${a} → n=${b}`], ['光子能量 ΔE', fmt(dE, 3) + ' eV'], ['波长 λ', fmt(nm, 1) + ' nm'], ['频率 ν', fmt(3e8 / (nm * 1e-9) / 1e14, 3) + '×10¹⁴ Hz'], ['所属谱系', ['赖曼系', '巴耳末系', '帕邢系', '布拉开系', '普丰德系', '汉弗莱系'][b - 1]], ['区域', nm < 380 ? '紫外' : nm > 750 ? '红外' : '可见光'], [`n=${a} 一群原子谱线数 C(${a},2)`, comb(a, 2)], ['基态电离能', '13.6 eV']]);
      void Y;
    });
  }
});

/* ---------- 放射性衰变与半衰期 ---------- */
Lab.reg({
  id: 'p-decay', subj: 'phys', book: 5, unit: '原子核', title: '放射性衰变与半衰期', kw: '半衰期 α衰变 β衰变 统计规律 核反应方程 质量数 电荷数',
  info: `<p class="fb">剩余原子核数 N = N₀(1/2)^(t/T½)<br>α 衰变：质量数减 4，电荷数减 2　β 衰变：质量数不变，电荷数加 1<br>衰变方程遵循质量数守恒和电荷数守恒</p>
  <p>半衰期是大量原子核衰变的统计规律，由原子核内部决定，与温度、压强、化学状态无关；对少数几个原子核没有意义。可以把原子核数改为 10 个，多做几次观察。</p>`,
  tasks: ['经过 3 个半衰期，剩余原子核占多少？与模拟比较。', '把原子核数设为 16，重复几次，每次到第一个半衰期时剩下的个数都是 8 吗？', '写出铀-238 经过一次 α 衰变和两次 β 衰变后的产物。'],
  init(L) {
    const c = L.canvas(), iso = { c14: ['碳-14', 'β', '5730 年', '¹⁴₆C → ¹⁴₇N + ⁰₋₁e'], u238: ['铀-238', 'α', '4.47×10⁹ 年', '²³⁸₉₂U → ²³⁴₉₀Th + ⁴₂He'], i131: ['碘-131', 'β', '8.02 天', '¹³¹₅₃I → ¹³¹₅₄Xe + ⁰₋₁e'], rn222: ['氡-222', 'α', '3.8 天', '²²²₈₆Rn → ²¹⁸₈₄Po + ⁴₂He'], po210: ['钋-210', 'α', '138 天', '²¹⁰₈₄Po → ²⁰⁶₈₂Pb + ⁴₂He'] };
    const is = L.select('同位素', Object.entries(iso).map(([k, v]) => [k, `${v[0]}（${v[1]} 衰变，T½ = ${v[2]}）`]), 'c14', () => reset());
    const n0 = L.select('原子核数', [['400', '400'], ['100', '100'], ['16', '16'], ['10', '10']], '400', () => reset());
    const Th = L.slider('模拟中的半衰期', 1, 10, 0.5, 3, () => L.draw(), 's');
    L.button('开始 / 暂停', () => run.toggle(), true); L.button('重置', () => reset());
    const out = L.out();
    let nuc = [], t = 0, hist = [];
    function reset() { nuc = new Array(+n0.v).fill(true); t = 0; hist = [[0, nuc.length]]; L.draw(); }
    reset();
    const run = L.loop(dt => {
      const pr = 1 - Math.pow(0.5, dt / Th.v); for (let i = 0; i < nuc.length; i++) if (nuc[i] && Math.random() < pr) nuc[i] = false;
      t += dt; hist.push([t, nuc.filter(Boolean).length]); if (hist.length > 1500) hist = hist.filter((_, i) => i % 2 === 0); L.drawFn();
    }, false);
    L.onDraw(() => {
      c.clear(); const g = c.g, N = nuc.length, side = Math.ceil(Math.sqrt(N)), box = Math.min(c.w * 0.42, c.h - 60), cell = box / side, ox = 30, oy = 30;
      nuc.forEach((a, i) => D.circle(g, ox + (i % side + 0.5) * cell, oy + (Math.floor(i / side) + 0.5) * cell, cell * 0.38, a ? T.c2 : alpha(T.muted, 0.25)));
      const left = nuc.filter(Boolean).length, gx = ox + box + 40, gw = c.w - gx - 20;
      if (gw > 120) {
        const tm = Math.max(Th.v * 5, t), ts = [...Array(101).keys()].map(i => tm * i / 100);
        const ch = D.chart(g, gx, oy, gw, c.h - 2 * oy - 20, [{ pts: ts.map(x => [x, N * 0.5 ** (x / Th.v)]), color: T.muted, dash: [5, 4], w: 1.5 }, { pts: hist, color: T.c2, w: 2.2 }], { title: '剩余原子核数 N − t', xl: 't / s', xmin: 0, xmax: tm, ymin: 0, ymax: N * 1.05 });
        for (let k = 1; k * Th.v <= tm; k++) { const x = ch.X(k * Th.v); D.line(g, x, ch.Y(0), x, ch.Y(N * 0.5 ** k), T.grid2, 1, [2, 3]); D.text(g, `${k}T½`, x, ch.Y(0) + 12, T.muted, { align: 'center', size: 10 }); }
      }
      const I = iso[is.v];
      out.set([['衰变方程', I[3]], ['衰变类型', I[1] + ' 衰变'], ['真实半衰期', I[2]], ['经过时间', fmt(t / Th.v, 2) + ' 个半衰期'], ['剩余（模拟）', `${left} / ${N}`], ['剩余（理论）', fmt(N * 0.5 ** (t / Th.v), 1)]]);
    });
  }
});
