'use strict';
/* ======================= 化学 ======================= */

/* ---------- 元素数据 ---------- */
const EL = (() => {
  const sym = 'H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og'.split(' ');
  const name = Array.from('氢氦锂铍硼碳氮氧氟氖钠镁铝硅磷硫氯氩钾钙钪钛钒铬锰铁钴镍铜锌镓锗砷硒溴氪铷锶钇锆铌钼锝钌铑钯银镉铟锡锑碲碘氙铯钡镧铈镨钕钷钐铕钆铽镝钬铒铥镱镥铪钽钨铼锇铱铂金汞铊铅铋钋砹氡钫镭锕钍镤铀镎钚镅锔锫锎锿镄钔锘铹𬬻𬭊𬭳𬭛𬭶鿏𫟼𬬭鿔鿭𫓧镆𫟷鿬鿫');
  const mass = [1.008, 4.003, 6.941, 9.012, 10.81, 12.01, 14.01, 16.00, 19.00, 20.18, 22.99, 24.31, 26.98, 28.09, 30.97, 32.06, 35.45, 39.95, 39.10, 40.08, 44.96, 47.87, 50.94, 52.00, 54.94, 55.85, 58.93, 58.69, 63.55, 65.38, 69.72, 72.63, 74.92, 78.97, 79.90, 83.80, 85.47, 87.62, 88.91, 91.22, 92.91, 95.95, 98, 101.1, 102.9, 106.4, 107.9, 112.4, 114.8, 118.7, 121.8, 127.6, 126.9, 131.3, 132.9, 137.3, 138.9, 140.1, 140.9, 144.2, 145, 150.4, 152.0, 157.3, 158.9, 162.5, 164.9, 167.3, 168.9, 173.0, 175.0, 178.5, 180.9, 183.8, 186.2, 190.2, 192.2, 195.1, 197.0, 200.6, 204.4, 207.2, 209.0, 209, 210, 222, 223, 226, 227, 232.0, 231.0, 238.0, 237, 244, 243, 247, 247, 251, 252, 257, 258, 259, 262, 267, 268, 269, 270, 277, 278, 281, 282, 285, 286, 289, 290, 293, 294, 294];
  const en = '2.20,,0.98,1.57,2.04,2.55,3.04,3.44,3.98,,0.93,1.31,1.61,1.90,2.19,2.58,3.16,,0.82,1.00,1.36,1.54,1.63,1.66,1.55,1.83,1.88,1.91,1.90,1.65,1.81,2.01,2.18,2.55,2.96,3.00,0.82,0.95,1.22,1.33,1.6,2.16,1.9,2.2,2.28,2.20,1.93,1.69,1.78,1.96,2.05,2.1,2.66,2.6,0.79,0.89,1.10,1.12,1.13,1.14,,1.17,,1.20,,1.22,1.23,1.24,1.25,,1.27,1.3,1.5,2.36,1.9,2.2,2.20,2.28,2.54,2.00,1.62,2.33,2.02,2.0,2.2,,0.7,0.9,1.1,1.3,1.5,1.38,1.36,1.28,1.3,1.3,1.3,1.3,1.3,1.3,1.3,1.3'.split(',').map(x => x ? +x : null);
  const ie = [1312, 2372, 520, 900, 801, 1086, 1402, 1314, 1681, 2081, 496, 738, 578, 787, 1012, 1000, 1251, 1521, 419, 590, 633, 659, 651, 653, 717, 762, 760, 737, 746, 906, 579, 762, 947, 941, 1140, 1351, 403, 550, 600, 640, 652, 684, 702, 710, 720, 804, 731, 868, 558, 709, 834, 869, 1008, 1170, 376, 503];
  const list = sym.map((s, i) => ({ z: i + 1, s, n: name[i], m: mass[i], en: en[i] ?? null, ie: ie[i] ?? null }));
  const by = {}; list.forEach(e => by[e.s] = e);
  return { list, by };
})();
function elCat(z) {
  if ([2, 10, 18, 36, 54, 86, 118].includes(z)) return 'noble';
  if ([9, 17, 35, 53, 85, 117].includes(z)) return 'halogen';
  if ([3, 11, 19, 37, 55, 87].includes(z)) return 'alkali';
  if ([4, 12, 20, 38, 56, 88].includes(z)) return 'alkaline';
  if (z >= 57 && z <= 71) return 'lan'; if (z >= 89 && z <= 103) return 'act';
  if ([5, 14, 32, 33, 51, 52].includes(z)) return 'metalloid';
  if ([1, 6, 7, 8, 15, 16, 34].includes(z)) return 'nonmetal';
  if ([13, 31, 49, 50, 81, 82, 83, 84, 113, 114, 115, 116].includes(z)) return 'post';
  return 'trans';
}
const CAT = { alkali: ['碱金属', 'c2'], alkaline: ['碱土金属', 'c4'], trans: ['过渡金属', 'c1'], post: ['其他金属', 'c5'], metalloid: ['类金属', 'c3'], nonmetal: ['非金属', 'c3'], halogen: ['卤素', 'c6'], noble: ['稀有气体', 'c5'], lan: ['镧系', 'c4'], act: ['锕系', 'c2'] };
function elPos(z) {
  if (z === 1) return [0, 0]; if (z === 2) return [0, 17];
  if (z <= 18) { const p = z <= 10 ? 1 : 2, i = z - (p === 1 ? 2 : 10); return [p, i <= 2 ? i - 1 : i + 9]; }
  if (z <= 54) { const p = z <= 36 ? 3 : 4, i = z - (p === 3 ? 18 : 36); return [p, i - 1]; }
  const p = z <= 86 ? 5 : 6, i = z - (p === 5 ? 54 : 86);
  if (i <= 2) return [p, i - 1]; if (i <= 17) return [p === 5 ? 8 : 9, i - 1]; return [p, i - 15];
}
const GROUPS = ['ⅠA', 'ⅡA', 'ⅢB', 'ⅣB', 'ⅤB', 'ⅥB', 'ⅦB', 'Ⅷ', 'Ⅷ', 'Ⅷ', 'ⅠB', 'ⅡB', 'ⅢA', 'ⅣA', 'ⅤA', 'ⅥA', 'ⅦA', '0'];
const SUBSH = (() => { const a = []; for (let s = 1; s <= 8; s++) for (let l = Math.min(3, s - 1); l >= 0; l--) { const n = s - l; if (n > l) a.push([n, l]); } return a.filter(([n, l]) => n <= 7 && l <= 3 && n + l <= 8); })();
const EXC = { 24: [['4s', -1], ['3d', 1]], 29: [['4s', -1], ['3d', 1]], 41: [['5s', -1], ['4d', 1]], 42: [['5s', -1], ['4d', 1]], 44: [['5s', -1], ['4d', 1]], 45: [['5s', -1], ['4d', 1]], 46: [['5s', -2], ['4d', 2]], 47: [['5s', -1], ['4d', 1]], 57: [['4f', -1], ['5d', 1]], 58: [['4f', -1], ['5d', 1]], 64: [['4f', -1], ['5d', 1]], 78: [['6s', -1], ['5d', 1]], 79: [['6s', -1], ['5d', 1]], 89: [['5f', -1], ['6d', 1]], 90: [['5f', -2], ['6d', 2]], 91: [['5f', -1], ['6d', 1]], 92: [['5f', -1], ['6d', 1]], 93: [['5f', -1], ['6d', 1]], 96: [['5f', -1], ['6d', 1]] };
function elConfig(z) {
  const L = 'spdf', cfg = {}; let left = z;
  for (const [n, l] of SUBSH) { if (left <= 0) break; const k = Math.min(left, 2 * (2 * l + 1)); cfg[n + L[l]] = k; left -= k; }
  (EXC[z] || []).forEach(([k, d]) => { cfg[k] = (cfg[k] || 0) + d; if (!cfg[k]) delete cfg[k]; });
  return Object.entries(cfg).sort((a, b) => a[0][0] - b[0][0] || L.indexOf(a[0][1]) - L.indexOf(b[0][1]));
}
const SUPN = n => String(n).split('').map(ch => '⁰¹²³⁴⁵⁶⁷⁸⁹'[ch] ?? ch).join('');
const SUBN = n => String(n).split('').map(ch => '₀₁₂₃₄₅₆₇₈₉'[ch] ?? ch).join('');

Lab.reg({
  id: 'c-ptable', subj: 'chem', book: 0, unit: '物质结构 元素周期律', title: '元素周期表与原子结构', kw: '元素周期律 电子排布 轨道表示式 原子结构示意图 电负性 电离能 构造原理 价电子',
  info: `<p>点击任一元素，下方显示它的原子结构示意图、电子排布式和（前 36 号元素的）轨道表示式。切换着色方式观察元素性质的周期性变化。</p>
  <p class="fb">构造原理：1s 2s 2p 3s 3p 4s 3d 4p 5s 4d 5p 6s 4f 5d 6p …<br>泡利原理：一个轨道最多容纳 2 个自旋相反的电子　洪特规则：电子优先分占不同轨道且自旋平行<br>半满、全满更稳定：Cr 3d⁵4s¹，Cu 3d¹⁰4s¹</p>
  <p><b>周期律</b>：同周期从左到右，原子半径减小，金属性减弱、非金属性增强，电负性增大；第一电离能总体增大，但 ⅡA &gt; ⅢA、ⅤA &gt; ⅥA（如 Be &gt; B，N &gt; O）。同主族从上到下，金属性增强，电负性和第一电离能减小。</p>`,
  tasks: ['用「第一电离能」着色，找出第二、三周期中两处「反常」，并用电子排布解释。', '比较 K（19）与 Cr（24）、Cu（29）的电子排布，哪两个不符合构造原理的简单填充？', '用「电负性」着色，找出电负性最大的元素和最小的（非放射性）元素。'],
  init(L) {
    const c = L.canvas(); L.tall();
    let sel = 26;
    const color = L.select('着色方式', [['cat', '元素分类'], ['en', '电负性'], ['ie', '第一电离能（1~56 号）'], ['m', '相对原子质量'], ['blk', '分区（s p d f）']], 'cat');
    L.legend(Object.entries(CAT).filter(([k]) => k !== 'nonmetal').map(([k, v]) => [`var(--${v[1]})`, v[0]]));
    const out = L.out();
    let cells = [];
    L.interact(c, { click: (x, y) => { const h = cells.find(q => x >= q[1] && x < q[1] + q[3] && y >= q[2] && y < q[2] + q[3]); if (h) { sel = h[0]; L.draw(); } } });
    const blockOf = z => { if ((z >= 57 && z <= 71) || (z >= 89 && z <= 103)) return 'f'; const col = elPos(z)[1]; return col <= 1 || z === 2 ? 's' : col >= 12 ? 'p' : 'd'; };
    L.onDraw(() => {
      c.clear(); const g = c.g, cell = Math.min((c.w - 30) / 18.3, (c.h * 0.6) / 10.4), ox = (c.w - cell * 18) / 2 + 6, oy = 18;
      cells = [];
      const mode = color.v;
      EL.list.forEach(e => {
        const [r, col] = elPos(e.z), x = ox + col * cell, y = oy + r * cell + (r >= 8 ? cell * 0.35 : 0);
        let fill;
        if (mode === 'cat') { const k = elCat(e.z); fill = alpha(T[CAT[k][1]], k === 'nonmetal' ? 0.18 : 0.45); }
        if (mode === 'en') fill = e.en ? alpha(T.c2, 0.08 + (e.en - 0.7) / 3.3 * 0.85) : alpha(T.muted, 0.08);
        if (mode === 'ie') fill = e.ie ? alpha(T.c1, 0.08 + (e.ie - 370) / 2000 * 0.9) : alpha(T.muted, 0.06);
        if (mode === 'm') fill = alpha(T.c3, 0.08 + e.m / 300 * 0.85);
        if (mode === 'blk') fill = alpha(T[{ s: 'c2', p: 'c4', d: 'c1', f: 'c3' }[blockOf(e.z)]], 0.4);
        D.rect(g, x + 1, y + 1, cell - 2, cell - 2, fill, e.z === sel ? T.fg : null, 2);
        if (cell > 22) { D.text(g, e.z, x + 3, y + 7, T.muted, { size: Math.max(7, cell * 0.2), mono: true }); D.text(g, e.s, x + cell / 2, y + cell * 0.5, T.fg, { align: 'center', bold: true, size: cell * 0.34 }); if (cell > 34) D.text(g, e.n, x + cell / 2, y + cell * 0.8, T.muted, { align: 'center', size: cell * 0.2 }); }
        else D.text(g, e.s, x + cell / 2, y + cell / 2, T.fg, { align: 'center', size: cell * 0.4 });
        cells.push([e.z, x, y, cell]);
      });
      [[5, '57-71'], [6, '89-103']].forEach(([r, t]) => { const x = ox + 2 * cell, y = oy + r * cell; D.rect(g, x + 1, y + 1, cell - 2, cell - 2, alpha(T.muted, 0.1)); D.text(g, t, x + cell / 2, y + cell / 2, T.muted, { align: 'center', size: Math.max(7, cell * 0.2) }); });
      if (cell > 18) { GROUPS.forEach((gn, i) => D.text(g, gn, ox + i * cell + cell / 2, oy - 8, T.muted, { align: 'center', size: Math.max(8, cell * 0.22) })); for (let r = 0; r < 7; r++) D.text(g, r + 1, ox - 8, oy + r * cell + cell / 2, T.muted, { align: 'center', size: 10 }); }
      D.text(g, '镧系', ox + 1.6 * cell, oy + 8.35 * cell + cell / 2, T.muted, { align: 'right', size: 10 }); D.text(g, '锕系', ox + 1.6 * cell, oy + 9.35 * cell + cell / 2, T.muted, { align: 'right', size: 10 });
      // 详情
      const e = EL.list[sel - 1], cfg = elConfig(sel), [r, col] = elPos(sel), period = r >= 8 ? r - 2 : r + 1;
      const shells = []; cfg.forEach(([k, v]) => { const n = +k[0]; shells[n - 1] = (shells[n - 1] || 0) + v; });
      const by0 = oy + 10.6 * cell + 10, bh = c.h - by0 - 10;
      const cfgStr = cfg.map(([k, v]) => k + SUPN(v)).join('');
      if (bh > 80) {
        const R0 = Math.min(26, bh * 0.2), cx = 30 + R0, cy = by0 + bh / 2;
        D.circle(g, cx, cy, R0, alpha(T.c2, 0.15), T.fg, 1.5); D.text(g, '+' + sel, cx, cy, T.fg, { align: 'center', bold: true, size: 13 });
        shells.forEach((n, i) => { const x = cx + R0 + 22 + i * 30; g.strokeStyle = T.fg; g.lineWidth = 1.4; g.beginPath(); g.arc(x - 40, cy, 44, -0.45, 0.45); g.stroke(); D.text(g, n || 0, x + 6, cy, T.fg, { align: 'center', size: 13, mono: true }); });
        D.text(g, '原子结构示意图', 20, by0 + 8, T.muted, { size: 11 });
        const ox2 = cx + R0 + 40 + shells.length * 30 + 20;
        if (sel <= 36 && c.w - ox2 > 200) {
          D.text(g, '轨道表示式', ox2, by0 + 8, T.muted, { size: 11 });
          let x = ox2; const bs = Math.min(20, (c.w - ox2 - 20) / 26), yb = cy - bs / 2;
          cfg.forEach(([k, v]) => {
            const l = 'spdf'.indexOf(k[1]), nb = 2 * l + 1;
            for (let b = 0; b < nb; b++) {
              D.rect(g, x + b * bs, yb, bs, bs, null, T.fg, 1);
              const up = v > b, dn = v > nb + b;
              if (up) D.arrow(g, x + b * bs + bs * 0.35, yb + bs - 3, x + b * bs + bs * 0.35, yb + 3, T.c2, 1.4, 5);
              if (dn) D.arrow(g, x + b * bs + bs * 0.65, yb + 3, x + b * bs + bs * 0.65, yb + bs - 3, T.c1, 1.4, 5);
            }
            D.text(g, k, x + nb * bs / 2, yb + bs + 12, T.muted, { align: 'center', size: 11 }); x += nb * bs + 8;
          });
        } else D.text(g, cfgStr, ox2, cy, T.fg, { size: 14, mono: true });
      }
      const noble = [2, 10, 18, 36, 54, 86].filter(n => n < sel).pop(), core = noble ? `[${EL.list[noble - 1].s}]` : '';
      const coreCfg = noble ? elConfig(noble).map(q => q[0]) : [];
      const short = core + cfg.filter(([k, v]) => !coreCfg.includes(k) || elConfig(noble).find(q => q[0] === k)[1] !== v).map(([k, v]) => k + SUPN(v)).join('');
      const grpNum = r >= 8 ? 'ⅢB（' + (r === 8 ? '镧系' : '锕系') + '）' : GROUPS[col];
      out.set([[`${e.n} ${e.s}`, `Z = ${sel}`], ['相对原子质量', ([43, 61].includes(sel) || sel >= 84) ? `(${e.m})` : e.m], ['位置', `第 ${period} 周期 ${grpNum} 族`], ['分区', blockOf(sel) + ' 区'], ['类别', CAT[elCat(sel)][0]],
        ['电子排布式', cfgStr], ['简化排布式', short], ['各层电子数', shells.map(x => x || 0).join(', ')], ['电负性', e.en ?? '—'], ['第一电离能', e.ie ? e.ie + ' kJ/mol' : '—']]);
    });
  }
});

/* ---------- 方程式配平 ---------- */
function parseFormula(s) {
  s = s.trim(); let charge = 0;
  const cm = s.match(/\^?\(?(\d*)([+-])\)?$/);
  if (s === 'e' || s === 'e-' || s === 'e^-') return { el: {}, charge: -1 };
  if (cm && s.includes('^')) { charge = (cm[2] === '+' ? 1 : -1) * (cm[1] ? +cm[1] : 1); s = s.slice(0, cm.index); }
  s = s.replace(/\^$/, '');
  const total = {};
  for (const part of s.split(/[·.*]/)) {
    let p = part, mult = 1; const lead = p.match(/^(\d+)/); if (lead) { mult = +lead[1]; p = p.slice(lead[1].length); }
    let i = 0;
    function group() {
      const r = {};
      while (i < p.length) {
        const ch = p[i];
        if (ch === '(' || ch === '[') { i++; const inner = group(); if (p[i] !== ')' && p[i] !== ']') throw new Error('括号不匹配：' + part); i++; const n = num(); for (const k in inner) r[k] = (r[k] || 0) + inner[k] * n; }
        else if (ch === ')' || ch === ']') return r;
        else if (/[A-Z]/.test(ch)) { let sy = ch; i++; while (i < p.length && /[a-z]/.test(p[i])) sy += p[i++]; if (!EL.by[sy]) throw new Error('未知元素：' + sy); const n = num(); r[sy] = (r[sy] || 0) + n; }
        else throw new Error(`无法识别「${ch}」`);
      }
      return r;
    }
    function num() { let t = ''; while (i < p.length && /\d/.test(p[i])) t += p[i++]; return t ? +t : 1; }
    const r = group(); if (i < p.length) throw new Error('括号不匹配：' + part);
    for (const k in r) total[k] = (total[k] || 0) + r[k] * mult;
  }
  return { el: total, charge };
}
function molarMass(el) { let m = 0; for (const k in el) m += EL.by[k].m * el[k]; return m; }
function prettyFormula(s) {
  if (/^e\^?-?$/.test(s.trim())) return 'e⁻';
  let charge = '';
  const cm = s.match(/\^\(?(\d*)([+-])\)?$/); if (cm) { charge = (cm[1] || '') + cm[2]; s = s.slice(0, cm.index); }
  return s.replace(/([A-Za-z)\]])(\d+)/g, (_, a, n) => a + `<sub>${n}</sub>`).replace(/[.*]/g, '·') + (charge ? `<sup>${charge.replace('-', '−')}</sup>` : '');
}
function balance(lhs, rhs) {
  const sp = [...lhs, ...rhs].map(parseFormula), keys = [...new Set(sp.flatMap(s => Object.keys(s.el)))];
  const hasCharge = sp.some(s => s.charge); if (hasCharge) keys.push('电荷');
  const rows = keys.map(k => sp.map((s, j) => (k === '电荷' ? s.charge : (s.el[k] || 0)) * (j < lhs.length ? 1 : -1)));
  // 有理数高斯消元
  const F = (n, d = 1) => { if (d < 0) { n = -n; d = -d; } const g0 = gcd(n, d) || 1; return [n / g0, d / g0]; };
  const sub = (a, b) => F(a[0] * b[1] - b[0] * a[1], a[1] * b[1]), mul = (a, b) => F(a[0] * b[0], a[1] * b[1]), div = (a, b) => F(a[0] * b[1], a[1] * b[0]);
  const M = rows.map(r => r.map(x => F(x))), n = sp.length, piv = [];
  let r = 0;
  for (let col = 0; col < n && r < M.length; col++) {
    const k = M.findIndex((row, i) => i >= r && row[col][0] !== 0); if (k < 0) continue;
    [M[r], M[k]] = [M[k], M[r]]; const pv = M[r][col]; M[r] = M[r].map(x => div(x, pv));
    for (let i = 0; i < M.length; i++) if (i !== r && M[i][col][0] !== 0) { const f = M[i][col]; M[i] = M[i].map((x, j) => sub(x, mul(f, M[r][j]))); }
    piv.push(col); r++;
  }
  const free = [...Array(n).keys()].filter(j => !piv.includes(j));
  if (free.length === 0) throw new Error('无法配平：请检查化学式是否正确');
  if (free.length > 1) throw new Error('配平结果不唯一（可能是几个反应的组合），请检查');
  const f = free[0], x = new Array(n).fill(null); x[f] = [1, 1];
  piv.forEach((col, i) => x[col] = F(-M[i][f][0], M[i][f][1]));
  const L2 = x.reduce((l, q) => l * q[1] / gcd(l, q[1]), 1); let ints = x.map(q => q[0] * L2 / q[1]);
  const g2 = ints.reduce((a, b) => gcd(a, b)); ints = ints.map(v => v / g2); if (ints.some(v => v < 0)) ints = ints.map(v => -v);
  if (ints.some(v => v <= 0)) throw new Error('无法得到全为正的系数，请检查反应物与生成物');
  return { coef: ints, sp, keys };
}
Lab.reg({
  id: 'c-eq', subj: 'chem', book: 0, unit: '物质的量 · 化学方程式', title: '化学方程式配平与计量计算', kw: '配平 摩尔质量 物质的量 质量守恒 离子方程式 化学计量数',
  info: `<p>用 <span class="f">=</span> 或 <span class="f">-></span> 分隔反应物和生成物，用 <span class="f">+</span> 分隔各物质。支持括号 <span class="f">Ca(OH)2</span>、结晶水 <span class="f">CuSO4·5H2O</span>（也可写 <span class="f">CuSO4.5H2O</span>）以及离子 <span class="f">Fe^3+</span>、<span class="f">MnO4^-</span>、电子 <span class="f">e</span>。</p>
  <p class="fb">配平依据：反应前后各元素原子个数守恒（离子方程式还要电荷守恒）<br>n = m/M　N = n·N_A　V = n·V_m（标准状况 V_m = 22.4 L/mol）<br>各物质的物质的量之比 = 化学计量数之比</p>`,
  tasks: ['配平 KMnO4 + HCl = KCl + MnCl2 + Cl2 + H2O，并计算 15.8 g KMnO4 能生成多少升 Cl₂（标况）。', '写出离子方程式 MnO4^- + Fe^2+ + H^+ = Mn^2+ + Fe^3+ + H2O 并配平。', '1 mol CuSO4·5H2O 的质量是多少？其中结晶水的质量分数是多少？'],
  init(L) {
    const c = L.canvas();
    L.group('化学方程式');
    let res = null, err = '';
    const inp = L.input('', 'Fe2O3 + CO = Fe + CO2', s => run(s), { ph: '例：Al + O2 = Al2O3' });
    L.select('示例', ['Fe2O3 + CO = Fe + CO2', 'KMnO4 + HCl = KCl + MnCl2 + Cl2 + H2O', 'Cu + HNO3 = Cu(NO3)2 + NO + H2O', 'C6H12O6 + O2 = CO2 + H2O', 'MnO4^- + Fe^2+ + H^+ = Mn^2+ + Fe^3+ + H2O', 'Na2O2 + H2O = NaOH + O2', 'NH3 + O2 = NO + H2O', 'Ca(OH)2 + NH4Cl = CaCl2 + NH3 + H2O', 'CuSO4.5H2O = CuSO4 + H2O'], 'Fe2O3 + CO = Fe + CO2', s => inp.set(s));
    L.group('计量计算');
    const who = L.select('已知物质', [['0', '—']], '0', () => L.draw());
    const amt = L.slider('已知质量', 0.1, 500, 0.1, 16, () => L.draw(), 'g');
    const out = L.out();
    function run(s) {
      try {
        const parts = s.split(/=|->|→|⟶|===/); if (parts.length !== 2) throw new Error('需要一个「=」或「->」分隔两边');
        const lhs2 = splitPlus(parts[0]), rhs2 = splitPlus(parts[1]);
        res = { ...balance(lhs2, rhs2), lhs: lhs2, rhs: rhs2 }; err = ''; inp.err('');
        who.el.innerHTML = ''; [...lhs2, ...rhs2].forEach((f, i) => { if (/^e\^?-?$/.test(f)) return; const o = document.createElement('option'); o.value = i; o.textContent = f; who.el.appendChild(o); });
      } catch (e) { res = null; err = e.message; inp.err(e.message); }
      L.draw();
    }
    function splitPlus(side) { // 「+」既是分隔符也可能是离子电荷，带 ^ 的电荷不拆
      const out = []; let cur = '';
      for (let i = 0; i < side.length; i++) { const ch = side[i]; if (ch === '+' && side[i - 1] !== '^' && !/\^\d*$/.test(cur.trim())) { if (cur.trim()) out.push(cur.trim()); cur = ''; } else cur += ch; }
      if (cur.trim()) out.push(cur.trim()); return out;
    }
    run(inp.v);
    L.onDraw(() => {
      c.clear(); const g = c.g;
      if (!res) { D.text(g, err || '请输入方程式', c.w / 2, c.h / 2, T.bad, { align: 'center', size: 15 }); out.set([]); return; }
      const { coef, sp, lhs, rhs } = res, n = sp.length;
      // 粒子示意：每种物质画 coef 个「分子」方块
      const W = c.w - 40, colW = W / n, top = 30;
      D.text(g, '反应物', 20, 14, T.muted, { size: 12 }); D.text(g, '生成物', 20 + colW * lhs.length + 4, 14, T.muted, { size: 12 });
      sp.forEach((s, i) => {
        const x = 20 + i * colW, els = Object.entries(s.el);
        const name = [...lhs, ...rhs][i];
        D.text(g, (coef[i] > 1 ? coef[i] + ' ' : '') + name, x + colW / 2, top + 6, i < lhs.length ? T.c1 : T.c2, { align: 'center', bold: true, size: 13 });
        let y = top + 30;
        for (let k = 0; k < Math.min(coef[i], 8); k++) {
          let xx = x + 10; const atoms = els.flatMap(([e2, m]) => Array(Math.min(m, 12)).fill(e2));
          atoms.forEach((a, j) => { const col = T.c[EL.by[a].z % 6]; D.circle(g, xx + (j % 8) * 13, y + Math.floor(j / 8) * 13, 6, alpha(col, 0.8)); if (atoms.length < 10) D.text(g, a, xx + (j % 8) * 13, y + Math.floor(j / 8) * 13, T.fg, { align: 'center', size: 7.5 }); });
          y += 16 + Math.floor((atoms.length - 1) / 8) * 13 + 6; if (y > c.h * 0.62) break;
        }
        if (coef[i] > 8) D.text(g, '…', x + colW / 2, y, T.muted, { align: 'center' });
        if (i === lhs.length - 1) D.text(g, '→', x + colW, top + 6, T.fg, { align: 'center', size: 18 });
      });
      // 原子守恒表
      const ty = c.h * 0.68; D.line(g, 20, ty - 12, c.w - 20, ty - 12, T.line, 1);
      D.text(g, '原子守恒核对：', 20, ty, T.muted, { size: 12 });
      res.keys.forEach((k, i) => {
        const l = sp.reduce((s, q, j) => s + (j < lhs.length ? coef[j] * (k === '电荷' ? q.charge : (q.el[k] || 0)) : 0), 0), r = sp.reduce((s, q, j) => s + (j >= lhs.length ? coef[j] * (k === '电荷' ? q.charge : (q.el[k] || 0)) : 0), 0);
        D.text(g, `${k}: ${l} = ${r}`, 20 + (i % 6) * 110, ty + 22 + Math.floor(i / 6) * 20, l === r ? T.ok : T.bad, { mono: true, size: 12 });
      });
      const eq = lhs.map((f, i) => (coef[i] > 1 ? coef[i] : '') + prettyFormula(f)).join(' + ') + ' ══ ' + rhs.map((f, i) => (coef[i + lhs.length] > 1 ? coef[i + lhs.length] : '') + prettyFormula(f)).join(' + ');
      const k0 = +who.v, M0 = molarMass(sp[k0].el), n0 = M0 ? amt.v / M0 : 0;
      const rows = [`<div class="big">${eq}</div>`];
      [...lhs, ...rhs].forEach((f, i) => { if (/^e\^?-?$/.test(f)) return; const M = molarMass(sp[i].el), ni = n0 * coef[i] / coef[k0]; rows.push([`${prettyFormula(f)}　M = ${fmt(M, 2)}`, `${fmt(ni, 4)} mol · ${fmt(ni * M, 3)} g`]); });
      rows.push(['标况下气体体积 = n × 22.4', '对气体适用']);
      out.set(rows);
    });
  }
});

/* ---------- 焰色试验 ---------- */
Lab.reg({
  id: 'c-flame', subj: 'chem', book: 0, unit: '海水中的重要元素——钠和氯', title: '焰色试验', kw: '焰色反应 钠 钾 钴玻璃 金属元素 物理变化',
  info: `<p><b>操作</b>：将铂丝（或光洁无锈的铁丝）用盐酸洗净，在外焰上灼烧至与原火焰颜色相同；蘸取试样在外焰上灼烧，观察火焰颜色；每次实验后都要用盐酸洗净铂丝。</p>
  <p>焰色试验是元素的性质，属于<b>物理变化</b>：金属原子的电子吸收能量跃迁到高能级，回到低能级时以特定波长的光放出。观察钾的焰色要透过<b>蓝色钴玻璃</b>，以滤去钠元素杂质的黄光。</p>`,
  tasks: ['依次观察钠、钾的焰色。为什么观察钾时要用钴玻璃？', '同一种金属的单质和化合物焰色相同吗？', '节日的烟花利用了哪些金属的焰色？'],
  init(L) {
    const c = L.canvas();
    const S = { none: ['（无试样）', '#7fb3ff', 0], Li: ['氯化锂 LiCl', '#e8263f', 671], Na: ['氯化钠 NaCl', '#ffc21a', 589], K: ['氯化钾 KCl', '#b06cff', 404], Ca: ['氯化钙 CaCl₂', '#ff6a2a', 622], Sr: ['氯化锶 SrCl₂', '#ff2050', 650], Ba: ['氯化钡 BaCl₂', '#a6e84a', 524], Cu: ['氯化铜 CuCl₂', '#2ce39a', 515], KNa: ['含少量 Na 的 KCl', '#ffb84d', 589] };
    const s = L.select('试样', Object.entries(S).map(([k, v]) => [k, v[0]]), 'Na', () => L.draw());
    const co = L.check('透过蓝色钴玻璃观察', false);
    const out = L.out();
    let t = 0; L.loop(dt => { t += dt; L.drawFn(); });
    L.onDraw(() => {
      c.clear(); const g = c.g, cx = c.w / 2, by = c.h - 60;
      D.rect(g, cx - 40, by, 80, 40, alpha(T.muted, 0.4), T.fg, 1.5); D.rect(g, cx - 10, by - 30, 20, 30, T.muted);
      let col = S[s.v][1];
      if (co.v) col = s.v === 'K' || s.v === 'KNa' ? '#9a5cff' : s.v === 'Na' ? '#3a3f8a' : '#5a6ad0';
      const fl = (sc, cc, a) => { g.fillStyle = cc; g.globalAlpha = a; g.beginPath(); const h = 220 * sc, w = 46 * sc; g.moveTo(cx - w, by - 30); for (let i = 0; i <= 20; i++) { const yy = by - 30 - h * i / 20, ww = w * Math.sin(PI * (1 - i / 20) * 0.9 + 0.1) * (1 + 0.08 * Math.sin(t * 9 + i)); g.lineTo(cx - ww, yy); } for (let i = 20; i >= 0; i--) { const yy = by - 30 - h * i / 20, ww = w * Math.sin(PI * (1 - i / 20) * 0.9 + 0.1) * (1 + 0.08 * Math.cos(t * 8 + i)); g.lineTo(cx + ww, yy); } g.fill(); g.globalAlpha = 1; };
      fl(1.0, col, 0.55); fl(0.7, col, 0.6); fl(0.35, '#a8d0ff', 0.7);
      D.line(g, cx + 140, by - 160, cx + 16, by - 150, T.muted, 2); D.circle(g, cx + 14, by - 150, 4, T.fg);
      if (co.v) { D.rect(g, 30, 30, c.w - 60, c.h - 60, 'rgba(40,60,200,0.18)', '#3050c0', 2); D.text(g, '蓝色钴玻璃', 40, 44, '#3050c0', { size: 12 }); }
      const nm = S[s.v][2];
      out.set([['试样', S[s.v][0]], ['焰色', { none: '淡蓝色（酒精灯/燃气本身）', Li: '紫红色', Na: '黄色', K: '紫色（透过钴玻璃）', Ca: '砖红色', Sr: '洋红色', Ba: '黄绿色', Cu: '绿色', KNa: co.v ? '紫色（钠的黄光被滤去）' : '黄色（钠掩盖了钾的紫色）' }[s.v]], ['特征谱线', nm ? nm + ' nm' : '—']]);
    });
  }
});

/* ---------- 溶液导电性 ---------- */
const LAMBDA = { 'H+': 350, 'OH-': 199, 'Na+': 50, 'Cl-': 76, 'K+': 74, 'NH4+': 74, 'CH3COO-': 41, 'Ba2+': 127, 'SO42-': 160, 'NO3-': 71, 'Ag+': 62 };
Lab.reg({
  id: 'c-conduct', subj: 'chem', book: 0, unit: '离子反应', title: '电解质溶液的导电性与离子反应', kw: '电解质 强电解质 弱电解质 电离 导电能力 离子反应 硫酸 氢氧化钡',
  info: `<p>溶液的导电能力取决于自由移动离子的浓度和所带电荷数。相同浓度时，强电解质完全电离，导电能力强；弱电解质（如 CH₃COOH、NH₃·H₂O）部分电离，导电能力弱。</p>
  <p class="fb">Ba²⁺ + 2OH⁻ + 2H⁺ + SO₄²⁻ ══ BaSO₄↓ + 2H₂O</p>
  <p>向 Ba(OH)₂ 溶液中滴加稀硫酸，离子不断结合成沉淀和水，灯泡逐渐变暗，恰好完全反应时几乎熄灭；继续滴加，H⁺ 和 SO₄²⁻ 过量，灯泡又变亮。</p>`,
  tasks: ['比较 0.1 mol/L 的盐酸与醋酸，灯泡亮度有何不同？为什么？', '滴定模式下，灯泡最暗时加入了多少毫升硫酸？写出离子方程式。', '把醋酸与氨水混合，导电能力为什么会增强？'],
  init(L) {
    const c = L.canvas();
    L.group('模式');
    const mode = L.seg('', [['cmp', '比较导电性'], ['tit', 'Ba(OH)₂ + H₂SO₄']], 'cmp', () => { G1.hidden = mode.v !== 'cmp'; G2.hidden = mode.v !== 'tit'; L.draw(); });
    const G1 = L.group('溶液');
    const sols = { HCl: ['盐酸 HCl', [['H+', 1], ['Cl-', 1]], 1], HAc: ['醋酸 CH₃COOH', [['H+', 1], ['CH3COO-', 1]], 1.75e-5], NaCl: ['氯化钠 NaCl', [['Na+', 1], ['Cl-', 1]], 1], NaOH: ['氢氧化钠 NaOH', [['Na+', 1], ['OH-', 1]], 1], NH3: ['氨水 NH₃·H₂O', [['NH4+', 1], ['OH-', 1]], 1.8e-5], NH4Ac: ['醋酸铵（醋酸与氨水混合）', [['NH4+', 1], ['CH3COO-', 1]], 1], sugar: ['蔗糖溶液', [], 0], water: ['蒸馏水', [], 0] };
    const sol = L.select('', Object.entries(sols).map(([k, v]) => [k, v[0]]), 'HCl');
    const conc = L.slider('浓度', 0.001, 1, 0.001, 0.1, null, 'mol/L');
    const G2 = L.group('滴定'); G2.hidden = true;
    const vol = L.slider('加入 0.1 mol/L H₂SO₄ 的体积', 0, 40, 0.1, 0, null, 'mL');
    L.note('烧杯中为 20 mL 0.1 mol/L Ba(OH)₂ 溶液。');
    const out = L.out();
    let t = 0; L.loop(dt => { t += dt; L.drawFn(); });
    function cond() {
      if (mode.v === 'cmp') {
        const S = sols[sol.v], cc = conc.v; if (!S[1].length) return { k: 0.0005, ions: [], alpha: 0 };
        const Ka = S[2], a = Ka >= 1 ? 1 : (-Ka + Math.sqrt(Ka * Ka + 4 * Ka * cc)) / (2 * cc);
        return { k: S[1].reduce((s, [ion, z]) => s + LAMBDA[ion] * z * a * cc, 0), ions: S[1].map(q => q[0]), alpha: a };
      }
      const nB = 0.002, nA = vol.v * 1e-4, Vt = (20 + vol.v) / 1000, ex = nB - nA;
      const ions = ex > 0 ? [['Ba2+', ex], ['OH-', 2 * ex]] : [['H+', -2 * ex], ['SO42-', -ex]];
      return { k: ions.reduce((s, [ion, n]) => s + LAMBDA[ion] * n / Vt, 0) + 0.0005, ions: ions.map(q => q[0]), alpha: 1, ppt: Math.min(nA, nB) };
    }
    L.onDraw(() => {
      c.clear(); const g = c.g, r = cond(), br = clamp(r.k / 40, 0, 1), cx = c.w * 0.45, top = 50;
      const bx = cx - 110, bw = 220, by = c.h * 0.42, bh = c.h * 0.48;
      D.rect(g, bx, by + 20, bw, bh - 20, alpha(T.c1, 0.12)); D.poly(g, [[bx, by], [bx, by + bh], [bx + bw, by + bh], [bx + bw, by]], null, T.fg, 2, false);
      if (r.ppt) { const h = r.ppt / 0.002 * 30; D.rect(g, bx + 2, by + bh - h - 2, bw - 4, h, alpha(T.muted, 0.6)); }
      D.rect(g, bx + 40, by - 20, 10, bh - 10, T.fg); D.rect(g, bx + bw - 50, by - 20, 10, bh - 10, T.fg);
      wire(g, [[bx + 45, by - 20], [bx + 45, top], [cx - 20, top]]); wire(g, [[cx + 20, top], [bx + bw - 45, top], [bx + bw - 45, by - 20]]);
      D.circle(g, cx, top, 30 + br * 20, `rgba(255,210,60,${0.1 + br * 0.6})`); D.circle(g, cx, top, 16, `rgba(255,220,90,${0.25 + br * 0.75})`, T.fg, 1.5);
      battery(g, bx - 40, c.h * 0.3, true, ''); wire(g, [[bx - 40, c.h * 0.3 - 4], [bx - 40, top], [bx + 45, top]], T.muted, 1);
      const ions = r.ions; for (let i = 0; i < Math.round(clamp(r.k, 0, 60)); i++) {
        const ion = ions[i % ions.length]; if (!ion) break; const pos = ion.includes('+'), x = bx + 20 + ((i * 53.7 + (pos ? 1 : -1) * t * 20) % (bw - 40) + (bw - 40)) % (bw - 40), y = by + 40 + (i * 37.3) % (bh - 70);
        D.circle(g, x, y, 6, alpha(pos ? T.c2 : T.c1, 0.75)); D.text(g, pos ? '+' : '−', x, y, '#fff', { align: 'center', size: 9, bold: true });
      }
      if (mode.v === 'tit' && c.w - (bx + bw) > 200) {
        const gx = bx + bw + 40, vs = [...Array(81).keys()].map(i => i / 2);
        const kk = v => { const nB = 0.002, nA = v * 1e-4, Vt = (20 + v) / 1000, ex = nB - nA; return ex > 0 ? (LAMBDA['Ba2+'] * ex + LAMBDA['OH-'] * 2 * ex) / Vt : (LAMBDA['H+'] * -2 * ex + LAMBDA['SO42-'] * -ex) / Vt; };
        const ch = D.chart(g, gx, 40, c.w - gx - 20, c.h - 100, [{ pts: vs.map(v => [v, kk(v)]), color: T.c1, w: 2 }], { title: '导电能力（相对）', xl: 'V(H₂SO₄) / mL', xmin: 0, xmax: 40, ymin: 0 });
        D.circle(g, ch.X(vol.v), ch.Y(kk(vol.v)), 5, T.c2);
      }
      out.set([['导电能力（相对）', fmt(r.k, 2)], ['灯泡', br < 0.03 ? '几乎不亮' : br < 0.3 ? '较暗' : br < 0.7 ? '较亮' : '很亮'], ['自由离子', ions.length ? ions.join('、') : '几乎没有'], mode.v === 'cmp' ? ['电离程度 α', fmt(r.alpha * 100, 2) + ' %'] : ['BaSO₄ 沉淀', fmt(r.ppt * 233.4 * 1000, 1) + ' mg']]);
    });
  }
});

/* ---------- 反应速率与碰撞理论 ---------- */
Lab.reg({
  id: 'c-rate', subj: 'chem', book: 1, unit: '化学反应的速率与限度', title: '反应速率与有效碰撞', kw: '反应速率 活化能 活化分子 有效碰撞 催化剂 温度 浓度 能量图',
  info: `<p>蓝色 A 与红色 B 相撞时，只有碰撞能量超过活化能 Eₐ 才能变成绿色产物 C（有效碰撞）。</p>
  <p class="fb">v = Δc/Δt　增大浓度：单位体积活化分子数增多<br>升高温度：活化分子百分数增大（右下能量分布曲线阴影面积变大）<br>催化剂：改变反应历程，降低活化能，正逆反应速率同等程度增大，ΔH 不变</p>`,
  tasks: ['只升高温度，观察能量分布曲线的阴影面积和反应速率怎样变化。', '加入催化剂，Eₐ 线向哪边移动？反应热 ΔH 变了吗？', '只增加 A 的数目，单位时间内有效碰撞次数如何变化？'],
  init(L) {
    const c = L.canvas();
    const p = L.params({ nA: ['A 的数目', 5, 80, 1, 40], nB: ['B 的数目', 5, 80, 1, 40], T: ['温度', 200, 800, 10, 400, 'K'] }, k => { if (k === 'T') retemp(); else reset(); });
    const cat = L.check('加入催化剂', false);
    L.button('重新开始', () => reset(), true);
    const out = L.out();
    let ps = [], t = 0, hist = [], events = [];
    const Ea0 = 3.0, EaC = 1.6, kT = () => p.T / 200; // 相对单位
    function spd() { return Math.sqrt(2 * kT() * -Math.log(Math.random() || 1e-9)); }
    function mk(type) { const s = spd() * 40, a = rnd(0, TAU); return { type, x: rnd(0.05, 0.95), y: rnd(0.05, 0.95), vx: s * Math.cos(a), vy: s * Math.sin(a) }; }
    function reset() { ps = [...Array(p.nA)].map(() => mk('A')).concat([...Array(p.nB)].map(() => mk('B'))); t = 0; hist = [[0, p.nA]]; events = []; L.draw(); }
    function retemp() { const target = Math.sqrt(2 * kT()) * 40; const cur = Math.sqrt(ps.reduce((s, q) => s + q.vx ** 2 + q.vy ** 2, 0) / ps.length) || 1; ps.forEach(q => { q.vx *= target / cur; q.vy *= target / cur; }); }
    reset();
    L.loop(dt => {
      const bw = c.w * 0.55, bh = c.h - 40, r = 5 / Math.min(bw, bh), Ea = cat.v ? EaC : Ea0;
      t += dt;
      for (const q of ps) { q.x += q.vx * dt / bw; q.y += q.vy * dt / bh; if (q.x < 0 || q.x > 1) { q.vx *= -1; q.x = clamp(q.x, 0, 1); } if (q.y < 0 || q.y > 1) { q.vy *= -1; q.y = clamp(q.y, 0, 1); } }
      for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
        const a = ps[i], b = ps[j], dx = (a.x - b.x) * bw, dy = (a.y - b.y) * bh, d = Math.hypot(dx, dy);
        if (d < 10 && d > 0) {
          const nx = dx / d, ny = dy / d, rv = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny; if (rv >= 0) continue;
          const E = 0.25 * rv * rv / 1600 / 1; // 沿连心线的相对动能（相对单位）
          if (((a.type === 'A' && b.type === 'B') || (a.type === 'B' && b.type === 'A')) && E > Ea) { a.type = b.type = 'C'; events.push(t); }
          a.vx -= rv * nx; a.vy -= rv * ny; b.vx += rv * nx; b.vy += rv * ny;
        }
      }
      void r;
      const nA = ps.filter(q => q.type === 'A').length; hist.push([t, nA]); if (hist.length > 1200) hist = hist.filter((_, i) => i % 2 === 0);
      events = events.filter(e => e > t - 2); retemp(); L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, bw = c.w * 0.55, bh = c.h - 40, ox = 20, oy = 20;
      D.rect(g, ox, oy, bw, bh, null, T.fg, 1.5);
      ps.forEach(q => D.circle(g, ox + q.x * bw, oy + q.y * bh, 5, q.type === 'A' ? T.c1 : q.type === 'B' ? T.c2 : T.c3));
      const gx = ox + bw + 30, gw = c.w - gx - 15, gh = (c.h - 60) / 3;
      if (gw > 100) {
        D.chart(g, gx, oy, gw, gh, [{ pts: hist, color: T.c1, w: 2 }], { title: 'A 的数目 − t', xl: 't', xmin: 0, xmax: Math.max(5, t), ymin: 0, ymax: Math.max(p.nA, 1) });
        const kt = kT(), Ea = cat.v ? EaC : Ea0, f = E => Math.sqrt(E) * Math.exp(-E / kt), Es = [...Array(121).keys()].map(i => i * 0.05);
        const ch = D.chart(g, gx, oy + gh + 24, gw, gh, [{ pts: Es.map(E => [E, f(E)]), color: T.c4, w: 2 }], { title: '分子能量分布', xl: 'E', xmin: 0, xmax: 6, ymin: 0, ymax: 0.9, yticks: false });
        g.fillStyle = alpha(T.c2, 0.35); g.beginPath(); g.moveTo(ch.X(Ea), ch.Y(0)); Es.filter(E => E >= Ea).forEach(E => g.lineTo(ch.X(E), ch.Y(f(E)))); g.lineTo(ch.X(6), ch.Y(0)); g.fill();
        D.line(g, ch.X(Ea), ch.Y(0), ch.X(Ea), ch.Y(0.85), T.c2, 1.5, [4, 3]); D.text(g, 'Eₐ', ch.X(Ea) + 4, ch.Y(0.8), T.c2);
        // 反应历程能量图
        const y0 = oy + 2 * gh + 48, ch3 = D.chart(g, gx, y0, gw, gh, [], { title: '反应历程（放热反应）', xmin: 0, xmax: 1, ymin: 0, ymax: 5, yticks: false });
        const prof = (h) => [...Array(61).keys()].map(i => { const x = i / 60; return [x, 2 - 1.2 * x + h * Math.exp(-((x - 0.5) ** 2) / 0.02)]; });
        [[Ea0, T.muted, [5, 4]], [EaC, T.c3, []]].forEach(([h, col, dash]) => { if (h === EaC && !cat.v) return; g.strokeStyle = col; g.lineWidth = 2; g.setLineDash(dash); g.beginPath(); prof(h).forEach(([x, y], i) => i ? g.lineTo(ch3.X(x), ch3.Y(y)) : g.moveTo(ch3.X(x), ch3.Y(y))); g.stroke(); g.setLineDash([]); });
        D.text(g, '反应物', ch3.X(0.02), ch3.Y(2) - 10, T.muted, { size: 10 }); D.text(g, '生成物', ch3.X(0.98), ch3.Y(0.8) - 10, T.muted, { size: 10, align: 'right' });
      }
      const kt = kT(), Ea = cat.v ? EaC : Ea0, frac = 1 - [...Array(400).keys()].reduce((s, i) => { const E = (i + 0.5) * Ea / 400; return s + Math.sqrt(E) * Math.exp(-E / kt) * Ea / 400; }, 0) / (Math.sqrt(PI) / 2 * kt ** 1.5);
      out.set([['剩余 A', ps.filter(q => q.type === 'A').length], ['生成 C', ps.filter(q => q.type === 'C').length], ['近 2 秒有效碰撞', events.length + ' 次'], ['活化能 Eₐ（相对）', fmt(Ea, 2) + (cat.v ? '（有催化剂）' : '')], ['活化分子百分数', fmt(frac * 100, 2) + ' %']]);
    });
  }
});

/* ---------- 化学平衡移动 ---------- */
Lab.reg({
  id: 'c-equil', subj: 'chem', book: 2, unit: '化学反应速率与化学平衡', title: '化学平衡移动（勒夏特列原理）', kw: '化学平衡 平衡常数 浓度商 勒夏特列 温度 压强 催化剂 v-t 图',
  info: `<p class="fb">K = Πc(生成物)^ν / Πc(反应物)^ν（纯固体、纯液体不写入，稀溶液中的水也不写入）<br>Q &lt; K 正向移动，Q = K 平衡，Q &gt; K 逆向移动<br>K 只与温度有关：放热反应升温 K 减小，吸热反应升温 K 增大</p>
  <p><b>勒夏特列原理</b>：改变影响平衡的一个条件（浓度、压强、温度），平衡向能够减弱这种改变的方向移动。催化剂同等程度地加快正、逆反应，不影响平衡。</p>
  <p>上方图像为各物质浓度随时间的变化，下方为正逆反应速率随时间的变化（v − t 图）。</p>`,
  tasks: ['合成氨反应中「压缩体积」，正逆反应速率如何突变？平衡向哪个方向移动？', '2NO₂ ⇌ N₂O₄：升温后颜色如何变化？说明该反应是放热还是吸热。', 'H₂ + I₂ ⇌ 2HI：压缩体积后颜色变深，平衡移动了吗？', 'FeCl₃ + KSCN：加入 KSCN 后颜色怎样变化？'],
  init(L) {
    const c = L.canvas();
    const R = {
      nh3: { name: 'N₂ + 3H₂ ⇌ 2NH₃　ΔH = −92.4 kJ/mol', sp: [['N₂', -1, 1, null], ['H₂', -3, 3, null], ['NH₃', 2, 0, null]], gas: true, dH: -92.4, K0: 0.05, T0: 500, k0: 0.25 },
      no2: { name: '2NO₂(红棕) ⇌ N₂O₄(无色)　ΔH = −57 kJ/mol', sp: [['NO₂', -2, 1.2, '#b5501d'], ['N₂O₄', 1, 0.2, null]], gas: true, dH: -57, K0: 2, T0: 330, k0: 1.2 },
      hi: { name: 'H₂ + I₂(紫) ⇌ 2HI　ΔH = −9.4 kJ/mol', sp: [['H₂', -1, 1, null], ['I₂', -1, 1, '#7a2fb0'], ['HI', 2, 0, null]], gas: true, dH: -9.4, K0: 50, T0: 700, k0: 0.4 },
      fe: { name: 'Fe³⁺ + 3SCN⁻ ⇌ Fe(SCN)₃(红色)', sp: [['Fe³⁺', -1, 0.5, '#d8a23a'], ['SCN⁻', -3, 1.0, null], ['Fe(SCN)₃', 1, 0, '#b0101a']], gas: false, dH: 0, K0: 4, T0: 298, k0: 0.6 },
      cr: { name: 'Cr₂O₇²⁻(橙) + H₂O ⇌ 2CrO₄²⁻(黄) + 2H⁺', sp: [['Cr₂O₇²⁻', -1, 0.3, '#e46b10'], ['CrO₄²⁻', 2, 0.1, '#e8d020'], ['H⁺', 2, 0.1, null]], gas: false, dH: 13, K0: 0.02, T0: 298, k0: 1 }
    };
    let rx = R.nh3, conc = [], Tk = 500, hist = [], vh = [], t = 0, catal = false;
    L.select('反应', Object.entries(R).map(([k, v]) => [k, v.name]), 'nh3', k => { rx = R[k]; reset(); build(); });
    const gOp = L.group('改变条件');
    const sT = L.slider('温度 T', 250, 900, 5, 500, v => { Tk = v; }, 'K');
    const box = el('div', 'row'); gOp.appendChild(box);
    L.group('');
    L.check('加入催化剂', false, v => catal = v);
    L.button('重新开始', () => reset(), true);
    const out = L.out();
    function build() {
      box.innerHTML = '';
      const add = (t2, f) => { const b = el('button', 'btn', t2); b.type = 'button'; b.onclick = f; box.appendChild(b); };
      rx.sp.forEach((s, i) => { if (s[0] === 'H₂O') return; add(`增大 c(${s[0]})`, () => { conc[i] += Math.max(0.3, conc[i] * 0.5); }); });
      rx.sp.forEach((s, i) => add(`减小 c(${s[0]})`, () => { conc[i] *= 0.5; }));
      if (rx.gas) { add('压缩体积（加压）', () => conc = conc.map(x => x * 2)); add('扩大体积（减压）', () => conc = conc.map(x => x / 2)); }
      else add('加水稀释', () => conc = conc.map(x => x / 2));
      sT.set(rx.T0, true); Tk = rx.T0;
    }
    function reset() { conc = rx.sp.map(s => s[2]); t = 0; hist = []; vh = []; }
    const K = () => rx.K0 * Math.exp(-rx.dH * 1000 / 8.314 * (1 / Tk - 1 / rx.T0));
    const kf = () => rx.k0 * Math.exp(-50000 / 8.314 * (1 / Tk - 1 / rx.T0)) * (catal ? 5 : 1);
    const rates = cc => { let f = kf(), r = kf() / K(); rx.sp.forEach((s, i) => { if (s[1] < 0) f *= Math.max(0, cc[i]) ** -s[1]; else r *= Math.max(0, cc[i]) ** s[1]; }); return [f, r]; };
    const Qc = () => rx.sp.reduce((q, s, i) => q * Math.max(1e-12, conc[i]) ** s[1], 1);
    reset(); build();
    L.loop(dt => {
      const n = 200, h = dt / n;
      for (let i = 0; i < n; i++) {
        const [f, r] = rates(conc); let d = (f - r) * h;
        rx.sp.forEach((s, j) => { if (s[1] < 0) d = Math.min(d, conc[j] / -s[1] * 0.5); else d = Math.max(d, -conc[j] / s[1] * 0.5); });
        conc = conc.map((x, j) => x + rx.sp[j][1] * d);
      }
      t += dt; const [f, r] = rates(conc); hist.push([t, ...conc]); vh.push([t, f, r]);
      if (hist.length > 900) { hist.shift(); vh.shift(); }
      L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, vw = Math.min(200, c.w * 0.3), vx = 20, vy = 40, vhh = c.h - 90;
      // 容器颜色
      let rr = 0, gg = 0, bb = 0, aa = 0;
      rx.sp.forEach((s, i) => { if (!s[3]) return; const n2 = parseInt(s[3].slice(1), 16), w = clamp(conc[i] / 1.5, 0, 1); rr += (n2 >> 16 & 255) * w; gg += (n2 >> 8 & 255) * w; bb += (n2 & 255) * w; aa += w; });
      const fill = aa ? `rgba(${rr / aa | 0},${gg / aa | 0},${bb / aa | 0},${clamp(aa, 0, 0.9)})` : alpha(T.c1, 0.05);
      if (rx.gas) { D.rect(g, vx, vy, vw, vhh, fill, T.fg, 2); D.rect(g, vx, vy - 12, vw, 12, T.muted); D.text(g, '密闭容器', vx + vw / 2, vy + vhh + 18, T.muted, { align: 'center', size: 12 }); }
      else { D.rect(g, vx, vy + 30, vw, vhh - 30, fill); D.poly(g, [[vx, vy], [vx, vy + vhh], [vx + vw, vy + vhh], [vx + vw, vy]], null, T.fg, 2, false); D.text(g, '试管 / 烧杯', vx + vw / 2, vy + vhh + 18, T.muted, { align: 'center', size: 12 }); }
      const gx = vx + vw + 50, gw = c.w - gx - 20, gh = (c.h - 80) / 2;
      if (gw > 100 && hist.length > 1) {
        const ser = rx.sp.map((s, i) => ({ pts: hist.map(q => [q[0], q[i + 1]]), color: T.c[i], w: 2 }));
        const ymax = Math.max(...hist.flatMap(q => q.slice(1))) * 1.1;
        D.chart(g, gx, 30, gw, gh, ser, { title: '浓度 c − t（mol/L）', xmin: hist[0][0], xmax: t, ymin: 0, ymax });
        rx.sp.forEach((s, i) => D.text(g, '■ ' + s[0], gx + 8 + i * 80, 30 + gh + 12, T.c[i], { size: 11 }));
        const vmax = Math.max(...vh.flatMap(q => [q[1], q[2]])) * 1.1 || 1;
        D.chart(g, gx, 60 + gh, gw, gh - 20, [{ pts: vh.map(q => [q[0], q[1]]), color: T.c2, w: 2 }, { pts: vh.map(q => [q[0], q[2]]), color: T.c1, w: 2, dash: [5, 3] }], { title: 'v − t：实线 v 正，虚线 v 逆', xl: 't', xmin: vh[0][0], xmax: t, ymin: 0, ymax: vmax });
      }
      const Q = Qc(), Kv = K(), st = Math.abs(Math.log(Q / Kv)) < 0.02 ? '已达平衡（Q ≈ K）' : Q < Kv ? 'Q < K，平衡正向移动' : 'Q > K，平衡逆向移动';
      out.set([['温度', Tk + ' K'], ['平衡常数 K', fmt(Kv, 4)], ['浓度商 Q', fmt(Q, 4)], ['状态', st], ...rx.sp.map((s, i) => [`c(${s[0]})`, fmt(conc[i], 4) + ' mol/L'])]);
    });
  }
});

/* ---------- 酸碱中和滴定 ---------- */
function solvePH(f) { let lo = -15, hi = 1; for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if (f(10 ** m) > 0) hi = m; else lo = m; } return -(lo + hi) / 2; }
Lab.reg({
  id: 'c-titr', subj: 'chem', book: 2, unit: '水溶液中的离子反应与平衡', title: '酸碱中和滴定曲线', kw: '中和滴定 pH 突跃 指示剂 酚酞 甲基橙 弱酸 等当点',
  info: `<p>pH 由电荷守恒精确求解（考虑水的电离与弱电解质的电离平衡）。</p>
  <p class="fb">恰好中和：c(酸)V(酸) = c(碱)V(碱)（一元酸碱）<br>滴定终点附近（±0.1% 即 ±0.02 mL）pH 发生突跃<br>指示剂变色范围：甲基橙 3.1~4.4（红→黄），酚酞 8.2~10.0（无色→粉红），石蕊 5.0~8.0</p>
  <p>强碱滴定弱酸，等当点溶液呈碱性，应选酚酞；强酸滴定弱碱，等当点呈酸性，应选甲基橙。石蕊变色不明显，一般不作滴定指示剂。</p>`,
  tasks: ['NaOH 滴定 HCl，记录 19.98 mL 和 20.02 mL 时的 pH，算出突跃范围。', '换成滴定醋酸，突跃范围怎样变化？等当点 pH 是多少？为什么选酚酞？', '把浓度都降为 0.01 mol/L，突跃范围如何变化？'],
  init(L) {
    const c = L.canvas();
    const sys = L.select('体系', [['sa', 'NaOH 滴定 HCl（强碱滴强酸）'], ['wa', 'NaOH 滴定 CH₃COOH（强碱滴弱酸）'], ['sb', 'HCl 滴定 NaOH（强酸滴强碱）'], ['wb', 'HCl 滴定 NH₃·H₂O（强酸滴弱碱）']], 'sa', () => L.draw());
    const p = L.params({ ca: ['待测液浓度', 0.01, 0.5, 0.01, 0.1, 'mol/L'], va: ['待测液体积', 10, 40, 1, 20, 'mL'], cb: ['标准液浓度', 0.01, 0.5, 0.01, 0.1, 'mol/L'], V: ['已滴入体积', 0, 50, 0.01, 0, 'mL'] });
    const ind = L.select('指示剂', [['pp', '酚酞 8.2~10.0'], ['mo', '甲基橙 3.1~4.4'], ['lt', '石蕊 5.0~8.0']], 'pp', () => L.draw());
    let auto = false; L.button('自动滴定', b => { auto = !auto; b.setAttribute('aria-pressed', auto); }, true); L.button('倒回 0', () => p.V = 0);
    const out = L.out();
    const Kw = 1e-14;
    function pH(V) {
      const { ca, va, cb } = p, s = sys.v, Vt = va + V, CT = ca * va / Vt, CX = cb * V / Vt;
      if (s === 'sa' || s === 'wa') { const Ka = s === 'sa' ? 1e8 : 1.75e-5; return solvePH(h => h + CX - Kw / h - CT * Ka / (Ka + h)); }
      const Ka2 = s === 'sb' ? 1e-30 : Kw / 1.8e-5; return solvePH(h => h + CT * h / (h + Ka2) - Kw / h - CX);
    }
    L.loop(dt => { if (auto) { const Veq = p.ca * p.va / p.cb, sp = Math.abs(p.V - Veq) < 1.5 ? 0.6 : 4; p.$V.set(Math.min(50, p.V + sp * dt)); if (p.V >= 50) auto = false; } });
    const indColor = ph => { const k = ind.v; if (k === 'pp') return ph < 8.2 ? 'rgba(255,255,255,0.08)' : `rgba(230,40,140,${clamp((ph - 8.2) / 1.8, 0, 1) * 0.65})`; if (k === 'mo') return ph < 3.1 ? 'rgba(220,40,40,0.65)' : ph > 4.4 ? 'rgba(240,190,30,0.6)' : 'rgba(240,120,40,0.6)'; return ph < 5 ? 'rgba(220,40,40,0.55)' : ph > 8 ? 'rgba(40,80,220,0.55)' : 'rgba(140,60,170,0.55)'; };
    L.onDraw(() => {
      c.clear(); const g = c.g, ph = pH(p.V), Veq = p.ca * p.va / p.cb, Vmax = Math.max(40, Veq * 2);
      // 滴定管与锥形瓶
      const bx = 60, top = 20; D.rect(g, bx - 8, top, 16, c.h * 0.5, alpha(T.c1, 0.1), T.fg, 1.5);
      const lv = clamp(p.V / 50, 0, 1); D.rect(g, bx - 7, top + 1 + lv * (c.h * 0.5 - 2), 14, (1 - lv) * (c.h * 0.5 - 2), alpha(T.c1, 0.3));
      for (let k = 0; k <= 50; k += 10) D.text(g, k, bx + 12, top + k / 50 * c.h * 0.5, T.muted, { size: 9, mono: true });
      D.line(g, bx, top + c.h * 0.5, bx, top + c.h * 0.5 + 20, T.fg, 2);
      if (auto) D.circle(g, bx, top + c.h * 0.5 + 26 + (performance.now() / 8 % 30), 3, alpha(T.c1, 0.8));
      const fy = c.h * 0.62 + 20; D.poly(g, [[bx - 10, fy], [bx - 10, fy + 30], [bx - 55, c.h - 30], [bx + 55, c.h - 30], [bx + 10, fy + 30], [bx + 10, fy]], null, T.fg, 1.8, false);
      D.poly(g, [[bx - 34, c.h - 70], [bx - 55, c.h - 30], [bx + 55, c.h - 30], [bx + 34, c.h - 70]], indColor(ph));
      const gx = 170, gw = c.w - gx - 20;
      const Vs = [...Array(401).keys()].map(i => Vmax * i / 400), dense = [...Array(81).keys()].map(i => Veq - 0.4 + i * 0.01);
      const pts = [...Vs, ...dense].filter(v => v >= 0 && v <= Vmax).sort((a, b) => a - b).map(v => [v, pH(v)]);
      const ch = D.chart(g, gx, 20, gw, c.h - 50, [{ pts, color: T.c1, w: 2.2 }], { title: 'pH − V 曲线', xl: 'V(标准液) / mL', xmin: 0, xmax: Vmax, ymin: 0, ymax: 14 });
      const band = { pp: [8.2, 10, 'rgba(230,40,140,0.12)'], mo: [3.1, 4.4, 'rgba(240,120,40,0.15)'], lt: [5, 8, 'rgba(140,60,170,0.12)'] }[ind.v];
      g.fillStyle = band[2]; g.fillRect(gx, ch.Y(band[1]), gw, ch.Y(band[0]) - ch.Y(band[1]));
      [7].forEach(y => D.line(g, gx, ch.Y(y), gx + gw, ch.Y(y), T.grid2, 1, [3, 3]));
      for (let y = 2; y <= 12; y += 2) D.text(g, y, gx - 4, ch.Y(y), T.muted, { align: 'right', size: 10, mono: true });
      D.line(g, ch.X(Veq), 20, ch.X(Veq), c.h - 30, T.muted, 1, [4, 4]); D.text(g, '等当点', ch.X(Veq) + 4, 36, T.muted, { size: 11 });
      D.circle(g, ch.X(Math.min(p.V, Vmax)), ch.Y(ph), 5.5, T.c2, T.stage, 1.5);
      const lo = pH(Veq * 0.999), hi = pH(Veq * 1.001), pe = pH(Veq);
      out.set([['当前 pH', fmt(ph, 2)], ['等当点体积', fmt(Veq, 2) + ' mL'], ['等当点 pH', fmt(pe, 2)], ['突跃范围（±0.1%）', `${fmt(lo, 2)} ~ ${fmt(hi, 2)}`], ['指示剂变色是否落在突跃内', (band[0] < hi && band[1] > lo) ? '是，适用' : '否，误差较大']]);
    });
  }
});

/* ---------- 电离平衡与分布系数 ---------- */
Lab.reg({
  id: 'c-ion', subj: 'chem', book: 2, unit: '水溶液中的离子反应与平衡', title: '弱电解质电离与盐类水解', kw: '电离平衡 电离常数 分布系数 盐类水解 pH 缓冲 多元弱酸 电离度',
  info: `<p>分布系数 δ 表示某种型体占该物质总浓度的比例。对一元弱酸：</p>
  <p class="fb">δ(HA) = c(H⁺)/[c(H⁺) + Kₐ]，δ(A⁻) = Kₐ/[c(H⁺) + Kₐ]<br>pH = pKₐ 时 c(HA) = c(A⁻)<br>弱酸溶液近似 c(H⁺) ≈ √(Kₐc)；稀释促进电离，电离度增大</p>
  <p>强碱弱酸盐（如 CH₃COONa、Na₂CO₃）水解显碱性，强酸弱碱盐（如 NH₄Cl）水解显酸性。「越弱越水解」：Na₂CO₃ 的碱性强于 NaHCO₃。</p>`,
  tasks: ['在 CH₃COOH 的分布图中，找到 δ(HA) = δ(A⁻) 的点，对应 pH 等于多少？', '把醋酸浓度从 0.1 降到 0.001 mol/L，pH 和电离度怎样变化？', '比较 0.1 mol/L 的 Na₂CO₃ 和 CH₃COONa 溶液 pH，哪个大？用 Kₐ 解释。'],
  init(L) {
    const c = L.canvas();
    const A = {
      ac: ['醋酸 CH₃COOH', [1.75e-5], ['CH₃COOH', 'CH₃COO⁻'], 0, ['CH₃COOH 溶液', 'CH₃COONa 溶液']],
      co3: ['碳酸 H₂CO₃', [4.5e-7, 4.7e-11], ['H₂CO₃', 'HCO₃⁻', 'CO₃²⁻'], 0, ['H₂CO₃ 溶液', 'Na₂CO₃ 溶液']],
      ox: ['草酸 H₂C₂O₄', [5.6e-2, 1.5e-4], ['H₂C₂O₄', 'HC₂O₄⁻', 'C₂O₄²⁻'], 0, ['H₂C₂O₄ 溶液', 'Na₂C₂O₄ 溶液']],
      po4: ['磷酸 H₃PO₄', [6.9e-3, 6.2e-8, 4.8e-13], ['H₃PO₄', 'H₂PO₄⁻', 'HPO₄²⁻', 'PO₄³⁻'], 0, ['H₃PO₄ 溶液', 'Na₃PO₄ 溶液']],
      nh4: ['铵根 NH₄⁺', [5.6e-10], ['NH₄⁺', 'NH₃·H₂O'], 1, ['NH₄Cl 溶液', 'NH₃·H₂O 溶液']]
    };
    const sel = L.select('弱电解质', Object.entries(A).map(([k, v]) => [k, v[0]]), 'ac', () => { sync(); L.draw(); });
    const form = L.seg('溶质', [['acid', '酸式'], ['salt', '盐 / 碱式']], 'acid', () => L.draw());
    const lc = L.slider('浓度 lg c', -4, 0, 0.05, -1, null, v => `${fmt(10 ** v, 4)} mol/L`);
    const pH0 = L.slider('观察 pH（竖线）', 0, 14, 0.05, 4.76);
    const out = L.out();
    function sync() { const a = A[sel.v]; form.btns.acid.textContent = a[4][0]; form.btns.salt.textContent = a[4][1]; }
    sync();
    const delta = (h, Ks) => { const n = Ks.length, terms = []; let prod = 1; for (let i = 0; i <= n; i++) { terms.push(h ** (n - i) * prod); prod *= Ks[i] ?? 1; } const s = terms.reduce((a, b) => a + b, 0); return terms.map(x => x / s); };
    L.onDraw(() => {
      c.clear(); const g = c.g, a = A[sel.v], Ks = a[1], n = Ks.length, z0 = a[3], cc = 10 ** lc.v;
      const counter = form.v === 'acid' ? -z0 * cc : (n - z0) * cc;
      const ph = solvePH(h => { const d = delta(h, Ks); return h + counter + d.reduce((s, x, i) => s + cc * x * (z0 - i), 0) - 1e-14 / h; });
      const ch = D.chart(g, 50, 24, c.w - 80, c.h - 120, a[2].map((nm, i) => ({ pts: [...Array(281).keys()].map(k => { const p2 = k / 20; return [p2, delta(10 ** -p2, Ks)[i]]; }), color: T.c[i], w: 2.4 })), { title: '分布系数 δ − pH', xl: 'pH', xmin: 0, xmax: 14, ymin: 0, ymax: 1.05 });
      for (let k = 0; k <= 14; k += 2) D.text(g, k, ch.X(k), c.h - 92, T.muted, { align: 'center', size: 10, mono: true });
      Ks.forEach(K => { const pk = -Math.log10(K); D.line(g, ch.X(pk), ch.Y(0), ch.X(pk), ch.Y(0.5), T.grid2, 1, [3, 3]); D.text(g, 'pKₐ=' + fmt(pk, 2), ch.X(pk) + 3, ch.Y(0.52), T.muted, { size: 10 }); });
      D.line(g, ch.X(pH0.v), 24, ch.X(pH0.v), c.h - 96, T.fg, 1.4); D.line(g, ch.X(ph), 24, ch.X(ph), c.h - 96, T.c2, 2, [6, 3]); D.text(g, '溶液 pH', ch.X(ph) + 4, 40, T.c2, { size: 11 });
      a[2].forEach((nm, i) => D.text(g, '■ ' + nm, 54 + i * 110, c.h - 70, T.c[i], { size: 12 }));
      const d0 = delta(10 ** -pH0.v, Ks), ds = delta(10 ** -ph, Ks);
      const rows = [['溶液', a[4][form.v === 'acid' ? 0 : 1] + `（${fmt(cc, 4)} mol/L）`], ['计算 pH', fmt(ph, 3)], ['溶液酸碱性', ph < 6.95 ? '酸性' : ph > 7.05 ? '碱性' : '中性']];
      if (n === 1 && form.v === 'acid') rows.push(['电离度 α', fmt(ds[1] * 100, 3) + ' %']);
      if (n === 1 && form.v === 'salt') rows.push(['水解程度', fmt(ds[0] * 100, 3) + ' %']);
      rows.push(...a[2].map((nm, i) => [`pH=${fmt(pH0.v, 2)} 时 δ(${nm})`, fmt(d0[i], 4)]));
      out.set(rows);
    });
  }
});

/* ---------- 原电池与电解池 ---------- */
Lab.reg({
  id: 'c-cell', subj: 'chem', book: 2, unit: '化学反应与电能', title: '原电池与电解池', kw: '原电池 盐桥 电极反应 电解 氯碱工业 电镀 精炼 金属腐蚀 燃料电池 能斯特',
  info: `<p><b>原电池</b>：化学能 → 电能。负极发生氧化反应，失电子；电子经外电路流向正极；溶液中阳离子移向正极，阴离子移向负极。</p>
  <p><b>电解池</b>：电能 → 化学能。与电源正极相连的是阳极（氧化反应），与负极相连的是阴极（还原反应）；阳离子移向阴极，阴离子移向阳极。</p>
  <p class="fb">铜锌原电池电动势（298 K）：E = 1.10 V − (0.0592/2) lg[c(Zn²⁺)/c(Cu²⁺)]</p>`,
  tasks: ['铜锌原电池中，盐桥里的 K⁺ 和 Cl⁻ 分别移向哪边？撤去盐桥会怎样？', '电解饱和食盐水时，为什么阴极附近滴入酚酞变红？', '电镀铜时，阳极和阴极分别用什么材料？电解液浓度变化吗？'],
  init(L) {
    const C = {
      zncu: { t: 'gal', name: '铜锌原电池（盐桥）', two: true, L: ['Zn', '#9aa3ad', '负极'], R: ['Cu', '#c87533', '正极'], solL: ['ZnSO₄', 'rgba(200,200,210,0.15)'], solR: ['CuSO₄', 'rgba(40,120,230,0.3)'], rl: 'Zn − 2e⁻ ══ Zn²⁺', rr: 'Cu²⁺ + 2e⁻ ══ Cu', tot: 'Zn + Cu²⁺ ══ Zn²⁺ + Cu', ionsL: [['Zn²⁺', 0], ['SO₄²⁻', 0]], ionsR: [['Cu²⁺', 1], ['SO₄²⁻', 0]], bridge: true },
      fuel: { t: 'gal', name: '氢氧燃料电池（酸性电解质）', two: false, L: ['H₂ 极', '#8a8a96', '负极'], R: ['O₂ 极', '#8a8a96', '正极'], sol: ['稀 H₂SO₄', 'rgba(120,200,255,0.15)'], rl: '2H₂ − 4e⁻ ══ 4H⁺', rr: 'O₂ + 4H⁺ + 4e⁻ ══ 2H₂O', tot: '2H₂ + O₂ ══ 2H₂O', ions: [['H⁺', 1]], gasL: true, gasR: true, E: 1.23 },
      rust: { t: 'gal', name: '钢铁的吸氧腐蚀', two: false, L: ['Fe', '#7a7f86', '负极'], R: ['C', '#333', '正极'], sol: ['中性水膜（溶有 O₂）', 'rgba(120,200,255,0.12)'], rl: '2Fe − 4e⁻ ══ 2Fe²⁺', rr: 'O₂ + 2H₂O + 4e⁻ ══ 4OH⁻', tot: '2Fe + O₂ + 2H₂O ══ 2Fe(OH)₂', ions: [['Fe²⁺', 1], ['OH⁻', -1]], E: 0.85 },
      cucl2: { t: 'ely', name: '电解 CuCl₂ 溶液（石墨电极）', L: ['阴极 C', '#333', '阴极'], R: ['阳极 C', '#333', '阳极'], sol: ['CuCl₂ 溶液', 'rgba(40,140,200,0.3)'], rl: 'Cu²⁺ + 2e⁻ ══ Cu', rr: '2Cl⁻ − 2e⁻ ══ Cl₂↑', tot: 'CuCl₂ ══(电解) Cu + Cl₂↑', ions: [['Cu²⁺', -1], ['Cl⁻', 1]], gasR: true, plateL: '#c87533' },
      nacl: { t: 'ely', name: '电解饱和食盐水（氯碱工业）', L: ['阴极 Fe', '#7a7f86', '阴极'], R: ['阳极 C', '#333', '阳极'], sol: ['饱和 NaCl 溶液（滴有酚酞）', 'rgba(200,220,240,0.15)'], rl: '2H₂O + 2e⁻ ══ H₂↑ + 2OH⁻', rr: '2Cl⁻ − 2e⁻ ══ Cl₂↑', tot: '2NaCl + 2H₂O ══(电解) 2NaOH + H₂↑ + Cl₂↑', ions: [['Na⁺', -1], ['Cl⁻', 1]], gasL: true, gasR: true, pink: true },
      plate: { t: 'ely', name: '电镀铜（铁件镀铜）', L: ['阴极 铁件', '#7a7f86', '阴极'], R: ['阳极 Cu', '#c87533', '阳极'], sol: ['CuSO₄ 溶液', 'rgba(40,120,230,0.3)'], rl: 'Cu²⁺ + 2e⁻ ══ Cu', rr: 'Cu − 2e⁻ ══ Cu²⁺', tot: '阳极铜溶解，阴极析出铜，c(Cu²⁺) 基本不变', ions: [['Cu²⁺', -1], ['SO₄²⁻', 1]], plateL: '#c87533' }
    };
    const c = L.canvas();
    let cf = C.zncu;
    L.select('装置', Object.entries(C).map(([k, v]) => [k, v.name]), 'zncu', k => { cf = C[k]; sync(); L.draw(); });
    const p = L.params({ zn: ['c(Zn²⁺)', 0.001, 2, 0.001, 1, 'mol/L'], cu: ['c(Cu²⁺)', 0.001, 2, 0.001, 1, 'mol/L'], U: ['外加电压', 1, 12, 0.5, 6, 'V'] });
    const out = L.out();
    function sync() { p.$zn.el.hidden = p.$cu.el.hidden = cf !== C.zncu; p.$U.el.hidden = cf.t !== 'ely'; }
    sync();
    let t = 0; L.loop(dt => { t += dt; L.drawFn(); });
    L.onDraw(() => {
      c.clear(); const g = c.g, W = c.w, top = 60, bh = Math.min(c.h - top - 40, 260), by = c.h - bh - 30;
      const E = cf === C.zncu ? 1.10 - 0.0296 * Math.log10(p.zn / p.cu) : cf.E || p.U, sp = clamp(Math.abs(E) / 1.1, 0.2, 2);
      let lx, rx; const ew = 16, eh = bh * 0.75;
      if (cf.two) {
        const w = Math.min(220, W * 0.32), gap = Math.min(120, W * 0.15), x1 = W / 2 - gap / 2 - w, x2 = W / 2 + gap / 2;
        [[x1, cf.solL], [x2, cf.solR]].forEach(([x, s]) => { D.rect(g, x, by + 30, w, bh - 30, s[1]); D.poly(g, [[x, by], [x, by + bh], [x + w, by + bh], [x + w, by]], null, T.fg, 2, false); D.text(g, s[0], x + w / 2, by + bh + 16, T.muted, { align: 'center', size: 12 }); });
        g.strokeStyle = T.c4; g.lineWidth = 14; g.beginPath(); g.moveTo(x1 + w - 30, by + 70); g.lineTo(x1 + w - 30, by + 10); g.lineTo(x2 + 30, by + 10); g.lineTo(x2 + 30, by + 70); g.stroke();
        D.text(g, '盐桥（KCl）', W / 2, by - 2, T.muted, { align: 'center', size: 11 });
        const k = (t * 30) % (x2 - x1 - w + 60); D.text(g, 'K⁺→', x1 + w - 30 + k, by + 10, T.c2, { size: 10, bold: true }); D.text(g, '←Cl⁻', x2 + 30 - k - 24, by + 10, T.c1, { size: 10, bold: true });
        lx = x1 + w * 0.35; rx = x2 + w * 0.65;
      } else {
        const w = Math.min(420, W * 0.6), x = W / 2 - w / 2;
        D.rect(g, x, by + 30, w, bh - 30, cf.sol[1]); D.poly(g, [[x, by], [x, by + bh], [x + w, by + bh], [x + w, by]], null, T.fg, 2, false); D.text(g, cf.sol[0], W / 2, by + bh + 16, T.muted, { align: 'center', size: 12 });
        lx = x + w * 0.25; rx = x + w * 0.75;
        if (cf.pink) { const gr = g.createRadialGradient(lx, by + bh * 0.6, 5, lx, by + bh * 0.6, w * 0.25); gr.addColorStop(0, 'rgba(235,60,150,0.5)'); gr.addColorStop(1, 'rgba(235,60,150,0)'); g.fillStyle = gr; g.fillRect(x, by + 30, w / 2, bh - 30); }
        cf.ions.forEach(([nm, dir], i) => { for (let k = 0; k < 6; k++) { const ph2 = ((t * 22 * (dir || 0.3) + k * 37 + i * 15) % (rx - lx) + (rx - lx)) % (rx - lx); const xx = dir >= 0 ? lx + ph2 : rx - ph2; D.text(g, nm, xx, by + 60 + ((k * 41 + i * 27) % (bh - 90)), nm.includes('+') ? T.c2 : T.c1, { align: 'center', size: 11, bold: true }); } });
      }
      [[lx, cf.L, cf.plateL], [rx, cf.R]].forEach(([x, e, plate]) => { D.rect(g, x - ew / 2, by + bh - eh - 10, ew, eh, e[1]); if (plate) D.rect(g, x - ew / 2 - 2, by + bh * 0.45, ew + 4, eh * 0.55, plate); D.text(g, e[0], x, by + bh - eh - 22, T.fg, { align: 'center', bold: true, size: 12 }); D.text(g, e[2], x, by + bh - eh - 38, e[2].includes('负') || e[2] === '阴极' ? T.c1 : T.c2, { align: 'center', size: 12 }); });
      if (cf.gasL) for (let k = 0; k < 8; k++) D.circle(g, lx + Math.sin(k * 3 + t * 3) * 6, by + bh - 20 - ((t * 50 + k * 30) % (bh - 50)), 3, null, T.muted, 1);
      if (cf.gasR) for (let k = 0; k < 8; k++) D.circle(g, rx + Math.sin(k * 2 + t * 3) * 6, by + bh - 20 - ((t * 50 + k * 30) % (bh - 50)), 3, null, cf === C.fuel ? T.muted : 'rgba(170,200,60,0.9)', 1.2);
      const wy = 30, path = [[lx, by + bh - eh - 10], [lx, wy], [rx, wy], [rx, by + bh - eh - 10]];
      wire(g, path);
      const mx = (lx + rx) / 2;
      if (cf.t === 'gal') { D.circle(g, mx, wy, 16, T.stage, T.fg, 1.5); D.text(g, 'V', mx, wy, T.fg, { align: 'center', bold: true }); D.text(g, fmt(E, 3) + ' V', mx, wy + 28, T.accent, { align: 'center', mono: true }); }
      else { D.rect(g, mx - 30, wy - 14, 60, 28, T.stage); battery(g, mx, wy, false, '', true); D.text(g, '−', mx - 16, wy - 18, T.c1, { align: 'center', bold: true }); D.text(g, '+', mx + 16, wy - 18, T.c2, { align: 'center', bold: true }); D.text(g, '电源 ' + p.U + ' V', mx, wy + 26, T.muted, { align: 'center', size: 11 }); }
      // 电子流：原电池从负极（左）到正极（右）；电解池电子从电源负极流向阴极（左），从阳极（右）流回电源正极
      flowDots(g, cf.t === 'gal' ? path : path.slice().reverse(), t * 40 * sp, T.c4, 26);
      D.text(g, 'e⁻', cf.t === 'gal' ? lx + 20 : rx - 30, wy - 14, T.c4, { bold: true });
      if (cf.two) { cf.ionsR.forEach(([nm], i) => { for (let k = 0; k < 4; k++) D.text(g, nm, rx - 40 - ((t * 15 + k * 30 + i * 10) % 60), by + 70 + k * 35 + i * 15, nm.includes('+') ? T.c2 : T.c1, { size: 10, align: 'center' }); }); }
      out.set([['装置类型', cf.t === 'gal' ? '原电池（化学能→电能）' : '电解池（电能→化学能）'], [cf.L[2] + '（' + cf.L[0] + '）', cf.rl], [cf.R[2] + '（' + cf.R[0] + '）', cf.rr], ['总反应', cf.tot], cf.t === 'gal' ? ['电动势', fmt(E, 3) + ' V'] : ['外加电压', p.U + ' V'], ['电子流向', cf.t === 'gal' ? `${cf.L[2]} → 外电路 → ${cf.R[2]}` : '电源负极 → 阴极；阳极 → 电源正极']]);
    });
  }
});

/* ---------- 分子结构（共用渲染） ---------- */
const CPK = { H: ['#f0f0f0', 0.28], C: ['#4a4a4a', 0.42], N: ['#3a5cf0', 0.42], O: ['#e8301e', 0.42], F: ['#7fd34e', 0.38], Cl: ['#30c030', 0.5], S: ['#e8c020', 0.5], P: ['#f08020', 0.5], B: ['#f5a5a5', 0.4], Xe: ['#5aa0c0', 0.5], Na: ['#ab5cf2', 0.5], Cs: ['#57178f', 0.5] };
const V3 = { n: a => { const l = Math.hypot(...a) || 1; return a.map(x => x / l); }, ...v3 };
function bdir(r, th, ph, hint = [0, 0, 1]) {
  r = V3.n(r); let u = V3.sub(hint, V3.mul(r, V3.dot(hint, r))); if (V3.len(u) < 1e-6) u = V3.sub([0, 1, 0], V3.mul(r, V3.dot([0, 1, 0], r))); u = V3.n(u); const w = V3.cross(r, u);
  th *= PI / 180; ph *= PI / 180; return V3.add(V3.mul(r, Math.cos(th)), V3.add(V3.mul(u, Math.sin(th) * Math.cos(ph)), V3.mul(w, Math.sin(th) * Math.sin(ph))));
}
function molFrom(center, ligs, lps, extra = {}) { // 中心原子 + 配体方向
  const atoms = [{ e: center, p: [0, 0, 0] }], bonds = [];
  ligs.forEach(([e, d, len, ord]) => { atoms.push({ e, p: V3.mul(V3.n(d), len) }); bonds.push([0, atoms.length - 1, ord || 1]); });
  return { atoms, bonds, lps: (lps || []).map(d => [0, V3.n(d)]), ...extra };
}
const TET = [[0, 1, 0], ...[0, 120, 240].map(a => [Math.sin(1.9106) * Math.cos(a * PI / 180), Math.cos(1.9106), Math.sin(1.9106) * Math.sin(a * PI / 180)])];
const TRI = [0, 120, 240].map(a => [Math.cos((a + 90) * PI / 180), Math.sin((a + 90) * PI / 180), 0]);
function drawMol(c, cam, M, s, showLP) {
  const g = c.g, P = M.atoms.map(a => cam.proj(a.p, c, s)), items = [];
  M.bonds.forEach(([i, j, o]) => items.push({ z: (P[i][2] + P[j][2]) / 2 - 0.01, draw: () => {
    const a = P[i], b = P[j], dx = b[0] - a[0], dy = b[1] - a[1], L2 = Math.hypot(dx, dy) || 1, nx = -dy / L2, ny = dx / L2;
    const offs = o === 2 ? [-3.5, 3.5] : o === 3 ? [-5, 0, 5] : o === 1.5 ? [0] : [0];
    offs.forEach(k => D.line(g, a[0] + nx * k, a[1] + ny * k, b[0] + nx * k, b[1] + ny * k, T.muted, o === 1.5 ? 4 : 3.2));
    if (o === 1.5) D.line(g, a[0] + nx * 5, a[1] + ny * 5, b[0] + nx * 5, b[1] + ny * 5, T.muted, 1.4, [3, 3]);
  } }));
  if (showLP) (M.lps || []).forEach(([i, d]) => { const tip = V3.add(M.atoms[i].p, V3.mul(d, 0.75)), q = cam.proj(tip, c, s), a = P[i]; items.push({ z: q[2], draw: () => { g.save(); g.translate((a[0] + q[0]) / 2, (a[1] + q[1]) / 2); g.rotate(Math.atan2(q[1] - a[1], q[0] - a[0])); g.fillStyle = alpha(T.c5, 0.28); g.strokeStyle = alpha(T.c5, 0.6); g.beginPath(); g.ellipse(0, 0, Math.hypot(q[0] - a[0], q[1] - a[1]) / 2 + 6, 9 * q[3], 0, 0, TAU); g.fill(); g.stroke(); D.circle(g, 2, -3, 1.8, T.c5); D.circle(g, 2, 3, 1.8, T.c5); g.restore(); } }); });
  M.atoms.forEach((a, i) => items.push({ z: P[i][2], draw: () => {
    const [col, r0] = CPK[a.e] || ['#999', 0.4], r = r0 * s * cam.scale * P[i][3] * (M.scale || 1), x = P[i][0], y = P[i][1];
    const gr = g.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.35, col); gr.addColorStop(1, alpha(col, 1)); g.fillStyle = gr;
    g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); g.strokeStyle = alpha(T.fg, 0.35); g.lineWidth = 1; g.stroke();
    if (a.lab !== false && r > 9) D.text(g, a.e, x, y, a.e === 'H' || a.e === 'S' || a.e === 'F' || a.e === 'B' ? '#222' : '#fff', { align: 'center', bold: true, size: Math.min(13, r * 0.8) });
    if (a.hl) D.circle(g, x, y, r + 4, null, T.c4, 2.4);
  } }));
  items.sort((a, b) => a.z - b.z).forEach(it => it.draw());
}
function molViewer(L, mols, first) {
  const c = L.canvas(), cam = new Cam3({ yaw: 0.4, pitch: 0.25, persp: 0.05 });
  L.orbit(c, cam);
  const sel = L.select('分子', Object.entries(mols).map(([k, v]) => [k, v.name]), first, () => L.draw());
  const lp = L.check('显示孤电子对', true), spin = L.check('自动旋转', true);
  const out = L.out();
  L.note('拖动画布旋转，滚轮缩放。');
  L.loop(dt => { if (spin.v) { cam.yaw += dt * 0.5; L.drawFn(); } });
  L.onDraw(() => {
    c.clear(); const M = mols[sel.v], ext = Math.max(...M.atoms.map(a => V3.len(a.p))) + 0.6, s = Math.min(c.w, c.h) / (2.6 * ext);
    drawMol(c, cam, M, s, lp.v);
    out.set(M.rows);
  });
}
const H = 'H';
const MOLS = {
  co2: molFrom('C', [['O', [1, 0, 0], 1.16, 2], ['O', [-1, 0, 0], 1.16, 2]], [], { name: 'CO₂ 二氧化碳', rows: [['σ 键 + 孤电子对', '2 + 0 = 2'], ['VSEPR 模型', '直线形'], ['空间结构', '直线形'], ['中心原子杂化', 'sp'], ['键角', '180°'], ['分子极性', '非极性分子']] }),
  h2o: molFrom('O', [[H, [Math.sin(0.912), -Math.cos(0.912), 0], 0.96], [H, [-Math.sin(0.912), -Math.cos(0.912), 0], 0.96]], [[0, 0.58, 0.82], [0, 0.58, -0.82]], { name: 'H₂O 水', rows: [['σ 键 + 孤电子对', '2 + 2 = 4'], ['孤电子对数', '(6 − 2×1)/2 = 2'], ['VSEPR 模型', '四面体形'], ['空间结构', 'V 形'], ['杂化', 'sp³'], ['键角', '104.5°'], ['分子极性', '极性分子']] }),
  nh3: molFrom('N', TET.slice(1).map(d => [H, V3.add(d, [0, -0.05, 0]), 1.01]), [[0, 1, 0]], { name: 'NH₃ 氨', rows: [['σ 键 + 孤电子对', '3 + 1 = 4'], ['孤电子对数', '(5 − 3×1)/2 = 1'], ['VSEPR 模型', '四面体形'], ['空间结构', '三角锥形'], ['杂化', 'sp³'], ['键角', '107°'], ['分子极性', '极性分子']] }),
  ch4: molFrom('C', TET.map(d => [H, d, 1.09]), [], { name: 'CH₄ 甲烷', rows: [['σ 键 + 孤电子对', '4 + 0 = 4'], ['VSEPR 模型', '正四面体形'], ['空间结构', '正四面体形'], ['杂化', 'sp³'], ['键角', '109°28′'], ['分子极性', '非极性分子']] }),
  nh4: molFrom('N', TET.map(d => [H, d, 1.03]), [], { name: 'NH₄⁺ 铵根离子', rows: [['σ 键 + 孤电子对', '4 + 0 = 4'], ['孤电子对数', '(5 − 1 − 4×1)/2 = 0'], ['空间结构', '正四面体形'], ['杂化', 'sp³'], ['说明', 'N 提供孤电子对与 H⁺ 形成配位键']] }),
  h3o: molFrom('O', TET.slice(1).map(d => [H, V3.add(d, [0, -0.1, 0]), 0.98]), [[0, 1, 0]], { name: 'H₃O⁺ 水合氢离子', rows: [['σ 键 + 孤电子对', '3 + 1 = 4'], ['孤电子对数', '(6 − 1 − 3×1)/2 = 1'], ['空间结构', '三角锥形'], ['杂化', 'sp³'], ['说明', '含配位键']] }),
  bf3: molFrom('B', TRI.map(d => ['F', d, 1.31]), [], { name: 'BF₃ 三氟化硼', rows: [['σ 键 + 孤电子对', '3 + 0 = 3'], ['孤电子对数', '(3 − 3×1)/2 = 0'], ['空间结构', '平面三角形'], ['杂化', 'sp²'], ['键角', '120°'], ['分子极性', '非极性分子']] }),
  so2: molFrom('S', [['O', [Math.sin(1.04), -Math.cos(1.04), 0], 1.43, 2], ['O', [-Math.sin(1.04), -Math.cos(1.04), 0], 1.43, 2]], [[0, 1, 0]], { name: 'SO₂ 二氧化硫', rows: [['σ 键 + 孤电子对', '2 + 1 = 3'], ['孤电子对数', '(6 − 2×2)/2 = 1'], ['VSEPR 模型', '平面三角形'], ['空间结构', 'V 形'], ['杂化', 'sp²'], ['键角', '约 119°'], ['分子极性', '极性分子']] }),
  so3: molFrom('S', TRI.map(d => ['O', d, 1.42, 2]), [], { name: 'SO₃ 三氧化硫', rows: [['σ 键 + 孤电子对', '3 + 0 = 3'], ['孤电子对数', '(6 − 3×2)/2 = 0'], ['空间结构', '平面三角形'], ['杂化', 'sp²'], ['分子极性', '非极性分子']] }),
  pcl5: molFrom('P', [['Cl', [0, 1, 0], 2.1], ['Cl', [0, -1, 0], 2.1], ...[0, 120, 240].map(a => ['Cl', [Math.cos(a * PI / 180), 0, Math.sin(a * PI / 180)], 2.02])], [], { name: 'PCl₅ 五氯化磷', rows: [['价层电子对数', '5'], ['空间结构', '三角双锥形'], ['键角', '90°、120°'], ['说明', '中心原子价层超过 8 电子']] }),
  sf6: molFrom('S', [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].map(d => ['F', d, 1.56]), [], { name: 'SF₆ 六氟化硫', rows: [['价层电子对数', '6'], ['空间结构', '正八面体形'], ['键角', '90°'], ['分子极性', '非极性分子']] })
};
Lab.reg({
  id: 'c-vsepr', subj: 'chem', book: 3, unit: '分子结构与性质', title: '价层电子对互斥模型与杂化', kw: 'VSEPR 杂化轨道 sp sp2 sp3 孤电子对 键角 分子极性 空间结构',
  info: `<p class="fb">价层电子对数 = σ 键电子对数 + 中心原子上的孤电子对数<br>孤电子对数 = ½(a − xb)　a：中心原子价电子数（离子要加减电荷），x：配位原子数，b：配位原子最多能接受的电子数（H 为 1，其余为 8 − 价电子数）</p>
  <p>价层电子对数 2、3、4 对应 VSEPR 模型直线形、平面三角形、四面体形，中心原子杂化分别为 sp、sp²、sp³。略去孤电子对得到分子的空间结构。孤电子对排斥力较大，使键角减小：CH₄ 109°28′ &gt; NH₃ 107° &gt; H₂O 104.5°。</p>`,
  tasks: ['依次查看 CH₄、NH₃、H₂O，解释键角为什么依次减小。', '为什么 CO₂ 是非极性分子而 SO₂ 是极性分子？', '计算 NH₄⁺ 和 H₃O⁺ 的孤电子对数，比较它们与 NH₃、H₂O 的结构。'],
  init(L) { molViewer(L, MOLS, 'h2o'); }
});

/* ---------- 有机分子 ---------- */
const ORG = (() => {
  const mk = (atoms, bonds, name, rows) => ({ atoms: atoms.map(([e, p, hl]) => ({ e, p, hl })), bonds, name, rows, lps: [] });
  // 乙烷（交叉式）
  const eth = [['C', [-0.77, 0, 0]], ['C', [0.77, 0, 0]]], eb = [[0, 1, 1]];
  [0, 120, 240].forEach(a => { eth.push([H, V3.add([-0.77, 0, 0], V3.mul(bdir([-1, 0, 0], 70.5, a, [0, 1, 0]), 1.09))]); eb.push([0, eth.length - 1, 1]); eth.push([H, V3.add([0.77, 0, 0], V3.mul(bdir([1, 0, 0], 70.5, a + 60, [0, 1, 0]), 1.09))]); eb.push([1, eth.length - 1, 1]); });
  // 乙醇 CH3-CH2-OH
  const C1 = [-1.2, -0.3, 0], C2 = [0.25, 0.25, 0], O = [1.25, -0.7, 0], Hh = [2.1, -0.3, 0];
  const et = [['C', C1], ['C', C2], ['O', O, true], [H, Hh, true]], etb = [[0, 1, 1], [1, 2, 1], [2, 3, 1]];
  [0, 120, 240].forEach(a => { et.push([H, V3.add(C1, V3.mul(bdir(V3.sub(C1, C2), 70.5, a, [0, 1, 0]), 1.09))]); etb.push([0, et.length - 1, 1]); });
  [60, 300].forEach(a => { et.push([H, V3.add(C2, V3.mul(bdir(V3.sub(C2, V3.mul(V3.add(C1, O), 0.5)), 54, a, [0, 0, 1]), 1.09))]); etb.push([1, et.length - 1, 1]); });
  // 乙酸 CH3-COOH
  const A1 = [-1.3, 0, 0], A2 = [0.2, 0, 0], O1 = [0.85, 1.05, 0], O2 = [0.85, -1.15, 0], H2 = [1.8, -1.0, 0];
  const ac = [['C', A1], ['C', A2, true], ['O', O1, true], ['O', O2, true], [H, H2, true]], acb = [[0, 1, 1], [1, 2, 2], [1, 3, 1], [3, 4, 1]];
  [0, 120, 240].forEach(a => { ac.push([H, V3.add(A1, V3.mul(bdir([-1, 0, 0], 70.5, a, [0, 1, 0]), 1.09))]); acb.push([0, ac.length - 1, 1]); });
  // 苯
  const bz = [], bzb = [];
  for (let k = 0; k < 6; k++) { const a = k * PI / 3; bz.push(['C', [1.39 * Math.cos(a), 1.39 * Math.sin(a), 0]]); }
  for (let k = 0; k < 6; k++) { const a = k * PI / 3; bz.push([H, [2.47 * Math.cos(a), 2.47 * Math.sin(a), 0]]); bzb.push([k, (k + 1) % 6, 1.5], [k, k + 6, 1]); }
  const cH = (x, s) => [H, [x + s * 0.55, 0.92, 0]], cH2 = (x, s) => [H, [x + s * 0.55, -0.92, 0]];
  return {
    ch4: { ...MOLS.ch4, name: '甲烷 CH₄', rows: [['类别', '烷烃'], ['碳原子杂化', 'sp³'], ['空间结构', '正四面体'], ['典型反应', '取代反应（光照下与 Cl₂）']] },
    c2h6: mk(eth, eb, '乙烷 C₂H₆', [['类别', '烷烃（饱和烃）'], ['碳原子杂化', 'sp³'], ['结构', 'C—C 单键可以旋转'], ['典型反应', '取代反应']]),
    c2h4: mk([['C', [-0.67, 0, 0], true], ['C', [0.67, 0, 0], true], cH(-1.2, 0), cH2(-1.2, 0), cH(1.2, 0), cH2(1.2, 0)], [[0, 1, 2], [0, 2, 1], [0, 3, 1], [1, 4, 1], [1, 5, 1]], '乙烯 C₂H₄', [['官能团', '碳碳双键'], ['碳原子杂化', 'sp²'], ['结构', '6 个原子共平面，键角约 120°'], ['典型反应', '加成（使溴水褪色）、加聚、被酸性 KMnO₄ 氧化']]),
    c2h2: mk([['C', [-0.6, 0, 0], true], ['C', [0.6, 0, 0], true], [H, [-1.66, 0, 0]], [H, [1.66, 0, 0]]], [[0, 1, 3], [0, 2, 1], [1, 3, 1]], '乙炔 C₂H₂', [['官能团', '碳碳三键'], ['碳原子杂化', 'sp'], ['结构', '4 个原子共直线'], ['σ 键与 π 键', '3 个 σ 键，2 个 π 键']]),
    c6h6: mk(bz, bzb, '苯 C₆H₆', [['结构', '平面正六边形，12 个原子共平面'], ['碳原子杂化', 'sp²'], ['化学键', '6 个碳原子间形成大 π 键（虚线），六个 C—C 键完全相同'], ['典型反应', '易取代（溴代、硝化），难加成，不能使酸性 KMnO₄ 褪色']]),
    etoh: mk(et, etb, '乙醇 C₂H₅OH', [['官能团', '羟基 —OH（高亮）'], ['典型反应', '与 Na 反应放出 H₂；催化氧化生成乙醛；与乙酸酯化'], ['氢键', '分子间可形成氢键，沸点较高，与水互溶']]),
    hac: mk(ac, acb, '乙酸 CH₃COOH', [['官能团', '羧基 —COOH（高亮）'], ['酸性', '弱酸，酸性强于碳酸'], ['典型反应', '酯化反应：酸脱羟基醇脱氢'], ['方程式', 'CH₃COOH + C₂H₅OH ⇌ CH₃COOC₂H₅ + H₂O']]),
    hcho: molFrom('C', [['O', [0, 1, 0], 1.21, 2], [H, [Math.sin(1.02), -Math.cos(1.02), 0], 1.1], [H, [-Math.sin(1.02), -Math.cos(1.02), 0], 1.1]], [], { name: '甲醛 HCHO', rows: [['官能团', '醛基 —CHO'], ['碳原子杂化', 'sp²'], ['空间结构', '平面三角形'], ['典型反应', '银镜反应、与新制 Cu(OH)₂ 反应']] })
  };
})();
Lab.reg({
  id: 'c-organic', subj: 'chem', book: 4, unit: '有机化合物的结构特点 · 烃 · 烃的衍生物', title: '有机分子结构与官能团', kw: '有机物 烷烃 烯烃 炔烃 苯 乙醇 乙酸 甲醛 官能团 共平面 球棍模型',
  info: `<p>球棍模型中高亮的原子组成官能团。碳原子的杂化方式决定了分子的空间结构：</p>
  <p class="fb">sp³：四面体，与 4 个原子相连（烷烃）<br>sp²：平面三角形（烯烃、苯环、醛基、羧基中的碳）<br>sp：直线形（炔烃）</p>
  <p>判断原子共面：与 C=C 直接相连的 6 个原子共平面；苯环上 12 个原子共平面；与 C≡C 直接相连的 4 个原子共直线；甲基上的氢最多只有 1 个与平面共面。</p>`,
  tasks: ['旋转乙烯，确认 6 个原子共平面；旋转乙烷，观察两个甲基的相对位置。', '比较乙醇与乙酸的官能团，说明为什么乙酸有酸性而乙醇没有。', '苯分子中为什么不存在单双键交替？'],
  init(L) { molViewer(L, ORG, 'c2h4'); }
});

/* ---------- 晶体结构 ---------- */
Lab.reg({
  id: 'c-crystal', subj: 'chem', book: 3, unit: '晶体结构与性质', title: '晶胞与均摊法', kw: '晶胞 均摊法 配位数 空间利用率 密度 NaCl CsCl 金刚石 干冰 金属晶体 体心立方 面心立方',
  info: `<p><b>均摊法</b>：立方晶胞中，顶点原子为 8 个晶胞共有，计 1/8；棱上 1/4；面上 1/2；体内 1。</p>
  <p class="fb">晶体密度 ρ = N·M / (N_A·a³)　N 为晶胞中粒子（或「化学式」）数<br>简单立方：配位数 6，空间利用率 52%<br>体心立方：配位数 8，68%　面心立方（最密堆积）：配位数 12，74%</p>
  <p>颜色区分位置：顶点、棱心、面心、体内。勾选「2×2×2」可以看到晶胞如何在空间无隙并置。</p>`,
  tasks: ['数一数 NaCl 晶胞中 Na⁺ 和 Cl⁻ 各有几个，与化学式比较。', '金刚石晶胞中有几个碳原子？每个碳原子的配位数是多少？', '已知铜的晶胞参数 a = 361.5 pm，验证密度约为 8.93 g/cm³。'],
  init(L) {
    const c = L.canvas(), cam = new Cam3({ yaw: -0.55, pitch: 0.4, persp: 0.06 });
    L.orbit(c, cam);
    const X = {
      sc: { name: '简单立方（钋 Po）', a: 336, M: 209, sites: [['Po', 'corner']], cn: 6, pf: '52%', f: 'Po' },
      bcc: { name: '体心立方（Na、K、Fe）', a: 286.6, M: 55.85, sites: [['Fe', 'corner'], ['Fe', 'body']], cn: 8, pf: '68%', f: 'Fe' },
      fcc: { name: '面心立方（Cu、Al、Au）', a: 361.5, M: 63.55, sites: [['Cu', 'corner'], ['Cu', 'face']], cn: 12, pf: '74%', f: 'Cu' },
      nacl: { name: '氯化钠 NaCl', a: 564, M: 58.44, sites: [['Cl', 'corner'], ['Cl', 'face'], ['Na', 'edge'], ['Na', 'body']], cn: 6, f: 'NaCl' },
      cscl: { name: '氯化铯 CsCl', a: 412, M: 168.36, sites: [['Cl', 'corner'], ['Cs', 'body']], cn: 8, f: 'CsCl' },
      dia: { name: '金刚石 C', a: 356.7, M: 12.01, sites: [['C', 'corner'], ['C', 'face'], ['C', 'tet']], cn: 4, f: 'C' },
      co2: { name: '干冰 CO₂（分子晶体）', a: 562, M: 44.01, sites: [['C', 'corner'], ['C', 'face']], cn: 12, f: 'CO₂', mol: true }
    };
    const sel = L.select('晶体', Object.entries(X).map(([k, v]) => [k, v.name]), 'nacl', () => L.draw());
    const big = L.check('显示 2×2×2 晶胞', false), lab = L.check('按位置着色（顶点/棱/面/体）', true);
    const out = L.out();
    const POS = {
      corner: [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1]],
      body: [[0.5, 0.5, 0.5]], face: [[0.5, 0.5, 0], [0.5, 0.5, 1], [0.5, 0, 0.5], [0.5, 1, 0.5], [0, 0.5, 0.5], [1, 0.5, 0.5]],
      edge: [[0.5, 0, 0], [0.5, 1, 0], [0.5, 0, 1], [0.5, 1, 1], [0, 0.5, 0], [1, 0.5, 0], [0, 0.5, 1], [1, 0.5, 1], [0, 0, 0.5], [1, 0, 0.5], [0, 1, 0.5], [1, 1, 0.5]],
      tet: [[0.25, 0.25, 0.25], [0.75, 0.75, 0.25], [0.75, 0.25, 0.75], [0.25, 0.75, 0.75]]
    };
    const W = { corner: 1 / 8, edge: 1 / 4, face: 1 / 2, body: 1, tet: 1 };
    const WN = { corner: '顶点 ×1/8', edge: '棱心 ×1/4', face: '面心 ×1/2', body: '体心 ×1', tet: '体内 ×1' };
    L.onDraw(() => {
      c.clear(); const x = X[sel.v], n = big.v ? 2 : 1, s = Math.min(c.w, c.h) / (2.4 * n), atoms = [], bonds = [];
      const key = p => p.map(v => v.toFixed(3)).join(',');
      const seen = new Set();
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) for (let k = 0; k < n; k++) x.sites.forEach(([e, where]) => POS[where].forEach(q => {
        const p = [q[0] + i, q[1] + j, q[2] + k], kk = key(p); if (seen.has(kk)) return; seen.add(kk);
        atoms.push({ e, p: p.map(v => v - n / 2), where });
      }));
      const colOf = a => lab.v ? { corner: T.c1, edge: T.c4, face: T.c2, body: T.c3, tet: T.c3 }[a.where] : (CPK[a.e] || ['#999'])[0];
      const g = c.g, P = atoms.map(a => cam.proj(a.p, c, s));
      // 晶胞棱
      const E = []; for (let i = 0; i <= n; i++) for (let j = 0; j <= n; j++) { E.push([[i, j, 0], [i, j, n]], [[i, 0, j], [i, n, j]], [[0, i, j], [n, i, j]]); }
      E.forEach(([a, b]) => { const A = cam.proj(a.map(v => v - n / 2), c, s), B = cam.proj(b.map(v => v - n / 2), c, s); D.line(g, A[0], A[1], B[0], B[1], alpha(T.fg, 0.35), 1.2); });
      if (sel.v === 'dia') atoms.forEach((a, i) => { if (a.where !== 'tet') return; atoms.forEach((b, j) => { if (i !== j && V3.len(V3.sub(a.p, b.p)) < 0.45) bonds.push([i, j]); }); });
      if (sel.v === 'nacl' || sel.v === 'cscl') atoms.forEach((a, i) => atoms.forEach((b, j) => { if (j > i && a.e !== b.e && V3.len(V3.sub(a.p, b.p)) < (sel.v === 'nacl' ? 0.51 : 0.87)) bonds.push([i, j]); }));
      bonds.forEach(([i, j]) => D.line(g, P[i][0], P[i][1], P[j][0], P[j][1], alpha(T.muted, 0.7), 2));
      const order = atoms.map((a, i) => i).sort((i, j) => P[i][2] - P[j][2]);
      order.forEach(i => {
        const a = atoms[i], big2 = a.e === 'Cl' ? 0.17 : a.e === 'Cs' ? 0.2 : a.e === 'Na' ? 0.11 : x.mol ? 0.08 : 0.12, r = big2 * s * cam.scale * P[i][3], [px, py] = P[i], col = colOf(a);
        if (x.mol) { const d = [0.12, 0.12, 0.12].map((v, k) => v * (k === (i % 3) ? 1.6 : 0.2)); const A = cam.proj(V3.add(a.p, d), c, s), B = cam.proj(V3.sub(a.p, d), c, s); D.line(g, A[0], A[1], B[0], B[1], T.c2, 3); D.circle(g, A[0], A[1], r * 0.8, CPK.O[0]); D.circle(g, B[0], B[1], r * 0.8, CPK.O[0]); }
        const gr = g.createRadialGradient(px - r * 0.3, py - r * 0.3, r * 0.1, px, py, r); gr.addColorStop(0, '#fff'); gr.addColorStop(0.4, col); gr.addColorStop(1, col);
        g.fillStyle = gr; g.beginPath(); g.arc(px, py, r, 0, TAU); g.fill(); g.strokeStyle = alpha(T.fg, 0.3); g.stroke();
      });
      const counts = {}; x.sites.forEach(([e, w]) => { counts[e] = counts[e] || []; counts[e].push([w, POS[w].length]); });
      const rows = Object.entries(counts).map(([e, arr]) => [`${e} 的个数`, arr.map(([w, k]) => `${k}×${W[w] === 1 ? 1 : '1/' + 1 / W[w]}`).join(' + ') + ' = ' + arr.reduce((s2, [w, k]) => s2 + k * W[w], 0)]);
      const N = sel.v === 'nacl' ? 4 : sel.v === 'cscl' ? 1 : Object.values(counts)[0].reduce((s2, [w, k]) => s2 + k * W[w], 0);
      const rho = N * x.M / (6.022e23 * (x.a * 1e-10) ** 3);
      rows.push(['每个晶胞含「' + x.f + '」', N], ['配位数', x.cn], ...(x.pf ? [['空间利用率', x.pf]] : []), ['晶胞参数 a', x.a + ' pm'], ['密度 ρ = NM/(N_A a³)', fmt(rho, 3) + ' g/cm³']);
      out.set(rows);
      if (lab.v) { let yy = 18; Object.entries(WN).forEach(([w, t2]) => { if (!x.sites.some(q => q[1] === w)) return; D.circle(g, 16, yy, 5, { corner: T.c1, edge: T.c4, face: T.c2, body: T.c3, tet: T.c3 }[w]); D.text(g, t2, 26, yy, T.muted, { size: 11 }); yy += 18; }); }
    });
  }
});
