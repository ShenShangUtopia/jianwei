'use strict';
/* ======================= 物理（必修） ======================= */

// 沿折线移动的电流点
function flowDots(g, path, phase, color, gap = 22) {
  let total = 0; const segs = [];
  for (let i = 0; i < path.length - 1; i++) { const [x1, y1] = path[i], [x2, y2] = path[i + 1], l = Math.hypot(x2 - x1, y2 - y1); segs.push([x1, y1, x2, y2, l, total]); total += l; }
  for (let s = ((phase % gap) + gap) % gap; s < total; s += gap) {
    const sg = segs.find(q => s >= q[5] && s <= q[5] + q[4]); if (!sg) continue;
    const t = (s - sg[5]) / sg[4]; D.circle(g, lerp(sg[0], sg[2], t), lerp(sg[1], sg[3], t), 2.6, color);
  }
}
function wire(g, pts, c, w = 1.8) { D.poly(g, pts, null, c || T.fg, w, false); }
function resistor(g, x1, y1, x2, y2, label, c) { // 沿线段画电阻方框
  const mx = (x1 + x2) / 2, my = (y1 + y2) / 2, hor = Math.abs(x2 - x1) > Math.abs(y2 - y1), L2 = 22, W2 = 8;
  if (hor) { D.line(g, x1, y1, mx - L2, my, T.fg, 1.8); D.line(g, mx + L2, my, x2, y2, T.fg, 1.8); D.rect(g, mx - L2, my - W2, 2 * L2, 2 * W2, T.stage, c || T.fg, 1.8); D.text(g, label, mx, my - W2 - 10, T.fg, { align: 'center', size: 12 }); }
  else { D.line(g, x1, y1, mx, my - L2, T.fg, 1.8); D.line(g, mx, my + L2, x2, y2, T.fg, 1.8); D.rect(g, mx - W2, my - L2, 2 * W2, 2 * L2, T.stage, c || T.fg, 1.8); D.text(g, label, mx + W2 + 6, my, T.fg, { size: 12 }); }
}
function meter(g, x, y, letter, val) { D.circle(g, x, y, 14, T.stage, T.fg, 1.8); D.text(g, letter, x, y + 1, T.fg, { align: 'center', bold: true, size: 13 }); if (val) D.text(g, val, x, y + 26, T.accent, { align: 'center', size: 11.5, mono: true }); }
function battery(g, x, y, vertical, label, flip) { // 长线为正极；flip 时正极在右/下
  const s = flip ? -1 : 1;
  if (vertical) { D.line(g, x - 14, y - 4 * s, x + 14, y - 4 * s, T.fg, 2); D.line(g, x - 7, y + 4 * s, x + 7, y + 4 * s, T.fg, 4); }
  else { D.line(g, x - 4 * s, y - 14, x - 4 * s, y + 14, T.fg, 2); D.line(g, x + 4 * s, y - 7, x + 4 * s, y + 7, T.fg, 4); }
  if (label) D.text(g, label, x + (vertical ? 20 : 0), y + (vertical ? 0 : -24), T.fg, { align: vertical ? 'left' : 'center', size: 12 });
}

/* ---------- 匀变速直线运动 ---------- */
Lab.reg({
  id: 'p-kin', subj: 'phys', book: 0, unit: '匀变速直线运动的研究', title: '匀变速直线运动与打点纸带', kw: '位移 速度 加速度 x-t v-t 图像 自由落体 逐差法',
  info: `<p class="fb">v = v₀ + at　x = v₀t + ½at²　v² − v₀² = 2ax<br>连续相等时间 T 内的位移差 Δx = aT²（逐差法求加速度）<br>某段时间中间时刻的瞬时速度 = 该段平均速度</p>
  <p>纸带上每 0.1 s 打一个计数点。v-t 图像与时间轴围成的面积等于位移，图像斜率等于加速度；x-t 图像切线斜率等于瞬时速度。自由落体是 v₀ = 0、a = g 的匀加速直线运动。</p>`,
  tasks: ['选「匀减速」，观察 v-t 图像穿过时间轴时小车怎样运动，x-t 图像此时有什么特点？', '读出纸带上相邻计数点的间距，用逐差法求 a，再与设定值比较。', '自由落体中，前 1 s、前 2 s、前 3 s 内的位移之比是多少？'],
  init(L) {
    const c = L.canvas();
    let t = 0;
    const p = L.params({ v0: ['初速度 v₀', -10, 10, 0.5, 1, 'm/s'], a: ['加速度 a', -5, 10, 0.1, 2, 'm/s²'], T: ['总时长', 1, 8, 0.5, 4, 's'] }, () => { t = 0; L.draw(); });
    L.button('匀速', () => { p.$v0.set(3, true); p.a = 0; }); L.button('匀加速', () => { p.$v0.set(1, true); p.a = 2; }); L.button('匀减速', () => { p.$v0.set(8, true); p.a = -3; }); L.button('自由落体', () => { p.$v0.set(0, true); p.a = 9.8; });
    L.group('运行');
    const run = L.loop(dt => { t += dt; if (t >= p.T) { t = p.T; run.pause(); } L.drawFn(); }, false);
    L.button('开始 / 暂停', () => { if (t >= p.T) t = 0; run.toggle(); }, true); L.button('重置', () => { t = 0; run.pause(); L.draw(); });
    const out = L.out();
    L.onDraw(() => {
      c.clear(); const g = c.g, { v0, a, T: Tm } = p, X = tt => v0 * tt + a * tt * tt / 2, V = tt => v0 + a * tt;
      const samples = [...Array(101).keys()].map(i => X(Tm * i / 100)), xmin = Math.min(0, ...samples), xmax = Math.max(0.5, ...samples);
      const pad = 40, W = c.w - 2 * pad, sx = W / (xmax - xmin || 1), PX = x => pad + (x - xmin) * sx;
      // 轨道与小车
      const ty = 60; D.line(g, pad - 10, ty + 14, c.w - pad + 10, ty + 14, T.axis, 2);
      for (let m = Math.ceil(xmin); m <= xmax; m += Math.max(1, Math.round(60 / sx))) { D.line(g, PX(m), ty + 14, PX(m), ty + 20, T.axis, 1); D.text(g, m + ' m', PX(m), ty + 30, T.muted, { align: 'center', size: 10, mono: true }); }
      const cx = PX(X(t)); D.rrect(g, cx - 18, ty - 8, 36, 20, 4, T.c1); D.circle(g, cx - 10, ty + 12, 4, T.fg); D.circle(g, cx + 10, ty + 12, 4, T.fg);
      D.arrow(g, cx, ty - 18, cx + V(t) * 6, ty - 18, T.c2, 2.4); D.text(g, 'v', cx + V(t) * 6 + (V(t) >= 0 ? 6 : -12), ty - 18, T.c2);
      // 纸带
      const py = 108; D.rect(g, pad - 10, py - 12, W + 20, 24, alpha(T.c4, 0.18), T.line, 1);
      let last = null; const gaps = [];
      for (let k = 0; k * 0.1 <= t + 1e-9; k++) { const x = PX(X(k * 0.1)); D.circle(g, x, py, 2.6, T.fg); if (last != null) gaps.push(X(k * 0.1) - last); last = X(k * 0.1); }
      D.text(g, '纸带（每 0.1 s 一个计数点）', pad - 6, py + 22, T.muted, { size: 11 });
      // 图像
      const gy = 150, gh = c.h - gy - 30, gw = (c.w - 3 * pad) / 2;
      const ts = [...Array(121).keys()].map(i => Tm * i / 120), cur = ts.filter(x => x <= t);
      const xc = D.chart(g, pad, gy, gw, gh, [{ pts: ts.map(x => [x, X(x)]), color: T.grid2, dash: [4, 4] }, { pts: [...cur, t].map(x => [x, X(x)]), color: T.c1, w: 2.4 }], { title: 'x − t 图像（m）', xl: 't / s', xmin: 0, xmax: Tm });
      const vmin = Math.min(0, V(0), V(Tm)), vmax = Math.max(0.5, V(0), V(Tm));
      const vc = D.chart(g, 2 * pad + gw, gy, gw, gh, [{ pts: ts.map(x => [x, V(x)]), color: T.grid2, dash: [4, 4] }, { pts: [...cur, t].map(x => [x, V(x)]), color: T.c2, w: 2.4 }], { title: 'v − t 图像（m/s）', xl: 't / s', xmin: 0, xmax: Tm, ymin: vmin * 1.1, ymax: vmax * 1.1 });
      g.fillStyle = alpha(T.c2, 0.15); g.beginPath(); g.moveTo(vc.X(0), vc.Y(0)); [...cur, t].forEach(x => g.lineTo(vc.X(x), vc.Y(V(x)))); g.lineTo(vc.X(t), vc.Y(0)); g.fill();
      D.circle(g, xc.X(t), xc.Y(X(t)), 4, T.c1); D.circle(g, vc.X(t), vc.Y(V(t)), 4, T.c2);
      const dd = gaps.length > 1 ? gaps.slice(1).map((x, i) => x - gaps[i]) : [];
      out.set([['t', fmt(t, 2) + ' s'], ['位移 x', fmt(X(t), 3) + ' m'], ['速度 v', fmt(V(t), 3) + ' m/s'], ['相邻计数点间距', gaps.slice(-3).map(x => fmt(x * 100, 1)).join(', ') + ' cm'], ['相邻间距之差 Δx', dd.length ? fmt(dd[dd.length - 1] * 100, 2) + ' cm' : '—'], ['aT² 理论值', fmt(a * 0.01 * 100, 2) + ' cm']]);
    });
  }
});

/* ---------- 力的合成与分解 ---------- */
Lab.reg({
  id: 'p-force', subj: 'phys', book: 0, unit: '相互作用——力', title: '力的合成与分解', kw: '平行四边形定则 合力 分力 正交分解',
  info: `<p><b>平行四边形定则</b>：以两个分力为邻边作平行四边形，对角线就是合力。</p>
  <p class="fb">F = √(F₁² + F₂² + 2F₁F₂cos θ)<br>|F₁ − F₂| ≤ F ≤ F₁ + F₂</p>
  <p>力的分解是合成的逆运算：给定两个分力的方向，分解结果是唯一的。正交分解把力沿互相垂直的 x、y 轴分解：Fₓ = F cos α，F_y = F sin α。</p>`,
  tasks: ['保持两个分力大小不变，增大夹角，合力如何变化？', '两个 6 N 的力合力为 6 N，夹角是多少？', '分解模式：保持 F 不变，让两个方向夹角变小，两个分力怎样变化？'],
  init(L) {
    const c = L.canvas(), v = new View(c, -12, 12, -9, 9, { equal: true });
    const P = { F1: [6, 2], F2: [2, 5], F: [7, 4] };
    L.group('模式');
    const mode = L.seg('', [['add', '合成'], ['dec', '分解']], 'add', () => { gd.hidden = mode.v !== 'dec'; L.draw(); });
    const ring = L.check('显示合力范围圆环', true);
    const gd = L.group('分解方向'); gd.hidden = true;
    const q = L.params({ a1: ['方向 1 与 x 轴夹角', -90, 180, 1, 0, '°'], a2: ['方向 2 与 x 轴夹角', -90, 180, 1, 90, '°'] });
    L.button('正交分解', () => { q.$a1.set(0, true); q.a2 = 90; });
    const out = L.out();
    L.note('拖动箭头端点改变力的大小与方向。网格每格 1 N。');
    L.interact(c, {
      hit: (x, y) => (mode.v === 'add' ? ['F1', 'F2'] : ['F']).find(k => Math.hypot(v.X(P[k][0]) - x, v.Y(P[k][1]) - y) < 14),
      drag: (k, x, y) => { P[k] = [Math.round(v.ix(x) * 2) / 2, Math.round(v.iy(y) * 2) / 2]; }
    });
    L.onDraw(() => {
      v.begin({ xl: 'x', yl: 'y' });
      const mag = p => Math.hypot(p[0], p[1]), ang = p => Math.atan2(p[1], p[0]) * 180 / PI;
      if (mode.v === 'add') {
        const [a, b] = [P.F1, P.F2], R = [a[0] + b[0], a[1] + b[1]], m1 = mag(a), m2 = mag(b);
        if (ring.v) { const g = c.g; g.fillStyle = alpha(T.c3, 0.08); g.beginPath(); g.arc(v.X(0), v.Y(0), (m1 + m2) * v.sx, 0, TAU); g.arc(v.X(0), v.Y(0), Math.abs(m1 - m2) * v.sx, 0, TAU, true); g.fill(); }
        v.seg(a[0], a[1], R[0], R[1], T.muted, 1, [4, 3]); v.seg(b[0], b[1], R[0], R[1], T.muted, 1, [4, 3]);
        v.vec(0, 0, ...R, T.c3, 3.2); v.vec(0, 0, ...a, T.c1, 2.6); v.vec(0, 0, ...b, T.c2, 2.6);
        v.label('F₁', ...a, T.c1, { bold: true, size: 13 }); v.label('F₂', ...b, T.c2, { bold: true, size: 13 }); v.label('F 合', ...R, T.c3, { bold: true, size: 13 });
        v.dot(...a, T.c1, 6, true); v.dot(...b, T.c2, 6, true);
        let th = Math.abs(ang(a) - ang(b)); if (th > 180) th = 360 - th;
        out.set([['F₁', fmt(m1, 2) + ' N'], ['F₂', fmt(m2, 2) + ' N'], ['夹角 θ', fmt(th, 1) + '°'], ['合力 F', fmt(mag(R), 3) + ' N'], ['合力方向', fmt(ang(R), 1) + '°'], ['范围', `${fmt(Math.abs(m1 - m2), 2)} ~ ${fmt(m1 + m2, 2)} N`]]);
      } else {
        const F = P.F, u1 = [Math.cos(q.a1 * PI / 180), Math.sin(q.a1 * PI / 180)], u2 = [Math.cos(q.a2 * PI / 180), Math.sin(q.a2 * PI / 180)];
        const det = u1[0] * u2[1] - u1[1] * u2[0];
        v.seg(-u1[0] * 20, -u1[1] * 20, u1[0] * 20, u1[1] * 20, T.c1, 1, [2, 4]); v.seg(-u2[0] * 20, -u2[1] * 20, u2[0] * 20, u2[1] * 20, T.c2, 1, [2, 4]);
        let rows = [['F', fmt(mag(F), 3) + ' N']];
        if (Math.abs(det) > 1e-6) {
          const k1 = (F[0] * u2[1] - F[1] * u2[0]) / det, k2 = (u1[0] * F[1] - u1[1] * F[0]) / det, A = [k1 * u1[0], k1 * u1[1]], B = [k2 * u2[0], k2 * u2[1]];
          v.seg(...A, ...F, T.muted, 1, [4, 3]); v.seg(...B, ...F, T.muted, 1, [4, 3]); v.vec(0, 0, ...A, T.c1, 2.6); v.vec(0, 0, ...B, T.c2, 2.6);
          v.label('F₁', ...A, T.c1, { bold: true }); v.label('F₂', ...B, T.c2, { bold: true });
          rows.push(['分力 1（沿方向 1）', fmt(k1, 3) + ' N'], ['分力 2（沿方向 2）', fmt(k2, 3) + ' N']);
        } else rows.push(['提示', '两方向共线，无法分解']);
        v.vec(0, 0, ...F, T.c3, 3.2); v.dot(...F, T.c3, 6, true); v.label('F', ...F, T.c3, { bold: true, size: 13 });
        out.set(rows);
      }
    });
  }
});

/* ---------- 斜面上的物体 ---------- */
Lab.reg({
  id: 'p-incline', subj: 'phys', book: 0, unit: '运动和力的关系', title: '斜面上的物块与牛顿第二定律', kw: '受力分析 摩擦力 静摩擦 滑动摩擦 牛顿第二定律',
  info: `<p>物块受重力 G、支持力 N、摩擦力 f 及沿斜面的外力 F（向上为正）。</p>
  <p class="fb">N = mg cos θ　G 沿斜面分力 = mg sin θ<br>滑动摩擦 f = μN，方向与相对运动方向相反<br>静止时为静摩擦，大小由平衡条件决定，最大值近似取 μN<br>F 合 = ma</p>
  <p>不受外力时物块能静止的条件是 tan θ ≤ μ。θ 增大到 arctan μ 时物块恰好开始下滑。</p>`,
  tasks: ['F = 0、μ = 0.5，缓慢增大 θ，物块在约多少度时开始下滑？与 arctan 0.5 比较。', '让物块静止，逐渐增大 F，观察静摩擦力的大小和方向如何变化。', '无摩擦时，加速度与质量有关吗？为什么？'],
  init(L) {
    const c = L.canvas(), Lg = 6; let s = 3, vel = 0;
    const p = L.params({ th: ['倾角 θ', 0, 60, 1, 30, '°'], m: ['质量 m', 0.5, 10, 0.5, 2, 'kg'], mu: ['动摩擦因数 μ', 0, 1, 0.01, 0.3], F: ['沿斜面外力 F（向上为正）', -40, 40, 0.5, 0, 'N'] });
    L.group('运行');
    const run = L.loop(dt => { step(dt); L.drawFn(); });
    L.button('暂停 / 继续', () => run.toggle()); L.button('放回中点', () => { s = 3; vel = 0; L.draw(); }, true);
    const out = L.out();
    let st = {};
    function forces() {
      const g = 9.8, th = p.th * PI / 180, N = p.m * g * Math.cos(th), Gp = p.m * g * Math.sin(th), drive = p.F - Gp;
      let f, a, kind;
      if (Math.abs(vel) < 1e-4) {
        if (Math.abs(drive) <= p.mu * N + 1e-9) { f = -drive; a = 0; kind = '静摩擦'; }
        else { f = -Math.sign(drive) * p.mu * N; a = (drive + f) / p.m; kind = '滑动摩擦'; }
      } else { f = -Math.sign(vel) * p.mu * N; a = (drive + f) / p.m; kind = '滑动摩擦'; }
      return { N, Gp, f, a, kind, G: p.m * g, th };
    }
    function step(dt) {
      st = forces(); const nv = vel + st.a * dt;
      if (vel !== 0 && Math.sign(nv) !== Math.sign(vel) && Math.abs(st.f) > 0 && Math.sign(st.f) !== Math.sign(nv)) vel = 0; else vel = nv;
      if (Math.abs(vel) < 1e-4 && st.kind === '静摩擦') vel = 0;
      s += vel * dt; if (s < 0.4) { s = 0.4; vel = 0; } if (s > Lg - 0.4) { s = Lg - 0.4; vel = 0; }
    }
    L.onDraw(() => {
      c.clear(); const g = c.g; st = forces(); const th = st.th;
      const sc = Math.min((c.w - 80) / (Lg * Math.cos(th) + 0.5), (c.h - 80) / (Lg * Math.sin(th) + 1.5), 110);
      const ox = 40, oy = c.h - 40, B = [ox + Lg * Math.cos(th) * sc, oy], Tp = [ox + Lg * Math.cos(th) * sc, oy - Lg * Math.sin(th) * sc];
      D.poly(g, [[ox, oy], B, Tp], alpha(T.muted, 0.12), T.fg, 1.8);
      D.line(g, 10, oy, c.w - 10, oy, T.axis, 1.5);
      g.strokeStyle = T.muted; g.beginPath(); g.arc(ox, oy, 36, -th, 0); g.stroke(); D.text(g, 'θ', ox + 44, oy - 10, T.muted);
      // 物块：斜面从右上到左下，s 从底端算起
      const ex = -Math.cos(th), ey = Math.sin(th); // 沿斜面向上的屏幕方向（向左上）
      void ex; void ey;
      const ux = Math.cos(th), uy = -Math.sin(th); // 屏幕上沿斜面向上（从左下到右上）
      const nx = Math.sin(th), ny = Math.cos(th); // 垂直斜面向外（屏幕：左上）
      const bx = ox + s * sc * Math.cos(th), by = oy - s * sc * Math.sin(th), bw = 0.8 * sc, bh = 0.5 * sc;
      const cx = bx - nx * bh / 2, cy = by - ny * bh / 2;
      g.save(); g.translate(cx, cy); g.rotate(-th); D.rrect(g, -bw / 2, -bh / 2, bw, bh, 3, alpha(T.c1, 0.85), T.fg, 1.2); g.restore();
      const k = Math.min(60 / Math.max(st.G, 1), 4);
      D.arrow(g, cx, cy, cx, cy + st.G * k, T.fg, 2.4); D.text(g, 'G', cx + 6, cy + st.G * k, T.fg, { bold: true });
      D.arrow(g, cx, cy, cx - nx * st.N * k, cy - ny * st.N * k, T.c3, 2.4); D.text(g, 'N', cx - nx * st.N * k - 14, cy - ny * st.N * k, T.c3, { bold: true });
      if (Math.abs(st.f) > 1e-6) { D.arrow(g, bx, by, bx + ux * st.f * k, by + uy * st.f * k, T.c2, 2.4); D.text(g, 'f', bx + ux * st.f * k + 4, by + uy * st.f * k - 8, T.c2, { bold: true }); }
      if (Math.abs(p.F) > 1e-6) { D.arrow(g, cx, cy, cx + ux * p.F * k, cy + uy * p.F * k, T.c5, 2.4); D.text(g, 'F', cx + ux * p.F * k + 4, cy + uy * p.F * k - 8, T.c5, { bold: true }); }
      out.set([['重力 G', fmt(st.G, 2) + ' N'], ['G 沿斜面分力', fmt(st.Gp, 2) + ' N'], ['支持力 N', fmt(st.N, 2) + ' N'], ['摩擦力', `${fmt(Math.abs(st.f), 2)} N（${st.kind}，${st.f > 1e-6 ? '沿斜面向上' : st.f < -1e-6 ? '沿斜面向下' : '为零'}）`],
        ['加速度 a', fmt(st.a, 3) + ' m/s²'], ['速度 v', fmt(vel, 3) + ' m/s'], ['tan θ 与 μ', `${fmt(Math.tan(th), 3)} ${Math.tan(th) <= p.mu ? '≤' : '>'} ${fmt(p.mu, 2)}`]]);
    });
  }
});

/* ---------- 超重与失重 ---------- */
Lab.reg({
  id: 'p-elev', subj: 'phys', book: 0, unit: '运动和力的关系', title: '电梯里的超重与失重', kw: '超重 失重 完全失重 视重',
  info: `<p>人站在电梯里的体重秤上，秤的示数等于秤对人的支持力 N（视重）。取竖直向上为正：</p>
  <p class="fb">N − mg = ma ⇒ N = m(g + a)</p>
  <p>a 向上（加速上升或减速下降）时 N &gt; mg，<b>超重</b>；a 向下（加速下降或减速上升）时 N &lt; mg，<b>失重</b>；a = −g 时 N = 0，<b>完全失重</b>。超重失重只与加速度方向有关，与速度方向无关。</p>`,
  tasks: ['比较「加速上升」与「减速下降」两种情况的示数。', '选「自由下落」，示数为多少？此时人对秤还有压力吗？'],
  init(L) {
    const c = L.canvas(); let a = 0, v = 0, y = 0, hist = [], t = 0;
    const m = L.slider('人的质量 m', 30, 90, 1, 60, null, 'kg');
    L.group('电梯状态');
    const st = L.seg('', [['0', '静止/匀速'], ['2', '加速上升'], ['-2', '减速上升'], ['-2d', '加速下降'], ['2d', '减速下降'], ['-9.8', '自由下落']], '0', k => { a = parseFloat(k); if (k === '-2d' && v > 0) v = 0; if (k === '2d' && v >= 0) v = -3; if (k === '2' && v < 0) v = 0; if (k === '-2' && v <= 0) v = 3; });
    const out = L.out();
    L.loop(dt => {
      t += dt; v += a * dt;
      if ((st.v === '2d' && v >= 0) || (st.v === '-2' && v <= 0)) { v = 0; a = 0; st.set('0', true); }
      y += v * dt; hist.push([t, m.v * (9.8 + a)]); if (hist.length > 400) hist.shift(); L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, ex = 60, ew = 140, eh = 200, ey = c.h / 2 - eh / 2;
      for (let k = -2; k < 12; k++) { const yy = ((k * 60 + y * 30) % (c.h + 120) + c.h + 120) % (c.h + 120) - 60; D.line(g, ex - 20, yy, ex - 8, yy, T.grid2, 2); D.line(g, ex + ew + 8, yy, ex + ew + 20, yy, T.grid2, 2); }
      D.rect(g, ex, ey, ew, eh, alpha(T.muted, 0.08), T.fg, 2);
      D.rect(g, ex + 40, ey + eh - 16, 60, 10, T.c4); const N = m.v * (9.8 + a);
      D.text(g, fmt(N / 9.8, 1) + ' kg', ex + 70, ey + eh + 14, T.c4, { align: 'center', mono: true, bold: true });
      const px = ex + 70, py = ey + eh - 16; D.circle(g, px, py - 92, 12, null, T.fg, 2); D.line(g, px, py - 80, px, py - 40, T.fg, 2); D.line(g, px, py - 40, px - 12, py, T.fg, 2); D.line(g, px, py - 40, px + 12, py, T.fg, 2); D.line(g, px - 18, py - 66, px + 18, py - 66, T.fg, 2);
      D.arrow(g, ex + ew + 40, c.h / 2, ex + ew + 40, c.h / 2 - v * 18, T.c2, 2.6); D.text(g, 'v', ex + ew + 48, c.h / 2 - v * 18, T.c2);
      D.arrow(g, ex + ew + 70, c.h / 2, ex + ew + 70, c.h / 2 - a * 8, T.c3, 2.6); D.text(g, 'a', ex + ew + 78, c.h / 2 - a * 8, T.c3);
      const cx0 = ex + ew + 110;
      if (c.w - cx0 > 120) {
        const ch = D.chart(g, cx0, 30, c.w - cx0 - 20, c.h - 70, [{ pts: hist.map(h => [h[0], h[1]]), color: T.c1, w: 2 }], { title: '体重秤示数 N（牛）', xl: 't', ymin: 0, ymax: m.v * 9.8 * 2, xmin: hist.length ? hist[0][0] : 0, xmax: t });
        const yg = ch.Y(m.v * 9.8); D.line(g, cx0, yg, c.w - 20, yg, T.muted, 1, [5, 4]); D.text(g, 'mg', c.w - 24, yg - 8, T.muted, { align: 'right' });
      }
      const s = Math.abs(a + 9.8) < 1e-6 ? '完全失重' : a > 1e-6 ? '超重' : a < -1e-6 ? '失重' : '正常';
      out.set([['加速度 a', fmt(a, 2) + ' m/s²'], ['速度 v', fmt(v, 2) + ' m/s'], ['重力 mg', fmt(m.v * 9.8, 1) + ' N'], ['支持力 N（视重）', fmt(N, 1) + ' N'], ['状态', s]]);
    });
  }
});

/* ---------- 抛体运动 ---------- */
Lab.reg({
  id: 'p-proj', subj: 'phys', book: 1, unit: '抛体运动', title: '平抛与斜抛运动', kw: '运动的合成与分解 平抛 斜抛 射程 空气阻力',
  info: `<p>抛体运动可分解为水平方向的匀速直线运动和竖直方向的匀变速直线运动。</p>
  <p class="fb">平抛：x = v₀t，y = ½gt²，落地时间 t = √(2h/g)<br>斜抛：vₓ = v₀cos θ，v_y = v₀sin θ − gt<br>地面斜抛射程 R = v₀² sin 2θ / g，θ = 45° 时最大</p>
  <p>勾选空气阻力后，阻力 f = kv² 与速度反向，轨迹不再对称，最大射程角小于 45°。</p>`,
  tasks: ['h = 0 时依次发射 30° 与 60°，两者射程有什么关系？', '平抛时改变 v₀，落地时间变吗？', '打开空气阻力，找出射程最远的抛射角。'],
  init(L) {
    const c = L.canvas(), v = new View(c, -2, 40, -2, 20, { equal: true, pad: [10, 10, 10, 10] });
    const p = L.params({ v0: ['初速度 v₀', 1, 30, 0.5, 15, 'm/s'], th: ['抛射角 θ', -30, 90, 1, 45, '°'], h: ['抛出高度 h', 0, 30, 0.5, 0, 'm'], g: ['重力加速度 g', 1, 20, 0.1, 9.8, 'm/s²'], k: ['阻力系数 k/m', 0, 0.1, 0.002, 0.02] }, () => { if (!cur) fitView(); L.draw(); });
    const drag = L.check('考虑空气阻力', false, () => { fitView(); L.draw(); });
    L.button('发射', () => launch(), true); L.button('清除轨迹', () => { trails = []; L.draw(); });
    L.button('平抛', () => { p.$th.set(0, true); p.h = 20; }); L.button('45°', () => { p.$h.set(0, true); p.th = 45; });
    const comp = L.check('显示速度分量', true);
    const out = L.out();
    let trails = [], cur = null;
    function fitView() {
      const th = p.th * PI / 180, vx = p.v0 * Math.cos(th), vy = p.v0 * Math.sin(th), tf = (vy + Math.sqrt(vy * vy + 2 * p.g * p.h)) / p.g;
      const R = vx * tf, H = p.h + Math.max(0, vy * vy / (2 * p.g));
      v.r = [-2, Math.max(10, R * 1.1), -1, Math.max(6, H * 1.2)]; v.home = v.r.slice();
    }
    function launch() {
      const th = p.th * PI / 180; cur = { pts: [[0, p.h]], x: 0, y: p.h, vx: p.v0 * Math.cos(th), vy: p.v0 * Math.sin(th), t: 0, maxH: p.h, drag: drag.v, k: p.k, g: p.g };
      trails.push(cur); if (trails.length > 6) trails.shift();
    }
    fitView();
    L.interact(c, { view: v });
    L.loop(dt => {
      if (!cur) return;
      const sub = 20, h = dt * 1.0 / sub;
      for (let i = 0; i < sub; i++) {
        const sp = Math.hypot(cur.vx, cur.vy), ax = cur.drag ? -cur.k * sp * cur.vx : 0, ay = -cur.g - (cur.drag ? cur.k * sp * cur.vy : 0);
        cur.vx += ax * h; cur.vy += ay * h; cur.x += cur.vx * h; cur.y += cur.vy * h; cur.t += h; cur.maxH = Math.max(cur.maxH, cur.y);
        if (cur.y <= 0 && cur.t > 0.01) { const f = cur.y / (cur.y - cur.pts[cur.pts.length - 1][1] || 1); cur.x -= (cur.x - cur.pts[cur.pts.length - 1][0]) * f; cur.y = 0; cur.pts.push([cur.x, 0]); cur.done = true; cur = null; break; }
      }
      if (cur) cur.pts.push([cur.x, cur.y]);
      L.drawFn();
    });
    L.onDraw(() => {
      v.begin({ xl: 'x / m', yl: 'y / m' }); const g = c.g;
      D.rect(g, 0, v.Y(0), c.w, c.h - v.Y(0), alpha(T.c4, 0.1));
      if (p.h > 0) D.rect(g, v.X(-1.5), v.Y(p.h), v.X(0) - v.X(-1.5), v.Y(0) - v.Y(p.h), alpha(T.muted, 0.2), T.muted, 1);
      const th = p.th * PI / 180; v.vec(0, p.h, Math.cos(th) * 3, p.h + Math.sin(th) * 3, T.muted, 1.5);
      trails.forEach((tr, i) => {
        const col = T.c[i % 6]; g.strokeStyle = col; g.lineWidth = tr === cur ? 2.4 : 1.6; g.beginPath();
        tr.pts.forEach((q, j) => j ? g.lineTo(v.X(q[0]), v.Y(q[1])) : g.moveTo(v.X(q[0]), v.Y(q[1]))); g.stroke();
        const e = tr.pts[tr.pts.length - 1]; v.dot(e[0], e[1], col, tr === cur ? 6 : 3.5, tr === cur);
        if (tr === cur && comp.v) { const s = 0.25; v.vec(e[0], e[1], e[0] + tr.vx * s, e[1], T.c2, 2); v.vec(e[0], e[1], e[0], e[1] + tr.vy * s, T.c3, 2); v.vec(e[0], e[1], e[0] + tr.vx * s, e[1] + tr.vy * s, T.fg, 2); }
      });
      const vx = p.v0 * Math.cos(th), vy = p.v0 * Math.sin(th), tf = (vy + Math.sqrt(vy * vy + 2 * p.g * p.h)) / p.g;
      const last = trails[trails.length - 1];
      out.set([['理论飞行时间', fmt(tf, 3) + ' s'], ['理论射程', fmt(vx * tf, 3) + ' m'], ['理论最大高度', fmt(p.h + Math.max(0, vy * vy / 2 / p.g), 3) + ' m'], last ? ['本次 t', fmt(last.t, 2) + ' s'] : null, last ? ['本次水平位移', fmt(last.x, 2) + ' m'] : null, last ? ['本次最大高度', fmt(last.maxH, 2) + ' m'] : null, last ? ['速度 (vₓ, v_y)', `(${fmt(last.vx, 2)}, ${fmt(last.vy, 2)}) m/s`] : null]);
    });
  }
});

/* ---------- 竖直面内的圆周运动 ---------- */
Lab.reg({
  id: 'p-circle', subj: 'phys', book: 1, unit: '圆周运动', title: '竖直面内的圆周运动', kw: '向心力 向心加速度 绳模型 杆模型 临界速度',
  info: `<p class="fb">v = ωr　aₙ = v²/r = ω²r　Fₙ = mv²/r<br>小球在最低点速度为 v₀，由机械能守恒：v² = v₀² − 2gR(1 − cos φ)（φ 从最低点算起）</p>
  <p><b>绳模型</b>（或轨道内侧）：绳只能拉不能推，T = mv²/R + mg cos φ。最高点临界速度 v = √(gR)，对应最低点 v₀ = √(5gR)。若 T 减为 0，小球脱离圆周做斜抛运动。</p>
  <p><b>杆模型</b>（或圆管）：杆可拉可推，最高点速度可为 0，对应最低点 v₀ = 2√(gR)。最高点 v &lt; √(gR) 时杆对球是支持力。</p>`,
  tasks: ['绳模型 R=1 m，求恰好过最高点的 v₀，再用滑块验证。', '让 v₀ 略小于临界值，观察小球在哪里脱离圆周。', '杆模型下，让最高点速度为 √(gR)，杆对球的作用力是多少？'],
  init(L) {
    const c = L.canvas();
    L.group('模型');
    const mode = L.seg('', [['rope', '绳模型（轨道内侧）'], ['rod', '杆模型（圆管）']], 'rope', () => reset());
    const p = L.params({ R: ['半径 R', 0.5, 2, 0.05, 1, 'm'], v0: ['最低点速度 v₀', 0, 12, 0.05, 7.2, 'm/s'], m: ['质量 m', 0.1, 2, 0.1, 0.5, 'kg'] }, () => reset());
    L.button('重新释放', () => reset(), true); L.button('设为临界速度', () => p.v0 = mode.v === 'rope' ? Math.sqrt(5 * 9.8 * p.R) : 2 * Math.sqrt(9.8 * p.R));
    const out = L.out();
    const g0 = 9.8; let s;
    function reset() { s = { phi: 0, w: p.v0 / p.R, free: false, x: 0, y: -p.R, vx: p.v0, vy: 0, trace: [], minT: Infinity, t: 0 }; L.draw(); }
    reset();
    L.loop(dt => {
      const R = p.R, sub = 40, h = dt / sub;
      for (let i = 0; i < sub; i++) {
        s.t += h;
        if (!s.free) {
          s.w += -(g0 / R) * Math.sin(s.phi) * h; s.phi += s.w * h;
          const v = s.w * R, Tn = p.m * v * v / R + p.m * g0 * Math.cos(s.phi);
          if (mode.v === 'rope' && Tn < 0) { s.free = true; s.x = R * Math.sin(s.phi); s.y = -R * Math.cos(s.phi); s.vx = R * s.w * Math.cos(s.phi); s.vy = R * s.w * Math.sin(s.phi); s.trace = [[s.x, s.y]]; }
        } else {
          s.vy -= g0 * h; s.x += s.vx * h; s.y += s.vy * h;
          if (Math.hypot(s.x, s.y) >= R) { const ph = Math.atan2(s.x, -s.y); s.phi = ph; s.w = (s.vx * Math.cos(ph) + s.vy * Math.sin(ph)) / R; s.free = false; }
        }
      }
      if (s.free) s.trace.push([s.x, s.y]);
      L.drawFn();
    });
    L.onDraw(() => {
      c.clear(); const g = c.g, R = p.R, sc = Math.min(c.w, c.h) * 0.36 / R, cx = c.w / 2, cy = c.h / 2;
      const X = x => cx + x * sc, Y = y => cy - y * sc;
      D.circle(g, cx, cy, R * sc, null, mode.v === 'rod' ? T.muted : T.grid2, mode.v === 'rod' ? 10 : 1.5);
      if (mode.v === 'rod') D.circle(g, cx, cy, R * sc, null, T.stage, 6);
      D.circle(g, cx, cy, 3, T.fg);
      const bx = s.free ? s.x : R * Math.sin(s.phi), by = s.free ? s.y : -R * Math.cos(s.phi);
      if (s.trace.length > 1) D.poly(g, s.trace.map(q => [X(q[0]), Y(q[1])]), null, T.c2, 1.5, false);
      if (!s.free) D.line(g, cx, cy, X(bx), Y(by), T.fg, mode.v === 'rod' ? 4 : 1.5);
      else D.line(g, cx, cy, X(bx), Y(by), T.grid2, 1, [3, 4]);
      D.circle(g, X(bx), Y(by), 10, T.c1, T.fg, 1.5);
      const vx = s.free ? s.vx : R * s.w * Math.cos(s.phi), vy = s.free ? s.vy : R * s.w * Math.sin(s.phi), v = Math.hypot(vx, vy);
      D.arrow(g, X(bx), Y(by), X(bx) + vx * 8, Y(by) - vy * 8, T.c2, 2.2);
      const Tn = s.free ? 0 : p.m * v * v / R + p.m * g0 * Math.cos(s.phi);
      const kf = 6 / Math.max(p.m, 0.2);
      D.arrow(g, X(bx), Y(by), X(bx), Y(by) + p.m * g0 * kf, T.fg, 2); D.text(g, 'mg', X(bx) + 6, Y(by) + p.m * g0 * kf, T.fg, { size: 11 });
      if (!s.free) { const ux = -bx / R, uy = -by / R; D.arrow(g, X(bx), Y(by), X(bx) + ux * Tn * kf, Y(by) - uy * Tn * kf, T.c3, 2.2); }
      const vtop = Math.sqrt(Math.max(0, p.v0 ** 2 - 4 * g0 * R));
      out.set([['当前速度 v', fmt(v, 3) + ' m/s'], ['角度 φ（从最低点）', fmt(((s.phi * 180 / PI) % 360 + 360) % 360, 1) + '°'], [mode.v === 'rope' ? '绳拉力 T' : '杆的作用力', s.free ? '0（已脱离圆周）' : `${fmt(Math.abs(Tn), 3)} N${mode.v === 'rod' ? (Tn >= 0 ? '（拉力）' : '（支持力）') : ''}`],
        ['向心加速度 v²/R', fmt(v * v / R, 3) + ' m/s²'], ['最低点临界 v₀', fmt(mode.v === 'rope' ? Math.sqrt(5 * g0 * R) : 2 * Math.sqrt(g0 * R), 3) + ' m/s'], ['理论最高点速度', p.v0 ** 2 >= 4 * g0 * R ? fmt(vtop, 3) + ' m/s' : '到不了最高点'], ['状态', s.free ? '脱离圆周，做抛体运动' : '沿圆周运动']]);
    });
  }
});

/* ---------- 万有引力与航天 ---------- */
Lab.reg({
  id: 'p-grav', subj: 'phys', book: 1, unit: '万有引力与宇宙航行', title: '人造卫星与宇宙速度', kw: '万有引力 开普勒定律 第一宇宙速度 第二宇宙速度 同步卫星 椭圆轨道',
  info: `<p class="fb">F = GMm/r²　GM = gR²（黄金代换）<br>圆轨道：v = √(GM/r)，T = 2π√(r³/GM)，轨道越高 v 越小、T 越大<br>第一宇宙速度 7.9 km/s，第二宇宙速度 11.2 km/s<br>开普勒第三定律：a³/T² = GM/4π²</p>
  <p>从高度 h 处水平发射卫星：速度等于圆轨道速度时做圆周运动；稍大则为椭圆轨道（发射点为近地点）；稍小则发射点为远地点；达到 √2 倍时逃逸。勾选「面积定律」可看到相等时间扫过的面积相等。</p>`,
  tasks: ['点「第一宇宙速度」发射，测周期，与 T = 2π√(R³/GM) ≈ 84 min 比较。', '把速度调到 9 km/s 发射，记录远地点高度；再试 11.2 km/s。', '打开面积定律，观察卫星在近地点与远地点附近的速度快慢。'],
  init(L) {
    const c = L.canvas(), GM = 398600, R = 6371, v = new View(c, -4 * R, 4 * R, -3 * R, 3 * R, { equal: true });
    const p = L.params({ h: ['发射高度 h', 100, 40000, 100, 500, 'km'], v: ['发射速度 v（水平）', 3, 12, 0.01, 7.61, 'km/s'], w: ['时间倍率', 100, 6000, 100, 1200, '×'] });
    L.button('发射', () => launch(), true); L.button('清除', () => { sats = []; L.draw(); });
    L.button('第一宇宙速度', () => { p.$h.set(100, true); p.$v.set(7.85, true); launch(); });
    L.button('圆轨道速度', () => { p.$v.set(Math.sqrt(GM / (R + p.h)), true); launch(); });
    L.button('第二宇宙速度', () => { p.$v.set(Math.sqrt(2 * GM / (R + p.h)), true); launch(); });
    L.button('同步卫星', () => { p.$h.set(35786, true); p.$v.set(3.075, true); v.r = [-8 * R, 8 * R, -6 * R, 6 * R]; launch(); });
    const kep = L.check('显示面积定律（等时扇形）', true);
    const out = L.out();
    L.note('滚轮缩放视野，拖动平移。');
    L.interact(c, { view: v });
    let sats = [];
    function launch() {
      const r0 = R + p.h, vv = p.v, E = vv * vv / 2 - GM / r0, a = E < 0 ? -GM / (2 * E) : Infinity, T = E < 0 ? TAU * Math.sqrt(a ** 3 / GM) : Infinity;
      sats.push({ x: 0, y: r0, vx: vv, vy: 0, t: 0, trail: [[0, r0]], dead: false, T, E, a, marks: [[0, r0]], nextMark: T / 12, rmin: r0, rmax: r0 });
      if (sats.length > 4) sats.shift();
      const ext = isFinite(a) ? Math.max(2 * a - r0, r0) * 1.25 : r0 * 3; if (ext > v.r[1]) { v.r = [-ext, ext, -ext * 0.75, ext * 0.75]; }
    }
    L.loop(dt => {
      for (const s of sats) {
        if (s.dead) continue;
        let left = dt * p.w;
        while (left > 0) {
          const r = Math.hypot(s.x, s.y), h = Math.min(left, 0.02 * r ** 1.5 / Math.sqrt(GM)); left -= h;
          const ax = -GM * s.x / r ** 3, ay = -GM * s.y / r ** 3;
          s.vx += ax * h / 2; s.vy += ay * h / 2; s.x += s.vx * h; s.y += s.vy * h;
          const r2 = Math.hypot(s.x, s.y); s.vx += -GM * s.x / r2 ** 3 * h / 2; s.vy += -GM * s.y / r2 ** 3 * h / 2; s.t += h;
          s.rmin = Math.min(s.rmin, r2); s.rmax = Math.max(s.rmax, r2);
          if (r2 < R) { s.dead = '撞击地面'; break; }
          if (r2 > 60 * R) { s.dead = '飞离地球'; break; }
          if (isFinite(s.T) && s.t >= s.nextMark) { s.marks.push([s.x, s.y]); s.nextMark += s.T / 12; }
        }
        s.trail.push([s.x, s.y]); if (s.trail.length > 3000) s.trail.shift();
      }
      L.drawFn();
    });
    L.onDraw(() => {
      v.begin({ grid: false }); const g = c.g;
      D.circle(g, v.X(0), v.Y(0), R * v.sx, alpha(T.c1, 0.35), T.c1, 1.5);
      D.text(g, '地球', v.X(0), v.Y(0), T.fg, { align: 'center', size: 12 });
      if (p.h > 30000) D.circle(g, v.X(0), v.Y(0), (R + 35786) * v.sx, null, T.grid2, 1, [4, 4]);
      sats.forEach((s, i) => {
        const col = T.c[(i + 1) % 6];
        if (kep.v && s.marks.length > 1) for (let k = 0; k < s.marks.length - 1 && k < 12; k += 2) { const a = s.marks[k], b = s.marks[k + 1]; const seg = s.trail.filter(() => true); void seg; D.poly(g, [[v.X(0), v.Y(0)], v.P(...a), v.P(...b)], alpha(col, 0.15)); }
        D.poly(g, s.trail.map(q => v.P(...q)), null, col, 1.8, false);
        v.dot(s.x, s.y, col, 5, true);
      });
      const s = sats[sats.length - 1];
      const rv = R + p.h;
      const rows = [['该高度圆轨道速度', fmt(Math.sqrt(GM / rv), 3) + ' km/s'], ['该高度逃逸速度', fmt(Math.sqrt(2 * GM / rv), 3) + ' km/s'], ['该高度圆轨道周期', fmt(TAU * Math.sqrt(rv ** 3 / GM) / 60, 1) + ' min']];
      if (s) {
        const r = Math.hypot(s.x, s.y);
        rows.push(['当前高度', fmt(r - R, 0) + ' km'], ['当前速率', fmt(Math.hypot(s.vx, s.vy), 3) + ' km/s'], ['已飞行', fmt(s.t / 60, 1) + ' min'],
          ['轨道类型', s.dead ? s.dead : s.E >= 0 ? '逃逸（抛物/双曲线）' : Math.abs(s.rmax - s.rmin) < 5 ? '圆' : '椭圆'],
          ['理论周期', isFinite(s.T) ? fmt(s.T / 60, 1) + ' min' : '—'], ['近地点 / 远地点高度', isFinite(s.a) ? `${fmt(s.rmin - R, 0)} / ${fmt(Math.max(s.rmax, 2 * s.a - s.rmin) - R, 0)} km` : '—']);
      }
      out.set(rows);
    });
  }
});

/* ---------- 机械能守恒 ---------- */
Lab.reg({
  id: 'p-energy', subj: 'phys', book: 1, unit: '机械能守恒定律', title: '轨道上的机械能守恒', kw: '动能 重力势能 机械能 动能定理 摩擦生热',
  info: `<p class="fb">Eₖ = ½mv²　Eₚ = mgh　只有重力做功时 Eₖ + Eₚ = 恒量<br>动能定理：W 合 = ΔEₖ　摩擦产生的热量 Q = 机械能的减少量</p>
  <p>小球沿光滑轨道运动时，动能和势能相互转化，总机械能不变；它最多能回到释放时的高度。加入摩擦后，机械能逐渐转化为内能。</p>`,
  tasks: ['从「过山车」左侧释放，小球能越过中间的山峰吗？用机械能判断再验证。', '加摩擦 μ = 0.05，记录小球每次到达右侧的最高点高度。', '改变质量 m，小球的运动快慢会变吗？'],
  init(L) {
    const c = L.canvas(), v = new View(c, -6, 6, -0.5, 6, { equal: true, pad: [10, 120, 10, 10] });
    const tracks = {
      'U 形槽': x => 0.18 * x * x,
      '过山车': x => 0.11 * x * x + 1.1 * Math.cos(1.5 * x) + 1.2,
      '斜面接平面': x => 0.45 * (-x + Math.sqrt(x * x + 0.4)) + 0.05 * Math.max(0, x - 4) ** 2,
      '双峰': x => 3.4 * Math.exp(-((x + 2.2) ** 2) * 0.8) + 2.2 * Math.exp(-((x - 1.8) ** 2) * 0.9) + 0.15 * x * x
    };
    let f = tracks['过山车'], x = -5, u = 0, E0 = 0, Q = 0;
    const tk = L.select('轨道形状', Object.keys(tracks), '过山车', k => { f = tracks[k]; reset(); });
    const p = L.params({ x0: ['释放位置 x', -5.8, 5.8, 0.05, -5], m: ['质量 m', 0.2, 5, 0.1, 1, 'kg'], mu: ['摩擦因数 μ', 0, 0.2, 0.005, 0] }, k => { if (k === 'x0') reset(); else L.draw(); });
    const run = L.loop(dt => { step(dt); L.drawFn(); });
    L.button('暂停 / 继续', () => run.toggle()); L.button('重新释放', () => reset(), true);
    const out = L.out();
    const g0 = 9.8, sl = x => (f(x + 1e-4) - f(x - 1e-4)) / 2e-4;
    function reset() { x = p.x0; u = 0; Q = 0; E0 = p.m * g0 * f(x); L.draw(); }
    function step(dt) {
      const sub = 40, h = dt / sub;
      for (let i = 0; i < sub; i++) {
        const s = sl(x), ca = 1 / Math.sqrt(1 + s * s), sa = s * ca;
        let a = -g0 * sa;
        if (p.mu > 0) { if (Math.abs(u) > 1e-3) a -= Math.sign(u) * p.mu * g0 * ca; else if (Math.abs(sa / ca) <= p.mu) { u = 0; continue; } else a -= Math.sign(a) * p.mu * g0 * ca; }
        const nu = u + a * h; if (p.mu > 0 && u !== 0 && Math.sign(nu) !== Math.sign(u)) u = 0; else u = nu;
        x += u * ca * h; if (x < -5.95) { x = -5.95; u = 0; } if (x > 5.95) { x = 5.95; u = 0; }
      }
      Q = Math.max(0, E0 - (0.5 * p.m * u * u + p.m * g0 * f(x)));
    }
    reset();
    L.interact(c, { hit: (px, py) => Math.hypot(v.X(x) - px, v.Y(f(x)) - py) < 16 ? 'ball' : null, drag: (o, px) => { p.$x0.set(clamp(v.ix(px), -5.8, 5.8)); } });
    L.onDraw(() => {
      v.begin({ grid: false }); const g = c.g;
      g.fillStyle = alpha(T.muted, 0.12); g.beginPath(); g.moveTo(v.X(-6), v.Y(-0.5)); for (let xx = -6; xx <= 6.001; xx += 0.05) g.lineTo(v.X(xx), v.Y(f(xx))); g.lineTo(v.X(6), v.Y(-0.5)); g.fill();
      v.plot(f, T.fg, 2.2);
      v.seg(-6, f(p.x0), 6, f(p.x0), T.c4, 1, [5, 5]); v.label('释放高度', 5.9, f(p.x0), T.c4, { align: 'right', dx: 0 });
      const s = sl(x), nx = -s / Math.sqrt(1 + s * s), ny = 1 / Math.sqrt(1 + s * s), r = 0.22;
      D.circle(g, v.X(x + nx * r), v.Y(f(x) + ny * r), r * v.sx, T.c1, T.fg, 1.2);
      const Ek = 0.5 * p.m * u * u, Ep = p.m * g0 * f(x), E = Ek + Ep, Emax = Math.max(E0, 1e-6);
      const bx = c.w - 110, bh = c.h - 60, by = 30;
      [[Ek, T.c2, 'Eₖ'], [Ep, T.c1, 'Eₚ'], [Q, T.c4, 'Q 热'], [E, T.c3, 'E 机械']].forEach(([val, col, lab], i) => {
        const hh = val / Emax * bh * 0.9; D.rect(g, bx + i * 26, by + bh - hh, 20, hh, col); D.text(g, lab, bx + i * 26 + 10, by + bh + 12, T.fg, { align: 'center', size: 11 });
      });
      D.line(g, bx - 4, by + bh, bx + 104, by + bh, T.axis, 1);
      out.set([['高度 h', fmt(f(x), 3) + ' m'], ['速率 v', fmt(Math.abs(u), 3) + ' m/s'], ['动能 Eₖ', fmt(Ek, 3) + ' J'], ['势能 Eₚ', fmt(Ep, 3) + ' J'], ['机械能 E', fmt(E, 3) + ' J'], ['摩擦生热 Q', fmt(Q, 3) + ' J'], ['E + Q', fmt(E + Q, 3) + ' J']]);
    });
  }
});

/* ---------- 静电场 ---------- */
Lab.reg({
  id: 'p-field', subj: 'phys', book: 2, unit: '静电场及其应用 · 静电场中的能量', title: '点电荷的电场线与等势线', kw: '电场强度 电场线 等势面 电势 库仑定律 叠加',
  info: `<p class="fb">库仑定律 F = kq₁q₂/r²　点电荷场强 E = kQ/r²<br>点电荷电势 φ = kQ/r（取无穷远为零）　多个电荷：场强矢量叠加、电势代数相加<br>电场线从正电荷出发终止于负电荷；等势线处处与电场线垂直；沿电场线方向电势降低</p>
  <p>背景颜色表示电势：偏红为正，偏蓝为负。鼠标悬停处显示该点的场强方向与相对大小（取 k = 1 的相对单位）。</p>`,
  tasks: ['放一正一负等量电荷，观察两电荷连线中垂线上的电势。', '放两个等量正电荷，找出场强为零的点。', '把一个电荷的电量改为另一个的 2 倍，场强为零的点向哪里移动？'],
  init(L) {
    const c = L.canvas();
    let Q = [{ x: 0.35, y: 0.5, q: 1 }, { x: 0.65, y: 0.5, q: -1 }], hover = null;
    L.group('电荷');
    const qv = L.select('新电荷电量', [['1', '+q'], ['2', '+2q'], ['-1', '−q'], ['-2', '−2q']], '1');
    L.button('添加电荷', () => { Q.push({ x: rnd(0.3, 0.7), y: rnd(0.3, 0.7), q: +qv.v }); L.draw(); }, true);
    L.button('等量异种', () => { Q = [{ x: 0.35, y: 0.5, q: 1 }, { x: 0.65, y: 0.5, q: -1 }]; L.draw(); });
    L.button('等量同种', () => { Q = [{ x: 0.35, y: 0.5, q: 1 }, { x: 0.65, y: 0.5, q: 1 }]; L.draw(); });
    L.button('清空', () => { Q = []; L.draw(); });
    L.group('显示');
    const fl = L.check('电场线', true), eq = L.check('等势线', true), bg = L.check('电势着色', true);
    const out = L.out();
    L.note('拖动电荷移动它；双击电荷删除。');
    L.interact(c, {
      hit: (x, y) => Q.find(o => Math.hypot(o.x * c.w - x, o.y * c.h - y) < 14),
      drag: (o, x, y) => { o.x = clamp(x / c.w, 0.02, 0.98); o.y = clamp(y / c.h, 0.02, 0.98); },
      hover: (x, y) => { hover = [x, y]; L.draw(); }
    });
    c.cv.addEventListener('dblclick', e => { const r = c.cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; Q = Q.filter(o => Math.hypot(o.x * c.w - x, o.y * c.h - y) > 14); L.draw(); });
    c.cv.addEventListener('pointerleave', () => { hover = null; L.draw(); });
    const sc = 120; // 相对单位：像素/sc 作为距离
    const field = (x, y) => { let ex = 0, ey = 0, ph = 0; for (const o of Q) { const dx = (x - o.x * c.w) / sc, dy = (y - o.y * c.h) / sc, r2 = dx * dx + dy * dy + 1e-6, r = Math.sqrt(r2); ex += o.q * dx / (r2 * r); ey += o.q * dy / (r2 * r); ph += o.q / r; } return [ex, ey, ph]; };
    const off = document.createElement('canvas');
    const rgb = h => { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
    L.onDraw(() => {
      c.clear(); const g = c.g, W = c.w, H = c.h, step = 6, nx = Math.ceil(W / step) + 1, ny = Math.ceil(H / step) + 1;
      const P = new Float32Array(nx * ny); for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) P[j * nx + i] = field(i * step, j * step)[2];
      if (bg.v && Q.length) {
        off.width = nx; off.height = ny; const og = off.getContext('2d'), img = og.createImageData(nx, ny), cp = rgb(T.c2), cn = rgb(T.c1), b0 = rgb(T.stage);
        for (let k = 0; k < nx * ny; k++) { const t = Math.tanh(P[k] / 3), col = t > 0 ? cp : cn, a = Math.abs(t) * 0.55; img.data[4 * k] = b0[0] + (col[0] - b0[0]) * a; img.data[4 * k + 1] = b0[1] + (col[1] - b0[1]) * a; img.data[4 * k + 2] = b0[2] + (col[2] - b0[2]) * a; img.data[4 * k + 3] = 255; }
        og.putImageData(img, 0, 0); g.imageSmoothingEnabled = true; g.drawImage(off, 0, 0, nx * step, ny * step);
      }
      if (eq.v && Q.length) {
        g.strokeStyle = alpha(T.fg, 0.45); g.lineWidth = 1; g.beginPath();
        const levels = [-8, -4, -2, -1, -0.5, -0.25, 0.25, 0.5, 1, 2, 4, 8]; if (Q.some(o => o.q > 0) && Q.some(o => o.q < 0)) levels.push(0);
        for (const lv of levels) for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
          const a = P[j * nx + i] - lv, b = P[j * nx + i + 1] - lv, cc = P[(j + 1) * nx + i + 1] - lv, d = P[(j + 1) * nx + i] - lv;
          const pts = [], x0 = i * step, y0 = j * step;
          if (a * b < 0) pts.push([x0 + step * a / (a - b), y0]); if (b * cc < 0) pts.push([x0 + step, y0 + step * b / (b - cc)]);
          if (cc * d < 0) pts.push([x0 + step * (1 - cc / (cc - d)), y0 + step]); if (d * a < 0) pts.push([x0, y0 + step * (1 - d / (d - a))]);
          if (pts.length >= 2) { g.moveTo(...pts[0]); g.lineTo(...pts[1]); } if (pts.length === 4) { g.moveTo(...pts[2]); g.lineTo(...pts[3]); }
        }
        g.stroke();
      }
      if (fl.v && Q.length) {
        const src = Q.some(o => o.q > 0) ? Q.filter(o => o.q > 0) : Q, dir = Q.some(o => o.q > 0) ? 1 : -1;
        g.strokeStyle = T.fg; g.lineWidth = 1.2;
        for (const o of src) {
          const n = 12 * Math.abs(o.q);
          for (let k = 0; k < n; k++) {
            let x = o.x * c.w + 9 * Math.cos(TAU * k / n), y = o.y * c.h + 9 * Math.sin(TAU * k / n); g.beginPath(); g.moveTo(x, y); let mid = null;
            for (let s = 0; s < 900; s++) {
              const [ex, ey] = field(x, y), m = Math.hypot(ex, ey); if (m < 1e-9) break;
              const hx = x + dir * 2 * ex / m, hy = y + dir * 2 * ey / m, [ex2, ey2] = field(hx, hy), m2 = Math.hypot(ex2, ey2) || 1;
              x += dir * 4 * (ex / m + ex2 / m2) / 2; y += dir * 4 * (ey / m + ey2 / m2) / 2; g.lineTo(x, y);
              if (s === 40) mid = [x, y, dir * ex / m, dir * ey / m];
              if (x < -20 || y < -20 || x > W + 20 || y > H + 20) break;
              if (Q.some(q2 => q2 !== o && Math.hypot(q2.x * c.w - x, q2.y * c.h - y) < 7)) break;
            }
            g.stroke();
            if (mid) { const [mx, my, ux, uy] = mid; g.fillStyle = T.fg; g.beginPath(); g.moveTo(mx + ux * 5, my + uy * 5); g.lineTo(mx - ux * 4 - uy * 4, my - uy * 4 + ux * 4); g.lineTo(mx - ux * 4 + uy * 4, my - uy * 4 - ux * 4); g.fill(); }
          }
        }
      }
      for (const o of Q) { D.circle(g, o.x * c.w, o.y * c.h, 11 + Math.abs(o.q) * 1.5, o.q > 0 ? T.c2 : T.c1, T.stage, 2); D.text(g, o.q > 0 ? '+' : '−', o.x * c.w, o.y * c.h + 1, '#fff', { align: 'center', bold: true, size: 16 }); }
      if (hover) {
        const [ex, ey, ph] = field(...hover), m = Math.hypot(ex, ey), L2 = Math.min(40, 10 + m * 20);
        if (m > 1e-9) D.arrow(g, hover[0], hover[1], hover[0] + ex / m * L2, hover[1] + ey / m * L2, T.c4, 2.4);
        out.set([['探测点电势 φ', fmt(ph, 3)], ['场强大小 |E|', fmt(m, 3)], ['场强方向', fmt(-Math.atan2(ey, ex) * 180 / PI, 1) + '°'], ['电荷数', Q.length]]);
      } else out.set([['电荷数', Q.length], ['提示', '把鼠标移到画布上测量']]);
    });
  }
});

/* ---------- 电容器 ---------- */
Lab.reg({
  id: 'p-cap', subj: 'phys', book: 2, unit: '静电场中的能量', title: '平行板电容器的动态分析', kw: '电容 电荷量 电压 场强 介电常数 静电计',
  info: `<p class="fb">C = Q/U　C = εᵣS/(4πkd)　E = U/d<br>保持与电源相连：U 不变，Q = CU 随 C 变化<br>充电后断开电源：Q 不变，U = Q/C，E = 4πkQ/(εᵣS) 与 d 无关</p>
  <p>右侧的静电计指针偏角反映两板间电压 U。极板上的「+ −」个数代表电荷量，板间电场线的疏密代表场强。</p>`,
  tasks: ['连着电源，增大 d，Q、E 怎样变化？', '断开电源后再增大 d，静电计偏角怎样变化？E 变不变？', '断开电源后插入电介质（增大 εᵣ），U 如何变化？'],
  init(L) {
    const c = L.canvas(), e0 = 8.854e-12, U0 = 12;
    const p = L.params({ d: ['板间距 d', 1, 10, 0.1, 4, 'mm'], S: ['正对面积 S', 20, 200, 1, 100, 'cm²'], er: ['相对介电常数 εᵣ', 1, 8, 0.1, 1] }, () => update());
    L.group('电源');
    let conn = true, Q = 0;
    const sw = L.seg('', [['1', '保持连接电源（U 不变）'], ['0', '断开电源（Q 不变）']], '1', vv => { conn = vv === '1'; update(); });
    const out = L.out();
    const C = () => p.er * e0 * p.S * 1e-4 / (p.d * 1e-3);
    function update() { if (conn) Q = C() * U0; L.draw(); }
    update();
    L.onDraw(() => {
      c.clear(); const g = c.g, Cv = C(), U = Q / Cv, E = U / (p.d * 1e-3);
      const cx = c.w * 0.42, cy = c.h / 2, pw = 60 + p.S * 1.4, gap = 14 + p.d * 16;
      const top = cy - gap / 2, bot = cy + gap / 2;
      if (p.er > 1) D.rect(g, cx - pw / 2, top, pw, gap, alpha(T.c4, 0.12 + p.er * 0.03));
      D.rect(g, cx - pw / 2, top - 8, pw, 8, T.c2); D.rect(g, cx - pw / 2, bot, pw, 8, T.c1);
      const Qref = 2.5e-10, nq = Math.max(1, Math.round(Q / Qref * 6));
      for (let i = 0; i < Math.min(nq, 40); i++) { const x = cx - pw / 2 + (i + 0.5) * pw / Math.min(nq, 40); D.text(g, '+', x, top - 16, T.c2, { align: 'center', bold: true }); D.text(g, '−', x, bot + 18, T.c1, { align: 'center', bold: true }); }
      const nE = Math.max(1, Math.round(E / 6e3 * pw / 120));
      for (let i = 0; i < Math.min(nE, 40); i++) { const x = cx - pw / 2 + (i + 0.5) * pw / Math.min(nE, 40); D.arrow(g, x, top + 2, x, bot - 2, alpha(T.fg, 0.55), 1, 6); }
      // 电路
      const lx = cx - pw / 2 - 70;
      wire(g, [[cx, top - 8], [cx, top - 40], [lx, top - 40], [lx, cy - 16]]); wire(g, [[cx, bot + 8], [cx, bot + 40], [lx, bot + 40], [lx, cy + 16]]);
      if (conn) battery(g, lx, cy, true, U0 + ' V'); else { D.line(g, lx, cy - 16, lx + 14, cy - 34, T.fg, 2); D.text(g, '开关断开', lx + 18, cy, T.muted, { size: 12 }); D.circle(g, lx, cy + 16, 3, T.fg); }
      // 静电计
      const ex = cx + pw / 2 + 90, ey = cy + 30;
      wire(g, [[cx + pw / 2, top - 4], [ex, top - 4], [ex, ey - 60]]); wire(g, [[cx + pw / 2, bot + 4], [ex + 40, bot + 4], [ex + 40, ey + 40], [ex, ey + 40]]);
      D.circle(g, ex, ey, 40, null, T.fg, 1.5); D.line(g, ex, ey - 60, ex, ey + 10, T.fg, 2);
      const ang = Math.min(80, U / 40 * 80) * PI / 180; D.line(g, ex, ey - 10, ex + Math.sin(ang) * 34, ey - 10 + Math.cos(ang) * 34 * -1 + 34 * 0, T.c3, 3);
      D.text(g, '静电计', ex, ey + 54, T.muted, { align: 'center', size: 11 });
      out.set([['电容 C', fmt(Cv * 1e12, 2) + ' pF'], ['电荷量 Q', sci(Q, 3) + ' C'], ['电压 U', fmt(U, 2) + ' V'], ['板间场强 E', fmt(E, 0) + ' V/m'], ['储存能量 ½CU²', sci(0.5 * Cv * U * U, 3) + ' J']]);
    });
  }
});

/* ---------- 闭合电路 ---------- */
Lab.reg({
  id: 'p-circuit', subj: 'phys', book: 2, unit: '电路及其应用 · 电能 能量守恒定律', title: '闭合电路欧姆定律与滑动变阻器', kw: '电动势 内阻 路端电压 输出功率 限流 分压 欧姆定律',
  info: `<p class="fb">I = E/(R + r)　路端电压 U = E − Ir<br>输出功率 P 出 = I²R = E²R/(R + r)²，当 R = r 时最大，P max = E²/4r<br>电源效率 η = U/E = R/(R + r)</p>
  <p><b>限流式</b>接法：负载电压调节范围 ERₓ/(Rₓ + R₀) ~ E，耗能少。<b>分压式</b>接法：负载电压可从 0 调到 E，调节范围大，要求电压从零开始时必须用分压式。</p>`,
  tasks: ['调节 R，验证 U-I 图像是一条直线，纵截距和斜率分别代表什么？', '找出输出功率最大的 R，此时效率是多少？', '比较限流与分压两种接法下，负载电压随滑片位置的变化曲线。'],
  init(L) {
    const c = L.canvas();
    L.group('电路');
    const mode = L.seg('', [['closed', '闭合电路'], ['lim', '限流式'], ['div', '分压式']], 'closed', () => { sync(); L.draw(); });
    const p = L.params({ E: ['电动势 E', 1, 12, 0.5, 6, 'V'], r: ['内阻 r', 0, 5, 0.1, 1, 'Ω'], R: ['外电阻 R', 0, 30, 0.1, 4, 'Ω'], R0: ['变阻器总阻值 R₀', 5, 100, 1, 20, 'Ω'], Rx: ['负载 Rₓ', 1, 50, 1, 10, 'Ω'], k: ['滑片位置', 0, 1, 0.01, 0.5] });
    const out = L.out();
    function sync() { const m = mode.v; p.$R.el.hidden = m !== 'closed'; p.$R0.el.hidden = p.$Rx.el.hidden = p.$k.el.hidden = m === 'closed'; }
    sync();
    let ph = 0;
    L.loop(dt => { ph += dt * 60; L.drawFn(); });
    L.onDraw(() => {
      c.clear(); const g = c.g, { E, r } = p, half = c.w < 640 ? c.w : c.w * 0.5;
      const x0 = 40, x1 = half - 40, y0 = 50, y1 = Math.min(c.h - 50, (c.w < 640 ? c.h * 0.45 : c.h - 60));
      let I, rows = [];
      if (mode.v === 'closed') {
        const R = p.R; I = E / (R + r || 1e-9); const U = I * R;
        const path = [[(x0 + x1) / 2, y1], [x0, y1], [x0, y0], [x1, y0], [x1, y1], [(x0 + x1) / 2, y1]];
        wire(g, path); flowDots(g, path, -ph * Math.min(I, 6) * 0.6, T.c4);
        D.rect(g, (x0 + x1) / 2 - 50, y1 - 26, 100, 52, T.stage); battery(g, (x0 + x1) / 2 - 24, y1, false, `E=${E}V`); resistor(g, (x0 + x1) / 2 + 0, y1, (x0 + x1) / 2 + 50, y1, `r=${r}Ω`);
        D.line(g, (x0 + x1) / 2 - 50, y1, (x0 + x1) / 2 - 28, y1, T.fg, 1.8); D.line(g, (x0 + x1) / 2 - 20, y1, (x0 + x1) / 2, y1, T.fg, 1.8);
        D.rect(g, x1 - 20, (y0 + y1) / 2 - 30, 40, 60, T.stage); resistor(g, x1, (y0 + y1) / 2 - 30, x1, (y0 + y1) / 2 + 30, `R=${fmt(R, 1)}Ω`, T.c1);
        D.circle(g, (x0 + x1) / 2, y0, 16, T.stage); meter(g, (x0 + x1) / 2, y0, 'A', fmt(I, 3) + ' A');
        wire(g, [[x0, y0 + 30], [x0 + 60, y0 + 30], [x0 + 60, y1 - 50], [x0, y1 - 50]], T.muted, 1.2); D.circle(g, x0 + 60, (y0 + y1) / 2 - 10, 16, T.stage); meter(g, x0 + 60, (y0 + y1) / 2 - 10, 'V', fmt(U, 3) + ' V');
        const gx = c.w < 640 ? 40 : half + 20, gw = c.w - gx - 30, gy = c.w < 640 ? y1 + 50 : 30, gh = (c.w < 640 ? c.h - gy - 20 : c.h - 60) / 2 - 20;
        const Im = r > 0 ? E / r : E / 0.1;
        const ch1 = D.chart(g, gx, gy, gw, gh, [{ pts: [[0, E], [Im, E - Im * r]], color: T.c1, w: 2.2 }], { title: 'U − I 图像', xl: 'I / A', xmin: 0, xmax: Im * 1.05, ymin: 0, ymax: E * 1.1 });
        D.circle(g, ch1.X(I), ch1.Y(U), 5, T.c2);
        const Rs = [...Array(121).keys()].map(i => i / 4), Pout = R2 => E * E * R2 / (R2 + r) ** 2, Pm = r > 0 ? E * E / 4 / r : Pout(30);
        const ch2 = D.chart(g, gx, gy + gh + 30, gw, gh, [{ pts: Rs.map(R2 => [R2, Pout(R2)]), color: T.c3, w: 2.2 }], { title: '输出功率 P − R', xl: 'R / Ω', xmin: 0, xmax: 30, ymin: 0, ymax: Math.max(Pm, Pout(30)) * 1.15 });
        D.circle(g, ch2.X(R), ch2.Y(Pout(R)), 5, T.c2); if (r > 0) D.line(g, ch2.X(r), gy + gh + 30, ch2.X(r), gy + 2 * gh + 30, T.muted, 1, [4, 4]);
        rows = [['电流 I', fmt(I, 4) + ' A'], ['路端电压 U', fmt(U, 4) + ' V'], ['内电压 Ir', fmt(I * r, 4) + ' V'], ['输出功率 P 出', fmt(I * U, 4) + ' W'], ['总功率 EI', fmt(E * I, 4) + ' W'], ['效率 η', fmt(U / E * 100, 2) + ' %'], ['P 出最大值（R = r）', r > 0 ? fmt(E * E / 4 / r, 3) + ' W' : '—']];
      } else {
        const { R0, Rx, k } = p, lim = mode.v === 'lim';
        const Ux = kk => { if (lim) { const i = E / (Rx + kk * R0 + r); return i * Rx; } const a = kk * R0, par = a > 1e-9 ? a * Rx / (a + Rx) : 0, i = E / ((1 - kk) * R0 + par + r); return i * par; };
        const U = Ux(k); I = U / Rx;
        const rx0 = x0 + 30, rx1 = x1 - 30, ry = (y0 + y1) / 2 + 20;
        D.rect(g, rx0, ry - 9, rx1 - rx0, 18, T.stage, T.fg, 1.8); D.text(g, 'R₀', rx0 - 18, ry, T.fg);
        const sx = rx0 + (rx1 - rx0) * k; D.arrow(g, sx, ry - 34, sx, ry - 10, T.c2, 2.4);
        battery(g, (x0 + x1) / 2, y1, false, `E=${E}V`);
        if (lim) {
          wire(g, [[rx0, ry], [x0, ry], [x0, y1], [(x0 + x1) / 2 - 4, y1]]); wire(g, [[(x0 + x1) / 2 + 4, y1], [x1, y1], [x1, y0], [sx, y0], [sx, ry - 34]]);
          D.rect(g, (x0 + x1) / 2 - 30 + 60, y0 - 16, 60, 32, T.stage); resistor(g, (x0 + x1) / 2 + 30, y0, (x0 + x1) / 2 + 90, y0, 'Rₓ', T.c1);
          D.text(g, '只用 R₀ 的左段（滑片左侧）', rx0, ry + 28, T.muted, { size: 11 });
        } else {
          wire(g, [[rx0, ry], [x0, ry], [x0, y1], [(x0 + x1) / 2 - 4, y1]]); wire(g, [[(x0 + x1) / 2 + 4, y1], [x1, y1], [x1, ry], [rx1, ry]]);
          wire(g, [[sx, ry - 34], [sx, y0], [(x0 + x1) / 2 + 40, y0]]); wire(g, [[(x0 + x1) / 2 - 40, y0], [x0 + 10, y0], [x0 + 10, ry]]);
          resistor(g, (x0 + x1) / 2 - 40, y0, (x0 + x1) / 2 + 40, y0, 'Rₓ', T.c1);
          D.text(g, 'Rₓ 并联在 R₀ 左段两端', rx0, ry + 28, T.muted, { size: 11 });
        }
        const gx = c.w < 640 ? 40 : half + 20, gw = c.w - gx - 30, gy = c.w < 640 ? y1 + 50 : 40, gh = c.w < 640 ? c.h - gy - 30 : c.h - 90;
        const ks = [...Array(101).keys()].map(i => i / 100);
        const save = mode.v; const other = kk => { const a = kk * R0; if (save === 'lim') { const par = a > 1e-9 ? a * Rx / (a + Rx) : 0, i = E / ((1 - kk) * R0 + par + r); return i * par; } return E / (Rx + kk * R0 + r) * Rx; };
        const ch = D.chart(g, gx, gy, gw, gh, [{ pts: ks.map(kk => [kk, other(kk)]), color: T.grid2, w: 1.5, dash: [5, 4] }, { pts: ks.map(kk => [kk, Ux(kk)]), color: T.c1, w: 2.4 }], { title: `负载电压 Uₓ − 滑片位置（虚线为${lim ? '分压' : '限流'}式）`, xl: '滑片位置', xmin: 0, xmax: 1, ymin: 0, ymax: E * 1.1 });
        D.circle(g, ch.X(k), ch.Y(U), 5, T.c2);
        const lo = Math.min(...ks.map(Ux)), hi = Math.max(...ks.map(Ux));
        rows = [['负载电压 Uₓ', fmt(U, 3) + ' V'], ['负载电流', fmt(I, 4) + ' A'], ['Uₓ 调节范围', `${fmt(lo, 2)} ~ ${fmt(hi, 2)} V`]];
      }
      out.set(rows);
    });
  }
});
