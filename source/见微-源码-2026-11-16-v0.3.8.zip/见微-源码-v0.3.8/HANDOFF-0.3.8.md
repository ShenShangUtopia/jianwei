# 见微 0.3.8 · 交接（2026-11-16）

`store.VERSION` = **0.3.8**。源码改完、自测见 §4；**没有打包**（`tools/release.py` 的 `OUT` / `TAG` 还是 0.3.7，打包前要改）。用户说明见 `RELEASE-0.3.8.md`。

## 1. 这一轮做了什么

| 事项 | 状态 |
| --- | --- |
| 观澜第三批：人物 22 位、金句 31 句、词条 12 个（合计 73 / 115 / 46） | 做完 |
| 每日选人选句没按新闻主题挑（主题名对不上）的 bug | 修好 |
| 素材库：收藏、只看收藏、和今天的新闻相关、随机翻一条、单独看金句和词条、复制素材卡、Ctrl+F | 做完 |
| 见微主窗口观澜页「我的收藏」 | 做完 |

## 2. 结构

- `guanlan/core/library_third.py`：第三批数据，沿用 `library_more` 的 `_p` / `_q`。
  - `library_people/quotes/terms.py` 末尾 `+= X_THIRD`。
  - 新金句都直接写了 `origin`，不靠作者名推。
- `guanlan/core/library.py`：
  - `short_theme()` 把「外交合作」等换算成三张表用的短名，`_theme_weights` 先换算。**这之前每日人物 / 金句 / 词条的「按新闻主题挑」从来没生效过。**
  - `relevance(kind, entry, themes)` 给素材库用。
- `guanlan/core/favorites.py`：
  - 存 `data/favorites.json`，格式 `{people:[id], quotes:[id], terms:[id]}`。
  - 写入是临时文件加替换。`toggle` 把新收藏的插在最前，`load` 会跳过坏数据。
- `guanlan/core/facets.py`：
  - `search` / `counts` 多了 `only`（收藏的 id，按收藏先后）和 `themes`（只留相关的，按贴合度排）两个参数，由 `_base()` 先做。
  - `material_card(kind, entry)` 拼素材卡纯文本。
- `guanlan/ui/library.py`：
  - `StarButton`；`PersonRow(person, star)`。
  - 开关存在 `picks[kind]` 的 `_fav` / `_today` 里，下划线开头的不算维度，「清除筛选」会一起清掉。
  - `set_today(themes)` 由窗口在 `_load_data` 时调，主题取自 `pages.edition_themes(edition)`。
  - `person_index` 现在指「单独看第几条」，人物、金句、词条都用它，名字没改，因为自测和窗口都在调。`open_person`、`step`、`close_sheet` 对三类都有效。
  - `toggle_fav` 会同步所有显示同一条的星标（`self.stars`，控件销毁时自动移除）。
- `ui/cards.py`：`QuoteCard` / `TermCard` 有 `actions` 一排和 `add_action(widget)`，素材库往里放星标和复制键。
- `ui/pages.py`：
  - `PersonView.build(..., extra=())` 把额外按键放在顶行。
  - 「复制素材卡」键发 `card_copied(str)`；`PeoplePage` 转发这个信号，窗口 `_copy_card` 负责弹提示。
- `ui/icons.py`：新增 `star`、`star_fill`、`dice` 三个图标。
- 见微：
  - `guanlan_host.open_library(kind, favorites=False)`。
  - `library_counts()` 多了 `favorites`。
  - `pages.build_guanlan` 的「我的收藏」键。

## 3. 坑

- 自测里找卡片要用 `isVisible()`，不要用 `not isHidden()`。`clear()` 只把外层藏起来再 `deleteLater`，离屏 `spin()` 不处理 DeferredDelete，旧卡片里的子控件 `isHidden()` 仍是 False。
- 新建的卡片要 `spin(.2)` 后才可见。
- 「和今天的新闻相关」用的是 `library.py` 里的标签表（`PERSON_THEME_TAGS` 等），比较宽：气候 + 科技两个主题能挑出 73 人里的 44 人。想收窄就改那三张表。

## 4. 测试（全部隔离 JIANWEI_HOME / LOCALAPPDATA）

- `panels_selftest`：通过，新加 17 项左右。
- 全量 `main.py --self-test --no-single`（离屏）：**37 组全部 OK**（2026-11-16）。

## 5. 可以接着做

1. 联网跑一次今日版，看「和今天的新闻相关」挑出来的是否贴切，以及每日人物是不是真的随新闻变了。
2. 第三批内容可以请人再核一遍，尤其是年份和引语。
3. 素材卡可以加「导出全部收藏」成一份文档。
4. 打包 0.3.8：改 `release.py` 的 `OUT` / `TAG`，跑 `build` / `smoke` / `pack`；**不要把密钥打进去**。
