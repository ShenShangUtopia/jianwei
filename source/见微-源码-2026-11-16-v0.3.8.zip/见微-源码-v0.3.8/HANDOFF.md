# 见微 · 高考学习舱 —— 交接

> 2026-11-16，当前 **0.3.8**（观澜第三批素材、收藏、和今天新闻相关；未打包）。这份只写接手需要知道的现状。完整历史（1.x 到 2.14）原样保存在 `HANDOFF-历史.md`；逐版细节看 `HANDOFF-0.3.8.md`、`HANDOFF-0.3.7.md`、`HANDOFF-0.3.6.md`、`HANDOFF-0.3.5.md`、`HANDOFF-给GPT.md` 和 `RELEASE-0.*.md`。
>
> **2026-11-15 起工作区在 E 盘**（`E:\space for Claude\jianwei\src2`），这台机器没有 F 盘；下文还写着 F 盘的路径都按 E 盘理解。venv 重建过，见 `HANDOFF-0.3.6.md` 第 0 节。

## 1. 是什么

Windows 托盘应用，PySide6 全原生（不用浏览器内核，课堂除外）。

- **主窗口**（`app/shell.py`、`pages.py`、`modules.py`）：今日、课件、读文、习题台、实验室、观澜、倒计时、设置。
- **学习窗口**（`app/native/main_win.py`）：习题、实验、工作台、析题、读文、课件、课堂七个模式，第一次打开才建（快捷键按 `MODE_KEYS`，读文是 Ctrl+7）。
- **读文**（0.3.6，`app/native/reading/`）：文言文 / 英语边输入边逐字精析；离线考纲词表兜底，DeepSeek 逐句精析并缓存。
- **观澜浮窗**（`app/guanlan/`）：每日世界线索，内嵌在见微里，没有自己的托盘。0.3.7 起：素材库（`core/facets.py` 维度 + `ui/library.py`），第二批人物 / 金句 / 词条在 `core/library_more.py`，新闻筛选偏好在配置 `prefs`（`core/filters.py` 的 `clean_prefs` / `muted` / `pref_bonus`）。0.3.8：第三批在 `core/library_third.py`，收藏 `core/favorites.py`（`data/favorites.json`），素材卡 `facets.material_card`。
- **时间胶囊**（`app/countdown.py`）：桌面上的倒计时尺。
- **暮省**：`Jianwei.exe --evening` 独立进程全屏播放（`guanlan/core/evening.py` 出数据，`native/evening.py` 播放）。
- **课堂**（0.3.0）：整合 OpenMAIC v1.4.2（MIT），本机起 PostgreSQL + Node，Edge `--app` 窗口打开。服务端 `native/classroom/service.py`，运行包 `F:\space for Claude\openmaic\runtime-dist`。

## 2. 路径、版本、发行

- 源码 `E:\space for Claude\jianwei\src2`，Python 是 `jianwei\.venv\Scripts\python.exe`（3.12.10，底座是 `jianwei\python312-nuget`）。
- 版本号在 `app/store.py` 的 `VERSION`。命名：1.x→0.1.x，2.x→0.2.x，0.3.x 起整合课堂。
- **GPT 也在同一个 `src2` 里出版本：动版本号前先看 `store.VERSION` 和最新的 `RELEASE-*.md`。**
- 发行：改 `tools/release.py` 顶部的 `OUT`、`TAG`，然后在 `src2` 下依次跑 `build`、`smoke`、`pack`。
  - 产物在 `jianwei/release-<版本>-<日期>/`，两个 zip 复制到 **`F:\AI\`**。
  - `smoke` 是冻结版全量自测（约 10 分钟），不过不能 `pack`；构建后改过源码也会被拒。
  - 不覆盖 `src2/dist`，不碰桌面快捷方式；新加的顶层模块 PyInstaller 能自己找到，新实验 / 工作台文件要登记到 `native/lab/all_modules.py`。
- 0.3.x 各版：0.3.0 课堂；0.3.1 性能；0.3.2 水墨 + 平按键 + 课件进主菜单；0.3.3 手绘风格 + 导航位置；0.3.4 疏密；0.3.5 模块桌面 / 工作台。

## 3. 外观五项（设置 → 外观，互不相干）

| 配置键 | 取值 | 管什么 |
| --- | --- | --- |
| `skin` | `ink` 水墨（默认）/ `celadon` 青瓷 / `doodle` 手绘 | 颜色和笔触；学习窗口、观澜浮窗一起换 |
| `pageLayout` | `pages` 经典页面（默认）/ `desktop` 模块桌面 / `workspace` 工作台 | 整个主窗口怎么组织 |
| `layout` | `side` / `top` / `compact` | 导航放哪，只对经典页面有用 |
| `density` | `normal` / `dense` | 间距疏密 |
| `themeMode` | `auto` / `day` / `night` | 昼夜，auto 按 7–19 点 |

- 风格的配色在三处，加风格三处都要改：`native/design/tokens.py`（SKINS）、`ui_kit.py`（_SKINS）、`guanlan/ui/theme.py`（SKINS）；再把它加进 `native/design/selftest.py` 的对比度检查。
- 0.3.4 的「舒展 / 分栏 / 紧凑」旧配置在 `Shell.__init__` 里自动换算；`pages.py` 里分栏的死代码 0.3.6 已删（`Page.add(side=…)` 参数留着不起作用）。

## 4. 主窗口怎么搭的

- 所有东西挂在 `Shell._root` 下。换页面布局 / 导航位置走 `_rebuild_chrome()` 整个重搭。换风格 / 昼夜走 `_apply_look()`：先 `_drop_pages()` 再 `app.setStyleSheet`（活着的控件越少越快）。
- **页面按需建**：`_builders` 是七个建页函数，`_built` 记哪些是新的，`goto()` 点到才建；数据变了调 `refresh_pages(keys)`。不要一次建全部页面。
- 栈的最后一格（下标 `len(NAV)`）是模块桌面 / 工作台 `self.home`。这两种布局下 `goto("home")`、`goto("today")` 都去那里；顶栏 `_homeband()` 有「‹ 桌面 / 课件」返回键，Esc 也能回。`_rebuild_home()` 用 `deleteLater`（可能正在块里的点击处理中）。
- **页面写法**：`pages.Page` = 标题 + 一句说明 + `page.action(...)`，一页只一个 primary。颜色在建的时候取（`ui_kit.lab(text, size, tone)`、`C.*H`），自绘控件在重绘时取；不要写旧色字面量。卡片一律 `ui_kit.paint_card()`，按它返回的矩形排内容（手绘风格有硬边投影）。
- **按键**：主窗口用 `ui_kit.Btn(text, variant, tip, icon)`（primary / 普通 / soft / danger）、`Chip`、`Check`、`Combo`、`SmoothScroll`，全是自绘。学习窗口的按键在 `design/widgets.qss()`，内边距保持 11 / 13 像素：有些按钮按旧宽度写死，多 1 像素就裁字。
- **模块**（`modules.py`）：`SPEC` 里八个模块，`build(ctx, m, big)`；桌面用精简版，工作台用满版。工作台摆法存在 `cfg["workspace"]`（cols / w / h），拖放落点在 `Panel._side()`，改摆法在 `Workspace.drop / move / add / remove`。加模块：`SPEC` + `Desktop.GRID` + `ORDER`。
- **课件**在主窗口里只是外壳：导入队列和放映器借学习窗口的 `LecturePage`（`Shell.lecture_backend()`，不显示学习窗口）。析题模块经 `Shell.analyze_text()` 送进学习窗口的析题页。

## 5. 性能约定（0.3.1 定的，别退回去）

- 应用级 eventFilter 先 `isinstance` 再取 `event.type()`（取类型要造枚举，很贵）。观澜的过滤器只在浮窗展开可见时挂（`MainWindow._sync_watch`）。
- 时间胶囊平时每帧只重画指针光点那一小块；被最大化窗口盖住时一秒一帧；隐藏后定时器全停。
- 看不见的控件不跑定时器（在 show / hide 里开关）。
- 过渡动画先问 `ui_kit.motion()`：自测 / 离屏时返回 False，否则截图截到过渡一半。
- 拖滑块存配置用 `Shell.save_soon()`，停手后才写盘。
- 实测（0.3.0 → 0.3.1）：主窗口建界面 1.5 秒 → 0.25 秒；托盘常驻私有内存 98 MB → 60 MB。

## 6. 规矩（用户定的，必须遵守）

- 测试必须把 `JIANWEI_HOME` 和 `LOCALAPPDATA` 指到临时目录，不碰真实数据。暮省测试尤其要改 `LOCALAPPDATA`，否则当晚定时暮省会被跳过。
- 真窗口测试先把配置里 `autoFetch`、`autoEvening` 关掉，否则会联网、弹全屏暮省。
- 不打印、不记日志、不复制 DeepSeek 密钥（`%LOCALAPPDATA%\Jianwei\deepseek.env`）；测试要用就向用户要，用完删。
- 只停自己启动的进程；测试不启动 Word（本机没有 Office，PowerPoint.Application 指向 WPS）；WPS 测试文稿用 COM 关，不杀 wpp。
- 不要 Python 报错弹窗（自测都走 `native/kit/test_runtime`）。
- `E:\U盘备份` 里的真实课件只读。不绕过验证码（必应、百度、360 都不要绕）。
- 用户用中文交流，回复要简洁直白。

## 7. 测试

- 全量（源码）：`app/main.py --self-test <目录> --no-single`，环境变量设 `QT_QPA_PLATFORM=offscreen`、`QT_QPA_FONTDIR=C:\Windows\Fonts`、隔离的 `JIANWEI_HOME` / `LOCALAPPDATA`。约 10 分钟，31 组结果写成 `*-result.txt`。
- 主窗口 / 观澜 / 胶囊：`app/panels_selftest.py <目录>`（102 项）。
- 设计（含六套配色对比度）：`python -m native.design.selftest <目录>`。
- 截图核对：用真实窗口截（不设 `QT_QPA_PLATFORM`）字更准；离屏截图只用于版面。

## 8. 坑

- 字体看机器：旧开发机（F 盘那台）没有楷体、雅黑、宋体；2026-11-15 起的这台（E 盘）有雅黑、等线、黑体、楷体、仿宋、新宋体和 Noto Sans SC。别依赖核对不了的字体。
- **PDF 文字层的部首坑**：Qt 用 Noto Sans SC、等线写 PDF 时，「一」「二」「用」这类和康熙部首同形的字在文字层里记成部首码位（⼀ ⼆ ⽤），看着一样、比对全错；雅黑、黑体写的正常。0.3.6 起读 PDF 文字一律走 `lecture/pageview.py` 的 `clean_text` / `page_text`（只把 U+2E80–2FDF 做 NFKC），新写的取字代码也要用它。导出的 PDF 本身在别的阅读器里复制出来仍可能是部首字，没改写入端。
- 导入 `ui_kit` 前必须已有 QApplication，否则进程直接崩（0xC0000409）。
- 雅黑没有半粗：600 字重在 Windows 上发糊，`f()` / `font()` 已把 600 换成 700。
- 给容器 `setStyleSheet("background:transparent;")` 会级联洗掉所有子控件的底色；样式表别给按钮写 `min-height`（会覆盖 `setFixedHeight`）。
- venv 的 `python.exe` 是转发器，量 CPU / 内存要量它的子进程。
- 脚本里不在事件循环内时 `deleteLater` 不执行，要手动 `QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)`。
- 离屏脚本结尾 `os._exit` 偶尔报 0xC0000005，是退出时的假象。
- 打包版没有 `PySide6.QtTest`，进总自测的文件别用它。
- 输入框要 `ClickFocus`，否则快捷键先要点一下。
- 课件框选取字靠 `text.pdf`（导入后后台做）+ Windows 中文 OCR；别的电脑常没装中文 OCR，`Ocr.status` 会报 `nozh`。
- 课堂：PostgreSQL 不支持中文路径，先转 8.3 短路径，转不出就放 `%PUBLIC%\Jianwei\pg-*`；pnpm 的 junction 每次启动按 `server\links.json` 重建。OpenMAIC 只能用低内存 webpack 模式构建（`openmaic\build-lowmem\`，峰值约 1.8 GB）。

## 9. 和用户确认需求

- 界面布局类的需求先画线框草图让用户确认再做。「页面布局」这个词先后被理解成导航位置、页面内部疏密，第三次用草图才对上（用户要的是没有侧栏、功能模块化）。
- 用户对界面的标准：清晰、简洁、直接；入口少，一页一个主键。

## 10. 没验证 / 下一步

- 真机验收 0.3.5：工作台用鼠标拖模块（离屏只测了落下后的那一步）、手绘风格按下的效果、有雅黑的电脑上的字。
- 读文：真 DeepSeek 已测、课件框选已能送到读文（0.3.7）；还可做析题送读文、生词本。
- 0.3.6 已打包（E:\space for Claude\jianwei\release-0.3.6-2026-11-15）；0.3.7 已打包（E:\space for Claude\jianwei\release-0.3.7-2026-11-15）。0.3.8 未打包。观澜后续见 `HANDOFF-0.3.8.md`。
- 课堂：TTS / ASR 接见微已有的语音；精简 `classroom\server\node_modules`（约 0.5 GB）；课堂生成的课和讲台、析题互通。
- 模块桌面 / 工作台可以加「课堂」模块。

## 11. 实验台后续源码更新（2026-11-13，未发行）

- GPT已继续化学真实性升级：润洗残液、管尖气泡、活塞和固定支架、滴定终点记录；气密性/漏气/排水收集；96条表达式守恒核对与银氨、铁硫氰模型修正；玻璃/液面/管路画面。见`HANDOFF-化学真实性-GPT.md`末尾第二批记录。
- 新入口在化学工作台“实验”页的“操作训练”：酸碱滴定、制取氧气。旧存档保留理想模式，新器材使用操作训练的前提与边界。
- Claude的生物成果见`HANDOFF-生物真实性-Claude.md`。化学与生物helper已登记`lab/all_modules.py`，化学四个专项已接总自测和smoke预期；生物专项的总自测接入仍待统一处理。
- 11月13日这一轮的会话交接（生物三个模型、卡片封面与图标、时间胶囊跟随风格进行中）见`HANDOFF-0.3.5-后续-2026-11-13.md`。
- `store.VERSION`仍0.3.5，发行OUT/TAG未改。化学专项和化学台走查通过；没有据此声称整套应用或冻结版已经验收。不要直接用旧发行目录打包；统一发行前先核对版本、接入生物专项并跑完整build/smoke/pack。
