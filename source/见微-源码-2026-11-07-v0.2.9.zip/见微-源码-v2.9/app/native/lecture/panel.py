"""上网查询的抽屉：截图、搜索词（可改）、AI 摘要、资料卡片，顶上显示实际用时。"""
from __future__ import annotations

import re
import threading
import time

from PySide6.QtCore import QObject, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QImage, QPixmap
from PySide6.QtWidgets import QDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QVBoxLayout, QWidget

from . import lookup

QSS = """
QFrame#lookup { background:#111A17; border-left:1px solid #2E3F39; }
QFrame#lookup QLabel { background:transparent; color:#DCE5E0; font-family:'Microsoft YaHei UI'; }
QFrame#lookup QLabel#title { font-size:15px; font-weight:700; color:#F2F6F4; }
QFrame#lookup QLabel#time { font-size:12px; color:#7FD1A0; }
QFrame#lookup QLabel#note { font-size:12px; color:#93A39C; }
QFrame#lookup QLineEdit { background:#0B1210; color:#F2F6F4; border:1px solid #34463F; border-radius:7px; padding:7px 9px; font-size:13.5px; font-family:'Microsoft YaHei UI'; selection-background-color:#C8402A; }
QFrame#lookup QLineEdit:focus { border-color:#DA5238; }
QFrame#lookup QPushButton { background:#1B2925; color:#DCE5E0; border:1px solid #34463F; border-radius:5px; border-bottom:2px solid #080D0B; padding:5px 11px 4px 11px; font-size:12.5px; font-family:'Microsoft YaHei UI'; }
QFrame#lookup QPushButton:hover { background:#263732; color:white; }
QFrame#lookup QPushButton#pri { background:#C8402A; border-color:#C8402A; color:white; font-weight:600; }
QFrame#lookup QPushButton#pri:hover { background:#DA5238; }
QFrame#lookup QPushButton#x { background:transparent; border:none; font-size:17px; padding:2px 8px; color:#93A39C; }
QFrame#lookup QPushButton#x:hover { color:white; background:#263732; }
QFrame#lookup QPushButton#mini { background:transparent; border:none; color:#7CC8B8; padding:2px 0; font-size:12px; }
QFrame#lookup QPushButton#mini:hover { color:#A6E0D2; background:transparent; }
QFrame#card { background:#172320; border:1px solid #26342F; border-radius:7px; }
QFrame#card:hover { border-color:#3A4C45; }
QFrame#ai { background:#14251F; border:1px solid #2C5046; border-radius:7px; }
QLabel#cardTitle { color:#A6E0D2; font-size:13.5px; font-weight:600; }
QLabel#snip { color:#C2CFC9; font-size:12.5px; }
QLabel#src { color:#7F8F88; font-size:11px; }
QLabel#why { color:#9FB2AA; font-size:11.5px; }
QFrame#lookup QPushButton#fold { background:transparent; border:none; color:#93A39C; font-size:12px; padding:3px 0; text-align:left; }
QFrame#lookup QPushButton#fold:hover { color:#DCE5E0; background:transparent; }
QLabel#aiTag { color:#7CC8B8; font-size:11.5px; font-weight:600; }
QLabel#aiBody { color:#E6EEE9; font-size:13.5px; }
QScrollArea, QScrollArea > QWidget > QWidget { background:transparent; border:none; }
QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
QScrollBar::handle:vertical { background:#34463F; border-radius:3px; min-height:30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { height:0; background:transparent; }
"""


class _TextGot(QObject):
    got = Signal(int, str, float)
    diagram = Signal(int, object)


BADGE = dict(keep=("可靠", "#21804F"), doubt=("存疑", "#B97F00"), drop=("已筛掉", "#5C6D66"))


class Card(QFrame):
    def __init__(self, item, to_board):
        super().__init__()
        self.setObjectName("card")
        self.item = item
        self.verdict = None
        v = QVBoxLayout(self)
        v.setContentsMargins(11, 9, 11, 8)
        v.setSpacing(4)
        top = QHBoxLayout()
        top.setSpacing(6)
        self.badge = QLabel("")
        self.badge.hide()
        top.addWidget(self.badge, 0, Qt.AlignmentFlag.AlignTop)
        t = QLabel((f"[{item['n']}] " if item.get("n") else "") + item["title"])
        t.setObjectName("cardTitle")
        t.setWordWrap(True)
        t.setCursor(Qt.CursorShape.PointingHandCursor)
        t.setToolTip(item["url"])
        t.mousePressEvent = lambda _e: QDesktopServices.openUrl(QUrl(item["url"]))
        self.title = t
        top.addWidget(t, 1)
        v.addLayout(top)
        if item.get("snippet"):
            s = QLabel(item["snippet"])
            s.setObjectName("snip")
            s.setWordWrap(True)
            s.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            v.addWidget(s)
        self.reason = QLabel("")
        self.reason.setObjectName("why")
        self.reason.setWordWrap(True)
        self.reason.hide()
        v.addWidget(self.reason)
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        src = QLabel(f"{item.get('source', '')} · {lookup.domain(item['url'])}")
        src.setObjectName("src")
        h.addWidget(src, 1)
        b = QPushButton("写上黑板")
        b.setObjectName("mini")
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda: to_board(item["title"] + ("\n" + item["snippet"] if item.get("snippet") else "")))
        h.addWidget(b)
        v.addLayout(h)

    def set_verdict(self, verdict, why):
        self.verdict = verdict
        text, color = BADGE[verdict]
        self.badge.setText(text)
        self.badge.setStyleSheet(f"background:{color};color:white;border-radius:3px;padding:1px 5px;font-size:11px;font-weight:600;")
        self.badge.show()
        if self.item.get("n"):
            self.title.setText(f"[{self.item['n']}] {self.item['title']}")
        if why:
            self.reason.setText("核查：" + why)
            self.reason.show()


class LookupPanel(QFrame):
    closed = Signal()
    to_board = Signal(str)
    image_to_board = Signal(QImage)

    def __init__(self, ocr: lookup.Ocr):
        super().__init__()
        self.setObjectName("lookup")
        self.setStyleSheet(QSS)
        self.ocr = ocr
        self.engine = lookup.Lookup()
        self.engine.results.connect(self._on_results)
        self.engine.ai_text.connect(self._on_ai)
        self.engine.verdict.connect(self._on_verdict)
        self.engine.checked.connect(self._on_checked)
        self.engine.finished.connect(self._on_done)
        self.bridge = _TextGot()
        self.bridge.got.connect(self._on_text)
        self.bridge.diagram.connect(self._on_diagram)
        self.diagram_revision=0
        self.diagram_view=None
        self.diagram_data=None
        self.image = None
        self.ticket = 0
        self.job = -1
        self.t0 = 0.0
        self.first_at = None
        self.n = 0
        self.cards = []
        self.show_dropped = False
        self.verified = None
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(9)
        top = QHBoxLayout()
        ti = QLabel("上网查询")
        ti.setObjectName("title")
        top.addWidget(ti)
        self.time_label = QLabel("")
        self.time_label.setObjectName("time")
        top.addWidget(self.time_label, 1)
        x = QPushButton("×")
        x.setObjectName("x")
        x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        x.clicked.connect(self.close_panel)
        top.addWidget(x)
        v.addLayout(top)
        self.thumb = QLabel()
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb.setMaximumHeight(120)
        v.addWidget(self.thumb)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.edit = QLineEdit()
        self.edit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.edit.setPlaceholderText("要查什么")
        self.edit.returnPressed.connect(self.search_now)
        row.addWidget(self.edit, 1)
        go = QPushButton("查询")
        go.setObjectName("pri")
        go.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        go.clicked.connect(self.search_now)
        row.addWidget(go)
        v.addLayout(row)
        self.note = QLabel("")
        self.note.setObjectName("note")
        self.note.setWordWrap(True)
        v.addWidget(self.note)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.body = QWidget()
        self.list = QVBoxLayout(self.body)
        self.list.setContentsMargins(0, 0, 4, 0)
        self.list.setSpacing(8)
        self.local_box=QWidget()
        self.local_lay=QVBoxLayout(self.local_box)
        self.local_lay.setContentsMargins(0,0,0,0)
        self.local_note=QLabel('')
        self.local_note.setWordWrap(True)
        self.local_lay.addWidget(self.local_note)
        self.enlarge=QPushButton('放大本地图解')
        self.enlarge.clicked.connect(self._enlarge_diagram)
        self.local_lay.addWidget(self.enlarge)
        self.enlarge.hide()
        self.list.addWidget(self.local_box)
        self.ai_box = QFrame()
        self.ai_box.setObjectName("ai")
        av = QVBoxLayout(self.ai_box)
        av.setContentsMargins(11, 9, 11, 9)
        av.setSpacing(4)
        ah = QHBoxLayout()
        self.ai_tag = QLabel("DeepSeek 正在核查…")
        self.ai_tag.setObjectName("aiTag")
        self.ai_tag.setWordWrap(True)
        ah.addWidget(self.ai_tag, 1)
        ab = QPushButton("写上黑板")
        ab.setObjectName("mini")
        ab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        ab.clicked.connect(lambda: self.to_board.emit(re.sub(r"\s*\[\d+\]", "", self.ai_body.text())))
        ah.addWidget(ab)
        av.addLayout(ah)
        self.ai_body = QLabel("")
        self.ai_body.setObjectName("aiBody")
        self.ai_body.setWordWrap(True)
        self.ai_body.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        av.addWidget(self.ai_body)
        self.ai_box.hide()
        self.list.addWidget(self.ai_box)
        self.fold = QPushButton("")
        self.fold.setObjectName("fold")
        self.fold.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.fold.setCursor(Qt.CursorShape.PointingHandCursor)
        self.fold.clicked.connect(self._toggle_dropped)
        self.fold.hide()
        self.list.addWidget(self.fold)
        self.list.addStretch(1)
        self.scroll.setWidget(self.body)
        v.addWidget(self.scroll, 1)
        foot = QHBoxLayout()
        self.img_btn = QPushButton("截图带入黑板")
        self.img_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.img_btn.clicked.connect(lambda: self.image is not None and self.image_to_board.emit(self.image))
        foot.addWidget(self.img_btn)
        self.web_btn = QPushButton("在浏览器里搜")
        self.web_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.web_btn.clicked.connect(self._open_web)
        foot.addWidget(self.web_btn)
        foot.addStretch(1)
        v.addLayout(foot)

    # ---- 开始
    def start(self, image: QImage, text: str, hint: str = "") -> None:
        """截图 + 文字层里的文字；没有文字时先识别图片。整个过程不卡界面。"""
        self.t0 = time.perf_counter()
        self.ticket += 1
        self.image = image
        self.engine.cancel()
        self._reset()
        self.img_btn.setVisible(True)
        pm = QPixmap.fromImage(image).scaled(420, 120, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.thumb.setPixmap(pm)
        self.thumb.setVisible(True)
        self.edit.setText("")
        self.hint = hint
        q = lookup.make_query(text)
        if len(q) >= 2:
            self.edit.setText(q)
            self._local_diagram(text)
            self._go(q)
            return
        self.note.setText("这块是图片，正在识别上面的文字…")
        lookup.warm()
        tk = self.ticket
        threading.Thread(target=lambda: self.bridge.got.emit(tk, self.ocr.read(image), time.perf_counter() - self.t0), daemon=True).start()

    def _on_text(self, ticket, text, _el):
        if ticket != self.ticket:
            return
        q = lookup.make_query(text)
        if len(q) >= 2:
            self.edit.setText(q)
            self._local_diagram(text)
            self._go(q)
        else:
            self.note.setText("图里没有读到文字。写下想查的内容，按回车。")
            if self.hint:
                self.edit.setPlaceholderText(f"比如：{self.hint}")
            self.edit.setFocus()

    def search_now(self):
        q = self.edit.text().strip()
        if q:
            self.t0 = time.perf_counter()
            self._reset()
            self._local_diagram(q)
            self._go(q)

    def _reset(self):
        self.engine.cancel()
        self.diagram_revision+=1
        self.diagram_data=None
        self.enlarge.hide()
        self.local_note.setText('')
        if self.diagram_view is not None:
            self.diagram_view.hide()
            self.diagram_view.deleteLater()
            self.diagram_view=None
        self.first_at = None
        self.n = 0
        self.time_label.setText("")
        self.note.setText("")
        self.ai_body.setText("")
        self.ai_tag.setText("DeepSeek 正在核查…")
        self.ai_box.hide()
        self.fold.hide()
        self.show_dropped = False
        for c in self.cards:
            self.list.removeWidget(c)
            c.hide()
            c.deleteLater()
        self.cards = []

    def _local_diagram(self,text):
        from .local_diagram import resolve
        revision=self.diagram_revision
        self.local_note.setText('正在匹配本地逐题图解…')
        bridge=self.bridge
        def work():
            try:
                figure=resolve(text)
            except (OSError,ValueError,TypeError):
                figure=None
            try:
                bridge.diagram.emit(revision,figure)
            except RuntimeError:
                pass  # Panel was destroyed; no Qt worker object survives it.
        threading.Thread(target=work,daemon=True).start()

    def _on_diagram(self,revision,figure):
        if revision!=self.diagram_revision:
            return
        if not figure:
            self.local_note.setText('本地未匹配到专用图解。可将完整题干带入析题，不使用相似题的数值代替。')
            return
        from ..analysis.figure.view import FigureView
        self.diagram_data=figure
        self.diagram_view=FigureView(figure)
        self.diagram_view.setMinimumHeight(300)
        self.local_lay.insertWidget(1,self.diagram_view)
        self.local_note.setText('本地题干/概念精确匹配图解 · 定性图不代替数值求解')
        self.enlarge.show()

    def _enlarge_diagram(self):
        if not self.diagram_data:
            return
        from ..analysis.figure.view import FigureView
        dialog=QDialog(self)
        dialog.setWindowTitle('本地图解')
        dialog.resize(1080,780)
        QVBoxLayout(dialog).addWidget(FigureView(self.diagram_data))
        dialog.exec()

    def _go(self, q):
        self.note.setText("正在查…")
        self.verified = None
        self.job = self.engine.start(q)

    # ---- 结果
    def _on_results(self, job, items, _el):
        if job != self.job:
            return
        if self.first_at is None:
            self.first_at = time.perf_counter() - self.t0
            self.note.setText("")
            if lookup._ai_ready():
                self.ai_box.show()
            else:
                self.note.setText("这些结果没有经过核查。填了 DeepSeek 密钥后，会逐条核查并筛选。")
        for it in items:
            if self.n >= 12:
                break
            c = Card(it, self.to_board.emit)
            self.cards.append(c)
            self.list.insertWidget(self.list.count() - 1, c)
            self.n += 1
        self._time()

    def _time(self):
        self.time_label.setText(f"{self.first_at:.1f} 秒出资料 · {self.n} 条")

    def _on_verdict(self, job, url, verdict, why):
        if job != self.job:
            return
        for c in self.cards:
            if c.item["url"] == url:
                c.set_verdict(verdict, why)
                break

    def _on_ai(self, job, text):
        if job != self.job:
            return
        self.ai_box.show()
        self.ai_body.setText(text)

    def _on_checked(self, job, info):
        """核查结束：可靠的排前面，存疑的其次，筛掉的收起来（可以展开看）。"""
        if job != self.job:
            return
        self.verified = info
        if not info.get("ok"):
            self.ai_box.hide()
            self.note.setText(f"没能核查（{info.get('why')}），下面是未筛选的原始结果。")
            return
        el = time.perf_counter() - self.t0
        if not info["total"]:
            self.ai_tag.setText("没有查到网上资料。下面是 DeepSeek 自己的知识，没有经过资料核对，请谨慎使用")
            self.note.setText("")
            return
        tag = f"DeepSeek 核查了 {info['total']} 条：{info['kept']} 条可靠，{info['doubt']} 条存疑，筛掉 {info['dropped']} 条（{el:.1f} 秒）"
        if not self.ai_body.text():
            self.ai_body.setText("这些资料不足以回答。可以换个说法再查。")
        self.ai_tag.setText(tag + "。只看了标题和摘要，没有打开原网页")
        if info.get("conflict"):
            self.ai_body.setText(self.ai_body.text() + "\n\n资料之间有分歧：" + info["conflict"])
        order = {"keep": 0, "doubt": 1, None: 2, "drop": 3}
        self.cards.sort(key=lambda c: order[c.verdict])
        for c in self.cards:
            self.list.removeWidget(c)
        pos = 2
        for c in self.cards:
            if c.verdict == "drop":
                continue
            self.list.insertWidget(pos, c)
            pos += 1
        self.list.removeWidget(self.fold)
        self.list.insertWidget(pos, self.fold)
        pos += 1
        for c in self.cards:
            if c.verdict == "drop":
                self.list.insertWidget(pos, c)
                pos += 1
        self._apply_fold()

    def _toggle_dropped(self):
        self.show_dropped = not self.show_dropped
        self._apply_fold()

    def _apply_fold(self):
        gone = [c for c in self.cards if c.verdict == "drop"]
        self.fold.setVisible(bool(gone))
        self.fold.setText(f"{'▾' if self.show_dropped else '▸'} 已筛掉 {len(gone)} 条，点开看原因")
        for c in gone:
            c.setVisible(self.show_dropped)

    def _on_done(self, job, n, _el):
        if job != self.job or n:
            return
        if not self.ai_body.text():
            self.ai_box.hide()
            blocked = bool(lookup._muted) and all(t > time.time() for t in lookup._muted.values())
            self.note.setText("搜索站暂时要求人工验证（可能查得太频繁），过一会儿再试，或者点下面的「在浏览器里搜」。" if blocked else "没有查到资料。可能没联网，或者换个说法再试试。")

    def _open_web(self):
        from urllib.parse import quote
        q = self.edit.text().strip()
        if q:
            QDesktopServices.openUrl(QUrl(f"https://www.so.com/s?q={quote(q)}"))

    def close_panel(self):
        self.engine.cancel()
        self.diagram_revision+=1
        if self.diagram_view is not None:
            self.diagram_view.timer.stop()
        self.ticket += 1
        self.hide()
        self.closed.emit()
