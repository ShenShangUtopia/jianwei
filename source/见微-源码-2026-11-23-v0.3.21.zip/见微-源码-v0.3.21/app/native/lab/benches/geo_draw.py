"""几何画板的绘制层（由 legacy/lab-math.js 改写）：网格、坐标轴、对象、测量、变换标注、矩阵卡。"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPixmap, QPolygonF, QTransform

from ...design.tokens import T, alpha, qc
from ...kit.core import TAU, clamp
from ...kit.draw import D
from .geo_core import apply_m, fmt_angle, invert_m, is_i, is_num, matrix_rows, num, pretty_expr, truncate


def clip_line(x1, y1, x2, y2, w, h):
    dx, dy = x2 - x1, y2 - y1
    pts = []

    def add(x, y):
        if x < -0.01 or x > w + 0.01 or y < -0.01 or y > h + 0.01:
            return
        if any(abs(p[0] - x) < 0.5 and abs(p[1] - y) < 0.5 for p in pts):
            return
        pts.append((x, y))
    if abs(dx) > 1e-9:
        add(0, y1 + (0 - x1) / dx * dy)
        add(w, y1 + (w - x1) / dx * dy)
    if abs(dy) > 1e-9:
        add(x1 + (0 - y1) / dy * dx, 0)
        add(x1 + (h - y1) / dy * dx, h)
    if len(pts) < 2:
        return None
    if len(pts) == 2:
        return pts
    best, bd = pts[:2], -1
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            d = math.hypot(pts[i][0] - pts[j][0], pts[i][1] - pts[j][1])
            if d > bd:
                bd, best = d, [pts[i], pts[j]]
    return best


class GeoDraw:
    """混入 GeoCore：把场景画到 G 上。"""

    def color_of(self, key):
        return {"accent": T.c2, "jade": T.c3, "ink": T.fg, "ink2": T.math, "gold": T.c4, "soft": T.muted, "faint": T.axis,
                "data0": T.math, "data1": T.c1, "data2": T.c3}.get(key, T.math)

    def object_color(self, o):
        if not o:
            return self.color_of("ink2")
        if o["type"] in ("mdist", "mangle", "marea"):
            return self.color_of("accent")
        return self.color_of(o.get("color") or "ink2")

    def current_transform(self):
        if self.handle and self.handle.get("preview"):
            return self.handle["preview"]
        return self.last_transform

    def draw_scene(self, g, w, h):
        self.w, self.h = w, h
        self.draw_base(g, w, h)
        self.draw_backdrop(g, w, h)
        for o in self.objects:   # 原像 ghost
            self.draw_object(g, o, "ghost")
        if self.show_measure:
            for o in self.objects:
                if not o["hidden"] and o["type"] == "marea":
                    self.draw_measure_base(g, o)
        for i in self.selection:   # 选中光晕
            o = self.by_id(i)
            if not o or o["hidden"]:
                continue
            if o["type"] == "function":
                self.draw_function(g, o, "halo")
            elif o["type"] not in ("point", "mdist", "mangle", "marea"):
                self.draw_shape(g, o, "halo")
        for group in (("function",), ("line", "segment", "vector"), ("circle",), ("polygon",), ("point",)):
            for o in self.objects:
                if o["type"] in group:
                    self.draw_object(g, o, "solid")
        if self.show_measure:
            for o in self.objects:
                if not o["hidden"] and o["type"] in ("mdist", "mangle", "marea"):
                    self.draw_measure(g, o)
        self.draw_fn_extras(g)
        self.draw_draft(g)
        self.draw_snap(g)
        self.draw_annotation(g, w, h)
        self.draw_handle_hint(g)
        self.draw_matrix_card(g, w, h)
        self.draw_scale_bar(g, w, h)

    def draw_base(self, g, w, h):
        """底色 + 网格 + 坐标轴 + 刻度。视野不变（拖点、拖切点、选对象）时直接贴上次画好的底图（0.3.12）。"""
        dev = g.p.device()
        dpr = dev.devicePixelRatioF() if dev is not None else 1.0
        v = self.view
        key = (v["cx"], v["cy"], v["scale"], w, h, dpr, T.stage, T.fg, T.math, T.muted, bool(self.show_grid))
        bc = self.__dict__.setdefault("_base", {"key": None, "pm": None})
        if bc["key"] != key or bc["pm"] is None:
            pm = QPixmap(max(1, round(w * dpr)), max(1, round(h * dpr)))
            pm.setDevicePixelRatio(dpr)
            pm.fill(qc(T.stage))
            p = QPainter(pm)
            p.setRenderHints(g.p.renderHints())
            from ...kit.draw import G
            sub = G(p)
            try:
                if self.show_grid:
                    self.draw_grid(sub, w, h)
                self.draw_axes(sub, w, h)
            finally:
                p.end()
            bc["key"], bc["pm"] = key, pm
            bc["builds"] = bc.get("builds", 0) + 1
        g.p.drawPixmap(0, 0, bc["pm"])

    def draw_grid(self, g, w, h):
        major, minor = self.grid_steps()
        s = self.view["scale"]
        xmin, xmax = self.view["cx"] - w / 2 / s, self.view["cx"] + w / 2 / s
        ymin, ymax = self.view["cy"] - h / 2 / s, self.view["cy"] + h / 2 / s
        aa = g.p.testRenderHint(QPainter.RenderHint.Antialiasing)
        g.p.setRenderHint(QPainter.RenderHint.Antialiasing, False)

        # 网格紧接着底色画，所以先把半透明的线色和底色混好，再用不透明的 1 像素矩形填：
        # Qt 软件光栅画半透明线很慢（160 条约 10 ms），不透明填充快得多，画出来一样（0.3.12）
        bg, fg = qc(T.stage), qc(T.fg)

        def mix(a):
            return QColor(round(bg.red() + (fg.red() - bg.red()) * a), round(bg.green() + (fg.green() - bg.green()) * a),
                          round(bg.blue() + (fg.blue() - bg.blue()) * a))

        def lines(step, a, skip=None):
            col = mix(a)
            x = math.ceil(xmin / step) * step
            while x <= xmax:
                if skip is None or abs(x / skip - round(x / skip)) > 1e-6:
                    g.p.fillRect(QRectF(round(self.X(x)), 0, 1, h), col)
                x += step
            y = math.ceil(ymin / step) * step
            while y <= ymax:
                if skip is None or abs(y / skip - round(y / skip)) > 1e-6:
                    g.p.fillRect(QRectF(0, round(self.Y(y)), w, 1), col)
                y += step
        if minor * s >= 6:
            lines(minor, 0.04, major)
        lines(major, 0.085)
        g.p.setRenderHint(QPainter.RenderHint.Antialiasing, aa)

    def draw_axes(self, g, w, h):
        major, _ = self.grid_steps()
        ax_x, ax_y = clamp(self.X(0), 0, w), clamp(self.Y(0), 0, h)
        ink = alpha(T.math, 0.52)
        D.line(g, 0, round(ax_y) + 0.5, w, round(ax_y) + 0.5, ink, 1.15)
        D.line(g, round(ax_x) + 0.5, 0, round(ax_x) + 0.5, h, ink, 1.15)
        tip = alpha(T.math, 0.62)
        if self.X(0) < w - 2:
            D.poly(g, [(w - 1, ax_y), (w - 8, ax_y - 3.6), (w - 8, ax_y + 3.6)], tip)
        if self.Y(0) > 2:
            D.poly(g, [(ax_x, 1), (ax_x - 3.6, 8), (ax_x + 3.6, 8)], tip)
        s = self.view["scale"]
        col = alpha(T.muted, 0.82)
        xmin, xmax = self.view["cx"] - w / 2 / s, self.view["cx"] + w / 2 / s
        ymin, ymax = self.view["cy"] - h / 2 / s, self.view["cy"] + h / 2 / s
        ly = ax_y + 12 if ax_y < h - 22 else ax_y - 10
        x = math.ceil(xmin / major) * major
        while x <= xmax:
            sx = self.X(x)
            if abs(x) >= major * 1e-6 and 12 <= sx <= w - 12:
                D.text(g, self.tick_text(x, major), sx, ly, col, size=9.5, align="center")
            x += major
        lx, al = (ax_x - 6, "right") if ax_x > 48 else (ax_x + 6, "left")
        y = math.ceil(ymin / major) * major
        while y <= ymax:
            sy = self.Y(y)
            if abs(y) >= major * 1e-6 and 12 <= sy <= h - 12:
                D.text(g, self.tick_text(y, major), lx, sy, col, size=9.5, align=al)
            y += major
        if 0 <= self.X(0) <= w and 0 <= self.Y(0) <= h:
            D.circle(g, self.X(0), self.Y(0), 1.8, alpha(T.math, 0.65))
        nm = alpha(T.muted, 0.72)
        D.text(g, "x", w - 11, ax_y - 12, nm, size=11, align="right", serif=True)
        D.text(g, "y", ax_x + 7, 16, nm, size=11, serif=True)

    def draw_backdrop(self, g, w, h):
        lt = self.current_transform()
        if not lt or lt["type"] != "sym-line" or not self.show_annotation:
            return
        ax = (lt.get("params") or {}).get("axis")
        if not ax or len(ax) < 2:
            return
        a, b = self.screen_of(ax[0]), self.screen_of(ax[1])
        seg = clip_line(a[0], a[1], b[0], b[1], w, h)
        if seg:
            D.line(g, seg[0][0], seg[0][1], seg[1][0], seg[1][1], alpha(T.c2, 0.4), 1.2, [7, 6])

    def draw_object(self, g, o, mode):
        if not o or o["hidden"]:
            return
        t = o["type"]
        if mode == "ghost":
            if t == "function":
                if not is_i(o["m"]):
                    self.draw_function(g, o, "ghost")
                return
            if t == "point":
                p = self.cur_of_point(o)
                if p and not is_i(o["m"]):
                    g.dash = [3, 3]
                    g.stroke_style, g.line_width = alpha(T.axis, 0.55), 1.2
                    g.begin_path()
                    g.arc(self.X(p[0]), self.Y(p[1]), 3.2, 0, TAU)
                    g.stroke()
                    g.dash = []
                return
            if t in ("mdist", "mangle", "marea"):
                return
            pts = self.dep_points(o)
            if not pts or not any(not is_i(p.get("m")) for p in pts):
                return
            self.draw_shape(g, o, "ghost")
            return
        if t == "point":
            self.draw_point(g, o)
        elif t == "function":
            self.draw_function(g, o, "halo" if mode == "halo" else "solid")
        elif t in ("circle", "polygon", "segment", "line", "vector"):
            self.draw_shape(g, o, mode)

    def _style(self, g, o, mode):
        ghost, halo = mode == "ghost", mode == "halo"
        col = T.axis if ghost else T.c2 if halo else self.object_color(o)
        a = 0.55 if ghost else 0.15 if halo else 1
        g.stroke_style = alpha(col, a)
        g.fill_style = alpha(col, a)
        wd = o.get("width") or 2
        g.line_width = 1.2 if ghost else wd + 6 if halo else wd
        g.line_join, g.line_cap = "round", "round"
        g.dash = [5, 4] if ghost else [4, 4] if o.get("dash") else []
        return col

    def _reset(self, g):
        g.line_join, g.line_cap = "miter", "butt"
        g.dash = []

    def draw_shape(self, g, o, mode):
        if not o or o["hidden"]:
            return
        ghost, halo = mode == "ghost", mode == "halo"
        t = o["type"]
        X, Y = self.X, self.Y
        base = [(p["x"], p["y"]) if ghost else self.cur_of_point(p) for p in self.dep_points(o)]
        if t == "circle":
            co, ro = self.by_id(o.get("c")), self.by_id(o.get("r"))
            if not co or not ro:
                return
            c = (co["x"], co["y"]) if ghost else self.cur_of_point(co)
            rp = (ro["x"], ro["y"]) if ghost else self.cur_of_point(ro)
            r = math.hypot(rp[0] - c[0], rp[1] - c[1]) * self.view["scale"]
            if r < 0.5:
                return
            col = self._style(g, o, mode)
            g.begin_path()
            g.arc(X(c[0]), Y(c[1]), r, 0, TAU)
            if not ghost and not halo:
                g.fill_style = alpha(col, 0.045)
                g.fill()
            g.stroke()
            self._reset(g)
            if not ghost and not halo and o["id"] in self.selection:
                D.line(g, X(c[0]), Y(c[1]), X(rp[0]), Y(rp[1]), alpha(T.c2, 0.34), 1, [4, 5])
            return
        if t == "polygon":
            if len(base) < 3:
                return
            col = self._style(g, o, mode)
            g.begin_path()
            for i, p in enumerate(base):
                (g.line_to if i else g.move_to)(X(p[0]), Y(p[1]))
            g.close_path()
            if not ghost and not halo:
                g.fill_style = alpha(col, 0.065)
                g.fill()
            g.stroke()
            self._reset(g)
            return
        if t in ("segment", "vector"):
            if len(base) < 2:
                return
            a, b = base[0], base[1]
            col = self._style(g, o, mode)
            g.begin_path()
            g.move_to(X(a[0]), Y(a[1]))
            g.line_to(X(b[0]), Y(b[1]))
            g.stroke()
            if t == "vector" and not ghost and not halo:
                self._head(g, X(a[0]), Y(a[1]), X(b[0]), Y(b[1]), col, 9)
            self._reset(g)
            return
        if t == "line":
            if len(base) < 2:
                return
            a, b = base[0], base[1]
            seg = clip_line(X(a[0]), Y(a[1]), X(b[0]), Y(b[1]), self.w, self.h)
            if not seg:
                return
            self._style(g, o, mode)
            g.begin_path()
            g.move_to(*seg[0])
            g.line_to(*seg[1])
            g.stroke()
            self._reset(g)

    @staticmethod
    def _head(g, x0, y0, x1, y1, col, ln):
        ang = math.atan2(y1 - y0, x1 - x0)
        D.poly(g, [(x1, y1), (x1 - ln * math.cos(ang - 0.42), y1 - ln * math.sin(ang - 0.42)),
                   (x1 - ln * math.cos(ang + 0.42), y1 - ln * math.sin(ang + 0.42))], col)

    def draw_point(self, g, o):
        p = self.cur_of_point(o)
        if not p:
            return
        sx, sy = self.X(p[0]), self.Y(p[1])
        col = self.object_color(o)
        if o["aux"]:
            D.circle(g, sx, sy, 2.3, alpha(col, 0.55))
            return
        selected = o["id"] in self.selection
        pr = 3.4 + (o.get("width") or 1) * 0.8
        r = pr + 1 if selected else pr
        D.circle(g, sx, sy, r, col, alpha(T.stage, 0.9), 1.3)
        if selected:
            D.circle(g, sx, sy, 9.2, None, alpha(T.c2, 0.92), 1.6)
            D.circle(g, sx, sy, 9.2, None, alpha(T.c2, 0.22), 4)
        D.text(g, o.get("name") or "", sx + 9, sy - 9, alpha(T.c2 if selected else T.fg, 0.95), size=12, serif=True)

    def draw_function(self, g, o, mode):
        if not o or o["hidden"] or not o.get("fn"):
            return
        ghost, halo = mode == "ghost", mode == "halo"
        polys = self.curve_polys(("f", o["id"]), o["fn"], o["m"])
        if polys is None:
            return
        col = T.axis if ghost else T.c2 if halo else self.object_color(o)
        a = 0.55 if ghost else 0.16 if halo else 1
        wd = o.get("width") or 2.2
        g.line_join, g.line_cap = "round", "round"
        self._polylines(g, polys, g._pen(alpha(col, a), 1.2 if ghost else wd + 6 if halo else wd, [5, 4] if ghost else []))
        self._reset(g)
        fn, m = o["fn"], o["m"]
        vs, cx = self.view["scale"], self.view["cx"]
        if not ghost and not halo:   # 曲线标签：在可视区右侧找一个点
            tx = cx + (self.w * 0.26) / vs
            y = fn(tx)
            if math.isfinite(y):
                s = self.screen_of(apply_m(m, tx, y))
                if 20 < s[0] < self.w - 20 and 50 < s[1] < self.h - 30 and o["id"] not in self.selection:
                    self.chip(g, s[0], s[1] - 18, "y = " + truncate(pretty_expr(o["expr"]), 18), self.object_color(o), "center")

    # ---- 函数：特殊点、切线、导函数、伸缩前的原图
    def curve_polys(self, tag, fn, m):
        """曲线的屏幕折线（列表）。采样结果按世界坐标缓存：
        同一函数、同一伸缩、同一缩放比例时，视野还在已采样范围内（左右各多采半屏）就不重新求值，
        平移视野、拖别的对象都只做一次坐标变换（0.3.12）。tag 区分同一对象的原曲线 / 导函数 / 原图。"""
        x0, x1 = self.fn_x_range({"m": m})
        if not math.isfinite(x0) or not math.isfinite(x1) or x1 - x0 < 1e-6:
            return None
        vs, cx, cy, hw, hh = self.view["scale"], self.view["cx"], self.view["cy"], self.w / 2, self.h / 2
        mk = tuple(m[:6])
        cache = self.__dict__.setdefault("_curves", {})
        hit = cache.get(tag)
        # 缩放比例差不到两成时也复用（采样密度、去点容差跟着差一点，肉眼看不出），滚轮缩放时不用每帧重采
        if not (hit and hit["fn"] is fn and hit["m"] == mk and 0.85 <= vs / hit["vs"] <= 1.18 and hit["h"] == self.h
                and hit["x0"] <= x0 and x1 <= hit["x1"] and hit["w"] >= self.w):
            span = x1 - x0
            X0, X1 = clamp(x0 - span * 0.5, -1e4, 1e4), clamp(x1 + span * 0.5, -1e4, 1e4)
            n = int(clamp(round(clamp(self.w, 300, 1200) * (X1 - X0) / span), 300, 2600))
            hit = {"fn": fn, "m": mk, "vs": vs, "h": self.h, "w": self.w, "x0": X0, "x1": X1,
                   "polys": self._sample(fn, mk, X0, X1, n, self.h * 0.62 / vs, 0.2 / vs)}
            self.__dict__["_curve_builds"] = self.__dict__.get("_curve_builds", 0) + 1
            cache[tag] = hit
        tr = QTransform(vs, 0, 0, -vs, hw - cx * vs, hh + cy * vs)
        # 采样范围比可视区宽：只描落在可视区里的那几段（按每 48 个点一块的外框判断），屏幕外的不描
        pad = 12 / vs
        view = QRectF(cx - hw / vs - pad, cy - hh / vs - pad, self.w / vs + pad * 2, self.h / vs + pad * 2)
        out = []
        for poly, boxes in hit["polys"]:
            vis = [k for k, b in enumerate(boxes) if b.intersects(view)]
            if not vis:
                continue
            a, b = vis[0], vis[-1]
            if a == 0 and b == len(boxes) - 1:
                out.append(tr.map(poly))
            else:
                i0, i1 = a * 48, min(poly.size(), (b + 1) * 48 + 1)
                out.append(tr.map(QPolygonF(poly.mid(i0, i1 - i0))))
        return out

    @staticmethod
    def _sample(fn, m, x0, x1, n, lim, tol):
        """在 [x0, x1] 上取 n+1 个点，经仿射 m 变到世界坐标；遇到无定义或跳变（世界坐标里超过 lim）就断开。
        几乎共线的点去掉（偏离不超过 tol，约 0.2 像素）：直线段、平缓段只留两端，描线时少很多段。"""
        m0, m1, m2, m3, m4, m5 = m
        polys, run, prev = [], [], None

        def flush():
            if len(run) > 1:
                pts = GeoDraw._simplify(run, tol)
                boxes = []
                for k in range(0, len(pts) - 1, 48):   # 第 k 块是点 k..k+48（相邻块共用端点）
                    seg = pts[k:k + 49]
                    xs, ys = [p[0] for p in seg], [p[1] for p in seg]
                    boxes.append(QRectF(min(xs), min(ys), max(xs) - min(xs) or 1e-9, max(ys) - min(ys) or 1e-9))
                polys.append((QPolygonF([QPointF(px, py) for px, py in pts]), boxes))
        dx = (x1 - x0) / n
        for i in range(n + 1):
            x = x0 + dx * i
            try:
                y = fn(x)
            except (ValueError, ZeroDivisionError, OverflowError):
                y = math.nan
            if not math.isfinite(y) or abs(y) > 1e7:
                flush()
                run, prev = [], None
                continue
            wy = m3 * x + m4 * y + m5
            if prev is not None and abs(wy - prev) > lim:
                flush()
                run = []
            run.append((m0 * x + m1 * y + m2, wy))
            prev = wy
        flush()
        return polys

    @staticmethod
    def _simplify(pts, tol, cap=24):
        """贪心去点：从锚点出发往后延伸，只要中间所有点到「锚点—新点」连线的距离都 ≤ tol 就继续；
        中间点最多 cap 个，保证每次判断的代价有上限。"""
        if len(pts) < 3:
            return pts
        out = [pts[0]]
        ax, ay = pts[0]
        mids = []
        for k in range(1, len(pts)):
            px, py = pts[k]
            dx, dy = px - ax, py - ay
            ln = math.hypot(dx, dy)
            ok = len(mids) < cap
            if ok and mids and ln > 0:
                for qx, qy in mids:
                    if abs((qx - ax) * dy - (qy - ay) * dx) > tol * ln:
                        ok = False
                        break
            if ok:
                mids.append(pts[k])
                continue
            last = mids[-1] if mids else pts[k]
            out.append(last)
            ax, ay = last
            mids = [pts[k]] if mids else []
            if not mids:
                ax, ay = pts[k]
        if mids:
            out.append(mids[-1])
        return out

    @staticmethod
    def _polylines(g, polys, pen):
        g.p.setPen(pen)
        g.p.setBrush(Qt.BrushStyle.NoBrush)
        for p in polys:
            g.p.drawPolyline(p)

    def draw_curve(self, g, fn, m, col, wd, dash=(), tag=None):
        polys = self.curve_polys(tag or ("c", id(fn)), fn, m)
        if polys:
            self._polylines(g, polys, g._pen(col, wd, list(dash)))

    def draw_fn_extras(self, g):
        from .geo_calc import deriv, is_ident, line_text
        for o in self.objects:
            if o["type"] != "function" or o["hidden"] or not o.get("fn"):
                continue
            col = self.object_color(o)
            sel = o["id"] in self.selection
            m = o["m"]
            if not is_ident(o.get("tf")) and o.get("_base"):
                self.draw_curve(g, o["_base"], m, alpha(T.axis, 0.6), 1.2, (5, 4), ("b", o["id"]))
            if o.get("deriv"):
                f = o["fn"]
                dfn = self.__dict__.setdefault("_dfns", {})
                if dfn.get(o["id"], (None,))[0] is not f:   # 导函数的 lambda 跟着 f 走，曲线缓存才认得出是同一条
                    dfn[o["id"]] = (f, lambda x, f=f: deriv(f, x))
                self.draw_curve(g, dfn[o["id"]][1], m, alpha(col, 0.55), 1.6, (7, 4), ("d", o["id"]))
            if sel or o.get("marks"):
                self.draw_features(g, o, col, sel)
            if o.get("tan"):
                self.draw_tangent(g, o, col, line_text)

    def draw_features(self, g, o, col, sel):
        feats = self.fn_features_wide(o)
        m = o["m"]
        if o.get("deriv"):   # f′ 的零点就是 f 的极值点：用竖虚线连起来
            for x, y in feats["maxima"] + feats["minima"]:
                s = self.screen_of(apply_m(m, x, y))
                g.p.strokePath(self._vline(s[0]), g._pen(alpha(col, 0.28), 1, [3, 4]))
        shown = 0
        cx, cy = self.w / 2, self.h / 2
        for kind in ("zeros", "maxima", "minima", "inflections"):
            # 0.3.14：先挑在屏幕上的、离中心近的 12 个（以前先取宽范围里最左的 12 个，周期函数中间一个标记都没有）；
            # 屏幕上挨得很近的（floor(x) 一整段都是 0）只画一个
            pts = []
            for x, y in feats[kind]:
                sx, sy = self.screen_of(apply_m(m, x, y))
                if -20 < sx < self.w + 20 and -20 < sy < self.h + 20 and all(abs(sx - a) + abs(sy - b) > 10 for a, b, _x, _y in pts):
                    pts.append((sx, sy, x, y))
            pts.sort(key=lambda p: abs(p[0] - cx) + abs(p[1] - cy))
            for sx, sy, x, y in sorted(pts[:12]):
                if kind == "zeros":
                    D.circle(g, sx, sy, 4.6, alpha(T.stage, 0.95), col, 1.8)
                elif kind == "maxima":
                    D.poly(g, [(sx, sy - 6), (sx - 5.5, sy + 3.5), (sx + 5.5, sy + 3.5)], col)
                elif kind == "minima":
                    D.poly(g, [(sx, sy + 6), (sx - 5.5, sy - 3.5), (sx + 5.5, sy - 3.5)], col)
                else:
                    D.poly(g, [(sx, sy - 5), (sx + 5, sy), (sx, sy + 5), (sx - 5, sy)], alpha(T.stage, 0.95), col, 1.5)
                if sel and shown < 10:
                    shown += 1
                    name = {"zeros": "零点", "maxima": "极大", "minima": "极小", "inflections": "拐点"}[kind]
                    above = kind != "minima"
                    self.chip(g, sx, sy - 17 if above else sy + 17, f"{name} ({num(x, 2)}, {num(y, 2)})", col, "center", 9.5)

    def _vline(self, sx):
        path = QPainterPath()
        path.moveTo(sx, 0)
        path.lineTo(sx, self.h)
        return path

    def draw_tangent(self, g, o, col, line_text):
        from .geo_calc import tangent
        t = o["tan"]
        a = t["x"]
        res = tangent(o["fn"], a)
        if not res:
            return
        y0, k = res
        m = o["m"]
        p, q = apply_m(m, a, y0), apply_m(m, a + 1, y0 + k)
        sp, sq = self.screen_of(p), self.screen_of(q)
        tc = T.c2
        seg = clip_line(sp[0], sp[1], sq[0], sq[1], self.w, self.h)
        if seg:
            D.line(g, seg[0][0], seg[0][1], seg[1][0], seg[1][1], alpha(tc, 0.9), 1.8)
        if t.get("normal"):
            nq = apply_m(m, a - k, y0 + 1)
            sn = self.screen_of(nq)
            seg = clip_line(sp[0], sp[1], sn[0], sn[1], self.w, self.h)
            if seg:
                D.line(g, seg[0][0], seg[0][1], seg[1][0], seg[1][1], alpha(tc, 0.55), 1.3, [6, 5])
        dragging = bool(self.pointer and self.pointer.get("mode") == "slide" and self.pointer.get("id") == o["id"])
        D.circle(g, sp[0], sp[1], 10 if dragging else 8, None, alpha(tc, 0.25), 4)
        D.circle(g, sp[0], sp[1], 5.6, tc, alpha(T.stage, 0.95), 1.6)
        ident = is_i(m)
        eq = line_text(k, y0 - k * a) if ident else f"斜率 {num(k, 3)}"
        lines = [f"x = {num(a, 3)}，f(x) = {num(y0, 3)}", f"切线 {eq}", f"f′(x) = {num(k, 3)}"]
        if t.get("snap"):
            lines.append("吸附：" + t["snap"])
        bx = sp[0] + 14 if sp[0] < self.w - 190 else sp[0] - 14
        by = sp[1] - 44 if sp[1] > 70 else sp[1] + 16
        for i, s in enumerate(lines):
            self.chip(g, bx, by + i * 17, s, tc if i == 1 else col, "left" if bx > sp[0] else "right", 9.5)

    def chip(self, g, x, y, text, color=None, align="center", size=10):
        tw = D.measure(text, size)
        pad, hgt = 6, 18
        bx = x if align == "left" else x - tw - pad * 2 if align == "right" else x - tw / 2 - pad
        bx = clamp(bx, 6, max(6, self.w - tw - pad * 2 - 6))
        D.rrect(g, bx, y - hgt / 2, tw + pad * 2, hgt, 7, alpha(T.surface, 0.88), T.line, 1)
        D.text(g, text, bx + pad, y, color or T.fg, size=size)

    def draw_measure_base(self, g, o):
        poly = self.by_id(o.get("poly"))
        if not poly:
            return
        pts = self.poly_pts(poly)
        if len(pts) >= 3:
            D.poly(g, [self.screen_of(p) for p in pts], alpha(T.c2, 0.055))

    def draw_measure(self, g, o):
        t = o["type"]
        acc = T.c2
        X, Y = self.X, self.Y
        if t == "mdist":
            a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
            if not a or not b:
                return
            D.line(g, X(a[0]), Y(a[1]), X(b[0]), Y(b[1]), alpha(acc, 0.72), 1.2, [4, 4])
            self.chip(g, X((a[0] + b[0]) / 2), Y((a[1] + b[1]) / 2), f"{self.name_of(o['a'])}{self.name_of(o['b'])} = {num(self.segment_len(o), 2)}", acc)
        elif t == "mangle":
            a, b, c = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b")), self.cur_of_id(o.get("c"))
            if not a or not b or not c:
                return
            col = alpha(acc, 0.6)
            D.line(g, X(a[0]), Y(a[1]), X(b[0]), Y(b[1]), col, 1.2, [4, 4])
            D.line(g, X(b[0]), Y(b[1]), X(c[0]), Y(c[1]), col, 1.2, [4, 4])
            a1 = math.atan2(Y(a[1]) - Y(b[1]), X(a[0]) - X(b[0]))
            a2 = math.atan2(Y(c[1]) - Y(b[1]), X(c[0]) - X(b[0]))
            r = 32
            g.stroke_style, g.line_width = col, 1.2
            g.begin_path()
            g.arc(X(b[0]), Y(b[1]), r, min(a1, a2), max(a1, a2))
            g.stroke()
            mid = (a1 + a2) / 2
            self.chip(g, X(b[0]) + math.cos(mid) * (r + 30), Y(b[1]) + math.sin(mid) * (r + 30),
                      f"∠{self.name_of(o['a'])}{self.name_of(o['b'])}{self.name_of(o['c'])} = {fmt_angle(self.angle_of(o))}", acc)
        elif t == "marea":
            poly = self.by_id(o.get("poly"))
            if not poly:
                return
            pts = self.poly_pts(poly)
            if len(pts) >= 3:
                c = self.centroid_of(pts)
                self.chip(g, X(c[0]), Y(c[1]), "S = " + num(self.polygon_area(poly), 2), acc)

    def draw_draft(self, g):
        d = self.draft
        acc = T.c2
        X, Y = self.X, self.Y
        if d:
            pts = [p for p in (self.cur_of_id(i) for i in d["ids"]) if p]
            cur = d.get("cursor")
            col = alpha(acc, 0.8)
            if pts and cur:
                if d["tool"] == "circle":
                    c = pts[0]
                    r = math.hypot(cur[0] - c[0], cur[1] - c[1]) * self.view["scale"]
                    g.dash, g.stroke_style, g.line_width = [5, 4], col, 1.4
                    g.begin_path()
                    g.arc(X(c[0]), Y(c[1]), r, 0, TAU)
                    g.stroke()
                    g.dash = []
                    D.line(g, X(c[0]), Y(c[1]), X(cur[0]), Y(cur[1]), col, 1.4, [5, 4])
                elif d["tool"] == "polygon":
                    seq = [(X(p[0]), Y(p[1])) for p in pts] + [(X(cur[0]), Y(cur[1]))]
                    for i in range(len(seq) - 1):
                        D.line(g, seq[i][0], seq[i][1], seq[i + 1][0], seq[i + 1][1], col, 1.4, [5, 4])
                    if len(pts) >= 3:
                        D.line(g, seq[-1][0], seq[-1][1], seq[0][0], seq[0][1], alpha(acc, 0.35), 1.4, [5, 4])
                else:
                    a = pts[-1]
                    D.line(g, X(a[0]), Y(a[1]), X(cur[0]), Y(cur[1]), col, 1.4, [5, 4])
                    if d["tool"] == "vector":
                        self._head(g, X(a[0]), Y(a[1]), X(cur[0]), Y(cur[1]), col, 9)
        for i in self.measure_picks:   # 测量拾取环
            p = self.cur_of_id(i)
            if p:
                D.circle(g, X(p[0]), Y(p[1]), 10, None, alpha(acc, 0.9), 2)

    def draw_snap(self, g):
        s = self.snap_info
        if not s:
            return
        col = alpha(T.c2, 0.85)
        sx, sy = self.X(s["x"]), self.Y(s["y"])
        if s.get("point"):
            D.circle(g, sx, sy, 11, None, col, 1.4)
        elif s.get("step"):
            D.line(g, sx - 6, sy, sx + 6, sy, col, 1.4)
            D.line(g, sx, sy - 6, sx, sy + 6, col, 1.4)
            D.circle(g, sx, sy, 3, None, alpha(T.c2, 0.35), 1.4)

    def draw_annotation(self, g, w, h):
        lt = self.current_transform()
        if not lt or not self.show_annotation or is_i(lt.get("matrix")):
            return
        acc = T.c2
        p = lt.get("params") or {}
        X, Y = self.X, self.Y
        ty = lt["type"]
        pv = p.get("pivot")
        if ty == "rotate" and pv:
            rad = p.get("rad")
            rad = math.radians(p.get("angle") or 0) if rad is None else rad
            r = 36
            px, py = X(pv[0]), Y(pv[1])
            col = alpha(acc, 0.55)
            D.line(g, px, py, px + r, py, col, 1.2, [4, 4])
            D.line(g, px, py, px + r * math.cos(rad), py - r * math.sin(rad), col, 1.2, [4, 4])
            g.stroke_style, g.line_width = alpha(acc, 0.85), 1.5
            g.begin_path()
            g.arc(px, py, r, 0, -rad, rad > 0)
            g.stroke()
            D.circle(g, px, py, 2.6, acc)
            mid = -rad / 2
            self.chip(g, px + math.cos(mid) * (r + 28), py + math.sin(mid) * (r + 28), f"θ = {num(abs(math.degrees(rad)), 1)}°", acc)
        elif ty == "scale" and pv:
            px, py = X(pv[0]), Y(pv[1])
            D.circle(g, px, py, 5, None, alpha(acc, 0.75), 1.3)
            D.circle(g, px, py, 2.2, acc)
            self.chip(g, px + 14, py - 18, f"k = {num(p.get('k'), 2)}", acc, "left")
        elif ty == "translate":
            b = self.selection_bounds()
            if b and is_num(p.get("dx")) and is_num(p.get("dy")):
                fx, fy = (b[0] + b[1]) / 2 - p["dx"], (b[2] + b[3]) / 2 - p["dy"]
                tx, ty2 = fx + p["dx"], fy + p["dy"]
                col = alpha(acc, 0.75)
                D.line(g, X(fx), Y(fy), X(tx), Y(ty2), col, 1.5, [5, 4])
                self._head(g, X(fx), Y(fy), X(tx), Y(ty2), col, 8)
                self.chip(g, X(tx), Y(ty2) - 18, f"({num(p['dx'], 1)}, {num(p['dy'], 1)})", acc)
        elif ty == "sym-point" and pv:
            px, py = X(pv[0]), Y(pv[1])
            col = alpha(acc, 0.8)
            D.circle(g, px, py, 6, None, col, 1.3)
            D.line(g, px - 9, py, px + 9, py, col, 1.3)
            D.line(g, px, py - 9, px, py + 9, col, 1.3)
        elif ty == "sym-line" and p.get("axis"):
            a, b = self.screen_of(p["axis"][0]), self.screen_of(p["axis"][1])
            seg = clip_line(a[0], a[1], b[0], b[1], w, h)
            if seg:
                self.chip(g, seg[0][0] + 40, seg[0][1] - 18, p.get("axisLabel") or "对称轴", acc, "left")

    def draw_handle_hint(self, g):
        h = self.handle
        if not h or h["phase"] != "wait":
            return
        acc = T.c2
        if h["kind"] == "translate":
            b = self.selection_bounds()
            center = ((b[0] + b[1]) / 2, (b[2] + b[3]) / 2) if b else None
        else:
            center = self.get_pivot()
        if not center:
            return
        sx, sy = self.X(center[0]), self.Y(center[1])
        if sx < -40 or sx > self.w + 40 or sy < -40 or sy > self.h + 40:
            return
        col = alpha(acc, 0.8)
        g.dash, g.stroke_style, g.line_width = [4, 4], col, 1.5
        g.begin_path()
        g.arc(sx, sy, 24 if h["kind"] == "translate" else 25, 0, TAU)
        g.stroke()
        g.dash = []
        if h["kind"] == "translate":
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                D.line(g, sx + dx * 24, sy + dy * 24, sx + dx * 31, sy + dy * 31, col, 1.5)
            self.chip(g, sx, sy - 38, "拖拽平移", acc)
        else:
            D.circle(g, sx + 25, sy, 4, col)
            self.chip(g, sx + 32, sy - 24, "拖拽旋转" if h["kind"] == "rotate" else "拖拽缩放", acc, "left")

    def draw_matrix_card(self, g, w, _h):
        lt = self.current_transform()
        if not self.show_annotation or not lt or is_i(lt.get("matrix")) or w < 620:
            return
        cw, ch = 196, 94
        x, y = w - self.B.safe()[2] - cw - 14, self.B.safe()[1] + 14
        D.rrect(g, x, y, cw, ch, 13, alpha(T.surface, 0.92), T.line, 1)
        D.text(g, "变换矩阵 · T", x + 12, y + 14, T.axis, size=9)
        D.text(g, truncate(lt.get("label") or "", 22), x + 12, y + 27, T.muted, size=10)
        for i, row in enumerate(matrix_rows(lt["matrix"])):
            D.text(g, row, x + 12, y + 46 + i * 15, T.fg, size=10.5, mono=True)

    def draw_scale_bar(self, g, w, h):
        if w < 340 or h < 220:
            return
        step = self.nice_step(self.view["scale"], 86)
        px = step * self.view["scale"]
        if px < 34 or px > w * 0.4:
            return
        x, y = self.B.safe()[0] + 16, h - 17
        col = alpha(T.muted, 0.6)
        D.line(g, x, y, x + px, y, col, 1.2)
        D.line(g, x, y - 4, x, y + 4, col, 1.2)
        D.line(g, x + px, y - 4, x + px, y + 4, col, 1.2)
        D.text(g, self.tick_text(step, step) + " 单位", x, y - 12, alpha(T.axis, 0.72), size=9.5)


def _unused():
    _ = invert_m
