"""各模块的「问 AI」入口：把当前内容交给这个控件所在窗口的 AI 聊天。

窗口（主窗口 Shell、学习窗口 NativeWindow）有 ask_ai(attachments, text) 就用它；都没有时用 HANDLER（外壳启动时设）。
"""
from __future__ import annotations

HANDLER = None


def ask(widget, attachments, text="") -> bool:
    win = widget.window() if widget is not None else None
    while win is not None:
        if hasattr(win, "ask_ai"):
            win.ask_ai(attachments, text)
            return True
        parent = win.parentWidget()
        win = parent.window() if parent is not None else None
    if HANDLER is not None:
        HANDLER(attachments, text)
        return True
    return False
