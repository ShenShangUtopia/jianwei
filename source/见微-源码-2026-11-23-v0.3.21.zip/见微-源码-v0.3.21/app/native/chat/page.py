"""AI 聊天页：左边历史对话，中间对话，下面附件条 + 输入框。

拖进来：文件（PDF、Word、PPT、图片、文本）、图片（截图、素材篮里的课件框选和实验台快照）、文字。
附件在发送时抽成文字交给 AI；有附件时出现「分析 / 讲解 / 出题 / 总结」一键提问。
AI 回答末尾的动作标记变成按钮（打开题目、加入复习、加入番茄计划、送去析题、导入成试卷、单词卡、背诗、读文）。
host：外壳给的跳转函数 dict（open_question、lab、exam、poem、read、snapshots）；没给的动作会提示去对应页面。
"""
from __future__ import annotations

import html
import threading
import time
from datetime import date

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QImage, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QFileDialog, QHBoxLayout, QListWidget, QListWidgetItem, QMenu, QPlainTextEdit,
                               QPushButton, QTextBrowser, QVBoxLayout, QWidget)

from ..design.tokens import T, css, qc
from ..design.widgets import FlowLayout, qss
from ..exam.page import _btn, _card, _label
from . import core


class _Bridge(QObject):
    partial = Signal(int, str)
    done = Signal(int, str, str)          # 票号, 回答, 错误


class ChatPage(QWidget):
    def __init__(self, compact=False, host=None):
        super().__init__()
        self.setObjectName("chatPage")
        self.compact = compact
        self.host = host or {}
        self.streamer = None          # 自测：fn(messages, on_text, cancel) -> str
        self.reader = None
        self.pending = []             # 还没发出去的附件
        self.busy = False
        self.ticket = 0
        self.cancel_flag = threading.Event()
        self.bridge = _Bridge()
        self.bridge.partial.connect(self._partial)
        self.bridge.done.connect(self._done)
        self.live = ""
        self._render_timer = QTimer(self, singleShot=True, interval=80, timeout=self.render)
        self.setAcceptDrops(True)
        h = QHBoxLayout(self)
        h.setContentsMargins(*((0, 0, 0, 0) if compact else (24, 18, 24, 18)))
        h.setSpacing(14)
        side, sv = _card()
        top = QHBoxLayout()
        top.addWidget(_label("对话", "cardTitle"))
        top.addStretch(1)
        top.addWidget(_btn("新对话", self.new_conv, "", "开一个新对话（Ctrl+N）"))
        sv.addLayout(top)
        self.list = QListWidget()
        self.list.currentRowChanged.connect(self._pick)
        sv.addWidget(self.list, 1)
        sv.addWidget(_btn("删除这个对话", self.delete_conv, "danger"))
        sv.addWidget(_label("对话只存在本机。", "note", True))
        side.setMaximumWidth(250)
        h.addWidget(side)
        main = QVBoxLayout()
        main.setSpacing(8)
        head = QHBoxLayout()
        self.title = _label("AI 聊天", "examTitle")
        head.addWidget(self.title)
        self.state = _label("", "examStatus")
        head.addWidget(self.state, 1)
        main.addLayout(head)
        self.view = QTextBrowser()
        self.view.setObjectName("chatView")
        self.view.setOpenLinks(False)
        main.addWidget(self.view, 1)
        self.act_box = QWidget()
        self.act_row = FlowLayout(self.act_box, 6)
        main.addWidget(self.act_box)
        self.att_box = QWidget()
        self.att_row = FlowLayout(self.att_box, 6)
        main.addWidget(self.att_box)
        self.quick_box = QWidget()
        qr = QHBoxLayout(self.quick_box)
        qr.setContentsMargins(0, 0, 0, 0)
        qr.addWidget(_label("一键：", "note"))
        for name, prompt in core.QUICK:
            qr.addWidget(_btn(name, lambda p=prompt: self.send(p), "", prompt))
        qr.addStretch(1)
        main.addWidget(self.quick_box)
        self.input = QPlainTextEdit()
        self.input.setObjectName("chatInput")
        self.input.setPlaceholderText("问点什么；文件、截图、题目、素材篮里的东西都可以直接拖进来。Ctrl+Enter 发送")
        self.input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.input.setMaximumHeight(110)
        main.addWidget(self.input)
        row = QHBoxLayout()
        self.k_attach = _btn("附上…", self.attach_menu, "", "文件、剪贴板、学习窗口里的页面快照")
        row.addWidget(self.k_attach)
        row.addStretch(1)
        self.k_stop = _btn("停止", self.stop)
        self.k_stop.hide()
        row.addWidget(self.k_stop)
        self.k_send = _btn("发送", lambda: self.send(), "pri", "Ctrl+Enter")
        row.addWidget(self.k_send)
        main.addLayout(row)
        h.addLayout(main, 1)
        QShortcut(QKeySequence("Ctrl+Return"), self, activated=lambda: self.send())
        QShortcut(QKeySequence("Ctrl+N"), self, activated=self.new_conv)
        self.apply_theme()
        self.conv = None
        self.fill_list()
        self.sync_ready()

    # ------------------------------------------------------------ 对话列表
    def fill_list(self, select=None):
        cs = core.convs()
        if not cs:
            cs = [core.new_conv()]
        self.list.blockSignals(True)
        self.list.clear()
        for c in cs:
            it = QListWidgetItem(c["title"])
            it.setData(Qt.ItemDataRole.UserRole, c["id"])
            self.list.addItem(it)
        self.list.blockSignals(False)
        ids = [c["id"] for c in cs]
        row = ids.index(select) if select in ids else 0
        self.list.setCurrentRow(row)
        self._pick(row)

    def _pick(self, row):
        it = self.list.item(row)
        if it is None:
            return
        self.conv = core.get(it.data(Qt.ItemDataRole.UserRole))
        self.live = ""
        self.render()

    def new_conv(self):
        if self.conv and not self.conv["messages"]:
            return
        c = core.new_conv()
        self.fill_list(c["id"])

    def delete_conv(self):
        if self.conv:
            core.delete_conv(self.conv["id"])
            self.conv = None
            self.fill_list()

    def sync_ready(self):
        ok, note = core.ready()
        if self.streamer is not None:
            ok, note = True, "测试引擎"
        self.ai_ok = ok
        self.state.setText(("● " if ok else "○ ") + note)
        self.state.setStyleSheet(f"color:{css(T.ok if ok else T.muted)};font-size:12px;")
        self.state.setToolTip(note)
        self.state.setWordWrap(True)

    # ------------------------------------------------------------ 显示
    def render(self):
        c = self.conv or dict(messages=[])
        colors = dict(code=css(T.fg, 0.07))
        parts = []
        if not c["messages"] and not self.live:
            parts.append(f"<p style='color:{css(T.muted)};line-height:170%'>可以直接问题目、概念、作文思路、英语语法……<br>"
                         "把 PDF、Word、PPT、图片、截图拖进来，再点「分析 / 讲解 / 出题 / 总结」。<br>"
                         "回答里会带按钮：打开题目、加入复习、排进番茄计划、送去析题、导入成试卷、做单词卡、去背诗、送读文。</p>")
        for m in c["messages"]:
            parts.append(self._bubble(m["role"], m["content"], m.get("attachments"), colors))
        if self.live:
            parts.append(self._bubble("assistant", self.live + " …", None, colors))
        self.view.setHtml(f"<div style='font-size:14px;color:{css(T.fg)}'>{''.join(parts)}</div>")
        sb = self.view.verticalScrollBar()
        sb.setValue(sb.maximum())
        self.render_actions()

    def _bubble(self, role, content, atts, colors):
        if role == "user":
            chips = "".join(f"<span style='color:{qc(T.accent).name()}'>[附件：{html.escape(a.get('name', ''))}]</span>&nbsp; "
                            for a in atts or [])
            # Qt 富文本对 rgba 底色的单元格会画成一条条横带：用 bgcolor + 不透明色
            return (f"<table width='100%' cellspacing='0' cellpadding='10' style='margin:8px 0'><tr><td width='18%'></td>"
                    f"<td bgcolor='{qc(T.raised).name()}' style='border-left:3px solid {qc(T.accent).name()}'>"
                    f"<p style='margin:0 0 4px 0;color:{css(T.muted)};font-size:11px'>我</p>{chips}"
                    f"<p style='margin:2px 0;line-height:160%'>{html.escape(content).replace(chr(10), '<br>')}</p></td></tr></table>")
        return (f"<table width='100%' cellspacing='0' cellpadding='10' style='margin:8px 0'><tr><td bgcolor='{qc(T.stage).name()}'>"
                f"<p style='margin:0 0 4px 0;color:{css(T.muted)};font-size:11px'>AI</p>{core.to_html(content, colors)}</td>"
                f"<td width='10%'></td></tr></table>")

    def _clear(self, lay):
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

    def render_actions(self):
        self._clear(self.act_row)
        last = next((m for m in reversed((self.conv or {}).get("messages", [])) if m["role"] == "assistant"), None)
        acts = core.parse_actions(last["content"]) if last and not self.live else []
        self.actions = acts
        for a in acts:
            b = QPushButton(a["label"])
            b.setToolTip("、".join(a["args"])[:200])
            b.clicked.connect(lambda _c=False, a=a: self.run_action(a))
            self.act_row.addWidget(b)
        self.act_box.setVisible(bool(acts))
        self._clear(self.att_row)
        for i, a in enumerate(self.pending):
            b = QPushButton(f"{a.get('name', '附件')[:20]}  移除")
            b.setObjectName("ghost")
            b.setToolTip((a.get("how", "") + "：" if a.get("how") else "") + (a.get("text", "")[:300] or "没有取到文字"))
            b.clicked.connect(lambda _c=False, i=i: self.remove_attachment(i))
            self.att_row.addWidget(b)
        self.att_box.setVisible(bool(self.pending))
        self.quick_box.setVisible(bool(self.pending))

    # ------------------------------------------------------------ 附件
    def add_attachment(self, a):
        self.pending.append(a)
        self.render_actions()
        self.set_note(f"附上了「{a.get('name', '')}」" + ("" if a.get("text") else "（没有取到文字）"))

    def remove_attachment(self, i):
        if 0 <= i < len(self.pending):
            self.pending.pop(i)
            self.render_actions()

    def set_note(self, text):
        self.state.setText(text)
        self.state.setStyleSheet(f"color:{css(T.muted)};font-size:12px;")

    def attach_file(self, path):
        try:
            self.add_attachment(core.file_attachment(path, reader=self.reader))
        except Exception as exc:  # noqa: BLE001
            self.set_note(f"读不了 {path}：{exc}")

    def attach_image(self, image, name="截图"):
        if image is None or image.isNull():
            return
        self.add_attachment(core.image_attachment(image, name, reader=self.reader))

    def attach_menu(self):
        m = QMenu(self)
        m.addAction("文件…", self._pick_file)
        m.addAction("剪贴板里的内容", self.paste_clipboard)
        snaps = self.host.get("snapshots")
        for name, grab in (snaps() if snaps else []):
            m.addAction(f"快照：{name}", lambda g=grab, n=name: self.attach_image(g(), f"{n}快照"))
        m.exec(self.k_attach.mapToGlobal(self.k_attach.rect().topLeft()))

    def _pick_file(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "附上文件", "", "文档与图片 (*.pdf *.docx *.pptx *.png *.jpg *.jpeg *.bmp *.txt *.md *.csv);;全部文件 (*)")
        for p in paths:
            self.attach_file(p)

    def paste_clipboard(self):
        self.drop_mime(QApplication.clipboard().mimeData())

    def drop_mime(self, mime):
        if mime is None:
            return False
        if mime.hasUrls() and any(u.isLocalFile() for u in mime.urls()):
            for u in mime.urls():
                if u.isLocalFile():
                    self.attach_file(u.toLocalFile())
            return True
        if mime.hasImage():
            img = QImage(mime.imageData())
            text = mime.text().strip() if mime.hasText() else ""
            if text:            # 素材篮里的课件框选：有字就直接用字，省一次识图
                self.add_attachment(core.text_attachment(text, "素材"))
            else:
                self.attach_image(img, "图片")
            return True
        if mime.hasText() and mime.text().strip():
            self.add_attachment(core.text_attachment(mime.text()))
            return True
        return False

    def dragEnterEvent(self, e):  # noqa: N802
        md = e.mimeData()
        if md.hasUrls() or md.hasImage() or md.hasText():
            e.acceptProposedAction()

    def dropEvent(self, e):  # noqa: N802
        if self.drop_mime(e.mimeData()):
            e.acceptProposedAction()

    def receive(self, attachments, text=""):
        """别的模块「问 AI」送进来的：附件放进附件条，文字放进输入框。"""
        for a in attachments or []:
            self.add_attachment(a)
        if text:
            self.input.setPlainText(text)

    # ------------------------------------------------------------ 发送
    def send(self, text=None):
        if self.busy:
            return
        text = (self.input.toPlainText() if text is None else text).strip()
        if not text and not self.pending:
            return
        if self.conv is None:
            self.conv = core.new_conv()
        msg = dict(role="user", content=text or "请看附件。", attachments=list(self.pending), t=time.time())
        self.conv["messages"].append(msg)
        if self.conv["title"] == "新对话":
            self.conv["title"] = core.auto_title(text or (self.pending[0].get("name") if self.pending else ""))
        self.conv["updated"] = time.time()
        core.save_conv(self.conv)
        self.pending = []
        self.input.clear()
        self.fill_list(self.conv["id"])
        self.sync_ready()
        if text and not msg["attachments"] and core.wants_plan(text):
            # 「帮我排下周计划」：走 AI 排计划（本机汇总学情 → 草稿 → 预览确认），不当普通聊天发出去
            self.conv["messages"].append(dict(role="assistant", t=time.time(), offline=True,
                                              content="排计划交给「AI 排计划」：它会先在本机汇总你的考情、背诵、专注记录和目标，"
                                                      "排出一周草稿和学情诊断；你在预览里改好、确认后才会写进计划。\n"
                                                      f"[[动作:aiplan|{text[:60]}]]"))
            core.save_conv(self.conv)
            self.render()
            self.run_action(dict(kind="aiplan", args=[text[:60]], label="AI 排计划"))
            return
        if not self.ai_ok:
            note = core.ready()[1]
            self.conv["messages"].append(dict(role="assistant", content="（没有发出去）" + note, t=time.time(), offline=True))
            core.save_conv(self.conv)
            self.render()
            return
        self.busy = True
        self.sending_id = self.conv["id"]       # 回答回来时可能已经切到别的对话：记到发问的那个对话里
        self.ticket += 1
        tk = self.ticket
        self.cancel_flag = threading.Event()
        cancel = self.cancel_flag
        msgs = core.api_messages(self.conv)
        streamer = self.streamer or core.stream
        self.k_send.hide()
        self.k_stop.show()
        self.live = ""
        self.render()
        bridge = self.bridge

        def work():
            try:
                ans = streamer(msgs, lambda t: bridge.partial.emit(tk, t), cancel.is_set)
                err = ""
            except Exception as exc:  # noqa: BLE001  错误信息里不会带密钥（llm 只回状态码和服务端说明）
                ans, err = "", str(exc) or type(exc).__name__
            try:
                bridge.done.emit(tk, ans or "", err)
            except RuntimeError:
                pass
        if getattr(self, "sync", False):
            work()
        else:
            threading.Thread(target=work, daemon=True).start()

    def _partial(self, tk, text):
        if tk == self.ticket and self.busy:
            self.live = text
            if not self._render_timer.isActive():
                self._render_timer.start()

    def _done(self, tk, ans, err):
        if tk != self.ticket:
            return
        self.busy = False
        self.live = ""
        self.k_stop.hide()
        self.k_send.show()
        conv = core.get(self.sending_id) or self.conv
        if err:
            conv["messages"].append(dict(role="assistant", content=f"（出错了）{err}", t=time.time(), offline=True))
        else:
            conv["messages"].append(dict(role="assistant", content=ans + ("\n\n（已停止）" if self.cancel_flag.is_set() else ""), t=time.time()))
        conv["updated"] = time.time()
        core.save_conv(conv)
        self.fill_list(conv["id"])

    def stop(self):
        self.cancel_flag.set()

    # ------------------------------------------------------------ 动作
    def run_action(self, a):
        k, args = a["kind"], a["args"]
        last_atts = next((m.get("attachments") for m in reversed(self.conv["messages"]) if m["role"] == "user" and m.get("attachments")), []) or []
        att_text = "\n".join(x.get("text", "") for x in last_atts)
        try:
            if k == "review":
                from .. import learning
                learning.add_card(dict(src="chat", n=args[0] if args else "知识点", d=args[1] if len(args) > 1 else "", f=[], p=[]), "")
                self.set_note(f"「{args[0] if args else '知识点'}」已加入复习")
            elif k == "plan":
                from ..focus import plan
                minutes = int(args[2]) if len(args) > 2 and args[2].strip().isdigit() else 30
                d = date.today().isoformat()
                b = plan.add(d, plan.next_free(d, minutes), minutes, args[0] if args else "", args[1] if len(args) > 1 else "", "self")
                self.set_note(f"已排进今天 {plan.hhmm(b['start'])} 的番茄计划")
            elif k == "aiplan":
                from ..focus.aiplan_page import open_dialog
                self.aiplan_dlg = open_dialog(self.window(), args[0] if args else "")
                self.set_note("已打开「AI 排计划」：生成后在预览里确认才会写进计划")
            elif k == "word":
                from ..recite import core as rc
                rc.add_word(args[0], args[1] if len(args) > 1 else "")
                self.set_note(f"单词卡「{args[0]}」已加入复习")
            else:
                fn = self.host.get({"open_question": "open_question", "lab": "lab", "exam": "exam", "poem": "poem", "read": "read"}[k])
                payload = args[0] if args else ""
                if k == "exam" and not payload:
                    payload = att_text
                if k in ("lab", "read") and not payload:
                    payload = att_text
                if fn is None:
                    self.set_note("这个动作要在学习窗口或主窗口里用")
                    return
                fn(payload)
                self.set_note(core.ACTIONS[k] + "：已打开")
        except Exception as exc:  # noqa: BLE001
            self.set_note(f"没做成：{exc}")

    # ------------------------------------------------------------ 外观
    def apply_theme(self):
        self.setStyleSheet(qss() + f"""
QWidget#chatPage {{ background:{"transparent" if self.compact else T.bg}; color:{T.fg}; }}
QLabel#examTitle {{ color:{T.fg}; font-size:20px; font-weight:700; padding-right:6px; }}
QFrame#examCard {{ background:{T.surface}; border:1px solid {T.line}; border-radius:10px; }}
QLabel#cardTitle {{ color:{T.fg}; font-size:14px; font-weight:700; }}
QTextBrowser#chatView {{ background:{T.surface}; color:{T.fg}; border:1px solid {T.line}; border-radius:10px; padding:6px 10px; }}
QPlainTextEdit#chatInput {{ font-size:14px; }}
QListWidget::item:selected {{ background:{css(T.accent, .14)}; }}
""")
        self.title.setVisible(not self.compact)
        if hasattr(self, "conv"):
            self.render()
