"""AI 聊天的离屏自测：附件抽字（PDF / Word / PPT / 图片 / 文本）、拖入、一键提问、假引擎流式回答、历史保存、
公式渲染、动作按钮联动（复习、番茄计划、单词卡、打开题目、析题、导入试卷、背诗、读文）、没密钥的提示、
各模块「问 AI」入口、学习窗口和主窗口（三种布局 × 三种风格）。不联网。"""
from ..kit import test_runtime
test_runtime.configure()
import sys
import time
import zipfile
from pathlib import Path


class FakeReader:
    def __init__(self, text):
        self.text = text

    def available(self):
        return True

    def read(self, image, hint="", cancel=lambda: False, refresh=False):
        return dict(text=self.text, query="", uncertainty="")


class FakeStreamer:
    """按顺序回答；记下收到的 messages。"""

    def __init__(self, answers):
        self.answers, self.seen = list(answers), []

    def __call__(self, messages, on_text, cancel):
        self.seen.append(messages)
        ans = self.answers.pop(0) if self.answers else "好的。"
        for i in range(1, len(ans) + 1, max(1, len(ans) // 4)):
            on_text(ans[:i])
        return ans


def _pptx(path, slides):
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        for i, s in enumerate(slides, 1):
            z.writestr(f"ppt/slides/slide{i}.xml", "<p:sld xmlns:a='a' xmlns:p='p'><a:t>" + "</a:t><a:t>".join(s) + "</a:t></p:sld>")


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    fails, log = [], []

    def check(name, ok, detail=""):
        log.append(("OK  " if ok else "FAIL") + " " + name + ("" if ok else f"  {detail}"))
        if not ok:
            fails.append(name)

    def spin(sec=0.05):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from . import core

    # ------------------------------------------------ 规则
    t = "先求导。\n[[动作:review|导数的几何意义|切线斜率]]\n[[动作:plan|数学|导数练习|40]]\n[[动作:bad|x]]"
    acts = core.parse_actions(t)
    check("解析动作标记（不认识的丢掉）", [a["kind"] for a in acts] == ["review", "plan"] and acts[1]["args"] == ["数学", "导数练习", "40"], acts)
    check("显示时去掉动作标记", "[[" not in core.strip_actions(t) and core.strip_actions(t).startswith("先求导"))
    h = core.to_html("## 解答\n**关键**：$\\frac{1}{2}x^2$ 的导数\n- 第一步\n```\ncode\n```")
    check("渲染：标题、粗体、列表、代码、公式上下标", "<b>关键</b>" in h and "<sup>1</sup>" in h and "<sup>2</sup>" in h
          and "· 第一步" in h and "<pre" in h and "font-weight:700" in h, h[:300])
    ok, note = core.ready()
    check("自测里不联网，并说明原因", not ok and note)
    _pptx(out / "deck.pptx", [["牛顿第一定律", "惯性"], ["F=ma"]])
    a = core.file_attachment(out / "deck.pptx")
    check("PPT 抽字（按页）", "【第 1 页】牛顿第一定律 惯性" in a["text"] and "【第 2 页】F=ma" in a["text"], a["text"])
    (out / "note.txt").write_text("动量守恒的条件是系统不受外力或合外力为零。", encoding="utf-8")
    check("文本附件", "动量守恒" in core.file_attachment(out / "note.txt")["text"])
    from ..exam import selftest as ex_st
    ex_st._docx(out / "w.docx", ["1. 已知 x+1=2，求 x。", "参考答案", "1. 1"])
    check("Word 附件", "x+1=2" in core.file_attachment(out / "w.docx")["text"])
    ex_st._pdf(out / "p.pdf", ["细胞膜的主要成分是脂质和蛋白质。"])
    check("PDF 附件（文字层）", "细胞膜" in core.file_attachment(out / "p.pdf")["text"])
    from PySide6.QtGui import QImage
    im = QImage(300, 120, QImage.Format.Format_RGB32)
    im.fill(0xFFFFFF)
    im.save(str(out / "shot.png"))
    ia = core.file_attachment(out / "shot.png", reader=FakeReader("截图里的题：求 sin30°"))
    check("图片附件走识图", ia["kind"] == "image" and "sin30" in ia["text"])
    try:
        core.file_attachment(out / "old.ppt")
        check("旧版 .ppt 提示另存", False)
    except ValueError as e:
        check("旧版 .ppt 提示另存", ".pptx" in str(e))
    from ..bank.data import bank
    bank.load()
    q0 = next(q for q in bank.questions if q.get("subject") == "物理")
    qa = core.question_attachment(q0)
    check("题目附件带 id、题干、答案", q0["id"] in qa["text"] and q0["stem"][:10] in qa["text"])
    conv = dict(messages=[dict(role="user", content="问", attachments=[qa]), dict(role="assistant", content="答[[动作:review|x]]"),
                          dict(role="assistant", content="（没有发出去）", offline=True)])
    msgs = core.api_messages(conv)
    check("发给 AI：附件拼进用户消息、动作标记去掉、没发出去的提示不发", len(msgs) == 2 and "<附件" in msgs[0]["content"] and msgs[1]["content"] == "答")

    # ------------------------------------------------ 聊天页
    from .page import ChatPage
    calls = {}

    def host_fn(name):
        return lambda arg: calls.setdefault(name, []).append(arg)
    host = {k: host_fn(k) for k in ("open_question", "lab", "exam", "poem", "read")}
    host["snapshots"] = lambda: [("实验台", lambda: im)]
    page = ChatPage(host=host)
    page.resize(1180, 780)
    page.show()
    spin()
    page.sync = True
    page.send("导数是什么？")
    check("没有密钥：不发出去，提示去设置", page.conv["messages"][-1].get("offline") and "设置" in page.conv["messages"][-1]["content"]
          and "自测" not in page.state.text() or "设置" in page.conv["messages"][-1]["content"] or "自测" in page.conv["messages"][-1]["content"],
          page.conv["messages"][-1])
    fake = FakeStreamer(["**导数**是函数的变化率，例如 $x^2$ 的导数是 $2x$。\n[[动作:review|导数的定义|瞬时变化率]]\n[[动作:plan|数学|导数基础题|30]]\n[[动作:word|derivative|n. 导数]]",
                         "这道题考动量守恒。\n[[动作:open_question|" + q0["id"] + "]]\n[[动作:lab]]",
                         "这份卷子共 2 题。\n[[动作:exam]]\n[[动作:poem|登高]]\n[[动作:read|人非生而知之者]]"])
    page.streamer = fake
    page.sync_ready()
    page.new_conv()
    page.input.setPlainText("导数是什么？")
    page.send()
    spin(0.2)
    last = page.conv["messages"][-1]
    check("流式回答完整保存", last["role"] == "assistant" and "变化率" in last["content"] and not page.busy)
    check("对话标题自动取第一句", page.conv["title"].startswith("导数是什么"))
    check("回答渲染公式和粗体", "<sup>2</sup>" in page.view.toHtml() or "x²" in page.view.toPlainText() or "2" in page.view.toPlainText())
    check("回答带动作按钮", [a["kind"] for a in page.actions] == ["review", "plan", "word"] and page.act_box.isVisible())
    from .. import learning
    for a in page.actions:
        page.run_action(a)
    due = [it["title"] for _k, it in learning.due()]
    from ..focus import plan
    from datetime import date
    check("动作：加入复习", "导数的定义" in due)
    check("动作：排进今天的番茄计划", any(b["task"] == "导数基础题" and b["minutes"] == 30 for b in plan.blocks(date.today().isoformat())))
    from ..recite import core as rc
    check("动作：生成单词卡", rc.find("derivative") and "derivative" in due)
    # 拖入：文件、图片、文字；一键提问
    from PySide6.QtCore import QMimeData, QUrl
    md = QMimeData()
    md.setUrls([QUrl.fromLocalFile(str(out / "note.txt"))])
    page.drop_mime(md)
    md2 = QMimeData()
    md2.setImageData(im)
    page.reader = FakeReader("图上：一个滑块在光滑水平面上")
    page.drop_mime(md2)
    md3 = QMimeData()
    md3.setText("补充：两物体质量相等")
    page.drop_mime(md3)
    check("拖入文件、图片、文字都成附件", [x["kind"] for x in page.pending] == ["file", "image", "text"] and page.quick_box.isVisible())
    page.remove_attachment(2)
    page.receive([qa], "")
    page.grab().save(str(out / "chat-attach.png"))
    page.send(core.QUICK[1][1])
    sent = fake.seen[-1][-1]["content"]
    check("一键「讲解」：附件文字一起发出", "动量守恒的条件" in sent and "光滑水平面" in sent and q0["stem"][:8] in sent and "讲解" in sent)
    check("发出后附件条清空", not page.pending and not page.att_box.isVisible())
    for a in page.actions:
        page.run_action(a)
    check("动作：打开题目（题库 id）", calls.get("open_question") == [q0["id"]])
    check("动作：送去析题（没写题目就用附件）", calls.get("lab") and "动量守恒" in calls["lab"][-1])
    ex_text = "1. 1+1=?\nA. 1 B. 2 C. 3 D. 4\n2. 2+2=______\n参考答案\n1. B\n2. 4"
    page.receive([core.text_attachment(ex_text, "卷子")])
    page.send("这是什么卷子")
    for a in page.actions:
        page.run_action(a)
    check("动作：导入成试卷（用附件文字）", calls.get("exam") and "参考答案" in calls["exam"][-1])
    check("动作：去背诗、送读文", calls.get("poem") == ["登高"] and calls.get("read") == ["人非生而知之者"])
    # 历史
    cid = page.conv["id"]
    saved = core.get(cid)
    check("对话存在本机历史里（含附件）", saved and len(saved["messages"]) == 6 and saved["messages"][2]["attachments"])
    page.new_conv()
    page.fill_list(cid)
    check("切回历史对话", page.conv["id"] == cid and "导入成试卷" in "".join(a["label"] for a in page.actions))
    # 停止
    def slow(messages, on_text, cancel):
        on_text("一半")
        page.stop()
        return "一半"
    page.streamer = slow
    page.send("长一点")
    check("停止：保留已经回答的部分", page.conv["messages"][-1]["content"].endswith("（已停止）"))
    page.streamer = lambda m, o, c: (_ for _ in ()).throw(RuntimeError("服务端 500"))
    page.send("会出错")
    check("出错时写清楚，不卡住", "出错了" in page.conv["messages"][-1]["content"] and not page.busy and page.k_send.isVisible())
    page.streamer = fake
    snaps = host["snapshots"]()
    page.attach_image(snaps[0][1](), "实验台快照")
    check("学习窗口页面快照可以附上", page.pending and page.pending[-1]["name"] == "实验台快照")
    page.pending = []
    page.delete_conv()
    check("删除对话", core.get(cid) is None)
    from ..design import tokens
    page.fill_list(core.convs()[0]["id"])
    page.grab().save(str(out / "chat.png"))
    tokens.set_theme("night")
    page.apply_theme()
    page.grab().save(str(out / "chat-night.png"))
    tokens.set_theme("day")
    page.apply_theme()
    page.close()

    # ------------------------------------------------ 学习窗口：问 AI 模式、各模块入口、host
    from ..main_win import MODE_KEYS, MODES, NativeWindow
    check("学习窗口有「问AI」（Ctrl+0）", ("chat", "问AI") in MODES and MODE_KEYS["chat"] == 0)
    nw = NativeWindow("day")
    nw.resize(1100, 640)
    nw.show()
    spin()
    check("窄栏在最小高度放得下", nw.rail.minimumSizeHint().height() <= 620, nw.rail.minimumSizeHint().height())
    desk = nw.goto("desk", q0["id"])
    spin()
    desk.ask_ai()
    spin()
    cp = nw.pages.get("chat")
    check("习题台「问 AI」：切到问 AI、带上这道题", nw.mode == "chat" and cp.pending and cp.pending[-1]["kind"] == "question"
          and cp.pending[-1]["ref"] == q0["id"])
    cp.pending = []
    rec = nw.goto("recite")
    rec.show_tab("poems")
    rec.ask_ai()
    check("背诵「问 AI」带上这篇", nw.mode == "chat" and cp.pending and rec.poem["title"] in cp.pending[-1]["name"] and cp.input.toPlainText())
    cp.pending = []
    rd = nw.goto("reading")
    rd.set_text("学而不思则罔，思而不学则殆。", "wyw")
    rd.ask_ai()
    check("读文「问 AI」带上原文", nw.mode == "chat" and "学而不思" in cp.pending[-1]["text"])
    cp.pending = []
    h2 = nw.chat_host()
    h2["exam"](ex_text)
    check("学习窗口：导入成试卷打开考试核对", nw.mode == "exam" and nw.pages["exam"].stack.currentWidget() is nw.pages["exam"].v_setup)
    h2["poem"]("登高")
    check("学习窗口：去背诗", nw.mode == "recite" and nw.pages["recite"].poem["title"] == "登高")
    h2["read"]("人非生而知之者")
    check("学习窗口：送读文", nw.mode == "reading")
    check("学习窗口：页面快照列表", any(n == "习题台" for n, _g in h2["snapshots"]()))
    h2["open_question"](q0["id"])
    check("学习窗口：打开题目", nw.mode == "desk")
    ep = nw.pages["exam"]
    ep.start()
    ep.grader = lambda exm, ims: (__import__("native.exam.grade", fromlist=["x"]).offline(exm), "离线")
    ep.grader.sync = True
    ep.submit()
    ep.ask_ai()
    check("考试报告「问 AI」带上错题", nw.mode == "chat" and "错题" in cp.pending[-1]["name"])
    nw.goto("chat").grab().save(str(out / "native-chat.png"))
    nw.shutdown()
    nw.close()

    # ------------------------------------------------ 主窗口
    try:
        import os
        import store
        from shell import NAV, Shell
        real = Path.home() / "AppData" / "Local" / "Jianwei"
        if not os.environ.get("JIANWEI_HOME") or os.path.realpath(store.HOME) == os.path.realpath(real):
            raise RuntimeError("JIANWEI_HOME 没有指向隔离目录，不建主窗口")
        check("主窗口导航有「问 AI」", ("chat", "问 AI") in NAV)
        cfg = store.load_config()
        cfg.update(autoFetch=False, autoEvening=False, prewarmWeb=False)
        store.save_config(cfg)
        sh = Shell(tray_enabled=False, jobs_enabled=False)
        sh.resize(1280, 820)
        sh.show()
        spin()
        for skin in ("ink", "celadon", "doodle"):
            sh._apply_look("day", skin)
            for lay in ("pages", "desktop", "workspace"):
                sh.set_page_layout(lay)
                spin()
                if lay == "desktop":
                    check(f"{skin}·模块桌面有问 AI 模块", "chat" in sh.home.modules)
                elif lay == "workspace":
                    sh.home.add("chat")
                    spin()
                    check(f"{skin}·工作台能加问 AI 模块", "chat" in sh.home.panels)
                sh.goto("chat", animate=False)
                spin()
                cur = sh.stack.currentWidget()
                check(f"{skin}·{lay} 打开问 AI 页", getattr(cur, "chat", None) is not None and cur.chat.isVisible())
                if skin == "doodle" and lay == "pages":
                    sh.grab().save(str(out / "shell-chat.png"))
        for mode in ("side", "top", "compact"):
            sh.set_page_layout("pages")
            sh.set_layout(mode)
            spin()
            sh.goto("chat", animate=False)
            spin()
            check(f"导航位置 {mode} 打开问 AI 页", getattr(sh.stack.currentWidget(), "chat", None) is not None)
            if mode == "top":
                btns = [b for b in sh.nav_buttons if b.property("navKey") != "settings"]
                right = max(b.mapTo(sh, b.rect().topRight()).x() for b in btns)
                sett = next(b for b in sh.nav_buttons if b.property("navKey") == "settings")
                check("顶栏导航 1280 宽放得下（不压到设置）", all(b.isVisible() for b in btns) and right < sett.mapTo(sh, sett.rect().topLeft()).x(),
                      (right, sett.mapTo(sh, sett.rect().topLeft()).x()))
                sh.grab().save(str(out / "shell-top.png"))
        sh.set_page_layout("pages")
        sh.set_layout("side")
        sh.goto("reading", animate=False)
        spin()
        rp = sh.stack.currentWidget().reading
        rp.set_text("The early bird catches the worm.", "en")
        rp.ask_ai()
        spin()
        check("主窗口读文「问 AI」：切到问 AI 页、带上原文", sh.tab == "chat" and "early bird" in sh.stack.currentWidget().chat.pending[-1]["text"])
        sh._tray = None
        sh._build_tray()
        check("托盘菜单有「问 AI」", "问 AI" in [a.text() for a in sh._tray.contextMenu().actions()])
        sh._tray.hide()
        from . import bridge
        check("外壳登记了「问 AI」的兜底入口", bridge.HANDLER is not None)
        sh._apply_look("day", "ink")
        sh.close()
        sh.deleteLater()
    except Exception:  # noqa: BLE001
        import traceback
        check("主窗口入口", False, traceback.format_exc()[-800:])

    (out / "chat-log.txt").write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))
    print("CHAT_FAIL" if fails else "CHAT_OK", len(log), "项")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
