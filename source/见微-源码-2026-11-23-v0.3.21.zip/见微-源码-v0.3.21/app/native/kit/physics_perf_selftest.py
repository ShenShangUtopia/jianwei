"""0.3.11：物理台静止时不重画、力学轨迹底图缓存（ROADMAP §3）。

python -m native.kit.physics_perf_selftest <目录>（在 src2/app 下，隔离 JIANWEI_HOME / LOCALAPPDATA）
离屏跑：耗时只比相对大小，阈值放得比目标（一帧 ≤ 6 ms）宽。
"""
import os
import statistics
import sys
import time
from pathlib import Path

from . import test_runtime

test_runtime.configure()


def main(output=None):
    app = test_runtime.application()
    from . import ctx as kctx
    from ..lab.studio import Studio
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    checks, failures = [], []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        (checks if ok else failures).append(name)

    def spin(t):
        end = time.perf_counter() + t
        while time.perf_counter() < end:
            app.processEvents()
            time.sleep(0.002)

    real_idle = kctx.idle_seconds
    kctx.idle_seconds = lambda: 999.0       # 当作「很久没人碰」，不受这台机器上真实鼠标的影响
    try:
        with test_runtime.isolated_data(out / "data"):
            st = Studio("day")
            st.resize(1500, 900)
            st.show()
            spin(0.4)
            cnt = [0]

            def count_on(bid):
                st.open_bench(bid)
                spin(0.5)
                # 数工作台自己要求的重画（L.draw），不数窗口别处引起的重绘（离屏首启动的过渡动画也会重绘子控件）
                real_draw = type(st.ctx).draw.__get__(st.ctx)
                st.ctx.draw = lambda: (cnt.__setitem__(0, cnt[0] + 1), real_draw())[1]
                cnt[0] = 0

            # ---- 力学台：暂停时不画，poke 后画，播放时每帧画
            count_on("phys")
            B = st.B
            btn = lambda name: next(c for c in st.ctx.ctrls if c["kind"] == "button" and c["name"] == name)
            names = [c["name"] for c in st.ctx.ctrls if c["kind"] == "button"]
            if "暂停" in names:
                btn("暂停")["press"]()
            spin(0.3)
            cnt[0] = 0
            spin(1.0)
            check("力学台暂停、没人碰：基本不重画", cnt[0] <= 3, cnt[0])
            st.ctx.poke()
            cnt[0] = 0
            spin(0.4)
            check("poke 之后照常重画", cnt[0] >= 8, cnt[0])
            kctx_real = kctx.idle_seconds
            kctx.idle_seconds = lambda: 0.1
            cnt[0] = 0
            spin(0.4)
            check("刚有输入时照常重画", cnt[0] >= 8, cnt[0])
            kctx.idle_seconds = kctx_real

            # 0.3.14：题目导入、互通这类按名称调控件的路径（没有键鼠输入）也要重画
            spin(1.0)
            cnt[0] = 0
            names = [c["name"] for c in st.ctx.ctrls]
            for nm in ("重置", "清除轨迹"):
                c = next((c for c in st.ctx.ctrls if c["name"] == nm and c.get("press")), None)
                if c:
                    c["press"]()
            spin(0.3)
            check("按名称按「重置」「清除轨迹」后重画（不靠键鼠输入）", cnt[0] >= 3, (cnt[0], [n for n in names if n in ("重置", "清除轨迹")]))

            # 10 个物体 + 电场 + 磁场，播放
            it = lambda label: next(i.it for i in B.pal.all if i.it.get("label") == label)
            it("空白场景")["click"]()
            spin(0.2)
            for i in range(10):
                it("带正电小球" if i % 2 else "小球")["drop"](200 + i * 90, 300 + (i % 3) * 60)
            it("匀强电场")["click"]()
            it("匀强磁场 ⊙")["click"]()
            spin(0.2)
            loop = next(t for t in st.ctx.timers if isinstance(t, kctx.Loop))
            loop.pause()
            btn("播放")["press"]()
            stage = st.ctx.stage
            for _ in range(60):
                loop.fn(1 / 60)
            ts = []
            for _ in range(600):
                loop.fn(1 / 60)
                t = time.perf_counter()
                stage.repaint()
                ts.append((time.perf_counter() - t) * 1000)
            ts.sort()
            med, p90 = statistics.median(ts), ts[int(len(ts) * 0.9)]
            check("10 个物体加场跑 10 秒：一帧中位数 ≤ 6 ms", med <= 6.0, f"median {med:.2f} p90 {p90:.2f}")
            (out / "physics-perf.txt").write_text(f"median {med:.2f} ms, p90 {p90:.2f} ms, max {ts[-1]:.2f} ms\n", encoding="utf-8")

            # 轨迹底图缓存：增量画出来的和整张重做的一样
            TR = B.mech_trails
            check("轨迹底图建好了", TR["pm"] is not None and TR["mark"])
            a = stage.grab().toImage()
            TR["key"] = None
            b = stage.grab().toImage()
            diff = _diff(a, b)
            check("增量画的轨迹和整张重画一致（差异像素 < 0.5%）", diff < 0.005, f"{diff:.4%}")
            stage.grab().save(str(out / "mech-trails.png"))
            # 清空轨迹（重置）后底图跟着重做，不残留旧轨迹
            loop.pause()
            for o in [o for o in B.mech_objs() if o.get("kind") == "body"]:
                o["trail"] = []
            stage.repaint()
            check("轨迹清空后底图重做、不残留", not any(TR["mark"].values()), TR["mark"])
            loop.play()

            # ---- 场景台、电路板
            count_on("scene")
            spin(0.2)
            cnt[0] = 0
            spin(1.0)
            check("场景台暂停、没人碰：基本不重画", cnt[0] <= 3, cnt[0])
            count_on("circ")
            spin(0.2)
            cnt[0] = 0
            spin(1.0)
            check("电路板：光点在走时约 30 帧，不再 60 帧", cnt[0] <= 40, cnt[0])

            # ---- 化学台（0.3.13）：静止时不重画；有东西在动（时钟驱动的效果）时照常画
            count_on("chem")
            spin(2.5)                       # 让开场的倾倒、沉降走完
            cnt[0] = 0
            spin(1.0)
            check("化学台静止、没人碰：基本不重画", cnt[0] <= 6, cnt[0])
            # 0.3.14：数真正的 Paint 事件（以前只数 L.draw；批注层和画布互相触发重画，静止时每秒仍画 120 次，L.draw 数不出来）
            from PySide6.QtCore import QEvent, QObject
            paints = [0]

            class _P(QObject):
                def eventFilter(self, o, e):
                    if e.type() == QEvent.Type.Paint:
                        paints[0] += 1
                    return False
            pf = _P()
            st.ctx.stage.installEventFilter(pf)
            spin(1.0)
            st.ctx.stage.removeEventFilter(pf)
            check("化学台静止：画布真正的绘制事件也基本没有", paints[0] <= 6, paints[0])
            (out / "chem-idle.txt").write_text(f"chem idle draws/s {cnt[0]}, paint events/s {paints[0]}\n", encoding="utf-8")
            # 酒精灯火焰只靠时钟动（状态不变）：程序点灯（不经键鼠）后火焰出来，并且一直在动
            live = st.B.chem_live
            lamp = live["new_lamp"]()
            spin(0.5)
            if lamp is not None:
                live["toggle_lamp"](lamp)
                spin(0.5)
                cnt[0] = 0
                spin(1.0)
                check("点着的酒精灯：没人碰也一直画（火焰在动）", cnt[0] >= 30, cnt[0])
                live["toggle_lamp"](lamp)
                spin(0.5)
            else:
                check("能放酒精灯", False, "new_lamp None")
            st.ctx.poke()
            cnt[0] = 0
            spin(0.4)
            check("化学台 poke 后照常重画", cnt[0] >= 8, cnt[0])
            vs = st.B.chem_live["vessels"]()
            if vs:
                vs[0]["V"] = max(vs[0]["V"], 10.0)   # 一杯热水冒蒸汽：跟着时钟动，没人碰也要一直画
                vs[0]["T"] = 92.0
                spin(0.3)
                cnt[0] = 0
                spin(1.0)
                check("化学台有蒸汽在冒：没人碰也照常重画", cnt[0] >= 30, cnt[0])
            else:
                check("化学台开场有容器", False, "no vessel")

            # ---- 几何画板（0.3.12）：网格底图、函数采样缓存
            st.open_bench("draw")
            spin(0.4)
            bd, stage = st.B.geo_board, st.ctx.stage

            def frames(mut=None, n=40):
                ts = []
                for i in range(n):
                    if mut:
                        mut(i)
                    t = time.perf_counter()
                    stage.repaint()
                    ts.append((time.perf_counter() - t) * 1000)
                return statistics.median(ts)
            bd.objects[:] = []
            bd.selection = []
            empty = frames()
            check("几何画板空板一帧 ≤ 8 ms（原来约 16 ms）", empty <= 8, f"{empty:.2f}")
            for e in ("x^3-3x", "1/x", "tan(x)", "sin(x)"):
                bd.add_function(e)
            bd.selection = [next(o["id"] for o in bd.objects if o["type"] == "function")]
            frames(n=3)
            builds = (bd._curve_builds, bd._base["builds"])
            still = frames()
            check("四条函数、选中一条，静止一帧 ≤ 20 ms（原来约 41 ms）", still <= 20, f"{still:.2f}")
            check("视野不动时不重新采样、不重画网格", (bd._curve_builds, bd._base["builds"]) == builds, ((bd._curve_builds, bd._base["builds"]), builds))
            cb = bd._curve_builds
            pan = frames(lambda i: bd.view.__setitem__("cx", bd.view["cx"] + 0.02))
            check("小幅平移复用采样（不重新求值）", bd._curve_builds == cb, (bd._curve_builds, cb))
            check("平移一帧 ≤ 30 ms（原来约 45 ms）", pan <= 30, f"{pan:.2f}")
            a = stage.grab().toImage()
            for k in ("_curves", "_base", "_featw"):
                bd.__dict__.pop(k, None)
            b = stage.grab().toImage()
            diff = _diff(a, b)
            check("缓存画出来的和清空缓存重画一致", diff < 0.005, f"{diff:.4%}")
            stage.grab().save(str(out / "geo-cache.png"))
            (out / "geo-perf.txt").write_text(f"empty {empty:.2f} ms, 4 funcs still {still:.2f} ms, pan {pan:.2f} ms\n", encoding="utf-8")
            st.close()
    finally:
        kctx.idle_seconds = real_idle

    check("拿得到系统输入时间（Windows）", real_idle() is not None)
    (out / "physics-perf-result.txt").write_text("OK" if not failures else "FAIL\n" + "\n".join(failures), encoding="utf-8")
    print(f"PHYSICS_PERF {'OK' if not failures else 'FAIL'} {len(checks)} checks", flush=True)
    return 0 if not failures else 1


def _diff(a, b):
    """两张图不同像素的比例（每个通道差 > 24 才算不同，抗锯齿边缘的细微差别不算）。"""
    if a.size() != b.size():
        return 1.0
    w, h = a.width(), a.height()
    bad = total = 0
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            ca, cb = a.pixelColor(x, y), b.pixelColor(x, y)
            total += 1
            if max(abs(ca.red() - cb.red()), abs(ca.green() - cb.green()), abs(ca.blue() - cb.blue())) > 24:
                bad += 1
    return bad / max(1, total)


if __name__ == "__main__":
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    raise SystemExit(test_runtime.run(main))
