"""安全的表达式编译：把 `a*x^2+2x`、`sinx`、`|x-1|`、`log(2,x)`、`3!` 编译成 Python 函数。

语法与旧 compileExpr 一致：省略乘号、π / √ / ² / ³ / 全角符号、阶乘、绝对值竖线。
只允许白名单函数与给定变量名，生成的代码在无内置函数的命名空间里求值，不能执行任意代码。
"""
from __future__ import annotations

import math
import re


def _fact(n):
    if n < 0 or n != int(n):
        return math.nan
    return float(math.factorial(int(n)))


def _log(a, b=None):
    return math.log10(a) if b is None else math.log(b) / math.log(a)


def _safe(fn):
    def g(*a):
        try:
            return fn(*a)
        except (ValueError, ZeroDivisionError, OverflowError):
            return math.nan
    return g


MF = {k: _safe(v) for k, v in {
    "sin": math.sin, "cos": math.cos, "tan": math.tan, "asin": math.asin, "acos": math.acos, "atan": math.atan,
    "arcsin": math.asin, "arccos": math.acos, "arctan": math.atan, "sqrt": math.sqrt, "abs": abs, "exp": math.exp,
    "ln": math.log, "lg": math.log10, "log": _log, "floor": math.floor, "ceil": math.ceil, "round": round,
    "sign": lambda x: (x > 0) - (x < 0), "max": max, "min": min, "pow": math.pow, "cbrt": lambda x: math.copysign(abs(x) ** (1 / 3), x),
    "cot": lambda x: 1 / math.tan(x), "sec": lambda x: 1 / math.cos(x), "csc": lambda x: 1 / math.sin(x), "fact": _fact,
    "comb": lambda n, k: float(math.comb(int(n), int(k))), "perm": lambda n, k: float(math.perm(int(n), int(k))),
}.items()}
MCONST = {"pi": math.pi, "e": math.e}


class ExprError(ValueError):
    pass


def _pow(a, b):
    try:
        if isinstance(a, (int, float)) and isinstance(b, float) and a < 0 and not b.is_integer():
            # 0.3.14：x^(1/3)、x^(2/3) 在 x < 0 取实根（教材里定义域是 R）；分母是偶数（x^(1/2)）仍无定义
            from fractions import Fraction
            fr = Fraction(b).limit_denominator(9)
            if abs(float(fr) - b) < 1e-12 and fr.denominator % 2 == 1:
                r = abs(a) ** b
                return -r if fr.numerator % 2 else r
        r = a ** b
        return r if isinstance(r, float) or isinstance(r, int) else math.nan
    except (ZeroDivisionError, OverflowError):
        return math.nan


def _div(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return math.inf if a > 0 else -math.inf if a < 0 else math.nan


_TOK = re.compile(r"\s*(?:(\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+)|([a-zA-Z_]+)|(.))")


def translate(src: str, vars=("x",)) -> str:
    s = str(src).strip()
    for a, b in (("π", "pi"), ("×", "*"), ("·", "*"), ("÷", "/"), ("（", "("), ("）", ")"), ("，", ","),
                 ("²", "^2"), ("³", "^3"), ("√", "sqrt"), ("−", "-")):
        s = s.replace(a, b)
    s = re.sub(r"^\s*(y|f\s*\(\s*x\s*\)|g\s*\(\s*x\s*\)|h\s*\(\s*x\s*\))\s*=", "", s)
    if not s.strip():
        raise ExprError("表达式为空")
    names = sorted([*MF, *MCONST, *vars], key=len, reverse=True)
    toks, pos = [], 0
    while pos < len(s):
        m = _TOK.match(s, pos)
        if not m or m.end() == pos:
            break
        pos = m.end()
        if m.group(1):
            toks.append(("n", m.group(1)))
        elif m.group(2):
            w = m.group(2)
            while w:
                hit = next((n for n in names if w.startswith(n)), None)
                if not hit:
                    raise ExprError(f"不认识的符号「{w}」")
                toks.append(("f" if hit in MF else "v", hit))
                w = w[len(hit):]
        elif m.group(3).strip():
            ch = m.group(3)
            if ch not in "+-*/^(),!|":
                raise ExprError(f"不支持的字符「{ch}」")
            toks.append(("o", ch))
    i = 0

    def peek():
        return toks[i] if i < len(toks) else None

    def eat(v):
        nonlocal i
        if i < len(toks) and toks[i][1] == v and toks[i][0] == "o":
            i += 1
            return True
        return False

    def starts_primary(t):
        return t is not None and (t[0] in ("n", "v", "f") or t == ("o", "("))

    def expr():
        a = term()
        while True:
            if eat("+"):
                a = f"({a}+{term()})"
            elif eat("-"):
                a = f"({a}-{term()})"
            else:
                return a

    def term():
        a = unary()
        while True:
            if eat("*"):
                a = f"({a}*{unary()})"
            elif eat("/"):
                a = f"_div({a},{unary()})"
            elif starts_primary(peek()):
                a = f"({a}*{unary()})"
            else:
                return a

    def unary():
        if eat("-"):
            return f"(-{unary()})"
        if eat("+"):
            return unary()
        return power()

    def power():
        b = postfix()
        if eat("^"):
            return f"_pow({b},{unary()})"
        return b

    def postfix():
        a = primary()
        while eat("!"):
            a = f"F['fact']({a})"
        return a

    def primary():
        nonlocal i
        if i >= len(toks):
            raise ExprError("表达式不完整")
        t = toks[i]
        i += 1
        if t[0] == "n":
            return f"({float(t[1])!r})"
        if t[0] == "v":
            return f"({MCONST[t[1]]!r})" if t[1] in MCONST else t[1]
        if t[0] == "f":
            if eat("("):
                args = [expr()]
                while eat(","):
                    args.append(expr())
                if not eat(")"):
                    raise ExprError("缺少右括号")
                return f"F['{t[1]}']({','.join(args)})"
            return f"F['{t[1]}']({power()})"
        if t[1] == "(":
            a = expr()
            if not eat(")"):
                raise ExprError("缺少右括号")
            return a
        if t[1] == "|":
            a = expr()
            if not eat("|"):
                raise ExprError("缺少绝对值右竖线")
            return f"abs({a})"
        raise ExprError(f"此处不能出现「{t[1]}」")

    code = expr()
    if i < len(toks):
        raise ExprError(f"多余的「{toks[i][1]}」")
    return code


def compile_expr(src: str, vars=("x",)):
    vars = tuple(vars)
    code = translate(src, vars)
    ns = {"__builtins__": {}, "F": MF, "_pow": _pow, "_div": _div, "abs": abs}
    fn = eval(f"lambda {','.join(vars)}: {code}", ns)  # noqa: S307  代码只由白名单记号拼成

    def safe(*a):
        try:
            v = fn(*a)
            return float(v) if not isinstance(v, complex) else math.nan
        except (ValueError, ZeroDivisionError, OverflowError, TypeError):
            return math.nan
    safe.code = code
    return safe
