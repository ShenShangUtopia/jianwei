"""题面里的轻量 TeX → Qt 富文本（对应旧 JW.fx）。Qt 富文本支持 sup / sub，分数写成 a/b 的上下标形式。"""
from __future__ import annotations

import html
import re

_SYMS = [(r"\pi", "π"), (r"\alpha", "α"), (r"\beta", "β"), (r"\theta", "θ"), (r"\omega", "ω"), (r"\varphi", "φ"), (r"\phi", "φ"), (r"\Delta", "Δ"), (r"\mu", "μ"), (r"\lambda", "λ"),
         (r"\times", "×"), (r"\cdot", "·"), (r"\pm", "±"), (r"\le", "≤"), (r"\ge", "≥"), (r"\neq", "≠"), (r"\Rightarrow", "⇒"), (r"\to", "→"), (r"\infty", "∞"), (r"\angle", "∠"),
         (r"\circ", "°"), (r"\left", ""), (r"\right", "")]


_SUP = str.maketrans("0123456789+-−=()n", "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁻⁼⁽⁾ⁿ")
_SUB = str.maketrans("0123456789+-−=()nx", "₀₁₂₃₄₅₆₇₈₉₊₋₋₌₍₎ₙₓ")


def plain(tex) -> str:
    """纯文本标签用：上下标换成 Unicode 上下标字符（没有对应字符的保留 ^ _），分数写成 a/b。"""
    s = str("" if tex is None else tex)
    s = re.sub(r"\\d?frac\{([^{}]*)\}\{([^{}]*)\}", lambda m: "/".join(x if re.fullmatch(r"\w+", x) else f"({x})" for x in m.groups()), s)
    s = re.sub(r"\\sqrt\{([^{}]*)\}", r"√(\1)", s)
    for a, b in _SYMS:
        s = s.replace(a, b)

    def conv(m, table):
        body = m.group(2) if m.group(2) is not None else m.group(3)
        return body.translate(table) if body and all(ord(ch) in table for ch in body) else m.group(0)
    s = re.sub(r"(\^)(?:\{([^{}]*)\}|(-?\d+|[+\-−n]))", lambda m: conv(m, _SUP), s)
    s = re.sub(r"(_)(?:\{([^{}]*)\}|(\d+|[nx]))", lambda m: conv(m, _SUB), s)
    return s


def spaced_options(s: str) -> str:
    """单行预览里把选项隔开：「…H₂O B.含…」→「…H₂O　　B. 含…」（今日一题预览，0.3.14）。"""
    return re.sub(r"(?:\s+|(?<=[^A-Za-z0-9.\s]))([B-D])[.．、](?=\S)", "　　\\1. ", str(s or ""))


def fx(tex) -> str:
    s = html.escape(str("" if tex is None else tex), quote=False)
    s = re.sub(r"\\d?frac\{([^{}]*)\}\{([^{}]*)\}", r"<sup>\1</sup>⁄<sub>\2</sub>", s)
    s = re.sub(r"\\sqrt\{([^{}]*)\}", r"√(\1)", s)
    for a, b in _SYMS:
        s = s.replace(a, b)
    s = re.sub(r"\^(-?\d+|[^<\s])", r"<sup>\1</sup>", s)
    s = re.sub(r"_(\d+|[^<\s])", r"<sub>\1</sub>", s)
    return s
