"""subjects 引擎 · 其余模式（由 views/subjects.js 改写）：长难句、古诗、议论文结构、通用流程、数据图。"""
from __future__ import annotations

import math
import re

from ..kit.core import clamp
from .sb_core import C, mode, num, tw, wrap_text


# ---------------------------------------------------------------- 长难句
def default_syntax():
    return [{"role": "主语", "text": "The scientist", "main": True, "children": [
                {"role": "定语从句", "text": "who discovered the vaccine", "children": [{"role": "主", "text": "who"}, {"role": "谓", "text": "discovered"}, {"role": "宾", "text": "the vaccine"}]}]},
            {"role": "谓语", "text": "said", "main": True},
            {"role": "宾语从句", "text": "that the results were convincing", "main": True, "children": [
                {"role": "引导", "text": "that"}, {"role": "主", "text": "the results"}, {"role": "系动词", "text": "were"}, {"role": "表语", "text": "convincing"}]}]


VERBS = set("is are was were has have had said says discovered found shows show proves prove makes make becomes become believes believe thinks think argues argue allows allow helps help causes cause leads lead means mean keeps keep can could will would".split())
MARK = re.compile(r"^(that|which|who|whom|whose|because|although|when|if|while|where|as)\b", re.I)


def guess_syntax(sentence):
    s = re.sub(r"\s+", " ", str(sentence or "")).strip()
    if not s:
        return default_syntax()
    words = re.sub(r"[.,;:!?]$", "", s).split(" ")
    clauses, cur = [], []
    for i, w in enumerate(words):
        if i > 0 and MARK.match(w):
            clauses.append(cur)
            cur = [w]
        else:
            cur.append(w)
    if cur:
        clauses.append(cur)
    out = []
    for k, arr in enumerate(clauses):
        vi = next((i for i, w in enumerate(arr) if w.lower() in VERBS), -1)
        marker = arr[0] if arr and MARK.match(arr[0]) else ""
        lead = 1 if marker else 0
        subj = " ".join(arr[lead:(vi if vi > lead else lead + 1)])
        verb = arr[vi] if vi >= 0 else ""
        obj = " ".join(arr[vi + 1:])
        if marker:
            role = "定语从句" if re.match(r"^(who|which|whose|whom)$", marker, re.I) else "从句" if marker.lower() == "that" else "状语从句"
        else:
            role = f"分句 {k + 1}"
        kids = []
        if subj:
            kids.append({"role": "主", "text": subj})
        if verb:
            kids.append({"role": "谓", "text": verb})
        if obj:
            kids.append({"role": "宾/表", "text": obj})
        out.append({"role": role, "text": " ".join(arr), "main": k == 0, "children": kids})
    return out


def norm_tree(t):
    """题库里的树有三种写法：节点列表、夹了字符串的列表、{root, subject, modifier, object} 主干速记。统一成节点列表。"""
    if isinstance(t, dict):
        if "role" in t or "text" in t:
            return [t]
        subj = {"role": "主语", "text": t.get("subject") or "", "main": True}
        if t.get("modifier"):
            subj["children"] = [{"role": "修饰", "text": t["modifier"]}]
        out = [subj, {"role": "谓语", "text": t.get("root") or "", "main": True}]
        if t.get("object"):
            out.append({"role": "宾语", "text": t["object"], "main": True})
        return [n for n in out if n["text"]]
    out = []
    for n in t or []:
        if isinstance(n, dict):
            n = dict(n)
            if n.get("children"):
                n["children"] = norm_tree(n["children"])
            out.append(n)
        elif n:
            out.append({"role": "", "text": str(n)})
    return out


@mode("syntax")
def mount_syntax(W):
    D_, P = W.D, W.P
    sentence = D_.get("sentence") or P.get("sentence") or "The scientist who discovered the vaccine said that the results were convincing."
    tree = norm_tree(D_.get("tree")) or (guess_syntax(sentence) if D_.get("sentence") else default_syntax())
    S = {"closed": set(), "open": set(), "rows": [], "top": 62, "row_h": 24}
    uid = [0]
    total = [0]
    clauses = [0]

    def mark(lst, parent):
        for n in lst:
            uid[0] += 1
            n["id"] = f"n{uid[0]}"
            n["parent"] = parent
            n["children"] = n.get("children") or []
            total[0] += 1
            if "从句" in n.get("role", ""):
                clauses[0] += 1
            mark(n["children"], n["id"])
    mark(tree, None)
    W.head_title("长难句结构树", "主干 / 从句分层 · 可收起")
    W.add_steps(["主干", "一层", "两层", "全开"])
    W.L.note(sentence)
    W.sec("读数")
    W.stat("节点", total[0])
    W.stat("从句", clauses[0])
    W.kv("主干", "主 + 谓 + 宾")
    W.note("点带 +/− 的节点逐层展开或收起；主干用朱砂括号标出。")
    W.legend([(C.accent, "主干（主谓宾）"), (C.data[2], "从句与修饰")])

    def can_see(n, depth):
        if n["id"] in S["closed"]:
            return False
        return depth + 1 <= W.step or n["id"] in S["open"]

    def rows_of():
        out = []

        def walk(lst, depth):
            for n in lst:
                out.append({"n": n, "depth": depth})
                if can_see(n, depth):
                    walk(n["children"], depth + 1)
        walk(tree, 0)
        return out

    def render(w, h):
        Pd, top = 18, 62
        rows = rows_of()
        row_h = min(24, max(14, (h - top - 12) / max(1, len(rows))))   # 行多时压缩行高，不用滚动
        S.update(rows=rows, top=top, row_h=row_h)
        W.txt(Pd, 22, "句子结构树", size=12, weight=700)
        for i, ln in enumerate(wrap_text(sentence, w - Pd * 2 - 10, 10.5)[:2]):
            W.txt(Pd, 39 + i * 14, ln, size=10.5, fill=C.soft)
        W.line(Pd, top - 13, w - Pd, top - 13, C.line2)
        mains = [i for i, r in enumerate(rows) if r["n"].get("main")]
        if mains:
            y0, y1 = top + mains[0] * row_h - 10, top + mains[-1] * row_h + 10
            W.line(Pd - 6, y0, Pd - 6, y1, C.accent, 2)
            W.line(Pd - 6, y0, Pd - 2, y0, C.accent, 2)
            W.line(Pd - 6, y1, Pd - 2, y1, C.accent, 2)
            W.txt(Pd + 2, y0 - 8, "主干", size=9, fill=C.accent)
        for i, r in enumerate(rows):
            n = r["n"]
            x, y = 24 + r["depth"] * 26, top + i * row_h + 8
            r["x"], r["y"] = x, y
            if r["depth"] > 0:
                pr = next((o for o in rows if o["n"]["id"] == n["parent"]), None)
                if pr and "x" in pr:
                    W.line(pr["x"] + 9, pr["y"] + 9, pr["x"] + 9, y, C.line)
                    W.line(pr["x"] + 9, y, x - 5, y, C.line)
            if n["children"]:
                W.rect(x - 15, y - 5, 10, 10, rx=1, fill=C.card, stroke=C.line, width=0.9)
                W.txt(x - 10, y, "−" if can_see(n, r["depth"]) else "+", size=9, anchor="middle", fill=C.soft)
            main = bool(n.get("main"))
            tag = f"[{n.get('role', '')}]"
            W.txt(x, y, tag, size=9.5, fill=C.faint)
            rw = tw(tag, 9.5) + 5
            W.txt(x + rw, y, n.get("text", ""), size=11.5, fill=C.ink if main else C.ink2, weight=600 if main else 400)
            if n["id"] in S["closed"] and n["children"]:
                W.txt(x + rw + tw(n.get("text", ""), 11.5) + 6, y, f"… {len(n['children'])}", size=9, fill=C.faint)
    W.set(render)

    def click(_x, py, _o):
        for i, r in enumerate(S["rows"]):
            if abs(py - (S["top"] + i * S["row_h"] + 8)) <= S["row_h"] / 2:
                n = r["n"]
                if not n["children"]:
                    return
                if can_see(n, r["depth"]):
                    S["closed"].add(n["id"])
                    S["open"].discard(n["id"])
                else:
                    S["closed"].discard(n["id"])
                    S["open"].add(n["id"])
                W.redraw()
                return
    W.L.interact(W.c, click=click)


# ---------------------------------------------------------------- 古诗
POEM_DEF = {"title": "春望", "author": "杜甫", "lines": ["国破山河在", "城春草木深", "感时花溅泪", "恨别鸟惊心", "烽火连三月", "家书抵万金", "白头搔更短", "浑欲不胜簪"],
            "emotion": [0.82, 0.70, 0.48, 0.40, 0.28, 0.22, 0.46, 0.58],
            "sections": [{"name": "起", "a": 0, "b": 1}, {"name": "承", "a": 2, "b": 3}, {"name": "转", "a": 4, "b": 5}, {"name": "合", "a": 6, "b": 7}],
            "images": [{"word": "山河", "line": 0}, {"word": "草木", "line": 1}, {"word": "花", "line": 2}, {"word": "鸟", "line": 3}, {"word": "烽火", "line": 4}, {"word": "家书", "line": 5}, {"word": "白头", "line": 6}]}


@mode("poem")
def mount_poem(W):
    D_ = W.D
    PM = D_["poem"] if isinstance(D_.get("poem"), dict) else {}
    lines = PM.get("lines") or D_.get("lines") or POEM_DEF["lines"]
    if isinstance(lines, str):
        lines = [x for x in re.split(r"\n|/|，|。", lines) if x]
    lines = lines[:10]
    title, author = PM.get("title") or D_.get("title") or POEM_DEF["title"], PM.get("author") or D_.get("author") or POEM_DEF["author"]
    emotion = (PM.get("emotion") or POEM_DEF["emotion"])[:len(lines)]
    sections = PM.get("sections") or POEM_DEF["sections"]
    images = []
    for im in PM.get("images") or D_.get("images") or POEM_DEF["images"]:
        if isinstance(im, str):   # 只给了词：到诗句里找位置
            ln = next((i for i, x in enumerate(lines) if im in x), -1)
            im = {"word": im, "line": ln}
        if 0 <= im.get("line", -1) < len(lines):
            images.append(im)
    S = {"sel": 0 if images else -1}

    def emo(i):
        return emotion[i] if i < len(emotion) and emotion[i] is not None else 0.4
    W.head_title("诗歌结构", "起承转合 · 意象 · 情感曲线")
    W.add_steps(["起", "承", "转", "合"])
    W.sec("作品")
    W.kv("题目", title)
    W.kv("作者", author)
    W.kv("句数", f"{len(lines)} 句")
    W.sec("意象")
    if images:
        W.L.seg("", [[i, im["word"]] for i, im in enumerate(images)], 0, lambda v: (S.__setitem__("sel", int(v)), W.redraw()))
    detail = W.note("")
    W.note("点意象查看对应诗句；四段用同样的浅色带标在情感曲线下。")

    def geom(w, h):
        Pd = 20
        cy0, cy1, cx0, cx1 = h * 0.60, h - 46, Pd + 6, w - Pd
        n = len(lines)

        def ex(i):
            return cx0 + (0.5 if n == 1 else (i + 0.5) / n) * (cx1 - cx0)

        def ey(v):
            return cy1 - (v or 0) * (cy1 - cy0)
        return cy0, cy1, cx0, cx1, ex, ey, n

    def render(w, h):
        Pd = 20
        idx = min(W.step, len(sections) - 1)
        sec = sections[idx]
        W.txt(Pd, 26, title, size=17, weight=700, serif=True)
        W.txt(Pd + tw(title, 17) + 14, 27, author, size=10, fill=C.soft, serif=True)
        W.txt(w - Pd, 26, "起 · 承 · 转 · 合", size=9.5, anchor="end", fill=C.faint)
        W.line(Pd, 40, w - Pd, 40, C.line2)
        col_x = (Pd + 34, w * 0.52 + 12)
        row_h, start_y = 30, 66
        line_w = max(90, w * 0.38)
        sel_line = images[S["sel"]]["line"] if S["sel"] >= 0 else -1
        for i, ln in enumerate(lines):
            x, y = col_x[0 if i < 4 else 1], start_y + (i % 4) * row_h
            in_sec = sec["a"] <= i <= sec["b"]
            lit = sel_line == i
            if in_sec:
                W.rect(x - 6, y - 14, min(line_w, tw(ln, 14) + 12), 26, fill=C.data[4], rx=2)
            W.txt(x, y, ln, size=14, serif=True, fill=C.accent if lit else C.ink if in_sec else C.ink2, weight=700 if lit else 400)
            if lit:
                W.line(x, y + 12, x + tw(ln, 14), y + 12, C.accent, 1.2)
        for k, s2 in enumerate(sections):
            x = col_x[0 if s2["a"] < 4 else 1] - 24
            y0 = start_y + (s2["a"] % 4) * row_h - 12
            y1 = y0 + (s2["b"] - s2["a"]) * row_h + 12
            on = k == idx
            W.line(x, y0, x, y1, C.accent if on else C.line, 2 if on else 1)
            W.txt(x - 6, (y0 + y1) / 2, s2["name"], size=11, anchor="middle", serif=True, fill=C.accent if on else C.faint, weight=700 if on else 400)
        cy0, cy1, cx0, cx1, ex, ey, n = geom(w, h)
        W.txt(Pd, cy0 - 12, "情感走向", size=9.5, fill=C.faint)
        half = 0 if n == 1 else (cx1 - cx0) / n / 2
        for k, s2 in enumerate(sections):
            if s2["a"] >= n:
                continue
            a, b = ex(s2["a"]) - half, ex(min(s2["b"], n - 1)) + half
            W.rect(a, cy0, max(0, b - a), cy1 - cy0, fill=C.data[1], opacity=0.08 if k == idx else 0.03)
            W.line(a, cy0, a, cy1, C.line2)
            W.txt((a + b) / 2, cy1 + 14, s2["name"], size=9.5, anchor="middle", fill=C.faint)
        W.line(cx0, cy1, cx1, cy1, C.line)
        W.poly([(ex(i), ey(emo(i))) for i in range(n)], stroke=C.data[1], width=1.8)
        for i in range(n):
            lit = sel_line == i
            W.circ(ex(i), ey(emo(i)), 4.6 if lit else 2.8, fill=C.accent if lit else C.ink2, stroke=C.card)
        for i, im in enumerate(images):
            x, y = ex(im["line"]), ey(emo(im["line"]))
            up = i % 2 == 0
            ly = y - 17 if up else y + 19
            lit = i == S["sel"]
            W.line(x, y + (-5 if up else 5), x, ly + (7 if up else -7), C.accent if lit else C.data[2], 0.8, opacity=0.7)
            bw = tw(im["word"], 10) + 10
            W.rect(x - bw / 2, ly - 8, bw, 16, rx=2, fill=C.accent if lit else C.card, stroke=C.accent if lit else C.line)
            W.txt(x, ly, im["word"], size=10, anchor="middle", fill=C.card if lit else C.ink)
        if S["sel"] >= 0:
            im = images[S["sel"]]
            detail.text(f"<b>“{im['word']}”</b>　第 {im['line'] + 1} 句：{lines[im['line']]}。情感值 {num(emo(im['line']), 2)}（越低越沉郁）。")
        else:
            detail.text("点意象节点，诗句同步高亮。")
    W.set(render)

    def click(px, py, _o):
        _c0, _c1, _x0, _x1, ex, ey, _n = geom(W.w, W.h)
        for i, im in enumerate(images):
            x, y = ex(im["line"]), ey(emo(im["line"]))
            ly = y - 17 if i % 2 == 0 else y + 19
            if abs(px - x) < 26 and abs(py - ly) < 11:
                S["sel"] = i
                W.redraw()
                return
    W.L.interact(W.c, click=click)


# ---------------------------------------------------------------- 议论文结构
COMP_DEF = {"thesis": "数字时代的阅读，需要“深读”而非“刷读”",
            "points": [{"text": "深读重建注意力的连续性", "evidences": ["持续阅读训练工作记忆的实验", "纸质书与屏幕阅读的对照"]},
                       {"text": "深读保留怀疑与对话的空间", "evidences": ["慢读批注的经典案例", "课堂共读的讨论记录"]},
                       {"text": "深读沉淀可迁移的知识结构", "evidences": ["主题阅读的笔记网络", "跨文本比较的写作"]}]}


@mode("composition")
def mount_composition(W):
    D_ = W.D
    src = D_.get("outline") or D_.get("composition") or COMP_DEF
    if isinstance(src, list):   # 只给了提纲条目：第一条当论点，其余当分论点
        src = {"thesis": src[0] if src else COMP_DEF["thesis"], "points": src[1:]}
    if isinstance(src, str):
        src = {"thesis": src, "points": []}
    thesis = src.get("thesis") or src.get("argument") or D_.get("title") or COMP_DEF["thesis"]
    points = (src.get("points") or src.get("branches") or D_.get("angles") or COMP_DEF["points"])[:3]
    nodes = {"t": {"id": "t", "level": 0, "role": "中心论点", "text": thesis, "parent": None}}
    order1, ev0 = [], {}
    for i, p in enumerate(points):
        pid = f"p{i}"
        text = p if isinstance(p, str) else (p.get("text") or p.get("title") or "分论点")
        evs = [] if isinstance(p, str) else (p.get("evidences") or p.get("evidence") or [])
        nodes[pid] = {"id": pid, "level": 1, "role": f"分论点 {i + 1}", "text": text, "parent": "t"}
        order1.append(pid)
        ev0[pid] = []
        for k, e in enumerate(evs[:2]):
            eid = f"{pid}_{k}"
            nodes[eid] = {"id": eid, "level": 2, "role": "论据", "text": e if isinstance(e, str) else (e.get("text") or ""), "parent": pid}
            ev0[pid].append(eid)
    S = {"sel": "t", "pos": {}, "order1": list(order1), "ev": {k: list(v) for k, v in ev0.items()}, "drag": None}
    W.head_title("议论文结构", "论点 — 分论点 — 论据 · 可拖动重排")
    W.add_steps(["论点", "分论点", "论据", "论证链"])
    W.sec("结构读数")
    W.stat("分论点", len(order1))
    W.stat("论据", sum(1 for n in nodes.values() if n["level"] == 2))
    detail = W.note("")
    W.note("拖动分论点或论据改变顺序，松手后自动重排并重连。")

    def reset():
        S["order1"] = list(order1)
        S["ev"] = {k: list(v) for k, v in ev0.items()}
        W.redraw()
    W.button("恢复原顺序", reset)

    def layout(w, h):
        pad, gap = 16, 12
        pos = {}
        root_w = min(w * 0.58, 470)
        root_h = clamp(22 + len(wrap_text(thesis, root_w - 18, 12)) * 17, 44, 92)
        pos["t"] = [(w - root_w) / 2, 22, root_w, root_h]
        n1 = max(1, len(S["order1"]))
        bw = (w - pad * 2 - gap * (n1 - 1)) / n1
        bh, by = 74, max(22 + root_h + 26, h * 0.31)
        ey, eh = max(by + bh + 46, h * 0.63), 84
        for i, pid in enumerate(S["order1"]):
            pos[pid] = [pad + i * (bw + gap), by, bw, bh]
            kids = S["ev"].get(pid) or []
            cw = (bw - (8 if len(kids) > 1 else 0)) / max(1, len(kids))
            for k, eid in enumerate(kids):
                pos[eid] = [pad + i * (bw + gap) + k * (cw + 8), ey, cw, eh]
        shift = (h - max(p[1] + p[3] for p in pos.values()) - 20) / 2
        if shift > 0:
            for p in pos.values():
                p[1] += shift
        return pos

    def update_detail():
        n = nodes.get(S["sel"])
        if not n:
            detail.text("点节点查看内容")
            return
        kids = len(S["order1"]) if n["level"] == 0 else len(S["ev"].get(n["id"]) or []) if n["level"] == 1 else 0
        detail.text(f"<b>{n['role']}</b><br>{n['text']}" + (f"（下辖 {kids} 项）" if kids else ""))

    def render(w, h):
        step = W.step
        pos = layout(w, h)
        d = S["drag"]
        if d and d.get("moved"):
            pos[d["id"]][0], pos[d["id"]][1] = d["x"], d["y"]
        S["pos"] = pos

        def link(a, b):
            pa, pb = pos.get(a), pos.get(b)
            if not pa or not pb:
                return
            x1, y1, x2, y2 = pa[0] + pa[2] / 2, pa[1] + pa[3], pb[0] + pb[2] / 2, pb[1]
            my = (y1 + y2) / 2

            def cv(g):
                g.move_to(x1, y1)
                g.bezier_to(x1, my, x2, my, x2, y2)
            chain = step == 3
            W.stroke_path(cv, stroke=C.ink2 if chain else C.line, width=1.4 if chain else 1, dash=None if step >= 3 else "2 3", opacity=0.85 if chain else 0.9)
            W.head(x2, y2 - 1, math.pi / 2, 4.5, C.ink2 if chain else C.data[2], 0.85 if chain else 0.5)
        for pid in S["order1"]:
            link("t", pid)
        if step >= 2:
            for pid in S["order1"]:
                for eid in S["ev"].get(pid) or []:
                    link(pid, eid)
        for nid, n in nodes.items():
            p = pos.get(nid)
            if not p:
                continue
            op = 1 if step >= n["level"] else 0.3
            sel = S["sel"] == nid
            W.rect(p[0], p[1], p[2], p[3], rx=6, fill=C.card, stroke=C.accent if sel else C.line, width=1.6 if sel else 1, opacity=op)
            W.txt(p[0] + 8, p[1] + 13, n["role"], size=9.5, fill=C.accent if sel else C.faint, weight=600, opacity=op)
            size = 12 if n["level"] == 0 else 11 if n["level"] == 1 else 10
            maxl = max(1, int((p[3] - 26) // (size * 1.4)))
            for k, ln in enumerate(wrap_text(n["text"], p[2] - 16, size)[:maxl]):
                W.txt(p[0] + 8, p[1] + 28 + k * size * 1.4, ln, size=size, weight=600 if n["level"] == 0 else 400, opacity=op)
        update_detail()
    W.set(render)

    def hit(x, y):
        for nid, p in reversed(list(S["pos"].items())):
            if p[0] <= x <= p[0] + p[2] and p[1] <= y <= p[1] + p[3]:
                return {"id": nid, "ox": x - p[0], "oy": y - p[1], "x": p[0], "y": p[1], "moved": False}
        return None

    def down(_x, _y, h):
        if h:
            S["sel"] = h["id"]
            S["drag"] = h

    def drag(h, x, y, _dx, _dy):
        if nodes[h["id"]]["level"] == 0:
            return
        h.update(moved=True, x=x - h["ox"], y=y - h["oy"])

    def up(h):
        d, S["drag"] = S["drag"], None
        if not h or not d or not d.get("moved"):
            return
        n = nodes[h["id"]]
        pos = S["pos"]
        if n["level"] == 1:
            S["order1"].sort(key=lambda a: pos[a][0])
        elif n["level"] == 2:
            S["ev"][n["parent"]].sort(key=lambda a: pos[a][0])
    W.L.interact(W.c, hit=hit, down=down, drag=drag, up=up)


# ---------------------------------------------------------------- 通用流程
@mode("flow")
def mount_flow(W, unknown=None):
    D_ = W.D
    q = W.q
    W.reveals = "讲解步骤卡"       # 画面就是解题步骤：习题台「做题」时盖住
    title = D_.get("title") or q.get("title") or "通用解释"
    teach = q.get("steps")
    lines = teach if teach and len(teach) >= 2 else (D_.get("lines") or D_.get("chain") or D_.get("nodes"))
    if not lines:
        lines = ["识别条件", "建立模型", "推导求解", "检验结论"]
    if isinstance(lines, str):
        lines = [x for x in re.split(r"→|->|\n|；|;", lines) if x]
    extra = D_.get("lines") if isinstance(D_.get("lines"), list) else []
    steps = []
    for i, n in enumerate(lines[:8]):
        if isinstance(n, dict):
            steps.append((n.get("label") or n.get("title") or n.get("text") or "", n.get("desc") or n.get("note") or ""))
        else:
            ex = str(extra[i]) if i < len(extra) and str(extra[i]) != str(n) else ""
            steps.append((str(n), ex))
    W.head_title("通用解释卡" if unknown else "讲解顺序", f"未识别的 mode：{unknown}" if unknown else "逐节点推进")
    W.L.note(f"<b>{title}</b>　{len(steps)} 个节点")
    W.sec("节点")
    vI = W.stat("当前", f"1 / {len(steps)}")
    desc = W.note("")
    W.note("这个题型还没有专属视图，先用讲解顺序顶上。" if unknown else "点一行或按「解题路径」，画面上的聚光会跟过去。")
    S = {"ys": []}

    def render(w, h):
        step = min(W.step, len(steps) - 1)
        Pd, top = 26, 74
        n = len(steps)
        gap = max(42, min(78, (h - top - 26) / max(1, n)))
        S["ys"] = []
        W.txt(Pd, 30, title, size=14, weight=700)
        W.txt(w - Pd, 30, f"{n} 步 · 按顺序读", size=9.5, anchor="end", fill=C.faint)
        for i, (label, _d) in enumerate(steps):
            y = top + i * gap
            S["ys"].append(y)
            lit, active = i <= step, i == step
            if active:
                W.rect(Pd - 12, y - 16, w - Pd * 2 + 24, 34, rx=8, fill=C.accent, opacity=0.07)
                W.rect(Pd - 12, y - 10, 3, 18, rx=1.5, fill=C.accent)
            col = (C.accent if active else C.ink2) if lit else None
            W.circ(Pd + 2, y, 9.5, fill=col, stroke=col if lit else C.line, width=1.2)
            W.txt(Pd + 2, y, i + 1, size=9.5, anchor="middle", weight=600, fill=C.card if lit else C.faint)
            size = 14 if active else 12.5
            cx = Pd + 26
            ls = wrap_text(label, w - cx - Pd - 10, size)[:3 if active else 2]
            for k, ln in enumerate(ls):
                W.txt(cx, y + (k - (len(ls) - 1) / 2) * (size + 5), ln, size=size, weight=700 if active else 500, fill=(C.ink if active else C.ink2) if lit else C.faint)
            if i < n - 1:
                W.line(cx, y + gap - 14, w - Pd, y + gap - 14, C.line, opacity=0.5 if lit else 0.25)
        vI.text(f"{step + 1} / {n}")
        cur = steps[step]
        desc.text(f"<b>第 {step + 1} 步</b><br>{cur[1] or cur[0]}")
    W.set(render)

    def focus(i):
        ys = S["ys"]
        if not ys:
            return None
        return {"x": 44, "y": ys[max(0, min(len(ys) - 1, i))], "r": 20, "label": f"第 {i + 1} 步"}
    W.focus = focus


# ---------------------------------------------------------------- 数据图
@mode("data")
def mount_data(W):
    D_ = W.D
    W.reveals = "数据图"            # 柱状图直接画出要求的数值：习题台「做题」时盖住
    if D_.get("rows"):
        kind = "bar"
        rows = []
        for r in D_["rows"]:
            if isinstance(r, list):   # [名称, 数值]
                rows.append({"label": str(r[0]), "value": float(r[1]) if len(r) > 1 and _isnum(r[1]) else 0.0})
            else:
                v = r.get("value") if r.get("value") is not None else r.get("v")
                rows.append({"label": r.get("label") or r.get("name") or "", "value": float(v) if _isnum(v) else 0.0})
        series = [{"name": D_.get("title") or "数值", "rows": rows}]
    elif D_.get("series"):
        series = [{"name": s.get("name") or s.get("label") or f"序列 {i + 1}", "values": [float(v) for v in (s.get("values") or s.get("data") or []) if _isnum(v)]} for i, s in enumerate(D_["series"])]
        kind = "line"
    elif D_.get("curve"):
        series = [{"name": "曲线", "points": [(float(p[0]), float(p[1])) if isinstance(p, list) else (float(p["x"]), float(p["y"])) for p in D_["curve"]]}]
        kind = "xy"
    else:
        kind = "bar"
        series = [{"name": "样本得分", "rows": [{"label": a, "value": b} for a, b in (("阅读", 82), ("计算", 74), ("写作", 88), ("实验", 66), ("表达", 79))]}]
    W.head_title("数据图", "自动刻度 · 逐序列读数")
    W.add_steps(["坐标", "数据", "读数", "对比"])
    W.sec("读数")
    vMax, vMin, vAvg = W.stat("最大"), W.stat("最小"), W.stat("均值")
    legend = W.note("")
    W.note("按步骤切换，图中其余序列退为淡色。")
    if D_.get("lines") and kind != "line":
        W.sec("要点")
        W.L.note("<br>".join(str(x) for x in D_["lines"]))

    def render(w, h):
        Lm, Rm, Tm, Bm = 46, 22, 32, 48
        iw, ih = w - Lm - Rm, h - Tm - Bm
        step = W.step
        rows = series[0]["rows"] if kind == "bar" else None
        if rows:
            vals = [r["value"] for r in rows]
        elif kind == "xy":
            vals = [p[1] for p in series[0]["points"]]
        else:
            vals = [v for s in series for v in s["values"]]
        vals = vals or [0.0]
        vmax, vmin = max([1.0] + vals), min([0.0] + vals)
        pad = (vmax - vmin) * 0.12 or 1
        vmax += pad
        if kind != "bar":
            vmin -= pad

        def y(v):
            return Tm + (1 - (v - vmin) / (vmax - vmin)) * ih
        for k in range(5):
            v = vmin + (vmax - vmin) * k / 4
            W.line(Lm, y(v), w - Rm, y(v), C.grid2)
            W.txt(Lm - 8, y(v), num(v, 0 if v >= 10 else 1), size=9.5, anchor="end", fill=C.faint)
        W.line(Lm, Tm + ih, w - Rm, Tm + ih, C.faint)
        W.line(Lm, Tm, Lm, Tm + ih, C.faint)
        W.txt(Lm - 8, Tm - 12, "数值", size=9.5, anchor="end", fill=C.soft)

        def blurb(label):
            W.txt(w - Rm, h - 10, "当前：" + (label or "—"), size=9.5, anchor="end", fill=C.faint)
        if kind == "bar":
            n = len(rows)
            bw = min(48, iw / n * 0.52)
            for i, r in enumerate(rows):
                cx = Lm + (i + 0.5) * iw / n
                sel = i == step % n
                W.rect(cx - bw / 2, y(r["value"]), bw, y(vmin) - y(r["value"]), fill=C.accent if sel else C.data[2], opacity=1 if sel else 0.78)
                W.txt(cx, y(r["value"]) - 7, num(r["value"], 0 if abs(r["value"]) >= 10 else 2), size=9.5, anchor="middle", fill=C.accent if sel else C.soft, weight=700 if sel else 400)
                W.txt(cx, Tm + ih + 16, (wrap_text(r["label"], iw / n - 6, 10) or [""])[0], size=10, anchor="middle", fill=C.soft)
            r0 = rows[step % n]
            legend.text(f"{r0['label']} · {num(r0['value'], 2)}")
            blurb(r0["label"])
            cur = vals
        elif kind == "xy":
            pts = series[0]["points"]
            xmin, xmax = min(p[0] for p in pts), max(p[0] for p in pts)

            def X(v):
                return Lm + (0.5 if xmax == xmin else (v - xmin) / (xmax - xmin)) * iw
            W.poly([(X(p[0]), y(p[1])) for p in pts], stroke=C.ink2, width=1.8)
            for i, p in enumerate(pts):
                sel = i == step % len(pts)
                W.circ(X(p[0]), y(p[1]), 4 if sel else 2.4, fill=C.accent if sel else C.ink2)
            s = pts[step % len(pts)]
            legend.text(f"选中点 ({num(s[0], 2)}, {num(s[1], 2)})")
            blurb("x = " + num(s[0], 2))
            cur = vals
        else:
            shades = (C.ink, C.data[1], C.data[2], C.data[3])

            def X(i, n):
                return Lm + (0.5 if n <= 1 else i / (n - 1)) * iw
            ai = step % len(series)
            for si, s in enumerate(series):
                active = ai == si
                W.poly([(X(i, len(s["values"])), y(v)) for i, v in enumerate(s["values"])], stroke=C.ink if active else shades[si % 4], width=2 if active else 1.2, opacity=1 if active else 0.35)
                if active:
                    for i, v in enumerate(s["values"]):
                        W.circ(X(i, len(s["values"])), y(v), 2.6, fill=C.ink)
            cur = series[ai]["values"] or [0.0]
            legend.text("<br>".join(f"{'▶ ' if ai == si else ''}{s['name']}（{len(s['values'])} 点）" for si, s in enumerate(series)))
            blurb(series[ai]["name"])
        vMax.text(num(max(cur), 1))
        vMin.text(num(min(cur), 1))
        vAvg.text(num(sum(cur) / len(cur), 1))
        W.txt(16, 22, D_.get("title") or "数据概览", size=12, weight=700)
    W.set(render)


def _isnum(v):
    if isinstance(v, (int, float)):
        return True
    try:
        float(v)
        return True
    except (TypeError, ValueError):
        return False
