"""习题台自测：逐题打开、走完每一步（昼 / 夜），汇报出错的题；默认只给每个模式存一张截图。

用法：python -m native.bank.selftest <输出目录> [题目 id 或 引擎名 ...]
"""
from __future__ import annotations

from ..kit import test_runtime

test_runtime.configure()

import os
import sys
import time
import traceback
from pathlib import Path


def _main(argv=None) -> int:
    import faulthandler
    faulthandler.enable()
    argv = list(sys.argv[1:] if argv is None else argv)
    out = Path(argv.pop(0) if argv else "bank-selftest")
    out.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    if os.path.isdir(r"C:\Windows\Fonts"):
        os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    from PySide6.QtWidgets import QFileDialog
    app = test_runtime.application(sys.argv[:1])
    QFileDialog.getSaveFileName = staticmethod(lambda *_a, **_k: ("", ""))
    from ..design import tokens
    from .data import bank
    from .desk import Desk
    errs: list = []
    w = Desk("day")
    w.resize(1440, 900)
    w.show()
    app.processEvents()
    sys.excepthook = lambda et, ev, tb: errs.append("".join(traceback.format_exception(et, ev, tb))[-500:])   # 窗口建好以后才接管：之前的错要直接报出来
    want = set(argv)
    bad = []
    shot = set()
    total = 0
    for theme in ("day", "night"):
        tokens.set_theme(theme)
        w.apply_theme()
        for q in bank.questions:
            v = q.get("view") or {}
            key = f"{v.get('engine')}-{v.get('mode') or v.get('kind') or ''}"
            if want and q["id"] not in want and v.get("engine") not in want and v.get("mode") not in want and v.get("kind") not in want:
                continue
            total += 1
            errs.clear()
            try:
                w.open(q["id"])
                w.pause()
                n = max(1, w.n_steps())
                for i in range(n):
                    w.set_step(i)
                    app.processEvents()
                    w.ctx.stage.repaint()
            except Exception:  # noqa: BLE001  主流程的异常不走 excepthook 的话会被吞掉，这里直接记下
                errs.append(traceback.format_exc()[-600:])
            time.sleep(0.002)
            err = (w.ctx.stage.error if w.ctx else "未打开") or (errs[0] if errs else None)
            if err:
                bad.append((q["id"], theme, key, err))
                print(f"{theme:5s} {q['id']:24s} {key:22s} ERR {err}", flush=True)
            if (theme, key) not in shot:
                shot.add((theme, key))
                w.grab().save(str(out / f"{key}-{theme}.png"))
    # 「做题 / 看讲解」两种状态（0.3.13）
    if not want:
        from .graph import lab_question
        q = next(q for q in bank.questions if len(q.get("steps") or []) >= 3)
        w.open(q["id"])
        app.processEvents()
        checks = [
            ("打开题库里的题默认是做题", w.mode == "do" and w.mode_seg.value == "do"),
            ("做题时不自动播放、步骤盖住、播放条收起", not w.auto_timer.isActive() and not w.playing and w.path_stack.currentIndex() == 0 and w.player_box.isHidden()),
        ]
        w.gate_btn.click()
        app.processEvents()
        checks.append(("点「看讲解」：步骤出来，稍后自动播放", w.mode == "learn" and w.path_stack.currentIndex() == 1 and not w.player_box.isHidden() and w.auto_timer.isActive()))
        w.open(q["id"])
        w.next_step()
        checks.append(("做题时按下一步：先切到讲解、停在第 1 步", w.mode == "learn" and w.step == 0 and not w.auto_timer.isActive()))
        # 0.3.14：画面本身露答案的视图（讲解顺序卡、数据图）做题时盖住；物理场景停在 t = 0
        fq = next(q for q in bank.questions if (q.get("view") or {}).get("mode") == "flow" and len(q.get("steps") or []) >= 2)
        w.open(fq["id"])
        app.processEvents()
        rev_do = bool(w._reveals()) and w.mode == "do"
        w.set_mode("learn", autoplay=False)
        checks.append(("讲解顺序卡：做题时盖住、看讲解时不盖", rev_do and w.mode == "learn"))
        pq = next((q for q in bank.questions if (q.get("view") or {}).get("engine") == "physics" and len(q.get("steps") or []) >= 2), None)
        if pq:
            w.open(pq["id"])
            for _ in range(30):
                app.processEvents()
                time.sleep(0.01)
            st = w.view.state
            checks.append(("物理题做题时场景不自己播放", w.mode == "do" and not st.playing and st.t == 0.0))
            w.set_mode("learn", autoplay=False)
            checks.append(("物理题看讲解后场景接着播", st.playing))
        w.open(q["id"])
        w.mine.setText("x")
        w.check_answer()
        w.mine.setText("")
        w.check_answer()
        checks.append(("对照结果另起一行，空输入后提示回到「先自己做」", w.gate_head.text() == "先自己做" and w.mine.width() >= 150))
        from .data import compare_answer
        judge = [("0.5", "1/2", True), ("−3", "-3", True), ("C", "D（脂肪只含 C、H、O）", False), ("A", "ABD", False),
                 ("[-1,2]", "(-1,2]", False), ("x>3", "x<3", False), ("DBA", "ABD", True), ("2000", "2×10^3", True), ("2", "ln2", False)]
        wrong = [(a, b) for a, b, e in judge if compare_answer(a, b)[0] != e]
        checks.append(("判分：分数小数、减号、选择题字母、区间开闭、不等号", not wrong))
        w.open_q(lab_question())
        checks.append(("变换实验室这类临时题直接是讲解", w.mode == "learn"))
        w.pause()
        for name, ok in checks:
            print(("ok   " if ok else "FAIL ") + name, flush=True)
            if not ok:
                bad.append(("mode", "", name, "FAIL"))
    print("BANK SELFTEST", "FAIL" if bad else "OK", total, "runs", len(bad), "errors", flush=True)
    sys.stdout.flush()
    return 1 if bad else 0


def main(argv=None):
    from PySide6.QtWidgets import QFileDialog
    saved=(QFileDialog.getSaveFileName,sys.excepthook)
    try:
        return _main(argv)
    finally:
        QFileDialog.getSaveFileName,sys.excepthook=saved


if __name__ == "__main__":
    raise SystemExit(test_runtime.run(main))
