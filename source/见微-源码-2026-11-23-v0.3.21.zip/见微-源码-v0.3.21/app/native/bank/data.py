"""题库：内置 questions.json（由 1.x 题库 JS 转换）+ 用户导入 / 自建的题。"""
from __future__ import annotations

import json
from pathlib import Path

from ..kit.home import load_json, save_json

SUBJECTS = ["全部", "数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理"]
IMPORTED = "bank-imported.json"


class Bank:
    def __init__(self):
        self.questions: list[dict] = []
        self.by_id: dict[str, dict] = {}
        self.loaded = False

    def load(self):
        if self.loaded:
            return self
        self.loaded = True
        raw = json.loads((Path(__file__).parent / "questions.json").read_text(encoding="utf-8"))
        for q in raw:
            self._add(q)
        for q in load_json(IMPORTED, []) or []:
            q["imported"] = True
            self._add(q)
        self.load_built()
        return self

    def load_built(self):
        """场景搭建器存的题：删掉的也要从列表里拿掉。"""
        keep = load_json("bank-built.json", []) or []
        ids = {q.get("id") for q in keep}
        for q in [x for x in self.questions if x.get("built") and x["id"] not in ids]:
            self.questions.remove(q)
            del self.by_id[q["id"]]
        for q in keep:
            q["built"] = True
            if q.get("id"):
                if not isinstance(q.get("year"), int):
                    q["year"] = 2026
                self._add(q)

    def _add(self, q):
        if not q or not q.get("id"):
            return
        q.setdefault("steps", [])
        if q["id"] in self.by_id:
            self.questions[self.questions.index(self.by_id[q["id"]])] = q
        else:
            self.questions.append(q)
        self.by_id[q["id"]] = q

    def add_imported(self, q):
        q["imported"] = True
        self._add(q)
        save_json(IMPORTED, [x for x in self.questions if x.get("imported")][-200:])

    def remove_imported(self, qid):
        q = self.by_id.get(qid)
        if q and q.get("imported"):
            self.questions.remove(q)
            del self.by_id[qid]
            save_json(IMPORTED, [x for x in self.questions if x.get("imported")])

    def related(self, q, n=3):
        """同一考点：知识点重合多的优先，其次同科目、同引擎；实在没有就给同科目的题。"""
        mine = [str(x) for x in q.get("points") or []]
        scored = []
        for x in self.questions:
            if x["id"] == q["id"]:
                continue
            ps = [str(p) for p in x.get("points") or []]
            s = sum(1 for p in ps if any(m == p or p in m or m in p for m in mine))
            if x.get("subject") == q.get("subject"):
                s += 0.4
            if (x.get("view") or {}).get("engine") == (q.get("view") or {}).get("engine"):
                s += 0.3
            if s >= 0.4:
                scored.append((s, x))
        scored.sort(key=lambda t: -t[0])
        return [x for _s, x in scored[:n]]

    def match(self, q, text):
        t = text.lower()
        hay = " ".join(str(q.get(k) or "") for k in ("title", "stem", "subject", "paper", "type", "year")) + " " + " ".join(str(p) for p in q.get("points") or [])
        return all(w in hay.lower() for w in t.split())


bank = Bank()


# ---- 答案对照（0.3.14 重写）：不是判卷，只回答「和参考答案对不对得上」
import math as _math
import re as _re
import unicodedata as _ud

_CJK = _re.compile(r"[一-鿿　-〿，；：]")
_ATOM = r"(?:\d+(?:\.\d+)?(?:e-?\d+)?)?(?:√\(?\d+(?:\.\d+)?\)?|π)|\d+(?:\.\d+)?(?:e-?\d+)?"
_NUM = _re.compile(rf"((?<![\w)}}\]])-)?({_ATOM})(?:/({_ATOM}))?(%)?")


def _norm(s):
    """全角转半角、各种减号统一、科学计数法改成 e 记法、去空白；大小写统一成小写。"""
    s = _ud.normalize("NFKC", str(s or ""))
    for k, v in (("−", "-"), ("–", "-"), ("—", "-"), ("﹣", "-"), (">=", "≥"), ("<=", "≤"), ("pi", "π"), ("×", "*"), ("·", "*")):
        s = s.replace(k, v)
    s = _re.sub(r"\s+", "", s)
    s = _re.sub(r"(\d)\*10\^\{?(-?\d+)\}?", r"\1e\2", s)
    s = _re.sub(r"(?<=\d),(?=\d{3}(?!\d))", "", s)          # 1,000 → 1000
    return s.replace("M/s", "m/s").lower()


def _strip_note(s):
    """去掉参考答案后面带中文的全角括号说明：「1:1:1:1（四种表现型各占 1/4）」→「1:1:1:1」。"""
    return _re.sub(r"（[^（）]*）", lambda m: "" if _CJK.search(m.group(0)) else m.group(0), str(s or ""))


def _atom(t):
    m = _re.fullmatch(r"(\d+(?:\.\d+)?(?:e-?\d+)?)?(?:√\(?(\d+(?:\.\d+)?)\)?|(π))?", t)
    if not m:
        return None
    coef = float(m.group(1)) if m.group(1) else 1.0
    if m.group(2):
        return coef * _math.sqrt(float(m.group(2)))
    if m.group(3):
        return coef * _math.pi
    return coef if m.group(1) else None


def _nums(s):
    """(值, 小数位数, 是否百分数) 列表；√3/3、2π、1.8e4、15% 都算一个数。"""
    out = []
    for m in _NUM.finditer(s):
        a = _atom(m.group(2))
        if a is None:
            continue
        if m.group(3):
            b = _atom(m.group(3))
            if not b:
                continue
            a /= b
        if m.group(1):
            a = -a
        dec = len(m.group(2).split(".")[1].split("e")[0]) if "." in m.group(2) and not m.group(3) and "√" not in m.group(2) else None
        out.append((a, dec, bool(m.group(4))))
    return out


def _same(r, m, approx):
    rv, rd, rp = r
    for v in ([rv / 100, rv] if rp else [rv]):
        for mv in ([m[0], m[0] / 100] if m[2] else [m[0]]):
            if _same1(v, rd, mv, m[1], approx):
                return True
    return False


def _same1(v, rd, mv, md, approx):
    d = abs(v - mv)
    if d <= 1e-6 * max(1.0, abs(v)):
        return True
    if approx and d <= 0.5 * 10 ** -(rd if rd is not None else 2) + 1e-9:
        return True                             # 参考答案「≈0.58」，我写 0.577
    if md is not None and md >= 1 and d <= 0.5 * 10 ** -md + 1e-9:
        return True                             # 我写的 0.58，参考是 √3/3：按我写的位数四舍五入对得上
    return False


def _shape(s):
    """区间的开闭括号和不等号序列；f(x) 这种函数括号不算。"""
    out = []
    for m in _re.finditer(r"[\(\[][^()\[\]]*,[^()\[\]]*[\)\]]|[<>≤≥≠]", s):
        t = m.group(0)
        out += [t] if len(t) == 1 else [t[0], t[-1]]
    return out


def choice_key(right):
    """选择题参考答案开头的字母（「D（脂肪只含 C、H、O）」→「D」）；不是选择题答案返回 None。"""
    s = _ud.normalize("NFKC", str(right or "")).strip()
    m = _re.match(r"([A-E]{1,4})(?=$|[\s,;.:、。，；：]|\((?![\d\-+]))", s)   # F(1,0) 是坐标，不是选项
    return "".join(sorted(set(m.group(1)))) if m else None


def choice_mine(mine):
    """「选C」「答案：c.」「Ｃ」「DBA」→ 字母集合；写的不是单纯字母返回 None。"""
    s = _ud.normalize("NFKC", str(mine or "")).upper()
    s = _re.sub(r"^(答案|选项|答|选)[:：]?", "", s.strip())
    s = _re.sub(r"[\s,，、.。;；()（）]", "", s)
    return "".join(sorted(set(s))) if _re.fullmatch(r"[A-G]{1,7}", s or "-") and len(set(s)) == len(s) else None


def grade_choice(mine, right):
    """选择题判对错：True / False；不是选择题或没写成字母返回 None。"""
    k, m = choice_key(right), choice_mine(mine)
    return None if k is None or m is None else m == k


def compare_answer(mine, right):
    """答案对照：选择题比字母集合；有数值的比数值（多重集）和括号、不等号；文字题比覆盖程度。返回 (ok, 文案)。"""
    if not str(mine or "").strip():
        return False, "先写点什么再对照"
    k = choice_key(right)
    if k is not None:
        m = choice_mine(mine)
        if m is not None:
            if m == k:
                return True, "选对了"
            if set(m) < set(k):
                return False, f"漏选了：参考答案选 {len(k)} 项"
            if set(m) > set(k):
                return False, "多选了"
            return False, "选项不对，看看讲解"
    a, b0 = _norm(mine), _norm(right)
    core = _norm(_strip_note(right))
    if a in (b0, core):
        return True, "完全一致"
    parts = [p for p in core.split("≈") if p]
    nb = _nums(parts[0]) if parts else []
    na = _nums(a)
    if nb:
        if not na:
            return False, "参考答案里有数值，先把结果算出来"
        best = None
        for i, p in enumerate(parts):
            want = _nums(p)
            left, hit = list(na), 0
            for r in want:
                j = next((j for j, m in enumerate(left) if _same(r, m, i > 0)), None)
                if j is not None:
                    left.pop(j)
                    hit += 1
            score = (hit == len(want), hit / max(1, len(want)), -len(left))
            if best is None or score > best[0]:
                best = (score, hit, len(want), len(left), p)
        (full, _r, _l), hit, total, extra, p = best
        if not full:
            return False, (f"对 {hit}/{total} 个数值，再检查一下" if hit else "数值和参考答案对不上")
        approx_mine = any(m[1] for m in na)          # 写成小数近似值时不要求有 √、π
        miss = [f for f in _re.findall(r"ln|lg|log|sin|cos|tan|√|π", p) if f not in a and not (approx_mine and f in "√π")]
        if miss:
            return False, f"数值对上了，但少了 {miss[0]}"
        shape_r, shape_m = _shape(p), _shape(a)
        if shape_r and shape_r != shape_m:
            return False, "数值对上了，但区间开闭或不等号和参考答案写法不同，核对一下"
        if extra and len(na) > total:
            return False, f"参考答案里的数都有，但多写了 {extra} 个，核对一下"
        return True, ("数值和范围写法都对上了" if shape_r else f"关键数值都对（{total} 个）")
    # 没有数值：文字题
    if len(a) >= 2 and (core in a or (a in core and len(a) >= 0.6 * len(core))):
        return True, "意思对上了"
    common = sum(1 for ch in set(a) if ch in core)
    if len(core) >= 4 and len(a) >= 2 and common >= 0.8 * len(set(core)):
        return True, "大体对上了，自己再核对一下用词"
    return False, "和参考答案不一致，点「显示答案」逐项比"
