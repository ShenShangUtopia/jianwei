"""原有题目视图的可选补图；不替换原图，不改题目和解答。"""


def attach(widget):
    from ..analysis.figure.bank_figures import load
    figure=load().get(widget.q.get("id"))
    if not figure:
        return widget
    from ..analysis.figure.view import FigureView
    view=FigureView(figure)
    view.setParent(widget.L.stage)
    view.hide()
    original=widget.render_fn
    enabled=[bool(figure.get("original_flow"))]
    def draw(width,height):
        if not enabled[0]:
            return original(width,height) if original else None
        view.k=min(len(view.stages)-1,max(0,widget.step))
        painter=widget.c.g.p
        painter.save()
        factor=min(width/1000,height/650)
        painter.translate((width-1000*factor)/2,(height-650*factor)/2)
        painter.scale(factor,factor)
        try:
            view.paint(painter)
        finally:
            painter.restore()
    widget.set(draw)
    def toggle(_button):
        enabled[0]=not enabled[0]
        widget.redraw()
    widget.L.group("本题补图")
    widget.L.button("切换原图 / 本题图解",toggle)
    widget.L.note("补图依题干、原有参数和程序计算生成；原有仿真和讲解保留。")
    widget._figure_view=view
    widget._fig_on=enabled          # 习题台：换成本题补图时画面不再是讲解步骤，做题时不用盖
    return widget
