"""习题台窗口（原生）：左题目列表，中间题面 + 图解 + 播放条，右侧解题路径 / 控件 / 补充材料。"""
from __future__ import annotations

from types import SimpleNamespace

import html as _html
import math
import time
import uuid

from PySide6.QtCore import QEvent, Qt, QTimer
from PySide6.QtGui import QImage, QKeyEvent, QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import (QAbstractButton, QAbstractSlider, QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QScrollArea, QStackedWidget, QTextEdit, QVBoxLayout, QWidget)

from ..design import tokens
from ..design.tokens import RADIUS, T, qc
from ..design.widgets import IconButton, Segmented, TabBar, qss  # noqa: F401
from ..kit.ctx import Ctx
from ..kit.draw import D, G
from ..lab.studio import NavList
from .data import SUBJECTS, bank, compare_answer
from .fx import fx
from .graph import lab_question
from .study import Stars, hint_html, match_card, related_to_card
from .tools import BuilderDialog, HelpDialog, ImportDialog
from .views import safe_mount

SPEEDS = (0.6, 1.0, 1.6)
BASE_MS = 2800
SUBJ_KEY = {"数学": "math", "物理": "phys", "化学": "chem", "生物": "bio"}


def _row(q):
    return ("item", SimpleNamespace(id=q["id"], title=q.get("title") or (q.get("stem") or "")[:18], unit=f"{q.get('subject', '')} · {q.get('paper', '')} · {q.get('type', '')}"))


class StepList(QWidget):
    """解题路径：一列可点的步骤（QLabel 富文本折行，当前步高亮）。"""

    def __init__(self, on_pick):
        super().__init__()
        self.on_pick = on_pick
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(14, 12, 14, 12)
        self.lay.setSpacing(6)
        self.rows: list[QPushButton] = []

    def set_steps(self, steps):
        while self.lay.count():
            w = self.lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        self.rows = []
        for i, s in enumerate(steps):
            text = s if isinstance(s, str) else (s.get("text") or s.get("title") or "")
            lb = _StepRow(i, text, self.on_pick)
            self.lay.addWidget(lb)
            self.rows.append(lb)
        if not steps:
            n = QLabel("这道题没有分步讲解。")
            n.setObjectName("note")
            self.lay.addWidget(n)
        self.lay.addStretch(1)

    def set_current(self, i):
        for k, r in enumerate(self.rows):
            r.set_state(k == i, k < i)


class _StepRow(QLabel):
    def __init__(self, i, text, on_pick):
        super().__init__()
        self.i, self.raw, self.on_pick = i, text, on_pick
        self.setWordWrap(True)
        self.setTextFormat(Qt.TextFormat.RichText)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setContentsMargins(10, 7, 10, 7)
        self.set_state(False, False)

    def set_state(self, cur, done):
        col = T.fg if cur else T.soft if done else T.muted
        self.setText(f"<span style='color:{qc(T.accent if cur else T.faint).name()};font-weight:700'>{self.i + 1}</span>&nbsp;&nbsp;<span style='color:{qc(col).name()}'>{fx(self.raw)}</span>")
        self.setStyleSheet(f"QLabel{{background:{tokens.css(T.accent, 0.1) if cur else 'transparent'};border-radius:8px;border-left:3px solid {qc(T.accent).name() if cur else 'transparent'};}}")

    def mousePressEvent(self, _e):  # noqa: N802
        self.on_pick(self.i)


class Desk(QWidget):
    def __init__(self, theme="day"):
        super().__init__()
        self.setObjectName("jw2")
        self.setWindowTitle("见微 · 习题台")
        self.resize(1360, 860)
        tokens.set_theme(theme)
        bank.load()
        self.subj = "全部"
        self.cur = None
        self.ctx = None
        self.view = None
        self.step = 0
        self.speed = 1.0
        self.touched = False
        self.play_timer = QTimer(self)
        self.play_timer.setSingleShot(True)
        self.play_timer.timeout.connect(self._tick_play)
        self.auto_timer = QTimer(self)   # 打开题目后稍等再自动讲解；人一动手就取消
        self.auto_timer.setSingleShot(True)
        self.auto_timer.timeout.connect(self._auto_play)
        self.playing = False
        self.stars = Stars()
        self.star_mode = False
        self.hint_level = 0
        self.guide_timer = QTimer(self)   # 播放时让引导圈跳动
        self.guide_timer.setInterval(40)
        self.guide_timer.timeout.connect(lambda: self.ctx.stage.update() if self.ctx else None)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._top())
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._rail())
        body.addWidget(self._center(), 1)
        body.addWidget(self._side())
        root.addLayout(body, 1)
        QShortcut(QKeySequence("Ctrl+F"), self, activated=lambda: self.search.setFocus())
        QShortcut(QKeySequence("Ctrl+Right"), self, activated=lambda: self.next_step())
        QShortcut(QKeySequence("Ctrl+Left"), self, activated=lambda: self.prev_step())
        QShortcut(QKeySequence("Ctrl+E"), self, activated=self.export_png)
        from PySide6.QtWidgets import QApplication
        QApplication.instance().installEventFilter(self)
        self.apply_theme()
        self.refresh_list()
        if bank.questions:
            self.open(bank.questions[0]["id"])

    # ---- 结构
    def _top(self):
        bar = QFrame()
        bar.setObjectName("topbar")
        bar.setFixedHeight(54)
        h = QHBoxLayout(bar)
        h.setContentsMargins(16, 0, 12, 0)
        h.setSpacing(10)
        b = QLabel("见微")
        b.setObjectName("brand")
        s = QLabel("习题台")
        s.setObjectName("brandSub")
        h.addWidget(b)
        h.addWidget(s)
        h.addSpacing(18)
        self.subj_bar = Segmented([(x, x) for x in SUBJECTS], "全部")
        self.subj_bar.changed.connect(self.set_subj)
        h.addWidget(self.subj_bar)
        h.addStretch(1)
        self.count = QLabel()
        self.count.setObjectName("brandSub")
        h.addWidget(self.count)
        self.search = QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("搜索题目、知识点…（Ctrl+F）")
        self.search.setFocusPolicy(Qt.FocusPolicy.ClickFocus)   # 打开窗口时焦点别落在输入框，否则快捷键要先点一下才有用
        self.search.setMinimumWidth(130)
        self.search.setMaximumWidth(240)
        self.search.textChanged.connect(lambda _t: self.refresh_list())
        h.addWidget(self.search)
        self.theme_btn = IconButton("moon", "切换昼 / 夜", 32)
        self.theme_btn.clicked.connect(lambda: (tokens.set_theme("day" if T.dark else "night"), self.apply_theme()))
        h.addWidget(self.theme_btn)
        return bar

    def resizeEvent(self, e):  # noqa: N802
        """0.3.14：窄窗口（学习窗口最小 1000 宽时习题台只有约 930）收紧左栏和底部一行，不让按钮文字竖排。"""
        super().resizeEvent(e)
        if not hasattr(self, "side_box"):
            return
        narrow = self.width() < 1150
        if getattr(self, "_narrow", None) == narrow:
            return
        self._narrow = narrow
        self.rail_box.setFixedWidth(250 if narrow else 270)
        self.side_box.setFixedWidth(300 if narrow else 340)
        for lb in (self.gate_note, self.gate_note2):
            lb.setFixedWidth((300 if narrow else 340) - 36)
        self.mine.setMinimumWidth(100 if narrow else 160)
        self.paint_star()
        for i, b in enumerate(self.hint_btns):
            b.setText(str(i + 1) if narrow else f"提示 {i + 1}")
            b.setMinimumWidth(34 if narrow else 0)
        self.ans_btn.setText(("答案" if narrow else "显示答案") if self.answer.isHidden() else ("收起" if narrow else "收起答案"))

    def _rail(self):
        box = QFrame()
        box.setObjectName("drawer")
        box.setFixedWidth(270)
        self.rail_box = box
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 8, 0, 0)
        v.setSpacing(6)
        tools = QHBoxLayout()
        tools.setContentsMargins(10, 0, 10, 0)
        tools.setSpacing(4)
        self.star_chip = self._btn("错题本", lambda: self.set_star_mode(not self.star_mode), tip="只看标过的错题")
        self.star_chip.setCheckable(True)
        tools.addWidget(self.star_chip, 1)
        tools.addWidget(self._btn("实验室", lambda: self.open_q(lab_question()), tip="变换实验室：选函数族，看平移、伸缩、旋转"), 1)
        tools.addWidget(self._btn("导入", self.show_import, tip="粘贴题目（I）"), 1)
        tools.addWidget(self._btn("搭建", self.show_builder, tip="物理场景搭建器（B）"), 1)
        v.addLayout(tools)
        self.nav = NavList()
        self.nav.picked.connect(self.pick_row)
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setWidget(self.nav)
        v.addWidget(sc)
        return box

    def _center(self):
        page = QWidget()
        ev = QVBoxLayout(page)
        ev.setContentsMargins(18, 12, 14, 12)
        ev.setSpacing(8)
        self.meta = QLabel()
        self.meta.setObjectName("note")
        self.title = QLabel()
        self.title.setTextFormat(Qt.TextFormat.RichText)
        self.stem = QLabel()
        self.stem.setWordWrap(True)
        self.stem.setTextFormat(Qt.TextFormat.RichText)
        self.stem.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        # 「做题 / 看讲解」两种状态：默认做题，讲解要自己点开（0.3.13，调研「习题台」问题 1）
        self.mode = "learn"
        self.mode_seg = Segmented([("do", "做题"), ("learn", "看讲解")], "do")
        self.mode_seg.setToolTip("做题：先自己写，卡住了用提示；看讲解：分步播放解题过程")
        self.mode_seg.changed.connect(lambda m: self.set_mode(m))
        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.addWidget(self.meta, 1)
        top.addWidget(self.mode_seg)
        ev.addLayout(top)
        ev.addWidget(self.title)
        ev.addWidget(self.stem)
        self.stage_host = QFrame()
        self.stage_host.setObjectName("stageHost")
        self.stage_lay = QVBoxLayout(self.stage_host)
        self.stage_lay.setContentsMargins(1, 1, 1, 1)
        ev.addWidget(self.stage_host, 1)
        ev.addWidget(self._player())
        ev.addWidget(self._foot())
        return page

    def _btn(self, text, cb, pri=False, tip=""):
        b = QPushButton(text)
        b.setObjectName("pri" if pri else "btn")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        if tip:
            b.setToolTip(tip)
        b.clicked.connect(lambda _=False: cb())
        return b

    def _player(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        self.prev_btn = self._btn("‹ 上一步", self.prev_step, tip="Ctrl+←")
        self.play_btn = self._btn("播放讲解", self.toggle_play, True)
        self.next_btn = self._btn("下一步 ›", self.next_step, tip="Ctrl+→")
        self.replay_btn = self._btn("重播", self.replay)
        self.speed_btn = self._btn("1×", self.cycle_speed, tip="播放速度")
        self.export_btn = self._btn("导出 PNG", self.export_png, tip="把当前画面存成图片（Ctrl+E）")
        self.step_info = QLabel()
        self.step_info.setObjectName("note")
        self.step_text = QLabel()
        self.step_text.setObjectName("note")
        self.step_text.setWordWrap(False)
        for x in (self.prev_btn, self.play_btn, self.next_btn, self.replay_btn, self.speed_btn, self.step_info):
            h.addWidget(x)
        h.addStretch(1)
        h.addWidget(self.export_btn)
        self.player_box = w
        return w

    def _foot(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.ans_btn = self._btn("显示答案", self.toggle_answer, True)
        self.mine = QLineEdit()
        self.mine.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.mine.setPlaceholderText("先写自己的答案，可只写数")
        self.mine.returnPressed.connect(self.check_answer)
        self.mine.setMinimumWidth(160)
        # 对照结果另起一行、可折行（以前挤在同一行，1280 宽时把输入框压到 48 像素）
        self.check_out = QLabel()
        self.check_out.setObjectName("note")
        self.check_out.setWordWrap(True)
        self.check_out.setVisible(False)
        _set = self.check_out.setText
        self.check_out.setText = lambda s: (_set(s), self.check_out.setVisible(bool(s)))   # 没字时不占一行
        row.addWidget(self.ans_btn)
        row.addWidget(self.mine, 1)
        row.addWidget(self._btn("对照", self.check_answer))
        self.hint_btns = []
        for i, nm in enumerate(("审题", "方法", "关键一步")):
            b = self._btn(f"提示 {i + 1}", lambda n=i + 1: self.toggle_hint(n), tip=f"第 {i + 1} 级：{nm}")
            b.setCheckable(True)
            self.hint_btns.append(b)
            row.addWidget(b)
        v.addLayout(row)
        v.addWidget(self.check_out)
        self.hint_box = QLabel()
        self.hint_box.setWordWrap(True)
        self.hint_box.setTextFormat(Qt.TextFormat.RichText)
        self.hint_box.setVisible(False)
        v.addWidget(self.hint_box)
        self.answer = QLabel()
        self.answer.setWordWrap(True)
        self.answer.setTextFormat(Qt.TextFormat.RichText)
        self.answer.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.answer.setVisible(False)
        v.addWidget(self.answer)
        return w

    def _side(self):
        box = QFrame()
        box.setObjectName("sidebar")
        box.setFixedWidth(340)
        self.side_box = box
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        self.star_btn = self._btn("标为错题", self.toggle_star, tip="S")
        self.star_btn.setCheckable(True)
        wrap = QWidget()
        wh = QVBoxLayout(wrap)
        wh.setContentsMargins(14, 8, 14, 6)
        wh.setSpacing(6)
        wh.addWidget(self.star_btn)
        wh.addWidget(self._btn("检查我的步骤 / 改条件重算", self.open_practice))   # 以前没放进带边距的布局，贴边越出侧栏
        wh.addWidget(self._btn("问 AI", self.ask_ai, tip="把这道题（题干、参考答案）带进 AI 聊天：讲解、变式、出题"))   # 0.3.18
        v.addWidget(wrap)
        self.tabs = TabBar(["解题路径", "控件", "补充"])
        v.addWidget(self.tabs)
        self.side_stack = QStackedWidget()
        self.tabs.changed.connect(self.side_stack.setCurrentIndex)
        self.steps = StepList(self.set_step)
        s1 = QScrollArea()
        s1.setWidgetResizable(True)
        s1.setWidget(self.steps)
        # 做题状态下「解题路径」页先盖一张卡：步骤不露出来，只有一个「看讲解」出口
        self.path_stack = QStackedWidget()
        self.gate = QWidget()
        gv = QVBoxLayout(self.gate)
        gv.setContentsMargins(18, 18, 18, 18)
        gv.setSpacing(10)
        self.gate_head = QLabel("先自己做")
        self.gate_head.setObjectName("grpTitle")
        # 两行说明分成两个标签、给定宽度：放在 QStackedWidget 里的折行标签不给宽度时高度算不对，行会叠在一起
        self.gate_note = QLabel()
        self.gate_note2 = QLabel()
        for lb in (self.gate_note, self.gate_note2):
            lb.setObjectName("note")
            lb.setWordWrap(True)
            lb.setFixedWidth(340 - 36)
        self.gate_btn = self._btn("看讲解", lambda: self.set_mode("learn"), True, tip="展开步骤并播放（空格）")
        gv.addWidget(self.gate_head)
        gv.addWidget(self.gate_note)
        gv.addWidget(self.gate_note2)
        gv.addWidget(self.gate_btn)
        gv.addStretch(1)
        self.path_stack.addWidget(self.gate)
        self.path_stack.addWidget(s1)
        self.side_stack.addWidget(self.path_stack)
        self.panel_scroll = QScrollArea()
        self.panel_scroll.setWidgetResizable(True)
        self.panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.side_stack.addWidget(self.panel_scroll)
        self.extra = QWidget()
        self.extra_lay = QVBoxLayout(self.extra)
        self.extra_lay.setContentsMargins(16, 12, 16, 12)
        self.extra_lay.setSpacing(8)
        s3 = QScrollArea()
        s3.setWidgetResizable(True)
        s3.setWidget(self.extra)
        self.side_stack.addWidget(s3)
        v.addWidget(self.side_stack, 1)
        return box

    # ---- 主题
    def apply_theme(self):
        t = T
        self.setStyleSheet(qss() + f"""
QFrame#topbar {{ background:{t.surface}; border-bottom:1px solid {t.line}; }}
QFrame#drawer {{ background:{t.surface}; border-right:1px solid {t.line}; }}
QFrame#sidebar {{ background:{t.surface}; border-left:1px solid {t.line}; }}
QFrame#stageHost {{ background:{t.stage}; border:1px solid {t.line2}; border-radius:{RADIUS['md']}px; }}
QLabel#brand {{ font-size:17px; font-weight:700; letter-spacing:2px; color:{t.fg}; }}
QLabel#brandSub {{ font-size:12px; color:{t.muted}; letter-spacing:1px; padding-top:3px; }}
QLineEdit#search {{ padding:5px 10px; background:{t.bg}; }}
""")
        self.theme_btn.icon = "sun" if T.dark else "moon"
        self.update()
        if self.cur:
            self._fill_text()
            self.steps.set_current(self.step)
        if self.ctx:
            self.ctx.draw()

    # ---- 列表
    def set_subj(self, s):
        self.subj = s
        self.refresh_list()

    def refresh_list(self):
        qt = self.search.text().strip()
        lst = [q for q in bank.questions if (self.subj == "全部" or q.get("subject") == self.subj) and (not qt or bank.match(q, qt)) and (not self.star_mode or self.stars.has(q["id"]))]
        rows = []
        for y in sorted({q.get("year") for q in lst}, key=lambda v: -(v or 0)):
            rows.append(("head", f"{y} 年"))
            rows += [_row(q) for q in lst if q.get("year") == y]
        if not rows:
            rows.append(("head", "错题本还是空的：打开一道题，点右上角「标为错题」。" if self.star_mode else "没有符合条件的题目"))
        self.nav.set_rows(rows, self.cur.get("id") if self.cur else None)
        ys = [q["year"] for q in bank.questions if (q.get("year") or 0) > 2000]
        self.count.setText(f"{len(bank.questions)} 题" + (f" · {min(ys)}—{max(ys)}" if ys else ""))

    # ---- 打开一道题
    def _close_view(self):
        self.pause()
        if self.ctx:
            self.ctx.dispose()
            self.ctx.stage.setParent(None)
            self.ctx.stage.deleteLater()
            self.ctx = None
            self.view = None

    def _fill_text(self):
        q = self.cur
        self.meta.setText(" · ".join(str(x) for x in (f"{q.get('year')} 年" if q.get("year") else None, q.get("paper"), q.get("subject"), q.get("type")) if x))
        self.title.setText(f"<span style='font-size:19px;font-weight:700;color:{qc(T.fg).name()}'>{q.get('title') or ''}</span>")
        self.stem.setText(f"<span style='color:{qc(T.soft).name()};font-size:13.5px'>{fx(q.get('stem') or '')}</span>")
        self.answer.setText(f"<span style='color:{qc(T.fg).name()};font-size:13.5px'><b>答案</b>　{fx(q.get('answer') or '')}</span>")
        self.paint_hints()

    def ask_ai(self):
        if self.cur:
            from ..chat import bridge
            from ..chat.core import question_attachment
            bridge.ask(self, [question_attachment(self.cur)], "")

    def open(self, qid):
        q = bank.by_id.get(qid)
        if q:
            self.open_q(q)

    def open_q(self, q):
        """打开一道题（题库里的，或自定义函数、知识块这种临时题）。"""
        self._close_view()
        self.cur = q
        self._opened_at=time.monotonic()
        self._attempt_event=uuid.uuid4().hex
        self.step = 0
        self.touched = False
        k = SUBJ_KEY.get(q.get("subject"))
        tokens.set_subject(k or "math")
        self._fill_text()
        self.answer.setVisible(False)
        self.ans_btn.setText("答案" if getattr(self, "_narrow", False) else "显示答案")
        self.hint_level = 0
        self.paint_hints()
        self.paint_star()
        self.mine.clear()
        self.check_out.setText("")
        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(18, 12, 18, 18)
        pv.setSpacing(4)
        self.ctx = Ctx(self.stage_host, panel)
        self.ctx.open_question = self.open_q
        self.stage_lay.addWidget(self.ctx.stage)
        self.ctx.stage.show()
        self.view, err = safe_mount(self.ctx, q)
        if err:
            self.ctx.stage.error = err
        pv.addStretch(1)
        self.panel_scroll.setWidget(panel)
        self.ctx.stage.overlays.append(self._draw_guide)
        self.ctx.stage.overlays.append(self._draw_cover)
        self._wrap_touch()
        self.steps.set_steps(q.get("steps") or [])
        self._fill_extra(q)
        self.apply_theme()
        self.refresh_list()
        self.set_step(0)
        # 题库里的题默认「做题」；实验室、自定义函数这类临时题本身就是拿来看的，直接讲解
        self.set_mode("do" if q.get("id") in bank.by_id and self.n_steps() >= 2 else "learn", autoplay=False)

    def set_mode(self, mode, autoplay=True):
        """做题：不播放、步骤盖住、播放条收起，留提示和「显示答案」；看讲解：步骤、播放条出来，三步以上自动播放。"""
        self.mode = mode
        self.mode_seg.set_value(mode)
        has = self.n_steps() >= 2
        self.mode_seg.setVisible(has)
        doing = mode == "do" and has
        if doing:
            self.pause()
            self.set_step(0)
            n = self.n_steps()
            self.gate_head.setText("先自己做")
            self.gate_note.setText("写下自己的答案，再点「对照」。卡住了按「提示 1 / 2 / 3」，一次多看一点。")
            self.gate_note2.setText(f"讲解一共 {n} 步，做完或实在想不出来再看。")
        # 物理场景：做题时停在 t = 0，不自己播到落点（落点就是答案）；看讲解时接着播
        stv = getattr(self.view, "state", None) if self.view else None
        if stv is not None and hasattr(stv, "playing") and getattr(self.view, "scene", None):
            if doing:
                stv.playing, stv.t = False, 0.0
            elif not getattr(stv, "playing", False) and not (self.cur.get("view") or {}).get("lesson"):
                stv.playing = True
        # 讲解顺序卡的「控件」页写着当前步骤：做题时也收起来
        pw = self.panel_scroll.widget()
        if pw is not None:
            pw.setVisible(not (doing and self._reveals()))
        self.path_stack.setCurrentIndex(0 if doing else 1)
        self.player_box.setVisible(self.n_steps() >= 2 and not doing)
        if self.ctx:
            self.ctx.stage.update()
        if not doing and autoplay and self.n_steps() >= 3:
            self.touched = False
            self.auto_timer.start(300)

    def _learn(self):
        """做题时按了播放、下一步之类的键：先切到讲解，不自动播放。"""
        if self.mode == "do" and self.n_steps() >= 2:
            self.set_mode("learn", autoplay=False)

    def _wrap_touch(self):
        """碰画布 = 自己看：暂停自动播放。"""
        st = self.ctx.stage
        inner = st.mouse

        def handler(kind, e):
            if kind == "down":
                self.touched = True
                self.pause()
            if inner:
                inner(kind, e)
        st.mouse = handler

    def _auto_play(self):
        if not self.touched and self.cur:
            self.play()

    def _fill_extra(self, q):
        lay = self.extra_lay
        while lay.count():
            w = lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        def head(t):
            h = QLabel(t)
            h.setObjectName("grpTitle")
            lay.addWidget(h)

        def para(t):
            n = QLabel(t)
            n.setWordWrap(True)
            n.setTextFormat(Qt.TextFormat.RichText)
            n.setObjectName("note")
            lay.addWidget(n)
        head("知识点（点开看知识卡）")
        pts = [str(p) for p in q.get("points") or []]
        for pt in pts:
            lay.addWidget(self._btn(pt, lambda t=pt: self.open_card(t)))
        if not pts:
            lay.addWidget(self._btn("通用审题卡", lambda: self.open_card("")))
        head("为什么这样想")
        para(fx(q.get("why") or "—"))
        if q.get("note"):
            head("说明")
            para(q["note"])
        head("同类题")
        rel = bank.related(q)
        for x in rel:
            lay.addWidget(self._btn(f"{x.get('subject')} · {x.get('title')}", lambda i=x["id"]: self.open(i)))
        if not rel:
            para("暂时没有同类题。")
        lay.addStretch(1)

    # ---- 知识卡（占用「补充」页，有返回）
    def open_card(self, text):
        c = match_card(text)
        lay = self.extra_lay
        while lay.count():
            w = lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        def para(t, obj="note", rich=True):
            n = QLabel(t)
            n.setWordWrap(True)
            n.setObjectName(obj)
            n.setTextFormat(Qt.TextFormat.RichText if rich else Qt.TextFormat.PlainText)
            lay.addWidget(n)
        lay.addWidget(self._btn("‹ 返回", lambda: self._fill_extra(self.cur)))
        def review_card():
            from .. import learning
            try:
                learning.add_card(c,c.get('s',''))
                self.check_out.setText('已加入间隔复习，可在今日页开始。')
            except Exception:
                self.check_out.setText('复习计划未能保存，原记录保留。')
        lay.addWidget(self._btn('加入间隔复习',review_card))
        para(f"知识卡 · {c.get('s') or '通用'}")
        name = QLabel(f"<span style='font-size:17px;font-weight:700;color:{qc(T.fg).name()}'>{_html.escape(c['n'])}</span>")
        lay.addWidget(name)
        n = QLabel(f"<span style='color:{qc(T.fg).name()}'>{fx(c['d'])}</span>")
        n.setWordWrap(True)
        lay.addWidget(n)
        para("常见公式 / 结论", "grpTitle")
        for t in c.get("f") or ["这张卡没有固定公式，按定义与审题顺序走。"]:
            para(f"<span style='color:{qc(T.fg).name()}'>{fx(t)}</span>")
        para("两个常见坑", "grpTitle")
        for i, t in enumerate(c.get("p") or []):
            para(f"{i + 1}. {fx(t)}")
        lst = related_to_card(c, text, self.cur)
        para(f"用这个知识点的题 · {len(lst)} 题", "grpTitle")
        for q in lst[:10]:
            lay.addWidget(self._btn(f"{q.get('subject', '')} · {q.get('title') or (q.get('stem') or '')[:18]}", lambda i=q["id"]: self.open(i)))
        if not lst:
            para("题库里暂时没有直接考它的题，先把公式和两个坑记住。")
        lay.addStretch(1)
        self.tabs.set_index(2)      # TabBar 的方法叫 set_index（以前写成 set_current，标签高亮不跟着切）
        self.side_stack.setCurrentIndex(2)

    # ---- 错题本与提示
    def paint_star(self):
        q = self.cur
        on = bool(q and q.get("id") and self.stars.has(q["id"]))
        self.star_btn.setChecked(on)
        self.star_btn.setText(f"{'已标错题 · 点击取消' if on else '标为错题'}　{len(self.stars.ids)}")
        self.star_chip.setChecked(self.star_mode)
        n = len(self.stars.ids)
        self.star_chip.setText(f"错题{n}" if getattr(self, "_narrow", False) else f"错题本 {n}")

    def toggle_star(self):
        if self.cur and self.cur.get("id"):
            self.stars.toggle(self.cur["id"])
            try:
                from .. import learning
                learning.sync_questions(self.stars.ids,bank.by_id)
            except Exception:
                self.check_out.setText('错题标记已保存，但复习计划未能更新。')
            self.paint_star()
            if self.star_mode:
                self.refresh_list()

    def set_star_mode(self, on):
        self.star_mode = bool(on)
        self.paint_star()
        self.refresh_list()

    def pick_row(self, qid):
        self.open(qid)

    def toggle_hint(self, n):
        self.hint_level = 0 if self.hint_level == n else n
        self.paint_hints()

    def paint_hints(self):
        for i, b in enumerate(self.hint_btns):
            b.setChecked(i + 1 <= self.hint_level)
        txt = hint_html(self.hint_level, self.cur, qc(T.accent).name(), qc(T.muted).name())
        self.hint_box.setText(f"<div style='color:{qc(T.fg).name()};font-size:13px'>{txt}</div>" if txt else "")
        self.hint_box.setVisible(bool(txt))

    # ---- 工具
    def _adopt(self, q):
        bank.add_imported(q)
        self.refresh_list()
        self.open(q["id"])

    def show_import(self):
        ImportDialog(self, self._adopt).exec()

    def show_builder(self):
        BuilderDialog(self, self.open_q).exec()
        bank.load_built()
        self.refresh_list()

    def compose_png(self):
        """画面 + 题头 + 当前步骤，拼成一张能直接发出去的图。"""
        st = self.ctx.stage
        pix = st.grab()
        W, H = pix.width(), pix.height()
        head, foot = 74, 46
        img = QImage(W, H + head + foot, QImage.Format.Format_RGB32)
        img.fill(qc(T.stage))
        p = QPainter(img)
        g = G(p)
        q = self.cur
        D.text(g, q.get("title") or "", 18, 26, T.fg, size=18, bold=True)
        D.text(g, " · ".join(str(x) for x in (q.get("year"), q.get("paper"), q.get("subject"), q.get("type")) if x), 18, 54, T.muted, size=12)
        p.drawPixmap(0, head, pix)
        steps = q.get("steps") or []
        s = steps[self.step] if self.step < len(steps) else ""
        s = s if isinstance(s, str) else (s.get("text") or s.get("title") or "")
        D.text(g, f"第 {self.step + 1} / {len(steps)} 步　{s}" if steps else "", 18, H + head + 18, T.fg, size=13)
        D.text(g, "见微", W - 18, H + head + 32, T.muted, size=11, align="right")
        p.end()
        return img

    def export_png(self):
        if not self.ctx or not self.cur:
            return None
        import re
        name = re.sub(r'[\\/:*?"<>|\s]+', "-", self.cur.get("title") or "见微")
        path, _f = QFileDialog.getSaveFileName(self, "导出 PNG", f"{name}.png", "PNG 图片 (*.png)")
        if path:
            self.compose_png().save(path)
        return path

    def eventFilter(self, obj, e):  # noqa: N802
        """全局快捷键：正在打字时不抢键。"""
        # 这个过滤器挂在整个应用上，每个事件都会进来：先用类型判断挡掉非键盘事件（比取事件类型便宜）
        if not isinstance(e, QKeyEvent) or e.type() != QEvent.Type.KeyPress or not self.isVisible() or not self.isActiveWindow():
            return False
        from PySide6.QtWidgets import QApplication
        fw = QApplication.focusWidget()
        k, mods = e.key(), e.modifiers()
        if k == Qt.Key.Key_Escape:
            if isinstance(fw, QLineEdit):
                fw.clearFocus()
                return True
            if self.cur:
                self._fill_extra(self.cur)
            return False
        if isinstance(fw, (QLineEdit, QTextEdit, QPlainTextEdit, QComboBox)) or mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier):
            return False
        if isinstance(fw, QAbstractSlider) and k in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            return False
        if isinstance(fw, QAbstractButton) and k == Qt.Key.Key_Space:
            return False
        t = e.text()
        act = {Qt.Key.Key_Left: self.prev_step, Qt.Key.Key_Right: self.next_step, Qt.Key.Key_Space: self.toggle_play}.get(k)
        if k == Qt.Key.Key_Space and getattr(self.view, "scene", None):
            act = self._learn if self.mode == "do" and self.n_steps() >= 2 else None   # 物理题的空格归时间轴；做题时先切到讲解
        if act is None:
            act = {"r": self.replay, "a": self.toggle_answer, "s": self.toggle_star, "i": self.show_import, "b": self.show_builder, "?": lambda: HelpDialog(self).exec(),
                   "1": lambda: self.toggle_hint(1), "2": lambda: self.toggle_hint(2), "3": lambda: self.toggle_hint(3)}.get(t.lower())
        if act:
            act()
            return True
        return False

    # ---- 步骤与播放
    def n_steps(self):
        return len((self.cur or {}).get("steps") or [])

    def set_step(self, i):
        n = self.n_steps()
        self.step = max(0, min(i, max(0, n - 1)))
        self.steps.set_current(self.step)
        self.step_info.setText(f"{self.step + 1} / {n}" if n else "")
        if self.view:
            try:
                self.view.apply_step(self.step)
            except Exception as exc:  # noqa: BLE001
                self.ctx.stage.error = f"{type(exc).__name__}: {exc}"

    def next_step(self):
        if self.mode == "do" and self.n_steps() >= 2:
            self._learn()
            return
        self.pause()
        self.set_step(self.step + 1)

    def prev_step(self):
        if self.mode == "do":
            return
        self.pause()
        self.set_step(self.step - 1)

    def replay(self):
        self._learn()
        self.set_step(0)
        self.play()

    def play(self):
        if self.n_steps() < 2:
            return
        self._learn()
        if self.step >= self.n_steps() - 1:
            self.set_step(0)
        self.playing = True
        self.play_btn.setText("暂停")
        self.play_timer.start(int(BASE_MS / self.speed))
        self.guide_timer.start()

    def pause(self):
        self.playing = False
        self.play_timer.stop()
        self.auto_timer.stop()
        self.guide_timer.stop()
        self.play_btn.setText("播放讲解")
        if self.ctx:
            self.ctx.stage.update()

    def toggle_play(self):
        self.pause() if self.playing else self.play()

    def _tick_play(self):
        if not self.playing:
            return
        if self.step >= self.n_steps() - 1:
            self.pause()
            return
        self.set_step(self.step + 1)
        self.play_timer.start(int(BASE_MS / self.speed))

    def cycle_speed(self):
        self.speed = SPEEDS[(SPEEDS.index(self.speed) + 1) % len(SPEEDS)]
        self.speed_btn.setText(f"{self.speed:g}×")

    def _reveals(self):
        """当前视图的画面会不会直接露出解题步骤或答案（讲解顺序卡、数据图）。换成本题补图时不算。"""
        v = self.view
        if not v or not getattr(v, "reveals", None):
            return None
        fig = getattr(v, "_fig_on", None)
        return None if fig and fig[0] else v.reveals

    def _draw_cover(self, g):
        """做题时盖住会露答案的画面（0.3.14：以前只盖了右栏步骤，画布上照样把步骤和结论画出来）。"""
        if self.mode != "do" or self.n_steps() < 2 or not self._reveals():
            return
        st = self.ctx.stage
        w, h = st.width(), st.height()
        D.rect(g, 0, 0, w, h, T.stage)
        D.text(g, "先自己做", w / 2, h / 2 - 16, T.fg, size=17, bold=True, align="center")
        D.text(g, f"这道题的画面是{self._reveals()}，会直接露出答案", w / 2, h / 2 + 14, T.muted, size=13, align="center")
        D.text(g, "点「看讲解」后再展开", w / 2, h / 2 + 36, T.muted, size=13, align="center")

    def _draw_guide(self, g):
        """引导层：播放时把当前步骤写到画面上；视图给出 focus(i) 就在图上圈出来。"""
        if not self.playing or not self.cur:
            return
        steps = self.cur.get("steps") or []
        fn = getattr(self.view, "focus", None)
        f = fn(self.step) if fn else None
        if f:
            k = (math.sin(time.perf_counter() * 4) + 1) / 2
            D.circle(g, f["x"], f["y"], f.get("r", 20) + 5 * k, None, T.accent, 2)
        if self.step < len(steps):
            s = steps[self.step]
            s = s if isinstance(s, str) else (s.get("text") or s.get("title") or "")
            w = self.ctx.stage.width()
            import re
            s = re.sub(r"\\[a-z]+|[{}]", "", s)
            # 函数图右下角有一排视野键：提示条靠左放，长句截断，不压按钮
            engine = (self.cur or {}).get("view", {}).get("engine") if isinstance(self.cur, dict) else None
            room = w - 24 - (280 if engine == "graph" else 0)
            if D.measure(s, 13) + 56 > room:
                while s and D.measure(s + "…", 13) + 56 > room:
                    s = s[:-1]
                s += "…"
            tw = min(D.measure(s, 13) + 56, room)
            x0 = 12 if engine == "graph" else (w - tw) / 2
            y0 = self.ctx.stage.height() - (72 if getattr(self.view, "scene", None) else 46)
            D.rrect(g, x0, y0, tw, 30, 15, tokens.alpha(qc(T.fg), 0.86))
            D.text(g, str(self.step + 1), x0 + 18, y0 + 15, T.stage, size=12, bold=True, align="center")
            D.text(g, s, x0 + 34, y0 + 15, T.stage, size=13)

    # ---- 答案
    def toggle_answer(self):
        on = self.answer.isHidden()
        self.answer.setVisible(on)
        narrow = getattr(self, "_narrow", False)
        self.ans_btn.setText(("收起" if narrow else "收起答案") if on else ("答案" if narrow else "显示答案"))

    def open_practice(self):
        if not self.cur:
            return
        from ..analysis import lesson
        from ..analysis.practice_ui import PracticeDialog
        value=lesson.analyze_offline(self.cur['stem'])
        if not value.get('taskRes'):
            from PySide6.QtWidgets import QMessageBox
            top=self.window()
            can=top is not self and hasattr(top,'page')
            # 0.3.14：以前关掉提示就强行跳到析题，还把析题里已经写的内容整个覆盖
            if not can:
                QMessageBox.information(self,'这道题还不能检查步骤','本题没有离线参数模型，不能从答案相似度猜测错在哪一步。')
                return
            r=QMessageBox.question(self,'这道题还不能检查步骤','本题没有离线参数模型，不能从答案相似度猜测错在哪一步。\n\n要把题目带到「析题」里建立模型吗？')
            if r!=QMessageBox.StandardButton.Yes:
                return
            top.goto('analysis')
            box=top.page('analysis').text
            if not box.toPlainText().strip() or box.toPlainText().strip()==self.cur['stem'].strip():
                box.setPlainText(self.cur['stem'])
            elif QMessageBox.question(self,'析题里已经有内容','析题里已经有一道题。换成这道吗？')==QMessageBox.StandardButton.Yes:
                box.setPlainText(self.cur['stem'])
            return
        dialog=PracticeDialog(value,self,reference=dict(question=self.cur['id']))
        dialog.student.setPlainText(self.mine.text())
        def use_variant(new):
            top=self.window()
            if top is not self and hasattr(top,'page'):
                top.goto('analysis')
                analysis=top.page('analysis')
                analysis.rev+=1
                analysis._on_done(analysis.rev,new)
        dialog.variant_ready.connect(use_variant)
        dialog.exec()

    def check_answer(self):
        if self.cur:
            ok, msg = compare_answer(self.mine.text(), self.cur.get("answer"))
            self.check_out.setText(msg)
            self.check_out.setStyleSheet(f"color:{qc(T.ok if ok else T.bad).name()};")
            if self.mode == "do":
                self.gate_head.setText(("对照完了，看看讲解" if ok else "没对上：再试一次，或者看讲解") if self.mine.text().strip() else "先自己做")
            if self.mine.text().strip():
                from .. import learning
                from .data import grade_choice, _nums, _norm, _strip_note
                # 选择题按字母判；单选、填空里答案是数值的，按数值对照的结果记（0.3.14：以前 60 道单选里 42 道记成未判定）
                correct = grade_choice(self.mine.text(), self.cur.get('answer', ''))
                if correct is None and str(self.cur.get('type', '')) in ('单选', '填空') and _nums(_norm(_strip_note(self.cur.get('answer', '')))):
                    correct = ok
                objective = correct is not None
                if not self.cur.get('id'):
                    return
                try:
                    learning.record(self.cur['id'],self.cur.get('subject',''),time.monotonic()-self._opened_at,correct=correct,source='program' if objective else 'ungraded',event_id=self._attempt_event)
                except Exception:
                    self.check_out.setText(msg+'；学习记录未能保存，原记录保留。')
