"""新界面的设计截图（B2 用，不是自测组）：三种风格 × 昼夜 × 1280 / 1920 × 新页面，外加三种布局、1000×620 小窗口、
番茄小窗、提醒卡片、AI 排计划窗口；老板块（今日、习题台模块）也截一张作对照。

用法（离屏、隔离数据目录）：python -m native.focus.design_shots <输出目录>
"""
from ..kit import test_runtime
test_runtime.configure()
import os
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path


def seed():
    from . import core, plan
    from ..exam import grade, paper, records
    from .. import learning
    ex = paper.new_exam(paper.from_bank("数学", 6, ["单选"], seed=3), "十一月月考", "数学")
    ex["answers"] = {}
    ex["report"] = grade.offline(ex)
    ex["submitted"] = time.time() - 86400
    records.upsert(ex)
    learning.add_card(dict(n="动量守恒", d="系统合外力为零", f=[], p=[]), "物理")
    t = date.today()
    for d, h, m, s, task in ((0, 8, 45, "数学", "导数大题"), (0, 10, 30, "英语", "完形填空"), (0, 14, 60, "物理", "电磁感应"),
                             (0, 19, 45, "化学", "方程式配平"), (1, 9, 45, "语文", "古诗默写"), (2, 19, 90, "数学", "月考")):
        b = plan.add((t + timedelta(days=d)).isoformat(), h * 60, m, s, task, "exam" if task == "月考" else "self")
        if d == 0 and h == 8:
            plan.update(b["id"], done=True, focused=2700)
    plan.add(t.isoformat(), 20 * 60 + 30, 30, "生物", "遗传图解", subtasks=["画图", "算概率"])
    base = datetime.combine(t, datetime.min.time()).timestamp()
    for h, s, f in ((8.1, "数学", 25), (8.6, "数学", 20), (10.6, "英语", 25)):
        core.add_session(dict(day=t.isoformat(), start=base + h * 3600, end=base + h * 3600 + f * 60, focus=f * 60, status="done",
                              subject=s, task="", interruptions=[]))
    plan.save_review_text("day", t - timedelta(days=1), "数学拖了，今天先做导数")


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    import store
    real = Path.home() / "AppData" / "Local" / "Jianwei"
    if not os.environ.get("JIANWEI_HOME") or os.path.realpath(store.HOME) == os.path.realpath(real):
        raise SystemExit("JIANWEI_HOME 没有指向隔离目录")
    seed()

    def spin(sec=0.08):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from shell import Shell
    cfg = store.load_config()
    cfg.update(autoFetch=False, autoEvening=False, prewarmWeb=False)
    store.save_config(cfg)
    sh = Shell(tray_enabled=False, jobs_enabled=False)
    sh.show()
    shots = []

    def page_shots(tag):
        for key, tabs in (("exam", ("exam", "stats")), ("focus", ("pomo", "plan", "review")), ("recite", (None,)), ("chat", (None,))):
            sh.goto(key, animate=False)
            spin()
            cur = sh.stack.currentWidget()
            inner = getattr(cur, key, None)
            for tab in tabs:
                if tab and inner is not None:
                    inner.show_tab(tab)
                    spin()
                name = f"{tag}-{key}" + (f"-{tab}" if tab else "") + ".png"
                sh.grab().save(str(out / name))
                shots.append(name)

    sh.set_page_layout("pages")
    for skin in ("ink", "celadon", "doodle"):
        for mode in ("day", "night"):
            sh._apply_look(mode, skin)
            for w, h in ((1280, 720), (1920, 1080)):
                sh.resize(w, h)
                spin()
                page_shots(f"{skin}-{mode}-{w}")
        sh._apply_look("day", skin)
        sh.resize(1000, 620)
        spin()
        page_shots(f"{skin}-day-1000")
        sh.resize(1280, 720)
        for lay in ("desktop", "workspace"):
            sh.set_page_layout(lay)
            spin()
            sh.grab().save(str(out / f"{skin}-{lay}.png"))
            sh.goto("focus", animate=False)
            spin()
            sh.grab().save(str(out / f"{skin}-{lay}-focus.png"))
        sh.set_page_layout("pages")
        sh.goto("today", animate=False)
        spin()
        sh.grab().save(str(out / f"{skin}-today.png"))
    # 小窗、卡片、AI 排计划
    from .engine import engine
    from .floater import floater
    from .notify import card
    eng = engine()
    for skin in ("ink", "doodle"):
        for mode in ("day", "night"):
            sh._apply_look(mode, skin)
            eng.start("数学", "导数大题")
            fl = floater()
            fl.sync()
            spin()
            fl.grab().save(str(out / f"float-{skin}-{mode}-focus.png"))
            eng.skip()
            spin()
            fl.grab().save(str(out / f"float-{skin}-{mode}-break.png"))
            eng.abandon()
            nc = card()
            nc.push(dict(key=f"k{skin}{mode}", kind="block", title="计划到点", text="5 分钟后（19:00）开始：数学 导数大题（已顺延 1 次）"))
            spin()
            nc.grab().save(str(out / f"notice-{skin}-{mode}.png"))
            nc.act("skip")
            from .aiplan_page import open_dialog
            dlg = open_dialog(sh)
            dlg.panel.generate(sync=True)
            spin()
            dlg.grab().save(str(out / f"aiplan-{skin}-{mode}.png"))
            dlg.close()
    eng.timer.stop()
    sh.close()
    print("SHOTS", len(shots) + 1, out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
