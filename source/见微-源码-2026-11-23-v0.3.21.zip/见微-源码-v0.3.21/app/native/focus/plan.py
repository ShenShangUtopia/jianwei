"""自由安排：长期目标 → 周计划 → 日计划 → 时间块，每层都能看完成度。

数据 focus-plan.json（v2，v1 读进来自动补字段）：
  blocks   [{id, day, start(当天第几分钟), minutes, subject, task, source, ref, done, focused(秒), reminded,
             priority(0 低 / 1 中 / 2 高), pomos(预计番茄数，0＝按时长算), deadline, subtasks[{t, done}],
             rep(重复模板 id), carried(顺延了几次), orig(最早排在哪天), why(为什么这样排)}]
  repeats  [{id, rule(daily|weekday|weekly), days[0–6], start, minutes, subject, task, source, priority, since, skip[日期]}]
  goals    {total(高考目标总分), subjects{科目: 目标分}, note}
  weeks    {周一日期: {goals[{t, done}], note}}
  reviews  {"d:日期" / "w:周一日期": {text, t}}
  avail    {weekday[[开始, 结束]…], weekend[[开始, 结束]…]}   每天可用时段（分钟）
  rolled   上次顺延检查的日期
source：self 自己写 / review 复习到期 / preview 预习单 / weak 考情薄弱点 / recite 背诵 / exam 考试 / ai AI 排的。
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta

from ..kit.home import load_json, save_json

FILE = "focus-plan.json"
DAY_START, DAY_END = 6 * 60, 23 * 60          # 计划表画 6:00–23:00
STEP = 15                                       # 拖动按 15 分钟对齐
SOURCES = dict(self="自己", review="复习", preview="预习", weak="薄弱点", recite="背诵", exam="考试", ai="AI")
PRIORITY = {0: "低", 1: "中", 2: "高"}
RULES = dict(none="不重复", daily="每天", weekday="工作日", weekly="每周几")
FULL = dict(语文=150, 数学=150, 英语=150, 物理=100, 化学=100, 生物=100, 历史=100, 地理=100, 政治=100)
AVAIL = dict(weekday=[[18 * 60 + 30, 22 * 60 + 30]],
             weekend=[[8 * 60 + 30, 11 * 60 + 30], [14 * 60, 17 * 60 + 30], [19 * 60, 22 * 60]])
POMO = 25                                       # 估番茄数时一个按 25 分钟算
_BLOCK_DEFAULTS = dict(priority=1, pomos=0, deadline="", subtasks=[], rep="", carried=0, orig="", why="")


def _load():
    d = load_json(FILE, None)
    if not isinstance(d, dict) or d.get("v") not in (1, 2) or not isinstance(d.get("blocks"), list):
        d = dict(v=2, blocks=[])
    d["v"] = 2
    for b in d["blocks"]:
        for k, v in _BLOCK_DEFAULTS.items():
            b.setdefault(k, list(v) if isinstance(v, list) else v)
    d.setdefault("repeats", [])
    d.setdefault("goals", dict(total=0, subjects={}, note=""))
    d.setdefault("weeks", {})
    d.setdefault("reviews", {})
    d.setdefault("avail", {k: [list(x) for x in v] for k, v in AVAIL.items()})
    d.setdefault("rolled", "")
    return d


def _write(d):
    keep = (date.today() - timedelta(days=120)).isoformat()
    d["blocks"] = [b for b in d["blocks"] if b.get("day", "") >= keep][-3000:]
    save_json(FILE, d)


def _save(bs):
    d = _load()
    d["blocks"] = bs
    _write(d)


def blocks(day=None) -> list[dict]:
    bs = _load()["blocks"]
    if day is not None:
        day = str(day)
        bs = [b for b in bs if b.get("day") == day]
    return sorted(bs, key=lambda b: (b.get("day", ""), b.get("start", 0)))


def hhmm(minutes) -> str:
    m = int(minutes)
    return f"{m // 60:02d}:{m % 60:02d}"


def parse_hhmm(s, default=None):
    try:
        h, m = str(s).strip().replace("：", ":").split(":")
        h, m = int(h), int(m)
        if 0 <= h < 24 and 0 <= m < 60:
            return h * 60 + m
    except (ValueError, AttributeError):
        pass
    return default


def snap(minutes) -> int:
    return int(round(minutes / STEP) * STEP)


def _clamp(start, minutes):
    minutes = max(STEP, min(DAY_END - DAY_START, snap(minutes)))
    start = max(DAY_START, min(DAY_END - minutes, snap(start)))
    return start, minutes


def _clean_subtasks(subs):
    out = []
    for s in subs or []:
        if isinstance(s, str):
            s = dict(t=s, done=False)
        t = str(s.get("t", "")).strip()[:60]
        if t:
            out.append(dict(t=t, done=bool(s.get("done"))))
    return out[:12]


def add(day, start, minutes, subject="", task="", source="self", ref="", **extra) -> dict:
    start, minutes = _clamp(start, minutes)
    b = dict(id=uuid.uuid4().hex[:10], day=str(day), start=start, minutes=minutes, subject=subject, task=str(task)[:80],
             source=source if source in SOURCES else "self", ref=str(ref), done=False, focused=0.0, reminded=False)
    for k, v in _BLOCK_DEFAULTS.items():
        b[k] = list(v) if isinstance(v, list) else v
    b.update({k: v for k, v in extra.items() if k in _BLOCK_DEFAULTS})
    b["subtasks"] = _clean_subtasks(b["subtasks"])
    b["priority"] = max(0, min(2, int(b["priority"])))
    d = _load()
    d["blocks"].append(b)
    _write(d)
    return b


def update(bid, **kw) -> dict | None:
    d = _load()
    for b in d["blocks"]:
        if b["id"] == bid:
            if "day" in kw:
                kw["day"] = str(kw["day"])
            if "subtasks" in kw:
                kw["subtasks"] = _clean_subtasks(kw["subtasks"])
            if "priority" in kw:
                kw["priority"] = max(0, min(2, int(kw["priority"])))
            if "task" in kw:
                kw["task"] = str(kw["task"])[:80]
            b.update(kw)
            if "start" in kw or "minutes" in kw:
                b["start"], b["minutes"] = _clamp(b["start"], b["minutes"])
                b["reminded"] = False
            _write(d)
            return b
    return None


def move(bid, day, start):
    return update(bid, day=day, start=start)


def resize(bid, minutes):
    return update(bid, minutes=minutes)


def remove(bid):
    d = _load()
    b = next((x for x in d["blocks"] if x["id"] == bid), None)
    if b and b.get("rep"):                      # 删掉重复生成的某一天：记下，别再生成回来
        for r in d["repeats"]:
            if r["id"] == b["rep"] and b["day"] not in r.setdefault("skip", []):
                r["skip"].append(b["day"])
    d["blocks"] = [x for x in d["blocks"] if x["id"] != bid]
    _write(d)


def get(bid):
    return next((b for b in _load()["blocks"] if b["id"] == bid), None)


def toggle_subtask(bid, i) -> dict | None:
    b = get(bid)
    if not b or not 0 <= i < len(b["subtasks"]):
        return b
    subs = b["subtasks"]
    subs[i]["done"] = not subs[i]["done"]
    done = b["done"] or (bool(subs) and all(s["done"] for s in subs))
    return update(bid, subtasks=subs, done=done)


def pomos_of(b) -> int:
    return int(b.get("pomos") or 0) or max(1, round(b["minutes"] / POMO))


def next_free(day, minutes, after=None) -> int:
    """这一天第一个放得下 minutes 的空档（从 after 或现在往后，15 分钟对齐）。没有就放在最后。"""
    taken = [(b["start"], b["start"] + b["minutes"]) for b in blocks(day)]
    now = datetime.now()
    t = after if after is not None else (snap(now.hour * 60 + now.minute + 7) if str(day) == now.date().isoformat() else 8 * 60)
    t = max(DAY_START, snap(t))
    while t + minutes <= DAY_END:
        if all(t + minutes <= a or t >= b for a, b in taken):
            return t
        t += STEP
    return DAY_END - minutes


def add_focus(bid, seconds, done_ratio=0.8):
    """番茄挂在这个块上：累计专注秒数，够块时长的八成算完成。"""
    b = get(bid)
    if b is None:
        return None
    f = float(b.get("focused") or 0) + float(seconds)
    return update(bid, focused=round(f, 1), done=b.get("done") or f >= b["minutes"] * 60 * done_ratio)


def due_reminders(now: datetime) -> list[dict]:
    """（0.3.16 的老接口，0.3.19 起提醒走 remind.check）到点（开始后 10 分钟内）还没提醒过的块。"""
    bs = _load()["blocks"]
    day, m = now.date().isoformat(), now.hour * 60 + now.minute
    out = []
    for b in bs:
        if b.get("day") == day and not b.get("reminded") and not b.get("done") and b["start"] <= m < b["start"] + 10:
            b["reminded"] = True
            out.append(dict(b))
    if out:
        _save(bs)
    return out


# ---------------------------------------------------------------- 重复规则
def _matches(r, d: date) -> bool:
    if d.isoformat() in (r.get("skip") or []) or d.isoformat() < r.get("since", ""):
        return False
    wd = d.weekday()
    rule = r.get("rule")
    return rule == "daily" or (rule == "weekday" and wd < 5) or (rule == "weekly" and wd in (r.get("days") or []))


def repeats() -> list[dict]:
    return _load()["repeats"]


def set_repeat(bid, rule, days=None) -> dict | None:
    """给一块设重复规则（none 取消）。这一块成为第一次；以后的块按规则生成。改规则时，以后还没做的重新生成。"""
    d = _load()
    b = next((x for x in d["blocks"] if x["id"] == bid), None)
    if b is None:
        return None
    days = sorted({int(x) for x in (days or []) if 0 <= int(x) <= 6})
    old = b.get("rep")
    if old:      # 去掉这块以后的、没做的生成块，模板删掉或改掉
        d["blocks"] = [x for x in d["blocks"] if not (x.get("rep") == old and x["day"] > b["day"] and not x.get("done"))]
        d["repeats"] = [r for r in d["repeats"] if r["id"] != old]
        b["rep"] = ""
    if rule in ("daily", "weekday", "weekly") and (rule != "weekly" or days):
        r = dict(id=uuid.uuid4().hex[:8], rule=rule, days=days, start=b["start"], minutes=b["minutes"],
                 subject=b.get("subject", ""), task=b.get("task", ""), source=b.get("source", "self"),
                 priority=b.get("priority", 1), pomos=b.get("pomos", 0), subtasks=[dict(t=s["t"], done=False) for s in b["subtasks"]],
                 since=b["day"], skip=[])
        d["repeats"].append(r)
        b["rep"] = r["id"]
    _write(d)
    return b


def ensure_repeats(days, today=None) -> int:
    """按重复规则把这些天（只管今天以后）缺的块补上。返回补了几块。"""
    today = today or date.today()
    d = _load()
    have = {(b.get("rep"), b["day"]) for b in d["blocks"] if b.get("rep")}
    n = 0
    for day in days:
        if day < today:
            continue
        for r in d["repeats"]:
            if (r["id"], day.isoformat()) in have or not _matches(r, day):
                continue
            b = dict(id=uuid.uuid4().hex[:10], day=day.isoformat(), start=r["start"], minutes=r["minutes"], subject=r["subject"],
                     task=r["task"], source=r.get("source", "self"), ref="", done=False, focused=0.0, reminded=False)
            b.update({k: (list(v) if isinstance(v, list) else v) for k, v in _BLOCK_DEFAULTS.items()})
            b.update(priority=r.get("priority", 1), pomos=r.get("pomos", 0), rep=r["id"],
                     subtasks=[dict(t=s["t"], done=False) for s in r.get("subtasks") or []])
            d["blocks"].append(b)
            n += 1
    if n:
        _write(d)
    return n


def repeat_rule(b) -> tuple[str, list[int]]:
    r = next((x for x in repeats() if x["id"] == b.get("rep")), None) if b and b.get("rep") else None
    return (r["rule"], list(r.get("days") or [])) if r else ("none", [])


# ---------------------------------------------------------------- 顺延
def rollover(today: date | None = None, now_min: int | None = None) -> list[dict]:
    """没做完的块顺延到今天（一天只做一次）：放进今天第一个空档，carried + 1，记下最早排在哪天。
    考试块和重复生成的块不顺延（重复的明天自己会再有）。只看最近 7 天。"""
    today = today or date.today()
    d = _load()
    if d.get("rolled") == today.isoformat():
        return []
    lo = (today - timedelta(days=7)).isoformat()
    moved = []
    av = avail_for(today, d)
    after = max([av[0][0]] if av else [8 * 60])
    if now_min is not None:
        after = max(after, snap(now_min + 7))
    taken = [(b["start"], b["start"] + b["minutes"]) for b in d["blocks"] if b["day"] == today.isoformat()]
    for b in sorted(d["blocks"], key=lambda x: (-x.get("priority", 1), x["day"], x["start"])):
        if not (lo <= b["day"] < today.isoformat()) or b.get("done") or b.get("source") == "exam" or b.get("rep"):
            continue
        t = max(DAY_START, snap(after))
        while t + b["minutes"] <= DAY_END and not all(t + b["minutes"] <= x or t >= y for x, y in taken):
            t += STEP
        if t + b["minutes"] > DAY_END:
            t = DAY_END - b["minutes"]
        b["orig"] = b.get("orig") or b["day"]
        b.update(day=today.isoformat(), start=t, carried=int(b.get("carried") or 0) + 1, reminded=False)
        taken.append((t, t + b["minutes"]))
        moved.append(dict(b))
    d["rolled"] = today.isoformat()
    _write(d)
    return moved


# ---------------------------------------------------------------- 可用时段 / 目标 / 周目标 / 复盘文字
def avail() -> dict:
    return _load()["avail"]


def avail_for(day: date, d=None) -> list[list[int]]:
    d = d or _load()
    return [list(x) for x in d["avail"]["weekend" if day.weekday() >= 5 else "weekday"]]


def parse_ranges(text) -> list[list[int]]:
    """「18:30-22:30, 8:00-11:00」→ [[1110, 1350], [480, 660]]，不合法的段丢掉，按开始排序。"""
    out = []
    for part in str(text).replace("，", ",").replace("；", ",").replace(";", ",").split(","):
        part = part.strip().replace("—", "-").replace("–", "-").replace("~", "-")
        if "-" not in part:
            continue
        a, b = part.split("-", 1)
        a, b = parse_hhmm(a), parse_hhmm(b)
        if a is not None and b is not None and b - a >= STEP:
            out.append([max(DAY_START, a), min(DAY_END, b)])
    return sorted(out)


def ranges_text(rs) -> str:
    return ", ".join(f"{hhmm(a)}-{hhmm(b)}" for a, b in rs)


def set_avail(weekday=None, weekend=None):
    d = _load()

    def clean(rs):                       # 夹到计划表范围 6:00–23:00，太短的段丢掉
        return sorted([max(DAY_START, int(a)), min(DAY_END, int(b))] for a, b in rs if min(DAY_END, int(b)) - max(DAY_START, int(a)) >= STEP)
    if weekday is not None:
        d["avail"]["weekday"] = clean(weekday)
    if weekend is not None:
        d["avail"]["weekend"] = clean(weekend)
    _write(d)


def goals() -> dict:
    return _load()["goals"]


def set_goals(total=None, subjects=None, note=None):
    d = _load()
    g = d["goals"]
    if total is not None:
        g["total"] = max(0, min(750, int(total)))
    if subjects is not None:
        g["subjects"] = {k: max(0, min(FULL.get(k, 150), int(v))) for k, v in subjects.items() if int(v) > 0}
    if note is not None:
        g["note"] = str(note)[:200]
    _write(d)
    return g


def week_key(day: date) -> str:
    return (day - timedelta(days=day.weekday())).isoformat()


def week(day: date) -> dict:
    w = _load()["weeks"].get(week_key(day)) or {}
    return dict(goals=list(w.get("goals") or []), note=w.get("note", ""))


def set_week(day: date, goals_=None, note=None):
    d = _load()
    w = d["weeks"].setdefault(week_key(day), dict(goals=[], note=""))
    if goals_ is not None:
        w["goals"] = _clean_subtasks(goals_)
    if note is not None:
        w["note"] = str(note)[:200]
    _write(d)
    return w


def review_text(kind, day: date) -> str:
    key = ("d:" + day.isoformat()) if kind == "day" else ("w:" + week_key(day))
    return (_load()["reviews"].get(key) or {}).get("text", "")


def save_review_text(kind, day: date, text, now=None):
    d = _load()
    key = ("d:" + day.isoformat()) if kind == "day" else ("w:" + week_key(day))
    d["reviews"][key] = dict(text=str(text).strip()[:200], t=(now or datetime.now()).timestamp())
    _write(d)


# ---------------------------------------------------------------- 完成度
def _sessions_on(day_iso, recs=None):
    if recs is None:
        from . import core
        recs = core.sessions()
    return [r for r in recs if r.get("day") == day_iso]


def day_progress(day: date, bs=None, recs=None) -> dict:
    """日计划：块数、按时长算的完成率、计划分钟、实际专注分钟（番茄记录）、顺延的块数、考试。"""
    iso = day.isoformat()
    bs = [b for b in (blocks() if bs is None else bs) if b["day"] == iso]
    study = [b for b in bs if b.get("source") != "exam"]
    total = sum(b["minutes"] for b in study)
    done_min = sum(b["minutes"] for b in study if b.get("done"))
    actual = sum(float(r.get("focus") or 0) for r in _sessions_on(iso, recs)) / 60.0
    return dict(day=iso, n=len(study), done=sum(1 for b in study if b.get("done")), planned=total, done_min=done_min,
                rate=round(done_min / total, 4) if total else None, actual=round(actual, 1),
                carried=sum(1 for b in study if b.get("carried")), exams=[b for b in bs if b.get("source") == "exam"])


def week_progress(day: date, bs=None, recs=None) -> dict:
    start = day - timedelta(days=day.weekday())
    bs = blocks() if bs is None else bs
    days = [day_progress(start + timedelta(days=i), bs, recs) for i in range(7)]
    planned = sum(x["planned"] for x in days)
    done_min = sum(x["done_min"] for x in days)
    w = week(day)
    gd = sum(1 for g in w["goals"] if g["done"])
    return dict(start=start.isoformat(), days=days, planned=planned, done_min=done_min,
                rate=round(done_min / planned, 4) if planned else None, actual=round(sum(x["actual"] for x in days), 1),
                n=sum(x["n"] for x in days), done=sum(x["done"] for x in days),
                goals=w["goals"], goals_done=gd, goals_rate=round(gd / len(w["goals"]), 4) if w["goals"] else None)


def goal_progress(analysis=None) -> dict:
    """长期目标：每科目标分 vs 最近一次考试得分率折算的分数。没考过的科目 current=None。"""
    g = goals()
    if analysis is None:
        try:
            from ..exam import records
            analysis = records.analyze()
        except Exception:   # noqa: BLE001
            analysis = dict(subjects={})
    rows = []
    cur_total, tgt_total = 0.0, 0
    for s, tgt in g.get("subjects", {}).items():
        st = (analysis.get("subjects") or {}).get(s) or {}
        tr = st.get("trend") or []
        cur = round(tr[-1] * FULL.get(s, 150), 1) if tr else None
        rows.append(dict(subject=s, target=tgt, current=cur, full=FULL.get(s, 150),
                         rate=round(min(1.0, cur / tgt), 4) if cur is not None and tgt else None))
        if cur is not None:
            cur_total += cur
            tgt_total += tgt
    total = g.get("total") or sum(r["target"] for r in rows)
    return dict(total=total, subjects=rows, note=g.get("note", ""), current_total=round(cur_total, 1) if tgt_total else None,
                rate=round(min(1.0, cur_total / tgt_total), 4) if tgt_total else None)


# ---------------------------------------------------------------- 复盘
def review(kind, day: date, bs=None, recs=None) -> dict:
    """复盘：完成率、各科计划 vs 实际（分钟）、偏差、顺延，加一句自动的观察。kind = day / week。"""
    if recs is None:
        from . import core
        recs = core.sessions()
    bs = blocks() if bs is None else bs
    if kind == "day":
        days = [day]
        prog = day_progress(day, bs, recs)
    else:
        start = day - timedelta(days=day.weekday())
        days = [start + timedelta(days=i) for i in range(7)]
        prog = week_progress(day, bs, recs)
    isos = {d.isoformat() for d in days}
    plan_s, act_s = {}, {}
    for b in bs:
        if b["day"] in isos and b.get("source") != "exam":
            k = b.get("subject") or "未分科"
            plan_s[k] = plan_s.get(k, 0) + b["minutes"]
    for r in recs:
        if r.get("day") in isos:
            k = r.get("subject") or "未分科"
            act_s[k] = round(act_s.get(k, 0) + float(r.get("focus") or 0) / 60.0, 1)
    subj = []
    for k in sorted(set(plan_s) | set(act_s), key=lambda x: -(plan_s.get(x, 0) + act_s.get(x, 0))):
        subj.append(dict(subject=k, planned=plan_s.get(k, 0), actual=act_s.get(k, 0.0), diff=round(act_s.get(k, 0.0) - plan_s.get(k, 0), 1)))
    carried = [b for b in bs if b["day"] in isos and b.get("carried")]
    notes = []
    if prog["rate"] is not None:
        notes.append(f"完成 {int(prog['rate'] * 100)}%")
    if subj:
        worst = min(subj, key=lambda x: x["diff"])
        if worst["diff"] <= -20:
            notes.append(f"{worst['subject']}比计划少 {int(-worst['diff'])} 分钟")
        best = max(subj, key=lambda x: x["diff"])
        if best["diff"] >= 20:
            notes.append(f"{best['subject']}比计划多 {int(best['diff'])} 分钟")
    if carried:
        mx = max(carried, key=lambda b: b.get("carried", 0))
        notes.append(f"「{mx.get('task') or mx.get('subject') or '一项'}」已经顺延 {mx['carried']} 次")
    if not notes:
        notes.append("还没有计划和专注记录")
    return dict(kind=kind, start=days[0].isoformat(), end=days[-1].isoformat(), rate=prog["rate"], n=prog["n"], done=prog["done"],
                planned=prog["planned"], actual=prog["actual"], deviation=round(prog["actual"] - prog["planned"], 1),
                subjects=subj, carried=len(carried), max_carried=max([b.get("carried", 0) for b in carried] or [0]),
                observe="；".join(notes) + "。", text=review_text(kind, day))


# ---------------------------------------------------------------- 候选与自动排程
def candidates() -> list[dict]:
    """能拉进计划的任务：复习到期、当前预习单、考情薄弱点、背诵。每项 {source, subject, task, ref, minutes, priority, why}。"""
    out = []
    try:
        from .. import learning
        due = learning.due()
        if due:
            subs = {}
            for _k, it in due:
                subs[it.get("subject") or ""] = subs.get(it.get("subject") or "", 0) + 1
            for s, n in sorted(subs.items(), key=lambda t: -t[1]):
                out.append(dict(source="review", subject=s, task=f"复习到期 {n} 项" + (f"（{s}）" if s else ""),
                                ref="review:" + s, minutes=max(15, min(60, n * 5)), priority=2,
                                why=f"有 {n} 项今天到期，拖过今天记忆曲线就断了"))
    except Exception:   # noqa: BLE001
        pass
    try:
        from ..exam import records
        for w in records.analyze()["weak"][:5]:
            r = w.get("rate", 0.5)
            out.append(dict(source="weak", subject=w.get("subject", ""), task="薄弱点：" + w["point"],
                            ref="weak:" + w["point"], minutes=30 if r >= 0.4 else 45, priority=2 if r < 0.5 else 1,
                            why=f"这个点得分率 {int(r * 100)}%，" + ("错得多，先补" if r < 0.5 else "还不稳")))
    except Exception:   # noqa: BLE001
        pass
    try:
        from ..recite import core as rc
        st = rc.word_stats()
        if st["total"] and st["learned"] < st["total"]:
            out.append(dict(source="recite", subject="英语", task="背单词 20 个", ref="recite:words", minutes=15, priority=1,
                            why=f"词表已学会 {st['learned']}/{st['total']}"))
        for p in rc.poems():
            s = rc.poem_state(p["id"])
            if s.get("best", 0) < 0.9:
                out.append(dict(source="recite", subject="语文", task="背诵：" + p["title"], ref="poem:" + p["id"], minutes=15,
                                priority=1, why="还没默写到九成" if s.get("tries") else "还没背过"))
                break
    except Exception:   # noqa: BLE001
        pass
    try:
        from .. import preview
        sheet = preview.current()
        if sheet:
            done, total = preview.progress(sheet)
            if done < total:
                out.append(dict(source="preview", subject=sheet.get("subject", ""), task="预习：" + sheet.get("title", ""),
                                ref="preview:" + sheet["id"], minutes=30, priority=0, why=f"预习单做了 {done}/{total}"))
    except Exception:   # noqa: BLE001
        pass
    return out


def free_slots(day: date, now_min=None, bs=None, d=None) -> list[list[int]]:
    """这天可用时段减去已排的块（今天再减去已经过去的时间）。"""
    d = d or _load()
    iso = day.isoformat()
    taken = sorted((b["start"], b["start"] + b["minutes"]) for b in (d["blocks"] if bs is None else bs) if b["day"] == iso)
    out = []
    for a, b in avail_for(day, d):
        if now_min is not None:
            a = max(a, snap(now_min + 7))
        segs = [[a, b]]
        for x, y in taken:
            nxt = []
            for s, e in segs:
                if y <= s or x >= e:
                    nxt.append([s, e])
                else:
                    if x > s:
                        nxt.append([s, x])
                    if y < e:
                        nxt.append([y, e])
            segs = nxt
        out += [[snap(s) if snap(s) >= s else snap(s) + STEP, e] for s, e in segs]
    return [[s, e] for s, e in out if e - s >= STEP]


def suggest_day(day: date, now_min=None, fill=0.85, cands=None) -> list[dict]:
    """一键排今天：按优先级把候选放进空闲时段，最多排满空闲时间的 fill 倍，留出余量。返回建议（还没写进计划）。"""
    cands = candidates() if cands is None else cands
    slots = free_slots(day, now_min)
    budget = sum(e - s for s, e in slots) * fill
    order = sorted(cands, key=lambda c: (-c.get("priority", 1), ["review", "weak", "exam", "recite", "preview", "self", "ai"].index(c["source"])
                                         if c["source"] in SOURCES else 9))
    out, used = [], 0
    for c in order:
        m = max(STEP, snap(c.get("minutes", 30)))
        if used + m > budget:
            continue
        for sl in slots:
            if sl[1] - sl[0] >= m:
                out.append(dict(day=day.isoformat(), start=sl[0], minutes=m, subject=c.get("subject", ""), task=c["task"],
                                source=c["source"], ref=c.get("ref", ""), priority=c.get("priority", 1), why=c.get("why", "")))
                sl[0] += m + (5 if sl[1] - sl[0] - m >= 20 else 0)
                sl[0] = snap(sl[0]) if snap(sl[0]) >= sl[0] else snap(sl[0]) + STEP
                used += m
                break
    return out


def accept(items) -> list[dict]:
    """把建议写进计划（冲突的往后找空档）。"""
    made = []
    for it in items:
        day = it["day"]
        start = it["start"]
        taken = [(b["start"], b["start"] + b["minutes"]) for b in blocks(day)]
        if not all(start + it["minutes"] <= a or start >= b for a, b in taken):
            start = next_free(day, it["minutes"], after=start)
        made.append(add(day, start, it["minutes"], it.get("subject", ""), it.get("task", ""), it.get("source", "self"),
                        it.get("ref", ""), priority=it.get("priority", 1), why=it.get("why", ""), pomos=it.get("pomos", 0),
                        subtasks=it.get("subtasks") or []))
    return made
