"""专注监督：前台窗口是不是白名单里的程序、多久没有键鼠输入。只读本机状态，只在本机记录。

Probe.read() → dict(exe, title, idle, own)。Windows 用 GetForegroundWindow / QueryFullProcessImageNameW / GetLastInputInfo；
自测换成假的 probe。Supervisor.check(pomo, now, probe_state) 在专注进行中按规则记中断，返回要给用户看的温和提醒（或空串）：
- 前台切到非白名单程序超过 grace_seconds：记一次「离开」（回来时补上离开时长）；
- 超过 idle_minutes 没有输入：记一次「无操作」（有输入时结束）。
不锁屏、不关程序、不截图。
"""
from __future__ import annotations

import os
import sys

KIND_NAME = dict(away="离开", idle="无操作")


class Probe:
    def read(self) -> dict:
        if sys.platform != "win32":
            return dict(exe="", title="", idle=0.0, own=True)
        import ctypes
        from ctypes import wintypes
        user, kernel = ctypes.windll.user32, ctypes.windll.kernel32
        hwnd = user.GetForegroundWindow()
        pid = wintypes.DWORD()
        user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        exe = ""
        h = kernel.OpenProcess(0x1000, False, pid.value)      # PROCESS_QUERY_LIMITED_INFORMATION
        if h:
            try:
                buf = ctypes.create_unicode_buffer(520)
                n = wintypes.DWORD(520)
                if kernel.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    exe = os.path.basename(buf.value)
            finally:
                kernel.CloseHandle(h)
        tbuf = ctypes.create_unicode_buffer(256)
        user.GetWindowTextW(hwnd, tbuf, 256)

        class LASTINPUTINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]
        li = LASTINPUTINFO()
        li.cbSize = ctypes.sizeof(LASTINPUTINFO)
        idle = 0.0
        if user.GetLastInputInfo(ctypes.byref(li)):
            idle = max(0.0, ((kernel.GetTickCount() - li.dwTime) & 0xFFFFFFFF) / 1000.0)
        return dict(exe=exe, title=tbuf.value, idle=idle, own=pid.value == os.getpid() or not hwnd)


class Supervisor:
    def __init__(self):
        self.away_since = None       # 第一次看到非白名单前台的时间
        self.away_logged = False
        self.idle_logged = False

    def reset(self):
        self.away_since, self.away_logged, self.idle_logged = None, False, False

    @staticmethod
    def allowed(st, whitelist) -> bool:
        if st.get("own") or not st.get("exe"):
            return True
        return st["exe"].lower() in {w.lower() for w in whitelist}

    def check(self, pomo, now, st, cfg) -> str:
        if not cfg.get("watch", True) or pomo.phase != "focus" or not pomo.running:
            if self.away_logged:
                pomo.close_interrupt("away", now)
            self.reset()
            return ""
        msg = ""
        if self.allowed(st, cfg.get("whitelist") or []):
            if self.away_logged:
                pomo.close_interrupt("away", now)
                msg = "回来了。这个番茄还剩一点，接着做完它。"
            self.away_since, self.away_logged = None, False
        else:
            if self.away_since is None:
                self.away_since = now
            if not self.away_logged and now - self.away_since >= float(cfg.get("grace_seconds", 30)):
                pomo.interrupt("away", st.get("exe", ""), now=self.away_since, open_=True)
                self.away_logged = True
                msg = f"专注中切到了 {st.get('exe') or '别的程序'}。如果是查资料，可以在设置里把它加进白名单。"
        limit = float(cfg.get("idle_minutes", 5)) * 60
        if st.get("idle", 0) >= limit:
            if not self.idle_logged:
                pomo.interrupt("idle", f"{int(st['idle'] // 60)} 分钟没有输入", now=now - st["idle"], open_=True)
                self.idle_logged = True
                msg = msg or "好一会儿没有动键盘鼠标了。在纸上做题的话不用管，番茄照常走。"
        elif self.idle_logged:
            pomo.close_interrupt("idle", now)
            self.idle_logged = False
        return msg
