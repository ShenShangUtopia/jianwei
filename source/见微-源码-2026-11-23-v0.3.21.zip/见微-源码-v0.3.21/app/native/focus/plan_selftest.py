"""0.3.19 计划细化 + 每日提醒的离屏自测：层级完成度、任务属性、重复规则、跨天顺延、自动排程、复盘、
提醒（早晚、提前 N 分钟、到期、考试、免打扰、错过补报、推迟 / 跳过 / 开始番茄）、三种视图、小窗口。全用假时钟。"""
from ..kit import test_runtime
test_runtime.configure()
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    fails, log = [], []

    def check(name, ok, detail=""):
        log.append(("OK  " if ok else "FAIL") + " " + name + ("" if ok else f"  {str(detail)[:600]}"))
        if not ok:
            fails.append(name)

    def spin(sec=0.05):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from . import core, plan, remind
    from .selftest import Clock, FakeProbe

    # 以「下周一」为第 0 天，免得和真实的今天搅在一起（老数据、真实 now 都不影响）
    base = date.today() + timedelta(days=7 - date.today().weekday())      # 一个周一
    D = [base + timedelta(days=i) for i in range(14)]

    def at(d, h, m=0):
        return datetime.combine(d, datetime.min.time()) + timedelta(hours=h, minutes=m)

    # ------------------------------------------------ 任务属性
    b = plan.add(D[0].isoformat(), 8 * 60, 50, "数学", "导数大题", priority=5, pomos=2, deadline=D[3].isoformat(),
                 subtasks=["读题", dict(t="列式", done=False), "  "])
    check("块的属性：优先级夹到 0–2、番茄数、截止日、子任务去空", b["priority"] == 2 and b["pomos"] == 2 and b["deadline"] == D[3].isoformat()
          and [s["t"] for s in b["subtasks"]] == ["读题", "列式"], b)
    check("按时长估番茄数", plan.pomos_of(dict(minutes=50, pomos=0)) == 2 and plan.pomos_of(b) == 2)
    plan.toggle_subtask(b["id"], 0)
    check("勾一个子任务不算完成", not plan.get(b["id"])["done"] and plan.get(b["id"])["subtasks"][0]["done"])
    plan.toggle_subtask(b["id"], 1)
    check("子任务全勾＝块完成", plan.get(b["id"])["done"])
    import json
    from ..kit.home import load_json, save_json
    old = dict(v=1, blocks=[dict(id="old1", day=D[0].isoformat(), start=600, minutes=30, subject="英语", task="旧块", source="self",
                                 ref="", done=False, focused=0.0, reminded=False)])
    raw = load_json(plan.FILE, {})
    save_json(plan.FILE, old)
    ob = plan.get("old1")
    check("v1 的计划文件读进来自动补字段", ob and ob["priority"] == 1 and ob["subtasks"] == [] and ob["carried"] == 0, ob)
    save_json(plan.FILE, raw)

    # ------------------------------------------------ 重复规则
    rd = plan.add(D[0].isoformat(), 7 * 60, 15, "英语", "背单词")
    plan.set_repeat(rd["id"], "daily")
    rw = plan.add(D[0].isoformat(), 19 * 60, 30, "数学", "错题")
    plan.set_repeat(rw["id"], "weekday")
    rk = plan.add(D[1].isoformat(), 20 * 60, 45, "物理", "周测")
    plan.set_repeat(rk["id"], "weekly", [1, 3])
    plan.ensure_repeats(D, today=D[0])
    cnt = lambda rid: sum(1 for x in plan.blocks() if x.get("rep") == rid)   # noqa: E731
    check("每天：两周 14 块", cnt(plan.get(rd["id"])["rep"]) == 14, cnt(plan.get(rd["id"])["rep"]))
    check("工作日：两周 10 块", cnt(plan.get(rw["id"])["rep"]) == 10, cnt(plan.get(rw["id"])["rep"]))
    check("每周二、四：两周 4 块", cnt(plan.get(rk["id"])["rep"]) == 4, cnt(plan.get(rk["id"])["rep"]))
    check("重复生成的块不重复生成", plan.ensure_repeats(D, today=D[0]) == 0)
    inst = next(x for x in plan.blocks(D[2].isoformat()) if x.get("rep") == plan.get(rd["id"])["rep"])
    plan.remove(inst["id"])
    plan.ensure_repeats(D, today=D[0])
    check("删掉某一天的重复块，不会再生成回来", not any(x.get("rep") == plan.get(rd["id"])["rep"] for x in plan.blocks(D[2].isoformat())))
    check("编辑栏能读回规则", plan.repeat_rule(plan.get(rk["id"])) == ("weekly", [1, 3]))
    plan.set_repeat(rk["id"], "none")
    check("取消重复：以后没做的生成块删掉", cnt(rk["id"]) == 0 and plan.repeat_rule(plan.get(rk["id"]))[0] == "none"
          and not any(x.get("task") == "周测" and x["day"] > D[1].isoformat() for x in plan.blocks()))
    plan.ensure_repeats([D[0] - timedelta(days=3)], today=D[0])
    check("过去的日子不补重复块", not plan.blocks((D[0] - timedelta(days=3)).isoformat()))

    # ------------------------------------------------ 跨天顺延
    y = plan.add(D[0].isoformat(), 15 * 60, 45, "化学", "方程式配平", priority=2)
    ex = plan.add(D[0].isoformat(), 16 * 60, 90, "数学", "月考", "exam")
    moved = plan.rollover(D[1], now_min=9 * 60)
    yb = plan.get(y["id"])
    check("没做完的顺延到第二天，标顺延 1 次、记最早日期", yb["day"] == D[1].isoformat() and yb["carried"] == 1 and yb["orig"] == D[0].isoformat(), yb)
    check("顺延放进空档，不压已有的块", all(not (yb["start"] < o["start"] + o["minutes"] and o["start"] < yb["start"] + yb["minutes"])
                                    for o in plan.blocks(D[1].isoformat()) if o["id"] != yb["id"]), plan.blocks(D[1].isoformat()))
    check("考试块、重复块、已完成的不顺延", plan.get(ex["id"])["day"] == D[0].isoformat() and plan.get(b["id"])["day"] == D[0].isoformat()
          and all(m.get("rep") == "" for m in moved))
    check("一天只顺延一次", plan.rollover(D[1], now_min=10 * 60) == [])
    plan.rollover(D[2], now_min=9 * 60)
    check("又没做：顺延 2 次", plan.get(y["id"])["carried"] == 2 and plan.get(y["id"])["day"] == D[2].isoformat())

    # ------------------------------------------------ 完成度与复盘
    sess = [dict(day=D[2].isoformat(), start=at(D[2], 15).timestamp(), focus=40 * 60, status="done", subject="化学", interruptions=[]),
            dict(day=D[2].isoformat(), start=at(D[2], 20).timestamp(), focus=25 * 60, status="done", subject="英语", interruptions=[])]
    for s in sess:
        core.add_session(s)
    plan.add_focus(y["id"], 40 * 60)
    dp = plan.day_progress(D[2])
    check("日完成度：块数、按时长算完成率、实际专注", dp["done"] >= 1 and dp["actual"] == 65.0 and 0 < dp["rate"] <= 1, dp)
    wp = plan.week_progress(D[2])
    check("周完成度汇总七天", wp["start"] == D[0].isoformat() and len(wp["days"]) == 7 and wp["n"] >= dp["n"] and wp["actual"] >= 65)
    plan.set_week(D[2], [dict(t="导数每天一道", done=True), "错题本整理"])
    wp = plan.week_progress(D[2])
    check("周目标完成度", wp["goals_done"] == 1 and len(wp["goals"]) == 2 and wp["goals_rate"] == 0.5, wp["goals"])
    plan.set_goals(total=620, subjects=dict(数学=130, 物理=85, 化学=0))
    gp = plan.goal_progress(dict(subjects=dict(数学=dict(trend=[0.6, 0.7]))))
    m = next(r for r in gp["subjects"] if r["subject"] == "数学")
    check("长期目标：按最近一次得分率折算、没考过的科目为空、0 分目标不存", m["current"] == 105.0 and abs(m["rate"] - 105 / 130) < 1e-3
          and next(r for r in gp["subjects"] if r["subject"] == "物理")["current"] is None and "化学" not in plan.goals()["subjects"], gp)
    rv = plan.review("day", D[2])
    eng_ = next((x for x in rv["subjects"] if x["subject"] == "英语"), None)
    check("每日复盘：各科计划 vs 实际、偏差、顺延", eng_ and eng_["actual"] == 25.0 and rv["carried"] >= 1 and "顺延 2 次" in rv["observe"], rv)
    plan.save_review_text("day", D[2], "化学拖了两天，明早先做")
    plan.save_review_text("week", D[2], "这周数学偏少")
    check("复盘文字存下、按周取", plan.review("day", D[2])["text"].startswith("化学") and plan.review("week", D[4])["text"] == "这周数学偏少")

    # ------------------------------------------------ 可用时段与自动排程
    check("时段解析：中文标点、非法段丢掉", plan.parse_ranges("18:30-22:30，8:00~9:00; 25:00-26:00, 9-10") == [[480, 540], [1110, 1350]])
    plan.set_avail(weekday=[[18 * 60, 21 * 60]], weekend=[[9 * 60, 12 * 60]])
    d5 = D[3]                                           # 周四
    plan.add(d5.isoformat(), 19 * 60, 30, "英语", "听力")
    fs = plan.free_slots(d5)
    check("空闲时段＝可用时段减已排的块", fs == [[18 * 60, 19 * 60], [19 * 60 + 30, 21 * 60]], fs)
    check("今天的空闲时段扣掉已经过去的", plan.free_slots(d5, now_min=19 * 60 + 40)[0][0] >= 19 * 60 + 45)
    cands = [dict(source="review", subject="物理", task="复习到期 6 项", ref="review:物理", minutes=30, priority=2, why="到期"),
             dict(source="weak", subject="数学", task="薄弱点：导数", ref="weak:导数", minutes=45, priority=2, why="得分率低"),
             dict(source="recite", subject="语文", task="背诵：师说", ref="poem:x", minutes=15, priority=1, why="没背过"),
             dict(source="preview", subject="化学", task="预习：电化学", ref="preview:y", minutes=30, priority=0, why="预习单")]
    sg = plan.suggest_day(d5, cands=cands)
    used = sum(x["minutes"] for x in sg)
    check("一键排程：高优先级先排、不超过空闲的 85%", sg and sg[0]["source"] == "review" and sg[1]["source"] == "weak" and used <= 150 * 0.85,
          [(x["task"], x["start"], x["minutes"]) for x in sg])
    sg_tight = plan.suggest_day(d5, cands=cands, fill=0.6)
    check("留余量：空闲少时低优先级的先不排", sum(x["minutes"] for x in sg_tight) <= 90 and not any(x["source"] == "preview" for x in sg_tight),
          [(x["task"], x["minutes"]) for x in sg_tight])
    taken = [(x["start"], x["start"] + x["minutes"]) for x in plan.blocks(d5.isoformat())]
    check("建议都在可用时段里、彼此不重叠、不压已有的块",
          all(18 * 60 <= x["start"] and x["start"] + x["minutes"] <= 21 * 60 for x in sg) and
          all(not (a["start"] < c["start"] + c["minutes"] and c["start"] < a["start"] + a["minutes"]) for i, a in enumerate(sg) for c in sg[i + 1:]) and
          all(not (x["start"] < e and s < x["start"] + x["minutes"]) for x in sg for s, e in taken), sg)
    check("每项写了为什么这样排", all(x["why"] for x in sg))
    n0 = len(plan.blocks(d5.isoformat()))
    made = plan.accept(sg)
    check("接受建议才写进计划", len(plan.blocks(d5.isoformat())) == n0 + len(sg) and all(m["why"] for m in made))
    check("排满了就不再建议", plan.suggest_day(d5, cands=cands[:1] * 3) == [] or
          sum(x["minutes"] for x in plan.suggest_day(d5, cands=cands[:1] * 3)) <= 30)

    # ------------------------------------------------ 提醒：纯逻辑
    cfg = core.settings()
    cfg.update(remind=True, remind_lead=5, remind_due_on=True, remind_due="17:30", dnd_on=True, dnd_start="22:30", dnd_end="06:30")
    st = remind._state()
    st["last"] = at(D[5], 6, 50).timestamp()            # 周六 6:50 上次检查
    save_json(remind.FILE, st)
    it = remind.check(at(D[5], 8, 31), cfg)
    check("周末早上提醒按周末的时间（8:30）", any(x["kind"] == "morning" and not x["missed"] for x in it)
          and not any(x["kind"] == "morning" and x["missed"] for x in it), it)
    check("早上提醒里有今日计划概要", "今天" in next(x for x in it if x["kind"] == "morning")["text"])
    blk = plan.add(D[5].isoformat(), 10 * 60, 45, "物理", "电磁感应")
    check("块开始前 5 分钟以外不响", not any(x.get("block") == blk["id"] for x in remind.check(at(D[5], 9, 50), cfg)))
    it = remind.check(at(D[5], 9, 55), cfg)
    x = next((x for x in it if x.get("block") == blk["id"]), None)
    check("块开始前 5 分钟提醒，带剩几分钟", x and not x["missed"] and "5 分钟后" in x["text"] and "电磁感应" in x["text"], it)
    check("提醒过的不再响", not any(x.get("block") == blk["id"] for x in remind.check(at(D[5], 9, 58), cfg)))
    plan.move(blk["id"], D[5].isoformat(), 11 * 60)
    it = remind.check(at(D[5], 10, 56), cfg)
    check("块挪了时间，新时间再提醒一次", any(x.get("block") == blk["id"] for x in it))
    remind.snooze(next(x for x in it if x.get("block") == blk["id"]), 10, at(D[5], 10, 56))
    check("推迟 10 分钟：9 分钟时还不响", not any(x.get("block") == blk["id"] for x in remind.check(at(D[5], 11, 5), cfg)))
    it = remind.check(at(D[5], 11, 6, ), cfg)
    check("推迟 10 分钟：到点再响", any(x.get("block") == blk["id"] and x.get("snoozed") for x in it), it)
    exb = plan.add(D[5].isoformat(), 14 * 60, 120, "数学", "模拟考", "exam")
    check("考试至少提前 30 分钟提醒", any(x["kind"] == "exam" and "开考" in x["text"] for x in remind.check(at(D[5], 13, 30), cfg)))
    from .. import learning
    learning.add_card(dict(n="楞次定律", d="阻碍变化", f=[], p=[]), "物理")
    from ..recite import core as rc
    rc.add_word("abandon", "放弃")
    it = remind.check(at(D[5], 17, 30), cfg)
    du = next((x for x in it if x["kind"] == "due"), None)
    check("到期复习、背诵提醒分开数", du and "复习" in du["text"] and "背诵" in du["text"], it)
    plan.add(D[6].isoformat(), 9 * 60, 120, "英语", "期中考", "exam")
    it = remind.check(at(D[5], 21, 31), cfg)
    ev = next((x for x in it if x["kind"] == "evening"), None)
    check("晚上提醒复盘，带明天的考试", ev and "复盘" in ev["text"] and "明天有考试" in ev["text"], it)
    # 免打扰：23:00 的块不在免打扰里响，出了免打扰补报
    late = plan.add(D[5].isoformat(), 22 * 60 + 45, 15, "语文", "睡前默写")
    check("免打扰时段里不响", remind.check(at(D[5], 22, 41), cfg) == [])
    check("免打扰判断跨午夜", remind.in_dnd(at(D[6], 3, 0), cfg) and not remind.in_dnd(at(D[6], 6, 31), cfg))
    it = remind.check(at(D[6], 6, 31), cfg)
    check("出了免打扰，错过的补报（标 missed）", any(x.get("block") == late["id"] and x["missed"] for x in it), it)
    cfg2 = dict(cfg)
    cfg2["remind_daily"] = dict(cfg["remind_daily"])
    cfg2["remind_daily"]["6"] = dict(on=False, am="08:30", pm="21:30")
    check("某天关掉早晚提醒", not any(x["kind"] == "morning" for x in remind.check(at(D[6], 8, 31), cfg2)))
    # 见微没开：周日 9:00 关掉，周一 9:00 再开
    st = remind._state()
    st["last"] = at(D[6], 9, 0).timestamp()
    save_json(remind.FILE, st)
    plan.add(D[7].isoformat(), 8 * 60, 30, "数学", "早读公式")
    it = remind.check(at(D[7], 9, 0), cfg)
    missed = [x for x in it if x["missed"]]
    check("没开见微时错过的，下次启动补报（晚上复盘、早上计划、早上的块）", {"evening", "morning", "block"} <= {x["kind"] for x in missed}, [(x["kind"], x["missed"]) for x in it])
    mm = remind.merge_missed(missed)
    check("补报合成一条，带条数和时间", mm["kind"] == "missed" and str(len(missed)) in mm["title"] and "21:30" in mm["text"], mm)
    st = remind._state()
    st["last"] = at(D[7], 9, 0).timestamp() - 3 * 86400
    save_json(remind.FILE, st)
    it = remind.check(at(D[7], 9, 1), cfg)
    check("最多补报 24 小时内的", all(x["at"] >= at(D[7], 9, 1).timestamp() - remind.LOOKBACK - 1 for x in it))
    check("关掉提醒就什么都不响", remind.check(at(D[7], 12, 0), dict(cfg, remind=False)) == [])

    # ------------------------------------------------ 引擎 + 通知卡片：跨天、开始番茄、推迟、跳过
    from . import engine as engine_mod
    from .engine import engine
    c = Clock(at(D[8], 9, 0).timestamp())                # 周二 9:00
    st = remind._state()
    st["last"] = c() - 60
    save_json(remind.FILE, st)
    fp = FakeProbe()
    eng = engine(clock=c, probe=fp, now_dt=c.dt)
    got, changed = [], []
    eng.reminder.connect(got.append)
    eng.planChanged.connect(lambda: changed.append(1))
    carry = plan.add(D[8].isoformat(), 20 * 60, 30, "生物", "遗传图解")
    eng.step()
    c.t = at(D[9], 7, 1).timestamp()                     # 第二天 7:01
    eng.step()
    check("引擎跨天：顺延昨天没做的、补重复块、发 planChanged", plan.get(carry["id"])["day"] == D[9].isoformat() and changed, (plan.get(carry["id"]), changed))
    check("引擎跨天后推早上提醒", any(x["kind"] == "morning" for x in got) or any(x["kind"] == "missed" for x in got), [x["kind"] for x in got])
    from .notify import card
    nc = card(lambda tab: opened.append(tab))
    opened = []
    nc.queue.clear()
    nc.item = None
    tb = plan.add(D[9].isoformat(), 9 * 60, 45, "数学", "数列", priority=2)
    c.t = at(D[9], 8, 55).timestamp()
    got.clear()
    eng.reminder.connect(nc.push)
    eng.step()
    check("到点前 5 分钟，通知卡片出现", nc.isVisible() and nc.item and nc.item.get("block") == tb["id"], (nc.isVisible(), nc.item))
    nc.grab().save(str(out / "notice.png"))
    k = nc.keys()
    check("卡片三个键不重叠、在卡片里", k["main"].right() < k["snooze"].left() < k["snooze"].right() < k["skip"].left() and k["skip"].right() <= nc.width())
    nc.act("main")
    check("「开始番茄」：按这一块开始专注", eng.pomo.phase == "focus" and eng.state()["block"] == tb["id"])
    eng.abandon("测")
    tb2 = plan.add(D[9].isoformat(), 10 * 60, 30, "英语", "完形")
    c.t = at(D[9], 9, 55).timestamp()
    eng.step()
    nc.act("snooze")
    check("「推迟 10 分钟」：记下、卡片收起", any(s["item"].get("block") == tb2["id"] for s in remind.pending_snoozes()) and not nc.isVisible())
    c.t = at(D[9], 10, 5).timestamp()
    eng.step()
    check("推迟到点再弹一次", nc.isVisible() and nc.item.get("block") == tb2["id"])
    nc.act("skip")
    check("「跳过」：收起，不再响", not nc.isVisible() and not any(s["item"].get("block") == tb2["id"] for s in remind.pending_snoozes()))
    nc.push(dict(key="a", kind="morning", title="今日计划", text="一"))
    nc.push(dict(key="b", kind="evening", title="晚间复盘", text="二"))
    check("几条排队，卡片写还有几条", nc.item["key"] == "a" and len(nc.queue) == 1)
    nc.act("skip")
    check("晚间复盘的第一个键是「去复盘」", nc.main_label() == "去复盘")
    nc.act("main")
    check("「去复盘」打开复盘页", opened == ["review"] and not nc.isVisible(), opened)
    nc.push(dict(key="long", kind="missed", title="你不在时错过了 9 条提醒", text="很长" * 200, missed=True))
    spin()
    nc.grab().save(str(out / "notice-long.png"))
    nc.act("skip")
    check("长文字截断，不压到键上（画得出来）", not nc.isVisible())

    # ------------------------------------------------ 页面：三种视图、编辑、目标、复盘、设置
    from .page import FocusPage
    page = FocusPage()
    page.resize(1280, 820)
    page.show()
    spin()
    page.day = D[9]
    page.week_start = D[7]
    page.show_tab("plan")
    for mode in ("day", "week", "month"):
        page._set_plan_mode(mode)
        spin()
        page.grab().save(str(out / f"plan-{mode}.png"))
    check("月视图：42 格，有块的那天有数", len(page.month.cells) == 42 and any(pg["n"] for _d, pg in page.month.cells), page.pl_prog.text())
    page.month.picked.emit(D[9])
    check("月视图点一天＝看那天", page.view_mode == "day" and page.day == D[9] and page.grid.days == [D[9]])
    page._set_plan_mode("week")
    check("周视图表头有完成度", any(pg["n"] for pg in page.grid._prog.values()) and "本周" in page.pl_prog.text(), page.pl_prog.text())
    page.grid.sel = tb["id"]
    page._pick_block(tb["id"])
    check("编辑栏读出属性", page.ed_task.text() == "数列" and page.ed_pri.currentData() == 2 and page.ed_box.isEnabled())
    page.ed_rep.setCurrentIndex(page.ed_rep.findData("weekly"))
    for i in (1, 4):
        page.ed_day_cb[i].setChecked(True)
    page.ed_dl_on.setChecked(True)
    page.ed_sub_new.setText("等差")
    page.add_subtask()
    page.ed_sub_new.setText("等比")
    page.add_subtask()
    page.ed_pomos.setValue(3)
    page.save_block()
    tbb = plan.get(tb["id"])
    check("编辑栏保存：重复每周二五、截止、子任务、番茄数", plan.repeat_rule(tbb) == ("weekly", [1, 4]) and tbb["deadline"] and
          [s["t"] for s in tbb["subtasks"]] == ["等差", "等比"] and tbb["pomos"] == 3, tbb)
    page.ed_subs.item(0).setCheckState(page.ed_subs.item(0).checkState().__class__.Checked)
    check("编辑栏勾子任务", plan.get(tb["id"])["subtasks"][0]["done"])
    page.ed_kind.setCurrentIndex(1)
    page.save_block()
    check("块改成考试", plan.get(tb["id"])["source"] == "exam")
    page._side_tab("goal")
    page.gl_sub["数学"].setValue(135)
    page.save_goals()
    page.wk_new.setText("每天一篇英语阅读")
    page.add_week_goal()
    check("目标栏：存目标分、加周目标", plan.goals()["subjects"]["数学"] == 135 and any(g["t"] == "每天一篇英语阅读" for g in plan.week(page.day)["goals"]))
    page.grab().save(str(out / "plan-goals.png"))
    # 一键排今天（页面）
    plan.set_avail(weekday=[[18 * 60, 22 * 60]], weekend=[[9 * 60, 12 * 60]])
    sg = page.suggest_today(now=at(D[9], 17, 0))
    check("页面「一键排今天」列出建议、切到拉任务栏", page.sg_list.count() == len(sg) and page.side_stack.currentWidget() is page.side_views["pull"]
          and page.sg_go.isEnabled() == bool(sg), page.sg_note.text())
    page.grab().save(str(out / "plan-suggest.png"))
    if sg:
        from PySide6.QtCore import Qt as _Qt
        page.sg_list.item(0).setCheckState(_Qt.CheckState.Unchecked)
        made = page.accept_suggest()
        check("勾掉一项再排入", len(made) == len(sg) - 1)
    # 复盘
    page.rv_day = D[2]
    page.show_tab("review")
    spin()
    check("复盘页：完成率、计划 vs 实际、已写的复盘", page.rv_tiles[0][0].text().endswith("%") and page.rv_pairs.rows and page.rv_text.text().startswith("化学"),
          [t[0].text() for t in page.rv_tiles])
    page.grab().save(str(out / "review-day.png"))
    page._rv_kind("week")
    page.rv_text.setText("下周多做数学")
    page.save_review()
    check("每周复盘保存", plan.review_text("week", D[2]) == "下周多做数学")
    page.grab().save(str(out / "review-week.png"))
    # 设置
    page.show_tab("set")
    page.st_daily[5][1].setTime(page.st_daily[5][1].time().fromString("09:15", "HH:mm"))
    page.st["remind_lead"].setValue(10)
    page.st_av_we.setText("9:00-11:00, 15:00-18:00")
    page.save_settings()
    s = core.settings()
    check("设置：周六早上时间、提前分钟、周末可用时段", s["remind_daily"]["5"]["am"] == "09:15" and s["remind_lead"] == 10
          and plan.avail()["weekend"] == [[540, 660], [900, 1080]] and eng.cfg["remind_lead"] == 10, (s["remind_daily"]["5"], plan.avail()))
    page.st_av_wd.setText("乱写")
    page.save_settings()
    check("可用时段乱写被拦下", "可用时段" in page.status.text())
    page.grab().save(str(out / "settings.png"))
    try:
        core.save_settings(remind_daily={"0": dict(on=True, am="25:00", pm="21:00")})
        check("每日提醒时间不合法被拒", False)
    except ValueError:
        check("每日提醒时间不合法被拒", True)
    # 夜间、小窗口
    from ..design import tokens
    tokens.set_theme("night")
    page.apply_theme()
    page.show_tab("plan")
    page._set_plan_mode("week")
    spin()
    page.grab().save(str(out / "plan-week-night.png"))
    tokens.set_theme("day")
    page.apply_theme()
    page.resize(1000, 620)
    for tab in ("plan", "review", "set"):
        page.show_tab(tab)
        spin()
        page.grab().save(str(out / f"small-{tab}.png"))
    side = page.side_stack.parentWidget()
    check("1000×620：计划右栏不被挤没", side.width() >= 280, side.width())
    # 性能：番茄在走（每秒一跳）时，计划页的计划表、番茄环都不该重画；番茄页只重画番茄环
    from PySide6.QtCore import QEvent, QObject

    class PaintCount(QObject):
        def __init__(self):
            super().__init__()
            self.n = {}

        def eventFilter(self, obj, ev):  # noqa: N802
            if ev.type() == QEvent.Type.Paint:
                self.n[obj] = self.n.get(obj, 0) + 1
            return False
    pc = PaintCount()
    page.resize(1280, 820)
    page.show_tab("plan")
    spin(0.2)
    for w in (page.grid, page.ring, page.month):
        w.installEventFilter(pc)
    eng.start("数学", "测")
    for _ in range(5):
        c.go(1)
        eng.step()
        spin(0.02)
    check("计划页静止：番茄每秒一跳也不重画计划表、番茄环", pc.n.get(page.grid, 0) <= 1 and pc.n.get(page.ring, 0) == 0, pc.n)
    page.show_tab("pomo")
    spin(0.1)
    pc.n.clear()
    for _ in range(3):
        c.go(1)
        eng.step()
        spin(0.02)
    check("番茄页：每秒只重画番茄环，不碰计划表", pc.n.get(page.ring, 0) >= 3 and pc.n.get(page.grid, 0) == 0, pc.n)
    eng.abandon("测")
    check("番茄停了引擎回到 30 秒一跳", eng.timer.interval() == 30000)
    page.close()

    eng.timer.stop()
    nc.hide()
    engine_mod._ENGINE = None
    from . import floater as _fl, notify as _nt
    _fl._FLOAT = None
    _nt._CARD = None
    (out / "plan-log.txt").write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))
    print("PLAN_FAIL" if fails else "PLAN_OK", len(log), "项")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
