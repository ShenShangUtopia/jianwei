"""桌面上的番茄小窗：置顶、无边框、可拖动。番茄在走（或刚有提醒）时出现；点中间打开专注页。

和时间胶囊一样只在需要时显示；看不见时不重画。位置存在 focus-float.json。
"""
from __future__ import annotations

from PySide6.QtCore import QPoint, QRectF, Qt, QTimer
from PySide6.QtGui import QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QWidget

from ..design.icons import draw_icon
from ..design.tokens import T, font, qc
from ..kit.home import load_json, save_json
from .engine import engine

W, H, HN = 260, 74, 112


def mmss(sec):
    sec = max(0, int(round(sec)))
    return f"{sec // 60:02d}:{sec % 60:02d}"


class FocusFloat(QWidget):
    def __init__(self, open_page=None):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.open_page = open_page
        self.eng = engine()
        self.msg = ""
        self._drag = None
        self._moved = False
        self.setFixedSize(W, H)
        self.msg_timer = QTimer(self)
        self.msg_timer.setSingleShot(True)
        self.msg_timer.timeout.connect(self._clear_msg)
        self.eng.changed.connect(self.sync)
        self.eng.notice.connect(self.on_notice)
        pos = load_json("focus-float.json", None)
        scr = QGuiApplication.primaryScreen().availableGeometry()
        if isinstance(pos, dict) and scr.adjusted(-50, -50, 50, 50).contains(QPoint(int(pos.get("x", -1)), int(pos.get("y", -1)))):
            self.move(int(pos["x"]), int(pos["y"]))
        else:
            self.move(scr.right() - W - 24, scr.top() + 90)

    # ---- 显示
    def wanted(self) -> bool:
        st = self.eng.pomo
        return bool(self.eng.cfg.get("floater", True)) and (st.phase != "idle" or bool(self.msg))

    def sync(self):
        if self.wanted():
            if not self.isVisible():
                self.show()
            self.update()
        elif self.isVisible():
            self.hide()

    def on_notice(self, kind, text):
        if not text or kind == "remind":          # 0.3.19 起提醒有自己的通知卡片（notify.py），小窗不重复
            return
        self.msg = text
        self.setFixedSize(W, HN)
        self.msg_timer.start(12000 if kind != "nudge" else 9000)
        self.sync()

    def _clear_msg(self):
        self.msg = ""
        self.setFixedSize(W, H)
        self.sync()

    # ---- 键
    def _keys(self):
        return dict(toggle=QRectF(W - 74, 20, 28, 28), skip=QRectF(W - 40, 20, 28, 28))

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.pos()
            self._moved = False

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._drag is not None:
            p = e.globalPosition().toPoint() - self._drag
            if (p - self.pos()).manhattanLength() > 3:
                self._moved = True
            self.move(p)

    def mouseReleaseEvent(self, e):  # noqa: N802
        if self._drag is None:
            return
        self._drag = None
        if self._moved:
            save_json("focus-float.json", dict(x=self.x(), y=self.y()))
            return
        pos = e.position()
        k = self._keys()
        if k["toggle"].contains(pos):
            self.eng.toggle()
        elif k["skip"].contains(pos):
            self.eng.skip()
        elif self.msg and pos.y() > H - 6:
            self._clear_msg()
        elif self.open_page:
            self.open_page()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(qc(T.line2), 1))
        p.setBrush(qc(T.raised))
        p.drawRoundedRect(r, 12, 12)
        st = self.eng.state()
        col = qc(T.accent if st["phase"] == "focus" else T.ok if st["phase"] in ("short", "long") else T.muted)
        # 专注 / 休息一眼分开：左边一道阶段色，休息时整张卡片淡淡染上休息色
        if st["phase"] in ("short", "long"):
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.ok, 0.07))
            p.drawRoundedRect(r, 12, 12)
        p.fillRect(QRectF(r.left() + 1, 16, 3, H - 32), col)
        # 进度环
        ring = QRectF(14, 13, 48, 48)
        p.setPen(QPen(qc(T.fg, 0.08), 4))
        p.drawEllipse(ring)
        if st["length"]:
            frac = 1 - st["remaining"] / st["length"]
            pen = QPen(col, 4)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawArc(ring, 90 * 16, int(-frac * 360 * 16))
        p.setPen(col)
        p.setFont(font(11, 700))
        p.drawText(ring, int(Qt.AlignmentFlag.AlignCenter), st["name"])
        p.setPen(qc(T.fg if st["running"] else T.muted))
        p.setFont(font(22, 700, "mono"))
        p.drawText(QRectF(72, 10, 110, 30), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   mmss(st["remaining"]) if st["phase"] != "idle" else "--:--")
        p.setFont(font(11))
        p.setPen(qc(T.muted))
        what = " · ".join(x for x in (st["subject"], st["task"]) if x) or ("已暂停" if st["phase"] != "idle" and not st["running"] else "专注中")
        if st["interruptions"]:
            what += f" · 中断 {st['interruptions']}"
        p.drawText(QRectF(72, 40, W - 150, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   p.fontMetrics().elidedText(what, Qt.TextElideMode.ElideRight, W - 150))
        k = self._keys()
        for name, rect in k.items():
            p.setPen(QPen(qc(T.line2), 1))
            p.setBrush(qc(T.surface))
            p.drawRoundedRect(rect, 7, 7)
            icon = ("pause" if st["running"] else "play") if name == "toggle" else "chevron_r"
            draw_icon(p, icon, rect.adjusted(6, 6, -6, -6), qc(T.soft), 1.5)
        if self.msg:
            p.setPen(QPen(qc(T.line), 1))
            p.drawLine(14, H - 2, W - 14, H - 2)
            p.setPen(qc(T.soft))
            p.setFont(font(11.5))
            p.drawText(QRectF(14, H + 2, W - 28, HN - H - 8), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap), self.msg)
        p.end()


_FLOAT = None


def floater(open_page=None) -> FocusFloat:
    global _FLOAT
    if _FLOAT is None:
        _FLOAT = FocusFloat(open_page)
    elif open_page is not None:
        _FLOAT.open_page = open_page
    return _FLOAT
