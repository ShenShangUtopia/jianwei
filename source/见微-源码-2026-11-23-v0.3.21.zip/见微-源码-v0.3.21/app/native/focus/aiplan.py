"""AI 自动生成计划（0.3.20）：本地汇总学情 → AI（或规则版）出一周计划草稿 → 学生预览、增删改、重排 → 接受后才写进计划。

- digest()：本地先汇总成精简摘要再发给 AI。只有得分率、趋势、错因计数、知识点名、题库 id、诗词篇名、专注分钟、
  完成率、拖延次数、距高考天数、目标分、可用时段；不发题目全文、作答、评语、姓名等。
- generate()：有 AI 用 llm.ask_json 出结构化 JSON，check() 校验（时间不冲突、在可用时段里、题和篇目存在、不超过每天的量）；
  没密钥或 AI 失败用 rule_plan()，草稿上标 engine="rule"。
- 草稿存在 focus-aiplan.json：{draft, history[], auto{on, last}}。accept() 才写进 plan（source="ai"），AI 从不直接改计划。
- 每周自动草稿：auto_due(now) 为真时由引擎在后台生成下周草稿，推一条提醒，学生确认后才生效。
"""
from __future__ import annotations

import json
import time
from datetime import date, datetime, timedelta

from ..kit.home import load_json, save_json
from . import core, plan

FILE = "focus-aiplan.json"
SUBJECTS = ["数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理", "政治"]
KINDS = dict(weak="薄弱点", review="复习", recite="背诵", preview="预习", practice="练习", self="其他")

SYSTEM = """你是高中生的学习规划老师。下面是程序在本机汇总的学情摘要（JSON），以及要排计划的日期和每天可用时段。
请给出一周（只排给定的日期）的学习计划，落到具体知识点、题库题（用摘要里给的题目 id）、背诵篇目（用摘要里给的 poem_id）和番茄数。

要求：
1. 只排在每天的可用时段内，块与块、块与已有安排（busy）都不能重叠；开始时间写 "HH:MM"，按 15 分钟对齐；每块 15–120 分钟。
2. 每天总时长不超过 daily_budget 给的分钟数（它已经按这个学生的历史完成率打了折，不要排满）。
3. 优先：到期复习 > 得分率低、趋势下降的薄弱点 > 背诵 > 预习；离考试越近越偏重薄弱科目；照顾学生写的目标分和额外要求。
4. 每一块写一句 why（为什么这样排，引用摘要里的数据，比如得分率、到期数）。
5. 再给学情诊断（强项、弱项、风险各 1–4 条）和下一阶段建议（一段话），以及 2–4 条本周目标。
只输出 JSON，格式：
{"diagnosis":{"strengths":["…"],"weaknesses":["…"],"risks":["…"]},"advice":"…","week_goals":["…"],
 "days":[{"day":"YYYY-MM-DD","blocks":[{"start":"19:00","minutes":45,"subject":"数学","kind":"weak|review|recite|preview|practice",
   "task":"导数单调性：错题重做","points":["导数"],"qids":["题目id"],"poem_id":"","pomos":2,"why":"…"}]}]}"""


# ---------------------------------------------------------------- 存储
def _state():
    s = load_json(FILE, None)
    if not isinstance(s, dict):
        s = {}
    s.setdefault("draft", None)
    s.setdefault("history", [])
    s.setdefault("auto", dict(on=False, last=""))
    return s


def draft():
    return _state()["draft"]


def save_draft(d):
    s = _state()
    s["draft"] = d
    save_json(FILE, s)
    return d


def auto_settings() -> dict:
    return dict(_state()["auto"])


def set_auto(on: bool):
    s = _state()
    s["auto"]["on"] = bool(on)
    save_json(FILE, s)


# ---------------------------------------------------------------- 摘要
def days_to_gaokao(today: date) -> int | None:
    try:
        import store
        return max(0, (store.target_dt(store.load_config()).date() - today).days)
    except Exception:   # noqa: BLE001
        return None


def _bank_ids_for(point, wrong, n=3):
    try:
        from ..exam import records
        return [str(q.get("id")) for q in records.suggest(dict(point=point, wrong_q=wrong), n) if q.get("id")]
    except Exception:   # noqa: BLE001
        return []


def week_days(start: date, today: date) -> list[date]:
    """要排的日子：start 起的七天里，今天以后的。"""
    return [start + timedelta(days=i) for i in range(7) if start + timedelta(days=i) >= today]


def history_rate(today: date, days=14) -> float | None:
    bs = plan.blocks()
    recs = core.sessions()
    pl, dn = 0, 0
    for i in range(1, days + 1):
        p = plan.day_progress(today - timedelta(days=i), bs, recs)
        pl += p["planned"]
        dn += p["done_min"]
    return round(dn / pl, 4) if pl >= 60 else None


def budgets(days: list[date], today: date, now_min=None) -> dict:
    """每天最多排多少分钟：空闲时间 × 系数。系数按近两周计划完成率定（没记录按 0.75），夹在 0.5–0.9。"""
    r = history_rate(today)
    k = 0.75 if r is None else max(0.5, min(0.9, r + 0.1))
    out = {}
    for d in days:
        free = sum(e - s for s, e in plan.free_slots(d, now_min if d == today else None))
        out[d.isoformat()] = int(plan.snap(free * k)) if free >= 30 else 0
    return out


def digest(days: list[date], today: date | None = None, now_min=None, analysis=None) -> dict:
    """发给 AI 的精简摘要（也给规则版用）。"""
    today = today or date.today()
    if analysis is None:
        try:
            from ..exam import records
            analysis = records.analyze()
        except Exception:   # noqa: BLE001
            analysis = dict(subjects={}, weak=[], causes={}, exams=[])
    subj = {}
    for s, v in (analysis.get("subjects") or {}).items():
        tr = v.get("trend") or []
        subj[s] = dict(exam_rate=v.get("exam_rate"), practice_rate=v.get("practice_rate"), practice_n=v.get("practice_n", 0),
                       trend=tr[-4:], falling=len(tr) >= 2 and tr[-1] < tr[-2] - 0.05)
    weak = []
    for w in (analysis.get("weak") or [])[:8]:
        weak.append(dict(point=w["point"], subject=w.get("subject", ""), rate=w.get("rate"), n=w.get("n", 0),
                         qids=_bank_ids_for(w["point"], w.get("wrong_q", []))))
    causes = dict(sorted((analysis.get("causes") or {}).items(), key=lambda t: -t[1])[:6])
    due = {}
    try:
        from .. import learning
        for _k, it in learning.due():
            src = (it.get("card") or {}).get("src")
            key = "背诵" if src in ("word", "poem") else (it.get("subject") or "未分科")
            due[key] = due.get(key, 0) + 1
    except Exception:   # noqa: BLE001
        pass
    recite = dict(words=None, poems=[])
    try:
        from ..recite import core as rc
        ws = rc.word_stats()
        recite["words"] = dict(learned=ws["learned"], total=ws["total"])
        for p in rc.poems():
            st = rc.poem_state(p["id"])
            if st.get("best", 0) < 0.9:
                recite["poems"].append(dict(poem_id=p["id"], title=p["title"], best=round(st.get("best", 0), 2)))
            if len(recite["poems"]) >= 6:
                break
    except Exception:   # noqa: BLE001
        pass
    fs = core.summary(14, today=today)
    t = fs["total"]
    carried = [b for b in plan.blocks() if b.get("carried") and b["day"] >= (today - timedelta(days=14)).isoformat()]
    focus = dict(minutes_14d=t["focus_min"], pomodoro_done=t["done"], pomodoro_started=t["started"],
                 plan_rate_14d=history_rate(today), carried_blocks=len(carried),
                 most_carried=[dict(task=b.get("task", ""), times=b["carried"]) for b in sorted(carried, key=lambda b: -b["carried"])[:3]],
                 subject_minutes=fs["subjects"])
    gp = plan.goal_progress(analysis)
    busy = {d.isoformat(): [f"{plan.hhmm(b['start'])}-{plan.hhmm(b['start'] + b['minutes'])} {b.get('subject') or ''}{' 考试' if b.get('source') == 'exam' else ''}"
                            for b in plan.blocks(d.isoformat())] for d in days}
    avail = {d.isoformat(): [f"{plan.hhmm(s)}-{plan.hhmm(e)}" for s, e in plan.free_slots(d, now_min if d == today else None)] for d in days}
    return dict(today=today.isoformat(), days_to_gaokao=days_to_gaokao(today),
                goals=dict(total=gp["total"], subjects={r["subject"]: dict(target=r["target"], current=r["current"]) for r in gp["subjects"]}),
                subjects=subj, weak_points=weak, error_causes=causes, due_review=due, recite=recite, focus=focus,
                dates=[d.isoformat() for d in days], free=avail, busy=busy, daily_budget=budgets(days, today, now_min))


# ---------------------------------------------------------------- 校验
def _valid_qids():
    try:
        from ..bank.data import bank
        bank.load()
        return bank.by_id
    except Exception:   # noqa: BLE001
        return {}


def _valid_poems():
    try:
        from ..recite import core as rc
        return {p["id"]: p["title"] for p in rc.poems()}
    except Exception:   # noqa: BLE001
        return {}


def make_check(dg: dict):
    """校验 AI 的 JSON：日期在范围内、时间在可用时段里、不和已有安排 / 彼此重叠、每天不超量、题和篇目存在。"""
    dates = set(dg["dates"])
    free = {d: plan.parse_ranges(", ".join(v)) for d, v in dg["free"].items()}
    qids = _valid_qids()
    poems = _valid_poems()

    def check(js):
        errs = []
        if not isinstance(js, dict) or not isinstance(js.get("days"), list):
            return dict(ok=False, errors=["缺少 days 数组"])
        out_days = []
        kept = 0
        total = 0
        for d in js["days"]:
            if not isinstance(d, dict):
                errs.append("days 里每一项都要是 {day, blocks} 对象")
                continue
            day = str(d.get("day", ""))
            if day not in dates:
                errs.append(f"日期 {day} 不在要排的范围里（只能是 {', '.join(sorted(dates))}）")
                continue
            used, blocks = [], []
            for b in d.get("blocks") if isinstance(d.get("blocks"), list) else []:
                total += 1
                if not isinstance(b, dict):
                    errs.append(f"{day}：blocks 里每一项都要是对象")
                    continue
                try:
                    pomos = max(0, min(8, int(b.get("pomos") or 0)))
                except (TypeError, ValueError):
                    pomos = 0
                st = plan.parse_hhmm(b.get("start"))
                try:
                    mins = int(b.get("minutes") or 0)
                except (TypeError, ValueError):
                    mins = 0
                name = f"{day} {b.get('start')} {b.get('task', '')[:12]}"
                if st is None or not 15 <= mins <= 120:
                    errs.append(f"{name}：开始时间要写 HH:MM，时长 15–120 分钟")
                    continue
                st, mins = plan.snap(st), plan.snap(mins)
                if not any(a <= st and st + mins <= e for a, e in free.get(day, [])):
                    errs.append(f"{name}：不在这天的可用时段 {dg['free'].get(day)} 里")
                    continue
                if any(st < y and x < st + mins for x, y in used):
                    errs.append(f"{name}：和这天别的块时间重叠")
                    continue
                bad_q = [q for q in (b.get("qids") or []) if str(q) not in qids]
                if bad_q:
                    errs.append(f"{name}：题库里没有这些题 id：{', '.join(map(str, bad_q[:3]))}")
                    continue
                pid = str(b.get("poem_id") or "")
                if pid and pid not in poems:
                    errs.append(f"{name}：没有 poem_id {pid}")
                    continue
                subj = str(b.get("subject") or "")
                if subj and subj not in SUBJECTS:
                    errs.append(f"{name}：科目 {subj} 不认识")
                    continue
                task = str(b.get("task") or "").strip()
                if not task:
                    errs.append(f"{name}：task 不能为空")
                    continue
                used.append((st, st + mins))
                blocks.append(dict(day=day, start=st, minutes=mins, subject=subj, task=task[:60],
                                   kind=b.get("kind") if b.get("kind") in KINDS else "self",
                                   points=[str(x)[:20] for x in (b.get("points") or [])][:3], qids=[str(q) for q in (b.get("qids") or [])][:5],
                                   poem_id=pid, pomos=pomos, why=str(b.get("why") or "")[:120],
                                   on=True))
            budget = dg["daily_budget"].get(day, 0)
            if sum(x["minutes"] for x in blocks) > budget * 1.1 + 15:
                errs.append(f"{day} 一共排了 {sum(x['minutes'] for x in blocks)} 分钟，超过了 daily_budget {budget}")
                while blocks and sum(x["minutes"] for x in blocks) > budget * 1.1 + 15:
                    blocks.pop()
            if any(not x["why"] for x in blocks):
                errs.append(f"{day}：每块都要写 why")
            kept += len(blocks)
            out_days.append(dict(day=day, blocks=blocks))
        dia = js.get("diagnosis") if isinstance(js.get("diagnosis"), dict) else {}
        value = dict(days=sorted(out_days, key=lambda x: x["day"]),
                     diagnosis={k: [str(x)[:80] for x in (dia.get(k) or [])][:4] for k in ("strengths", "weaknesses", "risks")},
                     advice=str(js.get("advice") or "")[:400], week_goals=[str(x)[:40] for x in (js.get("week_goals") or [])][:5])
        if not kept and total:
            errs.append("一块合格的都没有")
        if errs:
            return dict(ok=False, errors=errs[:12], fallback=value if kept >= max(1, total // 2) else None)
        return dict(ok=True, value=value)
    return check


# ---------------------------------------------------------------- 规则版
def rule_plan(dg: dict, request: str = "") -> dict:
    """没有密钥时：到期复习优先，薄弱点按（1−得分率）加权轮流排，再补背诵和预习；每天不超过 daily_budget。"""
    lighter = any(w in request for w in ("轻松", "少一点", "少排", "累"))
    favor = next((s for s in SUBJECTS if s in request and any(w in request for w in ("多", "加强", "重点"))), "")
    weak = sorted(dg["weak_points"], key=lambda w: (w["subject"] != favor, w.get("rate") if w.get("rate") is not None else 1))
    due = dg["due_review"]
    poems = list(dg["recite"]["poems"])
    days = []
    wi = 0
    for i, d in enumerate(dg["dates"]):
        slots = plan.parse_ranges(", ".join(dg["free"][d]))
        budget = int(dg["daily_budget"].get(d, 0) * (0.7 if lighter else 1))
        items = []
        if i == 0 and due:
            for k, n in sorted(due.items(), key=lambda t: -t[1])[:2]:
                items.append(dict(subject="" if k in ("背诵", "未分科") else k, kind="review", task=f"复习到期 {n} 项" + (f"（{k}）" if k else ""),
                                  minutes=max(15, min(45, plan.snap(n * 5))), why=f"有 {n} 项到期，先过掉"))
        elif due:
            items.append(dict(subject="", kind="review", task="当天到期复习", minutes=15, why="间隔复习每天都有新到期的"))
        for _ in range(2):
            if weak:
                w = weak[wi % len(weak)]
                wi += 1
                r = w.get("rate")
                items.append(dict(subject=w["subject"], kind="weak", task=f"{w['point']}：错题重做 + 同类题", points=[w["point"]],
                                  qids=w.get("qids", [])[:3], minutes=45 if r is not None and r < 0.5 else 30, pomos=2 if r is not None and r < 0.5 else 1,
                                  why=(f"得分率 {int(r * 100)}%，" if r is not None else "") + ("偏好要求多练" if w["subject"] == favor else "是目前最弱的点之一")))
        if favor and not any(x["subject"] == favor for x in items):
            items.append(dict(subject=favor, kind="practice", task=f"{favor}综合练习", minutes=30, why="你要求多练" + favor))
        if poems and i % 2 == 0:
            p = poems[(i // 2) % len(poems)]
            items.append(dict(subject="语文", kind="recite", task="背诵：" + p["title"], poem_id=p["poem_id"], minutes=15,
                              why="还没默写到九成" if p["best"] else "还没背过"))
        w = dg["recite"].get("words")
        if w and w["learned"] < w["total"]:
            items.append(dict(subject="英语", kind="recite", task="背单词 20 个", minutes=15, why=f"词表学会 {w['learned']}/{w['total']}"))
        blocks, used = [], 0
        for it in items:
            m = it["minutes"]
            if used + m > budget:
                continue
            for sl in slots:
                if sl[1] - sl[0] >= m:
                    blocks.append(dict(day=d, start=sl[0], minutes=m, subject=it.get("subject", ""), task=it["task"], kind=it["kind"],
                                       points=it.get("points", []), qids=it.get("qids", []), poem_id=it.get("poem_id", ""),
                                       pomos=it.get("pomos", 0), why=it["why"], on=True))
                    sl[0] += m
                    used += m
                    break
        days.append(dict(day=d, blocks=blocks))
    subj = dg["subjects"]
    rated = [(s, v.get("exam_rate") if v.get("exam_rate") is not None else v.get("practice_rate")) for s, v in subj.items()]
    rated = [(s, r) for s, r in rated if r is not None]
    strengths = [f"{s} 得分率 {int(r * 100)}%" for s, r in sorted(rated, key=lambda t: -t[1])[:2] if r >= 0.75]
    weaknesses = [f"{w['point']}（{w['subject']}）得分率 {int((w.get('rate') or 0) * 100)}%" for w in dg["weak_points"][:3]]
    risks = [f"{s} 成绩在下降" for s, v in subj.items() if v.get("falling")]
    fr = dg["focus"]
    if fr.get("plan_rate_14d") is not None and fr["plan_rate_14d"] < 0.6:
        risks.append(f"近两周计划只完成了 {int(fr['plan_rate_14d'] * 100)}%，这周排得更少一点")
    if fr.get("carried_blocks"):
        risks.append(f"有 {fr['carried_blocks']} 块顺延过，拖得最久的是「{fr['most_carried'][0]['task']}」")
    goals = [f"{w['point']}的错题清零" for w in dg["weak_points"][:2]] + (["每天过完到期复习"] if due else [])
    return dict(days=days, diagnosis=dict(strengths=strengths, weaknesses=weaknesses, risks=risks[:4]),
                advice=("先把薄弱点的错题吃透，再做同类题；" if weaknesses else "目前没有明显的薄弱点，保持节奏、多做综合题；")
                + ("到期复习每天先做。" if due else "") + (f"离高考还有 {dg['days_to_gaokao']} 天。" if dg.get("days_to_gaokao") is not None else ""),
                week_goals=goals[:4] or ["每天至少完成两个番茄"])


# ---------------------------------------------------------------- 生成 / 重排 / 接受
def ai_ready() -> bool:
    try:
        from ..analysis import llm
        return bool(llm.available())
    except Exception:   # noqa: BLE001
        return False


def _prompt(dg, request="", previous=None):
    s = "学情摘要：\n" + json.dumps(dg, ensure_ascii=False)
    if previous:
        s += "\n\n上一版计划（学生看过了，要按要求重排）：\n" + json.dumps(dict(days=previous.get("days"), week_goals=previous.get("week_goals")), ensure_ascii=False)
    if request:
        s += "\n\n学生的额外要求：" + str(request)[:200]
    return s


def generate(start: date, today: date | None = None, now_min=None, request: str = "", previous=None, engine=None,
             status=None, analysis=None) -> dict:
    """出一份草稿（不写进计划）。engine 不给且有密钥时用真 AI；没有密钥用规则版。AI 失败也退回规则版并写明原因。"""
    today = today or date.today()
    days = week_days(start, today)
    dg = digest(days, today, now_min, analysis)
    note = ""
    value = None
    eng_name = "rule"
    if engine is not None or ai_ready():
        try:
            from ..analysis import llm
            engine = engine or llm.Engine(SYSTEM)
            res = llm.ask_json(engine, _prompt(dg, request, previous), make_check(dg), repairs=1, status=status)
            value = res["value"]
            eng_name = "ai"
            if res.get("dropped"):
                note = f"AI 的结果有 {len(res['dropped'])} 处不合格，已去掉"
        except Exception as exc:   # noqa: BLE001
            note = f"AI 没排成（{str(exc)[:60]}），先用规则版"
    else:
        note = "没有 AI 密钥：这是规则版（按薄弱点加权、到期复习优先），在 设置 → AI 服务 填密钥后能让 AI 排"
    if value is None:
        value = rule_plan(dg, request)
    d = dict(value, start=start.isoformat(), dates=dg["dates"], engine=eng_name, note=note, request=request,
             created=time.time(), status="draft", budget=dg["daily_budget"])
    return save_draft(d)


def items_of(d) -> list[dict]:
    return [b for day in (d or {}).get("days", []) for b in day.get("blocks", [])]


def edit_item(d, day, i, **kw) -> dict:
    """改草稿里的一项（start 分钟、minutes、task、subject、on）。"""
    for x in d["days"]:
        if x["day"] == day and 0 <= i < len(x["blocks"]):
            b = x["blocks"][i]
            if "start" in kw or "minutes" in kw:
                st, mi = plan._clamp(kw.get("start", b["start"]), kw.get("minutes", b["minutes"]))
                kw["start"], kw["minutes"] = st, mi
            b.update(kw)
    return save_draft(d)


def remove_item(d, day, i) -> dict:
    for x in d["days"]:
        if x["day"] == day and 0 <= i < len(x["blocks"]):
            x["blocks"].pop(i)
    return save_draft(d)


def add_item(d, day, subject="", task="自己加的一项", minutes=30) -> dict:
    x = next((x for x in d["days"] if x["day"] == day), None)
    if x is None:
        x = dict(day=day, blocks=[])
        d["days"].append(x)
        d["days"].sort(key=lambda t: t["day"])
    taken = [(b["start"], b["start"] + b["minutes"]) for b in x["blocks"]] + \
            [(b["start"], b["start"] + b["minutes"]) for b in plan.blocks(day)]
    slots = plan.parse_ranges(plan.ranges_text(plan.avail_for(date.fromisoformat(day))))
    st = None
    for a, e in slots:
        t = a
        while t + minutes <= e:
            if all(t + minutes <= p or t >= q for p, q in taken):
                st = t
                break
            t += plan.STEP
        if st is not None:
            break
    x["blocks"].append(dict(day=day, start=st if st is not None else plan.next_free(day, minutes, after=19 * 60), minutes=minutes,
                            subject=subject, task=task, kind="self", points=[], qids=[], poem_id="", pomos=0, why="自己加的", on=True))
    x["blocks"].sort(key=lambda b: b["start"])
    return save_draft(d)


def conflicts(d) -> list[str]:
    """草稿里互相重叠、或和已有计划重叠的项（学生改过时间以后用）。"""
    out = []
    for x in d.get("days", []):
        on = [b for b in x["blocks"] if b.get("on", True)]
        exist = [(b["start"], b["start"] + b["minutes"]) for b in plan.blocks(x["day"])]
        for i, b in enumerate(on):
            s, e = b["start"], b["start"] + b["minutes"]
            if any(s < q and p < e for p, q in exist) or any(s < c["start"] + c["minutes"] and c["start"] < e for c in on[i + 1:]):
                out.append(f"{x['day'][5:]} {plan.hhmm(s)} {b['task'][:10]}")
    return out


def accept(d=None, only_on=True) -> list[dict]:
    """接受草稿：勾选的项写进计划（source=ai，带 why、子任务＝要做的题）；本周目标写进周目标。"""
    d = d or draft()
    if not d or d.get("status") == "accepted":        # 同一份草稿只写一次
        return []
    items = []
    for b in items_of(d):
        if only_on and not b.get("on", True):
            continue
        subs = [f"题 {q}" for q in b.get("qids", [])[:5]]
        items.append(dict(day=b["day"], start=b["start"], minutes=b["minutes"], subject=b.get("subject", ""), task=b["task"],
                          source="ai", ref=("poem:" + b["poem_id"]) if b.get("poem_id") else ("qids:" + ",".join(b.get("qids", []))),
                          priority=2 if b.get("kind") in ("weak", "review") else 1, why=b.get("why", ""), pomos=b.get("pomos", 0),
                          subtasks=subs))
    made = plan.accept(items)
    if d.get("week_goals"):
        day0 = date.fromisoformat(d["dates"][0]) if d.get("dates") else date.today()
        cur = plan.week(day0)["goals"]
        have = {g["t"] for g in cur}
        plan.set_week(day0, cur + [dict(t=g, done=False) for g in d["week_goals"] if g not in have])
    s = _state()
    d["status"] = "accepted"
    d["accepted"] = time.time()
    s["history"] = (s["history"] + [dict(start=d.get("start"), engine=d.get("engine"), n=len(made), t=d["accepted"])])[-20:]
    s["draft"] = d
    save_json(FILE, s)
    return made


# ---------------------------------------------------------------- 每周自动草稿
def next_week_start(today: date) -> date:
    return today - timedelta(days=today.weekday()) + timedelta(days=7)


def auto_due(now: datetime) -> bool:
    """每周日 17 点以后（或周日以后第一次打开）还没给下周出过草稿：该自动出一份。"""
    a = auto_settings()
    if not a.get("on"):
        return False
    today = now.date()
    if today.weekday() != 6 or now.hour < 17:
        return False
    nxt = next_week_start(today).isoformat()
    d = draft()
    return a.get("last") != nxt and not (d and d.get("start") == nxt)


def mark_auto(start: date):
    s = _state()
    s["auto"]["last"] = start.isoformat()
    save_json(FILE, s)
