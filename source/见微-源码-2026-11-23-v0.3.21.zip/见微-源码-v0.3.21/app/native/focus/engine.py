"""专注引擎：整个程序只有一个（engine()），番茄钟、监督、计划提醒都在这里跑；页面、悬浮窗、托盘只是它的显示。

定时器：番茄在走时每秒一跳（顺带问一次监督），没在走时每 30 秒看一次计划提醒。
自测：engine(clock=假时钟, probe=假探针, now_dt=假的 datetime 函数)，然后手动调 step()。
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta

from PySide6.QtCore import QObject, QTimer, Signal

from . import core, plan, remind
from .watch import Probe, Supervisor

_ENGINE = None


def engine(**kw) -> "FocusEngine":
    global _ENGINE
    if _ENGINE is None or kw:
        if _ENGINE is not None:
            _ENGINE.timer.stop()
        _ENGINE = FocusEngine(**kw)
    return _ENGINE


class FocusEngine(QObject):
    changed = Signal()               # 状态变了（每秒也发，界面刷新数字）
    notice = Signal(str, str)        # (种类, 文字)：done 阶段结束 / nudge 监督提醒 / remind 计划到点
    recorded = Signal()              # 记下了一个番茄（统计要刷新）
    reminder = Signal(dict)          # 0.3.19 每日提醒（带键的通知卡片、托盘气泡用）：remind.check 的一项
    planChanged = Signal()           # 跨天顺延、按重复规则补了块

    def __init__(self, clock=time.time, probe=None, now_dt=datetime.now):
        super().__init__()
        self.clock, self.now_dt = clock, now_dt
        self.probe = probe or Probe()
        self.cfg = core.settings()
        self.pomo = core.Pomodoro(clock, self.cfg)
        self.sup = Supervisor()
        self.last_notice = ("", "")
        self.last_reminders = []
        self._day = None
        self._remind_at = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.step)
        self._arm()

    def _arm(self):
        self.timer.start(1000 if self.pomo.running else 30000)

    def reload_settings(self):
        self.cfg.clear()
        self.cfg.update(core.settings())
        self.changed.emit()

    def state(self):
        return self.pomo.state()

    def _say(self, kind, text):
        self.last_notice = (kind, text)
        self.notice.emit(kind, text)

    # ---- 操作
    def start(self, subject="", task="", block=""):
        self.pomo.start(subject, task, block)
        self.sup.reset()
        self._arm()
        self.changed.emit()

    def start_block(self, bid):
        b = plan.get(bid)
        if b:
            if self.pomo.phase != "idle":
                return False
            self.pomo.next_phase = "focus"
            self.start(b.get("subject", ""), b.get("task", ""), bid)
            return True
        return False

    def pause(self):
        self.pomo.pause()
        self._arm()
        self.changed.emit()

    def resume(self):
        self.pomo.resume()
        self._arm()
        self.changed.emit()

    def toggle(self):
        if self.pomo.phase == "idle":
            self.start()
        elif self.pomo.running:
            self.pause()
        else:
            self.resume()

    def skip(self):
        rec = self.pomo.skip()
        self._recorded(rec)
        self._arm()
        self.changed.emit()

    def abandon(self, reason=""):
        rec = self.pomo.abandon(reason)       # 严格模式没理由会抛 ValueError，由界面接住
        self.sup.reset()
        self._recorded(rec)
        self._arm()
        self.changed.emit()
        return rec

    def _recorded(self, rec):
        if not rec:
            return
        if rec.get("block") and rec.get("focus"):
            plan.add_focus(rec["block"], rec["focus"])
        self.recorded.emit()

    # ---- 计划：跨天顺延 + 每日提醒
    def _daily(self):
        now = self.now_dt()
        if self._day != now.date():
            self._day = now.date()
            try:
                moved = plan.rollover(now.date(), now.hour * 60 + now.minute)
                n = plan.ensure_repeats([now.date() + timedelta(days=i) for i in range(8)], now.date())
                if moved or n:
                    self.planChanged.emit()
            except Exception:   # noqa: BLE001  计划文件坏了不影响番茄
                pass
        # 番茄在走时每秒一跳；提醒到分钟就够，20 秒看一次
        if self._remind_at is not None and abs(now.timestamp() - self._remind_at) < 20:
            return
        self._remind_at = now.timestamp()
        self._auto_plan(now)
        try:
            items = remind.check(now, self.cfg)
        except Exception:   # noqa: BLE001
            items = []
        live = [it for it in items if not it.get("missed")]
        missed = remind.merge_missed([it for it in items if it.get("missed")])
        for it in ([missed] if missed else []) + live:
            self.last_reminders = (self.last_reminders + [it])[-20:]
            self._say("remind", it["text"].split("\n")[0] if it["kind"] != "missed" else it["title"])
            self.reminder.emit(it)

    # ---- 每周自动出下周计划草稿（0.3.20）：后台生成，推一条提醒；学生确认后才写进计划
    def _auto_plan(self, now, sync=False, engine=None):
        try:
            from . import aiplan
            if getattr(self, "_aiw", None) is not None or not aiplan.auto_due(now):
                return
            start = aiplan.next_week_start(now.date())
            aiplan.mark_auto(start)
            job = lambda: aiplan.generate(start, today=now.date(), engine=engine)   # noqa: E731
            if sync:
                self._auto_done(job())
                return
            from ..exam.page import Worker
            self._aiw = Worker(job)
            self._aiw.done.connect(self._auto_done)
            self._aiw.failed.connect(lambda _e: setattr(self, "_aiw", None))
            self._aiw.start()
        except Exception:   # noqa: BLE001
            self._aiw = None

    def _auto_done(self, d):
        self._aiw = None
        if not d:
            return
        from . import aiplan
        n = len(aiplan.items_of(d))
        item = dict(key="aiplan:" + d.get("start", ""), kind="aiplan", title="下周计划草稿",
                    text=f"按学情排好了下周 {n} 项（{'AI' if d.get('engine') == 'ai' else '规则版'}）。看一眼、改一改，确认后才会写进计划。",
                    missed=False)
        self.last_reminders = (self.last_reminders + [item])[-20:]
        self._say("remind", item["text"])
        self.reminder.emit(item)

    def remind_start(self, item) -> bool:
        """提醒卡片上的「开始番茄」。"""
        if self.pomo.phase != "idle":
            return False
        if item.get("block") and plan.get(item["block"]):
            return self.start_block(item["block"])
        if item.get("kind") == "morning":
            now = self.now_dt()
            m = now.hour * 60 + now.minute
            todo = [b for b in plan.blocks(now.date().isoformat()) if not b.get("done") and b["start"] + b["minutes"] > m
                    and b.get("source") != "exam"]
            if todo:
                return self.start_block(todo[0]["id"])
        self.pomo.next_phase = "focus"
        self.start(item.get("subject", ""), item.get("task", ""))
        return True

    def remind_snooze(self, item, minutes=10):
        remind.snooze(item, minutes, self.now_dt())

    # ---- 时钟
    def step(self):
        now = self.clock()
        p = self.pomo
        before = p.session
        events = p.tick(now)
        if "focus_done" in events:
            rec = core.sessions()[-1] if before is not None else None
            self._recorded(rec)
            nxt = core.PHASE_NAME[p.phase if p.phase != "idle" else p.next_phase]
            self._say("done", f"完成一个番茄（本轮第 {p.count} 个）。接下来：{nxt}。")
        elif "break_done" in events:
            self._say("done", "休息结束，开始下一个番茄吧。" if p.phase == "idle" else "休息结束，下一个番茄开始了。")
        if p.running and p.phase == "focus":
            try:
                st = self.probe.read()
            except Exception:   # noqa: BLE001  读不到前台窗口就不监督这一秒
                st = None
            if st is not None:
                msg = self.sup.check(p, now, st, self.cfg)
                if msg:
                    self._say("nudge", msg)
        elif self.sup.away_logged or self.sup.idle_logged:
            self.sup.check(p, now, dict(own=True, idle=0), self.cfg)
        self._daily()
        if events or self.timer.interval() != (1000 if p.running else 30000):
            self._arm()
        self.changed.emit()
