"""0.3.20 AI 自动生成计划的离屏自测：摘要不带原文和隐私、规则版、假 AI（合格 / 不合格→修正 / 一直不合格→退回规则版 / 部分不合格）、
预览里勾选 / 改 / 删 / 加 / 冲突、按要求重排、接受才写进计划、每周自动草稿、入口（专注页、考情、问 AI）。全用假引擎。"""
from ..kit import test_runtime
test_runtime.configure()
import json
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path


class FakeEngine:
    """按顺序回 replies 里的 JSON（dict 会转成字符串）；记下收到的消息。"""

    def __init__(self, *replies):
        self.replies, self.calls, self.seen = list(replies), 0, []

    def ask(self, messages, deep=False, status=None, **_kw):
        self.seen.append(messages)
        r = self.replies[min(self.calls, len(self.replies) - 1)]
        self.calls += 1
        return (json.dumps(r, ensure_ascii=False) if not isinstance(r, str) else r), False


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    fails, log = [], []

    def check(name, ok, detail=""):
        log.append(("OK  " if ok else "FAIL") + " " + name + ("" if ok else f"  {str(detail)[:600]}"))
        if not ok:
            fails.append(name)

    def spin(sec=0.05):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from . import aiplan, core, plan
    from ..exam import grade, paper, records
    from ..bank.data import bank
    from ..recite import core as rc
    from .. import learning

    # 学情：一次数学考试（制造薄弱点）、到期复习、背诵进度、专注记录、目标
    ex = paper.new_exam(paper.from_bank("数学", 6, ["单选"], seed=5), "月考", "数学")
    ex["answers"] = {}
    ex["report"] = grade.offline(ex)
    ex["submitted"] = time.time()
    records.upsert(ex)
    learning.add_card(dict(n="动量守恒", d="系统合外力为零", f=[], p=[]), "物理")
    rc.add_word("abandon", "放弃")
    plan.set_goals(total=600, subjects=dict(数学=130, 物理=80))
    plan.set_avail(weekday=[[18 * 60 + 30, 22 * 60]], weekend=[[9 * 60, 11 * 60 + 30], [14 * 60, 17 * 60]])
    base = date.today() + timedelta(days=7 - date.today().weekday())      # 下周一
    days = [base + timedelta(days=i) for i in range(7)]
    today = base - timedelta(days=1)                                       # 假装今天是周日
    plan.add(days[1].isoformat(), 19 * 60, 60, "英语", "已有安排：网课")

    # ------------------------------------------------ 摘要
    an = records.analyze()
    dg = aiplan.digest(days, today, analysis=an)
    raw = json.dumps(dg, ensure_ascii=False)
    stems = [str(q.get("stem") or q.get("q") or q.get("question") or "")[:20] for q in ex["questions"]]
    check("摘要不带题目原文", not any(s and len(s) >= 8 and s in raw for s in stems), [s for s in stems if s and s in raw][:2])
    check("摘要不带密钥、姓名、作答", "key" not in dg and "answers" not in raw and "name" not in dg)
    check("摘要有：得分率与趋势、薄弱点（带题库 id）、错因、到期复习、背诵、专注、目标、距高考、可用时段、每天上限",
          dg["subjects"] and dg["weak_points"] and all(isinstance(w["qids"], list) for w in dg["weak_points"]) and dg["due_review"]
          and dg["recite"]["words"] and "minutes_14d" in dg["focus"] and dg["goals"]["subjects"].get("数学", {}).get("target") == 130
          and isinstance(dg["days_to_gaokao"], int) and len(dg["free"]) == 7 and all(v >= 0 for v in dg["daily_budget"].values()), raw[:400])
    check("已有安排扣出可用时段、写进 busy", "19:00-20:00 英语" in dg["busy"][days[1].isoformat()][0]
          and not any("19:00" <= s.split("-")[0] < "20:00" for s in dg["free"][days[1].isoformat()]), (dg["busy"], dg["free"][days[1].isoformat()]))
    check("每天上限按完成率打折（没有记录按 0.75）", dg["daily_budget"][days[0].isoformat()] == plan.snap(210 * 0.75), dg["daily_budget"])
    check("题库 id 都真实存在", all(q in bank.by_id for w in dg["weak_points"] for q in w["qids"]))

    # ------------------------------------------------ 规则版（没有密钥）
    n_before = len(plan.blocks())
    d = aiplan.generate(base, today=today, analysis=an)
    check("没密钥用规则版，界面上标明", d["engine"] == "rule" and "规则版" in d["note"] and d["status"] == "draft", d.get("note"))
    check("生成草稿不会写进计划", len(plan.blocks()) == n_before)
    ok_time, ok_budget = True, True
    for x in d["days"]:
        fr = plan.parse_ranges(", ".join(dg["free"][x["day"]]))
        used = []
        for b in x["blocks"]:
            if not any(a <= b["start"] and b["start"] + b["minutes"] <= e for a, e in fr) or any(b["start"] < q and p < b["start"] + b["minutes"] for p, q in used):
                ok_time = False
            used.append((b["start"], b["start"] + b["minutes"]))
        if sum(b["minutes"] for b in x["blocks"]) > d["budget"][x["day"]]:
            ok_budget = False
    check("规则版：都在可用时段里、不重叠", ok_time)
    check("规则版：每天不超过上限", ok_budget, [(x["day"], sum(b["minutes"] for b in x["blocks"])) for x in d["days"]])
    items = aiplan.items_of(d)
    check("规则版：到期复习排第一天、薄弱点带题、每项有理由", d["days"][0]["blocks"] and d["days"][0]["blocks"][0]["kind"] == "review"
          and any(b["kind"] == "weak" and b["qids"] for b in items) and all(b["why"] for b in items), [(b["task"], b["kind"]) for b in items[:5]])
    check("规则版：诊断、建议、周目标", d["diagnosis"]["weaknesses"] and d["advice"] and d["week_goals"], d["diagnosis"])
    light = aiplan.generate(base, today=today, request="这周更轻松一点", analysis=an)
    check("规则版也能按「更轻松」重排：总量变少", sum(b["minutes"] for b in aiplan.items_of(light)) < sum(b["minutes"] for b in items))
    more = aiplan.generate(base, today=today, request="多练物理", analysis=an)
    check("规则版按「多练某科」加这一科", sum(1 for b in aiplan.items_of(more) if b["subject"] == "物理") > sum(1 for b in items if b["subject"] == "物理"))

    # ------------------------------------------------ 假 AI
    qid = next(iter(bank.by_id))
    pid = rc.poems()[0]["id"]
    d0, d1 = days[0].isoformat(), days[1].isoformat()
    good = dict(diagnosis=dict(strengths=["计算稳"], weaknesses=["导数"], risks=["数学在下降"]), advice="先补导数。", week_goals=["导数错题清零"],
                days=[dict(day=d0, blocks=[dict(start="18:30", minutes=45, subject="数学", kind="weak", task="导数：错题重做", qids=[qid], pomos=2, why="得分率 40%"),
                                           dict(start="19:30", minutes=15, subject="语文", kind="recite", task="背诵", poem_id=pid, why="还没背过")]),
                      dict(day=d1, blocks=[dict(start="20:00", minutes=60, subject="物理", kind="review", task="动量复习", why="到期 1 项")])])
    fe = FakeEngine(good)
    d = aiplan.generate(base, today=today, engine=fe, analysis=an)
    check("假 AI 合格：一次通过、标 AI", d["engine"] == "ai" and fe.calls == 1 and len(aiplan.items_of(d)) == 3, (d.get("note"), fe.calls))
    sent = fe.seen[0][0]["content"] if isinstance(fe.seen[0], list) else str(fe.seen[0])
    check("发给 AI 的只有摘要（没有题目原文）", "学情摘要" in sent and not any(s and len(s) >= 8 and s in sent for s in stems))
    bad = json.loads(json.dumps(good))
    bad["days"][0]["blocks"].append(dict(start="18:45", minutes=30, subject="数学", task="重叠的", why="x"))       # 重叠
    bad["days"][1]["blocks"].append(dict(start="19:00", minutes=30, subject="英语", task="压网课", why="x"))      # 压已有安排
    bad["days"].append(dict(day="2000-01-01", blocks=[]))                                                        # 日期不在范围
    bad["days"][0]["blocks"].append(dict(start="21:00", minutes=30, subject="数学", task="假题", qids=["no-such-id"], why="x"))
    fe = FakeEngine(bad, good)
    d = aiplan.generate(base, today=today, engine=fe, analysis=an)
    errs = fe.seen[1][-1]["content"] if fe.calls > 1 else ""
    check("假 AI 不合格：把问题发回去修正，第二次合格", fe.calls == 2 and d["engine"] == "ai" and len(aiplan.items_of(d)) == 3, (fe.calls, d.get("note")))
    check("校验抓到：重叠、压已有安排、日期越界、题不存在", all(k in errs for k in ("重叠", "可用时段", "不在要排的范围", "no-such-id")), errs[:400])
    fe = FakeEngine("这不是 JSON", "还不是")
    d = aiplan.generate(base, today=today, engine=fe, analysis=an)
    check("AI 一直不合格：退回规则版并写明原因", d["engine"] == "rule" and "AI 没排成" in d["note"], d.get("note"))
    over = json.loads(json.dumps(good))
    over["days"][0]["blocks"] = [dict(start="18:30", minutes=120, subject="数学", task="猛刷", why="多"),
                                 dict(start="20:30", minutes=90, subject="物理", task="猛刷2", why="多")]
    fe = FakeEngine(over, over)
    d = aiplan.generate(base, today=today, engine=fe, analysis=an)
    tot0 = sum(b["minutes"] for b in d["days"][0]["blocks"]) if d["days"] else 0
    check("超过每天上限：修正不了就去掉超出的项", tot0 <= dg["daily_budget"][d0] * 1.1 + 15, (tot0, d.get("note"), d["engine"]))

    chk = aiplan.make_check(dg)
    weird_ok = True
    for js in ({}, dict(days="x"), dict(days=["x"]), dict(days=[dict(day=d0, blocks=["x"])]), [1, 2],
               dict(days=[dict(day=d0, blocks=[dict(start="18:30", minutes=30, pomos="两个", task="a", why="b")])])):
        try:
            r = chk(js)
            weird_ok = weird_ok and (r["ok"] or r.get("errors"))
        except Exception:   # noqa: BLE001
            weird_ok = False
    check("校验遇到怪 JSON（字符串当对象、番茄数写汉字）不崩，给出能发回去的错误", weird_ok)
    plan.set_avail(weekday=[[0, 24 * 60]], weekend=[[5 * 60, 6 * 60 + 10]])
    check("可用时段夹到 6:00–23:00，太短的段丢掉", plan.avail() == dict(weekday=[[360, 1380]], weekend=[]), plan.avail())
    plan.set_avail(weekday=[[18 * 60 + 30, 22 * 60]], weekend=[[9 * 60, 11 * 60 + 30], [14 * 60, 17 * 60]])

    # ------------------------------------------------ 预览里改、重排、接受
    d = aiplan.generate(base, today=today, engine=FakeEngine(good), analysis=an)
    d = aiplan.edit_item(d, d0, 0, start=19 * 60 + 30, minutes=30)
    check("改一项的时间：和别的项冲突时标出来", aiplan.conflicts(d), aiplan.conflicts(d))
    d = aiplan.edit_item(d, d0, 0, start=20 * 60, minutes=45)
    check("改开以后没有冲突", not aiplan.conflicts(d), aiplan.conflicts(d))
    d = aiplan.edit_item(d, d0, 1, on=False)
    d = aiplan.add_item(d, days[2].isoformat(), "化学", "自己加的化学", 30)
    d = aiplan.remove_item(d, d1, 0)
    check("增删改：去掉物理、加化学、勾掉背诵", [b["task"] for b in aiplan.items_of(d)] == ["导数：错题重做", "背诵", "自己加的化学"]
          and not d["days"][0]["blocks"][1]["on"], [b["task"] for b in aiplan.items_of(d)])
    fe = FakeEngine(good)
    aiplan.generate(base, today=today, engine=fe, request="更轻松一点", previous=d, analysis=an)
    p = fe.seen[0][0]["content"]
    check("按要求重排：把要求和上一版一起交给 AI", "更轻松一点" in p and "上一版计划" in p and "自己加的化学" in p)
    d = aiplan.edit_item(aiplan.generate(base, today=today, engine=FakeEngine(good), analysis=an), d0, 1, on=False)
    n0 = len(plan.blocks())
    made = aiplan.accept(d)
    check("接受勾选的：只写勾上的，source=ai、带理由、题作子任务", len(made) == 2 and len(plan.blocks()) == n0 + 2
          and all(b["source"] == "ai" and b["why"] for b in made) and any(s["t"] == f"题 {qid}" for b in made for s in b["subtasks"]), made)
    check("本周目标进了周目标", any(g["t"] == "导数错题清零" for g in plan.week(days[0])["goals"]))
    check("接受后草稿标已接受", aiplan.draft()["status"] == "accepted")
    n1 = len(plan.blocks())
    check("同一份草稿接受第二次不重复写", aiplan.accept(aiplan.draft()) == [] and len(plan.blocks()) == n1)

    # ------------------------------------------------ 每周自动草稿（引擎）
    from .engine import engine
    from . import engine as engine_mod
    from .selftest import Clock, FakeProbe
    aiplan.set_auto(False)
    sun = datetime.combine(today, datetime.min.time()) + timedelta(hours=18)
    check("没开自动：周日也不出", not aiplan.auto_due(sun))
    aiplan.set_auto(True)
    check("开了自动：周六不出、周日下午五点前不出", not aiplan.auto_due(sun - timedelta(days=1)) and not aiplan.auto_due(sun - timedelta(hours=2)))
    check("下周已经接受过一份计划：不再自动出", not aiplan.auto_due(sun))
    aiplan.save_draft(None)
    check("周日傍晚该出下周草稿", aiplan.auto_due(sun))
    c = Clock(sun.timestamp())
    eng = engine(clock=c, probe=FakeProbe(), now_dt=c.dt)
    got = []
    eng.reminder.connect(got.append)
    eng._auto_plan(sun, sync=True)
    dr = aiplan.draft()
    check("引擎出了下周草稿（规则版）并推提醒，确认后才生效", dr["start"] == base.isoformat() and dr["status"] == "draft"
          and any(x["kind"] == "aiplan" for x in got), (dr.get("start"), got))
    check("同一周不重复出", not aiplan.auto_due(sun + timedelta(hours=2)))
    aiplan.set_auto(False)

    # ------------------------------------------------ 预览页
    from .aiplan_page import AIPlanPanel, open_dialog
    panel = AIPlanPanel(engine=FakeEngine(good), today=lambda: sun)
    panel.resize(1080, 680)
    panel.show()
    spin()
    panel.grab().save(str(out / "aiplan-empty.png"))
    panel.week.set_value("next")
    panel.generate(sync=True)
    spin()
    check("预览页：生成后列出每天和每项、标 AI", panel.d and panel.badge.text() == "AI 排的" and panel.list.count() >= 4 and panel.k_all.isEnabled(),
          (panel.badge.text(), panel.list.count()))
    panel.grab().save(str(out / "aiplan-draft.png"))
    row = next(i for i, r in enumerate(panel._rows) if r)
    panel.list.setCurrentRow(row)
    panel.e_min.setValue(30)
    panel.apply_edit()
    check("预览页改时长", aiplan.items_of(panel.d)[0]["minutes"] == 30)
    from PySide6.QtCore import Qt
    panel.list.item(row).setCheckState(Qt.CheckState.Unchecked)
    check("预览页勾掉一项", not aiplan.items_of(panel.d)[0]["on"])
    panel.list.setCurrentRow(row)
    n_items = len(aiplan.items_of(panel.d))
    panel.add_item()
    check("预览页这天加一项", len(aiplan.items_of(panel.d)) == n_items + 1)
    panel.req.setText("")
    panel.regenerate(sync=True)
    check("没写要求不重排，提示写一句", "要求" in panel.note.text())
    panel._quick("多练数学")
    panel.engine = FakeEngine(good)
    panel.regenerate(sync=True)
    check("快捷要求 + 重排", "多练数学" in panel.req.text() and panel.engine.calls >= 1 and "多练数学" in panel.engine.seen[0][0]["content"],
          (panel.req.text(), panel.engine.calls, panel.note.text()))
    n0 = len(plan.blocks())
    made = panel.accept(False)
    check("整份接受：写进计划、按键变灰", len(plan.blocks()) == n0 + len(made) and made and not panel.k_all.isEnabled())
    panel.grab().save(str(out / "aiplan-accepted.png"))
    p2 = AIPlanPanel(today=lambda: sun)
    p2.resize(1000, 620)
    p2.show()
    p2.generate(sync=True)
    spin()
    check("没密钥：预览页标「规则版」", p2.badge.text() == "规则版" and "规则版" in p2.note.text())
    p2.grab().save(str(out / "aiplan-rule-small.png"))
    from ..design import tokens
    tokens.set_theme("night")
    p2.apply_theme()
    p2.render()
    spin()
    p2.grab().save(str(out / "aiplan-night.png"))
    tokens.set_theme("day")
    p2.close()
    panel.close()

    # ------------------------------------------------ 入口
    from ..chat import core as chat_core
    check("聊天里认得「帮我排下周计划」", chat_core.wants_plan("帮我排下周计划") and chat_core.wants_plan("给我做一份学习计划")
          and not chat_core.wants_plan("把导数加进番茄计划") and not chat_core.wants_plan("计划经济是什么"))
    check("动作表里有 AI 排计划", "aiplan" in chat_core.ACTIONS and "aiplan" in chat_core.SYSTEM)
    from ..chat.page import ChatPage
    cp = ChatPage(host={})
    cp.send("帮我排下周计划")
    spin()
    dlg = getattr(cp, "aiplan_dlg", None)
    check("问 AI 里说「帮我排下周计划」：打开 AI 排计划，不当普通聊天发", dlg is not None and dlg.isVisible() and cp.conv["messages"][-1].get("offline")
          and chat_core.parse_actions(cp.conv["messages"][-1]["content"])[0]["kind"] == "aiplan")
    dlg.close()
    cp.close()
    from .page import FocusPage
    fp = FocusPage()
    fp.show_tab("aiplan")
    spin()
    check("专注页：show_tab('aiplan') 打开预览窗口（提醒卡片「去看看」走这里）", fp.aiplan_dlg.isVisible() and fp.stack.currentWidget() is fp.views["plan"])
    fp.aiplan_dlg.close()
    fp.close()
    from ..exam.page import ExamPage
    ep = ExamPage()
    ep.show_tab("stats")
    check("考情页有「AI 排计划」", ep.k_aiplan.text() == "AI 排计划")
    ep.open_aiplan().close()
    ep.close()
    dlg = open_dialog(None, "周末多排一点")
    check("窗口带上要求", dlg.panel.req.text() == "周末多排一点")
    import ui_kit
    ui_kit.apply_theme("night", "doodle")
    dlg.panel.apply_theme()
    spin()
    from PySide6.QtWidgets import QLabel
    img = dlg.grab().toImage()
    t = dlg.findChild(QLabel, "examTitle")
    tl = t.mapTo(dlg, t.rect().topLeft())
    bg = img.pixelColor(tl.x() + t.width() - 2, tl.y() + 2).name()
    check("手绘夜间：窗口里的底色画出来了（不是系统浅灰），浅色字看得清", bg == ui_kit.C.PAPER.name(), (bg, ui_kit.C.PAPER.name()))
    ui_kit.apply_theme("day", "ink")
    dlg.close()

    eng.timer.stop()
    engine_mod._ENGINE = None
    (out / "aiplan-log.txt").write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))
    print("AIPLAN_FAIL" if fails else "AIPLAN_OK", len(log), "项")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
