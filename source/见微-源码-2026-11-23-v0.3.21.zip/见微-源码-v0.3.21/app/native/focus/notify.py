"""提醒卡片：桌面右下角、置顶、不抢焦点。三个键：开始番茄 / 推迟 10 分钟 / 跳过（晚间复盘的第一个键是「去复盘」）。

一次只显示一张，后面的排队（卡片上写「还有 N 条」）；90 秒没人理就收起（算看过）。看不见时不重画。
open_page(tab)：点卡片正文、「去复盘」时打开专注页的某一栏。
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QApplication, QWidget

from ..design.icons import draw_icon
from ..design.tokens import T, font, qc
from .engine import engine

W, H = 348, 150
ICON = dict(morning="calendar", evening="note", block="clock", exam="exam", due="recite", missed="bell", aiplan="spark")


class NoticeCard(QWidget):
    def __init__(self, open_page=None):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.open_page = open_page
        self.eng = engine()
        self.queue: list[dict] = []
        self.item: dict | None = None
        self.hover = ""
        self.result = []                     # 自测看：(key, 动作)
        self.setFixedSize(W, H)
        self.setMouseTracking(True)
        self.life = QTimer(self)
        self.life.setSingleShot(True)
        self.life.timeout.connect(lambda: self._done("timeout"))

    # ---- 队列
    def push(self, item):
        if not item or not item.get("text"):
            return
        if self.item and self.item.get("key") == item.get("key"):
            return
        self.queue.append(item)
        if self.item is None:
            self._next()
        else:
            self.update()
        if self.eng.cfg.get("sound"):
            QApplication.beep()

    def _next(self):
        self.item = self.queue.pop(0) if self.queue else None
        if self.item is None:
            self.hide()
            return
        scr = QGuiApplication.primaryScreen().availableGeometry()
        self.move(scr.right() - W - 18, scr.bottom() - H - 18)
        self.life.start(90000)
        self.show()
        self.update()

    def _done(self, action):
        if self.item is not None:
            self.result.append((self.item.get("key"), action))
        self._next()

    # ---- 键
    def keys(self) -> dict:
        y = H - 44
        return dict(main=QRectF(16, y, 112, 30), snooze=QRectF(136, y, 104, 30), skip=QRectF(W - 16 - 84, y, 84, 30),
                    close=QRectF(W - 34, 12, 20, 20))

    def main_label(self):
        k = (self.item or {}).get("kind")
        return "去复盘" if k == "evening" else "去看看" if k == "aiplan" else "开始番茄"

    def act(self, name):
        it = self.item
        if it is None:
            return
        if name == "main":
            if it.get("kind") in ("evening", "aiplan"):
                if self.open_page:
                    self.open_page("review" if it["kind"] == "evening" else "aiplan")
            elif not self.eng.remind_start(it):
                self.eng._say("nudge", "先结束当前的番茄，再开始这一项。")
        elif name == "snooze":
            self.eng.remind_snooze(it, 10)
        elif name == "body" and self.open_page:
            self.open_page("plan")
        self._done(name)

    def mouseMoveEvent(self, e):  # noqa: N802
        h = next((k for k, r in self.keys().items() if r.contains(e.position())), "")
        if h != self.hover:
            self.hover = h
            self.setCursor(Qt.CursorShape.PointingHandCursor if h else Qt.CursorShape.ArrowCursor)
            self.update()

    def leaveEvent(self, _e):  # noqa: N802
        if self.hover:
            self.hover = ""
            self.update()

    def mouseReleaseEvent(self, e):  # noqa: N802
        if e.button() != Qt.MouseButton.LeftButton:
            return
        k = next((k for k, r in self.keys().items() if r.contains(e.position())), "")
        self.act("skip" if k == "close" else k or "body")

    # ---- 画
    def paintEvent(self, _e):  # noqa: N802
        it = self.item
        if it is None:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        accent = qc(T.bad if it.get("kind") == "exam" else T.warn if it.get("missed") else T.accent)
        p.setPen(QPen(qc(T.line2), 1))
        p.setBrush(qc(T.raised))
        p.drawRoundedRect(r, 12, 12)
        p.fillRect(QRectF(r.left() + 1, 18, 3, 26), accent)
        draw_icon(p, ICON.get(it.get("kind"), "bell"), QRectF(16, 16, 18, 18), accent, 1.6)
        p.setPen(qc(T.fg))
        p.setFont(font(13, 700))
        title = it.get("title", "提醒")
        if self.queue:
            title += f"  · 还有 {len(self.queue)} 条"
        p.drawText(QRectF(42, 12, W - 90, 26), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), title)
        draw_icon(p, "close", self.keys()["close"].adjusted(4, 4, -4, -4), qc(T.fg if self.hover == "close" else T.faint), 1.4)
        p.setPen(qc(T.soft))
        p.setFont(font(12))
        body = QRectF(16, 42, W - 32, H - 42 - 52)
        fm = p.fontMetrics()
        text = it.get("text", "")
        # 两三行放不下就截断，免得压到键上
        lines, cur = [], ""
        for ch in text.replace("\n", "　"):
            if fm.horizontalAdvance(cur + ch) > body.width():
                lines.append(cur)
                cur = ch
            else:
                cur += ch
        if cur:
            lines.append(cur)
        maxl = int(body.height() // (fm.height() + 1)) or 1
        if len(lines) > maxl:
            lines = lines[:maxl]
            lines[-1] = fm.elidedText(lines[-1] + "……", Qt.TextElideMode.ElideRight, int(body.width()))
        for i, ln in enumerate(lines):
            p.drawText(QRectF(body.left(), body.top() + i * (fm.height() + 1), body.width(), fm.height()),
                       int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), ln)
        for name, rect in self.keys().items():
            if name == "close":
                continue
            label = self.main_label() if name == "main" else "推迟 10 分钟" if name == "snooze" else "跳过"
            primary = name == "main"
            hov = self.hover == name
            p.setPen(QPen(accent if primary else qc(T.line2), 1))
            p.setBrush(accent if primary else qc(T.fg, 0.06 if hov else 0.0))
            if primary and hov:
                p.setBrush(accent.lighter(110))
            p.drawRoundedRect(rect, 7, 7)
            p.setPen(qc(T.raised) if primary else qc(T.fg if hov else T.soft))
            p.setFont(font(12, 700 if primary else 500))
            p.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), label)
        p.end()


_CARD = None


def card(open_page=None) -> NoticeCard:
    global _CARD
    if _CARD is None:
        _CARD = NoticeCard(open_page)
    elif open_page is not None:
        _CARD.open_page = open_page
    return _CARD
