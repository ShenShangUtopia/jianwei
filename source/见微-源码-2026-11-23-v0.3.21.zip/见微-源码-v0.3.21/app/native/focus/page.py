"""专注页：番茄钟 · 计划 · 复盘 · 统计 · 设置。主窗口「专注」页用（compact=True 背景透明）。

番茄状态都在 engine()，这里只显示和发命令；关掉页面番茄照走（悬浮窗、托盘都还在）。
计划（0.3.19 细化）：长期目标 → 周目标 → 日计划 → 时间块；一天 / 一周 / 一月三种视图（planview.py）；
块有科目、预计番茄、优先级、截止日、重复规则、子任务；「一键排今天」按空闲时段和到期任务给出建议，确认后才写进计划。
复盘：每天、每周各一次，完成率、各科计划 vs 实际、偏差，写一句总结。
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

from PySide6.QtCore import QDate, QPointF, QRectF, Qt, QTime
from PySide6.QtGui import QPainter, QPen
from PySide6.QtWidgets import (QBoxLayout, QCheckBox, QComboBox, QDateEdit, QGridLayout, QHBoxLayout, QLineEdit, QListWidget,
                               QListWidgetItem, QPlainTextEdit, QScrollArea, QSpinBox, QStackedWidget, QTimeEdit,
                               QVBoxLayout, QWidget)

from ..design.tokens import T, css, font, qc
from ..design.widgets import Segmented, qss
from ..exam.page import Bars, _btn, _card, _label
from . import core, plan
from .engine import engine
from .planview import MonthGrid, PairBars, PlanGrid, subj_color  # noqa: F401  subj_color 给老代码用
from .watch import KIND_NAME

SUBJECTS = ["", "数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理", "政治"]
WEEK = "一二三四五六日"
STATUS = dict(done="完成", skipped="提前结束", abandoned="放弃")


def mmss(sec):
    sec = max(0, int(round(sec)))
    return f"{sec // 60:02d}:{sec % 60:02d}"


def _subj_combo():
    c = QComboBox()
    for s in SUBJECTS:
        c.addItem(s or "不分科", s)
    return c


def _time_edit(text):
    t = QTimeEdit()
    t.setDisplayFormat("HH:mm")
    m = plan.parse_hhmm(text, 7 * 60)
    t.setTime(QTime(m // 60, m % 60))
    return t


def _hm(qt: QTimeEdit) -> str:
    return qt.time().toString("HH:mm")


class Ring(QWidget):
    """大番茄环：进度、剩余时间、阶段、这一轮的点。"""

    def __init__(self):
        super().__init__()
        self.setMinimumSize(240, 240)

    def paintEvent(self, _e):  # noqa: N802
        st = engine().state()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        side = min(self.width(), self.height()) - 24
        r = QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)
        p.setPen(QPen(qc(T.fg, 0.07), 10))
        p.drawEllipse(r)
        col = qc(T.accent if st["phase"] == "focus" else T.ok if st["phase"] in ("short", "long") else T.faint)
        if st["length"]:
            pen = QPen(col, 10)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawArc(r, 90 * 16, int(-(1 - st["remaining"] / st["length"]) * 360 * 16))
        p.setPen(qc(T.fg if st["running"] or st["phase"] == "idle" else T.muted))
        p.setFont(font(side * 0.2, 700, "mono"))
        txt = mmss(st["remaining"]) if st["phase"] != "idle" else mmss(engine().pomo.length(st["next"]))
        p.drawText(r.adjusted(0, -side * 0.06, 0, -side * 0.06), int(Qt.AlignmentFlag.AlignCenter), txt)
        p.setFont(font(14, 700))
        p.setPen(col)
        name = st["name"] if st["phase"] != "idle" else ("准备 · " + core.PHASE_NAME[st["next"]])
        if st["phase"] != "idle" and not st["running"]:
            name += " · 已暂停"
        p.drawText(QRectF(r.left(), r.center().y() + side * 0.1, r.width(), 24), int(Qt.AlignmentFlag.AlignCenter), name)
        n = st["rounds"]
        y = r.center().y() + side * 0.1 + 34
        for i in range(n):
            x = r.center().x() + (i - (n - 1) / 2) * 16
            p.setPen(QPen(col if i < st["count"] else qc(T.line2), 1.5))
            p.setBrush(col if i < st["count"] else Qt.BrushStyle.NoBrush)
            p.drawEllipse(QPointF(x, y), 4.5, 4.5)
        p.end()


class FocusPage(QWidget):
    def __init__(self, compact=False, open_review=None):
        super().__init__()
        self.setObjectName("focusPage")
        self.compact = compact
        self.eng = engine()
        self.day = date.today()
        self.week_start = self.day - timedelta(days=self.day.weekday())
        self.view_mode = "week"
        self.rv_kind, self.rv_day = "day", date.today()
        self._loading = False
        v = QVBoxLayout(self)
        v.setContentsMargins(*((0, 0, 0, 0) if compact else (24, 18, 24, 18)))
        v.setSpacing(12)
        top = QHBoxLayout()
        self.title = _label("专注", "examTitle")
        self.title.setVisible(not compact)
        top.addWidget(self.title)
        self.seg = Segmented([("pomo", "番茄钟"), ("plan", "计划"), ("review", "复盘"), ("stats", "统计"), ("set", "设置")], "pomo")
        self.seg.changed.connect(self.show_tab)
        top.addWidget(self.seg)
        self.status = _label("", "examStatus")
        top.addWidget(self.status, 1)
        v.addLayout(top)
        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)
        self.views = dict(pomo=self._build_pomo(), plan=self._build_plan(), review=self._build_review(),
                          stats=self._build_stats(), set=self._build_set())
        for w in self.views.values():
            self.stack.addWidget(w)
        self.eng.changed.connect(self._tick)
        self.eng.notice.connect(self._notice)
        self.eng.recorded.connect(self.refresh_today)
        self.eng.planChanged.connect(self._plan_changed)
        self.apply_theme()
        self.refresh_today()
        self._sync_keys()

    def open_aiplan(self, request=""):
        """AI 排计划（0.3.20）：弹预览窗口，接受后刷新计划表。"""
        from .aiplan_page import open_dialog
        self.aiplan_dlg = open_dialog(self.window(), request, on_accept=lambda _n: self._plan_changed())
        return self.aiplan_dlg

    def show_tab(self, key):
        if key == "aiplan":
            self.show_tab("plan")
            self.open_aiplan()
            return
        self.seg.set_value(key)
        self.stack.setCurrentWidget(self.views[key])
        if key == "plan":
            self.refresh_plan()
        elif key == "review":
            self.refresh_review()
        elif key == "stats":
            self.refresh_stats()
        elif key == "set":
            self.load_settings()
        else:
            self.refresh_today()

    def set_status(self, text, tone="muted"):
        self.status.setText(text)
        self.status.setStyleSheet(f"color:{getattr(T, tone)};font-size:12px;")

    # ------------------------------------------------------------ 番茄钟
    def _build_pomo(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(14)
        left, lv = _card()
        self.ring = Ring()
        lv.addWidget(self.ring, 1)
        row = QHBoxLayout()
        row.addWidget(_label("科目", "ctlLabel"))
        self.p_subj = _subj_combo()
        row.addWidget(self.p_subj)
        self.p_task = QLineEdit()
        self.p_task.setPlaceholderText("这个番茄做什么（可空）")
        self.p_task.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        row.addWidget(self.p_task, 1)
        lv.addLayout(row)
        keys = QHBoxLayout()
        self.k_abandon = _btn("放弃", self.ask_abandon, "danger", "放弃这个番茄（记为放弃；严格模式要写理由）")
        self.k_skip = _btn("跳过", self.eng.skip, "", "专注中：提前结束；休息中：直接开始下一个")
        self.k_main = _btn("开始专注", self.main_key, "pri")
        keys.addWidget(self.k_abandon)
        keys.addStretch(1)
        keys.addWidget(self.k_skip)
        keys.addWidget(self.k_main)
        lv.addLayout(keys)
        self.ab_row = QWidget()
        ar = QHBoxLayout(self.ab_row)
        ar.setContentsMargins(0, 0, 0, 0)
        self.ab_reason = QLineEdit()
        self.ab_reason.setPlaceholderText("为什么放弃？写一句（严格模式必填）")
        self.ab_reason.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        ar.addWidget(self.ab_reason, 1)
        ar.addWidget(_btn("算了，继续", lambda: self.ab_row.hide(), "ghost"))
        ar.addWidget(_btn("确定放弃", self.do_abandon, "danger"))
        self.ab_row.hide()
        lv.addWidget(self.ab_row)
        self.p_notice = _label("", "note", True)
        lv.addWidget(self.p_notice)
        h.addWidget(left, 3)
        right, rv = _card()
        rv.addWidget(_label("今天的计划", "cardTitle"))
        self.t_prog = _label("双击一项，按它开始专注。", "note", True)
        rv.addWidget(self.t_prog)
        self.t_plan = QListWidget()
        self.t_plan.setWordWrap(True)
        self.t_plan.itemDoubleClicked.connect(lambda it: it.data(Qt.ItemDataRole.UserRole) and self.start_block(it.data(Qt.ItemDataRole.UserRole)))
        rv.addWidget(self.t_plan, 2)
        rv.addWidget(_label("今天的番茄", "cardTitle"))
        self.t_sum = _label("", "note", True)
        rv.addWidget(self.t_sum)
        self.t_sess = QListWidget()
        rv.addWidget(self.t_sess, 2)
        h.addWidget(right, 2)
        return w

    def main_key(self):
        st = self.eng.state()
        if st["phase"] == "idle":
            self.eng.start(self.p_subj.currentData() or "", self.p_task.text().strip())
        else:
            self.eng.toggle()

    def ask_abandon(self):
        if self.eng.pomo.phase != "focus":
            self.eng.abandon()
            return
        self.ab_reason.clear()
        self.ab_row.show()

    def do_abandon(self):
        try:
            self.eng.abandon(self.ab_reason.text())
        except ValueError as e:
            self.set_status(str(e), "bad")
            return
        self.ab_row.hide()
        self.set_status("这个番茄记为放弃")

    def start_block(self, bid):
        if not bid:
            self.set_status("先选中计划里的一块")
            return
        if not self.eng.start_block(bid):
            self.set_status("先结束当前的番茄，再开始计划里的下一项", "warn")
            return
        b = plan.get(bid) or {}
        self.set_status(f"开始：{b.get('subject', '')} {b.get('task', '')}".strip())
        self.show_tab("pomo")

    def _sync_keys(self):
        st = self.eng.state()
        idle = st["phase"] == "idle"
        self.k_main.setText(("开始" + core.PHASE_NAME[st["next"]]) if idle else ("暂停" if st["running"] else "继续"))
        self.k_skip.setEnabled(not idle or st["next"] != "focus")
        self.k_abandon.setEnabled(st["phase"] == "focus")
        self.p_subj.setEnabled(idle)
        self.p_task.setEnabled(idle)
        if not idle and st["phase"] == "focus":
            i = self.p_subj.findData(st["subject"])
            if i >= 0:
                self.p_subj.setCurrentIndex(i)
            self.p_task.setText(st["task"])

    def _tick(self):
        if not self.isVisible():
            return
        cur = self.stack.currentWidget()
        if cur is self.views["pomo"]:
            self.ring.update()
        elif cur is self.views["plan"] and self.grid.isVisible():
            m = datetime.now().strftime("%H%M")
            if m != getattr(self, "_grid_min", m):         # 「现在」那条线一分钟挪一次，别的时候不重画
                self.grid.update()
            self._grid_min = m
        self._sync_keys()

    def _notice(self, kind, text):
        self.p_notice.setText(text)
        if kind != "nudge":
            self.refresh_today()

    def refresh_today(self):
        today = date.today()
        iso = today.isoformat()
        self.t_plan.clear()
        for b in plan.blocks(iso):
            tags = []
            if b.get("source") == "exam":
                tags.append("考试")
            if b.get("carried"):
                tags.append(f"顺延 {b['carried']} 次")
            if b.get("subtasks"):
                tags.append(f"子任务 {sum(1 for s in b['subtasks'] if s['done'])}/{len(b['subtasks'])}")
            if b.get("done"):
                tags.append("已完成")
            it = QListWidgetItem(f"{plan.hhmm(b['start'])}–{plan.hhmm(b['start'] + b['minutes'])}　{b.get('subject') or ''} {b.get('task') or ''}"
                                 + ("　" + " · ".join(tags) if tags else ""))
            it.setData(Qt.ItemDataRole.UserRole, b["id"])
            self.t_plan.addItem(it)
        if not self.t_plan.count():
            it = QListWidgetItem("今天还没排计划。到「计划」里排一下，或者点「一键排今天」。")
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.t_plan.addItem(it)
        pg = plan.day_progress(today)
        self.t_prog.setText((f"完成 {pg['done']}/{pg['n']} 块（{int((pg['rate'] or 0) * 100)}%）· 计划 {pg['planned']} 分钟 · "
                             f"实际专注 {int(pg['actual'])} 分钟。双击一项开始。") if pg["n"] else "双击一项，按它开始专注。")
        rs = [r for r in core.sessions() if r.get("day") == iso]
        self.t_sess.clear()
        for r in reversed(rs):
            t = datetime.fromtimestamp(r["start"]).strftime("%H:%M")
            inter = len(r.get("interruptions") or [])
            self.t_sess.addItem(f"{t}　{STATUS.get(r['status'], r['status'])}　{int(r['focus'] // 60)} 分钟　{r.get('subject') or ''} {r.get('task') or ''}"
                                + (f"　中断 {inter}" if inter else "") + (f"　理由：{r['reason']}" if r.get("reason") else ""))
        done = sum(1 for r in rs if r["status"] == "done")
        mins = int(sum(r["focus"] for r in rs) // 60)
        inter = sum(len(r.get("interruptions") or []) for r in rs)
        self.t_sum.setText(f"完成 {done} 个 · 专注 {mins} 分钟 · 中断 {inter} 次" if rs else "还没开始。")

    # ------------------------------------------------------------ 计划
    def _build_plan(self):
        w = QWidget()
        h = QBoxLayout(QBoxLayout.Direction.LeftToRight, w)
        self.pl_box = h
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(14)
        left = QVBoxLayout()
        left.setSpacing(8)
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.pl_mode = Segmented([("day", "日"), ("week", "周"), ("month", "月")], self.view_mode)
        self.pl_mode.changed.connect(self._set_plan_mode)
        bar.addWidget(self.pl_mode)
        for text, k, tip in (("‹", -1, "往前"), ("今天", 0, "回到今天"), ("›", 1, "往后")):
            b = _btn(text, lambda k=k: self._shift(k), "ghost", tip)
            if text != "今天":
                b.setFixedWidth(34)
            bar.addWidget(b)
        self.pl_range = _label("", "cardTitle")
        bar.addWidget(self.pl_range)
        self.pl_prog = _label("", "note")
        bar.addStretch(1)
        bar.addWidget(_btn("AI 排计划", lambda: self.open_aiplan(), "", "按考情、背诵、专注记录和目标，让 AI 排一周（没有密钥用规则版）；预览确认后才写进计划"))
        bar.addWidget(_btn("一键排今天", self.suggest_today, "", "按今天的空闲时段，把到期复习、薄弱点、背诵、预习排成建议日程；确认后才写进计划"))
        bar.addWidget(_btn("新建一块", self.new_block, "pri", "在选中的那天找个空档放一块 45 分钟"))
        left.addLayout(bar)
        self.pl_stack = QStackedWidget()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.grid = PlanGrid()
        self.grid.setMinimumHeight(17 * 44 + 40)
        self.grid.picked.connect(self._pick_block)
        self.grid.activated.connect(self.start_block)
        self.grid.changed.connect(self._plan_changed)
        scroll.setWidget(self.grid)
        self.pl_stack.addWidget(scroll)
        self.month = MonthGrid()
        self.month.picked.connect(self._open_day)
        self.pl_stack.addWidget(self.month)
        left.addWidget(self.pl_stack, 1)
        foot = QHBoxLayout()
        foot.addWidget(self.pl_prog)
        foot.addWidget(_label("· 拖动换时间、拖下边改时长，双击开始番茄；右侧细条＝实际番茄，淡绿底＝可用时段，红＝考试", "note"), 1)
        left.addLayout(foot)
        h.addLayout(left, 3)
        side, sv = _card()
        self.side_seg = Segmented([("block", "这一块"), ("pull", "拉任务"), ("goal", "目标")], "block")
        self.side_seg.changed.connect(self._side_tab)
        sv.addWidget(self.side_seg)
        self.side_stack = QStackedWidget()
        self.side_views = dict(block=self._build_editor(), pull=self._build_pull(), goal=self._build_goals())
        for x in self.side_views.values():
            self.side_stack.addWidget(x)
        sv.addWidget(self.side_stack, 1)
        side.setMinimumWidth(280)
        side.setMaximumWidth(340)
        self.pl_side = side
        h.addWidget(side, 1)
        return w

    def resizeEvent(self, e):  # noqa: N802
        """窄的时候（小于 960 宽，比如 1000×620 的窗口）右栏挪到计划表下面，免得被挤出去。"""
        super().resizeEvent(e)
        if not hasattr(self, "pl_box"):
            return
        narrow = self.width() < 960
        want = QBoxLayout.Direction.TopToBottom if narrow else QBoxLayout.Direction.LeftToRight
        if self.pl_box.direction() != want:
            self.pl_box.setDirection(want)
            self.pl_side.setMaximumWidth(16777215 if narrow else 340)
            self.pl_side.setMinimumHeight(380 if narrow else 0)
            self.grid.setMinimumHeight(17 * 30 + 40 if narrow else 17 * 44 + 40)

    def _side_tab(self, key):
        self.side_seg.set_value(key)
        self.side_stack.setCurrentWidget(self.side_views[key])
        if key == "goal":
            self.refresh_goals()

    def _build_editor(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        self.ed_hint = _label("点计划表里的一块来编辑；或者「新建一块」。", "note", True)
        v.addWidget(self.ed_hint)
        self.ed_box = QWidget()
        g = QGridLayout(self.ed_box)
        g.setContentsMargins(0, 0, 0, 0)
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(6)
        self.ed_subj = _subj_combo()
        self.ed_kind = QComboBox()
        self.ed_kind.addItem("学习", "self")
        self.ed_kind.addItem("考试", "exam")
        self.ed_task = QLineEdit()
        self.ed_task.setPlaceholderText("做什么")
        self.ed_task.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.ed_min = QSpinBox()
        self.ed_min.setRange(15, 600)
        self.ed_min.setSingleStep(15)
        self.ed_min.setSuffix(" 分钟")
        self.ed_pomos = QSpinBox()
        self.ed_pomos.setRange(0, 24)
        self.ed_pomos.setSpecialValueText("按时长")
        self.ed_pomos.setSuffix(" 个番茄")
        self.ed_pri = QComboBox()
        for k in (2, 1, 0):
            self.ed_pri.addItem(plan.PRIORITY[k] + "优先", k)
        self.ed_dl_on = QCheckBox("截止")
        self.ed_dl = QDateEdit()
        self.ed_dl.setCalendarPopup(True)
        self.ed_dl.setDisplayFormat("M月d日")
        self.ed_dl_on.toggled.connect(self.ed_dl.setEnabled)
        self.ed_rep = QComboBox()
        for k, t in plan.RULES.items():
            self.ed_rep.addItem(t, k)
        self.ed_rep.currentIndexChanged.connect(lambda _i: self.ed_days.setVisible(self.ed_rep.currentData() == "weekly"))
        self.ed_days = QWidget()
        dh = QHBoxLayout(self.ed_days)
        dh.setContentsMargins(0, 0, 0, 0)
        dh.setSpacing(2)
        self.ed_day_cb = []
        for i in range(7):
            cb = QCheckBox(WEEK[i])
            dh.addWidget(cb)
            self.ed_day_cb.append(cb)
        self.ed_days.hide()
        rows = (("科目", self.ed_subj, self.ed_kind), ("做什么", self.ed_task, None), ("时长", self.ed_min, self.ed_pomos),
                ("优先级", self.ed_pri, None), (None, self.ed_dl_on, self.ed_dl), ("重复", self.ed_rep, None))
        for r, (lab, a, b) in enumerate(rows):
            if lab:
                g.addWidget(_label(lab, "ctlLabel"), r, 0)
            else:
                g.addWidget(a, r, 0)
                a = None
            if a is not None:
                g.addWidget(a, r, 1, 1, 1 if b is not None else 2)
            if b is not None:
                g.addWidget(b, r, 2 if a is not None else 1, 1, 1 if a is not None else 2)
        g.addWidget(self.ed_days, len(rows), 0, 1, 3)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(2, 1)
        v.addWidget(self.ed_box)
        self.ed_subs_title = _label("子任务", "ctlLabel")
        v.addWidget(self.ed_subs_title)
        self.ed_subs = QListWidget()
        self.ed_subs.setMaximumHeight(110)
        self.ed_subs.itemChanged.connect(self._sub_changed)
        v.addWidget(self.ed_subs)
        sr = QHBoxLayout()
        self.ed_sub_new = QLineEdit()
        self.ed_sub_new.setPlaceholderText("加一条子任务，回车")
        self.ed_sub_new.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.ed_sub_new.returnPressed.connect(self.add_subtask)
        sr.addWidget(self.ed_sub_new, 1)
        sr.addWidget(_btn("加", self.add_subtask))
        self.ed_sub_row = QWidget()
        self.ed_sub_row.setLayout(sr)
        sr.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self.ed_sub_row)
        self.ed_info = _label("", "note", True)
        v.addWidget(self.ed_info)
        v.addStretch(1)
        kr = QHBoxLayout()
        kr.addWidget(_btn("删除", self.delete_block, "danger"))
        kr.addStretch(1)
        kr.addWidget(_btn("开始番茄", lambda: self.start_block(self.grid.sel)))
        kr.addWidget(_btn("保存", self.save_block))
        self.ed_keys = QWidget()
        self.ed_keys.setLayout(kr)
        kr.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self.ed_keys)
        for x in (self.ed_box, self.ed_subs, self.ed_sub_row, self.ed_keys):
            x.setEnabled(False)
        return w

    def _build_pull(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        v.addWidget(_label("建议日程", "cardTitle"))
        self.sg_note = _label("点上面的「一键排今天」：按今天的空闲时段排到期复习、薄弱点、背诵和预习，留两成余量。勾掉不要的再排入。", "note", True)
        v.addWidget(self.sg_note)
        self.sg_list = QListWidget()
        v.addWidget(self.sg_list, 2)
        self.sg_go = _btn("排入勾选的", self.accept_suggest, "", "写进计划；之后可以拖动微调")
        self.sg_go.setEnabled(False)
        v.addWidget(self.sg_go)
        v.addWidget(_label("拉进计划", "cardTitle"))
        v.addWidget(_label("选中一项，放到选中那天的第一个空档。", "note", True))
        self.cand = QListWidget()
        self.cand.itemDoubleClicked.connect(lambda _it: self.add_candidate())
        v.addWidget(self.cand, 2)
        v.addWidget(_btn("加入计划", self.add_candidate, "", "放进选中那天的第一个空档"))
        return w

    def _build_goals(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 4, 6, 0)
        v.setSpacing(6)
        v.addWidget(_label("长期目标", "cardTitle"))
        self.gl_sum = _label("", "note", True)
        v.addWidget(self.gl_sum)
        g = QGridLayout()
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(4)
        g.addWidget(_label("高考总分", "ctlLabel"), 0, 0)
        self.gl_total = QSpinBox()
        self.gl_total.setRange(0, 750)
        self.gl_total.setSpecialValueText("按各科加")
        g.addWidget(self.gl_total, 0, 1)
        self.gl_sub = {}
        for i, s in enumerate(SUBJECTS[1:]):
            g.addWidget(_label(s, "ctlLabel"), 1 + i // 2, (i % 2) * 2)
            sp = QSpinBox()
            sp.setRange(0, plan.FULL.get(s, 150))
            sp.setSpecialValueText("—")
            g.addWidget(sp, 1 + i // 2, (i % 2) * 2 + 1)
            self.gl_sub[s] = sp
        v.addLayout(g)
        self.gl_bars = Bars(color="rate")
        v.addWidget(self.gl_bars)
        v.addWidget(_btn("保存目标", self.save_goals))
        v.addWidget(_label("这周的目标", "cardTitle"))
        self.wk_sum = _label("", "note", True)
        v.addWidget(self.wk_sum)
        self.wk_list = QListWidget()
        self.wk_list.setMaximumHeight(130)
        self.wk_list.itemChanged.connect(self._week_changed)
        v.addWidget(self.wk_list)
        wr = QHBoxLayout()
        self.wk_new = QLineEdit()
        self.wk_new.setPlaceholderText("比如：导数大题每天一道，回车")
        self.wk_new.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.wk_new.returnPressed.connect(self.add_week_goal)
        wr.addWidget(self.wk_new, 1)
        wr.addWidget(_btn("加", self.add_week_goal))
        v.addLayout(wr)
        v.addStretch(1)
        scroll.setWidget(w)
        return scroll

    # ---- 视图
    def _set_plan_mode(self, m):
        self.view_mode = m
        self.pl_mode.set_value(m)
        self.refresh_plan()

    def _open_day(self, d):
        self.day = d
        self.week_start = d - timedelta(days=d.weekday())
        self._set_plan_mode("day")

    def _shift(self, k):
        if k == 0:
            self.day = date.today()
        elif self.view_mode == "month":
            m = self.day.replace(day=1)
            self.day = (m - timedelta(days=1)).replace(day=1) if k < 0 else (m + timedelta(days=32)).replace(day=1)
        else:
            self.day += timedelta(days=k * (7 if self.view_mode == "week" else 1))
        self.week_start = self.day - timedelta(days=self.day.weekday())
        self.refresh_plan()

    def _days(self):
        return [self.day] if self.view_mode == "day" else [self.week_start + timedelta(days=i) for i in range(7)]

    def refresh_plan(self):
        days = self._days()
        plan.ensure_repeats(days)
        if self.view_mode == "month":
            self.month.set_month(self.day)
            self.pl_stack.setCurrentWidget(self.month)
            self.pl_range.setText(f"{self.day.year} 年 {self.day.month} 月")
            ps = [pg for d, pg in self.month.cells if d.month == self.day.month]
            n, dn = sum(x["n"] for x in ps), sum(x["done"] for x in ps)
            pm, dm = sum(x["planned"] for x in ps), sum(x["done_min"] for x in ps)
            self.pl_prog.setText(f"本月 {dn}/{n} 块 · 完成 {int(dm / pm * 100)}%" if pm else "本月还没有计划")
        else:
            self.grid.set_days(days)
            self.pl_stack.setCurrentIndex(0)
            self.pl_range.setText(f"{days[0].month}/{days[0].day}" + (f" – {days[-1].month}/{days[-1].day}" if len(days) > 1 else f" 周{WEEK[days[0].weekday()]}"))
            wp = plan.week_progress(self.day)
            dp = plan.day_progress(self.day)
            parts = []
            if wp["n"]:
                parts.append(f"本周完成 {int((wp['rate'] or 0) * 100)}%（{wp['done']}/{wp['n']} 块）")
            if wp["goals"]:
                parts.append(f"周目标 {wp['goals_done']}/{len(wp['goals'])}")
            if self.view_mode == "day" and dp["n"]:
                parts.append(f"这天 {int((dp['rate'] or 0) * 100)}%")
            self.pl_prog.setText(" · ".join(parts))
        self.cand.clear()
        for c in plan.candidates():
            it = QListWidgetItem(f"[{plan.SOURCES[c['source']]}] {c['task']}　{c['minutes']} 分钟")
            it.setToolTip(c.get("why", ""))
            it.setData(Qt.ItemDataRole.UserRole, c)
            self.cand.addItem(it)
        if not self.cand.count():
            it = QListWidgetItem("现在没有可拉的任务：复习没到期、没在预习、考情里没有薄弱点。")
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.cand.addItem(it)
        self._pick_block(self.grid.sel)
        if self.side_stack.currentWidget() is self.side_views["goal"]:
            self.refresh_goals()

    def _target_day(self):
        b = plan.get(self.grid.sel) if self.grid.sel else None
        if b:
            return date.fromisoformat(b["day"])
        return self.day

    def new_block(self):
        d = self._target_day()
        b = plan.add(d.isoformat(), plan.next_free(d.isoformat(), 45), 45, self.p_subj.currentData() or "", "")
        self.grid.sel = b["id"]
        self._side_tab("block")
        self._plan_changed()
        self.ed_task.setFocus()

    def add_candidate(self):
        it = self.cand.currentItem()
        c = it.data(Qt.ItemDataRole.UserRole) if it else None
        if not c:
            self.set_status("先在右边选一项")
            return
        d = self._target_day()
        b = plan.add(d.isoformat(), plan.next_free(d.isoformat(), c["minutes"]), c["minutes"], c["subject"], c["task"], c["source"],
                     c["ref"], priority=c.get("priority", 1), why=c.get("why", ""))
        self.grid.sel = b["id"]
        self._plan_changed()
        self.set_status(f"已排到 {d.month}/{d.day} {plan.hhmm(b['start'])}")

    # ---- 一键排今天
    def suggest_today(self, now=None):
        now = now or datetime.now()
        today = now.date()
        self._suggest = plan.suggest_day(today, now.hour * 60 + now.minute)
        self.sg_list.clear()
        for s in self._suggest:
            it = QListWidgetItem(f"{plan.hhmm(s['start'])}–{plan.hhmm(s['start'] + s['minutes'])}　{s.get('subject') or ''} {s['task']}")
            it.setToolTip(s.get("why", ""))
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked)
            self.sg_list.addItem(it)
        free = sum(e - s for s, e in plan.free_slots(today, now.hour * 60 + now.minute))
        if self._suggest:
            used = sum(s["minutes"] for s in self._suggest)
            self.sg_note.setText(f"今天还空 {free} 分钟，建议排 {len(self._suggest)} 项共 {used} 分钟（留出余量）。鼠标停在一项上看为什么这样排。")
        elif not free:
            self.sg_note.setText("今天剩下的可用时段已经排满了。可以在「设置」里改每天可用时段。")
        else:
            self.sg_note.setText("现在没有要排的任务：复习没到期、没有薄弱点和背诵任务。")
        self.sg_go.setEnabled(bool(self._suggest))
        self._side_tab("pull")
        if self.view_mode != "day" or self.day != today:
            self.day = today
            self.week_start = today - timedelta(days=today.weekday())
        if self.stack.currentWidget() is not self.views["plan"]:
            self.show_tab("plan")
        return self._suggest

    def accept_suggest(self):
        items = [s for i, s in enumerate(getattr(self, "_suggest", [])) if self.sg_list.item(i).checkState() == Qt.CheckState.Checked]
        made = plan.accept(items)
        self._suggest = []
        self.sg_list.clear()
        self.sg_go.setEnabled(False)
        self.sg_note.setText(f"已排入 {len(made)} 项。拖动计划表里的块可以微调。")
        self._plan_changed()
        self.set_status(f"排入 {len(made)} 项", "ok")
        return made

    # ---- 编辑一块
    def _pick_block(self, bid):
        b = plan.get(bid) if bid else None
        self._loading = True
        for x in (self.ed_box, self.ed_subs, self.ed_sub_row, self.ed_keys):
            x.setEnabled(b is not None)
        if b:
            if self.side_stack.currentWidget() is not self.side_views["block"] and self.sender() is self.grid:
                self._side_tab("block")
            self.ed_hint.setText(f"{date.fromisoformat(b['day']).month}/{date.fromisoformat(b['day']).day} 周{WEEK[date.fromisoformat(b['day']).weekday()]} "
                                 f"{plan.hhmm(b['start'])}–{plan.hhmm(b['start'] + b['minutes'])}　来自：{plan.SOURCES.get(b.get('source'), '自己')}")
            self.ed_subj.setCurrentIndex(max(0, self.ed_subj.findData(b.get("subject", ""))))
            self.ed_kind.setCurrentIndex(1 if b.get("source") == "exam" else 0)
            self.ed_task.setText(b.get("task", ""))
            self.ed_min.setValue(int(b["minutes"]))
            self.ed_pomos.setValue(int(b.get("pomos") or 0))
            self.ed_pri.setCurrentIndex(max(0, self.ed_pri.findData(int(b.get("priority", 1)))))
            has_dl = bool(b.get("deadline"))
            self.ed_dl_on.setChecked(has_dl)
            self.ed_dl.setEnabled(has_dl)
            dl = date.fromisoformat(b["deadline"]) if has_dl else date.fromisoformat(b["day"])
            self.ed_dl.setDate(QDate(dl.year, dl.month, dl.day))
            rule, days = plan.repeat_rule(b)
            self.ed_rep.setCurrentIndex(max(0, self.ed_rep.findData(rule)))
            for i, cb in enumerate(self.ed_day_cb):
                cb.setChecked(i in days)
            self.ed_days.setVisible(rule == "weekly")
            self.ed_subs.clear()
            for s in b.get("subtasks") or []:
                it = QListWidgetItem(s["t"])
                it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                it.setCheckState(Qt.CheckState.Checked if s["done"] else Qt.CheckState.Unchecked)
                self.ed_subs.addItem(it)
            info = [f"预计 {plan.pomos_of(b)} 个番茄 · 已专注 {int(float(b.get('focused') or 0) / 60)} 分钟"]
            if b.get("carried"):
                info.append(f"已顺延 {b['carried']} 次（最早排在 {b.get('orig') or '—'}）")
            if b.get("deadline"):
                left = (date.fromisoformat(b["deadline"]) - date.today()).days
                info.append(f"截止 {b['deadline'][5:]}（" + (f"还有 {left} 天" if left > 0 else "今天" if left == 0 else f"过了 {-left} 天") + "）")
            if b.get("why"):
                info.append("为什么这样排：" + b["why"])
            self.ed_info.setText("\n".join(info))
        else:
            self.ed_hint.setText("点计划表里的一块来编辑；或者「新建一块」。")
            self.ed_subs.clear()
            self.ed_info.setText("")
        self._loading = False

    def save_block(self):
        bid = self.grid.sel
        if not bid:
            return
        subs = [dict(t=self.ed_subs.item(i).text(), done=self.ed_subs.item(i).checkState() == Qt.CheckState.Checked)
                for i in range(self.ed_subs.count())]
        q = self.ed_dl.date()
        dl = date(q.year(), q.month(), q.day()).isoformat() if self.ed_dl_on.isChecked() else ""
        cur = plan.get(bid) or {}
        src = "exam" if self.ed_kind.currentData() == "exam" else (cur.get("source") if cur.get("source") != "exam" else "self")
        done = cur.get("done", False)
        if subs and all(s["done"] for s in subs) and not all(s["done"] for s in cur.get("subtasks") or [dict(done=False)]):
            done = True                                         # 刚勾完最后一个子任务
        plan.update(bid, subject=self.ed_subj.currentData() or "", task=self.ed_task.text().strip(), minutes=self.ed_min.value(),
                    pomos=self.ed_pomos.value(), priority=self.ed_pri.currentData(), deadline=dl, subtasks=subs, source=src, done=done)
        rule = self.ed_rep.currentData()
        days = [i for i, cb in enumerate(self.ed_day_cb) if cb.isChecked()]
        old_rule, old_days = plan.repeat_rule(plan.get(bid))
        if (rule, days if rule == "weekly" else []) != (old_rule, old_days if old_rule == "weekly" else []):
            if rule == "weekly" and not days:
                self.set_status("每周几：至少勾一天", "warn")
            else:
                plan.set_repeat(bid, rule, days)
                plan.ensure_repeats(self._days())
        self._plan_changed()
        self.set_status("已保存", "ok")

    def add_subtask(self):
        """加子任务、勾子任务都连同编辑栏里别的改动一起存（不然重读会把没保存的改动冲掉）。"""
        t = self.ed_sub_new.text().strip()
        if not t or not self.grid.sel:
            return
        self._loading = True
        it = QListWidgetItem(t)
        it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
        it.setCheckState(Qt.CheckState.Unchecked)
        self.ed_subs.addItem(it)
        self._loading = False
        self.ed_sub_new.clear()
        self.save_block()

    def _sub_changed(self, _item):
        if self._loading or not self.grid.sel:
            return
        self.save_block()

    def delete_block(self):
        if self.grid.sel:
            plan.remove(self.grid.sel)
            self.grid.sel = ""
            self._plan_changed()

    def _plan_changed(self):
        if self.view_mode == "month":
            self.month.set_month(self.day)
        self.grid.reload()
        self._pick_block(self.grid.sel)
        self.refresh_today()
        if self.stack.currentWidget() is self.views["plan"]:
            self.refresh_plan()

    # ---- 目标
    def refresh_goals(self):
        self._loading = True
        gp = plan.goal_progress()
        g = plan.goals()
        self.gl_total.setValue(int(g.get("total") or 0))
        for s, sp in self.gl_sub.items():
            sp.setValue(int(g.get("subjects", {}).get(s, 0)))
        rows = [(r["subject"], r["rate"] or 0, f"{r['current'] if r['current'] is not None else '—'}/{r['target']}") for r in gp["subjects"]]
        self.gl_bars.set_rows(rows)
        if gp["subjects"]:
            self.gl_sum.setText(f"目标 {gp['total']} 分" + (f"，按最近一次考试折算约 {int(gp['current_total'])} 分（已考科目），达成 {int(gp['rate'] * 100)}%"
                                                         if gp["rate"] is not None else "；还没有考试成绩，考过后这里会显示差距。"))
        else:
            self.gl_sum.setText("给各科定一个目标分；考情里的成绩会按得分率折算，显示还差多少。")
        wk = plan.week(self.day)
        ws = self.day - timedelta(days=self.day.weekday())
        self.wk_list.clear()
        for x in wk["goals"]:
            it = QListWidgetItem(x["t"])
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if x["done"] else Qt.CheckState.Unchecked)
            self.wk_list.addItem(it)
        wp = plan.week_progress(self.day)
        self.wk_sum.setText(f"{ws.month}/{ws.day} 这周：目标 {wp['goals_done']}/{len(wp['goals'])} 条，计划完成 {int((wp['rate'] or 0) * 100)}%"
                            if wk["goals"] or wp["n"] else f"{ws.month}/{ws.day} 这周还没写目标。")
        self._loading = False

    def save_goals(self):
        plan.set_goals(total=self.gl_total.value(), subjects={s: sp.value() for s, sp in self.gl_sub.items()})
        self.refresh_goals()
        self.set_status("目标已保存", "ok")

    def add_week_goal(self):
        t = self.wk_new.text().strip()
        if not t:
            return
        plan.set_week(self.day, plan.week(self.day)["goals"] + [dict(t=t, done=False)])
        self.wk_new.clear()
        self.refresh_goals()
        self.refresh_plan()

    def _week_changed(self, _item):
        if self._loading:
            return
        goals = [dict(t=self.wk_list.item(i).text(), done=self.wk_list.item(i).checkState() == Qt.CheckState.Checked)
                 for i in range(self.wk_list.count())]
        plan.set_week(self.day, goals)
        self.refresh_goals()

    # ------------------------------------------------------------ 复盘
    def _build_review(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 6, 0)
        v.setSpacing(12)
        bar = QHBoxLayout()
        self.rv_seg = Segmented([("day", "每日复盘"), ("week", "每周复盘")], "day")
        self.rv_seg.changed.connect(self._rv_kind)
        bar.addWidget(self.rv_seg)
        for text, k, tip in (("‹", -1, "往前"), ("今天", 0, "回到今天"), ("›", 1, "往后")):
            b = _btn(text, lambda k=k: self._rv_shift(k), "ghost", tip)
            if text != "今天":
                b.setFixedWidth(34)
            bar.addWidget(b)
        self.rv_range = _label("", "cardTitle")
        bar.addWidget(self.rv_range)
        bar.addStretch(1)
        v.addLayout(bar)
        tiles = QHBoxLayout()
        self.rv_tiles = []
        for _ in range(4):
            f, fv = _card()
            a, b = _label("", "tileBig"), _label("", "note")
            fv.addWidget(a)
            fv.addWidget(b)
            self.rv_tiles.append((a, b))
            tiles.addWidget(f, 1)
        v.addLayout(tiles)
        c1, c1v = _card()
        c1v.addWidget(_label("各科时间：计划 vs 实际", "cardTitle"))
        self.rv_pairs = PairBars()
        c1v.addWidget(self.rv_pairs)
        v.addWidget(c1)
        c2, c2v = _card()
        c2v.addWidget(_label("一句话复盘", "cardTitle"))
        self.rv_obs = _label("", "note", True)
        c2v.addWidget(self.rv_obs)
        r = QHBoxLayout()
        self.rv_text = QLineEdit()
        self.rv_text.setPlaceholderText("今天怎么样？哪里没做完、为什么，明天怎么调")
        self.rv_text.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.rv_text.returnPressed.connect(self.save_review)
        r.addWidget(self.rv_text, 1)
        r.addWidget(_btn("保存复盘", self.save_review, "pri"))
        c2v.addLayout(r)
        c2v.addWidget(_label("写过的复盘会出现在今日页和考情分析里。", "note", True))
        v.addWidget(c2)
        c3, c3v = _card()
        c3v.addWidget(_label("最近的复盘", "cardTitle"))
        self.rv_hist = QListWidget()
        self.rv_hist.setMinimumHeight(140)
        c3v.addWidget(self.rv_hist)
        v.addWidget(c3)
        v.addStretch(1)
        scroll.setWidget(w)
        return scroll

    def _rv_kind(self, k):
        self.rv_kind = k
        self.rv_seg.set_value(k)
        self.refresh_review()

    def _rv_shift(self, k):
        self.rv_day = date.today() if k == 0 else self.rv_day + timedelta(days=k * (7 if self.rv_kind == "week" else 1))
        self.refresh_review()

    def refresh_review(self):
        rv = plan.review(self.rv_kind, self.rv_day)
        s, e = date.fromisoformat(rv["start"]), date.fromisoformat(rv["end"])
        self.rv_range.setText(f"{s.month}/{s.day} 周{WEEK[s.weekday()]}" if self.rv_kind == "day" else f"{s.month}/{s.day} – {e.month}/{e.day}")
        dev = rv["deviation"]
        vals = [(f"{int(rv['rate'] * 100)}%" if rv["rate"] is not None else "—", f"完成率（{rv['done']}/{rv['n']} 块）"),
                (f"{int(rv['planned'])}/{int(rv['actual'])}", "计划 / 实际（分钟）"),
                (("+" if dev >= 0 else "") + f"{int(dev)}′", "实际比计划" + ("多" if dev >= 0 else "少")),
                (str(rv["carried"]), "块是顺延来的" + (f"（最多 {rv['max_carried']} 次）" if rv["carried"] else ""))]
        for (a, b), (x, y) in zip(self.rv_tiles, vals):
            a.setText(x)
            b.setText(y)
        self.rv_pairs.set_rows([(x["subject"], x["planned"], x["actual"]) for x in rv["subjects"]])
        self.rv_obs.setText("观察：" + rv["observe"])
        self.rv_text.setText(rv["text"])
        self.rv_text.setPlaceholderText("今天怎么样？哪里没做完、为什么，明天怎么调" if self.rv_kind == "day" else "这周怎么样？下周重点放在哪")
        self.rv_hist.clear()
        data = plan._load()["reviews"]
        for k in sorted(data, reverse=True)[:14]:
            kind, d = k.split(":", 1)
            dd = date.fromisoformat(d)
            self.rv_hist.addItem(("周 " if kind == "w" else "") + f"{dd.month}/{dd.day}　{data[k].get('text', '')}")
        if not self.rv_hist.count():
            it = QListWidgetItem("还没写过复盘。每天晚上的提醒会叫你来写一句。")
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.rv_hist.addItem(it)

    def save_review(self):
        plan.save_review_text(self.rv_kind, self.rv_day, self.rv_text.text())
        self.refresh_review()
        self.set_status("复盘已保存", "ok")

    # ------------------------------------------------------------ 统计
    def _build_stats(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 6, 0)
        v.setSpacing(12)
        tiles = QHBoxLayout()
        self.s_tiles = []
        for _ in range(4):
            f, fv = _card()
            a, b = _label("", "tileBig"), _label("", "note")
            fv.addWidget(a)
            fv.addWidget(b)
            self.s_tiles.append((a, b))
            tiles.addWidget(f, 1)
        v.addLayout(tiles)
        row = QHBoxLayout()
        c1, c1v = _card()
        c1v.addWidget(_label("近七天每天专注", "cardTitle"))
        self.s_days = Bars(color="accent")
        c1v.addWidget(self.s_days)
        c1v.addStretch(1)
        row.addWidget(c1, 1)
        c2, c2v = _card()
        c2v.addWidget(_label("各科专注时长", "cardTitle"))
        self.s_subj = Bars(color="c3")
        c2v.addWidget(self.s_subj)
        c2v.addStretch(1)
        row.addWidget(c2, 1)
        v.addLayout(row)
        c3, c3v = _card()
        c3v.addWidget(_label("中断与放弃", "cardTitle"))
        c3v.addWidget(_label("中断＝专注中切到白名单以外的程序超过宽限时间，或长时间没有键鼠输入。只在本机记录。", "note", True))
        self.s_kinds = Bars(color="warn")
        c3v.addWidget(self.s_kinds)
        self.s_reasons = _label("", "note", True)
        c3v.addWidget(self.s_reasons)
        v.addWidget(c3)
        v.addStretch(1)
        scroll.setWidget(w)
        return scroll

    def refresh_stats(self):
        s = core.summary(7)
        t = s["total"]
        today = s["days"][-1]
        vals = [(f"{int(t['focus_min'])} 分钟", f"近七天专注 · 今天 {int(today['focus_min'])} 分钟"),
                (f"{t['done']}/{t['started']}", "完成的番茄 / 开始的番茄" + (f"（{int(t['rate'] * 100)}%）" if t["rate"] is not None else "")),
                (str(t["interruptions"]), "次中断（近七天）"),
                (f"{int(t['plan_rate'] * 100)}%" if t["plan_rate"] is not None else "—", f"计划完成率（{t['plan_done']}/{t['plan_total']} 块）")]
        for (a, b), (x, y) in zip(self.s_tiles, vals):
            a.setText(x)
            b.setText(y)
        mx = max([r["focus_min"] for r in s["days"]] + [1])
        self.s_days.set_rows([(f"周{WEEK[date.fromisoformat(r['day']).weekday()]}", r["focus_min"] / mx,
                               f"{int(r['focus_min'])} 分") for r in s["days"]])
        ms = max(list(s["subjects"].values()) + [1])
        self.s_subj.set_rows([(k, v / ms, f"{int(v)} 分") for k, v in sorted(s["subjects"].items(), key=lambda t: -t[1])])
        tot = sum(s["kinds"].values()) or 1
        self.s_kinds.set_rows([(KIND_NAME.get(k, k), n / tot, f"{n} 次") for k, n in s["kinds"].items()])
        self.s_reasons.setText("最近放弃的理由：" + "；".join(s["reasons"]) if s["reasons"] else "")

    # ------------------------------------------------------------ 设置
    def _build_set(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 6, 0)
        v.setSpacing(12)
        row = QHBoxLayout()
        row.setSpacing(12)
        c, cv = _card()
        cv.addWidget(_label("番茄与监督", "cardTitle"))
        g = QGridLayout()
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(8)
        self.st = {}
        for r, (k, text, lo, hi, suf) in enumerate((("focus", "专注", 1, 180, " 分钟"), ("short", "短休", 1, 60, " 分钟"),
                                                    ("long", "长休", 1, 90, " 分钟"), ("rounds", "几个番茄一轮", 1, 12, " 个"),
                                                    ("idle_minutes", "多久没输入算无操作", 1, 60, " 分钟"),
                                                    ("grace_seconds", "切走多久算离开", 5, 600, " 秒"))):
            g.addWidget(_label(text, "ctlLabel"), r, 0)
            sp = QSpinBox()
            sp.setRange(lo, hi)
            sp.setSuffix(suf)
            g.addWidget(sp, r, 1)
            self.st[k] = sp
        cv.addLayout(g)
        for k, text in (("auto_break", "专注结束自动开始休息"), ("auto_focus", "休息结束自动开始下一个番茄"),
                        ("floater", "番茄进行时在桌面显示小窗"),
                        ("watch", "专注监督：切到白名单以外的程序、长时间没输入时记一次中断并温和提醒"),
                        ("strict", "严格模式：中途放弃要写一句理由")):
            cb = QCheckBox(text)
            self.st[k] = cb
            cv.addWidget(cb)
        cv.addWidget(_label("白名单（专注时允许在前台的程序，一行一个，如 wps.exe）。见微自己总是允许。", "ctlLabel"))
        self.st_white = QPlainTextEdit()
        self.st_white.setMaximumHeight(120)
        cv.addWidget(self.st_white)
        cv.addWidget(_label("监督只读本机前台程序名和空闲时长，不截图、不记窗口内容、不上传。", "note", True))
        cv.addStretch(1)
        row.addWidget(c, 1)
        c2, c2v = _card()
        c2v.addWidget(_label("每日提醒", "cardTitle"))
        for k, text in (("remind", "打开提醒（关掉后早晚提醒、到点提醒都不响）"), ("tray_bubble", "同时弹托盘气泡"),
                        ("sound", "提醒时响一声"), ("remind_due_on", "到期复习、背诵提醒")):
            cb = QCheckBox(text)
            self.st[k] = cb
            c2v.addWidget(cb)
        g2 = QGridLayout()
        g2.setHorizontalSpacing(8)
        g2.setVerticalSpacing(6)
        g2.addWidget(_label("时间块开始前", "ctlLabel"), 0, 0)
        self.st["remind_lead"] = QSpinBox()
        self.st["remind_lead"].setRange(0, 120)
        self.st["remind_lead"].setSuffix(" 分钟")
        g2.addWidget(self.st["remind_lead"], 0, 1, 1, 2)
        g2.addWidget(_label("到期提醒时间", "ctlLabel"), 1, 0)
        self.st_due = _time_edit("17:30")
        g2.addWidget(self.st_due, 1, 1, 1, 2)
        self.st["dnd_on"] = QCheckBox("免打扰")
        g2.addWidget(self.st["dnd_on"], 2, 0)
        self.st_dnd_a, self.st_dnd_b = _time_edit("22:30"), _time_edit("06:30")
        g2.addWidget(self.st_dnd_a, 2, 1)
        g2.addWidget(self.st_dnd_b, 2, 2)
        c2v.addLayout(g2)
        c2v.addWidget(_label("早上推今日计划，晚上推复盘。每天可以单独设，周末单独设；见微没开时错过的，下次启动补报。", "note", True))
        g3 = QGridLayout()
        g3.setHorizontalSpacing(8)
        g3.setVerticalSpacing(4)
        g3.addWidget(_label("早上", "ctlLabel"), 0, 2)
        g3.addWidget(_label("晚上", "ctlLabel"), 0, 3)
        self.st_daily = []
        for i in range(7):
            on = QCheckBox("周" + WEEK[i])
            am, pm = _time_edit("07:00"), _time_edit("21:30")
            g3.addWidget(on, i + 1, 0, 1, 2)
            g3.addWidget(am, i + 1, 2)
            g3.addWidget(pm, i + 1, 3)
            self.st_daily.append((on, am, pm))
        c2v.addLayout(g3)
        c2v.addWidget(_label("每天可用时段（一键排程只往这里排）", "cardTitle"))
        g4 = QGridLayout()
        g4.setHorizontalSpacing(8)
        g4.addWidget(_label("周一到周五", "ctlLabel"), 0, 0)
        self.st_av_wd = QLineEdit()
        self.st_av_wd.setPlaceholderText("18:30-22:30")
        g4.addWidget(self.st_av_wd, 0, 1)
        g4.addWidget(_label("周末", "ctlLabel"), 1, 0)
        self.st_av_we = QLineEdit()
        self.st_av_we.setPlaceholderText("8:30-11:30, 14:00-17:30")
        g4.addWidget(self.st_av_we, 1, 1)
        c2v.addLayout(g4)
        c2v.addStretch(1)
        row.addWidget(c2, 1)
        v.addLayout(row)
        hb = QHBoxLayout()
        hb.addStretch(1)
        hb.addWidget(_btn("保存设置", self.save_settings, "pri"))
        v.addLayout(hb)
        v.addStretch(1)
        scroll.setWidget(w)
        return scroll

    def load_settings(self):
        s = core.settings()
        for k, wdg in self.st.items():
            if isinstance(wdg, QSpinBox):
                wdg.setValue(int(s[k]))
            else:
                wdg.setChecked(bool(s[k]))
        self.st_white.setPlainText("\n".join(s["whitelist"]))
        for qt, k in ((self.st_due, "remind_due"), (self.st_dnd_a, "dnd_start"), (self.st_dnd_b, "dnd_end")):
            m = plan.parse_hhmm(s[k], 0)
            qt.setTime(QTime(m // 60, m % 60))
        for i, (on, am, pm) in enumerate(self.st_daily):
            row = s["remind_daily"][str(i)]
            on.setChecked(bool(row.get("on")))
            for qt, k in ((am, "am"), (pm, "pm")):
                m = plan.parse_hhmm(row.get(k), 0)
                qt.setTime(QTime(m // 60, m % 60))
        av = plan.avail()
        self.st_av_wd.setText(plan.ranges_text(av["weekday"]))
        self.st_av_we.setText(plan.ranges_text(av["weekend"]))

    def save_settings(self):
        kw = {k: (w.value() if isinstance(w, QSpinBox) else w.isChecked()) for k, w in self.st.items()}
        kw["whitelist"] = self.st_white.toPlainText().split()
        kw.update(remind_due=_hm(self.st_due), dnd_start=_hm(self.st_dnd_a), dnd_end=_hm(self.st_dnd_b),
                  remind_daily={str(i): dict(on=on.isChecked(), am=_hm(am), pm=_hm(pm)) for i, (on, am, pm) in enumerate(self.st_daily)})
        wd, we = plan.parse_ranges(self.st_av_wd.text()), plan.parse_ranges(self.st_av_we.text())
        if self.st_av_wd.text().strip() and not wd or self.st_av_we.text().strip() and not we:
            self.set_status("可用时段写成 18:30-22:30，几段用逗号隔开", "bad")
            return
        try:
            core.save_settings(**kw)
        except ValueError as e:
            self.set_status(str(e), "bad")
            return
        plan.set_avail(wd, we)
        self.eng.reload_settings()
        self.set_status("已保存。时长从下一个阶段起生效。", "ok")

    # ------------------------------------------------------------ 外观
    def showEvent(self, e):  # noqa: N802
        super().showEvent(e)
        self.refresh_today()
        self._sync_keys()

    def apply_theme(self):
        self.setStyleSheet(qss() + f"""
QWidget#focusPage {{ background:{"transparent" if self.compact else T.bg}; color:{T.fg}; }}
QLabel#examTitle {{ color:{T.fg}; font-size:20px; font-weight:700; padding-right:6px; }}
QLabel#examStatus {{ font-size:12px; padding-left:8px; color:{T.muted}; }}
QFrame#examCard {{ background:{T.surface}; border:1px solid {T.line}; border-radius:10px; }}
QLabel#cardTitle {{ color:{T.fg}; font-size:14px; font-weight:700; }}
QLabel#tileBig {{ color:{T.fg}; font-size:24px; font-weight:700; }}
QListWidget::item:selected {{ background:{css(T.accent, .14)}; }}
""")
