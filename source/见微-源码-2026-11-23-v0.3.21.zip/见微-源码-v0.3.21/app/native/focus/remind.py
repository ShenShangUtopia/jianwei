"""每日提醒：早上推今日计划、晚上推复盘、时间块开始前 N 分钟、到期复习 / 背诵、考试。

纯 Python，时间都由调用方给（引擎传 now_dt()，自测传假时钟）。
check(now, cfg) 每次看「上次检查到现在」之间该响的提醒：
  - 刚到点的（块还没过、早晚提醒 20 分钟内）＝ live，逐条推；
  - 更早的（见微没开、免打扰期间）＝ missed，合成一条「错过的提醒」补报；
  - 免打扰时段里什么都不推，也不往前挪「上次检查」，出了免打扰再一起补。
推迟：snooze(item, 10) 记到 focus-remind.json，到点当 live 再推一次。
数据 focus-remind.json = {last: 时间戳, fired: {key: 时间戳}, snooze: [{at, item}]}。
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

from ..kit.home import load_json, save_json
from . import plan

FILE = "focus-remind.json"
LOOKBACK = 24 * 3600            # 最多补报 24 小时内错过的
LIVE_DAILY = 20 * 60            # 早晚提醒、到期提醒：20 分钟内算刚到点
KINDS = dict(morning="今日计划", evening="晚间复盘", block="计划到点", exam="考试", due="到期复习", missed="错过的提醒")
WEEK = "一二三四五六日"


def default_daily() -> dict:
    return {str(i): dict(on=True, am="07:00" if i < 5 else "08:30", pm="21:30") for i in range(7)}


def _state():
    s = load_json(FILE, None)
    if not isinstance(s, dict):
        s = {}
    s.setdefault("last", 0.0)
    s.setdefault("fired", {})
    s.setdefault("snooze", [])
    return s


def in_dnd(now: datetime, cfg) -> bool:
    if not cfg.get("dnd_on", True):
        return False
    a = plan.parse_hhmm(cfg.get("dnd_start", "22:30"), 22 * 60 + 30)
    b = plan.parse_hhmm(cfg.get("dnd_end", "06:30"), 6 * 60 + 30)
    m = now.hour * 60 + now.minute
    if a == b:
        return False
    return a <= m < b if a < b else (m >= a or m < b)


def _at(day: date, minutes) -> datetime:
    return datetime.combine(day, datetime.min.time()) + timedelta(minutes=int(minutes))


def _due_counts():
    rev, rec = 0, 0
    try:
        from .. import learning
        for _k, it in learning.due():
            if (it.get("card") or {}).get("src") in ("word", "poem"):
                rec += 1
            else:
                rev += 1
    except Exception:   # noqa: BLE001
        pass
    return rev, rec


def morning_text(day: date) -> str:
    bs = [b for b in plan.blocks(day.isoformat())]
    study = [b for b in bs if b.get("source") != "exam"]
    exams = [b for b in bs if b.get("source") == "exam"]
    parts = []
    if study:
        mins = sum(b["minutes"] for b in study)
        first = study[0]
        parts.append(f"今天排了 {len(study)} 块、共 {mins // 60} 小时 {mins % 60} 分；第一项 {plan.hhmm(first['start'])} "
                     f"{first.get('subject') or ''} {first.get('task') or ''}".rstrip())
        car = [b for b in study if b.get("carried")]
        if car:
            parts.append(f"其中 {len(car)} 块是顺延来的")
    else:
        parts.append("今天还没排计划，可以在专注页「一键排今天」")
    rev, rec = _due_counts()
    if rev or rec:
        parts.append("到期：" + "、".join(x for x in (f"复习 {rev} 项" if rev else "", f"背诵 {rec} 项" if rec else "") if x))
    for e in exams:
        parts.append(f"考试 {plan.hhmm(e['start'])} {e.get('subject') or ''} {e.get('task') or ''}".rstrip())
    return "。".join(parts) + "。"


def evening_text(day: date) -> str:
    p = plan.day_progress(day)
    if p["n"]:
        s = f"今天完成 {p['done']}/{p['n']} 块（{int((p['rate'] or 0) * 100)}%），实际专注 {int(p['actual'])} 分钟。花一分钟写一句复盘。"
    else:
        s = f"今天专注 {int(p['actual'])} 分钟。写一句复盘，顺手排一下明天。"
    tm = [b for b in plan.blocks((day + timedelta(days=1)).isoformat()) if b.get("source") == "exam"]
    if tm:
        s += "明天有考试：" + "、".join(f"{plan.hhmm(b['start'])} {b.get('subject') or ''}{b.get('task') or ''}" for b in tm) + "。"
    return s


def _events(day: date, cfg) -> list[tuple[datetime, dict]]:
    """这一天所有该响的提醒（时间, item）。文字到响的时候再算。"""
    out = []
    daily = (cfg.get("remind_daily") or default_daily()).get(str(day.weekday())) or {}
    iso = day.isoformat()
    if daily.get("on", True):
        am = plan.parse_hhmm(daily.get("am"))
        pm = plan.parse_hhmm(daily.get("pm"))
        if am is not None:
            out.append((_at(day, am), dict(key="morning:" + iso, kind="morning", day=iso)))
        if pm is not None:
            out.append((_at(day, pm), dict(key="evening:" + iso, kind="evening", day=iso)))
    lead = max(0, int(cfg.get("remind_lead", 5)))
    for b in plan.blocks(iso):
        if b.get("done"):
            continue
        kind = "exam" if b.get("source") == "exam" else "block"
        ld = max(lead, 30) if kind == "exam" else lead       # 考试至少提前半小时
        out.append((_at(day, b["start"] - ld), dict(key=f"block:{b['id']}:{iso}:{b['start']}", kind=kind, day=iso, block=b["id"],
                                                    start=b["start"], end=b["start"] + b["minutes"], lead=ld,
                                                    subject=b.get("subject", ""), task=b.get("task", ""))))
    if cfg.get("remind_due_on", True):
        t = plan.parse_hhmm(cfg.get("remind_due", "17:30"))
        if t is not None:
            out.append((_at(day, t), dict(key="due:" + iso, kind="due", day=iso)))
    return out


def _fill(item, now: datetime) -> dict | None:
    """把文字填上；该响但已经没意义的（到期 0 项）返回 None。"""
    it = dict(item)
    k = it["kind"]
    it["title"] = KINDS.get(k, "提醒")
    if k == "morning":
        it["text"] = morning_text(date.fromisoformat(it["day"]))
    elif k == "evening":
        it["text"] = evening_text(date.fromisoformat(it["day"]))
    elif k in ("block", "exam"):
        b = plan.get(it["block"])
        if b is None or b.get("done"):
            return None
        what = f"{b.get('subject') or ''} {b.get('task') or ''}".strip() or "计划里的一项"
        now_m = now.hour * 60 + now.minute if now.date().isoformat() == it["day"] else -1
        left = b["start"] - now_m
        if 0 < left:
            it["text"] = f"{left} 分钟后（{plan.hhmm(b['start'])}）{'开考' if k == 'exam' else '开始'}：{what}"
        else:
            it["text"] = f"{plan.hhmm(b['start'])} 该做：{what}" if k == "block" else f"{plan.hhmm(b['start'])} 考试：{what}"
        if b.get("carried"):
            it["text"] += f"（已顺延 {b['carried']} 次）"
        it.update(subject=b.get("subject", ""), task=b.get("task", ""))
    elif k == "due":
        rev, rec = _due_counts()
        if not (rev or rec):
            return None
        it["text"] = "今天到期：" + "、".join(x for x in (f"复习 {rev} 项" if rev else "", f"背诵 {rec} 项" if rec else "") if x) + "，趁现在过一遍。"
        it["subject"], it["task"] = "", "到期复习"
    return it


def _live(item, t: datetime, now: datetime) -> bool:
    if item["kind"] in ("block", "exam"):
        end_live = _at(date.fromisoformat(item["day"]), item["start"] + 10)
        return now < end_live
    return (now - t).total_seconds() <= LIVE_DAILY


def check(now: datetime, cfg) -> list[dict]:
    """该推的提醒。每项 {key, kind, title, text, block?, subject?, task?, missed}。missed 的由调用方合成一条补报。"""
    if not cfg.get("remind", True):
        return []
    st = _state()
    nowt = now.timestamp()
    if in_dnd(now, cfg):
        if not st["last"]:
            st["last"] = nowt
            save_json(FILE, st)
        return []
    last = float(st["last"] or 0) or nowt - 60
    last = max(last, nowt - LOOKBACK)
    out = []
    fired = st["fired"]
    d0 = datetime.fromtimestamp(last).date()
    d = d0
    while d <= now.date():
        for t, item in _events(d, cfg):
            ts = t.timestamp()
            if not (last < ts <= nowt) or item["key"] in fired:
                continue
            filled = _fill(item, now)
            fired[item["key"]] = nowt
            if filled is None:
                continue
            filled["missed"] = not _live(item, t, now)
            filled["at"] = ts
            out.append(filled)
        d += timedelta(days=1)
    keep = []
    for s in st["snooze"]:
        if float(s.get("at", 0)) <= nowt:
            it = dict(s["item"])
            if it.get("block"):
                b = plan.get(it["block"])
                if b is None or b.get("done"):
                    continue
            it["missed"] = nowt - float(s["at"]) > LIVE_DAILY
            it["snoozed"] = True
            out.append(it)
        else:
            keep.append(s)
    st["snooze"] = keep
    st["last"] = nowt
    cut = nowt - 3 * 86400
    st["fired"] = {k: v for k, v in fired.items() if v >= cut}
    save_json(FILE, st)
    out.sort(key=lambda x: x.get("at", nowt))
    return out


def snooze(item, minutes=10, now: datetime | None = None):
    now = now or datetime.now()
    st = _state()
    it = {k: v for k, v in item.items() if k not in ("missed", "snoozed")}
    st["snooze"].append(dict(at=now.timestamp() + minutes * 60, item=it))
    st["snooze"] = st["snooze"][-50:]
    save_json(FILE, st)


def pending_snoozes() -> list[dict]:
    return list(_state()["snooze"])


def merge_missed(items) -> dict | None:
    """错过的几条合成一条补报。"""
    if not items:
        return None
    lines = []
    for it in items[:6]:
        t = datetime.fromtimestamp(it.get("at", 0)).strftime("%H:%M") if it.get("at") else ""
        lines.append(f"{t} {it['title']}：{it['text']}".strip())
    more = f"……还有 {len(items) - 6} 条" if len(items) > 6 else ""
    blk = next((it for it in items if it.get("block") and plan.get(it["block"]) and not plan.get(it["block"]).get("done")), None)
    return dict(key="missed:" + str(items[-1].get("at", "")), kind="missed", title=f"你不在时错过了 {len(items)} 条提醒",
                text="\n".join(lines) + more, block=blk["block"] if blk else "", subject=blk.get("subject", "") if blk else "",
                task=blk.get("task", "") if blk else "", missed=True, items=items)
