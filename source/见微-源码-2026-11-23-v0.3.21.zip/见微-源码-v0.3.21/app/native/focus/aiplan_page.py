"""AI 排计划的预览页：生成 → 看诊断 → 逐项勾选 / 改时间 / 删 / 加 → 按要求重排 → 接受后才写进计划。

入口：专注页计划栏「AI 排计划」、考情页、问 AI（说「帮我排下周计划」或点动作按钮）、每周自动草稿的提醒卡片。
open_dialog(parent, request) 弹一个窗口装 AIPlanPanel。生成在后台线程（自测里 sync=True + 假引擎）。
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

from PySide6.QtCore import Qt, QTime, Signal
from PySide6.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLineEdit, QListWidget, QListWidgetItem, QSpinBox,
                               QTimeEdit, QVBoxLayout, QWidget)

from ..design.tokens import T, css
from ..design.widgets import Segmented, qss
from ..exam.page import Worker, _btn, _card, _label
from . import aiplan, plan

WEEK = "一二三四五六日"
QUICK = ["更轻松一点", "多练数学", "多背诵", "周末多排一点"]


class AIPlanPanel(QWidget):
    accepted = Signal(int)          # 写进计划的块数

    def __init__(self, request="", engine=None, today=None):
        super().__init__()
        self.setObjectName("aiplanPage")
        # 普通 QWidget 不加这个属性，样式表里的底色画不出来：放进对话框后底色变成系统默认的浅灰，夜间浅色字就看不清了
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.engine = engine        # 自测注入假引擎；None＝有密钥用真 AI，没有用规则版
        self.today_fn = today or (lambda: datetime.now())
        self.worker = None
        self.d = aiplan.draft()
        if self.d and self.d.get("status") != "draft":
            self.d = None
        v = QVBoxLayout(self)
        v.setContentsMargins(20, 16, 20, 16)
        v.setSpacing(10)
        top = QHBoxLayout()
        top.addWidget(_label("AI 排计划", "examTitle"))
        self.badge = _label("", "badge")
        top.addWidget(self.badge)
        top.addStretch(1)
        self.week = Segmented([("this", "本周剩下的"), ("next", "下周")], "next" if self.today_fn().weekday() >= 4 else "this")
        top.addWidget(self.week)
        v.addLayout(top)
        req = QHBoxLayout()
        self.req = QLineEdit(request)
        self.req.setPlaceholderText("额外要求（可空）：比如「更轻松一点」「多练数学」「周六下午要上课」")
        self.req.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        req.addWidget(self.req, 1)
        for q in QUICK:
            req.addWidget(_btn(q, lambda q=q: self._quick(q), "ghost"))
        self.k_gen = _btn("生成", self.generate, "", "本机先汇总学情（不发题目原文和个人信息），再请 AI 排；没有密钥用规则版")
        req.addWidget(self.k_gen)
        v.addLayout(req)
        self.note = _label("", "note", True)
        v.addWidget(self.note)
        body = QHBoxLayout()
        body.setSpacing(12)
        left, lv = _card()
        lv.addWidget(_label("学情诊断", "cardTitle"))
        self.dia = _label("", "body", True)
        self.dia.setTextFormat(Qt.TextFormat.RichText)
        lv.addWidget(self.dia)
        lv.addWidget(_label("下一阶段建议", "cardTitle"))
        self.adv = _label("", "body", True)
        lv.addWidget(self.adv)
        lv.addWidget(_label("本周目标（接受后进周目标）", "cardTitle"))
        self.goals = _label("", "body", True)
        lv.addWidget(self.goals)
        lv.addStretch(1)
        left.setMinimumWidth(280)
        left.setMaximumWidth(360)
        body.addWidget(left, 2)
        right, rv = _card()
        rv.addWidget(_label("计划草稿（勾掉不要的；选中一项可以改）", "cardTitle"))
        self.list = QListWidget()
        self.list.currentRowChanged.connect(self._pick)
        self.list.itemChanged.connect(self._toggled)
        rv.addWidget(self.list, 1)
        ed = QHBoxLayout()
        self.e_start = QTimeEdit()
        self.e_start.setDisplayFormat("HH:mm")
        self.e_min = QSpinBox()
        self.e_min.setRange(15, 120)
        self.e_min.setSingleStep(15)
        self.e_min.setSuffix(" 分钟")
        self.e_task = QLineEdit()
        self.e_task.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        ed.addWidget(self.e_start)
        ed.addWidget(self.e_min)
        ed.addWidget(self.e_task, 1)
        ed.addWidget(_btn("改", self.apply_edit))
        ed.addWidget(_btn("删", self.delete_item, "danger"))
        ed.addWidget(_btn("这天加一项", self.add_item, "ghost"))
        self.ed_box = QWidget()
        self.ed_box.setLayout(ed)
        ed.setContentsMargins(0, 0, 0, 0)
        self.ed_box.setEnabled(False)
        rv.addWidget(self.ed_box)
        body.addWidget(right, 5)
        v.addLayout(body, 1)
        bottom = QHBoxLayout()
        self.warn = _label("", "warn", True)
        bottom.addWidget(self.warn, 1)
        self.auto = QCheckBox("每周日傍晚自动出下周草稿（确认后才生效）")
        self.auto.setChecked(aiplan.auto_settings().get("on", False))
        self.auto.toggled.connect(aiplan.set_auto)
        bottom.addWidget(self.auto)
        self.k_redo = _btn("按要求重排", self.regenerate, "", "把上面的要求和这一版一起交给 AI，重新排")
        self.k_some = _btn("接受勾选的", lambda: self.accept(True))
        self.k_all = _btn("整份接受", lambda: self.accept(False), "pri", "写进计划；之后可以在计划表里拖动微调")
        for b in (self.k_redo, self.k_some, self.k_all):
            bottom.addWidget(b)
        v.addLayout(bottom)
        self.apply_theme()
        self.render()

    # ---- 生成
    def _quick(self, q):
        t = self.req.text().strip()
        if q not in t:
            self.req.setText((t + "，" if t else "") + q)

    def _start(self):
        now = self.today_fn()
        today = now.date()
        start = today - timedelta(days=today.weekday())
        if self.week.value == "next":
            start += timedelta(days=7)
        return start, today, now.hour * 60 + now.minute

    def generate(self, sync=False, previous=None):
        if self.worker is not None:
            return
        start, today, now_min = self._start()
        req = self.req.text().strip()
        eng = self.engine
        self.note.setText("正在本机汇总学情，再请 AI 排计划……" if (eng is not None or aiplan.ai_ready()) else "没有 AI 密钥，用规则版排……")
        for b in (self.k_gen, self.k_redo, self.k_all, self.k_some):
            b.setEnabled(False)
        job = lambda: aiplan.generate(start, today, now_min if start <= today else None, req, previous, eng)   # noqa: E731
        if sync:
            self._done(job())
            return
        self.worker = Worker(job)
        self.worker.done.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def regenerate(self, sync=False):
        if not self.d:
            self.generate(sync)
            return
        if not self.req.text().strip():
            self.note.setText("先在上面写一句要求，比如「更轻松一点」「多练数学」。")
            return
        self.generate(sync, previous=self.d)

    def _done(self, d):
        self.worker = None
        self.d = d
        self.render()

    def _failed(self, msg):
        self.worker = None
        self.note.setText("没排成：" + msg)
        self.render()

    # ---- 显示
    def render(self):
        d = self.d
        busy = self.worker is not None
        self.k_gen.setEnabled(not busy)
        for b in (self.k_redo, self.k_all, self.k_some):
            b.setEnabled(bool(d) and not busy)
        self.list.blockSignals(True)
        self.list.clear()
        if not d:
            self.badge.setText("")
            self.dia.setText("点「生成」：本机先汇总考情、背诵、专注和目标，再排出这一周的计划。没有 AI 密钥时用规则版。")
            self.adv.setText("")
            self.goals.setText("")
            it = QListWidgetItem("还没有草稿。")
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.list.addItem(it)
            self.warn.setText("")
            self.list.blockSignals(False)
            return
        self.badge.setText("AI 排的" if d.get("engine") == "ai" else "规则版")
        self.badge.setStyleSheet(f"color:{T.accent if d.get('engine') == 'ai' else T.warn};border:1px solid {css(T.accent if d.get('engine') == 'ai' else T.warn, .5)};"
                                 "border-radius:9px;padding:1px 8px;font-size:11.5px;")
        if d.get("note"):
            self.note.setText(d["note"])
        elif not self.note.text().startswith("已"):
            self.note.setText("看一眼诊断和每一项的理由，不合适就勾掉、改时间或者写要求重排。接受之前什么都不会写进计划。")
        dg = d.get("diagnosis") or {}
        parts = []
        for k, name, col in (("strengths", "强项", T.ok), ("weaknesses", "弱项", T.bad), ("risks", "风险", T.warn)):
            xs = dg.get(k) or []
            if xs:
                parts.append(f"<b style='color:{col}'>{name}</b><br>" + "<br>".join("· " + x for x in xs))
        self.dia.setText("<br><br>".join(parts) or "数据还太少，先做几次考试或练习。")
        self.adv.setText(d.get("advice") or "")
        self.goals.setText("\n".join("· " + g for g in d.get("week_goals") or []))
        self._rows, self._days = [], []
        for x in d["days"]:
            dd = date.fromisoformat(x["day"])
            tot = sum(b["minutes"] for b in x["blocks"] if b.get("on", True))
            head = QListWidgetItem(f"周{WEEK[dd.weekday()]} {dd.month}/{dd.day}　共 {tot} 分钟" + (f"（上限 {d['budget'].get(x['day'])}）" if d.get("budget") else ""))
            head.setFlags(Qt.ItemFlag.NoItemFlags)
            f = head.font()
            f.setBold(True)
            head.setFont(f)
            self.list.addItem(head)
            self._rows.append(None)
            self._days.append(x["day"])
            for i, b in enumerate(x["blocks"]):
                extra = []
                if b.get("qids"):
                    extra.append(f"题 {len(b['qids'])} 道")
                if b.get("pomos"):
                    extra.append(f"{b['pomos']} 个番茄")
                it = QListWidgetItem(f"{plan.hhmm(b['start'])}–{plan.hhmm(b['start'] + b['minutes'])}　{b.get('subject') or ''} {b['task']}"
                                     + (f"　[{aiplan.KINDS.get(b.get('kind'), '')}]" if b.get("kind") in aiplan.KINDS else "")
                                     + ("　" + " · ".join(extra) if extra else "") + (f"\n　　为什么：{b['why']}" if b.get("why") else ""))
                it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                it.setCheckState(Qt.CheckState.Checked if b.get("on", True) else Qt.CheckState.Unchecked)
                self.list.addItem(it)
                self._rows.append((x["day"], i))
                self._days.append(x["day"])
            if not x["blocks"]:
                it = QListWidgetItem("　这天没排（空闲时间不够，或者不需要）")
                it.setFlags(Qt.ItemFlag.NoItemFlags)
                self.list.addItem(it)
                self._rows.append(None)
                self._days.append(x["day"])
        cf = aiplan.conflicts(d)
        self.warn.setText(("时间冲突：" + "、".join(cf[:3]) + "（改一下时间再接受，接受时冲突的会自动往后找空档）") if cf else "")
        if d.get("status") == "accepted":
            for b in (self.k_redo, self.k_all, self.k_some):
                b.setEnabled(False)
        self.list.blockSignals(False)
        self._pick(self.list.currentRow())

    def _sel(self):
        r = self.list.currentRow()
        return self._rows[r] if self.d and 0 <= r < len(getattr(self, "_rows", [])) else None

    def _block(self, sel):
        day, i = sel
        x = next(x for x in self.d["days"] if x["day"] == day)
        return x["blocks"][i]

    def _pick(self, _r):
        sel = self._sel()
        self.ed_box.setEnabled(sel is not None and self.d.get("status") == "draft")
        if sel:
            b = self._block(sel)
            self.e_start.setTime(QTime(b["start"] // 60, b["start"] % 60))
            self.e_min.setValue(int(b["minutes"]))
            self.e_task.setText(b["task"])

    def _toggled(self, item):
        r = self.list.row(item)
        sel = self._rows[r] if 0 <= r < len(self._rows) else None
        if sel and self.d:
            aiplan.edit_item(self.d, sel[0], sel[1], on=item.checkState() == Qt.CheckState.Checked)
            self.render()

    def apply_edit(self):
        sel = self._sel()
        if not sel:
            return
        t = self.e_start.time()
        r = self.list.currentRow()
        self.d = aiplan.edit_item(self.d, sel[0], sel[1], start=t.hour() * 60 + t.minute(), minutes=self.e_min.value(),
                                  task=self.e_task.text().strip() or self._block(sel)["task"])
        self.render()
        self.list.setCurrentRow(r)

    def delete_item(self):
        sel = self._sel()
        if sel:
            self.d = aiplan.remove_item(self.d, sel[0], sel[1])
            self.render()

    def add_item(self, day=None):
        if day is None and self.d:
            r = max(0, self.list.currentRow())
            day = next((self._days[i] for i in range(min(r, len(self._days) - 1), -1, -1) if self._days[i]), None)
            day = day or (self.d["days"][0]["day"] if self.d["days"] else None)
        if day:
            self.d = aiplan.add_item(self.d, day)
            self.render()

    def accept(self, only_on=True):
        if not self.d:
            return []
        made = aiplan.accept(self.d, only_on)
        self.d = aiplan.draft()
        self.note.setText(f"已写进计划 {len(made)} 项，提醒照常生效。可以在计划表里拖动微调。")
        self.render()
        self.accepted.emit(len(made))
        return made

    def apply_theme(self):
        # 这个窗口是主窗口那套外观（卡片、按键用 ui_kit 画），底色和字也取主窗口的颜色，免得昼夜 / 风格对不上
        try:
            from ui_kit import C
            bg, fg, soft = C.PAPER.name(), C.INK.name(), C.SOFT.name()
        except Exception:  # noqa: BLE001
            bg, fg, soft = T.bg, T.fg, T.soft
        self.setStyleSheet(qss() + f"""
QWidget#aiplanPage {{ background:{bg}; color:{fg}; }}
QLabel {{ color:{fg}; }}
QLabel#examTitle {{ color:{fg}; font-size:20px; font-weight:700; padding-right:6px; }}
QFrame#examCard {{ background:{T.surface}; border:1px solid {T.line}; border-radius:10px; }}
QLabel#cardTitle {{ color:{fg}; font-size:14px; font-weight:700; }}
QLabel#note {{ color:{soft}; font-size:12px; }}
QCheckBox {{ color:{fg}; }}
QLabel#body {{ color:{soft}; font-size:12.5px; }}
QLabel#warn {{ color:{T.warn}; font-size:12px; }}
QListWidget::item {{ padding:4px 2px; }}
QListWidget::item:selected {{ background:{css(T.accent, .14)}; color:{T.fg}; }}
""")


_DIALOGS = []


def open_dialog(parent=None, request="", engine=None, on_accept=None) -> QDialog:
    """弹出 AI 排计划的窗口（非模态）。"""
    dlg = QDialog(parent)
    dlg.setWindowTitle("见微 · AI 排计划")
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(0, 0, 0, 0)
    panel = AIPlanPanel(request, engine)
    lay.addWidget(panel)
    if on_accept:
        panel.accepted.connect(on_accept)
    dlg.panel = panel
    dlg.resize(1080, 680)
    dlg.setMinimumSize(900, 560)
    _DIALOGS.append(dlg)
    dlg.destroyed.connect(lambda *_: _DIALOGS.remove(dlg) if dlg in _DIALOGS else None)
    dlg.show()
    return dlg
