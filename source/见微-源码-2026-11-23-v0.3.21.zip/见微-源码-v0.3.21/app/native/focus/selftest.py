"""番茄钟 + 自由安排 + 专注监督的离屏自测。计时全用假时钟，监督用假探针，不读真的前台窗口。"""
from ..kit import test_runtime
test_runtime.configure()
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path


class Clock:
    def __init__(self, t=None):
        self.t = t or datetime.combine(date.today(), datetime.min.time()).timestamp() + 9 * 3600   # 今天 9:00

    def __call__(self):
        return self.t

    def go(self, sec):
        self.t += sec
        return self.t

    def dt(self):
        return datetime.fromtimestamp(self.t)


class FakeProbe:
    def __init__(self):
        self.st = dict(exe="Jianwei.exe", title="见微", idle=0.0, own=True)

    def read(self):
        return dict(self.st)

    def set(self, exe="", idle=0.0, own=False):
        self.st = dict(exe=exe, title="", idle=idle, own=own)


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    fails, log = [], []

    def check(name, ok, detail=""):
        log.append(("OK  " if ok else "FAIL") + " " + name + ("" if ok else f"  {detail}"))
        if not ok:
            fails.append(name)

    def spin(sec=0.05):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from . import core, plan
    from .watch import Supervisor

    # ------------------------------------------------ 设置
    s = core.settings()
    check("默认 25 / 5 / 15、四个一轮", (s["focus"], s["short"], s["long"], s["rounds"]) == (25, 5, 15, 4))
    core.save_settings(focus=1, short=1, long=2, rounds=2)
    check("时长和轮数可以自己设", core.settings()["focus"] == 1 and core.settings()["rounds"] == 2)
    for bad in (dict(focus=0), dict(rounds=99), dict(nope=1)):
        try:
            core.save_settings(**bad)
            check(f"不合法的设置被拒 {bad}", False)
        except ValueError:
            check(f"不合法的设置被拒 {list(bad)[0]}", True)
    core.save_settings(whitelist=["WPS.exe", " notepad.exe ", ""])
    check("白名单统一小写、去空", core.settings()["whitelist"] == ["notepad.exe", "wps.exe"])
    core.save_settings(**{k: core.DEFAULTS[k] for k in ("focus", "short", "long", "rounds", "whitelist")})

    # ------------------------------------------------ 番茄状态机
    c = Clock()
    cfg = dict(core.settings(), focus=25, short=5, long=15, rounds=2, auto_break=True, auto_focus=False)
    p = core.Pomodoro(c, cfg)
    p.start("数学", "导数大题")
    check("开始专注", p.phase == "focus" and p.running and p.remaining() == 1500)
    c.go(600)
    p.pause()
    c.go(300)
    check("暂停时不走", abs(p.remaining() - 900) < 1e-6)
    p.resume()
    c.go(899)
    check("还差 1 秒没结束", p.tick() == [] and p.phase == "focus")
    c.go(2)
    ev = p.tick()
    recs = core.sessions()
    check("到点：记一个完成的番茄，自动进短休", ev == ["focus_done"] and p.phase == "short" and recs[-1]["status"] == "done"
          and recs[-1]["subject"] == "数学" and abs(recs[-1]["focus"] - 1500) < 1 and abs(recs[-1]["paused"] - 300) < 1, (ev, p.phase, recs[-1:]))
    c.go(301)
    check("短休结束回到准备（不自动开始）", p.tick() == ["break_done"] and p.phase == "idle" and p.next_phase == "focus")
    p.start()
    c.go(1500)
    p.tick()
    check("第二个番茄后是长休（两个一轮）", p.phase == "long" and p.count == 2, (p.phase, p.count))
    c.go(900)
    p.tick()
    check("长休后一轮重新数", p.phase == "idle" and p.count == 0)
    p.start()
    c.go(100)
    rec = p.skip()
    check("专注中跳过＝提前结束，不算完成", rec["status"] == "skipped" and p.phase == "short" and p.count == 0, (rec["status"], p.phase))
    p.skip()
    check("休息中跳过回到准备", p.phase == "idle")
    p.cfg["strict"] = True
    p.start()
    c.go(60)
    try:
        p.abandon("")
        check("严格模式：不写理由不能放弃", False)
    except ValueError:
        check("严格模式：不写理由不能放弃", p.phase == "focus")
    rec = p.abandon("被叫去吃饭")
    check("严格模式：写了理由可以放弃，理由记下", rec["status"] == "abandoned" and rec["reason"] == "被叫去吃饭" and p.phase == "idle")
    p.cfg["strict"] = False
    p.start()
    c.go(30)
    check("普通模式放弃不用理由", p.abandon()["status"] == "abandoned")
    p.cfg["auto_focus"] = True
    p.start()
    c.go(1500 + 300 + 10)
    ev = p.tick()
    check("自动接下一个番茄：一次跳过多个阶段", ev == ["focus_done", "break_done"] and p.phase == "focus" and abs(p.remaining() - 1490) < 1, (ev, p.phase, p.remaining()))
    p.abandon()
    p.cfg["auto_focus"] = False

    # ------------------------------------------------ 监督
    sup = Supervisor()
    cfg2 = dict(core.settings(), grace_seconds=30, idle_minutes=5, watch=True)
    p = core.Pomodoro(c, cfg2)
    p.start("物理")
    t0 = c()
    msg = sup.check(p, c.go(10), dict(exe="game.exe", idle=0, own=False), cfg2)
    check("切走没超过宽限不记", msg == "" and not p.session["interruptions"])
    msg = sup.check(p, c.go(30), dict(exe="game.exe", idle=0, own=False), cfg2)
    check("切走超过宽限：记一次离开、温和提醒", len(p.session["interruptions"]) == 1 and p.session["interruptions"][0]["kind"] == "away"
          and "game.exe" in msg and abs(p.session["interruptions"][0]["t"] - (t0 + 10)) < 1e-6, msg)
    sup.check(p, c.go(55), dict(exe="game.exe", idle=0, own=False), cfg2)
    check("一直没回来不重复记", len(p.session["interruptions"]) == 1)
    msg = sup.check(p, c.go(5), dict(exe="WPS.EXE", idle=0, own=False), cfg2)
    it = p.session["interruptions"][0]
    check("回到白名单程序：补上离开时长", "open" not in it and abs(it["seconds"] - 90) < 1 and "回来" in msg, it)
    check("见微自己的窗口总是允许", Supervisor.allowed(dict(exe="python.exe", own=True), []))
    msg = sup.check(p, c.go(10), dict(exe="Jianwei.exe", idle=301, own=True), cfg2)
    check("超过 5 分钟没输入：记一次无操作", p.session["interruptions"][-1]["kind"] == "idle" and "键盘" in msg)
    sup.check(p, c.go(5), dict(exe="Jianwei.exe", idle=0, own=True), cfg2)
    check("有输入后无操作结束并记时长", "open" not in p.session["interruptions"][-1] and p.session["interruptions"][-1]["seconds"] > 300)
    p.pause()
    msg = sup.check(p, c.go(100), dict(exe="game.exe", idle=0, own=False), cfg2)
    check("暂停时不监督", msg == "" and len(p.session["interruptions"]) == 2)
    p.resume()
    cfg2["watch"] = False
    sup.check(p, c.go(100), dict(exe="game.exe", idle=999, own=False), cfg2)
    check("关掉监督就不记", len(p.session["interruptions"]) == 2)
    cfg2["watch"] = True
    c.go(1500)
    p.tick()
    check("中断计入这个番茄的记录", len(core.sessions()[-1]["interruptions"]) == 2)

    # ------------------------------------------------ 计划
    today = c.dt().date()
    d = today.isoformat()
    b1 = plan.add(d, 8 * 60 + 7, 50, "数学", "导数")
    check("计划块按 15 分钟对齐", b1["start"] == 8 * 60 + 15 - 15 or b1["start"] in (8 * 60, 8 * 60 + 15) and b1["minutes"] == 45, b1)
    b2 = plan.add(d, 5 * 60, 30, "英语", "单词")
    check("早于 6:00 的块放到 6:00", b2["start"] == plan.DAY_START)
    free = plan.next_free(d, 60, after=8 * 60)
    check("找空档避开已有的块", free >= b1["start"] + b1["minutes"], (free, b1))
    plan.move(b2["id"], (today + timedelta(days=1)).isoformat(), 20 * 60 + 5)
    m = plan.get(b2["id"])
    check("拖到另一天、另一时间", m["day"] == (today + timedelta(days=1)).isoformat() and m["start"] == 20 * 60)
    plan.resize(b2["id"], 500)
    check("拖长不超过 23:00", plan.get(b2["id"])["start"] + plan.get(b2["id"])["minutes"] <= plan.DAY_END)
    plan.remove(b2["id"])
    check("删除", plan.get(b2["id"]) is None)
    plan.add_focus(b1["id"], 25 * 60)
    check("挂在块上的番茄累计时长，不够八成不算完成", not plan.get(b1["id"])["done"])
    plan.add_focus(b1["id"], 15 * 60)
    check("够八成算完成", plan.get(b1["id"])["done"])
    b3 = plan.add(d, 9 * 60 + 30, 30, "化学", "方程式")
    due = plan.due_reminders(datetime.combine(today, datetime.min.time()) + timedelta(hours=9, minutes=31))
    check("到点提醒一次", [x["id"] for x in due] == [b3["id"]])
    check("提醒过的不再提醒", plan.due_reminders(datetime.combine(today, datetime.min.time()) + timedelta(hours=9, minutes=33)) == [])
    # 候选：复习到期、预习单、薄弱点
    from .. import learning, preview
    learning.add_card(dict(n="牛顿第二定律", d="F=ma", f=[], p=[]), "物理")
    sheet = preview.make("数学", preview.chapters("数学")[0])
    preview.save(sheet)
    from ..exam import paper, records, grade
    ex = paper.new_exam(paper.from_bank("数学", 3, ["单选"], seed=2), "测", "数学")
    ex["answers"] = {}
    ex["report"] = grade.offline(ex)
    ex["submitted"] = time.time()
    records.upsert(ex)
    cs = plan.candidates()
    srcs = {x["source"] for x in cs}
    check("能拉进计划的：复习、预习、薄弱点", {"review", "preview", "weak"} <= srcs, srcs)

    # ------------------------------------------------ 统计
    sm = core.summary(7, today=today)
    t = sm["total"]
    check("统计：完成 / 开始 / 完成率", t["done"] >= 4 and t["started"] > t["done"] and 0 < t["rate"] < 1, t)
    check("统计：中断次数和种类", t["interruptions"] == 2 and sm["kinds"] == dict(away=1, idle=1), (t["interruptions"], sm["kinds"]))
    check("统计：计划完成率", t["plan_total"] == 2 and t["plan_done"] == 1 and t["plan_rate"] == 0.5, t)
    check("统计：各科时长、放弃理由", sm["subjects"].get("数学", 0) > 0 and "被叫去吃饭" in sm["reasons"])

    # ------------------------------------------------ 引擎 + 页面 + 悬浮窗
    from .engine import engine
    fp = FakeProbe()
    c2 = Clock(c() + 3600)
    eng = engine(clock=c2, probe=fp, now_dt=c2.dt)
    core.save_settings(focus=25, short=5, rounds=4, strict=True, auto_break=True)
    eng.reload_settings()
    notes = []
    eng.notice.connect(lambda k, tx: notes.append((k, tx)))
    from .floater import floater
    fl = floater()
    check("没番茄时不显示小窗", not fl.isVisible())
    from .page import FocusPage
    page = FocusPage()
    page.resize(1200, 800)
    page.show()
    spin()
    page.p_subj.setCurrentIndex(page.p_subj.findData("生物"))
    page.p_task.setText("减数分裂")
    page.main_key()
    eng.step()
    spin()
    check("页面开始专注，引擎每秒一跳", eng.pomo.phase == "focus" and eng.timer.interval() == 1000 and eng.state()["subject"] == "生物")
    check("番茄进行时桌面小窗出现", fl.isVisible())
    page.grab().save(str(out / "pomo.png"))
    fl.grab().save(str(out / "float.png"))
    fp.set("game.exe")
    eng.step()
    c2.go(40)
    eng.step()
    check("监督提醒送到小窗", any(k == "nudge" for k, _ in notes) and fl.msg and fl.height() > 80)
    fp.set("Jianwei.exe", own=True)
    c2.go(5)
    eng.step()
    page.main_key()
    check("页面暂停", not eng.pomo.running and page.k_main.text() == "继续")
    page.main_key()
    page.ask_abandon()
    page.do_abandon()
    check("严格模式在页面上：不写理由放弃被拦下", eng.pomo.phase == "focus" and "理由" in page.status.text())
    page.ab_reason.setText("头疼，先休息")
    page.do_abandon()
    check("写了理由放弃成功", eng.pomo.phase == "idle" and core.sessions()[-1]["reason"] == "头疼，先休息")
    core.save_settings(strict=False)
    eng.reload_settings()
    # 计划块开番茄 → 完成后计入块
    blk = plan.add(c2.dt().date().isoformat(), plan.next_free(c2.dt().date().isoformat(), 30, after=11 * 60), 30, "地理", "气候类型")
    page.start_block(blk["id"])
    check("从计划块开始番茄（带科目、任务）", eng.state()["block"] == blk["id"] and eng.state()["task"] == "气候类型")
    c2.go(25 * 60 + 1)
    eng.step()
    check("番茄完成：提醒、记到块上", any(k == "done" for k, _ in notes) and plan.get(blk["id"])["done"] and eng.pomo.phase == "short")
    eng.skip()
    eng.step()
    spin()
    check("回到准备后小窗收起（提醒还在时留着）", (not fl.isVisible()) or bool(fl.msg))
    fl._clear_msg()
    check("提醒看完小窗收起", not fl.isVisible())
    # 计划到点提醒（引擎）
    soon = plan.add(c2.dt().date().isoformat(), plan.snap(c2.dt().hour * 60 + c2.dt().minute + 15), 30, "语文", "古诗默写")
    c2.t = datetime.combine(c2.dt().date(), datetime.min.time()).timestamp() + soon["start"] * 60 + 30
    got = []
    eng.reminder.connect(got.append)
    eng.step()
    check("计划到点：引擎发提醒（0.3.19 起走通知卡片，小窗不重复）", any(k == "remind" and "古诗默写" in tx for k, tx in notes)
          and any(it.get("block") == soon["id"] for it in got) and not fl.msg, (notes[-2:], got))
    fl._clear_msg()
    # 计划表：拖动和改时长（模拟鼠标）
    from PySide6.QtCore import QEvent, QPointF, Qt
    from PySide6.QtGui import QMouseEvent
    page.show_tab("plan")
    page.pl_mode.set_value("day")
    page._set_plan_mode("day")
    page.day = c2.dt().date()
    page.refresh_plan()
    spin()
    g = page.grid
    r = g.rect_of(plan.get(soon["id"]))

    def mouse(kind, pos, btn=Qt.MouseButton.LeftButton):
        ev = QMouseEvent(kind, QPointF(pos), QPointF(g.mapToGlobal(pos.toPoint())), btn,
                         btn if kind != QEvent.Type.MouseButtonRelease else Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier)
        {QEvent.Type.MouseButtonPress: g.mousePressEvent, QEvent.Type.MouseMove: g.mouseMoveEvent,
         QEvent.Type.MouseButtonRelease: g.mouseReleaseEvent}[kind](ev)
    k = g._ppm()
    start = QPointF(r.center().x(), r.top() + 10)
    mouse(QEvent.Type.MouseButtonPress, start)
    check("点中计划块：编辑栏可用", g.sel == soon["id"] and page.ed_box.isEnabled() and page.ed_task.text() == "古诗默写")
    mouse(QEvent.Type.MouseMove, start + QPointF(0, 60 * k))
    mouse(QEvent.Type.MouseButtonRelease, start + QPointF(0, 60 * k))
    check("拖动块：往后挪一小时", plan.get(soon["id"])["start"] == soon["start"] + 60, plan.get(soon["id"])["start"])
    r = g.rect_of(plan.get(soon["id"]))
    edge = QPointF(r.center().x(), r.bottom() - 3)
    mouse(QEvent.Type.MouseButtonPress, edge)
    mouse(QEvent.Type.MouseMove, edge + QPointF(0, 30 * k))
    mouse(QEvent.Type.MouseButtonRelease, edge + QPointF(0, 30 * k))
    check("拖下边：时长加 30 分钟", plan.get(soon["id"])["minutes"] == 60, plan.get(soon["id"])["minutes"])
    page.ed_task.setText("古诗默写 + 文言实词")
    page.save_block()
    check("编辑栏改任务", plan.get(soon["id"])["task"] == "古诗默写 + 文言实词")
    n0 = len(plan.blocks())
    page.cand.setCurrentRow(0)
    page.add_candidate()
    check("从候选拉一项进计划", len(plan.blocks()) == n0 + 1 and plan.blocks()[-1]["source"] in ("review", "preview", "weak") or
          any(b["source"] != "self" for b in plan.blocks(page.day.isoformat())))
    page.new_block()
    check("新建一块", len(plan.blocks()) == n0 + 2)
    page.view_mode = "week"
    page.pl_mode.set_value("week")
    page.refresh_plan()
    spin()
    page.grab().save(str(out / "plan.png"))
    page.show_tab("stats")
    spin()
    check("统计页有数", page.s_tiles[0][0].text().endswith("分钟") and page.s_kinds.rows)
    page.grab().save(str(out / "stats.png"))
    page.show_tab("set")
    page.st["focus"].setValue(40)
    page.st_white.setPlainText("wps.exe\nchrome.exe")
    page.save_settings()
    check("设置页保存：时长、白名单", core.settings()["focus"] == 40 and "chrome.exe" in core.settings()["whitelist"] and eng.cfg["focus"] == 40)
    core.save_settings(focus=25)
    eng.reload_settings()
    from ..design import tokens
    tokens.set_theme("night")
    page.apply_theme()
    page.show_tab("pomo")
    page.grab().save(str(out / "pomo-night.png"))
    tokens.set_theme("day")
    page.apply_theme()
    page.close()

    # 考情里看得到专注
    from ..exam.page import ExamPage
    ep = ExamPage()
    ep.show_tab("stats")
    check("考情分析里有专注汇总", "专注" in ep.k_focus.text() and ep.k_focus_days.rows, ep.k_focus.text())
    ep.close()

    # ------------------------------------------------ 主窗口：导航、今日卡片、托盘、三种布局 × 三种风格
    try:
        import os
        import store
        from shell import NAV, Shell
        real = Path.home() / "AppData" / "Local" / "Jianwei"
        if not os.environ.get("JIANWEI_HOME") or os.path.realpath(store.HOME) == os.path.realpath(real):
            raise RuntimeError("JIANWEI_HOME 没有指向隔离目录，不建主窗口")
        check("主窗口导航有「专注」", ("focus", "专注") in NAV)
        cfg = store.load_config()
        cfg.update(autoFetch=False, autoEvening=False, prewarmWeb=False)
        store.save_config(cfg)
        sh = Shell(tray_enabled=False, jobs_enabled=False)
        sh.resize(1280, 820)
        sh.show()
        spin()
        sh.set_page_layout("pages")
        sh.goto("today", animate=False)
        spin()
        today_page = sh.stack.currentWidget()
        from PySide6.QtWidgets import QLabel
        check("今日页有专注卡片", any(lb.text() == "专注" for lb in today_page.findChildren(QLabel)))
        sh.focus_toggle()
        check("托盘的「开始 / 暂停番茄」", eng.pomo.phase == "focus")
        sh.focus_toggle()
        eng.abandon("测试")
        for skin in ("ink", "celadon", "doodle"):
            sh._apply_look("day", skin)
            for lay in ("pages", "desktop", "workspace"):
                sh.set_page_layout(lay)
                spin()
                if lay == "desktop":
                    check(f"{skin}·模块桌面有专注模块", "focus" in sh.home.modules)
                elif lay == "workspace":
                    sh.home.add("focus")
                    spin()
                    check(f"{skin}·工作台能加专注模块", "focus" in sh.home.panels)
                sh.goto("focus", animate=False)
                spin()
                cur = sh.stack.currentWidget()
                check(f"{skin}·{lay} 打开专注页", getattr(cur, "focus", None) is not None and cur.focus.isVisible())
                if skin in ("ink", "doodle") and lay != "workspace":
                    sh.grab().save(str(out / f"shell-{skin}-{lay}.png"))
        for mode in ("side", "top", "compact"):
            sh.set_page_layout("pages")
            sh.set_layout(mode)
            spin()
            sh.goto("focus", animate=False)
            spin()
            check(f"导航位置 {mode} 打开专注页", getattr(sh.stack.currentWidget(), "focus", None) is not None)
        sh.set_layout("side")
        sh._apply_look("day", "ink")
        sh._tray = None
        sh._build_tray()
        texts = [a.text() for a in sh._tray.contextMenu().actions()]
        check("托盘菜单有专注入口", "专注" in texts and "开始 / 暂停番茄" in texts, texts)
        sh._tray.hide()
        sh.close()
        sh.deleteLater()
    except Exception:  # noqa: BLE001
        import traceback
        check("主窗口入口", False, traceback.format_exc()[-800:])
    fl.hide()
    eng.timer.stop()
    from . import engine as _engine_mod, floater as _floater_mod
    _engine_mod._ENGINE = None          # 后面的测试组拿到的是真时钟的新引擎
    _floater_mod._FLOAT = None

    (out / "focus-log.txt").write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))
    print("FOCUS_FAIL" if fails else "FOCUS_OK", len(log), "项")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
