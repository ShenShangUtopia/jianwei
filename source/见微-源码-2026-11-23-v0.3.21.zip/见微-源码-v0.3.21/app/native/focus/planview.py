"""计划的三种视图：PlanGrid（一天 / 一周的时间轴）、MonthGrid（月历）、PairBars（计划 vs 实际）。

PlanGrid：块按科目着色；右侧细条是这段时间实际的番茄（focus.json 的 sessions）；考试块红色；
顺延过的块标「顺延 n」；拖动时原位置留虚线框、新位置显示起止时间；「现在」画一条带时间的线。
数据在 reload() 时读一次（块、番茄记录、每天完成度），重画不读盘。
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QPainter, QPen
from PySide6.QtWidgets import QWidget

from ..design.icons import draw_icon
from ..design.tokens import T, font, qc
from . import core, plan

WEEK = "一二三四五六日"
SUBJ_COLOR = dict(数学="math", 物理="phys", 化学="chem", 生物="bio", 语文="c2", 英语="c5", 历史="c4", 地理="c6", 政治="c3")


def subj_color(s):
    return qc(getattr(T, SUBJ_COLOR.get(s or "", "accent")))


def block_color(b):
    return qc(T.bad) if b.get("source") == "exam" else subj_color(b.get("subject"))


class PlanGrid(QWidget):
    """计划表。days：要画的日期列表（1 或 7 天）。"""
    picked = Signal(str)          # 选中块 id（空串＝没选）
    activated = Signal(str)       # 双击块
    changed = Signal()

    HEAD, LEFT = 40, 46

    def __init__(self, today=None):
        super().__init__()
        self.today_fn = today or date.today
        self.now_fn = datetime.now
        self.days = [self.today_fn()]
        self.sel = ""
        self.drag = None
        self._preview = None
        self._bs, self._recs, self._prog = [], [], {}
        self.setMinimumHeight(520)
        self.setMouseTracking(True)
        self.reload()

    def set_days(self, days):
        self.days = list(days)
        self.reload()

    def reload(self):
        isos = {d.isoformat() for d in self.days}
        self._bs = [b for b in plan.blocks() if b["day"] in isos]
        self._recs = [r for r in core.sessions() if r.get("day") in isos and r.get("start")]
        self._prog = {d.isoformat(): plan.day_progress(d, self._bs, self._recs) for d in self.days}
        data = plan._load()
        self._avail = {d.isoformat(): plan.avail_for(d, data) for d in self.days}
        self.update()

    def _ppm(self):
        return (self.height() - self.HEAD - 6) / (plan.DAY_END - plan.DAY_START)

    def _colw(self):
        return (self.width() - self.LEFT - 4) / max(1, len(self.days))

    def rect_of(self, b):
        try:
            i = [d.isoformat() for d in self.days].index(b["day"])
        except ValueError:
            return None
        k, cw = self._ppm(), self._colw()
        return QRectF(self.LEFT + i * cw + 3, self.HEAD + (b["start"] - plan.DAY_START) * k, cw - 12, max(14.0, b["minutes"] * k))

    def at(self, pos):
        """(块, 是否在下边缘) 或 (None, False)。"""
        for b in reversed(self._bs):
            r = self.rect_of(b)
            if r is not None and r.contains(pos):
                return b, pos.y() > r.bottom() - 7
        return None, False

    def slot(self, pos):
        """位置 → (日期, 当天分钟)。"""
        i = int((pos.x() - self.LEFT) // self._colw())
        i = max(0, min(len(self.days) - 1, i))
        m = plan.DAY_START + (pos.y() - self.HEAD) / self._ppm()
        return self.days[i], plan.snap(m)

    def mousePressEvent(self, e):  # noqa: N802
        b, edge = self.at(e.position())
        self.sel = b["id"] if b else ""
        self.picked.emit(self.sel)
        if b:
            _d, m = self.slot(e.position())
            self.drag = ("size" if edge else "move", b["id"], m - b["start"], dict(b))
            self.setCursor(Qt.CursorShape.SizeVerCursor if edge else Qt.CursorShape.ClosedHandCursor)
        self.update()

    def mouseMoveEvent(self, e):  # noqa: N802
        if not self.drag:
            b, edge = self.at(e.position())
            self.setCursor(Qt.CursorShape.SizeVerCursor if edge else Qt.CursorShape.OpenHandCursor if b else Qt.CursorShape.ArrowCursor)
            return
        kind, _bid, off, orig = self.drag
        d, m = self.slot(e.position())
        if kind == "move":
            st, mi = plan._clamp(m - off, orig["minutes"])
            self._preview = dict(orig, day=d.isoformat(), start=st, minutes=mi)
        else:
            st, mi = plan._clamp(orig["start"], max(plan.STEP, m - orig["start"]))
            self._preview = dict(orig, minutes=mi)
        self.update()

    def mouseReleaseEvent(self, _e):  # noqa: N802
        if self.drag and self._preview:
            pv = self._preview
            if (pv["day"], pv["start"], pv["minutes"]) != (self.drag[3]["day"], self.drag[3]["start"], self.drag[3]["minutes"]):
                plan.update(pv["id"], day=pv["day"], start=pv["start"], minutes=pv["minutes"])
                self.reload()
                self.changed.emit()
        self.drag, self._preview = None, None
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.update()

    def mouseDoubleClickEvent(self, e):  # noqa: N802
        b, _ = self.at(e.position())
        if b:
            self.activated.emit(b["id"])

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        k, cw = self._ppm(), self._colw()
        today = self.today_fn()
        wide = cw >= 120
        # 时间轴：整点实线，半点淡线
        for h in range(plan.DAY_START // 60, plan.DAY_END // 60 + 1):
            y = self.HEAD + (h * 60 - plan.DAY_START) * k
            p.setPen(QPen(qc(T.line), 1))
            p.drawLine(QPointF(self.LEFT, y), QPointF(self.width() - 2, y))
            if h * 60 + 30 < plan.DAY_END and k * 60 > 36:
                p.setPen(QPen(qc(T.line, 0.5), 1, Qt.PenStyle.DotLine))
                p.drawLine(QPointF(self.LEFT, y + 30 * k), QPointF(self.width() - 2, y + 30 * k))
            p.setPen(qc(T.faint))
            p.setFont(font(11, kind="mono"))
            p.drawText(QRectF(0, y - 8, self.LEFT - 8, 16), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), f"{h}:00")
        # 可用时段：淡底
        for i, d in enumerate(self.days):
            x = self.LEFT + i * cw
            for a, b in self._avail.get(d.isoformat(), []):
                p.fillRect(QRectF(x + 1, self.HEAD + (a - plan.DAY_START) * k, cw - 2, (b - a) * k), qc(T.ok, 0.035))
        # 列头：周几 日期 + 这一天的完成度
        for i, d in enumerate(self.days):
            x = self.LEFT + i * cw
            is_today = d == today
            if is_today:
                p.fillRect(QRectF(x, self.HEAD, cw, self.height() - self.HEAD), qc(T.accent, 0.05))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.accent, 0.14))
                p.drawRoundedRect(QRectF(x + 4, 3, cw - 8, self.HEAD - 8), 6, 6)
            p.setPen(qc(T.accent if is_today else T.soft))
            p.setFont(font(12, 700 if is_today else 500))
            head = f"周{WEEK[d.weekday()]} {d.month}/{d.day}" + (" 今天" if is_today and wide else "")
            p.drawText(QRectF(x, 3, cw, 18), int(Qt.AlignmentFlag.AlignCenter), head)
            pg = self._prog.get(d.isoformat())
            if pg and pg["n"]:
                p.setPen(qc(T.muted))
                p.setFont(font(10.5))
                txt = f"{pg['done']}/{pg['n']} 块" + (f" · 实际 {int(pg['actual'])}′" if wide else "")
                p.drawText(QRectF(x, 20, cw, 14), int(Qt.AlignmentFlag.AlignCenter), txt)
                bw = cw - 24
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.fg, 0.08))
                p.drawRoundedRect(QRectF(x + 12, self.HEAD - 4, bw, 3), 1.5, 1.5)
                p.setBrush(qc(T.ok))
                p.drawRoundedRect(QRectF(x + 12, self.HEAD - 4, max(2.0, bw * (pg["rate"] or 0)), 3), 1.5, 1.5)
            p.setPen(QPen(qc(T.line), 1))
            p.drawLine(QPointF(x, self.HEAD), QPointF(x, self.height()))
        # 实际的番茄：每列右边一条细条
        for r in self._recs:
            try:
                i = [d.isoformat() for d in self.days].index(r["day"])
            except ValueError:
                continue
            st = datetime.fromtimestamp(r["start"])
            m0 = st.hour * 60 + st.minute + st.second / 60
            dur = max(float(r.get("focus") or 0) / 60.0, 2.0)
            m0, m1 = max(plan.DAY_START, m0), min(plan.DAY_END, m0 + dur)
            if m1 <= m0:
                continue
            col = subj_color(r.get("subject"))
            col.setAlphaF(1.0 if r.get("status") == "done" else 0.45)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col)
            x = self.LEFT + (i + 1) * cw - 7
            p.drawRoundedRect(QRectF(x, self.HEAD + (m0 - plan.DAY_START) * k, 4, max(3.0, (m1 - m0) * k)), 2, 2)
        pv = self._preview
        for b in self._bs:
            if pv and b["id"] == pv["id"]:
                r0 = self.rect_of(b)
                if r0 is not None:               # 原位置：虚线框
                    p.setPen(QPen(qc(T.muted), 1, Qt.PenStyle.DashLine))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawRoundedRect(r0, 5, 5)
                b = pv
            self._paint_block(p, b, dragging=bool(pv and b["id"] == pv["id"]))
        # 现在
        now = self.now_fn()
        nm = now.hour * 60 + now.minute
        if today in self.days and plan.DAY_START <= nm <= plan.DAY_END:
            i = self.days.index(today)
            y = self.HEAD + (nm - plan.DAY_START) * k
            p.setPen(QPen(qc(T.bad), 2))
            p.drawLine(QPointF(self.LEFT + i * cw, y), QPointF(self.LEFT + (i + 1) * cw, y))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.bad))
            p.drawEllipse(QPointF(self.LEFT + i * cw + 1, y), 4, 4)
            p.setFont(font(10, 700, "mono"))
            tag = QRectF(2, y - 8, self.LEFT - 6, 16)
            p.drawRoundedRect(tag, 4, 4)
            p.setPen(qc(T.raised))
            p.drawText(tag, int(Qt.AlignmentFlag.AlignCenter), f"{nm // 60}:{nm % 60:02d}")
        p.end()

    def _paint_block(self, p, b, dragging=False):
        r = self.rect_of(b)
        if r is None:
            return
        col = block_color(b)
        sel = b["id"] == self.sel
        done = b.get("done")
        p.setPen(QPen(qc(T.fg) if sel or dragging else col, 2 if sel or dragging else 1))
        fill = qc(col.name(), 0.10 if done else 0.30 if dragging else 0.20)
        p.setBrush(fill)
        p.drawRoundedRect(r, 5, 5)
        p.fillRect(QRectF(r.left(), r.top() + 1, 3, r.height() - 2), col)
        p.save()
        p.setClipRect(r)                # 15 分钟的块很矮：字别溢出到下一块上
        tall = r.height() >= 20
        p.setPen(qc(T.muted if done else T.fg))
        p.setFont(font(11.5 if tall else 10, 700))
        if dragging:
            line1 = f"{plan.hhmm(b['start'])}–{plan.hhmm(b['start'] + b['minutes'])}"
        else:
            line1 = f"{plan.hhmm(b['start'])} {('考试 ' if b.get('source') == 'exam' else '')}{b.get('subject') or ''}"
        tags = []
        if done:
            tags.append("完成")
        if b.get("carried"):
            tags.append(f"顺延 {b['carried']}")
        if b.get("priority") == 2:
            tags.append("高")
        subs = b.get("subtasks") or []
        if subs:
            tags.append(f"{sum(1 for s in subs if s['done'])}/{len(subs)}")
        x0 = r.left() + 7
        if b.get("rep") and r.width() > 60:
            draw_icon(p, "repeat", QRectF(r.right() - 16, r.top() + 3, 12, 12), qc(T.muted), 1.2)
        room = int(r.width() - (26 if b.get("rep") and r.width() > 60 else 10))
        p.drawText(QRectF(x0, r.top() + 2, room, 16), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop),
                   p.fontMetrics().elidedText(line1 + ("  " + " · ".join(tags) if tags and r.width() > 140 else ""),
                                              Qt.TextElideMode.ElideRight, room))
        if r.height() > 30:
            p.setFont(font(11))
            p.setPen(qc(T.soft))
            p.drawText(r.adjusted(7, 18, -4, -16 if r.height() > 52 else -2),
                       int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap), b.get("task") or "")
        if r.height() > 52:
            act = int(float(b.get("focused") or 0) / 60)
            p.setFont(font(10))
            p.setPen(qc(T.muted))
            foot = f"计划 {b['minutes']}′ · 实际 {act}′"
            if tags and r.width() <= 140:
                foot = " · ".join(tags)
            p.drawText(QRectF(x0, r.bottom() - 15, r.width() - 10, 13), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                       p.fontMetrics().elidedText(foot, Qt.TextElideMode.ElideRight, int(r.width() - 10)))
        p.restore()


class MonthGrid(QWidget):
    """月历：每格写计划分钟、完成度、实际专注；有考试的格子标红点。点一格＝看那一天。"""
    picked = Signal(object)        # date

    HEAD = 26

    def __init__(self, today=None):
        super().__init__()
        self.today_fn = today or date.today
        self.month = self.today_fn().replace(day=1)
        self.cells = []
        self.setMinimumHeight(420)
        self.setMouseTracking(True)
        self.hover = None

    def set_month(self, d: date):
        self.month = d.replace(day=1)
        start = self.month - timedelta(days=self.month.weekday())
        days = [start + timedelta(days=i) for i in range(42)]
        bs = plan.blocks()
        recs = core.sessions()
        self.cells = [(d, plan.day_progress(d, bs, recs)) for d in days]
        self.update()

    def _cell(self, i):
        cw, ch = self.width() / 7, (self.height() - self.HEAD) / 6
        return QRectF((i % 7) * cw, self.HEAD + (i // 7) * ch, cw, ch)

    def mouseMoveEvent(self, e):  # noqa: N802
        i = self._index(e.position())
        if i != self.hover:
            self.hover = i
            self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = None
        self.update()

    def _index(self, pos):
        for i in range(len(self.cells)):
            if self._cell(i).contains(pos):
                return i
        return None

    def mouseReleaseEvent(self, e):  # noqa: N802
        i = self._index(e.position())
        if i is not None:
            self.picked.emit(self.cells[i][0])

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        cw = self.width() / 7
        p.setFont(font(12, 600))
        for i in range(7):
            p.setPen(qc(T.muted))
            p.drawText(QRectF(i * cw, 0, cw, self.HEAD), int(Qt.AlignmentFlag.AlignCenter), "周" + WEEK[i])
        today = self.today_fn()
        for i, (d, pg) in enumerate(self.cells):
            r = self._cell(i).adjusted(2, 2, -2, -2)
            inside = d.month == self.month.month
            is_today = d == today
            p.setPen(QPen(qc(T.accent) if is_today else qc(T.line), 1.5 if is_today else 1))
            p.setBrush(qc(T.accent, 0.06) if self.hover == i else qc(T.raised) if inside else qc(T.fg, 0.02))
            p.drawRoundedRect(r, 6, 6)
            p.setPen(qc(T.accent if is_today else T.fg if inside else T.faint))
            p.setFont(font(13, 700 if is_today else 500))
            p.drawText(QRectF(r.left() + 8, r.top() + 4, 40, 18), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), str(d.day))
            if pg["exams"]:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.bad))
                p.drawEllipse(QPointF(r.right() - 10, r.top() + 13), 4, 4)
            if not inside or r.height() < 40:
                continue
            p.setFont(font(10.5))
            y = r.top() + 26
            if pg["n"]:
                p.setPen(qc(T.soft))
                p.drawText(QRectF(r.left() + 8, y, r.width() - 12, 14), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                           p.fontMetrics().elidedText(f"{pg['done']}/{pg['n']} 块 · {pg['planned']}′", Qt.TextElideMode.ElideRight, int(r.width() - 12)))
                y += 15
            if pg["actual"]:
                p.setPen(qc(T.muted))
                p.drawText(QRectF(r.left() + 8, y, r.width() - 12, 14), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                           f"专注 {int(pg['actual'])}′")
            if pg["n"]:
                bw = r.width() - 16
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.fg, 0.08))
                p.drawRoundedRect(QRectF(r.left() + 8, r.bottom() - 9, bw, 4), 2, 2)
                rate = pg["rate"] or 0
                p.setBrush(qc(T.ok if rate >= 0.8 else T.warn if rate >= 0.4 else T.bad))
                p.drawRoundedRect(QRectF(r.left() + 8, r.bottom() - 9, max(3.0, bw * rate), 4), 2, 2)
        p.end()


class PairBars(QWidget):
    """计划 vs 实际：每行 科目 | 计划（空心条）+ 实际（实心条）| 数字。rows=[(名字, 计划, 实际)]（分钟）。"""

    def __init__(self):
        super().__init__()
        self.rows = []
        self.setFixedHeight(32)

    def set_rows(self, rows):
        self.rows = rows
        self.setFixedHeight(max(32, 30 * len(rows) + 26))
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if not self.rows:
            p.setPen(qc(T.faint))
            p.setFont(font(12))
            p.drawText(self.rect(), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "这段时间还没有计划和番茄记录。")
            p.end()
            return
        lw, rw = 72, 118
        bw = max(40, self.width() - lw - rw - 12)
        mx = max([max(a, b) for _n, a, b in self.rows] + [1])
        for i, (name, planned, actual) in enumerate(self.rows):
            y = 4 + i * 30
            col = subj_color(name)
            p.setFont(font(12))
            p.setPen(qc(T.soft))
            p.drawText(QRectF(0, y, lw - 8, 22), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), name)
            p.setPen(QPen(col, 1.2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(QRectF(lw, y + 3, max(4.0, bw * planned / mx), 7), 3, 3)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col)
            p.drawRoundedRect(QRectF(lw, y + 12, max(3.0, bw * actual / mx), 7), 3, 3)
            diff = actual - planned
            p.setPen(qc(T.muted if abs(diff) < 20 else T.ok if diff > 0 else T.warn))
            p.setFont(font(11, kind="mono"))
            p.drawText(QRectF(lw + bw + 8, y, rw, 22), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                       f"{int(planned)}→{int(actual)} ({'+' if diff >= 0 else ''}{int(diff)})")
        y = 4 + len(self.rows) * 30
        p.setFont(font(10.5))
        p.setPen(QPen(qc(T.muted), 1.2))
        p.drawRoundedRect(QRectF(lw, y + 5, 16, 6), 3, 3)
        p.drawText(QRectF(lw + 20, y, 60, 16), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "计划")
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qc(T.muted))
        p.drawRoundedRect(QRectF(lw + 64, y + 5, 16, 6), 3, 3)
        p.setPen(qc(T.muted))
        p.drawText(QRectF(lw + 84, y, 120, 16), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "实际（分钟）")
        p.end()
