"""番茄钟状态机 + 专注记录 + 统计。纯 Python，时间都从 clock() 取（自测换成假时钟）。

阶段：idle → focus → short / long → idle（或自动接下一个 focus）……
一个 focus 结束时记一条 session：done 完成 / skipped 提前结束 / abandoned 放弃（严格模式要写理由）。
专注中被监督判定离开或长时间无操作，记进这个 session 的 interruptions。
数据：focus.json = {v:1, settings:{…}, sessions:[…]}，最多留 5000 条。
"""
from __future__ import annotations

import copy
import time
import uuid
from datetime import date, datetime, timedelta

from ..kit.home import load_json, save_json

FILE = "focus.json"
DEFAULTS = dict(focus=25, short=5, long=15, rounds=4, strict=False, auto_break=True, auto_focus=False,
                watch=True, idle_minutes=5, grace_seconds=30, floater=True, remind=True,
                whitelist=["jianwei.exe", "python.exe", "pythonw.exe", "wps.exe", "wpp.exe", "et.exe", "winword.exe",
                           "powerpnt.exe", "excel.exe", "acrord32.exe", "acrobat.exe", "sumatrapdf.exe", "notepad.exe",
                           "mspaint.exe", "calc.exe", "calculatorapp.exe", "geogebra.exe"],
                # 0.3.19 每日提醒：早晚按星期设（0＝周一），块开始前 N 分钟，到期复习时间，免打扰，提示音
                remind_daily={str(i): dict(on=True, am="07:00" if i < 5 else "08:30", pm="21:30") for i in range(7)},
                remind_lead=5, remind_due_on=True, remind_due="17:30", dnd_on=True, dnd_start="22:30", dnd_end="06:30",
                sound=False, tray_bubble=True)
PHASE_NAME = dict(idle="准备", focus="专注", short="短休", long="长休")


def _hhmm_ok(s) -> bool:
    try:
        h, m = str(s).split(":")
        return 0 <= int(h) < 24 and 0 <= int(m) < 60
    except ValueError:
        return False


def load() -> dict:
    data = load_json(FILE, None)
    if not isinstance(data, dict) or data.get("v") != 1:
        data = dict(v=1, settings={}, sessions=[])
    data.setdefault("settings", {})
    data.setdefault("sessions", [])
    return data


def settings() -> dict:
    s = copy.deepcopy(DEFAULTS)
    s.update({k: copy.deepcopy(v) for k, v in (load().get("settings") or {}).items() if k in DEFAULTS})
    daily = s["remind_daily"] if isinstance(s["remind_daily"], dict) else {}
    s["remind_daily"] = {k: dict(DEFAULTS["remind_daily"][k], **(daily.get(k) or {})) for k in DEFAULTS["remind_daily"]}
    return s


def save_settings(**kw):
    data = load()
    cur = settings()
    for k, v in kw.items():
        if k not in DEFAULTS:
            raise ValueError("不认识的设置：" + k)
        if k in ("focus", "short", "long") and not 1 <= int(v) <= 180:
            raise ValueError("时长要在 1 到 180 分钟之间")
        if k == "rounds" and not 1 <= int(v) <= 12:
            raise ValueError("一轮 1 到 12 个番茄")
        if k == "whitelist":
            v = sorted({str(x).strip().lower() for x in v if str(x).strip()})
        if k in ("remind_due", "dnd_start", "dnd_end") and not _hhmm_ok(v):
            raise ValueError("时间要写成 时:分，比如 07:30")
        if k == "remind_lead" and not 0 <= int(v) <= 120:
            raise ValueError("提前提醒要在 0 到 120 分钟之间")
        if k == "remind_daily":
            if not isinstance(v, dict):
                raise ValueError("每日提醒格式不对")
            nv = {}
            for i in range(7):
                row = dict(DEFAULTS["remind_daily"][str(i)], **(v.get(str(i)) or {}))
                for t in ("am", "pm"):
                    if row.get(t) and not _hhmm_ok(row[t]):
                        raise ValueError(f"周{'一二三四五六日'[i]}的时间要写成 时:分")
                nv[str(i)] = dict(on=bool(row.get("on")), am=row.get("am") or "", pm=row.get("pm") or "")
            v = nv
        cur[k] = v
    data["settings"] = cur
    save_json(FILE, data)
    return cur


def add_session(rec):
    data = load()
    data["sessions"].append(rec)
    data["sessions"] = data["sessions"][-5000:]
    save_json(FILE, data)


def sessions():
    return load()["sessions"]


class Pomodoro:
    """一个番茄钟。所有方法都接受可选的 now（秒），不给就用 clock()。"""

    def __init__(self, clock=time.time, cfg=None):
        self.clock = clock
        self.cfg = cfg or settings()
        self.phase = "idle"
        self.running = False
        self.started_at = 0.0       # 本阶段（最近一次）开始 / 继续的时间
        self.spent = 0.0            # 本阶段暂停前已经走过的秒数
        self.count = 0              # 本轮完成了几个专注
        self.subject, self.task, self.block = "", "", ""
        self.session = None         # 正在进行的专注记录
        self.next_phase = "focus"   # idle 时按「开始」进入的阶段

    # ---- 查询
    def length(self, phase=None) -> float:
        p = phase or self.phase
        return 0.0 if p == "idle" else float(self.cfg[p]) * 60.0

    def elapsed(self, now=None) -> float:
        now = self.clock() if now is None else now
        return self.spent + (now - self.started_at if self.running else 0.0)

    def remaining(self, now=None) -> float:
        return max(0.0, self.length() - self.elapsed(now))

    def state(self, now=None) -> dict:
        return dict(phase=self.phase, name=PHASE_NAME[self.phase], running=self.running, remaining=self.remaining(now),
                    length=self.length(), count=self.count, rounds=int(self.cfg["rounds"]), subject=self.subject,
                    task=self.task, block=self.block, next=self.next_phase,
                    interruptions=len(self.session["interruptions"]) if self.session else 0)

    # ---- 操作
    def start(self, subject="", task="", block="", now=None):
        """开始专注（idle 时），或者开始 idle 时排好的休息。"""
        now = self.clock() if now is None else now
        if self.phase != "idle":
            return self.resume(now)
        if subject or task or block:
            self.subject, self.task, self.block = subject, task, block
        self._enter(self.next_phase, now)

    def _enter(self, phase, now):
        self.phase, self.running, self.started_at, self.spent = phase, True, now, 0.0
        if phase == "focus":
            self.session = dict(id=uuid.uuid4().hex[:12], day=datetime.fromtimestamp(now).date().isoformat(), start=now,
                                end=None, planned=self.length("focus"), focus=0.0, paused=0.0, subject=self.subject,
                                task=self.task, block=self.block, status="", reason="", interruptions=[])

    def pause(self, now=None):
        now = self.clock() if now is None else now
        if self.running:
            self.spent += now - self.started_at
            self.running = False
            self._paused_at = now

    def resume(self, now=None):
        now = self.clock() if now is None else now
        if not self.running and self.phase != "idle":
            if self.session is not None and getattr(self, "_paused_at", None) is not None:
                self.session["paused"] += now - self._paused_at
            self._paused_at = None
            self.started_at, self.running = now, True

    def _close_focus(self, status, now, reason=""):
        s = self.session
        if s is None:
            return None
        s.update(end=now, focus=round(min(self.elapsed(now), self.length("focus")), 1), status=status, reason=reason)
        for it in s["interruptions"]:
            if it.get("open"):
                it["seconds"] = round(now - it["t"], 1)
                it.pop("open", None)
        add_session(copy.deepcopy(s))
        self.session = None
        return s

    def _after_focus(self, now, counted):
        if counted:
            self.count += 1
        brk = "long" if self.count and self.count % int(self.cfg["rounds"]) == 0 else "short"
        if self.cfg.get("auto_break", True):
            self._enter(brk, now)
        else:
            self.phase, self.running, self.next_phase = "idle", False, brk

    def _after_break(self, now):
        if self.phase == "long":
            self.count = 0
        self.next_phase = "focus"
        if self.cfg.get("auto_focus"):
            self._enter("focus", now)
        else:
            self.phase, self.running, self.spent = "idle", False, 0.0

    def skip(self, now=None):
        """跳过：专注中＝提前结束（记 skipped，不算完成的番茄，进休息）；休息中＝直接回到专注前。"""
        now = self.clock() if now is None else now
        if self.phase == "focus":
            rec = self._close_focus("skipped", now)
            self._after_focus(now, counted=False)
            return rec
        if self.phase in ("short", "long"):
            self._after_break(now)
        elif self.phase == "idle" and self.next_phase != "focus":
            self.next_phase = "focus"
        return None

    def abandon(self, reason="", now=None):
        """放弃这个番茄：记 abandoned，回到准备。严格模式下必须写理由。"""
        now = self.clock() if now is None else now
        if self.phase == "focus":
            if self.cfg.get("strict") and len(str(reason).strip()) < 2:
                raise ValueError("严格模式：放弃要写一句理由")
            rec = self._close_focus("abandoned", now, str(reason).strip()[:200])
        else:
            rec = None
        self.phase, self.running, self.spent, self.next_phase = "idle", False, 0.0, "focus"
        return rec

    def interrupt(self, kind, detail="", now=None, open_=False):
        """监督记一次中断（只在专注进行中记）。open_=True 表示还没结束，结束时补上时长。"""
        now = self.clock() if now is None else now
        if self.phase != "focus" or not self.running or self.session is None:
            return None
        it = dict(t=now, kind=kind, detail=str(detail)[:120], seconds=0.0)
        if open_:
            it["open"] = True
        self.session["interruptions"].append(it)
        return it

    def close_interrupt(self, kind, now=None):
        now = self.clock() if now is None else now
        for it in reversed((self.session or {}).get("interruptions", [])):
            if it.get("open") and it["kind"] == kind:
                it["seconds"] = round(now - it["t"], 1)
                it.pop("open", None)
                return it
        return None

    def tick(self, now=None) -> list[str]:
        """推进时间：到点的阶段结束。返回发生的事：focus_done / break_done。"""
        now = self.clock() if now is None else now
        events = []
        guard = 0
        while self.running and self.phase != "idle" and self.remaining(now) <= 0 and guard < 4:
            guard += 1
            end = self.started_at + (self.length() - self.spent)
            if self.phase == "focus":
                self._close_focus("done", end)
                events.append("focus_done")
                self._after_focus(end, counted=True)
            else:
                events.append("break_done")
                self._after_break(end)
        return events


# ---------------------------------------------------------------- 统计
def summary(days=7, today=None, recs=None, plan_blocks=None) -> dict:
    """近 days 天：每天专注分钟、开始 / 完成的番茄、完成率、中断次数；计划块完成率。"""
    today = today or date.today()
    recs = sessions() if recs is None else recs
    if plan_blocks is None:
        from . import plan
        plan_blocks = plan.blocks()
    rows = []
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).isoformat()
        rs = [r for r in recs if r.get("day") == d]
        bs = [b for b in plan_blocks if b.get("day") == d]
        started = len(rs)
        done = sum(1 for r in rs if r.get("status") == "done")
        inter = sum(len(r.get("interruptions") or []) for r in rs)
        rows.append(dict(day=d, focus_min=round(sum(float(r.get("focus") or 0) for r in rs) / 60.0, 1), started=started,
                         done=done, rate=round(done / started, 4) if started else None, interruptions=inter,
                         abandoned=sum(1 for r in rs if r.get("status") == "abandoned"),
                         plan_total=len(bs), plan_done=sum(1 for b in bs if b.get("done"))))
    tot = dict(focus_min=round(sum(r["focus_min"] for r in rows), 1), started=sum(r["started"] for r in rows),
               done=sum(r["done"] for r in rows), interruptions=sum(r["interruptions"] for r in rows),
               plan_total=sum(r["plan_total"] for r in rows), plan_done=sum(r["plan_done"] for r in rows))
    tot["rate"] = round(tot["done"] / tot["started"], 4) if tot["started"] else None
    tot["plan_rate"] = round(tot["plan_done"] / tot["plan_total"], 4) if tot["plan_total"] else None
    subj = {}
    kinds = {}
    reasons = []
    first = rows[0]["day"]
    for r in recs:
        if r.get("day", "") < first:
            continue
        k = r.get("subject") or "未分科"
        subj[k] = round(subj.get(k, 0) + float(r.get("focus") or 0) / 60.0, 1)
        for it in r.get("interruptions") or []:
            kinds[it["kind"]] = kinds.get(it["kind"], 0) + 1
        if r.get("status") == "abandoned" and r.get("reason"):
            reasons.append(r["reason"])
    return dict(days=rows, total=tot, subjects=subj, kinds=kinds, reasons=reasons[-5:])
