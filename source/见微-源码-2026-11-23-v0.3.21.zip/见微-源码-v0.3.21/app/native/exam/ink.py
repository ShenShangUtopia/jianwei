"""作答手写板：一块带横线的答题纸。笔画模型、撤销栈用 kit/pen.py（和课件、黑板同一套），
数位板压感、笔尾橡皮照黑板的处理（tabletEvent）。笔画存控件坐标（加上下滚动量），导出白底黑字的图给识别。
"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPointingDevice
from PySide6.QtWidgets import QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from ..design.tokens import T, qc
from ..kit import pen as ink

LINE = 44.0          # 横线间距（板上坐标）
WIDTHS = (("细", 2.2), ("中", 3.4), ("粗", 5.0))


class InkPad(QWidget):
    """一题一块。strokes 是 pen.py 的 v1 笔画（存黑色，画的时候按昼夜换成前景色）。"""
    changed = Signal()

    def __init__(self, strokes=None):
        super().__init__()
        self.hist = ink.History(strokes or [])
        self.tool = "pen"
        self.width_px = WIDTHS[1][1]
        self.active = None
        self.erasing = False
        self.dy = 0.0
        self.setMinimumHeight(220)
        self.setAttribute(Qt.WidgetAttribute.WA_TabletTracking, True)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setToolTip("用数位板或鼠标在这里写；笔尾或「橡皮」擦除；滚轮上下翻")

    # ---- 数据
    @property
    def strokes(self):
        return self.hist.strokes

    def has_ink(self) -> bool:
        return bool(self.hist.strokes)

    def set_strokes(self, strokes):
        self.hist = ink.History(strokes or [])
        self.dy = 0.0
        self.update()

    def undo(self):
        if self.hist.undo():
            self.changed.emit()
            self.update()

    def clear(self):
        if self.hist.strokes:
            self.hist.clear()
            self.changed.emit()
            self.update()

    def set_tool(self, tool):
        self.tool = tool
        self.setCursor(Qt.CursorShape.PointingHandCursor if tool == "eraser" else Qt.CursorShape.CrossCursor)

    # ---- 坐标
    def _q(self, pos):
        return QPointF(pos.x(), pos.y() + self.dy)

    def content_bottom(self) -> float:
        ys = [ink.bounds(s).bottom() for s in self.hist.strokes]
        return max(ys) if ys else 0.0

    # ---- 输入
    def _press(self, pos, pr=1.0, pressure=False, eraser=False):
        q = self._q(pos)
        if eraser or self.tool == "eraser":
            self.erasing = True
            self._before = list(self.hist.strokes)
            self._erase(q)
            return
        self.active = ink.new_stroke("pen", "#000000", self.width_px, pressure)
        ink.add_point(self.active, q.x(), q.y(), pr)
        self.update()

    def _move(self, pos, pr=1.0):
        q = self._q(pos)
        if self.active is not None:
            if ink.add_point(self.active, q.x(), q.y(), pr, 0.6):
                self.update()
        elif self.erasing:
            self._erase(q)

    def _release(self):
        if self.active is not None:
            st, self.active = self.active, None
            self.hist.add(st)
            self.changed.emit()
            self.update()
        elif self.erasing:
            self.erasing = False
            now = list(self.hist.strokes)
            if now != self._before:
                self.hist.strokes = list(self._before)
                self.hist.replace(now)
                self.changed.emit()

    def _erase(self, q):
        hit = [s for s in self.hist.strokes if ink.hit(s, q.x(), q.y(), 10.0)]
        if hit:
            self.hist.strokes = [s for s in self.hist.strokes if not any(s is h for h in hit)]
            self.update()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._press(e.position())
        elif e.button() == Qt.MouseButton.RightButton:
            self._press(e.position(), eraser=True)

    def mouseMoveEvent(self, e):  # noqa: N802
        if e.buttons():
            self._move(e.position())

    def mouseReleaseEvent(self, _e):  # noqa: N802
        self._release()

    def tabletEvent(self, e):  # noqa: N802
        t = e.type()
        eraser = e.pointerType() == QPointingDevice.PointerType.Eraser
        if t == e.Type.TabletPress:
            self._press(e.position(), e.pressure(), True, eraser)
        elif t == e.Type.TabletMove:
            self._move(e.position(), e.pressure())
        elif t == e.Type.TabletRelease:
            self._release()
        e.accept()

    def wheelEvent(self, e):  # noqa: N802
        limit = max(0.0, self.content_bottom() + LINE * 4 - self.height())
        self.dy = max(0.0, min(limit + LINE * 6, self.dy - e.angleDelta().y() * 0.6))
        self.update()

    # ---- 绘制
    def _paint_paper(self, p, w, h, dark, color_line):
        p.setPen(QPen(color_line, 1))
        first = int(self.dy // LINE) + 1
        y = first * LINE - self.dy
        while y < h:
            p.drawLine(QPointF(16, y), QPointF(w - 16, y))
            y += LINE

    def _paint_strokes(self, p, color):
        p.save()
        p.translate(0, -self.dy)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        for s in self.hist.strokes + ([self.active] if self.active else []):
            ink.draw(p, dict(s, color=color))
        p.restore()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(QPen(qc(T.line2), 1))
        p.setBrush(qc(T.stage))
        p.drawRoundedRect(r, 8, 8)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        self._paint_paper(p, self.width(), self.height(), T.dark, qc(T.line))
        self._paint_strokes(p, qc(T.fg).name())
        if not self.hist.strokes and self.active is None:
            p.setPen(qc(T.faint))
            p.drawText(QRectF(0, 0, self.width(), LINE * 1.5), int(Qt.AlignmentFlag.AlignCenter), "在这里手写作答")
        p.end()

    def render_image(self) -> QImage:
        """白底黑字、整块内容（不管滚到哪）：给 AI 识图 / 本机 OCR 用。没有笔迹返回空图。"""
        if not self.hist.strokes:
            return QImage()
        rect = QRectF()
        for s in self.hist.strokes:
            rect = rect.united(ink.bounds(s))
        rect = rect.adjusted(-20, -20, 20, 20)
        w, h = int(max(200, rect.width())), int(max(80, rect.height()))
        im = QImage(w, h, QImage.Format.Format_RGB32)
        im.fill(QColor("white"))
        p = QPainter(im)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.translate(-rect.left(), -rect.top())
        for s in self.hist.strokes:
            ink.draw(p, dict(s, color="#111111"))
        p.end()
        return im


class InkBox(QWidget):
    """手写板 + 一排工具键（笔、橡皮、粗细、撤销、清空）。"""
    changed = Signal()

    def __init__(self, strokes=None):
        super().__init__()
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.pad = InkPad(strokes)
        self.pad.changed.connect(self.changed)
        self.keys = {}
        for key, text, tip in (("pen", "笔", "手写（数位板有压感）"), ("eraser", "橡皮", "擦掉碰到的笔画；数位板笔尾、鼠标右键也能擦")):
            b = QPushButton(text)
            b.setCheckable(True)
            b.setToolTip(tip)
            b.clicked.connect(lambda _c=False, k=key: self.set_tool(k))
            bar.addWidget(b)
            self.keys[key] = b
        bar.addSpacing(8)
        self.wkeys = []
        for name, w in WIDTHS:
            b = QPushButton(name)
            b.setCheckable(True)
            b.setToolTip("笔画粗细")
            b.clicked.connect(lambda _c=False, w=w: self.set_width(w))
            bar.addWidget(b)
            self.wkeys.append((w, b))
        bar.addStretch(1)
        u = QPushButton("撤销")
        u.clicked.connect(self.pad.undo)
        c = QPushButton("清空")
        c.setObjectName("ghost")
        c.clicked.connect(self.pad.clear)
        bar.addWidget(u)
        bar.addWidget(c)
        v.addLayout(bar)
        v.addWidget(self.pad, 1)
        self.set_tool("pen")
        self.set_width(WIDTHS[1][1])

    def set_tool(self, tool):
        self.pad.set_tool(tool)
        for k, b in self.keys.items():
            b.setChecked(k == tool)

    def set_width(self, w):
        self.pad.width_px = w
        for ww, b in self.wkeys:
            b.setChecked(ww == w)
        self.set_tool("pen")
