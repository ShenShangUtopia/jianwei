"""限时考试 + 考情分析的离屏自测（不联网、不用 QtTest）。

导入：文本 / Word / PDF / 图片切题、答案表；题库组卷；离线判分、自评；假 AI 评分（选择题以程序为准）；
手写板压感、橡皮、撤销、导出图；考试页完整走一遍（含手写题、交卷、报告、考情、加入复习）；
时间到自动交卷、断点续考；学习窗口和主窗口三种页面布局 × 三种风格都能打开考试页。
"""
from ..kit import test_runtime
test_runtime.configure()
import json
import sys
import time
import zipfile
from pathlib import Path

PAPER = """2025-2026 学年高一数学期中考试
一、单项选择题：本题共 4 小题，每小题 5 分，共 20 分。
1. 已知集合 A={1,2,3}，B={2,3,4}，则 A∩B=（　）
A. {1}　　B. {2,3}　　C. {1,2,3,4}　　D. ∅
2．函数 f(x)=log₂(x−1) 的定义域是（　）
A. (1,+∞)　B. [1,+∞)　C. (0,+∞)　D. R
3、若 2.5x=5，则 x=（　）
A. 1　B. 2　C. 3　D. 4
4. sin30°=（　）
A. 1/2　B. √3/2　C. 1　D. 0
二、填空题：本题共 2 小题，每小题 5 分，共 10 分。
5. 计算 (1/2)^(-2) = ______。
6. 等差数列 1，3，5，… 的第 10 项是 ______。
三、解答题：本题共 2 小题，共 27 分。
7.（12 分）已知函数 f(x)=x²−2x−3。
(1) 求 f(x) 的零点；
(2) 求 f(x) 在 [0,3] 上的最大值和最小值。
8.（15 分）已知等比数列 {aₙ} 中 a₁=2，a₄=16，求通项公式和前 n 项和。
参考答案
1.B 2.A 3.B 4.A
5. 4
6. 19
7. (1) 零点 −1 和 3；(2) 最小值 −4，最大值 0。
8. aₙ=2ⁿ，Sₙ=2ⁿ⁺¹−2
"""


class FakeEngine:
    """假的 AI：按题号回分；第 2 题故意给满分（选择题应以程序判的 0 分为准）。"""

    def __init__(self, items, summary="计算基础好，函数定义域要再练。"):
        self.items, self.summary, self.calls = items, summary, 0

    def ask(self, messages, deep=False, status=None, **_kw):
        self.calls += 1
        return json.dumps(dict(items=self.items, summary=self.summary), ensure_ascii=False), False


class FakeReader:
    def __init__(self, text):
        self.text = text

    def available(self):
        return True

    def read(self, image, hint="", cancel=lambda: False, refresh=False):
        return dict(text=self.text, query="", uncertainty="")


def _docx(path, lines):
    w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = "".join(f'<w:p><w:r><w:t xml:space="preserve">{ln.replace("&", "&amp;").replace("<", "&lt;")}</w:t></w:r></w:p>' for ln in lines)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="xml" ContentType="application/xml"/></Types>')
        z.writestr("word/document.xml", f'<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="{w}"><w:body>{body}</w:body></w:document>')


def _docx_numbered(path, qs):
    """像老师出的卷子：大题标题 + 自动编号的小题（numPr，题号不写在文字里）+ 末尾答案表。"""
    from xml.sax.saxutils import escape
    w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    def para(text, num=False):
        ppr = '<w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="7"/></w:numPr></w:pPr>' if num else ""
        runs = "".join(f'<w:r><w:t xml:space="preserve">{escape(ln)}</w:t></w:r>' + ('<w:r><w:br/></w:r>' if i < len(text.split("\n")) - 1 else "")
                       for i, ln in enumerate(text.split("\n")))
        return f"<w:p>{ppr}{runs}</w:p>"
    from .paper import TYPES, bank_type
    body, sec = [], None
    heads = {"单选": "一、选择题：本题共若干小题，每小题 5 分。", "多选": "二、多项选择题：每小题 6 分。",
             "填空": "三、填空题：每小题 5 分。", "解答": "四、解答题：解答应写出文字说明、证明过程或演算步骤。"}
    for q in qs:
        t = bank_type(q)
        if t != sec:
            body.append(para(heads[t]))
            sec = t
        body.append(para(q["stem"], num=True))
    body.append(para("参考答案"))
    for i, q in enumerate(qs, 1):
        body.append(para(f"{i}. " + str(q["answer"]).split("\n")[0]))
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("word/document.xml", f'<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="{w}"><w:body>{"".join(body)}</w:body></w:document>')
    return TYPES


def _pdf(path, lines):
    from PySide6.QtCore import QMarginsF, QRectF, Qt
    from PySide6.QtGui import QFont, QPageLayout, QPageSize, QPainter, QPdfWriter
    pw = QPdfWriter(str(path))
    pw.setPageLayout(QPageLayout(QPageSize(QPageSize.PageSizeId.A4), QPageLayout.Orientation.Portrait, QMarginsF(15, 15, 15, 15)))
    p = QPainter(pw)
    f = QFont("Microsoft YaHei")       # 雅黑写的 PDF 文字层没有部首字问题（见 HANDOFF §8）
    f.setPointSize(11)
    p.setFont(f)
    y = 0
    step = pw.resolution() * 0.28
    for ln in lines:
        p.drawText(QRectF(0, y, pw.width(), step), int(Qt.AlignmentFlag.AlignLeft), ln)
        y += step
    p.end()


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    fails, log = [], []

    def check(name, ok, detail=""):
        log.append(("OK  " if ok else "FAIL") + " " + name + ("" if ok else f"  {detail}"))
        if not ok:
            fails.append(name)

    def spin(sec=0.05):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from . import grade, paper, records
    from .. import learning

    # ------------------------------------------------ 切题
    qs = paper.split_text(PAPER, "数学")
    check("切出 8 题", len(qs) == 8, [q["no"] for q in qs])
    check("题型按大题标题", [q["type"] for q in qs] == ["单选"] * 4 + ["填空"] * 2 + ["解答"] * 2, [q["type"] for q in qs])
    check("分值：每小题 5 分、题干里的（12 分）", [q["score"] for q in qs] == [5, 5, 5, 5, 5, 5, 12, 15], [q["score"] for q in qs])
    check("答案表按题号填回", [q["answer"][:3] for q in qs[:6]] == ["B", "A", "B", "A", "4", "19"], [q["answer"] for q in qs])
    check("长答案跨行也接上", "最大值 0" in qs[6]["answer"] and "Sₙ" in qs[7]["answer"], qs[6]["answer"])
    check("2.5 不当成题号、选项留在题干", "2.5x=5" in qs[2]["stem"] and "D. 4" in qs[2]["stem"], qs[2]["stem"])
    check("小问 (1)(2) 留在本题", "(1)" in qs[6]["stem"] and "(2)" in qs[6]["stem"], qs[6]["stem"])
    check("中文标点不被改成英文", "，" in qs[0]["stem"], qs[0]["stem"])
    check("没有大题标题时按选项猜单选", paper.guess_type("下列说法正确的是\nA. 甲 B. 乙 C. 丙 D. 丁") == "单选")
    ex0 = paper.new_exam(qs, "", "数学")
    check("满分与默认时长", ex0["full"] == 57 and 10 <= ex0["minutes"] <= 150, (ex0["full"], ex0["minutes"]))
    no_key = paper.split_text("1. 甲\n2. 乙\n3、丙")
    check("没有答案表时答案为空", len(no_key) == 3 and not any(q["answer"] for q in no_key))

    # ------------------------------------------------ 文件
    lines = PAPER.splitlines()
    _docx(out / "paper.docx", lines)
    text, how = paper.load_file(out / "paper.docx")
    dq = paper.split_text(text)
    check("Word 导入切题", how == "Word" and len(dq) == 8 and dq[0]["answer"] == "B", (how, len(dq)))
    _pdf(out / "paper.pdf", lines)
    text, how = paper.load_file(out / "paper.pdf")
    pq = paper.split_text(text)
    check("PDF 文字层导入切题", "PDF" in how and len(pq) == 8 and pq[4]["answer"] == "4", (how, len(pq), text[:200]))
    from PySide6.QtGui import QImage
    im = QImage(400, 300, QImage.Format.Format_RGB32)
    im.fill(0xFFFFFF)
    im.save(str(out / "paper.png"))
    text, how = paper.load_file(out / "paper.png", reader=FakeReader("1. 题一\nA. 1 B. 2 C. 3 D. 4\n2. 题二 ______"))
    iq = paper.split_text(text)
    check("图片走识图再切题", how == "AI 识图" and len(iq) == 2 and iq[0]["type"] == "单选" and iq[1]["type"] == "填空", (how, iq))
    # 真题卷：题库里 2024 新课标Ⅰ卷数学的原题，做成 Word 自动编号（题号不在文字里）+ 大题标题 + 答案表
    from ..bank.data import bank as _bank
    _bank.load()
    real = [q for q in _bank.questions if q.get("year") == 2024 and q.get("paper") == "新课标Ⅰ卷" and q.get("subject") == "数学"]
    real.sort(key=lambda q: paper.TYPES.index(paper.bank_type(q)))
    _docx_numbered(out / "real-2024-I.docx", real)
    text, how = paper.load_file(out / "real-2024-I.docx")
    rq = paper.split_text(text, "数学")
    check("真题卷（Word 自动编号）导入：题数", len(rq) == len(real), (len(rq), len(real)))
    check("真题卷：题型和参考答案对上", all(a["answer"].strip() == str(b["answer"]).strip().split("\n")[0].strip() for a, b in zip(rq, real))
          and [a["type"] for a in rq] == [paper.bank_type(b) for b in real], [(a["type"], a["answer"][:10]) for a in rq])
    try:
        paper.load_file(out / "old.doc")
        check("旧版 .doc 给出提示", False)
    except ValueError as e:
        check("旧版 .doc 给出提示", ".docx" in str(e))

    # ------------------------------------------------ 题库组卷
    bq = paper.from_bank("物理", 6, ["单选", "解答"], seed=3)
    check("题库组卷：科目、题数、带答案", len(bq) == 6 and all(q["subject"] == "物理" and q["qid"] and q["answer"] for q in bq))
    check("选择题排在前面", [q["type"] for q in bq] == sorted([q["type"] for q in bq], key=paper.TYPES.index))
    ids = [q["qid"] for q in bq[:2]]
    check("指定 id 组卷", [q["qid"] for q in paper.from_bank(ids=ids)] == ids)

    # ------------------------------------------------ 离线判分
    ex = paper.new_exam(paper.split_text(PAPER, "数学"), "期中", "数学")
    ex["answers"] = {"1": dict(text="B"), "2": dict(text="选C"), "3": dict(text="b"), "5": dict(text="4"), "6": dict(text="20"),
                     "7": dict(text="", ink=True)}
    rep = grade.offline(ex)
    st = {i["no"]: i["status"] for i in rep["items"]}
    check("离线：选择题比字母（大小写、「选C」）", st[1] == "right" and st[2] == "wrong" and st[3] == "right", st)
    check("离线：填空数值对照", st[5] == "right" and st[6] == "wrong", st)
    check("离线：未答、手写主观题待自评", st[4] == "blank" and st[7] == "self" and st[8] == "blank", st)
    check("离线总分", rep["total"] == 15 and rep["pending"] == 1 and rep["engine"] == "offline", rep)
    rep2 = grade.set_self_score(rep, 7, 8)
    check("自评给分后总分更新", rep2["total"] == 23 and rep2["pending"] == 0 and rep2["items"][6]["status"] == "partial", rep2["total"])
    mq = dict(no=1, type="多选", score=6, answer="ABD", points=[])
    part = [grade.offline_item(mq, dict(text=t)) for t in ("AB", "ABD", "ABC", "A")]
    check("多选：漏选按比例给分、选错不得分", [p["score"] for p in part] == [4, 6, 0, 2] and part[0]["status"] == "partial",
          [p["score"] for p in part])
    rep3 = grade.set_self_score(rep2, 7, 99)
    check("自评不超过满分", rep3["items"][6]["score"] == 12 and rep3["items"][6]["status"] == "right")

    # ------------------------------------------------ AI 评分（假引擎）
    fake = FakeEngine([dict(no=n, score=s, cause=c, comment=m, points=p) for n, s, c, m, p in (
        (1, 5, "", "对", ["集合交集"]), (2, 5, "", "AI 以为对", ["对数定义域"]), (3, 5, "", "", ["一元一次方程"]),
        (5, 5, "", "", ["负指数幂"]), (6, 0, "计算错误", "第 10 项是 1+9×2=19", ["等差数列通项"]),
        (7, 7, "表达不规范", "零点对，最值没写取到的 x", ["二次函数最值"]), (8, 0, "未作答", "", ["等比数列"]), (4, 0, "未作答", "", []))])
    ai_rep = grade.ai(ex, {7: "零点 -1 和 3，最小值 -4"}, engine=fake)
    ai_st = {i["no"]: i for i in ai_rep["items"]}
    check("AI：选择题以程序判的为准", ai_st[2]["score"] == 0 and ai_st[2]["how"] == "程序", ai_st[2])
    check("AI：主观题给步骤分和错因", ai_st[7]["score"] == 7 and ai_st[7]["status"] == "partial" and ai_st[7]["cause"] == "表达不规范", ai_st[7])
    check("AI：手写识别文字带进报告", "最小值" in ai_st[7].get("ink", ""))
    check("AI：未答的不交给 AI 改分", ai_st[8]["status"] == "blank" and ai_st[8]["score"] == 0)
    check("AI：总分与总结", ai_rep["total"] == 22 and ai_rep["engine"] == "ai" and "定义域" in ai_rep["summary"], ai_rep["total"])
    bad = FakeEngine([dict(no=1, score=50, cause="", comment="", points=[])])
    try:
        grade.ai(ex, {}, engine=bad)
        check("AI：输出不合格时报错（退回离线由调用方处理）", False)
    except Exception as e:  # noqa: BLE001
        check("AI：输出不合格时报错（退回离线由调用方处理）", type(e).__name__ == "AskError" and bad.calls == 2, (type(e).__name__, bad.calls))
    got = grade.recognize_ink(ex, {7: im}, reader=FakeReader("手写：x=3"))
    check("手写识别走识图接口", got == {7: "手写：x=3"})

    # ------------------------------------------------ 手写板
    from PySide6.QtCore import QPointF
    from .ink import InkBox, InkPad
    box = InkBox()
    box.resize(600, 300)
    box.show()
    spin()
    pad = box.pad
    pad._press(QPointF(40, 40), 0.2, True)
    for i in range(1, 30):
        pad._move(QPointF(40 + i * 8, 40 + (i % 5) * 3), 0.2 + i * 0.025)
    pad._release()
    pad._press(QPointF(40, 120))
    pad._move(QPointF(200, 130))
    pad._release()
    check("手写两笔、压感记录在点里", len(pad.strokes) == 2 and pad.strokes[0]["pressure"] and pad.strokes[0]["points"][-1][2] > 0.8)
    pad._press(QPointF(120, 126), eraser=True)
    pad._release()
    check("笔尾橡皮擦掉碰到的那笔", len(pad.strokes) == 1)
    pad.undo()
    check("撤销把擦掉的找回来", len(pad.strokes) == 2)
    box.set_tool("eraser")
    pad._press(QPointF(42, 41))
    pad._release()
    check("橡皮工具", len(pad.strokes) == 1)
    box.set_tool("pen")
    img = pad.render_image()
    check("导出白底手写图", not img.isNull() and img.width() >= 200 and QImage(img).pixelColor(1, 1).name() == "#ffffff")
    pad2 = InkPad(pad.strokes)
    check("笔画能存下来再载入（pen.py v1 格式）", len(pad2.strokes) == 1 and pad2.strokes[0]["v"] == 1)
    box.grab().save(str(out / "ink.png"))
    box.close()

    # ------------------------------------------------ 考试页完整一遍
    from ..design import tokens
    from .page import ExamPage
    page = ExamPage()
    page.resize(1200, 820)
    page.show()
    spin()
    check("考试页打开：首页", page.stack.currentWidget() is page.v_home and not page.resume_box.isVisible())
    page.import_file(str(out / "real-2024-I.docx"), sync=True)
    check("考试页导入 Word 真题卷", page.stack.currentWidget() is page.v_setup and page.s_list.count() == len(real)
          and page.s_title.text() == "real-2024-I", (page.s_list.count(), page.s_title.text()))
    page.show_tab("exam")
    page.paste.setPlainText(PAPER)
    page.split_paste()
    check("粘贴切题进入核对", page.stack.currentWidget() is page.v_setup and page.s_list.count() == 8, page.s_list.count())
    page.s_list.setCurrentRow(7)
    page.e_score.setValue(16)
    check("核对时改分值", page.exam["questions"][7]["score"] == 16 and page.exam["full"] == 58, page.exam["full"])
    page.s_list.setCurrentRow(7)
    page._merge_up()
    check("并到上一题", len(page.exam["questions"]) == 7 and "8. " in page.exam["questions"][6]["stem"] and page.exam["questions"][6]["score"] == 28)
    page.paste.setPlainText(PAPER)
    page.split_paste()
    page.s_min.setValue(40)
    page.grab().save(str(out / "setup.png"))
    page.start()
    spin()
    check("开始考试：倒计时", page.stack.currentWidget() is page.v_take and page.tick.isActive() and page.t_clock.text().startswith("39:5")
          or page.t_clock.text() == "40:00", page.t_clock.text())
    check("进行中的考试存盘", records.current() is not None and records.current()["id"] == page.exam["id"])
    page.t_text.setPlainText("B")
    page.go(1)
    page.t_text.setPlainText("C")
    page.go(4)
    page.t_text.setPlainText("4")
    page.go(6)
    check("解答题默认手写", page.t_mode.value == "ink" and page.t_input.currentIndex() == 1)
    ipad = page.pads[7].pad
    ipad.resize(700, 300)
    ipad._press(QPointF(30, 30), 0.5, True)
    for i in range(20):
        ipad._move(QPointF(30 + i * 10, 30 + i), 0.6)
    ipad._release()
    spin(0.7)
    check("手写作答记进答卷并自动存盘", records.current()["answers"]["7"]["ink"] and len(records.current()["answers"]["7"]["strokes"]) == 1)
    check("题号格标出已答", page.t_done.text() == "已答 4/8", page.t_done.text())
    page.grab().save(str(out / "take.png"))
    page.submit_ask()
    check("交卷前提示没答的题", page.t_confirm.isVisible() and "4 题没答" in page.t_confirm_text.text(), page.t_confirm_text.text())

    def grader(exam, images):
        fk = FakeEngine([dict(no=n, score=s, cause=c, comment="", points=p) for n, s, c, p in (
            (1, 5, "", ["集合交集"]), (2, 0, "概念不清", ["对数函数定义域"]), (5, 5, "", ["负指数幂"]),
            (7, 6, "计算错误", ["二次函数最值", "函数零点"]), (3, 0, "未作答", []), (4, 0, "未作答", []), (6, 0, "未作答", []), (8, 0, "未作答", []))])
        ink_text = grade.recognize_ink(exam, images, reader=FakeReader("零点 -1 和 3"))
        return grade.ai(exam, ink_text, engine=fk), "假 AI 评分"
    grader.sync = True
    grader.seen = None
    page.grader = grader
    page.submit()
    spin()
    check("交卷后出报告", page.stack.currentWidget() is page.v_report and page.exam.get("report") is not None)
    rep = page.exam["report"]
    check("报告总分（手写题由 AI 评）", rep["total"] == 16 and rep["engine"] == "ai", rep["total"])
    check("手写图存成文件", Path(page.exam["answers"]["7"]["ink_file"]).exists())
    check("记录进考试历史，进行中的清掉", len(records.history()) == 1 and records.current() is None)
    ev = [e for e in learning.load()["events"] if str(e.get("id", "")).startswith("exam-")]
    check("每题记一条学习事件", len(ev) == 8 and sum(1 for e in ev if e["correct"] is True) == 2, len(ev))
    page.grab().save(str(out / "report.png"))

    # 第二场：题库组卷、离线判分、自评
    page.show_tab("exam")
    page.b_subj.setCurrentText("数学")
    page.b_count.setValue(4)
    page.compose()
    check("题库组卷进入核对", page.stack.currentWidget() is page.v_setup and len(page.exam["questions"]) == 4)
    page.start()
    for i, q in enumerate(page.exam["questions"]):
        page.go(i)
        page._set_mode("type")
        page.t_text.setPlainText("Z" if q["type"] in paper.OBJECTIVE else "不会")
    page.grader = None
    page.submit()
    for _ in range(200):
        spin(0.02)
        if page.exam.get("report"):
            break
    rep = page.exam.get("report") or {}
    check("没有密钥时离线判分（后台线程）", rep.get("engine") == "offline", rep.get("engine"))
    pend = [i for i in rep.get("items", []) if i["status"] == "self"]
    if pend:
        page.self_score(pend[0]["no"], 1)
        check("报告里自评", records.get(page.exam["id"])["report"]["items"][pend[0]["no"] - 1]["how"] == "自评")
    check("两场考试都在历史里", len(records.history()) == 2)

    # 考情
    page.show_tab("stats")
    spin()
    stt = page.stats
    check("考情：考试次数与趋势", len(stt["exams"]) == 2 and len(page.k_trend.values) == 2)
    check("考情：各科得分率", stt["subjects"]["数学"]["exam_rate"] is not None)
    check("考情：错因分布", stt["causes"].get("概念不清", 0) >= 1 and stt["causes"].get("未作答", 0) >= 4, stt["causes"])
    names = [w["point"] for w in stt["weak"]]
    check("考情：薄弱点排行", "对数函数定义域" in names and "集合交集" not in names, names)
    check("考情：用时", stt["time"]["exam_used"] >= 0)
    # 习题台的作答也算进来
    from ..bank.data import bank
    bank.load()
    qid = next(q["id"] for q in bank.questions if q.get("subject") == "化学" and q.get("points"))
    learning.record(qid, "化学", 30, correct=False, source="program", event_id="desk-1")
    learning.record(qid, "化学", 40, correct=True, source="program", event_id="desk-2")
    st2 = records.analyze()
    check("考情：习题台作答并入统计", st2["subjects"]["化学"]["practice_n"] == 2 and st2["subjects"]["化学"]["practice_rate"] == 0.5, st2["subjects"].get("化学"))
    check("考情：考试那几条不重复算进习题台", st2["subjects"]["数学"]["practice_n"] == 0, st2["subjects"]["数学"])
    page.refresh_stats()
    page.grab().save(str(out / "stats.png"))
    before = len(learning.due())
    page.add_weak()
    after = learning.due()
    check("一键把薄弱点加入复习（今天到期）", len(after) > before and any(it.get("kind") == "card" and it["title"] == "对数函数定义域" for _k, it in after),
          (before, len(after)))
    page.add_weak()
    check("重复加入不重复建卡", len(learning.due()) == len(after), (len(after), len(learning.due())))

    # 时间到自动交卷 / 断点续考
    e3 = paper.new_exam(paper.split_text("1. 1+1=?\nA. 1 B. 2 C. 3 D. 4\n参考答案\n1. B"), "超时", "数学", minutes=1)
    e3["started"] = time.time() - 120
    e3["answers"] = {"1": dict(text="B")}
    records.save_current(e3)
    page.show_tab("exam")
    check("首页提示有没交卷的考试", page.resume_box.isVisible() and "时间已到" in page.resume_text.text(), page.resume_text.text())
    page.grader = lambda ex, ims: (grade.offline(ex), "离线")
    page.grader.sync = True
    page.resume()
    spin()
    check("时间到自动交卷", page.exam["id"] == e3["id"] and page.exam["report"]["total"] == 5 and records.current() is None)
    check("超时交卷用时按时长封顶", page.exam["used"] == 60.0, page.exam.get("used"))
    e4 = paper.new_exam(paper.split_text("1. 写出勾股定理\n2. 1+2=______"), "续考", "数学", minutes=30)
    e4["started"] = time.time() - 60
    e4["answers"] = {"1": dict(text="a²+b²=c²")}
    records.save_current(e4)
    p2 = ExamPage()
    p2.show()
    spin()
    p2.resume()
    check("关掉再开接着考：答案还在、计时接着走", p2.stack.currentWidget() is p2.v_take and p2.t_text.toPlainText() == "a²+b²=c²"
          and p2.t_clock.text().startswith("28:") or p2.t_clock.text().startswith("29:"), p2.t_clock.text())
    p2.hide()
    check("看不见时不跑计时器", not p2.tick.isActive())
    p2.abandon()
    check("放弃没考完的", records.current() is None)
    p2.close()

    # 昼夜切换不出错
    tokens.set_theme("night")
    page.apply_theme()
    page.show_tab("stats")
    page.grab().save(str(out / "stats-night.png"))
    tokens.set_theme("day")
    page.apply_theme()
    page.close()

    # ------------------------------------------------ 入口：学习窗口
    from ..main_win import MODE_KEYS, MODES, NativeWindow
    check("学习窗口有「考试」模式（Ctrl+8）", ("exam", "考试") in MODES and MODE_KEYS["exam"] == 8)
    nw = NativeWindow("day")
    nw.resize(1100, 640)
    nw.show()
    spin()
    w = nw.goto("exam", "stats")
    spin()
    check("学习窗口打开考试页的考情", type(w).__name__ == "ExamPage" and w.stack.currentWidget() is w.v_stats)
    check("窄栏在最小高度放得下", nw.rail.minimumSizeHint().height() <= 620, nw.rail.minimumSizeHint().height())
    nw.grab().save(str(out / "native.png"))
    nw.shutdown()
    nw.close()

    # ------------------------------------------------ 入口：主窗口 三种页面布局 × 三种风格
    try:
        import os
        import store
        from shell import NAV, Shell
        real = Path.home() / "AppData" / "Local" / "Jianwei"
        if not os.environ.get("JIANWEI_HOME") or os.path.realpath(store.HOME) == os.path.realpath(real):
            raise RuntimeError("JIANWEI_HOME 没有指向隔离目录，不建主窗口")
        check("主窗口导航有「考试」", ("exam", "考试") in NAV)
        cfg = store.load_config()
        cfg.update(autoFetch=False, autoEvening=False, prewarmWeb=False)
        store.save_config(cfg)
        sh = Shell(tray_enabled=False, jobs_enabled=False)
        sh.resize(1280, 820)
        sh.show()
        spin()
        for skin in ("ink", "celadon", "doodle"):
            sh._apply_look("day", skin)
            for lay in ("pages", "desktop", "workspace"):
                sh.set_page_layout(lay)
                spin()
                if lay == "desktop":
                    check(f"{skin}·模块桌面有考试模块", "exam" in sh.home.modules, list(sh.home.modules))
                elif lay == "workspace":
                    sh.home.add("exam")
                    spin()
                    check(f"{skin}·工作台能加考试模块", "exam" in sh.home.panels, list(sh.home.panels))
                sh.goto("exam", animate=False)
                spin()
                cur = sh.stack.currentWidget()
                ok = getattr(cur, "exam", None) is not None and cur.exam.isVisible()
                check(f"{skin}·{lay} 打开考试页", ok, type(cur).__name__)
                if ok and skin == "doodle":
                    cur.exam.show_tab("stats")
                    spin()
                if skin in ("ink", "doodle"):
                    sh.grab().save(str(out / f"shell-{skin}-{lay}.png"))
        for mode in ("side", "top", "compact"):
            sh.set_page_layout("pages")
            sh.set_layout(mode)
            spin()
            sh.goto("exam", animate=False)
            spin()
            check(f"导航位置 {mode} 打开考试页", getattr(sh.stack.currentWidget(), "exam", None) is not None)
        sh.set_layout("side")
        sh._apply_look("day", "ink")
        sh.close()
        sh.deleteLater()
    except Exception:  # noqa: BLE001
        import traceback
        check("主窗口入口", False, traceback.format_exc()[-600:])

    (out / "exam-log.txt").write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))
    print("EXAM_FAIL" if fails else "EXAM_OK", len(log), "项")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
