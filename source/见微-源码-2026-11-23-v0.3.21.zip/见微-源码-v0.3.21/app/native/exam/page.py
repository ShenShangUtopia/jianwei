"""考试页：导入试卷 / 题库组卷 → 核对题目 → 限时作答（打字、手写）→ 交卷评分 → 报告；另一栏是考情分析。

学习窗口的「考试」模式和主窗口的「考试」页是同一个控件（compact=True 时背景透明、不画大标题）。
进行中的考试随时存盘（exam-current.json），关掉再开会接着考，计时按墙上时钟走（中途关掉不暂停）。
"""
from __future__ import annotations

import html
import os
import re
import time
import traceback

from PySide6.QtCore import QRectF, QSize, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton,
                               QScrollArea, QSpinBox, QSplitter, QStackedWidget, QTextBrowser, QVBoxLayout, QWidget)

from ..design.tokens import T, css, font, qc
from ..design.widgets import Segmented, qss
from . import grade, paper, records
from .ink import InkBox, InkPad

SUBJECTS = ["数学", "物理", "化学", "生物", "语文", "英语", "历史", "地理"]
STATUS_TEXT = dict(right="对", partial="部分", wrong="错", blank="未答", self="待自评")
_ALIVE: set = set()


def ai_ready() -> bool:
    if os.environ.get("JIANWEI_SELFTEST") == "1":
        return False
    try:
        from ..analysis import llm
        return llm.available()
    except Exception:   # noqa: BLE001
        return False


def ai_name() -> str:
    try:
        from ..analysis import llm
        return llm.settings()["name"]
    except Exception:   # noqa: BLE001
        return "AI"


def rich(text) -> str:
    """题面 → 富文本：下划线空位先保护起来（fx 会把 _ 当下标），换行保留。"""
    from ..bank.fx import fx
    s = re.sub(r"_{2,}|＿{2,}", "\x00", str(text or ""))
    return fx(s).replace("\x00", "<u>　　　　　</u>").replace("\n", "<br>")


def mmss(sec) -> str:
    sec = max(0, int(sec))
    h, rem = divmod(sec, 3600)
    return (f"{h}:{rem // 60:02d}:{rem % 60:02d}" if h else f"{rem // 60:02d}:{rem % 60:02d}")


def _label(text="", name="", wrap=False):
    w = QLabel(text)
    if name:
        w.setObjectName(name)
    w.setWordWrap(wrap)
    return w


def _main_look(w) -> bool:
    """在主窗口（或单独弹出的窗口）里用主窗口那套自绘按键和卡片；在学习窗口里沿用学习窗口的样式表。"""
    try:
        return type(w.window()).__name__ != "NativeWindow"
    except RuntimeError:
        return False


try:
    import ui_kit as _uk
    _BtnBase = _uk.Btn
except Exception:  # noqa: BLE001  单独跑模块时找不到 ui_kit：退回普通按键
    _uk, _BtnBase = None, QPushButton


class UBtn(_BtnBase):
    """0.3.21：新模块的按键。主窗口里画成 ui_kit.Btn（主键 / 普通 / 轻键 / 危险，跟三种风格走，手绘有墨线）；
    学习窗口里还是样式表按键（按 objectName 认 pri / danger / ghost），宽度、高度和以前一样。"""
    VARIANT = dict(pri="primary", danger="danger", ghost="soft")

    def __init__(self, text, name=""):
        if _uk is not None:
            super().__init__(text, self.VARIANT.get(name, ""))
            self.setMinimumHeight(0)
            self.setMaximumHeight(16777215)
        else:
            super().__init__(text)
        self.setObjectName(name or "ubtn")
        self._main = None

    def _look(self):
        m = _uk is not None and _main_look(self)
        if m != self._main:
            self._main = m
            self.updateGeometry()
        return m

    def sizeHint(self):  # noqa: N802
        return super().sizeHint() if self._look() else QPushButton.sizeHint(self)

    def minimumSizeHint(self):  # noqa: N802
        if self._look():
            s = super().sizeHint()
            return QSize(min(s.width(), 48), s.height())
        return QPushButton.minimumSizeHint(self)

    def showEvent(self, e):  # noqa: N802
        self._look()
        super().showEvent(e)

    def paintEvent(self, e):  # noqa: N802
        if self._look():
            super().paintEvent(e)
        else:
            QPushButton.paintEvent(self, e)


class UCard(QFrame):
    """0.3.21：新模块的卡片。主窗口里用 ui_kit.paint_card 画（水墨 / 青瓷细线，手绘 2 像素墨线 + 硬边投影）；
    学习窗口里还是样式表的 #examCard。"""

    def paintEvent(self, e):  # noqa: N802
        if _uk is not None and _main_look(self):
            p = QPainter(self)
            _uk.paint_card(p, QRectF(self.rect()))
            p.end()
        else:
            super().paintEvent(e)


def _btn(text, fn=None, name="", tip=""):
    b = UBtn(text, name)
    if tip:
        b.setToolTip(tip)
    if fn:
        b.clicked.connect(lambda _c=False: fn())
    return b


class Worker(QThread):
    """后台跑一件事（读文件 / 评分），结果用信号回到界面线程。"""
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        _ALIVE.add(self)
        self.finished.connect(lambda: _ALIVE.discard(self))

    def run(self):
        try:
            self.done.emit(self.fn())
        except Exception as e:  # noqa: BLE001
            if type(e).__name__ not in ("AskError", "ValueError"):
                traceback.print_exc()
            self.failed.emit(str(e) or type(e).__name__)


def grade_exam(exam, images, status=None):
    """评分（在工作线程里）：有 AI 就先识别手写再交给 AI，AI 失败退回离线。返回 (报告, 说明)。"""
    if not ai_ready():
        return grade.offline(exam), "没有 AI 密钥：客观题由程序判，主观题待自评"
    ink_text = {}
    if images:
        if status:
            status("正在识别手写作答…")
        from ..lecture.lookup import Ocr
        ink_text = grade.recognize_ink(exam, images, ocr=Ocr())
    try:
        if status:
            status(f"正在请 {ai_name()} 逐题评分…")
        return grade.ai(exam, ink_text, status=status), f"{ai_name()} 评分" + (f"，手写识别 {len(ink_text)} 题" if images else "")
    except Exception as exc:  # noqa: BLE001
        return grade.offline(exam), f"AI 评分没成功（{str(exc)[:60]}），已改用离线判分"


# ================================================================ 画图的小控件
class Bars(QWidget):
    """横条：[(名字, 数值, 文字)]，数值 0..1。"""

    def __init__(self, rows=None, color="accent"):
        super().__init__()
        self.rows, self.color = rows or [], color
        self._fit()

    def set_rows(self, rows):
        self.rows = rows
        self._fit()
        self.update()

    def _fit(self):
        self.setFixedHeight(max(28, 26 * len(self.rows) + 4))

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if not self.rows:
            p.setPen(qc(T.faint))
            p.setFont(font(12))
            p.drawText(self.rect(), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "还没有数据")
            p.end()
            return
        lw, rw = 96, 70
        bw = max(40, self.width() - lw - rw - 12)
        for i, (name, val, text) in enumerate(self.rows):
            y = 4 + i * 26
            p.setFont(font(12))
            p.setPen(qc(T.soft))
            p.drawText(QRectF(0, y, lw - 8, 20), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), name)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.fg, 0.07))
            p.drawRoundedRect(QRectF(lw, y + 6, bw, 8), 4, 4)
            col = self.color if self.color != "rate" else ("ok" if val >= 0.85 else "warn" if val >= records.WEAK_RATE else "bad")
            p.setBrush(qc(getattr(T, col)))
            p.drawRoundedRect(QRectF(lw, y + 6, max(4.0, bw * max(0.0, min(1.0, val))), 8), 4, 4)
            p.setPen(qc(T.muted))
            p.setFont(font(11.5, kind="mono"))
            p.drawText(QRectF(lw + bw + 8, y, rw, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), text)
        p.end()


class Trend(QWidget):
    """得分率折线：values 0..1，labels 是横轴的字（日期）。少于两个点时画点。"""

    def __init__(self):
        super().__init__()
        self.values, self.labels = [], []
        self.setMinimumHeight(150)

    def set_data(self, values, labels):
        self.values, self.labels = list(values)[-20:], list(labels)[-20:]
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        L, R, Tp, B = 40, 12, 10, 24
        w, h = self.width() - L - R, self.height() - Tp - B
        p.setFont(font(10.5, kind="mono"))
        for k in (0, 0.5, 1.0):
            y = Tp + h * (1 - k)
            p.setPen(QPen(qc(T.line), 1))
            p.drawLine(int(L), int(y), int(L + w), int(y))
            p.setPen(qc(T.faint))
            p.drawText(QRectF(0, y - 8, L - 6, 16), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), f"{int(k * 100)}%")
        y70 = Tp + h * (1 - records.WEAK_RATE)
        pen = QPen(qc(T.warn, 0.6), 1, Qt.PenStyle.DashLine)
        p.setPen(pen)
        p.drawLine(int(L), int(y70), int(L + w), int(y70))
        if not self.values:
            p.setPen(qc(T.faint))
            p.setFont(font(12))
            p.drawText(QRectF(L, Tp, w, h), int(Qt.AlignmentFlag.AlignCenter), "考完一次就能看到趋势")
            p.end()
            return
        n = len(self.values)
        pts = [(L + (w * i / (n - 1) if n > 1 else w / 2), Tp + h * (1 - max(0, min(1, v)))) for i, v in enumerate(self.values)]
        p.setPen(QPen(qc(T.accent), 2))
        for a, b in zip(pts, pts[1:]):
            p.drawLine(int(a[0]), int(a[1]), int(b[0]), int(b[1]))
        p.setBrush(qc(T.raised))
        for (x, y), v in zip(pts, self.values):
            p.setPen(QPen(qc(T.accent if v >= records.WEAK_RATE else T.bad), 2))
            p.drawEllipse(QRectF(x - 3.5, y - 3.5, 7, 7))
        p.setPen(qc(T.faint))
        p.setFont(font(10))
        step = max(1, n // 6)
        for i in range(0, n, step):
            p.drawText(QRectF(pts[i][0] - 30, Tp + h + 4, 60, 16), int(Qt.AlignmentFlag.AlignCenter), str(self.labels[i])[5:])
        p.end()


class Spark(QWidget):
    """一科的小趋势线。"""

    def __init__(self, values):
        super().__init__()
        self.values = list(values)[-12:]
        self.setFixedSize(90, 22)

    def paintEvent(self, _e):  # noqa: N802
        if not self.values:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        n = len(self.values)
        pts = [(4 + (82 * i / (n - 1) if n > 1 else 41), 3 + 16 * (1 - max(0, min(1, v)))) for i, v in enumerate(self.values)]
        p.setPen(QPen(qc(T.accent), 1.6))
        for a, b in zip(pts, pts[1:]):
            p.drawLine(int(a[0]), int(a[1]), int(b[0]), int(b[1]))
        x, y = pts[-1]
        p.setBrush(qc(T.accent))
        p.drawEllipse(QRectF(x - 2.5, y - 2.5, 5, 5))
        p.end()


class QNav(QWidget):
    """作答时的题号格：已答的实心，当前的描边。"""
    picked = Signal(int)

    def __init__(self):
        super().__init__()
        self.items, self.cur = [], 0
        self.setMinimumWidth(120)

    def set_state(self, items, cur):
        self.items, self.cur = items, cur
        cols = max(1, (self.width() - 4) // 38)
        self.setMinimumHeight(((len(items) + cols - 1) // cols) * 38 + 4)
        self.update()

    def _cols(self):
        return max(1, (self.width() - 4) // 38)

    def mousePressEvent(self, e):  # noqa: N802
        c = self._cols()
        i = int(e.position().y() // 38) * c + int(e.position().x() // 38)
        if 0 <= i < len(self.items):
            self.picked.emit(i)

    def resizeEvent(self, e):  # noqa: N802
        self.set_state(self.items, self.cur)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        c = self._cols()
        for i, (no, answered) in enumerate(self.items):
            r = QRectF((i % c) * 38 + 2, (i // c) * 38 + 2, 32, 32)
            on = i == self.cur
            p.setPen(QPen(qc(T.accent if on else T.line2), 2 if on else 1))
            p.setBrush(qc(T.accent, 0.16) if answered else qc(T.raised))
            p.drawRoundedRect(r, 6, 6)
            p.setPen(qc(T.accent if answered or on else T.muted))
            p.setFont(font(12.5, 700 if on else 500))
            p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), str(no))
        p.end()


def _card():
    f = UCard()
    f.setObjectName("examCard")
    v = QVBoxLayout(f)
    v.setContentsMargins(16, 14, 16, 17)       # 下边多 3 像素：手绘风格的硬边投影
    v.setSpacing(8)
    return f, v


# ================================================================ 页面
class ExamPage(QWidget):
    changed = Signal()            # 有新的考试记录（主窗口刷新考情模块用）

    def __init__(self, compact: bool = False):
        super().__init__()
        self.setObjectName("examPage")
        self.compact = compact
        self.exam = None              # 正在核对 / 作答 / 看报告的考试
        self.cur = 0
        self.pads: dict[int, InkBox] = {}
        self.workers: list[Worker] = []
        self.note = ""
        self.grader = None            # 自测替换：fn(exam, images) -> (report, note)
        v = QVBoxLayout(self)
        v.setContentsMargins(*((0, 0, 0, 0) if compact else (24, 18, 24, 18)))
        v.setSpacing(12)
        top = QHBoxLayout()
        top.setSpacing(10)
        self.title = _label("考试", "examTitle")
        self.title.setVisible(not compact)
        top.addWidget(self.title)
        self.seg = Segmented([("exam", "限时考试"), ("stats", "考情分析")], "exam")
        self.seg.changed.connect(self.show_tab)
        top.addWidget(self.seg)
        self.status = _label("", "examStatus")
        top.addWidget(self.status, 1)
        v.addLayout(top)
        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)
        self.v_home = self._build_home()
        self.v_setup = self._build_setup()
        self.v_take = self._build_take()
        self.v_report = self._build_report()
        self.v_stats = self._build_stats()
        for w in (self.v_home, self.v_setup, self.v_take, self.v_report, self.v_stats):
            self.stack.addWidget(w)
        self.tick = QTimer(self)
        self.tick.setInterval(1000)
        self.tick.timeout.connect(self._tick)
        self.saver = QTimer(self)
        self.saver.setSingleShot(True)
        self.saver.setInterval(600)
        self.saver.timeout.connect(self._save_current)
        self.apply_theme()
        self.refresh_home()

    # ------------------------------------------------------------ 主页
    def _build_home(self):
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(12)
        self.resume_box, rv = _card()
        rh = QHBoxLayout()
        self.resume_text = _label("", wrap=True)
        rh.addWidget(self.resume_text, 1)
        rh.addWidget(_btn("放弃", self.abandon, "ghost", "不交卷，删掉这次没考完的"))
        rh.addWidget(_btn("继续作答", self.resume, "pri"))
        rv.addLayout(rh)
        outer.addWidget(self.resume_box)
        row = QHBoxLayout()
        row.setSpacing(12)
        imp, iv = _card()
        iv.addWidget(_label("导入试卷", "cardTitle"))
        iv.addWidget(_label("PDF、Word（.docx）、图片或文本文件；也可以直接把试卷文字粘贴到下面。按题号自动切题，"
                            "「参考答案」后面的部分会按题号填成答案。扫描版和图片用 AI 识图（没有密钥时用本机识别）。", "note", True))
        self.paste = QPlainTextEdit()
        self.paste.setObjectName("examPaste")
        self.paste.setPlaceholderText("粘贴试卷文字，例如：\n一、选择题（每小题 5 分）\n1. ……\nA. …  B. …  C. …  D. …\n……\n参考答案\n1. B  2. C ……")
        self.paste.setMinimumHeight(140)
        iv.addWidget(self.paste, 1)
        self.imp_note = _label("", "note", True)
        iv.addWidget(self.imp_note)
        ih = QHBoxLayout()
        ih.addWidget(_btn("选择文件", self.pick_file, "", "PDF、Word、图片、文本"))
        ih.addStretch(1)
        ih.addWidget(_btn("切题", self.split_paste, "pri", "把上面的文字按题号切成题目"))
        iv.addLayout(ih)
        row.addWidget(imp, 3)
        bank, bv = _card()
        bv.addWidget(_label("题库组卷", "cardTitle"))
        bv.addWidget(_label("从内置题库按科目、题型随机抽题，带参考答案和知识点，评分最准。", "note", True))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(8)
        g.addWidget(_label("科目", "ctlLabel"), 0, 0)
        self.b_subj = QComboBox()
        self.b_subj.addItems(SUBJECTS)
        g.addWidget(self.b_subj, 0, 1)
        g.addWidget(_label("题数", "ctlLabel"), 1, 0)
        self.b_count = QSpinBox()
        self.b_count.setRange(2, 30)
        self.b_count.setValue(8)
        g.addWidget(self.b_count, 1, 1)
        g.addWidget(_label("题型", "ctlLabel"), 2, 0)
        th = QHBoxLayout()
        self.b_types = {}
        for t, text in (("单选", "选择"), ("填空", "填空"), ("解答", "解答")):
            c = QCheckBox(text)
            c.setChecked(True)
            self.b_types[t] = c
            th.addWidget(c)
        th.addStretch(1)
        g.addLayout(th, 2, 1)
        bv.addLayout(g)
        bv.addStretch(1)
        bh = QHBoxLayout()
        bh.addStretch(1)
        bh.addWidget(_btn("组卷", self.compose, "pri"))
        bv.addLayout(bh)
        row.addWidget(bank, 2)
        outer.addLayout(row, 1)
        hist, hv = _card()
        hh = QHBoxLayout()
        hh.addWidget(_label("最近的考试", "cardTitle"))
        hh.addStretch(1)
        hv.addLayout(hh)
        self.hist_list = QListWidget()
        self.hist_list.setObjectName("examHist")
        self.hist_list.setMinimumHeight(110)
        self.hist_list.itemActivated.connect(self._open_hist)
        self.hist_list.itemClicked.connect(self._open_hist)
        hv.addWidget(self.hist_list)
        outer.addWidget(hist)
        return w

    def refresh_home(self):
        cur = records.current()
        self.resume_box.setVisible(bool(cur))
        if cur:
            left = records.time_left(cur)
            self.resume_text.setText(f"「{cur['title']}」还没交卷：{len(cur['questions'])} 题，"
                                     + (f"剩 {mmss(left)}。" if left > 0 else "时间已到，继续会直接交卷。"))
        self.hist_list.clear()
        for e in reversed(records.history()[-30:]):
            rep = e.get("report") or {}
            day = time.strftime("%m-%d %H:%M", time.localtime(e.get("submitted") or e.get("created") or 0))
            pend = f" · {rep['pending']} 题待自评" if rep.get("pending") else ""
            it = QListWidgetItem(f"{day}　{e['title']}　{rep.get('total', 0)}/{rep.get('full', 0)} 分　"
                                 f"{int(round(rep.get('rate', 0) * 100))}%{pend}")
            it.setData(Qt.ItemDataRole.UserRole, e["id"])
            self.hist_list.addItem(it)
        if not records.history():
            it = QListWidgetItem("还没有考过。导入一份试卷，或者从题库组一份。")
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.hist_list.addItem(it)

    def _open_hist(self, item):
        eid = item.data(Qt.ItemDataRole.UserRole)
        e = records.get(eid) if eid else None
        if e:
            self.exam = e
            self.show_report()

    def show_tab(self, key):
        self.seg.set_value(key)
        if key == "stats":
            self.refresh_stats()
            self.stack.setCurrentWidget(self.v_stats)
        else:
            self.refresh_home()
            self.stack.setCurrentWidget(self.v_home)
        self.status.setText("")

    def set_status(self, text, tone="muted"):
        self.status.setText(text)
        self.status.setStyleSheet(f"color:{getattr(T, tone)};font-size:12px;")

    # ------------------------------------------------------------ 导入
    def pick_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择试卷", "", "试卷 (*.pdf *.docx *.txt *.md *.png *.jpg *.jpeg *.bmp *.webp);;全部文件 (*)")
        if path:
            self.import_file(path)

    def import_file(self, path, sync=False):
        self.imp_note.setText("正在读取……扫描版和图片要识别文字，可能要十几秒。")
        name = os.path.splitext(os.path.basename(path))[0]

        def work():
            return paper.load_file(path)

        def done(res):
            text, how = res
            self.paste.setPlainText(text)
            self.split_paste(title=name, how=how)
        if sync:
            try:
                done(work())
            except Exception as exc:  # noqa: BLE001
                self.imp_note.setText(f"读不了这个文件：{exc}")
            return
        wk = Worker(work)
        wk.done.connect(done)
        wk.failed.connect(lambda m: self.imp_note.setText(f"读不了这个文件：{m}"))
        self.workers.append(wk)
        wk.start()

    def split_paste(self, title="", how=""):
        text = self.paste.toPlainText()
        if not text.strip():
            self.imp_note.setText("先粘贴试卷文字，或者选一个文件。")
            return
        subj = next((s for s in SUBJECTS if s in text[:200]), "")
        qs = paper.split_text(text, subj)
        if not qs:
            self.imp_note.setText("没认出题号。每题要以「1.」「2、」这样的题号开头。")
            return
        head = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
        title = title or (head[:30] if not re.match(r"^\s*\d", head) else "")
        keyed = sum(1 for q in qs if q["answer"])
        self.imp_note.setText(f"切出 {len(qs)} 题" + (f"，{keyed} 题有参考答案" if keyed else "，没有找到参考答案（AI 会自己解，离线时主观题自评）")
                              + (f"。来源：{how}" if how else ""))
        self.open_setup(paper.new_exam(qs, title, subj, source="import"))

    def compose(self):
        types = [t for t, c in self.b_types.items() if c.isChecked()] or list(self.b_types)
        if "单选" in types:
            types.append("多选")
        qs = paper.from_bank(self.b_subj.currentText(), self.b_count.value(), types)
        if not qs:
            self.set_status("题库里这一科没有这些题型的题", "bad")
            return
        self.open_setup(paper.new_exam(qs, f"{self.b_subj.currentText()}题库组卷", self.b_subj.currentText(), source="bank"))

    # ------------------------------------------------------------ 核对
    def _build_setup(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        h = QHBoxLayout()
        h.addWidget(_label("名称", "ctlLabel"))
        self.s_title = QLineEdit()
        self.s_title.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        h.addWidget(self.s_title, 2)
        h.addWidget(_label("科目", "ctlLabel"))
        self.s_subj = QComboBox()
        self.s_subj.addItems(SUBJECTS + ["综合"])
        h.addWidget(self.s_subj)
        h.addWidget(_label("时长（分钟）", "ctlLabel"))
        self.s_min = QSpinBox()
        self.s_min.setRange(1, 300)
        h.addWidget(self.s_min)
        self.s_full = _label("", "note")
        h.addWidget(self.s_full)
        v.addLayout(h)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.s_list = QListWidget()
        self.s_list.currentRowChanged.connect(self._pick_setup)
        split.addWidget(self.s_list)
        ed = QWidget()
        ev = QVBoxLayout(ed)
        ev.setContentsMargins(12, 0, 0, 0)
        ev.setSpacing(8)
        eh = QHBoxLayout()
        eh.addWidget(_label("题型", "ctlLabel"))
        self.e_type = QComboBox()
        self.e_type.addItems(list(paper.TYPES))
        self.e_type.currentTextChanged.connect(self._edit_q)
        eh.addWidget(self.e_type)
        eh.addWidget(_label("分值", "ctlLabel"))
        self.e_score = QDoubleSpinBox()
        self.e_score.setRange(0.5, 100)
        self.e_score.setSingleStep(1)
        self.e_score.setDecimals(1)
        self.e_score.valueChanged.connect(self._edit_q)
        eh.addWidget(self.e_score)
        eh.addStretch(1)
        eh.addWidget(_btn("并到上一题", self._merge_up, "", "切错了：把这题接到上一题后面"))
        eh.addWidget(_btn("删除", self._drop_q, "danger"))
        ev.addLayout(eh)
        ev.addWidget(_label("题干", "ctlLabel"))
        self.e_stem = QPlainTextEdit()
        self.e_stem.textChanged.connect(self._edit_q)
        ev.addWidget(self.e_stem, 3)
        ev.addWidget(_label("参考答案（可空：有 AI 时它自己解；离线时主观题自评）", "ctlLabel"))
        self.e_ans = QPlainTextEdit()
        self.e_ans.setMaximumHeight(90)
        self.e_ans.textChanged.connect(self._edit_q)
        ev.addWidget(self.e_ans, 1)
        split.addWidget(ed)
        split.setSizes([320, 700])
        v.addWidget(split, 1)
        fh = QHBoxLayout()
        fh.addWidget(_btn("返回", lambda: self.show_tab("exam"), "ghost"))
        fh.addStretch(1)
        fh.addWidget(_label("开始后计时，不能暂停；时间到自动交卷。", "note"))
        fh.addWidget(_btn("开始考试", self.start, "pri"))
        v.addLayout(fh)
        return w

    def open_setup(self, exam):
        self.exam = exam
        self.s_title.setText(exam["title"])
        i = self.s_subj.findText(exam["subject"])
        self.s_subj.setCurrentIndex(i if i >= 0 else self.s_subj.count() - 1)
        self.s_min.setValue(exam["minutes"])
        self._fill_setup(0)
        self.stack.setCurrentWidget(self.v_setup)
        self.set_status("核对切好的题：题型、分值、参考答案不对的改一下")

    def _fill_setup(self, row):
        self._filling = True
        self.s_list.clear()
        for q in self.exam["questions"]:
            stem = re.sub(r"\s+", " ", q["stem"])[:34]
            mark = "" if q.get("answer") else "　无答案"
            self.s_list.addItem(f"{q['no']}. [{q['type']} {paper._num(q['score'])}分] {stem}{mark}")
        self.exam["full"] = paper._num(sum(float(q["score"]) for q in self.exam["questions"]))
        self.s_full.setText(f"共 {len(self.exam['questions'])} 题 · 满分 {self.exam['full']}")
        self._filling = False
        if self.exam["questions"]:
            self.s_list.setCurrentRow(max(0, min(row, len(self.exam["questions"]) - 1)))

    def _pick_setup(self, row):
        if getattr(self, "_filling", False) or not self.exam or not 0 <= row < len(self.exam["questions"]):
            return
        q = self.exam["questions"][row]
        self._filling = True
        self.e_type.setCurrentText(q["type"])
        self.e_score.setValue(float(q["score"]))
        self.e_stem.setPlainText(q["stem"])
        self.e_ans.setPlainText(q.get("answer", ""))
        self._filling = False

    def _edit_q(self, *_a):
        row = self.s_list.currentRow()
        if getattr(self, "_filling", False) or not self.exam or not 0 <= row < len(self.exam["questions"]):
            return
        q = self.exam["questions"][row]
        old = (q["type"], q["score"], bool(q.get("answer")))
        q["type"], q["score"] = self.e_type.currentText(), paper._num(self.e_score.value())
        q["stem"], q["answer"] = self.e_stem.toPlainText(), self.e_ans.toPlainText().strip()
        if old != (q["type"], q["score"], bool(q["answer"])):
            self._fill_setup(row)

    def _merge_up(self):
        row = self.s_list.currentRow()
        qs = self.exam["questions"] if self.exam else []
        if row <= 0 or row >= len(qs):
            return
        prev, q = qs[row - 1], qs.pop(row)
        prev["stem"] = prev["stem"] + "\n" + f"{q['no']}. " + q["stem"]
        prev["score"] = paper._num(float(prev["score"]) + float(q["score"]))
        self._fill_setup(row - 1)

    def _drop_q(self):
        row = self.s_list.currentRow()
        if self.exam and 0 <= row < len(self.exam["questions"]) and len(self.exam["questions"]) > 1:
            self.exam["questions"].pop(row)
            self._fill_setup(row)

    def start(self):
        e = self.exam
        if not e or not e["questions"]:
            return
        e["title"] = self.s_title.text().strip() or e["title"]
        e["subject"] = self.s_subj.currentText()
        for q in e["questions"]:
            if not q.get("qid"):
                q["subject"] = e["subject"]
        e["minutes"] = self.s_min.value()
        e["full"] = paper._num(sum(float(q["score"]) for q in e["questions"]))
        e["started"] = time.time()
        e["answers"] = {}
        records.save_current(e)
        self.open_take(e)

    # ------------------------------------------------------------ 作答
    def _build_take(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        h = QHBoxLayout()
        self.t_title = _label("", "takeTitle")
        h.addWidget(self.t_title)
        h.addStretch(1)
        self.t_done = _label("", "note")
        h.addWidget(self.t_done)
        h.addSpacing(12)
        self.t_clock = _label("00:00", "examClock")
        self.t_clock.setToolTip("剩余时间")
        h.addWidget(self.t_clock)
        h.addSpacing(12)
        h.addWidget(_btn("交卷", self.submit_ask, "pri"))
        v.addLayout(h)
        self.t_confirm = QFrame()
        self.t_confirm.setObjectName("examCard")
        ch = QHBoxLayout(self.t_confirm)
        ch.setContentsMargins(14, 8, 14, 8)
        self.t_confirm_text = _label("", wrap=True)
        ch.addWidget(self.t_confirm_text, 1)
        ch.addWidget(_btn("再看看", lambda: self.t_confirm.hide(), "ghost"))
        ch.addWidget(_btn("确定交卷", self.submit, "pri"))
        self.t_confirm.hide()
        v.addWidget(self.t_confirm)
        body = QHBoxLayout()
        body.setSpacing(14)
        self.nav = QNav()
        self.nav.setFixedWidth(160)
        self.nav.picked.connect(self.go)
        navbox = QVBoxLayout()
        navbox.addWidget(_label("题号", "grpTitle"))
        navbox.addWidget(self.nav)
        navbox.addStretch(1)
        body.addLayout(navbox)
        main = QVBoxLayout()
        main.setSpacing(8)
        self.t_head = _label("", "grpTitle")
        main.addWidget(self.t_head)
        self.t_stem = QTextBrowser()
        self.t_stem.setObjectName("examStem")
        self.t_stem.setOpenLinks(False)
        main.addWidget(self.t_stem, 2)
        ah = QHBoxLayout()
        ah.addWidget(_label("作答", "grpTitle"))
        self.t_mode = Segmented([("type", "打字"), ("ink", "手写")], "type")
        self.t_mode.changed.connect(self._set_mode)
        ah.addWidget(self.t_mode)
        self.t_hint = _label("", "note")
        ah.addWidget(self.t_hint, 1)
        main.addLayout(ah)
        self.t_input = QStackedWidget()
        self.t_text = QPlainTextEdit()
        self.t_text.setObjectName("examAnswer")
        self.t_text.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.t_text.textChanged.connect(self._typed)
        self.t_input.addWidget(self.t_text)
        self.t_inkholder = QStackedWidget()
        self.t_input.addWidget(self.t_inkholder)
        main.addWidget(self.t_input, 3)
        nh = QHBoxLayout()
        self.t_prev = _btn("上一题", lambda: self.go(self.cur - 1))
        self.t_next = _btn("下一题", lambda: self.go(self.cur + 1))
        nh.addWidget(self.t_prev)
        nh.addStretch(1)
        nh.addWidget(self.t_next)
        main.addLayout(nh)
        body.addLayout(main, 1)
        v.addLayout(body, 1)
        return w

    def open_take(self, exam):
        self.exam = exam
        for box in self.pads.values():
            box.setParent(None)
            box.deleteLater()
        self.pads = {}
        self.t_title.setText(exam["title"])
        self.seg.hide()
        self.stack.setCurrentWidget(self.v_take)
        self.t_confirm.hide()
        self.set_status("")
        self.go(0)
        self._tick()
        self.tick.start()

    def _ans(self, q):
        return self.exam["answers"].setdefault(str(q["no"]), dict(text="", ink=False, strokes=[]))

    def _pad(self, q):
        no = q["no"]
        if no not in self.pads:
            a = self.exam["answers"].get(str(no)) or {}
            box = InkBox(a.get("strokes") or [])
            box.changed.connect(lambda n=no: self._inked(n))
            self.pads[no] = box
            self.t_inkholder.addWidget(box)
        return self.pads[no]

    def go(self, i):
        if not self.exam:
            return
        qs = self.exam["questions"]
        i = max(0, min(len(qs) - 1, i))
        self.cur = i
        q = qs[i]
        a = self.exam["answers"].get(str(q["no"])) or {}
        self.t_head.setText(f"第 {q['no']} 题 · {q['type']} · {paper._num(q['score'])} 分")
        self.t_stem.setHtml(f"<div style='font-size:15px;line-height:160%'>{rich(q['stem'])}</div>")
        self.t_text.blockSignals(True)
        self.t_text.setPlainText(a.get("text", ""))
        self.t_text.blockSignals(False)
        self.t_text.setPlaceholderText("写选项字母（如 B 或 AC）" if q["type"] in paper.OBJECTIVE
                                       else "写答案；推导多的题可以切到「手写」" if q["type"] == "解答" else "写答案")
        box = self._pad(q)
        self.t_inkholder.setCurrentWidget(box)
        mode = "ink" if (a.get("strokes") and not a.get("text")) or (q["type"] == "解答" and not a.get("text") and a.get("mode") != "type") else "type"
        self._set_mode(a.get("mode") or mode, save=False)
        self.t_prev.setEnabled(i > 0)
        self.t_next.setEnabled(i < len(qs) - 1)
        self._sync_nav()

    def _set_mode(self, mode, save=True):
        self.t_mode.set_value(mode)
        self.t_input.setCurrentIndex(1 if mode == "ink" else 0)
        self.t_hint.setText("数位板有压感；笔尾或右键擦除。打字和手写可以都写，一起交" if mode == "ink" else "")
        if save and self.exam:
            self._ans(self.exam["questions"][self.cur])["mode"] = mode
            self.saver.start()

    def _typed(self):
        if not self.exam:
            return
        self._ans(self.exam["questions"][self.cur])["text"] = self.t_text.toPlainText()
        self._sync_nav()
        self.saver.start()

    def _inked(self, no):
        q = next(q for q in self.exam["questions"] if q["no"] == no)
        a = self._ans(q)
        a["strokes"] = list(self.pads[no].pad.strokes)
        a["ink"] = bool(a["strokes"])
        self._sync_nav()
        self.saver.start()

    def _answered(self, q):
        a = self.exam["answers"].get(str(q["no"])) or {}
        return bool(str(a.get("text") or "").strip() or a.get("strokes"))

    def _sync_nav(self):
        qs = self.exam["questions"]
        self.nav.set_state([(q["no"], self._answered(q)) for q in qs], self.cur)
        self.t_done.setText(f"已答 {sum(self._answered(q) for q in qs)}/{len(qs)}")

    def _save_current(self):
        if self.exam and not self.exam.get("submitted") and self.exam.get("started"):
            records.save_current(self.exam)

    def _tick(self):
        if not self.exam or self.exam.get("submitted"):
            self.tick.stop()
            return
        left = records.time_left(self.exam)
        self.t_clock.setText(mmss(left))
        self.t_clock.setStyleSheet(f"color:{T.bad if left <= 300 else T.fg};")
        if left <= 0:
            self.tick.stop()
            self.submit(auto=True)

    def submit_ask(self):
        qs = self.exam["questions"]
        blank = [str(q["no"]) for q in qs if not self._answered(q)]
        self.t_confirm_text.setText(("还有 " + "、".join(blank[:12]) + (" 等" if len(blank) > 12 else "") + f" 共 {len(blank)} 题没答。" if blank else "都答了。")
                                    + f"剩余 {mmss(records.time_left(self.exam))}，确定交卷？")
        self.t_confirm.show()

    def submit(self, auto=False):
        e = self.exam
        if not e or e.get("submitted"):
            return
        self.tick.stop()
        self.saver.stop()
        e["submitted"] = time.time()
        e["used"] = round(max(0.0, min(e["minutes"] * 60.0, e["submitted"] - (e.get("started") or e["submitted"]))), 1)
        images = {}
        folder = None
        for q in e["questions"]:
            a = e["answers"].get(str(q["no"])) or {}
            if a.get("strokes"):
                pad = self.pads[q["no"]].pad if q["no"] in self.pads else InkPad(a["strokes"])
                im = pad.render_image()
                if not im.isNull():
                    folder = folder or records.ink_dir(e["id"])
                    path = folder / f"q{q['no']}.png"
                    im.save(str(path))
                    a["ink_file"] = str(path)
                    a["ink"] = True
                    images[q["no"]] = im
        records.save_current(e)
        self.t_confirm.hide()
        self.seg.show()
        self.show_report(grading=True)
        self.set_status(("时间到，已自动交卷。" if auto else "已交卷。") + "正在评分……")
        grader = self.grader or (lambda ex, ims: grade_exam(ex, ims, None))
        snapshot = dict(e, answers={k: dict(v) for k, v in e["answers"].items()})

        def done(res):
            rep, note = res
            self.finish_grading(rep, note)
        wk = Worker(lambda: grader(snapshot, images))
        wk.done.connect(done)
        wk.failed.connect(lambda m: self.finish_grading(grade.offline(e), f"评分出错（{m}），已改用离线判分"))
        self.workers.append(wk)
        if self.grader is not None and getattr(self.grader, "sync", False):
            done(grader(snapshot, images))
        else:
            wk.start()

    def finish_grading(self, rep, note):
        e = self.exam
        e["report"] = rep
        e["grade_note"] = note
        for a in e["answers"].values():
            a.pop("strokes", None)        # 笔迹已经存成图片，记录里不再放一大串坐标
        records.upsert(e)
        records.clear_current()
        records.record_learning(e)
        self.show_report()
        self.set_status(note, "muted")
        self.changed.emit()

    def resume(self):
        cur = records.current()
        if not cur:
            self.refresh_home()
            return
        self.open_take(cur)
        if records.time_left(cur) <= 0:
            self.submit(auto=True)

    def abandon(self):
        records.clear_current()
        self.refresh_home()

    # ------------------------------------------------------------ 报告
    def _build_report(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        head, hv = _card()
        hh = QHBoxLayout()
        self.r_score = _label("", "bigScore")
        hh.addWidget(self.r_score)
        hh.addSpacing(16)
        col = QVBoxLayout()
        self.r_title = _label("", "cardTitle")
        self.r_meta = _label("", "note", True)
        col.addWidget(self.r_title)
        col.addWidget(self.r_meta)
        hh.addLayout(col, 1)
        hv.addLayout(hh)
        self.r_summary = _label("", wrap=True)
        self.r_summary.setObjectName("summary")
        hv.addWidget(self.r_summary)
        v.addWidget(head)
        self.r_scroll = QScrollArea()
        self.r_scroll.setWidgetResizable(True)
        self.r_body = QWidget()
        self.r_rows = QVBoxLayout(self.r_body)
        self.r_rows.setContentsMargins(0, 0, 6, 0)
        self.r_rows.setSpacing(8)
        self.r_scroll.setWidget(self.r_body)
        v.addWidget(self.r_scroll, 1)
        fh = QHBoxLayout()
        fh.addWidget(_btn("删除这次记录", self.delete_report, "danger"))
        fh.addStretch(1)
        fh.addWidget(_btn("返回", lambda: self.show_tab("exam"), "ghost"))
        fh.addWidget(_btn("问 AI", self.ask_ai, "", "把这次考试的错题和评语带进 AI 聊天：讲错题、出同类题"))
        fh.addWidget(_btn("看考情", lambda: self.show_tab("stats"), "pri"))
        v.addLayout(fh)
        return w

    def show_report(self, grading=False):
        e = self.exam
        self.stack.setCurrentWidget(self.v_report)
        self.seg.show()
        while self.r_rows.count():
            it = self.r_rows.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self.r_title.setText(e["title"])
        if grading or not e.get("report"):
            self.r_score.setText("…")
            self.r_meta.setText(f"用时 {mmss(e.get('used', 0))} / {e['minutes']} 分钟")
            self.r_summary.setText("正在评分。手写作答会先识别成文字再评。")
            return
        rep = e["report"]
        self.r_score.setText(f"{paper._num(rep['total'])}<span style='font-size:16px;color:{T.muted}'> / {paper._num(rep['full'])}</span>")
        self.r_score.setTextFormat(Qt.TextFormat.RichText)
        eng = f"{ai_name()} 评分" if rep["engine"] == "ai" else "离线判分"
        self.r_meta.setText(f"得分率 {int(round(rep['rate'] * 100))}% · 用时 {mmss(e.get('used', 0))} / {e['minutes']} 分钟 · {eng}"
                            + (f" · {rep['pending']} 题待自评" if rep.get("pending") else "")
                            + (f"\n{e['grade_note']}" if e.get("grade_note") and rep["engine"] != "ai" else ""))
        self.r_summary.setText(rep.get("summary", ""))
        qmap = {q["no"]: q for q in e["questions"]}
        for it in rep["items"]:
            self.r_rows.addWidget(self._report_row(e, qmap.get(it["no"], {}), it))
        self.r_rows.addStretch(1)

    def _report_row(self, e, q, it):
        f, v = _card()
        f.setObjectName("examRow")
        h = QHBoxLayout()
        tone = dict(right="ok", partial="warn", wrong="bad", blank="bad", self="accent")[it["status"]]
        st = _label(STATUS_TEXT[it["status"]])
        st.setStyleSheet(f"color:{getattr(T, tone)};font-weight:700;border:1px solid {css(getattr(T, tone), .5)};border-radius:4px;padding:1px 6px;")
        h.addWidget(st)
        h.addWidget(_label(f"第 {it['no']} 题 · {q.get('type', '')}", "cardTitle"))
        h.addWidget(_label(f"{paper._num(it['score'])} / {paper._num(it['full'])} 分", "ctlValue"))
        if it.get("cause"):
            h.addWidget(_label("错因：" + it["cause"], "note"))
        h.addStretch(1)
        h.addWidget(_label(it.get("how", ""), "note"))
        if it["status"] == "self" or it.get("how") == "自评":
            spin = QDoubleSpinBox()
            spin.setRange(0, float(it["full"]))
            spin.setSingleStep(0.5)
            spin.setDecimals(1)
            spin.setValue(float(it["score"]))
            h.addWidget(spin)
            h.addWidget(_btn("给分", lambda n=it["no"], s=spin: self.self_score(n, s.value())))
        v.addLayout(h)
        stem = re.sub(r"\s+", " ", q.get("stem", ""))
        body = [f"<span style='color:{T.muted}'>{html.escape(stem[:120])}{'…' if len(stem) > 120 else ''}</span>"]
        a = e["answers"].get(str(it["no"])) or {}
        mine = str(a.get("text") or "").strip()
        if mine:
            body.append(f"<b>我的作答</b>　{html.escape(mine[:300])}")
        if it.get("ink"):
            body.append(f"<b>手写识别</b>　{html.escape(it['ink'][:300])}")
        if q.get("answer"):
            body.append(f"<b>参考答案</b>　{rich(q['answer'][:400])}")
        if it.get("comment"):
            body.append(f"<span style='color:{T.accent}'>{html.escape(it['comment'])}</span>")
        if it.get("points"):
            body.append(f"<span style='color:{T.faint}'>知识点：{html.escape('、'.join(it['points']))}</span>")
        t = _label("".join(f"<p style='margin:0 0 4px 0;line-height:150%'>{b}</p>" for b in body), wrap=True)
        t.setTextFormat(Qt.TextFormat.RichText)
        v.addWidget(t)
        if a.get("ink_file") and os.path.exists(a["ink_file"]):
            pm = QPixmap(a["ink_file"])
            if not pm.isNull():
                img = QLabel()
                img.setPixmap(pm.scaledToHeight(min(140, pm.height()), Qt.TransformationMode.SmoothTransformation))
                img.setToolTip("手写作答")
                v.addWidget(img)
        return f

    def self_score(self, no, score):
        e = self.exam
        e["report"] = grade.set_self_score(e["report"], no, score)
        records.upsert(e)
        self.show_report()
        self.set_status(f"第 {no} 题记 {paper._num(score)} 分")
        self.changed.emit()

    def ask_ai(self):
        """把这次考试里没拿满分的题（题干、我的作答、参考答案、评语）交给 AI 聊天。"""
        e = self.exam
        if not e or not e.get("report"):
            return
        qmap = {q["no"]: q for q in e["questions"]}
        rows = []
        for it in e["report"]["items"]:
            if it["status"] == "right":
                continue
            q = qmap.get(it["no"], {})
            a = e["answers"].get(str(it["no"])) or {}
            rows.append(f"第 {it['no']} 题（{q.get('type', '')}，{it['score']}/{it['full']} 分，错因：{it.get('cause') or '未判'}）\n"
                        f"题干：{q.get('stem', '')}\n我的作答：{a.get('text') or it.get('ink') or '（手写或未答）'}\n"
                        f"参考答案：{q.get('answer') or '（缺）'}\n评语：{it.get('comment', '')}")
        from ..chat import bridge
        from ..chat.core import text_attachment
        bridge.ask(self, [text_attachment("\n\n".join(rows) or "这次全对。", f"{e['title']}的错题", "text")],
                   "帮我逐题讲这次考试的错题，指出该怎么想，再各出一道同类题。")

    def delete_report(self):
        if self.exam:
            records.delete(self.exam["id"])
            self.exam = None
            self.changed.emit()
        self.show_tab("exam")

    # ------------------------------------------------------------ 考情
    def _build_stats(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 6, 0)
        v.setSpacing(12)
        self.k_head = QHBoxLayout()
        self.k_tiles = []
        for _ in range(4):
            f, fv = _card()
            big, small = _label("", "tileBig"), _label("", "note")
            fv.addWidget(big)
            fv.addWidget(small)
            self.k_tiles.append((big, small))
            self.k_head.addWidget(f, 1)
        v.addLayout(self.k_head)
        row = QHBoxLayout()
        row.setSpacing(12)
        tc, tv = _card()
        tv.addWidget(_label("历次考试得分率", "cardTitle"))
        self.k_trend = Trend()
        tv.addWidget(self.k_trend)
        row.addWidget(tc, 3)
        cc, cv = _card()
        cv.addWidget(_label("错因分布", "cardTitle"))
        self.k_causes = Bars(color="bad")
        cv.addWidget(self.k_causes)
        cv.addStretch(1)
        row.addWidget(cc, 2)
        v.addLayout(row)
        sc, sv = _card()
        sv.addWidget(_label("各科", "cardTitle"))
        sv.addWidget(_label("考试得分率按分值算；习题台正确率只算程序判过对错的题（选择、数值答案）。", "note", True))
        self.k_subj = QGridLayout()
        self.k_subj.setHorizontalSpacing(18)
        self.k_subj.setVerticalSpacing(6)
        sv.addLayout(self.k_subj)
        v.addWidget(sc)
        wc, wv = _card()
        wh = QHBoxLayout()
        wh.addWidget(_label("薄弱点", "cardTitle"))
        wh.addWidget(_label(f"得分率低于 {int(records.WEAK_RATE * 100)}% 的知识点，按得分率从低到高", "note"))
        wh.addStretch(1)
        self.k_review = _btn("开始复习", self.open_review, "", "打开间隔复习，做今天到期的项目")
        wh.addWidget(self.k_review)
        self.k_aiplan = _btn("AI 排计划", self.open_aiplan, "", "按这些考情、背诵、专注记录和目标排一周计划；预览确认后才写进计划")
        wh.addWidget(self.k_aiplan)
        self.k_add = _btn("加入复习", self.add_weak, "pri", "勾选的薄弱点各做一张知识卡，并把相关题目排进今天的复习")
        wh.addWidget(self.k_add)
        wv.addLayout(wh)
        self.k_weak = QVBoxLayout()
        self.k_weak.setSpacing(6)
        wv.addLayout(self.k_weak)
        v.addWidget(wc)
        fc, fv = _card()
        fv.addWidget(_label("专注（近七天）", "cardTitle"))
        self.k_focus = _label("", "note", True)
        fv.addWidget(self.k_focus)
        self.k_focus_days = Bars(color="accent")
        fv.addWidget(self.k_focus_days)
        v.addWidget(fc)
        pc, pv = _card()
        pv.addWidget(_label("知识点得分率（全部）", "cardTitle"))
        self.k_points = Bars(color="rate")
        pv.addWidget(self.k_points)
        v.addWidget(pc)
        v.addStretch(1)
        scroll.setWidget(w)
        return scroll

    @staticmethod
    def _clear(lay):
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                ExamPage._clear(it.layout())

    def refresh_stats(self):
        st = records.analyze()
        self.stats = st
        ex = st["exams"]
        rates = [r["rate"] for r in ex]
        prac_n = sum(s["practice_n"] for s in st["subjects"].values())
        prac_r = sum(s["practice_right"] for s in st["subjects"].values())
        tm = st["time"]
        tiles = [(str(len(ex)), "次考试"),
                 (f"{int(round(sum(rates) / len(rates) * 100))}%" if rates else "—", "考试平均得分率"),
                 (f"{int(round(prac_r / prac_n * 100))}%" if prac_n else "—", f"习题台正确率（{prac_n} 题）"),
                 (f"{int(tm['exam_used'] // 60)} 分钟", f"考试用时 · 习题台 {int(tm['practice_seconds'] // 60)} 分钟 / {tm['practice_days']} 天")]
        for (big, small), (a, b) in zip(self.k_tiles, tiles):
            big.setText(a)
            small.setText(b)
        self.k_trend.set_data(rates, [r["day"] for r in ex])
        total = sum(st["causes"].values()) or 1
        self.k_causes.set_rows([(k, n / total, f"{n} 次") for k, n in sorted(st["causes"].items(), key=lambda t: -t[1])])
        self._clear(self.k_subj)
        for c, t in enumerate(("科目", "考试得分率", "习题台正确率", "考试趋势")):
            self.k_subj.addWidget(_label(t, "grpTitle"), 0, c)
        subs = sorted(st["subjects"].items(), key=lambda t: (t[1]["exam_rate"] is None, t[1]["exam_rate"] or 0))
        for r, (name, s) in enumerate(subs, 1):
            self.k_subj.addWidget(_label(name), r, 0)
            self.k_subj.addWidget(_label(f"{int(round(s['exam_rate'] * 100))}%" if s["exam_rate"] is not None else "—", "ctlValue"), r, 1)
            self.k_subj.addWidget(_label(f"{int(round(s['practice_rate'] * 100))}%（{s['practice_n']}）" if s["practice_rate"] is not None else "—", "ctlValue"), r, 2)
            self.k_subj.addWidget(Spark(s["trend"]), r, 3)
        if not subs:
            self.k_subj.addWidget(_label("还没有数据：考一次试，或在习题台做几道题。", "note"), 1, 0, 1, 4)
        self._clear(self.k_weak)
        self.weak_checks = []
        for wp in st["weak"]:
            line = QHBoxLayout()
            c = QCheckBox(wp["point"])
            c.setChecked(True)
            self.weak_checks.append((c, wp))
            line.addWidget(c)
            line.addWidget(_label(wp["subject"], "note"))
            line.addWidget(_label(f"{int(round(wp['rate'] * 100))}% · {wp['n']} 次", "ctlValue"))
            sug = records.suggest(wp, 2)
            tip = ("建议复习：" + "、".join(q.get("title", "") for q in sug)) if sug else (wp["notes"][0] if wp.get("notes") else "")
            line.addWidget(_label(tip, "note"), 1)
            line.setContentsMargins(0, 0, 0, 0)
            holder = QWidget()
            holder.setLayout(line)
            self.k_weak.addWidget(holder)
        if not st["weak"]:
            self.k_weak.addWidget(_label("没有明显的薄弱点。" if st["points"] else "考过试、做过题之后，这里列出得分率低的知识点。", "note"))
        self.k_add.setEnabled(bool(st["weak"]))
        self.k_points.set_rows([(p["point"][:7], p["rate"], f"{int(round(p['rate'] * 100))}%") for p in st["points"][:14]])
        try:
            from ..focus import core as focus_core
            fs = focus_core.summary(7)
            t = fs["total"]
            self.focus_summary = fs
            subj = "、".join(f"{k} {int(v)} 分钟" for k, v in sorted(fs["subjects"].items(), key=lambda x: -x[1])[:4])
            self.k_focus.setText(f"专注 {int(t['focus_min'])} 分钟，完成 {t['done']}/{t['started']} 个番茄"
                                 + (f"（{int(t['rate'] * 100)}%）" if t["rate"] is not None else "") + f"，中断 {t['interruptions']} 次"
                                 + (f"；计划完成 {t['plan_done']}/{t['plan_total']} 块" if t["plan_total"] else "") + "。"
                                 + (f"\n各科：{subj}。" if subj else "") + self._plan_review_text())
            mx = max([r["focus_min"] for r in fs["days"]] + [1])
            self.k_focus_days.set_rows([(r["day"][5:], r["focus_min"] / mx, f"{int(r['focus_min'])} 分") for r in fs["days"]])
        except Exception:  # noqa: BLE001
            self.k_focus.setText("专注记录暂时读不到。")

    def open_aiplan(self, request=""):
        from ..focus.aiplan_page import open_dialog
        self.aiplan_dlg = open_dialog(self.window(), request)
        return self.aiplan_dlg

    @staticmethod
    def _plan_review_text() -> str:
        """考情里的计划复盘：本周计划 vs 实际、偏差最大的科目、最近写的复盘。"""
        try:
            from datetime import date as _date
            from ..focus import plan as fplan
            rv = fplan.review("week", _date.today())
            if not rv["n"] and not rv["actual"]:
                return ""
            s = f"\n本周计划 {int(rv['planned'])} 分钟、实际专注 {int(rv['actual'])} 分钟；{rv['observe']}"
            txt = rv["text"] or next((v.get("text") for k, v in sorted(fplan._load()["reviews"].items(), reverse=True) if v.get("text")), "")
            return s + (f"\n最近的复盘：{txt}" if txt else "")
        except Exception:  # noqa: BLE001
            return ""

    def add_weak(self):
        chosen = [wp for c, wp in getattr(self, "weak_checks", []) if c.isChecked()]
        if not chosen:
            self.set_status("先勾选要复习的薄弱点")
            return
        try:
            n = records.add_to_review(chosen)
        except Exception as exc:  # noqa: BLE001
            self.set_status(f"加入复习失败：{exc}", "bad")
            return
        self.set_status(f"已加入复习：{len(chosen)} 个知识点，新增 {n} 项，今天就能复习" if n else "这些已经在今天的复习里了", "ok")

    def open_review(self):
        try:
            from ..learning_ui import Review
            Review(self).exec()
        except Exception as exc:  # noqa: BLE001
            self.set_status(f"打不开复习：{exc}", "bad")

    # ------------------------------------------------------------ 外观 / 生命周期
    def showEvent(self, e):  # noqa: N802
        super().showEvent(e)
        if self.exam and self.stack.currentWidget() is self.v_take and not self.exam.get("submitted"):
            self.tick.start()
            self._tick()
        elif self.stack.currentWidget() is self.v_home:
            self.refresh_home()

    def hideEvent(self, e):  # noqa: N802
        super().hideEvent(e)
        self.tick.stop()            # 看不见不跑定时器；回来时按墙上时钟重算
        self._save_current()

    def shutdown(self):
        self._save_current()
        for wk in list(self.workers):
            if wk.isRunning():
                wk.wait(3000)

    def apply_theme(self):
        self.setStyleSheet(qss() + f"""
QWidget#examPage {{ background:{"transparent" if self.compact else T.bg}; color:{T.fg}; }}
QLabel#examTitle {{ color:{T.fg}; font-size:20px; font-weight:700; padding-right:6px; }}
QLabel#examStatus {{ font-size:12px; padding-left:8px; color:{T.muted}; }}
QFrame#examCard, QFrame#examRow {{ background:{T.surface}; border:1px solid {T.line}; border-radius:10px; }}
QLabel#cardTitle {{ color:{T.fg}; font-size:14px; font-weight:700; }}
QLabel#takeTitle {{ color:{T.fg}; font-size:16px; font-weight:700; }}
QLabel#examClock {{ font-family:"{font(12, kind='mono').family()}"; font-size:24px; font-weight:700; }}
QLabel#bigScore {{ color:{T.accent}; font-size:40px; font-weight:700; }}
QLabel#tileBig {{ color:{T.fg}; font-size:24px; font-weight:700; }}
QLabel#summary {{ color:{T.soft}; font-size:13px; }}
QTextBrowser#examStem {{ background:{T.raised}; color:{T.fg}; border:1px solid {T.line}; border-radius:10px; padding:10px 14px; }}
QPlainTextEdit#examAnswer {{ font-size:15px; }}
""")
        for w in self.findChildren(QWidget):
            if isinstance(w, (Bars, Trend, Spark, QNav, InkPad, Segmented)):
                w.update()

    def sizeHint(self):  # noqa: N802
        return QSize(1100, 760)
