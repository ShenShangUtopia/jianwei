"""试卷：从文字切题、读 PDF / Word / 图片、从题库组卷。全是普通函数（读图除外不碰界面）。

切题规则（够用、可预期，不靠 AI）：
- 「一、选择题」这类大题标题决定后面小题的题型和默认分值（「每小题 5 分」）；
- 行首「1.」「1、」「1．」「第1题」开始新题，题号必须比上一题大（防止把 2.5 这样的数当题号）；
- 「(1)」「（2）」是小问，留在本题里；A. B. C. D. 选项也留在本题里；
- 题干里的「（12 分）」是这题的分值；
- 「参考答案」「答案」之后的部分按题号拆成答案表，填回各题。
"""
from __future__ import annotations

import random
import re
import time
import unicodedata
import uuid
import zipfile
from pathlib import Path

CN_NUM = "一二三四五六七八九十"
TYPES = ("单选", "多选", "填空", "解答")
DEFAULT_SCORE = {"单选": 5, "多选": 6, "填空": 5, "解答": 12}
OBJECTIVE = ("单选", "多选")

_SECTION = re.compile(r"^\s*(?:第?[一二三四五六七八九十]+\s*[、.．部分]|[ⅠⅡⅢⅣⅤ]+\s*[、.．])\s*(.{0,40})$")
_QSTART = re.compile(r"^\s*(?:第\s*(\d{1,3})\s*题[\s:：.．、]*|(\d{1,3})\s*[.．、](?![\d])\s*|(\d{1,3})\s*[)）]\s+)")
_SCORE = re.compile(r"[（(]\s*(?:本(?:小)?题)?(?:满分)?\s*(\d{1,2}(?:\.\d)?)\s*分\s*[)）]")
_EACH = re.compile(r"每(?:小)?题\s*(\d{1,2}(?:\.\d)?)\s*分")
_KEY_HEAD = re.compile(r"^\s*(?:[【\[]?\s*(?:参考)?答案(?:与|及)?(?:解析|详解)?\s*[】\]]?|答案速查|参考答案)\s*[:：]?\s*$")
_OPTION = re.compile(r"(?:^|\s)([A-D])\s*[.．、:：]")


def _clean(text: str) -> str:
    # 只把全角数字、字母换成半角（题号、选项要认）；中文标点保持原样
    text = "".join(unicodedata.normalize("NFKC", ch) if ("０" <= ch <= "９" or "Ａ" <= ch <= "Ｚ" or "ａ" <= ch <= "ｚ") else ch
                   for ch in str(text or "")).replace("\r\n", "\n").replace("\r", "\n")
    try:
        from ..lecture.pageview import clean_text
        text = clean_text(text)
    except Exception:   # noqa: BLE001  没有 Qt 也能切题
        pass
    text = text.replace("　", " ").replace("\xa0", " ")
    return re.sub(r"[ \t]+\n", "\n", text)


def _section_type(title: str):
    t = title or ""
    if "多选" in t or "多项" in t:
        return "多选"
    if "选择" in t or "单选" in t or "单项" in t:
        return "单选"
    if "填空" in t:
        return "填空"
    if any(k in t for k in ("解答", "计算", "简答", "论述", "实验", "材料", "综合", "非选择", "作文", "写作", "阅读")):
        return "解答"
    return None


def guess_type(stem: str, section=None) -> str:
    if section:
        return section
    letters = {m.group(1) for m in _OPTION.finditer(stem)}
    if len(letters) >= 3:
        return "多选" if re.search(r"多选|多项|不定项", stem) else "单选"
    if re.search(r"_{3,}|＿{2,}|\(\s*\)\s*[。.]?$", stem):
        return "填空"
    return "解答"


def _parse_key(lines) -> dict:
    """答案表：「1.A 2.C 3.BD」或一行一题「13. 2√3」「17. 解：……」（多行接在上一题后面）。"""
    out: dict[int, str] = {}
    cur = None
    body = "\n".join(lines)
    inline = re.findall(r"(\d{1,3})\s*[.．、:：]\s*([A-G]{1,4})(?=\s|$|[,，;；])", body)
    if len(inline) >= 3 and all(len(x[1]) <= 4 for x in inline):
        for n, a in inline:
            out.setdefault(int(n), a)
    for line in lines:
        m = re.match(r"^\s*(\d{1,3})\s*[.．、:：)）]\s*(.*)$", line)
        if m and (cur is None or int(m.group(1)) > cur):
            cur = int(m.group(1))
            if cur not in out:
                out[cur] = m.group(2).strip()
        elif cur is not None and line.strip():
            if not re.fullmatch(r"[A-G]{1,4}", out.get(cur, "")):
                out[cur] = (out.get(cur, "") + "\n" + line.strip()).strip()
    return {k: v.strip() for k, v in out.items() if v.strip()}


def split_text(text: str, subject: str = "") -> list[dict]:
    """把一份试卷的文字切成题目列表。每题：no、stem、type、score、answer、points。"""
    lines = _clean(text).split("\n")
    key_at = next((i for i, ln in enumerate(lines) if _KEY_HEAD.match(ln)), None)
    key = _parse_key(lines[key_at + 1:]) if key_at is not None else {}
    if key_at is not None:
        lines = lines[:key_at]
    qs: list[dict] = []
    section, each, last = None, None, 0
    cur = None
    for raw in lines:
        line = raw.rstrip()
        if not line.strip():
            if cur is not None:
                cur["lines"].append("")
            continue
        sm = _SECTION.match(line)
        if sm and (_section_type(sm.group(1)) or _EACH.search(line)):
            section = _section_type(sm.group(1)) or section
            e = _EACH.search(line)
            each = float(e.group(1)) if e else None
            cur = None
            continue
        m = _QSTART.match(line)
        n = int(next(g for g in m.groups() if g)) if m else None
        if m and n > last and (n <= last + 3 or not qs):
            cur = dict(no=n, lines=[line[m.end():].strip()], section=section, each=each)
            qs.append(cur)
            last = n
            continue
        if cur is not None:
            cur["lines"].append(line.strip())
    out = []
    for q in qs:
        stem = re.sub(r"\n{3,}", "\n\n", "\n".join(q["lines"])).strip()
        if not stem:
            continue
        typ = guess_type(stem, q["section"])
        sm = _SCORE.search(stem[:80]) or _SCORE.search(stem)
        score = float(sm.group(1)) if sm else (q["each"] or DEFAULT_SCORE[typ])
        out.append(dict(no=q["no"], stem=stem, type=typ, score=_num(score), answer=key.get(q["no"], ""),
                        points=[], qid="", subject=subject))
    return out


def _num(x):
    x = float(x)
    return int(x) if x == int(x) else round(x, 1)


# ---------------------------------------------------------------- 文件
def read_docx(path) -> str:
    """直接读 document.xml 的段落文字（不经 Word / WPS）。公式对象取不出来时留「[公式]」。"""
    import xml.etree.ElementTree as ET
    ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    paras = []
    counters: dict[tuple, int] = {}
    for p in root.iter(ns + "p"):
        bits = []
        num = p.find(f"{ns}pPr/{ns}numPr")
        if num is not None:
            # 自动编号的题号不在文字里：按编号列表补上（第一级「1.」，第二级「(1)」）
            nid = num.find(ns + "numId")
            lvl = num.find(ns + "ilvl")
            nid = nid.get(ns + "val") if nid is not None else "0"
            lvl = int(lvl.get(ns + "val")) if lvl is not None else 0
            key = (nid, lvl)
            counters[key] = counters.get(key, 0) + 1
            for k in [k for k in counters if k[0] == nid and k[1] > lvl]:
                counters.pop(k)
            bits.append(f"{counters[key]}. " if lvl == 0 else f"({counters[key]}) ")
        for el in p.iter():
            tag = el.tag
            if tag == ns + "t" and el.text:
                bits.append(el.text)
            elif tag == ns + "tab":
                bits.append(" ")
            elif tag == ns + "br":
                bits.append("\n")
            elif tag.endswith("}oMath"):
                txt = "".join(t.text or "" for t in el.iter() if t.tag.endswith("}t"))
                bits.append(txt or "[公式]")
        paras.append("".join(bits))
    return "\n".join(paras)


def read_pdf(path, ocr=None, max_pages=24) -> tuple[str, list]:
    """PDF 的文字层；扫描版（几乎没字）返回每页图像，交给识图。返回 (文字, 没有文字的页图像)。"""
    from PySide6.QtCore import QSize
    from PySide6.QtPdf import QPdfDocument
    from ..lecture.pageview import page_text
    doc = QPdfDocument()
    doc.load(str(path))
    texts, images = [], []
    try:
        for i in range(min(doc.pageCount(), max_pages)):
            t = page_text(doc, i)
            if len(t.strip()) >= 8:          # 少于 8 个字才当扫描页（页眉页码那几个字不算正文）
                texts.append(t)
            else:
                sz = doc.pagePointSize(i)
                k = 1800 / max(1.0, max(sz.width(), sz.height()))
                images.append(doc.render(i, QSize(int(sz.width() * k), int(sz.height() * k))))
    finally:
        doc.close()
    return "\n".join(texts), images


def read_image_text(image, reader=None, ocr=None) -> tuple[str, str]:
    """一张图的文字：先用 AI 识图（有密钥时），不行再用本机 OCR。返回 (文字, 来源说明)。"""
    note = ""
    if reader is None:
        from ..lecture.vision import Reader
        reader = Reader()
    if reader.available():
        try:
            return reader.read(image, "这是一页试卷，请完整转录题号、题干、选项和分值。")["text"], "AI 识图"
        except Exception as exc:   # noqa: BLE001
            note = str(exc)
    if ocr is None:
        from ..lecture.lookup import Ocr
        ocr = Ocr()
    text = ocr.read(image) if ocr is not None else ""
    return text, ("本机识别" if text else (note or ocr.problem() or "识别不可用"))


def load_file(path, reader=None, ocr=None) -> tuple[str, str]:
    """读一份试卷文件，返回 (文字, 说明)。支持 .txt .md .docx .pdf 和常见图片。"""
    p = Path(path)
    ext = p.suffix.lower()
    if ext in (".txt", ".md"):
        raw = p.read_bytes()
        for enc in ("utf-8-sig", "gb18030"):
            try:
                return raw.decode(enc), "文本"
            except UnicodeDecodeError:
                continue
        return raw.decode("utf-8", "replace"), "文本"
    if ext in (".docx", ".docm"):
        return read_docx(p), "Word"
    if ext == ".pdf":
        text, images = read_pdf(p)
        notes = ["PDF 文字层"] if text.strip() else []
        for im in images:
            t, how = read_image_text(im, reader, ocr)
            text += "\n" + t
            notes.append(how)
        return text, "、".join(dict.fromkeys(notes)) or "PDF"
    if ext in (".png", ".jpg", ".jpeg", ".bmp", ".webp"):
        from PySide6.QtGui import QImage
        im = QImage(str(p))
        if im.isNull():
            raise ValueError("图片打不开")
        return read_image_text(im, reader, ocr)
    if ext in (".doc", ".wps", ".rtf"):
        raise ValueError("旧版 Word（.doc）请先另存为 .docx 或 PDF 再导入")
    raise ValueError("不支持的文件类型：" + ext)


# ---------------------------------------------------------------- 题库组卷
def bank_type(q) -> str:
    t = str(q.get("type") or "")
    if t in ("单选", "多选", "填空"):
        return t
    return "解答"


def from_bank(subject="数学", count=8, types=None, ids=None, seed=None) -> list[dict]:
    """从题库选题组卷：指定 ids 就按 ids，否则按科目、题型随机抽（选择在前、解答在后）。"""
    from ..bank.data import bank
    bank.load()
    if ids:
        pool = [bank.by_id[i] for i in ids if i in bank.by_id]
    else:
        pool = [q for q in bank.questions if (subject in ("", "全部") or q.get("subject") == subject)
                and (not types or bank_type(q) in types) and q.get("stem")]
        rnd = random.Random(seed)
        rnd.shuffle(pool)
        pool = pool[:max(1, int(count))]
        order = {t: i for i, t in enumerate(TYPES)}
        pool.sort(key=lambda q: order[bank_type(q)])
    out = []
    for i, q in enumerate(pool, 1):
        typ = bank_type(q)
        out.append(dict(no=i, stem=q.get("stem", ""), type=typ, score=DEFAULT_SCORE[typ], answer=q.get("answer", ""),
                        points=[str(p) for p in q.get("points") or []], qid=q["id"], subject=q.get("subject", ""),
                        title=q.get("title", ""), why=q.get("why", "")))
    return out


def new_exam(questions, title="", subject="", minutes=None, source="import") -> dict:
    subject = subject or next((q.get("subject") for q in questions if q.get("subject")), "") or "综合"
    for q in questions:
        q.setdefault("subject", subject)
        q["subject"] = q.get("subject") or subject
    full = sum(float(q.get("score") or 0) for q in questions)
    if minutes is None:
        minutes = max(10, min(150, int(round(sum(3 if q["type"] in OBJECTIVE else 5 if q["type"] == "填空" else 12 for q in questions) / 5.0) * 5)))
    return dict(v=1, id=time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4], title=title or f"{subject}限时练习",
                subject=subject, source=source, created=time.time(), minutes=int(minutes), full=_num(full),
                questions=questions, answers={}, started=None, submitted=None, report=None)
