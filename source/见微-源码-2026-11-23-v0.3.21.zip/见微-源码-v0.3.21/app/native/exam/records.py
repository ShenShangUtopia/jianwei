"""考试记录（exams.json）、进行中的考试（exam-current.json）、手写图（exams/<id>/q<n>.png），以及考情统计。

考情 = 历次考试（逐题得分、错因、用时）+ 习题台的作答（learning.json 里 kind=attempt 且程序判过对错的）。
"""
from __future__ import annotations

import copy
import time
from datetime import datetime

from ..kit.home import home, load_json, save_json

FILE = "exams.json"
CURRENT = "exam-current.json"
WEAK_RATE = 0.7


def history() -> list[dict]:
    data = load_json(FILE, [])
    return [e for e in data if isinstance(e, dict) and e.get("id")] if isinstance(data, list) else []


def save_history(items):
    save_json(FILE, items[-300:])


def upsert(exam):
    items = [e for e in history() if e["id"] != exam["id"]]
    items.append(copy.deepcopy(exam))
    items.sort(key=lambda e: e.get("submitted") or e.get("created") or 0)
    save_history(items)


def get(eid):
    return next((e for e in history() if e["id"] == eid), None)


def delete(eid):
    save_history([e for e in history() if e["id"] != eid])


def current():
    c = load_json(CURRENT, None)
    return c if isinstance(c, dict) and c.get("id") and not c.get("submitted") else None


def save_current(exam):
    save_json(CURRENT, exam)


def clear_current():
    try:
        (home() / CURRENT).unlink()
    except OSError:
        pass


def ink_dir(eid):
    p = home() / "exams" / eid
    p.mkdir(parents=True, exist_ok=True)
    return p


def time_left(exam, now=None) -> float:
    if not exam.get("started"):
        return exam["minutes"] * 60.0
    return exam["started"] + exam["minutes"] * 60.0 + float(exam.get("paused", 0)) - (now or time.time())


def record_learning(exam):
    """交卷评完后，每题记一条学习事件（题库题用题库 id，导入的题用 exam:<id>:<题号>）；同一份考试重复调用不重复记。"""
    from .. import learning
    rep = exam.get("report") or {}
    used = float(exam.get("used") or 0)
    n = max(1, len(exam["questions"]))
    for q, it in zip(exam["questions"], rep.get("items") or []):
        if it["status"] == "self":
            correct, source = None, "ungraded"
        else:
            correct, source = it["status"] == "right", "program" if it.get("how") != "自评" else "self"
        try:
            learning.record(q.get("qid") or f"exam:{exam['id']}:{q['no']}", q.get("subject") or exam.get("subject", ""),
                            used / n, correct=correct, source=source, event_id=f"exam-{exam['id']}-{q['no']}")
        except Exception:   # noqa: BLE001  学习记录坏了不影响考试记录
            pass


# ---------------------------------------------------------------- 考情
def _day(ts):
    return datetime.fromtimestamp(ts).date().isoformat() if ts else ""


def _bank_points():
    try:
        from ..bank.data import bank
        bank.load()
        return {q["id"]: (q.get("subject", ""), [str(p) for p in q.get("points") or []], q.get("title", "")) for q in bank.questions}
    except Exception:   # noqa: BLE001
        return {}


def analyze(exams=None, events=None) -> dict:
    """汇总考情。返回：
    exams      [dict(id,title,subject,day,rate,total,full,used,minutes,pending)]（按时间）
    subjects   {科目: dict(exam_score,exam_full,exam_rate,practice_n,practice_right,practice_rate,trend=[rate...])}
    points     [dict(point,subject,score,full,rate,n,wrong_q=[qid...],last)]（按得分率升序）
    causes     {错因: 次数}
    time       dict(exam_used,exam_minutes,practice_seconds,practice_days)
    weak       points 里得分率 < 0.7 的前 8 个
    """
    exams = history() if exams is None else exams
    if events is None:
        try:
            from .. import learning
            events = learning.load()["events"]
        except Exception:   # noqa: BLE001
            events = []
    bp = _bank_points()
    done = [e for e in exams if e.get("report")]
    done.sort(key=lambda e: e.get("submitted") or 0)
    subjects, points, causes = {}, {}, {}

    def subj(name):
        return subjects.setdefault(name or "未分类", dict(exam_score=0.0, exam_full=0.0, practice_n=0, practice_right=0, trend=[], days=[]))

    def point(name, sname):
        return points.setdefault(name, dict(point=name, subject=sname, score=0.0, full=0.0, n=0, wrong_q=[], notes=[], last=""))

    rows = []
    exam_refs = set()
    for e in done:
        rep = e["report"]
        per = {}
        for q, it in zip(e["questions"], rep["items"]):
            exam_refs.add(q.get("qid") or f"exam:{e['id']}:{q['no']}")
            if it["status"] == "self":
                continue
            sname = q.get("subject") or e.get("subject") or "未分类"
            s = subj(sname)
            sc, fu = float(it["score"]), float(it["full"])
            s["exam_score"] += sc
            s["exam_full"] += fu
            a = per.setdefault(sname, [0.0, 0.0])
            a[0] += sc
            a[1] += fu
            if it["status"] != "right":
                c = it.get("cause") or "其他"
                causes[c] = causes.get(c, 0) + 1
            for pname in (it.get("points") or q.get("points") or ["未标注知识点"]):
                pt = point(pname, sname)
                pt["score"] += sc
                pt["full"] += fu
                pt["n"] += 1
                pt["last"] = _day(e.get("submitted"))
                if it["status"] != "right" and q.get("qid") and q["qid"] not in pt["wrong_q"]:
                    pt["wrong_q"].append(q["qid"])
                note = "：".join(x for x in (it.get("cause"), it.get("comment")) if x)
                if it["status"] != "right" and note and len(pt["notes"]) < 3 and note not in pt["notes"]:
                    pt["notes"].append(note[:120])
        for sname, (sc, fu) in per.items():
            if fu:
                subj(sname)["trend"].append(round(sc / fu, 4))
                subj(sname)["days"].append(_day(e.get("submitted")))
        rows.append(dict(id=e["id"], title=e.get("title", ""), subject=e.get("subject", ""), day=_day(e.get("submitted")),
                         rate=rep.get("rate", 0), total=rep.get("total", 0), full=rep.get("full", 0),
                         used=float(e.get("used") or 0), minutes=e.get("minutes", 0), pending=rep.get("pending", 0),
                         engine=rep.get("engine", "")))
    practice_seconds, practice_days = 0.0, set()
    for ev in events:
        if ev.get("kind") != "attempt":
            continue
        ref = str(ev.get("reference") or "")
        if ref in exam_refs or str(ev.get("id", "")).startswith("exam-"):
            continue                      # 考试那几条已经按考试算过了
        practice_seconds += float(ev.get("seconds") or 0)
        practice_days.add(ev.get("day"))
        if ev.get("source") != "program" or type(ev.get("correct")) is not bool:
            continue
        sname, pts, _title = bp.get(ref, (ev.get("subject") or "未分类", [], ""))
        s = subj(ev.get("subject") or sname)
        s["practice_n"] += 1
        s["practice_right"] += int(ev["correct"])
        for pname in pts or []:
            pt = point(pname, sname)
            pt["full"] += 1
            pt["score"] += int(ev["correct"])
            pt["n"] += 1
            pt["last"] = max(pt["last"], ev.get("day") or "")
            if not ev["correct"] and ref not in pt["wrong_q"]:
                pt["wrong_q"].append(ref)
    for s in subjects.values():
        s["exam_rate"] = round(s["exam_score"] / s["exam_full"], 4) if s["exam_full"] else None
        s["practice_rate"] = round(s["practice_right"] / s["practice_n"], 4) if s["practice_n"] else None
    plist = []
    for p in points.values():
        if p["full"]:
            p["rate"] = round(p["score"] / p["full"], 4)
            plist.append(p)
    plist.sort(key=lambda p: (p["rate"], -p["n"]))
    weak = [p for p in plist if p["rate"] < WEAK_RATE and p["point"] != "未标注知识点"][:8]
    return dict(exams=rows, subjects=subjects, points=plist, causes=causes, weak=weak,
                time=dict(exam_used=sum(r["used"] for r in rows), exam_minutes=sum(r["minutes"] for r in rows),
                          practice_seconds=practice_seconds, practice_days=len(practice_days)))


def suggest(weak_point, n=3) -> list[dict]:
    """给一个薄弱点挑复习题：先是这个点上做错的题，再补题库里同知识点的题。"""
    try:
        from ..bank.data import bank
        bank.load()
    except Exception:   # noqa: BLE001
        return []
    out = [bank.by_id[q] for q in weak_point.get("wrong_q", []) if q in bank.by_id]
    name = weak_point["point"]
    for q in bank.questions:
        if len(out) >= n:
            break
        if q not in out and any(name == str(p) or name in str(p) or str(p) in name for p in q.get("points") or []):
            out.append(q)
    return out[:n]


def add_to_review(weak_points, now=None) -> int:
    """把薄弱点加进间隔复习：每个点一张知识卡 + 它的复习题（题库题），今天就到期。返回新加的条数。"""
    from .. import learning
    before = len(learning.load()["items"])
    for wp in weak_points:
        qs = suggest(wp, 3)
        rate = int(round(wp["rate"] * 100))
        titles = "、".join(q.get("title", "") for q in qs if q.get("title"))
        have = any(it.get("kind") == "card" and it.get("active") and (it.get("card") or {}).get("src") == "exam"
                   and it.get("title") == wp["point"] for it in learning.load()["items"].values())
        if not have:
            learning.add_card(dict(src="exam", n=wp["point"], d=f"考情薄弱点：得分率 {rate}%（{wp['n']} 次）。先回忆这个知识点的定义、条件和常见题型"
                                   + (f"，再做：{titles}。" if titles else "。"), f=[], p=list(wp.get("notes") or [])),
                              wp.get("subject", ""), now=now)
        for q in qs:
            learning.add_question(q["id"], q, now=now)
    return len(learning.load()["items"]) - before
