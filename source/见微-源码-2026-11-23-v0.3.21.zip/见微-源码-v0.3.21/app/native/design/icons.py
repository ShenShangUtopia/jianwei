"""线性图标：统一圆头描边，坐标系 0..18，按目标矩形缩放。全界面的图标都从这里画。"""
from __future__ import annotations

import math
import html

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QPainter, QPainterPath, QPen


def bench_object_svg(kind,label,fallback):
    paths={
        'energy_network':'<circle cx="12" cy="3" r="2"/><circle cx="4" cy="12" r="2"/><circle cx="20" cy="12" r="2"/><circle cx="12" cy="21" r="2"/><path d="M10 5l-5 5m9-5 5 5M5 14l5 5m9-5-5 5"/>',
        'ticker':'<rect x="2" y="5" width="20" height="14"/><path d="M4 12h16"/><circle cx="6" cy="12" r="1"/><circle cx="11" cy="12" r="1"/><circle cx="18" cy="12" r="1"/>',
        'gate':'<path d="M4 20V4h5v10m6 0V4h5v16M9 11h6"/>',
        'fiber':'<path d="M2 4h20M2 20h20M2 12l5-7 10 14 5-7"/>',
        'conical':'<path d="M3 3h18M12 3l7 14"/><ellipse cx="12" cy="18" rx="8" ry="3"/><circle cx="19" cy="17" r="2"/>',
        'cyclotron':'<circle cx="12" cy="12" r="10"/><path d="M12 2v20M10 12a2 2 0 1 0 4 0 4 4 0 1 0-8 0 6 6 0 1 0 12 0"/>',
        'selector':'<path d="M2 4h20M2 20h20M2 12h20M4 7v3m-2-1h4"/><circle cx="12" cy="16" r="2"/>',
        'induction_rail':'<path d="M3 4h18M3 20h18M3 4v16M15 3v18M18 9l4 3-4 3"/>',
        'motor':'<circle cx="12" cy="12" r="8"/><path d="M8 16V8l4 5 4-5v8M0 12h4m16 0h4"/>',
        'inductor':'<path d="M0 12h4c0-8 4-8 4 0 0-8 4-8 4 0 0-8 4-8 4 0 0-8 4-8 4 0h4"/>',
        'scope':'<rect x="3" y="4" width="18" height="16"/><path d="M5 15h4l4-7h6"/>',
        'filter':'<path d="M2 3h20L13 15v7h-2v-7zM6 5l6 8 6-8"/>',
        'distill':'<circle cx="6" cy="17" r="4"/><path d="M5 13V3h3v8l12 5v6h-4v-6M10 9l11 5"/>',
        'extract':'<path d="M5 3h14l-2 10-5 6-5-6zM6 9h12M12 19v4m-3-2h6"/>',
        "microscope":'<path d="M8 3l5 3-3 6-5-3zM12 10q10 3 5 10H4M8 15h9M10 20v2"/>',
        "plant":'<rect x="3" y="3" width="18" height="18" rx="3"/><rect x="5" y="5" width="14" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><ellipse cx="15" cy="15" rx="3" ry="2"/>',
        "animal":'<ellipse cx="12" cy="12" rx="10" ry="8"/><circle cx="12" cy="12" r="3"/><ellipse cx="6" cy="9" rx="2" ry="1"/><ellipse cx="18" cy="15" rx="2" ry="1"/>',
        "mitosis":'<ellipse cx="12" cy="12" rx="10" ry="8"/><path d="M8 8l3 8m-3 0 3-8M14 8l3 8m-3 0 3-8"/>',
        "meiosis":'<circle cx="6" cy="7" r="4"/><circle cx="18" cy="7" r="4"/><circle cx="6" cy="18" r="4"/><circle cx="18" cy="18" r="4"/>',
        "cross":'<path d="M3 3h18v18H3zM9 3v18M15 3v18M3 9h18M3 15h18"/>',
        "enzyme":'<path d="M2 20h20M3 18Q8 18 12 3Q16 18 21 18"/>',
        "photosynthesis":'<path d="M3 20C3 6 12 20 21 3M3 20h18"/><circle cx="5" cy="5" r="3"/>',
        "population":'<path d="M2 20h20M3 18C16 18 5 5 21 5"/>',
        "foodweb":'<path d="M12 2L2 22h20zM6 15h12M9 8h6"/>',
        "car":'<rect x="3" y="7" width="18" height="9"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
        "prism":'<path d="M3 20L12 3l9 17zM1 10l7 2 8-1 7 4"/>',
        "convex":'<path d="M12 2q9 10 0 20q-9-10 0-20zM2 12h20"/>',
        "concave":'<path d="M7 2q5 10 0 20h10q-5-10 0-20zM2 12h20"/>',
        "mirror":'<path d="M12 2v20M12 5l5-3M12 10l5-3M12 15l5-3M12 20l5-3"/>',
        "concavemirror":'<path d="M9 2q12 10 0 20M2 5l11 7L2 19"/>',
        "gas_piston":'<path d="M5 2v19h14V2M5 10h14M12 10V1"/><circle cx="9" cy="16" r="1"/><circle cx="16" cy="18" r="1"/>',
        "levels":'<path d="M3 21h18M3 10h18M3 6h18M3 3h18M12 6v13m-3-3 3 3 3-3"/>',
        "doubleslit":'<path d="M7 2v6m0 2v4m0 2v6M7 9l14-7M7 9l14 13M7 15L21 2M7 15l14 7"/>',
        "standingwave":'<path d="M2 12c3-12 7-12 10 0s7 12 10 0M2 12c3 12 7 12 10 0s7-12 10 0"/>',
        "photoelectric":'<path d="M7 3v18M1 6l6 4M1 12l6 4M7 10l12-4M7 16l12 2"/><circle cx="20" cy="6" r="1.5"/>',
        "pendulum":'<path d="M3 3h18M12 3l7 14"/><circle cx="19" cy="18" r="3"/>',
        "spring":'<path d="M2 12h3l2-6 3 12 3-12 3 12 3-6h3"/>',
        "projectile":'<path d="M2 20Q9-5 22 20"/><circle cx="9" cy="6" r="2"/>',
        "battery":'<path d="M2 12h6M16 12h6M8 7v10M16 3v18"/>',
        "resistor":'<path d="M2 12h4M18 12h4"/><rect x="6" y="8" width="12" height="8"/>',
        "capacitor":'<path d="M2 12h8M14 12h8M10 4v16M14 4v16"/>',
        "ammeter":'<circle cx="12" cy="12" r="9"/><path d="M8 17l4-11 4 11M10 13h4"/>',
        "switch":'<path d="M2 16h4M18 16h4M6 15L18 5"/><circle cx="6" cy="16" r="1"/><circle cx="18" cy="16" r="1"/>',
    }
    if kind in paths:
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">'+paths[kind]+'</svg>'
    # Remaining symbols retain the chapter glyph plus an identifying badge.
    return fallback.replace('</svg>','<rect x="11" y="12" width="13" height="12" fill="var(--surface,#fff)" stroke="none"/><text x="17" y="22" text-anchor="middle" fill="currentColor" stroke="none" font-size="10">'+html.escape(label[:1])+'</text></svg>')


def draw_icon(p: QPainter, name: str, rect, color, width: float = 1.6) -> None:
    r = QRectF(rect)
    s = min(r.width(), r.height()) / 18.0
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.translate(r.x() + (r.width() - 18 * s) / 2, r.y() + (r.height() - 18 * s) / 2)
    p.scale(s, s)
    pen = QPen(color, width / s)   # 描边保持屏幕上 width 像素，不随图标缩放变粗变细
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    f = _ICONS.get(name)
    if f:
        f(p, color)
    p.restore()


def _pt(*xy):
    return [QPointF(xy[i], xy[i + 1]) for i in range(0, len(xy), 2)]


def _lines(p, *segs):
    for x1, y1, x2, y2 in segs:
        p.drawLine(QPointF(x1, y1), QPointF(x2, y2))


def _fill_dot(p, c, x, y, r):
    p.save()
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(c)
    p.drawEllipse(QPointF(x, y), r, r)
    p.restore()


# ---------------------------------------------------------------- 通用
def _menu(p, c):
    _lines(p, (3, 5, 15, 5), (3, 9, 15, 9), (3, 13, 15, 13))


def _more(p, c):
    for x in (4, 9, 14):
        _fill_dot(p, c, x, 9, 1.3)


def _search(p, c):
    p.drawEllipse(QPointF(8, 8), 4.6, 4.6)
    p.drawLine(QPointF(11.4, 11.4), QPointF(15, 15))


def _sun(p, c):
    p.drawEllipse(QPointF(9, 9), 3.4, 3.4)
    for k in range(8):
        a = k * math.pi / 4
        p.drawLine(QPointF(9 + 5.6 * math.cos(a), 9 + 5.6 * math.sin(a)), QPointF(9 + 7.2 * math.cos(a), 9 + 7.2 * math.sin(a)))


def _moon(p, c):
    path = QPainterPath(QPointF(14.6, 11.2))
    path.cubicTo(10.4, 12.8, 5.4, 8.8, 7, 3.2)
    path.cubicTo(3.2, 4.2, 1.8, 8.4, 3.4, 11.6)
    path.cubicTo(5.4, 15.8, 11.4, 16.2, 14.6, 11.2)
    p.drawPath(path)


def _reset(p, c):
    path = QPainterPath()
    path.arcMoveTo(QRectF(3, 3, 12, 12), 60)
    path.arcTo(QRectF(3, 3, 12, 12), 60, 280)
    p.drawPath(path)
    p.drawPolyline(_pt(12, 2.5, 12.2, 5.6, 9.2, 5.8))


def _camera(p, c):
    p.drawRoundedRect(QRectF(2.5, 5, 13, 9.5), 2, 2)
    p.drawEllipse(QPointF(9, 9.8), 2.8, 2.8)
    p.drawPolyline(_pt(6.5, 5, 7.6, 3.2, 10.4, 3.2, 11.5, 5))


def _full(p, c):
    for (x, y, dx, dy) in ((3, 3, 1, 1), (15, 3, -1, 1), (3, 15, 1, -1), (15, 15, -1, -1)):
        p.drawLine(QPointF(x, y), QPointF(x + 4 * dx, y))
        p.drawLine(QPointF(x, y), QPointF(x, y + 4 * dy))


def _side(p, c):
    p.drawRoundedRect(QRectF(2.5, 3.5, 13, 11), 2, 2)
    p.drawLine(QPointF(11, 3.5), QPointF(11, 14.5))


def _home(p, c):
    p.drawPolyline(_pt(2.5, 9, 9, 3, 15.5, 9))
    p.drawPolyline(_pt(4.5, 7.5, 4.5, 15, 13.5, 15, 13.5, 7.5))


def _grid(p, c):
    p.drawRoundedRect(QRectF(3, 3, 5, 5), 1, 1)
    p.drawRoundedRect(QRectF(10, 3, 5, 5), 1, 1)
    p.drawRoundedRect(QRectF(3, 10, 5, 5), 1, 1)
    p.drawRoundedRect(QRectF(10, 10, 5, 5), 1, 1)


def _play(p, c):
    path = QPainterPath(QPointF(5.5, 3.5))
    path.lineTo(14, 9)
    path.lineTo(5.5, 14.5)
    path.closeSubpath()
    p.drawPath(path)


def _pause(p, c):
    _lines(p, (6.5, 4, 6.5, 14), (11.5, 4, 11.5, 14))


def _spark(p, c):
    path = QPainterPath(QPointF(9, 2.5))
    path.quadTo(9.6, 8.4, 15.5, 9)
    path.quadTo(9.6, 9.6, 9, 15.5)
    path.quadTo(8.4, 9.6, 2.5, 9)
    path.quadTo(8.4, 8.4, 9, 2.5)
    p.drawPath(path)


def _close(p, c):
    _lines(p, (4.5, 4.5, 13.5, 13.5), (13.5, 4.5, 4.5, 13.5))


def _min(p, c):
    p.drawLine(QPointF(4, 9), QPointF(14, 9))


def _undo(p, c):
    p.drawPolyline(_pt(6.6, 3.6, 3.2, 7, 6.6, 10.4))
    path = QPainterPath(QPointF(3.2, 7))
    path.lineTo(10.6, 7)
    path.cubicTo(16, 7, 16, 14.6, 10.6, 14.6)
    path.lineTo(7, 14.6)
    p.drawPath(path)


def _redo(p, c):
    p.drawPolyline(_pt(11.4, 3.6, 14.8, 7, 11.4, 10.4))
    path = QPainterPath(QPointF(14.8, 7))
    path.lineTo(7.4, 7)
    path.cubicTo(2, 7, 2, 14.6, 7.4, 14.6)
    path.lineTo(11, 14.6)
    p.drawPath(path)


def _plus(p, c):
    _lines(p, (9, 3.5, 9, 14.5), (3.5, 9, 14.5, 9))


def _trash(p, c):
    _lines(p, (3, 5, 15, 5), (7, 5, 7.6, 2.8), (7.6, 2.8, 10.4, 2.8), (10.4, 2.8, 11, 5), (7.6, 8, 7.6, 12.6), (10.4, 8, 10.4, 12.6))
    p.drawPolyline(_pt(4.4, 5, 5.2, 15.4, 12.8, 15.4, 13.6, 5))


def _chevron_l(p, c):
    p.drawPolyline(_pt(11, 3.5, 5.5, 9, 11, 14.5))


def _chevron_r(p, c):
    p.drawPolyline(_pt(7, 3.5, 12.5, 9, 7, 14.5))


def _chevron_d(p, c):
    p.drawPolyline(_pt(4, 7, 9, 12, 14, 7))


def _basket(p, c):
    p.drawRoundedRect(QRectF(2.6, 6.4, 12.8, 8.8), 1.8, 1.8)
    p.drawPolyline(_pt(5.2, 6.4, 5.2, 3, 12.8, 3, 12.8, 6.4))
    p.drawLine(QPointF(6.4, 10), QPointF(11.6, 10))


def _send(p, c):
    p.drawPolyline(_pt(9, 11.8, 9, 3, ))
    p.drawPolyline(_pt(5.4, 6.4, 9, 2.8, 12.6, 6.4))
    p.drawPolyline(_pt(3, 10.5, 3, 15, 15, 15, 15, 10.5))


def _board(p, c):
    p.drawRoundedRect(QRectF(2.2, 3, 13.6, 9.6), 1.4, 1.4)
    _lines(p, (6, 12.6, 4.6, 15.6), (12, 12.6, 13.4, 15.6), (5, 6.6, 9.6, 6.6), (5, 9.2, 12, 9.2))


# ---------------------------------------------------------------- 模式
def _today(p, c):
    p.drawRoundedRect(QRectF(2.5, 3.8, 13, 11.7), 2.2, 2.2)
    _lines(p, (2.5, 7.4, 15.5, 7.4), (6, 2.2, 6, 5), (12, 2.2, 12, 5))
    _fill_dot(p, c, 11.4, 11.4, 1.4)


def _guanlan(p, c):
    for y0 in (6.6, 11.6):
        path = QPainterPath(QPointF(2, y0))
        for i in range(1, 29):
            x = 2 + i * 0.5
            path.lineTo(x, y0 + 1.6 * math.sin((x - 2) / 14 * 2 * math.pi * 1.5))
        p.drawPath(path)


def _countdown(p, c):
    _lines(p, (4, 2.5, 14, 2.5), (4, 15.5, 14, 15.5))
    path = QPainterPath(QPointF(5, 2.5))
    path.cubicTo(5, 7, 8.6, 7.6, 8.6, 9)
    path.cubicTo(8.6, 10.4, 5, 11, 5, 15.5)
    p.drawPath(path)
    path = QPainterPath(QPointF(13, 2.5))
    path.cubicTo(13, 7, 9.4, 7.6, 9.4, 9)
    path.cubicTo(9.4, 10.4, 13, 11, 13, 15.5)
    p.drawPath(path)


def _desk(p, c):
    p.drawRoundedRect(QRectF(3.2, 2.2, 11.6, 13.6), 2, 2)
    _lines(p, (6, 6, 12, 6), (6, 8.8, 10.4, 8.8))
    p.drawPolyline(_pt(6.2, 12, 7.8, 13.4, 11.4, 10.6))


def _lab(p, c):
    path = QPainterPath(QPointF(7, 2.4))
    path.lineTo(7, 7)
    path.lineTo(3, 14)
    path.quadTo(2.6, 15.6, 4.4, 15.6)
    path.lineTo(13.6, 15.6)
    path.quadTo(15.4, 15.6, 15, 14)
    path.lineTo(11, 7)
    path.lineTo(11, 2.4)
    p.drawPath(path)
    _lines(p, (6, 2.4, 12, 2.4), (5, 11.4, 13, 11.4))


def _bench(p, c):
    # 工作台：一只扳手式的卡尺 + 台面
    _lines(p, (2.4, 14.8, 15.6, 14.8), (4.6, 14.8, 4.6, 10.4), (13.4, 14.8, 13.4, 10.4))
    p.drawRoundedRect(QRectF(3, 6.8, 12, 3.6), 1, 1)
    _lines(p, (6, 6.8, 6, 3.2), (6, 3.2, 12, 3.2), (12, 3.2, 12, 6.8))


def _analysis(p, c):
    # 析题：放大镜里一条折线
    p.drawEllipse(QPointF(7.8, 7.8), 5.4, 5.4)
    p.drawLine(QPointF(11.8, 11.8), QPointF(15.6, 15.6))
    p.drawPolyline(_pt(5, 9.6, 7, 7.4, 8.6, 8.8, 10.8, 6))


def _reading(p, c):
    """读文：摊开的书，左页三行字。"""
    left = QPainterPath(QPointF(9, 4.6))
    left.cubicTo(7, 3.2, 4.4, 3, 2.2, 3.6)
    left.lineTo(2.2, 14.2)
    left.cubicTo(4.4, 13.6, 7, 13.8, 9, 15.2)
    right = QPainterPath(QPointF(9, 4.6))
    right.cubicTo(11, 3.2, 13.6, 3, 15.8, 3.6)
    right.lineTo(15.8, 14.2)
    right.cubicTo(13.6, 13.6, 11, 13.8, 9, 15.2)
    p.drawPath(left)
    p.drawPath(right)
    _lines(p, (9, 4.6, 9, 15.2), (4.4, 6.6, 7, 7.2), (4.4, 9, 7, 9.6), (4.4, 11.4, 6.2, 11.8))


def _lecture(p, c):
    p.drawRoundedRect(QRectF(2.2, 2.8, 13.6, 9.6), 1.4, 1.4)
    _lines(p, (9, 12.4, 9, 15.6), (6, 15.6, 12, 15.6))
    path = QPainterPath(QPointF(7.4, 5.2))
    path.lineTo(11.4, 7.6)
    path.lineTo(7.4, 10)
    path.closeSubpath()
    p.drawPath(path)


def _settings(p, c):
    for y, kx in ((4.5, 11.5), (9, 6.5), (13.5, 10)):
        p.drawLine(QPointF(2.5, y), QPointF(kx - 2.4, y))
        p.drawLine(QPointF(kx + 2.4, y), QPointF(15.5, y))
        p.drawEllipse(QPointF(kx, y), 1.9, 1.9)


# ---------------------------------------------------------------- 画笔
def _pointer(p, c):
    path = QPainterPath(QPointF(4, 2.6))
    path.lineTo(14, 9.6)
    path.lineTo(9.4, 10.4)
    path.lineTo(7.2, 14.8)
    path.closeSubpath()
    p.drawPath(path)


def _pen(p, c):
    path = QPainterPath(QPointF(3, 15))
    path.lineTo(3.8, 11.4)
    path.lineTo(12.2, 3)
    path.lineTo(15, 5.8)
    path.lineTo(6.6, 14.2)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(10.6, 4.6), QPointF(13.4, 7.4))


def _marker(p, c):
    path = QPainterPath(QPointF(6.2, 12.4))
    path.lineTo(3.6, 9.8)
    path.lineTo(10.8, 2.6)
    path.lineTo(15.4, 7.2)
    path.lineTo(8.2, 14.4)
    path.closeSubpath()
    p.drawPath(path)
    p.drawPolyline(_pt(4.8, 11, 2.6, 15.4, 7, 13.2))


def _chalk(p, c):
    p.save()
    p.translate(9, 8)
    p.rotate(-35)
    p.drawRoundedRect(QRectF(-6.4, -2.2, 12.8, 4.4), 1, 1)
    p.drawLine(QPointF(2.4, -2.2), QPointF(2.4, 2.2))
    p.restore()
    p.drawLine(QPointF(9, 15.4), QPointF(15.6, 15.4))


def _eraser(p, c):
    path = QPainterPath(QPointF(6.4, 14.8))
    path.lineTo(2.8, 11.2)
    path.lineTo(10, 3.2)
    path.lineTo(15.4, 8.6)
    path.lineTo(9.4, 14.8)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(6, 7.6), QPointF(11.2, 12.8))
    p.drawLine(QPointF(9.4, 15.4), QPointF(15.6, 15.4))


def _lasso(p, c):
    path = QPainterPath()
    path.addEllipse(QRectF(2.8, 2.8, 12.4, 8.8))
    pen = p.pen()
    pen.setDashPattern([2.4, 2.0])
    p.setPen(pen)
    p.drawPath(path)
    pen.setStyle(Qt.PenStyle.SolidLine)
    p.setPen(pen)
    tail = QPainterPath(QPointF(6.6, 11.2))
    tail.cubicTo(5.2, 13.4, 8, 14, 7.2, 15.8)
    p.drawPath(tail)


def _laser(p, c):
    _fill_dot(p, c, 4.6, 13.4, 1.8)
    _lines(p, (7.6, 10.4, 15.4, 2.6), (4.6, 8.2, 4.6, 7), (9.8, 13.4, 11, 13.4), (8.2, 15.8, 9, 16.6))


def _line(p, c):
    p.drawLine(QPointF(3.2, 14.8), QPointF(14.8, 3.2))


def _rect(p, c):
    p.drawRoundedRect(QRectF(3, 4.4, 12, 9.2), .8, .8)


def _ellipse(p, c):
    p.drawEllipse(QPointF(9, 9), 6.4, 5)


def _arrow(p, c):
    p.drawLine(QPointF(3.2, 14.8), QPointF(14.4, 3.6))
    p.drawPolyline(_pt(8.6, 3.2, 14.8, 3.2, 14.8, 9.4))


def _axes(p, c):
    p.drawPolyline(_pt(4, 2.8, 4, 14, 15.4, 14))
    p.drawPolyline(_pt(2.4, 4.6, 4, 2.8, 5.6, 4.6))
    p.drawPolyline(_pt(13.6, 12.4, 15.4, 14, 13.6, 15.6))


def _select(p, c):
    pen = p.pen()
    pen.setDashPattern([2.2, 2.0])
    p.setPen(pen)
    p.drawRect(QRectF(3, 3, 12, 12))


def _shapes(p, c):
    p.drawRoundedRect(QRectF(2.6, 8.6, 6.8, 6.8), .8, .8)
    p.drawEllipse(QPointF(11.8, 6.2), 3.6, 3.6)


def _reagent(p, c):
    p.drawPolyline(_pt(7, 2.8, 11, 2.8))
    p.drawPolyline(_pt(7.6, 2.8, 7.6, 6.6, 4.4, 9.4, 4.4, 15.2, 13.6, 15.2, 13.6, 9.4, 10.4, 6.6, 10.4, 2.8))
    p.drawLine(QPointF(4.4, 11), QPointF(13.6, 11))


def _box(p, c):
    p.drawPolygon(_pt(9, 2.6, 15.4, 5.8, 15.4, 12.2, 9, 15.4, 2.6, 12.2, 2.6, 5.8))
    p.drawPolyline(_pt(2.6, 5.8, 9, 9, 15.4, 5.8))
    p.drawLine(QPointF(9, 9), QPointF(9, 15.4))


def _tune(p, c):
    _lines(p, (2.8, 5, 15.2, 5), (2.8, 13, 15.2, 13))
    for x, y in ((6.2, 5), (11.8, 13)):
        p.save()
        p.setBrush(c)
        p.drawEllipse(QPointF(x, y), 1.8, 1.8)
        p.restore()


def _note(p, c):
    p.drawRoundedRect(QRectF(3.6, 2.6, 10.8, 12.8), 1, 1)
    _lines(p, (6.2, 6.4, 11.8, 6.4), (6.2, 9.2, 11.8, 9.2), (6.2, 12, 9.8, 12))


# ---------------------------------------------------------------- 放映 / 黑板
def _text(p, c):
    _lines(p, (3.5, 4, 14.5, 4), (9, 4, 9, 15), (6.8, 15, 11.2, 15))
    _lines(p, (3.5, 4, 3.5, 5.8), (14.5, 4, 14.5, 5.8))


def _export(p, c):
    _lines(p, (9, 2.8, 9, 11))
    p.drawPolyline(_pt(5.6, 7.8, 9, 11.2, 12.4, 7.8))
    p.drawPolyline(_pt(3, 11.5, 3, 15, 15, 15, 15, 11.5))


def _detach(p, c):
    p.drawPolyline(_pt(8, 3.5, 3.5, 3.5, 3.5, 14.5, 14.5, 14.5, 14.5, 10))
    _lines(p, (8.6, 9.4, 15, 3))
    p.drawPolyline(_pt(10.6, 3, 15, 3, 15, 7.4))


def _attach(p, c):
    p.drawPolyline(_pt(8, 3.5, 3.5, 3.5, 3.5, 14.5, 14.5, 14.5, 14.5, 10))
    _lines(p, (15, 3, 8.6, 9.4))
    p.drawPolyline(_pt(8.6, 5, 8.6, 9.4, 13, 9.4))


def _locate(p, c):
    p.drawEllipse(QPointF(9, 9), 5, 5)
    _fill_dot(p, c, 9, 9, 1.6)
    _lines(p, (9, 1.8, 9, 4), (9, 14, 9, 16.2), (1.8, 9, 4, 9), (14, 9, 16.2, 9))


def _paper(p, c):
    p.drawRoundedRect(QRectF(2.8, 2.8, 12.4, 12.4), 1.5, 1.5)
    pen = p.pen()
    pen.setWidthF(pen.widthF() * .7)
    p.setPen(pen)
    _lines(p, (7, 2.8, 7, 15.2), (11, 2.8, 11, 15.2), (2.8, 7, 15.2, 7), (2.8, 11, 15.2, 11))


def _fit(p, c):
    p.drawRoundedRect(QRectF(5.5, 6, 7, 6), 1, 1)
    for (x, y, dx, dy) in ((2.5, 2.5, 1, 1), (15.5, 2.5, -1, 1), (2.5, 15.5, 1, -1), (15.5, 15.5, -1, -1)):
        p.drawLine(QPointF(x, y), QPointF(x + 3 * dx, y))
        p.drawLine(QPointF(x, y), QPointF(x, y + 3 * dy))


def _share(p, c):
    p.drawEllipse(QPointF(4.6, 9), 2, 2)
    p.drawEllipse(QPointF(13.4, 4.4), 2, 2)
    p.drawEllipse(QPointF(13.4, 13.6), 2, 2)
    _lines(p, (6.4, 8, 11.6, 5.3), (6.4, 10, 11.6, 12.7))


def _classroom(p, c):
    p.drawRoundedRect(QRectF(2, 2.5, 14, 9), 1, 1)
    _lines(p, (5, 6, 12, 6), (5, 8.5, 9, 8.5), (6, 14, 12, 14),
           (7, 14, 6, 16), (11, 14, 12, 16), (9, 11.5, 9, 14))


def _exam(p, c):
    """试卷 + 右下角一块表：限时考试。"""
    p.drawPolyline(_pt(10.5, 15.5, 3, 15.5, 3, 2.5, 13, 2.5, 13, 7.5))
    _lines(p, (5.5, 6, 10.5, 6), (5.5, 9, 9, 9), (5.5, 12, 7.5, 12))
    p.drawEllipse(QPointF(13.2, 12.6), 3.4, 3.4)
    _lines(p, (13.2, 10.8, 13.2, 12.7), (13.2, 12.7, 14.6, 13.6))


def _stats(p, c):
    """三根柱 + 一条趋势线：考情分析。"""
    _lines(p, (2.5, 15.5, 15.5, 15.5), (5, 15.5, 5, 11), (9, 15.5, 9, 8.5), (13, 15.5, 13, 10))
    p.drawPolyline(_pt(3.5, 7.5, 7.5, 4.5, 10.5, 6.5, 15, 2.8))


def _focus(p, c):
    """番茄钟：圆 + 顶上一小截柄 + 指针。"""
    p.drawEllipse(QPointF(9, 10), 6, 6)
    _lines(p, (9, 4, 9, 2.4), (7.2, 2.4, 10.8, 2.4), (9, 10, 9, 7), (9, 10, 11.2, 11.4), (13.6, 4.8, 14.8, 3.6))


def _bell(p, c):
    """铃：提醒。"""
    path = QPainterPath(QPointF(4, 13))
    path.cubicTo(5.2, 11.6, 5, 9.6, 5, 8)
    path.cubicTo(5, 5.4, 6.8, 3.6, 9, 3.6)
    path.cubicTo(11.2, 3.6, 13, 5.4, 13, 8)
    path.cubicTo(13, 9.6, 12.8, 11.6, 14, 13)
    path.closeSubpath()
    p.drawPath(path)
    _lines(p, (9, 2, 9, 3.6))
    p.drawArc(QRectF(7.2, 13.2, 3.6, 3), 180 * 16, 180 * 16)


def _clock(p, c):
    p.drawEllipse(QPointF(9, 9), 6.5, 6.5)
    _lines(p, (9, 9, 9, 5.2), (9, 9, 11.8, 10.6))


def _calendar(p, c):
    p.drawRoundedRect(QRectF(2.8, 4, 12.4, 11.4), 2, 2)
    _lines(p, (2.8, 7.4, 15.2, 7.4), (6, 2.4, 6, 5.4), (12, 2.4, 12, 5.4))
    for x, y in ((6, 10.2), (9, 10.2), (12, 10.2), (6, 12.8), (9, 12.8)):
        _fill_dot(p, c, x, y, 0.75)


def _repeat(p, c):
    """循环箭头：重复规则 / 顺延。"""
    p.drawArc(QRectF(3, 3, 12, 12), 30 * 16, 240 * 16)
    p.drawPolyline(_pt(15.2, 3.4, 14.2, 6.6, 11, 5.8))


def _recite(p, c):
    """翻开的书：背诵。"""
    p.drawPolyline(_pt(9, 5, 5.5, 3.6, 2.5, 3.6, 2.5, 14, 5.5, 14, 9, 15.4, 12.5, 14, 15.5, 14, 15.5, 3.6, 12.5, 3.6, 9, 5, 9, 15.4))
    _lines(p, (4.5, 7, 7, 7.6), (4.5, 10, 7, 10.6), (11, 7.6, 13.5, 7), (11, 10.6, 13.5, 10))


def _chat(p, c):
    """对话气泡 + 一个小星点：问 AI。"""
    path = QPainterPath()
    path.addRoundedRect(QRectF(2.5, 3.5, 13, 9), 2.5, 2.5)
    p.drawPath(path)
    p.drawPolyline(_pt(6, 12.5, 5, 15.5, 9, 12.5))
    _lines(p, (6, 7, 12, 7), (6, 9.5, 10, 9.5))


_ICONS = {"menu": _menu, "more": _more, "search": _search, "sun": _sun, "moon": _moon, "reset": _reset, "camera": _camera,
          "full": _full, "side": _side, "home": _home, "grid": _grid, "play": _play, "pause": _pause, "spark": _spark,
          "close": _close, "min": _min, "undo": _undo, "redo": _redo, "plus": _plus, "trash": _trash,
          "chevron_l": _chevron_l, "chevron_r": _chevron_r, "chevron_d": _chevron_d, "basket": _basket, "send": _send, "board": _board,
          "today": _today, "guanlan": _guanlan, "countdown": _countdown, "desk": _desk, "studio": _desk, "lab": _lab,
          "bench": _bench, "analysis": _analysis, "lecture": _lecture, "reading": _reading, "classroom": _classroom, "settings": _settings,
          "pointer": _pointer, "move": _pointer, "pen": _pen, "marker": _marker, "chalk": _chalk, "eraser": _eraser,
          "lasso": _lasso, "laser": _laser, "line": _line, "rect": _rect, "ellipse": _ellipse, "arrow": _arrow, "axes": _axes,
          "select": _select, "shapes": _shapes, "reagent": _reagent, "box": _box, "tune": _tune, "note": _note,
          "text": _text, "export": _export, "detach": _detach, "attach": _attach, "locate": _locate, "paper": _paper,
          "fit": _fit, "share": _share, "exam": _exam, "stats": _stats, "focus": _focus, "recite": _recite, "chat": _chat,
           "bell": _bell, "clock": _clock, "calendar": _calendar, "repeat": _repeat}
