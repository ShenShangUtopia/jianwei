"""背诵页：单词 · 诗词。主窗口「背诵」页（compact=True）和学习窗口「背诵」模式用的是同一个控件。

单词一组 10 个，每个词走 认词 → 释义四选一 → 例句 → 拼写；诗词选一篇，原文 / 逐句遮挡 / 填空 / 首字接龙 / 默写。
open_reading(text)：外壳给，把这篇送进读文精析。
"""
from __future__ import annotations

import html
import threading

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit,
                               QPushButton, QStackedWidget, QTextBrowser, QVBoxLayout, QWidget)

from ..design.tokens import T, css
from ..design.widgets import Segmented, qss
from ..exam.ink import InkBox
from ..exam.page import _btn, _card, _label
from . import core

MODES = [("read", "原文"), ("mask", "逐句遮挡"), ("fill", "填空"), ("chain", "首字接龙"), ("dictate", "默写")]


class _Bridge(QObject):
    recognized = Signal(int, str)


class RecitePage(QWidget):
    def __init__(self, compact=False, open_reading=None):
        super().__init__()
        self.setObjectName("recitePage")
        self.compact = compact
        self.open_reading = open_reading
        self.reader = None            # 自测：假的识图
        self.ocr = None
        self.bridge = _Bridge()
        self.bridge.recognized.connect(self._recognized)
        self.ticket = 0
        v = QVBoxLayout(self)
        v.setContentsMargins(*((0, 0, 0, 0) if compact else (24, 18, 24, 18)))
        v.setSpacing(12)
        top = QHBoxLayout()
        self.title = _label("背诵", "examTitle")
        self.title.setVisible(not compact)
        top.addWidget(self.title)
        self.seg = Segmented([("words", "单词"), ("poems", "诗词")], "words")
        self.seg.changed.connect(self.show_tab)
        top.addWidget(self.seg)
        self.status = _label("", "examStatus")
        top.addWidget(self.status, 1)
        self.k_review = _btn("开始复习", self.open_review, "", "间隔复习：今天到期的单词卡、诗词卡和其他项目")
        top.addWidget(self.k_review)
        v.addLayout(top)
        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)
        self.v_words = self._build_words()
        self.v_poems = self._build_poems()
        self.stack.addWidget(self.v_words)
        self.stack.addWidget(self.v_poems)
        self.apply_theme()
        self.batch, self.i, self.step_i = [], 0, 0
        self.refresh_words()
        self.fill_poems()

    def show_tab(self, key):
        self.seg.set_value(key)
        self.stack.setCurrentWidget(self.v_words if key == "words" else self.v_poems)

    def set_status(self, text, tone="muted"):
        self.status.setText(text)
        self.status.setStyleSheet(f"color:{getattr(T, tone)};font-size:12px;")

    def open_review(self):
        try:
            from ..learning_ui import Review
            Review(self).exec()
        except Exception as exc:  # noqa: BLE001
            self.set_status(f"打不开复习：{exc}", "bad")

    # ================================================================ 单词
    def _build_words(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(14)
        main, mv = _card()
        head = QHBoxLayout()
        self.w_stats = _label("", "note")
        head.addWidget(self.w_stats, 1)
        head.addWidget(_btn("导入词表", self.pick_wordlist, "", "txt / csv：一行一个「单词 释义」，第三列可写例句"))
        self.w_start = _btn("背一组", self.start_batch, "pri", "10 个词：认词 → 释义四选一 → 例句 → 拼写")
        head.addWidget(self.w_start)
        mv.addLayout(head)
        self.w_step = _label("", "grpTitle")
        mv.addWidget(self.w_step)
        mv.addStretch(1)
        self.w_word = _label("", "bigWord")
        self.w_word.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mv.addWidget(self.w_word)
        self.w_info = _label("", "", True)
        self.w_info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.w_info.setTextFormat(Qt.TextFormat.RichText)
        mv.addWidget(self.w_info)
        self.w_keys = QVBoxLayout()
        self.w_keys.setSpacing(8)
        keys_row = QHBoxLayout()
        keys_row.addStretch(1)
        keys_row.addLayout(self.w_keys, 4)
        keys_row.addStretch(1)
        mv.addLayout(keys_row)
        self.w_input = QLineEdit()
        self.w_input.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.w_input.setPlaceholderText("拼出这个词，回车检查")
        self.w_input.returnPressed.connect(self.check_spell)
        self.w_input.setMaximumWidth(420)
        self.w_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mv.addWidget(self.w_input, 0, Qt.AlignmentFlag.AlignHCenter)
        self.w_feedback = _label("", "", True)
        self.w_feedback.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mv.addWidget(self.w_feedback)
        mv.addStretch(1)
        nav = QHBoxLayout()
        nav.addStretch(1)
        self.w_next = _btn("下一步", self.next_step, "pri")
        nav.addWidget(self.w_next)
        mv.addLayout(nav)
        h.addWidget(main, 3)
        side, sv = _card()
        sv.addWidget(_label("这一组", "cardTitle"))
        self.w_list = QListWidget()
        sv.addWidget(self.w_list, 1)
        hint = QListWidgetItem("还没开始。点「背一组」，这里会列出这一组的 10 个词，背到哪个、哪个学会了都标出来。")
        hint.setFlags(Qt.ItemFlag.NoItemFlags)
        self.w_list.setWordWrap(True)
        self.w_list.addItem(hint)
        sv.addWidget(_label("查词", "cardTitle"))
        self.w_find = QLineEdit()
        self.w_find.setPlaceholderText("输入单词，回车查")
        self.w_find.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.w_find.returnPressed.connect(self.lookup)
        sv.addWidget(self.w_find)
        self.w_found = _label("", "note", True)
        sv.addWidget(self.w_found)
        sv.addWidget(_btn("加入复习", self.add_found, "", "把查到的词放进间隔复习"))
        side.setMaximumWidth(320)
        h.addWidget(side, 1)
        return w

    def refresh_words(self):
        st = core.word_stats()
        self.w_stats.setText(f"词库 {st['total']} 个（自定义 {st['custom']}）· 学过 {st['seen']} · 学会 {st['learned']}")
        if not self.batch:
            self.w_step.setText("")
            self.w_word.setText("")
            self.w_info.setText("点「背一组」开始。每个词：先认，再从四个释义里选，看例句，最后拼写。拼写对了算学会，会排进间隔复习。")
            self._clear_keys()
            self.w_input.hide()
            self.w_next.hide()
            self.w_feedback.setText("")

    def pick_wordlist(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入词表", "", "词表 (*.txt *.csv *.tsv);;全部文件 (*)")
        if path:
            self.import_wordlist(path)

    def import_wordlist(self, path_or_text):
        try:
            n = core.import_words(path_or_text)
        except Exception as exc:  # noqa: BLE001
            self.set_status(f"导入失败：{exc}", "bad")
            return 0
        self.set_status(f"导入 {n} 个词" if n else "没认出词：一行一个「单词 释义」", "ok" if n else "warn")
        self.refresh_words()
        return n

    def start_batch(self, words=None, seed=None):
        self.batch = list(words) if words is not None else core.batch(10, seed=seed)
        if not self.batch:
            self.set_status("词库里的词都学会了。可以导入新词表，或者去复习。", "ok")
            return
        self.i, self.step_i = 0, 0
        self.results = {x["w"]: [] for x in self.batch}
        self._fill_list()
        self.show_step()

    def _fill_list(self):
        self.w_list.clear()
        for j, x in enumerate(self.batch):
            res = self.results.get(x["w"], [])
            mark = "　当前" if j == self.i else ("　学会" if res and res[-1] == ("spell", True) else ("　有错" if any(not ok for _s, ok in res) else ""))
            self.w_list.addItem(f"{x['w']}{mark}")

    def _clear_keys(self):
        while self.w_keys.count():
            it = self.w_keys.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

    def cur(self):
        return self.batch[self.i] if 0 <= self.i < len(self.batch) else None

    def cur_step(self):
        x = self.cur()
        return core.steps_for(x)[self.step_i] if x else None

    def show_step(self):
        x, step = self.cur(), self.cur_step()
        self._clear_keys()
        self.w_feedback.setText("")
        self.w_input.hide()
        self.w_next.hide()
        if x is None:
            return
        self.answered = False
        self.w_step.setText(f"第 {self.i + 1} / {len(self.batch)} 个 · {core.STEP_NAME[step]}")
        if step == "recognize":
            self.w_word.setText(x["w"])
            self.w_info.setText("认识这个词吗？")
            row = QHBoxLayout()
            row.addStretch(1)
            row.addWidget(_btn("不认识", lambda: self.answer(False)))
            row.addWidget(_btn("认识", lambda: self.answer(True), "pri"))
            row.addStretch(1)
            holder = QWidget()
            holder.setLayout(row)
            self.w_keys.addWidget(holder)
        elif step == "choose":
            self.w_word.setText(x["w"])
            self.w_info.setText("选出正确的释义")
            self.opts = core.choices(x)
            self.opt_btns = []
            for m in self.opts:
                b = QPushButton(m)
                b.setObjectName("optBtn")
                b.clicked.connect(lambda _c=False, m=m: self.answer(m == x["m"], m))
                self.w_keys.addWidget(b)
                self.opt_btns.append(b)
        elif step == "example":
            self.w_word.setText(x["w"])
            self.w_info.setText(f"<span style='color:{T.muted}'>{html.escape(x['m'])}</span><br><br>"
                                f"<span style='font-size:16px'>{html.escape(core.blank_example(x))}</span>")
            self.w_input.setPlaceholderText("例句里空着的词（按句子写对词形），回车检查")
            self.w_input.clear()
            self.w_input.show()
        else:
            self.w_word.setText("")
            self.w_info.setText(f"<span style='font-size:18px'>{html.escape(x['m'])}</span><br>"
                                f"<span style='color:{T.faint}'>{len(x['w'])} 个字母，首字母 {x['w'][0]}</span>")
            self.w_input.setPlaceholderText("拼出这个词，回车检查")
            self.w_input.clear()
            self.w_input.show()
        self._fill_list()

    def answer(self, ok, picked=None):
        if self.answered:
            return
        self.answered = True
        x, step = self.cur(), self.cur_step()
        core.record_word(x, step, ok)
        self.results[x["w"]].append((step, ok))
        if step == "choose":
            for b in self.opt_btns:
                good = b.text() == x["m"]
                if good or b.text() == picked:
                    b.setStyleSheet(f"color:{T.ok if good else T.bad};border-color:{T.ok if good else T.bad};font-weight:700;")
        if step == "recognize" and not ok:
            self.w_info.setText(f"<span style='font-size:16px'>{html.escape(x['m'])}</span>")
        self.w_feedback.setText("对了" if ok else ("记一下：" + x["m"] if step != "spell" else f"正确拼写：{x['w']}"))
        self.w_feedback.setStyleSheet(f"color:{T.ok if ok else T.bad};font-size:14px;")
        self.w_next.show()
        self.w_next.setFocus()

    def check_spell(self):
        x, step = self.cur(), self.cur_step()
        if x is None or self.answered:
            return
        text = self.w_input.text()
        if step == "example":
            ok = bool(text.strip()) and text.strip().lower().startswith(x["w"].lower()[:max(3, len(x["w"]) - 2)])
            if ok and x.get("ex"):
                self.w_info.setText(self.w_info.text().replace("_____", f"<b>{html.escape(text.strip())}</b>"))
            self.answer(ok)
        else:
            self.answer(core.check_spell(x, text))

    def next_step(self):
        x = self.cur()
        if x is None:
            return
        steps = core.steps_for(x)
        if self.step_i + 1 < len(steps):
            self.step_i += 1
        else:
            self.i += 1
            self.step_i = 0
        if self.cur() is None:
            self.finish_batch()
        else:
            self.show_step()

    def finish_batch(self):
        learned = sum(1 for x in self.batch if self.results[x["w"]] and self.results[x["w"]][-1] == ("spell", True))
        self._fill_list()
        self.batch = []
        self.refresh_words()
        self.w_info.setText(f"这一组学会 {learned} 个。学会的和错得多的已经排进间隔复习。")
        self.set_status(f"这一组学会 {learned} 个", "ok")

    def lookup(self):
        x = core.find(self.w_find.text())
        self.found = x
        self.w_found.setText(f"{x['w']}　{x['m']}" + (f"\n{x['ex']}" if x.get("ex") else "") if x else "词库里没有。可以导入词表，或在读文里加入生词本。")

    def add_found(self):
        x = getattr(self, "found", None)
        if x:
            core.add_word(x["w"])
            self.set_status(f"{x['w']} 已加入复习", "ok")

    # ================================================================ 诗词
    def _build_poems(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(14)
        side, sv = _card()
        sv.addWidget(_label("篇目", "cardTitle"))
        self.p_list = QListWidget()
        self.p_list.currentRowChanged.connect(self._pick_poem)
        sv.addWidget(self.p_list, 1)
        sv.addWidget(_btn("导入篇目", self.toggle_import, "", "粘贴题目、作者和原文，加进篇目"))
        self.imp_box = QWidget()
        iv = QVBoxLayout(self.imp_box)
        iv.setContentsMargins(0, 0, 0, 0)
        self.imp_title = QLineEdit()
        self.imp_title.setPlaceholderText("题目")
        self.imp_author = QLineEdit()
        self.imp_author.setPlaceholderText("作者（可空）")
        self.imp_text = QPlainTextEdit()
        self.imp_text.setPlaceholderText("原文，一句一行")
        for x in (self.imp_title, self.imp_author):
            x.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
            iv.addWidget(x)
        iv.addWidget(self.imp_text)
        iv.addWidget(_btn("加入篇目", self.do_import, "pri"))
        self.imp_box.hide()
        sv.addWidget(self.imp_box)
        side.setMaximumWidth(300)
        h.addWidget(side, 1)
        main, mv = _card()
        hh = QHBoxLayout()
        self.p_title = _label("", "cardTitle")
        hh.addWidget(self.p_title)
        self.p_meta = _label("", "note")
        hh.addWidget(self.p_meta, 1)
        hh.addWidget(_btn("在读文里精析", self.to_reading, "", "把这一篇送进读文：逐字讲实词、虚词、句式"))
        hh.addWidget(_btn("加入复习", self.poem_review, "", "整篇做成复习卡，按间隔复习"))
        hh.addWidget(_btn("问 AI", self.ask_ai, "", "把这一篇带进 AI 聊天：赏析、背诵窍门、默写易错字"))
        mv.addLayout(hh)
        self.p_mode = Segmented(MODES, "read")
        self.p_mode.changed.connect(self.set_mode)
        mv.addWidget(self.p_mode)
        self.p_view = QTextBrowser()
        self.p_view.setObjectName("poemView")
        self.p_view.setOpenLinks(False)
        self.p_view.anchorClicked.connect(self._reveal)
        mv.addWidget(self.p_view, 3)
        self.p_ask = _label("", "", True)
        self.p_ask.setTextFormat(Qt.TextFormat.RichText)
        mv.addWidget(self.p_ask)
        ih = QHBoxLayout()
        self.p_input_mode = Segmented([("type", "打字"), ("ink", "手写")], "type")
        self.p_input_mode.changed.connect(self._input_mode)
        ih.addWidget(self.p_input_mode)
        ih.addStretch(1)
        self.p_hint = _btn("提示", self.hint)
        ih.addWidget(self.p_hint)
        self.p_check = _btn("检查", self.check_poem, "pri")
        ih.addWidget(self.p_check)
        mv.addLayout(ih)
        self.p_inputs = QStackedWidget()
        self.p_input = QPlainTextEdit()
        self.p_input.setObjectName("poemInput")
        self.p_input.setPlaceholderText("在这里写")
        self.p_input.setMaximumHeight(130)
        self.p_inputs.addWidget(self.p_input)
        self.p_ink = InkBox()
        self.p_ink.pad.setMinimumHeight(180)
        self.p_inputs.addWidget(self.p_ink)
        mv.addWidget(self.p_inputs, 2)
        self.p_result = _label("", "", True)
        self.p_result.setTextFormat(Qt.TextFormat.RichText)
        mv.addWidget(self.p_result)
        h.addWidget(main, 3)
        return w

    def fill_poems(self, select=None):
        self.all_poems = core.poems()
        self.p_list.blockSignals(True)
        self.p_list.clear()
        for p in self.all_poems:
            st = core.poem_state(p["id"])
            it = QListWidgetItem(f"{p['title']}　{p.get('author', '')}" + (f"　{int(st['best'] * 100)}%" if st["tries"] else ""))
            it.setData(Qt.ItemDataRole.UserRole, p["id"])
            self.p_list.addItem(it)
        self.p_list.blockSignals(False)
        row = next((i for i, p in enumerate(self.all_poems) if p["id"] == select), 0)
        self.p_list.setCurrentRow(row)
        self._pick_poem(row)

    def open_poem(self, pid):
        self.show_tab("poems")
        self.fill_poems(pid)

    def _pick_poem(self, row):
        if not 0 <= row < len(self.all_poems):
            return
        self.poem = self.all_poems[row]
        p = self.poem
        self.p_title.setText(p["title"])
        self.p_meta.setText(" · ".join(x for x in (p.get("dynasty"), p.get("author"), p.get("source")) if x))
        self.revealed = set()
        self.set_mode(self.p_mode.value)

    def set_mode(self, mode):
        self.p_mode.set_value(mode)
        self.mode = mode
        self.line_i = 0
        self.scores = []
        self.revealed = set()
        self.p_result.setText("")
        self.p_input.clear()
        self.p_ink.pad.clear()
        writing = mode in ("fill", "chain", "dictate")
        for w in (self.p_input_mode, self.p_hint, self.p_check, self.p_inputs):
            w.setVisible(writing)
        self.p_input_mode.setVisible(mode == "dictate")
        if mode != "dictate":
            self._input_mode("type")
        self.render_poem()

    def _input_mode(self, m):
        self.p_input_mode.set_value(m)
        self.p_inputs.setCurrentIndex(1 if m == "ink" else 0)

    def render_poem(self):
        p, ls = self.poem, core.lines(self.poem)
        fam = "font-family:'KaiTi','STKaiti',serif;font-size:19px;line-height:190%"
        if self.mode == "read":
            body = "<br>".join(html.escape(x) for x in ls)
            notes = "".join(f"<li><b>{html.escape(k)}</b>：{html.escape(v)}</li>" for k, v in p.get("notes", {}).items())
            self.p_view.setHtml(f"<div style=\"{fam}\">{body}</div>" + (f"<p style='color:{T.muted};margin-top:14px'>注释</p><ul style='color:{T.soft}'>{notes}</ul>" if notes else ""))
            self.p_ask.setText("")
        elif self.mode == "mask":
            rows = []
            for i, x in enumerate(ls):
                if i in self.revealed:
                    rows.append(html.escape(x))
                else:
                    rows.append(f"<a href='line:{i}' style='color:{T.faint};text-decoration:none'>{core.first_chars(x)}</a>")
            self.p_view.setHtml(f"<div style=\"{fam}\">{'<br>'.join(rows)}</div>")
            self.p_ask.setText(f"<span style='color:{T.muted}'>先在心里背出每一句，再点那一句看原文。已看 {len(self.revealed)}/{len(ls)} 句。</span>")
        elif self.mode in ("fill", "chain"):
            i = self.line_i
            if i >= len(ls):
                avg = sum(self.scores) / len(self.scores) if self.scores else 0
                core.record_poem(p, self.mode, avg)
                self.p_view.setHtml(f"<div style=\"{fam}\">" + "<br>".join(html.escape(x) for x in ls) + "</div>")
                self.p_ask.setText(f"<b>做完了</b>：平均正确率 {int(avg * 100)}%。")
                self.p_check.setEnabled(False)
                return
            self.p_check.setEnabled(True)
            done = "<br>".join(html.escape(x) for x in ls[max(0, i - 2):i])
            if self.mode == "fill":
                shown, _ = core.blanks(ls[i])
                ask = "把这一句写完整（＿是挖掉的字）："
            else:
                shown = core.first_chars(ls[i])
                ask = "按首字接着背出这一句："
            self.p_view.setHtml(f"<div style=\"{fam}\"><span style='color:{T.faint}'>{done}</span>" + ("<br>" if done else "") + f"<b>{html.escape(shown)}</b></div>")
            self.p_ask.setText(f"第 {i + 1}/{len(ls)} 句 · {ask}")
        else:
            self.p_view.setHtml(f"<div style='color:{T.muted};font-size:14px;line-height:180%'>默写全文：《{html.escape(p['title'])}》"
                                f"{html.escape(p.get('author', ''))}<br>可以打字，也可以切到「手写」用数位板写；写完点「检查」，按字比对（标点不计）。全对会自动加入复习。</div>")
            self.p_ask.setText("")
            self.p_check.setEnabled(True)

    def _reveal(self, url):
        s = url.toString()
        if s.startswith("line:"):
            self.revealed.add(int(s[5:]))
            self.render_poem()

    def hint(self):
        ls = core.lines(self.poem)
        if self.mode == "dictate":
            got = core.plain(self.p_input.toPlainText())
            full = core.plain("".join(ls))
            k = 0
            while k < len(got) and k < len(full) and got[k] == full[k]:
                k += 1
            self.p_result.setText(f"下一个字：<b>{html.escape(full[k:k + 1] or '（已经写完）')}</b>")
        elif self.line_i < len(ls):
            self.p_result.setText(f"提示：{html.escape(core.first_chars(ls[self.line_i]))}")

    def check_poem(self):
        ls = core.lines(self.poem)
        if self.mode == "dictate":
            if self.p_input_mode.value == "ink":
                im = self.p_ink.pad.render_image()
                if im.isNull():
                    self.p_result.setText("先写点什么")
                    return
                self.ticket += 1
                tk = self.ticket
                self.p_result.setText("正在识别手写……")
                reader, ocr = self.reader, self.ocr
                if ocr is None:
                    from ..lecture.lookup import Ocr
                    ocr = self.ocr = Ocr()

                def work():
                    try:
                        text = core.recognize_ink(im, reader=reader, ocr=ocr)
                    except Exception:  # noqa: BLE001
                        text = ""
                    try:
                        self.bridge.recognized.emit(tk, text)
                    except RuntimeError:
                        pass
                if getattr(self, "sync_ink", False):
                    work()
                else:
                    threading.Thread(target=work, daemon=True).start()
                return
            self._judge_dictation(self.p_input.toPlainText())
            return
        if self.line_i >= len(ls):
            return
        res = core.judge(self.p_input.toPlainText(), ls[self.line_i])
        self.scores.append(res["ratio"])
        self.p_result.setText(("<span style='color:%s'>对了</span>" % T.ok if res["ok"] else
                               f"<span style='color:{T.bad}'>错 {res['wrong']} 字</span>　") + ("" if res["ok"] else res["html"]))
        self.p_input.clear()
        self.line_i += 1
        self.render_poem()

    def _recognized(self, tk, text):
        if tk != self.ticket:
            return
        if not text.strip():
            self.p_result.setText("手写没认出来：没有 AI 识图、本机也没装中文文字识别。可以改用打字。")
            return
        self.p_input.setPlainText(text)
        self._judge_dictation(text, ink=True)

    def _judge_dictation(self, text, ink=False):
        res = core.judge(text, self.poem["text"])
        st = core.record_poem(self.poem, "dictate", res["ratio"])
        head = (f"<span style='color:{T.ok}'><b>全对</b>，已加入复习。</span>" if res["ok"] else
                f"<span style='color:{T.bad}'><b>错 {res['wrong']} 字</b></span>　正确率 {int(res['ratio'] * 100)}%（最好 {int(st['best'] * 100)}%）")
        self.p_result.setText(head + ("　（手写识别后比对）" if ink else "") + f"<div style='font-size:16px;line-height:170%'>{res['html']}</div>")
        self.last_result = res

    def toggle_import(self):
        self.imp_box.setVisible(not self.imp_box.isVisible())

    def do_import(self):
        try:
            p = core.import_poem(self.imp_title.text(), self.imp_text.toPlainText(), self.imp_author.text())
        except ValueError as e:
            self.set_status(str(e), "bad")
            return
        self.imp_box.hide()
        self.fill_poems(p["id"])
        self.set_status(f"已加入《{p['title']}》", "ok")

    def to_reading(self):
        if self.open_reading:
            self.open_reading(self.poem["text"])
        else:
            self.set_status("读文没有打开")

    def ask_ai(self):
        from ..chat import bridge
        from ..chat.core import text_attachment
        p = self.poem
        bridge.ask(self, [text_attachment(f"《{p['title']}》{p.get('dynasty', '')} {p.get('author', '')}\n{p['text']}", p["title"], "text")],
                   "讲讲这篇的内容和情感，再告诉我默写时容易写错的字。")

    def poem_review(self):
        core.add_poem_review(self.poem)
        self.set_status(f"《{self.poem['title']}》已加入复习，今天就能复习", "ok")

    # ================================================================ 外观
    def apply_theme(self):
        self.setStyleSheet(qss() + f"""
QWidget#recitePage {{ background:{"transparent" if self.compact else T.bg}; color:{T.fg}; }}
QLabel#examTitle {{ color:{T.fg}; font-size:20px; font-weight:700; padding-right:6px; }}
QLabel#examStatus {{ font-size:12px; padding-left:8px; color:{T.muted}; }}
QFrame#examCard {{ background:{T.surface}; border:1px solid {T.line}; border-radius:10px; }}
QLabel#cardTitle {{ color:{T.fg}; font-size:14px; font-weight:700; }}
QLabel#bigWord {{ color:{T.fg}; font-size:38px; font-weight:700; padding:14px 0 4px 0; }}
QPushButton#optBtn {{ text-align:left; padding:9px 14px; font-size:14px; }}
QTextBrowser#poemView {{ background:{T.raised}; color:{T.fg}; border:1px solid {T.line}; border-radius:10px; padding:10px 16px; }}
QPlainTextEdit#poemInput {{ font-size:16px; }}
QListWidget::item:selected {{ background:{css(T.accent, .14)}; }}
""")
