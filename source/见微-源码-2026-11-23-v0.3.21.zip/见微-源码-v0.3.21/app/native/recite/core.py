"""背诵的数据与规则（不碰界面）。

单词：内置词库（words_data）+ 导入的自定义词（recite-words.json 的 custom）。
      背一个词分四步：认词 → 释义四选一 → 例句（有才出）→ 拼写；拼写对了算学会，进间隔复习（学习记录的知识卡，src=word）。
      错两次以上的词也进复习。读文里遇到的生词 add_word() 一键加入。
诗词：内置篇目（poems_data）+ 导入的（recite-poems.json）。练法：逐句遮挡、填空、首字接龙、默写；判分 judge() 按字比，忽略标点。
      默写全对或手动「加入复习」时，整篇进间隔复习（src=poem）。
进度 recite.json = {v:1, words:{词:{step,right,wrong,learned,last}}, poems:{id:{tries,best,last}}}。
"""
from __future__ import annotations

import csv
import difflib
import hashlib
import html
import io
import random
import re
import time
from pathlib import Path

from ..kit.home import load_json, save_json
from . import poems_data, words_data

FILE = "recite.json"
CUSTOM_WORDS = "recite-words.json"
CUSTOM_POEMS = "recite-poems.json"
STEPS = ("recognize", "choose", "example", "spell")
STEP_NAME = dict(recognize="认词", choose="释义四选一", example="例句", spell="拼写")
PUNCT = set("，。、；：？！“”‘’「」『』《》（）()…—·,.;:?!\"' \t\r\n　")


def _progress():
    d = load_json(FILE, None)
    if not isinstance(d, dict) or d.get("v") != 1:
        d = dict(v=1, words={}, poems={})
    d.setdefault("words", {})
    d.setdefault("poems", {})
    return d


def _save(d):
    save_json(FILE, d)


# ================================================================ 单词
def builtin_words() -> list[dict]:
    out = []
    for line in words_data.RAW.strip().splitlines():
        w, _, m = line.partition("|")
        if w.strip() and m.strip():
            out.append(dict(w=w.strip(), m=m.strip(), ex=words_data.EXAMPLES.get(w.strip(), ""), src="builtin"))
    return out


def custom_words() -> list[dict]:
    d = load_json(CUSTOM_WORDS, None)
    return [x for x in (d.get("custom") if isinstance(d, dict) else []) or [] if isinstance(x, dict) and x.get("w")]


def words() -> list[dict]:
    seen, out = set(), []
    for x in custom_words() + builtin_words():        # 自定义的释义优先
        k = x["w"].lower()
        if k not in seen:
            seen.add(k)
            out.append(x)
    return sorted(out, key=lambda x: x["w"].lower())


def find(word):
    k = str(word).strip().lower()
    return next((x for x in words() if x["w"].lower() == k), None)


def parse_wordlist(text: str) -> list[dict]:
    """「单词 释义」一行一个：分隔可以是 Tab、逗号、竖线、等号，或者单词后面直接跟中文。第三列（可选）是例句。"""
    out = []
    rows = list(csv.reader(io.StringIO(text), delimiter="\t")) if "\t" in text else None
    for raw in (["\t".join(r) for r in rows] if rows else text.splitlines()):
        line = raw.strip().lstrip("﻿")
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"\t|\s*[|=]\s*|\s*,\s*(?=[^,]*[一-鿿])|，", line, maxsplit=2)
        if len(parts) < 2:
            m = re.match(r"^([A-Za-z][A-Za-z\-' ]*?)\s+(.*[一-鿿].*)$", line)
            parts = [m.group(1), m.group(2)] if m else []
        if len(parts) >= 2 and re.fullmatch(r"[A-Za-z][A-Za-z\-' ]{0,40}", parts[0].strip()) and parts[1].strip():
            out.append(dict(w=parts[0].strip(), m=parts[1].strip(), ex=(parts[2].strip() if len(parts) > 2 else ""), src="custom"))
    return out


def import_words(text_or_path) -> int:
    """导入自定义词表（txt / csv 文字或文件路径）。返回新增或更新的条数。"""
    p = Path(str(text_or_path))
    text = text_or_path
    if len(str(text_or_path)) < 300 and p.suffix.lower() in (".txt", ".csv", ".tsv") and p.exists():
        raw = p.read_bytes()
        for enc in ("utf-8-sig", "gb18030"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
    items = parse_wordlist(str(text))
    cur = {x["w"].lower(): x for x in custom_words()}
    for x in items:
        cur[x["w"].lower()] = x
    save_json(CUSTOM_WORDS, dict(v=1, custom=list(cur.values())))
    return len(items)


def word_card(x) -> dict:
    return dict(src="word", n=x["w"], d=x["m"], f=[x["ex"]] if x.get("ex") else [], p=[])


def add_word(word, meaning="", example="", subject="英语") -> str:
    """读文里的生词、AI 聊天里的「生成单词卡」：词库里没有就加进自定义；然后放进间隔复习，今天就能复习。返回复习项 key。"""
    from .. import learning
    x = find(word)
    if x is None or (meaning and meaning != x["m"]):
        if not meaning and x is None:
            meaning = "（释义待补）"
        cur = {c["w"].lower(): c for c in custom_words()}
        x = dict(w=str(word).strip(), m=meaning or x["m"], ex=example or (x or {}).get("ex", ""), src="custom")
        cur[x["w"].lower()] = x
        save_json(CUSTOM_WORDS, dict(v=1, custom=list(cur.values())))
    return learning.add_card(word_card(x), subject)


def word_state(w) -> dict:
    return _progress()["words"].get(w.lower(), dict(step=0, right=0, wrong=0, learned=False, last=0))


def batch(n=10, seed=None, only_new=True) -> list[dict]:
    """这一组要背的词：先是没学会、错过的，再按词库顺序补新词。"""
    prog = _progress()["words"]
    ws = words()
    weak = [x for x in ws if not prog.get(x["w"].lower(), {}).get("learned") and prog.get(x["w"].lower(), {}).get("wrong", 0) > 0]
    new = [x for x in ws if x["w"].lower() not in prog]
    rest = [x for x in ws if not prog.get(x["w"].lower(), {}).get("learned") and x not in weak and x not in new]
    rnd = random.Random(seed)
    rnd.shuffle(new)
    pool = weak + rest + new if only_new else ws
    return pool[:n]


def steps_for(x) -> list[str]:
    return [s for s in STEPS if s != "example" or x.get("ex")]


def choices(x, n=4, seed=None) -> list[str]:
    """释义四选一：正确释义 + 3 个别的词的释义（词性尽量相同）。"""
    rnd = random.Random(seed if seed is not None else x["w"])
    pos = x["m"].split(" ")[0]
    others = [y["m"] for y in words() if y["w"] != x["w"] and y["m"] != x["m"]]
    same = [m for m in others if m.split(" ")[0] == pos]
    pick = rnd.sample(same, min(n - 1, len(same))) if len(same) >= n - 1 else rnd.sample(others, n - 1)
    out = pick + [x["m"]]
    rnd.shuffle(out)
    return out


def blank_example(x) -> str:
    """例句挖空：把这个词（含常见词形变化）换成横线。"""
    ex = x.get("ex") or ""
    stem = re.escape(x["w"][:-1] if len(x["w"]) > 4 and x["w"][-1] in "ey" else x["w"])
    return re.sub(rf"\b{stem}\w*", "_____", ex, flags=re.I)


def check_spell(x, answer) -> bool:
    return re.sub(r"\s+", " ", str(answer).strip().lower()) == x["w"].lower()


def record_word(x, step, ok, now=None) -> dict:
    """记一步的结果。拼写对了算学会（进间隔复习）；错两次的也进复习。"""
    d = _progress()
    st = d["words"].setdefault(x["w"].lower(), dict(step=0, right=0, wrong=0, learned=False, last=0))
    st["last"] = now or time.time()
    if ok:
        st["right"] += 1
        st["step"] = max(st["step"], STEPS.index(step) + 1)
    else:
        st["wrong"] += 1
    newly = step == "spell" and ok and not st["learned"]
    if newly:
        st["learned"] = True
    _save(d)
    if newly or (not ok and st["wrong"] == 2):
        from .. import learning
        learning.add_card(word_card(x), "英语")
    try:
        from .. import learning
        learning.record("word:" + x["w"].lower(), "英语", 0, correct=bool(ok), source="program",
                        event_id=hashlib.sha1(f"{x['w']}|{step}|{st['last']}".encode()).hexdigest()[:16])
    except Exception:   # noqa: BLE001
        pass
    return dict(st)


def word_stats() -> dict:
    prog = _progress()["words"]
    ws = words()
    learned = sum(1 for x in ws if prog.get(x["w"].lower(), {}).get("learned"))
    return dict(total=len(ws), learned=learned, seen=sum(1 for x in ws if x["w"].lower() in prog),
                custom=len(custom_words()))


# ================================================================ 诗词
def poem_id(p) -> str:
    return p.get("id") or hashlib.sha1((p["title"] + p.get("author", "")).encode()).hexdigest()[:10]


def poems() -> list[dict]:
    out = []
    for p in poems_data.POEMS + list((load_json(CUSTOM_POEMS, {}) or {}).get("poems") or []):
        q = dict(p)
        q["id"] = poem_id(p)
        q.setdefault("notes", {})
        out.append(q)
    return out


def get_poem(pid):
    return next((p for p in poems() if p["id"] == pid), None)


def import_poem(title, text, author="", dynasty="", source="") -> dict:
    text = "\n".join(ln.strip() for ln in str(text).strip().splitlines() if ln.strip())
    if not title.strip() or not text:
        raise ValueError("要有题目和原文")
    d = load_json(CUSTOM_POEMS, {}) or {}
    ps = [p for p in d.get("poems") or [] if p.get("title") != title.strip()]
    p = dict(title=title.strip(), author=author.strip(), dynasty=dynasty.strip(), source=source.strip(), text=text, notes={})
    ps.append(p)
    save_json(CUSTOM_POEMS, dict(v=1, poems=ps))
    return dict(p, id=poem_id(p))


def lines(p) -> list[str]:
    """按行（统编本的分句）给出。"""
    return [ln.strip() for ln in p["text"].splitlines() if ln.strip()]


def clauses(line) -> list[str]:
    """一行里按逗号句号拆成小句（保留标点在小句末尾）。"""
    return [c for c in re.findall(r"[^，。；？！：]+[，。；？！：]?", line) if c.strip()]


def plain(s) -> str:
    return "".join(ch for ch in str(s) if ch not in PUNCT)


def first_chars(line) -> str:
    """首字提示：每个小句的第一个字，其余用「□」。"""
    out = []
    for c in clauses(line):
        body = plain(c)
        out.append((body[:1] + "□" * (len(body) - 1)) if body else "")
    return "，".join(out)


def blanks(line, k=0.35, seed=None) -> tuple[str, list[int]]:
    """填空：挖掉一部分字（不挖标点），返回 (带「＿」的句子, 被挖的位置)。实词优先：避开常见虚词。"""
    rnd = random.Random(seed if seed is not None else line)
    idx = [i for i, ch in enumerate(line) if ch not in PUNCT and ch not in "之乎者也而以于其不之兮矣焉哉"]
    n = max(1, int(len(idx) * k))
    pick = sorted(rnd.sample(idx, min(n, len(idx))))
    return "".join("＿" if i in pick else ch for i, ch in enumerate(line)), pick


def judge(answer, target) -> dict:
    """默写判分：忽略标点和空白逐字比。返回 ok（全对）、ratio、wrong（错字数）、html（错的、漏的标出来）。"""
    a, t = plain(answer), plain(target)
    sm = difflib.SequenceMatcher(None, t, a, autojunk=False)
    parts, wrong = [], 0
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            parts.append(html.escape(t[i1:i2]))
        elif op == "replace":
            wrong += max(i2 - i1, j2 - j1)
            parts.append(f"<span style='color:#C2331F'><s>{html.escape(a[j1:j2])}</s></span><u>{html.escape(t[i1:i2])}</u>")
        elif op == "delete":
            wrong += i2 - i1
            parts.append(f"<u>{html.escape(t[i1:i2])}</u>")
        else:
            wrong += j2 - j1
            parts.append(f"<span style='color:#C2331F'><s>{html.escape(a[j1:j2])}</s></span>")
    ratio = sm.ratio() if t else 0.0
    return dict(ok=wrong == 0 and bool(t), ratio=round(ratio, 3), wrong=wrong, html="".join(parts))


def poem_card(p) -> dict:
    return dict(src="poem", n=p["title"], d=p["text"], f=[" ".join(x for x in (p.get("dynasty"), p.get("author"), p.get("source")) if x)], p=[])


def add_poem_review(p) -> str:
    from .. import learning
    return learning.add_card(poem_card(p), "语文")


def record_poem(p, mode, ratio, now=None) -> dict:
    d = _progress()
    st = d["poems"].setdefault(p["id"], dict(tries=0, best=0.0, last=0, modes={}))
    st["tries"] += 1
    st["best"] = max(st["best"], float(ratio))
    st["last"] = now or time.time()
    st["modes"][mode] = max(st["modes"].get(mode, 0.0), float(ratio))
    _save(d)
    if mode == "dictate" and ratio >= 0.999:
        add_poem_review(p)
    return dict(st)


def poem_state(pid) -> dict:
    return _progress()["poems"].get(pid, dict(tries=0, best=0.0, last=0, modes={}))


def recognize_ink(image, reader=None, ocr=None) -> str:
    """手写默写 → 文字（和考试的手写识别同一条路：先 AI 识图，再本机 OCR）。"""
    from ..exam.grade import recognize_ink as _rec
    got = _rec(dict(questions=[]), {1: image}, reader=reader, ocr=ocr)
    return got.get(1, "")
