"""内置词库：高考英语核心词（按《普通高中英语课程标准》词汇表里最常考的一批挑的，不是全部 3500 词）。

一行一个：单词|词性和释义。完整的 3500 词表请用「导入词表」（txt / csv：单词 + 释义）。
例句在 EXAMPLES 里，只给一部分词；没有例句的词跳过例句这一步。
"""

RAW = """
abandon|v. 放弃；抛弃
ability|n. 能力；才能
abroad|adv. 在国外；到国外
absence|n. 缺席；不在
absolute|adj. 绝对的；完全的
absorb|v. 吸收；使专心
abstract|adj. 抽象的 n. 摘要
academic|adj. 学术的；学业的
accent|n. 口音；重音
accept|v. 接受；认可
access|n. 通道；使用权 v. 进入
accident|n. 事故；意外
accompany|v. 陪伴；伴随
accomplish|v. 完成；实现
account|n. 账户；描述 v. 解释
accurate|adj. 准确的；精确的
accuse|v. 指控；指责
achieve|v. 实现；达到
achievement|n. 成就；成绩
acknowledge|v. 承认；致谢
acquire|v. 获得；习得
adapt|v. 适应；改编
addition|n. 加；增加物
adjust|v. 调整；适应
admire|v. 钦佩；欣赏
admit|v. 承认；准许进入
adopt|v. 采用；收养
advance|v. 前进；提高 n. 进步
advantage|n. 优势；有利条件
adventure|n. 冒险；奇遇
advertisement|n. 广告
advice|n. 建议；忠告
advocate|v. 提倡 n. 拥护者
affect|v. 影响；感动
afford|v. 买得起；抽得出（时间）
agency|n. 代理处；机构
agriculture|n. 农业
aim|n. 目标 v. 瞄准；旨在
alarm|n. 警报；惊恐 v. 使惊恐
alternative|adj. 可替代的 n. 选择
amaze|v. 使惊奇
ambition|n. 雄心；抱负
amount|n. 数量；总额
amuse|v. 逗乐；使发笑
analyse|v. 分析
ancestor|n. 祖先
ancient|adj. 古代的；古老的
announce|v. 宣布；通告
annoy|v. 使恼怒
annual|adj. 每年的；年度的
anxious|adj. 焦虑的；渴望的
apologize|v. 道歉
apparent|adj. 明显的；表面上的
appeal|v. 呼吁；吸引 n. 吸引力
appear|v. 出现；似乎
appetite|n. 食欲；欲望
applaud|v. 鼓掌；称赞
apply|v. 申请；应用
appointment|n. 约会；任命
appreciate|v. 欣赏；感激
approach|v. 接近 n. 方法
appropriate|adj. 合适的；恰当的
approve|v. 批准；赞成
argue|v. 争论；主张
arise|v. 出现；产生
arrange|v. 安排；整理
arrest|v. 逮捕
article|n. 文章；物品；冠词
artificial|adj. 人造的；人工的
ashamed|adj. 羞愧的
aspect|n. 方面；外观
assess|v. 评估；评价
assist|v. 帮助；协助
associate|v. 联系；交往
assume|v. 假定；承担
atmosphere|n. 大气；气氛
attach|v. 附上；系
attack|v./n. 攻击；进攻
attempt|v./n. 尝试；企图
attend|v. 出席；照料
attention|n. 注意；关注
attitude|n. 态度；看法
attract|v. 吸引
attractive|adj. 有吸引力的
audience|n. 观众；听众
author|n. 作者
authority|n. 权威；当局
available|adj. 可获得的；有空的
average|adj. 平均的；普通的 n. 平均数
avoid|v. 避免；躲开
award|n. 奖品 v. 授予
aware|adj. 意识到的；知道的
awful|adj. 糟糕的；可怕的
awkward|adj. 尴尬的；笨拙的
background|n. 背景
balance|n. 平衡 v. 使平衡
ban|v./n. 禁止
bargain|n. 便宜货 v. 讨价还价
barrier|n. 障碍；屏障
basis|n. 基础；根据
behave|v. 表现；守规矩
behaviour|n. 行为；举止
belief|n. 信念；信仰
belong|v. 属于
benefit|n. 益处 v. 有益于
bitter|adj. 苦的；痛苦的
blame|v. 责备 n. 责任
blank|adj. 空白的 n. 空白
bless|v. 祝福；保佑
board|n. 木板；董事会 v. 登上
boom|n./v. 繁荣；激增
border|n. 边界；边境
bother|v. 打扰；烦恼
bound|adj. 一定的；被束缚的
brave|adj. 勇敢的
breath|n. 呼吸；气息
breathe|v. 呼吸
brief|adj. 简短的
brilliant|adj. 杰出的；明亮的
budget|n. 预算
burden|n. 负担
burst|v. 爆发；突然…起来
calm|adj. 平静的 v. 使平静
campaign|n. 运动；战役
cancel|v. 取消
candidate|n. 候选人；考生
capable|adj. 有能力的
capacity|n. 容量；能力
career|n. 职业；生涯
casual|adj. 随便的；偶然的
celebrate|v. 庆祝
ceremony|n. 典礼；仪式
challenge|n./v. 挑战
champion|n. 冠军；拥护者
channel|n. 频道；渠道
chapter|n. 章；篇
character|n. 性格；角色；汉字
charge|v. 收费；充电；指控 n. 费用；负责
charity|n. 慈善；慈善机构
chase|v. 追逐；追求
cheat|v. 欺骗；作弊
chemical|adj. 化学的 n. 化学品
circumstance|n. 情况；环境
citizen|n. 公民；市民
civil|adj. 公民的；国内的
claim|v. 声称；索要 n. 声明
classic|adj. 经典的 n. 名著
client|n. 客户；委托人
climate|n. 气候；风气
code|n. 代码；规则
collapse|v./n. 倒塌；崩溃
colleague|n. 同事
collect|v. 收集；领取
combine|v. 结合；联合
comfort|n./v. 安慰；舒适
command|n./v. 命令；掌握
comment|n./v. 评论
commercial|adj. 商业的 n. 广告
commit|v. 犯（错）；承诺
committee|n. 委员会
common|adj. 普通的；共同的
communicate|v. 交流；传达
community|n. 社区；群体
companion|n. 同伴；伴侣
company|n. 公司；陪伴
compare|v. 比较；比作
compete|v. 竞争；比赛
competition|n. 竞争；比赛
complain|v. 抱怨；投诉
complete|adj. 完整的 v. 完成
complex|adj. 复杂的
concentrate|v. 集中；专心
concept|n. 概念
concern|n. 担心；关心 v. 涉及
conclusion|n. 结论；结束
condition|n. 条件；状况
conduct|v. 实施；指挥 n. 行为
conference|n. 会议
confidence|n. 信心；信任
confident|adj. 自信的
confirm|v. 确认；证实
conflict|n. 冲突
confuse|v. 使困惑；混淆
congratulate|v. 祝贺
connect|v. 连接；联系
conscious|adj. 有意识的；清醒的
consequence|n. 后果；结果
conservation|n. 保护；保存
consider|v. 考虑；认为
considerate|adj. 体贴的
consist|v. 由…组成（of）
constant|adj. 不断的；恒定的
construct|v. 建造；构造
consult|v. 咨询；查阅
consume|v. 消耗；消费
contact|n./v. 联系；接触
contain|v. 包含；容纳
contemporary|adj. 当代的
content|n. 内容 adj. 满足的
contest|n. 比赛；竞争
context|n. 上下文；背景
continent|n. 大陆；洲
contribute|v. 贡献；捐献；促成
contribution|n. 贡献；捐款
control|v./n. 控制
convenient|adj. 方便的
conversation|n. 谈话
convince|v. 使相信；说服
cooperate|v. 合作
cope|v. 处理；应付（with）
correspond|v. 通信；相一致
cost|n. 费用 v. 花费
courage|n. 勇气
crash|v./n. 碰撞；坠毁
create|v. 创造
creative|adj. 有创造力的
creature|n. 生物；动物
credit|n. 信用；学分；赞扬
crisis|n. 危机
critical|adj. 批评的；关键的
criticize|v. 批评
crowd|n. 人群 v. 挤满
cruel|adj. 残忍的
cultural|adj. 文化的
cure|v. 治愈 n. 疗法
curious|adj. 好奇的
custom|n. 习俗；海关（customs）
damage|n./v. 损坏；损害
deadline|n. 截止日期
deal|v. 处理（with） n. 交易
debate|n./v. 辩论
decade|n. 十年
decline|v. 下降；婉拒
decorate|v. 装饰
decrease|v./n. 减少
dedicate|v. 奉献；致力于
defeat|v. 打败 n. 失败
defend|v. 保卫；为…辩护
definite|adj. 明确的；肯定的
degree|n. 程度；度数；学位
delay|v./n. 推迟；耽搁
delicate|adj. 精致的；易碎的
delicious|adj. 美味的
delight|n. 高兴 v. 使高兴
deliver|v. 递送；发表（演讲）
demand|n./v. 要求；需求
demonstrate|v. 证明；演示；示威
deny|v. 否认；拒绝给予
depend|v. 依靠；取决于（on）
deposit|n. 存款；押金 v. 存放
depress|v. 使沮丧
describe|v. 描述
desert|n. 沙漠 v. 抛弃
deserve|v. 应得；值得
design|n./v. 设计
desire|n./v. 渴望
despite|prep. 尽管
destination|n. 目的地
destroy|v. 毁坏；破坏
detail|n. 细节
determine|v. 决定；下决心
develop|v. 发展；开发；冲洗
device|n. 装置；设备
devote|v. 致力于；献身（to）
dialogue|n. 对话
differ|v. 不同
difficulty|n. 困难
digital|adj. 数字的；数码的
dignity|n. 尊严
disability|n. 残疾
disagree|v. 不同意
disappear|v. 消失
disappoint|v. 使失望
disaster|n. 灾难
discount|n. 折扣
discover|v. 发现
discuss|v. 讨论
disease|n. 疾病
dismiss|v. 解散；不予考虑
display|v./n. 展示；陈列
distance|n. 距离
distinct|adj. 明显的；不同的
distinguish|v. 区分；辨别
distribute|v. 分发；分配
disturb|v. 打扰；扰乱
divide|v. 分；划分
document|n. 文件
domestic|adj. 国内的；家庭的
donate|v. 捐赠
dramatic|adj. 戏剧性的；巨大的
drag|v. 拖；拉
dream|n./v. 梦；梦想
due|adj. 预期的；应付的；由于（to）
dynasty|n. 朝代
eager|adj. 渴望的
earn|v. 挣得；赢得
economic|adj. 经济的
economy|n. 经济；节约
edition|n. 版本
educate|v. 教育
effect|n. 效果；影响
effective|adj. 有效的
efficient|adj. 高效的
effort|n. 努力
elect|v. 选举
electric|adj. 电的
element|n. 元素；要素
eliminate|v. 消除；淘汰
embarrass|v. 使尴尬
emerge|v. 出现；浮现
emergency|n. 紧急情况
emotion|n. 情感；情绪
emphasis|n. 强调；重点
employ|v. 雇用；使用
enable|v. 使能够
encounter|v./n. 遇到；邂逅
encourage|v. 鼓励
energy|n. 能量；精力
engage|v. 参与；吸引；雇用
enhance|v. 提高；增强
enjoy|v. 享受；喜欢
enormous|adj. 巨大的
ensure|v. 确保
entertain|v. 娱乐；招待
enthusiasm|n. 热情
entire|adj. 整个的
entrance|n. 入口；进入
environment|n. 环境
equal|adj. 相等的；平等的
equip|v. 装备
equipment|n. 设备
escape|v./n. 逃脱
essay|n. 文章；短文
essential|adj. 必要的；本质的
establish|v. 建立；确立
estimate|v./n. 估计
evaluate|v. 评价；评估
event|n. 事件；活动
eventually|adv. 最后；终于
evidence|n. 证据
evolution|n. 进化；演变
exact|adj. 确切的
examine|v. 检查；考查
exchange|v./n. 交换；交流
excite|v. 使兴奋
exhibition|n. 展览
exist|v. 存在
expand|v. 扩大；扩展
expect|v. 期待；预料
expense|n. 费用；花费
experience|n. 经验；经历 v. 经历
experiment|n. 实验
expert|n. 专家
explain|v. 解释
explore|v. 探索；探究
export|v./n. 出口
expose|v. 暴露；使接触
express|v. 表达 n. 快车
extend|v. 延伸；扩展
extra|adj. 额外的
extraordinary|adj. 非凡的；特别的
extreme|adj. 极端的；极度的
facility|n. 设施；设备
factor|n. 因素
fade|v. 褪色；逐渐消失
fail|v. 失败；未能
faith|n. 信念；信任
familiar|adj. 熟悉的
fantastic|adj. 极好的；奇异的
fare|n. 车费
fascinate|v. 使着迷
fault|n. 过错；缺点
favour|n. 恩惠；帮助
feature|n. 特征 v. 以…为特色
fee|n. 费用
festival|n. 节日
figure|n. 数字；人物；身材 v. 认为
file|n. 文件
finance|n. 财政；金融
flexible|adj. 灵活的
float|v. 漂浮
flood|n. 洪水 v. 淹没
focus|v./n. 集中；焦点
forbid|v. 禁止
force|n. 力量 v. 强迫
forecast|n./v. 预报
foreign|adj. 外国的
forgive|v. 原谅
former|adj. 以前的；前者的
fortune|n. 运气；财富
found|v. 创建；建立
frequent|adj. 频繁的
frighten|v. 使害怕
frustrate|v. 使沮丧；挫败
fuel|n. 燃料
function|n. 功能 v. 运转
fund|n. 基金；资金
fundamental|adj. 基本的；根本的
furniture|n. 家具
gain|v. 获得；增加 n. 收获
gather|v. 聚集；收集
generate|v. 产生
generation|n. 一代人；产生
generous|adj. 慷慨的
gentle|adj. 温柔的；轻柔的
genuine|adj. 真正的；真诚的
global|adj. 全球的
goal|n. 目标；球门
govern|v. 统治；管理
grab|v. 抓取
grade|n. 年级；等级；成绩
gradual|adj. 逐渐的
graduate|v. 毕业 n. 毕业生
grateful|adj. 感激的
greet|v. 问候；迎接
guarantee|v./n. 保证
guilty|adj. 内疚的；有罪的
habit|n. 习惯
handle|v. 处理 n. 把手
harbour|n. 港口
harm|n./v. 伤害
harmony|n. 和谐
headline|n. 标题；头条
heal|v. 治愈；愈合
heritage|n. 遗产；传统
hesitate|v. 犹豫
highlight|v. 突出 n. 最精彩部分
honour|n. 荣誉 v. 尊敬
horizon|n. 地平线；眼界
host|n. 主人；主持人 v. 主办
household|n. 家庭 adj. 家庭的
humble|adj. 谦逊的；卑微的
humour|n. 幽默
identify|v. 识别；确认；认同
identity|n. 身份；特征
ignore|v. 忽视
illegal|adj. 非法的
illustrate|v. 说明；给…加插图
image|n. 形象；图像
imagine|v. 想象
immediate|adj. 立即的；直接的
impact|n. 影响；冲击
import|v./n. 进口
impress|v. 给…留下深刻印象
improve|v. 改进；提高
incident|n. 事件
include|v. 包括
income|n. 收入
increase|v./n. 增加
incredible|adj. 难以置信的
independent|adj. 独立的
indicate|v. 表明；指出
individual|adj. 个人的 n. 个人
industry|n. 工业；行业
influence|n./v. 影响
inform|v. 通知；告知
ingredient|n. 原料；成分
initial|adj. 最初的
injure|v. 伤害
innocent|adj. 无辜的；天真的
insist|v. 坚持；坚决要求（on）
inspire|v. 鼓舞；激发灵感
install|v. 安装
instance|n. 例子
instant|adj. 立即的；速溶的
instruct|v. 指导；命令
instrument|n. 仪器；乐器
insurance|n. 保险
intend|v. 打算
intense|adj. 强烈的；紧张的
interact|v. 互动；相互作用
interfere|v. 干涉；妨碍
internal|adj. 内部的
interpret|v. 解释；口译
interrupt|v. 打断
introduce|v. 介绍；引进
invent|v. 发明
invest|v. 投资
investigate|v. 调查
invite|v. 邀请
involve|v. 涉及；使参与
issue|n. 问题；（报刊）一期 v. 发布
item|n. 项目；物品
journey|n. 旅行；旅程
judge|v. 判断 n. 法官；裁判
justice|n. 正义；公正
keen|adj. 热衷的；敏锐的
knowledge|n. 知识
label|n. 标签 v. 贴标签
labour|n. 劳动
landscape|n. 风景
latest|adj. 最新的
launch|v. 发射；发起
layer|n. 层
leadership|n. 领导力
lecture|n. 讲座
leisure|n. 闲暇
liberty|n. 自由
license|n. 执照
limit|n./v. 限制
literature|n. 文学
local|adj. 当地的
locate|v. 位于；找出
lonely|adj. 孤独的
loyal|adj. 忠诚的
luxury|n. 奢侈；奢侈品
maintain|v. 保持；维修
major|adj. 主要的 n. 专业 v. 主修
manage|v. 管理；设法做成
manner|n. 方式；礼貌（manners）
marvellous|adj. 了不起的
mature|adj. 成熟的
measure|v. 测量 n. 措施
medal|n. 奖牌
media|n. 媒体
medicine|n. 药；医学
melt|v. 融化
memory|n. 记忆；回忆
mental|adj. 精神的；心理的
mention|v./n. 提及
mess|n. 混乱
method|n. 方法
military|adj. 军事的
minor|adj. 较小的；次要的
mission|n. 使命；任务
mistake|n. 错误 v. 误认
mood|n. 心情
moral|adj. 道德的 n. 寓意
motivate|v. 激励
motivation|n. 动力；动机
mysterious|adj. 神秘的
narrow|adj. 狭窄的
nation|n. 国家；民族
native|adj. 本地的；母语的
natural|adj. 自然的
negative|adj. 消极的；否定的
neglect|v. 忽视
negotiate|v. 谈判；协商
nervous|adj. 紧张的
network|n. 网络
nevertheless|adv. 然而；不过
noble|adj. 高尚的；贵族的
normal|adj. 正常的
notice|v. 注意到 n. 通知
novel|n. 小说 adj. 新颖的
nuclear|adj. 核的
numerous|adj. 许多的
nutrition|n. 营养
obey|v. 服从；遵守
object|n. 物体；目标 v. 反对
obligation|n. 义务
observe|v. 观察；遵守
obtain|v. 获得
obvious|adj. 明显的
occasion|n. 场合；时机
occupy|v. 占据；使忙碌
occur|v. 发生；想到（to）
offend|v. 冒犯
official|adj. 官方的 n. 官员
operate|v. 操作；做手术
opinion|n. 意见；看法
opponent|n. 对手
opportunity|n. 机会
oppose|v. 反对
optimistic|adj. 乐观的
option|n. 选择
ordinary|adj. 普通的
organize|v. 组织
origin|n. 起源；出身
original|adj. 原来的；独创的
otherwise|adv. 否则；另外
outcome|n. 结果
outstanding|adj. 杰出的
overcome|v. 克服
overlook|v. 忽视；俯瞰
owe|v. 欠；归功于
pace|n. 步伐；速度
panic|n./v. 恐慌
participate|v. 参加（in）
particular|adj. 特别的；特定的
partner|n. 伙伴
passage|n. 段落；通道
passion|n. 激情；热爱
patience|n. 耐心
patient|adj. 耐心的 n. 病人
pattern|n. 模式；图案
peculiar|adj. 奇怪的；特有的
perform|v. 表演；执行
permanent|adj. 永久的
permit|v. 允许 n. 许可证
persist|v. 坚持
personality|n. 个性
perspective|n. 观点；视角
persuade|v. 说服
phenomenon|n. 现象
physical|adj. 身体的；物理的
pioneer|n. 先驱
plenty|n. 大量；充足
policy|n. 政策
polite|adj. 礼貌的
pollution|n. 污染
popular|adj. 受欢迎的；流行的
population|n. 人口
portion|n. 部分；一份
positive|adj. 积极的；肯定的
possess|v. 拥有
potential|adj. 潜在的 n. 潜力
poverty|n. 贫穷
practical|adj. 实际的；实用的
praise|v./n. 赞扬
precious|adj. 珍贵的
predict|v. 预测
prefer|v. 更喜欢
prejudice|n. 偏见
prepare|v. 准备
present|adj. 现在的；出席的 n. 礼物 v. 呈现
preserve|v. 保护；保存
pressure|n. 压力
pretend|v. 假装
prevent|v. 阻止；预防
previous|adj. 先前的
primary|adj. 主要的；初级的
principle|n. 原则；原理
priority|n. 优先；优先事项
privacy|n. 隐私
procedure|n. 程序；步骤
process|n. 过程 v. 加工
produce|v. 生产；产生
profession|n. 职业
profit|n. 利润 v. 获益
progress|n./v. 进步；进展
prohibit|v. 禁止
project|n. 项目；工程
promise|v./n. 承诺
promote|v. 促进；提升；推销
prompt|adj. 迅速的 v. 促使
proper|adj. 适当的
property|n. 财产；性质
proportion|n. 比例
propose|v. 提议；求婚
protect|v. 保护
protest|v./n. 抗议
proud|adj. 骄傲的；自豪的
prove|v. 证明；证明是
provide|v. 提供
psychology|n. 心理学；心理
publish|v. 出版；发表
punish|v. 惩罚
purchase|v./n. 购买
pursue|v. 追求；继续
puzzle|n. 谜 v. 使困惑
qualify|v. 使有资格
quality|n. 质量；品质
quantity|n. 数量
quarrel|v./n. 争吵
quote|v. 引用；报价
range|n. 范围 v. 变动
rank|n. 等级 v. 排名
rare|adj. 稀有的；罕见的
rate|n. 比率；速度 v. 评价
react|v. 反应
reality|n. 现实
realize|v. 意识到；实现
reasonable|adj. 合理的
receive|v. 收到
recent|adj. 最近的
recognize|v. 认出；承认
recommend|v. 推荐；建议
recover|v. 恢复；康复
recycle|v. 回收利用
reduce|v. 减少
refer|v. 提到；参考（to）
reflect|v. 反映；反射；反思
reform|v./n. 改革
refuse|v. 拒绝
regard|v. 认为；看待（as）
region|n. 地区
regret|v./n. 后悔；遗憾
regular|adj. 定期的；规则的
reject|v. 拒绝；拒收
relate|v. 有关；讲述
relationship|n. 关系
relax|v. 放松
release|v. 释放；发布
relevant|adj. 相关的
reliable|adj. 可靠的
relieve|v. 缓解；减轻
religion|n. 宗教
rely|v. 依靠；信赖（on）
remain|v. 保持；剩下
remark|n./v. 评论；谈论
remarkable|adj. 非凡的；显著的
remind|v. 提醒；使想起
remove|v. 移除；去掉
rent|v. 租 n. 租金
repair|v./n. 修理
replace|v. 代替；更换
represent|v. 代表；表现
request|v./n. 请求
require|v. 需要；要求
rescue|v./n. 营救
research|n./v. 研究
reserve|v. 预订；保留
resident|n. 居民
resist|v. 抵抗；忍住
resource|n. 资源
respect|v./n. 尊敬；方面
respond|v. 回应；回答
responsibility|n. 责任
restore|v. 恢复；修复
restrict|v. 限制
result|n. 结果 v. 导致（in）
retire|v. 退休
reveal|v. 揭示；透露
review|v./n. 复习；评论
revise|v. 修改；复习
reward|n. 奖赏 v. 奖励
rhythm|n. 节奏
risk|n. 风险 v. 冒险
role|n. 角色；作用
romantic|adj. 浪漫的
routine|n. 常规 adj. 日常的
rural|adj. 农村的
sacrifice|v./n. 牺牲
satisfy|v. 使满意；满足
scenery|n. 风景
schedule|n. 日程表 v. 安排
scheme|n. 计划；方案
scientific|adj. 科学的
section|n. 部分；章节
secure|adj. 安全的 v. 获得
seek|v. 寻求；寻找
select|v. 选择
sensitive|adj. 敏感的
separate|adj. 分开的 v. 分离
series|n. 系列
serious|adj. 严肃的；严重的
settle|v. 定居；解决
severe|adj. 严重的；严厉的
shelter|n. 庇护所 v. 庇护
shift|v./n. 转移；轮班
signal|n. 信号
significant|adj. 重要的；显著的
similar|adj. 相似的
simplify|v. 简化
sincere|adj. 真诚的
situation|n. 情况；处境
skill|n. 技能
slight|adj. 轻微的
smooth|adj. 光滑的；顺利的
solution|n. 解决办法；溶液
solve|v. 解决
source|n. 来源
spare|adj. 空闲的；备用的 v. 抽出（时间）
species|n. 物种
specific|adj. 具体的；特定的
spirit|n. 精神；心灵
splendid|adj. 壮丽的；极好的
sponsor|n. 赞助商 v. 赞助
stable|adj. 稳定的
status|n. 地位；状态
steady|adj. 稳定的
stimulate|v. 刺激；激发
strategy|n. 策略；战略
strength|n. 力量；长处
stress|n. 压力；重音 v. 强调
structure|n. 结构
struggle|v./n. 挣扎；奋斗
submit|v. 提交；服从
substance|n. 物质；实质
succeed|v. 成功（in）
suffer|v. 遭受；受苦（from）
sufficient|adj. 足够的
suggest|v. 建议；表明
suitable|adj. 合适的
summary|n. 摘要；总结
supply|v./n. 供应
support|v./n. 支持
suppose|v. 假定；认为
surface|n. 表面
surround|v. 包围；环绕
survey|n./v. 调查
survive|v. 幸存；挺过
suspect|v. 怀疑 n. 嫌疑人
sustain|v. 维持；支撑
symbol|n. 象征；符号
sympathy|n. 同情
system|n. 系统；体系
talent|n. 天赋；人才
target|n. 目标；靶子
task|n. 任务
technique|n. 技术；技巧
technology|n. 技术；科技
temporary|adj. 暂时的
tend|v. 倾向于；照料
tension|n. 紧张
terrible|adj. 可怕的；糟糕的
theory|n. 理论
threat|n. 威胁
tolerate|v. 容忍
tough|adj. 艰难的；坚强的
tradition|n. 传统
traffic|n. 交通
transform|v. 改变；转变
transport|n./v. 运输
treasure|n. 财宝 v. 珍惜
treat|v. 对待；治疗；请客
tremendous|adj. 巨大的
trend|n. 趋势
typical|adj. 典型的
ultimate|adj. 最终的
unique|adj. 独特的；唯一的
universe|n. 宇宙
urban|adj. 城市的
urge|v. 敦促；力劝
urgent|adj. 紧急的
valuable|adj. 宝贵的；贵重的
variety|n. 多样；种类
various|adj. 各种各样的
vehicle|n. 车辆；交通工具
victim|n. 受害者
view|n. 观点；景色 v. 看待
violent|adj. 暴力的；猛烈的
virtual|adj. 虚拟的；实际上的
visible|adj. 可见的
vision|n. 视力；远见
vital|adj. 至关重要的
volunteer|n. 志愿者 v. 自愿
vote|v./n. 投票
wealth|n. 财富
weapon|n. 武器
welfare|n. 福利
wisdom|n. 智慧
withdraw|v. 撤回；取（钱）
witness|v. 目睹 n. 目击者
worth|adj. 值得的 n. 价值
wound|n. 伤口 v. 使受伤
"""

EXAMPLES = {
    "abandon": "They had to abandon the car and walk the rest of the way.",
    "ability": "She has the ability to explain hard ideas simply.",
    "accept": "He accepted the invitation to speak at the meeting.",
    "achieve": "You can achieve your goal if you keep working at it.",
    "adapt": "It took her a few weeks to adapt to the new school.",
    "advantage": "Living near the library is a great advantage.",
    "affect": "Lack of sleep can affect your memory.",
    "afford": "We can't afford to waste any more time.",
    "anxious": "He was anxious about the result of the exam.",
    "apply": "She applied for a place in the summer camp.",
    "appreciate": "I really appreciate your help with my project.",
    "approach": "We need a new approach to this problem.",
    "attend": "More than 500 students attended the lecture.",
    "attitude": "A positive attitude makes a big difference.",
    "available": "Are there any tickets still available?",
    "avoid": "Try to avoid making the same mistake twice.",
    "benefit": "Regular exercise benefits both body and mind.",
    "challenge": "Learning a new language is a real challenge.",
    "communicate": "Good friends communicate openly with each other.",
    "concentrate": "Turn off your phone so you can concentrate.",
    "confident": "She felt confident before the speech contest.",
    "consider": "Have you considered studying abroad?",
    "contribute": "Everyone contributed to the success of the event.",
    "convince": "He tried to convince me that he was right.",
    "cope": "How do you cope with stress before exams?",
    "courage": "It took courage to tell the truth.",
    "deal": "We must learn how to deal with difficulties.",
    "decline": "The number of wild tigers has declined sharply.",
    "deserve": "After all that hard work, you deserve a rest.",
    "determine": "Your effort will determine your result.",
    "devote": "He devoted his life to protecting wildlife.",
    "efficient": "Planning ahead makes your study more efficient.",
    "encourage": "My teacher encouraged me to join the debate team.",
    "ensure": "Please ensure that all the windows are closed.",
    "essential": "Water is essential for all living things.",
    "explore": "The students explored the old town on foot.",
    "focus": "Focus on one task at a time.",
    "gain": "She gained a lot of experience from the job.",
    "ignore": "Don't ignore the warning signs.",
    "impress": "His speech impressed everyone in the hall.",
    "improve": "Reading every day can improve your English.",
    "inspire": "Her story inspired many young people.",
    "insist": "He insisted on paying for the meal.",
    "involve": "The project involves a lot of teamwork.",
    "maintain": "It is important to maintain a balanced diet.",
    "motivate": "What motivates you to study hard?",
    "obtain": "You need to obtain permission first.",
    "occur": "The accident occurred late at night.",
    "opportunity": "The trip was a great opportunity to practise English.",
    "overcome": "She overcame her fear of speaking in public.",
    "participate": "All students are encouraged to participate in the activity.",
    "persuade": "We persuaded him to give up smoking.",
    "prevent": "Wearing a helmet can prevent serious injuries.",
    "protect": "We must protect the environment for future generations.",
    "provide": "The school provides free lunch for students.",
    "recommend": "Can you recommend a good book for me?",
    "reduce": "We should reduce the use of plastic bags.",
    "regret": "I regret not studying harder last term.",
    "rely": "You can always rely on your family.",
    "remind": "This photo reminds me of my childhood.",
    "require": "The job requires good communication skills.",
    "respond": "She responded to my email quickly.",
    "responsibility": "Taking care of pets is a big responsibility.",
    "seek": "When they get stuck, they seek help from their teacher.",
    "solve": "Working together, we solved the problem.",
    "suffer": "Many people suffer from lack of sleep.",
    "suggest": "I suggest that we start early tomorrow.",
    "survive": "Only a few plants can survive in the desert.",
    "tradition": "Eating dumplings is a Spring Festival tradition.",
    "valuable": "Time is more valuable than money.",
    "volunteer": "He volunteers at the local hospital every weekend.",
    "worth": "The museum is well worth a visit.",
}
