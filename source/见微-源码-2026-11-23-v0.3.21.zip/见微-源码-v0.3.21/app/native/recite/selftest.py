"""背诵（单词、诗词）的离屏自测：词库与导入、四步背词、进复习、诗词判分与各种练法、手写默写（假识图）、
和读文互通、学习窗口与主窗口入口（三种布局 × 三种风格）。不联网。"""
from ..kit import test_runtime
test_runtime.configure()
import sys
import time
from pathlib import Path


class FakeReader:
    def __init__(self, text):
        self.text = text

    def available(self):
        return True

    def read(self, image, hint="", cancel=lambda: False, refresh=False):
        return dict(text=self.text, query="", uncertainty="")


def main(output=None):
    app = test_runtime.application()
    out = Path(output or sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    fails, log = [], []

    def check(name, ok, detail=""):
        log.append(("OK  " if ok else "FAIL") + " " + name + ("" if ok else f"  {detail}"))
        if not ok:
            fails.append(name)

    def spin(sec=0.05):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.005)

    from . import core
    from .. import learning

    def due_titles():
        return [it["title"] for _k, it in learning.due()]

    # ------------------------------------------------ 词库
    ws = core.builtin_words()
    names = [x["w"].lower() for x in ws]
    check("内置词库 700 词以上、没有重复", len(ws) >= 700 and len(set(names)) == len(names), (len(ws), len(names) - len(set(names))))
    check("每个词都有词性和释义", all(x["m"] and "." in x["m"].split(" ")[0] for x in ws), [x["w"] for x in ws if "." not in x["m"].split(" ")[0]][:5])
    check("一部分词带例句，例句里有这个词", sum(1 for x in ws if x["ex"]) >= 60 and all(x["w"][:4].lower() in x["ex"].lower() for x in ws if x["ex"]))
    rows = core.parse_wordlist("apple\tn. 苹果\nbanana, 香蕉\ncherry|n. 樱桃|I like cherries.\n# 注释\ndurian 榴莲\n123 不是词\n")
    check("导入词表：Tab、逗号、竖线、空格都认", [r["w"] for r in rows] == ["apple", "banana", "cherry", "durian"] and rows[2]["ex"] == "I like cherries.", rows)
    (out / "list.txt").write_text("zebra\tn. 斑马\nabandon\tv. 放弃（自定义）\n", encoding="gb18030")
    n = core.import_words(str(out / "list.txt"))
    check("导入 GB18030 文件、自定义释义优先", n == 2 and core.find("zebra")["m"] == "n. 斑马" and "自定义" in core.find("abandon")["m"])
    x = core.find("achieve")
    ch = core.choices(x)
    check("释义四选一：4 个、含正确、不重复", len(ch) == 4 and x["m"] in ch and len(set(ch)) == 4, ch)
    be = core.blank_example(x)
    check("例句挖空", "_____" in be and "achieve" not in be.lower(), be)
    check("拼写判对：忽略大小写和首尾空格", core.check_spell(x, " Achieve ") and not core.check_spell(x, "achive"))

    # ------------------------------------------------ 背一个词
    for step in core.steps_for(x)[:-1]:
        core.record_word(x, step, True)
    check("没拼对之前不算学会", not core.word_state("achieve")["learned"])
    core.record_word(x, "spell", True)
    check("拼写对了算学会，进间隔复习", core.word_state("achieve")["learned"] and "achieve" in due_titles(), due_titles())
    y = core.find("ambition")
    core.record_word(y, "choose", False)
    core.record_word(y, "spell", False)
    check("错两次的词也进复习", "ambition" in due_titles())
    b = core.batch(5, seed=1)
    check("下一组先出错过没学会的词", b[0]["w"] == "ambition" and all(not core.word_state(z["w"])["learned"] for z in b), [z["w"] for z in b])
    core.add_word("serendipity", "n. 意外发现珍宝的运气", "It was pure serendipity.")
    check("一键加入生词（词库没有的进自定义）", core.find("serendipity") and "serendipity" in due_titles())

    # ------------------------------------------------ 诗词
    ps = core.poems()
    check("内置古诗文 20 篇以上，都有作者和原文", len(ps) >= 20 and all(p["author"] and core.lines(p) for p in ps), len(ps))
    check("篇目 id 不重复", len({p["id"] for p in ps}) == len(ps))
    dg = next(p for p in ps if p["title"] == "登高")
    ls = core.lines(dg)
    check("按句分行", len(ls) == 4 and ls[0].startswith("风急天高"))
    r = core.judge("风急天高猿啸哀渚清沙白鸟飞回", ls[0])
    check("默写判分：标点不计", r["ok"] and r["wrong"] == 0)
    r = core.judge("风急天高猿笑哀，渚清沙白鸟飞回。", ls[0])
    check("默写判分：错一个字", not r["ok"] and r["wrong"] == 1 and "<s>笑</s>" in r["html"] and "<u>啸</u>" in r["html"], r)
    r = core.judge("风急天高，渚清沙白鸟飞回。", ls[0])
    check("默写判分：漏字", r["wrong"] == 3 and r["ratio"] < 1)
    shown, pos = core.blanks(ls[1], seed=1)
    check("填空：只挖字不挖标点", pos and all(ls[1][i] not in core.PUNCT for i in pos) and shown.count("＿") == len(pos))
    check("首字提示", core.first_chars("明月几时有？把酒问青天。") == "明□□□□，把□□□□")
    imp = core.import_poem("测试篇", "床前明月光，疑是地上霜。\n举头望明月，低头思故乡。", "李白", "唐")
    check("导入篇目", core.get_poem(imp["id"])["author"] == "李白" and len(core.lines(imp)) == 2)
    core.record_poem(dg, "dictate", 1.0)
    check("默写全对自动进复习", "登高" in due_titles())

    # ------------------------------------------------ 背诵页：单词
    from .page import RecitePage
    sent = []
    page = RecitePage(open_reading=lambda t: sent.append(t))
    page.resize(1180, 780)
    page.show()
    spin()
    words = [core.find("benefit"), core.find("zebra")]
    page.start_batch(words)
    check("开始一组：认词", page.cur_step() == "recognize" and page.w_word.text() == "benefit")
    page.answer(True)
    page.next_step()
    check("四选一出 4 个选项", page.cur_step() == "choose" and len(page.opt_btns) == 4)
    good = next(bt for bt in page.opt_btns if bt.text() == words[0]["m"])
    good.click()
    check("选对释义", page.results["benefit"][-1] == ("choose", True))
    page.next_step()
    check("有例句的词出例句", page.cur_step() == "example" and "_____" in page.w_info.text())
    page.w_input.setText("benefits")
    page.check_spell()
    check("例句填词（词形变化也算对）", page.results["benefit"][-1] == ("example", True))
    page.next_step()
    page.w_input.setText("benifit")
    page.check_spell()
    check("拼错给出正确拼写", page.results["benefit"][-1] == ("spell", False) and "benefit" in page.w_feedback.text())
    page.next_step()
    check("没例句的词跳过例句", core.steps_for(words[1]) == ["recognize", "choose", "spell"])
    page.answer(False)
    page.next_step()
    bad = next(bt for bt in page.opt_btns if bt.text() != words[1]["m"])
    bad.click()
    page.next_step()
    page.w_input.setText("zebra")
    page.check_spell()
    page.grab().save(str(out / "words.png"))
    page.next_step()
    check("一组背完给小结", page.batch == [] and "学会 1 个" in page.w_info.text(), page.w_info.text())
    page.w_find.setText("Wisdom")
    page.lookup()
    page.add_found()
    check("查词并加入复习", "wisdom" in due_titles())

    # ------------------------------------------------ 背诵页：诗词
    page.show_tab("poems")
    page.open_poem(dg["id"])
    check("打开一篇：原文和注释", page.poem["title"] == "登高" and "注释" in page.p_view.toHtml() and "渚" in page.p_view.toPlainText())
    page.set_mode("mask")
    from PySide6.QtCore import QUrl
    check("逐句遮挡：只露首字", "风□□□" in page.p_view.toPlainText() and "猿啸哀" not in page.p_view.toPlainText())
    page._reveal(QUrl("line:0"))
    check("点一句露出原文", "猿啸哀" in page.p_view.toPlainText() and "1/4" in page.p_ask.text())
    page.set_mode("fill")
    for ln in ls:
        page.p_input.setPlainText(ln)
        page.check_poem()
    check("填空做完、记正确率", "100%" in page.p_ask.text() and core.poem_state(dg["id"])["modes"]["fill"] == 1.0, page.p_ask.text())
    page.set_mode("chain")
    page.p_input.setPlainText("风急天高猿啸哀，渚清沙白鸟飞回。")
    page.check_poem()
    page.p_input.setPlainText("无边落叶萧萧下，不尽长江滚滚来。")
    page.check_poem()
    check("首字接龙：错字标出来", "<s>叶</s>" in page.p_result.text() and page.line_i == 2)
    page.set_mode("dictate")
    page.p_input.setPlainText("风急天高猿啸哀渚清沙白鸟飞回")
    page.hint()
    check("默写提示下一个字", "无" in page.p_result.text())
    page.p_input.setPlainText(dg["text"].replace("潦倒", "撩倒"))
    page.check_poem()
    check("默写打字：错 1 字", page.last_result["wrong"] == 1)
    page._input_mode("ink")
    from PySide6.QtCore import QPointF
    pad = page.p_ink.pad
    pad.resize(600, 200)
    pad._press(QPointF(20, 20), 0.5, True)
    for i in range(20):
        pad._move(QPointF(20 + i * 8, 20 + i), 0.7)
    pad._release()
    page.reader = FakeReader(dg["text"])
    page.ocr = None
    page.sync_ink = True
    from ..lecture import lookup as _lk
    page.ocr = _lk.Ocr()          # 自测里本机 OCR 不启动，只用假识图
    page.check_poem()
    spin()
    check("手写默写：识别后判分（全对）", page.last_result["ok"] and "手写识别" in page.p_result.text(), page.p_result.text()[:200])
    page.grab().save(str(out / "poems.png"))
    page.to_reading()
    check("诗词送读文精析", sent and "风急天高" in sent[-1])
    from ..design import tokens
    tokens.set_theme("night")
    page.apply_theme()
    page.grab().save(str(out / "poems-night.png"))
    tokens.set_theme("day")
    page.apply_theme()
    page.close()

    # ------------------------------------------------ 读文 → 背诵
    from ..reading.page import ReadingPage
    rd = ReadingPage()
    opened = []
    rd.open_recite = lambda pid: opened.append(pid)
    rd.resize(1100, 700)
    rd.show()
    rd.set_text("The volunteers gathered on the bank of the river.", "en")
    spin(0.3)
    c = rd.edit.textCursor()
    c.setPosition(rd.edit.toPlainText().index("volunteers") + 2)
    rd.edit.setTextCursor(c)
    rd.sync_cursor()
    check("读文英语：「加入生词本」可用", rd.b_word.isVisible() and rd.b_word.isEnabled())
    rd.add_word()
    check("读文生词进生词本和复习", any(t.startswith("volunteer") for t in due_titles()) and "已加入" in rd.link_note.text(), due_titles())
    rd.set_text("十年生死两茫茫，不思量，自难忘。千里孤坟，无处话凄凉。", "wyw")
    spin(0.3)
    rd.sync_links()
    check("读文文言是必背篇目：出现「背这一篇」", not rd.b_poem.isHidden())
    rd.open_poem()
    check("跳到背诵的这一篇", opened and core.get_poem(opened[-1])["title"].startswith("江城子"))
    rd.close()

    # ------------------------------------------------ 学习窗口
    from ..main_win import MODE_KEYS, MODES, NativeWindow
    check("学习窗口有「背诵」（Ctrl+9）", ("recite", "背诵") in MODES and MODE_KEYS["recite"] == 9)
    nw = NativeWindow("day")
    nw.resize(1100, 640)
    nw.show()
    spin()
    rw = nw.goto("recite")
    check("学习窗口打开背诵", type(rw).__name__ == "RecitePage")
    rw.show_tab("poems")
    rw.to_reading()
    spin()
    check("学习窗口里诗词送读文", nw.mode == "reading" and "风急天高" in nw.pages["reading"].edit.toPlainText()
          or core.lines(rw.poem)[0][:4] in nw.pages["reading"].edit.toPlainText())
    nw.pages["reading"].open_poem()
    check("学习窗口里读文跳回背诵", nw.mode == "recite")
    check("窄栏在最小高度放得下", nw.rail.minimumSizeHint().height() <= 620, nw.rail.minimumSizeHint().height())
    nw.shutdown()
    nw.close()

    # ------------------------------------------------ 主窗口
    try:
        import os
        import store
        from shell import NAV, Shell
        real = Path.home() / "AppData" / "Local" / "Jianwei"
        if not os.environ.get("JIANWEI_HOME") or os.path.realpath(store.HOME) == os.path.realpath(real):
            raise RuntimeError("JIANWEI_HOME 没有指向隔离目录，不建主窗口")
        check("主窗口导航有「背诵」", ("recite", "背诵") in NAV)
        cfg = store.load_config()
        cfg.update(autoFetch=False, autoEvening=False, prewarmWeb=False)
        store.save_config(cfg)
        sh = Shell(tray_enabled=False, jobs_enabled=False)
        sh.resize(1280, 820)
        sh.show()
        spin()
        for skin in ("ink", "celadon", "doodle"):
            sh._apply_look("day", skin)
            for lay in ("pages", "desktop", "workspace"):
                sh.set_page_layout(lay)
                spin()
                if lay == "desktop":
                    check(f"{skin}·模块桌面有背诵模块", "recite" in sh.home.modules)
                elif lay == "workspace":
                    sh.home.add("recite")
                    spin()
                    check(f"{skin}·工作台能加背诵模块", "recite" in sh.home.panels)
                sh.goto("recite", animate=False)
                spin()
                cur = sh.stack.currentWidget()
                check(f"{skin}·{lay} 打开背诵页", getattr(cur, "recite", None) is not None and cur.recite.isVisible())
                if skin == "ink" and lay == "pages":
                    sh.grab().save(str(out / "shell-recite.png"))
        for mode in ("side", "top", "compact"):
            sh.set_page_layout("pages")
            sh.set_layout(mode)
            spin()
            sh.goto("recite", animate=False)
            spin()
            check(f"导航位置 {mode} 打开背诵页", getattr(sh.stack.currentWidget(), "recite", None) is not None)
            sh.grab().save(str(out / f"shell-nav-{mode}.png"))
            if mode == "compact":
                check("窄栏导航在最小高度放得下", sh._root.minimumSizeHint().height() <= max(620, sh.minimumHeight()) + 40,
                      (sh._root.minimumSizeHint().height(), sh.minimumHeight()))
        sh.set_page_layout("pages")
        sh.set_layout("side")
        sh.goto("reading", animate=False)
        spin()
        rp = sh.stack.currentWidget().reading
        rp.set_text("十年生死两茫茫，不思量，自难忘。", "wyw")
        rp.open_poem()
        spin()
        check("主窗口读文跳到背诵的这一篇", sh.tab == "recite" and sh.stack.currentWidget().recite.poem["title"].startswith("江城子"))
        sh.stack.currentWidget().recite.to_reading()
        spin()
        check("主窗口背诵送回读文", sh.tab == "reading")
        sh._apply_look("day", "ink")
        sh.close()
        sh.deleteLater()
    except Exception:  # noqa: BLE001
        import traceback
        check("主窗口入口", False, traceback.format_exc()[-800:])

    (out / "recite-log.txt").write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))
    print("RECITE_FAIL" if fails else "RECITE_OK", len(log), "项")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else None))
