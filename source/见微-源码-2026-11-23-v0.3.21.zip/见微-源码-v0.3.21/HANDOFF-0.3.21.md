# 见微 0.3.21 · 交接（2026-11-22）

`store.VERSION` = **0.3.21**，没打包。用户说明看 `RELEASE-0.3.21.md`。这一版是任务 B2（前端统一），见 `HANDOFF-下一步-计划细化·AI计划·全面测试.md` 第 3b 节。

## 1. 做法：从公共的小函数入手
考试、专注、背诵、问 AI、AI 排计划这几个新模块，都用 `exam/page.py` 里的 `_card()`、`_btn()`、`_label()`。所以只改这两个函数：
- `UBtn(ui_kit.Btn)`：`_btn()` 现在返回它。
  - 在主窗口或单独弹出的窗口里，画成 `ui_kit.Btn`。名字对应：`pri` → primary，`danger` → danger，`ghost` → soft，空 → 普通键。
  - 在学习窗口（`NativeWindow`）里，`paintEvent`、`sizeHint` 退回 `QPushButton` 自己的，objectName 保持 pri / danger / ghost，所以学习窗口的样式表照样认得。
  - 判断写在 `_main_look(w)`，看的是 `type(w.window()).__name__ != "NativeWindow"`。第一次显示时会 `updateGeometry()`，重新算尺寸。
- `UCard(QFrame)`：`_card()` 现在返回它。主窗口里用 `ui_kit.paint_card` 画；学习窗口里还是样式表里的 `#examCard`。内边距的下边加了 3 像素，留给手绘风格的投影。

## 2. 其他改动
- `focus/page.py`：
  - 计划页的外层是 `QBoxLayout`（`self.pl_box`）。在 `resizeEvent` 里，宽度小于 960 时改成上下排，右栏放到下面。
  - 顶栏的 ‹ › 是 34 宽的轻键；`pl_prog`（完成度）挪到计划表下面那一行。
- `focus/floater.py`：左边加一道阶段色；休息时整张小窗加一层淡绿。
- `focus/planview.py`：块标题右边只在有重复图标时留 26 像素。
- `focus/aiplan_page.py`：`apply_theme` 的底色和文字用 `ui_kit.C`（PAPER / INK / SOFT）。
- `recite/page.py`：「这一组」列表在空的时候显示一句提示。
- `focus/design_shots.py`：设计截图脚本，不是自测组。用法是 `python -m native.focus.design_shots <目录>`，要先隔离 `JIANWEI_HOME`。

## 3. 还没做、留意的地方
- 「AI 排计划」窗口在手绘、夜间下字很淡：**查明是真问题，已修**。面板是普通 QWidget，放进对话框后样式表里的底色画不出来，底色成了浅灰。现在面板加了 `WA_StyledBackground`，`aiplan` 自测里有一项专门检查。详见 `测试/0.3.21/测试总结.md`。
- 考情的图表（`Trend`、`Bars`）还是原来的自绘，坐标和图例没有大改。
- 新界面里的下拉框、数字框、日期框，还是学习窗口的样式表（`design.widgets.qss`），手绘风格下没有墨线。
