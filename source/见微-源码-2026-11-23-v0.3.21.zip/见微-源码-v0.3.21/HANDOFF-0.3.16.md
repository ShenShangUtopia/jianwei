# 见微 0.3.16 · 交接（2026-11-22）

`store.VERSION` = **0.3.16**，**没打包**。`tools/release.py` 的 `OUT`、`TAG` 还是 0.3.14，打包前要改。用户说明看 `RELEASE-0.3.16.md`。上一版是 `HANDOFF-0.3.15.md`（限时考试、考情），和这版同一天做。

需求来自另一个会话转达的用户原话：「也加入番茄钟与监督机制，可自由安排」。范围按那条消息定的：番茄钟、自由安排、监督、统计、各个入口。

## 1. 文件（`app/native/focus/`）
| 文件 | 管什么 |
| --- | --- |
| `core.py` | 设置 `settings` / `save_settings`；番茄状态机 `Pomodoro`；记录 `sessions` / `add_session`；统计 `summary(days)` |
| `plan.py` | 计划块：`add` / `update` / `move` / `resize` / `remove` / `next_free` / `add_focus` / `due_reminders`；拉进计划的候选 `candidates` |
| `watch.py` | `Probe` 读前台程序名和空闲秒数（Win32 ctypes）；`Supervisor.check` 按规则记中断 |
| `engine.py` | 全局唯一的 `engine()`：番茄、监督、计划提醒都在这里跑；信号有 `changed`、`notice(kind, text)`、`recorded` |
| `floater.py` | 桌面置顶小窗 `floater()`，单例 |
| `page.py` | `FocusPage`：番茄钟、计划（`PlanGrid` 拖动表）、统计、设置 |
| `selftest.py` | 87 项，全部用假时钟和假探针；接进 `main.py --self-test`（组名 `focus`）和 release 的 smoke 预期 |

### 数据（在 `JIANWEI_HOME` 下）
- `focus.json`：`{v:1, settings, sessions}`。
  - 每条 session 有：`id`、`day`、`start`、`end`、`planned`、`focus`（秒）、`paused`、`subject`、`task`、`block`、`reason`、`interruptions`。
  - `status` 是 done、skipped 或 abandoned。
  - `interruptions` 里每项是 `{t, kind(away|idle), detail, seconds}`。
- `focus-plan.json`：`{v:1, blocks}`。每块有 `id`、`day`、`start`（当天第几分钟）、`minutes`、`subject`、`task`、`source`（self、review、preview 或 weak）、`ref`、`done`、`focused`、`reminded`。只保留 120 天内的块。
- `focus-float.json`：小窗的位置。

## 2. 要点
- **计时**：`Pomodoro` 只用 `clock()` 取时间。`tick(now)` 一次能跨过好几个阶段，比如睡眠唤醒后，专注结束又接着休息结束。阶段的结束时间按「开始时间 + 剩余时长」算，不按 tick 的那一刻算。
- **引擎定时器**：番茄在走时 1 秒一跳，否则 30 秒一跳，用来看计划提醒。Shell 初始化时调 `_focus_boot()` 把引擎起起来。小窗只在第一次需要时才建：番茄开始，或者有计划提醒时。
- **监督**：
  - 只在专注且正在走的时候看。前台是白名单外的程序时，从第一次看到起算宽限时间，超过就记一次 away，开始时间往前记到第一次看到那一刻；回到白名单程序时补上离开时长。
  - `own`：前台是见微自己的进程，或者没有前台窗口，都算允许。
  - 空闲超过设定就记一次 idle，有输入时结束。
  - 每次中断只发一句提醒（`notice("nudge")`），不弹窗、不锁屏。
- **严格模式**：`Pomodoro.abandon` 没写理由会抛 `ValueError`，页面接住后在状态栏提示。
- **计划块和番茄**：从块开始的番茄结束后，`plan.add_focus` 累计专注秒数，够块时长的八成就把块标成完成。
- **候选**：
  - 复习：`learning.due()`，按科目合并，每项算 5 分钟，总共 15 到 60 分钟；
  - 预习：`preview.current()` 里没做完的那张单子；
  - 薄弱点：`exam.records.analyze()["weak"]` 的前 5 个。
- **入口**：
  - `shell.NAV` 在「考试」后面加了 `focus`；
  - `pages.build_focus`；
  - 今日页卡片 `pages._focus_card`，页面重建时会断开引擎的信号；
  - `modules.SPEC["focus"]`：模块桌面第 4 行改成考试、专注、读文各占一格；
  - 托盘加了「专注」和「开始 / 暂停番茄」，`Shell.focus_toggle`；
  - 考情页 `ExamPage.refresh_stats` 里多了一块专注汇总（`k_focus`、`k_focus_days`）。
- **图标**：新增 `focus`。
- **学习窗口**：没加专注模式，需求里没要求。

## 3. 测试
- 单项：`from native.focus import selftest; selftest.main(目录)`，87 项全过。主窗口那部分只在 `JIANWEI_HOME` 已隔离时跑。
- 自测结束时把引擎和小窗的单例清掉，后面的测试组会拿到用真时钟的新引擎。
- **没在真机上验证的**：
  - 真实前台窗口的检测（`Probe` 的 ctypes 调用），自测里用的是假探针；
  - 真数位板、真托盘气泡；
  - 小窗在多屏和高 DPI 下的位置。
- 全量 `main.py --self-test --no-single`：结果见 §5。

## 4. 没做 / 下一步
- 计划没有「每周重复」，也不能复制上一周。
- 只能从 6:00 排到 23:00。
- 监督读不到浏览器里开的是哪个网页，只认程序名。浏览器要么整个加进白名单，要么整个算离开。
- 番茄结束没有声音提醒，只有小窗和托盘。
- 学习窗口里没有专注入口；有需要可以照 `exam` 的写法加一个模式。

## 5. 全量自测
`main.py --self-test --no-single`（离屏，数据目录隔离，2026-11-22）：**全部通过**，43 个结果文件，失败列表为空，`exam` 和 `focus` 两组都过了。冻结版（smoke）没跑，因为这次没打包。
