# 见微 0.3.20 · 交接（2026-11-22）

`store.VERSION` = **0.3.20**，没打包。用户说明看 `RELEASE-0.3.20.md`。前一版是 0.3.19（`HANDOFF-0.3.19.md`）。

## 1. 文件（`app/native/focus/`）
| 文件 | 管什么 |
| --- | --- |
| `aiplan.py` | 新文件。<br>- 摘要：`digest(days, today, now_min, analysis)`、`budgets`、`history_rate`、`days_to_gaokao`<br>- 校验：`make_check(dg)`，给 `llm.ask_json` 用<br>- 规则版：`rule_plan(dg, request)`<br>- 生成：`generate(start, today, now_min, request, previous, engine)`，结果存成草稿，不写进计划<br>- 改草稿：`edit_item`、`remove_item`、`add_item`、`conflicts`<br>- 接受：`accept(d, only_on)`，写进计划时 source="ai"，题目写成子任务，周目标并进周计划<br>- 每周自动：`auto_due(now)`、`mark_auto`、`set_auto`<br>- 存储：`focus-aiplan.json` = `{draft, history[], auto{on, last}}` |
| `aiplan_page.py` | 新文件。`AIPlanPanel(request, engine, today)` 是预览页；`open_dialog(parent, request, engine, on_accept)` 弹出非模态窗口。生成在 `Worker` 线程里跑；自测时传 `sync=True` |
| `aiplan_selftest.py` | 新文件，47 项，全部用假引擎，组名 `aiplan`，已经接进 `main.py` 和 `tools/release.py` |
| `engine.py` | `_auto_plan(now, sync, engine)`：满足 `auto_due` 时在后台生成下周草稿，完成后由 `_auto_done` 推一条 `kind="aiplan"` 的提醒 |
| `notify.py` | `aiplan` 类型的提醒，第一个键是「去看看」，调 `open_page("aiplan")` |
| `page.py` | 计划栏加了「AI 排计划」按钮；`open_aiplan(request)`；`show_tab("aiplan")` 会切到计划栏并弹出 AI 排计划窗口 |

其他模块：
- `exam/page.py`：考情的薄弱点栏加了 `k_aiplan` 按钮和 `open_aiplan()`。
- `chat/core.py`：
  - `ACTIONS["aiplan"]`，`SYSTEM` 里加了这个动作的说明；
  - `wants_plan(text)` 用来认出「排…计划」这类话，但带「番茄」的不算，超过 80 字的也不算。
- `chat/page.py`：
  - `send()` 遇到 `wants_plan` 时不发给聊天 AI，而是记一条离线回答，带上 `[[动作:aiplan|…]]`，并直接打开 AI 排计划窗口；
  - `run_action` 支持 `aiplan`。

## 2. 要点
- **AI 调用**：`llm.Engine(SYSTEM)` + `llm.ask_json(engine, prompt, make_check(dg), repairs=1)`。
  - `check` 的结果：有一半以上的项合格时，返回 fallback（去掉不合格的项）。
  - 全都不行时抛 `AskError`，由 `generate` 接住，退回规则版，原因写进 `note`。
- **每天的上限**：可用时段减去已有安排，再乘一个系数。
  - 系数 = 近两周计划完成率 + 0.1，夹在 0.5 到 0.9 之间；
  - 没有记录时按 0.75；
  - 空闲不足 30 分钟的那天，上限记为 0。
- **隐私**：`digest` 里的知识点只给名字和题库 id，题目原文和作答都不放；错因只给次数。自测会检查：发出去的提示词里不含题干。
- **自动草稿**：
  - 时间在周日 17 点以后；
  - 已经给下周出过草稿（`auto.last`）的不再出；
  - 草稿的 start 已经是下周（不管有没有接受）的也不再出。
- **预览页的行**：`_rows[i]` 对应列表第 i 行，是 `(day, index)`，表头和空行是 None；`_days[i]` 是这一行属于哪一天。
