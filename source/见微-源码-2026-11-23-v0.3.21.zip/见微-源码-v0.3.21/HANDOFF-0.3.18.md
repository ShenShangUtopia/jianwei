# 见微 0.3.18 · 交接（2026-11-22）

`store.VERSION` = **0.3.18**，**没打包**，等用户说了再打。打包前要把 `tools/release.py` 的 `OUT`、`TAG` 改掉，现在还是 0.3.14。用户说明看 `RELEASE-0.3.18.md`。

同一天连着出了几版，都没打包：
- 0.3.15：限时考试、考情分析（`native/exam/`）
- 0.3.16：番茄钟、计划、专注监督（`native/focus/`）
- 0.3.17：单词、诗词背诵（`native/recite/`）
- 0.3.18：问 AI（`native/chat/`）

每版的细节看各自的 `HANDOFF-0.3.1x.md`。

## 1. 文件（`app/native/chat/`）
| 文件 | 管什么 |
| --- | --- |
| `core.py` | 对话存储（`convs`、`get`、`new_conv`、`save_conv`、`delete_conv`）；附件（`file_attachment`、`image_attachment`、`question_attachment`、`text_attachment`、`read_pptx`）；`compose`、`api_messages`；动作（`ACTIONS`、`parse_actions`、`strip_actions`）；渲染 `to_html`；`ready`；流式请求 `stream` |
| `page.py` | `ChatPage(compact, host)` |
| `bridge.py` | `ask(widget, attachments, text)`：各模块的「问 AI」交给控件所在窗口的 `ask_ai`；`HANDLER` 是兜底，Shell 启动时设成 `Shell.ask_ai` |
| `selftest.py` | 67 项，全部用假引擎、假识图；接进 `main.py --self-test`（组名 `chat`）和 release 的 smoke 预期 |

数据：`chat-history.json` = `{v:1, convs:[{id, title, created, updated, messages:[{role, content, attachments, t, offline?}]}]}`，最多存 200 个对话。

## 2. 要点
- **请求**：
  - `core.stream` 自己发普通流式请求，不开 JSON 模式。`llm.chat_once` 没法用，因为它固定开了 `response_format=json_object`。
  - 密钥、模型、地址都取 `llm.settings()`；模型用 `pick_model(None)`；带 `llm.thinking_field`（DeepSeek 关掉思考）。
  - 出错时只回状态码和服务端的前 200 字，不会带出密钥。
- **动作协议**：系统提示词（`SYSTEM`）里约定，AI 在回答末尾写 `[[动作:类型|参数…]]`。界面用 `parse_actions` 把它变成按钮，`strip_actions` 在显示时去掉这些标记。
  - 复习、番茄计划、单词卡这三个只动数据，`ChatPage.run_action` 直接做。
  - 打开题目、析题、导入试卷、背诗、读文要切页面，走外壳给的 `host`：主窗口是 `Shell.chat_host()`，学习窗口是 `NativeWindow.chat_host()`。
  - 析题、导入试卷、读文这三个动作没带参数时，用最近一条带附件的用户消息里的附件文字。
- **附件抽字**：大部分复用考试的 `paper.load_file`，PPT 自己解析 `ppt/slides/slideN.xml` 里的 `a:t`。从素材篮拖进来的东西同时带图和字，有字就直接用字，省一次识图。
- **历史**：
  - 回答回来时，按发问时记下的 `sending_id` 记到那个对话里，不管用户中途切到了哪个对话。
  - 没发出去的提示和出错信息带 `offline=True`，下一轮不会发给 AI。
- **「问 AI」入口**：
  - 习题台：`Desk.ask_ai`，右栏多了一个「问 AI」键；
  - 考试报告：`ExamPage.ask_ai`；
  - 读文：`ReadingPage.ask_ai`，`b_ask`；
  - 背诵：`RecitePage.ask_ai`。
- **外壳**：
  - `shell.NAV` 加了 `chat`；建页函数 `pages.build_chat`；
  - `modules.SPEC["chat"]` 放在桌面第 5 行，占两格；
  - 托盘加了「问 AI」；
  - `main_win.MODES` 加了 `chat`，快捷键 Ctrl+0；`RAIL_KEY_H` 改成 44。
  - 主窗口顶栏：1280 宽时导航放得下（自测里查了没压到设置），更窄时靠收起倒计时和时钟。侧栏、窄栏的导航键 0.3.17 起放在滚动区里。

## 3. 测试
- 单项：`from native.chat import selftest; selftest.main(目录)`，67 项全过。
- **真 AI 没测**：没有密钥，也不能复制用户的密钥。用户填了密钥以后要实测这几项：
  - 各家流式回答能不能正常收；
  - 模型会不会按约定写动作标记，写错的标记会被丢掉；
  - 大附件的长度：每个附件最多带 12000 字，整个对话最多带约 24000 字。
- 全量自测结果见 §5。

## 4. 没做 / 下一步
- 公式只做了 bank.fx 那一档的轻量排版（上下标、分数、根号），没有完整的 TeX 渲染。
- 附件只抽文字，没有把原图直接发给模型。识图模型是另一个，走的是 `lecture/vision`。
- 不能直接从实验台画布拖出来（要经过素材篮，或用「附上 → 快照」）。
- 对话里还不能按题号搜题库；「打开题目」只在 AI 知道题库 id 时有用。题目是从习题台「问 AI」带进来的话，附件里有 id。

## 5. 全量自测
`main.py --self-test --no-single`（离屏，数据目录隔离，2026-11-22）：**全部通过**，45 个结果文件，失败列表为空。新加的四组是 exam 97 项、focus 87 项、recite 72 项、chat 67 项，都过了。冻结版（smoke）没跑，因为没打包。
