# 见微 0.3.15 · 交接（2026-11-22）

`store.VERSION` = **0.3.15**，**没打包**（`tools/release.py` 的 `OUT`、`TAG` 还是 0.3.14，打包前改）。用户说明看 `RELEASE-0.3.15.md`，上一版是 `HANDOFF-0.3.14.md`。

这一版新做两个功能：限时考试、考情分析。代码都在新包 `app/native/exam/`。

## 1. 文件
| 文件 | 管什么 |
| --- | --- |
| `exam/paper.py` | 切题 `split_text`、读文件 `load_file`（txt / docx / pdf / 图片）、题库组卷 `from_bank`、`new_exam` |
| `exam/grade.py` | 离线判分 `offline` / `offline_item`、自评 `set_self_score`、AI 评分 `ai`、手写识别 `recognize_ink` |
| `exam/records.py` | 考试记录、进行中的考试、手写图、记学习事件、考情统计 `analyze`、薄弱点建议 `suggest` / `add_to_review` |
| `exam/ink.py` | 手写板 `InkPad`，带工具条的 `InkBox` |
| `exam/page.py` | `ExamPage`：首页 → 核对 → 作答 → 报告；另一栏是考情。主窗口和学习窗口用的是同一个控件 |
| `exam/selftest.py` | 离屏自测 97 项，已接进 `main.py --self-test`（组名 `exam`）和 `release.py` 的 smoke 预期 |

### 数据（都在 `JIANWEI_HOME` 下）
- `exams.json`：考试记录，最多 300 条。
- `exam-current.json`：进行中的考试，存答案和笔画。
- `exams/<id>/q<n>.png`：交卷时把手写导出成图片。交卷后，笔画坐标从记录里删掉。

### 考试的结构（dict）
- 字段：`id`、`title`、`subject`、`source`（import / bank）、`minutes`、`full`、`started`、`submitted`、`used`（秒）、`grade_note`。
- `questions`：每题 `no`、`stem`、`type`（单选 / 多选 / 填空 / 解答）、`score`、`answer`、`points`、`qid`（题库题才有）、`subject`。
- `answers`：`{"题号": {text, mode, ink, strokes, ink_file}}`。
- `report`：`engine`（ai / offline）、`total`、`full`、`rate`、`pending`、`summary`。`items` 每题有：
  - `no`、`score`、`full`；
  - `status`：right / partial / wrong / blank / self；
  - `cause`：取 `grade.CAUSES` 之一；
  - `comment`、`points`、`ink`；
  - `how`：程序 / AI / 自评。

## 2. 要点
- **切题**：
  - 按行首题号「1.」「1、」「第1题」「1)」切。题号必须比上一题大，最多跳 3 号，所以 `2.5x` 这种不会被当成题号。
  - 「(1)」是小问，留在本题。选项留在题干里。
  - 大题标题定题型和「每小题 n 分」，题干前 80 字里的「（12 分）」是这题的分值。
  - 「参考答案」这一行之后的内容按题号拆开，填回各题。
  - 只把全角数字、字母换成半角，中文标点不动（NFKC 会把「，」改成「,」）。
- **Word**：直接读 `word/document.xml`，不经过 Word 或 WPS。自动编号（`numPr`）按 numId / ilvl 计数补上题号：第一级写「1.」，第二级写「(1)」。没有解析 numbering.xml 的格式，按编号顺序数。
- **PDF**：每页用 `pageview.page_text` 取字。一页少于 20 字就当扫描页，渲染成图，交给 `read_image_text`：先 `lecture/vision.Reader` 识图，再用 `lookup.Ocr`。
- **评分**：
  - `page.grade_exam` 在工作线程里跑：有密钥时先识别手写，再调 `grade.ai`；AI 失败就改用 `grade.offline`，并在 note 里写明原因。
  - `grade.ai` 走 `llm.Engine` + `llm.ask_json`，最多修正 1 次。选择题的分以程序判的为准，AI 只补错因和评语。没作答的题不交给 AI 改分。
- **自测钩子**：
  - `ExamPage.grader = fn(exam, images) -> (report, note)`。给 fn 设 `fn.sync = True` 就同步跑，不起线程。
  - 离屏时 `ai_ready()` 恒为 False，自测不会联网。
- **学习记录**：交卷后每题记一条 `learning.record`。`event_id` 是 `exam-<id>-<题号>`，同一场考试重复调用不会重复记。题库题记题库 id，导入的题记 `exam:<id>:<题号>`。考情统计习题台时会跳过这些，避免和考试重复算。
- **加入复习**：用新函数 `learning.add_question(qid, q)` 加单道题，已有的题重新启用并改成今天到期；不能用 `sync_questions`，它会停用不在列表里的题。知识卡 `card.src = "exam"`，同一个知识点已经有卡就不再建。
- **计时**：按墙上时钟算，剩余时间 = started + minutes×60 − 现在。看不见时停 QTimer，显示时重算；时间到就自动交卷。续考时如果已经超时，直接交卷。
- **入口**：
  - `shell.NAV` 在习题台后面加了 `exam`，建页函数是 `pages.build_exam`。
  - `modules.SPEC` 加了 `exam`。模块桌面里 `exam` 和 `reading` 共用第 4 行（1 + 2 格），`ORDER` 也加了。
  - `main_win.MODES` 加了 `exam`，快捷键 Ctrl+8。`goto("exam", "stats")` 直接打开考情。`shutdown` 里会存盘。
  - 学习窗口窄栏的键改成 50 高（`RAIL_KEY_H`），保证最小高度 620 时放得下。
- **图标**：`design/icons.py` 新增 `exam`、`stats`。

## 3. 测试
- 单项：`python -m native.exam.selftest <目录>`，或者在代码里调 `selftest.main(目录)`，**97 项全过**。主窗口那部分只在 `JIANWEI_HOME` 已隔离时跑。
- 「导入真实试卷」的验收：本机没有试卷文件，`E:\U盘备份` 这台机器上也没有。所以拿题库里 2024 新课标Ⅰ卷数学的 11 道原题，生成一份用 Word 自动编号的 docx 来导入。11 题全部切对，题型和答案都对上，再走完核对、作答（含手写题）、交卷、报告、考情、加入复习。**还没用用户手里的真试卷（尤其是扫描版 PDF）试过。**
- 真 AI 评分没测：没有密钥，测的是假引擎。接真 AI 时注意两点：
  - 长卷的 prompt 大小：题干截到 1500 字，作答截到 2000 字；
  - 模型在 JSON 里漏题号时，会修正一次；还漏就用 fallback（至少一半的题有分），缺的题按离线结果填。
- 全量 `main.py --self-test --no-single`：结果见 §5。

## 4. 没做 / 下一步
- 扫描版试卷的版面：OCR 出来的文字顺序可能乱（双栏），需要在核对页手动并题、改题。可以考虑整页交给 AI 识图后按题号结构化。
- 题目里的图（几何图、电路图）：导入时没有截图。PDF 有文字层时，可以按题号所在位置截出这一题的区域图，放到作答页上。
- 手写板没有分页，靠滚轮往下写；要更大的地方可以做成全屏。
- 两个窗口（主窗口和学习窗口）同时开同一场没考完的考试时，各自存盘，后存的覆盖先存的。目前只在首页提示续考，没有加锁。
- 考情还可以加：按时间筛选（近 30 天）、和析题的错题本打通。

## 5. 全量自测
`main.py --self-test --no-single`（离屏，数据目录隔离，2026-11-22）：**全部通过**，42 个结果文件，失败列表为空。新的 `exam` 组 97 项。冻结版（smoke）没跑，因为这次没打包。
