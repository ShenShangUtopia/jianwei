# 见微 0.3.17 · 交接（2026-11-22）

`store.VERSION` = **0.3.17**，**没打包**，等用户说了再打。用户说明看 `RELEASE-0.3.17.md`，上一版是 `HANDOFF-0.3.16.md`。

需求来自另一个会话转达的用户原话：「单词，诗词背诵也加入，再加入一个API接入的AI聊天，可以问问题，一键拖入各种东西导入或分析，可以关联其他模块。」这次拆成两版：背诵是 0.3.17，AI 聊天是 0.3.18。

## 1. 文件（`app/native/recite/`）
| 文件 | 管什么 |
| --- | --- |
| `words_data.py` | 内置词库 `RAW`（单词\|词性释义，839 个）、例句 `EXAMPLES`（约 70 个） |
| `poems_data.py` | 内置篇目 `POEMS`（23 篇：title、author、dynasty、source、text 按句分行、notes） |
| `core.py` | 数据和规则，见下 |
| `page.py` | `RecitePage(compact, open_reading)`，分单词、诗词两栏 |
| `selftest.py` | 72 项；接进 `main.py --self-test`（组名 `recite`）和 release 的 smoke 预期 |

`core.py` 里的函数：
- 词库与导入：`words`、`find`、`parse_wordlist`、`import_words`；
- 背词：`batch`、`steps_for`、`choices`、`blank_example`、`check_spell`、`record_word`、`add_word`；
- 诗词：`poems`、`import_poem`、`lines`、`clauses`、`first_chars`、`blanks`、`judge`、`record_poem`、`add_poem_review`；
- 手写识别：`recognize_ink`，借用考试的 `grade.recognize_ink`。

### 数据（在 `JIANWEI_HOME` 下）
- `recite.json`：进度，`{v:1, words:{小写词:{step,right,wrong,learned,last}}, poems:{id:{tries,best,last,modes}}}`。
- `recite-words.json`：导入和生词本里的自定义词。
- `recite-poems.json`：导入的篇目。
- 间隔复习用的是学习记录 `learning.add_card` 的知识卡：单词卡是 `src="word"`，`n` 是单词，`d` 是释义，`f` 是例句；诗词卡是 `src="poem"`，`n` 是题目，`d` 是全文。复习窗口不用改就能显示。

## 2. 要点
- **内置词库不全**：只有 839 个词，不是 3500。本机找不到可信的完整词表，我也不愿凭记忆编 3500 条释义。所以留了导入口子，RELEASE 里写明了。之后如果用户给一份课标词表，用 `import_words` 导入就行，也可以直接换掉 `words_data.RAW`。
- **内置篇目也不全**：只收了能保证原文准确的 23 篇，长篇没收。
- **判分**：`judge` 用 `difflib.SequenceMatcher` 逐字比，先去掉标点（`PUNCT`）。返回值里 `wrong` 是错字和漏字的个数，`html` 里错写的字用删除线、漏写的字用下划线。
- **读文互通**：
  - `ReadingPage` 新加了一排按钮 `b_word`、`b_poem`、`link_note`，以及方法 `sync_links`、`matching_poem`、`add_word`、`open_poem`；`open_recite` 由外壳设置。
  - 主窗口在 `pages.build_reading` 里设，学习窗口在 `main_win.page("reading")` 里设。
  - 背诵送读文：主窗口走 `ctx.read_text`，学习窗口走 `NativeWindow.read_text`。
- **入口**：
  - `shell.NAV` 在「专注」后面加了 `recite`；
  - `pages.build_recite`；
  - `modules.SPEC["recite"]`，在模块桌面第 5 行；
  - `main_win.MODES` 加了 `recite`，快捷键 Ctrl+9；
  - 学习窗口的 `RAIL_KEY_H` 改成 46，窄栏间距改成 2。
- **主窗口导航（改了外壳）**：
  - 侧栏、窄栏的导航键改放在 `Shell._nav_scroll()` 返回的滚动区里，不显示滚动条，设置单独固定在最下面。
  - `nav_buttons` 的顺序仍然和 `NAV` 一致：设置最后加，`NAV` 里设置本来也在最后。
  - 顶栏导航没动。1280 宽时，倒计时和时钟已经被收起；再加入口要看宽度。

## 3. 测试
- 单项：`from native.recite import selftest; selftest.main(目录)`，72 项全过。
- **没在真机上验证的**：
  - 真数位板手写默写，以及真的 AI 识图 / 本机 OCR 识别出来的中文（自测里用的是假识图）；
  - 楷体显示（诗词正文用 KaiTi，这台机器有）。

## 4. 没做 / 下一步
- 完整 3500 词表、例句补全。没有密钥时可以让 AI 给缺例句的词生成例句，但这个没做。
- 单词发音（TTS）。
- 诗词按句做复习卡（现在是整篇一张卡）。
- 篇目还可以补长篇：先从可靠的来源核对原文，再加进 `poems_data`。
