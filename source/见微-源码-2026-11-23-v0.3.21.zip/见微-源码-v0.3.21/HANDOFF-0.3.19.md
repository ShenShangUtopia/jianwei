# 见微 0.3.19 · 交接（2026-11-22）

`store.VERSION` = **0.3.19**，没打包。用户说明看 `RELEASE-0.3.19.md`。底子是 0.3.16（`HANDOFF-0.3.16.md`）。

## 1. 文件（`app/native/focus/`）
| 文件 | 改了什么 |
| --- | --- |
| `plan.py` | 数据升到 v2（v1 读进来自动补字段）。新加的部分：<br>- 块的字段：`priority`、`pomos`、`deadline`、`subtasks`、`rep`、`carried`、`orig`、`why`<br>- 重复：`set_repeat`、`ensure_repeats`、`repeat_rule`；删掉某天的重复块时记进模板的 `skip`<br>- 顺延：`rollover(today, now_min)`，一天只跑一次，记在 `rolled`<br>- 时段：`avail`、`avail_for`、`set_avail`、`parse_ranges`、`free_slots`<br>- 排程：`suggest_day(day, now_min, fill=.85, cands)`、`accept(items)`<br>- 目标：`goals`、`set_goals`、`week`、`set_week`<br>- 完成度和复盘：`day_progress`、`week_progress`、`goal_progress`、`review(kind, day)`、`review_text`、`save_review_text`<br>- `candidates()` 多了背诵来源，每项带 `priority` 和 `why`<br>- `due_reminders` 留着没删，但已经不用 |
| `remind.py` | 新文件。`check(now, cfg)` 返回从「上次检查」到现在该响的提醒，分 live 和 missed 两种。还有：`snooze`、`merge_missed`、`in_dnd`、`morning_text`、`evening_text`。状态存在 `focus-remind.json` |
| `core.py` | `DEFAULTS` 加了：`remind_daily`（按星期 0–6）、`remind_lead`、`remind_due_on`、`remind_due`、`dnd_on`、`dnd_start`、`dnd_end`、`sound`、`tray_bubble`。`settings()` 改成深拷贝，并补齐每一天的设置；`save_settings` 会校验时间格式 |
| `engine.py` | 新信号：`reminder(dict)`、`planChanged`。`step()` 里调 `_daily()`：跨天时先顺延、再补未来 8 天的重复块；提醒每 20 秒查一次（番茄在走时 1 秒一跳，不会每秒读盘）。另有 `remind_start(item)`、`remind_snooze(item)` |
| `notify.py` | 新文件。通知卡片 `card(open_page)`，排队显示，90 秒后自动收起。三个键是 `act("main" / "snooze" / "skip")`；点正文时 `act("body")`，打开计划页 |
| `planview.py` | 新文件。`PlanGrid`（从 page.py 搬过来，`reload()` 时读一次数据，重画时不读盘）、`MonthGrid`、`PairBars` |
| `page.py` | 栏目变成五个：番茄钟 · 计划 · 复盘 · 统计 · 设置。<br>- 计划：日 / 周 / 月三种视图；右栏分「这一块 / 拉任务 / 目标」<br>- 复盘：新的一栏<br>- 设置：分「番茄与监督」「每日提醒 + 可用时段」两张卡 |
| `plan_selftest.py` | 新文件，79 项，全部用假时钟，组名 `plan`，已经接进 `main.py` 和 `tools/release.py` 的 smoke 预期 |
| `floater.py` | 不再显示 `remind` 类型的提示，改由通知卡片显示 |

外壳和其他模块：
- `shell.py`：
  - `_focus_boot` 连上 `eng.reminder → _focus_reminder`，弹卡片和托盘气泡；
  - 启动 3 秒后先跑一次 `eng.step()`，用来补报错过的提醒、做跨天顺延；
  - 新加 `_focus_open(tab)`；
  - `_focus_notice` 现在什么都不做。
- `pages._focus_card`：显示今天的完成度，以及昨天的完成率和复盘。
- `exam/page.ExamPage._plan_review_text`：考情的专注汇总里加上本周计划 vs 实际和最近一次复盘。
- `design/icons.py`：新加 `bell`、`clock`、`calendar`、`repeat` 四个图标。

## 2. 要点和坑
- **提醒的 key**：
  - 时间块：`block:{id}:{day}:{start}`。改了时间，key 就变了，会再提醒一次。
  - 早晚：`morning:` / `evening:` + 日期。
  - 到期：`due:` + 日期。
  - 响过的 key 存在 `fired` 里，3 天后清掉。
- **免打扰**：在免打扰时段里不往前挪 `last`，出了免打扰，期间的提醒就会被当成 missed 一起补报。最多往回看 24 小时（`LOOKBACK`）。
- **live 的判断**：时间块在开始后 10 分钟内算 live；早晚提醒和到期提醒在 20 分钟内算 live。超过这个时间的算 missed，由 `merge_missed` 合成一条补报。
- **顺延**：只看最近 7 天；不顺延考试块和重复生成的块；按优先级从高到低放进今天的空档（从可用时段的开头或「现在 + 7 分钟」开始找）。
- **编辑栏**：加子任务、勾子任务时，会调 `save_block()`，把编辑栏里的其他改动一起存下。以前是重读块，没保存的改动会被冲掉。
- **自测的日期**：`plan_selftest` 用「下周一」起的两周当日期，不碰真实的今天。
