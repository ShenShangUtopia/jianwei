"""框选之后上网查：取文字（文字层 → 本机识别）→ 多个来源同时搜 → 先到先出 → AI 摘要接着流式补上。

时间预算（目标 2 秒内出资料）：
- 连接提前握手：开始框选时就连上搜索站，点「查询」时已省掉 TLS 这 0.5~1 秒。
- 所有来源并发，哪个先回来先显示，不互相等；到 DEADLINE 还没回来的只是晚点补上。
- 识别文字用常驻进程，免去每次启动 PowerShell 的 0.5 秒。
只发送文字，不上传截图。
"""
from __future__ import annotations

import base64
import json
import re
import subprocess
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import quote, unquote, urlparse

import requests
from bs4 import BeautifulSoup
from PySide6.QtCore import QObject, Signal

DEADLINE = 1.8
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6"}
_session = requests.Session()
_session.headers.update(UA)
_session.mount("https://", requests.adapters.HTTPAdapter(pool_connections=8, pool_maxsize=16))
HOSTS = ("https://www.so.com/", "https://www.sogou.com/", "https://html.duckduckgo.com/")
_warm_at = 0.0


def warm() -> None:
    """提前连上搜索站（后台，不阻塞）。45 秒内不重复。"""
    global _warm_at
    now = time.time()
    if now - _warm_at < 45:
        return
    _warm_at = now

    def one(u):
        try:
            _session.head(u, timeout=2.5, allow_redirects=False)
        except requests.RequestException:
            pass
    for u in HOSTS:
        threading.Thread(target=one, args=(u,), daemon=True).start()


def clean_text(text: str) -> str:
    """去掉版面带来的换行和中文字之间的空格。"""
    s = re.sub(r"[\r\n  \t ]+", " ", str(text or "")).strip()
    return re.sub(r"(?<=[　-鿿＀-￯]) (?=[　-鿿＀-￯])", "", s)


def make_query(text: str, limit: int = 60) -> str:
    """搜索词：太长的文字取开头，尽量在句号处断开。"""
    s = re.sub(r"(^|\s)[•·▪●○◆■□►▶–—\-]+\s*", " ", clean_text(text)).strip()   # 项目符号不是要查的内容
    if len(s) <= limit:
        return s
    head = s[:limit]
    cut = max(head.rfind(c) for c in "。？！；?!;")
    if cut >= 12:
        return head[:cut]
    cut = max(head.rfind(c) for c in "，, ")
    return head[:cut] if cut >= 20 else head


def _trim(s, n=150):
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[:n - 1] + "…"


def parse_ddg(html):
    soup = BeautifulSoup(html, "html.parser")
    out = []
    for box in soup.select("div.result"):
        a = box.select_one("a.result__a")
        if not a or not a.get("href"):
            continue
        url = a["href"]
        m = re.search(r"uddg=([^&]+)", url)
        if m:
            url = unquote(m.group(1))
        elif url.startswith("//"):
            url = "https:" + url
        sn = box.select_one(".result__snippet")
        out.append(dict(title=_trim(a.get_text(), 70), url=url, snippet=_trim(sn.get_text(" ") if sn else "")))
    return out


def parse_so(html):
    a0 = html.find('class="result"')
    soup = BeautifulSoup(html[max(0, a0 - 200):] if a0 >= 0 else html, "html.parser")
    out = []
    for li in soup.select("li.res-list"):
        a = li.select_one("h3 a")
        if not a:
            continue
        url = a.get("data-mdurl") or a.get("href") or ""
        sn = li.select_one(".res-desc, .res-comm-con, .mh-summary, p")
        if url.startswith("http"):
            out.append(dict(title=_trim(a.get_text(), 70), url=url, snippet=_trim(sn.get_text(" ") if sn else "")))
    return out


def parse_sogou(html):
    a0 = html.find('class="results"')
    soup = BeautifulSoup(html[max(0, a0 - 100):] if a0 >= 0 else html, "html.parser")
    out = []
    for box in soup.select("div.vrwrap, div.rb"):
        a = box.select_one("h3 a")
        if not a or not a.get("href"):
            continue
        url = a["href"]
        if url.startswith("/"):
            url = "https://www.sogou.com" + url
        sn = box.select_one(".space-txt, .text-layout, .str_info, .ft, p")
        text = sn.get_text(" ") if sn else ""
        if text.strip():
            out.append(dict(title=_trim(a.get_text(), 70), url=url, snippet=_trim(text)))
    return out


SOURCES = (
    ("360", lambda q: f"https://www.so.com/s?q={quote(q)}", parse_so),
    ("搜狗", lambda q: f"https://www.sogou.com/web?query={quote(q)}", parse_sogou),
    ("DuckDuckGo", lambda q: f"https://html.duckduckgo.com/html/?q={quote(q)}", parse_ddg),
)


def _terms(q):
    q = q.lower()
    out = set(re.findall(r"[a-z0-9]{2,}", q))
    for run in re.findall(r"[\u4e00-\u9fff]+", q):
        out.update(run[i:i + 2] for i in range(max(1, len(run) - 1)))
    return out


def relevance(query, item) -> float:
    """标题和摘要里有多少查询词。有的搜索站对程序访问会返回随机内容，靠这个挡掉。"""
    terms = _terms(query)
    if not terms:
        return 1.0
    hay = (item.get("title", "") + " " + item.get("snippet", "")).lower()
    return sum(1 for t in terms if t in hay) / len(terms)


def fetch(name, make_url, parse, query, timeout=5.0):
    r = _session.get(make_url(query), timeout=(1.5, timeout))
    if r.status_code != 200 or "captcha" in r.url or "antispider" in r.url:   # 被要求验证就放弃这个来源，不去绕
        return []
    r.encoding = r.apparent_encoding if not r.encoding or r.encoding.lower() == "iso-8859-1" else r.encoding
    items = [it for it in parse(r.text) if relevance(query, it) >= 0.3]
    for it in items:
        it["source"] = name
    return items[:5]


class Lookup(QObject):
    """一次查询。信号都带 job 号：换了新查询后，旧的结果直接丢弃。"""
    results = Signal(int, object, float)     # job, 新到的条目, 用时
    ai_text = Signal(int, str)               # job, 目前的摘要全文
    ai_state = Signal(int, str)              # job, 状态文字
    finished = Signal(int, int, float)       # job, 条数, 用时

    def __init__(self):
        super().__init__()
        self.job = 0
        self.pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="lookup")

    def start(self, query: str, sources=SOURCES, use_ai=True) -> int:
        self.job += 1
        job = self.job
        threading.Thread(target=self._run, args=(job, query, sources, use_ai), daemon=True).start()
        return job

    def cancel(self):
        self.job += 1

    def _run(self, job, query, sources, use_ai):
        t0 = time.perf_counter()
        seen, got = set(), []
        lock = threading.Lock()
        first = threading.Event()
        pending = [len(sources)]
        all_done = threading.Event()

        def one(name, mk, parse):
            items = []
            try:
                items = fetch(name, mk, parse, query)
            except Exception:  # noqa: BLE001  网络和解析都可能出错；一个来源失败不影响别的
                items = []
            with lock:
                fresh = []
                for it in items:
                    key = re.sub(r"\W+", "", it["title"])[:24] or it["url"]
                    if key not in seen:
                        seen.add(key)
                        fresh.append(it)
                got.extend(fresh)
                pending[0] -= 1
                left = pending[0]
            if fresh and job == self.job:
                self.results.emit(job, fresh, time.perf_counter() - t0)
            if fresh:
                first.set()
            if left == 0:
                first.set()
                all_done.set()
        for name, mk, parse in sources:
            self.pool.submit(one, name, mk, parse)
        if use_ai and _ai_ready():
            first.wait(1.5)   # 手里有资料再问 AI：摘要才有依据（资料一到就开始，不会干等）
            if job == self.job:
                threading.Thread(target=self._ai, args=(job, query, got, lock), daemon=True).start()
        all_done.wait(7)
        if job == self.job:
            self.finished.emit(job, len(got), time.perf_counter() - t0)

    def _ai(self, job, query, got, lock):
        from ..analysis.llm import settings
        ds = settings()
        with lock:
            refs = list(got[:6])
        ctx = "\n".join(f"[{i + 1}] {r['title']}：{r['snippet']}" for i, r in enumerate(refs))
        system = "你是课堂助教。根据搜索摘要，用简体中文给高中生说清楚所查内容：先一句话讲是什么，再补一两个要点，共不超过 120 字。没把握的不要编造。直接写内容，不要标题和 Markdown。" + ("" if refs else "这次没有搜到资料，请根据常识回答，并在开头说明这一点。")
        user = f"要查的内容：{query}\n\n搜索摘要：\n{ctx or '（暂无）'}"
        model = ds["model"] if "reasoner" not in ds["model"] else "deepseek-chat"
        body = dict(model=model, messages=[dict(role="system", content=system), dict(role="user", content=user)], temperature=0.3, max_tokens=320, stream=True)
        text = ""
        try:
            r = requests.post(ds["base"] + "/chat/completions", json=body, headers={"Authorization": "Bearer " + ds["key"]}, stream=True, timeout=(2, 15))
            if r.status_code != 200:
                self.ai_state.emit(job, f"AI 摘要没有出来（{r.status_code}）")
                return
            for raw in r.iter_lines():
                if job != self.job:
                    r.close()
                    return
                if not raw.startswith(b"data:"):
                    continue
                data = raw[5:].strip()
                if data == b"[DONE]":
                    break
                try:
                    delta = json.loads(data)["choices"][0].get("delta") or {}
                except (ValueError, KeyError, IndexError):
                    continue
                if delta.get("content"):
                    text += delta["content"]
                    self.ai_text.emit(job, text)
        except requests.RequestException:
            self.ai_state.emit(job, "AI 摘要没有出来（连接失败）")


def _ai_ready() -> bool:
    from ..analysis.llm import available
    return available()


# ================================================================ 本机文字识别（Windows 自带）
OCR_PS = r"""
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null=[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
$null=[Windows.Storage.Streams.IRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
$m=([System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'})[0]
function Await($op,$t){ $k=$m.MakeGenericMethod($t).Invoke($null,@($op)); $k.Wait(); $k.Result }
$lang=[Windows.Globalization.Language]::new('zh-Hans-CN')
$engine=if([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($lang)){[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)}else{[Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()}
if(-not $engine){[Console]::Out.WriteLine('NOENGINE');exit 3}
[Console]::Out.WriteLine('READY');[Console]::Out.Flush()
while($true){
  $line=[Console]::In.ReadLine(); if($null -eq $line){break}
  try{
    $path=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($line.Trim()))
    $f=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
    $s=Await ($f.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $d=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($s)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $b=Await ($d.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $r=Await ($engine.RecognizeAsync($b)) ([Windows.Media.Ocr.OcrResult])
    $t=($r.Lines|ForEach-Object{$_.Text}) -join "`n"
    $s.Dispose();$b.Dispose()
    [Console]::Out.WriteLine('OK '+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes([string]$t)))
  }catch{ [Console]::Out.WriteLine('ERR') }
  [Console]::Out.Flush()
}
"""


class Ocr:
    """常驻的识别进程：播放器打开时启动，关闭时退出。"""

    def __init__(self):
        self.proc = None
        self.ready = threading.Event()
        self.lock = threading.Lock()
        self.tmp = None

    def start(self):
        if sys.platform != "win32" or self.proc is not None:
            return
        threading.Thread(target=self._boot, daemon=True).start()

    def _boot(self):
        try:
            self.tmp = Path(tempfile.mkdtemp(prefix="jw-ocr-"))
            script = self.tmp / "ocr.ps1"
            script.write_bytes(b"\xef\xbb\xbf" + OCR_PS.encode("utf-8"))
            self.proc = subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=0x08000000)
            if self.proc.stdout.readline().strip() == b"READY":
                self.ready.set()
        except OSError:
            self.proc = None

    def read(self, image, wait=1.5) -> str:
        """识别 QImage，返回文字；不可用或失败时返回空串。"""
        if not self.ready.wait(wait) or self.proc is None or self.proc.poll() is not None:
            return ""
        from PySide6.QtCore import Qt
        im = image
        if im.height() < 120 or im.width() < 300:   # 太小的图放大一点，识别率高很多
            k = min(3.0, max(300 / max(1, im.width()), 120 / max(1, im.height())))
            im = im.scaled(int(im.width() * k), int(im.height() * k), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        elif max(im.width(), im.height()) > 3000:
            im = im.scaled(3000, 3000, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        with self.lock:
            p = self.tmp / "cap.png"
            if not im.save(str(p), "PNG", 20):
                return ""
            try:
                self.proc.stdin.write(base64.b64encode(str(p).encode("utf-8")) + b"\n")
                self.proc.stdin.flush()
                line = self.proc.stdout.readline().strip()
            except OSError:
                return ""
        if not line.startswith(b"OK "):
            return ""
        return clean_text(base64.b64decode(line[3:]).decode("utf-8", "replace"))

    def stop(self):
        p, self.proc = self.proc, None
        self.ready.clear()
        if p is not None:
            try:
                p.stdin.close()
            except OSError:
                pass
        if self.tmp is not None:
            import shutil
            threading.Timer(1.5, lambda d=self.tmp: shutil.rmtree(d, ignore_errors=True)).start()


def domain(url: str) -> str:
    try:
        return urlparse(url).netloc.removeprefix("www.")
    except ValueError:
        return ""
