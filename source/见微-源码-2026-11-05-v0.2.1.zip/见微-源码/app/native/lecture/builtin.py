"""内置排版：机器上没有 Office / WPS 时，自己读 .pptx / .docx 并画成 PDF。

覆盖常见内容：文字、项目符号、图片、基本形状、表格、背景、母版。图表和 SmartArt 显示占位提示；版式以 Office 为准。
"""
from __future__ import annotations

import posixpath
import re
import zipfile
from xml.etree import ElementTree as ET

from PySide6.QtCore import QMarginsF, QPointF, QRectF, QSizeF, Qt
from PySide6.QtGui import (QBrush, QColor, QFont, QImage, QPageLayout, QPageSize, QPainter, QPainterPath, QPdfWriter, QPen, QTextBlockFormat, QTextCharFormat, QTextCursor, QTextDocument,
                           QTextFrameFormat, QTextImageFormat, QTextLayout, QTextLength, QTextOption, QTextTableFormat)

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
WP = "{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}"
REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"
EMU_PT = 12700.0
UNIT = 10.0   # 画笔坐标：每磅 10 个单位
CJK = "Microsoft YaHei"


class Package:
    def __init__(self, path):
        self.z = zipfile.ZipFile(path)
        self.names = set(self.z.namelist())

    def xml(self, name):
        return ET.fromstring(self.z.read(name))

    def rels(self, part):
        d, b = posixpath.split(part)
        name = f"{d}/_rels/{b}.rels" if d else f"_rels/{b}.rels"
        out = {}
        if name in self.names:
            for r in self.xml(name):
                if r.get("TargetMode") == "External":
                    continue
                t = r.get("Target") or ""
                out[r.get("Id")] = t.lstrip("/") if t.startswith("/") else posixpath.normpath(posixpath.join(d, t))
        return out

    def image(self, name):
        if name not in self.names:
            return QImage()
        return QImage.fromData(self.z.read(name))


def _i(v, d=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return d


# ================================================================ PPTX
SCHEME_MAP = dict(tx1="dk1", tx2="dk2", bg1="lt1", bg2="lt2")


class Deck:
    def __init__(self, path):
        self.pk = Package(path)
        pres = self.pk.xml("ppt/presentation.xml")
        rels = self.pk.rels("ppt/presentation.xml")
        self.slides = [rels[s.get(R + "id")] for s in pres.findall(f"{P}sldIdLst/{P}sldId") if s.get(R + "id") in rels]
        sz = pres.find(P + "sldSz")
        self.w = _i(sz.get("cx"), 9144000) / EMU_PT if sz is not None else 720.0
        self.h = _i(sz.get("cy"), 6858000) / EMU_PT if sz is not None else 540.0
        self.theme = dict(dk1="000000", lt1="FFFFFF", dk2="44546A", lt2="E7E6E6", accent1="4472C4", accent2="ED7D31", accent3="A5A5A5", accent4="FFC000", accent5="5B9BD5", accent6="70AD47", hlink="0563C1", folHlink="954F72")
        self.cache = {}

    def part(self, name):
        if name not in self.cache:
            self.cache[name] = self.pk.xml(name)
        return self.cache[name]

    def load_theme(self, master):
        for t in self.pk.rels(master).values():
            if "theme" in t and t in self.pk.names:
                scheme = self.part(t).find(f"{A}themeElements/{A}clrScheme")
                if scheme is not None:
                    for c in scheme:
                        k = c.tag.split("}")[1]
                        v = c.find(A + "srgbClr")
                        s = c.find(A + "sysClr")
                        if v is not None:
                            self.theme[k] = v.get("val")
                        elif s is not None and s.get("lastClr"):
                            self.theme[k] = s.get("lastClr")
                return

    # ---- 颜色
    def color(self, node):
        """solidFill 这一类节点里的第一个颜色。"""
        if node is None:
            return None
        for c in node:
            tag = c.tag.split("}")[1]
            if tag == "srgbClr":
                q = QColor("#" + (c.get("val") or "000000"))
            elif tag == "schemeClr":
                k = c.get("val") or "tx1"
                q = QColor("#" + self.theme.get(SCHEME_MAP.get(k, k), "000000"))
            elif tag == "sysClr":
                q = QColor("#" + (c.get("lastClr") or "000000"))
            elif tag == "prstClr":
                q = QColor(c.get("val") or "black")
            else:
                continue
            h, s, li, a = q.getHslF()
            mod = c.find(A + "lumMod")
            off = c.find(A + "lumOff")
            if mod is not None or off is not None:
                li = li * (_i(mod.get("val"), 100000) / 100000 if mod is not None else 1) + (_i(off.get("val")) / 100000 if off is not None else 0)
                q = QColor.fromHslF(h, s, max(0, min(1, li)), a)
            al = c.find(A + "alpha")
            if al is not None:
                q.setAlphaF(_i(al.get("val"), 100000) / 100000)
            return q
        return None


def _ph(sp):
    ph = sp.find(f"{P}nvSpPr/{P}nvPr/{P}ph")
    return ph


def _find_ph(tree, want):
    """在版式 / 母版里找对应的占位符。"""
    if tree is None or want is None:
        return None
    t, idx = want.get("type"), want.get("idx")
    same = None
    for sp in tree.iter(P + "sp"):
        ph = _ph(sp)
        if ph is None:
            continue
        if idx is not None and ph.get("idx") == idx:
            return sp
        if t and ph.get("type") == t:
            same = same if same is not None else sp
        elif t in (None, "body", "subTitle", "obj") and ph.get("type") in (None, "body", "obj") and same is None:
            same = sp
        elif t in ("title", "ctrTitle") and ph.get("type") in ("title", "ctrTitle") and same is None:
            same = sp
    return same


class SlidePainter:
    def __init__(self, deck, p):
        self.d, self.p = deck, p

    def fill(self, sppr):
        """形状的填充：返回颜色、None（无填充）或 'inherit'。"""
        if sppr is None:
            return "inherit"
        if sppr.find(A + "noFill") is not None:
            return None
        sf = sppr.find(A + "solidFill")
        if sf is not None:
            return self.d.color(sf)
        gf = sppr.find(A + "gradFill")
        if gf is not None:
            gs = gf.find(f"{A}gsLst/{A}gs")
            if gs is not None:
                return self.d.color(gs)
        return "inherit"

    def background(self, trees, rels_list):
        for tree, rels in zip(trees, rels_list):
            if tree is None:
                continue
            bg = tree.find(f"{P}cSld/{P}bg")
            if bg is None:
                continue
            pr = bg.find(P + "bgPr")
            if pr is not None:
                sf = pr.find(A + "solidFill")
                if sf is not None:
                    col = self.d.color(sf)
                    if col is not None:
                        self.p.fillRect(self.page_rect(), col)
                        return
                gf = pr.find(A + "gradFill")
                if gf is not None:
                    gs = gf.find(f"{A}gsLst/{A}gs")
                    col = self.d.color(gs) if gs is not None else None
                    if col is not None:
                        self.p.fillRect(self.page_rect(), col)
                        return
                bl = pr.find(f"{A}blipFill/{A}blip")
                if bl is not None:
                    im = self.d.pk.image(rels.get(bl.get(R + "embed"), ""))
                    if not im.isNull():
                        self.p.drawImage(self.page_rect(), im)
                        return
            ref = bg.find(P + "bgRef")
            if ref is not None:
                col = self.d.color(ref)
                if col is not None:
                    self.p.fillRect(self.page_rect(), col)
                    return
        self.p.fillRect(self.page_rect(), QColor("white"))

    def page_rect(self):
        return QRectF(0, 0, self.d.w * UNIT, self.d.h * UNIT)

    def shapes(self, parent, rels, ctx, master_shapes=False):
        for el in parent:
            tag = el.tag.split("}")[1]
            try:
                if tag == "sp":
                    if master_shapes and _ph(el) is not None:
                        continue   # 母版和版式上的占位符只是模板，不显示
                    self.sp(el, rels, ctx)
                elif tag == "pic":
                    self.pic(el, rels)
                elif tag == "cxnSp":
                    self.sp(el, rels, ctx)
                elif tag == "grpSp":
                    self.group(el, rels, ctx, master_shapes)
                elif tag == "graphicFrame":
                    self.frame(el, rels, ctx)
            except (ValueError, AttributeError, TypeError):
                continue   # 一个形状读不懂不影响整页

    def group(self, el, rels, ctx, master_shapes):
        x = el.find(f"{P}grpSpPr/{A}xfrm")
        self.p.save()
        if x is not None:
            off, ext, cho, che = x.find(A + "off"), x.find(A + "ext"), x.find(A + "chOff"), x.find(A + "chExt")
            if None not in (off, ext, cho, che) and _i(che.get("cx")) and _i(che.get("cy")):
                sx, sy = _i(ext.get("cx")) / _i(che.get("cx")), _i(ext.get("cy")) / _i(che.get("cy"))
                self.p.translate(_i(off.get("x")) / EMU_PT * UNIT, _i(off.get("y")) / EMU_PT * UNIT)
                self.p.scale(sx, sy)
                self.p.translate(-_i(cho.get("x")) / EMU_PT * UNIT, -_i(cho.get("y")) / EMU_PT * UNIT)
        self.shapes(el, rels, ctx, master_shapes)
        self.p.restore()

    @staticmethod
    def xfrm(sppr):
        x = sppr.find(A + "xfrm") if sppr is not None else None
        if x is None:
            return None
        off, ext = x.find(A + "off"), x.find(A + "ext")
        if off is None or ext is None:
            return None
        return (QRectF(_i(off.get("x")) / EMU_PT * UNIT, _i(off.get("y")) / EMU_PT * UNIT, _i(ext.get("cx")) / EMU_PT * UNIT, _i(ext.get("cy")) / EMU_PT * UNIT),
                _i(x.get("rot")) / 60000.0, x.get("flipH") == "1", x.get("flipV") == "1")

    def sp(self, el, rels, ctx):
        sppr = el.find(P + "spPr")
        ph = _ph(el)
        lay = _find_ph(ctx["layout"], ph)
        mas = _find_ph(ctx["master"], ph if lay is None or _ph(lay) is None else _ph(lay))
        chain = [e for e in (lay, mas) if e is not None]
        geo = self.xfrm(sppr)
        for e in chain:
            if geo is None:
                geo = self.xfrm(e.find(P + "spPr"))
        if geo is None:
            return
        rect, rot, fh, fv = geo
        self.p.save()
        if rot:
            c = rect.center()
            self.p.translate(c)
            self.p.rotate(rot)
            self.p.translate(-c)
        f = self.fill(sppr)
        if f == "inherit":
            f = None
            for e in chain:
                f = self.fill(e.find(P + "spPr"))
                if f != "inherit":
                    break
            if f == "inherit":
                f = None
            style = el.find(P + "style")
            if f is None and style is not None and sppr is not None and sppr.find(A + "noFill") is None:
                ref = style.find(A + "fillRef")
                if ref is not None and _i(ref.get("idx")):
                    f = self.d.color(ref)
        prst = (sppr.find(A + "prstGeom").get("prst") if sppr is not None and sppr.find(A + "prstGeom") is not None else "rect")
        ln = sppr.find(A + "ln") if sppr is not None else None
        pen = Qt.PenStyle.NoPen
        if ln is not None and ln.find(A + "noFill") is None:
            col = self.d.color(ln.find(A + "solidFill"))
            if col is not None:
                pen = QPen(col, max(1.0, _i(ln.get("w"), 9525) / EMU_PT * UNIT))
        elif ln is None and el.find(P + "style") is not None:
            ref = el.find(P + "style").find(A + "lnRef")
            if ref is not None and _i(ref.get("idx")):
                col = self.d.color(ref)
                if col is not None:
                    pen = QPen(col, 7.5)
        self.p.setPen(pen)
        self.p.setBrush(QBrush(f) if isinstance(f, QColor) else Qt.BrushStyle.NoBrush)
        if prst in ("line", "straightConnector1", "bentConnector3"):
            a = QPointF(rect.right() if fh else rect.left(), rect.bottom() if fv else rect.top())
            b = QPointF(rect.left() if fh else rect.right(), rect.top() if fv else rect.bottom())
            self.p.drawLine(a, b)
        elif prst == "ellipse":
            self.p.drawEllipse(rect)
        elif prst in ("roundRect", "round2SameRect"):
            r = min(rect.width(), rect.height()) * 0.1667
            self.p.drawRoundedRect(rect, r, r)
        elif f is not None or pen != Qt.PenStyle.NoPen:
            self.p.drawRect(rect)
        tx = el.find(P + "txBody")
        if tx is not None:
            ref = el.find(P + "style").find(A + "fontRef") if el.find(P + "style") is not None else None
            self.text(tx, rect, ph, chain, ctx, default_color=self.d.color(ref) if ref is not None else None)
        self.p.restore()

    def pic(self, el, rels):
        geo = self.xfrm(el.find(P + "spPr"))
        blip = el.find(f"{P}blipFill/{A}blip")
        if geo is None or blip is None:
            return
        rect, rot, fh, fv = geo
        im = self.d.pk.image(rels.get(blip.get(R + "embed"), ""))
        self.p.save()
        if rot:
            c = rect.center()
            self.p.translate(c)
            self.p.rotate(rot)
            self.p.translate(-c)
        if im.isNull():
            self.placeholder(rect, "图片（这种格式需要 Office 或 WPS）")
        else:
            src = QRectF(im.rect())
            crop = el.find(f"{P}blipFill/{A}srcRect")
            if crop is not None:
                l, t, r, b = (_i(crop.get(k)) / 100000 for k in "ltrb")
                src = QRectF(im.width() * l, im.height() * t, im.width() * (1 - l - r), im.height() * (1 - t - b))
            if fh or fv:
                im = im.flipped(Qt.Orientation.Horizontal if fh and not fv else Qt.Orientation.Vertical if fv and not fh else Qt.Orientation.Horizontal | Qt.Orientation.Vertical)
            self.p.drawImage(rect, im, src)
        self.p.restore()

    def placeholder(self, rect, label):
        self.p.setPen(QPen(QColor("#999999"), 5, Qt.PenStyle.DashLine))
        self.p.setBrush(QColor(128, 128, 128, 26))
        self.p.drawRect(rect)
        self.p.setPen(QColor("#777777"))
        self.p.setFont(self.font(12, False, False))
        self.p.drawText(rect, int(Qt.AlignmentFlag.AlignCenter) | int(Qt.TextFlag.TextWordWrap), label)

    def frame(self, el, rels, ctx):
        x = el.find(P + "xfrm")
        if x is None:
            return
        off, ext = x.find(A + "off"), x.find(A + "ext")
        rect = QRectF(_i(off.get("x")) / EMU_PT * UNIT, _i(off.get("y")) / EMU_PT * UNIT, _i(ext.get("cx")) / EMU_PT * UNIT, _i(ext.get("cy")) / EMU_PT * UNIT)
        tbl = el.find(f"{A}graphic/{A}graphicData/{A}tbl")
        if tbl is None:
            self.placeholder(rect, "图表（需要 Office 或 WPS 才能显示）")
            return
        cols = [_i(c.get("w")) / EMU_PT * UNIT for c in tbl.findall(f"{A}tblGrid/{A}gridCol")]
        y = rect.top()
        self.p.setPen(QPen(QColor("#9a9a9a"), 5))
        for tr in tbl.findall(A + "tr"):
            h = _i(tr.get("h")) / EMU_PT * UNIT
            xx = rect.left()
            for i, tc in enumerate(tr.findall(A + "tc")):
                w = cols[i] if i < len(cols) else 0
                span = _i(tc.get("gridSpan"), 1)
                for j in range(1, span):
                    w += cols[i + j] if i + j < len(cols) else 0
                r = QRectF(xx, y, w, h)
                if tc.get("hMerge") != "1" and tc.get("vMerge") != "1":
                    pr = tc.find(A + "tcPr")
                    col = self.d.color(pr.find(A + "solidFill")) if pr is not None else None
                    self.p.setPen(QPen(QColor("#9a9a9a"), 5))
                    self.p.setBrush(QBrush(col) if col is not None else Qt.BrushStyle.NoBrush)
                    self.p.drawRect(r)
                    body = tc.find(A + "txBody")
                    if body is not None:
                        self.text(body, r.adjusted(50, 25, -50, -25), None, [], ctx, default_sz=18)
                xx += cols[i] if i < len(cols) else 0
            y += h

    @staticmethod
    def font(pt, bold, italic, latin=None):
        f = QFont()
        f.setFamilies([latin or "Calibri", CJK, "SimSun"])
        f.setPixelSize(max(10, int(round(pt * UNIT))))
        f.setBold(bold)
        f.setItalic(italic)
        return f

    def _style_lvl(self, ph, lvl, ctx):
        """母版里这一层文字的默认字号、颜色、对齐。"""
        tx = ctx["master"].find(f"{P}txStyles") if ctx["master"] is not None else None
        t = ph.get("type") if ph is not None else None
        kind = "titleStyle" if t in ("title", "ctrTitle") else "bodyStyle" if ph is not None else "otherStyle"
        node = tx.find(f"{P}{kind}/{A}lvl{lvl + 1}pPr") if tx is not None else None
        return node

    def text(self, body, rect, ph, chain, ctx, default_sz=None, default_color=None):
        pr = body.find(A + "bodyPr")
        scale = 1.0
        anchor = None
        ins = [91440, 45720, 91440, 45720]
        prs = [pr] + [e.find(f"{P}txBody/{A}bodyPr") for e in chain]
        for q in prs:
            if q is None:
                continue
            anchor = anchor or q.get("anchor")
            na = q.find(A + "normAutofit")
            if na is not None and na.get("fontScale") and scale == 1.0:
                scale = _i(na.get("fontScale"), 100000) / 100000
        if pr is not None:
            for i, k in enumerate(("lIns", "tIns", "rIns", "bIns")):
                if pr.get(k) is not None:
                    ins[i] = _i(pr.get(k))
        area = rect.adjusted(ins[0] / EMU_PT * UNIT, ins[1] / EMU_PT * UNIT, -ins[2] / EMU_PT * UNIT, -ins[3] / EMU_PT * UNIT)
        if area.width() < 10:
            return
        paras = []
        for para in body.findall(A + "p"):
            ppr = para.find(A + "pPr")
            lvl = _i(ppr.get("lvl")) if ppr is not None else 0
            sty = self._style_lvl(ph, lvl, ctx)
            lay_lst = []
            for e in chain:
                n = e.find(f"{P}txBody/{A}lstStyle/{A}lvl{lvl + 1}pPr")
                if n is not None:
                    lay_lst.append(n)
            sources = lay_lst + ([sty] if sty is not None else [])
            def_rpr = [n.find(A + "defRPr") for n in sources if n.find(A + "defRPr") is not None]
            base_sz = next((_i(n.get("sz")) / 100 for n in def_rpr if n.get("sz")), default_sz or 18)
            base_col = next((c for c in (self.d.color(n.find(A + "solidFill")) for n in def_rpr) if c is not None), default_color or QColor("#" + self.d.theme.get("dk1", "000000")))
            base_b = next((n.get("b") == "1" for n in def_rpr if n.get("b") is not None), False)
            algn = (ppr.get("algn") if ppr is not None else None) or next((n.get("algn") for n in sources if n.get("algn")), "l")
            bullet = None
            nodes = ([ppr] if ppr is not None else []) + sources
            for n in nodes:
                if n.find(A + "buNone") is not None:
                    break
                bc = n.find(A + "buChar")
                if bc is not None:
                    bullet = bc.get("char") or "•"
                    break
                if n.find(A + "buAutoNum") is not None:
                    bullet = "•"
                    break
            mar = next((_i(n.get("marL")) for n in nodes if n.get("marL") is not None), 0) / EMU_PT * UNIT
            ind = next((_i(n.get("indent")) for n in nodes if n.get("indent") is not None), 0) / EMU_PT * UNIT
            text, fmts = "", []
            first_font = None
            for r in para:
                tag = r.tag.split("}")[1]
                if tag == "br":
                    text += " "
                    continue
                if tag not in ("r", "fld"):
                    continue
                t = r.find(A + "t")
                s = t.text if t is not None and t.text else ""
                if not s:
                    continue
                rp = r.find(A + "rPr")
                sz = (_i(rp.get("sz")) / 100 if rp is not None and rp.get("sz") else base_sz) * scale
                b = rp.get("b") == "1" if rp is not None and rp.get("b") is not None else base_b
                it = rp is not None and rp.get("i") == "1"
                u = rp is not None and rp.get("u") not in (None, "none")
                col = self.d.color(rp.find(A + "solidFill")) if rp is not None else None
                lat = rp.find(A + "latin") if rp is not None else None
                fmt = QTextCharFormat()
                ft = self.font(sz, b, it, lat.get("typeface") if lat is not None and not str(lat.get("typeface", "+")).startswith("+") else None)
                ft.setUnderline(u)
                fmt.setFont(ft)
                fmt.setForeground(col if col is not None else base_col)
                first_font = first_font or (ft, col if col is not None else base_col)
                rng = QTextLayout.FormatRange()
                rng.start, rng.length, rng.format = len(text), len(s), fmt
                fmts.append(rng)
                text += s
            size = (base_sz * scale)
            paras.append(dict(text=text, fmts=fmts, algn=algn, size=size, bullet=bullet if text else None, mar=mar, ind=ind, font=first_font, base=base_col))
        layouts, total = [], 0.0
        for q in paras:
            f0 = q["font"][0] if q["font"] else self.font(q["size"], False, False)
            lay = QTextLayout(q["text"], f0)
            lay.setFormats(q["fmts"])
            op = QTextOption({"ctr": Qt.AlignmentFlag.AlignHCenter, "r": Qt.AlignmentFlag.AlignRight, "just": Qt.AlignmentFlag.AlignJustify}.get(q["algn"], Qt.AlignmentFlag.AlignLeft))
            op.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
            lay.setTextOption(op)
            lay.beginLayout()
            y = 0.0
            lw = max(10.0, area.width() - q["mar"])
            while True:
                ln = lay.createLine()
                if not ln.isValid():
                    break
                ln.setLineWidth(lw)
                ln.setPosition(QPointF(0, y))
                y += ln.height() * 1.08
            lay.endLayout()
            h = y if q["text"] else f0.pixelSize() * 1.2
            gap = q["size"] * UNIT * 0.22
            layouts.append((lay, q, h, gap))
            total += h + gap
        top = area.top()
        if anchor == "ctr":
            top = area.top() + (area.height() - total) / 2
        elif anchor == "b":
            top = area.bottom() - total
        y = top
        for lay, q, h, gap in layouts:
            lay.draw(self.p, QPointF(area.left() + q["mar"], y))
            if q["bullet"] and q["font"]:
                self.p.setFont(q["font"][0])
                self.p.setPen(q["font"][1])
                self.p.drawText(QPointF(area.left() + q["mar"] + q["ind"], y + lay.lineAt(0).ascent()), "•" if q["bullet"] in ("§", "Ø", "ü", "n", "q", "v") else q["bullet"])
            y += h + gap


def pptx_to_pdf(src, out):
    d = Deck(src)
    if not d.slides:
        raise ValueError("文件里没有幻灯片")
    w = QPdfWriter(str(out))
    w.setResolution(int(72 * UNIT))
    w.setPageLayout(QPageLayout(QPageSize(QSizeF(d.w, d.h), QPageSize.Unit.Point, "slide", QPageSize.SizeMatchPolicy.ExactMatch), QPageLayout.Orientation.Portrait, QMarginsF(0, 0, 0, 0)))
    p = QPainter(w)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    sp = SlidePainter(d, p)
    for i, name in enumerate(d.slides):
        if i:
            w.newPage()
        rels = d.pk.rels(name)
        slide = d.part(name)
        layout_name = next((t for t in rels.values() if "slideLayout" in t), None)
        layout = d.part(layout_name) if layout_name else None
        lrels = d.pk.rels(layout_name) if layout_name else {}
        master_name = next((t for t in lrels.values() if "slideMaster" in t), None)
        master = d.part(master_name) if master_name else None
        mrels = d.pk.rels(master_name) if master_name else {}
        if master_name:
            d.load_theme(master_name)
        ctx = dict(layout=layout, master=master)
        sp.background([slide, layout, master], [rels, lrels, mrels])
        if master is not None and (layout is None or layout.get("showMasterSp") != "0") and slide.get("showMasterSp") != "0":
            sp.shapes(master.find(f"{P}cSld/{P}spTree"), mrels, ctx, True)
        if layout is not None and slide.get("showMasterSp") != "0":
            sp.shapes(layout.find(f"{P}cSld/{P}spTree"), lrels, ctx, True)
        sp.shapes(slide.find(f"{P}cSld/{P}spTree"), rels, ctx)
    p.end()


# ================================================================ DOCX
HEAD_PT = {0: 22, 1: 18, 2: 16, 3: 14, 4: 13, 5: 12}


class Doc:
    def __init__(self, path):
        self.pk = Package(path)
        self.rels = self.pk.rels("word/document.xml")
        self.styles = {}
        self.default_pt = 11.0
        if "word/styles.xml" in self.pk.names:
            root = self.pk.xml("word/styles.xml")
            dflt = root.find(f"{W}docDefaults/{W}rPrDefault/{W}rPr/{W}sz")
            if dflt is not None:
                self.default_pt = _i(dflt.get(W + "val"), 22) / 2
            for s in root.findall(W + "style"):
                self.styles[s.get(W + "styleId")] = s
        self.images = 0

    def style(self, sid, seen=None):
        """顺着 basedOn 合并样式：字号、粗体、颜色、大纲级别、对齐。"""
        seen = seen or set()
        out = dict(size=None, bold=None, italic=None, color=None, outline=None, jc=None, num=False)
        s = self.styles.get(sid)
        if s is None or sid in seen:
            return out
        seen.add(sid)
        base = s.find(W + "basedOn")
        if base is not None:
            out.update(self.style(base.get(W + "val"), seen))
        rp, pp = s.find(W + "rPr"), s.find(W + "pPr")
        if rp is not None:
            self._run_props(rp, out)
        if pp is not None:
            ol = pp.find(W + "outlineLvl")
            if ol is not None:
                out["outline"] = _i(ol.get(W + "val"))
            jc = pp.find(W + "jc")
            if jc is not None:
                out["jc"] = jc.get(W + "val")
            if pp.find(W + "numPr") is not None:
                out["num"] = True
        return out

    @staticmethod
    def _run_props(rp, out):
        sz = rp.find(W + "sz")
        if sz is not None:
            out["size"] = _i(sz.get(W + "val"), 22) / 2
        for k, tag in (("bold", "b"), ("italic", "i")):
            n = rp.find(W + tag)
            if n is not None:
                out[k] = n.get(W + "val") not in ("0", "false")
        c = rp.find(W + "color")
        if c is not None and re.fullmatch(r"[0-9A-Fa-f]{6}", c.get(W + "val") or ""):
            out["color"] = c.get(W + "val")
        return out


def _char_format(doc, st, rp):
    props = dict(st)
    if rp is not None:
        Doc._run_props(rp, props)
    f = QTextCharFormat()
    outline = st.get("outline")
    size = props.get("size") or (HEAD_PT.get(outline) if outline is not None else None) or doc.default_pt
    f.setFontPointSize(size)
    f.setFontFamilies(["Calibri", CJK, "SimSun"])
    f.setFontWeight(QFont.Weight.Bold if (props.get("bold") if props.get("bold") is not None else outline is not None) else QFont.Weight.Normal)
    f.setFontItalic(bool(props.get("italic")))
    if rp is not None and rp.find(W + "u") is not None and rp.find(W + "u").get(W + "val") != "none":
        f.setFontUnderline(True)
    if props.get("color") and props["color"].lower() != "auto":
        f.setForeground(QColor("#" + props["color"]))
    return f


def _para(doc, qdoc, cur, para, first):
    pp = para.find(W + "pPr")
    sid = pp.find(W + "pStyle").get(W + "val") if pp is not None and pp.find(W + "pStyle") is not None else "Normal"
    st = doc.style(sid)
    bf = QTextBlockFormat()
    jc = (pp.find(W + "jc").get(W + "val") if pp is not None and pp.find(W + "jc") is not None else None) or st.get("jc")
    bf.setAlignment({"center": Qt.AlignmentFlag.AlignHCenter, "right": Qt.AlignmentFlag.AlignRight, "both": Qt.AlignmentFlag.AlignJustify}.get(jc, Qt.AlignmentFlag.AlignLeft))
    bf.setBottomMargin(6)
    bf.setLineHeight(120, 1)
    if st.get("outline") is not None:
        bf.setTopMargin(12)
    num = (pp is not None and pp.find(W + "numPr") is not None) or st.get("num")
    if num:
        lvl = pp.find(f"{W}numPr/{W}ilvl") if pp is not None else None
        bf.setLeftMargin(18 * (1 + (_i(lvl.get(W + "val")) if lvl is not None else 0)))
    if not first:
        cur.insertBlock(bf)
    else:
        cur.setBlockFormat(bf)
    if num:
        cur.insertText("• ", _char_format(doc, st, None))
    for run in para.iter(W + "r"):
        rp = run.find(W + "rPr")
        fmt = _char_format(doc, st, rp)
        for ch in run:
            tag = ch.tag.split("}")[1]
            if tag == "t" and ch.text:
                cur.insertText(ch.text, fmt)
            elif tag == "tab":
                cur.insertText("\t", fmt)
            elif tag == "br":
                if ch.get(W + "type") == "page":
                    b = cur.blockFormat()
                    b.setPageBreakPolicy(QTextBlockFormat.PageBreakFlag.PageBreak_AlwaysAfter)
                    cur.setBlockFormat(b)
                else:
                    cur.insertText(" ", fmt)
            elif tag in ("drawing", "pict", "object"):
                blip = ch.find(f".//{A}blip")
                ext = ch.find(f".//{WP}extent")
                if blip is None:
                    continue
                im = doc.pk.image(doc.rels.get(blip.get(R + "embed"), ""))
                if im.isNull():
                    continue
                doc.images += 1
                name = f"img{doc.images}"
                qdoc.addResource(QTextDocument.ResourceType.ImageResource.value, name, im)
                f = QTextImageFormat()
                f.setName(name)
                wpt = _i(ext.get("cx")) / EMU_PT if ext is not None else im.width() * 0.75
                hpt = _i(ext.get("cy")) / EMU_PT if ext is not None else im.height() * 0.75
                f.setWidth(wpt)
                f.setHeight(hpt)
                cur.insertImage(f)


def _table(doc, qdoc, cur, tbl):
    rows = tbl.findall(W + "tr")
    ncol = max([len(r.findall(W + "tc")) for r in rows] + [1])
    if not rows:
        return
    tf = QTextTableFormat()
    tf.setBorder(0.5)
    tf.setBorderStyle(QTextFrameFormat.BorderStyle.BorderStyle_Solid)
    tf.setCellPadding(4)
    tf.setCellSpacing(0)
    tf.setWidth(QTextLength(QTextLength.Type.PercentageLength, 100))
    cur.insertBlock()
    t = cur.insertTable(len(rows), ncol, tf)
    for i, r in enumerate(rows):
        for j, tc in enumerate(r.findall(W + "tc")):
            cc = t.cellAt(i, j).firstCursorPosition()
            first = True
            for p in tc.findall(W + "p"):
                _para(doc, qdoc, cc, p, first)
                first = False
    cur.movePosition(QTextCursor.MoveOperation.End)


def docx_to_pdf(src, out):
    d = Doc(src)
    root = d.pk.xml("word/document.xml")
    body = root.find(W + "body")
    if body is None:
        raise ValueError("文件里没有正文")
    q = QTextDocument()
    sect = body.find(W + "sectPr")
    pw, ph, margin = 595.0, 842.0, 72.0
    if sect is not None:
        pg = sect.find(W + "pgSz")
        if pg is not None:
            pw, ph = _i(pg.get(W + "w"), 11906) / 20, _i(pg.get(W + "h"), 16838) / 20
        mar = sect.find(W + "pgMar")
        if mar is not None:
            margin = _i(mar.get(W + "left"), 1440) / 20
    q.setDocumentMargin(margin)
    q.setUseDesignMetrics(True)
    cur = QTextCursor(q)
    first = True
    for el in body:
        tag = el.tag.split("}")[1]
        if tag == "p":
            _para(d, q, cur, el, first)
            first = False
        elif tag == "tbl":
            _table(d, q, cur, el)
            first = False
    w = QPdfWriter(str(out))
    w.setPageLayout(QPageLayout(QPageSize(QSizeF(pw, ph), QPageSize.Unit.Point, "doc", QPageSize.SizeMatchPolicy.ExactMatch), QPageLayout.Orientation.Portrait, QMarginsF(0, 0, 0, 0)))
    w.setResolution(1200)
    q.print_(w)


_ = QPainterPath
