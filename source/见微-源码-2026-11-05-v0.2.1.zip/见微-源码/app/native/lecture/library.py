"""课件库：每份课件一个目录（原文件、PDF、缩略图、笔迹、黑板）。"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
import uuid
from pathlib import Path

from ..kit.home import home
from .convert import SUPPORTED, ConvertError, kind_of, to_pdf


def root() -> Path:
    p = home() / "lectures"
    p.mkdir(parents=True, exist_ok=True)
    return p


def folder(lid: str) -> Path:
    return root() / lid


def _write(path: Path, data) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


save_json = _write


def all_lectures() -> list:
    out = []
    for d in root().iterdir():
        m = read_json(d / "meta.json") if d.is_dir() else None
        if isinstance(m, dict) and (d / "doc.pdf").is_file():
            out.append(m)
    return sorted(out, key=lambda m: -float(m.get("opened") or m.get("added") or 0))


def update(lid: str, **kw) -> None:
    p = folder(lid) / "meta.json"
    m = read_json(p, {})
    m.update(kw)
    _write(p, m)


def remove(lid: str) -> None:
    d = folder(lid)
    if d.parent == root() and d.is_dir():
        shutil.rmtree(d, ignore_errors=True)


def _digest(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def import_file(src, status=None, use_com=True) -> dict:
    """导入一个文件，返回 meta。同一个文件再导入一次直接返回原来那份（笔迹和黑板都还在）。"""
    from PySide6.QtPdf import QPdfDocument

    from .pageview import render_page
    src = Path(src)
    if src.suffix.lower() not in SUPPORTED:
        raise ConvertError(f"不支持 {src.suffix or '这种'} 文件。可以导入 PPT、Word 和 PDF。")
    if not src.is_file():
        raise ConvertError("找不到这个文件")
    say = status or (lambda _s: None)
    digest = _digest(src)
    for m in all_lectures():
        if m.get("sha1") == digest:
            say("这份课件已经导入过")
            m["existing"] = True
            return m
    lid = uuid.uuid4().hex[:12]
    d = folder(lid)
    d.mkdir(parents=True)
    try:
        stored = d / ("source" + src.suffix.lower())
        shutil.copyfile(src, stored)
        engine = to_pdf(stored, d / "doc.pdf", say, use_com=use_com)
        doc = QPdfDocument()
        doc.load(str(d / "doc.pdf"))
        pages = doc.pageCount()
        if pages <= 0:
            raise ConvertError("转换结果没有内容，这个文件可能已损坏")
        pt = doc.pagePointSize(0)
        kind = kind_of(src)
        if kind == "pdf":
            kind = "slides" if pt.width() > pt.height() else "doc"
        thumb_w = 480
        render_page(doc, 0, thumb_w, max(1, int(thumb_w * pt.height() / max(1, pt.width())))).save(str(d / "thumb.png"))
        doc.close()
        meta = dict(id=lid, title=src.stem, kind=kind, pages=pages, engine=engine, src_name=src.name, sha1=digest, added=time.time(), opened=0, page=0)
        _write(d / "meta.json", meta)
        return meta
    except BaseException:
        shutil.rmtree(d, ignore_errors=True)
        raise
