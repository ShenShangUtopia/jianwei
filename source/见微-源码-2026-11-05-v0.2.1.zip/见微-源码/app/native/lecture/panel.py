"""上网查询的抽屉：截图、搜索词（可改）、AI 摘要、资料卡片，顶上显示实际用时。"""
from __future__ import annotations

import threading
import time

from PySide6.QtCore import QObject, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QImage, QPixmap
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QVBoxLayout, QWidget

from . import lookup

QSS = """
QFrame#lookup { background:#14171C; border-left:1px solid #2B3038; }
QFrame#lookup QLabel { background:transparent; color:#D8DDE5; font-family:'Microsoft YaHei UI'; }
QFrame#lookup QLabel#title { font-size:15px; font-weight:700; color:#F2F4F7; }
QFrame#lookup QLabel#time { font-size:12px; color:#7FD1A0; }
QFrame#lookup QLabel#note { font-size:12px; color:#8D96A3; }
QFrame#lookup QLineEdit { background:#0D0F13; color:#F2F4F7; border:1px solid #363C46; border-radius:7px; padding:7px 9px; font-size:13.5px; font-family:'Microsoft YaHei UI'; selection-background-color:#3B6FD8; }
QFrame#lookup QLineEdit:focus { border-color:#4F8CFF; }
QFrame#lookup QPushButton { background:#232830; color:#D8DDE5; border:1px solid #363C46; border-radius:7px; padding:6px 11px; font-size:12.5px; font-family:'Microsoft YaHei UI'; }
QFrame#lookup QPushButton:hover { background:#2D343E; color:white; }
QFrame#lookup QPushButton#pri { background:#3B6FD8; border-color:#3B6FD8; color:white; font-weight:600; }
QFrame#lookup QPushButton#pri:hover { background:#4F8CFF; }
QFrame#lookup QPushButton#x { background:transparent; border:none; font-size:17px; padding:2px 8px; color:#8D96A3; }
QFrame#lookup QPushButton#x:hover { color:white; background:#2D343E; }
QFrame#lookup QPushButton#mini { background:transparent; border:none; color:#7FA8F5; padding:2px 0; font-size:12px; }
QFrame#lookup QPushButton#mini:hover { color:#A9C6FF; background:transparent; }
QFrame#card { background:#1B1F26; border:1px solid #2A2F38; border-radius:9px; }
QFrame#card:hover { border-color:#3D4552; }
QFrame#ai { background:#172033; border:1px solid #2C3D63; border-radius:9px; }
QLabel#cardTitle { color:#A9C6FF; font-size:13.5px; font-weight:600; }
QLabel#snip { color:#C2C8D2; font-size:12.5px; }
QLabel#src { color:#7D8693; font-size:11px; }
QLabel#aiTag { color:#8FB0F5; font-size:11.5px; font-weight:600; }
QLabel#aiBody { color:#E7ECF5; font-size:13.5px; }
QScrollArea, QScrollArea > QWidget > QWidget { background:transparent; border:none; }
QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
QScrollBar::handle:vertical { background:#3A404A; border-radius:3px; min-height:30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { height:0; background:transparent; }
"""


class _TextGot(QObject):
    got = Signal(int, str, float)


class Card(QFrame):
    def __init__(self, item, to_board):
        super().__init__()
        self.setObjectName("card")
        self.item = item
        v = QVBoxLayout(self)
        v.setContentsMargins(11, 9, 11, 8)
        v.setSpacing(4)
        t = QLabel(item["title"])
        t.setObjectName("cardTitle")
        t.setWordWrap(True)
        t.setCursor(Qt.CursorShape.PointingHandCursor)
        t.setToolTip(item["url"])
        t.mousePressEvent = lambda _e: QDesktopServices.openUrl(QUrl(item["url"]))
        v.addWidget(t)
        if item.get("snippet"):
            s = QLabel(item["snippet"])
            s.setObjectName("snip")
            s.setWordWrap(True)
            s.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            v.addWidget(s)
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        src = QLabel(f"{item.get('source', '')} · {lookup.domain(item['url'])}")
        src.setObjectName("src")
        h.addWidget(src, 1)
        b = QPushButton("写上黑板")
        b.setObjectName("mini")
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda: to_board(item["title"] + ("\n" + item["snippet"] if item.get("snippet") else "")))
        h.addWidget(b)
        v.addLayout(h)


class LookupPanel(QFrame):
    closed = Signal()
    to_board = Signal(str)
    image_to_board = Signal(QImage)

    def __init__(self, ocr: lookup.Ocr):
        super().__init__()
        self.setObjectName("lookup")
        self.setStyleSheet(QSS)
        self.ocr = ocr
        self.engine = lookup.Lookup()
        self.engine.results.connect(self._on_results)
        self.engine.ai_text.connect(self._on_ai)
        self.engine.ai_state.connect(self._on_ai_state)
        self.engine.finished.connect(self._on_done)
        self.bridge = _TextGot()
        self.bridge.got.connect(self._on_text)
        self.image = None
        self.ticket = 0
        self.job = -1
        self.t0 = 0.0
        self.first_at = None
        self.n = 0
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(9)
        top = QHBoxLayout()
        ti = QLabel("上网查询")
        ti.setObjectName("title")
        top.addWidget(ti)
        self.time_label = QLabel("")
        self.time_label.setObjectName("time")
        top.addWidget(self.time_label, 1)
        x = QPushButton("×")
        x.setObjectName("x")
        x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        x.clicked.connect(self.close_panel)
        top.addWidget(x)
        v.addLayout(top)
        self.thumb = QLabel()
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb.setMaximumHeight(120)
        v.addWidget(self.thumb)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("要查什么")
        self.edit.returnPressed.connect(self.search_now)
        row.addWidget(self.edit, 1)
        go = QPushButton("查询")
        go.setObjectName("pri")
        go.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        go.clicked.connect(self.search_now)
        row.addWidget(go)
        v.addLayout(row)
        self.note = QLabel("")
        self.note.setObjectName("note")
        self.note.setWordWrap(True)
        v.addWidget(self.note)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.body = QWidget()
        self.list = QVBoxLayout(self.body)
        self.list.setContentsMargins(0, 0, 4, 0)
        self.list.setSpacing(8)
        self.ai_box = QFrame()
        self.ai_box.setObjectName("ai")
        av = QVBoxLayout(self.ai_box)
        av.setContentsMargins(11, 9, 11, 9)
        av.setSpacing(4)
        ah = QHBoxLayout()
        tag = QLabel("AI 摘要（根据下面的资料，请自己核对）")
        tag.setObjectName("aiTag")
        ah.addWidget(tag, 1)
        ab = QPushButton("写上黑板")
        ab.setObjectName("mini")
        ab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        ab.clicked.connect(lambda: self.to_board.emit(self.ai_body.text()))
        ah.addWidget(ab)
        av.addLayout(ah)
        self.ai_body = QLabel("")
        self.ai_body.setObjectName("aiBody")
        self.ai_body.setWordWrap(True)
        self.ai_body.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        av.addWidget(self.ai_body)
        self.ai_box.hide()
        self.list.addWidget(self.ai_box)
        self.list.addStretch(1)
        self.scroll.setWidget(self.body)
        v.addWidget(self.scroll, 1)
        foot = QHBoxLayout()
        self.img_btn = QPushButton("截图带入黑板")
        self.img_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.img_btn.clicked.connect(lambda: self.image is not None and self.image_to_board.emit(self.image))
        foot.addWidget(self.img_btn)
        self.web_btn = QPushButton("在浏览器里搜")
        self.web_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.web_btn.clicked.connect(self._open_web)
        foot.addWidget(self.web_btn)
        foot.addStretch(1)
        v.addLayout(foot)

    # ---- 开始
    def start(self, image: QImage, text: str, hint: str = "") -> None:
        """截图 + 文字层里的文字；没有文字时先识别图片。整个过程不卡界面。"""
        self.t0 = time.perf_counter()
        self.ticket += 1
        self.image = image
        self.engine.cancel()
        self._reset()
        self.img_btn.setVisible(True)
        pm = QPixmap.fromImage(image).scaled(420, 120, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.thumb.setPixmap(pm)
        self.thumb.setVisible(True)
        self.edit.setText("")
        self.hint = hint
        q = lookup.make_query(text)
        if len(q) >= 2:
            self.edit.setText(q)
            self._go(q)
            return
        self.note.setText("这块是图片，正在识别上面的文字…")
        lookup.warm()
        tk = self.ticket
        threading.Thread(target=lambda: self.bridge.got.emit(tk, self.ocr.read(image), time.perf_counter() - self.t0), daemon=True).start()

    def _on_text(self, ticket, text, _el):
        if ticket != self.ticket:
            return
        q = lookup.make_query(text)
        if len(q) >= 2:
            self.edit.setText(q)
            self._go(q)
        else:
            self.note.setText("图里没有读到文字。写下想查的内容，按回车。")
            if self.hint:
                self.edit.setPlaceholderText(f"比如：{self.hint}")
            self.edit.setFocus()

    def search_now(self):
        q = self.edit.text().strip()
        if q:
            self.t0 = time.perf_counter()
            self._reset()
            self._go(q)

    def _reset(self):
        self.engine.cancel()
        self.first_at = None
        self.n = 0
        self.time_label.setText("")
        self.note.setText("")
        self.ai_body.setText("")
        self.ai_box.hide()
        while self.list.count() > 2:
            w = self.list.takeAt(1).widget()
            if w is not None:
                w.hide()
                w.deleteLater()

    def _go(self, q):
        self.note.setText("正在查…")
        self.job = self.engine.start(q)

    # ---- 结果
    def _on_results(self, job, items, _el):
        if job != self.job:
            return
        if self.first_at is None:
            self.first_at = time.perf_counter() - self.t0
            self.note.setText("")
        for it in items:
            if self.n >= 12:
                break
            self.list.insertWidget(self.list.count() - 1, Card(it, self.to_board.emit))
            self.n += 1
        self.time_label.setText(f"{self.first_at:.1f} 秒出资料 · {self.n} 条")

    def _on_ai(self, job, text):
        if job != self.job:
            return
        self.ai_box.show()
        self.ai_body.setText(text)

    def _on_ai_state(self, job, text):
        if job == self.job and not self.ai_body.text():
            self.note.setText(text)

    def _on_done(self, job, n, _el):
        if job != self.job or n:
            return
        if not self.ai_body.text():
            self.note.setText("没有查到资料。可能没联网，或者换个说法再试试。")

    def _open_web(self):
        from urllib.parse import quote
        q = self.edit.text().strip()
        if q:
            QDesktopServices.openUrl(QUrl(f"https://www.so.com/s?q={quote(q)}"))

    def close_panel(self):
        self.engine.cancel()
        self.ticket += 1
        self.hide()
        self.closed.emit()
