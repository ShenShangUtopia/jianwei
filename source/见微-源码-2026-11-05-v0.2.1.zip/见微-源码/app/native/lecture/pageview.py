"""课件一页的显示与笔画：渲染缓存、缩放平移、笔 / 荧光笔 / 橡皮、框选截取。"""
from __future__ import annotations

import math
import time

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QCursor, QImage, QPainter, QPen, QPixmap, QPointingDevice
from PySide6.QtPdf import QPdfDocument
from PySide6.QtWidgets import QWidget

from . import ink

BG_SLIDE = QColor("#0B0D10")
BG_DOC = QColor("#23262B")
MIN_SELECT = 10


def render_page(doc: QPdfDocument, page: int, w: int, h: int) -> QImage:
    """渲染一页，垫上白底：有些 PDF 的页面背景是透明的，直接贴到深色背景上字就看不见了。"""
    src = doc.render(page, QSize(max(1, w), max(1, h)))
    out = QImage(max(1, w), max(1, h), QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(Qt.GlobalColor.white)
    if not src.isNull():
        p = QPainter(out)
        p.drawImage(0, 0, src)
        p.end()
    return out


def text_in_rect(doc: QPdfDocument, page: int, rect: QRectF, limit: int = 8000) -> str:
    """取框内的文字：逐字看它的位置（比 PDF 的「从这到那」选择更准，分栏时不会串）。"""
    total = len(doc.getAllText(page).text())
    out = []
    last_bottom = None
    for i in range(min(total, limit)):
        sel = doc.getSelectionAtIndex(page, i, 1)
        r = sel.boundingRectangle()
        if r.isEmpty() or not rect.contains(r.center()):
            continue
        ch = sel.text()
        if last_bottom is not None and r.top() > last_bottom:
            out.append("\n")
        last_bottom = r.bottom()
        out.append(ch)
    return "".join(out).strip()


class PageView(QWidget):
    page_changed = Signal(int)
    selected = Signal(object)        # 页面坐标的 QRectF；空矩形表示取消
    ink_changed = Signal()
    activity = Signal()

    def __init__(self, doc: QPdfDocument, kind: str = "slides", strokes=None):
        super().__init__()
        self.doc, self.kind = doc, kind
        self.pages = doc.pageCount()
        self.page = 0
        self.zoom, self.ox, self.oy = 1.0, 0.0, 0.0
        self.tool = "pointer"
        self.color, self.width_px = "#E5484D", 3.0
        self.histories = {int(k): ink.History(v) for k, v in (strokes or {}).items()}
        self.active = None
        self.sel = None          # 框选（页面坐标）
        self.sel_drag = None
        self.pan_from = None
        self.press_pos = None
        self.erasing_tablet = False
        self.cache = {}
        self.cache_order = []
        self._layer = None
        self._layer_key = None
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TabletTracking, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.preload = QTimer(self)
        self.preload.setSingleShot(True)
        self.preload.timeout.connect(self._preload)
        self.settle = QTimer(self)          # 缩放停下来之后再按新尺寸渲染
        self.settle.setSingleShot(True)
        self.settle.timeout.connect(self.update)
        self._apply_cursor()

    # ---- 几何
    def page_size(self, page=None):
        s = self.doc.pagePointSize(self.page if page is None else page)
        return max(1.0, s.width()), max(1.0, s.height())

    def fit_scale(self, page=None):
        pw, ph = self.page_size(page)
        w, h = max(1, self.width()), max(1, self.height())
        if self.kind == "doc":
            return min((w - 48) / pw, 2.2) if w > 80 else w / pw
        return min(w / pw, h / ph)

    def scale(self):
        return self.fit_scale() * self.zoom

    def page_rect(self) -> QRectF:
        pw, ph = self.page_size()
        s = self.scale()
        rw, rh = pw * s, ph * s
        w, h = self.width(), self.height()
        x = (w - rw) / 2 if rw <= w else max(w - rw, min(0.0, self.ox))
        y = (h - rh) / 2 if rh <= h else max(h - rh, min(0.0, self.oy))
        return QRectF(x, y, rw, rh)

    def to_page(self, pos) -> QPointF:
        r = self.page_rect()
        s = self.scale()
        return QPointF((pos.x() - r.x()) / s, (pos.y() - r.y()) / s)

    def to_view(self, pt) -> QPointF:
        r = self.page_rect()
        s = self.scale()
        return QPointF(r.x() + pt.x() * s, r.y() + pt.y() * s)

    def view_rect(self, rect: QRectF) -> QRectF:
        a = self.to_view(rect.topLeft())
        s = self.scale()
        return QRectF(a.x(), a.y(), rect.width() * s, rect.height() * s)

    # ---- 翻页与缩放
    def history(self, page=None) -> ink.History:
        i = self.page if page is None else page
        if i not in self.histories:
            self.histories[i] = ink.History()
        return self.histories[i]

    def go(self, i: int, at_bottom: bool = False) -> None:
        i = max(0, min(self.pages - 1, i))
        if i == self.page:
            return
        self.page = i
        self.sel = None
        self.ox = 0.0
        self.oy = -1e9 if at_bottom else 0.0
        self.selected.emit(QRectF())
        self.page_changed.emit(i)
        self.update()

    def next(self):
        self.go(self.page + 1)

    def prev(self):
        self.go(self.page - 1)

    def set_zoom(self, z, anchor=None):
        z = max(1.0, min(6.0, z))
        anchor = anchor or QPointF(self.width() / 2, self.height() / 2)
        pt = self.to_page(anchor)
        self.zoom = z
        s = self.scale()
        self.ox, self.oy = anchor.x() - pt.x() * s, anchor.y() - pt.y() * s
        self.settle.start(140)
        self.update()

    def set_tool(self, tool):
        if self.active is not None:
            self._finish_stroke()
        self.tool = tool
        if tool != "select" and self.sel is not None:
            self.clear_selection()
        self._apply_cursor()
        self.update()

    def clear_selection(self):
        self.sel = None
        self.sel_drag = None
        self.selected.emit(QRectF())
        self.update()

    def _apply_cursor(self):
        c = {"pen": Qt.CursorShape.CrossCursor, "marker": Qt.CursorShape.CrossCursor, "select": Qt.CursorShape.CrossCursor, "eraser": Qt.CursorShape.PointingHandCursor}.get(self.tool, Qt.CursorShape.ArrowCursor)
        self.setCursor(QCursor(c))

    # ---- 渲染
    def _render(self, page, w, h) -> QPixmap:
        key = (page, w, h)
        pm = self.cache.get(key)
        if pm is None:
            pm = QPixmap.fromImage(render_page(self.doc, page, w, h))
            self.cache[key] = pm
            self.cache_order.append(key)
            while len(self.cache_order) > 8:
                self.cache.pop(self.cache_order.pop(0), None)
        return pm

    def _pixel_size(self, page, scale):
        pw, ph = self.page_size(page)
        d = self.devicePixelRatioF()
        return max(1, int(pw * scale * d)), max(1, int(ph * scale * d))

    def _preload(self):
        if not self.isVisible():
            return
        for i in (self.page + 1, self.page - 1):
            if 0 <= i < self.pages:
                s = self.fit_scale(i)
                w, h = self._pixel_size(i, s)
                self._render(i, w, h)

    def _ink_layer(self, r) -> QPixmap:
        d = self.devicePixelRatioF()
        h = self.history()
        key = (self.page, round(r.width()), round(r.height()), h.version, d)
        if self._layer is None or self._layer_key != key:
            pm = QPixmap(max(1, int(r.width() * d)), max(1, int(r.height() * d)))
            pm.setDevicePixelRatio(d)
            pm.fill(Qt.GlobalColor.transparent)
            if h.strokes:
                p = QPainter(pm)
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                s = self.scale()
                p.scale(s, s)
                for st in h.strokes:
                    ink.draw(p, st)
                p.end()
            self._layer, self._layer_key = pm, key
        return self._layer

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.fillRect(self.rect(), BG_DOC if self.kind == "doc" else BG_SLIDE)
        if self.pages <= 0:
            p.end()
            return
        r = self.page_rect()
        s = self.scale()
        w, h = self._pixel_size(self.page, s)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        pm = None
        if self.settle.isActive():      # 正在缩放：先拉伸已有的那张，停下来再重新渲染
            for k in reversed(self.cache_order):
                if k[0] == self.page:
                    pm = self.cache[k]
                    break
        pm = pm or self._render(self.page, w, h)
        p.drawPixmap(r, pm, QRectF(pm.rect()))
        if self.history().strokes:
            p.drawPixmap(r.topLeft(), self._ink_layer(r))
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self.active is not None:
            p.save()
            p.translate(r.topLeft())
            p.scale(s, s)
            ink.draw(p, self.active)
            p.restore()
        self._paint_selection(p)
        p.end()
        if not self.settle.isActive() and not self.preload.isActive():
            self.preload.start(160)

    def _paint_selection(self, p):
        rect = self.sel_drag or self.sel
        if rect is None or rect.isEmpty():
            return
        v = self.view_rect(rect)
        shade = QColor(0, 0, 0, 120)
        W, H = self.width(), self.height()
        p.fillRect(QRectF(0, 0, W, v.top()), shade)
        p.fillRect(QRectF(0, v.bottom(), W, H - v.bottom()), shade)
        p.fillRect(QRectF(0, v.top(), v.left(), v.height()), shade)
        p.fillRect(QRectF(v.right(), v.top(), W - v.right(), v.height()), shade)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor("#FFFFFF"), 1.5))
        p.drawRect(v)
        p.setPen(QPen(QColor("#4F8CFF"), 1.5, Qt.PenStyle.DashLine))
        p.drawRect(v)
        p.setBrush(QColor("#FFFFFF"))
        p.setPen(QPen(QColor("#4F8CFF"), 1.5))
        for c in (v.topLeft(), v.topRight(), v.bottomLeft(), v.bottomRight()):
            p.drawEllipse(c, 4, 4)

    # ---- 笔
    def _begin_stroke(self, pos, pr, pressure):
        tool = "marker" if self.tool == "marker" else "pen"
        s = self.scale()
        w = (self.width_px * (4.5 if tool == "marker" else 1.0)) / s
        col = "#FFD60A" if tool == "marker" and self.color == "#E5484D" else self.color
        self.active = ink.new_stroke(tool, col, w, pressure and tool == "pen")
        q = self.to_page(pos)
        ink.add_point(self.active, q.x(), q.y(), pr)
        self._dirty_tail()

    def _extend_stroke(self, pos, pr):
        q = self.to_page(pos)
        if ink.add_point(self.active, q.x(), q.y(), pr, 0.6 / self.scale()):
            self._dirty_tail()

    def _dirty_tail(self):
        """只重画笔尖附近；荧光笔半透明，要整笔重画。"""
        if self.active is None:
            return
        if self.active["tool"] == "marker":
            self.update(self.view_rect(ink.bounds(self.active)).toAlignedRect().adjusted(-3, -3, 3, 3))
            return
        pts = self.active["pts"][-4:]
        s = self.scale()
        m = (self.active["width"] * 1.6 * s) + 3
        vs = [self.to_view(QPointF(a[0], a[1])) for a in pts]
        xs, ys = [v.x() for v in vs], [v.y() for v in vs]
        self.update(QRectF(min(xs) - m, min(ys) - m, max(xs) - min(xs) + 2 * m, max(ys) - min(ys) + 2 * m).toAlignedRect())

    def _finish_stroke(self):
        if self.active is None:
            return
        st, self.active = self.active, None
        self.history().add(st)
        self.ink_changed.emit()
        self.update()

    def _erase_at(self, pos):
        q = self.to_page(pos)
        r = 10.0 / self.scale()
        h = self.history()
        gone = [s for s in h.strokes if ink.hit(s, q.x(), q.y(), r)]
        if gone:
            h.remove(gone)
            self.ink_changed.emit()
            self.update()

    def undo(self):
        if self.history().undo():
            self.ink_changed.emit()
            self.update()

    def redo(self):
        if self.history().redo():
            self.ink_changed.emit()
            self.update()

    def clear_page(self):
        self.history().clear()
        self.ink_changed.emit()
        self.update()

    def ink_data(self) -> dict:
        return {str(k): v.strokes for k, v in self.histories.items() if v.strokes}

    # ---- 输入
    def _press(self, pos, pr=1.0, pressure=False, eraser=False):
        self.activity.emit()
        self.press_pos = QPointF(pos)
        self.press_t = time.perf_counter()
        if eraser or self.tool == "eraser":
            self.erasing_tablet = True
            self._erase_at(pos)
        elif self.tool in ("pen", "marker"):
            self._begin_stroke(pos, pr, pressure)
        elif self.tool == "select":
            self.sel = None
            self.selected.emit(QRectF())
            self.sel_start = self._clamp_page(self.to_page(pos))
            self.sel_drag = QRectF(self.sel_start, self.sel_start)
            self.select_begin()
            self.update()
        else:
            self.pan_from = (QPointF(pos), self.page_rect().x(), self.page_rect().y())

    def select_begin(self):
        """开始框选：提前连上搜索站。"""
        from .lookup import warm
        warm()

    def _clamp_page(self, q):
        pw, ph = self.page_size()
        return QPointF(max(0.0, min(pw, q.x())), max(0.0, min(ph, q.y())))

    def _move(self, pos, pr=1.0):
        if self.erasing_tablet:
            self._erase_at(pos)
        elif self.active is not None:
            self._extend_stroke(pos, pr)
        elif self.sel_drag is not None:
            self.sel_drag = QRectF(self.sel_start, self._clamp_page(self.to_page(pos))).normalized()
            self.update()
        elif self.pan_from is not None:
            a, x0, y0 = self.pan_from
            self.ox = x0 + pos.x() - a.x()
            self.oy = y0 + pos.y() - a.y()
            self.update()

    def _release(self, pos):
        if self.erasing_tablet:
            self.erasing_tablet = False
        elif self.active is not None:
            self._finish_stroke()
        elif self.sel_drag is not None:
            rect, self.sel_drag = self.sel_drag, None
            v = self.view_rect(rect)
            if v.width() >= MIN_SELECT and v.height() >= MIN_SELECT:
                self.sel = rect
                self.selected.emit(rect)
            self.update()
        elif self.pan_from is not None:
            a = self.pan_from[0]
            self.pan_from = None
            moved = math.hypot(pos.x() - a.x(), pos.y() - a.y())
            if moved < 5 and self.kind == "slides" and self.tool == "pointer" and self.zoom == 1.0:
                self.next()   # 单击下一页，和 PPT 放映一样

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.RightButton:
            if self.tool == "pointer":
                self.prev()
            return
        if e.button() == Qt.MouseButton.LeftButton:
            self._press(e.position())

    def mouseMoveEvent(self, e):  # noqa: N802
        self.activity.emit()
        if e.buttons() & Qt.MouseButton.LeftButton:
            self._move(e.position())

    def mouseReleaseEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._release(e.position())

    def tabletEvent(self, e):  # noqa: N802
        """手写笔：有压感；笔尾橡皮直接擦。"""
        t = e.type()
        pos = e.position()
        eraser = e.pointerType() == QPointingDevice.PointerType.Eraser
        if t == e.Type.TabletPress:
            self._press(pos, e.pressure(), True, eraser)
        elif t == e.Type.TabletMove:
            self._move(pos, e.pressure())
        elif t == e.Type.TabletRelease:
            self._release(pos)
        e.accept()

    def wheelEvent(self, e):  # noqa: N802
        self.activity.emit()
        dy = e.angleDelta().y()
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.set_zoom(self.zoom * (1.12 if dy > 0 else 1 / 1.12), e.position())
            return
        r = self.page_rect()
        if r.height() <= self.height() + 1:
            self._wheel_flip(dy)
            return
        old = r.y()
        self.ox, self.oy = r.x(), r.y() + dy * 0.9
        if abs(self.page_rect().y() - old) < 0.5:   # 已经滚到头：翻到邻页
            self._wheel_flip(dy, keep_edge=True)
        self.update()

    def _wheel_flip(self, dy, keep_edge=False):
        now = time.perf_counter()
        if now - getattr(self, "_flip_t", 0) < 0.18:   # 触摸板一下会发很多事件
            return
        self._flip_t = now
        if dy < 0:
            self.next()
        elif dy > 0:
            self.go(self.page - 1, at_bottom=keep_edge)

    # ---- 截取
    def capture(self, rect: QRectF, long_side: int = 2000):
        """返回框内的 QImage（含笔迹）；清晰度和屏幕无关，放到黑板上放大也清楚。"""
        rect = QRectF(rect)
        k = min(long_side / max(1.0, max(rect.width(), rect.height())), 6000 / max(self.page_size()))
        k = max(k, 1.0)
        pw, ph = self.page_size()
        full = render_page(self.doc, self.page, int(pw * k), int(ph * k))
        strokes = self.history().strokes
        if strokes:
            p = QPainter(full)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.scale(k, k)
            for s in strokes:
                if ink.bounds(s).intersects(rect):
                    ink.draw(p, s)
            p.end()
        return full.copy(int(rect.x() * k), int(rect.y() * k), max(1, int(rect.width() * k)), max(1, int(rect.height() * k)))

    def selection_text(self, rect: QRectF) -> str:
        return text_in_rect(self.doc, self.page, rect)

    def resizeEvent(self, e):  # noqa: N802
        self._layer = None
        super().resizeEvent(e)
