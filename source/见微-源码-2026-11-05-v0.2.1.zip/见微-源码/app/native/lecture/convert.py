"""把 Word / PPT 转成 PDF：优先用本机的 Office 或 WPS（版式最准），都没有时用内置排版。

统一转成 PDF 的好处：翻页快、缩放清晰，还保留文字层——框选后可以直接取到文字，不必识别图片。
转换在隔离的 PowerShell 进程里跑，超时只放弃不硬杀 Office；打开文件时禁用宏。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from ..kit.home import home

SLIDES = {".pptx", ".ppt", ".pptm", ".ppsx", ".pps", ".dps"}
DOCS = {".docx", ".doc", ".docm", ".rtf", ".wps"}
SUPPORTED = SLIDES | DOCS | {".pdf"}
FILTER = "课件 (*.pptx *.ppt *.pptm *.ppsx *.pps *.dps *.docx *.doc *.docm *.rtf *.wps *.pdf);;所有文件 (*)"
TIMEOUT = 120
NO_WINDOW = 0x08000000

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$src = $env:JW_SRC; $pdf = $env:JW_PDF; $engine = $env:JW_ENGINE
$proc = @{ 'PowerPoint.Application'='POWERPNT'; 'KWPP.Application'='wpp'; 'Word.Application'='WINWORD'; 'KWPS.Application'='wps' }[$engine]
$running = @(Get-Process $proc -ErrorAction SilentlyContinue).Count -gt 0
$app = $null; $doc = $null; $code = 1
try {
  $app = New-Object -ComObject $engine
  try { $app.DisplayAlerts = 0 } catch {}
  try { $app.AutomationSecurity = 3 } catch {}
  if ($engine -in 'PowerPoint.Application', 'KWPP.Application') {
    $doc = $app.Presentations.Open($src, -1, 0, 0)
    $doc.SaveAs($pdf, 32)
  } else {
    try { $app.Visible = $false } catch {}
    $doc = $app.Documents.Open($src, $false, $true, $false, '')
    $doc.ExportAsFixedFormat($pdf, 17)
  }
  $code = 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
} finally {
  try { if ($doc) { if ($engine -in 'Word.Application', 'KWPS.Application') { $doc.Close(0) } else { $doc.Close() } } } catch {}
  try {
    $open = if ($engine -in 'PowerPoint.Application', 'KWPP.Application') { $app.Presentations.Count } else { $app.Documents.Count }
    # 只收拾自己启动的实例：用户本来就开着、或还有别的文档时不退出
    if ($app -and -not $running -and $open -eq 0) { $app.Quit() }
  } catch {}
  try { if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) } } catch {}
  [GC]::Collect()
}
exit $code
"""


class ConvertError(Exception):
    pass


def kind_of(path) -> str:
    ext = Path(path).suffix.lower()
    return "slides" if ext in SLIDES else "doc" if ext in DOCS else "pdf"


def has_com(progid: str) -> bool:
    if sys.platform != "win32":
        return False
    import winreg
    try:
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid + "\\CLSID"))
        return True
    except OSError:
        return False


def _prefs_file() -> Path:
    return home() / "lecture-engines.json"


def engines_for(ext: str) -> list:
    """先试上次成功的那个：某个 Office 打不开文件时，不用每次都等它失败。"""
    # Word 排在 WPS 后面：装了但没激活的 Word 打开文件会失败，还会留下一个退不掉的后台进程
    names = ["PowerPoint.Application", "KWPP.Application"] if ext in SLIDES else ["KWPS.Application", "Word.Application"]
    names = [n for n in names if has_com(n)]
    try:
        last = json.loads(_prefs_file().read_text(encoding="utf-8")).get("slides" if ext in SLIDES else "doc")
    except (OSError, ValueError):
        last = None
    if last in names:
        names.remove(last)
        names.insert(0, last)
    return names


def _remember(ext: str, engine: str) -> None:
    key = "slides" if ext in SLIDES else "doc"
    try:
        data = json.loads(_prefs_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    data[key] = engine
    try:
        _prefs_file().write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


def _com(src: Path, pdf: Path, engine: str, timeout: int) -> str:
    """跑一次转换；成功返回空串，失败返回原因。"""
    tmp = Path(tempfile.mkdtemp(prefix="jw-conv-"))
    try:
        script = tmp / "convert.ps1"
        script.write_bytes(b"\xef\xbb\xbf" + SCRIPT.encode("utf-8"))
        env = dict(os.environ, JW_SRC=str(src), JW_PDF=str(pdf), JW_ENGINE=engine)
        env.pop("QT_QPA_PLATFORM", None)
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script)],
                               env=env, capture_output=True, timeout=timeout, creationflags=NO_WINDOW if sys.platform == "win32" else 0)
        except subprocess.TimeoutExpired:
            return f"超过 {timeout} 秒没有完成（文件可能设了密码，或者 Office 弹出了对话框）"
        except OSError as e:
            return str(e)
        if pdf.is_file() and pdf.stat().st_size > 200:
            return ""
        return r.stderr.decode("utf-8", "replace").strip()[:200] or f"退出码 {r.returncode}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


LABEL = {"PowerPoint.Application": "PowerPoint", "KWPP.Application": "WPS 演示", "Word.Application": "Word", "KWPS.Application": "WPS 文字"}


def to_pdf(src, pdf, status=None, timeout: int = TIMEOUT, use_com: bool = True) -> str:
    """src → pdf，返回所用引擎的名字；失败抛 ConvertError。"""
    src, pdf = Path(src), Path(pdf)
    ext = src.suffix.lower()
    if ext not in SUPPORTED:
        raise ConvertError(f"不支持 {ext or '这种'} 文件。可以导入 PPT、Word 和 PDF。")
    say = status or (lambda _s: None)
    if ext == ".pdf":
        shutil.copyfile(src, pdf)
        return "PDF"
    errors = []
    for engine in (engines_for(ext) if use_com else []):
        say(f"正在用 {LABEL[engine]} 转换…")
        t = time.perf_counter()
        pdf.unlink(missing_ok=True)
        why = _com(src, pdf, engine, timeout)
        if not why:
            _remember(ext, engine)
            say(f"{LABEL[engine]} 转换完成（{time.perf_counter() - t:.1f} 秒）")
            return LABEL[engine]
        errors.append(f"{LABEL[engine]}：{why}")
    if ext in (".pptx", ".pptm", ".ppsx", ".docx", ".docm"):
        say("正在用内置排版转换…")
        from . import builtin
        try:
            (builtin.pptx_to_pdf if ext in SLIDES else builtin.docx_to_pdf)(src, pdf)
            return "内置排版"
        except Exception as e:  # noqa: BLE001  坏文件什么异常都可能有，要给人读得懂的原因
            errors.append(f"内置排版：{e}")
    detail = "；".join(errors)
    if not errors or ext in (".ppt", ".pps", ".doc", ".rtf", ".wps", ".dps"):
        raise ConvertError(f"打开 {ext} 文件需要本机装有 Office 或 WPS。" + (f"（{detail}）" if detail else ""))
    raise ConvertError(f"这个文件转换失败，可能已损坏或设了密码。（{detail}）")
