"""自由工作台：注册表、素材栏（点击 / 拖到画布）、提示气泡。对应旧版 gewu/bench.js。

每个工作台用 @bench.reg(id=, subj=, short=, title=, sub=, desc=, art=) 注册 init(B)。
B 提供：
  B.L              实验上下文（Ctx），画布和右侧检查器都在它上面
  B.palette(secs)  左侧浮窗的素材：[{title, tab, items: [{id, icon, label, sub, title, click, drop(x, y)}]}]
                   tab 是 reagent（试剂）/ item（物品）/ exp（实验）；labels={"item": "元件"} 可改页名
  B.safe()         画布上没被浮窗和顶条盖住的范围：(左, 上, 右, 下) 四个内边距，放器材、画读数都要避开
  B.on_safe(fn)    浮窗开合时回调 fn(旧内边距, 新内边距)
  B.active(id)     高亮当前工具
  B.toast(html)    画布右上角的提示气泡
  B.clear_panel()  清空检查器（重新 inspect 前调用）
  B.tips(secs)     「原理」页里的使用说明：[(标题, [条目 html…])]
  B.log            实验记录（工作台自己往里 add 行，显示在「原理」页顶部）
icon 可以是 SVG 字符串（currentColor 会换成前景色），也可以是 fn(p: QPainter, rect: QRectF)。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from PySide6.QtCore import QByteArray, QMimeData, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QDrag, QFontMetrics, QPainter, QPixmap
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QScrollArea, QStackedWidget,
                               QVBoxLayout, QWidget)

from ..design.tokens import RADIUS, T, font, qc
from ..design.widgets import draw_key
from .home import load_json, save_json

MIME = "application/x-jw-palette"


# ---------------------------------------------------------------- 注册表
@dataclass
class BenchKit:
    id: str
    subj: str
    short: str
    title: str
    sub: str = ""
    desc: str = ""
    art: str = ""
    init: Callable | None = None
    extra: dict = field(default_factory=dict)


class _Benches:
    def __init__(self):
        self.list: list[BenchKit] = []
        self.by_id: dict[str, BenchKit] = {}
        self._loaded = False

    def reg(self, **meta):
        def deco(fn):
            k = BenchKit(init=fn, **meta)
            if k.id not in self.by_id:
                self.list.append(k)
            self.by_id[k.id] = k
            return fn
        return deco

    def load(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        from ..lab import all_modules  # noqa: F401  显式导入，打包后也找得到
        _ = all_modules


bench = _Benches()


# ---------------------------------------------------------------- SVG 图标
_svg_cache: dict = {}


def paint_svg(p: QPainter, svg: str, rect: QRectF) -> None:
    from PySide6.QtSvg import QSvgRenderer
    src = (svg.replace("currentColor", T.fg).replace("var(--surface,#fff)", T.surface)
           .replace("var(--surface)", T.surface))
    r = _svg_cache.get(src)
    if r is None:
        if not src.lstrip().startswith("<svg") or "xmlns" in src:
            data = src
        else:
            data = src.replace("<svg", "<svg xmlns='http://www.w3.org/2000/svg'", 1)
        r = QSvgRenderer(QByteArray(data.encode("utf-8")))
        if len(_svg_cache) > 400:
            _svg_cache.clear()
        _svg_cache[src] = r
    if r.isValid():
        vb = r.viewBoxF()
        if vb.width() > 0 and vb.height() > 0:   # 等比放进 rect
            k = min(rect.width() / vb.width(), rect.height() / vb.height())
            w, h = vb.width() * k, vb.height() * k
            rect = QRectF(rect.center().x() - w / 2, rect.center().y() - h / 2, w, h)
        r.render(p, rect)


def paint_icon(p: QPainter, icon, rect: QRectF) -> None:
    if not icon:
        return
    if callable(icon):
        icon(p, rect)
    elif isinstance(icon, str) and "<svg" in icon:
        paint_svg(p, icon, rect)
    else:   # 单个字符 / emoji
        p.setFont(font(rect.height() * 0.7))
        p.setPen(qc(T.fg))
        p.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), str(icon))


# ---------------------------------------------------------------- 素材栏
TABS = {"reagent": ("试剂", "reagent"), "item": ("物品", "box"), "exp": ("实验", "lab")}


class PalItem(QWidget):
    """一颗素材键。点击执行 click；按住拖到画布执行 drop(x, y)。
    tile=True 是两列的方块（图标在上），否则是占满一行的条目（实验列表用）。"""

    def __init__(self, it: dict, pal: "Palette", tile: bool = True):
        super().__init__()
        self.it, self.pal, self.tile = it, pal, tile
        self.on = False
        self.hover = False
        self._press = None
        self._pm = None
        self._pm_key = None
        self.setFixedHeight(78 if tile else 54)
        self.setMinimumWidth(60)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if it.get("title"):
            self.setToolTip(it["title"])
        elif it.get("sub"):
            self.setToolTip(f"{it['label']}：{it['sub']}")

    def matches(self, q: str) -> bool:
        return not q or q in (self.it.get("label", "") + " " + (self.it.get("sub") or "")).lower()

    def enterEvent(self, _e):  # noqa: N802
        self.hover = True
        self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = False
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = e.position()
            self.update()

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._press is None or not self.it.get("drop"):
            return
        d = e.position() - self._press
        if abs(d.x()) + abs(d.y()) < 8:
            return
        self._press = None
        self.update()
        Palette.dragging = self.it
        drag = QDrag(self)
        md = QMimeData()
        md.setData(MIME, QByteArray(b"1"))
        drag.setMimeData(md)
        pm = self.grab()
        drag.setPixmap(pm)
        drag.setHotSpot(e.position().toPoint())
        self.pal.drag_state.emit(True)   # 浮窗让开，整块画布都能放
        drag.exec(Qt.DropAction.CopyAction)
        self.pal.drag_state.emit(False)
        Palette.dragging = None

    def mouseReleaseEvent(self, e):  # noqa: N802
        if self._press is not None and e.button() == Qt.MouseButton.LeftButton:
            self._press = None
            self.update()
            fn = self.it.get("click")
            if fn:
                self.pal.remember(self.it)
                fn()

    def contextMenuEvent(self,event):
        menu=QMenu(self)
        menu.addAction("取消收藏" if self.pal.is_favorite(self.it) else "收藏",lambda:self.pal.toggle_favorite(self.it))
        menu.exec(event.globalPos())

    def _icon(self, size: int) -> QPixmap:
        """图标画一次存起来：SVG 逐帧渲染太贵。"""
        dpr = self.devicePixelRatioF()
        key = (T.dark, T.fg, size, dpr)
        if self._pm_key != key:
            pm = QPixmap(int(size * dpr), int(size * dpr))
            pm.setDevicePixelRatio(dpr)
            pm.fill(Qt.GlobalColor.transparent)
            q = QPainter(pm)
            q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            paint_icon(q, self.it.get("icon"), QRectF(0, 0, size, size))
            q.end()
            self._pm, self._pm_key = pm, key
        return self._pm

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        down = self._press is not None
        box = QRectF(0, 0, w, h)
        if self.on:   # 选中：白键 + 学科色边 + 淡染，字仍然读得清
            draw_key(p, box, T.raised, RADIUS["sm"], edge=qc(T.accent), sunk=down)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.accent, 0.14))
            p.drawRoundedRect(box.adjusted(1, 1, -1, -2), RADIUS["sm"], RADIUS["sm"])
        else:
            draw_key(p, box, T.hover if self.hover else T.raised, RADIUS["sm"], sunk=down)
        dy = 1 if down else 0
        sub = self.it.get("sub") or ""
        left = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        if self.tile:
            p.drawPixmap(9, 7 + dy, self._icon(28))
            tw = w - 16
            ny, sy = 37, 56
        else:
            p.drawPixmap(10, (h - 28) // 2 + dy, self._icon(28))
            tw = w - 56
            ny, sy = (8, 28) if sub else (17, 28)
        x = 8 if self.tile else 46
        p.setFont(font(13, 700))   # 小字号的半粗在 Windows 上会糊，用整数字号的真粗体
        p.setPen(qc(T.accent if self.on else T.fg))
        fm = QFontMetrics(p.font())
        p.drawText(QRectF(x, ny + dy, tw, 19), int(left), fm.elidedText(self.it.get("label", ""), Qt.TextElideMode.ElideRight, int(tw)))
        if sub:
            p.setFont(font(11))
            p.setPen(qc(T.muted))
            fm = QFontMetrics(p.font())
            p.drawText(QRectF(x, sy + dy, tw, 16), int(left), fm.elidedText(sub, Qt.TextElideMode.ElideRight, int(tw)))
        p.end()


class PalPage(QScrollArea):
    """素材栏的一页：若干分组，每组一个方格；搜索时重排，不留空洞。"""

    def __init__(self, cols: int):
        super().__init__()
        self.cols = cols
        self.groups: list[tuple] = []
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.body = QWidget()
        self.lay = QVBoxLayout(self.body)
        self.lay.setContentsMargins(10, 2, 10, 12)
        self.lay.setSpacing(6)
        self.setWidget(self.body)

    def add_group(self, title: str, tiles: list[PalItem], collapsed=False) -> None:
        h = QPushButton(title+" ▾")
        h.setCheckable(True)
        h.setChecked(not collapsed)
        h.setObjectName("grpTitle")
        h.setContentsMargins(2, 8, 0, 0)
        box = QWidget()
        grid = QGridLayout(box)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(6)
        for c in range(self.cols):
            grid.setColumnStretch(c, 1)
        self.lay.addWidget(h)
        self.lay.addWidget(box)
        h.toggled.connect(lambda opened:box.setVisible(opened))
        self.groups.append((h, box, grid, tiles))

    def finish(self) -> None:
        self.lay.addStretch(1)
        self.apply_filter("")

    def apply_filter(self, q: str) -> int:
        total = 0
        for h, box, grid, tiles in self.groups:
            for t in tiles:
                grid.removeWidget(t)
            shown = [t for t in tiles if t.matches(q) and t.pal.allowed(t.it)]
            if shown and shown[0].pal.filter_mode=="recent":
                shown.sort(key=lambda t:t.pal.recent().index(t.pal.item_key(t.it)))
            for t in tiles:
                t.setVisible(t in shown)
            for i, t in enumerate(shown):
                grid.addWidget(t, i // self.cols, i % self.cols)
            h.setVisible(bool(shown))
            box.setVisible(bool(shown) and (h.isChecked() or bool(q)))
            total += len(shown)
        return total


class Palette(QWidget):
    """素材栏：分「试剂 / 物品 / 实验」三页，顶上一个搜索框。页由 section 的 tab 字段决定。"""
    dragging: dict | None = None   # 正在拖的素材（拖放只在本进程内）
    drag_state = Signal(bool)
    tabs_changed = Signal()
    tab_picked = Signal(str)

    def __init__(self):
        super().__init__()
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(4)
        self.search = QLineEdit()
        self.search.setObjectName("palSearch")
        self.search.setPlaceholderText("搜索名称或化学式")
        self.search.setClearButtonEnabled(True)
        self.search.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.search.textChanged.connect(self.apply_filter)
        wrap = QHBoxLayout()
        wrap.setContentsMargins(10, 0, 10, 2)
        wrap.addWidget(self.search)
        v.addLayout(wrap)
        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)
        self.empty = QLabel("没有符合的素材")
        self.empty.setObjectName("note")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.stack.addWidget(self.empty)
        self.pages: dict[str, PalPage] = {}
        self.labels: dict[str, str] = {}
        self.items: dict[str, PalItem] = {}
        self.all: list[PalItem] = []
        self.cur = ""
        self.bench_id = ""
        self.filter_mode = "all"
        filters=QHBoxLayout()
        for title,mode in (("全部","all"),("收藏","favorite"),("最近","recent")):
            button=QPushButton(title)
            button.clicked.connect(lambda _=False,m=mode:self.set_filter_mode(m))
            filters.addWidget(button)
        v.insertLayout(1,filters)

    @staticmethod
    def item_key(item):
        return str(item.get("id") or item.get("label") or "")[:100]

    def prefs(self):
        if hasattr(self,"_preferences"):
            return self._preferences
        value=load_json("workbench-ui.json",{})
        self._preferences=value if isinstance(value,dict) else {}
        return self._preferences

    def recent(self):
        return self.prefs().get("materials",{}).get(self.bench_id,{}).get("recent",[])

    def is_favorite(self,item):
        return self.item_key(item) in self.prefs().get("materials",{}).get(self.bench_id,{}).get("favorites",[])

    def remember(self,item,favorite=False):
        value=load_json("workbench-ui.json",{})
        value=value if isinstance(value,dict) else {}
        data=value.setdefault("materials",{}).setdefault(self.bench_id,{})
        key=self.item_key(item)
        if favorite:
            saved=data.setdefault("favorites",[])
            if key in saved:
                saved.remove(key)
            else:
                saved.append(key)
        else:
            data["recent"]=[key]+[k for k in data.get("recent",[]) if k!=key][:19]
        try:
            save_json("workbench-ui.json",value)
        except OSError:
            self.search.setToolTip("界面偏好暂时不能保存；本次仍可继续使用素材")
        self._preferences=value

    def toggle_favorite(self,item):
        self.remember(item,True)
        self.apply_filter(self.search.text())

    def allowed(self,item):
        return self.filter_mode=="all" or (self.is_favorite(item) if self.filter_mode=="favorite" else self.item_key(item) in self.recent())

    def set_filter_mode(self,mode):
        self.filter_mode=mode
        self.apply_filter(self.search.text())

    def set_sections(self, secs, labels=None) -> None:
        for page in self.pages.values():
            self.stack.removeWidget(page)
            page.deleteLater()
        self.pages, self.items, self.all = {}, {}, []
        self.labels = {k: (labels or {}).get(k, TABS[k][0]) for k in TABS}
        for s in secs:
            tab = s.get("tab", "item")
            page = self.pages.get(tab)
            if page is None:
                page = self.pages[tab] = PalPage(1 if tab == "exp" else 2)
                self.stack.addWidget(page)
            tiles = []
            for it in s["items"]:
                b = PalItem(it, self, tile=tab != "exp")
                tiles.append(b)
                self.all.append(b)
                if it.get("id"):
                    self.items[it["id"]] = b
            page.add_group(s["title"], tiles,bool(s.get("collapsed")))
        for page in self.pages.values():
            page.finish()
        self.search.setPlaceholderText("搜索名称或化学式" if "reagent" in self.pages else "搜索名称或说明")
        self.tabs_changed.emit()

    def tabs(self) -> list[str]:
        return [k for k in TABS if k in self.pages]

    def first_tab(self) -> str:
        return next(iter(self.tabs()), "")

    def show_tab(self, tab: str) -> None:
        if tab in self.pages:
            self.cur = tab
            self.stack.setCurrentWidget(self.pages[tab])
            if self.search.text():
                self.apply_filter(self.search.text())

    def apply_filter(self, text: str) -> None:
        """搜索覆盖全部三页：当前页没有结果、别的页有，就自动跳过去。"""
        q = text.strip().lower()
        counts = {k: page.apply_filter(q) for k, page in self.pages.items()}
        if q and not counts.get(self.cur):
            hit = next((k for k in self.tabs() if counts[k]), None)
            if hit:
                self.cur = hit
                self.tab_picked.emit(hit)
        page = self.pages.get(self.cur)
        self.stack.setCurrentWidget(page if page is not None and (not q or counts.get(self.cur)) else self.empty)

    def active(self, iid) -> None:
        for k, b in self.items.items():
            if b.on != (k == iid):
                b.on = k == iid
                b.update()
        hit = self.items.get(iid)
        if hit is not None:   # 快捷键换了工具时，让选中的键露出来
            for tab, page in self.pages.items():
                if hit.parent() is not None and page.body.isAncestorOf(hit) and tab == self.cur:
                    page.ensureWidgetVisible(hit, 0, 12)


# ---------------------------------------------------------------- 提示气泡
class Toasts:
    def __init__(self, stage: QWidget):
        self.stage = stage
        self.labels: list[QLabel] = []

    def show(self, html: str, cls: str | None = None, ms: int = 2600) -> None:
        lb = QLabel(html, self.stage)
        lb.setTextFormat(Qt.TextFormat.RichText)
        lb.setWordWrap(True)
        lb.setMaximumWidth(360)
        col = T.bad if cls == "bad" else T.ok if cls == "ok" else T.accent
        lb.setStyleSheet(f"QLabel{{background:{T.raised};color:{T.fg};border:1px solid {T.line};border-left:3px solid {col};"
                         f"border-radius:8px;padding:7px 11px;font-size:12.5px;}}")
        lb.adjustSize()
        lb.show()
        lb.raise_()
        self.labels.insert(0, lb)
        while len(self.labels) > 3:
            self._drop(self.labels[-1])
        self._place()
        QTimer.singleShot(ms, lb, lambda: self._drop(lb))

    def _drop(self, lb: QLabel) -> None:
        if lb in self.labels:
            self.labels.remove(lb)
            lb.hide()
            lb.deleteLater()
            self._place()

    def _place(self) -> None:
        left, top, right, _bottom = self.stage.safe
        y = top + 6
        for lb in self.labels:
            lb.move(max(left + 8, self.stage.width() - right - lb.width() - 12), y)
            y += lb.height() + 6


# ---------------------------------------------------------------- 工作台 API
class Log:
    """实验记录：工作台 add 一行，显示在「原理」页。"""

    def __init__(self, on_change):
        self.rows: list[str] = []
        self.on_change = on_change

    def add(self, html: str) -> None:
        self.rows.insert(0, html)   # 新的在上
        if len(self.rows) > 80:
            self.rows.pop()
        self.on_change()

    def clear(self) -> None:
        self.rows.clear()
        self.on_change()


class BenchAPI:
    def __init__(self, L, palette: Palette, on_tips):
        self.L = L
        self.stage = L.stage
        self.pal = palette
        self._toasts = Toasts(L.stage)
        self.tip_secs: list = []
        self._on_tips = on_tips
        self.log = Log(on_tips)
        self.drop_ok = True
        L.stage.setAcceptDrops(True)
        L.stage.drop_fn = self._drop
        self.transfer_snapshot = None
        self.transfer_restore = None
        self.transfer_model = None
        self._safe_fn = None

    def safe(self) -> tuple:
        return self.L.stage.safe

    def on_safe(self, fn) -> None:
        self._safe_fn = fn

    def safe_changed(self, old: tuple, new: tuple) -> None:
        self._toasts._place()
        if self._safe_fn:
            self._safe_fn(old, new)
        self.L.draw()

    def transfer(self,snapshot,restore,model=None):
        self.transfer_snapshot,self.transfer_restore,self.transfer_model = snapshot,restore,model

    @property
    def items(self):
        return self.pal.items

    def _drop(self, x, y) -> None:
        it = Palette.dragging
        if it and it.get("drop"):
            it["drop"](x, y)
            self.pal.remember(it)
            self.L.draw()

    def palette(self, secs, labels=None) -> None:
        self.pal.set_sections(secs, labels)

    def active(self, iid) -> None:
        self.pal.active(iid)

    def toast(self, html: str, cls: str | None = None, ms: int = 2600) -> None:
        self._toasts.show(html, cls, ms)

    def clear_panel(self) -> None:
        L = self.L
        lay = L.panel_lay
        while lay.count():
            item = lay.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        L.box, L._row, L._gt = None, None, ""
        L.ctrls = []
        QTimer.singleShot(0, L.stage, self.show_panel)

    def show_panel(self) -> None:
        """检查器重建后把新控件都显示出来。面板正显示时只靠布局的延迟显示，
        几何画板（重建由定时器触发）会留下一片空白。工作台自己隐藏的控件不动。"""
        if self.L.draw_fn is None:
            return
        host = self.L.panel_lay.parentWidget()
        if host is None:
            return
        for w in host.findChildren(QWidget):
            if w.isHidden() and not w.testAttribute(Qt.WidgetAttribute.WA_WState_ExplicitShowHide):
                w.show()

    def tips(self, secs) -> None:
        self.tip_secs = list(secs)
        self._on_tips()
