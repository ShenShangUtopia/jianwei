"""Composite cards and bars for the reading surface."""
from __future__ import annotations

import html
import re

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, QSize, Qt, QVariantAnimation, Signal
from PySide6.QtGui import (
    QColor, QFontMetrics, QLinearGradient, QPainter, QPen, QTextOption,
)
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout, QWidget,
)

from .base import IconButton, TagLabel, TextBlock, TextButton
from .icons import draw_icon
from .theme import C, font, mono, serif


def _label(text: str, size: int = 10, weight: int = 400, color: QColor | None = None, spacing: float = 0.0) -> QLabel:
    lab = QLabel(text)
    lab.setFont(font(size, weight, spacing=spacing))
    lab.setStyleSheet(f"color: {color.name() if color else C.MUTED.name()}; background: transparent;")
    lab.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
    return lab


class TopBar(QWidget):
    refresh_clicked = Signal()
    play_toggled = Signal(bool)
    pin_toggled = Signal(bool)
    collapse_clicked = Signal()
    settings_clicked = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(58)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 8, 10, 0)
        layout.setSpacing(5)

        from .base import BrandMark
        self.mark = BrandMark()
        layout.addWidget(self.mark, 0, Qt.AlignmentFlag.AlignVCenter)

        brand = QVBoxLayout()
        brand.setSpacing(0)
        brand.setContentsMargins(0, 1, 0, 0)
        name = _label("观澜", 14, 600, C.TEXT, 2.0)
        en = _label("DAILY BRIEF", 7, 500, C.GOLD, 1.5)
        brand.addWidget(name)
        brand.addWidget(en)
        layout.addLayout(brand)
        layout.addStretch(1)

        self.date_label = _label("", 9, 400, C.MUTED, 0.3)
        self.date_label.setFont(mono(9, 400, spacing=0.2))
        layout.addWidget(self.date_label)

        self.play_btn = IconButton("play", "自动播放 · 每 12 秒一屏", 28, C.MUTED)
        self.play_btn.setCheckable(True)
        self.refresh_btn = IconButton("refresh", "重新筛选今日内容", 28, C.MUTED)
        self.pin_btn = IconButton("pin", "固定展开，不自动收起", 28, C.MUTED)
        self.pin_btn.setCheckable(True)
        self.collapse_btn = IconButton("collapse", "收起到侧边", 28, C.MUTED)
        self.settings_btn = IconButton("sliders", "设置与筛选说明", 28, C.MUTED)
        for btn in (self.play_btn, self.refresh_btn, self.pin_btn, self.collapse_btn, self.settings_btn):
            layout.addWidget(btn)

        self.refresh_btn.clicked.connect(self.refresh_clicked)
        self.play_btn.toggled.connect(self._on_play_toggled)
        self.pin_btn.toggled.connect(self.pin_toggled)
        self.collapse_btn.clicked.connect(self.collapse_clicked)
        self.settings_btn.clicked.connect(self.settings_clicked)

    def set_date(self, date_label: str, weekday: str) -> None:
        short_date = date_label[5:] if len(date_label) >= 10 else date_label
        self.date_label.setText(f"{short_date}  {weekday}")

    def _on_play_toggled(self, playing: bool) -> None:
        self.play_btn.set_icon("pause" if playing else "play")
        self.play_btn.setToolTip("暂停自动播放" if playing else "自动播放 · 每 12 秒一屏")
        self.play_toggled.emit(playing)

    def set_playing(self, playing: bool) -> None:
        self.play_btn.blockSignals(True)
        self.play_btn.setChecked(playing)
        self.play_btn.blockSignals(False)
        self.play_btn.set_icon("pause" if playing else "play")
        self.play_btn.setToolTip("暂停自动播放" if playing else "自动播放 · 每 12 秒一屏")

    def set_busy(self, busy: bool) -> None:
        self.refresh_btn.set_busy(busy)
        self.refresh_btn.setToolTip("正在抓取并筛选…" if busy else "重新筛选今日内容")


class Footer(QWidget):
    clicked = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(34)
        self._left = "今日 7 条 · 4 家信源"
        self._right = "更新 20:26"
        self._ok = True
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_status(self, left: str, right: str, ok: bool = True) -> None:
        self._left = left
        self._right = right
        self._ok = ok
        self.update()

    def mousePressEvent(self, event) -> None:
        self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(C.HAIRLINE)
        p.drawLine(QPointF(18, 0.5), QPointF(self.width() - 18, 0.5))
        p.setFont(font(9, 400, spacing=0.2))
        p.setPen(C.DIM if self._ok else C.CORAL)
        p.drawText(QPointF(18, 21), self._left)
        p.setFont(mono(9, 400, spacing=0.2))
        p.setPen(C.DIM)
        p.drawText(QRectF(self.width() - 190, 5, 172, 22), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, self._right)
        p.setBrush(QColor("#7FA99C") if self._ok else C.CORAL)
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(12, 17), 2.0, 2.0)


class HeroCard(QWidget):
    clicked = Signal()

    def __init__(self, story: dict | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.story = story or {}
        self._parallax = 0.0
        self._parallax_anim = QVariantAnimation(self)
        self._parallax_anim.setDuration(360)
        self._parallax_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._parallax_anim.valueChanged.connect(self._set_parallax)
        self.setFixedHeight(268)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 17, 20, 15)
        layout.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(8)
        self.overline = _label("TODAY'S FOCUS  /  今日焦点", 7.5, 600, C.GOLD, 1.4)
        self.counter = _label("", 8, 400, C.DIM, 0.5)
        self.counter.setFont(mono(8))
        top.addWidget(self.overline)
        top.addStretch(1)
        top.addWidget(self.counter)
        layout.addLayout(top)

        self.title = TextBlock("", 21, 700, C.TEXT, 2, 1.34)
        layout.addWidget(self.title)
        self.summary = TextBlock("", 11, 400, C.MUTED, 3, 1.58)
        layout.addWidget(self.summary)
        layout.addStretch(1)
        self.question = TextBlock("", 9.5, 400, C.GOLD_DIM, 1, 1.45)
        layout.addWidget(self.question)

        bottom = QHBoxLayout()
        bottom.setSpacing(8)
        self.meta = _label("", 9, 400, C.DIM, 0.2)
        self.meta.setFont(mono(8.5))
        self.open_btn = TextButton("阅读全文", C.GOLD_LIGHT, 9)
        self.open_btn.clicked.connect(self.clicked)
        bottom.addWidget(self.meta)
        bottom.addStretch(1)
        bottom.addWidget(self.open_btn)
        layout.addLayout(bottom)

        if story:
            self.set_story(story)

    def set_story(self, story: dict) -> None:
        self.story = story
        self.title.setText(story.get("display_title") or story.get("title", ""))
        self.summary.setText(story.get("summary", ""))
        self.question.setText(f"带着问题读  ·  {story.get('question', '')}")
        self.meta.setText(f"{story.get('source', '')}   ·   {story.get('published_display', '')}   ·   {story.get('read_minutes', 2)} MIN")
        self.counter.setText("FOCUS  01")

    def _set_parallax(self, value) -> None:
        self._parallax = float(value)
        self.update()

    def mouseMoveEvent(self, event) -> None:
        self._parallax_anim.stop()
        nx = (event.position().x() / max(1, self.width())) - 0.5
        ny = (event.position().y() / max(1, self.height())) - 0.5
        self._parallax = max(-1.0, min(1.0, nx * 2)) * 6.0 + ny * 0.8
        self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event) -> None:
        self._parallax_anim.stop()
        self._parallax_anim.setStartValue(self._parallax)
        self._parallax_anim.setEndValue(0.0)
        self._parallax_anim.start()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        grad = QLinearGradient(r.topLeft(), r.bottomRight())
        grad.setColorAt(0, QColor("#1C2A25"))
        grad.setColorAt(0.55, QColor("#14201C"))
        grad.setColorAt(1, QColor("#0E1613"))
        p.setBrush(grad)
        p.setPen(QPen(QColor(201, 168, 106, 70), 1))
        p.drawRoundedRect(r, 14, 14)

        # Gold hairline at the top-left.
        p.setPen(QPen(QColor(232, 212, 166, 140), 1.2))
        p.drawLine(QPointF(18, 0.8), QPointF(120, 0.8))

        # A quiet seal in the background.
        p.setFont(serif(142, 400))
        p.setPen(QColor(232, 212, 166, 16))
        p.drawText(QRectF(r.right() - 150 + self._parallax, r.bottom() - 155 - self._parallax * 0.25, 160, 160), Qt.AlignmentFlag.AlignCenter, "观")

        # Corner mark.
        p.setPen(QPen(QColor(201, 168, 106, 55), 1))
        p.drawLine(QPointF(r.right() - 48, r.bottom() - 18), QPointF(r.right() - 18, r.bottom() - 18))
        p.drawLine(QPointF(r.right() - 18, r.bottom() - 18), QPointF(r.right() - 18, r.bottom() - 40))


class StoryCard(QWidget):
    clicked = Signal(dict)

    def __init__(self, story: dict, index: int = 1, parent: QWidget | None = None):
        super().__init__(parent)
        self.story = story
        self.index = index
        self._hover = False
        self._hover_mix = 0.0
        self._hover_anim = QVariantAnimation(self)
        self._hover_anim.setDuration(170)
        self._hover_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._hover_anim.valueChanged.connect(self._set_hover_mix)
        self.setFixedHeight(160)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 11, 14, 10)
        layout.setSpacing(5)

        top = QHBoxLayout()
        top.setSpacing(8)
        idx = _label(f"{index:02d}", 8, 400, C.GOLD_DIM, 0.5)
        idx.setFont(mono(8, 400, spacing=0.8))
        top.addWidget(idx)
        tag_text = (story.get("tags") or [story.get("region", "")])[0]
        self.tag = TagLabel(tag_text, "gold" if index % 2 else "jade")
        top.addWidget(self.tag)
        top.addStretch(1)
        self.score = _label(f"{story.get('total', 0):.0f}", 8, 400, C.GOLD_DIM, 0.3)
        self.score.setFont(mono(8))
        top.addWidget(self.score)
        layout.addLayout(top)

        self.title = TextBlock(story.get("display_title") or story.get("title", ""), 13.5, 600, C.TEXT, 2, 1.45)
        layout.addWidget(self.title)
        self.summary = TextBlock(story.get("summary", ""), 10, 400, C.MUTED, 2, 1.55)
        layout.addWidget(self.summary)

        bottom = QHBoxLayout()
        bottom.setSpacing(6)
        self.meta = _label(f"{story.get('source', '')}  ·  {story.get('published_display', '')[-5:]}", 8, 400, C.DIM, 0.2)
        self.meta.setFont(mono(8))
        bottom.addWidget(self.meta)
        bottom.addStretch(1)
        self.read = TextButton("阅读", C.GOLD_DIM, 8.5)
        self.read.clicked.connect(lambda: self.clicked.emit(self.story))
        bottom.addWidget(self.read)
        layout.addLayout(bottom)

    def _set_hover_mix(self, value) -> None:
        self._hover_mix = float(value)
        self.update()

    def _animate_hover(self, target: float) -> None:
        self._hover_anim.stop()
        self._hover_anim.setStartValue(self._hover_mix)
        self._hover_anim.setEndValue(target)
        self._hover_anim.start()

    def enterEvent(self, event) -> None:
        self._hover = True
        self._animate_hover(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self._animate_hover(0.0)
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.story)
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        mix = max(0.0, min(1.0, self._hover_mix))
        p.setBrush(QColor(255, 255, 255, int(10 + 11 * mix)))
        p.setPen(QPen(QColor(255, 255, 255, int(16 + 20 * mix)), 1))
        p.drawRoundedRect(r, 12, 12)
        if mix > 0.01:
            glow = QLinearGradient(r.left(), 0, r.left() + 110, 0)
            glow.setColorAt(0, QColor(201, 168, 106, int(38 * mix)))
            glow.setColorAt(1, QColor(201, 168, 106, 0))
            p.setBrush(glow)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(r.adjusted(1, 1, -1, -1), 11, 11)
            p.setPen(QPen(QColor(201, 168, 106, int(220 * mix)), 1.6))
            p.drawLine(QPointF(1, 17), QPointF(1, self.height() - 17))


class TermCard(QWidget):
    def __init__(self, term: dict | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.term = term or {}
        self.setFixedHeight(176)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(17, 13, 17, 12)
        layout.setSpacing(3)
        self.overline = _label("CONCEPT  /  格局词典", 7.5, 600, C.JADE, 1.4)
        layout.addWidget(self.overline)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.name = _label("", 19, 500, C.TEXT, 0.5)
        self.name.setFont(serif(19, 500))
        self.en = _label("", 7, 500, C.GOLD_DIM, 1.0)
        row.addWidget(self.name)
        row.addStretch(1)
        row.addWidget(self.en)
        layout.addLayout(row)
        self.definition = TextBlock("", 10, 400, C.MUTED, 3, 1.55)
        layout.addWidget(self.definition)
        self.bottom = TextBlock("", 8.5, 400, C.DIM, 2, 1.42)
        layout.addWidget(self.bottom)
        if term:
            self.set_term(term)

    def set_term(self, term: dict) -> None:
        self.term = term
        self.name.setText(term.get("term", ""))
        self.en.setText(term.get("en", ""))
        self.definition.setText(term.get("definition", ""))
        self.bottom.setText(f"高考连接  ·  {term.get('exam', '')}")

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        grad = QLinearGradient(r.topLeft(), r.bottomRight())
        grad.setColorAt(0, QColor(127, 169, 156, 15))
        grad.setColorAt(1, QColor(255, 255, 255, 6))
        p.setBrush(grad)
        p.setPen(QPen(QColor(127, 169, 156, 45), 1))
        p.drawRoundedRect(r, 12, 12)
        p.setBrush(QColor(127, 169, 156, 120))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(QRectF(r.left() + 1, 18, 2, 28), 1, 1)


class QuoteCard(QWidget):
    copy_clicked = Signal(str)

    def __init__(self, quote: dict, index: int = 1, parent: QWidget | None = None):
        super().__init__(parent)
        self.quote = quote
        self.index = index
        self.setFixedHeight(178)   # 原 214：短句下面空出一大截
        layout = QVBoxLayout(self)
        layout.setContentsMargins(17, 13, 15, 12)
        layout.setSpacing(4)
        top = QHBoxLayout()
        over = _label(f"DAILY LINE  /  {index:02d}", 7.5, 600, C.GOLD, 1.4)
        copy_btn = IconButton("copy", "复制这句话", 25, C.DIM)
        copy_btn.clicked.connect(lambda: self.copy_clicked.emit(self.quote.get("text", "")))
        top.addWidget(over)
        top.addStretch(1)
        top.addWidget(copy_btn)
        layout.addLayout(top)
        self.text = TextBlock(quote.get("text", ""), 16, 400, C.TEXT_SOFT, 4, 1.62)
        self.text.set_text_font(serif(16, 400, spacing=0.2), 26)
        layout.addWidget(self.text)
        layout.addStretch(1)
        self.author = _label("", 9, 500, C.GOLD_LIGHT, 0.3)
        layout.addWidget(self.author)
        self.use = TextBlock(f"可用在  {quote.get('use', '')}", 9, 400, C.DIM, 1, 1.5)
        layout.addWidget(self.use)
        self.author.setText(f"—— {quote.get('author', '')}，{quote.get('source', '')}")

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setBrush(QColor(255, 255, 255, 10))
        p.setPen(QPen(QColor(255, 255, 255, 18), 1))
        p.drawRoundedRect(r, 12, 12)
        p.setPen(QPen(QColor(201, 168, 106, 45), 1))
        p.drawLine(QPointF(r.left() + 1, 18), QPointF(r.left() + 1, r.height() - 18))


class PersonSeal(QWidget):
    def __init__(self, monogram: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self._monogram = monogram
        self.setFixedSize(70, 70)

    def set_monogram(self, text: str) -> None:
        self._monogram = text
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(4, 4, 62, 62)
        p.setBrush(QColor(201, 168, 106, 12))
        p.setPen(QPen(QColor(201, 168, 106, 90), 1.0))
        p.drawEllipse(r)
        p.setPen(QPen(QColor(201, 168, 106, 30), 1.0))
        p.drawEllipse(r.adjusted(5, 5, -5, -5))
        p.setFont(serif(26, 500))
        p.setPen(C.GOLD_LIGHT)
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self._monogram)


class ArchiveRow(QWidget):
    clicked = Signal(dict)

    def __init__(self, entry: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self.entry = entry
        self._hover = False
        self.setFixedHeight(82)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.entry)
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setBrush(QColor(255, 255, 255, 16 if self._hover else 9))
        p.setPen(QPen(QColor(255, 255, 255, 26 if self._hover else 15), 1))
        p.drawRoundedRect(r, 10, 10)
        date = self.entry.get("date", "")
        day = date[-2:]
        month = date[5:7] if len(date) >= 7 else ""
        p.setFont(mono(24, 400))
        p.setPen(C.GOLD_LIGHT)
        p.drawText(QRectF(14, 12, 54, 32), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, day)
        p.setFont(mono(8, 400, spacing=0.8))
        p.setPen(C.DIM)
        p.drawText(QRectF(15, 43, 58, 16), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, f"{month} / {self.entry.get('weekday', '')}")
        p.setPen(QPen(C.HAIRLINE, 1))
        p.drawLine(QPointF(74, 15), QPointF(74, self.height() - 15))

        title = self.entry.get("title") or self.entry.get("lead") or ""
        p.setFont(font(12, 600))
        p.setPen(C.TEXT_SOFT)
        fm = QFontMetrics(p.font())
        p.drawText(QPointF(88, 31), fm.elidedText(title, Qt.TextElideMode.ElideRight, self.width() - 116))
        p.setFont(font(8.5, 400))
        p.setPen(C.DIM)
        lead = self.entry.get("lead", "")
        meta = f"{self.entry.get('read_count', 0)} 条  ·  {self.entry.get('reading_minutes', 0)} 分钟"
        p.drawText(QRectF(88, 41, self.width() - 118, 20), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, meta)
        if lead:
            p.setFont(font(8.5, 400))
            p.setPen(C.MUTED)
            p.drawText(QRectF(88, 58, self.width() - 126, 15), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, lead)
        draw_icon(p, "chevron_right", QRectF(self.width() - 28, 30, 14, 14), C.GOLD_DIM if self._hover else C.DIM, 1.2)
