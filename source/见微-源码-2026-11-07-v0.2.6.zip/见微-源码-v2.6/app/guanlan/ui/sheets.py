"""Overlays for reading a story, inspecting the filter, and settings."""
from __future__ import annotations

import html
import os

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, QRect, QRectF, QTimer, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (
    QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel, QProgressBar, QPushButton,
    QScrollArea, QSizePolicy, QTextBrowser, QVBoxLayout, QWidget,
)

from .base import IconButton, TagLabel, TextBlock, Switch
from .cards import _label
from .icons import draw_icon
from .theme import C, font, mono, serif


SHEET_QSS = """
QFrame#sheet {
    background-color: #111B18;
    border: 1px solid rgba(201,168,106,80);
    border-radius: 16px;
}
QPushButton#primary {
    background: rgba(201,168,106,0.16);
    border: 1px solid rgba(201,168,106,0.42);
    border-radius: 9px;
    color: #E8D4A6;
    font-size: 11px;
    padding: 8px 12px;
}
QPushButton#primary:hover { background: rgba(201,168,106,0.26); }
QPushButton#ghost {
    background: transparent;
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 9px;
    color: #93A39C;
    font-size: 11px;
    padding: 8px 12px;
}
QPushButton#ghost:hover { color: #F2EDE3; border-color: rgba(255,255,255,0.24); }
QProgressBar {
    background: rgba(255,255,255,0.07);
    border: none;
    border-radius: 2px;
    height: 4px;
}
QProgressBar::chunk { background: #C9A86A; border-radius: 2px; }
"""


class Toast(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._text = ""
        self.setFixedHeight(34)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.hide()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._start_hide)
        self._effect = QGraphicsOpacityEffect(self)
        self._effect.setOpacity(0.0)
        self.setGraphicsEffect(self._effect)
        self._fade = QPropertyAnimation(self._effect, b"opacity", self)
        self._fade.setDuration(170)
        self._fade.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade.finished.connect(self._fade_finished)
        self._hiding = False

    def show_message(self, text: str, ms: int = 1800) -> None:
        self._text = text
        fm = QFontMetrics(font(9))
        self.setFixedWidth(min(self.parent().width() - 32, fm.horizontalAdvance(text) + 36))
        self.adjustSize()
        self.setFixedWidth(min(self.parent().width() - 32, fm.horizontalAdvance(text) + 36))
        self.move((self.parent().width() - self.width()) // 2, self.parent().height() - 58)
        self._timer.stop()
        self._fade.stop()
        self._hiding = False
        self._effect.setOpacity(0.0)
        self.show()
        self.raise_()
        self._fade.setDuration(180)
        self._fade.setStartValue(0.0)
        self._fade.setEndValue(1.0)
        self._fade.start()
        self._timer.start(ms)
        self.update()

    def _start_hide(self) -> None:
        self._hiding = True
        self._fade.stop()
        self._fade.setDuration(150)
        self._fade.setStartValue(self._effect.opacity())
        self._fade.setEndValue(0.0)
        self._fade.start()

    def _fade_finished(self) -> None:
        if self._hiding and self._effect.opacity() < 0.02:
            self.hide()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setBrush(QColor(18, 27, 38, 246))
        p.setPen(QPen(QColor(201, 168, 106, 80), 1))
        p.drawRoundedRect(r, 10, 10)
        p.setFont(font(9, 400))
        p.setPen(C.TEXT_SOFT)
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self._text)


class BaseSheet(QWidget):
    closed = Signal()

    def __init__(self, parent: QWidget | None = None, height_ratio: float = 0.82):
        super().__init__(parent)
        self._height_ratio = height_ratio
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        self.hide()
        self.setStyleSheet(SHEET_QSS)
        self.sheet = QFrame(self)
        self.sheet.setObjectName("sheet")
        self.sheet.setStyleSheet(SHEET_QSS)
        self.sheet_layout = QVBoxLayout(self.sheet)
        self.sheet_layout.setContentsMargins(18, 15, 18, 15)
        self.sheet_layout.setSpacing(10)

        top = QHBoxLayout()
        top.setSpacing(8)
        self.eyebrow = QLabel("")
        self.eyebrow.setFont(mono(7.5, 500, spacing=1.0))
        self.eyebrow.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        top.addWidget(self.eyebrow)
        top.addStretch(1)
        self.close_btn = IconButton("close", "关闭", 28, C.MUTED)
        self.close_btn.clicked.connect(self.close_sheet)
        top.addWidget(self.close_btn)
        self.sheet_layout.addLayout(top)

        self.body = QWidget()
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(0, 0, 0, 0)
        self.body_layout.setSpacing(9)
        self.sheet_layout.addWidget(self.body, 1)

        self._anim = QPropertyAnimation(self, b"windowOpacity", self)
        self._anim.setDuration(150)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def open_sheet(self) -> None:
        parent = self.parentWidget()
        if not parent:
            return
        self.setGeometry(parent.rect())
        h = max(280, int(parent.height() * self._height_ratio))
        w = parent.width() - 24
        self.sheet.setGeometry((parent.width() - w) // 2, (parent.height() - h) // 2, w, h)
        self.show()
        self.raise_()
        self.setWindowOpacity(0.0)
        self._anim.stop()
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.start()

    def close_sheet(self) -> None:
        self._anim.stop()
        self._anim.setStartValue(self.windowOpacity())
        self._anim.setEndValue(0.0)
        self._anim.finished.connect(self._finish_close)
        self._anim.start()

    def _finish_close(self) -> None:
        try:
            self._anim.finished.disconnect(self._finish_close)
        except Exception:
            pass
        self.hide()
        self.closed.emit()

    def resizeEvent(self, event) -> None:
        parent = self.parentWidget()
        if parent:
            h = max(280, int(parent.height() * self._height_ratio))
            w = parent.width() - 24
            self.sheet.setGeometry((parent.width() - w) // 2, (parent.height() - h) // 2, w, h)
        super().resizeEvent(event)

    def mousePressEvent(self, event) -> None:
        if not self.sheet.geometry().contains(event.position().toPoint()):
            self.close_sheet()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(4, 8, 13, 195))


class DetailSheet(BaseSheet):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, 0.86)
        self.eyebrow.setText("READING  /  原文摘录")
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.inner = QWidget()
        self.inner.setStyleSheet("background: transparent;")
        self.il = QVBoxLayout(self.inner)
        self.il.setContentsMargins(0, 0, 6, 8)
        self.il.setSpacing(10)
        self.scroll.setWidget(self.inner)
        self.body_layout.addWidget(self.scroll, 1)
        self.story = {}

    def open_story(self, story: dict) -> None:
        self.story = story
        while self.il.count():
            item = self.il.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        title = QLabel(story.get("display_title") or story.get("title", ""))
        title.setFont(serif(19, 600, spacing=0.2))
        title.setWordWrap(True)
        title.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        self.il.addWidget(title)
        meta = QLabel(f"{story.get('source', '')}   ·   {story.get('published_display', '')}   ·   {story.get('region', '')} / {story.get('section_label', '')}")
        meta.setFont(mono(8.5))
        meta.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        self.il.addWidget(meta)

        tag_row = QHBoxLayout()
        tag_row.setSpacing(5)
        for i, tag in enumerate((story.get("tags") or [])[:3]):
            tag_row.addWidget(TagLabel(tag, "gold" if i == 0 else "muted"))
        tag_row.addStretch(1)
        self.il.addLayout(tag_row)

        body = QTextBrowser()
        body.setOpenExternalLinks(False)
        body.setStyleSheet("QTextBrowser { background: transparent; border: none; color: #D8D2C6; }")
        detail = story.get("detail") or story.get("summary") or "请点击下方“阅读原文”查看完整报道。"
        escaped = html.escape(detail).replace("\n", "<br>")
        body.setHtml(f"<div style='font-family:Microsoft YaHei UI; font-size:13px; line-height:1.8; color:#D8D2C6;'>{escaped}</div>")
        body.setFixedHeight(210)
        self.il.addWidget(body)

        angle = QFrame()
        angle.setStyleSheet("background: rgba(201,168,106,0.055); border: 1px solid rgba(201,168,106,0.18); border-radius: 10px;")
        al = QVBoxLayout(angle)
        al.setContentsMargins(12, 9, 12, 10)
        al.setSpacing(3)
        t = QLabel("阅读角度")
        t.setFont(font(8, 600, spacing=0.8))
        t.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        w = QLabel(story.get("why", ""))
        w.setFont(font(9.5))
        w.setWordWrap(True)
        w.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        q = QLabel(f"带着问题读：{story.get('question', '')}")
        q.setFont(font(9.5, 500))
        q.setWordWrap(True)
        q.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
        al.addWidget(t)
        al.addWidget(w)
        al.addWidget(q)
        self.il.addWidget(angle)

        source = QLabel(f"来源：{story.get('source', '')} · 评分 {story.get('total', 0):.1f}")
        source.setFont(font(8.5))
        source.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        self.il.addWidget(source)

        actions = QHBoxLayout()
        open_btn = QPushButton("阅读原文  ↗")
        open_btn.setObjectName("primary")
        open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        open_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(story.get("url", ""))))
        close = QPushButton("收起")
        close.setObjectName("ghost")
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.clicked.connect(self.close_sheet)
        actions.addWidget(open_btn)
        actions.addWidget(close)
        actions.addStretch(1)
        self.il.addLayout(actions)
        self.il.addStretch(1)
        self.open_sheet()


class FilterSheet(BaseSheet):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, 0.9)
        self.eyebrow.setText("SELECTION DESK  /  编辑台")
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.inner = QWidget()
        self.inner.setStyleSheet("background: transparent;")
        self.il = QVBoxLayout(self.inner)
        self.il.setContentsMargins(0, 0, 7, 8)
        self.il.setSpacing(12)
        self.scroll.setWidget(self.inner)
        self.body_layout.addWidget(self.scroll, 1)

    def open_filter(self, edition: dict) -> None:
        while self.il.count():
            item = self.il.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        sel = edition.get("selection") or {}
        title = QLabel("六维标尺，先筛掉噪音")
        title.setFont(serif(20, 600, spacing=0.2))
        title.setWordWrap(True)
        title.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        self.il.addWidget(title)
        sub = QLabel("不是把信息变少，而是把注意力留给能解释世界如何运转的线索。")
        sub.setFont(font(9.5))
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        self.il.addWidget(sub)

        funnel = sel.get("funnel") or {}
        box = QFrame()
        box.setStyleSheet("background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px;")
        fl = QHBoxLayout(box)
        fl.setContentsMargins(12, 11, 12, 11)
        fl.setSpacing(4)
        steps = [("抓取", funnel.get("fetched", 0)), ("硬筛", funnel.get("gate_pass", 0)), ("去重", funnel.get("deduped", 0)), ("入选", funnel.get("selected", 0))]
        for i, (label, value) in enumerate(steps):
            col = QVBoxLayout()
            col.setSpacing(1)
            v = QLabel(str(value))
            v.setFont(mono(17, 500))
            v.setStyleSheet(f"color: {C.GOLD_LIGHT.name()}; background: transparent;")
            v.setAlignment(Qt.AlignmentFlag.AlignCenter)
            l = QLabel(label)
            l.setFont(font(7.5))
            l.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
            l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            col.addWidget(v)
            col.addWidget(l)
            fl.addLayout(col, 1)
            if i < 3:
                arrow = QLabel("→")
                arrow.setFont(font(10))
                arrow.setStyleSheet(f"color: {C.GOLD_DIM.name()}; background: transparent;")
                arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                fl.addWidget(arrow)
        self.il.addWidget(box)

        from core.editorial import DIMENSIONS, WEIGHTS
        dims_title = QLabel("今天的评分均值")
        dims_title.setFont(font(8, 600, spacing=0.7))
        dims_title.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        self.il.addWidget(dims_title)
        averages = sel.get("averages") or {}
        for key, label, desc in DIMENSIONS:
            weight = int((sel.get("weights") or WEIGHTS).get(key, WEIGHTS[key]) * 100)
            row = QWidget()
            rl = QVBoxLayout(row)
            rl.setContentsMargins(0, 1, 0, 3)
            rl.setSpacing(3)
            head = QHBoxLayout()
            l1 = QLabel(label)
            l1.setFont(font(10, 500))
            l1.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
            l2 = QLabel(f"{weight}%  ·  {averages.get(key, 0):.0f}")
            l2.setFont(mono(8))
            l2.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
            head.addWidget(l1)
            head.addStretch(1)
            head.addWidget(l2)
            rl.addLayout(head)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(int(averages.get(key, 0)))
            bar.setTextVisible(False)
            bar.setFixedHeight(4)
            bar.setStyleSheet("QProgressBar { background: rgba(255,255,255,0.07); border: none; border-radius: 2px; } QProgressBar::chunk { background: #C9A86A; border-radius: 2px; }")
            rl.addWidget(bar)
            d = QLabel(desc)
            d.setFont(font(8.3))
            d.setWordWrap(True)
            d.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
            rl.addWidget(d)
            self.il.addWidget(row)

        dist_title = QLabel("来源与地区")
        dist_title.setFont(font(8, 600, spacing=0.7))
        dist_title.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
        self.il.addWidget(dist_title)
        src = QHBoxLayout()
        src.setSpacing(4)
        for name, count in (sel.get("source_distribution") or {}).items():
            src.addWidget(TagLabel(f"{name} {count}", "muted"))
        src.addStretch(1)
        self.il.addLayout(src)
        region = QHBoxLayout()
        region.setSpacing(4)
        for name, count in (sel.get("region_distribution") or {}).items():
            region.addWidget(TagLabel(f"{name} {count}", "jade"))
        region.addStretch(1)
        self.il.addLayout(region)

        reasons = sel.get("rejected_reasons") or []
        if reasons:
            rt = QLabel("被硬门槛挡下的内容")
            rt.setFont(font(8, 600, spacing=0.7))
            rt.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
            self.il.addWidget(rt)
            for reason, count in reasons[:5]:
                r = QLabel(f"{reason}  ·  {count} 条")
                r.setFont(font(8.5))
                r.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
                self.il.addWidget(r)

        pool = sel.get("candidate_pool") or []
        if pool:
            pt = QLabel("候选池 · 前 8 条")
            pt.setFont(font(8, 600, spacing=0.7))
            pt.setStyleSheet(f"color: {C.GOLD.name()}; background: transparent;")
            self.il.addWidget(pt)
            for c in pool[:8]:
                mark = "✓" if c.get("selected") else "·"
                row = QLabel(f"{mark}  {c.get('score', 0):.1f}   {c.get('source', '')}   {c.get('title', '')}")
                row.setFont(font(8.5))
                row.setWordWrap(True)
                row.setStyleSheet(f"color: {C.TEXT_SOFT.name() if c.get('selected') else C.DIM.name()}; background: transparent;")
                self.il.addWidget(row)

        note = QLabel("硬门槛：来源可信、时效、标题党/软新闻/猎奇排除；结构约束：同源≤3、同地区≤3、至少4个来源、3个地区。")
        note.setFont(font(8.2))
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        self.il.addWidget(note)
        self.il.addStretch(1)
        self.open_sheet()


class SettingsSheet(BaseSheet):
    refresh_requested = Signal()
    archive_requested = Signal()
    settings_changed = Signal(dict)

    def __init__(self, config: dict, parent: QWidget | None = None):
        super().__init__(parent, 0.66)
        self.config = dict(config)
        self.eyebrow.setText("PREFERENCES  /  设置")
        title = QLabel("让观澜待在该待的地方")
        title.setFont(serif(19, 600))
        title.setWordWrap(True)
        title.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        self.body_layout.addWidget(title)
        sub = QLabel("所有阅读记录与筛选档案只保存在本机。")
        sub.setFont(font(8.5))
        sub.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        self.body_layout.addWidget(sub)

        self.switches: dict[str, Switch] = {}
        rows = [
            ("auto_start", "开机自动启动", "登录 Windows 后静默驻留侧边栏"),
            ("hide_on_fullscreen", "全屏时自动隐身", "看视频、演示或游戏时不遮挡"),
            ("pinned", "保持展开", "关闭自动收起，适合专注阅读"),
        ]
        for key, label, desc in rows:
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 5, 0, 5)
            col = QVBoxLayout()
            col.setSpacing(1)
            l1 = QLabel(label)
            l1.setFont(font(10, 500))
            l1.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
            l2 = QLabel(desc)
            l2.setFont(font(8))
            l2.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
            col.addWidget(l1)
            col.addWidget(l2)
            sw = Switch(bool(self.config.get(key, key == "auto_start")))
            sw.toggled.connect(lambda checked, k=key: self._set(k, checked))
            self.switches[key] = sw
            rl.addLayout(col, 1)
            rl.addWidget(sw)
            self.body_layout.addWidget(row)

        update_row = QWidget()
        ul = QHBoxLayout(update_row)
        ul.setContentsMargins(0, 6, 0, 6)
        ul_l = QLabel("每日更新时间")
        ul_l.setFont(font(9.5))
        ul_l.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        self.update_value = QLabel(f"{self.config.get('update_time', '07:15')}  ·  开机后自动补齐")
        self.update_value.setFont(mono(8.5))
        self.update_value.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        ul.addWidget(ul_l)
        ul.addStretch(1)
        ul.addWidget(self.update_value)
        self.body_layout.addWidget(update_row)
        self.body_layout.addStretch(1)
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        refresh = QPushButton("立即更新")
        refresh.setObjectName("primary")
        refresh.clicked.connect(self.refresh_requested)
        archive = QPushButton("打开档案库")
        archive.setObjectName("ghost")
        archive.clicked.connect(self.archive_requested)
        btn_row.addWidget(refresh)
        btn_row.addWidget(archive)
        btn_row.addStretch(1)
        self.body_layout.addLayout(btn_row)

        hint = QLabel("快捷键  Alt + Shift + G   ·   单击侧边窄条展开   ·   Esc 收起")
        hint.setFont(font(8))
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {C.DIM.name()}; background: transparent;")
        self.body_layout.addWidget(hint)

    def set_config(self, config: dict) -> None:
        self.config = dict(config)
        if hasattr(self, "update_value"):
            self.update_value.setText(f"{self.config.get('update_time', '07:15')}  ·  开机后自动补齐")
        for key, sw in self.switches.items():
            sw.blockSignals(True)
            sw.setChecked(bool(config.get(key, False)))
            sw.blockSignals(False)

    def _set(self, key: str, checked: bool) -> None:
        self.config[key] = checked
        self.settings_changed.emit(dict(self.config))
