"""Reusable painted primitives for the Guanlan interface."""
from __future__ import annotations

import math
import random
import re
from typing import Callable

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, QSize, Qt, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import (
    QColor, QFontMetrics, QLinearGradient, QPainter, QPainterPath, QPen,
    QPixmap, QRadialGradient,
)
from PySide6.QtWidgets import (
    QAbstractButton, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget,
)

from .icons import draw_icon
from .theme import C, font, mono, serif


class TextBlock(QWidget):
    """A wrapped, ellipsized block of text with controlled line height."""

    NO_START = set("，。、；：？！,.;:?!）)》」』”’】〉…—·%")   # 不能开行
    NO_END = set("（(《「『“‘【〈")                          # 不能收行

    TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:[’'\-][A-Za-z0-9]+)*|[ \t]+|[\u4e00-\u9fff]|.", re.S)

    def __init__(self, text: str = "", size: int = 13, weight: int = 400,
                 color: QColor | None = None, max_lines: int = 2,
                 line_height: float = 1.55, family: str | None = None,
                 parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self._font = font(size, weight, family)
        self._color = color or C.TEXT
        self._max_lines = max_lines
        self._line_height = round(self._font.pixelSize() * line_height)
        self.setFixedHeight(max(1, self._max_lines * self._line_height))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._lines: list[str] = []

    def setText(self, text: str) -> None:
        if text != self._text:
            self._text = text or ""
            self._lines = []
            if getattr(self, "_fit", False) and self.width() > 20:
                self.setFixedHeight(max(1, len(self._wrap())) * self._line_height)
            self.update()

    def text(self) -> str:
        return self._text

    def setColor(self, color: QColor) -> None:
        self._color = color
        self.update()

    def set_text_font(self, f, line_height: int | None = None) -> None:
        self._font = f
        if line_height:
            self._line_height = line_height
        else:
            self._line_height = max(1, round(f.pixelSize() * 1.55))
        self.setFixedHeight(max(1, self._max_lines * self._line_height))
        self._lines = []
        self.update()

    def fit(self) -> "TextBlock":
        """高度跟随实际行数（默认按 max_lines 预留，短文字下面会空出一大块）。"""
        self._fit = True
        return self

    def resizeEvent(self, event) -> None:
        self._lines = []
        super().resizeEvent(event)
        if getattr(self, "_fit", False):
            want = max(1, len(self._wrap())) * self._line_height
            if want != self.height():
                self.setFixedHeight(want)

    def _wrap(self) -> list[str]:
        if self._lines:
            return self._lines
        width = max(20, self.width())
        fm = QFontMetrics(self._font)
        lines: list[str] = []
        for paragraph in (self._text or "").split("\n"):
            cur = ""
            for token in self.TOKEN_RE.findall(paragraph):
                if token == "\n":
                    continue
                if token.isspace() and not cur:
                    continue
                candidate = cur + token
                if fm.horizontalAdvance(candidate) <= width or not cur:
                    cur = candidate
                elif token[0] in self.NO_START and len(cur) > 1 and not cur[-1].isspace():
                    # 避头：标点不能开行，把前一个字一起带到下一行（不悬挂，免得超出宽度被裁掉）
                    lines.append(cur[:-1].rstrip())
                    cur = cur[-1] + token
                else:
                    # 避尾：开引号、开括号不留在行末
                    carry = ""
                    while len(cur) > 1 and cur[-1] in self.NO_END:
                        carry, cur = cur[-1] + carry, cur[:-1]
                    lines.append(cur.rstrip())
                    cur = carry + ("" if token.isspace() else token)
            if cur.strip():
                lines.append(cur.rstrip())
            if len(lines) > self._max_lines:
                break
        if len(lines) > self._max_lines:
            head = lines[: self._max_lines - 1]
            tail = lines[self._max_lines - 1]
            head.append(fm.elidedText(tail + "…", Qt.TextElideMode.ElideRight, width))
            lines = head
        self._lines = lines or [""]
        return self._lines

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        painter.setFont(self._font)
        painter.setPen(self._color)
        fm = QFontMetrics(self._font)
        for idx, line in enumerate(self._wrap()):
            painter.drawText(QPointF(0, fm.ascent() + idx * self._line_height), line)


class IconButton(QAbstractButton):
    def __init__(self, icon_name: str, tooltip: str = "", size: int = 28,
                 color: QColor | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.icon_name = icon_name
        self._color = color or C.MUTED
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(tooltip)
        self.setCheckable(False)
        self._hover = False
        self._busy = False
        self._spin_angle = 0
        self._spin_timer = QTimer(self)
        self._spin_timer.setInterval(50)
        self._spin_timer.timeout.connect(self._spin)

    def set_icon(self, name: str) -> None:
        self.icon_name = name
        self.update()

    def set_busy(self, busy: bool) -> None:
        self._busy = bool(busy)
        if self._busy:
            self._spin_timer.start()
        else:
            self._spin_timer.stop()
            self._spin_angle = 0
        self.update()

    def _spin(self) -> None:
        self._spin_angle = (self._spin_angle + 12) % 360
        self.update()

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        if self.isChecked():
            p.setBrush(QColor(201, 168, 106, 26))
            p.setPen(QPen(QColor(201, 168, 106, 75), 1))
            p.drawEllipse(rect)
        elif self._hover or self.isDown():
            p.setBrush(QColor(255, 255, 255, 12))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(rect)
        color = C.GOLD if (self.isChecked() or self._busy) else (C.TEXT if self._hover else self._color)
        if self._busy and self.icon_name == "refresh":
            p.save()
            center = self.rect().center()
            p.translate(center.x(), center.y())
            p.rotate(self._spin_angle)
            p.translate(-center.x(), -center.y())
            draw_icon(p, self.icon_name, QRectF(7, 7, self.width() - 14, self.height() - 14), color, 1.45)
            p.restore()
        else:
            draw_icon(p, self.icon_name, QRectF(7, 7, self.width() - 14, self.height() - 14), color, 1.45)


class TextButton(QAbstractButton):
    def __init__(self, text: str, color: QColor | None = None, size: int = 10,
                 arrow: str | None = "arrow_right", parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self._color = color or C.GOLD
        self._size = size
        self._arrow = arrow
        self._hover = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(22)
        self._font = font(size, 500, spacing=0.4)
        self.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

    def sizeHint(self) -> QSize:
        fm = QFontMetrics(self._font)
        extra = 16 if self._arrow else 0
        return QSize(fm.horizontalAdvance(self._text) + extra + 4, 22)

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(self._font)
        color = C.GOLD_LIGHT if self._hover else self._color
        p.setPen(color)
        fm = QFontMetrics(self._font)
        p.drawText(QPointF(0, (self.height() + fm.ascent() - fm.descent()) / 2 - 1), self._text)
        if self._arrow:
            x = fm.horizontalAdvance(self._text) + 7
            draw_icon(p, self._arrow, QRectF(x, 5, 13, 13), color, 1.2)


class TagLabel(QWidget):
    def __init__(self, text: str = "", tone: str = "gold", parent: QWidget | None = None):
        super().__init__(parent)
        self._text = text
        self._tone = tone
        self._font = font(9, 500, spacing=0.3)
        self.setFixedHeight(20)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._resize()

    def setText(self, text: str) -> None:
        self._text = text
        self._resize()
        self.update()

    def setTone(self, tone: str) -> None:
        self._tone = tone
        self.update()

    def _resize(self) -> None:
        fm = QFontMetrics(self._font)
        self.setFixedWidth(fm.horizontalAdvance(self._text) + 18)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        tones = {
            "gold": (QColor(201, 168, 106, 24), QColor(201, 168, 106, 60), C.GOLD_LIGHT),
            "jade": (QColor(127, 169, 156, 20), QColor(127, 169, 156, 55), C.JADE),
            "muted": (QColor(255, 255, 255, 9), QColor(255, 255, 255, 22), C.MUTED),
        }
        bg, border, fg = tones.get(self._tone, tones["gold"])
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(QPen(border, 1))
        p.setBrush(bg)
        p.drawRoundedRect(rect, 10, 10)
        p.setFont(self._font)
        p.setPen(fg)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, self._text)


class Hairline(QWidget):
    def __init__(self, color: QColor | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self._color = color or C.HAIRLINE
        self.setFixedHeight(1)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.fillRect(self.rect(), self._color)


class SectionHeader(QWidget):
    def __init__(self, label: str, en: str, count: int | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.label = label
        self.en = en
        self.count = count
        self.setFixedHeight(36)

    def setCount(self, count: int) -> None:
        self.count = count
        self.update()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(font(12, 600, spacing=0.2))
        p.setPen(C.TEXT)
        fm = QFontMetrics(p.font())
        p.drawText(QPointF(0, 18), self.label)
        x = fm.horizontalAdvance(self.label) + 9
        p.setFont(font(7, 500, spacing=1.5))
        p.setPen(C.GOLD_DIM)
        fm2 = QFontMetrics(p.font())
        p.drawText(QPointF(x, 17), self.en)
        x2 = x + fm2.horizontalAdvance(self.en) + 12
        end = self.width() - (34 if self.count is not None else 0)
        if x2 < end - 10:
            p.setPen(C.HAIRLINE)
            p.drawLine(QPointF(x2, 14), QPointF(end, 14))
        if self.count is not None:
            p.setFont(mono(9))
            p.setPen(C.DIM)
            p.drawText(QRectF(self.width() - 28, 5, 28, 20), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, f"{self.count:02d}")


class TabBar(QWidget):
    changed = Signal(int)

    def __init__(self, tabs: list[str], parent: QWidget | None = None):
        super().__init__(parent)
        self.tabs = tabs
        self.active = 0
        self.hover = -1
        self._indicator = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(220)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._on_indicator)
        self.setFixedHeight(40)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _tab_rect(self, idx: int) -> QRectF:
        w = self.width() / max(1, len(self.tabs))
        return QRectF(idx * w, 0, w, self.height())

    def _on_indicator(self, value) -> None:
        self._indicator = float(value)
        self.update()

    def set_active(self, idx: int, emit: bool = True) -> None:
        if idx < 0 or idx >= len(self.tabs):
            return
        self.active = idx
        self._anim.stop()
        self._anim.setStartValue(self._indicator)
        self._anim.setEndValue(float(idx))
        self._anim.start()
        if emit:
            self.changed.emit(idx)

    def mousePressEvent(self, event) -> None:
        idx = int(event.position().x() / max(1, self.width()) * len(self.tabs))
        idx = max(0, min(len(self.tabs) - 1, idx))
        self.set_active(idx)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        idx = int(event.position().x() / max(1, self.width()) * len(self.tabs))
        idx = max(0, min(len(self.tabs) - 1, idx))
        if idx != self.hover:
            self.hover = idx
            self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event) -> None:
        self.hover = -1
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(font(11, 500, spacing=0.5))
        for idx, label in enumerate(self.tabs):
            rect = self._tab_rect(idx)
            color = C.GOLD_LIGHT if idx == self.active else (C.TEXT if idx == self.hover else C.MUTED)
            p.setPen(color)
            p.drawText(rect, Qt.AlignmentFlag.AlignCenter, label)
        w = self.width() / max(1, len(self.tabs))
        cx = (self.active + 0.5) * w
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.GOLD)
        p.drawRoundedRect(QRectF(cx - 9, self.height() - 2, 18, 2), 1, 1)


class BrandMark(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedSize(32, 32)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(1.5, 1.5, 29, 29)
        p.setBrush(QColor(201, 168, 106, 14))
        p.setPen(QPen(QColor(201, 168, 106, 150), 1.0))
        p.drawRoundedRect(rect, 9, 9)
        p.setFont(serif(15, 500))
        p.setPen(C.GOLD_LIGHT)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, "观")
        p.setBrush(C.GOLD)
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(27, 5), 1.8, 1.8)


class Panel(QWidget):
    """The ink panel behind everything. Painted, not styled."""

    # 阴影由顶层窗口用 theme.paint_shadow 画在面板外围（不再挂 QGraphicsDropShadowEffect）
    SHADOW = dict(blur=42, radius=22, dy=10, alpha=175)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self._noise = self._make_noise()
        self._bg: QPixmap | None = None
        self._bg_key = None

    @staticmethod
    def _make_noise() -> QPixmap:
        img = QPixmap(96, 96)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        rng = random.Random(7)
        for _ in range(900):
            x, y = rng.randrange(96), rng.randrange(96)
            alpha = rng.randrange(4, 13)
            p.setPen(QColor(255, 255, 255, alpha))
            p.drawPoint(x, y)
        p.end()
        return img

    def paintEvent(self, event) -> None:
        # 底板只随尺寸变化：缓存成一张图，子控件重绘时只贴图，不再重算渐变与噪点
        dpr = self.devicePixelRatioF()
        key = (self.width(), self.height(), round(dpr, 3))
        if self._bg is None or self._bg_key != key:
            pm = QPixmap(max(1, round(self.width() * dpr)), max(1, round(self.height() * dpr)))
            pm.setDevicePixelRatio(dpr)
            pm.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pm)
            self._paint_bg(painter)
            painter.end()
            self._bg, self._bg_key = pm, key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._bg)

    def _paint_bg(self, p: QPainter) -> None:
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        path = QPainterPath()
        path.addRoundedRect(rect, 22, 22)
        p.setClipPath(path)

        grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
        grad.setColorAt(0.0, C.BG_TOP)
        grad.setColorAt(0.55, QColor("#0E1512"))
        grad.setColorAt(1.0, C.BG_BOTTOM)
        p.fillRect(rect, grad)

        glow = QRadialGradient(rect.left() + rect.width() * 0.12, rect.top() + 20, rect.width() * 0.75)
        glow.setColorAt(0, QColor(201, 168, 106, 22))
        glow.setColorAt(0.55, QColor(201, 168, 106, 5))
        glow.setColorAt(1, QColor(201, 168, 106, 0))
        p.fillRect(rect, glow)

        glow2 = QRadialGradient(rect.right() - 10, rect.bottom() - 80, rect.width() * 0.7)
        glow2.setColorAt(0, QColor(91, 137, 128, 18))
        glow2.setColorAt(1, QColor(91, 137, 128, 0))
        p.fillRect(rect, glow2)

        p.setOpacity(0.55)
        p.drawTiledPixmap(self.rect(), self._noise)
        p.setOpacity(1.0)

        # A restrained gold rim, bright at the top-left.
        rim = QLinearGradient(rect.topLeft(), rect.bottomRight())
        rim.setColorAt(0, QColor(232, 212, 166, 115))
        rim.setColorAt(0.35, QColor(255, 255, 255, 22))
        rim.setColorAt(1, QColor(201, 168, 106, 34))
        p.setPen(QPen(rim, 1.0))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)

        hi = QLinearGradient(rect.left(), rect.top(), rect.right(), rect.top())
        hi.setColorAt(0, QColor(232, 212, 166, 0))
        hi.setColorAt(0.25, QColor(232, 212, 166, 80))
        hi.setColorAt(0.7, QColor(232, 212, 166, 0))
        p.setPen(QPen(hi, 1.0))
        p.drawLine(QPointF(rect.left() + 22, rect.top() + 1.5), QPointF(rect.right() - 22, rect.top() + 1.5))


class Switch(QAbstractButton):
    def __init__(self, checked: bool = False, parent: QWidget | None = None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setFixedSize(40, 22)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._pos = 1.0 if checked else 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(160)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._set_pos)
        self.toggled.connect(self._toggle)

    def _set_pos(self, value) -> None:
        self._pos = float(value)
        self.update()

    def _toggle(self, checked: bool) -> None:
        self._anim.stop()
        self._anim.setStartValue(self._pos)
        self._anim.setEndValue(1.0 if checked else 0.0)
        self._anim.start()

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        track = QRectF(0.5, 1.5, self.width() - 1, self.height() - 3)
        if self.isChecked():
            p.setBrush(QColor(201, 168, 106, 65))
            p.setPen(QPen(QColor(201, 168, 106, 150), 1))
        else:
            p.setBrush(QColor(255, 255, 255, 12))
            p.setPen(QPen(QColor(255, 255, 255, 30), 1))
        p.drawRoundedRect(track, track.height() / 2, track.height() / 2)
        x = 3 + self._pos * (self.width() - 22)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(C.GOLD_LIGHT if self.isChecked() else QColor("#A8B5AF"))
        p.drawEllipse(QRectF(x, 4, 14, 14))


class Rail(QWidget):
    expand_requested = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedSize(58, 194)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover = False
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(380)
        self._timer.timeout.connect(self.expand_requested.emit)
        self._date = ""
        self._count = 0

    def set_info(self, date_label: str, count: int) -> None:
        self._date = date_label
        self._count = count
        self.update()

    def enterEvent(self, event) -> None:
        self._hover = True
        self._timer.start()
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self._timer.stop()
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        self._timer.stop()
        self.expand_requested.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        cx = self.width() / 2
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(201, 168, 106, 90 if self._hover else 45))
        p.drawEllipse(QPointF(cx, 19), 3, 3)

        p.setFont(serif(22, 500, spacing=2))
        p.setPen(C.GOLD_LIGHT)
        p.drawText(QRectF(0, 33, self.width(), 30), Qt.AlignmentFlag.AlignCenter, "观")
        p.setFont(serif(18, 400, spacing=2))
        p.setPen(C.TEXT_SOFT)
        p.drawText(QRectF(0, 63, self.width(), 26), Qt.AlignmentFlag.AlignCenter, "澜")

        p.setPen(QPen(C.GOLD_DIM, 1))
        p.drawLine(QPointF(cx - 8, 102), QPointF(cx + 8, 102))

        p.setFont(mono(11))
        p.setPen(C.TEXT)
        p.drawText(QRectF(0, 112, self.width(), 20), Qt.AlignmentFlag.AlignCenter, self._date[-5:] if self._date else "—")
        p.setFont(font(8, 400))
        p.setPen(C.MUTED)
        p.drawText(QRectF(0, 132, self.width(), 18), Qt.AlignmentFlag.AlignCenter, f"今日 {self._count} 条")

        p.setPen(QPen(C.GOLD if self._hover else C.DIM, 1.3))
        y = 168
        p.drawLine(QPointF(cx + 7, y - 5), QPointF(cx - 1, y))
        p.drawLine(QPointF(cx - 1, y), QPointF(cx + 7, y + 5))
