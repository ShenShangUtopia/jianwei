"""The floating window, its lifecycle, and Windows-native conveniences."""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
import traceback
from ctypes import wintypes
from datetime import datetime, time as dtime
from pathlib import Path

from PySide6.QtCore import (
    QAbstractNativeEventFilter, QCoreApplication, QEasingCurve, QEvent, QPoint, QPropertyAnimation,
    QRect, QRectF, QSize, Qt, QThread, QTimer, QUrl, Signal,
)
from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont, QIcon, QKeySequence, QPainter, QPen, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QApplication, QGraphicsOpacityEffect, QMenu, QStackedWidget, QSystemTrayIcon, QVBoxLayout, QWidget,
)

from core.autostart import is_enabled as autostart_enabled, set_enabled as set_autostart
from core.paths import ARCHIVE_DIR, CONFIG_PATH, DATA_DIR, LATEST_PATH, ROOT, load_config, save_config
from .base import Panel, Rail
from .cards import Footer, TopBar
from .pages import ArchivePage, PeoplePage, QuotesPage, TodayPage
from .sheets import DetailSheet, FilterSheet, SettingsSheet, Toast
from .theme import C, QSS, font, paint_shadow, serif


HWND_BOTTOM = 1
HWND_TOP = 0
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010


def _set_window_z(hwnd: int, insert_after: int) -> None:
    try:
        if hwnd:
            ctypes.windll.user32.SetWindowPos(
                hwnd, insert_after, 0, 0, 0, 0,
                SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE,
            )
    except Exception:
        pass


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_ulong),
        ("rcMonitor", RECT),
        ("rcWork", RECT),
        ("dwFlags", ctypes.c_ulong),
    ]


def foreground_is_fullscreen(our_hwnd: int = 0) -> bool:
    try:
        user32 = ctypes.windll.user32
        hwnd = int(user32.GetForegroundWindow())
        if not hwnd or hwnd == our_hwnd:
            return False
        if user32.IsIconic(hwnd):
            return False
        cls = ctypes.create_unicode_buffer(128)
        user32.GetClassNameW(hwnd, cls, 128)
        if cls.value in ("Progman", "WorkerW", "Shell_TrayWnd", "Windows.UI.Core.CoreWindow"):
            return False
        rect = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return False
        MONITOR_DEFAULTTONEAREST = 2
        monitor = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
        if not monitor:
            return False
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        if not user32.GetMonitorInfoW(monitor, ctypes.byref(mi)):
            return False
        m = mi.rcMonitor
        return (
            rect.left <= m.left + 2 and rect.top <= m.top + 2
            and rect.right >= m.right - 2 and rect.bottom >= m.bottom - 2
        )
    except Exception:
        return False


class HotkeyFilter(QAbstractNativeEventFilter):
    def __init__(self, callback):
        super().__init__()
        self.callback = callback
        self.hotkey_id = 0xB017
        self.registered = False

    def install(self) -> bool:
        try:
            user32 = ctypes.windll.user32
            MOD_ALT, MOD_SHIFT, MOD_NOREPEAT = 0x0001, 0x0004, 0x4000
            ok = user32.RegisterHotKey(None, self.hotkey_id, MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, ord("G"))
            if not ok:
                return False
            QCoreApplication.instance().installNativeEventFilter(self)
            self.registered = True
            return True
        except Exception:
            return False

    def remove(self) -> None:
        if not self.registered:
            return
        try:
            ctypes.windll.user32.UnregisterHotKey(None, self.hotkey_id)
            QCoreApplication.instance().removeNativeEventFilter(self)
        except Exception:
            pass
        self.registered = False

    def nativeEventFilter(self, event_type, message):
        try:
            if bytes(event_type) != b"windows_generic_MSG":
                return False, 0
            msg = wintypes.MSG.from_address(int(message))
            if msg.message == 0x0312 and int(msg.wParam) == self.hotkey_id:
                self.callback()
        except Exception:
            pass
        return False, 0


class CuratorWorker(QThread):
    progress = Signal(str)
    ok = Signal(dict)
    failed = Signal(str)

    def __init__(self, force: bool = True, parent=None):
        super().__init__(parent)
        self.force = force

    def run(self) -> None:
        try:
            from core.curator import run
            result = run(force=self.force, log_fn=self.progress.emit)
            self.ok.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc())


class MainWindow(QWidget):
    def __init__(self, start_collapsed: bool = False, start_hidden: bool = False):
        super().__init__()
        self._start_collapsed = start_collapsed
        self._start_hidden = start_hidden
        self._initializing = True
        self._z_hold_until = 0.0
        self._last_activity = time.monotonic()
        self.cfg = load_config()
        self.edition = None
        self.index_entries: list[dict] = []
        self._busy = False
        self._worker: CuratorWorker | None = None
        self._collapsed = False
        self._animating = False
        self._hidden_for_fullscreen = False
        self._quitting = False
        self._pinned = bool(self.cfg.get("pinned", False))
        self._last_error = ""
        self._auto_attempt_at = None
        self._auto_play = bool(self.cfg.get("auto_play", False))
        self._auto_play_index = 0
        self._play_scroll_anim = None
        self._play_steps = [(0, 0.0), (0, 0.45), (0, 0.8), (1, 0.0), (2, 0.0), (3, 0.0)]

        self.setWindowTitle("观澜 · 每日视界")
        # Deliberately not WindowStaysOnTopHint: Guanlan belongs to the desktop
        # layer. It may be raised by the hotkey/tray, then sinks again when it
        # loses focus or the pointer leaves.
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setMinimumSize(80, 200)
        self.setStyleSheet(QSS)
        self.setWindowOpacity(float(self.cfg.get("opacity", 0.99)))

        self.screen_geo = QApplication.primaryScreen().availableGeometry()
        self._panel_w = 416
        self._panel_h = min(672, max(420, self.screen_geo.height() - 48))
        self._win_w = self._panel_w + 32
        self._win_h = self._panel_h + 32
        self._right_gap = 12
        self._top_gap = 8
        self._collapsed_panel = (58, 194)
        self._collapsed_win = (58 + 32, 194 + 32)
        self._target_collapsed = False

        self._build_ui()
        self._load_data()
        self._apply_window_geometry(collapsed=False)
        self._setup_tray()
        self._setup_shortcuts()
        self._setup_hotkey()
        self._setup_timers()

        self._set_collapsed(start_collapsed, animate=False)
        self._initializing = False
        self._z_hold_until = time.monotonic() + 2.5
        QApplication.instance().installEventFilter(self)
        if start_hidden:
            self.hide()
        else:
            self.show()
            self._play_startup_fade()
        QTimer.singleShot(1800, self._auto_check)
        QTimer.singleShot(1400, self._ensure_autostart)
        if self._auto_play and not start_hidden:
            QTimer.singleShot(2400, self._begin_auto_play)

    def paintEvent(self, event) -> None:
        # 面板阴影：九宫格贴图（原先的 QGraphicsDropShadowEffect 让面板里每次小重绘都整块重画）
        p = QPainter(self)
        paint_shadow(p, QRectF(self.panel.geometry()), **Panel.SHADOW)
        p.end()

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 16, 16, 16)
        outer.setSpacing(0)
        self.panel = Panel(self)
        outer.addWidget(self.panel)
        panel_layout = QVBoxLayout(self.panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)
        self.view_stack = QStackedWidget()
        self.view_stack.setStyleSheet("background: transparent;")
        panel_layout.addWidget(self.view_stack)

        self.expanded_page = QWidget()
        exp = QVBoxLayout(self.expanded_page)
        exp.setContentsMargins(0, 0, 0, 0)
        exp.setSpacing(0)

        self.topbar = TopBar()
        exp.addWidget(self.topbar)

        from .base import TabBar
        self.tabs = TabBar(["今日", "人物", "金句", "档案"])
        tab_wrap = QWidget()
        tab_layout = QVBoxLayout(tab_wrap)
        tab_layout.setContentsMargins(18, 0, 14, 0)
        tab_layout.setSpacing(0)
        tab_layout.addWidget(self.tabs)
        exp.addWidget(tab_wrap)

        self.page_stack = QStackedWidget()
        self.page_stack.setStyleSheet("background: transparent;")
        self.today_page = TodayPage()
        self.people_page = PeoplePage()
        self.quotes_page = QuotesPage()
        self.archive_page = ArchivePage()
        for page in (self.today_page, self.people_page, self.quotes_page, self.archive_page):
            self.page_stack.addWidget(page)
        exp.addWidget(self.page_stack, 1)

        self.footer = Footer()
        exp.addWidget(self.footer)
        self.view_stack.addWidget(self.expanded_page)

        self.rail = Rail()
        self.view_stack.addWidget(self.rail)

        self.detail_sheet = DetailSheet(self.panel)
        self.filter_sheet = FilterSheet(self.panel)
        self.settings_sheet = SettingsSheet(self.cfg, self.panel)
        self.toast = Toast(self.panel)
        self._page_fade_anim = None
        self._page_fade_effect = None
        self._startup_fade = None

        self.today_page.open_story.connect(self._open_story)
        self.today_page.open_filter.connect(self._open_filter)
        self.tabs.changed.connect(self._tab_changed)
        self.people_page.open_url.connect(self._open_url)
        self.quotes_page.copy_requested.connect(self._copy)
        self.archive_page.open_entry.connect(self._open_archive_entry)
        self.archive_page.open_library.connect(self._open_archive)
        self.topbar.refresh_clicked.connect(lambda: self.refresh(True))
        self.topbar.play_toggled.connect(self._set_auto_play)
        self.topbar.pin_toggled.connect(self._pin_toggled)
        self.topbar.collapse_clicked.connect(lambda: self._set_collapsed(True, animate=True))
        self.topbar.settings_clicked.connect(self._open_settings)
        self.footer.clicked.connect(self._footer_clicked)
        self.rail.expand_requested.connect(lambda: self._set_collapsed(False, animate=True))
        self.settings_sheet.refresh_requested.connect(lambda: self.refresh(True))
        self.settings_sheet.archive_requested.connect(self._open_archive)
        self.settings_sheet.settings_changed.connect(self._settings_changed)

        self.topbar.pin_btn.blockSignals(True)
        self.topbar.pin_btn.setChecked(self._pinned)
        self.topbar.pin_btn.blockSignals(False)
        self.topbar.set_playing(self._auto_play)

    # ------------------------------------------------------------- data
    def _read_json(self, path: Path, default):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default

    def _load_data(self) -> None:
        self.edition = self._read_json(LATEST_PATH, None)
        self.index_entries = self._read_json(DATA_DIR / "index.json", []) or []
        self.today_page.set_edition(self.edition)
        self.people_page.set_edition(self.edition)
        self.quotes_page.set_edition(self.edition)
        self.archive_page.set_data(self.index_entries, self.edition)
        if self.edition:
            self.topbar.set_date(self.edition.get("date_label", ""), self.edition.get("weekday", ""))
            self.rail.set_info(self.edition.get("date_label", ""), self.edition.get("read_count", 0))
            src_count = len(self.edition.get("selection", {}).get("sources", []))
            left = f"今日 {self.edition.get('read_count', 7)} 条 · {src_count} 家信源"
            try:
                dt = datetime.fromisoformat(self.edition.get("generated_at", ""))
                right = "更新 " + dt.strftime("%H:%M")
                if self.edition.get("date") != datetime.now().astimezone().date().isoformat():
                    left = f"昨日版 · {self.edition.get('read_count', 7)} 条"
            except Exception:
                right = "更新 07:15"
            self.footer.set_status(left, right, True)
        else:
            self.topbar.set_date(datetime.now().strftime("%Y.%m.%d"), "")
            self.footer.set_status("尚未生成今日版", "等待更新", False)
            self.rail.set_info(datetime.now().strftime("%Y.%m.%d"), 0)

    def _tab_changed(self, idx: int) -> None:
        self.page_stack.setCurrentIndex(idx)
        self._play_page_fade()
        page = self.page_stack.currentWidget()
        if hasattr(page, "scroll_top"):
            page.scroll_top()
        if idx == 3:
            self.index_entries = self._read_json(DATA_DIR / "index.json", []) or []
            self.archive_page.set_data(self.index_entries, self.edition)

    def _play_startup_fade(self) -> None:
        try:
            target = float(self.cfg.get("opacity", 0.99))
            self.setWindowOpacity(0.0)
            anim = QPropertyAnimation(self, b"windowOpacity", self)
            anim.setDuration(280)
            anim.setStartValue(0.0)
            anim.setEndValue(target)
            anim.setEasingCurve(QEasingCurve.Type.OutCubic)
            self._startup_fade = anim
            anim.start()
        except Exception:
            self.setWindowOpacity(float(self.cfg.get("opacity", 0.99)))

    def _play_page_fade(self) -> None:
        try:
            if self._page_fade_anim is not None:
                self._page_fade_anim.stop()
            self.page_stack.setGraphicsEffect(None)
            effect = QGraphicsOpacityEffect(self.page_stack)
            effect.setOpacity(0.45)
            self.page_stack.setGraphicsEffect(effect)
            anim = QPropertyAnimation(effect, b"opacity", self)
            anim.setDuration(210)
            anim.setStartValue(0.45)
            anim.setEndValue(1.0)
            anim.setEasingCurve(QEasingCurve.Type.OutCubic)

            def finish():
                try:
                    self.page_stack.setGraphicsEffect(None)
                except Exception:
                    pass
                self._page_fade_anim = None
                self._page_fade_effect = None

            anim.finished.connect(finish)
            self._page_fade_anim = anim
            self._page_fade_effect = effect
            anim.start()
        except Exception:
            pass

    # ------------------------------------------------------------ geometry
    def _expanded_rect(self) -> QRect:
        g = self.screen_geo
        x = g.right() - self._win_w - self._right_gap + 1
        return QRect(x, g.top() + self._top_gap, self._win_w, self._win_h)

    def _collapsed_rect(self) -> QRect:
        g = self.screen_geo
        w, h = self._collapsed_win
        x = g.right() - w - self._right_gap + 1
        y = min(g.top() + 70, g.bottom() - h - 10)
        return QRect(x, y, w, h)

    def _apply_window_geometry(self, collapsed: bool) -> None:
        self.setGeometry(self._collapsed_rect() if collapsed else self._expanded_rect())
        self._sync_overlay_geometry()

    def _sync_overlay_geometry(self) -> None:
        for sheet in (self.detail_sheet, self.filter_sheet, self.settings_sheet):
            if sheet.isVisible():
                sheet.setGeometry(self.panel.rect())

    def _set_collapsed(self, collapsed: bool, animate: bool = True) -> None:
        if self._animating or (self._collapsed == collapsed and self.isVisible()):
            if self._collapsed == collapsed and not animate:
                self.view_stack.setCurrentWidget(self.rail if collapsed else self.expanded_page)
            return
        if not self.isVisible() and not getattr(self, "_initializing", False):
            self.show()
        if collapsed:
            if self._auto_play and not self._initializing:
                self._set_auto_play(False, announce=False)
            for sheet in (self.detail_sheet, self.filter_sheet, self.settings_sheet):
                if sheet.isVisible():
                    sheet.hide()
            self._idle_timer.stop()
        self._collapsed = collapsed
        target = self._collapsed_rect() if collapsed else self._expanded_rect()
        if not animate:
            self.view_stack.setCurrentWidget(self.rail if collapsed else self.expanded_page)
            self.setGeometry(target)
            self._animating = False
            if not collapsed:
                self._restart_idle()
            return
        self._animating = True
        self.view_stack.hide()
        anim = QPropertyAnimation(self, b"geometry", self)
        anim.setDuration(230)
        anim.setStartValue(self.geometry())
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._geom_anim = anim

        def done():
            self.view_stack.setCurrentWidget(self.rail if collapsed else self.expanded_page)
            self.view_stack.show()
            self.view_stack.raise_()
            self._animating = False
            if not collapsed:
                self._restart_idle()
            self._sync_overlay_geometry()

        anim.finished.connect(done)
        anim.start()

    def _restart_idle(self) -> None:
        self._last_activity = time.monotonic()
        if self._auto_play or self._pinned or self._collapsed or not self.isVisible():
            self._idle_timer.stop()
            return
        if not self._idle_timer.isActive():
            self._idle_timer.start()

    def _idle_check(self) -> None:
        if self._auto_play:
            return
        if self._pinned or self._collapsed or not self.isVisible():
            return
        if any(s.isVisible() for s in (self.detail_sheet, self.filter_sheet, self.settings_sheet)):
            self._last_activity = time.monotonic()
            return
        seconds = max(30, int(self.cfg.get("auto_collapse_seconds", 180) or 180))
        if time.monotonic() - self._last_activity >= seconds:
            self._set_collapsed(True, animate=True)

    # ---------------------------------------------------------- auto play
    def _auto_play_interval(self) -> int:
        return max(6, int(self.cfg.get("auto_play_seconds", 12) or 12)) * 1000

    def _set_auto_play(self, enabled: bool, persist: bool = True, announce: bool = True) -> None:
        enabled = bool(enabled)
        if enabled == self._auto_play:
            self.topbar.set_playing(enabled)
            return
        self._auto_play = enabled
        self.topbar.set_playing(enabled)
        try:
            if hasattr(self, "act_autoplay"):
                self.act_autoplay.blockSignals(True)
                self.act_autoplay.setChecked(enabled)
                self.act_autoplay.blockSignals(False)
        except Exception:
            pass
        if enabled:
            if self._collapsed:
                self._set_collapsed(False, animate=True)
            self._begin_auto_play()
            if announce:
                self._toast("自动播放已开始 · Ctrl+P 暂停")
        else:
            self._auto_play_timer.stop()
            if self._play_scroll_anim is not None:
                self._play_scroll_anim.stop()
                self._play_scroll_anim = None
            if not self._collapsed:
                self._restart_idle()
            if announce:
                self._toast("自动播放已暂停")
        if persist:
            try:
                self.cfg["auto_play"] = enabled
                save_config(self.cfg)
            except Exception:
                pass

    def _begin_auto_play(self) -> None:
        if not self._auto_play:
            return
        if self._collapsed:
            self._set_collapsed(False, animate=True)
        self._auto_play_index = 0
        self.topbar.set_playing(True)
        self._idle_timer.stop()
        QTimer.singleShot(320, self._apply_play_step)
        self._auto_play_timer.start(self._auto_play_interval())

    def _auto_play_tick(self) -> None:
        if not self._auto_play:
            return
        if (self._collapsed or not self.isVisible() or self._busy
                or any(s.isVisible() for s in (self.detail_sheet, self.filter_sheet, self.settings_sheet))):
            self._auto_play_timer.start(3000)
            return
        if time.monotonic() - self._last_activity < 4.0:
            self._auto_play_timer.start(2500)
            return
        self._auto_play_index = (self._auto_play_index + 1) % len(self._play_steps)
        self._apply_play_step()
        self._auto_play_timer.start(self._auto_play_interval())

    def _apply_play_step(self) -> None:
        if not self._auto_play or not self._play_steps:
            return
        tab, fraction = self._play_steps[self._auto_play_index % len(self._play_steps)]
        if self.tabs.active != tab:
            self.tabs.set_active(tab)
        page = self.page_stack.widget(tab)
        scroll = getattr(page, "scroll", None)
        if scroll is None:
            return
        bar = scroll.verticalScrollBar()
        target = int(bar.maximum() * max(0.0, min(1.0, fraction)))
        if self._play_scroll_anim is not None:
            self._play_scroll_anim.stop()
        if tab != 0:
            bar.setValue(0)
            return
        anim = QPropertyAnimation(bar, b"value", self)
        anim.setDuration(680)
        anim.setStartValue(bar.value())
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._play_scroll_anim = anim
        anim.start()

    # ------------------------------------------------------------- timers
    def _setup_timers(self) -> None:
        self._idle_timer = QTimer(self)
        self._idle_timer.setInterval(1000)
        self._idle_timer.timeout.connect(self._idle_check)
        self._auto_play_timer = QTimer(self)
        self._auto_play_timer.setSingleShot(True)
        self._auto_play_timer.timeout.connect(self._auto_play_tick)
        self._auto_timer = QTimer(self)
        self._auto_timer.setInterval(60_000)
        self._auto_timer.timeout.connect(self._auto_check)
        self._auto_timer.start()
        self._fs_timer = QTimer(self)
        self._fs_timer.setInterval(2400)
        self._fs_timer.timeout.connect(self._check_fullscreen)
        self._fs_timer.start()
        self._z_timer = QTimer(self)
        self._z_timer.setInterval(1500)
        self._z_timer.timeout.connect(self._keep_bottom)
        self._z_timer.start()

    def _send_to_bottom(self) -> None:
        try:
            _set_window_z(int(self.winId()), HWND_BOTTOM)
        except Exception:
            pass

    def _bring_forward(self) -> None:
        self._z_hold_until = time.monotonic() + 5.0
        try:
            self.show()
            self.raise_()
            self.activateWindow()
            _set_window_z(int(self.winId()), HWND_TOP)
        except Exception:
            pass

    def _keep_bottom(self) -> None:
        if not self.isVisible() or self._animating:
            return
        if time.monotonic() < self._z_hold_until:
            return
        if self.isActiveWindow() or self.underMouse():
            return
        if any(s.isVisible() for s in (self.detail_sheet, self.filter_sheet, self.settings_sheet)):
            return
        self._send_to_bottom()

    def _auto_check(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            return  # 抓取交给见微的每日节律，避免两头同时跑
        if self._busy:
            return
        now = datetime.now().astimezone()
        today = now.date().isoformat()
        update_at = str(self.cfg.get("update_time", "07:15"))
        try:
            hh, mm = [int(x) for x in update_at.split(":")[:2]]
            cutoff = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        except Exception:
            cutoff = now
        if now < cutoff:
            return
        if self._auto_attempt_at is not None:
            if (now - self._auto_attempt_at).total_seconds() < 600:
                return
        # The edition may already exist from an early/manual refresh. If it was
        # generated before today's cutoff, refresh it once after the cutoff;
        # if it was generated after the cutoff, it is already today's fresh copy.
        if self.edition and self.edition.get("date") == today:
            try:
                generated = datetime.fromisoformat(str(self.edition.get("generated_at", "")))
                if generated.tzinfo is None:
                    generated = generated.replace(tzinfo=now.tzinfo)
                if generated >= cutoff:
                    return
            except Exception:
                pass
        self._auto_attempt_at = now
        self.refresh(force=True)

    def _check_fullscreen(self) -> None:
        if not self.cfg.get("hide_on_fullscreen", True):
            if self._hidden_for_fullscreen:
                self._hidden_for_fullscreen = False
                self.show()
            return
        try:
            hwnd = int(self.winId())
        except Exception:
            hwnd = 0
        is_fs = foreground_is_fullscreen(hwnd)
        if is_fs and self.isVisible():
            self._hidden_for_fullscreen = True
            self.hide()
        elif not is_fs and self._hidden_for_fullscreen:
            self._hidden_for_fullscreen = False
            self.show()
            self._set_collapsed(True, animate=False)

    # ------------------------------------------------------------- tray
    def _make_icon(self) -> QIcon:
        pix = QPixmap(64, 64)
        pix.fill(Qt.GlobalColor.transparent)
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setBrush(QColor("#0D1512"))
        p.setPen(QPen(QColor(201, 168, 106, 210), 2))
        p.drawEllipse(3, 3, 58, 58)
        p.setFont(serif(26, 500))
        p.setPen(QColor("#E8D4A6"))
        p.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, "观")
        p.end()
        return QIcon(pix)

    def _setup_tray(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            self.tray = None
            self.act_autostart = None
            self.setWindowIcon(self._make_icon())
            return
        self.tray = QSystemTrayIcon(self._make_icon(), self)
        self.tray.setToolTip("观澜 · 每日视界")
        menu = QMenu()
        menu.setStyleSheet(
            "QMenu { background:#111B18; color:#D8D2C6; border:1px solid rgba(201,168,106,80); padding:6px; }"
            "QMenu::item { padding:6px 26px 6px 18px; border-radius:5px; }"
            "QMenu::item:selected { background:rgba(201,168,106,0.18); color:#E8D4A6; }"
            "QMenu::separator { height:1px; background:rgba(255,255,255,0.08); margin:5px 8px; }"
            "QMenu::indicator { width:10px; height:10px; }"
        )
        act_toggle = QAction("展开 / 收起", self)
        act_toggle.triggered.connect(self.toggle_window)
        act_refresh = QAction("立即更新", self)
        act_refresh.triggered.connect(lambda: self.refresh(True))
        self.act_autoplay = QAction("自动播放", self)
        self.act_autoplay.setCheckable(True)
        self.act_autoplay.setChecked(self._auto_play)
        self.act_autoplay.toggled.connect(self._set_auto_play)
        act_archive = QAction("打开今日档案", self)
        act_archive.triggered.connect(self._open_archive)
        act_library = QAction("打开档案库", self)
        act_library.triggered.connect(self._open_archive_root)
        menu.addAction(act_toggle)
        menu.addAction(act_refresh)
        menu.addAction(self.act_autoplay)
        menu.addAction(act_archive)
        menu.addAction(act_library)
        menu.addSeparator()
        self.act_autostart = QAction("开机自动启动", self)
        self.act_autostart.setCheckable(True)
        self.act_autostart.setChecked(bool(self.cfg.get("auto_start", True)))
        self.act_autostart.toggled.connect(self._tray_autostart)
        self.act_fullscreen = QAction("全屏时自动隐身", self)
        self.act_fullscreen.setCheckable(True)
        self.act_fullscreen.setChecked(bool(self.cfg.get("hide_on_fullscreen", True)))
        self.act_fullscreen.toggled.connect(self._tray_fullscreen)
        self.act_pin = QAction("保持展开", self)
        self.act_pin.setCheckable(True)
        self.act_pin.setChecked(self._pinned)
        self.act_pin.toggled.connect(self._tray_pin)
        menu.addAction(self.act_autostart)
        menu.addAction(self.act_fullscreen)
        menu.addAction(self.act_pin)
        menu.addSeparator()
        act_quit = QAction("退出观澜", self)
        act_quit.triggered.connect(self.quit_app)
        menu.addAction(act_quit)
        self._tray_menu = menu
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()
        self.setWindowIcon(self._make_icon())

    def _tray_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self.toggle_window()

    def _tray_autostart(self, checked: bool) -> None:
        ok, msg = set_autostart(checked)
        if not ok:
            self.act_autostart.blockSignals(True)
            self.act_autostart.setChecked(not checked)
            self.act_autostart.blockSignals(False)
            self._toast("开机自启设置失败")
            return
        self.cfg["auto_start"] = checked
        save_config(self.cfg)
        self.settings_sheet.set_config(self.cfg)
        self._toast(msg)

    def _tray_fullscreen(self, checked: bool) -> None:
        self.cfg["hide_on_fullscreen"] = checked
        save_config(self.cfg)
        self.settings_sheet.set_config(self.cfg)

    def _tray_pin(self, checked: bool) -> None:
        self._set_pinned(checked, from_tray=True)

    def _ensure_autostart(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            return
        if self.cfg.get("auto_start", True) and not autostart_enabled():
            ok, _ = set_autostart(True)
            if not ok:
                self.cfg["auto_start"] = False
                save_config(self.cfg)
                self.settings_sheet.set_config(self.cfg)
                self.act_autostart.blockSignals(True)
                self.act_autostart.setChecked(False)
                self.act_autostart.blockSignals(False)

    # ---------------------------------------------------------- hotkey/shortcut
    def _setup_shortcuts(self) -> None:
        self._esc = QShortcut(QKeySequence("Esc"), self)
        self._esc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self._esc.activated.connect(lambda: self._set_collapsed(True, animate=True))
        self._play_shortcut = QShortcut(QKeySequence("Ctrl+P"), self)
        self._play_shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        self._play_shortcut.activated.connect(lambda: self._set_auto_play(not self._auto_play))

    def _setup_hotkey(self) -> None:
        if os.environ.get("JIANWEI_EMBED") == "1":
            self._hotkey = None
            return
        self._hotkey = HotkeyFilter(self.toggle_window)
        self._hotkey.install()

    def show_window(self) -> None:
        if not self.isVisible():
            self._hidden_for_fullscreen = False
            self.show()
        if self._collapsed:
            self._set_collapsed(False, animate=True)
        self._bring_forward()

    def toggle_window(self) -> None:
        if not self.isVisible():
            self._hidden_for_fullscreen = False
            self.show()
            self._set_collapsed(False, animate=True)
            self._bring_forward()
            return
        if self._collapsed:
            self._set_collapsed(False, animate=True)
            self._bring_forward()
        elif not self.isActiveWindow():
            # Hotkey/tray is an explicit summons: bring a covered panel forward
            # instead of hiding it, then let it sink again when focus leaves.
            self._bring_forward()
        else:
            self._set_collapsed(True, animate=True)

    # ------------------------------------------------------------- actions
    def _pin_toggled(self, checked: bool) -> None:
        self._set_pinned(checked)

    def _set_pinned(self, checked: bool, from_tray: bool = False) -> None:
        self._pinned = checked
        self.cfg["pinned"] = checked
        save_config(self.cfg)
        self.topbar.pin_btn.blockSignals(True)
        self.topbar.pin_btn.setChecked(checked)
        self.topbar.pin_btn.blockSignals(False)
        if not from_tray:
            self.act_pin.blockSignals(True)
            self.act_pin.setChecked(checked)
            self.act_pin.blockSignals(False)
        self.settings_sheet.set_config(self.cfg)
        if checked:
            self._idle_timer.stop()
            self._toast("已固定展开")
        else:
            self._restart_idle()
            self._toast("已恢复自动收起")

    def _settings_changed(self, cfg: dict) -> None:
        previous_start = bool(self.cfg.get("auto_start", True))
        self.cfg.update(cfg)
        if self.cfg.get("auto_start") != previous_start:
            ok, msg = set_autostart(bool(self.cfg.get("auto_start")))
            if not ok:
                self.cfg["auto_start"] = previous_start
                self.settings_sheet.set_config(self.cfg)
                self._toast("开机自启设置失败")
                return
            self.act_autostart.blockSignals(True)
            self.act_autostart.setChecked(bool(self.cfg.get("auto_start")))
            self.act_autostart.blockSignals(False)
        self._pinned = bool(self.cfg.get("pinned", False))
        self.topbar.pin_btn.blockSignals(True)
        self.topbar.pin_btn.setChecked(self._pinned)
        self.topbar.pin_btn.blockSignals(False)
        self.act_pin.blockSignals(True)
        self.act_pin.setChecked(self._pinned)
        self.act_pin.blockSignals(False)
        self.act_fullscreen.blockSignals(True)
        self.act_fullscreen.setChecked(bool(self.cfg.get("hide_on_fullscreen", True)))
        self.act_fullscreen.blockSignals(False)
        save_config(self.cfg)
        if self._pinned:
            self._idle_timer.stop()
        else:
            self._restart_idle()

    def _open_settings(self) -> None:
        self.settings_sheet.set_config(self.cfg)
        self.settings_sheet.open_sheet()
        self._idle_timer.stop()

    def _open_filter(self) -> None:
        if self.edition:
            self.filter_sheet.open_filter(self.edition)
            self._idle_timer.stop()

    def _open_story(self, story: dict) -> None:
        if story:
            self.detail_sheet.open_story(story)
            self._idle_timer.stop()

    def _copy(self, text: str) -> None:
        QApplication.clipboard().setText(text)
        self._toast("已复制这句话")

    def _open_url(self, url: str) -> None:
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def _open_archive_entry(self, entry: dict) -> None:
        rel = entry.get("path") or ""
        folder = ROOT / rel
        if folder.exists():
            os.startfile(str(folder))
        else:
            self._open_archive_root()

    def _open_archive(self) -> None:
        if self.edition and self.edition.get("archive_path"):
            folder = ROOT / self.edition["archive_path"]
            if folder.exists():
                os.startfile(str(folder))
                return
        self._open_archive_root()

    def _open_archive_root(self) -> None:
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        os.startfile(str(ARCHIVE_DIR))

    def _footer_clicked(self) -> None:
        if self._last_error:
            self.refresh(True)

    def _toast(self, text: str) -> None:
        # Background refreshes must never pop the panel open. If it is
        # collapsed, the rail's count and (for updates) the tray notification
        # are enough.
        if self._collapsed:
            return
        self.toast.show_message(text)

    # ------------------------------------------------------------- refresh
    def refresh(self, force: bool = True) -> None:
        if self._busy:
            return
        self._busy = True
        self._last_error = ""
        self.topbar.set_busy(True)
        self.footer.set_status("正在筛选 · 连接信源", "请稍候", True)
        self._worker = CuratorWorker(force=force, parent=self)
        self._worker.progress.connect(self._on_progress)
        self._worker.ok.connect(self._on_refresh_ok)
        self._worker.failed.connect(self._on_refresh_failed)
        self._worker.start()

    def _on_progress(self, text: str) -> None:
        if self._busy:
            self.footer.set_status(text, "正在更新", True)

    def _on_refresh_ok(self, result: dict) -> None:
        self._busy = False
        self.topbar.set_busy(False)
        worker = self._worker
        self._worker = None
        if worker:
            worker.deleteLater()
        edition = result.get("edition")
        if edition:
            self.edition = edition
        self._load_data()
        if self._collapsed:
            if self.tray.isSystemTrayAvailable():
                try:
                    self.tray.showMessage("观澜 · 今日版已更新", "新的世界线索已经放好。", QSystemTrayIcon.MessageIcon.Information, 2800)
                except Exception:
                    pass
        else:
            self._toast(f"今日版已更新 · {self.edition.get('read_count', 7)} 条精选")

    def _on_refresh_failed(self, error: str) -> None:
        self._busy = False
        self.topbar.set_busy(False)
        worker = self._worker
        self._worker = None
        if worker:
            worker.deleteLater()
        self._last_error = error
        detail = error.strip().splitlines()[-1] if error.strip() else "网络或信源暂时不可用"
        self.footer.set_status("更新失败 · 点击重试", "保留原有内容", False)
        if self._collapsed:
            if self.tray.isSystemTrayAvailable():
                try:
                    self.tray.showMessage("观澜 · 更新失败", "已保留上一版内容，稍后可重试。", QSystemTrayIcon.MessageIcon.Warning, 2600)
                except Exception:
                    pass
        else:
            self._toast("更新失败，已保留上一版内容")
        try:
            (ROOT / "logs").mkdir(exist_ok=True)
            with open(ROOT / "logs" / "ui_errors.log", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now().isoformat()} | {error}\n")
        except Exception:
            pass

    # ------------------------------------------------------------- lifecycle
    def eventFilter(self, obj, event) -> bool:
        try:
            if event.type() in (
                QEvent.Type.MouseMove, QEvent.Type.MouseButtonPress,
                QEvent.Type.MouseButtonRelease, QEvent.Type.MouseButtonDblClick,
                QEvent.Type.Wheel, QEvent.Type.KeyPress, QEvent.Type.KeyRelease,
                QEvent.Type.TouchBegin,
            ):
                if isinstance(obj, QWidget) and (obj is self or self.isAncestorOf(obj)):
                    self._last_activity = time.monotonic()
                    if not self._pinned and not self._collapsed and self.isVisible() and not self._idle_timer.isActive():
                        self._idle_timer.start()
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def enterEvent(self, event) -> None:
        if not self._collapsed:
            self._restart_idle()
        super().enterEvent(event)

    def changeEvent(self, event) -> None:
        super().changeEvent(event)

    def closeEvent(self, event) -> None:
        if self._quitting:
            event.accept()
            return
        event.ignore()
        self._idle_timer.stop()
        self.hide()

    def quit_app(self) -> None:
        self._quitting = True
        try:
            QApplication.instance().removeEventFilter(self)
        except Exception:
            pass
        try:
            self._hotkey.remove()
        except Exception:
            pass
        self.tray.hide()
        save_config(self.cfg)
        QApplication.quit()
