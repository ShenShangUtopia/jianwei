"""Visual language for Guanlan: ink, champagne gold, jade, paper."""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QWidget


class C:
    BG_TOP = QColor("#121C19")
    BG_BOTTOM = QColor("#090F0D")
    PANEL = QColor("#0D1512")
    PANEL_2 = QColor("#111B18")
    CARD = QColor(255, 255, 255, 11)
    CARD_HOVER = QColor(255, 255, 255, 19)
    TEXT = QColor("#F2EDE3")
    TEXT_SOFT = QColor("#D8D2C6")
    MUTED = QColor("#93A39C")
    DIM = QColor("#65746D")
    GOLD = QColor("#C9A86A")
    GOLD_LIGHT = QColor("#E8D4A6")
    GOLD_DIM = QColor(201, 168, 106, 90)
    JADE = QColor("#7FA99C")
    JADE_DIM = QColor(127, 169, 156, 70)
    CORAL = QColor("#D17D67")
    HAIRLINE = QColor(255, 255, 255, 22)
    HAIRLINE_STRONG = QColor(255, 255, 255, 38)
    BLACK = QColor("#050806")


UI_FAMILIES = ["Noto Sans SC", "Microsoft YaHei UI", "Microsoft YaHei", "DengXian"]
SERIF_FAMILIES = ["SimSun", "Songti SC", "Noto Serif SC", "STSong"]
MONO_FAMILIES = ["Georgia", "Cambria", "Times New Roman"]


def _pick_family(candidates: list[str]) -> str:
    available = set(QFontDatabase.families())
    for family in candidates:
        if family in available:
            return family
    return candidates[-1]


UI_FAMILY = _pick_family(UI_FAMILIES)
SERIF_FAMILY = _pick_family(SERIF_FAMILIES)
MONO_FAMILY = _pick_family(MONO_FAMILIES)


FONT_BUMP = 1


def _pixel_size(size: float) -> int:
    # One extra pixel across the board makes the small Chinese labels much
    # easier to read without breaking the editorial hierarchy.
    return max(1, int(size + 0.5) + FONT_BUMP)


def font(size: float = 13, weight: int = 400, family: str | None = None,
         spacing: float = 0.0, italic: bool = False) -> QFont:
    f = QFont(family or UI_FAMILY)
    f.setPixelSize(_pixel_size(size))
    f.setWeight(QFont.Weight(weight))
    f.setItalic(italic)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    f.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    return f


def serif(size: int = 22, weight: int = 400, spacing: float = 0.0) -> QFont:
    return font(size, weight, SERIF_FAMILY, spacing)


def mono(size: int = 10, weight: int = 400, spacing: float = 0.0) -> QFont:
    return font(size, weight, MONO_FAMILY, spacing)


def shadow(widget: QWidget, blur: int = 34, dy: int = 8, alpha: int = 170) -> QGraphicsDropShadowEffect:
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur)
    effect.setOffset(0, dy)
    effect.setColor(QColor(0, 0, 0, alpha))
    widget.setGraphicsEffect(effect)
    return effect


_SHADOW_TILES: dict = {}


def _shadow_tile(blur: int, radius: float, alpha: int):
    """柔和阴影的九宫格素材，只生成一次。

    QGraphicsDropShadowEffect 挂在大面板上时，面板里任何一处重绘（悬停、滚动、动画帧）都要把整块面板
    离屏重画再模糊一遍（实测一次 9~12 ms）；预先模糊好一块小图，之后每帧只是贴九张切片。"""
    key = (blur, round(radius, 1), alpha)
    if key in _SHADOW_TILES:
        return _SHADOW_TILES[key]
    from PySide6.QtCore import QRectF, Qt
    from PySide6.QtGui import QImage, QPainter, QPixmap
    from PySide6.QtWidgets import QGraphicsBlurEffect, QGraphicsPixmapItem, QGraphicsScene

    pad = int(blur)
    core = int(radius * 2 + 4)
    size = core + 2 * pad
    src = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    src.fill(Qt.GlobalColor.transparent)
    p = QPainter(src)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(0, 0, 0, alpha))
    p.drawRoundedRect(QRectF(pad, pad, core, core), radius, radius)
    p.end()
    scene = QGraphicsScene()
    item = QGraphicsPixmapItem(QPixmap.fromImage(src))
    blur_fx = QGraphicsBlurEffect()
    blur_fx.setBlurRadius(blur)
    blur_fx.setBlurHints(QGraphicsBlurEffect.BlurHint.QualityHint)
    item.setGraphicsEffect(blur_fx)
    scene.addItem(item)
    out = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    scene.render(p, QRectF(0, 0, size, size), QRectF(0, 0, size, size))
    p.end()
    tile = (QPixmap.fromImage(out), pad, pad + int(radius) + 1)
    _SHADOW_TILES[key] = tile
    return tile


def paint_shadow(p, rect, blur: int = 42, radius: float = 22, dy: int = 10, alpha: int = 175) -> None:
    """在 rect 外围画阴影（九宫格贴图），效果对应 shadow() 的同名参数。"""
    from PySide6.QtCore import QRectF
    pm, pad, corner = _shadow_tile(blur, radius, alpha)
    size = pm.width()
    mid = size - 2 * corner
    r = QRectF(rect).adjusted(-pad, -pad + dy, pad, pad + dy)
    c = min(float(corner), r.width() / 2, r.height() / 2)
    x0, x1, x2 = r.left(), r.left() + c, r.right() - c
    y0, y1, y2 = r.top(), r.top() + c, r.bottom() - c
    s0, s1, s2 = 0.0, float(corner), float(corner + mid)
    cols = ((x0, c, s0, corner), (x1, x2 - x1, s1, mid), (x2, c, s2, corner))
    rows = ((y0, c, s0, corner), (y1, y2 - y1, s1, mid), (y2, c, s2, corner))
    for ty, th, sy, sh in rows:
        for tx, tw, sx, sw in cols:
            if tw > 0 and th > 0:
                p.drawPixmap(QRectF(tx, ty, tw, th), pm, QRectF(sx, sy, sw, sh))


QSS = """
QWidget { background: transparent; color: #F2EDE3; }
QToolTip {
    background-color: #18241F;
    color: #F2EDE3;
    border: 1px solid rgba(201,168,106,150);
    border-radius: 4px;
    padding: 6px 8px;
    font-size: 12px;
}
QScrollArea { border: none; background: transparent; }
QScrollArea > QWidget > QWidget { background: transparent; }
QScrollBar:vertical {
    background: transparent;
    width: 4px;
    margin: 2px 0;
}
QScrollBar::handle:vertical {
    background: rgba(201,168,106,75);
    min-height: 26px;
    border-radius: 2px;
}
QScrollBar::handle:vertical:hover { background: rgba(201,168,106,130); }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QCheckBox { color: #D8D2C6; font-size: 12px; spacing: 8px; }
QTextBrowser {
    background: transparent;
    border: none;
    color: #D8D2C6;
    selection-background-color: #C9A86A;
    selection-color: #0B1118;
}
"""
