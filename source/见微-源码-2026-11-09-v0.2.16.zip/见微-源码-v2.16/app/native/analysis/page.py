"""析题页（原生）：左边贴题，中间讲题卡（答案 → 过程 → 解释 + 程序核对），右边图解 / 仿真 / 实验。

AI 与网络都在工作线程；每次分析带票据（ticket），只有当前这道题的回答能写进界面，过时的回答直接丢弃。
"""
from __future__ import annotations

import html
import json
import re
import traceback
import time

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QTextDocument, QKeySequence, QShortcut
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton, QScrollArea, QSplitter, QStackedWidget, QTabWidget, QVBoxLayout, QWidget)

from ..design import tokens
from ..design.tokens import T, css, qc
from ..design.widgets import qss
from ..kit.ctx import Ctx
from ..kit.registry import lab
from . import lesson as Lesson
from . import llm
from . import mathfmt
from .viz import make_viz
from .figure import from_problem, validate, FigureError
from .figure.view import FigureView
from .figure.evidence import reconcile

E = html.escape
STATUS = dict(verified=("程序核对通过", "ok"), solved=("程序已求解", "ok"), conflict=("程序与解答不符，待复核", "bad"), unchecked=("没有可核对的数值", "muted"))
BADGE = dict(verified=("✓ 已核对", "ok", "程序用另一种方法独立算了一遍，结果一致"),
             solved=("✓ 程序算出", "ok", "数由程序计算，并做了独立核对"),
             conflict=("! 待复核", "bad", "程序算出的结果和解答不一致"),
             unchecked=("未核对", "muted", "这道题没有能让程序核对的数值"))


class Worker(QThread):
    status = Signal(int, str)
    draft = Signal(int, object)
    finished_ok = Signal(int, object)
    failed = Signal(int, str)

    def __init__(self, rev, fn):
        super().__init__()
        self.rev, self.fn = rev, fn
        self.cancelled = False

    def run(self):
        try:
            r = self.fn(lambda m: self.status.emit(self.rev, str(m)), lambda d: self.draft.emit(self.rev, d), lambda: self.cancelled)
            self.finished_ok.emit(self.rev, r)
        except llm.AskError as e:
            self.failed.emit(self.rev, str(e))
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self.failed.emit(self.rev, f"{type(e).__name__}: {e}")


class StepTrack(QWidget):
    """步骤进度条：圆点连成一条线，走过的实心，当前这步放大带圈，点哪个跳到哪一步。"""
    clicked = Signal(int)

    def __init__(self):
        super().__init__()
        self.n, self.k, self.tips = 0, 0, []
        self.setFixedHeight(30)
        self.setMinimumWidth(80)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

    def set_state(self, n, k, tips=None):
        self.n, self.k = n, k
        if tips is not None:
            self.tips = tips
        self.update()

    def _xs(self):
        if self.n <= 1:
            return [12.0]
        gap = min(64.0, (self.width() - 24) / (self.n - 1))
        return [12 + i * gap for i in range(self.n)]

    def _hit(self, x):
        xs = self._xs()
        return min(range(len(xs)), key=lambda i: abs(xs[i] - x)) if xs else -1

    def mousePressEvent(self, e):
        i = self._hit(e.position().x())
        if 0 <= i < self.n:
            self.clicked.emit(i)

    def mouseMoveEvent(self, e):
        i = self._hit(e.position().x())
        tip = self.tips[i] if 0 <= i < len(self.tips) else ""
        if tip != self.toolTip():
            self.setToolTip(f"第 {i + 1} 步：{tip}" if tip else "")

    def paintEvent(self, _e):
        from PySide6.QtGui import QPainter, QPen
        from PySide6.QtCore import QPointF
        if self.n <= 1:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        xs, y = self._xs(), self.height() / 2
        acc, line, card = qc(T.accent), qc(T.line2), qc(T.raised)
        p.setPen(QPen(line, 2))
        p.drawLine(QPointF(xs[0], y), QPointF(xs[-1], y))
        p.setPen(QPen(acc, 2.6))
        p.drawLine(QPointF(xs[0], y), QPointF(xs[self.k], y))
        for i, x in enumerate(xs):
            if i == self.k:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.accent, 0.18))
                p.drawEllipse(QPointF(x, y), 11, 11)
                p.setBrush(acc)
                p.drawEllipse(QPointF(x, y), 6.5, 6.5)
            elif i < self.k:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(acc)
                p.drawEllipse(QPointF(x, y), 4.5, 4.5)
            else:
                p.setPen(QPen(line, 2))
                p.setBrush(card)
                p.drawEllipse(QPointF(x, y), 4.5, 4.5)
        p.end()


EXAMPLES = (
    ("平抛", "从 20 m 高处以 15 m/s 的速度水平抛出一个小球，不计空气阻力，g 取 10 m/s²，求落地时间和水平位移。"),
    ("斜面", "质量 2 kg 的物块从倾角 37° 的斜面顶端由静止滑下，斜面长 8 m，μ = 0.25，g 取 10 m/s²，sin37° = 0.6，cos37° = 0.8，求加速度和滑到底端的时间。"),
    ("斜抛", "将小球以 20 m/s 的速度从地面斜向上抛出，与水平方向成 30°，g 取 10 m/s²，求飞行时间、射程和最大高度。"),
    ("函数", "已知 f(x)=x^3-3x，求 f(x) 的零点和极值。"),
)


def catalog_text():
    lab.load()
    return "\n".join(f"{e.id}｜{e.subj}｜{e.unit}｜{e.title}｜{e.kw or ''}" for e in lab.list)


class AnalysisPage(QWidget):
    lesson_ready = Signal(object)
    def __init__(self, engine_factory=None):
        super().__init__()
        self.setObjectName("jw2")
        self.engine_factory = engine_factory or (lambda cancel: llm.Engine(Lesson.protocol(), cancel))
        self.rev = 0
        self.worker = None
        self.L = None
        self.ctx = None
        self.visual_contexts = []
        self.workers = []
        self.figure_view = None
        self.linked_views = []
        self._step_buttons = []
        split = QSplitter(Qt.Orientation.Horizontal)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(split)
        split.addWidget(self._left())
        self.card_scroll = QScrollArea()
        self.card_scroll.setWidgetResizable(True)
        self.card_host = QWidget()
        self.card_lay = QVBoxLayout(self.card_host)
        self.card_lay.setContentsMargins(18, 14, 18, 14)
        self.card_lay.setSpacing(8)
        self.card_scroll.setWidget(self.card_host)
        split.addWidget(self.card_scroll)
        # 讲解舞台：上面答案卡，中间一张大图，下面这一步的话和算式 + 步骤条
        self.full_open = False      # 「完整解答」默认收起，打开过就记住（本次运行内）
        self.beats = None           # 程序写的讲解步骤（有仿真的物理题）
        self.play_timer = QTimer(self)
        self.play_timer.setInterval(2800)
        self.play_timer.timeout.connect(self._tick)
        stage = QWidget()
        stage.setObjectName("lessonStage")
        sv = QVBoxLayout(stage)
        sv.setContentsMargins(14, 12, 14, 12)
        sv.setSpacing(10)
        self.answer_card = QFrame()
        self.answer_card.setObjectName("answerCard")
        self.answer_lay = QVBoxLayout(self.answer_card)
        self.answer_lay.setContentsMargins(16, 12, 16, 12)
        self.answer_lay.setSpacing(8)
        self.answer_card.hide()
        sv.addWidget(self.answer_card)
        self.right = QStackedWidget()
        self.right.setObjectName("stageBox")
        self.empty = self._hero()
        self.right.addWidget(self.empty)
        sv.addWidget(self.right, 1)
        sv.addWidget(self._step_bar())
        split.addWidget(stage)
        split.setStretchFactor(2, 1)
        split.setSizes([300, 460, 680])
        self.split = split
        self.apply_theme()
        self.show_welcome()
        self.refresh_history()
        self.sync_actions()

    def _left(self):
        box = QFrame()
        box.setObjectName("drawer")
        v = QVBoxLayout(box)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(8)
        head = QHBoxLayout()
        title = QLabel("题目")
        title.setObjectName("paneTitle")
        head.addWidget(title, 1)
        self.key_btn = QPushButton("DeepSeek 密钥…")
        self.key_btn.setObjectName("ghost")
        self.key_btn.clicked.connect(self.edit_key)
        head.addWidget(self.key_btn)
        v.addLayout(head)
        self.text = QPlainTextEdit()
        self.text.setPlaceholderText("把题目粘贴到这里，例如：从 20 m 高处以 15 m/s 的速度水平抛出一个小球，不计空气阻力，求落地时间和水平位移。")
        v.addWidget(self.text, 2)
        row = QHBoxLayout()
        self.engine_box = QComboBox()
        self.engine_box.addItem("AI 读题（DeepSeek）", "ai")
        self.engine_box.addItem("离线读题", "offline")
        if not llm.available():
            self.engine_box.setCurrentIndex(1)
        row.addWidget(self.engine_box, 1)
        self.go_btn = QPushButton("分析")
        self.go_btn.setObjectName("pri")
        self.go_btn.setToolTip("开始分析（Ctrl+Enter）")
        self.go_btn.clicked.connect(lambda: self.go())
        QShortcut(QKeySequence("Ctrl+Return"), self.text, activated=lambda: self.go())
        QShortcut(QKeySequence("Ctrl+Enter"), self.text, activated=lambda: self.go())
        row.addWidget(self.go_btn)
        v.addLayout(row)
        self.export_button=QPushButton("导出讲题 PDF / 长图")
        self.export_button.clicked.connect(lambda:self.export_lesson())
        v.addWidget(self.export_button)
        self.action_row = QHBoxLayout()   # 分析完可以送去工作台、黑板（按钮由互通路由加入）
        self.action_row.setSpacing(6)
        v.addLayout(self.action_row)
        self.status_l = QLabel("")
        self.status_l.setWordWrap(True)
        self.status_l.setObjectName("note")
        v.addWidget(self.status_l)
        title = QLabel("记录")
        title.setObjectName("grpTitle")
        v.addWidget(title)
        self.hist = QListWidget()
        self.hist.itemClicked.connect(self.open_history)
        v.addWidget(self.hist, 1)
        return box

    # ---- 欢迎：还没分析时舞台上放说明和几道示例题
    def _hero(self):
        box = QWidget()
        box.setObjectName("hero")
        v = QVBoxLayout(box)
        v.setContentsMargins(48, 40, 48, 40)
        v.setSpacing(14)
        v.addStretch(2)
        t = QLabel("把题目贴到左边，点「分析」")
        t.setObjectName("heroTitle")
        v.addWidget(t)
        s = QLabel("答案在上面，图在中间，下面一步一步讲；物理题的仿真会跟着讲解走到对应的时刻。")
        s.setObjectName("heroSub")
        s.setWordWrap(True)
        v.addWidget(s)
        v.addSpacing(10)
        cards = QHBoxLayout()
        cards.setSpacing(12)
        for num, head, body in (("1", "读题", "AI 只读题、选题型、填参数，不算数。没有密钥也能离线读常见题型。"),
                                ("2", "计算", "数全部由程序算，并给出分步图解或仿真。"),
                                ("3", "核对", "答案要过独立核对才算数，不一致的会标出来。")):
            card = QFrame()
            card.setObjectName("heroCard")
            cv = QVBoxLayout(card)
            cv.setContentsMargins(16, 14, 16, 14)
            cv.setSpacing(4)
            n = QLabel(num)
            n.setObjectName("stepNum")
            h = QLabel(head)
            h.setObjectName("stepHead")
            d = QLabel(body)
            d.setObjectName("note")
            d.setWordWrap(True)
            cv.addWidget(n)
            cv.addWidget(h)
            cv.addWidget(d)
            cv.addStretch(1)
            cards.addWidget(card, 1)
        v.addLayout(cards)
        v.addSpacing(16)
        row = QHBoxLayout()
        row.setSpacing(8)
        lab_ = QLabel("试一道：")
        lab_.setObjectName("note")
        row.addWidget(lab_)
        for name, text in EXAMPLES:
            b = QPushButton(name)
            b.setObjectName("exampleChip")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setToolTip(text)
            b.clicked.connect(lambda _=False, s=text: (self.text.setPlainText(s), self.go(s)))
            row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        v.addStretch(3)
        return box

    # ---- 步骤条：这一步说什么 + 第几步
    def _step_bar(self):
        bar = QFrame()
        bar.setObjectName("stepBar")
        v = QVBoxLayout(bar)
        v.setContentsMargins(14, 10, 14, 10)
        v.setSpacing(8)
        top = QHBoxLayout()
        top.setSpacing(10)
        self.step_no = QLabel("")
        self.step_no.setObjectName("stepNo")
        top.addWidget(self.step_no, 0, Qt.AlignmentFlag.AlignTop)
        self.step_text = QLabel("")
        self.step_text.setObjectName("stepText")
        self.step_text.setWordWrap(True)
        self.step_text.setTextFormat(Qt.TextFormat.RichText)
        self.step_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.LinksAccessibleByMouse)
        self.step_text.linkHovered.connect(lambda link: self.figure_view.set_hover(link[8:].split(',') if link.startswith('jwlayer:') else []) if self.figure_view else None)
        self.step_text.setMinimumHeight(44)
        top.addWidget(self.step_text, 1)
        v.addLayout(top)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.prev_btn = QPushButton("‹")
        self.play_btn = QPushButton("播放")
        self.play_btn.setObjectName("pri")
        self.next_btn = QPushButton("›")
        self.prev_btn.setToolTip("上一步")
        self.next_btn.setToolTip("下一步")
        for b in (self.prev_btn, self.next_btn):
            b.setObjectName("roundKey")
        for b in (self.prev_btn, self.play_btn, self.next_btn):
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
        self.prev_btn.clicked.connect(lambda: self._user_step(-1))
        self.next_btn.clicked.connect(lambda: self._user_step(1))
        self.play_btn.clicked.connect(self.toggle_play)
        row.addWidget(self.prev_btn)
        row.addWidget(self.play_btn)
        row.addWidget(self.next_btn)
        row.addSpacing(14)
        self.track = StepTrack()
        self.track.clicked.connect(lambda k: (self._stop_play(), self.go_step(k)))
        row.addWidget(self.track, 1)
        v.addLayout(row)
        self.step_bar = bar
        bar.hide()
        return bar

    def _rebuild_chips(self):
        view = self.figure_view
        n = len(view.stages) if view is not None else 0
        self.track.set_state(n, view.k if view is not None else 0, [mathfmt.plain(s)[:120] for s in view.stages] if view is not None else [])
        self.track.setVisible(n > 1)
        self.step_bar.setVisible(n > 0)
        self.play_btn.setVisible(n > 1)
        self.prev_btn.setVisible(n > 1)
        self.next_btn.setVisible(n > 1)
        if view is not None:
            self._sync_steps(view.k)

    def _user_step(self, d):
        self._stop_play()
        if self.figure_view is not None:
            self.go_step(self.figure_view.k + d)

    def toggle_play(self):
        if self.play_timer.isActive():
            self._stop_play()
            return
        view = self.figure_view
        if view is None:
            return
        if view.k >= len(view.stages) - 1:
            self.go_step(0)
        self.play_timer.start()
        self.play_btn.setText("暂停")

    def _stop_play(self):
        self.play_timer.stop()
        self.play_btn.setText("播放")

    def _tick(self):
        view = self.figure_view
        if view is None or view.k >= len(view.stages) - 1:
            self._stop_play()
        else:
            self.go_step(view.k + 1)
            if view.k >= len(view.stages) - 1:
                self._stop_play()

    # ---- 答案卡：一眼看到结论，核对过程收进「完整解答」
    def _answer_items(self, L):
        """[(名称, 值文本, 是否核对不符)]：优先用程序算出的行，其次方程模型，最后拆 AI 的答案文字。"""
        items = []
        for t in L.get("taskRes") or []:
            for r in t.get("rows") or []:
                if r.get("kind") != "equation":
                    items.append((str(r.get("prompt") or ""), str(r.get("text") or ""), r.get("ok") is False))
        if not items and L.get("calc"):
            for r in L["calc"].get("rows") or []:
                items.append((str(r.get("prompt") or ""), f"{Lesson.fmt_num(r['value'])}{' ' + r['unit'] if r.get('unit') else ''}", r.get("ok") is False))
        if not items:
            ans = str(L.get("answer") or "").strip()
            parts = [p.strip() for p in re.split(r"[；;]\s*", ans) if p.strip()]
            for p in parts[:8]:
                name, sep, val = p.partition("：")
                items.append((name, val, False) if sep and len(name) <= 12 else ("", p, False))
        return items[:8]

    def _fill_answer(self, L):
        lay = self.answer_lay
        while lay.count():
            item = lay.takeAt(0)
            sub = item.layout()
            if sub is not None:
                while sub.count():
                    w = sub.takeAt(0).widget()
                    if w:
                        w.setParent(None)
                        w.deleteLater()
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        st = Lesson.status_of(L)
        subj_col = T.get(dict(物理="phys", 数学="math", 化学="chem", 生物="bio").get(L.get("subject") or "", "accent"), T.accent)
        self.answer_card.setStyleSheet(f"QFrame#answerCard {{ border-left:5px solid {subj_col}; }}")
        head = QHBoxLayout()
        head.setSpacing(10)
        title = QLabel(E(L.get("topic") or "讲题"))
        title.setObjectName("answerTopic")
        head.addWidget(title)
        if L.get("subject"):
            subj = QLabel(E(L["subject"]))
            subj.setObjectName("subjChip")
            head.addWidget(subj, 0, Qt.AlignmentFlag.AlignVCenter)
        badge_text, tone, tip = BADGE[st]
        badge = QLabel(badge_text)
        badge.setObjectName("badge_" + tone)
        badge.setToolTip(tip)
        head.addWidget(badge, 0, Qt.AlignmentFlag.AlignVCenter)
        head.addStretch(1)
        if L.get('task') and L.get('taskRes'):
            practice = QPushButton("改条件重算")
            practice.setObjectName("ghost")
            practice.setToolTip("检查我的步骤，或改一个条件让程序重算")
            practice.clicked.connect(self.open_practice)
            head.addWidget(practice)
        full = QPushButton("完整解答 ›" if not self.card_scroll.isVisible() else "‹ 收起解答")
        full.setObjectName("ghost")
        full.setToolTip("已知、思路、每一步、程序核对、易错点")
        full.clicked.connect(self.toggle_full)
        self.full_btn = full
        head.addWidget(full)
        lay.addLayout(head)
        if L.get("unsupported"):
            note = QLabel("这道题现在的读题方式还解不了，下面只整理了题干里的条件。可以换「AI 读题」再试。")
            note.setObjectName("note")
            note.setWordWrap(True)
            lay.addWidget(note)
            return
        items = self._answer_items(L)
        grid = QGridLayout()
        grid.setHorizontalSpacing(28)
        grid.setVerticalSpacing(6)
        short = all(len(v) <= 22 for _n, v, _b in items)
        cols = 3 if short and len(items) > 1 else 1
        bad = qc(T.bad).name()
        for i, (name, val, wrong) in enumerate(items):
            cell = QVBoxLayout()
            cell.setSpacing(0)
            if name:
                nl = QLabel(E(name))
                nl.setObjectName("ansName")
                cell.addWidget(nl)
            shown = mathfmt.to_html(val)
            approx = mathfmt.to_html("=" + val).startswith("≈") and re.fullmatch(r"\s*-?[\d.eE+-]+.*", val) is not None
            vl = QLabel(("≈ " if approx else "") + shown if not wrong else f"<span style='color:{bad}'>{shown}</span>")
            vl.setObjectName("ansValue" if cols > 1 else "ansValueWide")
            vl.setTextFormat(Qt.TextFormat.RichText)
            vl.setWordWrap(cols == 1)
            vl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            vl.setToolTip(f"{name}：{val}" if name else val)
            cell.addWidget(vl)
            grid.addLayout(cell, i // cols, i % cols)
        if cols > 1:
            grid.setColumnStretch(cols, 1)
        lay.addLayout(grid)
        if st == "conflict":
            note = QLabel("程序算出的结果和 AI 的解答对不上，先打开「完整解答」看核对表。")
            note.setObjectName("note")
            note.setWordWrap(True)
            lay.addWidget(note)

    def toggle_full(self):
        self.full_open = not self.card_scroll.isVisible()
        self.card_scroll.setVisible(self.full_open)
        if getattr(self, "full_btn", None) is not None:
            self.full_btn.setText("‹ 收起解答" if self.full_open else "完整解答 ›")

    def sync_actions(self):
        """没有讲题结果时，导出、送去工作台这些键灰掉，不要点了才报错。"""
        ready = self.L is not None
        self.export_button.setEnabled(ready)
        for i in range(self.action_row.count()):
            w = self.action_row.itemAt(i).widget()
            if w is not None:
                w.setEnabled(ready)
                w.setToolTip("" if ready else "分析完一道题后可用")
        self.export_button.setToolTip("" if ready else "分析完一道题后可用")

    def edit_key(self):
        key, ok = QInputDialog.getText(self, "DeepSeek 密钥", "密钥只保存在本机数据目录，不会上传到别处。留空则清除。", QLineEdit.EchoMode.Password)
        if ok:
            llm.save_key(key.strip())
            self.engine_box.setCurrentIndex(0 if key.strip() else 1)

    def apply_theme(self):
        t = T
        self.setStyleSheet(qss() + f"""
QFrame#drawer {{ background:{t.surface}; border:none; }}
QLabel#paneTitle {{ font-size:15px; font-weight:700; }}
QLabel#stepNum {{ color:{t.accent}; font-family:"{tokens.family('num')}"; font-size:20px; font-weight:600; }}
QLabel#stepHead {{ font-size:13.5px; font-weight:700; }}
QLabel#emptyNote {{ color:{t.faint}; font-size:13px; }}
QWidget#lessonStage {{ background:{t.bg}; }}
QFrame#drawer QPlainTextEdit {{ background:{t.raised}; border:1px solid {t.line}; border-radius:10px; padding:6px 4px; font-size:13.5px; }}
QFrame#drawer QPlainTextEdit:focus {{ border-color:{t.accent}; }}
QFrame#drawer QListWidget {{ border:none; background:transparent; }}
QFrame#drawer QListWidget::item {{ padding:7px 10px; margin:1px 0; border-radius:7px; color:{t.soft}; }}
QFrame#drawer QListWidget::item:hover {{ background:{t.hover}; }}
QFrame#drawer QListWidget::item:selected {{ background:{css(t.accent, .12)}; color:{t.accent}; }}
QFrame#answerCard {{ background:{t.raised}; border:1px solid {t.line}; border-left:4px solid {t.accent}; border-radius:9px; }}
QLabel#answerTopic {{ font-size:17px; font-weight:700; }}
QLabel#subjChip {{ color:{t.muted}; background:{t.surface}; border:1px solid {t.line}; border-radius:9px; padding:1px 8px; font-size:11.5px; }}
QLabel#badge_ok {{ color:{t.ok}; background:{css(t.ok, .10)}; border-radius:9px; padding:1px 8px; font-size:12px; font-weight:700; }}
QLabel#badge_bad {{ color:{t.bad}; background:{css(t.bad, .10)}; border-radius:9px; padding:1px 8px; font-size:12px; font-weight:700; }}
QLabel#badge_muted {{ color:{t.muted}; background:{t.surface}; border-radius:9px; padding:1px 8px; font-size:12px; }}
QLabel#ansName {{ color:{t.muted}; font-size:12px; }}
QLabel#ansValue {{ font-size:22px; font-weight:700; color:{t.fg}; }}
QLabel#ansValueWide {{ font-size:15px; font-weight:700; color:{t.fg}; }}
QLabel#ansValue, QLabel#ansValueWide {{ font-family:"{tokens.family('num')}","{tokens.family('ui')}"; }}
QFrame#stepBar {{ background:{t.raised}; border:1px solid {t.line}; border-radius:12px; }}
QLabel#stepNo {{ color:{t.accent}; font-family:"{tokens.family('num')}"; font-size:26px; font-weight:600; min-width:48px; }}
QLabel#stepText {{ font-size:16px; color:{t.fg}; line-height:150%; }}
QPushButton#roundKey {{ min-width:30px; max-width:30px; min-height:30px; max-height:30px; padding:0; border-radius:15px; font-size:17px; font-weight:700; }}
QStackedWidget#stageBox {{ background:{t.stage}; border:1px solid {t.line}; border-radius:12px; }}
QWidget#lessonStage QTabWidget::pane {{ border:none; background:{t.stage}; }}
QWidget#lessonStage QTabBar {{ background:transparent; }}
QWidget#lessonStage QTabBar::tab {{ background:transparent; color:{t.muted}; padding:5px 14px; margin:8px 2px 6px 8px; border:none; border-radius:13px; font-size:12.5px; }}
QWidget#lessonStage QTabBar::tab:selected {{ background:{css(t.accent, .14)}; color:{t.accent}; font-weight:700; }}
QWidget#lessonStage QTabBar::tab:hover:!selected {{ background:{t.hover}; color:{t.fg}; }}
QScrollArea#sceneSide {{ border:none; border-left:1px solid {t.line}; background:{t.surface}; }}
QScrollArea#sceneSide > QWidget > QWidget {{ background:{t.surface}; }}
QWidget#hero {{ background:{t.stage}; border-radius:12px; }}
QLabel#heroTitle {{ font-size:24px; font-weight:700; color:{t.fg}; }}
QLabel#heroSub {{ font-size:13.5px; color:{t.muted}; }}
QFrame#heroCard {{ background:{t.raised}; border:1px solid {t.line}; border-radius:10px; }}
QPushButton#exampleChip {{ background:{t.raised}; color:{t.accent}; border:1px solid {css(t.accent, .35)}; border-radius:14px; padding:4px 14px; font-weight:700; }}
QPushButton#exampleChip:hover {{ background:{css(t.accent, .10)}; }}
""")
        if self.L:
            self.render(self.L)

    # ---- 讲题卡
    def _clear_card(self):
        self._step_buttons=[]
        def clear(lay):
            while lay.count():
                item = lay.takeAt(0)
                if item.layout():
                    clear(item.layout())
                w = item.widget()
                if w:
                    w.setParent(None)
                    w.deleteLater()
        clear(self.card_lay)

    def _p(self, s, name=None):
        if self.L and self.figure_view:
            from .figure.links import linkify
            s=linkify(s,self.figure_view.figure,qc(T.accent).name())
        lb = QLabel(s)
        lb.setWordWrap(True)
        lb.setTextFormat(Qt.TextFormat.RichText)
        lb.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse|Qt.TextInteractionFlag.LinksAccessibleByMouse)
        def hovered(link):
            if self.figure_view:
                self.figure_view.set_hover(link[8:].split(',') if link.startswith('jwlayer:') else [])
        lb.linkHovered.connect(hovered)
        if name:
            lb.setObjectName(name)
        self.card_lay.addWidget(lb)
        return lb

    def _h(self, s):
        return self._p(s, "grpTitle")

    def show_welcome(self):
        self._clear_card()
        self.card_scroll.hide()      # 说明放在舞台上（_hero），这一栏等有解答再出现
        self.answer_card.hide()
        self._p("<span style='font-size:22px;font-weight:700'>析题</span>")
        self._p("贴一道题，点「分析」。没有密钥也能用离线读题器处理常见题型。", "note")
        self.card_lay.addSpacing(10)
        for n, head, body in (("1", "读题", "AI 只读题、选路线、填参数，不算数。"),
                              ("2", "计算", "数全部由程序算，并给出分步图解或仿真。"),
                              ("3", "核对", "每个答案都要过独立核对才算数，不一致的会标出来。")):
            row = QHBoxLayout()
            row.setSpacing(12)
            num = QLabel(n)
            num.setObjectName("stepNum")
            num.setFixedWidth(20)
            row.addWidget(num, 0, Qt.AlignmentFlag.AlignTop)
            col = QVBoxLayout()
            col.setSpacing(2)
            h = QLabel(head)
            h.setObjectName("stepHead")
            d = QLabel(body)
            d.setObjectName("note")
            d.setWordWrap(True)
            col.addWidget(h)
            col.addWidget(d)
            row.addLayout(col, 1)
            self.card_lay.addLayout(row)
            self.card_lay.addSpacing(8)
        self.card_lay.addStretch(1)

    def show_draft(self, d):
        self._clear_card()
        self.card_scroll.show()      # AI 边写边显示；写完收进「完整解答」
        self.answer_card.hide()
        self._p(f"<span style='font-size:17px;font-weight:700'>{E(d.get('topic') or '正在生成')}</span>　<span style='color:{qc(T.muted).name()}'>AI 正在写，程序随后核对</span>")
        if d.get("summary"):
            self._p(f"<b>题意：</b>{E(d['summary'])}")
        if d.get("knowns"):
            self._h("已知")
            self._p("<br>".join(E(x) for x in d["knowns"]))
        if d.get("steps"):
            self._h("解题步骤")
            self._p("<br>".join(f"{i + 1}. {E(x)}" for i, x in enumerate(d["steps"])))
        if d.get("answer"):
            self._p(f"<b>答案（待核对）：</b>{E(d['answer'])}")
        self.card_lay.addStretch(1)
        self._draft_figure(d)

    def _draft_figure(self,d):
        if d.get('taskRes'):
            key = json.dumps(d['taskRes'], sort_keys=True, ensure_ascii=False)
            if key != getattr(self, '_live_task_key', None):
                self._live_task_key = key
                self.visuals(dict(d, problem=self._active_problem))
                from .realtime import has_diagram
                if has_diagram(d) and getattr(self,'first_native_ms',None) is None:
                    self.first_native_ms=(time.perf_counter()-self._analysis_started)*1000
                self.right.currentWidget().setToolTip('程序按当前抽取参数生成；请核对参数是否与原题一致，AI讲解尚未完成。')
            return
        if getattr(self, '_live_task_key', None):
            return
        raw = d.get("figure") or from_problem(getattr(self,"_active_problem",self.text.toPlainText()))
        key = json.dumps(raw, sort_keys=True, ensure_ascii=False)
        if key == getattr(self, '_draft_figure_key', None):
            return
        self._draft_figure_key = key
        try:
            figure = validate(raw)
        except FigureError:
            return
        if self.figure_view is not None and self.right.currentWidget() is self.figure_view:
            self.figure_view.replace(figure)
        else:
            self._close_ctx()
            self.figure_view = FigureView(figure)
            self._set_right(self.figure_view)
        self.figure_view.setToolTip("草稿图：尚未程序核对")
        from .realtime import has_diagram
        if has_diagram({'figure':figure}) and getattr(self,'first_native_ms',None) is None:
            self.first_native_ms=(time.perf_counter()-getattr(self,'_analysis_started',time.perf_counter()))*1000
        if getattr(self,"first_figure_ms",None) is None:
            self.first_figure_ms = round((time.perf_counter()-getattr(self,"_analysis_started",time.perf_counter()))*1000,2)

    def render(self, L):
        self.sync_actions()
        self._clear_card()
        self.card_scroll.setVisible(self.full_open or bool(L.get("unsupported")))
        self._fill_answer(L)
        self.answer_card.show()
        self._rebuild_chips()
        M = mathfmt.to_html
        ok_c, bad_c, mut = qc(T.ok).name(), qc(T.bad).name(), qc(T.muted).name()
        st = Lesson.status_of(L)
        label, tone = STATUS[st]
        col = dict(ok=ok_c, bad=bad_c, muted=mut)[tone]
        self._p(f"<span style='font-size:17px;font-weight:700'>完整解答</span>　<span style='color:{mut}'>{E(L.get('subject') or '')}</span>　<span style='color:{col};font-weight:600'>{label}</span>")
        if L.get("summary"):
            self._p(f"<b>题意：</b>{E(L['summary'])}")
        if L.get("unsupported"):
            self._p("仍可在右栏检查从题干整理的条件图。", "note")
            self.card_lay.addStretch(1)
            return
        # 答案 → 过程 → 解释（VeloΦ 的三段）
        self._h("答案")
        ans = str(L.get("answer") or "—")
        if st == "conflict":
            self._p(f"<span style='color:{bad_c}'>{E(ans)}（程序核对不符，先看下面的核对表）</span>")
        else:
            self._p(f"<b style='font-size:15px'>{M(ans)}</b>", "out")
        rc = L.get("recheck") or {}
        if rc.get("oldAnswer"):
            self._p(f"AI 复查后改了答案。原答案：{E(str(rc['oldAnswer']))}" + (f"　错在：{E(rc.get('check') or '')}" if rc.get("check") else ""), "note")
        elif rc.get("disputed"):
            self._p(f"AI 复查后仍坚持原答案，和程序不一致，请老师判断。{E(rc.get('check') or '')}", "note")
        for t in L.get("taskRes") or []:
            self._task_block(t, ok_c, bad_c, mut)
        if L.get("calc"):
            self._calc_block(L["calc"], ok_c, bad_c, mut)
        if L.get("calcNote"):
            self._p(E(L["calcNote"]), "note")
        if L.get('figureNote'):
            self._p(E(L['figureNote']), 'note')
        if L.get("verify"):
            self._verify_block(L["verify"], ok_c, bad_c)
        if L.get("knowns"):
            self._h("已知")
            self._p("<br>".join(M(x) for x in L["knowns"]))
        if L.get("assumptions"):
            self._h("假设")
            self._p("<br>".join(M(x) for x in L["assumptions"]), "note")
        if L.get("method"):
            self._h("思路")
            self._p(M(L["method"]))
        if L.get("steps"):
            self._h("解题步骤")
            self._p("<br>".join(f"<b>{i + 1}.</b> {M(text)}" for i, text in enumerate(L["steps"][:64])))
        if L.get("figure_checks"):
            self._h("图中数值核对")
            self._p("<br>".join(E(x) for x in L["figure_checks"]),"note")
        if L.get("conclusion"):
            self._h("结论")
            self._p(M(L["conclusion"]))
        if L.get("check"):
            self._h("检验")
            self._p(M(L["check"]))
        if L.get("pitfalls"):
            self._h("易错点")
            self._p("<br>".join(M(x) for x in L["pitfalls"]))
        if L.get("watch"):
            self._h("观察")
            self._p("<br>".join(E(x) for x in L["watch"]))
        if L.get("caveats"):
            self._p(E(L["caveats"]), "note")
        self.card_lay.addStretch(1)

    def open_practice(self):
        if not self.L or not self.L.get('task'):
            return
        from .practice_ui import PracticeDialog
        dialog=PracticeDialog(self.L,self)
        def use_variant(value):
            self.rev+=1
            self._live_task_key=None
            self._on_done(self.rev,value)
        dialog.variant_ready.connect(use_variant)
        dialog.exec()

    def _task_block(self, t, ok_c, bad_c, mut):
        self._h(f"程序求解 · {t['title']}")
        info = t.get('model_info')
        if info:
            parameters = '，'.join(f'{k} = {v}' for k,v in info['parameters'].items() if k != 'kind')
            self._p(E(info['scope']) + '<br>当前参数：' + E(parameters), 'note')
        rows = []
        for r in t["rows"]:
            mark = "" if r["ok"] is None else f"<span style='color:{ok_c}'>✓</span>" if r["ok"] else f"<span style='color:{bad_c}'>✗</span>"
            cl = f"<span style='color:{mut}'>　AI：{E(json.dumps(r['claimed'], ensure_ascii=False) if isinstance(r['claimed'], (list, dict)) else str(r['claimed']))}</span>" if r.get("claimed") not in (None, "") else ""
            rows.append(f"{E(r['prompt'])}：<b>{mathfmt.to_html(str(r['text']))}</b> {mark}{cl}")
        self._p("<br>".join(rows))
        if t.get("checks"):
            self._p("<br>".join(f"<span style='color:{ok_c if c['ok'] else bad_c}'>{'✓' if c['ok'] else '✗'}</span> {mathfmt.to_html(c['text'], italic=False)}" for c in t["checks"]), "note")
        if t.get("detail"):
            self._p("<br>".join(mathfmt.to_html(d) for d in t["detail"]), "note")

    def _calc_block(self, c, ok_c, bad_c, mut):
        self._h(f"方程模型 · {Lesson.Solver.VERDICT.get(c['verdict'], c['verdict'])}")
        rows = []
        for r in c["rows"]:
            mark = "" if r["ok"] is None else f"<span style='color:{ok_c}'>✓</span>" if r["ok"] else f"<span style='color:{bad_c}'>✗</span>"
            cl = f"<span style='color:{mut}'>　AI：{E(str(r['claimed']))}</span>" if r.get("claimed") not in (None, "") else ""
            rows.append(f"{E(r['prompt'])}：<b>{Lesson.fmt_num(r['value'])}{' ' + E(r['unit']) if r['unit'] else ''}</b> {mark}{cl}")
        self._p("<br>".join(rows))
        self._p("<br>".join(mathfmt.to_html(e["text"]) + (f"（{E(e['why'])}）" if e["why"] else "") for e in c["equations"]), "note")
        if c.get("conflicts"):
            self._p("矛盾的方程：" + "；".join(E(x["text"]) for x in c["conflicts"]), "note")
        if c.get("undetermined"):
            self._p("不能确定：" + "、".join(E(x) for x in c["undetermined"]), "note")

    def _verify_block(self, v, ok_c, bad_c):
        self._h("实验核对")
        if v.get("rows"):
            self._p("<br>".join(f"{E(str(r['quantity']))}：答案 {E(r['answer'])}，读数「{E(r['readout'])}」{E(r['measured'])} <span style='color:{ok_c if r['ok'] else bad_c}'>{'✓' if r['ok'] else '✗'}</span>" for r in v["rows"]))
        if v.get("check"):
            self._p(E(v["check"]), "note")

    # ---- 右栏
    def _set_right(self, w):
        while self.right.count() > 1:
            old = self.right.widget(1)
            self.right.removeWidget(old)
            old.setParent(None)
            old.deleteLater()
        if w is None:
            self.right.setCurrentIndex(0)
            return
        self.right.addWidget(w)
        self.right.setCurrentWidget(w)

    def _close_ctx(self):
        contexts=list(self.visual_contexts)
        if self.ctx and self.ctx not in contexts:
            contexts.append(self.ctx)
        for ctx in contexts:
            ctx.dispose()
        self.visual_contexts=[]
        self.ctx=None

    def _mount_scene(self, sc, cue=""):
        from ..bank.views import safe_mount
        box = QWidget()
        h = QHBoxLayout(box)
        h.setContentsMargins(0, 0, 0, 0)
        host = QFrame()
        hv = QVBoxLayout(host)
        hv.setContentsMargins(1, 1, 1, 1)
        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(12, 10, 12, 10)
        ctx = Ctx(host, panel)
        hv.addWidget(ctx.stage)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(260)
        q = dict(id="lesson", steps=["a", "b", "c"], view=dict(engine="physics", kind=sc.get("kind"), params=sc.get("params") or {}, cue=cue, lesson=True))
        view, err = safe_mount(ctx, q)
        pv.addStretch(1)
        scroll.setWidget(panel)
        scroll.setObjectName("sceneSide")
        h.addWidget(host, 1)
        h.addWidget(scroll)
        self.ctx = ctx
        box.ctx=ctx
        self.visual_contexts.append(ctx)
        self.scene_view = view
        if view and not getattr(view, "beat", None):
            view.apply_step(2)
        if err:
            ctx.stage.error = err
        return box

    def _mount_exp(self, e):
        box = QWidget()
        h = QHBoxLayout(box)
        h.setContentsMargins(0, 0, 0, 0)
        host = QFrame()
        hv = QVBoxLayout(host)
        hv.setContentsMargins(1, 1, 1, 1)
        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(12, 10, 12, 10)
        ctx = Ctx(host, panel)
        hv.addWidget(ctx.stage)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(270)
        e.init(ctx)
        pv.addStretch(1)
        scroll.setWidget(panel)
        h.addWidget(host, 1)
        h.addWidget(scroll)
        self.ctx = ctx
        box.ctx=ctx
        self.visual_contexts.append(ctx)
        self.exp_panel = panel
        return box

    def visuals(self, L):
        """有题型图解就放图解；物理题型放仿真；否则放实验（路线 module）。"""
        self._close_ctx()
        tabs = QTabWidget()
        self.linked_views = []
        # 有仿真的物理题：讲解步骤由程序按算出的数来写，每一步定好画面时刻和讲到的量
        from . import script
        scr = script.for_lesson(L)
        self.beats = scr[1] if scr else None
        steps = [b["say"] for b in self.beats] if self.beats else L.get("steps")
        try:
            figure = validate(L.get("figure")) if L.get("figure") else from_problem(L.get("problem",""),L.get("subject",""),steps)
        except FigureError:
            figure = from_problem(L.get("problem",""),L.get("subject",""),steps)
        if L.get("figure"):
            figure,L["figure_checks"] = reconcile(figure,L)
        draft = self.figure_view
        if draft is not None and self.right.currentWidget() is draft:
            draft.setParent(None)
            draft.replace(figure)
            self.figure_view = draft
        else:
            self.figure_view = FigureView(figure)
        self.figure_view.step_changed.connect(self._sync_steps)
        self.figure_view.set_chrome(False)
        tabs.setDocumentMode(True)
        route = "figure"
        # 程序的图解 / 仿真放第一个；题干整理的文字框只在没有更好的图时才出现
        viz_tabs = []
        scened = set()
        for i, t in enumerate(L.get("taskRes") or []):
            v = t.get("viz") or {}
            if v.get("scene"):
                viz_tabs.append((self._mount_scene(v["scene"], L.get("summary") or ""), f"仿真 · {t['title']}"))
                sv = self.scene_view
                if sv and scr and scr[0] == i and getattr(sv, "beat", None):
                    beats = scr[1]
                    self.linked_views.append((lambda k, sv=sv, beats=beats: sv.beat(beats[k]), len(beats)))
                    scened.add(i)
                elif sv:
                    self.linked_views.append((sv.apply_step,3))
                route = "viz"
            else:
                try:
                    w = make_viz(t)
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
                    w = None
                if w:
                    viz_tabs.append((w, t["title"]))
                    self.linked_views.append((w.go,len(w.stages)))
                    route = "viz"
        fallback = not L.get("figure")
        if L.get("figure") or not viz_tabs:
            tabs.addTab(self.figure_view, "分步图解" if not fallback else "题干条件")
        else:
            self.figure_view.setParent(tabs)   # 不显示，只负责分步节奏和导出
            self.figure_view.hide()
        primary_viz = tabs.count()
        for w, title in viz_tabs:
            tabs.addTab(w, title)
        from .figure.mistakes import for_lesson
        comparison=for_lesson(L)
        if comparison:
            wrong_view=FigureView(comparison)
            tabs.addTab(wrong_view,"错因对比")
            self.linked_views.append((wrong_view.go,len(wrong_view.stages)))
        from .physics_clock import make as make_clock
        for i, result in enumerate(L.get('taskRes') or []):
            if i in scened:   # 讲题仿真右上角已有同一时刻的 v–t 小图，不再单开一页
                continue
            clock=make_clock(result)
            if clock is not None:
                tabs.addTab(clock,'同一时刻双图')
        tabs.tabBar().setVisible(tabs.count() > 1)
        if route=="viz" or L.get("figure"):
            self._set_right(tabs)
            self.go_step(0)
            if route=="viz":
                tabs.setCurrentIndex(primary_viz)
            self._rebuild_chips()
            return route
        lab.load()
        e = lab.by_id.get(L.get("module")) if L.get("module") else None
        if e:
            try:
                tabs.addTab(self._mount_exp(e),"实验")
                tabs.tabBar().setVisible(tabs.count() > 1)
                self._set_right(tabs)
                self._rebuild_chips()
                return "exp"
            except Exception:  # noqa: BLE001
                traceback.print_exc()
        self._set_right(tabs)
        self.go_step(0)
        self._rebuild_chips()
        return "figure"

    def _sync_steps(self,k):
        view = self.figure_view
        count = max(1,len(view.stages)-1)
        for go,n in self.linked_views:
            go(min(n-1,round(k*(n-1)/count)))
        n = len(view.stages)
        self.step_no.setText(f"{k + 1}<span style='font-size:13px;color:{qc(T.faint).name()}'>/{n}</span>" if n > 1 else "")
        self.step_no.setVisible(n > 1)
        from .figure.links import linkify
        physics = bool(self.beats) or (self.L or {}).get("subject") == "物理"
        self.step_text.setText(linkify(mathfmt.to_html(view.stages[k], colors=physics), view.figure, qc(T.accent).name()))
        self.track.set_state(n, k)
        # 这一步要播一段动画时，自动播放多停一会儿，等画面走完
        b = self.beats[k] if self.beats and k < len(self.beats) else None
        anim = (float(b["play_to"]) - float(b.get("t") or 0)) if b and b.get("play_to") is not None else 0
        self.play_timer.setInterval(int(max(2800, anim * 1000 + 1600)))
        self.prev_btn.setEnabled(k > 0)
        self.next_btn.setEnabled(k < n - 1)

    def go_step(self,k):
        if self.figure_view is not None:
            self.figure_view.go(k)

    def export_lesson(self,path=None):
        if not self.L:
            self.status_l.setText("先完成分析，再导出讲题")
            return
        if path is None:
            path,_=QFileDialog.getSaveFileName(self,"导出讲题","讲题.pdf","PDF (*.pdf);;PNG 长图 (*.png)")
        if not path:
            return
        from .figure.export import export_lesson
        self._stop_play()
        view=self.figure_view
        old=view.k
        playing=view.timer.isActive()
        view.timer.stop()
        images=[]
        try:
            tabs=self.right.currentWidget()
            diagram=tabs.currentWidget() if isinstance(tabs,QTabWidget) else tabs
            canvas=getattr(diagram,"canvas",None)
            for i in range(min(64,max(1,len(self.L.get("steps") or view.stages)))):
                self.go_step(i)
                if isinstance(diagram,FigureView):
                    images.append(diagram.image())
                elif canvas is not None:
                    images.append(canvas.grab().toImage())
                elif getattr(diagram,"ctx",None):
                    images.append(diagram.ctx.stage.grab().toImage())
            export_lesson(self.L,path,images)
            self.status_l.setText("讲题已导出")
        except (OSError,ValueError,RuntimeError) as exc:
            self.status_l.setText("导出失败："+str(exc))
        finally:
            self.go_step(old)
            if playing:
                view.timer.start(view.speed.currentData())

    # ---- 流程
    def go(self, text=None):
        text = (text if text is not None else self.text.toPlainText()).strip()
        if not text:
            self.status_l.setText("先把题目粘贴进来")
            return
        self.rev += 1
        self._analysis_started = time.perf_counter()
        self.first_figure_ms = None
        self.first_native_ms=None
        self._metric_written=False
        self._metric_active=True
        self._active_problem = text
        self._live_task_key = None
        self._draft_figure_key = None
        self.L = None
        self.sync_actions()
        self._stop_play()
        self.answer_card.hide()
        self.step_bar.hide()
        self._draft_figure({})
        if self.worker:
            self.worker.cancelled = True
        rev = self.rev
        use_ai = self.engine_box.currentData() == "ai" and (llm.available() or self.engine_factory.__name__ != "<lambda>")
        lab.load()
        ids = set(lab.by_id)
        cat = catalog_text()
        self.go_btn.setEnabled(False)
        self.status_l.setText("开始分析…")
        factory = self.engine_factory

        def job(status, draft, cancelled):
            engine = factory(cancelled) if use_ai else None
            L = Lesson.analyze(text, engine, ids, cat, status, draft, rev)
            L["_engine"] = engine
            return L
        self._start(rev, job, self._on_done)

    def _start(self, rev, job, done):
        w = Worker(rev, job)
        w.status.connect(self._on_status)
        w.draft.connect(self._on_draft)
        w.failed.connect(self._on_fail)
        w.finished_ok.connect(done)
        self.worker = w
        self.workers.append(w)
        w.finished.connect(lambda wk=w: self.workers.remove(wk) if wk in self.workers else None)
        w.start()

    def _on_status(self, rev, m):
        if rev == self.rev:
            self.status_l.setText(m)

    def _on_draft(self, rev, d):
        if rev == self.rev and (d.get("summary") or d.get("steps") or d.get("figure") or d.get('taskRes')):
            self.show_draft(d)

    def _on_fail(self, rev, m):
        if rev == self.rev:
            self._record_timing(None,'error')
            self.go_btn.setEnabled(True)
            self.status_l.setText(f"分析失败：{m}")
            self._draft_figure({})

    def _on_done(self, rev, L):
        if rev != self.rev:   # 票据：过时的回答直接丢弃
            return
        self.go_btn.setEnabled(True)
        engine = L.pop("_engine", None)
        self.L = L
        route = self.visuals(L)
        from .realtime import has_diagram
        if has_diagram(L) and getattr(self,'first_native_ms',None) is None and hasattr(self,'_analysis_started'):
            self.first_native_ms=(time.perf_counter()-self._analysis_started)*1000
        self.render(L)
        Lesson.save_lesson(L)
        self.refresh_history()
        self.status_l.setText("分析完成")
        self._record_timing(L,'ok')
        if route == "exp" and engine:
            self._configure(L, engine)
        else:
            self.lesson_ready.emit(L)

    def _record_timing(self,L,status):
        if not getattr(self,'_metric_active',False) or getattr(self,'_metric_written',False):
            return
        self._metric_written=True
        from . import timing
        values=dict((L or {}).get('timings') or {})
        values.update(first_condition_ms=self.first_figure_ms,first_native_ms=getattr(self,'first_native_ms',None),total_ms=(time.perf_counter()-self._analysis_started)*1000,engine=(L or {}).get('engine'),status=status)
        try:
            timing.write(values)
        except (OSError,ValueError,TypeError):
            pass # Timing is optional; never discard a solved lesson for log failure.

    # ---- 第 2、3 步：配置实验、用读数核对
    def _configure(self, L, engine):
        e = lab.by_id[L["module"]]
        rev = self.rev
        ctx = self.ctx
        snapshot = []
        for c in ctx.ctrls:
            s = dict(c)
            if c["kind"] in ("select", "choice"):
                opts = c["options"]()
                s["options"] = lambda o=opts: o
            if c["kind"] == "slider":
                lo, hi = c["minF"](), c["maxF"]()
                s["minF"], s["maxF"] = (lambda v=lo: v), (lambda v=hi: v)
            snapshot.append(s)
        ctl_json = Lesson.controls(ctx)
        problem = L["problem"]

        def job(status, _draft, _c):
            status("第 2 步：配置实验参数…")
            user = f"## 题目\n{problem}\n\n## 第一步结果\n{json.dumps({k: L.get(k) for k in ('summary', 'knowns', 'steps', 'answer', 'scenario')}, ensure_ascii=False)}\n\n## 实验「{e.title}」原理\n{re.sub(r'<[^>]+>', ' ', getattr(e, 'info', '') or '')}\n\n## 控件列表\n{json.dumps(ctl_json, ensure_ascii=False)}\n\n## 任务\n执行协议中的第二步，只输出 JSON。"
            return llm.ask_json(engine, user, lambda j: Lesson.check2(j, snapshot, problem), status=status)["value"]

        def done(r2, B):
            if r2 != self.rev or self.ctx is not ctx:
                return
            Lesson.apply_settings(L, B, ctx)
            self.lesson_ready.emit(L)
            self.render(L)
            Lesson.save_lesson(L)
            verified = any(r.get("ok") for r in Lesson.task_rows(L) + ((L.get("calc") or {}).get("rows") or [])) and Lesson.status_of(L) != "conflict"
            if verified:
                L["verify"] = dict(consistent=True, rows=[], check="程序已经核对过，不再用实验读数核对。")
                self.render(L)
                self.status_l.setText("分析完成")
                return
            self.status_l.setText("第 3 步：等实验跑稳，读数核对…")
            QTimer.singleShot(2500 if L.get("applied", {}).get("ok") else 800, lambda: self._verify(L, engine, ctx))
        self._start(rev, job, done)

    def readouts(self):
        out = []
        panel = getattr(self, "exp_panel", None)
        if not panel:
            return ""
        for lb in panel.findChildren(QLabel, "out"):
            doc = QTextDocument()
            doc.setHtml(lb.text())
            for line in doc.toPlainText().split("\n"):
                line = re.sub(r"\s*\t\s*", "：", line.strip())
                if line:
                    out.append(line)
        return "\n".join(out)

    def _verify(self, L, engine, ctx):
        if self.ctx is not ctx:
            return
        ctx.draw()
        reading = self.readouts()
        if not reading.strip():
            L["verify"] = dict(consistent=True, rows=[], check="实验面板没有可读的数值，未核对。")
            self.render(L)
            self.status_l.setText("分析完成")
            return
        rev = self.rev

        def job(status, _d, _c):
            status("第 3 步：把答案和读数配对…")
            base = f"## 题目\n{L['problem']}\n\n## 解答\n{json.dumps(dict(steps=L.get('steps'), answer=L.get('answer')), ensure_ascii=False)}\n\n## 实验设置\n{'；'.join((L.get('applied') or {}).get('ok') or [])}\n\n## 实验读数\n{reading}\n\n## 任务\n执行协议中的第三步，只输出 JSON。"
            C = llm.ask_json(engine, base, lambda j: dict(ok=True, value=j) if isinstance(j.get("pairs", []), list) else dict(ok=False, errors=["pairs 必须是数组"]), repairs=1, status=status)["value"]
            rows = Lesson.compare_pairs(C.get("pairs"), reading)
            L["verify"] = dict(consistent=all(r["ok"] for r in rows), rows=rows, check="" if rows else (C.get("note") or "实验中没有与答案直接对应的读数，未核对。"))
            if not L["verify"]["consistent"]:
                status("数值与实验不符，正在重新检查解答…")
                bad = "\n".join(f"{r['quantity']}：原答案换算为 {r['answer']}，实验读数「{r['readout']}」为 {r['measured']}" for r in rows if not r["ok"])
                Lesson.correct(L, f"实验按精确公式或数值模拟计算，读数可信，除非实验设置与题目不对应。\n实验设置：{'；'.join((L.get('applied') or {}).get('ok') or [])}\n不符的项目：\n{bad}", engine, status)
            return L

        def done(r2, _L):
            if r2 == self.rev:
                self.render(L)
                Lesson.save_lesson(L)
                self.status_l.setText("分析完成")
        self._start(rev, job, done)

    # ---- 记录
    def refresh_history(self):
        self.hist.clear()
        for x in Lesson.history():
            it = QListWidgetItem((x.get("topic") or x.get("problem") or "题目")[:24])
            it.setData(Qt.ItemDataRole.UserRole, x.get("ticket", {}).get("id"))
            it.setToolTip(str(x.get("problem") or "")[:200])
            self.hist.addItem(it)

    def open_history(self, it):
        qid = it.data(Qt.ItemDataRole.UserRole)
        L = next((x for x in Lesson.history() if x.get("ticket", {}).get("id") == qid), None)
        if L:
            self.rev += 1
            self.L = L
            self.text.setPlainText(L.get("problem") or "")
            self.visuals(L)
            self.render(L)

    def shutdown(self):
        self.rev += 1
        self.play_timer.stop()
        self._close_ctx()
        for view in self.right.findChildren(FigureView):
            view.timer.stop()
            view.transition.stop()
        for w in list(self.workers):
            w.cancelled = True
            w.wait(1500)


_ = tokens
