"""讲解脚本：物理题由程序按算出的数一步一步写讲解，每一步说清楚画面停在哪个时刻、讲到哪几个量。

一步（beat）= dict(say=讲解文字, lv=画到第几层 0..2, t=从哪个时刻开始, play_to=播到哪个时刻（None 表示停住）, focus=[讲到的量])
focus 里的名字和仿真图上箭头 / 标注的文字一致（vx、mg、R、T……），画面据此加粗发光，其余变淡。

数全部来自题目参数和程序公式，不经过 AI；AI 的讲解仍在「完整解答」里。
只写目前有仿真的题型；其他题型返回 None，页面照旧按图解分步。
"""
from __future__ import annotations

import math


def n(x) -> str:
    """讲解里的数：整数就写整数，否则留 6 位有效数字（显示时再约成 3 位并写 ≈）。"""
    if not math.isfinite(x):
        return "—"
    if abs(x - round(x)) < 1e-9 * max(1.0, abs(x)):
        return str(int(round(x)))
    return f"{x:.6g}"


def projectile(p):
    v0, ang, h0, g = float(p.get("v0", 0)), float(p.get("angle", 0)), float(p.get("h0", 0)), float(p.get("g", 9.8))
    th = math.radians(ang)
    vx, vy0 = v0 * math.cos(th), v0 * math.sin(th)
    T = (vy0 + math.sqrt(vy0 * vy0 + 2 * g * h0)) / g
    R, H = vx * T, h0 + vy0 * vy0 / (2 * g)
    vye = vy0 - g * T
    ve = math.hypot(vx, vye)
    flat = abs(ang) < 1e-9
    known = f"已知：初速度 v_0 = {n(v0)} m/s" + ("，水平抛出" if flat else f"，与水平方向成 θ = {n(ang)}°") + (f"，离地高度 h_0 = {n(h0)} m" if h0 > 0 else "，从地面抛出") + f"，g = {n(g)} m/s^2。"
    beats = [dict(say=known, lv=0, t=0, focus=["v₀", "h₀", "θ"])]
    if flat:
        beats.append(dict(say=f"把运动拆成两个方向：水平方向不受力，做匀速直线运动，v_x = v_0 = {n(vx)} m/s；竖直方向只受重力，从 v_y = 0 开始做自由落体。",
                          lv=1, t=0, play_to=T * 0.45, focus=["vx", "vy"]))
        beats.append(dict(say=f"竖直方向：h_0 = ½g·T^2，所以 T = sqrt(2h_0/g) = sqrt(2×{n(h0)}/{n(g)}) = {n(T)} s。", lv=2, t=T * 0.45, play_to=T, focus=["vy", "T"]))
    else:
        beats.append(dict(say=f"把初速度分解：v_x = v_0 cosθ = {n(vx)} m/s，v_y = v_0 sinθ = {n(vy0)} m/s。水平方向匀速，竖直方向是加速度为 g 的匀变速运动。",
                          lv=1, t=0, play_to=T * 0.3, focus=["vx", "vy", "v"]))
        if vy0 > 0:
            tp = vy0 / g
            beats.append(dict(say=f"竖直分速度减到 0 时到最高点：t = v_y/g = {n(tp)} s，最大高度 H = h_0 + v_y^2/(2g) = {n(H)} m。", lv=2, t=T * 0.3, play_to=min(tp, T), focus=["vy", "H"]))
        beats.append(dict(say=f"竖直方向：h_0 + v_y T − ½g·T^2 = 0，解得飞行时间 T = {n(T)} s。", lv=2, t=min(vy0 / g, T) if vy0 > 0 else 0, play_to=T, focus=["T"]))
    beats.append(dict(say=f"水平方向一直匀速：R = v_x T = {n(vx)} × {n(T)} = {n(R)} m。", lv=2, t=T, focus=["R", "vx"]))
    beats.append(dict(say=f"落地速度把两个分量合起来：v_y = {n(vye)} m/s，v = sqrt(v_x^2 + v_y^2) = {n(ve)} m/s。", lv=2, t=T, focus=["v", "vx", "vy"]))
    return beats


def incline(p):
    ang, mu, m, L, g = float(p.get("angle", 30)), float(p.get("mu", 0)), float(p.get("m", 1)), float(p.get("L", 1)), float(p.get("g", 9.8))
    th = math.radians(ang)
    s, c = math.sin(th), math.cos(th)
    N = m * g * c
    a_raw = g * (s - mu * c)
    beats = [dict(say=f"先画受力：重力 mg = {n(m * g)} N 竖直向下，支持力 N 垂直斜面向上" + ("，摩擦力 f 沿斜面向上（阻碍下滑）。" if mu > 0 else "；斜面光滑，没有摩擦力。"),
                  lv=1, t=0, focus=["mg", "N", "f"])]
    if a_raw <= 1e-9:
        beats.append(dict(say=f"比较 μ = {n(mu)} 和 tanθ = {n(s / c)}：μ ≥ tanθ，最大静摩擦力挡得住下滑分力，物块保持静止，f = mg sinθ = {n(m * g * s)} N。", lv=1, t=0, focus=["f", "mg"]))
        return beats
    f = mu * N
    T = math.sqrt(2 * L / a_raw)
    beats.append(dict(say=f"垂直斜面方向受力平衡：N = mg cosθ = {n(N)} N" + (f"，滑动摩擦力 f = μN = {n(mu)} × {n(N)} = {n(f)} N。" if mu > 0 else "。"),
                      lv=1, t=0, focus=["N", "f"]))
    beats.append(dict(say=f"沿斜面方向用牛顿第二定律：mg sinθ − f = ma，所以 a = g(sinθ − μcosθ) = {n(a_raw)} m/s^2。", lv=2, t=0, focus=["F合", "a"]))
    beats.append(dict(say=f"从静止开始匀加速滑完 L = {n(L)} m：L = ½a·t^2，t = sqrt(2L/a) = {n(T)} s。", lv=2, t=0, play_to=T, focus=["L", "t"]))
    beats.append(dict(say=f"到底端的速度：v = a·t = {n(a_raw)} × {n(T)} = {n(a_raw * T)} m/s。", lv=2, t=T, focus=["v"]))
    return beats


WRITERS = dict(projectile=projectile, incline=incline)


def for_lesson(L):
    """第一个有仿真的程序题型 → (任务下标, 讲解步骤)；没有就 None。"""
    for i, t in enumerate(L.get("taskRes") or []):
        sc = (t.get("viz") or {}).get("scene") or {}
        fn = WRITERS.get(sc.get("kind"))
        if fn and not t.get("failed_checks"):
            try:
                beats = fn(sc.get("params") or {})
            except (TypeError, ValueError, ZeroDivisionError):
                continue
            if beats:
                return i, beats
    return None
