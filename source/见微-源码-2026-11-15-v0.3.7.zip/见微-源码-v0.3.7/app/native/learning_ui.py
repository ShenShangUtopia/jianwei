"""Review queue and a quiet daily summary, using existing application styles."""
import time
from datetime import date
from PySide6.QtCore import Qt,QRectF,QTimer
from PySide6.QtGui import QPainter
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QPlainTextEdit,QDialog
from . import learning
from .design.tokens import T,qc,font
from .design.widgets import qss


class History(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.rows=[]
        self.setMinimumHeight(115)

    def paintEvent(self,event):
        p=QPainter(self)
        p.setFont(font(12))
        maximum=max([1]+[r['count'] for r in self.rows])
        width=self.width()/max(1,len(self.rows))
        for i,row in enumerate(self.rows):
            x=i*width+12
            h=row['count']/maximum*65
            p.fillRect(QRectF(x,80-h,max(10,width-24),h),qc(T.accent))
            p.setPen(qc(T.fg))
            p.drawText(QRectF(x,83,width-24,22),int(Qt.AlignmentFlag.AlignCenter),row['day'][5:])
            p.drawText(QRectF(x,58-h,width-24,20),int(Qt.AlignmentFlag.AlignCenter),str(row['count']))
        p.end()


class Review(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        from .bank.data import bank
        bank.load()
        self.bank=bank
        self.queue=learning.due()
        self.index=0
        self.current=None
        self.started=time.monotonic()
        self.setObjectName('jw2')
        self.setStyleSheet(qss())
        self.setWindowTitle('到期复习')
        self.resize(780,650)
        root=QVBoxLayout(self)
        self.title=QLabel()
        root.addWidget(self.title)
        self.front=QPlainTextEdit()
        self.front.setReadOnly(True)
        root.addWidget(self.front,1)
        self.answer=QPlainTextEdit()
        self.answer.setReadOnly(True)
        self.answer.hide()
        root.addWidget(self.answer,1)
        show=QPushButton('查看答案后自评')
        show.clicked.connect(self.answer.show)
        root.addWidget(show)
        row=QHBoxLayout()
        self.yes=QPushButton('记住了')
        self.no=QPushButton('没记住')
        self.skip=QPushButton('本次跳过')
        self.yes.clicked.connect(lambda:self.grade(True))
        self.no.clicked.connect(lambda:self.grade(False))
        self.skip.clicked.connect(self.next)
        for button in (self.yes,self.no,self.skip):
            row.addWidget(button)
        root.addLayout(row)
        self.status=QLabel('这是记忆自评，不计作自动判卷正确率；今天同一项目只更新一次排期。')
        self.status.setWordWrap(True)
        root.addWidget(self.status)
        self.render()

    def render(self):
        self.started=time.monotonic()
        self.answer.hide()
        if self.index>=len(self.queue):
            self.title.setText('本次复习结束')
            self.front.setPlainText('已处理当前队列。跳过的项目仍保留原排期；以后打开可继续。')
            self.yes.setEnabled(False);self.no.setEnabled(False);self.skip.setEnabled(False)
            self.current=None
            return
        key,item=self.queue[self.index]
        self.current=key
        self.title.setText(f"{self.index+1} / {len(self.queue)}　{item['title']}")
        self.yes.setEnabled(True);self.no.setEnabled(True)
        if item['kind']=='question':
            q=self.bank.by_id.get(item['ref'])
            if q:
                self.front.setPlainText(q.get('stem',''))
                self.answer.setPlainText(str(q.get('answer',''))+'\n\n'+'\n'.join(str(x) for x in q.get('steps',[])))
            else:
                self.front.setPlainText('原题暂不在当前题库中。记录保留，可跳过并检查导入题库。')
                self.answer.setPlainText('')
                self.yes.setEnabled(False);self.no.setEnabled(False)
        else:
            card=item['card']
            self.front.setPlainText(str(card.get('n','知识卡'))+'\n\n先回忆定义、公式与常见陷阱。')
            self.answer.setPlainText(str(card.get('d',''))+'\n\n'+'\n'.join(card.get('f',[]))+'\n\n'+'\n'.join(card.get('p',[])))

    def grade(self,correct):
        if self.current is None:
            return
        if not self.answer.isVisible():
            self.status.setText('先查看答案并核对，再选择是否记住。')
            return
        try:
            item=learning.grade(self.current,correct,time.monotonic()-self.started)
            self.status.setText('已更新，下次复习：'+item['due'])
        except Exception as exc:
            self.status.setText('未更新排期：'+str(exc))
            return
        self.next()

    def next(self):
        self.index+=1
        self.render()


class Daily(QWidget):
    def __init__(self,ctx,parent=None):
        super().__init__(parent)
        self.ctx=ctx
        root=QVBoxLayout(self)
        root.setContentsMargins(0,0,0,0)
        self.summary=QLabel()
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)
        self.history=History()
        root.addWidget(self.history)
        self.details=QLabel()
        self.details.setWordWrap(True)
        root.addWidget(self.details)
        self.nodes=QLabel()
        self.nodes.setWordWrap(True)
        root.addWidget(self.nodes)
        row=QHBoxLayout()
        self.start=QPushButton('开始到期复习')
        self.start.clicked.connect(self.review)
        refresh=QPushButton('刷新记录')
        refresh.clicked.connect(self.refresh)
        row.addWidget(self.start);row.addWidget(refresh);row.addStretch(1)
        root.addLayout(row)
        self.timer=QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(60000)
        self._stale=False
        self.refresh()

    def _tick(self):
        # 见微常驻托盘：看不见这张卡时不用每分钟读题库和记录，记一笔，等再显示时补刷
        if self.isVisible():
            self.refresh()
        else:
            self._stale=True

    def showEvent(self,event):
        super().showEvent(event)
        if self._stale:
            self._stale=False
            QTimer.singleShot(0,self.refresh)

    def refresh(self):
        try:
            from .bank.data import bank
            from .bank.study import Stars
            from .data_import import run_once
            run_once()
            bank.load()
            learning.sync_questions(Stars().ids,bank.by_id)
            rows=learning.daily()
            today=rows[-1]
            count=len(learning.due())
            self.summary.setText(f"今天到期 {count} 项；已记录作答 {today['attempts']} 次、复习 {today['self_review']} 项，用时约 {today['seconds']/60:.1f} 分钟。")
            self.start.setEnabled(count>0)
            rate=f"{today['correct']/today['graded']:.0%}（{today['graded']}次）" if today['graded'] else '暂无可判定的选择题'
            subjects='、'.join(f'{k} {v}次' for k,v in today['subjects'].items()) or '暂无记录'
            self.details.setText('自动核对正确率：'+rate+'。仅计可明确核对的选择题，自评与相似度对照另记。\n科目分布：'+subjects+'。图中为每日作答与复习活动数。')
            self.history.rows=rows;self.history.update()
        except Exception:
            self.summary.setText('复习或学习记录暂不可读取，原文件已保留；可先到设置备份数据。')
            self.start.setEnabled(False)
        lines=[]
        for node in self.ctx.cfg.get('milestones') or []:
            try:
                gap=(date.fromisoformat(node['date'])-date.today()).days
            except (TypeError,KeyError,ValueError):
                continue
            if gap>=0:
                text=f"{node.get('label') or '自定节点'}：{node['date']}，还有{gap}天"
                if gap<=7:
                    text+='。建议先复习到期错题和薄弱知识卡，再安排新题。'
                lines.append((gap,text))
        self.nodes.setText('\n'.join(text for _,text in sorted(lines)[:3]) or '尚未添加考试节点；可在倒计时设置中填写自己的日期。')

    def review(self):
        dialog=Review(self)
        dialog.exec()
        self.refresh()


def card(ctx):
    # The host calls this after QApplication exists, matching ui_kit's contract.
    from ui_kit import Card
    item=Card('复习与学习记录','固定间隔：1、3、7、14、30天；不排名、不设打卡目标')
    item.add(Daily(ctx))
    return item
