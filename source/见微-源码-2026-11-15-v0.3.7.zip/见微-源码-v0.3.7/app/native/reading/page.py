"""读文页：左边原文（直接打字或粘贴，分析结果画成彩色下划线），右边是光标所在字词的详解和这一句的译文、句式。

实时：每次停手 0.2 秒整段离线标注；句子写完整后自动送 DeepSeek 精析（几句一批，按顺序），结果缓存。
学习窗口的「读文」模式和主窗口的「读文」页用的是同一个控件。
"""
from __future__ import annotations

import html
import traceback

from PySide6.QtCore import QRectF, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QFont, QKeySequence, QPainter, QPen, QShortcut, QTextBlockFormat, QTextCursor
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QPushButton, QSplitter, QTextBrowser, QTextEdit, QVBoxLayout,
                               QWidget)

from ..design import tokens
from ..design.tokens import T, css, qc
from ..design.widgets import Segmented, qss
from ..kit.home import load_json, save_json
from . import analyze
from .analyze import tidy

DRAFT_FILE = "reading-draft.json"

# 下划线颜色：键是 token 的 kind，值是数据色板里的名字（随昼夜、皮肤变）
KIND_COLOR = {
    "wyw": [("实词", "c1"), ("虚词", "c2"), ("通假", "c5"), ("古今异义", "c3"), ("词类活用", "c4"), ("固定结构", "c6"),
            ("专有名词", "faint")],
    "en": [("主干", "c1"), ("修饰", "c3"), ("从句引导", "c2"), ("短语", "c5")],
}
LEGEND_TIP = {
    "wyw": "颜色标出有考点的字词；没联网时按考纲词表标，联网后按本句的实际用法重标",
    "en": "主干＝主谓宾表，修饰＝定状补和同位语；没联网时只标短语和从句引导词",
}

SAMPLES = {
    "wyw": "古之学者必有师。师者，所以传道受业解惑也。人非生而知之者，孰能无惑？惑而不从师，其为惑也，终不解矣。"
           "生乎吾前，其闻道也固先乎吾，吾从而师之；生乎吾后，其闻道也亦先乎吾，吾从而师之。",
    "en": "When the old bridge was finally reopened, the villagers who had waited for years gathered on the bank. "
          "Not only did they cheer, but they also brought food to share with the workers. "
          "It was the engineer's patience that made the difference, and she has been invited to speak at the school next week.",
}

HELP = {
    "wyw": "在左边输入或粘贴文言文。<br>· 字词下的彩色线：有考点的实词、虚词、通假字、古今异义等。<br>"
           "· 光标放到哪个字上，这里就讲哪个字：本句义、词性、用法、考纲里的其他义项。<br>"
           "· 句子写完（有句号、问号等）后会自动送 DeepSeek 逐字精析，并给出整句翻译和句式。",
    "en": "在左边输入或粘贴英语文章。<br>· 单词下的彩色线：句子主干、修饰成分、从句引导词、固定搭配。<br>"
          "· 光标放到哪个词上，这里就讲哪个词：词义、词性、句子成分、语法要点。<br>"
          "· 句子写完后会自动送 DeepSeek 精析：整句翻译、主干、从句、时态语态。",
}


_ALIVE: set = set()     # 还在跑的请求线程：页面被重建（换皮肤、换昼夜）时线程对象不能跟着销毁


_latin: str | None = None


def text_family(lang: str) -> str:
    """原文用的字体：文言用宋体一路；英语用正经的西文正文字体（通用名 serif 在有的机器上会落到打字机字体）。"""
    global _latin
    if lang == "wyw":
        return tokens.family("serif")
    if _latin is None:
        from PySide6.QtGui import QFontDatabase
        have = set(QFontDatabase.families())
        _latin = next((x for x in ("Georgia", "Cambria", "Constantia", "Charter", "Segoe UI") if x in have), tokens.family("ui"))
    return _latin


class Worker(QThread):
    done = Signal(str, object, object)        # lang, batch, {id: 结果}
    failed = Signal(str, object, str)

    def __init__(self, lang, batch, context):
        super().__init__()
        self.lang, self.batch, self.context = lang, batch, context
        _ALIVE.add(self)
        self.finished.connect(lambda: _ALIVE.discard(self))

    def run(self):
        try:
            result = analyze.ask(self.lang, self.batch, self.context)
            cache = analyze.shared_cache()  # 页面可能已经没了：结果先进缓存，重建的页面照样用得上
            for b in self.batch:
                if isinstance(result, dict) and result.get(b["id"]):
                    cache.put(self.lang, b["text"], result[b["id"]])
            self.done.emit(self.lang, self.batch, result)
        except Exception as e:  # noqa: BLE001  任何失败都只影响这几句，界面照常
            if type(e).__name__ != "AskError":
                traceback.print_exc()
            self.failed.emit(self.lang, self.batch, str(e) or type(e).__name__)


class ReadEdit(QTextEdit):
    """原文编辑区：照常打字，分析结果在字下面画粗的彩色短线，光标所在的字词衬一块底色。"""

    def __init__(self):
        super().__init__()
        self.setAcceptRichText(False)
        self.setTabChangesFocus(True)
        self.tokens: list[dict] = []
        self.sel: dict | None = None
        self.sentence: tuple[int, int] | None = None
        self.pending: list[tuple[int, int]] = []
        self.lang = "wyw"
        self.document().setDocumentMargin(20)

    # 行距加大，下划线有地方画
    def spacing(self):
        """所有段落统一行高。不发 textChanged（否则会和实时分析互相触发）。
        调行距并进上一步编辑（joinPreviousEditBlock），撤销时跟着那一步一起回去；
        不能用 setUndoRedoEnabled(False) 绕开——那会把整个撤销记录清空，Ctrl+Z 就没用了。"""
        doc = self.document()
        self._blocks = doc.blockCount()
        h = 185 if self.lang == "wyw" else 170
        b = doc.begin()
        while b.isValid() and b.blockFormat().lineHeight() == h:
            b = b.next()
        if not b.isValid():
            return
        was = self.blockSignals(True)
        c = QTextCursor(doc)
        c.joinPreviousEditBlock()
        c.select(QTextCursor.SelectionType.Document)
        fmt = QTextBlockFormat()
        fmt.setLineHeight(h, 1)     # 1 = ProportionalHeight
        c.mergeBlockFormat(fmt)
        c.endEditBlock()
        self.blockSignals(was)

    def set_plain(self, text):
        self.setPlainText(text)
        self.spacing()

    def _rects(self, a, b):
        """[a, b) 这段字在视口里的矩形；跨行时一行一块。"""
        c = QTextCursor(self.document())
        c.setPosition(a)
        r1 = self.cursorRect(c)
        c.setPosition(b)
        r2 = self.cursorRect(c)
        if abs(r1.top() - r2.top()) < 2 and r2.left() >= r1.left():
            return [QRectF(r1.left(), r1.top(), r2.left() - r1.left(), r1.height())]
        out, fm, text = [], self.fontMetrics(), self.document().toPlainText()
        for i in range(a, b):       # 跨行：逐字量，同一行的并成一块
            c.setPosition(i)
            r = self.cursorRect(c)
            c.setPosition(i + 1)
            n = self.cursorRect(c)
            right = n.left() if abs(n.top() - r.top()) < 2 else r.left() + fm.horizontalAdvance(text[i] if i < len(text) else " ")
            if out and abs(out[-1].top() - r.top()) < 2:
                out[-1].setRight(right)
            else:
                out.append(QRectF(r.left(), r.top(), right - r.left(), r.height()))
        return out

    def paintEvent(self, e):  # noqa: N802
        super().paintEvent(e)
        p = QPainter(self.viewport())
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        h = self.viewport().height()
        p.setPen(Qt.PenStyle.NoPen)
        if self.sentence:       # 底色是半透明的，叠在字上也不挡字
            p.setBrush(qc(T.fg, 0.035))
            for r in self._rects(*self.sentence):
                if -40 < r.top() < h:
                    p.drawRoundedRect(r.adjusted(-3, 1, 3, -1), 4, 4)
        if self.sel:
            p.setBrush(qc(T.accent, 0.16))
            for r in self._rects(self.sel["start"], self.sel["end"]):
                p.drawRoundedRect(r.adjusted(-2, 2, 2, -1), 4, 4)
        colors = dict(KIND_COLOR[self.lang])
        width = 2.6 if self.lang == "wyw" else 2.2
        for a, b in self.pending:       # 正在精析的句子：句尾一小段虚线
            for r in self._rects(max(a, b - 1), b)[-1:]:
                pen = QPen(qc(T.faint), 1.4, Qt.PenStyle.DotLine)
                p.setPen(pen)
                y = r.bottom() - 1
                p.drawLine(int(r.right() + 4), int(y), int(r.right() + 22), int(y))
        for t in self.tokens:
            name = colors.get(t.get("kind"))
            if not name:
                continue
            rects = self._rects(t["start"], t["end"])
            if rects and rects[0].top() > h:
                break       # tokens 按位置排好：后面的都在视口下面
            for r in rects:
                if r.bottom() < 0:
                    continue
                pen = QPen(qc(T[name], 0.95 if t.get("src") == "ai" else 0.6), width)
                pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                if t.get("src") != "ai":
                    pen.setDashPattern([2.2, 1.6])       # 离线的是推测：虚线
                p.setPen(pen)
                y = r.bottom() - 2
                p.drawLine(int(r.left() + 3), int(y), int(r.right() - 3), int(y))
        p.end()


class ReadingPage(QWidget):
    def __init__(self, compact: bool = False):
        super().__init__()
        self.setObjectName("readingPage")
        drafts = load_json(DRAFT_FILE, {}) or {}
        self.drafts = drafts if isinstance(drafts, dict) else {}
        self.lang = self.drafts.get("lang") if self.drafts.get("lang") in analyze.LANGS else "wyw"
        self.cache = analyze.shared_cache()
        self.sents: list[dict] = []
        self.inflight: set[str] = set()
        self.failed: dict[str, str] = {}
        self.worker: Worker | None = None
        self._workers: list[Worker] = []
        self.engine_note = ""

        v = QVBoxLayout(self)
        self.compact = compact      # compact：放进主窗口的页面里，不要自己的标题、底色和外边距
        v.setContentsMargins(*((0, 0, 0, 0) if compact else (24, 16, 24, 16)))
        v.setSpacing(10)
        top = QHBoxLayout()
        top.setSpacing(10)
        if not compact:
            title = QLabel("读文")
            title.setObjectName("readTitle")
            top.addWidget(title)
        self.seg = Segmented(list(analyze.LANGS.items()), self.lang)
        self.seg.changed.connect(self.set_lang)
        top.addWidget(self.seg)
        self.status = QLabel()
        self.status.setObjectName("readStatus")
        top.addWidget(self.status, 1)
        self.b_sample = QPushButton("示例")
        self.b_sample.setToolTip("放一段示例文章进来看看效果")
        self.b_sample.clicked.connect(self.load_sample)
        self.b_clear = QPushButton("清空")
        self.b_clear.clicked.connect(lambda: self.edit.set_plain(""))
        self.b_go = QPushButton("精析全文")
        self.b_go.setObjectName("pri")
        self.b_go.setToolTip("把还没精析的句子全部送 DeepSeek，包括没写完的最后一句（Ctrl+Enter）")
        self.b_go.clicked.connect(self.analyze_all)
        for b in (self.b_sample, self.b_clear, self.b_go):
            top.addWidget(b)
        v.addLayout(top)

        split = QSplitter(Qt.Orientation.Horizontal)
        split.setChildrenCollapsible(False)
        split.setHandleWidth(10)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(6)
        self.edit = ReadEdit()
        self.edit.setObjectName("readEdit")
        lv.addWidget(self.edit, 1)
        self.legend = Legend()
        lv.addWidget(self.legend)
        split.addWidget(left)
        self.detail = QTextBrowser()
        self.detail.setObjectName("readDetail")
        self.detail.setOpenLinks(False)
        self.detail.setMinimumWidth(320)
        split.addWidget(self.detail)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        split.setSizes([640, 420])
        v.addWidget(split, 1)

        self._off = QTimer(self, singleShot=True, interval=200, timeout=self.run_offline)
        self._ai = QTimer(self, singleShot=True, interval=1400, timeout=self.schedule_ai)
        self.edit.textChanged.connect(self._changed)
        self.edit.cursorPositionChanged.connect(self.sync_cursor)
        QShortcut(QKeySequence("Ctrl+Return"), self, activated=self.analyze_all)
        from PySide6.QtCore import QCoreApplication
        QCoreApplication.instance().aboutToQuit.connect(self.stop)     # 退出时别留下还在跑的请求线程
        self.apply_theme()
        self.edit.set_plain(self.drafts.get(self.lang, ""))
        self.run_offline()

    # ---------------------------------------------------------------- 语种、示例、草稿
    def set_lang(self, lang):
        if lang == self.lang or lang not in analyze.LANGS:
            return
        self.drafts[self.lang] = self.edit.toPlainText()
        self.lang = lang
        self.seg.set_value(lang)
        self.failed.clear()
        self.apply_theme()
        self.edit.set_plain(self.drafts.get(lang, ""))
        self.run_offline()

    def load_sample(self):
        self.edit.set_plain(SAMPLES[self.lang])
        c = self.edit.textCursor()
        c.setPosition(0)
        self.edit.setTextCursor(c)
        self.edit.setFocus()

    def set_text(self, text, lang=None):
        """外部送进来的文字（框选、粘贴）：语种不给就按有没有汉字猜。
        课件里取出来的字带着版面换行，先接回成段；原来的内容用 Ctrl+Z 能找回。"""
        text = str(text or "").strip()
        if lang is None:
            han = sum(1 for ch in text if "一" <= ch <= "鿿")
            lang = "wyw" if han >= max(1, len(text) // 4) else "en"
        text = tidy(text, lang)
        self.set_lang(lang)
        old = self.edit.toPlainText()
        if old.strip() and old != text:
            c = QTextCursor(self.edit.document())     # 整段替换但留在撤销记录里
            c.beginEditBlock()       # 换字和调行距算一步撤销
            c.select(QTextCursor.SelectionType.Document)
            c.insertText(text)
            self.edit.spacing()
            c.endEditBlock()
            self.edit.moveCursor(QTextCursor.MoveOperation.Start)
        else:
            self.edit.set_plain(text)
        self.run_offline()

    def _save_draft(self):
        self.drafts[self.lang] = self.edit.toPlainText()
        self.drafts["lang"] = self.lang
        try:
            save_json(DRAFT_FILE, self.drafts)
        except OSError:
            pass

    # ---------------------------------------------------------------- 实时分析
    def _changed(self):
        self._off.start()
        self._ai.start()

    def run_offline(self):
        if self.edit.document().blockCount() != getattr(self.edit, "_blocks", -1):
            self.edit.spacing()         # 新分出来的段落也用同样的行高
        text = self.edit.toPlainText()
        sents = analyze.offline(self.lang, text)
        for i, s in enumerate(sents):
            hit = self.cache.get(self.lang, s["text"])
            if hit:
                sents[i] = analyze.merge(self.lang, s, hit)
            elif self.cache.key(self.lang, s["text"]) in self.inflight:
                s["state"] = "pending"
            elif self.cache.key(self.lang, s["text"]) in self.failed:
                s["state"] = "error"
                s["error"] = self.failed[self.cache.key(self.lang, s["text"])]
        self.sents = sents
        self.edit.lang = self.lang
        self.edit.tokens = [t for s in sents for t in s["tokens"]]
        self.edit.pending = [(s["start"], s["end"]) for s in sents if s["state"] == "pending"]
        self.sync_cursor()
        self.update_status()
        self._save_draft()
        self.edit.viewport().update()

    def _todo(self, everything=False):
        text = self.edit.toPlainText()
        at = self.edit.textCursor().position() if self.edit.hasFocus() else None
        out = []
        for s in self.sents:
            k = self.cache.key(self.lang, s["text"])
            if s["state"] in ("ai", "ai-partial") or k in self.inflight or (k in self.failed and not everything):
                continue
            if everything or analyze.complete(self.lang, s, text, at):
                out.append(s)
        return out

    def schedule_ai(self, everything=False):
        from ..analysis import llm
        if self.worker is not None or not llm.available():
            return
        todo = self._todo(everything)
        if not todo:
            self._everything = False
            return
        batch = [dict(id=i, text=s["text"]) for i, s in enumerate(todo[:analyze.BATCH])]
        for b in batch:
            self.inflight.add(self.cache.key(self.lang, b["text"]))
            self.failed.pop(self.cache.key(self.lang, b["text"]), None)
        self.worker = Worker(self.lang, batch, self.edit.toPlainText())
        self.worker.done.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.finished.connect(self._finished)
        self._workers.append(self.worker)
        self.worker.start()
        self._everything = everything
        self.run_offline()

    def analyze_all(self):
        from ..analysis import llm
        if not llm.available():
            self.engine_note = "没有 DeepSeek 密钥，只能用离线词表：到「析题」页或主窗口设置里填密钥"
            self.update_status()
            return
        self.failed.clear()
        self.schedule_ai(everything=True)

    def _done(self, lang, batch, result):
        for b in batch:
            self.inflight.discard(self.cache.key(lang, b["text"]))
            r = result.get(b["id"]) if isinstance(result, dict) else None
            if not r:           # 有结果的已经在线程里存进缓存了
                self.failed[self.cache.key(lang, b["text"])] = "这一句没有拿到结果"
        self.engine_note = ""

    def _failed(self, lang, batch, msg):
        for b in batch:
            k = self.cache.key(lang, b["text"])
            self.inflight.discard(k)
            self.failed[k] = msg
        self.engine_note = msg

    def _finished(self):
        w = self.sender()
        if w in self._workers:
            self._workers.remove(w)
        if w is self.worker:
            self.worker = None
        self.run_offline()
        QTimer.singleShot(0, lambda: self.schedule_ai(getattr(self, "_everything", False)))

    # ---------------------------------------------------------------- 光标 → 详解
    def at_cursor(self):
        pos = self.edit.textCursor().position()
        sent = next((s for s in self.sents if s["start"] <= pos <= s["end"]), None)
        tok = None
        if sent:
            tok = next((t for t in sent["tokens"] if t["start"] <= pos < t["end"]), None)
            if tok is None:     # 光标在词尾也算这个词
                tok = next((t for t in sent["tokens"] if t["end"] == pos), None)
        return sent, tok

    def sync_cursor(self):
        sent, tok = self.at_cursor()
        self.edit.sel = tok
        self.edit.sentence = (sent["start"], sent["end"]) if sent and len(self.sents) > 1 else None
        self.detail.setHtml(self.render(sent, tok))
        self.edit.viewport().update()

    def update_status(self):
        from ..analysis import llm
        n = len(self.sents)
        done = sum(1 for s in self.sents if s["state"] in ("ai", "ai-partial"))
        busy = len(self.inflight)
        if self.engine_note:
            text, col = "⚠ " + self.engine_note, T.bad
        elif not llm.available():
            text, col = ("○ 离线词表 · 没有 DeepSeek 密钥，只标" + ("考纲字词" if self.lang == "wyw" else "短语、从句引导词和时态")), T.muted
        elif busy:
            text, col = f"● 正在精析 {busy} 句…（已完成 {done}/{n}）", T.accent
        elif n:
            text, col = f"● DeepSeek 实时精析 · {done}/{n} 句", T.ok
        else:
            text, col = "● DeepSeek 已就绪：输入或粘贴文章即开始", T.ok
        self.status.setText(text)
        self.status.setStyleSheet(f"color:{css(col)};")
        self.status.setToolTip(self.engine_note)

    # ---------------------------------------------------------------- 详解排版
    def render(self, sent, tok):
        if not self.sents:
            return self._page(f"<p style='color:{css(T.muted)};line-height:170%'>{HELP[self.lang]}</p>")
        parts = []
        if tok:
            parts.append(self._token_html(tok))
        elif sent:
            parts.append(f"<p style='color:{css(T.faint)}'>把光标放到某个字词上看它的解释。</p>")
        if sent:
            parts.append(self._sentence_html(sent))
        return self._page("".join(parts))

    def _page(self, body):
        return (f"<html><body style='font-family:\"{tokens.family('ui')}\";font-size:13.5px;color:{css(T.fg)}'>"
                f"{body}</body></html>")

    def _chip(self, text, col):
        return (f"<span style='background:{css(col, 0.14)};color:{css(col)};font-size:11.5px;font-weight:700'>"
                f"&nbsp;{html.escape(text)}&nbsp;</span>&nbsp;")

    def _row(self, label, value):
        if not value:
            return ""
        return (f"<tr><td style='color:{css(T.muted)};padding:3px 12px 3px 0;white-space:nowrap' valign='top'>{label}</td>"
                f"<td style='padding:3px 0'>{html.escape(value)}</td></tr>")

    def _token_html(self, t):
        e = html.escape
        colors = dict(KIND_COLOR[self.lang])
        serif = text_family(self.lang)
        sub =t.get("pinyin") or (t.get("lemma") if t.get("lemma") and t.get("lemma").lower() != t["w"].lower() else "")
        head = (f"<div><span style='font-family:\"{serif}\";font-size:34px;font-weight:700'>{e(t['w'])}</span>"
                + (f"&nbsp;&nbsp;<span style='color:{css(T.muted)};font-size:15px'>{e(sub)}</span>" if sub else "") + "</div>")
        chips = ""
        if t.get("kind"):
            chips += self._chip(t["kind"], T[colors.get(t["kind"], "accent")] if colors.get(t["kind"]) else T.accent)
        if t.get("exam") or (t.get("src") == "offline" and t.get("kind") in ("实词", "虚词")):
            chips += self._chip("考纲" + (t.get("exam") or t["kind"]), T.gold)
        chips += self._chip("DeepSeek 精析" if t.get("src") == "ai" else "离线词表", T.ok if t.get("src") == "ai" else T.faint)
        rows = "".join([
            self._row("本句义", t.get("sense")), self._row("词性", t.get("pos")), self._row("成分", t.get("role")),
            self._row("用法", t.get("usage")), self._row("搭配", t.get("phrase")), self._row("说明", t.get("note")),
        ])
        out = head + f"<p style='margin:6px 0 4px 0'>{chips}</p>"
        if rows:
            out += f"<table cellspacing='0' style='margin-top:4px'>{rows}</table>"
        elif t.get("src") == "offline" and not t.get("other"):
            out += f"<p style='color:{css(T.faint)}'>离线词表里没有这个{'字' if self.lang == 'wyw' else '词'}；联网精析后会给出本句义和用法。</p>"
        other = t.get("other") or []
        if other:
            title = "考纲里的常见义项" if self.lang == "wyw" else "其他"
            items = "".join(f"<li style='margin:2px 0'>{e(x)}</li>" for x in other[:10])
            out += (f"<p style='color:{css(T.muted)};font-weight:700;margin:12px 0 2px 0'>{title}</p>"
                    f"<ol style='margin:0 0 0 -18px;color:{css(T.soft)}'>{items}</ol>")
        return out

    def _sentence_html(self, s):
        e = html.escape
        out = f"<hr style='border:none;background:{css(T.line)};height:1px'/>"
        out += f"<p style='color:{css(T.muted)};font-weight:700;margin:8px 0 2px 0'>本句</p>"
        out += f"<p style='font-family:\"{text_family(self.lang)}\";font-size:15px;margin:2px 0 6px 0'>{e(s['text'])}</p>"
        if s.get("translation"):
            out += f"<p style='margin:2px 0 8px 0;line-height:160%'><b style='color:{css(T.accent)}'>译</b>&nbsp; {e(s['translation'])}</p>"
        if s.get("structure"):
            out += f"<p style='margin:2px 0 8px 0;line-height:160%'><b style='color:{css(T.accent)}'>主干</b>&nbsp; {e(s['structure'])}</p>"
        pats = s.get("patterns") or []
        if pats:
            out += f"<p style='color:{css(T.muted)};font-weight:700;margin:10px 0 2px 0'>{'句式' if self.lang == 'wyw' else '语法'}</p><ul style='margin:0 0 0 -18px'>"
            for p in pats:
                out += f"<li style='margin:3px 0'><b>{e(p['type'])}</b>" + (f"　{e(p['mark'])}" if p.get("mark") else "") + \
                       (f"<br><span style='color:{css(T.soft)}'>{e(p['note'])}</span>" if p.get("note") else "") + "</li>"
            out += "</ul>"
        cls = [c for c in s.get("clauses") or [] if c.get("src") == "ai"]
        if cls:
            out += f"<p style='color:{css(T.muted)};font-weight:700;margin:10px 0 2px 0'>从句</p><ul style='margin:0 0 0 -18px'>"
            for c in cls:
                out += (f"<li style='margin:3px 0'><b>{e(c['type'])}</b>　<i>{e(c['text'])}</i>"
                        + (f"<br><span style='color:{css(T.soft)}'>{e(c['note'])}</span>" if c.get("note") else "") + "</li>")
            out += "</ul>"
        state = s.get("state")
        note = {"offline": "离线词表的结果（虚线）：句子写完整后会自动送 DeepSeek 精析",
                "pending": "正在精析这一句…",
                "ai": "DeepSeek 逐字精析（实线）",
                "ai-partial": "DeepSeek 给了翻译和句式，但逐字结果和原文对不上，字词仍用离线词表",
                "error": "精析失败：" + str(s.get("error", "")) + "（点「精析全文」重试）"}.get(state, "")
        from ..analysis import llm
        if state == "offline" and not llm.available():
            note = "离线词表的结果：没有 DeepSeek 密钥，整句翻译和本句义项需要联网精析"
        out += f"<p style='color:{css(T.bad if state == 'error' else T.faint)};font-size:12px;margin-top:10px'>{e(note)}</p>"
        return out

    # ---------------------------------------------------------------- 外观
    def apply_theme(self):
        f = QFont(text_family(self.lang))
        f.setPixelSize(21 if self.lang == "wyw" else 18)
        self.edit.setFont(f)
        self.edit.lang = self.lang
        self.edit.spacing()
        self.edit.setPlaceholderText("在这里输入或粘贴文言文……" if self.lang == "wyw" else "Type or paste an English passage here…")
        # 带上学习窗口那套按键样式：放进主窗口时按键也一样
        self.setStyleSheet(qss() + f"""
QWidget#readingPage {{ background:{"transparent" if self.compact else T.bg}; }}
QLabel#readTitle {{ color:{T.fg}; font-size:20px; font-weight:700; padding-right:6px; }}
QLabel#readStatus {{ font-size:12px; padding-left:8px; }}
QTextEdit#readEdit {{ background:{T.stage}; color:{T.fg}; border:1px solid {T.line}; border-radius:10px; padding:0;
    font-family:"{f.family()}"; font-size:{f.pixelSize()}px;
    selection-background-color:{css(T.accent, 0.28)}; selection-color:{T.fg}; }}
QTextEdit#readEdit:focus {{ border-color:{css(T.accent, 0.6)}; }}
QTextBrowser#readDetail {{ background:{T.raised}; color:{T.fg}; border:1px solid {T.line}; border-radius:10px; padding:10px 14px; }}
QSplitter::handle, QSplitter::handle:hover {{ background:transparent; }}
QSplitter::handle:horizontal {{ width:10px; }}
""")
        self.legend.set(self.lang)
        self.update_status()
        self.detail.setHtml(self.render(*self.at_cursor()) if hasattr(self, "sents") else "")
        self.seg.update()
        self.edit.viewport().update()

    def stop(self):
        """窗口关闭时：等正在跑的请求线程结束（最多 2 秒），别让线程比控件活得久。"""
        for w in list(self._workers):
            w.wait(2000)


class Legend(QWidget):
    """编辑区下面一行图例：彩色短线 + 名称；虚线表示离线推测。"""

    def __init__(self):
        super().__init__()
        self.lang = "wyw"
        self.setFixedHeight(22)

    def set(self, lang):
        self.lang = lang
        self.setToolTip(LEGEND_TIP[lang])
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(tokens.font(11.5))
        x = 4
        for name, col in KIND_COLOR[self.lang]:
            pen = QPen(qc(T[col]), 2.6)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawLine(x, 15, x + 16, 15)
            p.setPen(qc(T.soft))
            w = p.fontMetrics().horizontalAdvance(name)
            p.drawText(x + 22, 4, w + 2, 16, int(Qt.AlignmentFlag.AlignVCenter), name)
            x += 22 + w + 16
        note = "实线＝精析　虚线＝离线"
        if self.width() - x >= p.fontMetrics().horizontalAdvance(note) + 12:      # 放不下就不写
            p.setPen(qc(T.faint))
            p.drawText(x + 6, 4, self.width() - x - 6, 16, int(Qt.AlignmentFlag.AlignVCenter), note)
        p.end()
