"""生物自由工作台：可并置、移动、调参、对比与保存的教学模型。"""
import copy
from PySide6.QtCore import QRectF,Qt
from PySide6.QtGui import QPen
from ...design.tokens import T,font,qc
from ...kit.bench import bench
from . import bio_cover,bio_division,bio_enzyme,bio_photo
from .bio_model import DEFAULT,NAMES,calculate

ART=bio_cover.ART


@bench.reg(id="bio",subj="bio",short="生物",title="生物工作台",sub="细胞 · 分裂 · 遗传 · 生理与生态模型",desc="并置多个生物教学模型，调参对比、观察读数；每个模型明确显示假设与近似。",art=ART)
def bio(B):
    L=B.L
    c=L.canvas()
    state=dict(v=1,objects=[],selected=None,seq=0)
    undo=[]
    dragging=[None]
    def snapshot():
        return copy.deepcopy(state)
    def remember():
        undo.append(snapshot())
        del undo[:-30]
    def chosen():
        return next((o for o in state["objects"] if o["id"]==state["selected"]),None)
    def panel():
        B.clear_panel()
        o=chosen()
        if not o:
            L.group("生物模型")
            L.note("从左侧放入模型；拖动模型卡片可并置比较。右键素材可收藏。")
            B.show_panel()
            return
        L.group(NAMES[o["kind"]])
        readout=[None]
        def setvalue(key,value):
            remember()
            o["p"][key]=value
            if key=='stage' and o['p'].get('chromosomes',{}).get('v')==1:
                o['p'].pop('chromosomes',None)
            if readout[0] is not None:
                readout[0].set(calculate(o["kind"],o["p"])["rows"])
            L.draw()
        specific=o["kind"]=="enzyme" and o["p"].get("enzyme") in bio_enzyme.ENZYMES
        extra=bio_enzyme.fresh(o["p"]["enzyme"]) if specific else bio_photo.DEFAULT if o["kind"]=="photosynthesis" else {}
        if o["kind"]=="enzyme":
            def choose(value):
                if value==(o["p"].get("enzyme") or ""):
                    return
                remember()
                best=round(bio_enzyme.optimum_ph(value),1)
                o["p"].update({**bio_enzyme.fresh(value),**{k:o["p"][k] for k in ("substrate","dose","minutes","pre_T","pre_min") if k in o["p"]},"temperature":o["p"]["temperature"],"pH":best,"pre_pH":best})
                panel()
                L.draw()
            L.select("酶",([] if specific else [("","通用钟形曲线（旧）")])+[(k,e["name"]) for k,e in bio_enzyme.ENZYMES.items()],o["p"].get("enzyme") or "",choose)
        enzyme=[("temperature","反应温度 / °C",0,100,1),("pH","反应 pH",0,14,.1),("substrate","底物浓度（以 Km 为 1）",.1,20,.1),("dose","酶量（相对）",.1,3,.1),("minutes","作用时间 / min",1,60,1),("pre_min","预处理时间 / min（0 = 不做）",0,30,1),("pre_T","预处理温度 / °C",0,100,1),("pre_pH","预处理 pH",0,14,.1)] if specific else [("temperature","温度 / °C",0,80,1),("pH","pH",0,14,.1)]
        params={"microscope":[] if o["p"].get("slide") is not None else [("magnification","总放大倍数",40,1000,10)],"enzyme":enzyme,"photosynthesis":[("light","相对光强",0,2000,10),("co2","CO₂ / %",.01,.1,.001),("temperature","温度 / °C",0,45,1),("day","每天光照 / h",0,24,.5)],"population":[("time","时间",0,20,.1),("rate","内禀增长率",.01,1,.01),("initial","初始数量",1,100,1),("capacity","环境容纳量",100,1000,10)],"foodweb":[("energy","生产者能量",10,10000,10),("efficiency","传递效率",.1,.2,.01)]}
        for key,label,lo,hi,step in params.get(o["kind"],[]):
            L.slider(label,lo,hi,step,min(hi,max(lo,o["p"].get(key,extra.get(key)))),lambda value,k=key:setvalue(k,value))
        if o['kind']=='energy_network':
            for key,label,lo,hi,step in [('energy','草输入能量 / kJ',10,10000,10),('efficiency','每级净转移效率',.1,.2,.01),('split','草分给兔的比例',0,1,.05),('eat_rabbit','鹰摄取兔环节的比例',0,1,.05),('eat_mouse','鹰摄取鼠环节的比例',0,1,.05)]:
                L.slider(label,lo,hi,step,o['p'][key],lambda value,k=key:setvalue(k,value))
        if o["kind"] in ("mitosis","meiosis"):
            L.select("分裂时期",[(str(stage),name) for stage,name in bio_division.phases(o["kind"])],str(o["p"]["stage"]),lambda value:setvalue("stage",int(value)))
        if o["kind"]=="cross":
            for key,label in (("father","父本"),("mother","母本")):
                L.select(label,["AA","Aa","aa"],o["p"][key],lambda value,k=key:setvalue(k,value))
        result=calculate(o["kind"],o["p"])
        readout[0]=L.out()
        readout[0].set(result["rows"])
        L.note(result["note"])
        if o['kind']=='microscope':
            def scope(_):
                from .bio_scope import ScopeDialog
                try:
                    dialog=ScopeDialog(o['p'],remember,L.stage.window())
                except ValueError as exc:
                    B.toast(str(exc),'bad')
                    return
                dialog.exec()
                panel()
                L.draw()
            L.button('制片与显微观察',scope,True)
        if o['kind'] in ('plant','animal','mitosis','meiosis'):
            def detail(_):
                from .cell_detail import Chromosomes,Organelles
                if o['kind'] in ('mitosis','meiosis') and o['p']['stage'] not in bio_division.SORTABLE:
                    B.toast('这个时期只有计数。逐条拖动核对请选：'+'、'.join(name.split('（')[0] for stage,name in bio_division.phases(o['kind']) if stage in bio_division.SORTABLE))
                    return
                try:
                    dialog=Chromosomes(o['kind'],o['p'],remember,L.stage.window()) if o['kind'] in ('mitosis','meiosis') else Organelles(o['kind'],o['p'],remember,L.stage.window())
                except ValueError as exc:
                    B.toast(str(exc))
                    return
                dialog.exec()
                panel()
                L.draw()
            L.button('逐条拖动并核对染色体' if o['kind'] in ('mitosis','meiosis') else '点选细胞结构',detail)
        def remove(_):
            remember()
            state["objects"].remove(o)
            state["selected"]=None
            panel()
            L.draw()
        L.button("删除模型",remove)
        B.show_panel()
    def add(kind,x=None,y=None):
        if len(state["objects"])>=12:
            B.toast("最多并置12个模型")
            return
        remember()
        left,top,right,bottom=B.safe()
        state["seq"]+=1
        index=len(state["objects"])
        o=dict(id=state["seq"],kind=kind,p={**DEFAULT,**(bio_enzyme.fresh() if kind=="enzyme" else {})},x=x if x is not None else left+20+(index%2)*300,y=y if y is not None else top+25+(index//2)*205)
        o["x"]=min(max(left+10,o["x"]),max(left+10,c.w-right-280))
        o["y"]=min(max(top+10,o["y"]),max(top+10,c.h-bottom-190))
        state["objects"].append(o)
        state["selected"]=o["id"]
        panel()
        L.draw()
    covers={}
    def cover(o):
        """卡片的封面图和两行说明：参数、装片或主题变了才重画（拖动卡片时不重算）。"""
        record=o["p"].get("slide") if o["kind"]=="microscope" else None
        dpr=min(2.,L.stage.devicePixelRatioF())
        seen=None
        if record is not None:
            from .bio_scope_view import stamp
            from . import bio_slide
            seen=(stamp(record),bio_slide.valid(record))
        key=(bio_cover.key(o["kind"],o["p"]),dpr,seen)
        hit=covers.get(o["id"])
        if hit is None or hit[0]!=key:
            result=calculate(o["kind"],o["p"])
            view=None
            if record is not None:
                from .bio_scope_view import render
                view=render(record if seen[1] else bio_slide.fresh(),bio_cover.VIEW,dpr)
            hit=covers[o["id"]]=(key,bio_cover.render(o["kind"],o["p"],result,dpr,view),bio_cover.caption(o["kind"],o["p"],result))
            for stale in [k for k in covers if not any(x["id"]==k for x in state["objects"])]:
                del covers[stale]
        return hit[1],hit[2]
    def draw():
        c.clear()
        p=c.g.p
        for o in state["objects"]:
            r=QRectF(o["x"],o["y"],280,185)
            chosen_one=o["id"]==state["selected"]
            image,(first,second)=cover(o)
            p.save()
            p.setPen(QPen(qc(T.accent if chosen_one else T.line),2 if chosen_one else 1.2))
            p.setBrush(qc(T.raised))
            p.drawRoundedRect(r,11,11)
            plate=QRectF(r.x()+8,r.y()+8,bio_cover.W,bio_cover.H)
            p.drawImage(plate,image)
            p.setPen(QPen(qc(T.line),1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(plate,7,7)
            p.setFont(font(14,600))
            p.setPen(qc(T.fg))
            p.drawText(QRectF(r.x()+12,r.y()+123,256,22),int(Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter),NAMES[o["kind"]])
            width=int(256-p.fontMetrics().horizontalAdvance(NAMES[o["kind"]])-12)
            p.setFont(font(11))
            metrics=p.fontMetrics()
            p.setPen(qc(T.muted))
            p.drawText(QRectF(r.x()+268-width,r.y()+124,width,22),int(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter),metrics.elidedText(first,Qt.TextElideMode.ElideRight,width))
            p.setPen(qc(T.soft))
            p.drawText(QRectF(r.x()+12,r.y()+147,256,28),int(Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop|Qt.TextFlag.TextWordWrap),second)
            p.restore()
    def mouse(kind,event):
        if not hasattr(event,'position'):
            return
        point=event.position()
        x,y=point.x(),point.y()
        if kind=="down":
            o=next((o for o in reversed(state["objects"]) if QRectF(o["x"],o["y"],280,185).contains(point)),None)
            if o:
                remember()
                state["selected"]=o["id"]
                dragging[:]=[(o,x-o["x"],y-o["y"])]
                panel()
        elif kind=="move" and dragging[0]:
            o,dx,dy=dragging[0]
            left,top,right,bottom=B.safe()
            o["x"]=min(max(left+4,x-dx),max(left+4,c.w-right-284))
            o["y"]=min(max(top+4,y-dy),max(top+4,c.h-bottom-189))
        elif kind=="up":
            dragging[0]=None
        L.draw()
    def restore(value):
        if value.get("v")!=1 or not isinstance(value.get("objects"),list) or len(value["objects"])>12:
            raise ValueError("生物工作台存档版本或格式无效")
        for o in value["objects"]:
            if o.get("kind") not in NAMES:
                raise ValueError("生物模型类型无效")
        state.clear()
        state.update(copy.deepcopy(value))
        for o in state["objects"]:
            o["p"]={**DEFAULT,**o.get("p",{})}
        panel()
        L.draw()
    def undo_once():
        if undo:
            restore(undo.pop())
    B.palette([dict(title="细胞与显微观察",tab="item",items=[dict(id="bio-"+k,icon=bio_cover.icon(k),label=NAMES[k],sub=bio_cover.SUBS[k],click=lambda k=k:add(k),drop=lambda x,y,k=k:add(k,x,y)) for k in ("microscope","plant","animal","mitosis","meiosis")]),dict(title="遗传、生理与生态",tab="item",items=[dict(id="bio-"+k,icon=bio_cover.icon(k),label=NAMES[k],sub=bio_cover.SUBS[k],click=lambda k=k:add(k),drop=lambda x,y,k=k:add(k,x,y)) for k in ("cross","enzyme","photosynthesis","population","foodweb","energy_network")]),dict(title="操作",tab="item",items=[dict(label="撤销",icon=bio_cover.icon("undo"),sub="回到上一步",click=undo_once)])],labels={"item":"模型"})
    L.on_draw(draw)
    L.stage.mouse=mouse
    B.transfer(snapshot,restore,state)
    from . import bio_slide
    B.tips([("模型边界",["所有读数来自本地模型。细胞与分裂使用计数示意；未模拟完整三维细胞。","酶：选了具体的酶之后，催化、失活、底物消耗分开算；高温、过酸、过碱造成的失活不可逆，预处理过的酶回到适宜条件也不恢复。","光合与呼吸：两个过程分开算、分开报，净光合是它们的差；全部是相对值，不代表具体物种。","分裂：各时期的染色体、核DNA、染色单体、同源染色体、细胞数从同一个 2n=4 的细胞按规则推出来，前后对得上。","显微镜卡片里的「制片与显微观察」：制片的每一步都记在装片上，直接影响视野；视野按物镜的数值孔径、景深、视场数算，颜色是标本和染色剂自己的颜色。","「点选细胞结构」是结构示意图：核糖体、内质网、高尔基体等在普通光学显微镜下看不到。"]),
            ("制片与显微镜：常数来源",[f"{what}——{who}" for what,who,_url in bio_slide.SOURCES]),
            ("制片与显微镜：假设（没有可核对的定标数据）",list(bio_slide.ASSUMPTIONS)),
            ("酶：来源与假设",[f"{what}——{who}" for what,who,_url in bio_enzyme.SOURCES]+["假设："+text for text in bio_enzyme.ASSUMPTIONS]),
            ("光合与呼吸：来源与假设",[f"{what}——{who}" for what,who,_url in bio_photo.SOURCES]+["假设："+text for text in bio_photo.ASSUMPTIONS])])
    panel()
