"""时间胶囊、观澜、全局交互的验收。隔离数据，不联网。

用法：python panels_selftest.py <隔离目录>（也接在 main.py --self-test 里）
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

SAMPLE = dict(
    date="2026-11-07", date_label="2026.11.07", weekday="周六", edition=9, read_count=4,
    title="在分歧中重写共同规则", subtitle="四条线索，拼出今天的世界坐标。", generated_at="2026-11-07T07:20:00",
    keywords=["规则", "能源"],
    lead=dict(title="焦点新闻", summary="摘要", detail="第一段。\n第二段。", url="https://example.invalid/a", question="为什么？", source="甲", why="角度"),
    sections=dict(world=[dict(title="世界新闻", summary="摘要", url="https://example.invalid/b", source="乙", tags=["全球"])],
                  tech=[dict(title="科技新闻", summary="摘要", url="https://example.invalid/c", source="丙"),
                        dict(title="没有摘录的新闻", summary="", url="", source="丁")]),
    person=dict(name="甲某", identity="学者", years="1900—1980", story="故事", monogram="甲", moments=[dict(year="1950", text="时刻")], qualities=["坚持"]),
    person_alternates=[dict(name="乙某", identity="学者", years="1900—1980", story="故事", monogram="乙")],
    quotes=[dict(text="一句话", author="某人", source="某书", use="作文")],
    selection=dict(funnel=dict(fetched=100, gate_pass=50, deduped=30, selected=4), averages=dict(authority=80)),
    term=dict(term="词条", definition="解释", exam="连接"),
)


def main(root=None) -> int:
    root = Path(root or tempfile.mkdtemp(prefix="jw-panels-"))
    root.mkdir(parents=True, exist_ok=True)
    os.environ["JIANWEI_HOME"] = str(root / "home")
    os.environ["LOCALAPPDATA"] = str(root / "local")
    from native.kit import test_runtime
    app = test_runtime.application(sys.argv[:1])
    from PySide6.QtCore import QEvent, QPoint, QPointF, Qt
    from PySide6.QtGui import QMouseEvent, QPixmap, QPainter, QWheelEvent
    from PySide6.QtWidgets import QApplication, QPushButton, QScrollArea, QSlider, QVBoxLayout, QWidget

    failures: list[str] = []

    def check(name, ok, detail=""):
        print(("ok   " if ok else "FAIL ") + name + (f"  {detail}" if detail != "" and not ok else ""), flush=True)
        if not ok:
            failures.append(name)

    def spin(t=0.05):
        end = time.time() + t
        while time.time() < end:
            app.processEvents()
            time.sleep(.005)

    # ------------------------------------------------ 胶囊
    import countdown as cd
    import store
    cfg = dict(store.DEFAULT_CONFIG, pillX=None)
    now = datetime(2026, 11, 7, 14, 30, 5)
    check("节点解析：写错的段落跳过", cd.parse_milestones("2027-03-10 一模；乱写；2027-13-01 错；2027-04-20 二模") ==
          [dict(date="2027-03-10", label="一模"), dict(date="2027-04-20", label="二模")])
    check("节点来回转换不变", cd.parse_milestones(cd.format_milestones(cd.parse_milestones("2027-03-10 一模"))) == [dict(date="2027-03-10", label="一模")])
    x0, x1 = cd.ruler_geometry(860, 60, cfg, now)
    check("尺在天数和时钟之间", 150 < x0 < x1 < 760, (x0, x1))
    nx = cd.needle_x(860, 60, cfg, now)
    check("指针在尺上", x0 < nx < x1)
    check("尺上取日：指针位置就是今天", cd.day_at(nx, 860, 60, cfg, now).date() == now.date(), cd.day_at(nx, 860, 60, cfg, now))
    check("尺外取不到日期", cd.day_at(10, 860, 60, cfg, now) is None)
    text = cd.describe_day(cfg, datetime(2026, 11, 17), now)
    check("悬停说明", "再过 10 天" in text and "还有" in text, text)
    check("考试当天的说明", "高考当天" in cd.describe_day(cfg, store.target_dt(cfg), now))
    for w, h in ((640, 52), (860, 60), (1200, 88)):
        pm = QPixmap(w, h)
        pm.fill(Qt.GlobalColor.black)
        p = QPainter(pm)
        cd.draw_pill(p, w, h, dict(cfg, milestones=[dict(date="2027-03-10", label="一模")]), now, None, 1.0)
        p.end()
        a, b = cd.ruler_geometry(w, h, cfg, now)
        check(f"{w}×{h} 版面放得下", b - a >= 100 and b < w, (a, b))
    after = datetime(2027, 6, 8)
    pm = QPixmap(860, 60)
    p = QPainter(pm)
    cd.draw_pill(p, 860, 60, cfg, after, None, 1.0)
    p.end()
    check("考试过后能画", cd._days_text(after, store.target_dt(cfg))[0] == "0")
    bright = QPixmap(60, 40)
    bright.fill(Qt.GlobalColor.white)
    dark = QPixmap(60, 40)
    dark.fill(Qt.GlobalColor.black)
    check("浅壁纸自动用瓷白", cd.resolve_style(dict(pillStyle="auto"), bright) is cd.STYLES["porcelain"])
    check("深壁纸自动用墨色", cd.resolve_style(dict(pillStyle="auto"), dark) is cd.STYLES["ink"])
    check("手动样式优先于壁纸", cd.resolve_style(dict(pillStyle="ink"), bright) is cd.STYLES["ink"])
    # 胶囊跟随三种风格：每种风格深浅各一套；没有 skin 或写错时还是原来那套
    seen = {}
    for skin in ("ink", "celadon", "doodle"):
        for tone in ("ink", "porcelain"):
            st = cd.resolve_style(dict(skin=skin, pillStyle=tone), None)
            pm = QPixmap(860, 60)
            pm.fill(Qt.GlobalColor.gray)
            p = QPainter(pm)
            cd.draw_pill(p, 860, 60, dict(cfg, skin=skin, pillStyle=tone), now, None, 1.0)
            p.end()
            seen[(skin, tone)] = (st, bytes(pm.toImage().constBits()))
    check("三种风格 × 深浅画出六种不同的胶囊", len({v[1] for v in seen.values()}) == 6)
    check("每套样式的键齐全", all(set(v[0]) == set(cd.STYLES["ink"]) and v[0]["dark"] == (k[1] == "ink") for k, v in seen.items()))
    check("青瓷就是原来那套", seen[("celadon", "ink")][0] is cd.STYLES["ink"] and seen[("celadon", "porcelain")][0] is cd.STYLES["porcelain"])
    check("没有皮肤或写错皮肤时用原来那套", cd.resolve_style(dict(skin="nope", pillStyle="ink"), None) is cd.STYLES["ink"])
    check("风格里也按壁纸选深浅", cd.resolve_style(dict(skin="doodle", pillStyle="auto"), bright) is cd.SKIN_STYLES["doodle"]["porcelain"]
          and cd.resolve_style(dict(skin="ink", pillStyle="auto"), dark) is cd.SKIN_STYLES["ink"]["ink"])
    # 胶囊版式：横尺 / 方块 / 竖条 / 迷你
    shots = {}
    miles = dict(cfg, milestones=[dict(date="2027-03-10", label="一模")])
    for lay in cd.LAYOUTS:
        c = dict(miles, pillLayout=lay)
        w, h = cd.pill_size(c)
        pm = QPixmap(w, h)
        pm.fill(Qt.GlobalColor.gray)
        p = QPainter(pm)
        cd.draw_pill(p, w, h, c, now, None, 1.0)
        p.end()
        shots[lay] = (w, h)
        pt = cd.needle_pos(w, h, c, now)
        check(f"版式 {lay}：今天在画面里", 0 < pt.x() < w and 0 < pt.y() < h, (pt, w, h))
        day = cd.hover_day(pt.x(), pt.y(), w, h, c, now)
        check(f"版式 {lay}：指针处取到今天", (day is None) if lay == "tile" else (day is not None and day.date() == now.date()), day)
    check("四种版式四种尺寸", len(set(shots.values())) == 4, shots)
    check("方块、竖条、迷你用「高度」当大小", cd.pill_size(dict(cfg, pillLayout="column", height=90))[1] > shots["column"][1]
          and cd.pill_size(dict(cfg, pillLayout="column", width=1200)) == shots["column"])
    check("没写或写错版式就是横尺", cd.pill_layout({}) == "bar" and cd.pill_layout(dict(pillLayout="x")) == "bar")
    check("下一个节点", cd.next_milestone(miles, now)[1] == "一模" and cd.next_milestone(miles, datetime(2027, 4, 1)) is None)
    col = cd.CountdownPill(dict(cfg, pillLayout="column"))
    col.show()
    spin()
    check("竖条窗口尺寸跟版式", (col.width(), col.height()) == shots["column"], col.size())
    check("竖条默认靠左", col.x() - col._screen_geo().x() < 40)
    check("右键菜单能换版式", any(a.menu() is not None and a.text() == "版式" for a in col.build_menu().actions()))
    col.close()

    cfg = dict(cfg, width=400, height=60)   # 离屏屏幕只有 800 宽
    pill = cd.CountdownPill(cfg)
    pill.show()
    spin()
    moved, acts = [], []
    pill.moved.connect(lambda x, y: moved.append((x, y)))
    pill.action.connect(acts.append)

    def mouse(widget, kind, pos, button=Qt.MouseButton.LeftButton, buttons=None):
        local = QPointF(pos)
        return QApplication.sendEvent(widget, QMouseEvent(kind, local, widget.mapToGlobal(local), button,
                                                          Qt.MouseButton.LeftButton if buttons is None else buttons,
                                                          Qt.KeyboardModifier.NoModifier))
    start = pill.pos()
    mouse(pill, QEvent.Type.MouseButtonPress, QPoint(30, 30))
    mouse(pill, QEvent.Type.MouseMove, QPoint(32, 31), Qt.MouseButton.NoButton)
    mouse(pill, QEvent.Type.MouseButtonRelease, QPoint(32, 31), buttons=Qt.MouseButton.NoButton)
    check("手抖不算拖动", pill.pos() == start and not moved)
    mouse(pill, QEvent.Type.MouseButtonPress, QPoint(30, 30))
    mouse(pill, QEvent.Type.MouseMove, QPoint(30 + 100, 30 + 50), Qt.MouseButton.NoButton)
    spin()
    mouse(pill, QEvent.Type.MouseButtonRelease, QPoint(30, 30), buttons=Qt.MouseButton.NoButton)
    check("拖动后上报位置", len(moved) == 1 and moved[0][0] == pill.x(), moved)
    pill.apply_config(dict(cfg, pillX=pill.x(), marginTop=moved[0][1]))
    spin()
    check("重新应用配置还在拖到的位置", pill.x() == moved[0][0] and pill.y() - pill._screen_geo().y() == moved[0][1], (pill.pos(), moved))
    geo = pill._screen_geo()
    mid = geo.x() + (geo.width() - pill.width()) // 2
    check("靠近中线会吸附", pill._snapped(QPoint(mid + 9, 50)).x() == mid)
    check("离中线远不吸附", pill._snapped(QPoint(mid + 80, 50)).x() == mid + 80)
    check("拖不出屏幕", pill._snapped(QPoint(mid, -500)).y() == geo.y())
    pill.apply_config(dict(cfg, pillX=99999))
    check("存的位置在屏幕外时拉回来", pill.x() < QApplication.primaryScreen().virtualGeometry().right())
    pill.apply_config(dict(cfg))
    mouse(pill, QEvent.Type.MouseButtonDblClick, QPoint(30, 30))
    check("双击打开见微", acts == ["open"], acts)
    labels = [a.text() for a in pill.build_menu().actions()]
    check("右键菜单有常用操作", {"打开见微", "观澜", "隐藏胶囊", "胶囊设置…"} <= set(labels), labels)
    ruler_y = 40
    mouse(pill, QEvent.Type.MouseMove, QPoint(int(cd.needle_x(400, 60, cfg, datetime.now())), ruler_y), Qt.MouseButton.NoButton, Qt.MouseButton.NoButton)
    check("悬停尺上有标线", pill._hover_x is not None)
    pill.apply_config(dict(cfg, clickThrough=True))
    acts.clear()
    mouse(pill, QEvent.Type.MouseButtonDblClick, QPoint(30, 30))
    check("点击穿透时不响应", not acts)
    timers = pill._z_timer
    pill.hide()
    pill.show()
    check("反复显示不会多开定时器", pill._z_timer is timers)
    pill.close()

    # 设置页：Shell 接线
    import ui_kit
    ui_kit.apply_theme("day")
    app.setStyleSheet(ui_kit.qss())
    from shell import Shell
    data = store.GUANLAN_HOME / "data"
    data.mkdir(parents=True, exist_ok=True)
    (data / "latest.json").write_text(json.dumps(SAMPLE, ensure_ascii=False), encoding="utf-8")
    (data / "index.json").write_text(json.dumps([dict(date="2026-11-07", title="第九期", read_count=4, reading_minutes=9, weekday="周六")], ensure_ascii=False), encoding="utf-8")
    shell = Shell(tray_enabled=False, jobs_enabled=False)
    shell.show()
    spin()
    shell.show_pill(True, quiet=True)
    spin()
    shell.pill.moved.emit(321, 44)
    check("胶囊位置写进配置", store.load_config().get("pillX") == 321 and store.load_config().get("marginTop") == 44)
    z = store.load_config().get("zorder", "bottom")
    shell.pill.action.emit("top")
    check("菜单切换总在最前", store.load_config().get("zorder") != z)
    shell.pill.action.emit("top")
    shell.pill.action.emit("settings")
    check("胶囊设置跳到倒计时页", shell.tab == "countdown")
    shell.pill.action.emit("center")
    check("回到居中", store.load_config().get("pillX") is None)
    shell.pill.action.emit("hide")
    check("隐藏胶囊", not shell.pill.isVisible() and store.load_config().get("showPill") is False)
    shell.toast("第一条")
    shell.toast("第二条")
    spin()
    check("提示条显示最后一条", shell._toast.text() == "第二条" and shell._toast.isVisible())
    check("窗口边有改大小的把手", len(shell._grips) == 5 and all(g.isVisible() for g, _w in shell._grips))
    shell._remember_geometry()
    check("记住窗口位置", isinstance(store.load_config().get("shellGeom"), list))
    check("离屏的窗口位置放回主屏", QApplication.primaryScreen().availableGeometry().intersects(Shell._on_screen(99999, 99999, 1000, 700)))

    # ------------------------------------------------ 观澜
    from ui import sheets as gs  # type: ignore
    gs.BaseSheet.anim_ms = 0
    panel = shell.guanlan.ensure()
    from ui.pages import story_list  # type: ignore
    panel.show_window()
    spin(.1)
    # 动画关掉后立刻到位
    check("打开有内容", panel.today_page.hero is not None and len(panel.today_page.cards) == 3, len(panel.today_page.cards))
    check("未读计数", panel.rail._unread == 4, panel.rail._unread)
    panel.topbar.pin_btn.click()
    spin()
    check("内嵌模式下固定按钮不报错", panel._pinned is True and not panel._idle_timer.isActive())
    panel.topbar.pin_btn.click()
    spin()
    check("取消固定恢复自动收起", panel._pinned is False)
    panel.cfg["auto_start"] = False
    panel._settings_changed(dict(panel.cfg, hide_on_fullscreen=False))
    check("内嵌模式下改设置不报错", panel.cfg["hide_on_fullscreen"] is False)
    check("内嵌模式不显示开机启动", "auto_start" not in panel.settings_sheet.switches)
    panel._on_refresh_failed("x")
    spin()
    check("更新失败显示重试", "重试" in panel.footer.status() and panel._last_error == "x")
    panel._set_collapsed(True, animate=False)
    panel._on_refresh_ok(dict(edition=SAMPLE))
    panel._on_refresh_failed("y")
    check("收起时更新结果不因没有托盘而出错", True)
    panel._set_collapsed(False, animate=False)
    panel._last_error = ""
    panel._load_data()
    spin()

    # 阅读
    stories = story_list(panel.edition)
    panel._open_story(stories[1])
    spin()
    sheet = panel.detail_sheet
    check("打开阅读层", sheet.isVisible() and sheet.index == 1)
    check("读过的记下来", (root / "home") is not None and len(panel._read) == 1)
    check("列表里变成已读", panel.today_page.cards[0].read)
    check("进度刻度更新", panel.today_page.ticks.read == 1)
    check("未读减一", panel.rail._unread == 3)
    panel._arrow(1)
    check("→ 换下一条", sheet.index == 2 and len(panel._read) == 2)
    panel._arrow(-1)
    panel._arrow(-1)
    check("← 回到第一条", sheet.index == 0 and not sheet.prev_btn.isEnabled())
    sheet.index = len(stories) - 1
    sheet._render(stories[-1])
    check("没有链接时阅读原文键灰掉", not [b for b in sheet.inner.findChildren(gs.QPushButton) if b.text() == "阅读原文"][-1].isEnabled())
    panel._esc_pressed()
    spin()
    check("Esc 先关阅读层", not sheet.isVisible() and not panel._collapsed)
    panel._esc_pressed()
    spin(.35)
    check("再按 Esc 才收起", panel._collapsed)
    panel._set_collapsed(False, animate=False)
    read_file = store.GUANLAN_HOME / "data" / "read.json"
    check("已读写进文件", read_file.exists() and json.loads(read_file.read_text(encoding="utf-8"))["date"] == "2026-11-07")
    panel._load_data()
    spin()
    check("重开后已读还在", panel.today_page.cards[0].read)
    read_file.write_text(json.dumps(dict(date="2026-11-01", keys=["https://example.invalid/b"])), encoding="utf-8")
    panel._load_data()
    spin()
    check("换了一版已读清零", not panel.today_page.cards[0].read)
    read_file.write_text("坏文件", encoding="utf-8")
    panel._load_data()
    spin()
    check("已读文件损坏不影响打开", panel.today_page.hero is not None)

    # 键盘和页面
    panel._go_tab(1)
    spin()
    check("数字键切页", panel.page_stack.currentIndex() == 1)
    first = panel.people_page.index
    panel._arrow(1)
    check("人物页 → 换人", panel.people_page.index != first)
    panel._go_tab(2)
    panel._go_tab(3)
    spin()
    check("档案页有内容", panel.page_stack.currentIndex() == 3)
    panel._go_tab(0)
    panel._open_filter()
    spin()
    check("筛选说明能打开", panel.filter_sheet.isVisible())
    panel._go_tab(2)
    check("阅读层打开时数字键不切页", panel.tabs.active == 0)
    panel.filter_sheet.close_sheet()
    panel._open_settings()
    spin()
    check("设置能打开", panel.settings_sheet.isVisible())
    panel.settings_sheet.collapse_box.setCurrentIndex(0)
    check("自动收起时长写入配置", panel.cfg.get("auto_collapse_seconds") == 60)

    # 新闻筛选偏好：主题三态、地区、屏蔽词、条数，都写进观澜配置
    ss = panel.settings_sheet
    ss.theme_chips["科技产业"].click()
    ss.theme_chips["安全冲突"].click()
    ss.theme_chips["安全冲突"].click()
    ss.region_chips["非洲"].click()
    ss.mute_edit.setText("彩票，明星 综艺")
    ss.mute_edit.editingFinished.emit()
    ss.count_box.setCurrentIndex(2)
    spin()
    from core.paths import load_config as gl_config  # type: ignore
    saved = gl_config().get("prefs") or {}
    check("偏好：多看 / 少看 / 地区 / 屏蔽词写进配置",
          saved == dict(more=["科技产业"], less=["安全冲突"], regions=["非洲"], mute=["彩票", "明星", "综艺"]), saved)
    check("偏好：每天条数", gl_config().get("max_stories") == 9 and panel.cfg.get("max_stories") == 9)
    check("偏好：按键状态和说明跟上", ss.theme_chips["科技产业"].mode == 1 and ss.theme_chips["安全冲突"].mode == -1
          and "多看 科技产业" in ss.pref_summary.text(), ss.pref_summary.text())
    ss.theme_chips["科技产业"].click()
    ss.theme_chips["科技产业"].click()
    check("偏好：第三下恢复常规", ss.theme_chips["科技产业"].mode == 0 and "科技产业" not in gl_config()["prefs"]["more"])
    ss.theme_chips["科技产业"].click()
    spin()
    ss.scroll.ensureWidgetVisible(ss.pref_summary, 0, 60)
    spin()
    ss.grab().save(str(root / "guanlan-prefs.png"))
    ss.theme_chips["科技产业"].click()
    ss.theme_chips["科技产业"].click()
    from core import filters as gfl  # type: ignore
    from core.sources import Candidate, now_local  # type: ignore
    t0 = now_local()

    def cand(title, url):
        return Candidate(title=title, url=url, source="新华社", published=t0,
                         summary="人工智能芯片供应链与产业规则正在重塑，联合国与多国讨论全球治理框架。" * 2)
    pool = [cand("人工智能芯片出口管制升级，全球供应链再起波澜", "https://e.invalid/1"),
            cand("彩票销售额创新高引发讨论，全球治理与规则受关注", "https://e.invalid/2")]
    base = gfl.prepare([cand(c.title, c.url) for c in pool], None, {})
    plus = gfl.prepare([cand(c.title, c.url) for c in pool], None, dict(more=["科技产业"], mute=["彩票"]))
    t_base = next((c.total for c in base["scored"] if c.url.endswith("/1")), None)
    t_plus = next((c.total for c in plus["scored"] if c.url.endswith("/1")), None)
    check("偏好：多看的主题加分", t_base is not None and t_plus is not None and t_plus > t_base, (t_base, t_plus))
    check("偏好：屏蔽词在门槛就挡下", not any(c.url.endswith("/2") for c in plus["scored"]) and plus["reasons"].get("你屏蔽的词") == 1,
          dict(plus["reasons"]))
    check("偏好：手改的坏配置不出错", gfl.clean_prefs(dict(more=["不存在"], mute=["", "x" * 50], regions="欧洲")) ==
          dict(more=[], less=[], regions=[], mute=["x" * 12]))
    ss._sync_prefs()
    for c in ss.region_chips.values():
        c.setChecked(False)
    for c in ss.theme_chips.values():
        c.set_mode(0)
    ss.mute_edit.setText("")
    ss.count_box.setCurrentIndex(1)
    ss._emit_prefs()
    check("偏好：清空后回到默认", gl_config().get("prefs") == dict(more=[], less=[], regions=[], mute=[]) and gl_config()["max_stories"] == 7)
    panel.settings_sheet.close_sheet()
    spin()

    # 素材库：人物 / 金句 / 词条，按维度筛、搜索、分批显示、在库里读人物
    from core import facets as gf  # type: ignore
    K = gf.KINDS
    check("素材库扩充到 50 人 / 80 句 / 30 条以上", len(K["people"]["items"]) >= 50 and len(K["quotes"]["items"]) >= 80
          and len(K["terms"]["items"]) >= 30, {k: len(v["items"]) for k, v in K.items()})
    ids = [x["id"] for k in K for x in K[k]["items"]]
    check("素材库 id 不重复", len(ids) == len(set(ids)))
    panel._go_tab(1)
    spin()
    links = [b for b in panel.people_page.content.findChildren(gs.QWidget) if type(b).__name__ == "TextButton" and "人物库" in b._text]
    check("人物页有进人物库的入口", len(links) == 1)
    links[0].click()
    spin()
    lib = panel.library_sheet
    check("素材库能打开，默认全部人物", lib.isVisible() and lib.kind == "people" and len(lib.results) == len(K["people"]["items"]))
    lib.rows["region"].chips["世界"].click()
    spin()
    check("人物按地区筛", lib.results and all(p.get("region") != "中国" for p in lib.results), len(lib.results))
    lib.rows["field"].chips["科学技术"].click()
    spin()
    n_both = len(lib.results)
    check("两个维度叠加", 0 < n_both < len(gf.search("people", {"region": "世界"})), n_both)
    check("按键上的数字就是点下去的条数",
          lib.rows["era"].chips["现代"]._count == len(gf.search("people", {"region": "世界", "field": "科学技术", "era": "现代"})))
    check("0 条的选项变灰、不能点", all(not c.isEnabled() for o, c in lib.rows["era"].chips.items() if c._count == 0))
    lib.reset()
    lib.search.setText("相对论")
    lib.refresh()
    check("全文搜索", [p["id"] for p in lib.results] == ["einstein"], [p["id"] for p in lib.results])
    lib.reset()
    lib.open_person(0)
    spin()
    check("点开人物在素材库里读", lib.person_index == 0 and lib.back_btn.isVisible() and not lib.head.isVisible())
    panel._arrow(1)
    check("→ 换下一位", lib.person_index == 1)
    panel._esc_pressed()
    spin()
    check("Esc 先回列表，不关素材库", lib.isVisible() and lib.person_index == -1 and lib.head.isVisible())
    lib.open_kind("quotes", reopen=False)
    spin()
    from ui.cards import QuoteCard as GQuote, TermCard as GTerm  # type: ignore
    cards = [w for w in lib.inner.findChildren(GQuote) if not w.isHidden()]
    check("金句超过一页时分批建卡片", len(cards) == 20 and lib.more_btn.isVisible(), len(cards))
    lib.more_btn.click()
    spin()
    check("再显示一批", len([w for w in lib.inner.findChildren(GQuote) if not w.isHidden()]) == 40)
    lib.rows["origin"].chips["古代中国"].click()
    lib.rows["theme"].chips["逆境与坚持"].click()
    spin()
    check("金句按出处 + 作文主题", lib.results and all(gf.quote_origin(q) == "古代中国" and "逆境与坚持" in gf.quote_facets(q)["theme"]
                                                 for q in lib.results), len(lib.results))
    lib.open_kind("terms", reopen=False)
    lib.rows["subject"].chips["地理"].click()
    spin()
    check("词条按学科", lib.results and all("地理：" in t["exam"] for t in lib.results)
          and len([w for w in lib.inner.findChildren(GTerm) if not w.isHidden()]) == min(20, len(lib.results)), len(lib.results))
    lib.open_kind("people", reopen=False)
    check("换回人物库时筛选还记着", lib.rows["region"].value == "全部" and len(lib.results) == len(K["people"]["items"]))
    lib.rows["region"].chips["中国"].click()
    lib.rows["theme"].chips["责任与担当"].click()
    spin(.3)
    rows = [w for w in lib.inner.findChildren(QWidget) if type(w).__name__ == "PersonRow" and not w.isHidden()]
    check("人物库的行不被压扁", rows and min(r.height() for r in rows) >= 60, [r.height() for r in rows[:4]])
    lib.grab().save(str(root / "guanlan-library.png"))
    lib.fold_btn.click()
    spin(.2)
    check("筛选可以收起，收起后标出已选几项", lib.facets_holder.isHidden() and "已选 2 项" in lib.fold_btn._text, lib.fold_btn._text)
    lib.grab().save(str(root / "guanlan-library-folded.png"))
    lib.fold_btn.click()
    check("再点展开", not lib.facets_holder.isHidden() and lib.fold_btn._text == "收起筛选")
    lib.reset()
    spin()
    panel._esc_pressed()
    spin()
    check("再按 Esc 关掉素材库", not lib.isVisible() and not panel._collapsed)

    # 档案：搜索和月份
    from ui.pages import archive_match  # type: ignore
    e1 = dict(date="2026-11-07", title="规则的重写", lead="APEC 峰会", keywords=["APEC", "供应链"], sources=["新华社"])
    e2 = dict(date="2026-10-30", title="能源与航道", lead="霍尔木兹", keywords=["能源通道"], sources=["联合国新闻"])
    check("档案按关键词和月份筛", archive_match(e1, "apec") and not archive_match(e2, "apec")
          and archive_match(e2, "", "2026-10") and not archive_match(e1, "", "2026-10") and archive_match(e1, "峰会 新华社"))
    panel._go_tab(3)       # 切到档案页会按真实索引重建，所以先切过去再塞两天测试数据
    spin()
    panel.archive_page.set_data([e1, e2], panel.edition)
    spin()
    panel.grab().save(str(root / "guanlan-archive.png"))
    panel.archive_page._month_changed("2026-10")
    check("档案页月份筛选", [e["date"] for e in panel.archive_page.filtered()] == ["2026-10-30"])
    panel.archive_page.search.setText("规则")
    check("档案页搜索和月份叠加（没有就说没有）", panel.archive_page.filtered() == [])
    panel.archive_page._month_changed("")
    check("档案页清掉月份", [e["date"] for e in panel.archive_page.filtered()] == ["2026-11-07"])
    panel.archive_page.query, panel.archive_page.month = "", ""
    panel._load_data()
    spin()

    # 拖动和默认位置
    default = panel._expanded_rect().topLeft()
    panel._drag_start(default + QPoint(50, 20))
    panel._drag_move(default + QPoint(50 - 900, 20 + 30))
    panel._drag_end()
    check("拖到的位置记下来", panel.cfg.get("panel_pos") == [panel.x(), panel.y()])
    check("放到左半屏就贴左边收起", panel._rail_side() == "left" and panel.rail.side == "left")
    check("收起的窄条在屏幕内", panel.screen_geo.intersects(panel._collapsed_rect()))
    panel._reset_position()
    check("双击顶栏回到默认位置", panel.pos() == default and "panel_pos" not in panel.cfg)
    panel.cfg["panel_pos"] = [99999, 99999]
    check("存的位置在屏幕外时拉回来", QApplication.primaryScreen().virtualGeometry().intersects(panel._expanded_rect()))
    panel.cfg.pop("panel_pos")

    # 换主题：整块重建，停在原来的页，已读不丢
    panel._go_tab(2)
    spin()
    panel._mark_read(stories[0])
    panel.set_theme("night")
    spin(.1)
    check("换夜间后还在原来的页", panel.page_stack.currentIndex() == 2 and panel.tabs.active == 2)
    from ui.theme import C  # type: ignore
    check("夜间配色生效", C.dark and C.PANEL.lightnessF() < .2)
    check("已读没丢", panel.today_page.hero.state.text() == "已读")
    panel.grab().save(str(root / "guanlan-night.png"))
    panel.set_theme("day")
    spin(.1)
    check("换回白天", not C.dark and C.PANEL.lightnessF() > .8)
    panel._set_collapsed(True, animate=False)
    panel.set_theme("night")
    panel.set_theme("day")
    spin()
    check("收起时换主题还是窄条", panel.view_stack.currentWidget() is panel.rail)
    panel._set_collapsed(False, animate=False)

    # 观澜版式：报纸 / 卡片 / 横条，换来换去数据和已读都在
    from ui import layouts as gl  # type: ignore
    panel.set_layout("paper")
    spin(.1)
    check("报纸：窗口变宽", panel.width() > 600 and panel._layout == "paper", panel.size())
    check("报纸：焦点在左栏、线索在中栏", panel.today_page.hero is not None and not panel.today_page.cards
          and len(panel.stories_page.cards) == 3)
    check("报纸：标签页只剩人物金句档案", panel.tabs.tabs == ["人物", "金句", "档案"])
    panel._go_tab(2)
    check("报纸：数字键切到档案", panel.page_stack.currentWidget() is panel.archive_page)
    panel._go_tab(3)
    check("报纸：多出来的数字键不出错", panel.page_stack.currentWidget() is panel.archive_page)
    panel._open_story(stories[2])
    spin()
    check("报纸：读过的中栏也变已读", panel.stories_page.cards[1].read)
    panel._esc_pressed()
    panel.grab().save(str(root / "guanlan-paper.png"))
    check("报纸：位置单独记", panel._pos_key() == "pos_paper")

    panel.set_layout("card")
    spin(.1)
    view = panel.compact_view
    check("卡片：小窗口", panel.width() < 500 and panel.height() < 320, panel.size())
    check("卡片：四条都在", len(view.items) == 4 and view.count.text().endswith("/ 4"), view.count.text())
    small = panel.geometry()
    i0 = view.index
    panel._arrow(1)
    check("卡片：→ 换下一条", view.index == (i0 + 1) % 4)
    view.body.clicked.emit()
    spin()
    check("卡片：点一下撑大读全文", panel.detail_sheet.isVisible() and panel._reading and panel.height() > small.height() + 200, panel.size())
    panel.grab().save(str(root / "guanlan-card-reading.png"))
    panel._esc_pressed()
    spin()
    check("卡片：关掉阅读层缩回去", not panel._reading and panel.geometry() == small and not panel._collapsed, panel.geometry())
    view.set_rotating(False)
    check("卡片：暂停轮换", not view._timer.isActive() and view.play_btn.icon_name == "play")
    panel._set_auto_play(True, announce=False)
    check("卡片：Ctrl+P 就是轮换", view.rotating and panel.cfg.get("rotate") is True)
    panel._idle_check()
    check("卡片：不会自己收起", not panel._collapsed)
    panel.grab().save(str(root / "guanlan-card.png"))

    panel.set_layout("strip")
    spin(.1)
    check("横条：细长", panel.height() < 100 and panel.width() > 500, panel.size())
    check("横条：默认在屏幕下半", panel.geometry().center().y() > panel.screen_geo.center().y())
    panel._open_settings()
    spin()
    check("横条：设置也撑大", panel.settings_sheet.isVisible() and panel.height() > 300)
    check("横条：设置里能选版式", panel.settings_sheet.layout_box.currentData() == "strip")
    panel.settings_sheet.close_sheet()
    spin()
    check("横条：关掉设置缩回去", panel.height() < 100)
    panel.grab().save(str(root / "guanlan-strip.png"))
    panel.set_theme("night")
    spin(.1)
    check("横条：换主题还是横条", panel.compact_view is not None and panel._layout == "strip" and panel.height() < 100)
    panel.set_theme("day")
    spin(.1)

    panel.set_layout("panel")
    spin(.1)
    check("换回侧栏面板", panel._layout == "panel" and len(panel.today_page.cards) == 3 and panel.compact_view is None
          and panel.tabs.tabs == ["今日", "人物", "金句", "档案"])
    check("版式写进观澜配置", panel.cfg.get("layout") == "panel")
    check("全部版式名称齐", set(gl.LAYOUT_NAMES) == set(gl.LAYOUTS) and gl.layout_name(dict(layout="x")) == "panel")
    shell._built.discard("guanlan")
    shell.goto("guanlan")
    spin()
    from ui_kit import Chip
    gchips = {c.text(): c for c in shell.findChildren(Chip) if c.text() in gl.LAYOUT_NAMES.values() and c.isVisible()}
    check("见微的观澜页能选浮窗版式", set(gchips) == set(gl.LAYOUT_NAMES.values()) and gchips["侧栏面板"].isChecked(), list(gchips))
    gchips["新闻卡片"].click()
    spin(.1)
    check("在见微里换版式，浮窗当场换", panel._layout == "card" and panel.compact_view is not None)
    shelf_btns = {b.text(): b for b in shell.findChildren(QPushButton) if b.text() in ("人物库", "金句库", "格局词典", "筛选偏好") and b.isVisible()}
    check("见微的观澜页有素材库和筛选偏好入口", len(shelf_btns) == 4, list(shelf_btns))
    panel.set_layout("panel")
    spin(.1)
    shelf_btns["金句库"].click()
    spin()
    check("从见微打开金句库", panel.library_sheet.isVisible() and panel.library_sheet.kind == "quotes")
    panel._esc_pressed()
    shelf_btns["筛选偏好"].click()
    spin()
    check("从见微打开筛选偏好", panel.settings_sheet.isVisible())
    panel.settings_sheet.close_sheet()
    spin()
    panel.set_layout("card")
    spin(.1)
    panel.set_layout("panel")
    spin(.1)
    shell._built.discard("countdown")
    shell.goto("countdown")
    spin()
    pchips = {c.text(): c for c in shell.findChildren(Chip) if c.text() in ("横尺", "方块", "竖条", "迷你") and c.isVisible()}
    check("倒计时页能选胶囊版式", len(pchips) == 4 and pchips["横尺"].isChecked(), list(pchips))
    pchips["竖条"].click()
    spin()
    check("选了竖条写进配置", store.load_config().get("pillLayout") == "column" and store.load_config().get("pillX") is None)
    pchips["横尺"].click()
    spin()
    (store.GUANLAN_HOME / "data" / "latest.json").unlink()
    panel.edition = None
    panel._load_data()
    spin()
    check("没有内容时给更新键", any(b.text() == "立即更新" for b in panel.today_page.content.findChildren(gs.QPushButton)))
    shell.guanlan.hide()

    # ------------------------------------------------ 全局交互
    from native.design import ux
    ux.install()
    host = QWidget()
    area = QScrollArea(host)
    area.setWidgetResizable(True)
    area.resize(300, 120)
    inner = QWidget()
    lay = QVBoxLayout(inner)
    sl = QSlider(Qt.Orientation.Horizontal)
    sl.setRange(0, 100)
    sl.setValue(50)
    sl.setProperty("jw_default", 50)
    lay.addWidget(sl)
    spacer = QWidget()
    spacer.setFixedHeight(800)
    lay.addWidget(spacer)
    area.setWidget(inner)
    host.resize(300, 120)
    host.show()
    spin()

    def wheel(widget):
        pos = QPointF(10, 5)
        ev = QWheelEvent(pos, widget.mapToGlobal(pos), QPoint(0, 0), QPoint(0, -120), Qt.MouseButton.NoButton,
                         Qt.KeyboardModifier.NoModifier, Qt.ScrollPhase.NoScrollPhase, False)
        QApplication.sendEvent(widget, ev)
    wheel(sl)
    spin()
    check("滚轮路过滑块不改数值", sl.value() == 50, sl.value())
    check("滚轮滚动外面的面板", area.verticalScrollBar().value() > 0, area.verticalScrollBar().value())
    area.verticalScrollBar().setValue(0)
    spin()
    mouse(sl, QEvent.Type.MouseButtonPress, QPoint(sl.width() - 3, sl.height() // 2))
    mouse(sl, QEvent.Type.MouseButtonRelease, QPoint(sl.width() - 3, sl.height() // 2), buttons=Qt.MouseButton.NoButton)
    check("点轨道直接跳过去", sl.value() >= 95, sl.value())
    mouse(sl, QEvent.Type.MouseButtonDblClick, QPoint(10, sl.height() // 2))
    check("双击回到初始值", sl.value() == 50, sl.value())
    host.close()

    from native.main_win import NativeWindow
    from native.kit.ctx import Slider
    from native.kit.quick_open import score
    check("匹配：包含优先于散落", 0 <= score("平抛", "平抛运动") < score("平运", "平抛运动"))
    check("匹配：不含的字不算", score("化学", "平抛运动") == -1)
    win = NativeWindow("day")
    win.resize(1280, 800)
    win.show()
    spin()
    win.quick_open()
    spin()
    q = win._quick
    check("Ctrl+K 打开", q.isVisible() and q.edit.hasFocus() in (True, False) and q.list.count() > 0)
    kinds = {e[1].split(" ")[0] for e in q.entries}
    check("候选有模式、工作台、实验、题目、操作", {"模式", "工作台", "实验", "题目", "操作"} <= kinds, kinds)
    check("候选够多", len(q.entries) > 270, len(q.entries))
    q.edit.setText("化学工作台")
    spin()
    check("搜到工作台", q.list.count() >= 1 and q.list.item(0).text() == "化学工作台", q.list.count())
    q.accept()
    spin(.3)
    check("回车打开工作台", win.mode == "bench" and win.pages["bench"].cur_bench.id == "chem" and not q.isVisible())
    studio = win.pages["bench"]

    # 换场景可以撤销
    studio.chrome.anim_ms = 0
    pal = studio.B.pal
    exp = next(b for b in pal.all if pal.pages["exp"].body.isAncestorOf(b))
    before = json.dumps(studio.B.transfer_snapshot(), ensure_ascii=False, sort_keys=True)
    pal.run_click(exp.it, exp.it["click"], exp.tile)
    spin()
    changed = json.dumps(studio.B.transfer_snapshot(), ensure_ascii=False, sort_keys=True)
    check("点实验换了台面", changed != before)
    check("提示里有撤销", "撤销" in studio.B._toasts.last.text())
    # 台面的动画状态一直在走，不能逐字节比：看存下来的是换之前的那份、还原后的台面也不再是新场景
    real_restore = studio.B.transfer_restore
    got = []
    studio.B.transfer_restore = lambda st: (got.append(json.dumps(st, ensure_ascii=False, sort_keys=True)), real_restore(st))
    studio.B.undo_last()
    studio.B.transfer_restore = real_restore
    spin()
    check("撤销用的是换场景之前那份", got and got[0] == before)
    after_undo = json.dumps(studio.B.transfer_snapshot(), ensure_ascii=False, sort_keys=True)
    check("撤销后台面变回去了", after_undo != changed and abs(len(after_undo) - len(before)) < abs(len(changed) - len(before)) + 200, (len(before), len(changed), len(after_undo)))

    # 滑块直接输入：找一个实验
    win.goto("lab", "")
    spin(.1)
    win.goto("bench", "phys")
    spin(.3)
    sliders = []
    orig = Slider.__init__

    def spy(self, *a, **k):
        orig(self, *a, **k)
        sliders.append(self)
    Slider.__init__ = spy
    try:
        from native.kit.registry import lab
        e = next(x for x in lab.list if x.subj == "phys")
        win.goto("lab", e.id)
        spin(.2)
    finally:
        Slider.__init__ = orig
    if sliders:
        s = sliders[0]
        mid_v = (s.min + s.max) / 2
        s.val.begin_edit()
        check("点数值出现输入框", s.val.editor is not None)
        s.val.editor.setText(str(mid_v))
        s.val.finish_edit(True)
        check("输入的值生效", abs(s.v - mid_v) < 1e-9, s.v)
        s.val.begin_edit()
        s.val.editor.setText("不是数字")
        s.val.finish_edit(True)
        check("乱填不改值", abs(s.v - mid_v) < 1e-9)
        s.val.begin_edit()
        s.val.editor.setText(str(s.max + 999))
        s.val.finish_edit(True)
        check("超范围夹到上限", abs(s.v - s.max) < 1e-9, s.v)
        s.val.begin_edit()
        s.val.finish_edit(False)
        check("Esc 放弃编辑", s.val.editor is None)
        check("滑块有初始值属性", s.sl.property("jw_default") is not None)
    else:
        check("没有找到滑块实验", False)

    win.show_shortcuts()
    spin()
    check("F1 快捷键表", win._keys.isVisible() and win._keys.box.width() > 200)
    win._keys.hide()
    fresh = list(win.btns)
    check("模式键写了快捷键", all("Ctrl+" in win.btns[k].toolTip() for k in fresh))
    win.goto("analysis")
    spin(.2)
    page = win.pages["analysis"]
    check("没结果时导出键灰掉", not page.export_button.isEnabled())
    check("没结果时互通键灰掉", all(not page.action_row.itemAt(i).widget().isEnabled() for i in range(page.action_row.count())))
    page.text.setPlainText("从 20 m 高处以 15 m/s 的速度水平抛出一个小球，不计空气阻力，求落地时间和水平位移。")
    page.engine_box.setCurrentIndex(page.engine_box.findData("offline"))
    page.go()
    for _ in range(200):
        spin(.02)
        if page.L is not None:
            break
    check("离线分析完导出键可用", page.L is not None and page.export_button.isEnabled())
    win.shutdown()
    win.close()
    shell.guanlan.hide()
    shell.hide()
    print("PANELS", "OK" if not failures else "FAIL " + ",".join(failures), flush=True)
    return int(bool(failures))


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from native.kit import test_runtime
    test_runtime.configure()
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    target = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix="jw-panels-")
    os.environ["JIANWEI_HOME"] = str(Path(target) / "home")
    os.environ["LOCALAPPDATA"] = str(Path(target) / "local")
    raise SystemExit(test_runtime.run(lambda: main(target)))
