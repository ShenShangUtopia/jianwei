"""素材库：人物 / 金句 / 词条全部条目，按几个方面筛、全文搜索。从右边滑入，和其他层一样 Esc 返回。

每排筛选按键后面标着「点下去还剩几条」，0 条的变灰；结果超过一页时点「再显示」往下加，
免得一次建几十张卡片。人物点开在这一层里读，←→ 在筛出来的人里换。
"""
from __future__ import annotations

from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QPainter
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QVBoxLayout, QWidget

from .base import Chip, FlowLayout, Hairline, TextBlock, TextButton
from .cards import PersonSeal, QuoteCard, TermCard, _card, _label
from .pages import PersonView, clear_layout
from .sheets import BaseSheet
from .theme import C

PAGE = 20


class PersonRow(QWidget):
    """人物库里的一行：印章、名字、身份、一句话。"""
    clicked = Signal(dict)

    def __init__(self, person: dict, parent: QWidget | None = None):
        super().__init__(parent)
        self.person = person
        self._hover = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(10)
        seal = PersonSeal(person.get("monogram", ""))
        seal.setFixedSize(40, 40)
        lay.addWidget(seal, 0, Qt.AlignmentFlag.AlignTop)
        # 都用定高的 TextBlock：会折行的 QLabel 放在滚动区里报不出高度，整行会被压扁
        col = QVBoxLayout()
        col.setSpacing(1)
        col.addWidget(TextBlock(f"{person.get('name', '')}  ·  {person.get('years', '')}", 13, 700, C.TEXT, 1, 1.5))
        col.addWidget(TextBlock(person.get("identity", ""), 12, 400, C.MUTED, 2, 1.45).fit())
        col.addWidget(TextBlock(person.get("headline", ""), 12, 400, C.TEXT_SOFT, 2, 1.5).fit())
        lay.addLayout(col, 1)

    def enterEvent(self, e) -> None:
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.person)
        super().mousePressEvent(e)

    def paintEvent(self, e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        _card(p, QRectF(self.rect()).adjusted(.5, .5, -.5, -.5), C.CARD_HOVER if self._hover else C.CARD, 7)


class FacetRow(QWidget):
    """一个维度：左边名字，右边一串可以折行的按键（全部 + 各选项），单选。"""
    picked = Signal(str, str)

    def __init__(self, key: str, label: str, options, parent: QWidget | None = None):
        super().__init__(parent)
        self.key = key
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        name = _label(label, 12, 600, C.MUTED)
        name.setFixedWidth(52)
        lay.addWidget(name, 0, Qt.AlignmentFlag.AlignTop)
        box = QWidget()
        self.flow = FlowLayout(box, 5)
        lay.addWidget(box, 1)
        self.chips: dict[str, Chip] = {}
        from core.facets import ALL
        for opt in (ALL,) + tuple(options):
            chip = Chip(opt)
            chip.setChecked(opt == ALL)
            chip.clicked.connect(lambda _=False, o=opt: self._pick(o))
            self.flow.addWidget(chip)
            self.chips[opt] = chip
        self.value = ALL

    def _pick(self, opt: str) -> None:
        self.set_value(opt)
        self.picked.emit(self.key, opt)

    def set_value(self, opt: str) -> None:
        self.value = opt
        for o, c in self.chips.items():
            c.setChecked(o == opt)

    def set_counts(self, counts: dict) -> None:
        from core.facets import ALL
        for o, c in self.chips.items():
            n = counts.get(o, 0)
            c.set_count(None if o == ALL else n)
            c.setEnabled(o == self.value or n > 0)
        self.flow.invalidate()


class LibrarySheet(BaseSheet):
    copy_requested = Signal(str)
    collect_requested = Signal(dict)
    open_url = Signal(str)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent, "素材库")
        from core.facets import KINDS
        self.kinds = KINDS
        self.kind = "people"
        self.picks: dict[str, dict] = {k: {} for k in KINDS}
        self.results: list[dict] = []
        self.shown = 0
        self.person_index = -1         # 正在读第几位（-1 = 在列表里）

        # 顶部固定区：库切换、搜索、各维度；下面滚动区放结果
        head = QWidget()
        hl = QVBoxLayout(head)
        hl.setContentsMargins(8, 0, 8, 4)
        hl.setSpacing(8)
        kinds_box = QWidget()
        kf = FlowLayout(kinds_box, 6)
        self.kind_chips: dict[str, Chip] = {}
        for key, spec in KINDS.items():
            chip = Chip(spec["label"], len(spec["items"]))
            chip.clicked.connect(lambda _=False, k=key: self.open_kind(k, reopen=False))
            kf.addWidget(chip)
            self.kind_chips[key] = chip
        hl.addWidget(kinds_box)
        self.search = QLineEdit()
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self._debounce.start())
        hl.addWidget(self.search)
        self.facets_holder = QWidget()
        self.facets_box = QVBoxLayout(self.facets_holder)
        self.facets_box.setContentsMargins(0, 0, 0, 0)
        self.facets_box.setSpacing(6)
        hl.addWidget(self.facets_holder)
        foot = QHBoxLayout()
        self.count_label = _label("", 12, 500, C.DIM)
        foot.addWidget(self.count_label)
        foot.addStretch(1)
        self.fold_btn = TextButton("收起筛选", C.MUTED, 12, "chevron_up")
        self.fold_btn.setToolTip("筛选按键收起来，给结果多留地方")
        self.fold_btn.clicked.connect(self.toggle_facets)
        foot.addWidget(self.fold_btn)
        self.reset_btn = TextButton("清除筛选", C.MUTED, 12, None)
        self.reset_btn.clicked.connect(self.reset)
        foot.addWidget(self.reset_btn)
        hl.addLayout(foot)
        hl.addWidget(Hairline())
        self.layout().insertWidget(1, head)
        self.head = head
        self.rows: dict[str, FacetRow] = {}

        self.back_btn = TextButton("回到列表", C.ACCENT, 13, "chevron_left")
        self.back_btn.clicked.connect(self.back_to_list)
        self.top.insertWidget(2, self.back_btn)
        self.back_btn.hide()

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(180)
        self._debounce.timeout.connect(self.refresh)

    # ------------------------------------------------------------ 打开、切换
    def open_kind(self, kind: str = "people", reopen: bool = True) -> None:
        if kind not in self.kinds:
            kind = "people"
        if kind != self.kind or not self.rows:
            self.kind = kind
            self._build_facets()
        for k, c in self.kind_chips.items():
            c.setChecked(k == kind)
        self.search.blockSignals(True)
        self.search.setText(self.picks[kind].get("_text", ""))
        self.search.blockSignals(False)
        self.search.setPlaceholderText({"people": "搜名字、事迹、品质……", "quotes": "搜句子、作者、出处……",
                                        "terms": "搜词条、定义、考点……"}[kind])
        self.person_index = -1
        self.refresh()
        if reopen:
            self.open_sheet()

    def _build_facets(self) -> None:
        clear_layout(self.facets_box)
        self.rows = {}
        for key, label, opts in self.kinds[self.kind]["rows"]:
            row = FacetRow(key, label, opts)
            row.set_value(self.picks[self.kind].get(key, "全部"))
            row.picked.connect(self._picked)
            self.facets_box.addWidget(row)
            self.rows[key] = row

    def toggle_facets(self) -> None:
        self.facets_holder.setVisible(self.facets_holder.isHidden())
        self._sync_fold()

    def _sync_fold(self) -> None:
        folded = self.facets_holder.isHidden()
        picked = sum(1 for k, v in self.picks[self.kind].items() if not k.startswith("_") and v != "全部")
        self.fold_btn._text = ("展开筛选" + (f"（已选 {picked} 项）" if picked else "")) if folded else "收起筛选"
        self.fold_btn._arrow = "chevron_down" if folded else "chevron_up"
        self.fold_btn.updateGeometry()
        self.fold_btn.update()

    def _picked(self, key: str, value: str) -> None:
        self.picks[self.kind][key] = value
        self.refresh()

    def reset(self) -> None:
        self.picks[self.kind] = {}
        for row in self.rows.values():
            row.set_value("全部")
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self.refresh()

    # ------------------------------------------------------------ 结果
    def _filters(self) -> tuple[dict, str]:
        picks = {k: v for k, v in self.picks[self.kind].items() if not k.startswith("_")}
        return picks, self.search.text()

    def refresh(self) -> None:
        from core import facets
        self._debounce.stop()      # 打字时排着的那次刷新作废，免得晚到一步把刚点开的人物又刷回列表
        self.picks[self.kind]["_text"] = self.search.text()
        picks, text = self._filters()
        self.results = facets.search(self.kind, picks, text)
        counts = facets.counts(self.kind, picks, text)
        for key, row in self.rows.items():
            row.set_counts(counts.get(key, {}))
        unit = {"people": "位", "quotes": "句", "terms": "个"}[self.kind]
        total = len(self.kinds[self.kind]["items"])
        self.count_label.setText(f"找到 {len(self.results)} {unit}" + ("" if len(self.results) == total else f"（共 {total}）"))
        self.reset_btn.setVisible(bool(text.strip()) or any(v != "全部" for v in picks.values()))
        self._sync_fold()
        self.person_index = -1
        self._show_list()

    def _show_list(self) -> None:
        self.head.show()
        self.back_btn.hide()
        self.title_label.setText("素材库")
        self.clear()
        self.shown = 0
        if not self.results:
            hint = _label("没有符合的条目，换个筛选或搜索词试试。", 13, 400, C.MUTED)
            hint.setWordWrap(True)
            self.il.addWidget(hint)
            self.il.addStretch(1)
            return
        self.more_btn = TextButton("", C.ACCENT, 13, "chevron_down")
        self.more_btn.clicked.connect(self._more)
        self.il.addWidget(self.more_btn)
        self.il.addStretch(1)
        self._more()
        self.scroll.stop_scroll()
        self.scroll.verticalScrollBar().setValue(0)

    def _more(self) -> None:
        start, end = self.shown, min(len(self.results), self.shown + PAGE)
        at = self.il.indexOf(self.more_btn)
        for i in range(start, end):
            self.il.insertWidget(at, self._card(self.results[i], i))
            at += 1
        self.shown = end
        left = len(self.results) - end
        self.more_btn.setVisible(left > 0)
        if left > 0:
            self.more_btn._text = f"再显示 {min(PAGE, left)} 条（还有 {left} 条）"
            self.more_btn.updateGeometry()
            self.more_btn.update()

    def _card(self, entry: dict, i: int) -> QWidget:
        if self.kind == "people":
            row = PersonRow(entry)
            row.clicked.connect(lambda _p, k=i: self.open_person(k))
            return row
        if self.kind == "quotes":
            card = QuoteCard(entry, i + 1)
            card.copy_clicked.connect(self.copy_requested)
            card.collect_requested.connect(self.collect_requested)
            return card
        card = TermCard(entry)
        card.collect_requested.connect(self.collect_requested)
        return card

    # ------------------------------------------------------------ 读一位人物
    def open_person(self, index: int) -> None:
        if not self.results:
            return
        self.person_index = index % len(self.results)
        self.head.hide()
        self.back_btn.show()
        self.title_label.setText("")
        self.clear()
        view = PersonView()
        view.collect_requested.connect(self.collect_requested)
        view.build(self.results[self.person_index], self.person_index, len(self.results),
                   lambda: self.step(-1), lambda: self.step(1), self.open_url.emit, kicker="人物库")
        self.il.addWidget(view)
        self.scroll.stop_scroll()
        self.scroll.verticalScrollBar().setValue(0)

    def step(self, d: int) -> bool:
        """←→：读人物时换上一位 / 下一位。返回是否处理了。"""
        if self.kind != "people" or self.person_index < 0:
            return False
        self.open_person(self.person_index + d)
        return True

    def back_to_list(self) -> None:
        self.person_index = -1
        self._show_list()

    def close_sheet(self) -> None:
        """在人物详情里按 Esc / 返回：先回列表，再按一次才关。"""
        if self.person_index >= 0 and self.isVisible():
            self.back_to_list()
            return
        super().close_sheet()
