# 见微 0.3.22 交接

2026-11-25。基于 0.3.21。**没打包**（打包前把 `tools/release.py` 的 `OUT`、`TAG` 改到 0.3.22）。

## 1. 怎么做的
四个 agent 分板块并行，按文件分工，互不改对方的文件。分工表 `协作/0.3.22-分工.md`，各自的报告：
- `协作/0.3.22-Codex.md`：化学台器材 / 标签避让（`lab/benches/chem.py`）、框选结果层级和取字（`lecture/panel.py`、`pageview.py`）、弹窗和输入控件统一（`ui_kit.py`、`design/widgets.py`）。
- `协作/0.3.22-Gemini.md`：几何画板性质老师写法（`geo_calc.py`、`geo.py`、`geo_draw.py`、`kit/expr.py`、`kit/math_fn_selftest.py`）、考情图表（`exam/page.py` 的 `Trend`、`Bars`）、顶栏时钟最小宽度和托盘分组（`shell.py`）。
- `协作/0.3.22-DeepSeek.md`：读文「配置 AI」主键、实心主键、英语只画主干（`reading/page.py`、`reading/selftest.py`）；词库 839 → 3699（`recite/words_data.py`、`recite/selftest.py`）。
- Claude：合并、版本号、文档、全量自测；修了词库里 opener 的释义错字。

## 2. 验证
- 合并后离屏全量自测 47 组全部 OK（隔离 JIANWEI_HOME / LOCALAPPDATA）。
- Codex 报告里提到的 math.exp 溢出（geo_calc）是它测试时 Gemini 还没改完；物理性能 6.02 ms 超 6 ms 门槛是几个 agent 同时跑测试的负载，合并后都通过。

## 3. 留意
- 词库 3699 词是 DeepSeek 整理的，只抽查了 30 条，还可能有个别释义错字。
- 函数性质的 ±∞、值域按当前视野数值推算，极端函数可能写得不准。
- `调研/总览.md` 第 5–10 条这一轮基本做完；还剩第 8 条的「把 m-func / m-deriv 和几何画板合并」。读文的离线词表有没有用上新词库，没有核对。
