"""上网查询的抽屉：截图、搜索词（可改）、AI 摘要、资料卡片，顶上显示实际用时。"""
from __future__ import annotations

import html
import re
import threading
import time

from PySide6.QtCore import QObject, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QImage, QPainter, QPixmap
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QPlainTextEdit, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QVBoxLayout, QWidget

from . import lookup

QSS = """
QFrame#lookup { background:#111A17; border-left:1px solid #2E3F39; }
QFrame#lookup QLabel { background:transparent; color:#DCE5E0; font-family:'Microsoft YaHei UI'; }
QFrame#lookup QLabel#title { font-size:15px; font-weight:700; color:#F2F6F4; }
QFrame#lookup QLabel#time { font-size:12px; color:#7FD1A0; }
QFrame#lookup QLabel#note { font-size:12px; color:#93A39C; }
QFrame#lookup QLineEdit { background:#0B1210; color:#F2F6F4; border:1px solid #34463F; border-radius:7px; padding:7px 9px; font-size:13.5px; font-family:'Microsoft YaHei UI'; selection-background-color:#C8402A; }
QFrame#lookup QLineEdit:focus { border-color:#DA5238; }
QFrame#lookup QPushButton { background:#1B2925; color:#DCE5E0; border:1px solid #34463F; border-radius:5px; border-bottom:2px solid #080D0B; padding:5px 11px 4px 11px; font-size:12.5px; font-family:'Microsoft YaHei UI'; }
QFrame#lookup QPushButton:hover { background:#263732; color:white; }
QFrame#lookup QPushButton#pri { background:#C8402A; border-color:#C8402A; color:white; font-weight:600; }
QFrame#lookup QPushButton#pri:hover { background:#DA5238; }
QFrame#lookup QPushButton#x { background:transparent; border:none; font-size:17px; padding:2px 8px; color:#93A39C; }
QFrame#lookup QPushButton#x:hover { color:white; background:#263732; }
QFrame#lookup QPushButton#mini { background:transparent; border:none; color:#7CC8B8; padding:2px 0; font-size:12px; }
QFrame#lookup QPushButton#mini:hover { color:#A6E0D2; background:transparent; }
QFrame#card { background:#172320; border:1px solid #26342F; border-radius:7px; }
QFrame#card:hover { border-color:#3A4C45; }
QFrame#ai { background:#14251F; border:1px solid #2C5046; border-radius:7px; }
QLabel#cardTitle { color:#A6E0D2; font-size:13.5px; font-weight:600; }
QLabel#snip { color:#C2CFC9; font-size:12.5px; }
QLabel#src { color:#7F8F88; font-size:11px; }
QLabel#why { color:#9FB2AA; font-size:11.5px; }
QFrame#lookup QPushButton#fold { background:transparent; border:none; color:#93A39C; font-size:12px; padding:3px 0; text-align:left; }
QFrame#lookup QPushButton#fold:hover { color:#DCE5E0; background:transparent; }
QLabel#aiTag { color:#93A39C; font-size:11px; font-weight:400; }
QLabel#aiBody { color:#E6EEE9; font-size:15px; }
QLabel#chip { border-radius:3px; padding:2px 7px; font-size:11.5px; }
QLabel#mono { color:#0B1210; border-radius:4px; font-size:12px; font-weight:700; }
QFrame#qcard { background:#172320; border:1px solid #2C5046; border-radius:7px; }
QFrame#qcard:hover { border-color:#4E8F7F; }
QLabel#qmeta { color:#7CC8B8; font-size:11.5px; }
QLabel#qtitle { color:#F2F6F4; font-size:14px; font-weight:700; }
QLabel#qstem { color:#C2CFC9; font-size:12.5px; }
QLabel#qhead { color:#F2F6F4; font-size:13px; font-weight:700; }
QScrollArea, QScrollArea > QWidget > QWidget { background:transparent; border:none; }
QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
QScrollBar::handle:vertical { background:#34463F; border-radius:3px; min-height:30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { height:0; background:transparent; }
"""


class _TextGot(QObject):
    got = Signal(int, str, float)
    diagram = Signal(int, object)
    recognized = Signal(int, object)


BADGE = dict(keep=("可靠", "#21804F"), doubt=("存疑", "#B97F00"), drop=("已筛掉", "#5C6D66"))


MONO_COLORS = ("#7CC8B8", "#E4B863", "#9CB4F0", "#E99A7E", "#A6D27A", "#D69FD0")


def highlight(text, query):
    """摘要里出现的查询词加粗变亮：一眼看出这条资料和要查的东西沾不沾边。"""
    words = sorted({w for w in re.findall(r"[\u4e00-\u9fff]{2,}|[A-Za-z0-9]{2,}", query or "")}, key=len, reverse=True)
    pieces = set()
    for w in words:
        if re.fullmatch(r"[\u4e00-\u9fff]+", w) and len(w) > 4:
            pieces.update(w[i:i + 2] for i in range(len(w) - 1))   # 长词拆成两字片段，局部命中也看得见
        else:
            pieces.add(w)
    out = html.escape(text or "")
    if not pieces:
        return out
    pat = re.compile("|".join(re.escape(html.escape(w)) for w in sorted(pieces, key=len, reverse=True)))
    return pat.sub(lambda m: f"<b style='color:#F2F6F4'>{m.group(0)}</b>", out)


class Card(QFrame):
    STRIP = dict(keep="#21804F", doubt="#B97F00", drop="#3A4943")

    def __init__(self, item, to_board, query=""):
        super().__init__()
        self.setObjectName("card")
        self.item = item
        self.verdict = None
        v = QVBoxLayout(self)
        v.setContentsMargins(11, 9, 11, 8)
        v.setSpacing(4)
        top = QHBoxLayout()
        top.setSpacing(7)
        dom = lookup.domain(item["url"]) or "?"
        mono = QLabel(dom[:1].upper())
        mono.setObjectName("mono")
        mono.setFixedSize(22, 22)
        mono.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mono.setStyleSheet(f"background:{MONO_COLORS[sum(map(ord, dom)) % len(MONO_COLORS)]};")
        top.addWidget(mono, 0, Qt.AlignmentFlag.AlignTop)
        self.badge = QLabel("")
        self.badge.hide()
        top.addWidget(self.badge, 0, Qt.AlignmentFlag.AlignTop)
        t = QLabel((f"[{item['n']}] " if item.get("n") else "") + item["title"])
        t.setObjectName("cardTitle")
        t.setWordWrap(True)
        t.setCursor(Qt.CursorShape.PointingHandCursor)
        t.setToolTip(item["url"])
        t.mousePressEvent = lambda _e: QDesktopServices.openUrl(QUrl(item["url"]))
        self.title = t
        top.addWidget(t, 1)
        v.addLayout(top)
        if item.get("snippet"):
            s = QLabel(highlight(item["snippet"], query))
            s.setObjectName("snip")
            s.setTextFormat(Qt.TextFormat.RichText)
            s.setWordWrap(True)
            s.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            v.addWidget(s)
        self.reason = QLabel("")
        self.reason.setObjectName("why")
        self.reason.setWordWrap(True)
        self.reason.hide()
        v.addWidget(self.reason)
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        kind = item.get("kind") or lookup.site_kind(item["url"])[0]
        src = QLabel(f"{kind} · {lookup.domain(item['url'])} · 来自{item.get('source', '')}")
        src.setToolTip("网站类型按域名判断：教育、政府、百科、权威媒体排在前面；问答、资料站、自媒体排在后面")
        src.setObjectName("src")
        h.addWidget(src, 1)
        o = QPushButton("打开")
        o.setObjectName("mini")
        o.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        o.setCursor(Qt.CursorShape.PointingHandCursor)
        o.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(item["url"])))
        h.addWidget(o)
        h.addSpacing(8)
        b = QPushButton("写上黑板")
        b.setObjectName("mini")
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda: to_board(item["title"] + ("\n" + item["snippet"] if item.get("snippet") else "")))
        h.addWidget(b)
        v.addLayout(h)
        self._style()

    def _style(self, flash=False):
        """左边一道色条表示核查结论：绿可靠、黄存疑、灰筛掉，没核查的不画。"""
        strip = self.STRIP.get(self.verdict, "#26342F")
        border = "#DA5238" if flash else "#26342F"
        self.setStyleSheet(f"QFrame#card {{ background:#172320; border:1px solid {border}; border-left:3px solid {strip}; border-radius:7px; }}")

    def flash(self):
        self._style(True)
        QTimer.singleShot(1200, self, self._style)

    def set_verdict(self, verdict, why):
        self.verdict = verdict
        self._style()
        text, color = BADGE[verdict]
        self.badge.setText(text)
        self.badge.setStyleSheet(f"background:{color};color:white;border-radius:3px;padding:1px 5px;font-size:11px;font-weight:600;")
        self.badge.show()
        if self.item.get("n"):
            self.title.setText(f"[{self.item['n']}] {self.item['title']}")
        if why:
            self.reason.setText("核查：" + why)
            self.reason.show()


class SourceStrip(QWidget):
    """每个搜索来源一个小标签：在查、几条、没结果、要人工验证。"""
    STATES = dict(wait=("…", "#26342F", "#93A39C"), ok=("", "#1E4A3C", "#A6E0D2"), empty=("无", "#26342F", "#7F8F88"),
                  blocked=("要验证", "#4A3418", "#E9B86A"), fail=("连不上", "#4A2420", "#F0A08E"))

    def __init__(self):
        super().__init__()
        self.lay = QHBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(5)
        self.chips = {}

    def reset(self, names):
        while self.lay.count():
            w = self.lay.takeAt(0).widget()
            if w:
                w.hide()   # deleteLater 要等回到事件循环：先藏起来，免得和新标签叠在一起
                w.deleteLater()
        self.chips = {}
        for n in names:
            c = QLabel()
            c.setObjectName("chip")
            self.lay.addWidget(c)
            self.chips[n] = c
            self.set(n, "wait")
        self.lay.addStretch(1)
        self.setVisible(bool(names))

    def set(self, name, state, elapsed=0.0, count=0):
        c = self.chips.get(name)
        if c is None:
            return
        tail, bg, fg = self.STATES.get(state, self.STATES["fail"])
        text = f"{name} {count} 条 · {elapsed:.1f}s" if state == "ok" else f"{name} {tail}"
        c.setText(text)
        c.setStyleSheet(f"background:{bg};color:{fg};")
        c.setToolTip({"blocked": "这个搜索站要求人工验证，15 分钟内不再找它", "empty": "这个来源没有相关结果", "fail": "网络连不上这个来源"}.get(state, ""))


class VerdictBar(QWidget):
    """核查结果的比例：绿可靠、黄存疑、灰筛掉。"""

    def __init__(self):
        super().__init__()
        self.setFixedHeight(6)
        self.parts = (0, 0, 0)

    def set_parts(self, keep, doubt, drop):
        self.parts = (keep, doubt, drop)
        self.setVisible(sum(self.parts) > 0)
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        total = sum(self.parts)
        if not total:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        x = 0.0
        for n, col in zip(self.parts, ("#21804F", "#B97F00", "#3A4943")):
            w = self.width() * n / total
            p.fillRect(QRectF(x, 0, w - (1 if n else 0), self.height()), QColor(col))
            x += w
        p.end()


class QuestionCard(QFrame):
    """题库里的一道题：哪年哪卷、像不像、在习题台打开。"""

    def __init__(self, hit, on_open):
        super().__init__()
        self.setObjectName("qcard")
        q = hit["q"]
        v = QVBoxLayout(self)
        v.setContentsMargins(11, 9, 11, 9)
        v.setSpacing(4)
        top = QHBoxLayout()
        meta = " · ".join(str(x) for x in (q.get("subject"), q.get("year"), q.get("paper"), q.get("type")) if x)
        m = QLabel(meta)
        m.setObjectName("qmeta")
        top.addWidget(m, 1)
        tag = QLabel("就是这道题" if hit["same"] else f"相似 {int(hit['score'] * 100)}%")
        tag.setObjectName("chip")
        tag.setStyleSheet("background:#21804F;color:white;" if hit["same"] else "background:#26342F;color:#C2CFC9;")
        top.addWidget(tag)
        v.addLayout(top)
        t = QLabel(q.get("title") or "")
        t.setObjectName("qtitle")
        t.setWordWrap(True)
        v.addWidget(t)
        stem = str(q.get("stem") or "")
        s = QLabel(stem if len(stem) <= 90 else stem[:88] + "…")
        s.setObjectName("qstem")
        s.setWordWrap(True)
        v.addWidget(s)
        b = QPushButton("在习题台打开")
        b.setObjectName("pri")
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda: on_open(q["id"]))
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(b)
        v.addLayout(row)


class LookupPanel(QFrame):
    closed = Signal()
    to_board = Signal(str)
    image_to_board = Signal(QImage)
    open_question = Signal(str)        # 题号：在习题台打开
    analyze = Signal(str, QImage)      # 题目文字（可能为空）和截图：送去析题

    def __init__(self, ocr: lookup.Ocr):
        super().__init__()
        self.setObjectName("lookup")
        self.setStyleSheet(QSS)
        from .vision import Reader
        self.vision = Reader()
        self.recognition_cancel = threading.Event()
        self.ocr = ocr
        self.engine = lookup.Lookup()
        self.engine.results.connect(self._on_results)
        self.engine.ai_text.connect(self._on_ai)
        self.engine.verdict.connect(self._on_verdict)
        self.engine.checked.connect(self._on_checked)
        self.engine.finished.connect(self._on_done)
        self.engine.source_state.connect(self._on_source)
        self.engine.rewritten.connect(self._on_rewritten)
        self.mode = "web"
        self.text = ""
        self.bridge = _TextGot()
        self.bridge.got.connect(self._on_text)
        self.bridge.recognized.connect(self._on_recognized)
        self.bridge.diagram.connect(self._on_diagram)
        self.diagram_revision=0
        self.diagram_view=None
        self.diagram_data=None
        self.image = None
        self.ticket = 0
        self.job = -1
        self.t0 = 0.0
        self.first_at = None
        self.n = 0
        self.cards = []
        self.show_dropped = False
        self.verified = None
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(9)
        top = QHBoxLayout()
        ti = QLabel("上网查询")
        ti.setObjectName("title")
        self.title_label = ti
        top.addWidget(ti)
        self.time_label = QLabel("")
        self.time_label.setObjectName("time")
        top.addWidget(self.time_label, 1)
        x = QPushButton("×")
        x.setObjectName("x")
        x.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        x.clicked.connect(self.close_panel)
        top.addWidget(x)
        v.addLayout(top)
        self.thumb = QLabel()
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb.setMaximumHeight(120)
        v.addWidget(self.thumb)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.edit = QLineEdit()
        self.edit.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.edit.setPlaceholderText("要查什么")
        self.edit.returnPressed.connect(self.search_now)
        self.edit.textEdited.connect(self._cancel_recognition)
        row.addWidget(self.edit, 1)
        go = QPushButton("查询")
        go.setObjectName("pri")
        go.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        go.clicked.connect(self.search_now)
        row.addWidget(go)
        v.addLayout(row)
        recognition_row = QHBoxLayout()
        self.vision_btn = QPushButton("AI 识图")
        self.vision_btn.setToolTip(f"把当前框选图片发送给 {self._ai_name()} 识别文字、公式和图形，再查询")
        self.vision_btn.clicked.connect(lambda: self.recognize_image())
        recognition_row.addWidget(self.vision_btn)
        self.transcript_btn = QPushButton("识别原文")
        self.transcript_btn.setEnabled(False)
        self.transcript_btn.clicked.connect(self._edit_transcript)
        recognition_row.addWidget(self.transcript_btn)
        self.local_ocr_btn = QPushButton("本机识别")
        self.local_ocr_btn.clicked.connect(lambda: self.recognize_image(local=True))
        recognition_row.addWidget(self.local_ocr_btn)
        v.addLayout(recognition_row)
        self.recognition_note = QLabel("")
        self.recognition_note.setObjectName("note")
        self.recognition_note.setWordWrap(True)
        v.addWidget(self.recognition_note)
        self.sources = SourceStrip()
        self.sources.hide()
        v.addWidget(self.sources)
        self.note = QLabel("")
        self.note.setObjectName("note")
        self.note.setWordWrap(True)
        v.addWidget(self.note)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.body = QWidget()
        self.list = QVBoxLayout(self.body)
        self.list.setContentsMargins(0, 0, 4, 0)
        self.list.setSpacing(8)
        self.qbox = QWidget()            # 搜题：题库里的匹配 + 送去析题
        self.qlay = QVBoxLayout(self.qbox)
        self.qlay.setContentsMargins(0, 0, 0, 4)
        self.qlay.setSpacing(8)
        self.qbox.hide()
        self.list.addWidget(self.qbox)
        self.local_box=QWidget()
        self.local_lay=QVBoxLayout(self.local_box)
        self.local_lay.setContentsMargins(0,0,0,0)
        self.local_note=QLabel('')
        self.local_note.setWordWrap(True)
        self.local_lay.addWidget(self.local_note)
        self.enlarge=QPushButton('放大本地图解')
        self.enlarge.clicked.connect(self._enlarge_diagram)
        self.local_lay.addWidget(self.enlarge)
        self.enlarge.hide()
        self.list.addWidget(self.local_box)
        self.ai_box = QFrame()
        self.ai_box.setObjectName("ai")
        av = QVBoxLayout(self.ai_box)
        av.setContentsMargins(11, 9, 11, 9)
        av.setSpacing(4)
        ah = QHBoxLayout()
        self.ai_tag = QLabel(self._ai_name() + " 正在核查…")
        self.ai_tag.setObjectName("aiTag")
        self.ai_tag.setWordWrap(True)
        ah.addStretch(1)
        ab = QPushButton("写上黑板")
        ab.setObjectName("mini")
        ab.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        ab.clicked.connect(lambda: self.to_board.emit(re.sub(r"\s*\[\d+\]", "", self.ai_plain)))
        ah.addWidget(ab)
        self.review_btn = QPushButton("加入复习")
        self.review_btn.setObjectName("mini")
        self.review_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.review_btn.setToolTip("把这条结论存成知识卡，按 1、3、7、14、30 天提醒复习")
        self.review_btn.clicked.connect(self._to_review)
        ah.addSpacing(8)
        ah.addWidget(self.review_btn)
        self.vbar = VerdictBar()
        self.vbar.hide()
        self.ai_body = QLabel("")
        self.ai_body.setObjectName("aiBody")
        self.ai_body.setWordWrap(True)
        self.ai_body.setTextFormat(Qt.TextFormat.RichText)
        self.ai_body.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse | Qt.TextInteractionFlag.LinksAccessibleByMouse)
        self.ai_body.linkActivated.connect(self._cite)
        self.ai_plain = ""
        av.addWidget(self.ai_body)
        av.addLayout(ah)
        av.addWidget(self.vbar)
        av.addWidget(self.ai_tag)
        self.ai_box.hide()
        self.list.insertWidget(0, self.ai_box)
        self.fold = QPushButton("")
        self.fold.setObjectName("fold")
        self.fold.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.fold.setCursor(Qt.CursorShape.PointingHandCursor)
        self.fold.clicked.connect(self._toggle_dropped)
        self.fold.hide()
        self.list.addWidget(self.fold)
        self.list.addStretch(1)
        self.scroll.setWidget(self.body)
        v.addWidget(self.scroll, 1)
        foot = QHBoxLayout()
        self.img_btn = QPushButton("截图带入黑板")
        self.img_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.img_btn.clicked.connect(lambda: self.image is not None and self.image_to_board.emit(self.image))
        foot.addWidget(self.img_btn)
        self.web_btn = QPushButton("在浏览器里搜")
        self.web_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.web_btn.clicked.connect(self._open_web)
        foot.addWidget(self.web_btn)
        foot.addStretch(1)
        v.addLayout(foot)

    # ---- 开始
    def start(self, image: QImage, text: str, hint: str = "", mode: str = "web") -> None:
        """截图 + 文字层里的文字；没有文字时先识别图片。整个过程不卡界面。
        mode="question" 是搜题：先在题库里找，再给「送去析题」；不自动上网。"""
        self._cancel_recognition()
        self.recognition_note.clear()
        self.text = str(text or "")
        self.transcript_btn.setEnabled(bool(self.text))
        self.t0 = time.perf_counter()
        self.ticket += 1
        self.image = image
        self.mode = mode
        self.engine.cancel()
        self._reset()
        self.title_label.setText("搜题" if mode == "question" else "上网查询")
        self.img_btn.setVisible(True)
        pm = QPixmap.fromImage(image).scaled(420, 120, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.thumb.setPixmap(pm)
        self.thumb.setVisible(True)
        self.edit.setText("")
        self.hint = hint
        q = lookup.focus_query(text)
        if mode == "question" and len(lookup.clean_text(text)) >= 6:
            self._question(text)
            return
        if len(q) >= 2 and mode != "question":
            self._set_query(q)
            self._local_diagram(text)
            self._go(q)
            return
        self.recognize_image(local=not self.vision.available(),refresh=False)

    def _cancel_recognition(self, *_args):
        self.recognition_cancel.set()
        if getattr(self,'recognizing',False):
            self.recognizing = False
            self.vision_btn.setEnabled(True)
            self.recognition_note.setText('本次识别已取消，可修改搜索词后查询')
        self.ticket += 1

    def recognize_image(self, local=False, refresh=True):
        if self.image is None or self.image.isNull():
            return
        self._cancel_recognition()
        self.recognition_cancel = threading.Event()
        cancel = self.recognition_cancel
        tk, bridge = self.ticket, self.bridge
        image, hint = QImage(self.image), self.text
        self.engine.cancel()
        self.job = -1
        self._reset()
        self.qbox.hide()
        self.recognizing = True
        self.vision_btn.setEnabled(False)
        self.recognition_note.setText("本机识别中…" if local else f"正在将框选图片交给 {self._ai_name()} 识别…")
        reader, ocr = self.vision, self.ocr
        def work():
            try:
                if local:
                    result = dict(text=ocr.read(image), local=True)
                else:
                    from .vision import VisionError
                    try:
                        result = reader.read(image,hint,cancel.is_set,refresh=refresh)
                    except VisionError as exc:
                        if cancel.is_set():
                            return
                        reason = str(exc)
                        result = dict(text=ocr.read(image),local=True,error=reason)
                if cancel.is_set():
                    return
                bridge.recognized.emit(tk,result)
            except RuntimeError:
                pass  # Panel was destroyed; the request completes without touching Qt.
            except Exception:
                if not cancel.is_set():
                    try:
                        bridge.recognized.emit(tk,dict(text='',local=True,error='识别暂不可用，请手动输入或重试'))
                    except RuntimeError:
                        pass
        threading.Thread(target=work,daemon=True).start()

    def _on_recognized(self,ticket,result):
        if ticket != self.ticket:
            return
        self.recognizing = False
        self.vision_btn.setEnabled(True)
        text = result.get('text','')
        self.text = text
        self.transcript_btn.setEnabled(bool(text))
        if result.get('local'):
            self.recognition_note.setText((result.get('error','')+'；已回退本机识别') if result.get('error') else '本机识别完成')
            self._on_text(ticket,text,0)
            return
        uncertainty = result.get('uncertainty','')
        self.recognition_note.setText('AI 识图完成'+('（缓存）' if result.get('cached') else '')+
            ('；需核对：'+uncertainty if uncertainty else '；可点“识别原文”核对公式'))
        if self.mode == 'question':
            self._question(text)
            return
        query = lookup.make_query(result.get('query') or text,60)
        self._set_query(query)
        self._local_diagram(text)
        if uncertainty:
            self.note.setText('有看不清的内容，请核对识别原文或修改搜索词后查询。')
        elif len(query)>=2:
            self._go(query)

    def _edit_transcript(self):
        dialog = QDialog(self)
        dialog.setWindowTitle('识别原文 · 核对公式后查询')
        dialog.resize(560,420)
        layout = QVBoxLayout(dialog)
        edit = QPlainTextEdit(self.text)
        layout.addWidget(edit)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('应用并查询')
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._cancel_recognition()
            self.text = edit.toPlainText().strip()
            self.transcript_btn.setEnabled(bool(self.text))
            self.recognition_note.setText('使用核对后的原文')
            if self.mode == 'question':
                self._question(self.text)
            else:
                self._set_query(lookup.make_query(self.text,60))
                self.search_now()

    def _set_query(self, q):
        self.edit.setText(q)
        self.edit.setCursorPosition(0)   # 从开头显示：长搜索词不要只露出结尾
        self.edit.setToolTip(q)

    def _on_text(self, ticket, text, _el):
        if ticket != self.ticket:
            return
        if self.mode == "question":
            self._question(text)
            return
        q = lookup.focus_query(text)
        if len(q) >= 2 and self.ocr.status == "nozh":
            # 没有中文组件时，英文识别把汉字认成乱码：放进框里让人改，不自动去搜
            self._set_query(q)
            self.note.setText(f"{self.ocr.problem()}\n框里是按英文认出来的，可能不对，改好后按回车。")
            self.edit.setFocus()
        elif len(q) >= 2:
            self._set_query(q)
            self._local_diagram(text)
            self._go(q)
        else:
            why = self.ocr.problem()
            self.note.setText(f"{why}\n现在可以在上面写下想查的内容，按回车。" if why else "图里没有读到文字。写下想查的内容，按回车。")
            if self.hint:
                self.edit.setPlaceholderText(f"比如：{self.hint}")
            self.edit.setFocus()

    def _question(self, text):
        """搜题：题库匹配几毫秒就出来；下面是送去析题和上网搜两个出口。"""
        from ..bank.data import bank
        from ..kit.question_search import similar
        # 送去析题的题目保留分行（每行各自去掉版面空格）；题库匹配用整段去空白的文字；搜索框里放按行截短的搜索词
        lines = [lookup.clean_text(line) for line in str(text or "").splitlines()]
        text = "\n".join(line for line in lines if line)
        self.text = text
        self._set_query(lookup.make_query(text))
        self.note.setText("")
        if not bank.questions:
            bank.load()
        hits = similar(lookup.clean_text(text), bank.questions) if text else []
        while self.qlay.count():
            w = self.qlay.takeAt(0).widget()
            if w:
                w.hide()
                w.deleteLater()
        head = QLabel("题库里的这道题" if hits and hits[0]["same"] else "题库里的相似题" if hits else "题库里没有找到这道题")
        head.setObjectName("qhead")
        self.qlay.addWidget(head)
        for h in hits:
            self.qlay.addWidget(QuestionCard(h, self.open_question.emit))
        if text and not hits:
            tip = QLabel("可以送去析题：AI 读题、程序计算、逐步讲解。")
            tip.setObjectName("note")
            tip.setWordWrap(True)
            self.qlay.addWidget(tip)
        if not text:
            why = self.ocr.problem()
            tip = QLabel((why + "\n可以在上面的框里写下题目。") if why else "框里没有读到文字。送去析题时会再识别一次；也可以在上面的框里改写题目。")
            tip.setObjectName("note")
            tip.setWordWrap(True)
            self.qlay.addWidget(tip)
        row = QHBoxLayout()
        go = QPushButton("送去析题")
        go.setObjectName("pri")
        go.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        go.setCursor(Qt.CursorShape.PointingHandCursor)
        go.setToolTip("在析题里读题、计算、出图解")
        go.clicked.connect(lambda: self.analyze.emit(self.edit.text().strip() if self.edit.text().strip() and len(self.edit.text().strip()) > len(self.text) else self.text, self.image if self.image is not None else QImage()))
        row.addWidget(go)
        web = QPushButton("也上网搜")
        web.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        web.setCursor(Qt.CursorShape.PointingHandCursor)
        web.clicked.connect(self.search_now)
        row.addWidget(web)
        row.addStretch(1)
        holder = QWidget()
        holder.setLayout(row)
        self.qlay.addWidget(holder)
        self.qbox.show()
        self.time_label.setText(f"{(time.perf_counter() - self.t0) * 1000:.0f} 毫秒找完题库" if text else "")
        self.questions = hits

    def search_now(self):
        self._cancel_recognition()
        q = self.edit.text().strip()
        if q:
            self.t0 = time.perf_counter()
            self._reset()
            self._local_diagram(q)
            self._go(q)

    def _reset(self):
        self.engine.cancel()
        self.job = -1
        self.diagram_revision+=1
        self.diagram_data=None
        self.enlarge.hide()
        self.local_note.setText('')
        if self.diagram_view is not None:
            self.diagram_view.hide()
            self.diagram_view.deleteLater()
            self.diagram_view=None
        self.first_at = None
        self.n = 0
        self.time_label.setText("")
        self.note.setText("")
        self.ai_body.setText("")
        self.ai_plain = ""
        self.review_btn.setText("加入复习")
        self.review_btn.setEnabled(True)
        self.vbar.set_parts(0, 0, 0)
        self.sources.reset([])
        if self.mode != "question":
            self.qbox.hide()
        self.ai_tag.setText(self._ai_name() + " 正在核查…")
        self.ai_box.hide()
        self.fold.hide()
        self.show_dropped = False
        for c in self.cards:
            self.list.removeWidget(c)
            c.hide()
            c.deleteLater()
        self.cards = []

    def _local_diagram(self,text):
        from .local_diagram import resolve
        revision=self.diagram_revision
        self.local_note.setText('正在匹配本地逐题图解…')
        bridge=self.bridge
        def work():
            try:
                figure=resolve(text)
            except (OSError,ValueError,TypeError):
                figure=None
            try:
                bridge.diagram.emit(revision,figure)
            except RuntimeError:
                pass  # Panel was destroyed; no Qt worker object survives it.
        threading.Thread(target=work,daemon=True).start()

    def _on_diagram(self,revision,figure):
        if revision!=self.diagram_revision:
            return
        if not figure:
            self.local_note.setText('')   # 没有本地图解就不占地方；搜题里有「送去析题」
            return
        from ..analysis.figure.view import FigureView
        self.diagram_data=figure
        self.diagram_view=FigureView(figure)
        self.diagram_view.setMinimumHeight(300)
        self.local_lay.insertWidget(1,self.diagram_view)
        self.local_note.setText('本地题干/概念精确匹配图解 · 定性图不代替数值求解')
        self.enlarge.show()

    def _enlarge_diagram(self):
        if not self.diagram_data:
            return
        from ..analysis.figure.view import FigureView
        dialog=QDialog(self)
        dialog.setWindowTitle('本地图解')
        dialog.resize(1080,780)
        QVBoxLayout(dialog).addWidget(FigureView(self.diagram_data))
        dialog.exec()

    def _go(self, q):
        self.note.setText("正在查…")
        self.verified = None
        self.query = q
        self.job = self.engine.start(q)
        self.sources.reset(getattr(self.engine, "names", []))

    def _on_source(self, job, name, state, elapsed, count):
        if job == self.job:
            self.sources.set(name, state, elapsed, count)

    # ---- 结果
    def _on_results(self, job, items, _el):
        if job != self.job:
            return
        if self.first_at is None:
            self.first_at = time.perf_counter() - self.t0
            self.note.setText("")
            if lookup._ai_ready():
                self.ai_box.show()
            else:
                self.note.setText("这些结果没有经过核查。填了 AI 密钥后，会逐条核查并筛选。")
        for it in items:
            if self.n >= 12:
                break
            c = Card(it, self.to_board.emit, getattr(self, "query", ""))
            # 还没核查时按网站可信度排：同等可信度的按到达先后
            trust = it.get("trust", 1)
            after = [x for x in self.cards if x.item.get("trust", 1) < trust and x.verdict is None]
            self.cards.append(c)
            if after:
                self.list.insertWidget(self.list.indexOf(after[0]), c)
            else:
                self.list.insertWidget(self.list.count() - 1, c)
            self.n += 1
        self._time()

    def _time(self):
        self.time_label.setText(f"{self.first_at:.1f} 秒出资料 · {self.n} 条")

    @staticmethod
    def _ai_name():
        try:
            from ..analysis.llm import settings
            return settings()["name"]
        except Exception:  # noqa: BLE001
            return "AI"

    def _on_rewritten(self, job, q2):
        if job == self.job:
            self.query = q2 + " " + getattr(self, "query", "")      # 两轮的词都高亮
            self.note.setText(f"AI 把搜索词改成「{q2}」，又查了一轮，结果合在下面。")

    def _to_review(self):
        text = re.sub(r"\s*\[\d+\]", "", self.ai_plain or "").strip()
        if not text:
            return
        try:
            from .. import learning
            title = (self.edit.text().strip() or text.splitlines()[0])[:24]
            learning.add_card(dict(n=title, d=text, src="课件框选查找"), lookup.guess_subject(title + text))
            self.review_btn.setText("已加入复习")
            self.review_btn.setEnabled(False)
        except (OSError, ValueError):
            self.note.setText("没能加入复习（学习记录读写失败），原数据没动。")

    def _set_ai(self, text):
        """结论里的 [n] 变成可以点的链接：点了滚到那条资料并闪一下。第一行是一句话结论，加粗。"""
        self.ai_plain = text
        head, _, rest = str(text or "").partition("\n")
        body = f"<b style='color:#F2F6F4;font-size:18px'>{html.escape(head)}</b>" + ("<br>" + html.escape(rest).replace("\n", "<br>") if rest else "")
        body = re.sub(r"\[(\d+)\]", lambda m: f"<a href='cite:{m.group(1)}' style='color:#7CC8B8;text-decoration:none'><sup>[{m.group(1)}]</sup></a>", body)
        self.ai_body.setText(body)

    def _cite(self, link):
        if not link.startswith("cite:"):
            return
        n = int(link[5:])
        card = next((c for c in self.cards if c.item.get("n") == n), None)
        if card is None:
            return
        if not card.isVisible():
            self.show_dropped = True
            self._apply_fold()
        self.scroll.ensureWidgetVisible(card, 0, 40)
        card.flash()

    def _on_verdict(self, job, url, verdict, why):
        if job != self.job:
            return
        for c in self.cards:
            if c.item["url"] == url:
                c.set_verdict(verdict, why)
                break

    def _on_ai(self, job, text):
        if job != self.job:
            return
        self.ai_box.show()
        self._set_ai(text)

    def _on_checked(self, job, info):
        """核查结束：可靠的排前面，存疑的其次，筛掉的收起来（可以展开看）。"""
        if job != self.job:
            return
        self.verified = info
        if not info.get("ok"):
            self.ai_box.hide()
            self.note.setText(f"没能核查（{info.get('why')}），下面是未筛选的原始结果。")
            return
        el = time.perf_counter() - self.t0
        if not info["total"]:
            self.ai_tag.setText(f"没有查到网上资料。下面是 {self._ai_name()} 自己的知识，没有经过资料核对，请谨慎使用")
            self.note.setText("")
            return
        tag = f"{self._ai_name()} 核查了 {info['total']} 条：{info['kept']} 条可靠，{info['doubt']} 条存疑，筛掉 {info['dropped']} 条（{el:.1f} 秒）"
        if not self.ai_plain:
            self._set_ai("这些资料不足以回答。可以换个说法再查。")
        self.ai_tag.setText(tag + "。只看了标题和摘要，没有打开原网页")
        self.vbar.set_parts(info["kept"], info["doubt"], info["dropped"])
        if info.get("conflict"):
            self._set_ai(self.ai_plain + "\n\n资料之间有分歧：" + info["conflict"])
        order = {"keep": 0, "doubt": 1, None: 2, "drop": 3}
        self.cards.sort(key=lambda c: order[c.verdict])
        for c in self.cards:
            self.list.removeWidget(c)
        pos = max(self.list.indexOf(self.ai_box), self.list.indexOf(self.qbox),
                  self.list.indexOf(self.local_box)) + 1
        for c in self.cards:
            if c.verdict == "drop":
                continue
            self.list.insertWidget(pos, c)
            pos += 1
        self.list.removeWidget(self.fold)
        self.list.insertWidget(pos, self.fold)
        pos += 1
        for c in self.cards:
            if c.verdict == "drop":
                self.list.insertWidget(pos, c)
                pos += 1
        self._apply_fold()

    def _toggle_dropped(self):
        self.show_dropped = not self.show_dropped
        self._apply_fold()

    def _apply_fold(self):
        gone = [c for c in self.cards if c.verdict == "drop"]
        self.fold.setVisible(bool(gone))
        self.fold.setText(f"{'▾' if self.show_dropped else '▸'} 已筛掉 {len(gone)} 条，点开看原因")
        for c in gone:
            c.setVisible(self.show_dropped)

    def _on_done(self, job, n, _el):
        if job != self.job or n:
            return
        if not self.ai_plain:
            self.ai_box.hide()
            blocked = bool(lookup._muted) and all(t > time.time() for t in lookup._muted.values())
            self.note.setText("搜索站暂时要求人工验证（可能查得太频繁），过一会儿再试，或者点下面的「在浏览器里搜」。" if blocked else "没有查到资料。可能没联网，或者换个说法再试试。")

    def _open_web(self):
        from urllib.parse import quote
        q = self.edit.text().strip()
        if q:
            QDesktopServices.openUrl(QUrl(f"https://www.so.com/s?q={quote(q)}"))

    def close_panel(self):
        self._cancel_recognition()
        self.engine.cancel()
        self.diagram_revision+=1
        if self.diagram_view is not None:
            self.diagram_view.timer.stop()
        self.ticket += 1
        self.hide()
        self.closed.emit()
