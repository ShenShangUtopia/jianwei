"""自由工作台 · 几何画板（由 legacy/lab-math.js 改写）：界面与交互。模型在 geo_core，绘制在 geo_draw。"""
from __future__ import annotations

import math

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QWidget

from ...design.tokens import T, alpha, qc
from ...kit.bench import bench
from ...kit.core import PI, clamp
from ...kit.draw import D
from ...kit.home import load_json, save_json
from .geo_core import (COLOR_KEYS, IDENT, PRESETS, TYPE_NAMES, GeoCore, apply_m, compose_fn, compile_checked, fmt_angle, fmt_pt, invert_m, is_i, is_num, matrix_rows, normalize_expr,
                       num, pretty_expr, truncate)
from .geo_draw import GeoDraw

SAVE = "lab-math.json"
ART = """<svg viewBox="0 0 160 110"><g fill="none" stroke="currentColor" stroke-width="2.2">
  <path d="M14 92H150M24 102V8" stroke-width="1.4" opacity=".5"/>
  <path d="M40 84L70 30L104 78Z" stroke-dasharray="5 4" opacity=".55"/>
  <path d="M66 74L104 26L134 80Z" fill="currentColor" fill-opacity=".12"/>
  <path d="M78 58q16-26 34-18" stroke-width="1.6"/><path d="M108 36l5 4-6 3" stroke-width="1.6"/></g>
  <g fill="currentColor"><circle cx="66" cy="74" r="4"/><circle cx="104" cy="26" r="4"/><circle cx="134" cy="80" r="4"/></g></svg>"""


def _ic(s):
    return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{s}</svg>'


ICONS = {
    "select": _ic('<path d="M5 3.5l13.2 7-5.6 1.5-2.1 5.5z"/>'),
    "point": _ic('<circle cx="12" cy="12" r="3.3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>'),
    "segment": _ic('<path d="M5 18.5L19 5.5"/><circle cx="5" cy="18.5" r="2"/><circle cx="19" cy="5.5" r="2"/>'),
    "line": _ic('<path d="M3.5 20.5L20.5 3.5"/><path d="M3 8.5h18" opacity=".28"/>'),
    "circle": _ic('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="1.1" fill="currentColor" stroke="none"/>'),
    "polygon": _ic('<path d="M12 3.8l8.2 6-3.1 9.7H6.9L3.8 9.8z"/>'),
    "vector": _ic('<path d="M4 19L18.5 4.5"/><path d="M12 4.5h6.5V11"/>'),
    "func": _ic('<path d="M3.5 18.5c3.7-1 3.4-11.6 8.1-11.6 3.2 0 2.7 6.9 8.9 6.9"/>'),
    "measure": _ic('<path d="M4 17.2L16.8 4.4l2.8 2.8L6.8 20z"/><path d="M8.4 14.6l2 2M11.6 11.4l2 2M14.8 8.2l2 2"/>'),
    "undo": _ic('<path d="M9 7L4 12l5 5"/><path d="M4 12h10a5 5 0 0 1 0 10h-2"/>'),
    "redo": _ic('<path d="M15 7l5 5-5 5"/><path d="M20 12H10a5 5 0 0 0 0 10h2"/>'),
    "trash": _ic('<path d="M4.5 7h15M9 7V4.5h6V7M6.5 7l.8 13h9.4l.8-13M10 11v5M14 11v5"/>'),
    "export": _ic('<path d="M12 3.5v11M7.5 10L12 14.5 16.5 10"/><path d="M4.5 16.5v3h15v-3"/>'),
    "zoomIn": _ic('<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M10.5 7.5v6M7.5 10.5h6"/>'),
    "zoomOut": _ic('<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M7.5 10.5h6"/>'),
    "reset": _ic('<path d="M4.5 9.5V4.5h5M19.5 14.5v5h-5"/><path d="M5.2 14.2A7.2 7.2 0 0 0 18.7 16M18.8 9.8A7.2 7.2 0 0 0 5.3 8"/>'),
    "preset": _ic('<path d="M4 5h16M4 12h16M4 19h10"/>'),
}
TOOLS = [("select", "选择", "V"), ("point", "点", "P"), ("segment", "线段", "S"), ("line", "直线", "L"), ("circle", "圆", "C"), ("polygon", "多边形", "G"),
         ("vector", "向量", "R"), ("func", "函数", "F"), ("measure", "测量", "M")]
KEYMAP = {"v": "select", "p": "point", "s": "segment", "l": "line", "c": "circle", "g": "polygon", "r": "vector", "f": "func", "m": "measure"}


class Board(GeoDraw, GeoCore):
    def __init__(self, B):
        super().__init__()
        self.B, self.L = B, B.L
        self.c = B.L.canvas()
        self.pointer = None
        self.status_text = ""
        self.coord_text = "(0, 0)"
        self.ui: dict = {}
        self.save_timer = QTimer(B.L.stage)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self.save_state)
        self.B.L.timers.append(self.save_timer)
        self.rebuild_pending = False
        self.play_id, self.play_timer = None, None     # 切点自动沿曲线走

    # ---- 钩子
    def toast(self, msg, ms=2000):
        self.B.toast(str(msg).replace("<", "&lt;"), ms=ms)

    def render(self):
        self.L.draw()

    def schedule_save(self):
        self.save_timer.start(320)

    def update_status(self):
        self.status_text = self.status_now()

    def update_tool_ui(self):
        self.B.active("tool-" + self.tool)

    def refresh_all(self):
        self.update_status()
        self.update_tool_ui()
        self.build_panel()

    # ---- 状态文字
    def status_now(self):
        h, d = self.handle, self.draft
        if h:
            if h["phase"] == "wait":
                return "拖拽手柄：在画布上拖动以" + {"rotate": "旋转", "scale": "缩放"}.get(h["kind"], "平移")
            return "松开完成变换 · Esc 取消"
        if d:
            if d["tool"] == "polygon":
                return "继续点击顶点 · 点回起点 / Enter / 双击闭合 · Esc 取消"
            return "再点一次确定" + ("半径点" if d["tool"] == "circle" else "终点") + " · Esc 取消"
        return {"select": "拖动空白平移 · 滚轮缩放 · 点选对象，拖点可移动", "point": "单击放置点 · 自动吸附网格与已有点", "segment": "单击两个端点画线段 · 吸附已有点",
                "line": "单击两点确定直线 · 直线无限延伸", "circle": "先点圆心，再点半径点", "polygon": "依次点击顶点 · Enter 或点回起点闭合", "vector": "单击起点与终点画向量",
                "func": "在右侧输入解析式并按 Enter 绘制",
                "measure": {"angle": "角度测量：依次点三个点，第二个点是顶点", "area": "面积测量：点击一个多边形"}.get(self.measure_mode, "距离测量：依次点两个点")}.get(self.tool, "")

    def set_tool(self, t):
        if self.handle:
            self.cancel_handle()
        if self.draft:
            self.cancel_draft()
        self.tool = t
        self.snap_info = None
        self.measure_picks = []
        self.update_tool_ui()
        self.update_status()
        if t == "func" and self.ui.get("fn"):
            try:
                self.ui["fn"].setFocus()
                self.ui["fn"].selectAll()
            except RuntimeError:
                pass
        self.render()

    # ---- 绘制入口
    def draw(self):
        c = self.c
        c.clear()
        g = c.g
        self.draw_scene(g, c.w, c.h)
        n = sum(1 for o in self.objects if not o["aux"])
        tw = D.measure(self.status_text, 11)
        if c.w > tw + 200:
            D.text(g, self.status_text, self.B.safe()[0] + 130, c.h - 15, alpha(T.muted, 0.9), size=11)
        D.text(g, self.coord_text, c.w - self.B.safe()[2] - 12, c.h - 15, alpha(T.muted, 0.9), size=11, align="right", mono=True)
        D.text(g, f"{n} 个对象", c.w - self.B.safe()[2] - 12, c.h - 31, alpha(T.axis, 0.8), size=10.5, align="right")

    # ---- 指针
    def on_mouse(self, kind, e):
        if kind == "wheel":
            p = e.position()
            w = self.world_at(p.x(), p.y())
            nxt = clamp(self.view["scale"] * math.exp(e.angleDelta().y() * 0.0014), 5, 420)
            self.view["scale"] = nxt
            self.view["cx"] = w[0] - (p.x() - self.w / 2) / nxt
            self.view["cy"] = w[1] + (p.y() - self.h / 2) / nxt
            self.render()
            self.schedule_save()
            return
        if kind == "leave":
            if not self.pointer:
                self.snap_info = None
                self.render()
            return
        p = e.position()
        lx, ly = p.x(), p.y()
        world = self.world_at(lx, ly)
        mods = e.modifiers()
        shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        alt = bool(mods & Qt.KeyboardModifier.AltModifier)
        if kind == "down":
            self.on_down(e, lx, ly, world, shift)
        elif kind == "move":
            self.on_move(lx, ly, world, alt)
        elif kind == "up":
            self.on_up()
        elif kind == "dbl":
            if self.draft and self.draft["tool"] == "polygon" and len(self.draft["ids"]) >= 3:
                self.finish_draft()
            elif self.tool == "select":
                hit = self.hit_test(lx, ly)
                if hit and hit["type"] == "function":   # 双击曲线：在这里作切线
                    self.push_history()
                    self.set_tangent(hit, self.fn_x_of_world(hit, world))
                    self.select_one(hit["id"], False)
                    self.refresh_all()
                    self.render()
                    self.schedule_save()
                    self.toast("已作切线 · 拖动切点沿曲线移动，靠近零点、极值点会吸附（按住 Alt 不吸附）")

    def on_down(self, e, lx, ly, world, shift):
        if e.button() == Qt.MouseButton.RightButton:
            return
        if e.button() == Qt.MouseButton.MiddleButton:
            self.pointer = {"mode": "pan", "start": (lx, ly), "view": (self.view["cx"], self.view["cy"]), "moved": False}
            return
        if self.handle and self.handle["phase"] == "wait":
            if self.start_handle_drag(world):
                self.pointer = {"mode": "handle"}
                self.update_status()
                self.render()
            return
        tool = self.tool
        if tool == "select":
            fo = self.hit_tangent(lx, ly)
            if fo:   # 拖切点：点沿曲线走，切线跟着变
                self.stop_play()
                self.push_history()
                if fo["id"] not in self.selection:
                    self.select_one(fo["id"], False)
                self.pointer = {"mode": "slide", "id": fo["id"], "moved": False}
                return
            hit = self.hit_test(lx, ly)
            if hit:
                self.select_one(hit["id"], shift)
                if hit["type"] == "point":
                    c = self.cur_of_point(hit)
                    self.push_history()
                    self.pointer = {"mode": "point", "id": hit["id"], "offset": (self.X(c[0]) - lx, self.Y(c[1]) - ly), "moved": False}
                else:
                    self.pointer = {"mode": "click"}
            else:
                if not shift:
                    self.selection = []
                    self.refresh_all()
                    self.render()
                self.pointer = {"mode": "pan", "start": (lx, ly), "view": (self.view["cx"], self.view["cy"]), "moved": False}
            return
        if tool == "measure":
            self.measure_pick(world)
            self.pointer = {"mode": "click"}
            return
        if tool == "point":
            self.push_history()
            s = self.snap_world(world)
            pt = self.create_point(s["x"], s["y"])
            self.selection = [pt["id"]]
            self.snap_info = None
            self.refresh_all()
            self.render()
            self.schedule_save()
            self.pointer = {"mode": "click"}
            return
        if tool in ("segment", "line", "vector", "circle", "polygon"):
            if not self.draft or self.draft["tool"] != tool:
                self.start_draft(tool)
            self.draft["cursor"] = world
            self.draft_add_point(world)
            self.pointer = {"mode": "draft"}
            return
        self.pointer = {"mode": "click"}

    def on_move(self, lx, ly, world, alt):
        self.coord_text = f"({num(round(world[0], 2), 2)}, {num(round(world[1], 2), 2)})"
        ptr = self.pointer
        if ptr:
            mode = ptr["mode"]
            if mode == "pan":
                dx, dy = lx - ptr["start"][0], ly - ptr["start"][1]
                if abs(dx) + abs(dy) > 2:
                    ptr["moved"] = True
                self.view["cx"] = ptr["view"][0] - dx / self.view["scale"]
                self.view["cy"] = ptr["view"][1] + dy / self.view["scale"]
                self.render()
            elif mode == "point":
                pt = self.by_id(ptr["id"])
                if pt:
                    s = self.view["scale"]
                    tgt = (world[0] + ptr["offset"][0] / s, world[1] - ptr["offset"][1] / s)
                    sn = self.snap_world(tgt, exclude=pt["id"], fine=alt)
                    pt["x"], pt["y"] = apply_m(invert_m(pt.get("m")), sn["x"], sn["y"])
                    ptr["moved"] = True
                    self.render()
            elif mode == "slide":
                fo = self.by_id(ptr["id"])
                if fo:
                    name = self.set_tangent(fo, self.fn_x_of_world(fo, world), snap=not alt)
                    fo["tan"]["snap"] = name
                    ptr["moved"] = True
                    self.update_fn_readout(fo)
                    self.render()
            elif mode == "handle":
                self.update_handle_drag(world)
            elif mode == "draft":
                if self.draft:
                    self.draft["cursor"] = world
                self.snap_info = self.snap_world(world, fine=alt)
                self.render()
            return
        if self.draft:
            self.draft["cursor"] = world
            self.snap_info = self.snap_world(world, fine=alt)
            self.render()
        elif self.tool in ("point", "segment", "line", "vector", "circle", "polygon"):
            self.snap_info = self.snap_world(world, fine=alt)
            self.render()
        else:
            self.render()   # 坐标读数要刷新

    def on_up(self):
        ptr = self.pointer
        if ptr:
            if ptr["mode"] == "point":
                if not ptr.get("moved") and self.past:   # 只是点选，没拖动：不留历史
                    self.past.pop()
                self.refresh_all()
                self.schedule_save()
            elif ptr["mode"] == "pan":
                self.schedule_save()
            elif ptr["mode"] == "handle":
                self.finish_handle()
            elif ptr["mode"] == "slide":
                fo = self.by_id(ptr["id"])
                if fo and fo.get("tan"):
                    fo["tan"].pop("snap", None)
                if not ptr.get("moved") and self.past:
                    self.past.pop()
                self.pointer = None
                self.refresh_all()
                self.schedule_save()
            self.pointer = None
        self.snap_info = None
        self.render()

    def zoom_by(self, f):
        self.view["scale"] = clamp(self.view["scale"] * f, 5, 420)
        self.render()
        self.schedule_save()

    def reset_view(self):
        self.view = {"cx": 0.0, "cy": 0.0, "scale": 54.0}
        self.render()
        self.schedule_save()
        self.toast("视野已复位")

    def pan_px(self, dx, dy):
        self.view["cx"] -= dx / self.view["scale"]
        self.view["cy"] += dy / self.view["scale"]
        self.render()
        self.schedule_save()

    # ---- 键盘
    def on_key(self, k, e):
        ctrl = bool(e and (e.modifiers() & Qt.KeyboardModifier.ControlModifier))
        shift = bool(e and (e.modifiers() & Qt.KeyboardModifier.ShiftModifier))
        kl = k.lower()
        if e is not None and ctrl:   # Ctrl 组合键的 text() 是控制字符，要看键码
            code = e.key()
            if code == Qt.Key.Key_Z:
                self.do_redo() if shift else self.do_undo()
            elif code == Qt.Key.Key_Y:
                self.do_redo()
            elif code == Qt.Key.Key_S:
                self.export_png()
            elif code == Qt.Key.Key_0:
                self.reset_view()
            else:
                return False
            return True
        if kl == "escape":
            if self.handle:
                self.cancel_handle()
                self.toast("已取消变换")
                return True
            if self.draft:
                self.cancel_draft()
                self.toast("已取消作图")
                return True
            self.measure_picks = []
            if self.tool != "select":
                self.set_tool("select")
            else:
                self.selection = []
                self.refresh_all()
                self.render()
            self.update_status()
            return True
        if kl in ("delete", "backspace"):
            self.delete_selection()
            return True
        if kl == "enter":
            if self.draft and self.draft["tool"] == "polygon":
                self.finish_draft()
            return True
        if kl in ("arrowleft", "arrowright", "arrowup", "arrowdown"):
            st = 120 if shift else 44
            self.pan_px(*{"arrowleft": (st, 0), "arrowright": (-st, 0), "arrowup": (0, st), "arrowdown": (0, -st)}[kl])
            return True
        if kl in ("+", "="):
            self.zoom_by(1.2)
            return True
        if kl in ("-", "_"):
            self.zoom_by(1 / 1.2)
            return True
        if kl == "0":
            self.reset_view()
            return True
        if kl in KEYMAP:
            self.set_tool(KEYMAP[kl])
            return True
        return False

    # ---- 面板
    def row(self, *widgets):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(5)
        for x in widgets:
            h.addWidget(x)
        self.L._add(w)
        return w

    @staticmethod
    def small_label(text, width=None):
        lb = QLabel(text)
        lb.setObjectName("ctlLabel")
        if width:
            lb.setFixedWidth(width)
        return lb

    @staticmethod
    def edit(text, width=None, ph=""):
        ed = QLineEdit(str(text))
        ed.setPlaceholderText(ph)
        if width:
            ed.setFixedWidth(width)
        return ed

    @staticmethod
    def btn(text, cb, pri=False, width=None):
        b = QPushButton(text)
        b.setObjectName("pri" if pri else "btn")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda _=False: cb())
        if width:
            b.setFixedWidth(width)
        return b

    def build_panel(self):
        """检查器重建放到事件循环里：一次操作可能连着触发几次 refresh_all，只重建一回。"""
        if not self.rebuild_pending:
            self.rebuild_pending = True
            QTimer.singleShot(0, self.L.stage, self._build_panel)

    def _build_panel(self):
        self.rebuild_pending = False
        B, L = self.B, self.L
        if L.draw_fn is None:
            return
        B.clear_panel()
        self.ui = {}
        self.panel_props()
        self.panel_matrix()
        self.panel_preset()
        self.panel_transform()
        self.panel_function()
        self.panel_measure()
        self.panel_objects()
        self.panel_display()
        L.panel_lay.addStretch(1)
        B.show_panel()

    def panel_function(self):
        L = self.L
        L.group("函数作图")
        ed = self.edit("", ph="如 2sin(x)+1")
        self.ui["fn"] = ed

        def go():
            if self.add_function_from_input(ed.text()):
                ed.clear()
        ed.returnPressed.connect(go)
        self.row(ed, self.btn("绘制", go, True))
        L.note("支持 sin cos tan sqrt ln exp · ^ · π。点下面的常用函数一键画出，再用「伸缩平移」滑块调。")

        def quick(expr):
            if self.add_function_from_input(expr):
                fo = next((x for x in reversed(self.objects) if x["type"] == "function"), None)
                if fo:
                    self.select_one(fo["id"], False)
        for exprs in (("x^2", "x^3", "sqrt(x)", "1/x"), ("sin(x)", "cos(x)", "tan(x)", "abs(x)"), ("exp(x)", "ln(x)", "2^x", "x^3-3x")):
            self.row(*[self.btn(pretty_expr(normalize_expr(e)), lambda e=e: quick(e)) for e in exprs])

    def panel_objects(self):
        L = self.L
        objs = [o for o in self.objects if not o["aux"]]
        L.group(f"对象 · {len(objs)}")
        if not objs:
            L.note("还没有对象。用左侧工具开始作图。")
            return
        for o in objs:
            self.object_row(o)

    def object_row(self, o):
        sel = o["id"] in self.selection
        fr = QFrame()
        h = QHBoxLayout(fr)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)
        col = qc(self.object_color(o)).name()
        name = QPushButton(f"{self.object_label(o)}")
        name.setObjectName("seg")
        name.setCheckable(True)
        name.setChecked(sel)
        name.setToolTip(f"{self.object_label(o)} · {self.object_meta(o)}")
        name.setCursor(Qt.CursorShape.PointingHandCursor)
        name.setStyleSheet(f"QPushButton{{text-align:left;border-left:3px solid {col};padding-left:8px;{'color:' + T.faint + ';' if o['hidden'] else ''}}}")
        name.clicked.connect(lambda _=False, i=o["id"]: self.select_one(i, False))

        def toggle(_=False, oo=o):
            self.push_history()
            oo["hidden"] = not oo["hidden"]
            self.refresh_all()
            self.render()
            self.schedule_save()

        def delete(_=False, i=o["id"]):
            self.push_history()
            self.remove_objects([i])
            self.toast("已删除 · Ctrl+Z 可撤销")
        eye = QPushButton("显" if o["hidden"] else "隐")
        eye.setObjectName("btn")
        eye.setFixedWidth(40)
        eye.setToolTip("显示" if o["hidden"] else "隐藏")
        eye.clicked.connect(toggle)
        dl = QPushButton("删")
        dl.setObjectName("btn")
        dl.setFixedWidth(40)
        dl.setToolTip("删除")
        dl.clicked.connect(delete)
        h.addWidget(name, 1)
        h.addWidget(eye)
        h.addWidget(dl)
        self.L._add(fr)

    def panel_props(self):
        L = self.L
        L.group("选中对象")
        sel = [o for o in (self.by_id(i) for i in self.selection) if o]
        if not sel:
            L.note("未选中对象。点选图形或点，Shift 多选。")
            return
        rows = []
        if len(sel) > 1:
            rows = [["已选", f"{len(sel)} 个对象"], ["类型", " / ".join(sorted({TYPE_NAMES.get(o["type"], o["type"]) for o in sel}))], ["提示", "变换同时作用于图形与顶点"]]
            L.out().set(rows)
            self.swatches(sel)
            self.width_slider(sel)
            self.prop_actions(sel)
            return
        o = sel[0]
        t = o["type"]
        rows.append([f"<b>{self.object_label(o)}</b>", TYPE_NAMES.get(t, "对象")])
        if t == "point":
            p = self.cur_of_point(o)
            L.out().set(rows + ([["状态", "已变换 · 虚线为原像"]] if not is_i(o.get("m")) else []))

            def set_xy(ix):
                def cb(ed):
                    try:
                        v = float(ed.text())
                    except ValueError:
                        return
                    self.push_history()
                    cur = list(self.cur_of_point(o))
                    cur[ix] = v
                    o["x"], o["y"] = apply_m(invert_m(o.get("m")), cur[0], cur[1])
                    self.refresh_all()
                    self.render()
                    self.schedule_save()
                return cb
            ex, ey = self.edit(num(p[0], 3)), self.edit(num(p[1], 3))
            ex.editingFinished.connect(lambda: set_xy(0)(ex) if ex.isModified() else None)
            ey.editingFinished.connect(lambda: set_xy(1)(ey) if ey.isModified() else None)
            self.row(self.small_label("x", 14), ex, self.small_label("y", 14), ey)
        elif t == "circle":
            c = self.current_circle(o)
            rp = self.by_id(o.get("r"))
            L.out().set(rows + [["圆心", fmt_pt(c["c"])], ["半径", num(c["r"], 3)], ["半径点", (rp or {}).get("name", "")]])
            er = self.edit(num(c["r"], 3))

            def set_r():
                try:
                    v = float(er.text())
                except ValueError:
                    return
                if v <= 0.001 or not er.isModified():
                    return
                self.push_history()
                cu = self.cur_of_point(rp)
                d = ((cu[0] - c["c"][0]) / (c["r"] or 1), (cu[1] - c["c"][1]) / (c["r"] or 1))
                rp["x"], rp["y"] = apply_m(invert_m(rp.get("m")), c["c"][0] + d[0] * v, c["c"][1] + d[1] * v)
                self.refresh_all()
                self.render()
                self.schedule_save()
            er.editingFinished.connect(set_r)
            self.row(self.small_label("r", 14), er)
        elif t == "segment":
            a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
            L.out().set(rows + [["端点 A", fmt_pt(a)], ["端点 B", fmt_pt(b)], ["长度", num(self.segment_len(o), 3)]])
        elif t == "line":
            a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
            L.out().set(rows + [["过点", fmt_pt(a)], ["倾角", fmt_angle(math.atan2(b[1] - a[1], b[0] - a[0]))], ["方向", f"({num(b[0] - a[0], 2)}, {num(b[1] - a[1], 2)})"]])
        elif t == "vector":
            a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
            L.out().set(rows + [["起点", fmt_pt(a)], ["终点", fmt_pt(b)], ["分量", f"({num(b[0] - a[0], 2)}, {num(b[1] - a[1], 2)})"], ["模长", num(self.segment_len(o), 3)]])
        elif t == "polygon":
            L.out().set(rows + [["顶点数", len(o.get("pts") or [])], ["面积", num(self.polygon_area(o), 3)], ["周长", num(self.polygon_perimeter(o), 3)]])
        elif t == "function":
            ed = self.edit(pretty_expr(o["expr"]))

            def apply_fn():
                try:
                    expr = normalize_expr(ed.text())
                    compile_checked(expr)
                    self.push_history()
                    self.set_function_expr(o, expr)
                    self.refresh_all()
                    self.render()
                    self.schedule_save()
                    self.toast("函数已更新")
                except Exception as exc:  # noqa: BLE001
                    self.toast(str(exc) or "表达式无效")
            ed.returnPressed.connect(apply_fn)
            self.row(ed, self.btn("更新", apply_fn))
            self.panel_fn_detail(o, rows)
        elif t == "mdist":
            L.out().set(rows + [["类型", "两点距离"], ["数值", num(self.segment_len(o), 3)]])
        elif t == "mangle":
            L.out().set(rows + [["类型", "三点角度"], ["数值", fmt_angle(self.angle_of(o))]])
        elif t == "marea":
            p = self.by_id(o.get("poly"))
            L.out().set(rows + [["类型", "多边形面积"], ["数值", num(self.polygon_area(p), 3) if p else "—"]])
        if t not in ("mdist", "mangle", "marea"):
            self.swatches(sel)
            self.width_slider(sel)
        self.prop_actions(sel)

    # ---- 函数：性质、切线、伸缩平移
    def fn_rows(self, o):
        """右栏「性质」那一块的行：按老师板书写法整理（±∞ 端点、定义域、值域、渐近线、周期通解）。"""
        from .geo_calc import (asymptotes_text, bake, domain_text, fmt_periodic_expr, fmt_val, is_ident,
                               mono_text, period_text, periodic_families, range_text)
        f = self.fn_features(o)
        per = f.get("period")

        def fmt_zeros(lst):
            if not lst:
                return "无"
            if per and len(lst) >= 2:
                bases, step = periodic_families([x for x, _ in lst], per, tol=max(1e-2, per * 1e-3))
                if bases and len(bases) <= 2:
                    return "x = " + "，".join(fmt_periodic_expr(b, step, num) for b in bases) + "（k∈Z）"
            out = []
            for x, _y in lst[:5]:
                s, exact = fmt_val(x, num, 3)
                out.append(f"x = {s}" if exact else f"x≈{s}")
            return "，".join(out) + ("…" if len(lst) > 5 else "")

        def fmt_ext(lst, n=4):
            if not lst:
                return "—"
            if per and len(lst) >= 2:
                ys = [y for _x, y in lst]
                if max(ys) - min(ys) <= 1e-4 * (1 + abs(ys[0])):
                    bases, step = periodic_families([x for x, _ in lst], per, tol=max(1e-2, per * 1e-3))
                    if bases and len(bases) <= 2:
                        yv = fmt_val(ys[0], num, 2)[0]
                        xs_txt = "，".join(fmt_periodic_expr(b, step, num) for b in bases)
                        return f"y = {yv}（x = {xs_txt}，k∈Z）"
            s = "，".join(f"({num(x, 2)}, {num(y, 2)})" for x, y in lst[:n])
            return s + (f" 等 {len(lst)} 个" if len(lst) > n else "")

        def fmt_infl(lst, n=3):
            if not lst:
                return "—"
            if per and len(lst) >= 2:
                ys = [y for _x, y in lst]
                if max(ys) - min(ys) <= 1e-4 * (1 + abs(ys[0])):
                    bases, step = periodic_families([x for x, _ in lst], per, tol=max(1e-2, per * 1e-3))
                    if bases and len(bases) <= 2:
                        yv = fmt_val(ys[0], num, 2)[0]
                        return "，".join(f"({fmt_periodic_expr(b, step, num)}, {yv})" for b in bases) + "（k∈Z）"
            s = "，".join(f"({num(x, 2)}, {num(y, 2)})" for x, y in lst[:n])
            return s + (f" 等 {len(lst)} 个" if len(lst) > n else "")

        expr = pretty_expr(o["expr"])
        rows = [["y =", truncate(expr, 26)]]
        if not is_ident(o.get("tf")):
            rows.append(["变换后", truncate(pretty_expr(bake(o["expr"], o["tf"])), 26)])
        poles = [c for c, _ll, _rl in (f.get("vasym") or [])]
        if f.get("domain") is not None:
            rows.append(["定义域", domain_text(f["domain"], num, period=per, poles=poles)])
        if f.get("val_range") is not None:
            rows.append(["值域", range_text(f["val_range"], num)])
        rows += [["零点", fmt_zeros(f["zeros"])],
                 ["极大值", fmt_ext(f["maxima"])],
                 ["极小值", fmt_ext(f["minima"])],
                 ["拐点", fmt_infl(f["inflections"])],
                 ["与 y 轴", "—" if f["y0"] is None else f"(0, {num(f['y0'], 3)})"],
                 ["单调", mono_text(f, num)]]
        if f["parity"]:
            rows.append(["奇偶", f["parity"]])
        if per:
            rows.append(["周期", period_text(per, num)])
        asym = asymptotes_text(f, num)
        if asym:
            rows.append(["渐近线", asym])
        # 非渐近线的间断（如 floor(x) 的跳跃间断）单独列出
        jump_breaks = [b for b in f.get("breaks", ()) if not any(abs(b - c) < 1e-2 for c in poles)]
        if jump_breaks:
            rows.append(["间断", "，".join(f"x = {fmt_val(x, num, 2)[0]}" if fmt_val(x, num, 2)[1] else f"x≈{num(x, 2)}" for x in jump_breaks[:4]) + ("…" if len(jump_breaks) > 4 else "")])
        return rows

    def fn_html(self, o):
        """性质表写成能折行的段落：Out 的表格右列不折行，长的零点列表会把右栏撑宽、把按键挤出去。"""
        def esc(s):
            return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("，", "， ").replace("；", "； ")
        return "".join(f"<div style='margin:0 0 3px 0'><span style='color:{T.muted}'>{esc(k)}</span>&nbsp;&nbsp;"
                       f"<span style='color:{T.fg}'>{esc(v)}</span></div>" for k, v in self.fn_rows(o))

    def update_fn_readout(self, o):
        """拖切点、拖滑块时只更新读数，不重建整个右栏。"""
        out = self.ui.get("fnprops")
        if out is not None:
            try:
                out.set(self.fn_html(o))
            except RuntimeError:
                self.ui.pop("fnprops", None)
        tn = self.ui.get("tan_x")
        if tn is not None and o.get("tan"):
            try:
                if not tn.hasFocus():
                    tn.setText(num(o["tan"]["x"], 3))
            except RuntimeError:
                self.ui.pop("tan_x", None)

    def panel_fn_detail(self, o, head):
        L = self.L
        L.out().set(head)
        L.group("性质（可视范围内，数值近似）")
        self.ui["fnprops"] = L.out()
        self.ui["fnprops"].set(self.fn_html(o))
        L.note("选中曲线时图上标出：○ 零点　▲ 极大　▼ 极小　◇ 拐点（虚线为渐近线）。端点 ±∞ 按当前视野趋势推算，缩放、平移视野后重算。")
        L.check("不选中时也标出特殊点", bool(o.get("marks")), lambda v: self.fn_flag(o, "marks", v))
        L.check("画导函数 f′(x)（虚线）", bool(o.get("deriv")), lambda v: self.fn_flag(o, "deriv", v))

        L.group("切线与动点")
        tx = self.edit(num(o["tan"]["x"], 3) if o.get("tan") else "", ph="x =", width=70)
        self.ui["tan_x"] = tx

        def make():
            try:
                x = float(tx.text().replace("π", str(PI)))
            except ValueError:
                feats = self.fn_features(o)
                cand = feats["maxima"] + feats["minima"] + feats["zeros"]
                x = cand[0][0] if cand else (self.fn_x_range(o)[0] + self.fn_x_range(o)[1]) / 2
            self.push_history()
            self.set_tangent(o, x, snap=False)
            self.refresh_all()
            self.render()
            self.schedule_save()
        tx.returnPressed.connect(make)
        self.row(self.small_label("在", 16), tx, self.small_label("处", 16), self.btn("作切线", make, True))
        if o.get("tan"):
            def normal(v):
                self.push_history()
                o["tan"]["normal"] = bool(v)
                self.render()
                self.schedule_save()
            L.check("同时画法线", bool(o["tan"].get("normal")), normal)
            playing = self.play_id == o["id"]
            self.row(self.btn("停止" if playing else "让切点沿曲线走", lambda: self.stop_play() if self.play_id == o["id"] else self.start_play(o)),
                     self.btn("去掉切线", lambda: self.remove_tangent(o)))
            L.note("拖动切点沿曲线移动；靠近零点、极值点、拐点和整数 x 会吸附，按住 Alt 不吸附。双击曲线也能直接作切线。")
        else:
            L.note("不填 x 时，切点放在第一个极值点或零点上。也可以直接双击曲线。")

        self.panel_fn_transform(o)

    def panel_fn_transform(self, o):
        from .geo_calc import IDENT_TF, bake, is_ident, tf_notes
        L = self.L
        L.group("伸缩平移　y = a·f(b(x − h)) + k")
        tf = dict(IDENT_TF, **(o.get("tf") or {}))
        st = {"dirty": False}
        note = L.note("")

        def show():
            lines = tf_notes(tf)
            note.setText("虚线是原图。" + ("先" + "，再".join(lines) + "。" if lines else "拖动下面的滑块看图像怎么变。"))

        def setter(key):
            def cb(v):
                if key == "b" and abs(v) < 0.1:
                    v = 0.1 if v >= 0 else -0.1
                if not st["dirty"]:
                    self.push_history()
                    st["dirty"] = True
                tf[key] = v
                o["tf"] = None if is_ident(tf) else dict(tf)
                compose_fn(o)
                show()
                self.update_fn_readout(o)
                self.render()
                self.schedule_save()
            return cb
        show()
        L.slider("a · 纵向伸缩", -3, 3, 0.1, tf["a"], setter("a"))
        L.slider("b · 横向伸缩", -3, 3, 0.1, tf["b"], setter("b"))
        L.slider("h · 左右平移", -6, 6, 0.1, tf["h"], setter("h"))
        L.slider("k · 上下平移", -6, 6, 0.1, tf["k"], setter("k"))

        def reset():
            self.push_history()
            o["tf"] = None
            compose_fn(o)
            self.refresh_all()
            self.render()
            self.schedule_save()

        def write_back():
            if is_ident(o.get("tf")):
                return
            self.push_history()
            self.set_function_expr(o, bake(o["expr"], o["tf"]))
            o["tf"] = None
            compose_fn(o)
            self.refresh_all()
            self.render()
            self.schedule_save()
            self.toast("已写进解析式")
        self.row(self.btn("还原", reset), self.btn("写进解析式", write_back))

    def fn_flag(self, o, key, v):
        self.push_history()
        o[key] = bool(v)
        self.render()
        self.schedule_save()

    def remove_tangent(self, o):
        self.stop_play()
        self.push_history()
        o.pop("tan", None)
        self.refresh_all()
        self.render()
        self.schedule_save()

    def start_play(self, o):
        """切点自己沿曲线从左走到右（视野范围内），约 6 秒走完。"""
        if not o.get("tan"):
            self.set_tangent(o, self.fn_x_range(o)[0], snap=False)
        self.play_id = o["id"]
        if self.play_timer is None:
            self.play_timer = QTimer(self.L.stage)
            self.play_timer.setInterval(33)
            self.play_timer.timeout.connect(self._play_step)
            self.L.timers.append(self.play_timer)
        self.play_timer.start()
        self.build_panel()

    def _play_step(self):
        o = self.by_id(self.play_id) if self.play_id else None
        if not o or not o.get("tan") or not self.L.stage.isVisible():
            self.stop_play()
            return
        x0, x1 = self.fn_x_range(o)
        x = o["tan"]["x"] + (x1 - x0) / 180
        if x > x1:
            x = x0
        o["tan"]["x"] = x
        self.update_fn_readout(o)
        self.render()

    def stop_play(self):
        was = self.play_id
        self.play_id = None
        if self.play_timer is not None:
            self.play_timer.stop()
        if was:
            self.schedule_save()
            self.build_panel()

    def swatches(self, sel):
        btns = []
        for key, name in COLOR_KEYS:
            b = QPushButton("")
            b.setFixedSize(26, 22)
            b.setToolTip(name)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            on = all(o.get("color") == key for o in sel)
            b.setStyleSheet(f"QPushButton{{background:{qc(self.color_of(key)).name()};border-radius:6px;border:{'2px solid ' + T.fg if on else '1px solid ' + T.line};}}")

            def pick(_=False, k=key):
                self.push_history()
                for o in sel:
                    o["color"] = k
                self.refresh_all()
                self.render()
                self.schedule_save()
            b.clicked.connect(pick)
            btns.append(b)
        self.row(*btns, QWidget())

    def width_slider(self, sel):
        st = {"dirty": False}

        def set_w(v):
            if not st["dirty"]:
                self.push_history()
                st["dirty"] = True
            for o in sel:
                o["width"] = v
            self.render()
            self.schedule_save()
        self.L.slider("线宽", 1, 5, 0.5, sel[0].get("width") or 2, set_w)

    def prop_actions(self, sel):
        def vis():
            self.push_history()
            hide = not all(o["hidden"] for o in sel)
            for o in sel:
                o["hidden"] = hide
            self.refresh_all()
            self.render()
            self.schedule_save()
        self.row(self.btn("显示/隐藏", vis), self.btn("删除", self.delete_selection))

    def panel_matrix(self):
        L = self.L
        L.group("变换矩阵")
        lt = self.current_transform() or {"type": "identity", "label": "尚未变换，当前为单位矩阵", "matrix": list(IDENT), "params": {}}
        p = lt.get("params") or {}
        rows = "<br>".join(matrix_rows(lt["matrix"]))
        ty = lt["type"]

        def pv():
            return fmt_pt(p["pivot"]) if p.get("pivot") else "原点"
        extra = ""
        if ty == "rotate" and is_num(p.get("angle")):
            extra = f"角度 θ = {num(p['angle'], 2)}° · 中心 {pv()}"
        elif ty == "scale" and is_num(p.get("k")):
            extra = f"比例 k = {num(p['k'], 3)} · 中心 {pv()}"
        elif ty == "translate" and is_num(p.get("dx")):
            extra = f"向量 ({num(p['dx'], 2)}, {num(p['dy'], 2)})"
        elif ty == "sym-line":
            extra = "对称轴 · " + (p.get("axisLabel") or "直线")
        elif ty == "sym-point":
            extra = "对称中心 · " + pv()
        elif ty == "identity":
            extra = "选择对象后可做平移 / 旋转 / 缩放 / 对称"
        html = f"<span style='color:{T.muted}'>T　{lt.get('label') or ''}</span><br><span style='font-family:monospace'>{rows.replace(' ', '&nbsp;')}</span>"
        if extra:
            html += f"<br><span style='color:{T.muted}'>{extra}</span>"
        cum = self.selection_matrix()
        if cum and not is_i(cum) and any(abs(cum[i] - lt["matrix"][i]) > 1e-9 for i in range(9)):
            html += f"<br><span style='color:{T.muted}'>累计 M</span><br><span style='font-family:monospace'>{'<br>'.join(matrix_rows(cum)).replace(' ', '&nbsp;')}</span>"
        L.out().set(html)

    def panel_transform(self):
        L = self.L
        L.group("变换")
        opts = [["origin", "原点 (0, 0)"], ["center", "选中对象中心"]]
        opts += [["point:" + o["id"], f"点 {o.get('name', '')} {fmt_pt(self.cur_of_point(o))}"] for o in self.objects if o["type"] == "point" and not o["aux"]]
        if self.pivot_mode not in [x[0] for x in opts]:
            self.pivot_mode = "origin"
        L.select("中心", opts, self.pivot_mode, lambda v: (setattr(self, "pivot_mode", v), self.schedule_save()))

        def tr_row(name, keys, apply_fn, handle):
            eds = []
            for k, ph in keys:
                ed = self.edit(self.tx[k], ph=ph)
                ed.textChanged.connect(lambda t, kk=k: self.tx.__setitem__(kk, t))
                ed.returnPressed.connect(apply_fn)
                eds.append(ed)
            self.row(self.small_label(name, 30), *eds, self.btn("应用", apply_fn, width=46), self.btn("拖", lambda: self.begin_handle(handle), width=40))
        tr_row("平移", [("dx", "dx"), ("dy", "dy")], lambda: self.numeric_apply("translate"), "translate")
        tr_row("旋转", [("angle", "°")], lambda: self.numeric_apply("rotate"), "rotate")
        tr_row("缩放", [("k", "k")], lambda: self.numeric_apply("scale"), "scale")
        self.row(self.small_label("对称", 30), self.btn("关于点", self.apply_sym_point), self.btn("关于线", self.apply_sym_line))
        ax = [["x", "x 轴 (y = 0)"], ["y", "y 轴 (x = 0)"]] + [["line:" + o["id"], "直线 " + self.object_label(o)] for o in self.objects if o["type"] == "line" and not o["aux"]]
        if self.axis_mode not in [x[0] for x in ax]:
            self.axis_mode = "x"
        L.select("对称轴", ax, self.axis_mode, lambda v: (setattr(self, "axis_mode", v), self.schedule_save()))

    def panel_preset(self):
        if not self.preset:
            return
        L = self.L
        pid = self.preset
        L.group("预设参数")
        p = self.params

        def slider(label, key, mn, mx, step, unit=""):
            st = {"dirty": False}

            def cb(v):
                if not st["dirty"]:
                    self.push_history()
                    st["dirty"] = True
                if pid == "inverse" and key == "k" and abs(v) < 0.125:
                    v = -0.25 if v < 0 else 0.25
                self.params[key] = v
                self.refresh_preset_objects()
                if self.ui.get("eq") is not None and pid == "circletangent":
                    self.ui["eq"].setText(self.tangent_equation())
                self.render()
                self.schedule_save()
            L.slider(label, mn, mx, step, p[key], cb, unit)
        if pid == "triangle":
            L.note("原像保留为虚线，实线为当前像；连续点击可叠加。")
            for k, t in (("translate", "平移 (2, 1)"), ("rotate", "旋转 60°"), ("scale", "缩放 ×1.5"), ("sym", "关于 x 轴对称")):
                L.button(t, lambda _b, kk=k: self.triangle_demo(kk))
        elif pid == "quadratic":
            L.note("y = a(x − h)² + k")
            slider("a · 开口", "a", -2, 2, 0.1)
            slider("h · 横移", "h", -5, 5, 0.1)
            slider("k · 纵移", "k", -5, 4, 0.1)
        elif pid == "trig":
            L.note("y = A sin(Bx + φ) + k")
            slider("A · 振幅", "A", -3, 3, 0.1)
            slider("B · 频率", "B", 0.2, 4, 0.1)
            slider("φ · 初相", "phi", -PI, PI, 0.05, "rad")
            slider("k · 纵移", "k", -3, 3, 0.1)
        elif pid == "inverse":
            L.note("y = k / x　两支曲线分别位于一三象限或二四象限。")
            slider("k", "k", -8, 8, 0.25)
        elif pid == "circletangent":
            L.note("x cos θ + y sin θ = r　P 为切点，OP 为半径。")
            slider("r · 半径", "r", 0.6, 4, 0.1)
            slider("θ · 切点角", "theta", 0, 360, 1, "°")
            self.ui["eq"] = L.note(self.tangent_equation())

    def panel_measure(self):
        L = self.L
        L.group("测量")

        def mode(k):
            def cb(_b):
                self.measure_mode = k
                self.measure_picks = []
                self.set_tool("measure")
            return cb
        L.button("距离", mode("dist"), self.tool == "measure" and self.measure_mode == "dist")
        L.button("角度", mode("angle"), self.tool == "measure" and self.measure_mode == "angle")
        L.button("面积", mode("area"), self.tool == "measure" and self.measure_mode == "area")
        L.check("显示测量", self.show_measure, lambda v: self.flag("show_measure", v))

    def flag(self, name, v):
        setattr(self, name, v)
        self.render()
        self.schedule_save()

    def panel_display(self):
        L = self.L
        L.group("显示")
        L.check("网格", self.show_grid, lambda v: self.flag("show_grid", v))
        L.check("吸附", self.snap_grid, lambda v: self.flag("snap_grid", v))
        L.check("变换标注", self.show_annotation, lambda v: self.flag("show_annotation", v))
        L.note("Esc 取消 · Delete 删除 · Ctrl+Z 撤销 · 方向键平移 · +/− 缩放（先点一下画布）")

    # ---- 存档
    def export_state(self):
        return {"v": 1, "objects": [self.strip_object(o) for o in self.objects], "view": dict(self.view), "selection": list(self.selection), "preset": self.preset,
                "params": self.params, "lastTransform": self.last_transform, "pivotMode": self.pivot_mode, "axisMode": self.axis_mode,
                "measureMode": self.measure_mode, "showGrid": self.show_grid, "snapGrid": self.snap_grid, "showMeasure": self.show_measure,
                "showAnnotation": self.show_annotation}

    def save_state(self):
        try:
            save_json(SAVE, self.export_state())
        except (OSError, TypeError):
            pass

    def load_state(self,data=None):
        d = load_json(SAVE) if data is None else data
        if not isinstance(d, dict) or not isinstance(d.get("objects"), list):
            return False
        self.objects = [self.hydrate_object(o) for o in d["objects"] if o and o.get("id") and o.get("type")]
        v = d.get("view") or {}
        self.view = {"cx": v.get("cx", 0) if is_num(v.get("cx")) else 0, "cy": v.get("cy", 0) if is_num(v.get("cy")) else 0,
                     "scale": clamp(v["scale"], 5, 420) if is_num(v.get("scale")) else 52}
        self.selection = [i for i in d.get("selection") or [] if self.by_id(i)]
        self.preset = d.get("preset") or ""
        self.params = {**self.default_params(self.preset), **(d.get("params") or {})}
        self.last_transform = d.get("lastTransform")
        self.pivot_mode = d.get("pivotMode") or "origin"
        self.axis_mode = d.get("axisMode") or "x"
        self.measure_mode = d.get("measureMode") or "dist"
        self.show_grid = d.get("showGrid") is not False
        self.snap_grid = d.get("snapGrid") is not False
        self.show_measure = d.get("showMeasure") is not False
        self.show_annotation = d.get("showAnnotation") is not False
        return True

    def export_png(self):
        path, _ = QFileDialog.getSaveFileName(self.L.stage, "导出 PNG", "几何画板.png", "PNG 图片 (*.png)")
        if path:
            self.L.stage.grab().save(path, "PNG")
            self.toast("已导出 PNG")


@bench.reg(id="draw", subj="math", short="几何画板", title="几何画板", sub="点 · 线 · 圆 · 多边形 · 向量 · 函数 · 平移 / 旋转 / 缩放 / 对称",
           desc="像 GeoGebra 一样自由作图：画点、线段、圆、多边形和 y = f(x)，拖点联动；选中后做平移、旋转、缩放、点对称、线对称，原像留虚线，右侧给出变换矩阵；可量距离、角度、面积，自动保存。",
           art=ART)
def geo(B):
    bd = Board(B)
    from .geo_construct import install,TOOLS as CONSTRUCTIONS
    begin_construction=install(bd)
    L = B.L
    bd.w, bd.h = bd.c.w, bd.c.h
    L.on_draw(bd.draw)
    L.stage.mouse = bd.on_mouse
    L.on_key(bd.on_key)
    B.palette([
        {"title":"辅助作图","tab":"item","collapsed":True,"items":[{"id":"construct-"+key,"icon":ICONS["line"],"label":value[0],"sub":"定义点移动后实时联动","click":lambda k=key:begin_construction(k)} for key,value in CONSTRUCTIONS.items()]},
        {"title": "工具", "items": [{"id": "tool-" + t, "icon": ICONS[t], "label": n, "sub": f"快捷键 {k}", "click": (lambda t=t: bd.set_tool(t))} for t, n, k in TOOLS]},
        {"title": "操作", "items": [
            {"icon": ICONS["undo"], "label": "撤销", "sub": "Ctrl+Z", "click": lambda: bd.do_undo()},
            {"icon": ICONS["redo"], "label": "重做", "sub": "Ctrl+Shift+Z", "click": lambda: bd.do_redo()},
            {"icon": ICONS["zoomIn"], "label": "放大", "sub": "+", "click": lambda: bd.zoom_by(1.2)},
            {"icon": ICONS["zoomOut"], "label": "缩小", "sub": "−", "click": lambda: bd.zoom_by(1 / 1.2)},
            {"icon": ICONS["reset"], "label": "适配全部对象", "sub": "把所有图形放进视野", "click": bd.fit_view},
            {"icon": ICONS["trash"], "label": "清空画布", "sub": "可撤销", "click": bd.clear_scene},
            {"icon": ICONS["export"], "label": "导出 PNG", "sub": "Ctrl+S", "click": bd.export_png}]},
        {"title": "预设", "tab": "exp", "items": [{"icon": ICONS["preset"], "label": p["name"], "sub": p["desc"], "click": (lambda i=p["id"]: bd.apply_preset(i))} for p in PRESETS]},
    ], labels={"item": "工具", "exp": "预设"})
    B.geo_board = bd      # 自测用
    B.tips([("怎么用", ["左侧工具条选工具：点、线段、直线、圆、多边形、向量；在画布上点击作图，拖动顶点会联动。",
                     "函数：右栏点常用函数一键画出；选中曲线后看零点、极值、单调区间，双击曲线作切线，拖切点沿曲线走（会吸附到零点、极值点），用 a、b、h、k 滑块伸缩平移。",
                     "选中图形后在右栏「变换」：平移、旋转、缩放、点对称、线对称，可以连续叠加，右栏显示累计矩阵 M。",
                     "拖动空白处平移视野，滚轮缩放；左栏「预设」有三角形四连变换、二次函数、三角函数、圆与切线。",
                     "画板内容会自动保存在本机，下次打开还在。"])])
    if not bd.load_state():
        bd.apply_preset("triangle", no_history=True, silent=True, preview=True)
    bd.refresh_all()
    def restore(data):
        if not bd.load_state(data):
            raise ValueError("几何画板快照无效")
        bd.refresh_all()
        bd.schedule_save()
    B.transfer(bd.export_state,restore,bd)
