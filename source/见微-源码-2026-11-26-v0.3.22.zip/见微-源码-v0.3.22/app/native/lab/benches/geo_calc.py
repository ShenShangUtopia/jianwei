"""几何画板的函数分析（纯数值，不依赖 Qt）：零点、极值、拐点、单调区间、奇偶性、周期、切线、伸缩平移。

都在给定区间（一般是当前可视范围）里数值求解：先密集取样找变号，再二分细化。
结果是「数值近似」，界面上也这么标。间断处（tan、1/x）两侧的跳变不算零点、不算极值。
"""
from __future__ import annotations

import math
import re
from fractions import Fraction

N = 900          # 取样点数
_BIS = 60        # 二分次数


def _ok(y):
    return isinstance(y, (int, float)) and math.isfinite(y)


def _eval(f, x):
    """安全求值：直接传 math.exp 等裸函数时，溢出 / 除零 / 定义域外统一转 NaN。"""
    try:
        v = f(x)
        return float(v) if isinstance(v, (int, float)) else float("nan")
    except (ValueError, ZeroDivisionError, OverflowError, TypeError):
        return float("nan")


def deriv(f, x):
    h = 1e-5 * (1 + abs(x))
    a, b = f(x - h), f(x + h)
    return (b - a) / (2 * h) if _ok(a) and _ok(b) else float("nan")


def deriv2(f, x):
    h = 1e-3 * (1 + abs(x))
    a, m, b = f(x - h), f(x), f(x + h)
    return (a - 2 * m + b) / (h * h) if _ok(a) and _ok(m) and _ok(b) else float("nan")


def _bisect(g, a, b, at_bad=False):
    """at_bad：碰到求不出的点就返回这个点（找函数自身的零点时，那里正是极点：1/(x−1) 在 1）。"""
    ga = g(a)
    for _ in range(_BIS):
        m = (a + b) / 2
        gm = g(m)
        if not _ok(gm):
            return m if at_bad else None
        if (ga <= 0) == (gm <= 0):
            a, ga = m, gm
        else:
            b = m
    return (a + b) / 2


def _continuous(f, a, b, ya, yb, span):
    """a、b 之间没有间断：中点的值在两端之间附近，且两端差得不离谱。"""
    m = f((a + b) / 2)
    if not _ok(m):
        return False
    lo, hi = min(ya, yb), max(ya, yb)
    pad = (hi - lo) * 0.6 + span * 1e-3
    return lo - pad <= m <= hi + pad and abs(yb - ya) < span * 0.5 + 1e-9


def _jump(f, a, b, ya, yb, span, dx):
    """同号的两点之间有没有间断：偶次极点（1/x²）或跳跃（floor）。"""
    m = f((a + b) / 2)
    if not _ok(m):
        return True
    lo, hi = min(ya, yb), max(ya, yb)
    pad = (hi - lo) * 0.6 + span * 1e-3
    if not (lo - pad <= m <= hi + pad):
        return True                     # 中点比两头都大得多：中间有极点（1/x² 在 0）
    d = abs(yb - ya)
    if d <= max(1e-12, span * 1e-9):
        return False
    da, db = deriv(f, a + dx * 0.05), deriv(f, b - dx * 0.05)
    if not (_ok(da) and _ok(db)):
        return False
    return d > 20 * dx * max(abs(da), abs(db)) + span * 1e-9


def _locate_jump(f, a, b):
    """把间断位置收窄：极点找 |f| 最大处，跳跃找两边值分开的地方。"""
    ya, yb = f(a), f(b)
    probe = [abs(f(a + (b - a) * t)) for t in (0.25, 0.5, 0.75)]
    pole = any(_ok(v) and v > 2 * max(abs(ya), abs(yb)) for v in probe) or not all(_ok(v) for v in probe)
    lo, hi = a, b
    for _ in range(_BIS):
        if pole:
            m1, m2 = lo + (hi - lo) / 3, hi - (hi - lo) / 3
            v1, v2 = f(m1), f(m2)
            v1 = abs(v1) if _ok(v1) else float("inf")
            v2 = abs(v2) if _ok(v2) else float("inf")
            if v1 < v2:
                lo = m1
            else:
                hi = m2
        else:
            m = (lo + hi) / 2
            v = f(m)
            if not _ok(v):
                break
            if abs(v - ya) <= abs(v - yb):
                lo = m
            else:
                hi = m
    return (lo + hi) / 2


def _crossings(vals, eps):
    """vals 里正负号的变化处：[(左下标, 右下标, 左边的号)]。中间等于 0（|v| ≤ eps）的样本跳过，
    这样取样恰好落在极值点、拐点上（导数为 0）时也能找到；遇到求不出的值就断开。"""
    out, last = [], None
    for i, v in enumerate(vals):
        if not _ok(v):
            last = None
            continue
        if abs(v) <= eps:
            continue
        s = v > 0
        if last is not None and last[1] != s:
            out.append((last[0], i, last[1]))
        last = (i, s)
    return out


def _dedupe(xs, tol):
    """挨着的合并成一个（取最左）；一串连着的也合并（floor(x) 在 [0,1) 上整段是 0，只留 0）。"""
    out, last = [], None
    for x in sorted(xs):
        if last is None or abs(x - last) > tol:
            out.append(x)
        last = x
    return out


def _robust_span(fin):
    """值域的「主体」：去掉两头各 5%（tan、1/x 在极点旁的巨大值不该把跨度撑大，否则跳变会被当成连续）。"""
    if not fin:
        return 1.0
    s = sorted(fin)
    k = len(s) // 20
    lo, hi = s[k], s[-1 - k]
    span = hi - lo
    if span <= 1e-12:
        span = s[-1] - s[0]
    return span if span > 1e-12 else 1.0


def analyze(f, x0, x1, n=N):
    """在 [x0, x1] 里找特殊点。返回 dict：zeros、maxima、minima、inflections（都是 [(x, y)]）、
    y0（与 y 轴交点或 None）、mono（[(a, b, '增'/'减')]）、mono_intervals、parity、period、
    breaks（间断点 x）、edges、domain、val_range、vasym、hasym。"""
    if not (math.isfinite(x0) and math.isfinite(x1)) or x1 - x0 <= 1e-9:
        return dict(zeros=[], maxima=[], minima=[], inflections=[], y0=None, mono=[], mono_intervals=[],
                    parity="", period=None, breaks=[], edges=[], domain=[], val_range=[], vasym=[], hasym=[])
    dx = (x1 - x0) / n
    xs = [x0 + i * dx for i in range(n + 1)]
    ys = [f(x) for x in xs]
    fin = [y for y in ys if _ok(y)]
    span = _robust_span(fin)
    tol = dx * 1.5
    small = max(1e-9, span * 1e-6)

    def edge(a, b):
        """有定义 / 没定义的分界（ln x 在 0、sqrt 在 0）：二分到分界处。"""
        ga = _ok(f(a))
        for _ in range(_BIS):
            m = (a + b) / 2
            if _ok(f(m)) == ga:
                a = m
            else:
                b = m
        return (a + b) / 2

    zeros, breaks, edges = [], [], []
    for i in range(n):
        a, b, ya, yb = xs[i], xs[i + 1], ys[i], ys[i + 1]
        if not (_ok(ya) and _ok(yb)):
            if _ok(ya) != _ok(yb):
                e = edge(a, b)
                edges.append(e)              # 定义域的边界（ln x、sqrt x 在 0），不算间断
                se = _snap(e)
                fe = f(se)
                if _ok(fe) and abs(fe) <= small * 1e3:
                    zeros.append(se)         # 定义域端点处的零点（如 sqrt(x) 在 x = 0）
            continue
        if ya == 0:
            zeros.append(a)
            if yb != 0 and _jump(f, a, b, ya, yb, span, dx):     # floor(x) 在 1 处：从 0 跳到 1
                breaks.append(_locate_jump(f, a, b))
            continue
        if (ya < 0) != (yb < 0):
            # 0.3.14：先二分，再看收敛点的函数值——很小是零点，很大（tan、1/x 的极点）或两边跳（取整）是间断。
            # 以前先用「跨度的一半」判连续，tan 的极点旁值很大把跨度撑大，渐近线被当成零点
            r = _bisect(f, a, b, at_bad=True)
            fr = f(r) if r is not None else float("nan")
            if r is not None and _ok(fr) and abs(fr) <= small * 1e3 and not _jump(f, a, b, ya, yb, span, dx):
                zeros.append(r)
            else:
                breaks.append(r if r is not None else (a + b) / 2)
        elif _jump(f, a, b, ya, yb, span, dx):
            breaks.append(_locate_jump(f, a, b))
    if _ok(ys[-1]) and ys[-1] == 0:
        zeros.append(xs[-1])

    def smooth(i, j):
        """i 到 j 之间每一小段都连续（没有跨过间断）。"""
        return all(_ok(ys[t]) and _ok(ys[t + 1]) and not _jump(f, xs[t], xs[t + 1], ys[t], ys[t + 1], span, dx) for t in range(i, j))

    ds = [deriv(f, x) for x in xs]
    dscale = max((abs(v) for v in ds if _ok(v)), default=0.0)
    maxima, minima, touch = [], [], []
    for i, j, up in _crossings(ds, dscale * 1e-9):
        if not smooth(i, j):
            continue
        r = _bisect(lambda x: deriv(f, x), xs[i], xs[j])
        if r is None:
            continue
        y = f(r)
        if not _ok(y):
            continue
        (maxima if up else minima).append((r, y))
        if abs(y) < span * 1e-7:          # 切于 x 轴（如 x²）：也是零点
            touch.append(r)
    zeros = _dedupe(zeros + touch, tol)

    d2 = [deriv2(f, x) for x in xs]
    d2s = sorted(abs(v) for v in d2 if _ok(v))
    scale = d2s[int(len(d2s) * 0.9)] if d2s else 0.0      # 用 90% 分位：极点旁的巨大二阶导不撑大尺度
    # 0.3.14：二阶导的数值噪声约 1e-16·|f| / h²；一次函数（100x）、(x²−1)/(x−1) 的二阶导全是噪声，以前报出上百个拐点
    fmax = max((abs(y) for y in fin), default=1.0)
    noise = 1e-15 * (fmax + 1) / (1e-3 * (1 + max(abs(x0), abs(x1)))) ** 2
    infl = []
    if scale > max(1e-9, noise * 50):
        for i, j, _up in _crossings(d2, scale * 1e-4):
            if not smooth(i, j) or any(min(abs(xs[i] - bx), abs(xs[j] - bx)) < dx * 4 for bx in breaks):
                continue
            r = _bisect(lambda x: deriv2(f, x), xs[i], xs[j])
            if r is not None and _ok(f(r)):
                infl.append((r, f(r)))
    infl = [p for p in infl if all(abs(p[0] - q[0]) > tol for q in maxima + minima)]

    y0 = f(0.0) if x0 <= 0 <= x1 and _ok(f(0.0)) else None

    # 单调区间：以极值点、间断点、定义域端点为界
    cuts = sorted([x0] + [p[0] for p in maxima + minima] + breaks + edges + [x1])
    mono = []
    for a, b in zip(cuts, cuts[1:]):
        if b - a < dx:
            continue
        # 0.3.14：用两端（略往里缩）的函数值判增减，不用中点导数的绝对阈值（e^(−x²) 尾巴上导数 ~1e-60，以前判不出）
        e = (b - a) * 0.02
        fa, fb = f(a + e), f(b - e)
        if not (_ok(fa) and _ok(fb)) or abs(fb - fa) <= 1e-12 * (1 + abs(fa)):
            d = deriv(f, (a + b) / 2)
            if not _ok(d) or d == 0:
                continue
        else:
            d = fb - fa
        kind = "增" if d > 0 else "减"
        if mono and mono[-1][2] == kind and abs(mono[-1][1] - a) < dx * 2 and not any(abs(a - bx) < dx * 2 for bx in breaks + edges):
            mono[-1] = (mono[-1][0], b, kind)
        else:
            mono.append((a, b, kind))

    tiny = 1e-9 * (x1 - x0)

    def cx(x):                          # −0.0、1e-17 这种显示成 0
        return 0.0 if abs(x) < tiny else x

    def cp(pts):
        return [(cx(x), y) for x, y in pts]

    zeros = [cx(z) for z in zeros]
    breaks = _dedupe([cx(b) for b in breaks], tol)
    raw_edges = [cx(e) for e in edges]           # 定义域按取样里的每次变化一一对应，不能先合并
    edges = _dedupe(raw_edges, tol)
    mono = [(cx(a), cx(b), k) for a, b, k in mono]
    maxima_p = cp(_dedupe_pts(maxima, tol))
    minima_p = cp(_dedupe_pts(minima, tol))
    infl_p = cp(_dedupe_pts(infl, tol))
    zeros_p = [(z, 0.0) for z in zeros]
    per = (period(f, x0, x1, maxima_p or minima_p)
           or period(f, x0, x1, zeros_p)
           or period(f, x0, x1, [(b, 0.0) for b in breaks]))
    dom = _domain(f, ys, raw_edges, breaks, span)
    vasym = _vertical_asymptotes(f, breaks + edges, span, tol)
    end_l = _end_behavior(f, -1, x0, x1, span) if (per is None and _ok(ys[0])) else ("none", None)
    end_r = _end_behavior(f, +1, x0, x1, span) if (per is None and _ok(ys[-1])) else ("none", None)
    hasym = _horizontal_asymptotes(end_l, end_r, fin)
    mono_iv = _mono_intervals(f, mono, x0, x1, dx, tol, breaks, edges, span, per)
    val_rng = _val_range(f, xs, ys, fin, dom, maxima_p, minima_p, vasym, end_l, end_r, per, x0, x1)
    return dict(zeros=zeros_p, maxima=maxima_p, minima=minima_p, inflections=infl_p, y0=y0,
                mono=mono, mono_intervals=mono_iv, parity=parity(f, x0, x1), period=per,
                breaks=breaks, edges=edges, domain=dom, val_range=val_rng, vasym=vasym, hasym=hasym)


def _snap(x):
    r = round(x, 6)
    return r if abs(r - x) < 1e-7 else x


def _snap_nice(x):
    """靠近 0、整数或简单 π 有理倍时吸附，避免 1.5707963 写成小数。"""
    if abs(x) < 1e-5:
        return 0.0
    ri = round(x)
    if abs(x - ri) < 1e-5:
        return float(ri)
    ratio = x / math.pi
    for q in (1, 2, 3, 4, 6):
        p = round(ratio * q)
        if p != 0 and abs(p) <= 24 and abs(ratio - p / q) < 1e-4:
            return p * math.pi / q
    return _snap(x)


def _side_diverge(f, c, sign, span):
    """判断 x → c± 时 f(x) 是否发散到 +∞ 或 −∞（包括 1/x、1/x²、tan 和慢发散的 ln x）。"""
    steps = (1e-2, 1e-5, 1e-8, 1e-11)
    vals = []
    for e in steps:
        v = _eval(f, c + sign * e)
        if isinstance(v, (int, float)) and math.isinf(v):
            return "+inf" if v > 0 else "-inf"
        if not _ok(v):
            break
        vals.append(v)
    if len(vals) < 3:
        return None
    diffs = [b - a for a, b in zip(vals, vals[1:])]
    if all(d > 0 for d in diffs):
        if (abs(vals[-1]) > max(20.0, 5.0 * span) and abs(vals[-1]) > 5.0 * max(1.0, abs(vals[0]))) or (
                abs(vals[-1] - vals[0]) > 8.0 and abs(diffs[-1]) >= 0.4 * abs(diffs[0])):
            return "+inf"
    if all(d < 0 for d in diffs):
        if (abs(vals[-1]) > max(20.0, 5.0 * span) and abs(vals[-1]) > 5.0 * max(1.0, abs(vals[0]))) or (
                abs(vals[-1] - vals[0]) > 8.0 and abs(diffs[-1]) >= 0.4 * abs(diffs[0])):
            return "-inf"
    return None


def _vertical_asymptotes(f, cands, span, tol):
    """找铅直渐近线：[(x, 左极限 '+inf'/'-inf'/None, 右极限 '+inf'/'-inf'/None)]。"""
    out = []
    for raw in _dedupe(cands, tol):
        c = _snap_nice(raw)
        ll = _side_diverge(f, c, -1, span)
        rl = _side_diverge(f, c, +1, span)
        if ll or rl:
            out.append((c, ll, rl))
    return out


def _end_behavior(f, sign, x0, x1, span):
    """探测 x → ±∞ 的趋势：('asym', L)、('inf', +1/-1) 或 ('other', None)。"""
    base = max(20.0, abs(x1 if sign > 0 else x0) * 2.0)
    # 先缓步试探（防止 exp(x) 在 1000 处直接溢出成 nan），再按 10 倍拉远
    xs = [sign * base * m for m in (1, 2.5, 6, 15, 40, 120, 400, 1500, 1e4, 1e5)]
    vals = []
    overflowed = False
    for x in xs:
        v = _eval(f, x)
        if isinstance(v, (int, float)) and math.isinf(v):
            return ("inf", 1 if v > 0 else -1)
        if not _ok(v):
            overflowed = True
            break
        vals.append(v)
    if overflowed and len(vals) >= 2:
        if abs(vals[-1]) > max(1e6, 1e3 * span) and abs(vals[-1]) > 5 * max(1.0, abs(vals[0])):
            return ("inf", 1 if vals[-1] > 0 else -1)
        return ("other", None)
    if len(vals) < 5:
        return ("other", None)
    tail = vals[-4:]
    d = [abs(b - a) for a, b in zip(tail, tail[1:])]
    scale = max(1.0, abs(tail[-1]))
    # 收敛到水平渐近线：相邻差快速变小，且末段变化极小
    if d[-1] <= 1e-3 * scale and (d[-1] == 0 or (d[0] > 0 and d[-1] < 0.35 * d[0])):
        L = 0.0 if abs(tail[-1]) < 1e-4 else _snap_nice(tail[-1])
        return ("asym", L)
    # 单调增长/下降且步幅不衰减（如 x、x²、ln x、x^(1/3)）
    sd = [b - a for a, b in zip(tail, tail[1:])]
    if all(v > 0 for v in sd) and sd[-1] >= 0.4 * sd[0] and tail[-1] - vals[0] > max(2.0, 0.5 * span):
        return ("inf", 1)
    if all(v < 0 for v in sd) and abs(sd[-1]) >= 0.4 * abs(sd[0]) and vals[0] - tail[-1] > max(2.0, 0.5 * span):
        return ("inf", -1)
    return ("other", None)


def _horizontal_asymptotes(end_l, end_r, fin):
    """汇总水平渐近线（常函数不算渐近线）。"""
    if not fin or max(fin) - min(fin) <= 1e-9 * (1 + abs(fin[0])):
        return []
    out = []
    for kind, val in (end_l, end_r):
        if kind == "asym" and not any(abs(val - u) < 1e-4 for u in out):
            out.append(val)
    return sorted(out)


def _mono_intervals(f, mono, x0, x1, dx, tol, breaks, edges, span, per):
    """带开闭括号和 ±∞ 端点的单调区间：[(a_or_None, a_closed, b_or_None, b_closed, '增'/'减')]。"""
    def is_open_pt(x):
        if any(abs(x - bx) <= tol for bx in breaks):
            return True
        v = _eval(f, _snap(x))
        return not _ok(v) or abs(v) > 1e6 * span

    out = []
    for a, b, k in mono:
        at_l = abs(a - x0) <= dx * 1.5
        at_r = abs(b - x1) <= dx * 1.5
        lo = None if (at_l and per is None) else _snap_nice(a)
        hi = None if (at_r and per is None) else _snap_nice(b)
        lc = False if lo is None else (not is_open_pt(a))
        rc = False if hi is None else (not is_open_pt(b))
        out.append((lo, lc, hi, rc, k))
    return out


def _merge_intervals(ivs):
    """合并重叠或相接的实数区间 [(lo_or_None, lc, hi_or_None, rc)]。"""
    if not ivs:
        return []

    def lo_key(iv):
        return (0, 0.0, 0) if iv[0] is None else (1, iv[0], 0 if iv[1] else 1)

    res = []
    for lo, lc, hi, rc in sorted(ivs, key=lo_key):
        if not res:
            res.append([lo, lc, hi, rc])
            continue
        plo, plc, phi, prc = res[-1]
        if phi is None:
            continue
        # 是否相交或相接（同一点至少有一侧闭合才合并）
        overlap = lo is None or lo < phi - 1e-4 or (abs(lo - phi) <= 1e-4 and (lc or prc))
        if overlap:
            if hi is None:
                res[-1][2], res[-1][3] = None, False
            elif hi > phi + 1e-4:
                res[-1][2], res[-1][3] = hi, rc
            elif abs(hi - phi) <= 1e-4:
                res[-1][3] = prc or rc
        else:
            res.append([lo, lc, hi, rc])
    return [tuple(x) for x in res]


def _val_range(f, xs, ys, fin, dom, maxima, minima, vasym, end_l, end_r, per, x0, x1):
    """估计函数的值域：[(lo_or_None, lc, hi_or_None, rc)]。"""
    if not fin:
        return []
    if max(fin) - min(fin) <= 1e-9 * (1 + abs(fin[0])):
        y = _snap_nice(fin[0])
        return [(y, True, y, True)]
    if per is not None:
        if vasym:
            has_pos = any(ll == "+inf" or rl == "+inf" for _, ll, rl in vasym)
            has_neg = any(ll == "-inf" or rl == "-inf" for _, ll, rl in vasym)
            if has_pos and has_neg and not maxima and not minima:
                return [(None, False, None, False)]
            ivs = []
            if has_neg and maxima:
                ivs.append((None, False, _snap_nice(max(y for _, y in maxima)), True))
            if has_pos and minima:
                ivs.append((_snap_nice(min(y for _, y in minima)), True, None, False))
            if ivs:
                return _merge_intervals(ivs)
            if has_pos and has_neg:
                return [(None, False, None, False)]
            if has_pos:
                return [(_snap_nice(min(fin)), True, None, False)]
            if has_neg:
                return [(None, False, _snap_nice(max(fin)), True)]
        # 无渐近线的周期函数：在一个周期上找最值
        ylo = min([y for _, y in minima] + fin)
        yhi = max([y for _, y in maxima] + fin)
        return [(_snap_nice(ylo), True, _snap_nice(yhi), True)]

    vmap = {c: (ll, rl) for c, ll, rl in vasym}

    def vlookup(pt):
        for c, lims in vmap.items():
            if abs(c - pt) < 1e-3:
                return lims
        return (None, None)

    ivs = []
    for s, sc, e, ec in dom:
        attained = [y for x, y in zip(xs, ys) if _ok(y) and (s is None or x > s + 1e-6) and (e is None or x < e - 1e-6)]
        attained += [y for x, y in maxima + minima if (s is None or x >= s - 1e-5) and (e is None or x <= e + 1e-5)]
        lo_unb = hi_unb = False
        open_bounds = []

        def add_end(behave):
            nonlocal lo_unb, hi_unb
            if behave[0] == "inf":
                if behave[1] > 0:
                    hi_unb = True
                else:
                    lo_unb = True
            elif behave[0] == "asym":
                open_bounds.append(behave[1])

        if s is None:
            add_end(end_l)
        else:
            _ll, rl = vlookup(s)
            if rl == "+inf":
                hi_unb = True
            elif rl == "-inf":
                lo_unb = True
            elif sc and _ok(_eval(f, s)):
                attained.append(_eval(f, s))
            else:
                v = _eval(f, s + 1e-6)
                if _ok(v):
                    open_bounds.append(v)

        if e is None:
            add_end(end_r)
        else:
            ll, _rl = vlookup(e)
            if ll == "+inf":
                hi_unb = True
            elif ll == "-inf":
                lo_unb = True
            elif ec and _ok(_eval(f, e)):
                attained.append(_eval(f, e))
            else:
                v = _eval(f, e - 1e-6)
                if _ok(v):
                    open_bounds.append(v)

        if not attained and not open_bounds and not (lo_unb or hi_unb):
            continue
        all_v = attained + open_bounds
        if lo_unb:
            ylo, lc = None, False
        else:
            lo_a = min(attained) if attained else float("inf")
            lo_o = min(open_bounds) if open_bounds else float("inf")
            if lo_a <= lo_o + 1e-5:
                # 只有在区间内部取到（极小值或闭合端点）才算闭区间，防止渐近线旁的采样点被误算闭
                fs_v = _eval(f, s) if (s is not None and sc) else float("nan")
                fe_v = _eval(f, e) if (e is not None and ec) else float("nan")
                at_min = any(abs(y - lo_a) <= 1e-5 for _, y in minima) or (_ok(fs_v) and abs(fs_v - lo_a) <= 1e-5) or (_ok(fe_v) and abs(fe_v - lo_a) <= 1e-5)
                if open_bounds and abs(lo_o - lo_a) <= 1e-2 and not at_min:
                    ylo, lc = _snap_nice(lo_o), False
                else:
                    ylo, lc = _snap_nice(lo_a), True
            else:
                ylo, lc = _snap_nice(lo_o), False
        if hi_unb:
            yhi, rc = None, False
        else:
            hi_a = max(attained) if attained else float("-inf")
            hi_o = max(open_bounds) if open_bounds else float("-inf")
            if hi_a >= hi_o - 1e-5:
                fs_v = _eval(f, s) if (s is not None and sc) else float("nan")
                fe_v = _eval(f, e) if (e is not None and ec) else float("nan")
                at_max = any(abs(y - hi_a) <= 1e-5 for _, y in maxima) or (_ok(fs_v) and abs(fs_v - hi_a) <= 1e-5) or (_ok(fe_v) and abs(fe_v - hi_a) <= 1e-5)
                if open_bounds and abs(hi_o - hi_a) <= 1e-2 and not at_max:
                    yhi, rc = _snap_nice(hi_o), False
                else:
                    yhi, rc = _snap_nice(hi_a), True
            else:
                yhi, rc = _snap_nice(hi_o), False
        if all_v or lo_unb or hi_unb:
            ivs.append((ylo, lc, yhi, rc))
    return _merge_intervals(ivs)


def _domain(f, ys, edges, breaks, span):
    """可视范围里的定义域：[(左端, 左闭, 右端, 右闭)]，端点 None 表示一直延伸到可视范围外（写成 ±∞）。
    边界由取样里「有定义 / 没定义」的变化二分得到；极点（1/x 在 0、tan 在 π/2）把区间断开。"""
    if not any(_ok(y) for y in ys):
        return []
    runs, start = [], (None if _ok(ys[0]) else False)
    pts = iter(edges)
    for i in range(1, len(ys)):
        a, b = _ok(ys[i - 1]), _ok(ys[i])
        if a == b:
            continue
        e = next(pts, None)
        if e is None:
            continue
        if b:                         # 没定义 → 有定义
            start = e
        else:
            runs.append((start, e))
            start = False
    if _ok(ys[-1]) and start is not False:
        runs.append((start, None))
    poles = [p for p in breaks if (lambda v: not _ok(v) or abs(v) > 1e6 * span)(f(_snap(p)))]
    out = []
    for s, e in runs:
        cur = s
        for p in poles:
            if (s is None or p > s) and (e is None or p < e):
                out.append((cur, p, False))
                cur = p
        out.append((cur, e, True))
    res = []
    for s, e, last in out:
        sc = s is not None and _ok(f(_snap(s))) and s not in poles
        ec = e is not None and last and _ok(f(_snap(e))) and e not in poles
        res.append((None if s is None else _snap(s), sc, None if e is None else _snap(e), ec))
    return res


def fmt_val(v, num, prec=3):
    """把数值写成老师常用的样子：0、整数、简单 π 分数（π/2、−π 等）算精确，其余按 num 保留小数。"""
    if abs(v) < 1e-5:
        return "0", True
    ratio = v / math.pi
    for q in (1, 2, 3, 4, 6):
        p = round(ratio * q)
        if p != 0 and abs(p) <= 24 and abs(ratio - p / q) < 1e-3:
            fr = Fraction(p, q)
            sign = "−" if fr.numerator < 0 else ""
            a = abs(fr.numerator)
            head = "π" if a == 1 else f"{a}π"
            return (f"{sign}{head}" if fr.denominator == 1 else f"{sign}{head}/{fr.denominator}"), True
    ri = round(v)
    if abs(v - ri) < 1e-5:
        return str(int(ri)), True
    return num(v, prec), False


def fmt_kstep(step, num):
    """把周期步长写成通解里的 k·T，如 kπ、2kπ、kπ/2、2k。"""
    ratio = step / math.pi
    for q in (1, 2, 3, 4, 6):
        p = round(ratio * q)
        if p > 0 and p <= 24 and abs(ratio - p / q) < 1e-3:
            fr = Fraction(p, q)
            a, b = fr.numerator, fr.denominator
            head = "kπ" if a == 1 else f"{a}kπ"
            return head if b == 1 else f"{head}/{b}"
    ri = round(step)
    if ri > 0 and abs(step - ri) < 1e-4:
        return "k" if ri == 1 else f"{int(ri)}k"
    return f"k·{num(step, 3)}"


def periodic_families(xs, T, tol=1e-2):
    """把周期 T 内的点按同余类合并，若正好把周期等分成 m 段，再合并成步长 T/m 的一族。返回 (基点列表, 步长)。"""
    if not xs or not T or T <= 1e-6:
        return [], T
    res = []
    for x in xs:
        r = ((x + T / 2) % T) - T / 2
        if abs(r + T / 2) <= tol:
            r = T / 2
        if abs(r) <= tol:
            r = 0.0
        if not any(abs(r - u) <= tol for u in res):
            res.append(r)
    res.sort()
    m = len(res)
    if m >= 2:
        step = T / m
        if all(abs((res[i] - res[0]) - i * step) <= tol * 1.5 for i in range(m)):
            # 挑一个最靠近 0 的代表元放进 (−step/2, step/2]
            r0 = ((res[0] + step / 2) % step) - step / 2
            if abs(r0 + step / 2) <= tol:
                r0 = step / 2
            if abs(r0) <= tol:
                r0 = 0.0
            return [r0], step
    return res, T


def fmt_periodic_expr(r, step, num):
    ks = fmt_kstep(step, num)
    if abs(r) < 1e-4:
        return ks
    rs, _ = fmt_val(r, num, 3)
    return f"{rs} + {ks}"


def _fmt_bound(v, num, prec=3, neg_inf=False):
    if v is None:
        return "−∞" if neg_inf else "+∞"
    return fmt_val(v, num, prec)[0]


def domain_text(dom, num, period=None, poles=None):
    """定义域写成老师的样子：R、(0, +∞)、[0, +∞)、(−∞, 0)∪(0, +∞)；周期极点写成 x ≠ π/2 + kπ（k∈Z）。"""
    if not dom:
        return "可视范围内没有定义"
    if len(dom) == 1 and dom[0][0] is None and dom[0][2] is None:
        return "R"
    if period and poles and len(poles) >= 2 and dom[0][0] is None and dom[-1][2] is None and all(not d[1] and not d[3] for d in dom):
        bases, step = periodic_families(poles, period, tol=max(1e-2, period * 1e-3))
        if bases and len(bases) <= 2:
            return "x ≠ " + "，".join(fmt_periodic_expr(b, step, num) for b in bases) + "（k∈Z）"
    if len(dom) > 3 and all(d[0] is None or not d[1] for d in dom):
        holes = [d[2] for d in dom[:-1]]
        return "x ≠ " + "，".join(fmt_val(h, num, 3)[0] for h in holes[:4]) + ("…" if len(holes) > 4 else "")
    parts = []
    for s, sc, e, ec in dom:
        parts.append(("[" if sc else "(") + _fmt_bound(s, num, 3, True) + ", " + _fmt_bound(e, num, 3, False) + ("]" if ec else ")"))
    return "∪".join(parts)


def range_text(rng, num):
    """值域写成老师的样子：R、(0, +∞)、[−1, 1]、(−∞, 0)∪(0, +∞)、{3}。"""
    if not rng:
        return "—"
    if len(rng) == 1:
        s, sc, e, ec = rng[0]
        if s is None and e is None:
            return "R"
        if s is not None and e is not None and sc and ec and abs(s - e) < 1e-5:
            return "{" + fmt_val(s, num, 3)[0] + "}"
    parts = []
    for s, sc, e, ec in rng:
        parts.append(("[" if sc else "(") + _fmt_bound(s, num, 3, True) + ", " + _fmt_bound(e, num, 3, False) + ("]" if ec else ")"))
    return "∪".join(parts)


def period_text(per, num):
    """周期写最小正周期和通解（如 T = kπ）。"""
    t_str, exact = fmt_val(per, num, 4)
    k_str = fmt_kstep(per, num)
    lead = f"最小正周期 {t_str}" if exact else f"最小正周期 T ≈ {t_str}"
    return f"{lead}，通解 T = {k_str}（k∈Z, k≠0）"


def mono_text(feats, num):
    """单调区间写成老师的样子：端点用 ±∞，多段同单调性用逗号隔开（不用 ∪）；周期函数写通解。"""
    per = feats.get("period")
    ivs = feats.get("mono_intervals") or []
    if not ivs:
        return "—"
    if per:
        # 周期函数：取落在完整视野内的单调段，按周期 T 归并到一个周期内再写 + kT
        full = [iv for iv in ivs if iv[0] is not None and iv[2] is not None]
        # 过滤掉被视野边界裁断的首尾半截
        inner = full[1:-1] if len(full) >= 3 else full
        by_kind = {"增": [], "减": []}
        tol = max(1e-2, per * 1e-3)
        for a, ac, b, bc, k in inner:
            if b - a <= tol or b - a > per + tol:
                continue
            # 平移一个整数倍周期，使区间中心落到 (−per/2, per/2]（±per/2 统一归到 +per/2，避免 sin 的减区间出现两份同余段）
            mid = (a + b) / 2
            nm = ((mid + per / 2) % per) - per / 2
            if abs(nm + per / 2) <= tol:
                nm = per / 2
            shift = round((mid - nm) / per) * per
            na, nb = a - shift, b - shift
            # 若已有同余的区间就不重复收
            if any(abs(na - oa) <= tol and abs(nb - ob) <= tol for oa, _, ob, _ in by_kind[k]):
                continue
            by_kind[k].append((na, ac, nb, bc))
        if by_kind["增"] or by_kind["减"]:
            ks = fmt_kstep(per, num)
            parts = []
            for k in ("增", "减"):
                if not by_kind[k]:
                    continue
                segs = []
                for a, ac, b, bc in sorted(by_kind[k])[:2]:
                    sa = ks if abs(a) < 1e-4 else f"{fmt_val(a, num, 2)[0]} + {ks}"
                    sb = ks if abs(b) < 1e-4 else f"{fmt_val(b, num, 2)[0]} + {ks}"
                    segs.append(("[" if ac else "(") + f"{sa}, {sb}" + ("]" if bc else ")"))
                parts.append(f"{k} " + "，".join(segs))
            return "；".join(parts) + "（k∈Z）"
    by_kind = {"增": [], "减": []}
    order = []
    for a, ac, b, bc, k in ivs:
        if k not in order:
            order.append(k)
        s = ("[" if ac else "(") + _fmt_bound(a, num, 2, True) + ", " + _fmt_bound(b, num, 2, False) + ("]" if bc else ")")
        by_kind[k].append(s)
    parts = [f"{k} " + "，".join(by_kind[k][:4]) + ("…" if len(by_kind[k]) > 4 else "") for k in order if by_kind[k]]
    return "；".join(parts) if parts else "—"


def asymptotes_text(feats, num):
    """渐近线：铅直渐近线（周期函数写通解）+ 水平渐近线。"""
    parts = []
    vasym = feats.get("vasym") or []
    per = feats.get("period")
    if vasym:
        xs = [c for c, _ll, _rl in vasym]
        if per and len(xs) >= 2:
            bases, step = periodic_families(xs, per, tol=max(1e-2, per * 1e-3))
            if bases and len(bases) <= 2:
                parts.append("铅直 x = " + "，".join(fmt_periodic_expr(b, step, num) for b in bases) + "（k∈Z）")
            else:
                parts.append("铅直 x = " + "，".join(fmt_val(c, num, 3)[0] for c in xs[:4]) + ("…" if len(xs) > 4 else ""))
        else:
            parts.append("铅直 x = " + "，".join(fmt_val(c, num, 3)[0] for c in xs[:4]) + ("…" if len(xs) > 4 else ""))
    hasym = feats.get("hasym") or []
    if hasym:
        parts.append("水平 y = " + "，".join(fmt_val(v, num, 3)[0] for v in hasym[:2]))
    return "；".join(parts)


def _dedupe_pts(pts, tol):
    out = []
    for p in sorted(pts):
        if not out or abs(p[0] - out[-1][0]) > tol:
            out.append(p)
    return out


def parity(f, x0, x1):
    """在关于原点对称的区间上比 f(−x) 和 f(x)：偶 / 奇 / 既奇又偶 / 非奇非偶。
    定义域关于原点不对称（如 ln x、√x）直接判为非奇非偶；视野偏离原点时仍在原点附近试探。"""
    r = min(abs(x0), abs(x1)) if x0 < 0 < x1 else 0.0
    if r < 0.5:
        r = max(2.0, min(8.0, (x1 - x0) * 0.4))
    even = odd = True
    seen = asym = 0
    for i in range(1, 41):
        x = r * i / 41
        a, b = _eval(f, x), _eval(f, -x)
        oa, ob = _ok(a), _ok(b)
        if oa != ob:
            asym += 1
            continue
        if not oa:
            continue
        seen += 1
        tol = 1e-7 * (1 + abs(a))
        even &= abs(a - b) <= tol
        odd &= abs(a + b) <= tol
    if asym >= 4:
        return "非奇非偶"
    if seen < 8:
        return ""
    return "偶函数" if even and not odd else "奇函数" if odd and not even else "既奇又偶" if odd and even else "非奇非偶"


def period(f, x0, x1, extrema):
    """用相邻及隔项同类特征点的间距猜周期，再在 20 个点上验证 f(x + T) = f(x)，并尽量缩成最小正周期。"""
    xs = sorted(p[0] for p in extrema)
    if len(xs) < 2:
        return None
    cands = {round(b - a, 9) for a, b in zip(xs, xs[1:]) if b - a > 1e-6}
    cands |= {round(c - a, 9) for a, c in zip(xs, xs[2:]) if c - a > 1e-6}

    def check_t(T):
        if T <= 1e-5 or T > (x1 - x0) * 1.5:
            return False
        good = checked = 0
        for i in range(20):
            x = x0 + (x1 - x0) * (i + 0.37) / 21
            a, b = _eval(f, x), _eval(f, x + T)
            if _ok(a) and _ok(b):
                checked += 1
                good += abs(a - b) <= 1e-6 * (1 + abs(a))
        return checked >= 10 and good == checked

    for T in sorted(cands)[:6]:
        if check_t(T):
            for div in (2, 3):
                while check_t(T / div):
                    T /= div
            return T
    return None


def tangent(f, a):
    """在 x = a 处的切线：(y0, 斜率)；求不出来返回 None。"""
    y = f(a)
    k = deriv(f, a)
    return (y, k) if _ok(y) and _ok(k) else None


def line_text(k, b):
    """y = kx + b 的好看写法。"""
    def n(v):
        v = 0.0 if abs(v) < 5e-10 else v
        s = f"{v:.3f}".rstrip("0").rstrip(".")
        return "0" if s in ("-0", "") else s
    if abs(k) < 5e-10:
        return f"y = {n(b)}"
    kx = "x" if abs(k - 1) < 5e-10 else "−x" if abs(k + 1) < 5e-10 else n(k).replace("-", "−") + "x"
    if abs(b) < 5e-10:
        return "y = " + kx
    return f"y = {kx} {'+' if b > 0 else '−'} {n(abs(b))}"


# ---------------------------------------------------------------- 伸缩平移 y = a·f(b(x − h)) + k
IDENT_TF = dict(a=1.0, b=1.0, h=0.0, k=0.0)


def is_ident(tf):
    return not tf or all(abs(float(tf.get(k, v)) - v) < 1e-12 for k, v in IDENT_TF.items())


def apply_tf(base, tf):
    if is_ident(tf):
        return base
    a, b, h, k = (float(tf.get(x, IDENT_TF[x])) for x in ("a", "b", "h", "k"))

    def g(x):
        y = base(b * (x - h))
        return a * y + k if _ok(y) else float("nan")
    return g


def _num(v):
    s = f"{v:.3f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def bake(expr, tf):
    """把伸缩平移写回解析式（字符串替换变量 x），用于「写进式子」。"""
    if is_ident(tf):
        return expr
    a, b, h, k = (float(tf.get(x, IDENT_TF[x])) for x in ("a", "b", "h", "k"))
    inner = "x" if abs(h) < 1e-12 else f"(x-{_num(h)})" if h > 0 else f"(x+{_num(-h)})"
    if abs(b - 1) > 1e-12:
        inner = f"(-{inner})" if abs(b + 1) < 1e-12 else f"({_num(b)}*{inner})"
    body = re.sub(r"(?<![A-Za-z_])x(?![A-Za-z_])", inner, expr)
    out = body if abs(a - 1) < 1e-12 else f"-({body})" if abs(a + 1) < 1e-12 else f"{_num(a)}*({body})"
    return out if abs(k) < 1e-12 else f"{out}+{_num(k)}" if k > 0 else f"{out}-{_num(-k)}"


def tf_notes(tf):
    """每个参数对图像做了什么（给学生看的结论）。"""
    a, b, h, k = (float(tf.get(x, IDENT_TF[x])) for x in ("a", "b", "h", "k"))
    out = []
    if abs(b - 1) > 1e-12:
        r = abs(1 / b)
        out.append(f"横坐标变为原来的 {_num(r)} 倍" + ("（再关于 y 轴翻折）" if b < 0 else ""))
    if abs(h) > 1e-12:
        out.append(f"向{'右' if h > 0 else '左'}平移 {_num(abs(h))} 个单位")
    if abs(a - 1) > 1e-12:
        out.append(f"纵坐标变为原来的 {_num(abs(a))} 倍" + ("（再关于 x 轴翻折）" if a < 0 else ""))
    if abs(k) > 1e-12:
        out.append(f"向{'上' if k > 0 else '下'}平移 {_num(abs(k))} 个单位")
    return out


def snap_x(x, feats, tol):
    """动点吸附：离特殊点或整数 x 不到 tol 就吸过去。返回 (x, 吸到的名字或 '')。"""
    best, name = None, ""
    for label in ("zeros", "maxima", "minima", "inflections"):
        for p in feats.get(label, ()):
            d = abs(p[0] - x)
            if d <= tol and (best is None or d < abs(best - x)):
                best, name = p[0], {"zeros": "零点", "maxima": "极大值点", "minima": "极小值点", "inflections": "拐点"}[label]
    if best is not None:
        return best, name
    r = round(x)
    if abs(r - x) <= tol * 0.6:
        return float(r), "整数点"
    return x, ""
