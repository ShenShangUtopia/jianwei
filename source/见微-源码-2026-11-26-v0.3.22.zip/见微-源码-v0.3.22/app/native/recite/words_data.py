"""内置词库：高考英语 3500 词表（3699 个词，每个词都带词性和中文释义）。

表按公开的高考 3500 词表整理：原有 800 多个词保留手写释义，其余从词表补进来；补进来的
只收词性和中文释义都对得上的，拿不准的没有收，也没有自己生造释义。想用自己老师发的词表，
用「导入词表」（txt / csv：单词 + 释义），导入的词优先。
一行一个：单词|词性和释义。
例句在 EXAMPLES 里，只给一部分词；没有例句的词跳过例句这一步。
"""

RAW = """
a|art. 一（个、件……）
abandon|v. 放弃；抛弃
ability|n. 能力；才能
able|adj. 能够；有能力的
abnormal|adj. 反常的；变态的
aboard|prep. 上（船，飞机，火车，汽车等）
abolish|v. 废除；废止
abortion|v. 人工流产；堕胎
about|adv. 大约；到处；四处 prep. 关于；在各处；四处
above|prep. 在……上面 adj. 上面的 adv. 在……之上
abroad|adv. 在国外；到国外
abrupt|adj. 突然的；意外的；粗鲁
absence|n. 缺席；不在
absent|adj. 缺席；不在
absolute|adj. 绝对的；完全的
absorb|v. 吸收；使专心
abstract|adj. 抽象的 n. 摘要
absurd|adj. 荒谬的；怪诞不经的
abundant|adj. 大量；丰盛的；充裕的
abuse|v. （酗酒）滥用；虐待；恶语
academic|adj. 学术的；学业的
academy|n. 专科学院；（美）私立学校
accelerate|v. （使）加速；加快
accent|n. 口音；重音
accept|v. 接受；认可
access|n. 通道；使用权 v. 进入
accessible|adj. 可到达的；可接受的；易相处的）
accident|n. 事故；意外
accommodation|n. 住宿；膳宿
accompany|v. 陪伴；伴随
accomplish|v. 完成；实现
account|n. 账户；描述 v. 解释
accountant|n. 会计；会计师
accumulate|v. 积累；积聚
accuracy|n. 准确；精确
accurate|adj. 准确的；精确的
accuse|v. 指控；指责
accustomed|adj. 习惯于；惯常的
ache|v./n. 痛；疼痛
achieve|v. 实现；达到
achievement|n. 成就；成绩
acid|adj. 酸的
acknowledge|v. 承认；致谢
acquaintance|n. 熟人；（与某人）认识
acquire|v. 获得；习得
acquisition|n. 获得；得到
acre|n. 英亩
across|prep. 横过；穿过
act|n. 法令；条例 v. （戏）表演；扮演（角色）；演出（戏）；行动；做事
action|n. 行动
active|adj. 积极的；主动的
activity|n. 活动
actor|n. 男演员
actress|n. 女演员
actual|adj. 实际的；现实的
acute|adj. 十分严重的；（病）急性的
adapt|v. 适应；改编
adaptation|n. 适应；改编本
add|v. 添加；增加
addicted|adj. 上瘾；成瘾；入迷
addition|n. 加；增加物
address|n. 地址
adequate|adj. 合适的；合乎需要的
adjust|v. 调整；适应
adjustment|n. 调整；适应
administration|n. 管理；行政部门
admirable|adj. 值得赞赏的；可钦佩的
admire|v. 钦佩；欣赏
admission|n. 准入；接纳
admit|v. 承认；准许进入
adolescence|n. 青春；青春期
adolescent|n. 青少年
adopt|v. 采用；收养
adore|v. （不用于进行时）热爱；爱慕某人
adult|n. 成年人
advance|v. 前进；提高 n. 进步
advantage|n. 优势；有利条件
adventure|n. 冒险；奇遇
advertise|v. 为……做广告
advertisement|n. 广告
advice|n. 建议；忠告
advise|v. 忠告；劝告；建议
advocate|v. 提倡 n. 拥护者
aeroplane|n. (英)飞机
affair|n. 事；事情
affect|v. 影响；感动
affection|n. 喜爱；钟爱
afford|v. 买得起；抽得出（时间）
afraid|adj. 害怕的；担心
after|adv. 在后；后来 prep. 在…之后；在 后面 conj. 在…以后
afternoon|n. 下午；午后
afterward|adv. 后来
again|adv. 再一次；再；又
against|prep. 对着；反对
age|n. 年龄；时代
agency|n. 代理处；机构
agenda|n. （会议）议程表；议事日程
agent|n. 代理人；经济人
aggression|n. 侵略
aggressive|adj. 侵略的；咄咄逼人
ago|adv. 以前
agree|v. 同意；应允
agreement|n. 同意；一致；协定；协议
agricultural|adj. 农业的
agriculture|n. 农业
ahead|adv. 在前；向前
aid|n. 援助；救护；辅助器具
aim|n. 目标 v. 瞄准；旨在
air|n. 空气；大气
aircraft|n. 飞机 (单复数同)
airline|n. 航空公司；航空系统
airmail|n. 航空邮件
airplane|n. （美）飞机
airport|n. 航空站；飞机场
airspace|n. 领空；（某国的）空域
alarm|n. 警报；惊恐 v. 使惊恐
album|n. 相册；影集；集邮簿
alcohol|n. 含酒精饮料；酒
algebra|n. 代数
alike|adv. 很相似地；同样地
alive|adj. 活着的；存在的
all|adv. 全部地 adj. 全（部）；所有的；总；整 pron. 全部；全体人员
allergic|adj. 过敏的；厌恶
alley|n. 小巷；胡同
allocate|v. 拨给；划归；分配…给
allow|v. 允许；准许
allowance|n. 津贴；补助
almost|adv. 几乎；差不多
alone|adj. 单独的；孤独的
along|adv. 向前；和…一起；一同 prep. 沿着；顺着
alongside|adv. 在…旁边；与…同时
aloud|adv. 大声地
alphabet|n. 字母表；字母
already|adv. 已经
also|adv. 也
alternative|adj. 可替代的 n. 选择
although|conj. 虽然；尽管
altitude|n. 海拔高度
altogether|adv. 总共
aluminium|n. （化）铝
always|adv. 总是；一直；永远
am|v. be的人称形式之一 
amateur|adj. 业余爱好的
amaze|v. 使惊奇
amazing|adj. 惊奇；惊叹的；震惊的
ambassadress|n. 大使夫人；女大使
ambiguous|adj. 模棱两可的
ambition|n. 雄心；抱负
ambulance|n. 救护车
among|prep. 在…中间；在（三个以上）之间
amount|n. 数量；总额
ample|adj. 足够的；丰裕的
amuse|v. 逗乐；使发笑
amusement|n. 娱乐
an|art. 一（个、件……）用于元音前
analyse|v. 分析
analysis|n. 分析；分析结果
analyze|v. 分析
ancestor|n. 祖先
ancient|adj. 古代的；古老的
and|conj. 和；又；而
anecdote|n. 逸事；趣闻
anger|n. 怒；愤怒
angle|n. 角度
angry|adj. 生气的；愤怒的
animal|n. 动物
ankle|n. 踝；踝关节
anniversary|n. 周年纪念日
announce|v. 宣布；通告
announcement|n. 通告；通知
annoy|v. 使恼怒
annual|adj. 每年的；年度的
another|adj. 再一；另一；别的；不同的 pron. 另一个
answer|n. 回答；答复；回信；答案 v. 回答；答复；回信；（作出）答案
ant|n. 蚂蚁
antique|n. 古董
anxiety|n. 担忧；焦虑
anxious|adj. 焦虑的；渴望的
any|pron. （无论）哪一个；哪些 任何的；（用于疑问句、否定句）一些；什么
anybody|pron. 任何人；无论谁
anyhow|adv. 不管怎样
anyone|pron. 任何人；无论谁
anything|pron. 什么事（物）；任何事（物）
anyway|adv. 不管怎样
anywhere|adv. 任何地方
apartment|n. （美）楼中单元房；一套房间；房间
apologize|v. 道歉
apology|n. 道歉；歉意
apparent|adj. 明显的；表面上的
appeal|v. 呼吁；吸引 n. 吸引力
appear|v. 出现；似乎
appearance|n. 出现；露面；容貌
appendix|n. 附录；阑尾
appetite|n. 食欲；欲望
applaud|v. 鼓掌；称赞
apple|n. 苹果
applicant|n. 申请人
application|n. 申请
apply|v. 申请；应用
appoint|v. 任命；委任；安排；确定（时间，地点）
appointment|n. 约会；任命
appreciate|v. 欣赏；感激
appreciation|n. 欣赏；鉴定；评估
approach|v. 接近 n. 方法
appropriate|adj. 合适的；恰当的
approve|v. 批准；赞成
approximately|adv. 近似；大约
apron|n. （机场的）停机坪
arbitrary|adj. 随心所欲的；独裁的；专断的
arch|n. 拱；拱门
architect|n. 建筑师；设计师
architecture|n. 建筑学；建筑设计；风格
are|v. (be) 是
area|n. 面积；地域；地方；区域；范围；领域
argue|v. 争论；主张
argument|n. 争论；辩论
arise|v. 出现；产生
arithmetic|n. 算术
arm|n. 臂；支架 v. 以…装备；武装起来 n. （美）武器；武力
armchair|n. 扶手椅
army|n. 军队
around|adv. 在周围；在附近 prep. 在……周围；大约
arrange|v. 安排；整理
arrangement|n. 安排；布置
arrest|v. 逮捕
arrival|n. 到来；到达
arrive|v. 到达；达到
arrow|n. 箭；箭头
art|n. 艺术；美术；技艺
article|n. 文章；物品；冠词
artificial|adj. 人造的；人工的
artist|n. 艺术家
as|adv./conj. 像……一样；如同；因为 prep. 作为；当做
ash|n. 灰；灰末
ashamed|adj. 羞愧的
aside|adv. 在旁边
ask|v. 问；请求；要求；邀请
asleep|adj. 睡着的；熟睡
aspect|n. 方面；外观
assess|v. 评估；评价
assessment|n. 看法；评价
assist|v. 帮助；协助
assistance|n. 帮助；援助；支持
assistant|n. 助手；助理
associate|v. 联系；交往
association|n. 协会；社团；联系
assume|v. 假定；承担
assumption|n. 假定；假设
astonish|v. 使惊讶
astronaut|n. 宇航员
astronomer|n. 天文学家
astronomy|n. 天文学
at|prep. 在（几点钟）；在（某处）
athlete|n. 运动员
athletic|adj. 健壮的；体育运动的
athletics|n. 田径
atmosphere|n. 大气；气氛
atom|n. 原子；微粒
attach|v. 附上；系
attack|v./n. 攻击；进攻
attain|v. （经过努力）获得；得到
attempt|v./n. 尝试；企图
attend|v. 出席；照料
attention|n. 注意；关注
attentively|adv. 注意地
attitude|n. 态度；看法
attract|v. 吸引
attraction|n. 吸引；爱慕
attractive|adj. 有吸引力的
audience|n. 观众；听众
aunt|n. 伯母；舅母；婶；姑；姨
authentic|adj. 真正的；真品的
author|n. 作者
authority|n. 权威；当局
automatic|adj. 自动的；机械的
autonomous|adj. 自治的；自主的
autumn|n. 秋天；秋季
available|adj. 可获得的；有空的
avenue|n. 大道
average|adj. 平均的；普通的 n. 平均数
avoid|v. 避免；躲开
award|n. 奖品 v. 授予
aware|adj. 意识到的；知道的
away|adv. 离开；远离
awesome|adj. 令人惊叹；很困难的
awful|adj. 糟糕的；可怕的
awkward|adj. 尴尬的；笨拙的
bachelor|n. 未婚男子；单身汉
back|adv. 回（原处）；向后 adj. 后面的 n. 背后；后部；背
backache|n. 背痛
background|n. 背景
backward|adv. 向后
bacon|n. 咸猪肉；熏猪肉 
bacterium|n. 细菌
badly|adv. 坏；恶劣地
badminton|n. 羽毛球
bag|n. 书包；提包；袋子
baggage|n. 行李
bake|v. 烤；烘（面包）
bakery|n. 面包店
balance|n. 平衡 v. 使平衡
balcony|n. 阳台；楼座
ball|n. 球 n. 舞会
ballet|n. 芭蕾舞
balloon|n. 气球
bamboo|n. 竹
ban|v./n. 禁止
banana|n. 香蕉
band|n. 乐队
bandage|n. 绷带
bang|int. 砰
bank|n. （河海湖的）岸；堤 n. 银行
bar|n. 条（长方）块；棒；横木 n. （酒店的）买酒柜台；酒吧；（卖东西的）柜台
barbecue|n. 烤肉野餐
barber|n. （为男人理发）理发师
barbershop|n. 理发店
bare|adj. 裸露的；光秃秃的
bargain|n. 便宜货 v. 讨价还价
bark|v. 狗叫 n. 狗叫声
barrier|n. 障碍；屏障
base|n. 根据地；基地（棒球）垒
baseball|n. 棒球
basement|n. 地下室
basic|adj. 基本的
basin|n. 水盆；脸盆
basis|n. 基础；根据
basket|n. 篮子
basketball|n. 篮球
bat|n. （棒球、板球的）球棒 n. 蝙蝠
bath|n. 洗澡；浴室；澡盆
bathe|v. 洗澡；游泳
bathrobe|n. 浴衣
bathroom|n. 浴室；盥洗室
bathtub|n. 澡盆
battery|n. 电池
battle|n. 战斗；战役
battleground|n. 战场
bay|n. 湾；海湾
be|v. 是（原形）；其人称和时态形式有(am, is, are, was, were, being, been)；成为
beach|n. 海滨；海滩
beam|n. 平衡木
bean|n. 豆；豆科植物
beancurd|n. 豆腐
bear|v. 承受；负担；承担；忍受；容忍 n. 熊
beard|n. （下巴上的）胡须
beast|n. 野兽；牲畜
beautiful|adj. 美；美丽；美观的
beauty|n. 美丽；美人
because|conj. 因为
become|v. 变得；成为
bed|n. 床
bedclothes|n. 铺盖（被褥等）
beddings|n. 卧具；铺盖
bedroom|n. 寝室；卧室
bee|n. 蜜蜂
beef|n. 牛肉
beehive|n. 蜂箱
beer|n. 啤酒
before|prep. 在…以前；在…前面 adv. 以前 conj. 在…之前
beg|v. 请求；乞求；乞讨 
beginning|n. 开始；开端
behalf|n. 代表某人；为了某人
behave|v. 表现；守规矩
behaviour|n. 行为；举止
behind|prep. (表示位置)在…后面 adv. 在后面；向后
being|n. 物；生物；人
belief|n. 信念；信仰
believe|v. 相信；认为
bell|n. 钟；铃；钟(铃)声；钟形物
belly|n. 肚子
belong|v. 属于
below|prep. 在……下面
belt|n. （皮）带
bench|n. 长凳；工作台
beneath|prep. 在…下方（面）
beneficial|adj. 有利的；有帮助的；有用的
benefit|n. 益处 v. 有益于
bent|adj. 弯的
beside|prep. 在…旁边；靠近
besides|prep. 除…以外（还有） adv. 还有；此外
best|adj./adv. 最好的；最好地；最 n. 最好的（人或物）
bestseller|n. 畅销书
betray|v. 出卖；泄露（机密）；辜负
better|adj./adv. 较好的；更好的；好些；更好地；更；更多 n. 较好的事物；较优者 v. 改善；胜过
between|prep. 在（两者）之间；在…中间
beyond|prep. (表示位置) 在…的那边
bicycle|n. 自行车
big|adj. 大的
bill|n. 账单；法案；议案；（美）钞票；纸币
billion|num. 十亿；百亿
bingo|n. 宾戈游戏
biochemistry|n. 生物化学
biography|n. 传记
biology|n. 生物（学）
bird|n. 鸟
birdcage|n. 鸟笼
birth|n. 出生；诞生
birthday|n. 生日
birthplace|n. 出生地；故乡
biscuit|n. 饼干
bishop|n. 主教
bit|n. 一点；一些；少量的
bitter|adj. 苦的；痛苦的
black|n. 黑色 adj. 黑色的
blackboard|n. 黑板
blame|v. 责备 n. 责任
blank|adj. 空白的 n. 空白
blanket|n. 毛毯；毯子
bleed|v. 出血；流血
bless|v. 祝福；保佑
blind|adj. 瞎的
block|n. 大块；（木、石等）块；街区；路障 v. 阻塞；阻挡
blood|n. 血；血液
blouse|n. 宽罩衫；（妇女、儿童穿的）短上衣
blow|n. 击；打击
blue|n. 蓝色 adj. 蓝色的 adj. 悲伤的；沮丧的
board|n. 木板；董事会 v. 登上
boat|n. 小船；小舟
boating|n. 划船（游玩）；泛舟 body n. 身体
boatrace|n. 划船比赛
bodybuilding|n. 健美
boil|v. 沸腾；烧开；煮……
bomb|n. 炸弹 v. 轰炸
bone|n. 骨头；骨质
bonus|n. 津贴；奖金；红利
book|n. 书；本子 v. 预定；定（房间、车票等）
bookcase|n. 书橱
bookmark|n. 书签
bookshelf|n. 书架
bookshop|n. 书店
bookstore|n. 书店
boom|n./v. 繁荣；激增
boot|n. 长统靴；靴
booth|n. 岗；（为某种用途而设的）亭或小隔间
border|n. 边界；边境
bored|adj. （对人，事）厌倦的；烦闷的
boring|adj. 乏味的；无聊的
born|adj. 出生
borrow|v. （向别人）借用；借
boss|n. 领班；老板
botanical|adj. 植物学的
botany|n. 植物；植物学
both|adj. 两；双 pron. 两者；双方
bother|v. 打扰；烦恼
bottle|n. 瓶子
bottom|n. 底部；底
bounce|v. 弹起；蹦；上下晃动
bound|adj. 一定的；被束缚的
boundary|n. 边界；界限
bow|v./n. 鞠躬；弯腰行礼
bowl|n. 碗
bowling|n. 保龄球
box|n. 盒子；箱子
boxing|n. 拳击（运动）
boy|n. 男孩
boycott|v. 拒绝购买；抵制
brain|n. 脑（子）
brake|n. 闸 v. 刹车
branch|n. 树枝；分枝；分公司；分店；支部
brand|n. 品牌
brave|adj. 勇敢的
bravery|n. 勇气
bread|n. 面包
break|n. 间隙
breakfast|n. 早餐
breakthrough|n. 重大进展；突破
breast|n. 乳房；胸脯
breath|n. 呼吸；气息
breathe|v. 呼吸
breathless|adj. 气喘吁吁的；上气不接下气的
brewery|n. 啤酒厂（公司）
brick|n. 砖；砖块
bride|n. 新娘
bridegroom|n. 新郎
bridge|n. 桥
brief|adj. 简短的
bright|adj. 明亮的；聪明的
brilliant|adj. 杰出的；明亮的
broad|adj. 宽的；宽大的
broadcast|v. 广播
brochure|n. 资料（或广告）手册
broken|adj. 弄坏了的
broom|n. 扫帚
brother|n. 兄；弟
brotherhood|n. 兄弟般的关系
brown|n. 褐色；棕色 adj. 褐色的；棕色的
brunch|n. 早午饭（晚早饭）
brush|v. 刷；擦 n. 刷子
bucket|n. 铲斗；桶
budget|n. 预算
buffet|n. 自助餐
building|n. 建筑物；房屋；大楼
bun|n. 馒头；小甜面包
bunch|n. 串；束；扎；大量；大批
bungalow|n. 平房
burden|n. 负担
bureaucratic|adj. 官僚的
burglar|n. 入室窃贼
burial|n. 埋葬
burn|v. 燃；烧；着火；使烧焦；使晒黑 n. 烧伤；晒伤
burst|v. 爆发；突然…起来
bury|v. 埋；葬
bus|n. 公共汽车
bush|n. 灌木丛；矮树丛
business|n. （本分）工作；职业；职责；生意；交易；事业
businessman|n. 商人（男）；男企业家
businesswoman|n. 商人（女）；女企业家
busy|adj. 忙（碌）的
but|conj. 但是；可是 prep. 除了；除……外
butter|n. 黄油；奶油
butterfly|n. 蝴蝶
button|n. 纽扣；（电铃等的）按钮 v. 扣（纽扣） 
by|prep. 靠近；在…旁；在…时间；不迟于；被；用；由；乘（车）
bye|int. 再见
cab|n. （美）出租车
cabbage|n. 卷心菜；洋白菜
cafe|n. 咖啡馆；餐馆
cafeteria|n. 自助餐厅
cake|n. 蛋糕；糕点；饼
calculate|v. 计算；核算；推测
call|n. 喊；叫；电话；通话 v. 称呼；呼唤；喊；叫
calm|adj. 平静的 v. 使平静
camel|n. 骆驼
camera|n. 照相机；摄像机
camp|n. （夏令）营 v. 野营；宿营
campaign|n. 运动；战役
can|v. 可能；能够；可以 不能 n. （美）罐头；罐子
canal|n. 运河；水道
cancel|v. 取消
cancer|n. 癌
candidate|n. 候选人；考生
candle|n. 蜡烛
candy|n. 糖果
canteen|n. 餐厅；食堂
cap|n. （无檐的或仅在前面有檐的）帽子；（瓶子的）盖；（钢笔等的）笔套
capable|adj. 有能力的
capacity|n. 容量；能力
capital|n. 首都.省会.大写；资本
capsule|n. （药）胶囊
captain|n. （海军）上校；船长；舰长；队长
caption|n. （图片，漫画等的）说明文字
car|n. 汽车；小卧车
carbon|n. 碳
card|n. 卡片；名片；纸牌
care|n. 照料；保护；小心 v. 介意……；在乎；关心
career|n. 职业；生涯
careful|adj. 小心；仔细；谨慎的
careless|adj. 粗心的；漫不经心的
carpenter|n. 木工；木匠
carpet|n. 地毯
carriage|n. 四轮马车；（火车）客车厢
carrier|n. 搬运者；媒介；（自行车等的）置物架；（车的）货架
carrot|n. 胡萝卜
carry|v. 拿；搬；带；提；抬；背；抱；运等
cartoon|n. 动画片；卡通；漫画
carve|v. 刻；雕刻
case|n. 情况；病例；案件；真相 n. 箱；盒；容器
cash|n. 现金；现钞 v. 兑现
cassette|n. 磁带
cast|v. 扔；抛；撒
castle|n. 城堡
casual|adj. 随便的；偶然的
cat|n. 猫 
catalogue|n. 目录
catastrophe|n. 灾难；灾祸；不幸事件
category|n. 类别；种类
cater|v. 提供饮食；承办酒席
cathedral|n. 大教堂（天主教）
catholic|adj. 天主教的
cattle|n. 牛（总称）；家畜
cause|n. 原因；起因 v. 促使；引起；使发生
caution|n. 谨慎；小心；警告
cautious|adj. 小心的；谨慎的
cave|n. 洞；穴；地窖
ceiling|n. 天花板；顶棚
celebrate|v. 庆祝
celebration|n. 庆祝；庆祝会
cell|n. （监狱的）单人牢房；（修道院等的）单人小室；（蜂巢的）小蜂窝；蜂房；［生物］ 细胞
cellar|n. 地窖；地下储藏室
cent|n. 美分
center|n. 中心；中央(美)
centigrade|adj. 摄氏的
central|adj. 中心；中央；主要的
centre|n. 中心；中央(英)
century|n. 世纪；百年
ceremony|n. 典礼；仪式
certain|adj. （未指明真实名称的）某…；确定的；无疑的；一定会…
certainly|adv. 当然；一定；无疑
certificate|n. 证明；证明书
chain|n. 链；链条
chair|n. 椅子
chairman|n. 主席；会长；议长
chairwoman|n. 女主席；女会长；女议长
chalk|n. 粉笔
challenge|n./v. 挑战
challenging|adj. 具有挑战性的
champion|n. 冠军；拥护者
chance|n. 机会；可能性
change|n. 零钱；找头 v. 改变；变化；更换；兑换
changeable|adj. 易变的；变化无常的
channel|n. 频道；渠道
chaos|n. 混乱；杂乱；紊乱
chapter|n. 章；篇
character|n. 性格；角色；汉字
characteristic|adj. 典型的；独特的
charge|v. 收费；充电；指控 n. 费用；负责
charity|n. 慈善；慈善机构
chart|n. 图表；航海图
chase|v. 追逐；追求
cheap|adj. 便宜的；贱
cheat|v. 欺骗；作弊
check|n. 检查；批改 v. 校对；核对；检查；批改
cheek|n. 面颊；脸蛋
cheer|n./v. 欢呼；喝彩
cheerful|adj. 兴高采烈的；快活的
cheers|int. 干杯；(口)谢谢；再见
cheese|n. 奶酪
chef|n. 厨师长；主厨
chemical|adj. 化学的 n. 化学品
chemist|n. 药剂师；化学家
chemistry|n. 化学
chess|n. 棋
chest|n. 箱子；盒子；胸部
chew|v. 咀嚼
chick|n. 小鸡
chicken|n. 鸡；鸡肉
chief|adj. 主要；首要的 n. 领导；头
child|n. 孩子；儿童
childhood|n. 幼年时代；童年
children|n. 孩子们；儿童们
chimney|n. 烟囱；烟筒
chips|n. 炸土豆条（片）
chocolate|n. 巧克力
choice|n. 选择；抉择
choir|n. 合唱团；教堂的唱诗班
choke|n./v. 窒息
chopsticks|n. 筷子
chorus|n. 合唱曲；歌咏队
church|n. 教堂；教会
cigar|n. 雪茄烟
cigarette|n. 纸烟；香烟
cinema|n. 电影院；电影
circuit|n. 环形路线；巡回赛
circulate|v. （液体或气体）环流；循环
circumstance|n. 情况；环境
circus|n. 马戏团
citizen|n. 公民；市民
city|n. 市；城市；都市
civil|adj. 公民的；国内的
civilian|n. 平民；老百姓
civilization|n. 文明
claim|v. 声称；索要 n. 声明
clap|v. 拍手；鼓掌
clarify|v. 澄清；阐明
class|n. （学校的）班；年级；课
classic|adj. 经典的 n. 名著
classical|adj. 传统的；古典的
classify|v. 分类；归类
classmate|n. 同班同学
classroom|n. 教室
claw|n. 爪
clay|n. 黏土；陶土
clean|v. 弄干净；擦干净 adj. 清洁的；干净的
cleaner|n. 清洁工.；清洁器.；清洁剂
clear|adj. 清晰；明亮的；清楚的
clearly|adv. 清楚地；无疑地
clerk|n. 书记员；办事员；职员
clever|adj. 聪明的；伶俐的
click|v. 点击（计算机用语）
client|n. 客户；委托人
climate|n. 气候；风气
climb|v. 爬；攀登
clinic|n. 诊所
clock|n. 钟
clone|n. 克隆（无性繁殖出来的有机体群）
close|adj. 亲密的；近；靠近 adv. 近；靠近 v. 关；关闭
cloth|n. 布
clothes|n. 衣服；各种衣物
clothing|n. (总称) 衣服
cloud|n. 云；云状物；阴影
cloudy|adj. 多云的；阴天的
club|n. 俱乐部；纸牌中的梅花
clumsy|adj. 笨拙的；不灵巧的
co-worker|n. 合作者；同事
coach|n. 教练；马车；长途车
coal|n. 煤；煤块
coast|n. 海岸；海滨
coat|n. 外套；涂层；表皮；皮毛 v. 给……穿外套；涂上
cock|n. 公鸡
cocoa|n. 可可粉
code|n. 代码；规则
coffee|n. 咖啡
coin|n. 硬币
coincidence|n. 巧合；巧事
coke|n. 可口可乐
cold|adj. 冷的；寒的 n. 寒冷；感冒；伤风
coldblooded|adj. (动物) 冷血的
collapse|v./n. 倒塌；崩溃
collar|n. 衣领；硬领
colleague|n. 同事
collect|v. 收集；领取
collection|n. 收藏品；收集物
college|n. 学院；专科学校
collision|n. 碰撞事故
color|n. 颜色 v. 给…着色；涂色
colour|n. 颜色 v. 给…着色；涂色
comb|n. 梳子 v. 梳
combine|v. 结合；联合
comedy|n. 喜剧
comfort|n./v. 安慰；舒适
comfortable|adj. 舒服的；安逸的；舒服自在的
comma|n. 逗号
command|n./v. 命令；掌握
comment|n./v. 评论
commercial|adj. 商业的 n. 广告
commit|v. 犯（错）；承诺
commitment|n. 承诺；允诺；承担
committee|n. 委员会
common|adj. 普通的；共同的
communicate|v. 交流；传达
communication|n. 交际；交往；通讯
communism|n. 共产主义
communist|n. 共产主义者 adj. 共产党的；共产主义的
community|n. 社区；群体
companion|n. 同伴；伴侣
company|n. 公司；陪伴
compare|v. 比较；比作
compass|n. 罗盘；指南针
compensate|v. 补偿；弥补
compete|v. 竞争；比赛
competence|n. 能力；胜任；管辖权
competition|n. 竞争；比赛
competitor|n. 竞赛者；比赛者
complain|v. 抱怨；投诉
complete|adj. 完整的 v. 完成
complex|adj. 复杂的
component|n. 组成部分；部件
composition|n. 作文；作曲
comprehension|n. 理解
compromise|v. 妥协；折中；让步
compulsory|adj. 强制的；必须做的
computer|n. 电子计算机
comrade|n. 同志
concentrate|v. 集中；专心
concept|n. 概念
concern|n. 担心；关心 v. 涉及
concert|n. 音乐会；演奏会
conclude|v. 完成；结束
conclusion|n. 结论；结束
concrete|adj. 混凝土制的
condemn|v. 谴责；指责；宣判
condition|n. 条件；状况
conduct|v. 实施；指挥 n. 行为
conductor|n. 管理人；指导者；（车上的）售票员；列车员；乐队指挥
conference|n. 会议
confidence|n. 信心；信任
confident|adj. 自信的
confidential|adj. 机密的；保密的
confirm|v. 确认；证实
conflict|n. 冲突
confuse|v. 使困惑；混淆
congratulate|v. 祝贺
congratulation|n. 祝贺；庆贺
connect|v. 连接；联系
connection|n. 连接物；接触；联系
conscience|n. 良心；良知；内疚
conscious|adj. 有意识的；清醒的
consensus|n. 一致的意见；共识
consequence|n. 后果；结果
conservation|n. 保护；保存
conservative|adj. 保守的；守旧的；保守主义的；谨慎的 n. 保守的人；保守主义
consider|v. 考虑；认为
considerate|adj. 体贴的
consideration|n. 考虑；关心
consist|v. 由…组成（of）
consistent|adj. 一致的；始终如一的；连续的
constant|adj. 不断的；恒定的
constitution|n. 宪法；章程；身体素质
construct|v. 建造；构造
construction|n. 建造；建设；建筑物
consult|v. 咨询；查阅
consultant|n. 顾问
consume|v. 消耗；消费
contact|n./v. 联系；接触
contain|v. 包含；容纳
container|n. 容器
contemporary|adj. 当代的
content|n. 内容 adj. 满足的
contest|n. 比赛；竞争
context|n. 上下文；背景
continent|n. 大陆；洲
continue|v. 继续
contradict|v. 反驳；驳斥；批驳
contradictory|adj. 相互矛盾；对立的
contribute|v. 贡献；捐献；促成
contribution|n. 贡献；捐款
control|v./n. 控制
controversial|adj. 引起争论的；有争议的
convenience|n. 便利
convenient|adj. 方便的
conventional|adj. 依照惯例的；习惯的
conversation|n. 谈话
convey|v. 表达；传递（思想，感情等）
convince|v. 使相信；说服
cook|n. 炊事员；厨师 v. 烹调；做饭
cooker|n. 炊具(锅、炉灶、烤炉等)
cookie|n. 小甜饼
cool|adj. 凉的；凉爽的；酷
cooperate|v. 合作
cope|v. 处理；应付（with）
copy|n. 抄本；副本 v. 抄写；复印
coral|n. 珊瑚；珊瑚虫
cordless|adj. 无线的
corn|n. 玉米；谷物
corner|n. 角；角落；拐角
corporation|n. （大）公司
correct|v. 改正；纠正 adj. 正确的；对的；恰当的
correction|n. 改正
correspond|v. 通信；相一致
cost|n. 费用 v. 花费
cosy|adj. 暖和舒适的；亲密无间的
cottage|n. (郊外)小屋；村舍；别墅
cotton|n. 棉花 adj. 棉花的
cough|n./v. 咳嗽
count|v. 数；点数
counter|n. 柜台；结账处
country|n. 国家；农村；乡下
countryside|n. 乡下；农村
couple|n. 夫妇；一对
courage|n. 勇气
course|n. 过程；经过；课程
court|n. 法庭；法院
courtyard|n. 庭院；院子
cousin|n. 堂（表）兄弟；堂（表）姐妹
cover|n. 盖子；罩 v. 覆盖；遮盖；掩盖
cow|n. 母牛；奶牛
cowboy|n. （美国）牛仔；牧场骑士
crash|v./n. 碰撞；坠毁
crazy|adj. 疯狂的
cream|n. 奶油；乳脂
create|v. 创造
creative|adj. 有创造力的
creature|n. 生物；动物
credit|n. 信用；学分；赞扬
crew|n. 全体船员
crime|n. （法律上的）罪；犯罪
criminal|n. 罪犯
crisis|n. 危机
critical|adj. 批评的；关键的
criticize|v. 批评
crop|n. 庄稼；收成
cross|adj. 脾气不好的；易怒的 n. 十字形的东西 v. 越过；穿过
crossing|n. 十字路口；人行横道
crossroads|n. 交叉路口
crowd|n. 人群 v. 挤满
crowded|adj. 拥挤的
cruel|adj. 残忍的
cry|n. 叫喊；哭声 v. 喊叫；哭
cube|n. 立方体
cubic|adj. 立方体的；立方形的
cuisine|n. 饭菜；佳肴
cultural|adj. 文化的
culture|n. 文化
cup|n. 茶杯
cupboard|n. 碗柜；橱柜
cure|v. 治愈 n. 疗法
curious|adj. 好奇的
currency|n. 货币；现金
curriculum|n. （学校的）全部课程
curtain|n. 窗帘
cushion|n. 垫子
custom|n. 习俗；海关（customs）
customer|n. （商店）顾客；主顾
customs|n. 海关；关税
cycle|v. 骑自行车
cyclist|n. 骑自行车的人
daily|adj. 每日的；日常的 adv. 每天 n. 日报
dam|n. 水坝；堰堤
damage|n./v. 损坏；损害
damp|adj./n. 潮湿（的）
dance|n./v. 跳舞
danger|n. 危险
dangerous|adj. 危险的
dare|v./aux. （后接不带to的不定式；主要用于疑问，否定或条件句）敢；敢于
dark|n. 黑暗；暗处；日暮 adj. 黑暗的；暗淡的；深色的
darkness|n. 黑暗；阴暗
dash|v./n. 快跑；冲刺；短跑
data|n. 资料；数据
database|n. 资料库；数据库
date|n. 日期；约会 n. 枣
daughter|n. 女儿
dawn|n. 黎明；拂晓
day|n. （一）天；（一）日；白天
daylight|n. 日光；白昼；黎明
dead|adj. 死的；无生命的
deadline|n. 截止日期
deaf|adj. 聋的
deal|v. 处理（with） n. 交易
dear|int. （表示惊愕）哎呀！唷！ adj. 亲爱的；贵的
death|n. 死
debate|n./v. 辩论
debt|n. 债务；欠款
decade|n. 十年
decide|v. 决定；下决心
decision|n. 决定；决心
declare|v. 声明；断言
decline|v. 下降；婉拒
decorate|v. 装饰
decoration|n. 装饰；修饰
decrease|v./n. 减少
dedicate|v. 奉献；致力于
deed|n. 行为；事迹
deep|adj. 深 adv. 深；深厚
deeply|adv. 深深地
deer|n. 鹿
defeat|v. 打败 n. 失败
defend|v. 保卫；为…辩护
definite|adj. 明确的；肯定的
degree|n. 程度；度数；学位
delay|v./n. 推迟；耽搁
delete|v. 删去
deliberately|adv. 故意；蓄意；存心
delicate|adj. 精致的；易碎的
delicious|adj. 美味的
delight|n. 高兴 v. 使高兴
delighted|adj. 高兴的；快乐的
deliver|v. 递送；发表（演讲）
demand|n./v. 要求；需求
demonstrate|v. 证明；演示；示威
dentist|n. 牙科医生 
deny|v. 否认；拒绝给予
department|n. 部门；（机关的）司；处；（大学的）系
department-store|n. 百货商场
departure|n. 离开；启程
depend|v. 依靠；取决于（on）
deposit|n. 存款；押金 v. 存放
depress|v. 使沮丧
depth|n. 深；深度
describe|v. 描述
description|n. 描述；描写
desert|n. 沙漠 v. 抛弃
deserve|v. 应得；值得
design|n./v. 设计
desire|n./v. 渴望
desk|n. 书桌；写字台
desperate|adj. （因绝望而）不惜冒险的；不顾一切的；拼命的
despite|prep. 尽管
dessert|n. 甜点
destination|n. 目的地
destroy|v. 毁坏；破坏
detail|n. 细节
detective|n. 侦探
determination|n. 决心
determine|v. 决定；下决心
develop|v. 发展；开发；冲洗
development|n. 发展；发达；发育；开发
device|n. 装置；设备
devote|v. 致力于；献身（to）
devotion|n. 奉献；奉献精神
diagram|n. 图表；图样
dial|v. 拨（电话号码）
dialog|n. 对话
dialogue|n. 对话
diamond|n. 钻石；金刚石；纸牌中的方块
diary|n. 日记；日记簿
dictation|n. 听写
dictionary|n. 词典；字典
die|v. 死
diet|n. 饮食
differ|v. 不同
difference|n. 不同
different|adj. 不同的；有差异的
difficult|adj. 难；艰难；不易相处
difficulty|n. 困难
digest|v. 消化；领会
digital|adj. 数字的；数码的
dignity|n. 尊严
dilemma|n. （进退两难的）窘境；困境
dimension|n. 量度；尺寸；面积；程度；范围
dine|v. 吃饭；（指正式）进餐
dinner|n. 正餐；宴会
dinosaur|n. 恐龙
dioxide|n. 二氧化物
dip|v. 浸；蘸；把…放入又取出
diploma|n. 毕业文凭；学位证书
direction|n. 方向；方位
director|n. 所长；处长；主任；董事；导演
directory|n. 姓名地址录
dirt|n. 污物；脏物
dirty|adj. 脏的
disability|n. 残疾
disabled|adj. 残废的；残疾的
disadvantage|n. 不利条件；弱点
disagree|v. 不同意
disagreement|n. 意见不一致；相违；争论
disappear|v. 消失
disappoint|v. 使失望
disappointment|n. 失望；沮丧
disaster|n. 灾难
discount|n. 折扣
discourage|v. （使）气馁；打消（做…的念头）
discover|v. 发现
discovery|n. 发现
discrimination|n. 歧视
discuss|v. 讨论
discussion|n. 讨论；辩论
disease|n. 疾病
disgusting|adj. 极糟的；令人不快的；令人厌恶的
dish|n. 盘；碟；盘装菜；盘形物
dislike|v. 不喜爱；厌恶
dismiss|v. 解散；不予考虑
disobey|v. 不服从
display|v./n. 展示；陈列
distance|n. 距离
distant|adj. 远的；遥远的
distinct|adj. 明显的；不同的
distinction|n. 差别；区别；优秀；卓越
distinguish|v. 区分；辨别
distribute|v. 分发；分配
district|n. 区；地区；区域
disturb|v. 打扰；扰乱
disturbing|adj. 令人不安的；引起恐慌的
dive|v. 跳水
diverse|v. 不同的；多种多样；形形色色的
divide|v. 分；划分
division|n. （算术用语）除
divorce|v. 离婚
dizzy|adj. 头眩目晕的
do|v./aux. 做；干（用以构成疑问句及否定句。第三人称单数现在时用does） 不做；不干
doctor|n. 医生；大夫；博士
document|n. 文件
dog|n. 狗
doll|n. 玩偶；玩具娃娃
dollar|n. 元（美国、加拿大、澳大利亚等国货币单位）
domestic|adj. 国内的；家庭的
donate|v. 捐赠
door|n. 门
dormitory|n. 学生宿舍（缩写式dorm）
dot|n. 点；小点；圆点
double|adj. 两倍.双的 n. 两个.双
doubt|n./v. 怀疑；疑惑
down|prep. 沿着；沿…而下 adv. 向下
download|n./v. 下载
downstairs|adv. 在楼下；到楼下
downtown|adv. 往或在城市的商业区（或中心区、闹市区） n. 城市的商业区；中心区；闹市区 adj. 城市的商业区的；中心区的；闹市区的
downward|adv. 向下
dozen|n. 十二个；几十；许多
drag|v. 拖；拉
dramatic|adj. 戏剧性的；巨大的
drawback|n. 缺点；不利条件
drawer|n. 抽屉
drawing|n. 图画；素描；绘画
dream|n./v. 梦；梦想
dress|n. 女服；连衣裙；(统指)服装；童装 v. 穿衣；穿着
drill|n. 钻头；（反复的）训练 v. 钻(孔)；在…上钻孔；重复训练
drink|n. 饮料；喝酒 
driver|n. 司机；驾驶员
drop|n. 滴 v. 掉下.落下.投递.放弃
drown|v. 溺死；淹没
drug|n. 药；药物；毒品
drum|n. 鼓
drunk|adj. 醉的
dry|v. 使…干；弄干；擦干 adj. 干的；干燥的
duck|n. 鸭子
due|adj. 预期的；应付的；由于（to）
dull|adj. 阴暗的；单调无味
dumpling|n. 饺子
during|prep. 在…期间；在…过程中
dusk|n. 黄昏
dust|n. 灰尘；尘土
dustbin|n. 垃圾箱
dusty|adj. 尘土般的；尘土多的
duty|n. 责任；义务
dynasty|n. 朝代
each|adj./pron. 每人.每个.每件
eager|adj. 渴望的
eagle|n. 鹰
ear|n. 耳朵.耳状物；听力；听觉
early|adj. 早的 adv. 早地
earn|v. 挣得；赢得
earth|n. 地球；土；泥；大地
earthquake|n. 地震
ease|v. 减轻；缓解（难度或严重程度）
easily|adv. 容易地
east|adj. 东方；东部的；朝东的；从东方来 adv. 在东方；向东方；从东方 n. 东；东方；东部
eastern|adj. 东方的；东部的
eastwards|adv. 向东
easy|adj. 容易的；不费力的
easygoing|adj. 随和的
ecology|n. 生态；生态学
economic|adj. 经济的
economy|n. 经济；节约
edge|n. 边缘
edition|n. 版本
editor|n. 编辑
educate|v. 教育
education|n. 教育；培养
educator|n. 教育家
effect|n. 效果；影响
effective|adj. 有效的
efficient|adj. 高效的
effort|n. 努力
egg|n. 蛋；卵
eggplant|n. 茄子
eight|num. 八
eighteen|num. 十八
eighth|num. 第八
eighty|num. 八十
either|adj. 两方任一方的；二者之一 conj. 二者之一；要么……
elder|n. 长者；前辈
elect|v. 选举
electric|adj. 电的
electrical|adj. 电的；电器的
electricity|n. 电；电流
electronic|adj. 电子的
elegant|adj. 文雅的；漂亮的；精美的
element|n. 元素；要素
elephant|n. 象
eleven|num. 十一
eliminate|v. 消除；淘汰
else|adv. 别的；其他的
email|n. 电子邮件
embarrass|v. 使尴尬
embassy|n. 大使馆
emerge|v. 出现；浮现
emergency|n. 紧急情况
emotion|n. 情感；情绪
emperor|n. 皇帝
emphasis|n. 强调；重点
empire|n. 帝国
employ|v. 雇用；使用
empty|adj. 空的
enable|v. 使能够
encounter|v./n. 遇到；邂逅
encourage|v. 鼓励
encouragement|n. 鼓励
end|n. 末尾；终点；结束 v. 结束；终止
ending|n. 结局；结尾；最后
endless|adj. 无止境的；没完的
enemy|n. 敌人；敌军
energetic|adj. 精力旺盛的
energy|n. 能量；精力
engage|v. 参与；吸引；雇用
engine|n. 发动机；引擎
engineer|n. 工程师；技师
enhance|v. 提高；增强
enjoy|v. 享受；喜欢
enjoyable|adj. 愉快的；有趣的
enlarge|v. 扩大
enormous|adj. 巨大的
enough|n. 足够；充足 adj. 足够；充分的 adv. 足够地；充分地
enquiry|n. 询问
ensure|v. 确保
enter|v. 进入
enterprise|n. 公司；企；事业单位
entertain|v. 娱乐；招待
entertainment|n. 娱乐
enthusiasm|n. 热情
enthusiastic|adj. 热情的；热心的
entire|adj. 整个的
entrance|n. 入口；进入
entry|n. 进入
envelope|n. 信封
environment|n. 环境
envy|v./n. 忌妒；羡慕
equal|adj. 相等的；平等的
equality|n. 平等
equip|v. 装备
equipment|n. 设备
eraser|n. 橡皮擦；黑板擦
error|n. 错误；差错
erupt|v. （火山）爆发；喷发
escape|v./n. 逃脱
especially|adv. 特别；尤其
essay|n. 文章；短文
essential|adj. 必要的；本质的
establish|v. 建立；确立
estimate|v./n. 估计
evaluate|v. 评价；评估
even|adv. 甚至；连（…都）；更
evening|n. 傍晚；晚上
event|n. 事件；活动
eventually|adv. 最后；终于
ever|adv. 曾经；无论何时
every|adj. 每一；每个的
everybody|pron. 每人；人人
everyday|adj. 每日的；日常的
everyone|pron. 每人；人人
everything|pron. 每件事；事事
everywhere|adv. 到处
evidence|n. 证据
evident|adj. 清楚的；显而易见的
evolution|n. 进化；演变
exact|adj. 确切的
exactly|adv. 精确地；确切地
examine|v. 检查；考查
example|n. 例子；榜样
excellent|adj. 极好的；优秀的
except|prep. 除……之外
exchange|v./n. 交换；交流
excite|v. 使兴奋
excuse|n. 借口.辩解 v. 原谅.宽恕
exercise|n. 锻炼；做操；练习；习题 v. 锻炼
exhibition|n. 展览
exist|v. 存在
existence|n. 存在；生存；存在物
exit|n. 出口；太平门
expand|v. 扩大；扩展
expect|v. 期待；预料
expectation|n. 预料；期望
expense|n. 费用；花费
expensive|adj. 昂贵的
experience|n. 经验；经历 v. 经历
experiment|n. 实验
expert|n. 专家
explain|v. 解释
explanation|n. 解释；说明
explicit|adj. 清楚明白；易于理解的
explode|v. （使）爆炸
exploit|v. 开采.开发.利用.剥削
explore|v. 探索；探究
explorer|n. 探险者
export|v./n. 出口
expose|v. 暴露；使接触
express|v. 表达 n. 快车
expression|n. 表达；词句；表示；说法；表情
extend|v. 延伸；扩展
extension|n. 扩大；延伸
extra|adj. 额外的
extraordinary|adj. 非凡的；特别的
extreme|adj. 极端的；极度的
extremely|adv. 极其；非常
eye|n. 眼睛
eyesight|n. 视力；视觉
eyewitness|n. 目击证人
face|n. 脸 v. 面向；面对
facial|adj. 面部用的
facility|n. 设施；设备
fact|n. 事实；现实
factor|n. 因素
factory|n. 工厂
fade|v. 褪色；逐渐消失
fail|v. 失败；未能
failure|n. 失败
fair|adj. 公平的；合理的 adj. (肤色)白皙的；（人）白肤金发的 n. 集市；庙会；展览会
fairly|adv. 公正地；正当地；相当（程度）地
fairness|n. 公平；公正
faith|n. 信念；信任
fall|n. （美）秋季
false|adj. 不正确的；假的
familiar|adj. 熟悉的
family|n. 家庭；家族；子女
famous|adj. 著名的
fan|n. （电影、运动等的）迷；热心的爱好者（支持者） n. 风扇
fancy|adj. 花式；装饰的；奇特的
fantastic|adj. 极好的；奇异的
fare|n. 车费
farm|n. 农场；农庄
farmer|n. 农民
fascinate|v. 使着迷
fast|adj. 快的；迅速的；紧密的 adv. 快地；迅速地；紧密地
fasten|v. 扎牢；扣住
fat|n. 脂肪 adj. 胖的；肥的
father|n. 父亲
fault|n. 过错；缺点
favour|n. 恩惠；帮助
fax|n. 传真
fear|n. 害怕；恐惧；担忧
feast|n. 盛宴；宴会；（宗教的）节日
feather|n. 羽毛
feature|n. 特征 v. 以…为特色
federal|adj. 中央的（政府）联邦的
fee|n. 费用
feeling|n. 感情；感觉
fellow|n. 同伴；伙伴
female|adj. 女的；女性的；雌性的
fence|n. 栅栏；围栏；篱笆
ferry|n. 渡船
festival|n. 节日
fetch|v. （去）取（物）来；（去）带（人）来
fever|n. 发烧；发热
few|pron. 不多；少数 不多的；少数的
fiction|n. 小说；虚构的事
field|n. 田地；牧场；场地
fierce|adj. 猛烈的
fifteen|num. 十五
fifth|num. 第五
fifty|num. 五十
fight|n. 打仗（架）；争论
fighter|v. 战士；斗士
figure|n. 数字；人物；身材 v. 认为
file|n. 文件
fill|v. 填空；装满
film|n. 电影；影片；胶卷 v. 拍摄；把……拍成电影
final|adj. 最后的；终极的
finance|n. 财政；金融
fine|adj. 细的；晴朗的；美好的；（身体）健康的 n./v. 罚款
finger|n. 手指
fingernail|n. 指甲
finish|v. 结束；做完
fire|n. 火；火炉；火灾 v. 开火；开（枪，炮等）；射击
firefighter|n. 消防人员
fireplace|n. 壁炉
firewood|n. 木柴
firework|n. 焰火
firm|n. 公司；企业 adj. 坚固的；坚定的
firmly|adv. 牢牢地
first|num. 第一 adj./adv. 第一；首次；最初 n. 开始；开端
fish|n. 鱼；鱼肉 v. 钓鱼；捕鱼
fisherman|n. 渔民；钓鱼健身者
fist|n. 拳(头)
fit|adj. 健康的；适合的 v. （使）适合；安装
five|num. 五
fix|v. 修理；安装；确定；决定
flag|n. 旗；标志；旗舰
flame|n. 火焰；光辉
flaming|adj. 火红的；火焰般的
flash|n. 闪；闪光；转瞬间
flashlight|n. 手电
flat|adj. 平的 n. 楼中一套房间；公寓(常用复数)
flesh|n. 肉
flexible|adj. 灵活的
flight|n. 航班 n. 楼梯的一段
float|v. 漂浮
flood|n. 洪水 v. 淹没
floor|n. 地面；地板.（楼房的）层
flour|n. 面粉；粉
flow|v. 流动
flower|n. 花
flu|n. 流行性感冒
fluency|n. （外语）流利；流畅
fluent|adj. （外语）流利的；流畅
fly|n. 飞行；苍蝇
focus|v./n. 集中；焦点
fog|n. 雾
foggy|adj. 多雾的
fold|v. 折叠；合拢
folk|adj. 民间的
follow|v. 跟随；仿效；跟得上
following|adj. 接着的；以下的
fond|adj. 喜爱的；爱好的
food|n. 食物；食品
fool|n. 傻子；蠢人
foolish|adj. 愚蠢的；傻的
football|n. （英式）足球；（美式）橄榄球
for|prep. 为了…；向…；往…；与…交换；防备…；适合…；因为…；在…期 间；对于…；对…来说 conj. 因为；由于
forbid|v. 禁止
force|n. 力量 v. 强迫
forecast|n./v. 预报
forehead|n. 前额
foreign|adj. 外国的
foreigner|n. 外国人
forest|n. 森林
forever|adv. 永远；永恒的
forgetful|adj. 健忘的；不留心的
forgive|v. 原谅
fork|n. 叉；餐叉
form|n. 表格；形式；结构
format|n. 安排；计划；设计
former|adj. 以前的；前者的
fortnight|n. 十四日；两星期
fortunate|adj. 幸运的；侥幸的
fortune|n. 运气；财富
forty|num. 四十
forward|adv. 将来.今后.向前；前进
found|v. 创建；建立
founding|n. 成立；建立
fountain|n. 喷泉
four|num. 四
fourteen|num. 十四
fourth|num. 第四
fox|n. 狐狸
fragile|adj. 易碎的；易损的
fragrant|adj. 香的；芳香的
framework|n. （建筑物）框架；结构
franc|n. 法郎
free|adj. 自由；空闲的；免费的
freedom|n. 自由
freeway|n. 高速公路
freezing|adj. 冻结的；极冷的
frequent|adj. 频繁的
fresh|adj. 新鲜的
friction|n. 摩擦
fried|adj. 油煎的
friend|n. 朋友
friendly|adj. 友好的
friendship|n. 友谊；友情
fright|n. 惊恐；恐吓
frighten|v. 使害怕
frog|n. 青蛙
from|prep. 从；从…起.距.来自
front|adj. 前面的；前部的 n. 前面；前部；前线
frontier|n. 前沿；边界；前线
frost|n. 霜
fruit|n. 水果；果实
frustrate|v. 使沮丧；挫败
fry|v. 用油煎；用油炸
fuel|n. 燃料
full|adj. 满的；充满的；完全的
fun|n. 有趣的事；娱乐；玩笑
function|n. 功能 v. 运转
fund|n. 基金；资金
fundamental|adj. 基本的；根本的
funeral|n. 葬礼
funny|adj. 有趣的；滑稽可笑的
fur|n. 毛皮；皮子
furnished|adj. 配备了家具的
furniture|n. 家具
future|n. 将来
gain|v. 获得；增加 n. 收获
gale|n. 强风（约每小时60英里）
gallery|n. 画廊；美术品陈列室
gallon|n. 加仑
game|n. 游戏；运动；比赛
garage|n. 汽车间（库）
garbage|n. 垃圾
garden|n. 花园；果园；菜园
gardening|n. 园艺学
garlic|n. 大蒜
garment|n. （一件）衣服
gas|n. 煤气
gate|n. 大门
gather|v. 聚集；收集
gay|adj. （男）同性恋的；快活的；愉快的
general|adj. 大体；笼统的；总的
generate|v. 产生
generation|n. 一代人；产生
generous|adj. 慷慨的
gentle|adj. 温柔的；轻柔的
gentleman|n. 绅士；先生；有身份；有教养的人
genuine|adj. 真正的；真诚的
geography|n. 地理学
geometry|n. 几何学
gesture|n. 姿势；手势
gettogether|n. 聚会
gift|n. 赠品；礼物
gifted|adj. 有天赋的；有才华的
giraffe|n. 长颈鹿
girl|n. 女孩
glad|adj. 高兴的；乐意的
glance|v. 匆匆一看；一瞥
glare|v. 瞪眼；怒目而视；闪耀
glass|n. 玻璃杯；玻璃；眼镜
glasshouse|n. 温室；暖房
global|adj. 全球的
globe|n. 地球仪；地球
glory|n. 巨大的光荣；荣誉；赞美
glove|n. 手套
glue|n. 胶水
goal|n. 目标；球门
goat|n. 山羊
god|n. 神；（大写）上帝
gold|n. 黄金 a 金的；黄金的
golden|adj. 金(黄)色的
goldfish|n. 金鱼
golf|n. 高尔夫球
good-bye|int. 再见；再会
goodness|n. 善良；美德
goods|n. 商品；货物
govern|v. 统治；管理
government|n. 政府
gown|n. 礼服；长外衣；睡衣
grab|v. 抓取
grade|n. 年级；等级；成绩
gradual|adj. 逐渐的
gradually|adv. 逐渐地
graduate|v. 毕业 n. 毕业生
graduation|n. 毕业；毕业典礼
grain|n. 谷物；谷类
gram|n. 克(重量单位)
grammar|n. 语法
grand|adj. 宏伟的
grandchild|n. (外)孙或孙女.孙辈
granddaughter|n. （外）孙女
grandparents|n. 祖父母.外祖父母
grandson|n. （外）孙子
granny|n. 老奶奶；祖母；外婆
grape|n. 葡萄
graph|n. 图表；曲线图
grasp|v. 抓住；紧握
grass|n. 草；草场；牧草
grateful|adj. 感激的
gravity|n. 重力；地球引力
great|adj. 伟大的；重要的；好极了 adv. （口语）好极了；很好
greedy|adj. 贪婪的
green|adj. 绿色的；青的 n. 绿色
greengrocer|n. （英）蔬菜水果商
greet|v. 问候；迎接
greeting|n. 祝贺
grey|adj. 灰色的；灰白的
grill|n. （烧食物的）烤架
grocer|n. 零售商人；食品店
ground|n. 地面
group|n. 组；群
growth|n. 生长；增长
gruel|n. 粥
guarantee|v./n. 保证
guard|n. 防护装置；警戒
guess|v. 猜
guest|n. 客人；宾客
guidance|n. 引导；指导
guide|n. 向导；导游者
guilty|adj. 内疚的；有罪的
guitar|n. 吉他；六弦琴
gun|n. 枪；炮
gymnastics|n. 体操
ha|int. 哈(笑声)
habit|n. 习惯
hair|n. 头发
haircut|n. （男子）理发
half|adj./n. 半；一半；半个
hall|n. 大厅；会堂；礼堂；过道
ham|n. 火腿
hamburger|n. 汉堡包
hammer|n. 锤子；锣锤
hand|n. 手；指针 v. 递；给；交付 交上；交进
handbag|n. 女用皮包；手提包
handful|n. (一)把；少数；少量
handkerchief|n. 手帕
handle|v. 处理 n. 把手
handsome|adj. 英俊的
handtruck|n. 手推运货车
handwriting|n. 书法
handy|adj. 便利的；顺手的 hang(hanged,hanged) v. 处（人）绞刑；上吊
happen|v. （偶然）发生
happily|adv. 幸福地；快乐地
happiness|n. 幸福；愉快
happy|adj. 幸福；快乐的；高兴的
harbor|n. 港口
harbour|n. 港口
hard|adv. 努力地；使劲；猛烈地 adj. 硬的；困难的；艰难的
hardly|adv. 几乎不
hardship|n. 困难
hardworking|adj. 努力工作的
harm|n./v. 伤害
harmful|adj. 有害的；致伤的
harmless|adj. 无害的；不致伤的
harmony|n. 和谐
harvest|n./v. 收割；收获（物）
hat|n. 帽子(一般指有边的)；礼帽
hatch|v. （鸟、鸡）孵蛋
hate|v./n. 恨；讨厌
hawk|n. 鹰
hay|n. 作饲料用的干草
he|pron. 他
head|n. 头；头脑(像)；才智；首脑；源头；标题 adj. 头部的；主要的；首席的 v. 率领；加标题；用头顶；出发；(船等)驶向
headache|n. 头疼
headline|n. 标题；头条
headmaster|n. （英）中小学校长
headmistress|n. 女校长
headteacher|n. 中小学班主任
heal|v. 治愈；愈合
health|n. 健康；卫生
healthy|adj. 健康的；健壮的
heap|n. 堆 v. 堆起来
hearing|n. 听力
heart|n. 心.心脏；纸牌中的红桃
heat|n. 热 v. 把……加热
heaven|n. 天；天空
heavily|adv. 重地；大量地
heavy|adj. 重的
heel|n. 脚后跟
height|n. 高；高度
helicopter|n. 直升飞机
hello|int. 喂；你好（表示打招呼，问候或唤起注意）
helmet|n. 头盔
help|n./v. 帮助；帮忙
helpful|adj. 有帮助的；有益的
hen|n. 母鸡
her|pron. 她(宾格)；她的
herb|n. 草药
here|adv. 这里；在这里；向这里
heritage|n. 遗产；传统
hero|n. 英雄；勇士；男主角
heroine|n. 女英雄；女主角
hers|pron. 她的
herself|pron. 她自己
hesitate|v. 犹豫
hey|int. 嘿！
hi|int. 你好（表示打招呼、问候或唤起注 意）
hibernate|v. 冬眠
hibernation|n. 冬眠
high|adj. 高的；高度的 adv. 高地
highlight|v. 突出 n. 最精彩部分
highway|n. 公路；主要交通道路
hill|n. 小山；丘陵；土堆；斜坡
hillside|n. （小山）山腰；山坡
hilly|adj. 丘陵的；多小山的
him|pron. 他（宾格）
himself|pron. 他自己
hire|v. 租用
his|pron. 他的
history|n. 历史；历史学
hive|n. 蜂房；蜂箱
hobby|n. 业余爱好；嗜好
hole|n. 洞；坑
holiday|n. 假日；假期
holy|adj. 神圣的
home|n. 家 adv. 到家；回家
homeland|n. 祖国
hometown|n. 故乡
homework|n. 家庭作业
honest|adj. 诚实的；正直的
honey|n. 蜂蜜
honor|n. 荣誉；光荣 v. 尊敬；给予荣誉
honour|n. 荣誉 v. 尊敬
hook|n./v. 钩子；衔接；连接
hooray|int. 好哇！（欢呼声）
hope|n./v. 希望
hopeful|adj. 有希望的；有前途的
hopeless|adj. 没有希望；不可救药的
horizon|n. 地平线；眼界
horrible|adj. 令人恐惧；恐怖的
horse|n. 马
hospital|n. 医院
host|n. 主人；主持人 v. 主办
hostess|n. 女主人
hot|adj. 热的
hotel|n. 旅馆；饭店；宾馆
hour|n. 小时
house|n. 房子；住宅
household|n. 家庭 adj. 家庭的
housewife|n. 家庭主妇
housework|n. 家务劳动
how|adv. 怎样；如何；多少；多么
however|adv. 可是 conj. 然而；可是；尽管如此
howl|v. 嚎叫；嚎哭
hug|v. 拥抱
huge|adj. 巨大的；庞大的
human|adj. 人的；人类的
humble|adj. 谦逊的；卑微的
humor|n. 幽默；幽默感
humorous|adj. 富于幽默的
humour|n. 幽默
hundred|num. 百
hunger|n. 饥饿
hungry|adj. （饥）饿的
hunt|v. 寻找；狩猎；猎取
hunter|n. 猎人
hurricane|n. 飓风；十二级风
hurry|v. 赶快；急忙
husband|n. 丈夫
hydrogen|n. 氢
ice|n. 冰
ice-cream|n. 冰淇淋
idea|n. 主意；意见；打算；想法
identification|n. 鉴定；辨别
identify|v. 识别；确认；认同
identity|n. 身份；特征
idiom|n. 习语；成语
if|conj. 如果；假使；是否；是不是
ignore|v. 忽视
ill|adj. 有病的；不健康的
illegal|adj. 非法的
illness|n. 疾病
illustrate|v. 说明；给…加插图
image|n. 形象；图像
imagine|v. 想象
immediate|adj. 立即的；直接的
immediately|adv. 立即
immigration|n. 移民
impact|n. 影响；冲击
import|v./n. 进口
importance|n. 重要性
important|adj. 重要的
impossible|adj. 不可能的
impress|v. 给…留下深刻印象
impression|n. 印象；感觉
improve|v. 改进；提高
in|prep. 在…里(内)；在…；以… adv. 在家；在内；向内
inch|n. 英寸
incident|n. 事件
include|v. 包括
income|n. 收入
incorrect|adj. 不正确的；错误的
increase|v./n. 增加
incredible|adj. 难以置信的
indeed|adj. 确实；实在
independence|n. 独立
independent|adj. 独立的
indicate|v. 表明；指出
individual|adj. 个人的 n. 个人
industry|n. 工业；行业
influence|n./v. 影响
inform|v. 通知；告知
information|n. 信息
ingredient|n. 原料；成分
initial|adj. 最初的
injure|v. 伤害
injury|n. 受伤处
ink|n. 墨水；油墨
inland|adj. 内陆的；内地的
inn|n. 小旅店；小饭店
innocent|adj. 无辜的；天真的
insect|n. 昆虫
insert|v. 插入
inside|prep. 在…里面 adv. 在里面
insist|v. 坚持；坚决要求（on）
inspect|v. 检查；检验；审视
inspire|v. 鼓舞；激发灵感
install|v. 安装
instance|n. 例子
instant|adj. 立即的；速溶的
instead|adv. 代替；顶替
institute|n. (研究)所；院；学院
institution|n. (慈善、宗教等性质的)公共机构；学校
instruct|v. 指导；命令
instruction|n. 说明；须知；教导
instrument|n. 仪器；乐器
insurance|n. 保险
insure|v. 给……保险
intelligence|n. 智力；才智；智慧
intend|v. 打算
intense|adj. 强烈的；紧张的
intention|n. 打算；计划；意图
interact|v. 互动；相互作用
interest|n. 兴趣；趣味；利息
interesting|adj. 有趣的
interfere|v. 干涉；妨碍
internal|adj. 内部的
international|adj. 国际的
internet|n. 互联网；英特网
interpret|v. 解释；口译
interpreter|n. 翻译
interrupt|v. 打断
interval|n. 间歇；间隔
interview|n./v. 采访；会见；面试
into|prep. 到…里；向内；变成
introduce|v. 介绍；引进
introduction|n. 引进；介绍
invent|v. 发明
invention|n. 发明；创造
inventor|n. 发明者；创造者
invest|v. 投资
investigate|v. 调查
invitation|n. 邀请；请帖
invite|v. 邀请
involve|v. 涉及；使参与
iron|n. 铁；熨斗 v. 熨烫
irrigate|v. 灌溉
irrigation|n. 灌溉
island|n. 岛
issue|n. 问题；（报刊）一期 v. 发布
it|pron. 它
item|n. 项目；物品
its|pron. 它的
itself|pron. 它自己
jacket|n. 短上衣；夹克衫
jam|n. 果酱；阻塞
jar|n. 罐子；坛子
jaw|n. 下巴
jazz|n. 爵士音乐；爵士舞曲
jeans|n. 牛仔裤
jeep|n. 吉普车
jet|n. 喷气式飞机；喷射（器）
jewel|n. 宝石
jewelry|n. （总称）珠宝
job|n. （一份）工作
jog|v. 慢跑
join|v. 参加；加入；连接；会合
joke|n. 笑话
journalist|n. 记者；新闻工作者
journey|n. 旅行；旅程
joy|n. 欢乐；高兴；乐趣
judge|v. 判断 n. 法官；裁判
judgement|n. 裁判
juice|n. 汁；液
juicy|adj. 多汁的；水分多的
jump|n. 跳跃；跳变 v. 跳跃；惊起；猛扑
jungle|n. 丛林；密林
junior|adj. 初级的；年少的
junk|n. （口语）废品；破烂货
just|adv. 刚才；恰好；不过；仅 adj. 公正的
justice|n. 正义；公正
kangaroo|n. 大袋鼠
keen|adj. 热衷的；敏锐的
keeper|n. （动物园中的）饲养员；看守人
kettle|n. (烧水用的)水壶
key|n. 钥匙；答案；键；关键
keyboard|n. 键盘
kick|v./n. 踢
kid|n. 小孩
kill|v. 杀死；弄死
kilo|n. 千克；千米
kilogram|n. 千克
kilometre|n. 千米（公里）
kind|n. 种；类 adj. 善良；友好的
kind-hearted|adj. 好心的
kindergarten|n. 幼儿园
kindness|n. 仁慈；善良
king|n. 国王
kingdom|n. 王国
kiss|n./v. 吻；亲吻
kitchen|n. 厨房
kite|n. 风筝
knee|n. 膝盖
knife|n. 小刀；匕首；刀片
knock|n./v. 敲；打；击 
knowledge|n. 知识
label|n. 标签 v. 贴标签
labor|n. 劳动
labour|n. 劳动
labourer|n. 体力劳动者
lack|n./v. 缺乏；缺少
ladder|n. 梯子
lady|n. 女士；夫人
lake|n. 湖
lamb|n. 羔羊
lame|adj. 跛的；瘸的；残废的
lamp|n. 灯；油灯；光源
land|n. 陆地；土地 v. 登岸(陆)降落
landscape|n. 风景
language|n. 语言
lantern|n. 灯笼；提灯
lap|n. (人坐时)膝部.(跑道的)一圈
large|adj. 大的；巨大的
laser|n. 激光
last|adj. 最近刚过去；最后的 adv. 最近刚过去；最后地 n. 最后 v. 持续
late|adj. 晚的；迟的 adv. 晚地；迟地
lately|adv. 最近；不久前
later|adj. 晚些的；迟些的
latest|adj. 最新的
latter|n. （两者之中的）后者
laugh|n./v. 笑；大笑；嘲笑
laughter|n. 笑；笑声
launch|v. 发射；发起
laundry|n. 洗衣店；要洗的衣服
lavatory|n. 便所；厕所
law|n. 法律；法令；定律
lawyer|n. 律师
layer|n. 层
lazy|adj. 懒惰的
leader|n. 领袖；领导人
leadership|n. 领导力
leading|adj. 最主要的；第一位的
league|n. 联盟；社团
leak|v. 漏；渗
learn|v. 学；学习；学会
learned|adj. 有才华的；博学的
least|n. 最少；最少量
leather|n. 皮革
lecture|n. 讲座
left|adj. 左边的 adv. 向左 n. 左；左边
left-handed|adj. 惯用左手的
left-wing|n. 左翼的
leftover|adj. 剩余；剩下的 n. 剩饭菜
leg|n. 腿；腿脚；支柱
legal|adj. 与法律有关的；法律的
leisure|n. 闲暇
lemon|n. 柠檬 adj. 柠檬色(味)的
lemonade|n. 柠檬水
length|n. 长；长度；段；节
less|adj./adv. 少于；小于（little的比较级）
lesson|n. 课；功课；教训
let|v. 让
letter|n. 信；字母
letter-box|n. 信箱
level|n. 水平线；水平
liberate|v. 解放；使获自由
liberation|n. 解放
liberty|n. 自由
librarian|n. 图书管理员；（西方的）图书馆馆长
library|n. 图书馆；图书室
license|n. 执照
lid|n. 盖子
lifetime|n. 一生；终生
lift|v. 举起；抬起；（云、烟等）消散 n. （英）电梯
light|n. 光；光亮；灯；灯光 v. 点（火）；点燃 adj. 明亮的；轻的；浅色的
lightning|n. 闪电
like|prep. 像；跟…一样 v. 喜欢；喜爱
likely|adj. 很可能的
limit|n./v. 限制
line|n. 绳索；线；排；行；线路 v. 画线于；（使）成行
link|v. 连接；联系
lion|n. 狮子
lip|n. 嘴唇
liquid|n./adj. 液体；液体的
list|n. 一览表；清单
listen|v. 听；仔细听
liter|n. 升；公升
literary|adj. 文学的
literature|n. 文学
litre|n. 升；公升
litter|v. 乱丢杂物
live|v. 生活；居住；活着 adj. 活的；活着的；实况；现场（直播）的
lively|adj. 活泼的；充满生气的
living|adj. 活着的 n. 生计
load|n. 担子；货物
loaf|n. 一个面包
local|adj. 当地的
locate|v. 位于；找出
lock|n. 锁 v. 锁；锁上
locust|n. 蝗虫
lonely|adj. 孤独的
long|adj. 长的；远 adv. 长久
look|n. 看；瞧 v. 看；观看 v. link 看起来
loose|adj. 松散的；宽松的
lorry|n. （英）运货汽车；卡车
loss|n. 丧失；损耗
lot|n. 许多；好些
loud|adj. 大声的
loudly|adv. 大声地
loudspeaker|n. 扬声器；喇叭
lounge|n. 休息厅；休息室
love|n./v. 爱；热爱；很喜欢
lovely|adj. 美好的；可爱的
low|adj./adv. 低；矮
loyal|adj. 忠诚的
luck|n. 运气；好运
lucky|adj. 运气好；侥幸
luggage|n. (总称)行李
lunch|n. 午餐；午饭
lung|n. 肺；肺脏
luxury|n. 奢侈；奢侈品
machine|n. 机器
mad|adj. 发疯的；生气的
madam|n. 夫人；女士
magazine|n. 杂志
magic|adj. 有魔力的
maid|n. 女仆；侍女
mail|n. 邮政；邮递 v. (美)邮寄
mailbox|n. 邮筒；邮箱
main|adj. 主要的
mainland|n. 大陆
maintain|v. 保持；维修
major|adj. 主要的 n. 专业 v. 主修
majority|n. 大多数 
male|adj. 男（性）的；雄的
man-made|adj. 人造的；人工的
manage|v. 管理；设法做成
manager|n. 经理
mankind|n. 人类；（总称）人
manner|n. 方式；礼貌（manners）
map|n. 地图
maple|n. 枫树
marathon|n. 马拉松
marble|n. 大理石；玻璃弹子
march|n. 游行；行进
mark|n. 标记 v. 标明；作记号于
market|n. 市场；集市
marriage|n. 结婚；婚姻
married|adj. 已婚的
marry|v. （使）成婚；结婚
marvellous|adj. 了不起的
mask|n. 口罩；面罩(具)；遮盖物 v. 戴面具；掩饰；伪装
mass|n. 众多；大量；群众
master|v. 精通；掌握
mat|n. 垫子
match|v. 使相配；使成对 n. 比赛；竞赛 n. 火柴
material|n. 材料；原料
matter|n. 要紧事；要紧；事情；问题 v. 要紧；有重大关系
mature|adj. 成熟的
maximum|adj./n. 最大量(的)；最大限度(的)
maybe|adv. 可能；大概；也许
me|pron. 我（宾格）
meal|n. 一餐（饭） 
meaning|n. 意思；含意
means|n. 方法；手段；财产
meanwhile|adv. 同时
measure|v. 测量 n. 措施
meat|n. （猪、牛、羊等的）肉
medal|n. 奖牌
media|n. 媒体
medical|adj. 医学的；医疗的
medicine|n. 药；医学
medium|n. 媒体；中间的；中等的
meeting|n. 会；集会；会见；汇合点
melon|n. （甜）瓜；瓜状物
melt|v. 融化
member|n. 成员；会员
memorial|n. 纪念馆
memorize|v. 记忆
memory|n. 记忆；回忆
mend|v. 修理；修补
mental|adj. 精神的；心理的
mentally|adv. 精神上；智力上
mention|v./n. 提及
menu|n. 菜单
merchant|adj. 商业的；商人的 n. 商人；生意人
merciful|adj. 仁慈的；宽大的
mercy|n. 怜悯
merely|adv. 仅仅；只不过
merry|adj. 高兴的；愉快的
mess|n. 混乱
message|n. 消息；音信
messy|adj. 乱七八糟的
metal|n. 金属 adj. 金属制成的
meter|n. 米；公尺
method|n. 方法
metre|n. 米；公尺
microcomputer|n. 微机
microscope|n. 显微镜
microwave|n. 微波
mid-autumn|n. 中秋
midday|n. 中午；正午
middle|n. 中间；当中；中级的
midnight|n. 午夜
mild|adj. 温和；暖和的；凉爽的
mile|n. 英里
military|adj. 军事的
milk|n. 牛奶 v. 挤奶
millimetre|n. 毫米
million|num. 百万 n. 百万个（人或物）
millionaire|n. 百万富翁
mind|n. 思想；想法 v. 介意；关心
mine|n. 矿藏；矿山 v. 开采(矿物) pron. 我的
mineral|n. 矿物质；矿物
minibus|n. 小型公共汽车
minimum|adj. 最小的
miniskirt|n. 超短裙
minister|n. 部长；牧师
ministry|n. （政府的）部
minor|adj. 较小的；次要的
minority|n. 少数；少数民族
minus|prep./adj. 负的；减去的
minute|n. 分钟；一会儿；瞬间
mirror|n. 镜子
miss|v. 失去；错过；缺
mission|n. 使命；任务
mist|n. 雾
mistake|n. 错误 v. 误认
mistaken|adj. 错误的
misunderstand|v. 误会；不理解
mix|v. 混合；搅拌
mixture|n. 混合物
mobile|adj. 活动的；可移动的
model|n. 模型；原形；范例；模范
modem|n. 调制解调器
modern|adj. 现代的
modest|adj. 谦虚的；谦逊的
moment|n. 片刻；瞬间
money|n. 钱；货币
monitor|n. （班级内的）班长；纠察生；监视器
monkey|n. 猴子
month|n. 月；月份
monument|n. 纪念碑；纪念物
mood|n. 心情
moon|n. 月球；月光；月状物
moral|adj. 道德的 n. 寓意
morning|n. 早晨；上午
most|adj./adv. 最多 n. 大部分；大多数
mother|n. 母亲
motherland|n. 祖国
motivate|v. 激励
motivation|n. 动力；动机
motor|n. 发动机；马达
motorbike|n. 摩托车
motorcycle|n. 摩托车
motto|n. 箴言；格言
mountain|n. 山；山脉
mountainous|adj. 多山的
mourn|v. 哀痛；哀悼
moustache|n. 小胡子
mouth|n. 嘴；口
mouthful|n. 满口；一口
move|v. 移动；搬动；搬家
movement|n. 运动；活动
movie|n. （口语）电影
mud|n. 泥；泥浆
muddy|adj. 泥泞的
multiply|v. 乘；使相乘
murder|v. 谋杀
museum|n. 博物馆；博物院
mushroom|n. 蘑菇
music|n. 音乐；乐曲
musical|adj. 音乐的；爱好音乐的 n. 音乐片
musician|n. 音乐家；乐师
mustard|n. 芥末；芥子粉
mutton|n. 羊肉
my|pron. 我的
myself|pron. 我自己
mysterious|adj. 神秘的
nail|n. 钉；钉子
name|n. 名字；姓名；名称 v. 命名；名叫
narrow|adj. 狭窄的
nation|n. 国家；民族
national|adj. 国家的；全国性的；民族的
nationality|n. 国籍
nationwide|adv. 全国范围内的；全国性的
native|adj. 本地的；母语的
natural|adj. 自然的
nature|n. 自然；性质；种类
navy|n. 海军
near|adj. 近的 adv. 附近；邻近 prep. 在……附近；靠近
nearby|adj. 附近的
nearly|adv. 将近；几乎
neat|adj. 整洁的；灵巧的
necessary|adj. 必需的；必要的
neck|n. 颈；脖子
necklace|n. 项链
necktie|n. 领带；领花
need|n. 需要；需求 aux./v. 需要；必须
needle|n. 针
negative|adj. 消极的；否定的
neglect|v. 忽视
negotiate|v. 谈判；协商
neighbor|n. 邻居；邻人
neighbour|n. 邻居；邻人
neighbourhood|n. 四邻；邻近地区 (美neighborhood)
neither|adj. （两者）都不；也不
nephew|n. 侄子；外甥
nervous|adj. 紧张的
nest|n. 巢；窝
net|n. 网
network|n. 网络
never|adv. 决不；从来没有
nevertheless|adv. 然而；不过
new|adj. 新的；新鲜的
news|n. 新闻；消息
newspaper|n. 报纸
next|adj. 最近的；紧挨着的；隔壁的；下一次 adv. 随后；然后；下一步 n. 下一个人（东西）
nice|adj. 令人愉快；好的漂亮的
niece|n. 侄女；甥女
night|n. 夜；夜间
night-club|n. 夜总会
nine|num. 九
nineteen|num. 十九
ninety|num. 九十
ninth|num. 第九
no|adv. 不；不是 adj. 没有；无；不
noble|adj. 高尚的；贵族的
nobody|n. 渺小人物 pron. 没有人；谁也不
nod|v. 点头
noise|n. 声音；噪声；喧闹声
noisily|adv. 喧闹地
noisy|adj. 喧闹的；嘈杂的
non-stop|adj./adv. 不停的；不断地
non-violent|adj. 非暴力的
none|pron. 无任何东西；无一人
noodle|n. 面条
noon|n. 中午；正午
nor|conj. 也不
normal|adj. 正常的
north|adj. 北的；朝北的；从北来的 adv. 向（在,从）北方 n. 北；北方；北部
northeast|n. 东北（部）
northern|adj. 北方的；北部的
northwards|adv. 向北
northwest|n. 西北
nose|n. 鼻
not|adv. 不；没
note|n. 便条；笔记；注释；钞票；纸币；音符；音调 v. 记下；记录；注意；留意
notebook|n. 笔记簿
nothing|n. 没有东西；没有什么 adv. 一点也不；并不
notice|v. 注意到 n. 通知
novel|n. 小说 adj. 新颖的
novelist|n. 小说家
now|adv. 现在
nowadays|adv. 当今；现在
nowhere|adv. 任何地方都不；无处
nuclear|adj. 核的
numb|adj. 麻木的；失去知觉的；迟钝的
number|n. 数；数字；号码；数量
numerous|adj. 许多的
nurse|n. 护士；保育员
nursery|n. 托儿所
nursing|n. (职业性的）保育；护理
nut|n. 坚果；果仁(胡桃,栗子等)
nutrition|n. 营养
nylon|n. 尼龙
o'clock|n. 点钟
obey|v. 服从；遵守
object|n. 物体；目标 v. 反对
obligation|n. 义务
observe|v. 观察；遵守
obtain|v. 获得
obvious|adj. 明显的
occasion|n. 场合；时机
occupation|n. 职业；工作
occupy|v. 占据；使忙碌
occur|v. 发生；想到（to）
ocean|n. 海洋
of|prep. ……的；属于
off|prep. 离开；脱离；（走）开
offence|n. 违法行为；犯罪
offend|v. 冒犯
offer|n./v. 提供；建议
office|n. 办公室
officer|n. 军官；公务员；官员；警察；警官
official|adj. 官方的 n. 官员
offshore|adj. 近海的
often|adv. 经常；常常
oh|int. 哦！啊！
oil|n. 油
oilfield|n. 油田
old|adj. 老的；旧的
omelette|n. 煎蛋卷；煎蛋饼
on|prep. 在…上（时）；关于 adv. （穿，放…）上；接通；进行下 去；（电灯）开
once|n./adv. 一次；一度；从前 conj. 一旦
one|pron. 一（个，只…） num. 一
oneself|pron. 自己；自身
onion|n. 洋葱；洋葱头
only|adj. 惟一的；仅有的 adv. 仅仅；只；才
onto|prep. 到…的上面
open|adj. 开着的；开的 v. 开；打开
opener|n. 开启工具；启子
opening|n. 开放；口子
opera|n. 歌剧
operate|v. 操作；做手术
operation|n. 手术；操作
operator|n. 接线员
opinion|n. 意见；看法
opponent|n. 对手
opportunity|n. 机会
oppose|v. 反对
opposite|n. 相反；对面 adj. 相反的；对面的
optimistic|adj. 乐观的
option|n. 选择
optional|adj. 可选择的；选修的
or|conj. 或；就是；否则
oral|adj. 口述的；口头上的
orange|n. 橘子；橙子；橘汁 adj. 橘色的；橙色的
orbit|n. （天体等的）运行轨道
order|v. 定购；定货；点菜
ordinary|adj. 普通的
organ|n. （人，动物）器官
organise|v. 组织
organiser|n. 组织者
organization|n. 组织；机构
organize|v. 组织
origin|n. 起源；出身
original|adj. 原来的；独创的
other|pron. 别人；别的东西 adj. 别的；另外的
otherwise|adv. 否则；另外
ought|v./aux. 应该；应当
our|pron. 我们的
ours|pron. 我们的
ourselves|pron. 我们自己
out|adv. 出外；在外；向外；熄
outcome|n. 结果
outdoors|adv. 在户外；在野外
outer|adj. 外部的；外面的
outgoing|adj. 爱交际的；外向的
outing|n. 郊游；远足
outline|n. 概述；略述
output|n. 产量；输出量
outside|n. 外面 adv. 在外面；向外面 prep. 在…外面
outspoken|adj. 直率；坦诚
outstanding|adj. 杰出的
outward|adv. 向外的；外出的
oval|n./adj. 椭圆；椭圆形的
over|prep. 在…上方；越过；遍及 adv. 翻倒；遍布；越过；结束
overcoat|n. 大衣
overcome|v. 克服
overhead|adj. 在头顶上；架空的
overlook|v. 忽视；俯瞰
overweight|adj. 太胖的；超重的
owe|v. 欠；归功于
own|adj. 自己的 v. 拥有；所有
owner|n. 物主；所有人
ownership|n. 所有制
oxygen|n. 氧；氧气
pace|n. 步伐；速度
pack|n. 包；捆；（猎犬、野兽的）一群 v. (为运输或储存而)打包
package|n. （尤指包装好或密封的容器）一包；一袋；一盒
packet|n. 小包裹；袋
paddle|n. 桨状物；蹼
page|n. 页；页码
pain|n. 疼痛；疼
painful|adj. 使痛的；使痛苦的
paint|n. 油漆 v. 油漆；粉刷；绘画
painter|n. 绘画者；（油）画家
painting|n. 油画；水彩画
pair|n. 一双；一对
palace|n. 宫；宫殿
pale|adj. 苍白的；灰白的
pan|n. 平底锅
pancake|n. 薄煎饼
panda|n. 熊猫
panic|n./v. 恐慌
paper|n. 纸；报纸
paperwork|n. 日常文书工作
paragraph|n. （文章的）段落
parallel|n. 极其相似的人；纬线
parcel|n. 包裹
pardon|n. 原谅；宽恕；对不起
parent|n. 父(母)；双亲
park|v. 停放（汽车）
parking|n. 停车
parrot|n. 鹦鹉
part|n. 部分；成分；角色；部件；零件 adj. 局部的；部分的 v. 分离；分开；分割
part-time|adj./adv. 兼职的；部分时间的（地）
participate|v. 参加（in）
particular|adj. 特别的；特定的
partly|adv. 部分地；在一定程度上
partner|n. 伙伴
party|n. 聚会；晚会；党派
pass|v. 传；递；经过；通过
passage|n. 段落；通道
passenger|n. 乘客；旅客
passer-by|n. 过客；过路人
passion|n. 激情；热爱
passive|adj. 被动的
passport|n. 护照
past|adv. 过 n. 过去；昔日；往事 prep. 过…；走过某处
patent|n. 专利权；专利证书
path|n. 小道；小径
patience|n. 耐心
patient|adj. 耐心的 n. 病人
pattern|n. 模式；图案
pause|n./v. 中止；暂停；停止
pea|n. 豌豆
peace|n. 和平
peaceful|adj. 和平的；安宁的
peach|n. 桃子
pear|n. 梨子；梨树
peasant|n. 农民；佃农
peculiar|adj. 奇怪的；特有的
pedestrian|n. 步行者；行人
pen|n. 钢笔；笔
pen-friend|n. 笔友
pencil|n. 铅笔
pencil-box|n. 铅笔盒
pension|n. 养老金
people|n. 人；人们；人民
pepper|n. 胡椒粉
per|prep. 每；每一
percent|n. 百分之……
percentage|n. 百分率
perfect|adj. 完美的；极好的
perform|v. 表演；执行
performance|n. 演出；表演
performer|n. 表演者；执行者
perfume|n. 香水
perhaps|adv. 可能；或
period|n. 时期；时代
permanent|adj. 永久的
permission|n. 允许；许可；同意
permit|v. 允许 n. 许可证
persist|v. 坚持
person|n. 人
personal|adj. 个人的；私人的
personality|n. 个性
personally|adv. 就自己而言
personnel|n. 全体人员；职员
perspective|n. 观点；视角
persuade|v. 说服
pest|n. 害虫
pet|n. 宠物；爱畜
petrol|n. 石油
phenomenon|n. 现象
phone-booth|n. 公用电话间
photograph|n. 照片
photographer|n. 摄影师
phrase|n. 短语；习惯用语
physical|adj. 身体的；物理的
physician|n. (有行医执照的)医生
physicist|n. 物理学家
physics|n. 物理（学）
pianist|n. 钢琴家
piano|n. 钢琴
pick|v. 拾起；采集；挑选
picnic|n./v. 野餐
picture|n. 图片；画片；照片
pie|n. 甜馅饼
piece|n. 一块（片，张，件…）
pig|n. 猪
pile|n. 堆
pill|n. 药丸；药片
pillow|n. 枕头
pilot|n. 飞行员
pin|n. 别针 v. 别住；钉住
pine|n. 松树
pineapple|n. 菠萝
ping-pong|n. 乒乓球
pink|adj. 粉红色的
pint|n. （液量单位）品脱
pioneer|n. 先驱
pipe|n. 管子；输送管
pity|n. 怜悯；同情
place|n. 地方；处所 v. 放置；安置；安排
plain|adj. 家常的；普通的
plan|n./v. 计划；打算
plane|n. 飞机
planet|n. 行星
plant|v. 种植；播种 n. 植物
plastic|adj. 塑料的
plate|n. 板；片；牌；盘子；盆子
platform|n. 讲台；(车站的)月台
play|v. 玩；打（球）；游戏；播放 n. 玩耍；戏剧
player|n. 比赛者；选手
playground|n. 操场；运动场
playmate|n. 玩伴
playroom|n. 游戏室
pleasant|adj. 令人愉快的；舒适的
please|v. 请；使人高兴；使人满意
pleased|adj. 高兴的
pleasure|n. 高兴；愉快
plenty|n. 大量；充足
plug|n. 塞子 v. （用塞子）把…塞住
plus|prep. 加；加上
pocket|n. （衣服的）口袋
poem|n. 诗
poet|n. 诗人
point|v. 指；指向 n. 点；分数
poison|n. 毒药
poisonous|adj. 有毒的；致命的
pole|n. 杆；电线杆
police|n. 警察；警务人员
policeman|n. 警察；巡警policewoman ( -women) n. 女警察
policy|n. 政策
polish|v. 擦亮 n. 擦光剂；亮光剂
polite|adj. 礼貌的
political|adj. 政治的
politician|n. 政治家
politics|n. 政治
pollute|v. 污染
pollution|n. 污染
pond|n. 池塘
pool|n. 水塘；水池
poor|adj. 贫穷；可怜；不好的；差的
popcorn|n. 爆米花
popular|adj. 受欢迎的；流行的
population|n. 人口
pork|n. 猪肉
porridge|n. 稀饭；粥
port|n. 港口；码头
portable|adj. 手提的；便携式的
porter|n. （火车站或旅馆处的）搬运工
portion|n. 部分；一份
position|n. 位置
positive|adj. 积极的；肯定的
possess|v. 拥有
possession|n. 所有；拥有；财产；所有物
possible|adj. 可能的
possibly|adv. 可能地；也许
post|n. 邮政；邮寄；邮件 v. 投寄；邮寄
postage|n. 邮费
postbox|n. 邮箱
postcard|n. 明信片
postcode|n. （英）邮政编码
poster|n. (贴在公共场所的大型)招贴；广告(画)
postman|n. 邮递员
postpone|v. 推迟；延期
pot|n. 锅；壶；瓶；罐
potato|n. 土豆；马铃薯
potential|adj. 潜在的 n. 潜力
pound|n. 磅；英镑
pour|v. 倾泻；不断流出
poverty|n. 贫穷
powder|n. 粉；粉末
power|n. 力；动力；电力
powerful|adj. 效力大的；强有力的；强大的
practical|adj. 实际的；实用的
practice|n. 练习
prairie|n. 大草原
praise|v./n. 赞扬
pray|v. 祈祷；祈求
prayer|n. 祈祷
precious|adj. 珍贵的
precise|adj. 准确；精确的；确切的
predict|v. 预测
prefer|v. 更喜欢
preference|n. 选择；趋向
pregnant|adj. 怀孕的
prejudice|n. 偏见
premier|n. 首相；总理
preparation|n. 准备
prepare|v. 准备
prescription|n. 处方；药方
present|adj. 现在的；出席的 n. 礼物 v. 呈现
presentation|n. 演示；演出
preserve|v. 保护；保存
president|n. 总统；主席
press|v. 压；按 n. 新闻界；出版社
pressure|n. 压力
pretend|v. 假装
pretty|adj. 漂亮的；俊俏的
prevent|v. 阻止；预防
preview|v. 预习；试演；预展
previous|adj. 先前的
price|n. 价格；价钱
pride|n. 自豪；骄傲
primary|adj. 主要的；初级的
primitive|adj. 原始的；远古的
principle|n. 原则；原理
print|v. 印刷
printer|n. 打印机
printing|n. 印刷；印刷术
priority|n. 优先；优先事项
prison|n. 监狱
prisoner|n. 囚犯
privacy|n. 隐私
private|adj. 私人的
prize|n. 奖赏；奖品
probable|adj. 很可能；很有希望的
probably|adv. 很可能；大概
problem|n. 问题；难题
procedure|n. 程序；步骤
process|n. 过程 v. 加工
produce|v. 生产；产生
product|n. 产品；制品
production|n. 生产；制造
profession|n. 职业
professor|n. 教授
profit|n. 利润 v. 获益
programme|n. 节目；项目 (美program)
progress|n./v. 进步；进展
prohibit|v. 禁止
project|n. 项目；工程
promise|v./n. 承诺
promote|v. 促进；提升；推销
prompt|adj. 迅速的 v. 促使
pronounce|v. 发音
pronunciation|n. 发音
proper|adj. 适当的
properly|adv. 适当地
property|n. 财产；性质
proportion|n. 比例
propose|v. 提议；求婚
protect|v. 保护
protection|n. 保护
protest|v./n. 抗议
proud|adj. 骄傲的；自豪的
prove|v. 证明；证明是
provide|v. 提供
province|n. 省
psychology|n. 心理学；心理
pub|n. 酒店；酒吧
public|adj. 公共；公众的 n. 公众
publicly|adv. 当众；公开地
publish|v. 出版；发表
pulse|n. 脉搏；（光、能量、波等的）脉动；搏动
punctual|adj. 准时的
punctuate|v. 加标点
punctuation|n. 标点符号
punish|v. 惩罚
punishment|n. 惩罚
pupil|n. （小）学生
purchase|v./n. 购买
pure|adj. 纯的；不掺杂的
purpose|n. 目的；意图
purse|n. 钱包
pursue|v. 追求；继续
push|n./v. 推
put|v. 放；摆
puzzle|n. 谜 v. 使困惑
puzzled|adj. 迷惑的；困惑的
pyramid|n. 角锥形；金字塔
quake|n./v. 震动；颤抖
qualification|n. 资格；学历
qualify|v. 使有资格
quality|n. 质量；品质
quantity|n. 数量
quarrel|v./n. 争吵
quarter|n. 四分之一；一刻钟
queen|n. 皇后；女王
question|v. 询问 n. 问题
questionnaire|n. 调查表；问卷
queue|n. 行列；长队
quick|adj. 快；敏捷的；急剧的 adv. 快地；敏捷地；急剧地
quiet|adj. 安静的；寂静的
quilt|n. 被子；被状物
quit|v. 离任；离校；戒掉
quite|adv. 完全；十分
quiz|n. 测验；小型考试
quote|v. 引用；报价
rabbit|n. 兔；家兔
race|n. 种族；民族 v. （速度）竞赛；比赛 n. 赛跑；竞赛
racial|adj. 种族的
radiation|n. 放射；放射物
radio|n. 无线电；收音机
radioactive|adj. 放射性的
radium|n. 镭
rag|n. 破布；抹布
rail|n. 铁路
railway|n. 铁路；铁道
rain|n. 雨；雨水 v. 下雨
rainbow|n. 虹；彩虹
raincoat|n. 雨衣
rainfall|n. 一场雨；降雨量
rainy|adj. 下雨的；多雨的
raise|v. 使升高；饲养
random|adj. 随意；未经事先考虑的
range|n. 范围 v. 变动
rank|n. 等级 v. 排名
rapid|adj. 快的；迅速的
rare|adj. 稀有的；罕见的
rat|n. 老鼠
rate|n. 比率；速度 v. 评价
rather|adv. 相当；宁可
raw|adj. 生的；未煮过的；未加工的
ray|n. 光辉；光线
razor|n. 剃须刀
reach|v. 到达；伸手(脚)够到
react|v. 反应
read|v. 读；朗读
reading|n. 阅读；朗读
ready|adj. 准备好的
real|adj. 真实的；确实的
realise|v. 认识到；实现
reality|n. 现实
realize|v. 意识到；实现
really|adv. 真正地；到底；确实
reason|v. 评理；劝说 n. 理由；原因
reasonable|adj. 合理的
rebuild|v. 重建
receipt|n. 收据
receive|v. 收到
receiver|n. 电话听筒
recent|adj. 最近的
reception|n. 接待
receptionist|n. 接待员
recipe|n. 烹饪法；食谱
recite|v. 背诵
recognise|v. 认出
recognize|v. 认出；承认
recommend|v. 推荐；建议
record|v. 录制；记录
recorder|n. 录音机
recover|v. 恢复；康复
recreation|n. 娱乐；消遣
rectangle|n./adj. 长方形；长方形的
recycle|v. 回收利用
red|n. 红色 adj. 红色的
redirect|v. 使改变；使转移
reduce|v. 减少
refer|v. 提到；参考（to）
referee|n. 裁判；仲裁；调解员
reference|n. 提到；涉及；谈及；查询
reflect|v. 反映；反射；反思
reform|v./n. 改革
refresh|v. 使恢复精力；提醒
refreshments|n. 点心；便餐；(会议后的)简单茶点招待
refrigerator|n. 冰箱
refusal|n. 拒绝
refuse|v. 拒绝
regard|v. 认为；看待（as）
regardless|adj. 不顾；不加理会
regards|n. 问候；致意
region|n. 地区
register|n. 登记簿；花名册；注册员 v. 登记；注册
regret|v./n. 后悔；遗憾
regular|adj. 定期的；规则的
regulation|n. 规则；规章
reject|v. 拒绝；拒收
relate|v. 有关；讲述
relation|n. 关系；亲属
relationship|n. 关系
relative|n. 亲属；亲戚
relax|v. 放松
relay|n. 接力；接替人；中转 v. 接替；补充；转运
release|v. 释放；发布
relevant|adj. 相关的
reliable|adj. 可靠的
relief|n. 轻松；解脱；缓和；救济
relieve|v. 缓解；减轻
religion|n. 宗教
religious|adj. 宗教的
rely|v. 依靠；信赖（on）
remain|v. 保持；剩下
remark|n./v. 评论；谈论
remarkable|adj. 非凡的；显著的
remember|v. 记得；想起
remind|v. 提醒；使想起
remote|adj. 偏远的；偏僻的
remove|v. 移除；去掉
rent|v. 租 n. 租金
repair|v./n. 修理
repairs|n. 修理工作
repeat|v. 重说；重做
replace|v. 代替；更换
reply|n. 回答；答复
report|n./v. 报道；报告
reporter|n. 记者；新闻通讯员
represent|v. 代表；表现
representative|n. 代表；典型人物
republic|n. 共和国
reputation|n. 名声；名誉
request|v./n. 请求
require|v. 需要；要求
requirement|n. 需要；要求；必要的条件
rescue|v./n. 营救
research|n./v. 研究
resemble|v. （不用进行时）像；看起来像
reservation|n. 预定
reserve|v. 预订；保留
resident|n. 居民
resign|v. 辞职
resist|v. 抵抗；忍住
resource|n. 资源
respect|v./n. 尊敬；方面
respond|v. 回应；回答
responsibility|n. 责任
rest|n. 休息；剩余的部分；其余的人（物） v. 休息；歇息
restaurant|n. 饭馆；饭店
restore|v. 恢复；修复
restrict|v. 限制
restriction|n. 限制；约束
result|n. 结果 v. 导致（in）
retell|v. 重讲；重复；复述
retire|v. 退休
return|v. 归还
reuse|v. 重新使用；循环使用
reveal|v. 揭示；透露
review|v./n. 复习；评论
reviewer|n. 评论者；书评家
revise|v. 修改；复习
revision|n. 复习；温习
revolution|n. 革命；变革
reward|n. 奖赏 v. 奖励
rewind|v. 回转（磁带等）
rewrite|v. 重写
rhythm|n. 节奏
rice|n. 稻米；米饭
rich|adj. 富裕的；有钱的
rid|v. 使摆脱
riddle|n. 谜(语)
ridiculous|adj. 荒谬的；愚蠢的
right|n. 权利 adj. 对；正确的 adv. 正确地；恰恰；完全地 adj. 右；右边的
right-handed|adj. 惯用右手的
right-wing|n. 右翼
rigid|adj. 死板的；僵硬的；固执的
ring-road|n. 环形公路
ripe|adj. 成熟的；熟的
ripen|v. 成熟
risk|n. 风险 v. 冒险
river|n. 江；河；水道；巨流
road|n. 路；道路
roast|v. 烤（肉）
rob|v. 抢夺；抢劫
robot|n. 机器人
rock|n. 岩石；大石头 v. 摇；摇晃
rocket|n. 火箭
role|n. 角色；作用
roll|v. 滚动；打滚 n. 面包圈；小圆面包；卷状物
roller|n. 滚筒；辊
romantic|adj. 浪漫的
roof|n. 屋顶；顶部
room|n. 房间；室；空间；地方
rooster|n. (美)公鸡
root|n. 根；根源；起源
rope|n. 绳；索
rose|n. 玫瑰花
rot|v. 烂；腐败
rough|adj. 粗糙的；粗略的
round|adv. 转过来 prep. 环绕一周；围着 adj. 圆的；球形的
roundabout|adj./n. 绕道的；不直接的；转盘路
routine|n. 常规 adj. 日常的
row|n. （一）排；（一）行 v. 划船
royal|adj. 皇家的；王室的；国王的；女王的
rubber|n. 橡胶；合成橡胶
rubbish|n. 垃圾；废物
rude|adj. 无理的；粗鲁的
rugby|n. （英）橄榄球
ruin|v. （使）毁坏；（使） 毁灭 n. 废墟；遗迹
rule|n. 规则；规定 v. 统治；支配
ruler|n. 统治者；直尺
runner|n. 赛跑者；操作者；滑行装置
running|n. 跑步
rural|adj. 农村的
rush|v. 冲；奔跑
sacred|adj. 害怕；恐惧；担心
sacrifice|v./n. 牺牲
sad|adj. （使人）悲伤的
sadness|n. 悲哀；忧伤
safe|adj. 安全的 n. 保险柜
safety|n. 安全；保险
sail|n. 航行 v. 航行；开航
sailing|n. 航海
sailor|n. 水手；海员
salad|n. 色拉（西餐中的一种菜）
salary|n. 薪金；薪水
sale|n. 卖；出售
salesgirl|n. 女售货员
salesman|n. 男售货员
saleswoman|n. 女售货员
salt|n. 盐
salty|adj. 盐的；咸的；含盐的
salute|v./n. 敬礼
same|n. 同样的事a同样的；同一
sand|n. 沙；沙子
sandwich|n. 三明治（夹心面包片）
satellite|n. 卫星
satisfaction|n. 满意
satisfy|v. 使满意；满足
sauce|n. 酱汁；调味汁
saucer|n. 茶碟；茶托；小圆盘
sausage|n. 香肠；腊肠
savage|n. 野蛮人；未开化的人
save|v. 救；挽救；节省
saying|n. 说；俗话；谚语
scan|v. 略读；浏览；扫描
scar|n. 伤疤；伤痕
scare|v. 使害怕；使恐惧
scarf|n. 领巾；围巾
scene|n. （戏剧、电影等的）一场；场景；布景
scenery|n. 风景
sceptical|adj. 怀疑的
schedule|n. 日程表 v. 安排
scheme|n. 计划；方案
scholar|n. 学者
scholarship|n. 奖学金
school|n. 学校
school-leaver|n. (英)学校毕业生
schoolbag|n. 书包
schoolmate|n. 同校同学
science|n. 科学；自然科学
scientific|adj. 科学的
scientist|n. 科学家
scissors|n. 剪刀；剪子
scold|v. 责骂
score|n./v. 得分；分数
scores|n. 许多；很多
scream|n. 尖叫
screen|n. 幕；荧光屏
sculpture|n. 雕塑（术）；雕刻（术）；雕刻作品；雕像
sea|n. 海；海洋
seagull|n. 海鸥
seal|n. 海豹
seaman|n. 水手；海员
search|n./v. 搜寻；搜查
seashell|n. 海贝
seaside|n. 海滨
season|n. 季；季节
seat|n. 座位；座
seaweed|n. 海草；海藻；海带
second|n. 秒 num. 第二 adj. 第二的
secondhand|n. 二手货；旧货
secret|n. 秘密；内情
secretary|n. 秘书；书记
section|n. 部分；章节
secure|adj. 安全的 v. 获得
security|n. 安全；平安
see-saw|n. 跷跷板（游戏）
seed|n. 种子
seek|v. 寻求；寻找
seem|v. 似乎；好像
seize|v. 抓住(时机等)
seldom|adv. 很少；不常
select|v. 选择
self|n. 自己；自我；自身
self-service|n. 自助；自我服务的
selfish|adj. 自私的
semicircle|n. 半圆
senior|adj. 年长的；资深的；高年级的 n. 上级；长辈；高年级生
sense|n. 感觉；意识
sensitive|adj. 敏感的
sentence|n. 句子
separate|adj. 分开的 v. 分离
separately|adv. 单独地；各自地
separation|n. 分离；隔离
series|n. 系列
serious|adj. 严肃的；严重的
servant|n. 仆人；佣人
serve|v. 招待（顾客等）；服务
service|n. 服务
service-charge|n. 服务费；小费
session|n. 一场；一节；一段时间
settle|v. 定居；解决
settlement|n. 新拓居地；（美）部落；村落
settler|n. 移居者；开拓者
seven|num. 七
seventeen|num. 十七
seventh|num. 第七
seventy|num. 七十
several|pron. 几个；数个 adj. 若干
severe|adj. 严重的；严厉的
sew|v. 缝；缝制；缝补；缝纫
sex|n. 性；性别
shabby|adj. 破旧；破烂；衣衫褴褛的
shade|n. 阴凉处；树荫处
shadow|n. 影子；阴影
shallow|adj. 浅的；不深的；肤浅的
shame|n. 遗憾的事；羞愧
shape|n. 形状；外形 v. 使成型；制造；塑造
share|v. 分享；共同使用
shark|n. 鲨鱼
sharp|adj. 锋利的；尖的
sharpen|v. （使）变锐利；削尖
sharpener|n. 削尖用的器具
shave|v. 刮（脸，胡子）
shaver|n. 电动剃须刀
she|pron. 她
sheep|n. （绵）羊；羊皮；驯服者
sheet|n. 成幅的薄片；薄板
shelter|n. 庇护所 v. 庇护
shift|v./n. 转移；轮班
shine|v. 发光；照耀；杰出；擦亮
ship|n. 船；轮船 v. 用船装运
shock|v. 使震惊
shoe|n. 鞋
shoot|n. 射击；开枪；开炮；射击声；子弹
shooting|n. 射击
shop|v. 买东西 n. 商店；车间
shopkeeper|n. 店主；零售商人
shopping|n. 买东西
shore|n. 滨；岸
short|adj. 短的；矮的
shortcoming|n. 缺点；短处
shortly|adv. 不久
shorts|n. 短裤；运动短裤
shortwave|n. 短波
should|v. mod. 应当；应该；会 /v.aux. 会；应该（shall的过去时态）
shoulder|n. 肩膀；(道路的)路肩
shout|n./v. 喊；高声呼喊
show|n. 展示；展览（会）；演出show
shower|n. 阵雨；淋浴
shrink|v. 缩小；收缩；减少
shy|adj. 害羞的
sick|adj. 有病的；患病的
sickness|n. 疾病；（想）呕吐
side|n. 边；旁边；面；侧面
sideway|n. 人行道 n. 岔路；旁路
sideways|adv. 斜向一边的
sigh|v. 叹息；叹气
sight|n. 情景；风景；视力
sightseeing|n. 游览；观光
sign|n. 符号；标记
signal|n. 信号
signature|n. 签名
significance|n. 重要性；意义
significant|adj. 重要的；显著的
silence|n. 安静；沉默
silent|adj. 无声的；无对话的
silk|n. （蚕）丝；丝织品
silly|adj. 傻的；愚蠢的
silver|n. 银
similar|adj. 相似的
simple|adj. 简单的；简易的
simple-minded|adj. 纯朴；头脑简单
simplify|v. 简化
simply|adv. 简单地；(加强语气)的确
since|adv. 从那时以来 conj. 从…以来；…以后；由于 prep. 从…以来
sincere|adj. 真诚的
sincerely|adv. 真诚地
singer|n. 歌唱家；歌手
single|adj. 单一的；单个的
sink|n. 洗涤槽；污水槽
sir|n. 先生；阁下
sister|n. 姐；妹
sister-in-law|n. 嫂；弟媳
situation|n. 情况；处境
six|num. 六
sixteen|num. 十六
sixteenth|num. 第十六
sixth|num. 第六
sixty|num. 六十
size|n. 尺寸；大小
skate|v. 溜冰；滑冰
skateboard|n. 冰鞋；滑板
ski|n./v. 滑雪板；滑雪
skill|n. 技能
skilled|adj. 熟练的；有技能的
skillful|adj. 熟练；精湛的；灵巧的
skillfully|adv. 精湛地；巧妙地
skin|n. 皮；皮肤；兽皮
skip|v. 蹦蹦跳跳；跳绳
skirt|n. 女裙
sky|n. 天；天空
skyscraper|n. 摩天楼
slave|n. 奴隶
slavery|n. 奴隶制度
sleep|n. 睡觉
sleepy|adj. 想睡的；困倦的；瞌睡的
sleeve|n. 袖子；袖套
slice|n. 片；切面（薄）片
slide|n. 幻灯片；滑道 v. 滑行；滑动
slight|adj. 轻微的
slim|adj. 苗条的；纤细的
slip|n. 片；条；纸片；纸条
slow|adv. 慢慢地；缓慢地
small|adj. 小的；少的
smart|adj. 灵巧的；伶俐的；（人、服装等）时髦的；帅的
smell|v. 嗅；闻到；发气味 n. 气味
smelly|adj. 有臭味的；发出臭味的
smile|n./v. 微笑
smog|n. 烟雾
smoke|n. 烟 v. 冒烟；吸烟
smoke-free|adj. 非吸烟的；无烟的
smoker|n. 吸烟者
smoking|n. 吸烟；抽烟；冒烟
smooth|adj. 光滑的；顺利的
snack|n. 小吃
snake|n. 蛇 v. 蛇般爬行；蜿蜒行进
snatch|v. 夺；夺得；夺走
sneaker|n. 轻便运动鞋（美）
sneeze|v. 打喷嚏
sniff|v. 抽鼻子（哭,患感冒时）
snow|n. 雪 v. 下雪
snowball|n. 雪球
snowman|n. 雪人
snowy|adj. 雪(白)的；下雪的；多(积)雪的
so|adv. 如此；这么；非常；同样 conj. 因此；所以
so-so|adj. 一般；不怎么样；凑合
soap|n. 肥皂
sob|n./v. 抽泣；啜泣
soccer|n. 英式足球
social|adj. 社会的；社交的
socialism|n. 社会主义
socialist|adj. 社会主义的
society|n. 社会
sock|n. 短袜
socket|n. （电源）插座
sofa|n. （长）沙发
soft|adj. 软的；柔和的
softball|n. 垒球
softdrink|n. (不含酒精)清凉饮料
software|n. 软件
soil|n. 土壤；土地
solar|adj. 太阳的
soldier|n. 士兵；战士
solid|adj. 结实的；固体的 n. 固体
solution|n. 解决办法；溶液
solve|v. 解决
some|adj. 一些；若干；有些；某一 pron. 若干；一些
somebody|pron. 某人；有人；有名气的人
someone|pron. 某一个人
something|pron. 某事；某物
sometimes|adv. 有时
somewhere|adv. 在某处
son|n. 儿子
song|n. 歌唱；歌曲
soon|adv. 不久；很快；一会儿
sorrow|n. 悲伤；悲痛
sorry|adj. 对不起；抱歉；难过的
sort|v. 把…分类；拣选 n. 种类；类别
soul|n. 灵魂；心灵；气魄
sound|v. 听起来；发出声音 n. 声音
soup|n. 汤
sour|adj. 酸的；馊的
source|n. 来源
south|adj. 南(方)的；向南的；从南来的 adv. 在南方；向南方；自南方 n. 南；南方；南风；南部
southeast|n. 东南
southern|adj. 南部的；南方的
southwest|n. 西南
souvenirs|n. 旅游纪念品；纪念物
sow|v. 播种
space|n. 空间
spaceship|n. 宇宙飞船
spade|n. 铲子；纸牌中的黑桃
spaghetti|n. 意大利式面条
spare|adj. 空闲的；备用的 v. 抽出（时间）
sparrow|n. 麻雀；雀型鸟类
speaker|n. 演讲人；演说家
spear|n. 矛；枪；梭镖
special|adj. 特别的；专门的
specialist|n. （医学）专家；专科医生；专家；专业人员
species|n. 物种
specific|adj. 具体的；特定的
speech|n. 演讲
speed|n. 速度 v. （使）加速
spell|v. 拼写
spelling|n. 拼写；拼读
spin|v./n. 纺；（使）快速旋转；旋转；旋转运动
spirit|n. 精神；心灵
spiritual|adj. 精神的；心灵的
spit|v. 吐唾沫；吐痰
splendid|adj. 壮丽的；极好的
split|v. 撕开；切开
spoken|adj. 口语的
spokesman|n. 发言人
sponsor|n. 赞助商 v. 赞助
spoon|n. 匙；调羹
spoonful|n. 一匙（的量）
spot|n. 斑点；污点；场所；地点 v. 沾上污渍；弄脏
spread|v. 延伸；展开
spring|n. 春天；春季 n. 泉水；泉
spy|n. 密探；间谍 v. 侦探；刺探
square|n. 广场 adj. 平方的；方形的；宽而结实的（体格，肩膀）
squeeze|n. 挤压；捏；塞
squid|n. 鱿鱼
squirrel|n. 松鼠
stable|adj. 稳定的
stadium|n. （露天）体育场
staff|n. 全体职工（雇员）
stage|n. 舞台；阶段
stain|n. 污点；污渍；染色剂
stainless|adj. 无污点的
stair|n. 楼梯
stamp|n. 邮票
stand|n. 站；立；停止；立场；地位；台；坛；摊
standard|n./adj. 标准（的）
star|n. 星；恒星
stare|v. 盯；凝视
start|v. 开始；着手；出发
starvation|n. 饥饿；饿死
starve|v. 饿死
state|n. 状态；情形；国家；（美国的）州
statement|n. 声明；陈诉；说法
statesman|n. 政治家
station|n. 站；所；车站；电台
statistics|n. 统计数字；统计资料；统计学
statue|n. 法令；法规；章程
status|n. 地位；状态
stay|n./v. 停留；逗留；呆
steady|adj. 稳定的
steak|n. 牛排；肉排；鱼排
steam|n. 汽；水蒸气
steel|n. 钢；钢铁
steep|adj. 险峻的；陡峭的
step|n. 脚步；台阶；梯级 v. 走；跨步
step-mother|n. 继母
steward|n. (火车、飞机、轮船等)男服务员；男乘务员
stewardess|n. 女乘务员；空中小姐
still|adj. 不动的；平静的 adv. 仍然；还
stimulate|v. 刺激；激发
stocking|n. 长统袜
stomach|n. 胃；胃部
stomachache|n. 胃疼
stone|n. 石头；石料
stop|n. 停；（停车）站 v. 停；停止；阻止
stopwatch|n. 记秒表；跑表
storage|n. 贮藏；储存
store|n. 商店 v. 储藏；存储
storm|n. 风暴；暴（风）雨
story|n. 故事；小说
stout|adj. 肥壮的；厚实牢固的
stove|n. （供烹饪用的 ）火炉；煤炉；电炉
straight|adj. 一直的；直的 adv. 一直地；直地
strait|n. 海峡
strange|adj. 奇怪；奇特的；陌生的
stranger|n. 陌生人；外人
strategy|n. 策略；战略
straw|n. 稻草
strawberry|n. 草莓
stream|n. 小河；溪流
street|n. 街；街道
strength|n. 力量；长处
strengthen|v. 加强；增强
stress|n. 压力；重音 v. 强调
strict|adj. 严格的；严密的
strike|v. 擦（打）火；侵袭
string|n. 细绳；线；带
strong|adj. 强(壮)的；坚固的；强烈的；坚强的
structure|n. 结构
struggle|v./n. 挣扎；奋斗
stubborn|adj. 固执的；倔强的
student|n. 学生
studio|n. 工作室；演播室
study|v. 学习；研究 n. 书房
stupid|adj. 愚蠢的；笨的
style|n. 方式；作风；款式
subject|adj. 隶属的；受支配的；易受…的；在…条件下 v. 使隶属；使服从；使受到 n. 题目；主题；学科；主语；主体
subjective|adj. 主观的
submit|v. 提交；服从
subscribe|v. 订阅；订购（报刊等）
substance|n. 物质；实质
substitute|v. 代替；取代
subtraction|n. （算数中的）减
succeed|v. 成功（in）
success|n. 成功
successful|adj. 成功的；有成就的
such|adv. 那么 pron. （泛指）人；事物 adj. 这样的；那样的
suck|v. 吸吮
sudden|adj. 突然的
suffer|v. 遭受；受苦（from）
suffering|n. 痛苦；苦难
sufficient|adj. 足够的
sugar|n. 糖
suggest|v. 建议；表明
suggestion|n. 建议
suit|v. 适合 n. 一套（衣服）
suitable|adj. 合适的
suitcase|n. (旅行用)小提箱；衣箱
suite|n. 套间；组曲
summary|n. 摘要；总结
summer|n. 夏天；夏季
sun|n. 太阳；阳光
sunburnt|adj. 晒黑的
sunglasses|n. 太阳眼镜；墨镜
sunlight|n. 日光；阳光
sunny|adj. 晴朗的；阳光充足的
sunrise|n. 黎明；拂晓
sunset|n. 日落(时分)
sunshine|n. 阳光
super|adj. 顶好的；超级的
superb|adj. 卓越的；质量极高的
superior|adj. 更胜一筹的 n. 上级；上司
superman|n. 超人
supermarket|n. 超级市场
supper|n. 晚餐；晚饭
supply|v./n. 供应
support|v./n. 支持
suppose|v. 假定；认为
supreme|adj. 至高无上的；最高的
sure|adj. 确信；肯定 adv. (口语)的确；一定；当然
surface|n. 表面
surgeon|n. 外科医生
surplus|n. 过剩；剩余
surprise|v. 使惊奇；使诧异 n. 惊奇；诧异
surround|v. 包围；环绕
surrounding|adj. 周围的
survey|n./v. 调查
survival|n. 存活；幸存
survive|v. 幸存；挺过
suspect|v. 怀疑 n. 嫌疑人
suspension|n. 暂令停职；推迟；延期
sustain|v. 维持；支撑
swallow|v. 吞下；咽下
swap|v. 交换（东西）
sweat|n. 汗；汗水
sweater|n. 厚运动衫；毛衣 
sweet|n. 甜食；蜜饯；甜点；糖果；芳香 adj. 甜的；新鲜的；可爱的；亲切的
swift|adj. 快的；迅速的
swim|n. 游泳；游
swimming|n. 游泳
swing|v. 挥舞；摆动 n. 秋千
sword|n. 剑；刀
symbol|n. 象征；符号
sympathy|n. 同情
symphony|n. 交响乐
symptom|n. 症状
system|n. 系统；体系
systematic|adj. 系统的；有条理的
table|n. 桌子；表格
tablet|n. 药片
tail|n. (动物的)尾巴
tailor|n. 裁缝
tale|n. 故事；传说
talent|n. 天赋；人才
talk|n./v. 谈话；讲话；演讲；交谈
tall|adj. 高的
tank|n. 储水容量；坦克
tanker|n. 油船
tap|n. (自来水煤气等的)龙头
tape|n. 磁带；录音带
target|n. 目标；靶子
task|n. 任务
taste|n. 品尝；尝味；味道 v. 品尝；尝味
tasteless|adj. 无滋味的
tasty|adj. 味道好的
tax|n. 税；税款
taxi|n. 出租汽车
taxpayer|n. 纳税人
tea|n. 茶；茶叶 
teacher|n. 教师；教员
team|n. 队；组
teamwork|n. 合作；协同工作
teapot|n. 茶壶
tear|n. 眼泪 v. 扯破；撕开
tease|v. 取笑；戏弄；寻开心
technical|adj. 技术的；工艺的
technique|n. 技术；技巧
technology|n. 技术；科技
teenager|n. （13～19岁的）青少年；十几岁的少年
telegram|n. 电报
telegraph|v. (拍) 电报
telephone|v. 打电话 n. 电话
telephone-booth|n. 公用电话间
telescope|n. 望远镜
television|n. 电视
temperature|n. 温度
temple|n. 庙宇；寺院
temporary|adj. 暂时的
temptation|n. 引诱；诱惑
ten|num. 十
tend|v. 倾向于；照料
tendency|n. 倾向；偏好；性情
tennis|n. 网球
tense|adj. 心烦意乱的；紧张的
tension|n. 紧张
tent|n. 帐篷
tentative|adj. 不确定的；踌躇的
term|n. 学期；术语；条款；项
terminal|adj. (火车汽车飞机)终点站
terrible|adj. 可怕的；糟糕的
terrify|v. 使人感到恐怖
terror|n. 恐惧；惊恐
test|v./n. 测试；考查；试验
text|n. 文本；课文
textbook|n. 课本；教科书
than|conj. 比
thank|v. 感谢；致谢；道谢 n. 感谢；谢意
thankful|adj. 感谢的；感激的
that|adj./pron. 那；那个 conj. 那；那个（引导宾语从句等）ad. 那么；那样
the|art. 这（那）个；这（那）些（用于特定人或物，序数词，最高级，专有名词，世上独一 无二事物前）
theater|n. 剧场；戏院
theatre|n. 剧场；戏院
theft|n. 盗窃案
their|pron. 他(她,它)们的
theirs|pron. 他（她,它）们的
them|pron. 他/她/它们（宾格）
theme|n. 主题
themselves|pron. 他/她/它们自己
then|adv. 当时；那时；然后；那么
theoretical|adj. 理论的
theory|n. 理论
there|int. 那！你瞧（表示引起注意） n. 那里；那儿 adv. 在那里；往那里；（作引导词）表”存在"
therefore|adv. 因此；所以
thermos|n. 热水瓶
these|adj./pron. 这些
they|pron. 他（她）们；它们
thick|adj. 厚的
thin|adj. 薄的；瘦的；稀的
thing|n. 东西；物品；用品；事情；事件
thinking|n. 思索；见解；想法
third|num. 第三
thirst|n. 渴；口渴
thirsty|adj. 渴
thirteen|num. 十三
thirty|num. 三十
this|adj./pron. 这；这个
thorough|adj. 彻底的
those|adj./pron. 那些
though|conj. 虽然；可是
thought|n. 思考；思想；念头
thousand|num. 千
thread|n. 线
threat|n. 威胁
three|num. 三
thriller|n. 惊险小说
throat|n. 喉咙
through|prep. 穿（通）过；从始至终 adv. 穿(通)过；自始至终；全部
throughout|prep. 遍及；贯穿
thunder|n./v. 雷声；打雷
thunderstorm|n. 雷电交加暴风雨
thus|adv. 这样；因而
tick|v. 作记号
ticket|n. 票；卷
tidy|adj. 整洁的；干净的 v. 弄整洁；弄干净
tie|v. （用绳，线）系；拴；扎 n. 领带；绳子；结；关系
tiger|n. 老虎
tight|adj. 紧的
till|conj./prep. 直到；直到…为止
time|n. 时间；时期；钟点；次；回 v. 测定…的时间；记录…的时间
timetable|n. （火车、公共汽车等）时间表；（学校）课表
tin|n. （英）罐头；听头
tiny|adj. tinier；tiniest adj. 极小的；微小的
tip|n./v. 顶端；尖端；告诫；提示 (给)小费
tire|n. 轮胎
tired|adj. 疲劳的；累的
tiresome|adj. 令人厌倦的
tissue|n. （人，动植物的）组织；纸巾
title|n. 标题；题目
to|prep. （动词不定式符号，无词义）；（表示接受动作的人或物）给；对；向；到；在…之前
tobacco|n. 烟草；烟叶
today|adv./n. 今天；现在；当前
together|adv. 一起；共同
toilet|n. 厕所
tolerate|v. 容忍
tomato|n. 西红柿；番茄
tomb|n. 坟墓
tomorrow|adv./n. 明天
ton|n. （重量单位）吨
tongue|n. 舌；舌头
tonight|adv./n. 今晚；今夜
too|adv. 也；还；又；太；过分；很；非常
tool|n. 工具；器具
toothache|n. 牙痛
toothbrush|n. 牙刷
toothpaste|n. 牙膏
top|n. 顶部；（物体的）上面
topic|n. 题目；话题
tortoise|n. 乌龟
total|adj. 总数的；总括的；完全的；全然的 n. 合计；总计 v. 合计为
totally|adv. 总合地；完全地
touch|v. 触摸；接触
tough|adj. 艰难的；坚强的
tour|n. 参观；观光；旅行
tourism|n. 旅游业；观光
tournament|n. 锦标赛；联赛
toward|prep. 向；朝；对于
towel|n. 毛巾
tower|n. 塔
town|n. 城镇；城
toy|n. 玩具；玩物
track|n. 轨道；田径
tractor|n. 拖拉机
trade|n. 贸易 v. 用…进行交换
tradition|n. 传统
traditional|adj. 传统的；风俗的
traffic|n. 交通
train|n. 火车 v. 培训；训练
trainer|n. 训练人；教练
training|n. 培训
tram|n. 有轨电车
transform|v. 改变；转变
translate|v. 翻译
translation|n. 翻译；译文
translator|n. 翻译家；译者
transparent|adj. 透明的；清澈的
transport|n./v. 运输
trap|n. 陷阱 v. 使陷入困境
travel|n./v. 旅行
traveler|n. 旅行者
treasure|n. 财宝 v. 珍惜
treat|v. 对待；治疗；请客
treatment|n. 治疗；疗法
tree|n. 树
tremble|v. 颤抖
tremendous|adj. 巨大的
trend|n. 趋势
trial|n. 审判；试验；试用
triangle|n./adj. 三角形；三角形的
trick|n. 诡计；把戏
trip|n. 旅行；旅程
trolley-bus|n. 无轨电车
troop|n. 部队
trooping|v. 成群结队地走
trouble|v. 使苦恼；使忧虑；使麻烦 n. 问题；疾病；烦恼；麻烦
troublesome|adj. 令人烦恼；讨厌
trousers|n. 裤子；长裤
truck|n. 卡车；运货车；车皮 v. 装车；用货车运
true|adj. 真的；真实的；忠诚的
truly|adv. 真正地；真实地
trunk|n. 树干；大箱子
trust|v. 相信；信任；信赖
truth|n. 真理；事实；真相；实际
try|v. 试；试图；努力
tube|n. 管；管状物
tune|n. 曲调；曲子
turkey|n. 火鸡
turn|v. 旋转；翻转；转变；转弯 n. 轮流；（轮流的）顺序
tutor|n. 家庭教师；私人教师；导师
twelfth|num. 第十二
twelve|num. 十二
twenty|num. 二十
twenty-first|num. 第二十一
twenty-one|num. 二十一
twice|adv. 两次；两倍
twin|n. 双胞胎之一
two|num. 二
type|v. 打字
typewriter|n. 打字机
typhoon|n. 台风
typical|adj. 典型的
typist|n. 打字员
tyre|n. 轮胎
ugly|adj. 丑陋的；难看的
ultimate|adj. 最终的
umbrella|n. 雨伞
unable|adj. 不能的；不能胜任的
unbearable|adj. 难耐得；无法接受的
unbelievable|adj. 难以置信的
uncertain|adj. 不确定的
uncle|n. 叔；伯；舅；姑夫；姨父
uncomfortable|adj. 令人不舒服的
unconditional|adj. 无条件；绝对的
unconscious|adj. 昏迷；不省人事的
under|adv./prep. 在…下面；向…下面
underground|adj. 地下的 n. 地铁
underline|v. 在…下划线
understanding|n. 领会；理解
underwear|n. 内衣
undivided|adj. 没分开的；专一的；专心的
undo|v. 解开；松开
unemployment|n. 失业；失业状态
unfair|adj. 不公平的；不公正的
unfit|adj. 不合宜的；不相宜的
unfold|v. 展开；打开
unfortunate|adj. 不幸的
unfortunately|adv. 不幸地
unhappy|adj. 不高兴的；伤心的
unhealthy|adj. 不健康的；不卫生的
uniform|n. 制服
unimportant|adj. 不重要的；无意义
union|n. 联合；联盟；工会
unique|adj. 独特的；唯一的
unit|n. 单元；单位
unite|v. 联合；团结
universal|adj. 普遍的；全体的
universe|n. 宇宙
university|n. 大学
unknown|adj. 不知道的
unless|conj. 如果不；除非
unlike|prep. 不像；和…不同
unmarried|adj. 未婚的；独身的
unpleasant|adj. 使人不愉快的
unrest|n. 不安；骚动
unsafe|adj. 不安全的；危险的
unsuccessful|adj. 不成功；失败的
until|prep./conj. 直到…为止
untrue|adj. 不真实的；假的
unusual|adj. 不平常的；异常的
unwilling|adj. 不愿意的；勉强的
up|adv. 向上；在上方；起来；在…以上 adj. 上面的；向上的；上行的 n. 上升；上坡；上行；繁荣 v. 举起；拿起；提高 prep. 向(高处)；向(在)……上(面)游
upon|prep. 在……上面
upper|adj. 较高的；较上的
upset|adj. 心烦的；苦恼的
upstairs|adv. 在楼上；到楼上
upward|adv. 向上；往上
urban|adj. 城市的
urge|v. 敦促；力劝
urgent|adj. 紧急的
use|n./v. 利用；使用；应用
used|adj. 用过的；旧的；二手的
useful|adj. 有用的；有益的
useless|adj. 无用的
user|n. 使用者；用户
usual|adj. 通常的；平常的
usually|adv. 通常；经常
vacant|adj. 空缺的；未被占用的
vacation|n. 假期；休假
vague|adj. 含糊的；紧迫的
vain|n. 自负的；自视过高的；徒劳的；无效的
valid|adj. 有效的；合理的；有根据的
valley|n. 山谷；溪谷
valuable|adj. 宝贵的；贵重的
value|n. 价值；益处
vanilla|n. 香草
variety|n. 多样；种类
various|adj. 各种各样的
vase|n. （花）瓶；瓶饰
vast|adj. 巨大的；广阔的
veal|n. （食用）小牛肉
vegetable|n. 蔬菜
vehicle|n. 车辆；交通工具
version|n. 变体；变种；改写本
vertical|adj. 垂直的；纵向的
vest|n. 背心；内衣
via|prep. 经过（某地）；通过
vice|n. 罪行；不道德行为
victim|n. 受害者
victory|n. 胜利
video|n. 录像；视频
videophone|n. 可视电话
view|n. 观点；景色 v. 看待
viewer|n. 观看者
village|n. 村庄；乡村
villager|n. 村民
vinegar|n. 醋
violate|v. 违反（法律、协议等）；侵犯
violence|n. 暴力行为
violent|adj. 暴力的；猛烈的
violin|n. 小提琴
violinist|n. 提琴家；提琴手
virtual|adj. 虚拟的；实际上的
virtue|n. 美德；正直的品行；德行
virus|n. 病毒
visa|n. 签证；背签
visible|adj. 可见的
vision|n. 视力；远见
visit|n./v. 参观；访问；拜访
visitor|n. 访问者；参观者
visual|adj. 视力的；视觉的
vital|adj. 至关重要的
vivid|adj. 生动；逼真的；鲜明的
vocabulary|n. 词汇；词汇表
voice|n. 说话声；语态
volcano|n. 火山
volleyball|n. 排球
voluntary|adj. 自愿的；主动的
volunteer|n. 志愿者 v. 自愿
vote|v./n. 投票
voyage|n. 航行；旅行
wag|v. 摇动；摆动
wage|n. 工资；工钱；报酬
waist|n. 腰；腰部；腰围
wait|v. 等；等候
waiter|n. （餐厅）男服务员
waiting-room|n. 候诊室；候车室
waitress|n. 女服务员
walk|n./v. 步行；散步
walkman|n. 随身听
wall|n. 墙
wallet|n. (放钱,证件等的)皮夹
walnut|n. 核桃；胡桃
wander|v. 漫游；游荡；漫步；流浪
want|v. 想；想要；需要；必要
war|v. 警告；预先通知
ward|n. 保卫；看护；病房；收容所
warehouse|n. 仓库；货栈
warm|adj. 暖和的；温暖的；热情的
warm-hearted|adj. 热心的
warmth|n. 暖和；温暖
warning|n. 警报
wash|n. 洗(涤)冲洗；洗剂；泼溅；洗的衣服 v. 洗(涤)；冲洗；流过；弄湿
washing-machine|n. 洗衣机
washroom|n. 盥洗室
waste|n./v. 浪费
watch|v. 观看；注视；当心；注意 n. 手表；表
water|n. 水 v. 浇水
watermelon|n. 西瓜
wave|n. （热、光、声等的）波；波浪 v. 挥手；挥动；波动
wax|n. 蜡
way|n. 路；路线；方式；手段
wayside|adj. 路边的
we|pron. 我们
weak|adj. 差的；弱的；淡的
weakness|n. 软弱
wealth|n. 财富
wealthy|adj. 富的
weapon|n. 武器
weather|n. 天气
weatherman|n. 气象员；预报天气的人
web|n. 网；网状物
website|n. 网络
wedding|n. 婚礼；结婚
weed|n. 杂草；野草
week|n. 星期；周
weekday|n. 平日
weekend|n. 周末
weekly|adj. 每周的
weep|v. 哭泣；流泪
weigh|v. 称…的重量；重（若干）
weight|n. 重；重量
welcome|int. n./v. 欢迎 adj. 受欢迎的
welfare|n. 福利
well-known|adj. 出名；众所周知的
west|adj. (在)西；向西；从西来的 adv. 在西方；向西方 n. 西部；西方
western|adj. 西方的；西部的
westerner|n. 西方人
westwards|adv. 向西
wet|adj. 湿的；潮的；多雨的
whale|n. 鲸
what|pron. 什么；怎么样 adj. 多么；何等；什么
whatever|conj./pron. 无论什么；不管什么
wheat|n. 小麦
wheel|n. 轮；机轮
when|conj. 当…的时候 adv. 什么时候；何时
whenever|conj. 每当；无论何时
where|adv. 在哪里；往哪里
wherever|conj. 无论在哪里
whether|conj. 是否
which|pron. 那(哪)一个；那(哪)一些 adj. 这(哪)个；这(哪)些；无论哪个(些)
whichever|pron. 无论哪个；无论哪些
while|conj. 在…的时候；和…同时 n. 一会儿；一段时间
whisper|v. 低语；私下说
whistle|n. 口哨；口哨声
white|adj. 白色的 n. 白色
who|pron. 谁
whole|adj. 整个的
whom|pron. (who的宾格 )
whose|pron. 谁的
wide|adj. 宽阔的
widespread|adj. 分布广的；普遍的
wife|n. 妻子
wild|adj. 未开发的；荒凉的；野生的；野的
wildlife|n. 野生动物
will|n. 意志；遗嘱
willing|adj. 乐意的；愿意的
willingly|adv. 乐意地
willingness|n. 意愿；愿望
wind|n. 风 
windbreaker|n. 风衣；防风(皮)夹克
window|n. 窗户；计算机的窗
windy|adj. 有风的；多风的
wine|n. 酒
wing|n. 机翼；翅膀
winner|n. 获胜者
winter|n. 冬天；冬季
wipe|v. 擦；擦净；擦干
wire|n. 电线
wisdom|n. 智慧
wise|adj. 聪明；英明的；有见识的
wish|n. 愿望；祝愿 v. 希望；想要；祝愿
with|prep. 关于；带有；以；和；用；有
withdraw|v. 撤回；取（钱）
within|prep. 在……里面
without|prep. 没有
witness|v. 目睹 n. 目击者
wonder|v. 对…疑惑；感到惊奇；想知道 n. 惊讶；惊叹；奇迹
wonderful|adj. 美妙的；精彩的；了不起的；太好了
woo|n. 羊毛；羊绒
wood|n. 木头；木材；树木；森林
wooden|adj. 木制的
woollen|adj. 羊毛的；羊毛制的
word|n. 词；单词；话
work|n. 工作；劳动；事情 v. 工作；(机器、器官等)运转；活动
workday|n. 工作日
worker|n. 工人；工作者
workforce|n. 劳动力
workmate|n. 同事；工友
workplace|n. 工作场所；车间
works|n. 著作；作品
world|n. 世界
world-famous|adj. 世界闻名的
worldwide|adj. 遍及全球的；世界范围的
worm|n. 软体虫；蠕虫(尤指蚯蚓)
worn|adj. 用坏；用旧的；疲惫的
worried|adj. 担心的；烦恼的
worry|n./v. 烦恼；担忧；发怒；困扰
worse|adj. (bad的比较级)更坏的
worst|adj. (bad的最高级)最坏的
worth|adj. 值得的 n. 价值
worthless|adj. 没有价值；没有用的
worthwhile|adj. 值得做的
worthy|adj. 值得的
wound|n. 伤口 v. 使受伤
wounded|adj. 受伤的
wrestle|v. 摔跤
wrinkle|n. 皱纹
wrist|n. 手腕；腕关节
writing|n. 书写；写
wrong|adj. 错误；不正常；有毛病的
yard|n. 码；院子；场地
yawn|v. 打哈欠
year|n. 年
yell|v. 叫喊；吼叫
yellow|adj. 黄色的
yes|adv. 是；好；同意
yesterday|n./adv. 昨天
yet|adv. 尚；还；仍然
yoghurt|n. 酸奶
you|pron. 你；你们
young|adj. 年轻的
your|pron. 你的；你们的
yours|pron. 你的；你们的
yourself|pron. 你自己
yourselves|pron. 你们自己
youth|n. 青春；青年
yummy|adj. 很好吃的
zebra|n. 斑马
zero|n./num. 零；零度；零点
zip|v./n. 拉开(或扣上)……的拉链；拉链
zipper|n. 拉链
zone|n. 区域；范围
zoo|n. 动物园
zoom|v. 快速移动；迅速前往；猛涨
"""

EXAMPLES = {
    "abandon": "They had to abandon the car and walk the rest of the way.",
    "ability": "She has the ability to explain hard ideas simply.",
    "accept": "He accepted the invitation to speak at the meeting.",
    "achieve": "You can achieve your goal if you keep working at it.",
    "adapt": "It took her a few weeks to adapt to the new school.",
    "advantage": "Living near the library is a great advantage.",
    "affect": "Lack of sleep can affect your memory.",
    "afford": "We can't afford to waste any more time.",
    "anxious": "He was anxious about the result of the exam.",
    "apply": "She applied for a place in the summer camp.",
    "appreciate": "I really appreciate your help with my project.",
    "approach": "We need a new approach to this problem.",
    "attend": "More than 500 students attended the lecture.",
    "attitude": "A positive attitude makes a big difference.",
    "available": "Are there any tickets still available?",
    "avoid": "Try to avoid making the same mistake twice.",
    "benefit": "Regular exercise benefits both body and mind.",
    "challenge": "Learning a new language is a real challenge.",
    "communicate": "Good friends communicate openly with each other.",
    "concentrate": "Turn off your phone so you can concentrate.",
    "confident": "She felt confident before the speech contest.",
    "consider": "Have you considered studying abroad?",
    "contribute": "Everyone contributed to the success of the event.",
    "convince": "He tried to convince me that he was right.",
    "cope": "How do you cope with stress before exams?",
    "courage": "It took courage to tell the truth.",
    "deal": "We must learn how to deal with difficulties.",
    "decline": "The number of wild tigers has declined sharply.",
    "deserve": "After all that hard work, you deserve a rest.",
    "determine": "Your effort will determine your result.",
    "devote": "He devoted his life to protecting wildlife.",
    "efficient": "Planning ahead makes your study more efficient.",
    "encourage": "My teacher encouraged me to join the debate team.",
    "ensure": "Please ensure that all the windows are closed.",
    "essential": "Water is essential for all living things.",
    "explore": "The students explored the old town on foot.",
    "focus": "Focus on one task at a time.",
    "gain": "She gained a lot of experience from the job.",
    "ignore": "Don't ignore the warning signs.",
    "impress": "His speech impressed everyone in the hall.",
    "improve": "Reading every day can improve your English.",
    "inspire": "Her story inspired many young people.",
    "insist": "He insisted on paying for the meal.",
    "involve": "The project involves a lot of teamwork.",
    "maintain": "It is important to maintain a balanced diet.",
    "motivate": "What motivates you to study hard?",
    "obtain": "You need to obtain permission first.",
    "occur": "The accident occurred late at night.",
    "opportunity": "The trip was a great opportunity to practise English.",
    "overcome": "She overcame her fear of speaking in public.",
    "participate": "All students are encouraged to participate in the activity.",
    "persuade": "We persuaded him to give up smoking.",
    "prevent": "Wearing a helmet can prevent serious injuries.",
    "protect": "We must protect the environment for future generations.",
    "provide": "The school provides free lunch for students.",
    "recommend": "Can you recommend a good book for me?",
    "reduce": "We should reduce the use of plastic bags.",
    "regret": "I regret not studying harder last term.",
    "rely": "You can always rely on your family.",
    "remind": "This photo reminds me of my childhood.",
    "require": "The job requires good communication skills.",
    "respond": "She responded to my email quickly.",
    "responsibility": "Taking care of pets is a big responsibility.",
    "seek": "When they get stuck, they seek help from their teacher.",
    "solve": "Working together, we solved the problem.",
    "suffer": "Many people suffer from lack of sleep.",
    "suggest": "I suggest that we start early tomorrow.",
    "survive": "Only a few plants can survive in the desert.",
    "tradition": "Eating dumplings is a Spring Festival tradition.",
    "valuable": "Time is more valuable than money.",
    "volunteer": "He volunteers at the local hospital every weekend.",
    "worth": "The museum is well worth a visit.",
}
