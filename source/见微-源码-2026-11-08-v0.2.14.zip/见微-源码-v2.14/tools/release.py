"""可复现本地发行：隔离构建、冻结版自测、打包（不改桌面快捷方式）。"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import uuid
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent/"release-2.14-2026-11-08"
STAGE = OUT/"source-final"
TAG = "2026-11-08-v2.14"
SKIP = {"dist","build","tmp","__pycache__",".git",".venv",".claude",".codex",".agents"}


def eligible(path,base):
    rel = path.relative_to(base)
    return (not any(part in SKIP for part in rel.parts) and not path.is_symlink() and
            path.suffix.lower() not in (".pyc",".log",".spec",".pem",".key") and
            ".env" not in path.name.lower())


def fingerprint(base):
    digest = hashlib.sha256()
    for path in sorted((base/"app").rglob("*")):
        if path.is_file() and eligible(path,base):
            digest.update(path.relative_to(base).as_posix().encode())
            digest.update(path.read_bytes())
    digest.update((base/"build.py").read_bytes())
    return digest.hexdigest()


def safe_stage():
    target = STAGE.resolve()
    parent = ROOT.parent.resolve()
    if target==parent or not target.is_relative_to(parent) or target==ROOT.resolve():
        raise RuntimeError("拒绝在工作区外清理构建目录")
    return target


def environment(name):
    env = dict(os.environ)
    env.update(PYTHONIOENCODING="utf-8",QT_QPA_PLATFORM="offscreen",QT_QPA_FONTDIR=r"C:\Windows\Fonts",
               JIANWEI_HOME=str(OUT/name/"home"),LOCALAPPDATA=str(OUT/name/"local"),
               PYINSTALLER_CONFIG_DIR=str(OUT/"pyinstaller-cache"))
    return env


def build():
    OUT.mkdir(parents=True,exist_ok=True)
    target = safe_stage()
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(ROOT,target,ignore=lambda directory,names:[name for name in names if not eligible(Path(directory)/name,ROOT)])
    with (OUT/"build.log").open("w",encoding="utf-8") as log:
        result = subprocess.run([sys.executable,"-c","import build; raise SystemExit(build.build())"],cwd=target,
                    env=environment("build-data"),stdout=log,stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=="win32" else 0)
    if result.returncode:
        raise RuntimeError(f"构建失败 {result.returncode}，见 {OUT/'build.log'}")
    built_fingerprint = fingerprint(target)
    if built_fingerprint != fingerprint(ROOT):
        raise RuntimeError("源码在构建期间发生变化，需要重新构建")
    (OUT/"fingerprint.txt").write_text(built_fingerprint,encoding="ascii")
    (OUT/'frozen-verification.json').unlink(missing_ok=True)
    print("BUILD_OK",flush=True)


def smoke():
    exe = STAGE/"dist"/"Jianwei"/"Jianwei.exe"
    if not exe.is_file():
        raise RuntimeError("尚未构建")
    tested_fingerprint=(OUT/'fingerprint.txt').read_text(encoding='ascii')
    if fingerprint(ROOT)!=tested_fingerprint or fingerprint(STAGE)!=tested_fingerprint:
        raise RuntimeError('源码在构建后有变更，不能自测旧程序作为本轮结果')
    test_name = "frozen-test-"+uuid.uuid4().hex[:8]
    folder = OUT/test_name
    folder.mkdir(parents=True)
    with (folder/"process.log").open("w",encoding="utf-8") as log:
        result = subprocess.run([str(exe),"--self-test",str(folder/"results"),"--no-single"],cwd=exe.parent,
                    env=environment(test_name),stdout=log,stderr=subprocess.STDOUT,
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform=="win32" else 0)
    expected = {"design-result.txt":"OK","bench-ui-result.txt":"OK","pen-result.txt":"PEN_OK","clip-result.txt":"OK","work-transfer-result.txt":"OK",
                "interop-result.txt":"OK","lecture-result.txt":"LECTURE_OK","ppt-speed-result.txt":"OK", "figure-result.txt":"OK", "figure-live-result.txt":"OK", "figure-subject-result.txt":"OK", "figure-transfer-result.txt":"OK", "apparatus-result.txt":"OK", "extensions-result.txt":"OK", "realtime-result.txt":"OK","panels-result.txt":"OK","evening-result.txt":"OK"}
    checks = {}
    expected['compat-tools-result.txt']='OK'
    expected['chemical-result.txt']='OK'
    expected['vision-result.txt']='OK'
    expected.update({name+'-result.txt':'OK' for name in ('fidelity','backup','practice','models29','models29b','learning','stage6','traversal','bank','analysis')})
    for name,value in expected.items():
        path = folder/"results"/name
        checks[name] = path.read_text(encoding="utf-8").strip() if path.exists() else "MISSING"
    passed = result.returncode==0 and all(checks[k]==v for k,v in expected.items()) and fingerprint(ROOT)==tested_fingerprint and fingerprint(STAGE)==tested_fingerprint
    report = dict(returncode=result.returncode,checks=checks,passed=passed,folder=str(folder),fingerprint=tested_fingerprint)
    (OUT/"frozen-verification.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False),flush=True)
    if not passed:
        raise RuntimeError("冻结版自测未通过，见 frozen-verification.json 和 selftest.log")


def pack():
    if fingerprint(ROOT)!=(OUT/"fingerprint.txt").read_text(encoding="ascii") or fingerprint(STAGE)!=fingerprint(ROOT):
        raise RuntimeError("源码在构建后有变更，必须重新构建/自测")
    verification = json.loads((OUT/"frozen-verification.json").read_text(encoding="utf-8"))
    if not verification["passed"] or verification.get('fingerprint')!=fingerprint(ROOT):
        raise RuntimeError("冻结版自测未通过")
    products = []
    for kind,base,prefix in (("源码",ROOT,"见微-源码-v2.14"),("绿色版",STAGE/"dist"/"Jianwei","见微-绿色版-v2.14")):
        output = OUT/(f"见微-{kind}-{TAG}.zip")
        with zipfile.ZipFile(output,"w",zipfile.ZIP_DEFLATED,compresslevel=6,strict_timestamps=False) as archive:
            for path in sorted(base.rglob("*")):
                if not path.is_file() or path.is_symlink():
                    continue
                if kind=="源码" and not eligible(path,base):
                    continue
                archive.write(path,str(Path(prefix)/path.relative_to(base)))
            if kind=="绿色版":
                for name in ("README-使用说明.md","RELEASE-2.6.md","REALTIME-2.6.1.md","RELEASE-2.7.md","RELEASE-2.8.md","RELEASE-2.9.md","RELEASE-2.10.md","RELEASE-2.11.md","RELEASE-2.12.md","RELEASE-2.12.1.md","RELEASE-2.12.2.md","真机验收清单.md"):
                    archive.write(ROOT/name,str(Path(prefix)/name))
                archive.write(ROOT/'RELEASE-2.13.md',str(Path(prefix)/'RELEASE-2.13.md'))
                archive.write(ROOT/'RELEASE-2.13.1.md',str(Path(prefix)/'RELEASE-2.13.1.md'))
                archive.write(ROOT/'RELEASE-2.14.md',str(Path(prefix)/'RELEASE-2.14.md'))
        with zipfile.ZipFile(output) as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError("压缩包损坏："+bad)
        sha = hashlib.sha256(output.read_bytes()).hexdigest()
        products.append(dict(path=str(output),bytes=output.stat().st_size,sha256=sha))
    (OUT/"packages.json").write_text(json.dumps(products,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(products,ensure_ascii=False),flush=True)


def main():
    sys.path.insert(0,str(ROOT/"app"))
    from native.kit import test_runtime
    test_runtime.configure()  # 子进程继承静默错误模式，构建/自测不产生错误报告弹窗。
    parser = argparse.ArgumentParser()
    parser.add_argument("action",choices=("build","smoke","pack"))
    action = parser.parse_args().action
    {"build":build,"smoke":smoke,"pack":pack}[action]()


if __name__=="__main__":
    main()
