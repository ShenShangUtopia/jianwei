"""课件库页面：导入 Word / PPT（按钮或拖进来），点开全屏播放。"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QScrollArea, QVBoxLayout, QWidget

from ..design import tokens
from ..design.tokens import RADIUS, T
from ..design.widgets import qss
from . import library
from .convert import FILTER, PLAIN_ENGINES, SUPPORTED, ConvertError


class ImportWorker(QThread):
    status = Signal(str)
    done = Signal(object)
    failed = Signal(str, str)

    def __init__(self, path):
        super().__init__()
        self.path = path

    def run(self):
        try:
            self.done.emit(library.import_file(self.path, self.status.emit))
        except ConvertError as e:
            self.failed.emit(Path(self.path).name, str(e))
        except Exception as e:  # noqa: BLE001  什么原因都要告诉用户，不能让线程悄悄死掉
            self.failed.emit(Path(self.path).name, f"导入时出错：{e}")


class Card(QFrame):
    THUMB = QSize(264, 148)

    def __init__(self, meta, page):
        super().__init__()
        self.meta, self.page = meta, page
        self.setObjectName("lcard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedWidth(self.THUMB.width() + 20)
        v = QVBoxLayout(self)
        v.setContentsMargins(10, 10, 10, 9)
        v.setSpacing(6)
        th = QLabel()
        th.setObjectName("lthumb")
        th.setFixedSize(self.THUMB)
        th.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pm = QPixmap(str(library.folder(meta["id"]) / "thumb.png"))
        if not pm.isNull():
            th.setPixmap(pm.scaled(self.THUMB, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        v.addWidget(th)
        title = QLabel(meta.get("title", ""))
        title.setObjectName("ltitle")
        title.setToolTip(meta.get("src_name", ""))
        fm = title.fontMetrics()
        title.setText(fm.elidedText(meta.get("title", ""), Qt.TextElideMode.ElideRight, self.THUMB.width() - 8))
        v.addWidget(title)
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        kind = "演示" if meta.get("kind") == "slides" else "文档"
        unit = "张" if meta.get("kind") == "slides" else "页"
        sub = QLabel(f"{kind} · {meta.get('display_pages',meta.get('pages', 0))} {unit}")
        if meta.get("insert_pages"):
            sub.setText(sub.text()+f" · 含 {meta['insert_pages']} 插页")
        sub.setObjectName("lsub")
        if meta.get("steps"):
            sub.setText(sub.text() + " · 有动画")
        if meta.get("engine") in PLAIN_ENGINES:
            sub.setText(sub.text() + " · " + meta["engine"])
            sub.setToolTip("这台电脑没有可用的 Office / WPS：内置排版的版式可能和原文件有差异；旧版 .ppt / .doc 只能取到文字和图片，没有动画")
        h.addWidget(sub, 1)
        b = QPushButton("删除")
        b.setObjectName("ldel")
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(lambda: page.delete(meta))
        h.addWidget(b)
        v.addLayout(h)

    def mouseReleaseEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.page.play(self.meta)


class LecturePage(QWidget):
    def __init__(self,bus=None):
        super().__init__()
        self.clip_bus = bus
        self.setObjectName("lecturePage")
        self.setAcceptDrops(True)
        self.queue = []
        self.worker = None
        self.players = []
        self.batch_total = 0
        self.batch_done = 0
        self.failures = []
        self.current_path = None
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 22, 28, 18)
        v.setSpacing(12)
        top = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(3)
        ti = QLabel("课件")
        ti.setObjectName("lhead")
        col.addWidget(ti)
        sub = QLabel("导入 PPT、Word 全屏播放。放映时可以用笔勾画；框选一块后，可以带入黑板，或者上网查询。")
        sub.setObjectName("lsubhead")
        col.addWidget(sub)
        top.addLayout(col, 1)
        self.import_btn = QPushButton("导入课件")
        self.import_btn.setObjectName("pri")
        self.import_btn.setMinimumHeight(34)
        self.import_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.import_btn.clicked.connect(self.choose)
        top.addWidget(self.import_btn)
        v.addLayout(top)
        self.search = QLineEdit()
        self.search.setPlaceholderText("搜索课件名称或原文件名…")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.refresh)
        v.addWidget(self.search)
        actions = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.hide()
        actions.addWidget(self.progress, 1)
        self.stop_btn = QPushButton("取消等待项")
        self.stop_btn.setToolTip("当前文件会继续完成，尚未开始的文件从队列移除")
        self.stop_btn.clicked.connect(self.cancel_pending)
        self.stop_btn.hide()
        actions.addWidget(self.stop_btn)
        self.retry_btn = QPushButton("重试失败项")
        self.retry_btn.clicked.connect(self.retry_failed)
        self.retry_btn.hide()
        actions.addWidget(self.retry_btn)
        self.open_btn = QPushButton("打开刚导入的课件")
        self.open_btn.clicked.connect(lambda: self.play(self.last_meta))
        self.open_btn.hide()
        actions.addWidget(self.open_btn)
        v.addLayout(actions)
        self.status = QLabel("")
        self.status.setObjectName("lstatus")
        self.status.setWordWrap(True)
        self.status.hide()
        v.addWidget(self.status)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.inner = QWidget()
        self.inner.setObjectName("linner")
        self.grid = QGridLayout(self.inner)
        self.grid.setContentsMargins(0, 4, 0, 4)
        self.grid.setSpacing(16)
        self.grid.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.scroll.setWidget(self.inner)
        v.addWidget(self.scroll, 1)
        self.empty = QLabel("还没有课件\n点右上角「导入课件」，或者把 PPT、Word 文件拖到这里")
        self.empty.setObjectName("lempty")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        v.addWidget(self.empty, 1)
        self.cols = 0
        self.apply_theme()
        self.refresh()

    def apply_theme(self):
        t = T
        for player in self.players:
            player.pen_bar.apply_theme()
            player.board.pen_bar.apply_theme()
        self.setStyleSheet(qss() + f"""
QWidget#lecturePage, QWidget#linner {{ background:{t.bg}; }}
QLabel#lhead {{ color:{t.fg}; font-size:22px; font-weight:700; }}
QLabel#lsubhead {{ color:{t.muted}; font-size:12.5px; }}
QLabel#lstatus {{ color:{t.soft}; background:{t.raised}; border:1px solid {t.line}; border-left:3px solid {t.accent}; border-radius:3px; padding:8px 12px; font-size:12.5px; }}
QLabel#lempty {{ color:{t.muted}; font-size:14px; border:1px dashed {t.edge}; border-radius:{RADIUS['lg']}px; }}
QLineEdit {{ padding:7px 10px; }}
QFrame#lcard {{ background:{t.raised}; border:1px solid {t.line}; border-radius:{RADIUS['lg']}px; }}
QFrame#lcard:hover {{ border-color:{t.accent}; }}
QLabel#lthumb {{ background:{tokens.css(t.fg, 0.05)}; border-radius:{RADIUS['sm']}px; }}
QLabel#ltitle {{ color:{t.fg}; font-size:13.5px; font-weight:600; }}
QLabel#lsub {{ color:{t.muted}; font-size:12px; }}
QPushButton#ldel {{ background:transparent; color:{t.muted}; border:none; font-size:12px; padding:1px 5px; border-radius:3px; }}
QPushButton#ldel:hover {{ color:{t.bad}; background:{tokens.css(t.bad, .12)}; }}
QPushButton#ldel:pressed {{ margin-top:0; }}
""")

    # ---- 列表
    def refresh(self):
        while self.grid.count():
            w = self.grid.takeAt(0).widget()
            if w is not None:
                w.hide()
                w.deleteLater()
        items = library.all_lectures()
        query = self.search.text().strip().casefold()
        if query:
            items = [m for m in items if query in (m.get("title", "") + " " + m.get("src_name", "")).casefold()]
        self.empty.setText("没有找到匹配的课件，试试其他关键词" if query else "还没有课件\n点右上角「导入课件」，或者把 PPT、Word、PDF 文件拖到这里")
        self.empty.setVisible(not items)
        self.scroll.setVisible(bool(items))
        self.cols = max(1, (self.width() - 56) // (Card.THUMB.width() + 36)) if self.width() > 100 else 3
        for i, m in enumerate(items):
            self.grid.addWidget(Card(m, self), i // self.cols, i % self.cols)

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        c = max(1, (self.width() - 56) // (Card.THUMB.width() + 36))
        if c != self.cols:
            self.refresh()

    # ---- 导入
    def choose(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "导入课件", "", FILTER)
        self.import_paths(paths)

    def import_paths(self, paths):
        if self.worker is None and not self.queue:
            self.batch_total = self.batch_done = 0
            self.failures = []
            self.retry_btn.hide()
        known = {str(Path(p).resolve()).casefold() for p in self.queue}
        if self.current_path:
            known.add(str(Path(self.current_path).resolve()).casefold())
        rejected = []
        for path in paths:
            p = Path(path)
            key = str(p.resolve()).casefold()
            if not p.is_file() or p.suffix.lower() not in SUPPORTED:
                rejected.append(p.name)
            elif key not in known:
                known.add(key)
                self.queue.append(str(p))
                self.batch_total += 1
        if rejected:
            self.say("已跳过不支持或不存在的文件：" + "、".join(rejected))
        self.update_progress()
        self._next()

    def update_progress(self):
        self.progress.setRange(0, max(1, self.batch_total))
        self.progress.setValue(self.batch_done)
        self.progress.setFormat(f"已处理 {self.batch_done}/{self.batch_total} · 等待 {len(self.queue)}")
        self.progress.setVisible(self.batch_total > 0)
        self.stop_btn.setVisible(bool(self.queue))

    def cancel_pending(self):
        self.batch_total -= len(self.queue)
        self.queue.clear()
        self.update_progress()

    def retry_failed(self):
        paths = [p for p, _ in self.failures]
        self.import_paths(paths)

    def _next(self):
        if self.worker is not None or not self.queue:
            return
        path = self.queue.pop(0)
        self.current_path = path
        self.update_progress()
        self.import_btn.setText("继续添加课件")
        self.say(f"正在导入 {Path(path).name}…")
        self.worker = ImportWorker(path)
        self.worker.status.connect(lambda s, n=Path(path).name: self.say(f"{n}：{s}"))
        self.worker.done.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.finished.connect(self._finished)
        self.worker.start()

    def say(self, text, autohide=False):
        self.status.setText(text)
        self.status.show()
        if autohide:
            QTimer.singleShot(4000, lambda t=text: self.status.hide() if self.status.text() == t else None)

    def _done(self, meta):
        self.last_meta = meta
        self.open_btn.show()
        note = "已经导入过，直接用原来那份" if meta.get("existing") else f"导入完成（{meta.get('engine')}）"
        self.say(f"{meta.get('title')}：{note}", True)
        self.refresh()

    def _failed(self, name, why):
        self.failures.append((self.current_path, why))
        self.say(f"{name} 没有导入：{why}")

    def _finished(self):
        worker = self.worker
        self.worker = None
        if worker is not None:
            worker.deleteLater()
        self.current_path = None
        self.batch_done += 1
        self.update_progress()
        if not self.queue:
            self.import_btn.setText("导入课件")
            self.retry_btn.setVisible(bool(self.failures))
            self.retry_btn.setToolTip("\n".join(f"{Path(p).name}：{why}" for p, why in self.failures))
            self.say(f"本批处理完成：成功 {self.batch_done - len(self.failures)}，失败 {len(self.failures)}。" + ("可点「重试失败项」再次导入。" if self.failures else ""))
        self._next()

    def dragEnterEvent(self, e):  # noqa: N802
        if e.mimeData().hasUrls() and any(Path(u.toLocalFile()).suffix.lower() in SUPPORTED for u in e.mimeData().urls()):
            e.acceptProposedAction()

    def dropEvent(self, e):  # noqa: N802
        self.import_paths([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])
        e.acceptProposedAction()

    # ---- 操作
    def play(self, meta):
        from .player import open_player
        p = open_player(meta, self.window(),self.clip_bus)
        self.players.append(p)
        p.destroyed.connect(self._player_gone)
        return p

    def _player_gone(self,*_args):
        from shiboken6 import isValid
        self.players[:] = [p for p in self.players if isValid(p) and not p.closing]
        QTimer.singleShot(0,self,self.refresh)

    def delete(self, meta):
        ask = QMessageBox(QMessageBox.Icon.Question, "删除课件", f"删除「{meta.get('title')}」？\n这份课件里的笔迹和黑板也会一起删除，你电脑上的原文件不受影响。", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel, self)
        ask.setDefaultButton(QMessageBox.StandardButton.Cancel)
        if ask.exec() == QMessageBox.StandardButton.Yes:
            library.remove(meta["id"])
            self.refresh()

    def shutdown(self):
        for p in list(self.players):
            p.close()
        if self.worker is not None:
            self.worker.wait(2000)
