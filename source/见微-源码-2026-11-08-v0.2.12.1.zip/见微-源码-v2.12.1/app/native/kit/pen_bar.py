"""共享画笔工具条：一排图标键，课件、黑板、工作台共用；横/竖布局，四个持久样式预设。

on_dark=True 用在放映条和黑板上：这些地方底色永远是深的，不跟昼夜主题走。
"""
from __future__ import annotations

import copy

from PySide6.QtCore import QPointF, QRectF, QSignalBlocker, Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QColorDialog, QComboBox, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QMenu, QPushButton, QSlider, QVBoxLayout, QWidgetAction)

from ..design.icons import draw_icon
from ..design.tokens import RADIUS, T, qc
from ..design.widgets import draw_key
from .home import load_json, save_json

TOOLS = [("pointer","指针 V"),("pen","笔 P"),("marker","荧光笔 H"),("chalk","粉笔"),
         ("eraser","橡皮 E"),("lasso","套索"),("laser","激光笔 L"),
         ("line","直线"),("rect","矩形"),("ellipse","圆 / 椭圆"),("arrow","箭头"),("axes","坐标轴")]
SHAPES = ("line","rect","ellipse","arrow","axes")
DEFAULTS = [dict(tool="pen",color="#E5484D",width=3.5),dict(tool="pen",color="#2F6FED",width=2),
            dict(tool="marker",color="#FFD60A",width=3.5),dict(tool="chalk",color="#F4F1E8",width=4)]
SWATCHES = ["#E5484D","#F59E0B","#FFD60A","#16A34A","#0FA3A3","#2F6FED","#7C5CD6","#F4F1E8","#8A9791","#111418"]
WIDTHS = [("细",1.5),("中",3.5),("粗",6.0),("特粗",10.0)]
DARK = dict(fg="#DCE5E0",dim="#9DAFA7",hover="#22332E",line="#2E3F39",on="#C8402A",onfg="#FFFFFF",edge="#7E2616")


def _colors(on_dark):
    if on_dark:
        return DARK
    return dict(fg=T.fg,dim=T.soft,hover=T.hover,line=T.line2,on=T.accent,onfg=T.stage,edge=qc(T.accent).darker(140).name())


class _Key(QPushButton):
    """工具条上的一颗键：32×32，选中时填色，按下时下沉。"""
    SIZE = 32

    def __init__(self,bar,tip):
        super().__init__(bar)
        self.bar,self._hover = bar,False
        self.setFixedSize(self.SIZE,self.SIZE)
        self.setToolTip(tip)
        self.setFlat(True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self,e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self,e):  # noqa: N802
        self._hover = False
        self.update()

    def paint_base(self,p):
        c = _colors(self.bar.on_dark)
        r = QRectF(self.rect()).adjusted(1,1,-1,-1)
        if self.isChecked():
            draw_key(p,r,c["on"],RADIUS["sm"],edge=QColor(c["edge"]),sunk=self.isDown())
        elif self._hover or self.isDown():
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(c["hover"]))
            p.drawRoundedRect(r,RADIUS["sm"],RADIUS["sm"])
        return c


class ToolKey(_Key):
    def __init__(self,bar,icon,tip,tool=None,caret=False):
        super().__init__(bar,tip)
        self.icon,self.tool,self.caret = icon,tool,caret
        self.setCheckable(tool is not None or caret)

    def paintEvent(self,_e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        c = self.paint_base(p)
        on = self.isChecked()
        col = QColor(c["onfg"] if on else (c["fg"] if self._hover else c["dim"]))
        if not self.isEnabled():
            col.setAlphaF(.4)
        dy = 1 if self.isDown() else 0
        draw_icon(p,self.icon,QRectF(7,7+dy,18,18),col)
        if self.caret:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col)
            p.drawPolygon([QPointF(25,27),QPointF(28.5,27),QPointF(28.5,23.5)])
        p.end()


class ColorKey(_Key):
    def paintEvent(self,_e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        c = self.paint_base(p)
        p.setPen(QPen(QColor(c["line"]),1))
        p.setBrush(QColor(self.bar.target.color))
        p.drawEllipse(QRectF(8,8,16,16))
        p.end()


class WidthKey(_Key):
    def paintEvent(self,_e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        c = self.paint_base(p)
        d = max(2.5,min(16,self.bar.target.width_px*1.4))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(c["fg"]))
        p.drawEllipse(QRectF(16-d/2,16-d/2,d,d))
        p.end()


class Swatch(QPushButton):
    def __init__(self,color,fn):
        super().__init__()
        self.color = color
        self.setFixedSize(26,26)
        self.setFlat(True)
        self.setToolTip(color)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("background:transparent;border:none;")
        self.clicked.connect(lambda:fn(color))

    def paintEvent(self,_e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        p.setPen(QPen(qc(T.edge),1))
        p.setBrush(QColor(self.color))
        p.drawEllipse(QRectF(4,4,18,18))
        p.end()


def menu_style():
    return (f"QMenu{{background:{T.raised};color:{T.fg};border:1px solid {T.line2};padding:4px;font-size:12.5px;}}"
            f"QMenu::item{{padding:6px 24px 6px 12px;border-radius:3px;}}QMenu::item:selected{{background:{T.hover};}}"
            f"QMenu::item:disabled{{color:{T.faint};}}QMenu::separator{{height:1px;background:{T.line};margin:4px 6px;}}")


class PenBar(QFrame):
    def __init__(self, target, session, parent=None, vertical=False, board=False, on_dark=False):
        super().__init__(parent)
        self.target, self.session, self.board, self.on_dark = target, session, board, on_dark
        self.setObjectName("penBar")
        self.settings_error = ""
        layout = QVBoxLayout(self) if vertical else QHBoxLayout(self)
        self._vertical = vertical
        layout.setContentsMargins(3,3,3,3)
        layout.setSpacing(1)
        # 状态放在隐藏的下拉框和数值框里：其他模块和自测通过它们读写当前工具、笔宽
        self.tool_box = QComboBox(self)
        for key,label in TOOLS + ([] if board else [("select","截取 S")]):
            self.tool_box.addItem(label,"move" if board and key == "pointer" else key)
        self.tool_box.currentIndexChanged.connect(lambda i: self.set_tool(self.tool_box.itemData(i)))
        self.tool_box.hide()
        self.width_box = QDoubleSpinBox(self)
        self.width_box.setRange(.5,30)
        self.width_box.setSingleStep(.5)
        self.width_box.valueChanged.connect(lambda v: setattr(target,"width_px",v))
        self.width_box.hide()
        self.keys = {}
        labels = dict(TOOLS+[("select","框选截取 S")])
        for key in ("pointer","pen","marker","chalk","eraser","lasso","laser"):
            data = "move" if board and key == "pointer" else key
            tip = {"pointer":"指针 V" if not board else "移动 V","lasso":"套索：圈选后拖动移动，拖右下角缩放","chalk":"粉笔"}.get(key,labels[key])
            k = ToolKey(self,key,tip,data)
            k.clicked.connect(lambda _=False,d=data:self.set_tool(d))
            layout.addWidget(k)
            self.keys[data] = k
        self.shape_key = ToolKey(self,"shapes","形状：直线、矩形、圆、箭头、坐标轴",caret=True)
        self.shape_key.clicked.connect(self.open_shapes)
        layout.addWidget(self.shape_key)
        if not board:
            k = ToolKey(self,"select",labels["select"],"select")
            k.clicked.connect(lambda _=False:self.set_tool("select"))
            layout.addWidget(k)
            self.keys["select"] = k
        layout.addWidget(self._sep())
        self.color_btn = ColorKey(self,"画笔颜色")
        self.color_btn.clicked.connect(self.open_colors)
        layout.addWidget(self.color_btn)
        self.width_key = WidthKey(self,"笔宽；荧光笔自动加宽")
        self.width_key.clicked.connect(self.open_widths)
        layout.addWidget(self.width_key)
        layout.addWidget(self._sep())
        self.undo_key = ToolKey(self,"undo","撤销 Ctrl+Z")
        self.undo_key.clicked.connect(target.undo)
        layout.addWidget(self.undo_key)
        self.redo_key = ToolKey(self,"redo","重做 Ctrl+Y")
        self.redo_key.clicked.connect(target.redo)
        layout.addWidget(self.redo_key)
        self.more = ToolKey(self,"more","橡皮方式、形状吸附、套索操作与共享预设")
        self.more.clicked.connect(self.open_menu)
        layout.addWidget(self.more)
        self.apply_theme()
        self.reload_settings()
        self.sync()

    def _sep(self):
        s = QFrame(self)
        s.setObjectName("penSep")
        s.setFixedSize(24,1) if self._vertical else s.setFixedSize(1,20)
        return s

    def apply_theme(self):
        c = _colors(self.on_dark)
        if self.on_dark:
            self.setStyleSheet(f"QFrame#penBar{{background:transparent;border:none;}}QFrame#penSep{{background:{c['line']};margin:0 3px;}}")
        else:
            self.setStyleSheet(f"QFrame#penBar{{background:{T.raised};border:1px solid {T.line};border-radius:{RADIUS['md']}px;}}QFrame#penSep{{background:{T.line2};}}")
        self.update()

    def sync(self):
        tool = self.target.tool
        with QSignalBlocker(self.tool_box):
            self.tool_box.setCurrentIndex(self.tool_box.findData(tool))
        with QSignalBlocker(self.width_box):
            self.width_box.setValue(self.target.width_px)
        for data,key in self.keys.items():
            key.setChecked(data == tool)
        is_shape = tool in SHAPES
        self.shape_key.setChecked(is_shape)
        if is_shape:
            self.shape_key.icon = tool
        self.color_btn.update()
        self.width_key.update()
        self.update()

    def set_tool(self,tool):
        self.target.set_tool(tool)
        if hasattr(self.target,"activity"):
            self.target.activity.emit()
        self.sync()

    def set_color(self,color):
        self.target.color = color
        if self.target.tool in ("pointer","move","eraser","laser","lasso","select"):
            self.set_tool("pen")
        self.sync()

    def choose_color(self):
        color = QColorDialog.getColor(QColor(self.target.color),self,"画笔颜色")
        if color.isValid():
            self.set_color(color.name())

    def open_shapes(self):
        self.sync()   # 点开菜单不算切工具，复位键的选中态
        menu = QMenu(self)
        menu.setStyleSheet(menu_style())
        labels = dict(TOOLS)
        for key in SHAPES:
            menu.addAction(labels[key],lambda _=False,k=key:self.set_tool(k))
        menu.exec(self._below(self.shape_key))

    def _below(self,w):
        return w.mapToGlobal(w.rect().bottomLeft())

    def open_colors(self):
        menu = QMenu(self)
        menu.setStyleSheet(menu_style())
        box = QFrame()
        grid = QGridLayout(box)
        grid.setContentsMargins(6,6,6,4)
        grid.setSpacing(2)
        def pick(color):
            self.set_color(color)
            menu.close()
        for i,color in enumerate(SWATCHES):
            grid.addWidget(Swatch(color,pick),i//5,i%5)
        action = QWidgetAction(menu)
        action.setDefaultWidget(box)
        menu.addAction(action)
        menu.addSeparator()
        menu.addAction("其他颜色…",self.choose_color)
        menu.exec(self._below(self.color_btn))

    def open_widths(self):
        menu = QMenu(self)
        menu.setStyleSheet(menu_style())
        box = QFrame()
        row = QHBoxLayout(box)
        row.setContentsMargins(10,6,10,6)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(1,60)
        slider.setFixedWidth(130)
        slider.setValue(int(round(self.target.width_px*2)))
        value = QLabel(f"{self.target.width_px:g} px")
        value.setFixedWidth(44)
        def changed(v):
            self.width_box.setValue(v/2)
            value.setText(f"{v/2:g} px")
            self.width_key.update()
        slider.valueChanged.connect(changed)
        row.addWidget(slider)
        row.addWidget(value)
        action = QWidgetAction(menu)
        action.setDefaultWidget(box)
        menu.addAction(action)
        menu.addSeparator()
        for label,w in WIDTHS:
            menu.addAction(f"{label}  {w:g} px",lambda _=False,x=w:(self.width_box.setValue(x),self.width_key.update()))
        menu.exec(self._below(self.width_key))

    def reload_settings(self):
        data = load_json("pen-settings.json",None)
        self.slots = copy.deepcopy(DEFAULTS)
        if data is None:
            # 已存在但不能解析时，不用默认预设覆盖原文件。
            from .home import home
            if (home()/"pen-settings.json").exists():
                self.settings_error = "预设文件无法读取，已保护原文件"
            return
        if not isinstance(data,dict) or data.get("version") != 1:
            self.settings_error = "预设文件版本不支持，已保护原文件"
            return
        slots = data.get("slots")
        if not isinstance(slots,list) or len(slots) != 4:
            self.settings_error = "预设列表无效，已保护原文件"
            return
        for slot in slots:
            if (not isinstance(slot,dict) or slot.get("tool") not in dict(TOOLS) or
                not isinstance(slot.get("color"),str) or not QColor(slot["color"]).isValid() or
                not isinstance(slot.get("width"),(int,float)) or not .5 <= slot["width"] <= 30):
                self.settings_error = "预设样式无效，已保护原文件"
                return
        self.slots = slots
        self.session.snap_enabled = bool(data.get("snap",True))
        self.settings_error = ""

    def save_settings(self):
        if self.settings_error:
            self.more.setToolTip(self.settings_error)
            return
        try:
            save_json("pen-settings.json",dict(version=1,slots=self.slots,snap=self.session.snap_enabled))
        except OSError as exc:
            self.more.setToolTip("预设未保存："+str(exc))

    def save_slot(self,index):
        tool = "pointer" if self.target.tool == "move" else self.target.tool
        if tool not in dict(TOOLS):
            return
        self.slots[index] = dict(tool=tool,
                                 color=self.target.color,width=self.target.width_px)
        self.save_settings()

    def use_slot(self,index):
        slot = self.slots[index]
        self.target.color,self.target.width_px = slot["color"],slot["width"]
        self.set_tool("move" if self.board and slot["tool"] == "pointer" else slot["tool"])

    def open_menu(self):
        self.reload_settings()
        menu = QMenu(self)
        menu.setStyleSheet(menu_style())
        for key,label in (("stroke","整笔橡皮"),("pixel","局部橡皮（保留剩余笔画）")):
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(self.session.eraser_mode == key)
            action.triggered.connect(lambda _=False,k=key:setattr(self.session,"eraser_mode",k))
        action = menu.addAction("停笔 0.5 秒识别形状")
        action.setCheckable(True)
        action.setChecked(self.session.snap_enabled)
        action.triggered.connect(lambda on:(setattr(self.session,"snap_enabled",on),self.save_settings()))
        menu.addSeparator()
        for key,label in (("copy","复制选中笔迹"),("delete","删除选中笔迹"),("larger","放大选中笔迹"),("smaller","缩小选中笔迹")):
            action = menu.addAction(label)
            action.setEnabled(bool(self.session.ids))
            action.triggered.connect(lambda _=False,k=key:self.session.selection_action(k))
        menu.addSeparator()
        for key,label in (("in","放大画布"),("out","缩小画布"),("reset","复位视图")):
            menu.addAction(label,lambda _=False,k=key:self.session.view_action(k))
        menu.addSeparator()
        for index in range(4):
            slot = self.slots[index]
            sub = menu.addMenu(f"预设 {index+1} · {dict(TOOLS)[slot['tool']]} · {slot['width']:g}px")
            sub.setStyleSheet(menu_style())
            sub.addAction("使用",lambda _=False,i=index:self.use_slot(i))
            action = sub.addAction("保存当前样式",lambda _=False,i=index:self.save_slot(i))
            action.setEnabled(not self.settings_error and self.target.tool in [k for k,_ in TOOLS]+["move"])
        if self.settings_error:
            menu.addAction(self.settings_error).setEnabled(False)
        menu.exec(self.more.mapToGlobal(self.more.rect().bottomLeft()))
