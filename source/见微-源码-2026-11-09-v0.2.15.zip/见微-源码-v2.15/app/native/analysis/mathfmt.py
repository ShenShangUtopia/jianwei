"""讲题里的算式排版：把程序和 AI 写的纯文本算式变成课本样子的富文本（QLabel 用）。

- v_0 → v₀（下标），m/s^2 → m/s²（上标），1.3116e-07 → 1.31×10⁻⁷
- 太长的小数只显示 3 位有效数字，被约过的等号改成 ≈（4.02156 → ≈ 4.02）
- sqrt(3) → √3 带顶线；>= ≤ ≠ → ±；theta / mu 等希腊字母名 → θ μ
- 单个字母的物理量用斜体；数字后面的单位保持正体（2 kg、10 m/s²）

只改显示，不改数据；核对、导出都还用原文。
"""
from __future__ import annotations

import html
import math
import re

GREEK = dict(alpha="α", beta="β", gamma="γ", delta="δ", Delta="Δ", epsilon="ε", theta="θ", lambda_="λ", lam="λ", mu="μ",
             pi="π", rho="ρ", sigma="σ", Sigma="Σ", tau="τ", phi="φ", omega="ω", Omega="Ω", eta="η")
GREEK["lambda"] = "λ"
UNIT_GREEK = set("Ωμ°℃")
UNIT_LETTERS = set("msNJWVATKgLCFHΩ")
GREEK_CHARS = set("αβγδεθλμπρστφωηΔ")
GENOTYPE = re.compile(r"[A-Za-z]_(?![0-9a-z{])")
ITALIC = "font-family:'Cambria Math','Cambria','Times New Roman',serif;font-style:italic"
OPS = {">=": "≥", "<=": "≤", "!=": "≠", "->": "→", "+-": "±", "*": "·", "=>": "⇒"}

TOKEN = re.compile(r"""
    (?P<sci>\d+(?:\.\d+)?[eE][+-]?\d+)
  | (?P<num>\d+(?:\.\d+)?)
  | (?P<sqrt>sqrt\(|√\()
  | (?P<word>[A-Za-z]+)
  | (?P<sup>\^\s*(?:\([^()]*\)|\{[^{}]*\}|[+\-−]?[0-9A-Za-z.]+))
  | (?P<sub>_(?:\{[^{}]*\}|[0-9]+|[a-z]{1,3}(?![A-Za-z])))
  | (?P<op>>=|<=|!=|->|\+-|=>|\*)
  | (?P<other>.)
""", re.X | re.S)


def round_text(s: str) -> tuple[str, bool]:
    """数字文本 → (显示文本, 是否被约过)。有效数字多于 4 位时约成 3 位。"""
    digits = s.replace(".", "").lstrip("0")
    if len(digits) <= 4 or "." not in s:
        return s, False
    v = float(s)
    if v == 0:
        return "0", True
    keep = max(0, 3 - (int(math.floor(math.log10(abs(v)))) + 1))
    out = f"{round(v, keep):.{keep}f}"
    if "." in out:
        out = out.rstrip("0").rstrip(".")
    return out, out != s


def _sci(s: str) -> tuple[str, bool]:
    mant, exp = re.split(r"[eE]", s)
    m, changed = round_text(mant)
    e = int(exp)
    if e == 0:
        return m, changed
    head = "" if m == "1" else f"{m}×"
    return f"{head}10<sup>{'−' if e < 0 else ''}{abs(e)}</sup>", changed


def _approx(out: list[str]) -> None:
    """刚写的数被约过：把它前面的等号改成约等号。"""
    i = len(out) - 1
    while i >= 0 and out[i] in (" ", "&nbsp;"):
        i -= 1
    if i >= 0 and out[i] == "=":
        out[i] = "≈"


def _close(text: str, start: int) -> int:
    depth = 1
    for j in range(start, len(text)):
        if text[j] == "(":
            depth += 1
        elif text[j] == ")":
            depth -= 1
            if depth == 0:
                return j
    return -1


def to_html(text, italic: bool = True) -> str:
    """纯文本算式 → 富文本。认不出的字符原样（转义后）输出。"""
    text = str(text or "")
    if GENOTYPE.search(text):   # A_B_、aaB_ 里的下划线是「任意」，不是下标；基因型也不套斜体
        return html.escape(plain(text)).replace("\n", "<br>")
    out: list[str] = []
    unit = False          # 刚读完一个数：后面紧跟的字母是单位
    prev_word = False     # 上一个记号是字母（下标只跟在字母后面）
    i = 0
    while i < len(text):
        m = TOKEN.match(text, i)
        kind, tok = m.lastgroup, m.group()
        i = m.end()
        if kind == "sci":
            s, changed = _sci(tok)
            if changed:
                _approx(out)
            out.append(s)
            unit, prev_word = True, False
        elif kind == "num":
            s, changed = round_text(tok)
            if changed:
                _approx(out)
            out.append(s)
            unit, prev_word = True, False
        elif kind == "sqrt":
            j = _close(text, i)
            if j < 0:
                out.append("√(")
                continue
            inner = text[i:j]
            body = to_html(inner, italic)
            simple = re.fullmatch(r"[0-9A-Za-z.]+", inner) is not None
            out.append(f"√<span style='text-decoration:overline'>{body if simple else '(' + body + ')'}</span>")
            i = j + 1
            unit, prev_word = False, False
        elif kind == "word":
            # 数后面：多字母或常见单位字母是单位（2 kg、10 m/s）；3x 里的 x 是未知量
            is_unit = unit and (len(tok) > 1 or tok in UNIT_LETTERS)
            if tok in GREEK:
                g = GREEK[tok]
                out.append(g if is_unit or not italic else f"<span style=\"{ITALIC}\">{g}</span>")
            elif is_unit or len(tok) > 1 or not italic:
                out.append(html.escape(tok))
            else:
                out.append(f"<span style=\"{ITALIC}\">{tok}</span>")
            prev_word = True
            unit = is_unit   # 单位链：kg·m/s、m/s² —— 后面跟 / · 再接字母仍是单位
        elif kind == "sup":
            body = tok[1:].strip()
            if body[:1] in "({":
                body = body[1:-1]
            if re.fullmatch(r"[\-−]?[0-9.]+", body):
                out.append(f"<sup>{body.replace('-', '−')}</sup>")
            else:
                out.append(f"<sup>{to_html(body, italic)}</sup>")
            prev_word = False
        elif kind == "sub":
            body = tok[1:]
            if body[:1] == "{":
                body = body[1:-1]
            if prev_word:
                out.append(f"<sub>{html.escape(body)}</sub>")
            else:
                out.append(html.escape(tok))
            prev_word = False
        elif kind == "op":
            out.append(OPS[tok])
            unit, prev_word = False, False
        else:
            ch = tok
            if ch == "\n":
                out.append("<br>")
                unit = False
            elif ch in "/·" and unit:
                out.append(html.escape(ch))      # m/s、kg·m 还在单位里
            elif ch == " " and unit and _last_is_number(out):
                out.append(" ")                  # 数和单位之间的空格
            elif ch in UNIT_GREEK and unit:
                out.append(ch)
            elif ch in "²³⁻¹":
                out.append(ch)
            elif ch in GREEK_CHARS and italic:
                out.append(f"<span style=\"{ITALIC}\">{ch}</span>")
                unit = False
            else:
                out.append(html.escape(ch))
                unit = False
            if ch not in "²³⁻¹":
                prev_word = False
    return "".join(out)


def _last_is_number(out: list[str]) -> bool:
    return bool(out) and bool(re.search(r"[0-9]$|</sup>$", out[-1]))


SUP = str.maketrans("0123456789-−+", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁻⁺")
SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")


def plain(text) -> str:
    """纯文本场合（画布上的字、提示框）：约长小数，指数和数字下标改成上下标字符。"""
    s = str(text or "")

    def eq(m):   # 被约过的数前面的等号改成约等号
        num = m.group(2)
        mant = re.split(r"[eE]", num)[0]
        return ("≈" if round_text(mant)[1] else "=") + m.group(1) + num
    s = re.sub(r"=(\s*)(\d+\.\d+(?:[eE][+-]?\d+)?)", eq, s)

    def fix(m):
        if m.group("sci"):
            mant, exp = re.split(r"[eE]", m.group())
            e = int(exp)
            return f"{round_text(mant)[0]}×10{str(e).translate(SUP)}"
        return round_text(m.group())[0]
    s = re.sub(r"(?P<sci>\d+(?:\.\d+)?[eE][+-]?\d+)|\d+\.\d+", fix, s)
    s = re.sub(r"\^\s*\(?([\-−+]?\d+)\)?", lambda m: m.group(1).translate(SUP), s)
    if not GENOTYPE.search(s):
        s = re.sub(r"(?<=[A-Za-zα-ωΑ-Ω])_\{?(\d+)\}?", lambda m: m.group(1).translate(SUB), s)
    return s
