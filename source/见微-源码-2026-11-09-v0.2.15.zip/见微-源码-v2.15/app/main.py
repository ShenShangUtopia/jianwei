"""见微 · 高考学习舱 —— 入口。

用法：
  python main.py                 显示主窗口
  python main.py --background    静默驻留托盘
  python main.py --self-test     无头渲染各页面截图（开发验收用，不弹窗）
  python main.py --studio [id]   直接打开析题台某题
  python main.py --pill          只显示倒计时胶囊（调试）
"""
from __future__ import annotations

import argparse
import ctypes
import os
import sys
import traceback
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

import store  # noqa: E402


def _log(exc_type, exc_value, exc_tb) -> None:
    try:
        (store.HOME / "logs").mkdir(parents=True, exist_ok=True)
        with open(store.HOME / "logs" / "app.log", "a", encoding="utf-8") as fh:
            fh.write("".join(traceback.format_exception(exc_type, exc_value, exc_tb)))
            fh.write("\n")
    except Exception:
        pass


def _self_test(out_dir: Path) -> int:
    out_dir.mkdir(parents=True,exist_ok=True)
    if sys.stdout is None or sys.stderr is None:
        test_log = (out_dir/"selftest.log").open("a",encoding="utf-8",buffering=1)
        sys.stdout = sys.stdout or test_log
        sys.stderr = sys.stderr or test_log
    from PySide6.QtGui import QPixmap
    from PySide6.QtWidgets import QApplication

    from countdown import draw_pill
    from shell import Shell

    out_dir.mkdir(parents=True, exist_ok=True)
    failures = []
    app = QApplication.instance() or QApplication(sys.argv[:1])
    shell = Shell(tray_enabled=False, jobs_enabled=False)
    shell.resize(1180, 780)
    shell.show()
    app.processEvents()

    from datetime import datetime
    from PySide6.QtGui import QPainter
    for key, _ in [("today", ""), ("guanlan", ""), ("countdown", ""), ("studio", ""), ("lab", ""), ("settings", "")]:
        shell.goto(key)
        for _ in range(3):
            app.processEvents()
        shell.grab().save(str(out_dir / f"shell-{key}.png"), "PNG")

    # 观澜浮窗：验证内嵌模块能在这套环境里真的建起来
    try:
        panel = shell.guanlan.ensure()
        panel.show_window()
        for _ in range(3):
            app.processEvents()
        panel.grab().save(str(out_dir / "panel.png"), "PNG")
        shell.guanlan.hide()
        print("PANEL_OK", panel.size().width(), panel.size().height())
    except Exception as exc:
        print("PANEL_FAIL", repr(exc))

    # 胶囊：直接画到画布（不依赖桌面取景）
    pm = QPixmap(700, 52)
    pm.fill(__import__("PySide6.QtGui", fromlist=["QColor"]).QColor(0, 0, 0, 0))
    p = QPainter(pm)
    draw_pill(p, 700, 52, shell.cfg, datetime.now(), None, 0.6)
    p.end()
    pm.save(str(out_dir / "pill.png"), "PNG")

    tall = QPixmap(880 * 2, 360)
    from PySide6.QtGui import QColor
    tall.fill(QColor("#2A3346"))
    p = QPainter(tall)
    for i, cfg in enumerate([
        dict(shell.cfg, width=880, height=64),
        dict(shell.cfg, width=720, height=56, showDate=False),
        dict(shell.cfg, width=1060, height=72, aurora=80),
    ]):
        p.save()
        p.translate(40, 30 + i * 110)
        draw_pill(p, cfg["width"], cfg["height"], cfg, datetime.now(), None, 0.9 + i)
        p.restore()
    p.end()
    tall.save(str(out_dir / "pill-sizes.png"), "PNG")

    # 学习窗口：四个模式都建一遍，题目分析走离线
    try:
        from native.main_win import NativeWindow
        nw = NativeWindow("day")
        nw.resize(1440, 900)
        nw.show()
        for key in ("desk", "lab", "bench", "analysis", "lecture"):
            nw.goto(key)
            for _ in range(5):
                app.processEvents()
            nw.grab().save(str(out_dir / f"native-{key}.png"), "PNG")
        print("NATIVE_OK", len(nw.pages))
        nw.shutdown()
        nw.close()
    except Exception as exc:
        import traceback
        traceback.print_exc()
        print("NATIVE_FAIL", repr(exc))
        failures.append("native")

    # 共享画笔：旧格式迁移、备份、写保护、绘图和撤销。
    try:
        from native.kit import pen_selftest
        code = pen_selftest.main(out_dir / "pen")
        from native.kit import pen_tools_selftest
        code = max(code, pen_tools_selftest.main(out_dir / "pen-tools"))
        (out_dir / "pen-result.txt").write_text("PEN_OK" if code == 0 else "PEN_FAIL", encoding="utf-8")
        if code:
            failures.append("pen")
    except Exception:
        import traceback
        (out_dir / "pen-result.txt").write_text("PEN_CRASH\n" + traceback.format_exc(), encoding="utf-8")
        failures.append("pen")

    from native.kit import test_runtime, clip_selftest, workbench_selftest, interop_selftest, bench_ui_selftest
    from native import evening_selftest, backup_selftest, learning_selftest
    from native.lecture import speed_selftest, fidelity_selftest, compat_tools_selftest, chemical_selftest, vision_selftest
    from native.design import selftest as design_selftest
    from native.analysis.figure import selftest as figure_selftest, integration_selftest as figure_live, subject_selftest, transfer_selftest
    from native.kit import apparatus_selftest, extension_selftest
    from native.analysis import realtime_selftest, practice_selftest, stage6_selftest
    from native.kit import models29_selftest, models29b_selftest
    # Dispose earlier test windows/timers between suites; keep the one Qt app.
    test_runtime.cleanup(False)
    try:
        with test_runtime.isolated_data(out_dir/'compat-tools'):
            code=compat_tools_selftest.main(out_dir/'compat-tools')
        (out_dir/'compat-tools-result.txt').write_text('OK' if not code else 'FAIL',encoding='utf-8')
        if code:
            failures.append('compat-tools')
    except Exception:
        import traceback
        (out_dir/'compat-tools-result.txt').write_text('CRASH\n'+traceback.format_exc(),encoding='utf-8')
        failures.append('compat-tools')
    finally:
        test_runtime.cleanup(False)
    for label,module in (("vision",vision_selftest),("chemical",chemical_selftest),("fidelity",fidelity_selftest),("backup",backup_selftest),("design",design_selftest),("evening",evening_selftest),("bench-ui",bench_ui_selftest),("clip",clip_selftest),("work-transfer",workbench_selftest),("interop",interop_selftest),("ppt-speed",speed_selftest),("figure",figure_selftest),("figure-live",figure_live),("figure-subject",subject_selftest),("figure-transfer",transfer_selftest),("apparatus",apparatus_selftest),("extensions",extension_selftest),("realtime",realtime_selftest)):
        try:
            with test_runtime.isolated_data(out_dir/label):
                code = module.main(out_dir/label)
            (out_dir/(label+"-result.txt")).write_text("OK" if not code else "FAIL",encoding="utf-8")
            if code:
                failures.append(label)
        except Exception:
            import traceback
            (out_dir/(label+"-result.txt")).write_text("CRASH\n"+traceback.format_exc(),encoding="utf-8")
            failures.append(label)
        finally:
            test_runtime.cleanup(False)

    from native import selftest as traversal_test
    from native.bank import selftest as bank_test
    from native.analysis import selftest as analysis_test
    for label,module,argv_style in (("practice",practice_selftest,False),("models29",models29_selftest,False),("models29b",models29b_selftest,False),("learning",learning_selftest,False),("stage6",stage6_selftest,False),("traversal",traversal_test,True),("bank",bank_test,True),("analysis",analysis_test,True)):
        try:
            with test_runtime.isolated_data(out_dir/label):
                code=module.main([str(out_dir/label)] if argv_style else out_dir/label)
            (out_dir/(label+'-result.txt')).write_text('OK' if not code else 'FAIL',encoding='utf-8')
            if code:
                failures.append(label)
        except Exception:
            import traceback
            (out_dir/(label+'-result.txt')).write_text('CRASH\n'+traceback.format_exc(),encoding='utf-8')
            failures.append(label)
        finally:
            test_runtime.cleanup(False)

    # 时间胶囊、观澜、全局交互（不联网）
    # 这组会改配置和观澜数据，只在数据目录已隔离时跑（发行脚本和手动自测都要设 JIANWEI_HOME）
    try:
        if os.environ.get("JIANWEI_HOME"):
            real_home = os.path.realpath(store.HOME) == os.path.realpath(os.environ["JIANWEI_HOME"])
        else:
            real_home = False
        if not real_home:
            raise RuntimeError("JIANWEI_HOME 没有指向隔离目录，跳过")
        import panels_selftest
        with test_runtime.isolated_data(out_dir/"panels"):
            code = panels_selftest.main(out_dir/"panels")
        (out_dir/"panels-result.txt").write_text("OK" if not code else "FAIL",encoding="utf-8")
        if code:
            failures.append("panels")
    except Exception:
        import traceback
        (out_dir/"panels-result.txt").write_text("CRASH\n"+traceback.format_exc(),encoding="utf-8")
        failures.append("panels")

    # 课件：导入、放映、笔、框选、黑板、查询（不联网）。打包版没有控制台，结果写进文件
    try:
        from native.lecture import selftest as lecture_test
        with test_runtime.isolated_data(out_dir/"lecture"):
            code = lecture_test.main([str(out_dir / "lecture")])
        (out_dir / "lecture-result.txt").write_text("LECTURE_OK" if code == 0 else "LECTURE_FAIL " + ",".join(lecture_test.LAST_FAILS), encoding="utf-8")
        if code:
            failures.append("lecture")
    except Exception:
        import traceback
        (out_dir / "lecture-result.txt").write_text("LECTURE_CRASH\n" + traceback.format_exc(), encoding="utf-8")
        failures.append("lecture")

    print("SELFTEST_FAIL" if failures else "SELFTEST_OK", out_dir,failures)
    return int(bool(failures))


def main() -> int:
    # 打包版的控制台可能是 cp1252/cp936：中文路径一 print 就抛 UnicodeEncodeError（自检会因此卡死在退出前）
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--background", action="store_true")
    parser.add_argument("--self-test", default="")
    parser.add_argument("--studio", default=None)
    parser.add_argument("--lab", action="store_true")
    parser.add_argument("--pill", action="store_true")
    parser.add_argument("--no-single", action="store_true")
    parser.add_argument("--no-tray", action="store_true")
    parser.add_argument("--evening", action="store_true", help="生成并全屏播放暮省，不开主窗口")
    parser.add_argument("--evening-no-open", action="store_true", help="只生成暮省，不播放")
    parser.add_argument("--evening-date", default="", help="重播某一期（YYYY-MM-DD）")
    parser.add_argument("--fetch", action="store_true", help="立即抓取一次今日内容")
    parser.add_argument('--data-backup',default='')
    parser.add_argument('--data-restore',default='')
    args, _ = parser.parse_known_args()

    if not args.self_test:
        from native import backup
        if args.data_backup or args.data_restore:
            from native.backup_ui import maintain
            return maintain(store.HOME,'restore' if args.data_restore else 'backup',args.data_restore or args.data_backup,store.VERSION)
        try:
            if backup.journal_path(store.HOME).exists():
                with backup.DataLease(store.HOME,exclusive=True):
                    backup.recover(store.HOME)
            global _DATA_LEASE
            _DATA_LEASE = backup.DataLease(store.HOME).acquire()
        except (backup.BackupError,OSError) as exc:
            # Explicit maintenance notice, not a Python crash report.
            if sys.platform=='win32':
                ctypes.windll.user32.MessageBoxW(0,str(exc),'见微 · 数据保护',0x10)
            return 1

    if args.evening or args.evening_no_open or args.evening_date or args.fetch:
        os.environ.setdefault("JIANWEI_CLI", "1")
        try:
            import scheduler
            if args.fetch:
                return scheduler.run_fetch()
            return scheduler.run_evening(play=not args.evening_no_open, date=args.evening_date)
        except Exception:
            import traceback
            traceback.print_exc()
            _log(*sys.exc_info())
            return 1

    if args.self_test:
        from native.kit import test_runtime
        test_runtime.configure()
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        if not os.environ.get("QT_QPA_FONTDIR") and os.path.isdir(r"C:\Windows\Fonts"):
            os.environ["QT_QPA_FONTDIR"] = r"C:\Windows\Fonts"

    sys.excepthook = _log
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Jianwei.StudyCabin.1")
    except Exception:
        pass

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtWidgets import QApplication

    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("见微")
    app.setApplicationDisplayName("见微 · 高考学习舱")
    app.setOrganizationName("Jianwei")
    app.setStyle("Fusion")
    app.setQuitOnLastWindowClosed(False)
    from native.design import ux
    ux.install(app)
    import ui_kit
    from store import load_config
    _t = load_config().get("theme", "auto")
    if _t not in ("day", "night"):
        from datetime import datetime as _dt
        _t = "day" if 7 <= _dt.now().hour < 19 else "night"
    ui_kit.apply_theme(_t)
    app.setStyleSheet(ui_kit.qss())

    if args.self_test:
        return test_runtime.run(lambda:_self_test(Path(args.self_test)))

    from PySide6.QtNetwork import QLocalServer, QLocalSocket

    server = None
    if not args.no_single:
        socket = QLocalSocket()
        socket.connectToServer("Jianwei-Suite-Local")
        if socket.waitForConnected(200):
            socket.write(b"show")
            socket.waitForBytesWritten(150)
            socket.disconnectFromServer()
            return 0
        server = QLocalServer()
        QLocalServer.removeServer("Jianwei-Suite-Local")
        server.listen("Jianwei-Suite-Local")

    from shell import Shell
    shell = Shell(tray_enabled=not args.no_tray)
    if server is not None:
        def new_connection():
            conn = server.nextPendingConnection()
            if conn is not None:
                conn.readyRead.connect(shell._tray_show)
        server.newConnection.connect(new_connection)

    if args.pill:
        shell.show_pill(True)
        return app.exec()

    if args.studio is not None:
        shell.open_studio(args.studio, lab=args.lab)
        return app.exec()

    if args.background or shell.cfg.get("startMinimized"):
        shell.hide()
    else:
        shell.show()
        shell.raise_()
    return app.exec()


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        try:
            result = main()
        except BaseException:
            # A frozen windowed bootloader otherwise displays a modal dialog
            # even when Windows' process error dialogs are suppressed.
            _log(*sys.exc_info())
            result = 1
        sys.exit(result)
    sys.exit(main())
