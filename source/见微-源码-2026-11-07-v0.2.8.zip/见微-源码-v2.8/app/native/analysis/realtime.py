"""Request-local live calculations. No fuzzy question matching or cached AI answers."""
import copy
import json
import re
from functools import lru_cache
from pathlib import Path


def completed_field(text, wanted):
    """Read completed top-level members only; never mistake nested keys for task."""
    if not isinstance(text, str) or len(text) > 200000:
        return None
    decoder = json.JSONDecoder()
    i = text.find('{') + 1
    if not i:
        return None
    try:
        while i < len(text):
            while i < len(text) and text[i] in ' \r\n\t,':
                i += 1
            key, i = decoder.raw_decode(text, i)
            while i < len(text) and text[i].isspace():
                i += 1
            if text[i:i+1] != ':':
                return None
            i += 1
            while i < len(text) and text[i].isspace():
                i += 1
            value, i = decoder.raw_decode(text, i)
            if key == wanted:
                return value
    except (ValueError, RecursionError):
        pass
    return None


def normalized(text):
    # Preserve punctuation, numbers, units, signs and case. No substring matching.
    return re.sub(r'\s+', '', text)


@lru_cache(maxsize=1)
def bank_index():
    from .figure.bank_figures import load
    figures = load()
    questions = json.loads((Path(__file__).parents[1]/'bank/questions.json').read_text(encoding='utf-8'))
    index = {}
    for q in questions:
        if q['id'] in figures and q['id'] != 's-2023-b-06':
            key = normalized(q['stem'])
            if key in index:  # Ambiguous duplicates must not select arbitrary diagrams.
                index[key] = None
            else:
                index[key] = figures[q['id']]
    return index


def exact_figure(text):
    if not text or len(text) > 24000:
        return None
    try:
        return copy.deepcopy(bank_index().get(normalized(text)))
    except (OSError, ValueError, KeyError):
        return None


class LiveTasks:
    """Solve each completed parameter set once per request, including final validation."""
    def __init__(self, problem, build):
        self.problem, self.build = problem, build
        self.cache = {}
        self.last_key = None

    def solve(self, spec):
        key = json.dumps(spec, sort_keys=True, ensure_ascii=False)
        if len(key) > 24000:
            return dict(ok=False, errors=['task 参数过长，请精简到24000字符以内'])
        if key not in self.cache:
            result = self.build(spec, self.problem)
            if len(self.cache) >= 8:
                self.cache.pop(next(iter(self.cache)))
            self.cache[key] = result
        return copy.deepcopy(self.cache[key])

    def preview(self, text):
        spec = completed_field(text, 'task')
        if spec is None:
            return None
        key = json.dumps(spec, sort_keys=True, ensure_ascii=False)
        if key == self.last_key:
            return None
        self.last_key = key
        result = self.solve(spec)
        if not result['ok'] or any(t.get('failed_checks') for t in result.get('results', [])):
            return None
        return result['results']
