"""从题库原有文字/参数构建静态讲解图，不改题干、答案或选项。"""
import json
import re
import hashlib
from functools import lru_cache
from pathlib import Path
from .fallback import from_problem
from .schema import validate


def for_question(q):
    from .curated_stem import for_question as specific_stem
    stem_figure=specific_stem(q)
    if stem_figure:
        return validate(stem_figure)
    from .curated import cell_question
    curated=cell_question(q)
    if curated:
        return validate(curated)
    figure=from_problem(q["stem"],q["subject"],q.get("steps"))
    figure["title"]=q.get("title", "本题图解")
    figure["layers"][1]["text"]="题库原有条件与解析整理；示意位置不代表真实尺寸。"
    v=q.get("view",{})
    data=v.get("data",{})
    special=None
    mode=v.get("mode")
    if v.get("engine")=="graph" and v.get("expr"):
        expr=v.get("expr","")
        for param in v.get("params",[]):
            expr=re.sub(r"\b"+re.escape(param["k"])+r"\b",str(param.get("v",0)),expr)
        special=dict(type="function",expr=expr,range=v.get("xr",[-5,5])+v.get("yr",[-5,5]))
    elif v.get("engine")=="solid":
        special=dict(type="solid",kind=v.get("shape","cube"),size=v.get("size",{}))
    elif mode=="map" and data.get("points"):
        special=dict(type="map",points=[[70+float(p["x"])*400,130+float(p["y"])*330] for p in data["points"]],labels=[str(p.get("label","")) for p in data["points"]])
    elif mode=="timeline":
        special=dict(type="timeline",items=[str(p.get("title",""))+"："+str(p.get("note","")) for p in data.get("events",[])])
    elif mode=="genetics" and data.get("cross"):
        cross=data["cross"]
        parents=[cross.get("father",""),cross.get("mother","")]
        if all(isinstance(s,str) and len(s) in (2,4,6) and s.isascii() and s.isalpha() and all(s[i].upper()==s[i+1].upper() for i in range(0,len(s),2)) for s in parents):
            special=dict(type="genetics",items=[parents[0],"×",parents[1]])
    if special:
        figure["specific"]=True
        # Keep the actual original question/steps next to a subject diagram.
        figure["layers"]=[figure["layers"][0],figure["layers"][1],dict(id="subject",x=65,y=130,w=430,h=360,color="c1",**special),dict(id="explanation",type="text",x=540,y=120,w=410,h=410,text=q["stem"][:900],source="problem")]
        for i,step in enumerate(figure["steps"]):
            step["show"]=["context","notice","subject","explanation"]
            step["highlight"]=["subject"] if i else ["explanation"]
    else:
        # Make the source steps explicit and selectable, without guessing a model.
        for layer in figure["layers"]:
            if layer["id"]=="context":
                layer["text"]=q.get("title","条件与关系")
    return validate(figure)


@lru_cache(maxsize=1)
def load():
    path=Path(__file__).with_name("bank-figures.json")
    try:
        value=json.loads(path.read_text(encoding="utf-8"))
        questions=path.parents[2]/"bank/questions.json"
        if value.get("source_sha256")!=hashlib.sha256(questions.read_bytes()).hexdigest():
            return {}
        return value.get("figures",{}) if value.get("v")==1 else {}
    except (OSError,ValueError,AttributeError):
        return {}
