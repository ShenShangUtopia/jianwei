"""原生 QPainter 图解画布；统一步骤与 SVG/PNG 导出。"""
from __future__ import annotations

import math
from PySide6.QtCore import QByteArray, QBuffer, QIODevice, QPointF, QRectF, Qt, QTimer, QVariantAnimation, Signal
from PySide6.QtGui import QImage, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import QComboBox, QDoubleSpinBox, QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from ...design.tokens import T, font, qc
from .schema import validate, expression

W, H = 1000, 650


class FigureCanvas(QWidget):
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.setMinimumSize(280,210)
        self.error = ""

    def paintEvent(self,event):
        painter = QPainter(self)
        painter.fillRect(self.rect(),qc(T.stage))
        k = min(self.width()/W,self.height()/H)
        painter.translate((self.width()-W*k)/2,(self.height()-H*k)/2)
        painter.scale(k,k)
        try:
            self.owner.paint(painter,True)
        except (ValueError,TypeError,KeyError,IndexError,OverflowError) as exc:
            self.error = str(exc)
            painter.setPen(qc(T.bad))
            painter.drawText(QPointF(30,50),"图解数据不完整，请重新分析")
        finally:
            painter.end()


class FigureView(QWidget):
    step_changed = Signal(int)

    def __init__(self, figure):
        super().__init__()
        self.figure = validate(figure)
        self.k = 0
        self._curves = {}
        self._labels = []
        self.parameters={name:p["value"] for name,p in self.figure.get("params",{}).items()}
        self.parameter_controls={}
        self._previous_visible = set()
        self._fade = 1.0
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10,10,10,10)
        bar = QHBoxLayout()
        self.title = QLabel(self.figure.get("title") or "图解")
        self.title.setTextFormat(Qt.TextFormat.PlainText)
        bar.addWidget(self.title,1)
        self.prev = QPushButton("上一步")
        self.play = QPushButton("播放")
        self.next_ = QPushButton("下一步")
        self.speed = QComboBox()
        for label, ms in (("慢速",5000),("常速",2800),("快速",1400)):
            self.speed.addItem(label,ms)
        self.speed.setCurrentIndex(1)
        self.speed.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        for widget in (self.prev,self.play,self.next_,self.speed):
            bar.addWidget(widget)
        lay.addLayout(bar)
        self.parameter_bar=QWidget()
        self.parameter_layout=QGridLayout(self.parameter_bar)
        self.parameter_layout.setContentsMargins(0,0,0,0)
        lay.addWidget(self.parameter_bar)
        self._build_parameters()
        self.canvas = FigureCanvas(self)
        lay.addWidget(self.canvas,1)
        self.caption = QLabel()
        self.caption.setTextFormat(Qt.TextFormat.PlainText)
        self.caption.setWordWrap(True)
        lay.addWidget(self.caption)
        self.timer = QTimer(self)
        self.transition=QVariantAnimation(self)
        self.transition.setDuration(180)
        self.transition.setStartValue(0.0)
        self.transition.setEndValue(1.0)
        def fade(value):
            self._fade=float(value)
            self.canvas.update()
        self.transition.valueChanged.connect(fade)
        self.timer.timeout.connect(self.advance)
        self.prev.clicked.connect(lambda:self.go(self.k-1))
        self.next_.clicked.connect(lambda:self.go(self.k+1))
        self.play.clicked.connect(self.toggle_play)
        self.speed.currentIndexChanged.connect(lambda:self.timer.setInterval(self.speed.currentData()))
        self.go(0)

    @property
    def stages(self):
        return [s["say"] for s in self.figure["steps"]]

    def replace(self, figure):
        value = validate(figure)
        self.figure = value
        self._curves.clear()
        self.parameters={name:p["value"] for name,p in value.get("params",{}).items()}
        self._build_parameters()
        self.title.setText(value.get("title") or "图解")
        self.go(min(self.k,len(value["steps"])-1))

    def _build_parameters(self):
        while self.parameter_layout.count():
            item=self.parameter_layout.takeAt(0)
            if item.widget():
                item.widget().hide()
                item.widget().deleteLater()
        self.parameter_controls={}
        for i,(name,param) in enumerate(self.figure.get("params",{}).items()):
            self.parameter_layout.addWidget(QLabel(name),i//3,(i%3)*2)
            control=QDoubleSpinBox()
            control.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
            control.setDecimals(3)
            control.setRange(param["min"],param["max"])
            control.setSingleStep(max(.001,(param["max"]-param["min"])/100))
            control.setValue(self.parameters[name])
            control.valueChanged.connect(lambda value,n=name:self.set_parameter(n,value))
            self.parameter_controls[name]=control
            self.parameter_layout.addWidget(control,i//3,(i%3)*2+1)
        self.parameter_bar.setVisible(bool(self.parameters))
        self.parameter_bar.setToolTip("实时重算图形；原题答案保留，变式结论需另行核对")

    def set_parameter(self,name,value):
        param=self.figure.get("params",{}).get(name)
        if not param or isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not param["min"]<=value<=param["max"]:
            raise ValueError("图形参数超出范围")
        self.parameters[name]=value
        control=self.parameter_controls.get(name)
        if control and control.value()!=value:
            control.blockSignals(True)
            control.setValue(value)
            control.blockSignals(False)
        self._curves.clear()
        self.canvas.update()

    def go(self,k):
        if hasattr(self,"figure"):
            self._previous_visible=set(self.figure["steps"][min(self.k,len(self.figure["steps"])-1)]["show"])
        self.k = max(0,min(len(self.figure["steps"])-1,int(k)))
        self.caption.setText(f"{self.k+1}/{len(self.figure['steps'])}　{self.stages[self.k]}")
        self.prev.setEnabled(self.k>0)
        self.next_.setEnabled(self.k<len(self.stages)-1)
        self.canvas.update()
        self.transition.start()
        self.step_changed.emit(self.k)

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play.setText("播放")
        else:
            if self.k==len(self.stages)-1:
                self.go(0)
            self.timer.start(self.speed.currentData())
            self.play.setText("暂停")

    def advance(self):
        if self.k>=len(self.stages)-1:
            self.timer.stop()
            self.play.setText("播放")
        else:
            self.go(self.k+1)

    def label(self,painter,text,rect,color=None):
        rect = QRectF(rect)
        # Keep bounded text boxes apart. Never extend below the canvas.
        for _ in range(12):
            if not any(rect.intersects(old) for old in self._labels):
                break
            rect.translate(0,18)
            if rect.bottom()>H-10:
                rect.moveTop(max(10,rect.top()-180))
                rect.translate(25,0)
        self._labels.append(rect)
        painter.setPen(qc(color or T.fg))
        size=max(10,min(17,math.sqrt(max(1,rect.width()*rect.height())/(max(1,len(str(text)))*.9))))
        painter.setFont(font(size))
        painter.drawText(rect,int(Qt.AlignmentFlag.AlignVCenter|Qt.TextFlag.TextWordWrap),str(text)[:1200])

    def paint(self,painter,animate=False):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(QRectF(0,0,W,H),qc(T.stage))
        self._labels = []
        if self.parameters:
            self.label(painter,"变式图形参数（原答案未重算）： "+"　".join(f"{k}={v:g}" for k,v in self.parameters.items()),QRectF(25,5,940,30),T.warn)
        step = self.figure["steps"][self.k]
        shown,highlight = set(step["show"]),set(step["highlight"])
        for layer in self.figure["layers"]:
            if layer["id"] not in shown:
                continue
            painter.save()
            if animate and layer["id"] not in self._previous_visible:
                painter.setOpacity(self._fade)
            col = getattr(T,layer.get("color","fg"))
            if layer["id"] in highlight:
                col = T.accent
            painter.setPen(QPen(qc(col),3.5 if layer["id"] in highlight else 2))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            self.draw_layer(painter,layer,col,step.get("set",{}).get("t",0))
            painter.restore()

    def draw_layer(self,p,l,col,t):
        kind = l["type"]
        x,y = l.get("x",60),l.get("y",100)
        w,h = l.get("w",360),l.get("h",180)
        r = QRectF(x,y,w,h)
        end = QPointF(l.get("x2",x+w),l.get("y2",y+h))
        if kind in ("text","formula"):
            self.label(p,l.get("text",""),r,col)
        elif kind in ("point","circle"):
            radius = l.get("r",5 if kind=="point" else 65)
            p.drawEllipse(QPointF(x,y),radius,radius)
        elif kind in ("line","arrow","dimension","ray","bracket"):
            p.drawLine(QPointF(x,y),end)
            if kind in ("arrow","ray","dimension"):
                a = math.atan2(end.y()-y,end.x()-x)
                for sign in (-1,1):
                    p.drawLine(end,end-QPointF(math.cos(a+sign*.45)*14,math.sin(a+sign*.45)*14))
        elif kind in ("arc","angle"):
            radius = l.get("r",50)
            p.drawArc(QRectF(x-radius,y-radius,2*radius,2*radius),int(l.get("start",0)*16),int(l.get("span",60)*16))
        elif kind=="rect":
            p.drawRoundedRect(r,8,8)
            if l.get("text"):
                self.label(p,l["text"],r.adjusted(12,6,-12,-6),col)
        elif kind in ("polygon","region"):
            pts = [QPointF(*v) for v in l.get("points",[])]
            fill = qc(col)
            fill.setAlpha(35)
            p.setBrush(fill)
            p.drawPolygon(QPolygonF(pts))
        elif kind in ("plot","trajectory","field","wave","function","conic"):
            pts = l.get("points",[])
            if kind=="function":
                limits = l.get("range",[-5,5,-5,5])
                key = (l["expr"],tuple(limits),t,x,y,w,h,tuple(self.parameters.items()))
                if key not in self._curves:
                    fn = expression(l["expr"],tuple(self.parameters))
                    samples = []
                    for i in range(241):
                        u = limits[0]+(limits[1]-limits[0])*i/240
                        v = fn(u,t,*self.parameters.values())
                        samples.append([x+w*i/240,y+h*(limits[3]-v)/(limits[3]-limits[2])] if math.isfinite(v) and limits[2]<=v<=limits[3] else None)
                    if len(self._curves)>128:
                        self._curves.clear()
                    self._curves[key] = samples
                pts = self._curves[key]
            elif kind=="wave":
                pts = [[x+w*i/240,y+h/2-h*.35*math.sin(i/240*4*math.pi-t)] for i in range(241)]
            elif kind=="conic":
                model=l.get("kind","ellipse")
                if model=="ellipse":
                    pts = [[x+w/2+w/2*math.cos(i*math.pi/120),y+h/2+h/2*math.sin(i*math.pi/120)] for i in range(241)]
                elif model=="hyperbola":
                    pts=[]
                    for sign in (-1,1):
                        if pts:
                            pts.append(None)
                        pts.extend([[x+w/2+sign*w*.15*math.cosh(-1.5+i/80),y+h/2+h*.2*math.sinh(-1.5+i/80)] for i in range(241)])
                else:
                    pts=[[x+w*i/240,y+h-h*((i-120)/120)**2] for i in range(241)]
            path = QPainterPath()
            connected = False
            for q in pts:
                if q is None:
                    connected=False
                elif connected:
                    path.lineTo(*q)
                else:
                    path.moveTo(*q)
                    connected=True
            p.save()
            p.setClipRect(QRectF(0,0,W,H))
            p.drawPath(path)
            p.restore()
        elif kind=="genetics":
            from .glyphs import punnett
            punnett(self,p,l,r,col)
        elif kind=="timeline":
            items=l.get("items",[])
            p.drawLine(QPointF(x,y+h/2),QPointF(x+w,y+h/2))
            for i,item in enumerate(items):
                xx=x+(i+.5)*w/max(1,len(items))
                p.drawEllipse(QPointF(xx,y+h/2),5,5)
                self.label(p,item,QRectF(xx-w/max(1,len(items))/2,y if i%2==0 else y+h/2+15,w/max(1,len(items))-5,max(35,h/2-20)),col)
        elif kind=="tree":
            items=l.get("items",[])
            positions=[]
            for i,item in enumerate(items):
                level=int(math.log2(i+1))
                index=i-(2**level-1)
                xx=x+(index+.5)*w/(2**level)
                yy=y+level*h/max(1,math.ceil(math.log2(len(items)+1)))
                pos=QPointF(xx,yy)
                if i:
                    p.drawLine(positions[(i-1)//2],pos)
                positions.append(pos)
                p.drawEllipse(pos,7,7)
                self.label(p,item,QRectF(xx-60,yy+10,120,45),col)
        elif kind=="metabolism":
            items=l.get("items",[])
            for i,item in enumerate(items):
                xx=x+(i%3+.5)*w/3
                yy=y+(i//3+.5)*h/max(1,math.ceil(len(items)/3))
                p.drawEllipse(QRectF(xx-55,yy-24,110,48))
                self.label(p,item,QRectF(xx-50,yy-20,100,40),col)
        elif kind=="flow":
            items = l.get("items",[])
            n = max(1,len(items))
            for i,item in enumerate(items):
                bx = x+(i%3)*(w/3)
                by = y+(i//3)*max(75,h/max(1,math.ceil(n/3)))
                box = QRectF(bx,by,w/3-22,62)
                p.drawRoundedRect(box,8,8)
                self.label(p,item,box.adjusted(8,2,-8,-2),col)
                if i%3<2 and i<n-1:
                    p.drawLine(QPointF(box.right(),by+31),QPointF(box.right()+22,by+31))
        elif kind=="table":
            rows = l.get("rows",[])
            rh = h/max(1,len(rows))
            for i,row in enumerate(rows):
                cells = row if isinstance(row,list) else [row]
                for j,text in enumerate(cells):
                    box = QRectF(x+j*w/max(1,len(cells)),y+i*rh,w/max(1,len(cells)),rh)
                    p.drawRect(box)
                    self.label(p,text,box.adjusted(8,2,-8,-2),col)
        elif kind=="venn":
            p.drawEllipse(QRectF(x,y,w*.65,h))
            p.drawEllipse(QRectF(x+w*.35,y,w*.65,h))
        elif kind=="numberline":
            p.drawLine(QPointF(x,y+h/2),QPointF(x+w,y+h/2))
            for i in range(11):
                p.drawLine(QPointF(x+w*i/10,y+h/2-6),QPointF(x+w*i/10,y+h/2+6))
        elif kind=="bar":
            values = l.get("items",[])
            nums = [float(v) for v in values if isinstance(v,(int,float)) and not isinstance(v,bool)]
            scale = max([abs(v) for v in nums]+[1])
            for i,v in enumerate(nums):
                p.drawRect(QRectF(x+i*w/max(1,len(nums)),y+h-abs(v)/scale*h,w/max(1,len(nums))*.65,abs(v)/scale*h))
        else:
            self.special(p,l,r,col,t)
        if l.get("label"):
            self.label(p,l["label"],QRectF(x+8,y-35,min(w,300),34),col)

    def special(self,p,l,r,col,t):
        from .glyphs import draw
        draw(self,p,l,r,col,t)

    def image(self):
        image = QImage(W,H,QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(qc(T.stage))
        painter = QPainter(image)
        try:
            self.paint(painter)
        finally:
            painter.end()
        return image

    def svg(self):
        from PySide6.QtSvg import QSvgGenerator
        from PySide6.QtCore import QSize
        data = QByteArray()
        buffer = QBuffer(data)
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        generator = QSvgGenerator()
        generator.setOutputDevice(buffer)
        generator.setSize(QSize(W,H))
        generator.setViewBox(QRectF(0,0,W,H))
        painter = QPainter(generator)
        try:
            self.paint(painter)
        finally:
            painter.end()
            buffer.close()
        return bytes(data)
