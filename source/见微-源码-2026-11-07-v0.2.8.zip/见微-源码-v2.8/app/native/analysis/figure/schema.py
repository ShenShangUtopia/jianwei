from __future__ import annotations

import copy
import math
import re

TYPES = {"point", "line", "arrow", "arc", "rect", "circle", "polygon", "text", "formula", "angle", "dimension", "bracket", "table", "flow", "timeline", "tree", "venn", "numberline", "bar", "plot", "function", "region", "conic", "forces", "trajectory", "circuit", "ray", "field", "wave", "energy", "apparatus", "ions", "structure", "cell", "organelle", "division", "genetics", "pedigree", "metabolism", "pyramid", "map", "solid"}
COLORS = {"fg", "muted", "accent", "ok", "bad", "warn", "c1", "c2", "c3", "c4", "c5", "c6"}


class FigureError(ValueError):
    pass


def _budget(value):
    count, active,characters = [0], set(),[0]
    def visit(v, depth):
        count[0] += 1
        if depth > 12 or count[0] > 16000:
            raise FigureError("图解嵌套或节点数量超限")
        if isinstance(v, (dict, list)):
            if id(v) in active:
                raise FigureError("图解包含循环引用")
            active.add(id(v))
            if len(v) > 1024:
                raise FigureError("数组或对象过大")
            if isinstance(v, dict):
                for key, item in v.items():
                    if not isinstance(key, str) or len(key) > 80:
                        raise FigureError("字段名无效")
                    visit(item, depth+1)
            else:
                for item in v:
                    visit(item, depth+1)
            active.remove(id(v))
        elif isinstance(v, float) and not math.isfinite(v):
            raise FigureError("图解包含 NaN 或无穷大")
        elif isinstance(v, (int, float)) and (isinstance(v, bool) or abs(v) > 1e9):
            if not isinstance(v, bool):
                raise FigureError("图解数值过大")
        elif isinstance(v, str):
            characters[0]+=len(v)
            if characters[0]>64000:
                raise FigureError("图解总文字量超限")
            if len(v) > 2400:
                raise FigureError("图解文字过长")
        elif v is not None and not isinstance(v, (bool, int, float)):
            raise FigureError("图解只接受 JSON 数据")
    visit(value, 0)


def expression(src,variables=()):
    from ...kit.expr import compile_expr
    if not isinstance(src, str) or len(src) > 160 or src.count("(") > 16:
        raise FigureError("表达式太长或嵌套过深")
    if re.search(r"!|\b(fact|comb|perm)\b|__|[\[\]{};:'\"\\]", src):
        raise FigureError("表达式不允许阶乘、组合或代码语法")
    try:
        return compile_expr(src, ("x", "t",*variables))
    except (ValueError, RecursionError, SyntaxError) as exc:
        raise FigureError("表达式无效："+str(exc)) from exc


def validate(raw):
    _budget(raw)
    if not isinstance(raw, dict) or type(raw.get("v")) is not int or raw.get("v") != 1:
        raise FigureError("figure.v 必须为 1")
    layers, steps = raw.get("layers"), raw.get("steps")
    if not isinstance(layers, list) or not 1 <= len(layers) <= 192:
        raise FigureError("layers 必须包含 1–192 个图元")
    if not isinstance(steps, list) or not 1 <= len(steps) <= 64:
        raise FigureError("steps 必须包含 1–64 步")
    out = copy.deepcopy(raw)
    params=out.get("params",{})
    from ...kit.expr import MF,MCONST
    if not isinstance(params,dict) or len(params)>6:
        raise FigureError("params 最多6个图形参数")
    for name,p in params.items():
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,11}",name) or name in {"x","t","F",*MF,*MCONST}:
            raise FigureError("图形参数名不合法或与内置函数重名")
        if not isinstance(p,dict) or any(isinstance(p.get(k),bool) or not isinstance(p.get(k),(int,float)) or abs(p[k])>10000 for k in ("min","max","value")) or not p["min"]<=p["value"]<=p["max"] or p["min"]>=p["max"]:
            raise FigureError("图形参数必须具有有效 min/max/value")
    for key in ("title", "subject"):
        if key in out and not isinstance(out[key],str):
            raise FigureError(key+" 必须是字符串")
    ids = set()
    for i, layer in enumerate(out["layers"]):
        prefix = f"layers[{i}]"
        if not isinstance(layer, dict):
            raise FigureError(prefix+" 必须是对象")
        lid = layer.get("id")
        if not isinstance(lid, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,48}", lid) or lid in ids:
            raise FigureError(prefix+" id 无效或重复")
        ids.add(lid)
        if layer.get("type") not in TYPES:
            raise FigureError(prefix+" type 不在图元白名单中")
        choices={"conic":{"ellipse","hyperbola","parabola"},"solid":{"cube","cuboid","prism","pyramid","cylinder","cone","sphere","frustum"},"apparatus":{"tube","beaker","flask","cylinder","burette","gasjar","dish","bottle","volumetric","roundflask"}}
        if layer["type"] in choices and "kind" in layer and layer["kind"] not in choices[layer["type"]]:
            raise FigureError(prefix+" kind 尚未支持，不能用其他形状代替")
        if layer.get("color", "fg") not in COLORS:
            raise FigureError(prefix+" color 必须是主题颜色名")
        for key in ("x", "y", "x2", "y2", "w", "h", "r", "start", "span", "width", "value"):
            if key in layer and (isinstance(layer[key], bool) or not isinstance(layer[key], (int, float))):
                raise FigureError(prefix+"."+key+" 必须是有限数字")
        for key in ("text", "label", "expr", "bind", "source", "kind"):
            if key in layer and not isinstance(layer[key], str):
                raise FigureError(prefix+"."+key+" 必须是字符串")
        for key in ("x", "x2"):
            if key in layer:
                layer[key] = min(980, max(20, layer[key]))
        for key in ("y", "y2"):
            if key in layer:
                layer[key] = min(620, max(30, layer[key]))
        for key in ("w", "h", "r"):
            if key in layer and not 0 < layer[key] <= 2000:
                raise FigureError(prefix+" 尺寸超限")
        for key in ("start","span"):
            if key in layer:
                layer[key]=max(-360,min(360,layer[key]))
        if "points" in layer:
            pts = layer["points"]
            if not isinstance(pts, list) or len(pts) > 512 or any(not isinstance(p, list) or len(p)!=2 or any(isinstance(n,bool) or not isinstance(n,(float,int)) or abs(n)>10000 for n in p) for p in pts):
                raise FigureError(prefix+" points 无效")
        for key in ("items", "rows", "labels"):
            if key in layer and (not isinstance(layer[key], list) or len(layer[key])>64):
                raise FigureError(prefix+"."+key+" 最多64项")
        if "rows" in layer and (len(layer["rows"])>16 or any(not isinstance(row,list) or len(row)>8 or any(not isinstance(v,(str,int,float)) or isinstance(v,bool) for v in row) for row in layer["rows"])):
            raise FigureError(prefix+" table最多16行8列，单元格只接受文字或数字")
        if layer["type"]=="function":
            expression(layer.get("expr", ""),tuple(params))
        if "range" in layer:
            r = layer["range"]
            if not isinstance(r,list) or len(r)!=4 or any(isinstance(x,bool) or not isinstance(x,(int,float)) or abs(x)>10000 for x in r) or r[0]>=r[1] or r[2]>=r[3]:
                raise FigureError(prefix+" range 应为递增的 [xmin,xmax,ymin,ymax]")
        if "size" in layer and (not isinstance(layer["size"],dict) or any(k not in ("a","b","h","r","R","n") or isinstance(v,bool) or not isinstance(v,(int,float)) or not 0<v<=10000 for k,v in layer["size"].items())):
            raise FigureError(prefix+" size 必须为有限的正尺寸")
        if layer["type"]=="pedigree":
            people=layer.get("items",[])
            seen=set()
            if not 1<=len(people)<=24:
                raise FigureError(prefix+" 系谱必须含1–24个人物")
            for person in people:
                if not isinstance(person,dict) or not isinstance(person.get("id"),str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,32}",person["id"]) or person["id"] in seen or person.get("sex") not in ("male","female","unknown") or (person.get("affected") is not None and type(person.get("affected")) is not bool):
                    raise FigureError(prefix+" 系谱人物需唯一id、sex及affected")
                parents=person.get("parents",[])
                if not isinstance(parents,list) or len(parents)>2 or any(not isinstance(pid,str) or pid not in seen for pid in parents) or len(set(parents))!=len(parents):
                    raise FigureError(prefix+" 系谱双亲必须在子代之前定义，禁止循环")
                seen.add(person["id"])
    labels=0
    segments=0
    for layer in out["layers"]:
        labels+=1+len(layer.get("items",[]))+len(layer.get("labels",[]))+sum(len(row) for row in layer.get("rows",[]))
        if layer["type"]=="genetics":
            labels+=81
        segments+=len(layer.get("points",[]))
        if layer["type"] in ("function","conic","wave"):
            segments+=241
        if layer["type"]=="solid":
            segments+=600
    if labels>256 or segments>10000:
        raise FigureError("图解绘制预算超限，请拆成更少图元/表格")
    for i, step in enumerate(out["steps"]):
        if not isinstance(step,dict) or not isinstance(step.get("say"),str):
            raise FigureError(f"steps[{i}] 缺少 say")
        for key in ("show", "highlight"):
            if key not in step:
                step[key] = list(ids) if key=="show" else []
            if not isinstance(step[key],list) or len(step[key])>192 or any(not isinstance(x,str) or x not in ids for x in step[key]):
                raise FigureError(f"steps[{i}].{key} 引用了不存在的图元")
        state = step.get("set",{})
        if not isinstance(state,dict) or any(k!="t" or isinstance(v,bool) or not isinstance(v,(int,float)) or abs(v)>10000 for k,v in state.items()):
            raise FigureError("步骤 set 只允许有限数值 t")
    return out
