"""跨窗口内容菜单、拖放、剪贴板与素材篮抽屉。"""
from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtGui import QDrag, QPixmap
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMenu, QPushButton, QVBoxLayout

from ..design.tokens import T
from ..design.widgets import qss
from .clip import MIME

BENCHES = (("draw","几何画板"),("scene","场景搭建"),("circ","电路"),("phys","力学"),("chem","化学"))


def send_menu(menu,bus,maker,context=None):
    for target,label in (("board","送到黑板"),("lecture","作为课件插页"),("basket","放入素材篮"),("analysis","析题并打开工作台")):
        menu.addAction(label,lambda _=False,t=target:bus.send(maker(),t,context))
    submenu = menu.addMenu("送到工作台")
    for bid,title in BENCHES:
        submenu.addAction(title,lambda _=False,k=bid:bus.send(maker(),"bench:"+k,context))


class ClipInteraction(QObject):
    def __init__(self,widget,bus,maker,receiver,context=None,origin=None):
        super().__init__(widget)
        self.widget,self.bus,self.maker,self.receiver = widget,bus,maker,receiver
        self.context,self.origin = context,origin
        self.drag_start = None
        widget.setAcceptDrops(True)
        widget.installEventFilter(self)

    def copy(self):
        clip = self.maker()
        self.bus.remember(clip)
        QApplication.clipboard().setMimeData(self.bus.store.mime(clip))

    def paste(self):
        clip = self.bus.store.from_mime(QApplication.clipboard().mimeData())
        self.bus.remember(clip)
        self.receiver(clip)

    def menu(self,pos):
        menu = QMenu(self.widget)
        from .pen_bar import menu_style
        menu.setStyleSheet(menu_style())
        send_menu(menu,self.bus,self.maker,self.context)
        menu.addSeparator()
        menu.addAction("复制素材 Ctrl+C",self.copy)
        menu.addAction("粘贴素材 Ctrl+V",self.paste)
        menu.addAction("打开素材篮",self.bus.basket_requested.emit)
        if self.origin:
            value = self.origin()
            if value:
                menu.addAction("回到素材来源",lambda:self.bus.origin_requested.emit(value))
        menu.addAction("拖放提示：按住 Shift 拖动画布发送素材").setEnabled(False)
        menu.exec(pos)

    def eventFilter(self,watched,event):  # noqa: N802
        try:
            kind = event.type()
            if kind == QEvent.Type.ContextMenu:
                self.menu(event.globalPos())
                return True
            if kind == QEvent.Type.MouseButtonPress:
                if event.button()==Qt.MouseButton.RightButton and callable(getattr(watched,"prev",None)):
                    return True
                if event.button()==Qt.MouseButton.LeftButton and event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                    self.drag_start = event.position()
                    return True
            elif kind == QEvent.Type.MouseMove and self.drag_start is not None:
                if (event.position()-self.drag_start).manhattanLength()>=QApplication.startDragDistance():
                    self.drag_start = None
                    clip = self.maker()
                    self.bus.remember(clip)
                    drag = QDrag(watched)
                    drag.setMimeData(self.bus.store.mime(clip))
                    drag.setPixmap(QPixmap.fromImage(self.bus.store.render(clip)).scaledToWidth(180,Qt.TransformationMode.SmoothTransformation))
                    drag.exec(Qt.DropAction.CopyAction)
                return True
            elif kind == QEvent.Type.MouseButtonRelease and self.drag_start is not None:
                self.drag_start = None
                return True
            elif kind == QEvent.Type.KeyPress and event.modifiers() & Qt.KeyboardModifier.ControlModifier:
                if event.key()==Qt.Key.Key_C:
                    self.copy()
                    return True
                if event.key()==Qt.Key.Key_V:
                    self.paste()
                    return True
            elif kind in (QEvent.Type.DragEnter,QEvent.Type.DragMove):
                mime = event.mimeData()
                if mime.hasFormat("application/x-jw-palette"):
                    return False
                if mime.hasFormat(MIME) or mime.hasImage() or mime.hasText():
                    event.acceptProposedAction()
                    return True
            elif kind == QEvent.Type.Drop:
                if event.mimeData().hasFormat("application/x-jw-palette"):
                    return False
                clip = self.bus.store.from_mime(event.mimeData())
                self.bus.remember(clip)
                self.receiver(clip)
                event.acceptProposedAction()
                return True
        except (OSError,ValueError,KeyError,TypeError) as exc:
            self.bus.error.emit(str(exc))
            return True
        return False


class MaterialList(QListWidget):
    def startDrag(self,actions):  # noqa: N802
        item = self.currentItem()
        if item is None:
            return
        owner = self.parentWidget()
        try:
            clip = owner.bus.store.load(item.data(Qt.ItemDataRole.UserRole))
        except (OSError,ValueError,KeyError) as exc:
            owner.status.setText(str(exc))
            return
        drag = QDrag(self)
        drag.setMimeData(owner.bus.store.mime(clip))
        drag.exec(Qt.DropAction.CopyAction)


class MaterialBasket(QFrame):
    def __init__(self,bus,parent):
        super().__init__(parent)
        self.bus,self.dirty = bus,True
        self.setObjectName("materialBasket")
        self.setFixedWidth(300)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14,12,14,12)
        layout.setSpacing(10)
        row = QHBoxLayout()
        title = QLabel("素材篮")
        title.setObjectName("basketTitle")
        row.addWidget(title)
        hint = QLabel("最近 30 项")
        hint.setObjectName("basketNote")
        row.addWidget(hint,1)
        button = QPushButton("收起")
        button.clicked.connect(self.hide)
        row.addWidget(button)
        layout.addLayout(row)
        self.list = MaterialList(self)
        self.list.setDragEnabled(True)
        self.list.itemDoubleClicked.connect(self.menu)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(lambda _p:self.menu())
        layout.addWidget(self.list,1)
        row = QHBoxLayout()
        for title,fn in (("发送",self.menu),("固定 / 取消",self.pin),("复制",self.copy)):
            button = QPushButton(title)
            button.clicked.connect(fn)
            row.addWidget(button)
        layout.addLayout(row)
        self.status = QLabel("双击发送；可拖到黑板、课件或工作台")
        self.status.setObjectName("basketNote")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        bus.changed.connect(self.mark_dirty)
        bus.error.connect(self.status.setText)
        self.apply_theme()
        parent.installEventFilter(self)
        self.hide()

    def eventFilter(self,watched,event):  # noqa: N802
        if event.type()==QEvent.Type.Resize and self.isVisible():
            self.setGeometry(max(0,watched.width()-300),0,300,watched.height())
        return False

    def apply_theme(self):
        self.setStyleSheet(qss()+f"QFrame#materialBasket{{background:{T.surface};border:none;border-left:1px solid {T.line2};}}QLabel#basketTitle{{font-size:15px;font-weight:700;}}QLabel#basketNote{{color:{T.muted};font-size:12px;}}")

    def mark_dirty(self):
        self.dirty = True
        if self.isVisible():
            self.refresh()

    def showEvent(self,event):  # noqa: N802
        super().showEvent(event)
        if self.parentWidget():
            self.setGeometry(max(0,self.parentWidget().width()-300),0,300,self.parentWidget().height())
        if self.dirty:
            self.refresh()
        self.raise_()

    def refresh(self):
        current = self.list.currentItem()
        selected = current.data(Qt.ItemDataRole.UserRole) if current else None
        self.list.clear()
        try:
            rows = self.bus.recent()
            for row in rows:
                try:
                    clip = self.bus.store.summary(row["id"])
                except (OSError,ValueError,KeyError):
                    continue
                origin = clip.get("origin",{}).get("type","剪贴板")
                title = (clip.get("text") or origin or clip["kind"]).replace("\n"," ")[:38]
                item = QListWidgetItem(("★ " if row.get("pinned") else "")+title+"\n"+origin)
                item.setData(Qt.ItemDataRole.UserRole,row["id"])
                self.list.addItem(item)
                if row["id"]==selected:
                    self.list.setCurrentItem(item)
            self.dirty = False
        except (OSError,ValueError,KeyError,TypeError) as exc:
            self.status.setText(str(exc))

    def selected(self):
        item = self.list.currentItem()
        try:
            return self.bus.store.load(item.data(Qt.ItemDataRole.UserRole)) if item else None
        except (OSError,ValueError,KeyError) as exc:
            self.status.setText(str(exc))
            return None

    def menu(self,*_args):
        clip = self.selected()
        if clip is None:
            return
        menu = QMenu(self)
        send_menu(menu,self.bus,lambda:clip)
        menu.addAction("回到来源",lambda:self.bus.origin_requested.emit(clip.get("origin",{})))
        menu.exec(self.mapToGlobal(self.rect().center()))

    def pin(self):
        clip = self.selected()
        if clip:
            row = next(x for x in self.bus.recent() if x["id"]==clip["id"])
            self.bus.pin(clip["id"],not row.get("pinned"))

    def copy(self):
        clip = self.selected()
        if clip:
            QApplication.clipboard().setMimeData(self.bus.store.mime(clip))
