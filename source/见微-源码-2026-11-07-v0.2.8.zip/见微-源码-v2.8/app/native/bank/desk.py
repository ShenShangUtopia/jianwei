"""习题台窗口（原生）：左题目列表，中间题面 + 图解 + 播放条，右侧解题路径 / 控件 / 补充材料。"""
from __future__ import annotations

from types import SimpleNamespace

import html as _html
import math
import time

from PySide6.QtCore import QEvent, Qt, QTimer
from PySide6.QtGui import QImage, QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import (QAbstractButton, QAbstractSlider, QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QScrollArea, QStackedWidget, QTextEdit, QVBoxLayout, QWidget)

from ..design import tokens
from ..design.tokens import RADIUS, T, qc
from ..design.widgets import IconButton, Segmented, TabBar, qss
from ..kit.ctx import Ctx
from ..kit.draw import D, G
from ..lab.studio import NavList
from .data import SUBJECTS, bank, compare_answer
from .fx import fx
from .graph import lab_question
from .study import Stars, hint_html, match_card, related_to_card
from .tools import BuilderDialog, HelpDialog, ImportDialog
from .views import safe_mount

SPEEDS = (0.6, 1.0, 1.6)
BASE_MS = 2800
SUBJ_KEY = {"数学": "math", "物理": "phys", "化学": "chem", "生物": "bio"}


def _row(q):
    return ("item", SimpleNamespace(id=q["id"], title=q.get("title") or (q.get("stem") or "")[:18], unit=f"{q.get('subject', '')} · {q.get('paper', '')} · {q.get('type', '')}"))


class StepList(QWidget):
    """解题路径：一列可点的步骤（QLabel 富文本折行，当前步高亮）。"""

    def __init__(self, on_pick):
        super().__init__()
        self.on_pick = on_pick
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(14, 12, 14, 12)
        self.lay.setSpacing(6)
        self.rows: list[QPushButton] = []

    def set_steps(self, steps):
        while self.lay.count():
            w = self.lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        self.rows = []
        for i, s in enumerate(steps):
            text = s if isinstance(s, str) else (s.get("text") or s.get("title") or "")
            lb = _StepRow(i, text, self.on_pick)
            self.lay.addWidget(lb)
            self.rows.append(lb)
        if not steps:
            n = QLabel("这道题没有分步讲解。")
            n.setObjectName("note")
            self.lay.addWidget(n)
        self.lay.addStretch(1)

    def set_current(self, i):
        for k, r in enumerate(self.rows):
            r.set_state(k == i, k < i)


class _StepRow(QLabel):
    def __init__(self, i, text, on_pick):
        super().__init__()
        self.i, self.raw, self.on_pick = i, text, on_pick
        self.setWordWrap(True)
        self.setTextFormat(Qt.TextFormat.RichText)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setContentsMargins(10, 7, 10, 7)
        self.set_state(False, False)

    def set_state(self, cur, done):
        col = T.fg if cur else T.soft if done else T.muted
        self.setText(f"<span style='color:{qc(T.accent if cur else T.faint).name()};font-weight:700'>{self.i + 1}</span>&nbsp;&nbsp;<span style='color:{qc(col).name()}'>{fx(self.raw)}</span>")
        self.setStyleSheet(f"QLabel{{background:{tokens.css(T.accent, 0.1) if cur else 'transparent'};border-radius:8px;border-left:3px solid {qc(T.accent).name() if cur else 'transparent'};}}")

    def mousePressEvent(self, _e):  # noqa: N802
        self.on_pick(self.i)


class Desk(QWidget):
    def __init__(self, theme="day"):
        super().__init__()
        self.setObjectName("jw2")
        self.setWindowTitle("见微 · 习题台")
        self.resize(1360, 860)
        tokens.set_theme(theme)
        bank.load()
        self.subj = "全部"
        self.cur = None
        self.ctx = None
        self.view = None
        self.step = 0
        self.speed = 1.0
        self.touched = False
        self.play_timer = QTimer(self)
        self.play_timer.setSingleShot(True)
        self.play_timer.timeout.connect(self._tick_play)
        self.auto_timer = QTimer(self)   # 打开题目后稍等再自动讲解；人一动手就取消
        self.auto_timer.setSingleShot(True)
        self.auto_timer.timeout.connect(self._auto_play)
        self.playing = False
        self.stars = Stars()
        self.star_mode = False
        self.hint_level = 0
        self.guide_timer = QTimer(self)   # 播放时让引导圈跳动
        self.guide_timer.setInterval(40)
        self.guide_timer.timeout.connect(lambda: self.ctx.stage.update() if self.ctx else None)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._top())
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._rail())
        body.addWidget(self._center(), 1)
        body.addWidget(self._side())
        root.addLayout(body, 1)
        QShortcut(QKeySequence("Ctrl+F"), self, activated=lambda: self.search.setFocus())
        QShortcut(QKeySequence("Ctrl+Right"), self, activated=lambda: self.next_step())
        QShortcut(QKeySequence("Ctrl+Left"), self, activated=lambda: self.prev_step())
        QShortcut(QKeySequence("Ctrl+E"), self, activated=self.export_png)
        from PySide6.QtWidgets import QApplication
        QApplication.instance().installEventFilter(self)
        self.apply_theme()
        self.refresh_list()
        if bank.questions:
            self.open(bank.questions[0]["id"])

    # ---- 结构
    def _top(self):
        bar = QFrame()
        bar.setObjectName("topbar")
        bar.setFixedHeight(54)
        h = QHBoxLayout(bar)
        h.setContentsMargins(16, 0, 12, 0)
        h.setSpacing(10)
        b = QLabel("见微")
        b.setObjectName("brand")
        s = QLabel("习题台")
        s.setObjectName("brandSub")
        h.addWidget(b)
        h.addWidget(s)
        h.addSpacing(18)
        self.subj_bar = Segmented([(x, x) for x in SUBJECTS], "全部")
        self.subj_bar.changed.connect(self.set_subj)
        h.addWidget(self.subj_bar)
        h.addStretch(1)
        self.count = QLabel()
        self.count.setObjectName("brandSub")
        h.addWidget(self.count)
        self.search = QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("搜索题目、知识点…（Ctrl+F）")
        self.search.setFocusPolicy(Qt.FocusPolicy.ClickFocus)   # 打开窗口时焦点别落在输入框，否则快捷键要先点一下才有用
        self.search.setMinimumWidth(130)
        self.search.setMaximumWidth(240)
        self.search.textChanged.connect(lambda _t: self.refresh_list())
        h.addWidget(self.search)
        self.theme_btn = IconButton("moon", "切换昼 / 夜", 32)
        self.theme_btn.clicked.connect(lambda: (tokens.set_theme("day" if T.dark else "night"), self.apply_theme()))
        h.addWidget(self.theme_btn)
        return bar

    def _rail(self):
        box = QFrame()
        box.setObjectName("drawer")
        box.setFixedWidth(270)
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 8, 0, 0)
        v.setSpacing(6)
        tools = QHBoxLayout()
        tools.setContentsMargins(10, 0, 10, 0)
        tools.setSpacing(4)
        self.star_chip = self._btn("错题本", lambda: self.set_star_mode(not self.star_mode), tip="只看标过的错题")
        self.star_chip.setCheckable(True)
        tools.addWidget(self.star_chip, 1)
        tools.addWidget(self._btn("实验室", lambda: self.open_q(lab_question()), tip="变换实验室：选函数族，看平移、伸缩、旋转"), 1)
        tools.addWidget(self._btn("导入", self.show_import, tip="粘贴题目（I）"), 1)
        tools.addWidget(self._btn("搭建", self.show_builder, tip="物理场景搭建器（B）"), 1)
        v.addLayout(tools)
        self.nav = NavList()
        self.nav.picked.connect(self.pick_row)
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setWidget(self.nav)
        v.addWidget(sc)
        return box

    def _center(self):
        page = QWidget()
        ev = QVBoxLayout(page)
        ev.setContentsMargins(18, 12, 14, 12)
        ev.setSpacing(8)
        self.meta = QLabel()
        self.meta.setObjectName("note")
        self.title = QLabel()
        self.title.setTextFormat(Qt.TextFormat.RichText)
        self.stem = QLabel()
        self.stem.setWordWrap(True)
        self.stem.setTextFormat(Qt.TextFormat.RichText)
        self.stem.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        ev.addWidget(self.meta)
        ev.addWidget(self.title)
        ev.addWidget(self.stem)
        self.stage_host = QFrame()
        self.stage_host.setObjectName("stageHost")
        self.stage_lay = QVBoxLayout(self.stage_host)
        self.stage_lay.setContentsMargins(1, 1, 1, 1)
        ev.addWidget(self.stage_host, 1)
        ev.addWidget(self._player())
        ev.addWidget(self._foot())
        return page

    def _btn(self, text, cb, pri=False, tip=""):
        b = QPushButton(text)
        b.setObjectName("pri" if pri else "btn")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        if tip:
            b.setToolTip(tip)
        b.clicked.connect(lambda _=False: cb())
        return b

    def _player(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        self.prev_btn = self._btn("‹ 上一步", self.prev_step, tip="Ctrl+←")
        self.play_btn = self._btn("播放讲解", self.toggle_play, True)
        self.next_btn = self._btn("下一步 ›", self.next_step, tip="Ctrl+→")
        self.replay_btn = self._btn("重播", self.replay)
        self.speed_btn = self._btn("1×", self.cycle_speed, tip="播放速度")
        self.export_btn = self._btn("导出 PNG", self.export_png, tip="把当前画面存成图片（Ctrl+E）")
        self.step_info = QLabel()
        self.step_info.setObjectName("note")
        self.step_text = QLabel()
        self.step_text.setObjectName("note")
        self.step_text.setWordWrap(False)
        for x in (self.prev_btn, self.play_btn, self.next_btn, self.replay_btn, self.speed_btn, self.step_info):
            h.addWidget(x)
        h.addStretch(1)
        h.addWidget(self.export_btn)
        self.player_box = w
        return w

    def _foot(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.ans_btn = self._btn("显示答案", self.toggle_answer, True)
        self.mine = QLineEdit()
        self.mine.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.mine.setPlaceholderText("先写自己的答案，可只写数")
        self.mine.returnPressed.connect(self.check_answer)
        self.check_out = QLabel()
        self.check_out.setObjectName("note")
        row.addWidget(self.ans_btn)
        row.addWidget(self.mine, 1)
        row.addWidget(self._btn("对照", self.check_answer))
        row.addWidget(self.check_out)
        self.hint_btns = []
        for i, nm in enumerate(("审题", "方法", "关键一步")):
            b = self._btn(f"提示 {i + 1}", lambda n=i + 1: self.toggle_hint(n), tip=f"第 {i + 1} 级：{nm}")
            b.setCheckable(True)
            self.hint_btns.append(b)
            row.addWidget(b)
        v.addLayout(row)
        self.hint_box = QLabel()
        self.hint_box.setWordWrap(True)
        self.hint_box.setTextFormat(Qt.TextFormat.RichText)
        self.hint_box.setVisible(False)
        v.addWidget(self.hint_box)
        self.answer = QLabel()
        self.answer.setWordWrap(True)
        self.answer.setTextFormat(Qt.TextFormat.RichText)
        self.answer.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.answer.setVisible(False)
        v.addWidget(self.answer)
        return w

    def _side(self):
        box = QFrame()
        box.setObjectName("sidebar")
        box.setFixedWidth(340)
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        self.star_btn = self._btn("标为错题", self.toggle_star, tip="S")
        self.star_btn.setCheckable(True)
        wrap = QWidget()
        wh = QHBoxLayout(wrap)
        wh.setContentsMargins(14, 8, 14, 4)
        wh.addWidget(self.star_btn)
        v.addWidget(wrap)
        self.tabs = TabBar(["解题路径", "控件", "补充"])
        v.addWidget(self.tabs)
        self.side_stack = QStackedWidget()
        self.tabs.changed.connect(self.side_stack.setCurrentIndex)
        self.steps = StepList(self.set_step)
        s1 = QScrollArea()
        s1.setWidgetResizable(True)
        s1.setWidget(self.steps)
        self.side_stack.addWidget(s1)
        self.panel_scroll = QScrollArea()
        self.panel_scroll.setWidgetResizable(True)
        self.panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.side_stack.addWidget(self.panel_scroll)
        self.extra = QWidget()
        self.extra_lay = QVBoxLayout(self.extra)
        self.extra_lay.setContentsMargins(16, 12, 16, 12)
        self.extra_lay.setSpacing(8)
        s3 = QScrollArea()
        s3.setWidgetResizable(True)
        s3.setWidget(self.extra)
        self.side_stack.addWidget(s3)
        v.addWidget(self.side_stack, 1)
        return box

    # ---- 主题
    def apply_theme(self):
        t = T
        self.setStyleSheet(qss() + f"""
QFrame#topbar {{ background:{t.surface}; border-bottom:1px solid {t.line}; }}
QFrame#drawer {{ background:{t.surface}; border-right:1px solid {t.line}; }}
QFrame#sidebar {{ background:{t.surface}; border-left:1px solid {t.line}; }}
QFrame#stageHost {{ background:{t.stage}; border:1px solid {t.line2}; border-radius:{RADIUS['md']}px; }}
QLabel#brand {{ font-size:17px; font-weight:700; letter-spacing:2px; color:{t.fg}; }}
QLabel#brandSub {{ font-size:12px; color:{t.muted}; letter-spacing:1px; padding-top:3px; }}
QLineEdit#search {{ padding:5px 10px; background:{t.bg}; }}
""")
        self.theme_btn.icon = "sun" if T.dark else "moon"
        self.update()
        if self.cur:
            self._fill_text()
            self.steps.set_current(self.step)
        if self.ctx:
            self.ctx.draw()

    # ---- 列表
    def set_subj(self, s):
        self.subj = s
        self.refresh_list()

    def refresh_list(self):
        qt = self.search.text().strip()
        lst = [q for q in bank.questions if (self.subj == "全部" or q.get("subject") == self.subj) and (not qt or bank.match(q, qt)) and (not self.star_mode or self.stars.has(q["id"]))]
        rows = []
        for y in sorted({q.get("year") for q in lst}, key=lambda v: -(v or 0)):
            rows.append(("head", f"{y} 年"))
            rows += [_row(q) for q in lst if q.get("year") == y]
        if not rows:
            rows.append(("head", "错题本还是空的：打开一道题，点右上角「标为错题」。" if self.star_mode else "没有符合条件的题目"))
        self.nav.set_rows(rows, self.cur["id"] if self.cur else None)
        ys = [q["year"] for q in bank.questions if (q.get("year") or 0) > 2000]
        self.count.setText(f"{len(bank.questions)} 题" + (f" · {min(ys)}—{max(ys)}" if ys else ""))

    # ---- 打开一道题
    def _close_view(self):
        self.pause()
        if self.ctx:
            self.ctx.dispose()
            self.ctx.stage.setParent(None)
            self.ctx.stage.deleteLater()
            self.ctx = None
            self.view = None

    def _fill_text(self):
        q = self.cur
        self.meta.setText(" · ".join(str(x) for x in (f"{q.get('year')} 年" if q.get("year") else None, q.get("paper"), q.get("subject"), q.get("type")) if x))
        self.title.setText(f"<span style='font-size:19px;font-weight:700;color:{qc(T.fg).name()}'>{q.get('title') or ''}</span>")
        self.stem.setText(f"<span style='color:{qc(T.soft).name()};font-size:13.5px'>{fx(q.get('stem') or '')}</span>")
        self.answer.setText(f"<span style='color:{qc(T.fg).name()};font-size:13.5px'><b>答案</b>　{fx(q.get('answer') or '')}</span>")
        self.paint_hints()

    def open(self, qid):
        q = bank.by_id.get(qid)
        if q:
            self.open_q(q)

    def open_q(self, q):
        """打开一道题（题库里的，或自定义函数、知识块这种临时题）。"""
        self._close_view()
        self.cur = q
        self.step = 0
        self.touched = False
        k = SUBJ_KEY.get(q.get("subject"))
        tokens.set_subject(k or "math")
        self._fill_text()
        self.answer.setVisible(False)
        self.ans_btn.setText("显示答案")
        self.hint_level = 0
        self.paint_hints()
        self.paint_star()
        self.mine.clear()
        self.check_out.setText("")
        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(18, 12, 18, 18)
        pv.setSpacing(4)
        self.ctx = Ctx(self.stage_host, panel)
        self.ctx.open_question = self.open_q
        self.stage_lay.addWidget(self.ctx.stage)
        self.ctx.stage.show()
        self.view, err = safe_mount(self.ctx, q)
        if err:
            self.ctx.stage.error = err
        pv.addStretch(1)
        self.panel_scroll.setWidget(panel)
        self.ctx.stage.overlays.append(self._draw_guide)
        self._wrap_touch()
        self.steps.set_steps(q.get("steps") or [])
        self.player_box.setVisible(bool(q.get("steps")))
        self._fill_extra(q)
        self.apply_theme()
        self.refresh_list()
        self.set_step(0)
        if len(q.get("steps") or []) >= 3:   # 一碰画面就交还给人
            self.auto_timer.start(900)

    def _wrap_touch(self):
        """碰画布 = 自己看：暂停自动播放。"""
        st = self.ctx.stage
        inner = st.mouse

        def handler(kind, e):
            if kind == "down":
                self.touched = True
                self.pause()
            if inner:
                inner(kind, e)
        st.mouse = handler

    def _auto_play(self):
        if not self.touched and self.cur:
            self.play()

    def _fill_extra(self, q):
        lay = self.extra_lay
        while lay.count():
            w = lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        def head(t):
            h = QLabel(t)
            h.setObjectName("grpTitle")
            lay.addWidget(h)

        def para(t):
            n = QLabel(t)
            n.setWordWrap(True)
            n.setTextFormat(Qt.TextFormat.RichText)
            n.setObjectName("note")
            lay.addWidget(n)
        head("知识点（点开看知识卡）")
        pts = [str(p) for p in q.get("points") or []]
        for pt in pts:
            lay.addWidget(self._btn(pt, lambda t=pt: self.open_card(t)))
        if not pts:
            lay.addWidget(self._btn("通用审题卡", lambda: self.open_card("")))
        head("为什么这样想")
        para(fx(q.get("why") or "—"))
        if q.get("note"):
            head("说明")
            para(q["note"])
        head("同类题")
        rel = bank.related(q)
        for x in rel:
            lay.addWidget(self._btn(f"{x.get('subject')} · {x.get('title')}", lambda i=x["id"]: self.open(i)))
        if not rel:
            para("暂时没有同类题。")
        lay.addStretch(1)

    # ---- 知识卡（占用「补充」页，有返回）
    def open_card(self, text):
        c = match_card(text)
        lay = self.extra_lay
        while lay.count():
            w = lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        def para(t, obj="note", rich=True):
            n = QLabel(t)
            n.setWordWrap(True)
            n.setObjectName(obj)
            n.setTextFormat(Qt.TextFormat.RichText if rich else Qt.TextFormat.PlainText)
            lay.addWidget(n)
        lay.addWidget(self._btn("‹ 返回", lambda: self._fill_extra(self.cur)))
        para(f"知识卡 · {c.get('s') or '通用'}")
        name = QLabel(f"<span style='font-size:17px;font-weight:700;color:{qc(T.fg).name()}'>{_html.escape(c['n'])}</span>")
        lay.addWidget(name)
        n = QLabel(f"<span style='color:{qc(T.fg).name()}'>{fx(c['d'])}</span>")
        n.setWordWrap(True)
        lay.addWidget(n)
        para("常见公式 / 结论", "grpTitle")
        for t in c.get("f") or ["这张卡没有固定公式，按定义与审题顺序走。"]:
            para(f"<span style='color:{qc(T.fg).name()}'>{fx(t)}</span>")
        para("两个常见坑", "grpTitle")
        for i, t in enumerate(c.get("p") or []):
            para(f"{i + 1}. {fx(t)}")
        lst = related_to_card(c, text, self.cur)
        para(f"用这个知识点的题 · {len(lst)} 题", "grpTitle")
        for q in lst[:10]:
            lay.addWidget(self._btn(f"{q.get('subject', '')} · {q.get('title') or (q.get('stem') or '')[:18]}", lambda i=q["id"]: self.open(i)))
        if not lst:
            para("题库里暂时没有直接考它的题，先把公式和两个坑记住。")
        lay.addStretch(1)
        self.tabs.set_current(2) if hasattr(self.tabs, "set_current") else None
        self.side_stack.setCurrentIndex(2)

    # ---- 错题本与提示
    def paint_star(self):
        q = self.cur
        on = bool(q and self.stars.has(q["id"]))
        self.star_btn.setChecked(on)
        self.star_btn.setText(f"{'已标错题 · 点击取消' if on else '标为错题'}　{len(self.stars.ids)}")
        self.star_chip.setChecked(self.star_mode)
        self.star_chip.setText(f"错题本 {len(self.stars.ids)}")

    def toggle_star(self):
        if self.cur:
            self.stars.toggle(self.cur["id"])
            self.paint_star()
            if self.star_mode:
                self.refresh_list()

    def set_star_mode(self, on):
        self.star_mode = bool(on)
        self.paint_star()
        self.refresh_list()

    def pick_row(self, qid):
        self.open(qid)

    def toggle_hint(self, n):
        self.hint_level = 0 if self.hint_level == n else n
        self.paint_hints()

    def paint_hints(self):
        for i, b in enumerate(self.hint_btns):
            b.setChecked(i + 1 <= self.hint_level)
        txt = hint_html(self.hint_level, self.cur, qc(T.accent).name(), qc(T.muted).name())
        self.hint_box.setText(f"<div style='color:{qc(T.fg).name()};font-size:13px'>{txt}</div>" if txt else "")
        self.hint_box.setVisible(bool(txt))

    # ---- 工具
    def _adopt(self, q):
        bank.add_imported(q)
        self.refresh_list()
        self.open(q["id"])

    def show_import(self):
        ImportDialog(self, self._adopt).exec()

    def show_builder(self):
        BuilderDialog(self, self.open_q).exec()
        bank.load_built()
        self.refresh_list()

    def compose_png(self):
        """画面 + 题头 + 当前步骤，拼成一张能直接发出去的图。"""
        st = self.ctx.stage
        pix = st.grab()
        W, H = pix.width(), pix.height()
        head, foot = 74, 46
        img = QImage(W, H + head + foot, QImage.Format.Format_RGB32)
        img.fill(qc(T.stage))
        p = QPainter(img)
        g = G(p)
        q = self.cur
        D.text(g, q.get("title") or "", 18, 26, T.fg, size=18, bold=True)
        D.text(g, " · ".join(str(x) for x in (q.get("year"), q.get("paper"), q.get("subject"), q.get("type")) if x), 18, 54, T.muted, size=12)
        p.drawPixmap(0, head, pix)
        steps = q.get("steps") or []
        s = steps[self.step] if self.step < len(steps) else ""
        s = s if isinstance(s, str) else (s.get("text") or s.get("title") or "")
        D.text(g, f"第 {self.step + 1} / {len(steps)} 步　{s}" if steps else "", 18, H + head + 18, T.fg, size=13)
        D.text(g, "见微", W - 18, H + head + 32, T.muted, size=11, align="right")
        p.end()
        return img

    def export_png(self):
        if not self.ctx or not self.cur:
            return None
        import re
        name = re.sub(r'[\\/:*?"<>|\s]+', "-", self.cur.get("title") or "见微")
        path, _f = QFileDialog.getSaveFileName(self, "导出 PNG", f"{name}.png", "PNG 图片 (*.png)")
        if path:
            self.compose_png().save(path)
        return path

    def eventFilter(self, obj, e):  # noqa: N802
        """全局快捷键：正在打字时不抢键。"""
        if e.type() != QEvent.Type.KeyPress or not self.isVisible() or not self.isActiveWindow():
            return False
        from PySide6.QtWidgets import QApplication
        fw = QApplication.focusWidget()
        k, mods = e.key(), e.modifiers()
        if k == Qt.Key.Key_Escape:
            if isinstance(fw, QLineEdit):
                fw.clearFocus()
                return True
            if self.cur:
                self._fill_extra(self.cur)
            return False
        if isinstance(fw, (QLineEdit, QTextEdit, QPlainTextEdit, QComboBox)) or mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier):
            return False
        if isinstance(fw, QAbstractSlider) and k in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            return False
        if isinstance(fw, QAbstractButton) and k == Qt.Key.Key_Space:
            return False
        t = e.text()
        act = {Qt.Key.Key_Left: self.prev_step, Qt.Key.Key_Right: self.next_step, Qt.Key.Key_Space: self.toggle_play}.get(k)
        if k == Qt.Key.Key_Space and getattr(self.view, "scene", None):
            act = None   # 物理题的空格归时间轴
        if act is None:
            act = {"r": self.replay, "a": self.toggle_answer, "s": self.toggle_star, "i": self.show_import, "b": self.show_builder, "?": lambda: HelpDialog(self).exec(),
                   "1": lambda: self.toggle_hint(1), "2": lambda: self.toggle_hint(2), "3": lambda: self.toggle_hint(3)}.get(t.lower())
        if act:
            act()
            return True
        return False

    # ---- 步骤与播放
    def n_steps(self):
        return len((self.cur or {}).get("steps") or [])

    def set_step(self, i):
        n = self.n_steps()
        self.step = max(0, min(i, max(0, n - 1)))
        self.steps.set_current(self.step)
        self.step_info.setText(f"{self.step + 1} / {n}" if n else "")
        if self.view:
            try:
                self.view.apply_step(self.step)
            except Exception as exc:  # noqa: BLE001
                self.ctx.stage.error = f"{type(exc).__name__}: {exc}"

    def next_step(self):
        self.pause()
        self.set_step(self.step + 1)

    def prev_step(self):
        self.pause()
        self.set_step(self.step - 1)

    def replay(self):
        self.set_step(0)
        self.play()

    def play(self):
        if self.n_steps() < 2:
            return
        if self.step >= self.n_steps() - 1:
            self.set_step(0)
        self.playing = True
        self.play_btn.setText("暂停")
        self.play_timer.start(int(BASE_MS / self.speed))
        self.guide_timer.start()

    def pause(self):
        self.playing = False
        self.play_timer.stop()
        self.auto_timer.stop()
        self.guide_timer.stop()
        self.play_btn.setText("播放讲解")
        if self.ctx:
            self.ctx.stage.update()

    def toggle_play(self):
        self.pause() if self.playing else self.play()

    def _tick_play(self):
        if not self.playing:
            return
        if self.step >= self.n_steps() - 1:
            self.pause()
            return
        self.set_step(self.step + 1)
        self.play_timer.start(int(BASE_MS / self.speed))

    def cycle_speed(self):
        self.speed = SPEEDS[(SPEEDS.index(self.speed) + 1) % len(SPEEDS)]
        self.speed_btn.setText(f"{self.speed:g}×")

    def _draw_guide(self, g):
        """引导层：播放时把当前步骤写到画面上；视图给出 focus(i) 就在图上圈出来。"""
        if not self.playing or not self.cur:
            return
        steps = self.cur.get("steps") or []
        fn = getattr(self.view, "focus", None)
        f = fn(self.step) if fn else None
        if f:
            k = (math.sin(time.perf_counter() * 4) + 1) / 2
            D.circle(g, f["x"], f["y"], f.get("r", 20) + 5 * k, None, T.accent, 2)
        if self.step < len(steps):
            s = steps[self.step]
            s = s if isinstance(s, str) else (s.get("text") or s.get("title") or "")
            w = self.ctx.stage.width()
            import re
            s = re.sub(r"\\[a-z]+|[{}]", "", s)
            # 函数图右下角有一排视野键：提示条靠左放，长句截断，不压按钮
            engine = (self.cur or {}).get("view", {}).get("engine") if isinstance(self.cur, dict) else None
            room = w - 24 - (280 if engine == "graph" else 0)
            if D.measure(s, 13) + 56 > room:
                while s and D.measure(s + "…", 13) + 56 > room:
                    s = s[:-1]
                s += "…"
            tw = min(D.measure(s, 13) + 56, room)
            x0 = 12 if engine == "graph" else (w - tw) / 2
            y0 = self.ctx.stage.height() - (72 if getattr(self.view, "scene", None) else 46)
            D.rrect(g, x0, y0, tw, 30, 15, tokens.alpha(qc(T.fg), 0.86))
            D.text(g, str(self.step + 1), x0 + 18, y0 + 15, T.stage, size=12, bold=True, align="center")
            D.text(g, s, x0 + 34, y0 + 15, T.stage, size=13)

    # ---- 答案
    def toggle_answer(self):
        on = not self.answer.isVisible()
        self.answer.setVisible(on)
        self.ans_btn.setText("收起答案" if on else "显示答案")

    def check_answer(self):
        if self.cur:
            ok, msg = compare_answer(self.mine.text(), self.cur.get("answer"))
            self.check_out.setText(msg)
            self.check_out.setStyleSheet(f"color:{qc(T.ok if ok else T.bad).name()};")
