"""课件播放窗口：左边课件、右边黑板（可分屏、可只看一边、黑板可成独立窗口），底部工具条。

快捷键：← → / 空格 / PgUp PgDn 翻页；V 指针 P 笔 H 荧光笔 E 橡皮 S 框选；B 黑板；G 目录；Ctrl+Z 撤销；F11 全屏；Esc 一层层退出。
"""
from __future__ import annotations

import time

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QIcon, QImage, QPainter, QPixmap
from PySide6.QtPdf import QPdfDocument
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSplitter, QVBoxLayout, QWidget

from . import library, lookup
from .board import Board
from .panel import LookupPanel
from .pageview import PageView, render_page
from ..kit.pen_store import PenStore
from ..kit.pen_bar import PenBar
from ..design.icons import draw_icon
from ..design.tokens import T
from .transfer import LectureTransfer

ICON_NAMES = dict(prev="chevron_l", next="chevron_r", slide="lecture", split="side")
COLORS = ["#E5484D", "#2F6FED", "#16A34A", "#F59E0B", "#111418"]
WIDTHS = [("细", 2.0), ("中", 3.5), ("粗", 6.0)]


def svg_icon(name, color="#DCE5E0", size=20) -> QIcon:
    """放映条的图标（和全局图标同一套）。"""
    icon = QIcon()
    for k in (1, 2):
        pm = QPixmap(size * k, size * k)
        pm.setDevicePixelRatio(k)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        draw_icon(p, ICON_NAMES.get(name, name), QRectF(0, 0, size, size), QColor(color))
        p.end()
        icon.addPixmap(pm)
    return icon


# 放映时背景永远是深色：放映条用固定的墨绿仪表色，不跟昼夜主题走
BAR_QSS = """
QFrame#bar { background:rgba(13,21,18,0.96); border:1px solid #2E3F39; border-radius:9px; }
QFrame#bar QPushButton#t { background:transparent; border:none; border-radius:5px; padding:0; min-height:0; }
QFrame#bar QPushButton#t:hover { background:#22332E; }
QFrame#bar QPushButton#t:pressed { background:#18251F; }
QFrame#bar QPushButton#t:checked { background:#C8402A; border-bottom:1px solid #7E2616; }
QFrame#bar QPushButton#num { background:transparent; border:none; border-radius:5px; color:#E6EEE9; font-size:13px; font-family:'Bahnschrift','Microsoft YaHei UI'; padding:0 7px; min-height:0; }
QFrame#bar QPushButton#num:hover { background:#22332E; }
QFrame#sep { background:#2E3F39; }
QFrame#acts { background:rgba(13,21,18,0.98); border:1px solid #3A4C45; border-radius:8px; }
QFrame#acts QPushButton { background:#1B2925; color:#E6EEE9; border:1px solid #2E3F39; border-bottom:2px solid #0A100E; border-radius:5px; padding:5px 12px 4px 12px; font-size:12.5px; font-family:'Microsoft YaHei UI'; }
QFrame#acts QPushButton:hover { background:#263732; }
QFrame#acts QPushButton:pressed { border-bottom:1px solid #0A100E; margin-top:1px; }
QFrame#acts QPushButton#pri { background:#C8402A; border-color:#7E2616; color:white; font-weight:600; }
QFrame#acts QPushButton#pri:hover { background:#DA5238; }
QLabel#toast { background:rgba(13,21,18,0.97); color:#F2F6F4; border:1px solid #3A4C45; border-left:3px solid #C8402A; border-radius:4px; padding:8px 14px; font-size:13px; font-family:'Microsoft YaHei UI'; }
QListWidget#grid { background:rgba(10,15,13,0.97); border:none; color:#DCE5E0; font-family:'Microsoft YaHei UI'; outline:0; }
QListWidget#grid::item { padding:6px; border-radius:5px; }
QListWidget#grid::item:selected, QListWidget#grid::item:hover { background:#22332E; color:white; }
"""


class BoardWindow(QWidget):
    """独立的黑板窗口：放回时把黑板还给播放器。"""

    def __init__(self, player):
        super().__init__(player, Qt.WindowType.Window)
        self.player = player
        self.setWindowTitle("见微 · 黑板")
        self.setLayout(QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.setStyleSheet("background:#101A17;")

    def closeEvent(self, e):  # noqa: N802
        if not self.player.closing:
            QTimer.singleShot(0, self.player, self.player.reattach_board)
        e.accept()


class LecturePlayer(LectureTransfer,QWidget):
    def __init__(self, meta: dict, start_view: str = "slide", bus=None):
        super().__init__()
        self.meta = meta
        self.closing = False
        self.dir = library.folder(meta["id"])
        self.setWindowTitle(f"{meta.get('title', '')} - 见微")
        self.setObjectName("player")
        self.setStyleSheet("QWidget#player { background:#0A0F0D; }" + BAR_QSS)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.base_doc = QPdfDocument(self)
        self.base_doc.load(str(self.dir / "doc.pdf"))
        self.prepare_transfer(bus)
        self.ink_store = PenStore(self.dir / "ink.json", "ink")
        strokes = dict(self.ink_store.data["pages"])
        if meta.get("clip_id"):
            self.seed_ink[0] = self.clip_bus.store.load(meta["clip_id"]).get("ink",[])
        for key,seed in self.seed_ink.items():
            strokes.setdefault(str(key),seed)
        self.view = PageView(self.doc, meta.get("kind", "slides"), strokes, self.projected_timeline)
        self.board = Board(self.dir / "board")
        self.board.detach_toggled.connect(self.toggle_detach)
        self.detached = None
        self.ocr = lookup.Ocr()
        self.ocr.start()
        lookup.warm()
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setHandleWidth(5)
        self.split.setStyleSheet("QSplitter::handle { background:#22332E; } QSplitter::handle:hover { background:#C8402A; }")
        self.split.addWidget(self.view)
        self.split.addWidget(self.board)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.storage_notice = QLabel()
        self.storage_notice.setWordWrap(True)
        self.storage_notice.setStyleSheet(f"background:{T.surface};color:{T.bad};padding:8px 14px;border-bottom:1px solid {T.line};")
        self.storage_notice.hide()
        root.addWidget(self.storage_notice)
        h = QHBoxLayout()
        root.addLayout(h, 1)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(self.split)
        self.panel = LookupPanel(self.ocr)
        self.panel.setParent(self)
        self.panel.hide()
        self.panel.to_board.connect(self.text_to_board)
        self.panel.image_to_board.connect(self.image_to_board)
        self.panel.closed.connect(self.setFocus)
        self.toast_label = QLabel(self)
        self.toast_label.setObjectName("toast")
        self.toast_label.hide()
        self.toast_timer = QTimer(self)
        self.toast_timer.setSingleShot(True)
        self.toast_timer.timeout.connect(self.toast_label.hide)
        self.board.canvas.storage_error.connect(self.show_storage_error)
        protected = [s.error for s in (self.ink_store, self.board.canvas.store) if s.error]
        if protected:
            QTimer.singleShot(0, lambda: self.show_storage_error("；".join(protected)))
        self._build_bar()
        self._build_actions()
        self.bind_transfer()
        self.grid = None
        self.view.page_changed.connect(self._on_page)
        self.view.frame_changed.connect(self._sync_num)
        self.view.selected.connect(self._on_selected)
        self.view.ink_changed.connect(self._schedule_save)
        self.view.activity.connect(self._wake)
        self.saver = QTimer(self)
        self.saver.setSingleShot(True)
        self.saver.timeout.connect(self.save)
        self.idle = QTimer(self)
        self.idle.setSingleShot(True)
        self.idle.timeout.connect(self._maybe_hide_bar)
        self.view_mode = "slide"
        self.set_view(start_view)
        start = max(0, min(self.view.pages - 1, int(meta.get("page") or 0)))
        self.view.page, self.view.frame = start, self.view.slides[start]["first"]
        self._on_page(start)
        QTimer.singleShot(300, self.view, self.view.start)
        self.set_tool("pointer")
        library.update(meta["id"], opened=time.time())
        self.resize(1280, 760)

    # ---- 工具条
    def _tbtn(self, icon, tip, fn, check=False):
        b = QPushButton()
        b.setObjectName("t")
        b.setIcon(svg_icon(icon))
        b.setIconSize(QSize(20, 20))
        b.setFixedSize(34, 34)
        b.setToolTip(tip)
        b.setCheckable(check)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(fn)
        return b

    @staticmethod
    def _sep():
        s = QFrame()
        s.setObjectName("sep")
        s.setFixedSize(1, 22)
        return s

    def _build_bar(self):
        bar = QFrame(self)
        bar.setObjectName("bar")
        self.bar = bar
        h = QHBoxLayout(bar)
        h.setContentsMargins(8, 6, 8, 6)
        h.setSpacing(3)
        self.nav_group = []
        add = lambda w, grp=None: (h.addWidget(w), grp.append(w) if grp is not None else None)
        add(self._tbtn("prev", "上一页（←）", self.view.prev), self.nav_group)
        self.num_btn = QPushButton("1 / 1")
        self.num_btn.setObjectName("num")
        self.num_btn.setFixedHeight(34)
        self.num_btn.setToolTip("目录（G）")
        self.num_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.num_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.num_btn.clicked.connect(self.toggle_grid)
        add(self.num_btn, self.nav_group)
        add(self._tbtn("next", "下一页（→）", self.view.next), self.nav_group)
        add(self._sep(), self.nav_group)
        self.pen_bar = PenBar(self.view,self.view.pen_session,on_dark=True)
        add(self.pen_bar,self.nav_group)
        add(self._tbtn("trash", "清除这一页的笔迹", self.view.clear_page), self.nav_group)
        add(self._sep(), self.nav_group)
        self.views = {}
        for key, icon, tip in (("slide", "slide", "只看课件"), ("split", "split", "课件和黑板分屏"), ("board", "board", "只看黑板（B）")):
            b = self._tbtn(icon, tip, lambda _c=False, k=key: self.set_view(k), True)
            self.views[key] = b
            h.addWidget(b)
        h.addWidget(self._sep())
        h.addWidget(self._tbtn("close", "退出放映（Esc）", self.close))
        self.set_color(COLORS[0], False)
        self.set_width(WIDTHS[1][1])

    def _build_actions(self):
        f = QFrame(self)
        f.setObjectName("acts")
        h = QHBoxLayout(f)
        h.setContentsMargins(5, 5, 5, 5)
        h.setSpacing(3)
        for label, fn, pri, tip in (("带入黑板", self.selection_to_board, True, "把这块放到独立的黑板区域（Enter）"), ("上网查询", self.selection_search, True, "取出这块的文字上网查（Q）"), ("复制", self.selection_copy, False, "复制截图到剪贴板"), ("取消", self.view.clear_selection, False, "")):
            b = QPushButton(label)
            if pri:
                b.setObjectName("pri")
            b.setToolTip(tip)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(fn)
            h.addWidget(b)
        f.hide()
        self.acts = f

    # ---- 布局
    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        self._place()

    def _place(self):
        W, H = self.width(), self.height()
        self.bar.adjustSize()
        pw = min(450, max(320, W // 3)) if self.panel.isVisible() else 0
        room = W - pw   # 查询面板开着时，工具条只在剩下的地方居中，不被挡住
        bw = min(self.bar.sizeHint().width(), room - 16)
        self.bar.setGeometry((room - bw) // 2, H - self.bar.sizeHint().height() - 12, bw, self.bar.sizeHint().height())
        self.bar.raise_()
        if pw:
            self.panel.setGeometry(W - pw, 0, pw, H)
            self.panel.raise_()
        if self.grid is not None and self.grid.isVisible():
            self.grid.setGeometry(self.rect())
            self.grid.raise_()
        self._place_actions()

    def _place_actions(self):
        if self.view.sel is None or self.view_mode == "board":
            self.acts.hide()
            return
        v = self.view.view_rect(self.view.sel)
        o = self.view.mapTo(self, QPointF(0, 0).toPoint())
        self.acts.adjustSize()
        aw, ah = self.acts.width(), self.acts.height()
        x = o.x() + v.right() - aw
        y = o.y() + v.bottom() + 8
        bar_top = self.bar.y() if self.bar.isVisible() else self.height()
        if y + ah > bar_top - 4:
            y = o.y() + v.top() - ah - 8
        if y < 4:
            y = o.y() + v.bottom() - ah - 8
        x = max(6, min(self.width() - aw - 6, x))
        self.acts.move(int(x), int(y))
        self.acts.show()
        self.acts.raise_()

    def toast(self, text, ms=2200):
        self.toast_label.setText(text)
        self.toast_label.adjustSize()
        self.toast_label.move((self.width() - self.toast_label.width()) // 2, 58)
        self.toast_label.show()
        self.toast_label.raise_()
        self.toast_timer.start(ms)

    # ---- 状态
    def set_tool(self, k):
        self.view.set_tool(k)
        self.pen_bar.sync()
        self._wake()

    def set_color(self, c, switch=True):
        self.view.color = c
        self.pen_bar.sync()
        if switch and self.view.tool not in ("pen", "marker"):
            self.set_tool("pen")

    def set_width(self, w):
        self.view.width_px = w
        self.pen_bar.sync()

    def set_view(self, mode):
        if self.detached is not None and mode != "slide":
            self.toast("黑板在独立窗口里")
            mode = "slide"
        self.view_mode = mode
        self.view.setVisible(mode in ("slide", "split"))
        self.board.setVisible(mode in ("split", "board") or self.detached is not None)
        if self.detached is None:
            self.board.setVisible(mode in ("split", "board"))
        if mode == "split":
            total = max(2, self.split.width())
            self.split.setSizes([total // 2, total - total // 2])
        for key, b in self.views.items():
            b.setChecked(key == mode)
        for w in self.nav_group:
            w.setVisible(mode != "board")
        self.bar.adjustSize()
        self._place()
        self._wake()
        QTimer.singleShot(0, self, self._place)

    def toggle_detach(self):
        if self.detached is None:
            self.detach_board()
        else:
            self.reattach_board()

    def detach_board(self):
        w = BoardWindow(self)
        self.board.setParent(None)
        w.layout().addWidget(self.board)
        self.board.show()
        self.detached = w
        self.board.set_detached(True)
        screens = QGuiApplication.screens()
        mine = self.screen()
        other = next((s for s in screens if s is not mine), None)
        if other is not None:
            w.setGeometry(other.geometry())
            w.showFullScreen()
        else:
            r = self.screen().availableGeometry()
            w.setGeometry(r.x() + r.width() // 5, r.y() + r.height() // 8, r.width() * 3 // 5, r.height() * 3 // 4)
            w.show()
        w.raise_()
        self.set_view("slide")

    def reattach_board(self):
        w, self.detached = self.detached, None
        if w is None:
            return
        self.board.setParent(None)
        self.split.addWidget(self.board)
        self.board.set_detached(False)
        w.close()
        w.deleteLater()
        self.set_view("split")

    def _sync_num(self):
        v = self.view
        sl = v.slides[v.page]
        steps = sl["last"] - sl["first"]
        extra = f"  ·  动画 {v.frame - sl['first']}/{steps}" if steps else ""
        self.num_btn.setText(f"{v.page + 1} / {v.pages}{extra}")
        self.bar.adjustSize()
        self._place()

    def _on_page(self, i):
        self._sync_num()
        library.update(self.meta["id"], page=i)
        self.acts.hide()
        self._wake()

    def _on_selected(self, rect):
        if rect.isEmpty():
            self.acts.hide()
        else:
            self._place_actions()

    def _wake(self):
        if not self.bar.isVisible():
            self.bar.show()
            self._place()
        if self.view_mode == "slide" and self.view.tool == "pointer" and self.detached is None:
            self.idle.start(3000)
        else:
            self.idle.stop()

    def _maybe_hide_bar(self):
        if self.view_mode == "slide" and self.view.tool == "pointer" and not self.bar.underMouse():
            self.bar.hide()

    # ---- 截取之后
    def _capture(self):
        r = self.view.sel
        return (self.view.capture(r), r) if r is not None else (None, None)

    def selection_to_board(self):
        if self.view.sel is None:
            return
        self.clip_bus.send(self.lecture_clip(),"board",self)
        self.view.clear_selection()

    def image_to_board(self, im):
        clip = self.clip_bus.store.create(image=im)
        self.clip_bus.send(clip,"board",self)

    def text_to_board(self, text):
        if not text.strip():
            return
        self.clip_bus.send(self.clip_bus.store.create(text=text.strip()),"board",self)

    def _show_board(self):
        if self.detached is not None:
            self.detached.raise_()
        elif self.view_mode == "slide":
            self.set_view("split")

    def selection_search(self):
        im, r = self._capture()
        if im is None:
            return
        text = self.view.selection_text(r)
        hint = lookup.make_query(self.doc.getAllText(self.view.pdf).text().split("\n")[0], 20)
        self.panel.show()
        self._place()
        self.panel.start(im, text, hint)
        self.view.clear_selection()

    def selection_copy(self):
        if self.view.sel is not None:
            QApplication.clipboard().setMimeData(self.clip_bus.store.mime(self.lecture_clip()))
            self.toast("截图已复制")
            self.view.clear_selection()

    # ---- 目录
    def toggle_grid(self):
        if self.grid is not None and self.grid.isVisible():
            self.grid.hide()
            self.setFocus()
            return
        if self.grid is None:
            g = QListWidget(self)
            g.setObjectName("grid")
            g.setViewMode(QListWidget.ViewMode.IconMode)
            g.setResizeMode(QListWidget.ResizeMode.Adjust)
            g.setMovement(QListWidget.Movement.Static)
            g.setIconSize(QSize(240, 240))
            g.setSpacing(10)
            g.setUniformItemSizes(True)
            g.itemClicked.connect(self._grid_pick)
            for i in range(self.view.pages):
                it = QListWidgetItem(str(i + 1))
                it.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
                it.setSizeHint(QSize(262, 262 if self.view.kind == "doc" else 190))
                g.addItem(it)
            self.grid = g
            self._grid_next = 0
            self.grid_timer = QTimer(self)
            self.grid_timer.timeout.connect(self._grid_thumb)
        self.grid.setCurrentRow(self.view.page)
        self.grid.setGeometry(self.rect())
        self.grid.show()
        self.grid.raise_()
        self.grid.setFocus()
        self.grid.scrollToItem(self.grid.item(self.view.page))
        if self._grid_next < self.view.pages:
            self.grid_timer.start(10)

    def _grid_thumb(self):
        i = self._grid_next
        if i >= self.view.pages or self.grid is None or not self.grid.isVisible():
            self.grid_timer.stop()
            return
        pw, ph = self.view.page_size(i)
        k = 240 / max(pw, ph)
        self.grid.item(i).setIcon(QIcon(QPixmap.fromImage(render_page(self.doc, self.view.final_pdf(i), int(pw * k), int(ph * k)))))
        self._grid_next = i + 1

    def _grid_pick(self, it):
        self.view.go(self.grid.row(it))
        self.grid.hide()
        self.setFocus()

    # ---- 按键
    def keyPressEvent(self, e):  # noqa: N802
        k, mod = e.key(), e.modifiers()
        ctrl = bool(mod & Qt.KeyboardModifier.ControlModifier)
        board_only = self.view_mode == "board"
        session = self.board.canvas.pen_session if board_only else self.view.pen_session
        if session.ids and k in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace):
            session.selection_action("delete")
            return
        if self.grid is not None and self.grid.isVisible():
            if k in (Qt.Key.Key_Escape, Qt.Key.Key_G):
                self.grid.hide()
                self.setFocus()
            elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._grid_pick(self.grid.currentItem())
            return
        if ctrl and k == Qt.Key.Key_Z:
            self.board.canvas.undo() if board_only else self.view.undo()
        elif ctrl and k == Qt.Key.Key_Y:
            self.board.canvas.redo() if board_only else self.view.redo()
        elif k == Qt.Key.Key_Escape:
            self._escape()
        elif k == Qt.Key.Key_F11:
            self.showNormal() if self.isFullScreen() else self.showFullScreen()
        elif k == Qt.Key.Key_B:
            self.set_view("slide" if board_only else "board")
        elif board_only:
            mapped = {Qt.Key.Key_V: "move", Qt.Key.Key_P: "pen", Qt.Key.Key_H: "marker", Qt.Key.Key_L: "laser", Qt.Key.Key_E: "eraser", Qt.Key.Key_T: "text"}.get(k)
            if mapped:
                self.board.canvas.set_tool(mapped)
            elif k in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
                self.board.canvas.delete_selected()
        elif k in (Qt.Key.Key_Right, Qt.Key.Key_PageDown, Qt.Key.Key_Space, Qt.Key.Key_Down):
            self.view.next()
        elif k in (Qt.Key.Key_Left, Qt.Key.Key_PageUp, Qt.Key.Key_Up):
            self.view.prev()
        elif k == Qt.Key.Key_Home:
            self.view.go(0)
        elif k == Qt.Key.Key_End:
            self.view.go(self.view.pages - 1)
        elif k == Qt.Key.Key_G:
            self.toggle_grid()
        elif k in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.view.sel is not None:
            self.selection_to_board()
        elif k == Qt.Key.Key_Q and self.view.sel is not None:
            self.selection_search()
        elif k in (Qt.Key.Key_V, Qt.Key.Key_P, Qt.Key.Key_H, Qt.Key.Key_E, Qt.Key.Key_S, Qt.Key.Key_L):
            self.set_tool({Qt.Key.Key_V: "pointer", Qt.Key.Key_P: "pen", Qt.Key.Key_H: "marker", Qt.Key.Key_E: "eraser", Qt.Key.Key_S: "select",Qt.Key.Key_L:"laser"}[k])
        else:
            super().keyPressEvent(e)

    def _escape(self):
        """Esc 一层层退：选区 → 查询 → 工具 → 黑板 → 退出。"""
        if self.view.sel is not None or self.view.sel_drag is not None:
            self.view.clear_selection()
        elif self.panel.isVisible():
            self.panel.close_panel()
        elif self.view_mode == "board":
            self.set_view("slide")
        elif self.view.tool != "pointer":
            self.set_tool("pointer")
        else:
            self.close()

    def mouseMoveEvent(self, e):  # noqa: N802
        self._wake()
        super().mouseMoveEvent(e)

    # ---- 保存
    def show_storage_error(self, text):
        self.storage_notice.setText("笔迹保存提示：" + text)
        self.storage_notice.show()

    def _schedule_save(self):
        self.saver.start(600)

    def save(self):
        try:
            self.ink_store.save(dict(self.ink_store.data, pages=self.view.ink_data()))
        except (OSError, ValueError) as exc:
            self.show_storage_error(str(exc))
        self.board.canvas.commit_editor()
        self.board.canvas.save()

    def closeEvent(self, e):  # noqa: N802
        self.closing = True
        self.save()
        self.ocr.stop()
        self.panel.engine.cancel()
        if self.detached is not None:
            self.detached.close()
        e.accept()


def open_player(meta, parent_window=None, bus=None) -> LecturePlayer:
    p = LecturePlayer(meta,bus=bus)
    p.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
    if parent_window is not None and parent_window.screen() is not None:
        p.setGeometry(parent_window.screen().geometry())
    p.showFullScreen()
    p.raise_()
    p.activateWindow()
    p.setFocus()
    return p


_ = (QColor, QImage, QMessageBox)
