"""黑板：独立于课件的一块大板。截图贴上来可以拖动、缩放，用粉笔在上面写，还能写字、分多块板。

画布不限大小：拖动空白处（或按住右键）平移，Ctrl+滚轮缩放；坐标存成板上的坐标，不随窗口变化。
"""
from __future__ import annotations

import copy
import random
import uuid
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QCursor, QImage, QLinearGradient, QPainter, QPen, QPixmap, QPointingDevice, QRadialGradient, QTextOption, QTransform
from PySide6.QtWidgets import QFileDialog, QFrame, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QWidget

from ..kit import pen as ink
from ..kit.pen_store import PenStore
from ..kit.pen_session import PenSession
from ..kit.pen_bar import PenBar
from .board_transfer import BoardTransfer

CHALK = ["#F4F1E8", "#F7D154", "#F28B82", "#7FD1F2", "#A5E08A"]
GREEN, GREEN2 = "#1E3B31", "#17302A"


class Item:
    """贴在板上的东西：图片或文字。"""

    def __init__(self, data):
        self.d = data

    @property
    def rect(self):
        d = self.d
        return QRectF(d["x"], d["y"], d["w"], d["h"])


class BoardCanvas(BoardTransfer,QWidget):
    changed = Signal()
    tool_changed = Signal(str)
    storage_error = Signal(str)
    selection_changed = Signal()
    origin_requested = Signal(object)

    def __init__(self, base: Path):
        super().__init__()
        self.base = Path(base)
        self.base.mkdir(parents=True, exist_ok=True)
        self.boards = [dict(items=[], strokes=[])]
        self.cur = 0
        self.tool = "move"
        self.color = CHALK[0]
        self.width_px = 4.0
        self.scale, self.dx, self.dy = 1.0, 0.0, 0.0
        self.sel = None
        self.drag = None
        self.active = None
        self.images = {}
        self.undo_stack, self.redo_stack = [], []
        self.editor = None
        self._bg = None
        self._layer = None
        self._layer_key = None
        self.version = 0
        self.stagger = 0
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TabletTracking, True)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.saver = QTimer(self)
        self.saver.setSingleShot(True)
        self.saver.timeout.connect(self.save)
        self.load()
        self.pen_session = PenSession(self,lambda:self.board["strokes"],self._live_ink,
                                      self._commit_ink,self.to_board,
                                      lambda q:QPointF(q.x()*self.scale+self.dx,q.y()*self.scale+self.dy),lambda:self.scale)

    def _live_ink(self,strokes):
        self.board["strokes"] = list(strokes)
        self.version += 1
        self.update()

    def _commit_ink(self,before,after):
        if before != after:
            self.board["strokes"] = list(before)
            self.snapshot()
            self.board["strokes"] = list(after)
            self._touch()

    # ---- 存取
    @property
    def board(self):
        return self.boards[self.cur]

    def load(self):
        self.store = PenStore(self.base / "board.json", "board")
        self.boards = self.store.data["boards"]
        if any("id" not in board for board in self.boards):
            self.store.legacy = True
        for index,board in enumerate(self.boards):
            board.setdefault("id",f"legacy-board-{index}")
        self.cur = max(0, min(len(self.boards) - 1, self.store.data["cur"]))
        if self.store.error:
            self.setToolTip(self.store.error)

    def save(self):
        self.saver.stop()
        try:
            self.store.save(dict(self.store.data, boards=self.boards, cur=self.cur))
            return True
        except (OSError, ValueError) as exc:
            self.setToolTip(str(exc))
            self.storage_error.emit(str(exc))
            return False

    def _touch(self):
        self.version += 1
        self.changed.emit()
        self.saver.start(800)
        self.update()

    def snapshot(self):
        self.undo_stack.append((self.cur, copy.deepcopy(self.board["items"]), list(self.board["strokes"])))
        del self.undo_stack[:-40]
        self.redo_stack.clear()

    def _swap(self, src, dst):
        if not src:
            return
        cur, items, strokes = src.pop()
        self.cur = max(0, min(len(self.boards) - 1, cur))
        dst.append((self.cur, copy.deepcopy(self.board["items"]), list(self.board["strokes"])))
        self.board["items"], self.board["strokes"] = items, strokes
        self.sel = None
        self._touch()

    def undo(self):
        self.pen_session.reset()
        self._swap(self.undo_stack, self.redo_stack)

    def redo(self):
        self.pen_session.reset()
        self._swap(self.redo_stack, self.undo_stack)

    # ---- 板面操作
    def view_center(self):
        return QPointF((self.width() / 2 - self.dx) / self.scale, (self.height() / 2 - self.dy) / self.scale)

    def add_image(self, image: QImage) -> dict:
        """把截图放到当前视野中间，大小不超过视野的六成；连续贴的时候错开一点。"""
        self.snapshot()
        name = uuid.uuid4().hex[:12] + ".png"
        image.save(str(self.base / name))
        vw, vh = max(200, self.width()) / self.scale, max(200, self.height()) / self.scale
        k = min(vw * 0.6 / max(1, image.width()), vh * 0.6 / max(1, image.height()), 1.0)
        w, h = image.width() * k, image.height() * k
        c = self.view_center()
        off = (self.stagger % 6) * 26
        self.stagger += 1
        d = dict(id=name, type="image", file=name, x=c.x() - w / 2 + off, y=c.y() - h / 2 + off, w=w, h=h)
        self.board["items"].append(d)
        self.sel = d
        self.set_tool("move")
        self._touch()
        return d

    def add_text(self, text: str, at=None) -> dict:
        self.snapshot()
        c = at or self.view_center()
        w = min(560.0, max(240.0, self.width() * 0.5 / self.scale))
        d = dict(id=uuid.uuid4().hex[:12], type="text", text=text, x=c.x() - (0 if at else w / 2), y=c.y(), w=w, h=40.0, size=24, color=self.color)
        d["h"] = self._text_height(d)
        self.board["items"].append(d)
        self.sel = d
        self._touch()
        return d

    def delete_selected(self):
        if self.sel is None:
            return
        self.snapshot()
        self.board["strokes"] = [s for s in self.board["strokes"] if s.get("group_id") != self.sel["id"]]
        self.board["items"] = [i for i in self.board["items"] if i is not self.sel]
        self.sel = None
        self._touch()

    def clear_board(self):
        self.pen_session.reset()
        if not self.board["items"] and not self.board["strokes"]:
            return
        self.snapshot()
        self.board["items"], self.board["strokes"] = [], []
        self.sel = None
        self._touch()

    def add_board(self):
        self.pen_session.reset()
        self.export_rect = None
        self.commit_editor()
        self.boards.append(dict(id=uuid.uuid4().hex,items=[], strokes=[]))
        self.cur = len(self.boards) - 1
        self.sel = None
        self.scale, self.dx, self.dy = 1.0, 0.0, 0.0
        self._touch()

    def go_board(self, delta):
        self.commit_editor()
        i = max(0, min(len(self.boards) - 1, self.cur + delta))
        if i != self.cur:
            self.pen_session.reset()
            self.export_rect = None
            self.cur = i
            self.sel = None
            self.scale, self.dx, self.dy = 1.0, 0.0, 0.0
            self._touch()

    def set_tool(self, tool):
        self.pen_session.reset()
        if tool != "region":
            self.export_rect = None
        self.commit_editor()
        if self.active is not None:
            self._finish()
        self.tool = tool
        if tool != "move":
            self.sel = None
        self.setCursor(QCursor({"chalk": Qt.CursorShape.CrossCursor, "text": Qt.CursorShape.IBeamCursor, "eraser": Qt.CursorShape.PointingHandCursor}.get(tool, Qt.CursorShape.ArrowCursor)))
        self.tool_changed.emit(tool)
        self.update()

    # ---- 坐标
    def to_board(self, pos):
        return QPointF((pos.x() - self.dx) / self.scale, (pos.y() - self.dy) / self.scale)

    def to_view_rect(self, r):
        return QRectF(r.x() * self.scale + self.dx, r.y() * self.scale + self.dy, r.width() * self.scale, r.height() * self.scale)

    def content_bounds(self) -> QRectF:
        r = QRectF()
        for d in self.board["items"]:
            r = r.united(Item(d).rect)
        for s in self.board["strokes"]:
            r = r.united(ink.bounds(s))
        return r

    # ---- 绘制
    def _background(self):
        size = (self.width(), self.height(), self.devicePixelRatioF())
        if self._bg is None or self._bg[0] != size:
            d = size[2]
            pm = QPixmap(max(1, int(size[0] * d)), max(1, int(size[1] * d)))
            pm.setDevicePixelRatio(d)
            p = QPainter(pm)
            g = QLinearGradient(0, 0, size[0], size[1])
            g.setColorAt(0, QColor(GREEN))
            g.setColorAt(1, QColor(GREEN2))
            p.fillRect(QRectF(0, 0, size[0], size[1]), g)
            rnd = random.Random(11)   # 擦过的粉笔灰
            p.setPen(Qt.PenStyle.NoPen)
            for _ in range(46):
                x, y = rnd.uniform(0, size[0]), rnd.uniform(0, size[1])
                rx, ry = rnd.uniform(90, 300), rnd.uniform(24, 80)
                g2 = QRadialGradient(QPointF(0, 0), 1)   # 边缘淡出，不要看出一个个椭圆
                g2.setColorAt(0, QColor(255, 255, 255, rnd.randint(5, 10)))
                g2.setColorAt(1, QColor(255, 255, 255, 0))
                b = QBrush(g2)
                b.setTransform(QTransform().translate(x, y).scale(rx, ry))
                p.setBrush(b)
                p.drawEllipse(QPointF(x, y), rx, ry)
            p.end()
            self._bg = (size, pm)
        return self._bg[1]

    def _pix(self, name):
        if name not in self.images:
            self.images[name] = QPixmap(str(self.base / name))
        return self.images[name]

    def _strokes_layer(self,marker=False):
        d = self.devicePixelRatioF()
        key = (self.width(), self.height(), d, self.scale, self.dx, self.dy, self.version, self.cur,marker)
        cache = getattr(self,"_ink_cache",{})
        if key not in cache:
            pm = QPixmap(max(1, int(self.width() * d)), max(1, int(self.height() * d)))
            pm.setDevicePixelRatio(d)
            pm.fill(Qt.GlobalColor.transparent)
            p = QPainter(pm)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.translate(self.dx, self.dy)
            p.scale(self.scale, self.scale)
            for s in self.board["strokes"]:
                if (s["tool"] == "marker") == marker:
                    ink.draw(p, s)
            p.end()
            if len(cache) >= 2:
                cache.clear()
            cache[key] = pm
            self._ink_cache = cache
        return cache[key]

    def _text_height(self, d):
        from PySide6.QtGui import QFont, QFontMetricsF
        f = QFont("Microsoft YaHei")
        f.setPixelSize(int(d.get("size", 24)))
        r = QFontMetricsF(f).boundingRect(QRectF(0, 0, d["w"] - 16, 100000), int(Qt.TextFlag.TextWordWrap), d.get("text") or " ")
        return r.height() + 16

    def _draw_item(self, p, d):
        r = Item(d).rect
        if d["type"] == "clip":
            self.paint_clip_item(p,d)
            return
        if d["type"] == "image":
            pm = self._pix(d["file"])
            if pm.isNull():
                p.setPen(QPen(QColor(255, 255, 255, 90), 1, Qt.PenStyle.DashLine))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(r)
                return
            p.fillRect(r.translated(3, 4), QColor(0, 0, 0, 70))
            p.drawPixmap(r, pm, QRectF(pm.rect()))
        else:
            from PySide6.QtGui import QFont
            f = QFont("Microsoft YaHei")
            f.setPixelSize(int(d.get("size", 24)))
            p.setFont(f)
            p.setPen(QColor(d.get("color", CHALK[0])))
            op = QTextOption()
            op.setWrapMode(QTextOption.WrapMode.WordWrap)
            p.drawText(r.adjusted(8, 8, -8, -8), d.get("text", ""), op)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.drawPixmap(0, 0, self._background())
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        p.save()
        p.translate(self.dx, self.dy)
        p.scale(self.scale, self.scale)
        for d in self.board["items"]:
            if self.editor is None or self.editor[1] is not d:
                self._draw_item(p, d)
        p.restore()
        p.save()
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
        p.drawPixmap(0,0,self._strokes_layer(True))
        p.restore()
        p.drawPixmap(0, 0, self._strokes_layer())
        if self.active is not None:
            p.save()
            p.translate(self.dx, self.dy)
            p.scale(self.scale, self.scale)
            ink.draw(p, self.active)
            p.restore()
        if self.sel is not None and self.tool == "move":
            v = self.to_view_rect(Item(self.sel).rect)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QColor("#F7D154"), 1.5, Qt.PenStyle.DashLine))
            p.drawRect(v)
            p.setPen(QPen(QColor("#F7D154"), 1.5))
            p.setBrush(QColor(GREEN2))
            p.drawRect(self._handle(v))
            x = self._close(v)
            p.setBrush(QColor("#C8372D"))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(x)
            p.setPen(QPen(QColor("white"), 1.6))
            c = x.center()
            p.drawLine(c + QPointF(-4, -4), c + QPointF(4, 4))
            p.drawLine(c + QPointF(-4, 4), c + QPointF(4, -4))
        if not self.board["items"] and not self.board["strokes"] and self.active is None and self.editor is None:
            p.setPen(QColor(255, 255, 255, 70))
            f = p.font()
            f.setPixelSize(18)
            f.setFamilies(["Microsoft YaHei"])
            p.setFont(f)
            p.drawText(self.rect(), int(Qt.AlignmentFlag.AlignCenter), "这块黑板还是空的\n在课件上框选一块，选「带入黑板」；也可以直接写")
        self.pen_session.paint(p)
        if getattr(self,"export_rect",None) is not None:
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QColor("#5799E5"),1.5,Qt.PenStyle.DashLine))
            p.drawRect(self.to_view_rect(self.export_rect))
        p.end()

    @staticmethod
    def _handle(v):
        return QRectF(v.right() - 7, v.bottom() - 7, 14, 14)

    @staticmethod
    def _close(v):
        return QRectF(v.right() - 11, v.top() - 11, 22, 22)

    # ---- 输入
    def _item_at(self, q):
        for d in reversed(self.board["items"]):
            if not d.get("locked") and Item(d).rect.contains(q):
                return d
        return None

    def _press(self, pos, pr=1.0, pressure=False, eraser=False):
        q = self.to_board(pos)
        if self.tool == "region":
            self.drag = ("region",q)
            self.export_rect = QRectF(q,q)
            return
        if eraser or self.tool == "eraser":
            self.drag = ("erase", False)
            self._erase(q)
            return
        if self.tool in ("pen","chalk","marker"):
            self.active = ink.new_stroke(self.tool, self.color, self.width_px * (4.5 if self.tool == "marker" else 1) / self.scale,
                                         pressure and self.tool in ("pen","chalk"))
            ink.add_point(self.active, q.x(), q.y(), pr)
            self.update()
            return
        if self.tool == "text":
            self.commit_editor()
            self._edit(None, q)
            return
        if self.sel is not None:
            v = self.to_view_rect(Item(self.sel).rect)
            if self._close(v).contains(pos):
                self.delete_selected()
                return
            if self._handle(v).adjusted(-5, -5, 5, 5).contains(pos):
                self.snapshot()
                self.drag = ("resize", pos, dict(self.sel))
                return
        it = self._item_at(q)
        self.sel = it
        self.selection_changed.emit()
        if it is not None:
            self.snapshot()
            self.drag = ("item", q, it["x"], it["y"], False)
        else:
            self.drag = ("pan", pos, self.dx, self.dy)
        self.update()

    def _move(self, pos, pr=1.0):
        q = self.to_board(pos)
        if self.active is not None:
            if ink.add_point(self.active, q.x(), q.y(), pr, 0.6 / self.scale):
                self.update()
            return
        if not self.drag:
            return
        kind = self.drag[0]
        if kind == "erase":
            self._erase(q)
        elif kind == "region":
            self.export_rect = QRectF(self.drag[1],q).normalized()
            self.update()
        elif kind == "pan":
            self.dx = self.drag[2] + pos.x() - self.drag[1].x()
            self.dy = self.drag[3] + pos.y() - self.drag[1].y()
            self.update()
        elif kind == "item":
            d = self.sel
            old_rect = (d["x"],d["y"],d["w"],d["h"])
            d["x"] = self.drag[2] + q.x() - self.drag[1].x()
            d["y"] = self.drag[3] + q.y() - self.drag[1].y()
            self.drag = self.drag[:4] + (True,)
            self.move_group(d,old_rect)
            self.update()
        elif kind == "resize":
            d, o = self.sel, self.drag[2]
            old_rect = (d["x"],d["y"],d["w"],d["h"])
            nw = max(40.0, o["w"] + (pos.x() - self.drag[1].x()) / self.scale)
            d["w"] = nw
            if d["type"] in ("image","clip"):
                d["h"] = o["h"] * nw / max(1.0, o["w"])
            else:
                d["size"] = max(12, int(o.get("size", 24) * nw / max(1.0, o["w"])))
                d["h"] = self._text_height(d)
            self.move_group(d,old_rect)
            self.update()

    def _release(self):
        if self.active is not None:
            self._finish()
        elif self.drag:
            kind = self.drag[0]
            if kind == "item" and not self.drag[4]:   # 只是点了一下，没有移动
                self.undo_stack.pop()
            self.drag = None
            if kind in ("item", "resize", "erase"):
                self._touch()

    def _finish(self):
        st, self.active = self.active, None
        self.snapshot()
        self.board["strokes"].append(st)
        self._touch()

    def _erase(self, q):
        r = 12.0 / self.scale
        hit = [s for s in self.board["strokes"] if ink.hit(s, q.x(), q.y(), r)]
        if hit:
            if self.drag and not self.drag[1]:
                self.snapshot()
                self.drag = ("erase", True)
            self.board["strokes"] = [s for s in self.board["strokes"] if not any(s is h for h in hit)]
            self.version += 1
            self.update()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.RightButton:
            self.drag = ("pan", e.position(), self.dx, self.dy)
        elif e.button() == Qt.MouseButton.LeftButton:
            self._press(e.position())

    def mouseMoveEvent(self, e):  # noqa: N802
        if e.buttons():
            self._move(e.position())

    def mouseReleaseEvent(self, _e):  # noqa: N802
        self._release()

    def mouseDoubleClickEvent(self, e):  # noqa: N802
        q = self.to_board(e.position())
        it = self._item_at(q)
        if it is not None and it["type"] == "text":
            self.set_tool("move")
            self._edit(it, q)
        elif it is None and self.tool == "move":
            self._edit(None, q)

    def tabletEvent(self, e):  # noqa: N802
        t = e.type()
        eraser = e.pointerType() == QPointingDevice.PointerType.Eraser
        if t == e.Type.TabletPress:
            self._press(e.position(), e.pressure(), True, eraser)
        elif t == e.Type.TabletMove:
            self._move(e.position(), e.pressure())
        elif t == e.Type.TabletRelease:
            self._release()
        e.accept()

    def wheelEvent(self, e):  # noqa: N802
        dy = e.angleDelta().y()
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            pos = e.position()
            q = self.to_board(pos)
            self.scale = max(0.2, min(4.0, self.scale * (1.12 if dy > 0 else 1 / 1.12)))
            self.dx, self.dy = pos.x() - q.x() * self.scale, pos.y() - q.y() * self.scale
        else:
            self.dy += dy * 0.8
        self.update()

    def keyPressEvent(self, e):  # noqa: N802
        if e.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.sel is not None:
            self.delete_selected()
        else:
            super().keyPressEvent(e)

    # ---- 写字
    def _edit(self, item, q):
        ed = QPlainTextEdit(self)
        ed.setStyleSheet(f"QPlainTextEdit {{ background:rgba(255,255,255,0.05); color:{self.color}; border:1px dashed #F7D154; font-family:'Microsoft YaHei'; font-size:{int(24 * self.scale)}px; }}")
        rect = Item(item).rect if item else QRectF(q.x(), q.y(), 420 / self.scale, 110 / self.scale)
        ed.setGeometry(self.to_view_rect(rect).toAlignedRect().adjusted(0, 0, 0, 12))
        if item:
            ed.setPlainText(item.get("text", ""))
        ed.show()
        ed.setFocus()
        self.editor = (ed, item, q)
        ed.focusOutEvent = lambda ev, old=ed.focusOutEvent: (old(ev), QTimer.singleShot(0, self.commit_editor))
        self.update()

    def commit_editor(self):
        if self.editor is None:
            return
        ed, item, q = self.editor
        self.editor = None
        text = ed.toPlainText().strip()
        ed.hide()
        ed.deleteLater()
        if item is not None:
            self.snapshot()
            if text:
                item["text"] = text
                item["h"] = self._text_height(item)
            else:
                self.board["items"] = [i for i in self.board["items"] if i is not item]
            self._touch()
        elif text:
            self.add_text(text, q)
        self.update()

    # ---- 导出
    def render_image(self) -> QImage:
        r = self.content_bounds().adjusted(-40, -40, 40, 40)
        if r.isEmpty():
            r = QRectF(0, 0, 800, 450)
        im = QImage(max(1, int(r.width())), max(1, int(r.height())), QImage.Format.Format_RGB32)
        im.fill(QColor(GREEN))
        p = QPainter(im)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        p.translate(-r.x(), -r.y())
        for d in self.board["items"]:
            self._draw_item(p, d)
        for s in self.board["strokes"]:
            ink.draw(p, s)
        p.end()
        return im

    def export_png(self):
        path, _ = QFileDialog.getSaveFileName(self, "保存黑板", "黑板.png", "PNG 图片 (*.png)")
        if path:
            self.render_image().save(path)


class Board(QFrame):
    """黑板加上它自己的工具条。"""
    detach_toggled = Signal()

    def __init__(self, base: Path):
        super().__init__()
        self.setObjectName("boardWrap")
        self.canvas = BoardCanvas(base)
        v = _vbox(self)
        bar = QFrame()
        bar.setObjectName("boardBar")
        h = QHBoxLayout(bar)
        h.setContentsMargins(10, 6, 10, 6)
        h.setSpacing(4)
        self.pen_bar = PenBar(self.canvas,self.canvas.pen_session,board=True,on_dark=True)
        for label,tip,fn in (("文字","单击输入文字 T",lambda:self.canvas.set_tool("text")),
                             ("擦净","清空这块黑板",self.canvas.clear_board)):
            button = self._btn(label,tip)
            button.clicked.connect(fn)
            h.addWidget(button)
        h.addStretch(1)
        b = self._btn("‹", "上一块")
        b.clicked.connect(lambda: self.canvas.go_board(-1))
        h.addWidget(b)
        self.num = QLabel("1 / 1")
        self.num.setObjectName("boardNum")
        h.addWidget(self.num)
        b = self._btn("›", "下一块")
        b.clicked.connect(lambda: self.canvas.go_board(1))
        h.addWidget(b)
        b = self._btn("＋", "再加一块黑板")
        b.clicked.connect(self.canvas.add_board)
        h.addWidget(b)
        h.addSpacing(8)
        b = self._btn("存图", "把这块黑板存成图片")
        b.clicked.connect(self.canvas.export_png)
        h.addWidget(b)
        self.detach_btn = self._btn("独立窗口", "把黑板放到单独的窗口；有第二块屏幕时放到那块屏上")
        self.detach_btn.clicked.connect(self.detach_toggled)
        h.addWidget(self.detach_btn)
        self.origin_btn = self._btn("回到来源","定位素材的原始页面或工作台")
        self.origin_btn.clicked.connect(lambda:self.canvas.origin_requested.emit(self.canvas.sel.get("origin",{})) if self.canvas.sel else None)
        h.addWidget(self.origin_btn)
        pen_row = QFrame()
        pen_row.setObjectName("boardPen")
        row = QHBoxLayout(pen_row)
        row.setContentsMargins(8, 3, 8, 3)
        row.addWidget(self.pen_bar)
        row.addStretch(1)
        v.addWidget(pen_row)
        v.addWidget(bar)
        v.addWidget(self.canvas, 1)
        self.canvas.changed.connect(self._sync)
        self.canvas.tool_changed.connect(lambda _t: self._sync())
        self.canvas.selection_changed.connect(self._sync)
        self.set_color(CHALK[0])
        self._sync()
        self.setStyleSheet("""
QFrame#boardWrap { background:#0F1815; }
QFrame#boardPen { background:#131D1A; }
QFrame#boardBar { background:#131D1A; border-bottom:1px solid #2E3F39; }
QFrame#boardBar QPushButton#bb { background:#1B2925; color:#DCE5E0; border:1px solid #2E3F39; border-bottom:2px solid #080D0B; border-radius:5px; padding:3px 9px 2px 9px; font-size:12px; font-family:'Microsoft YaHei UI'; min-height:20px; }
QFrame#boardBar QPushButton#bb:hover { background:#263732; color:white; }
QFrame#boardBar QPushButton#bb:pressed { border-bottom:1px solid #080D0B; margin-top:1px; }
QFrame#boardBar QPushButton#bb:checked { background:#C8402A; border-color:#7E2616; color:white; }
QFrame#boardBar QPushButton#bb:disabled { background:transparent; color:#5C6D66; border-color:#22302B; }
QLabel#boardNum { color:#9DAFA7; font-size:12px; padding:0 4px; font-family:'Bahnschrift','Microsoft YaHei UI'; }
""")

    @staticmethod
    def _btn(label, tip, checkable=False):
        b = QPushButton(label)
        b.setObjectName("bb")
        b.setToolTip(tip)
        b.setCheckable(checkable)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        return b

    def set_color(self, c):
        self.canvas.color = c
        self.pen_bar.sync()
        if self.canvas.tool not in ("chalk", "text"):
            self.canvas.set_tool("chalk")

    def _sync(self):
        self.pen_bar.sync()
        origin = self.canvas.sel.get("origin") if self.canvas.sel else None
        self.origin_btn.setEnabled(bool(origin))
        ref = (origin or {}).get("ref",{})
        self.origin_btn.setText(f"回到课件第 {ref.get('slide',0)+1} 页" if origin and origin.get("type")=="lecture" else "回到来源")
        self.num.setText(f"{self.canvas.cur + 1} / {len(self.canvas.boards)}")

    def set_detached(self, on: bool):
        self.detach_btn.setText("放回" if on else "独立窗口")


def _vbox(w):
    from PySide6.QtWidgets import QVBoxLayout
    v = QVBoxLayout(w)
    v.setContentsMargins(0, 0, 0, 0)
    v.setSpacing(0)
    return v
