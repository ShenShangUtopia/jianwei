"""四个阅读页：今日、人物、金句、档案。"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QPainter, QPen
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget

from .base import Hairline, IconButton, SectionHeader, TagLabel, TextBlock, TextButton
from .cards import ArchiveRow, HeroCard, PersonSeal, QuoteCard, StoryCard, TermCard, _label
from .icons import draw_icon
from .theme import C, font, mono


def clear_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.hide()          # deleteLater 要等回到事件循环；先藏起来，重建时不会和新内容叠影
            widget.deleteLater()
        child = item.layout()
        if child is not None:
            clear_layout(child)


def story_list(edition: dict | None) -> list[dict]:
    """今日版的阅读顺序：焦点在前，然后按栏目。"""
    if not edition:
        return []
    out = [edition["lead"]] if edition.get("lead") else []
    sections = edition.get("sections") or {}
    for key in ("world", "china_world", "tech", "society"):
        out.extend(sections.get(key) or [])
    return out


def story_key(story: dict) -> str:
    return str(story.get("url") or story.get("title") or "")


class ScrollPage(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.content = QWidget()
        self.layout_content = QVBoxLayout(self.content)
        self.layout_content.setContentsMargins(14, 12, 12, 20)
        self.layout_content.setSpacing(8)
        self.scroll.setWidget(self.content)
        outer.addWidget(self.scroll)

    def scroll_top(self) -> None:
        self.scroll.verticalScrollBar().setValue(0)


class ReadTicks(QWidget):
    """今天读到哪了：一条刻度，读过一条亮一格。"""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(20)
        self.read, self.total = 0, 0

    def set_progress(self, read: int, total: int) -> None:
        self.read, self.total = read, total
        self.update()

    def paintEvent(self, event) -> None:
        if not self.total:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        for i in range(self.total):
            p.setPen(QPen(C.ACCENT if i < self.read else C.HAIRLINE_STRONG, 3))
            x = 2 + i * 10
            p.drawLine(QPointF(x, 5), QPointF(x, 15))
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(font(12))
        p.setPen(C.MUTED)
        text = "今天的都读完了" if self.read >= self.total else f"已读 {self.read} / {self.total}"
        p.drawText(QRectF(self.total * 10 + 8, 0, self.width(), 20), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, text)


class FilterInvite(QWidget):
    clicked = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover = False

    def enterEvent(self, event) -> None:
        self._hover = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._hover = False
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self._hover:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.CARD_HOVER)
            p.drawRoundedRect(QRectF(self.rect()), 6, 6)
        draw_icon(p, "spark", QRectF(8, 12, 16, 16), C.ACCENT, 1.3)
        p.setFont(font(13))
        p.setPen(C.TEXT_SOFT)
        p.drawText(QRectF(30, 0, self.width(), self.height()), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "这些新闻是怎么选出来的")
        draw_icon(p, "chevron_right", QRectF(self.width() - 24, 12, 16, 16), C.DIM, 1.4)


class TodayPage(ScrollPage):
    open_story = Signal(dict)
    open_filter = Signal()
    refresh_requested = Signal()

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.edition: dict | None = None
        self.read_keys: set[str] = set()
        self.cards: list[StoryCard] = []
        self.hero: HeroCard | None = None
        self.ticks: ReadTicks | None = None

    def set_edition(self, edition: dict | None, read_keys=None) -> None:
        self.edition = edition
        self.read_keys = set(read_keys or ())
        self.cards, self.hero, self.ticks = [], None, None
        clear_layout(self.layout_content)
        if not edition:
            self._empty()
            return
        title = TextBlock(edition.get("title", ""), 19, 700, C.TEXT, 3, 1.4).fit()
        self.layout_content.addWidget(title)
        if edition.get("subtitle"):
            self.layout_content.addWidget(TextBlock(edition["subtitle"], 13, 400, C.MUTED, 3, 1.55).fit())
        self.ticks = ReadTicks()
        self.layout_content.addWidget(self.ticks)

        lead = edition.get("lead") or {}
        if lead:
            self.hero = HeroCard(lead, story_key(lead) in self.read_keys)
            self.hero.clicked.connect(lambda: self.open_story.emit(lead))
            self.layout_content.addWidget(self.hero)

        kws = edition.get("keywords", [])[:5]
        if kws:
            row = QHBoxLayout()
            row.setSpacing(5)
            width = 0
            for kw in kws:
                tag = TagLabel(f"# {kw}")
                width += tag.width() + 5
                if width > 380:    # 一行放不下就不放了，不撑宽面板
                    tag.deleteLater()
                    break
                row.addWidget(tag)
            row.addStretch(1)
            self.layout_content.addLayout(row)

        from core.editorial import SECTION_META
        sections = edition.get("sections") or {}
        idx = 1
        for section in ("world", "china_world", "tech", "society"):
            items = sections.get(section) or []
            if not items:
                continue
            self.layout_content.addSpacing(4)
            self.layout_content.addWidget(SectionHeader(SECTION_META[section]["label"], len(items)))
            for story in items:
                idx += 1
                card = StoryCard(story, idx, story_key(story) in self.read_keys)
                card.clicked.connect(self.open_story)
                self.layout_content.addWidget(card)
                self.cards.append(card)

        term = edition.get("term")
        if term:
            self.layout_content.addSpacing(6)
            self.layout_content.addWidget(TermCard(term))
        invite = FilterInvite()
        invite.clicked.connect(self.open_filter)
        self.layout_content.addWidget(invite)
        self.layout_content.addStretch(1)
        self._update_ticks()

    def mark_read(self, story: dict) -> None:
        key = story_key(story)
        self.read_keys.add(key)
        for card in self.cards:
            if story_key(card.story) == key:
                card.set_read(True)
        if self.hero is not None and story_key(self.hero.story) == key:
            self.hero.state.setText("已读")
        self._update_ticks()

    def _update_ticks(self) -> None:
        stories = story_list(self.edition)
        if self.ticks is not None:
            self.ticks.set_progress(sum(1 for s in stories if story_key(s) in self.read_keys), len(stories))

    def _empty(self) -> None:
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(12, 70, 12, 12)
        lay.setSpacing(10)
        title = QLabel("今天的内容还没有筛选")
        title.setFont(font(18, 700))
        title.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub = QLabel("每天早上会自动更新，也可以现在就更新。")
        sub.setFont(font(13))
        sub.setStyleSheet(f"color: {C.MUTED.name()}; background: transparent;")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        btn = QPushButton("立即更新")
        btn.setObjectName("primary")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(self.refresh_requested)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(btn)
        row.addStretch(1)
        lay.addWidget(title)
        lay.addWidget(sub)
        lay.addSpacing(6)
        lay.addLayout(row)
        self.layout_content.addWidget(box)
        self.layout_content.addStretch(1)


class PersonView(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(10)

    def build(self, person: dict, index: int, total: int, on_prev, on_next, on_url) -> None:
        clear_layout(self.lay)
        top = QHBoxLayout()
        top.addWidget(_label(f"今日人物  {index + 1} / {total}", 12, 700, C.ACCENT))
        top.addStretch(1)
        prev = IconButton("chevron_left", "上一位（←）", 28)
        nxt = IconButton("chevron_right", "下一位（→）", 28)
        prev.clicked.connect(on_prev)
        nxt.clicked.connect(on_next)
        top.addWidget(prev)
        top.addWidget(nxt)
        self.lay.addLayout(top)

        ident = QHBoxLayout()
        ident.setSpacing(12)
        ident.addWidget(PersonSeal(person.get("monogram", "")), 0, Qt.AlignmentFlag.AlignTop)
        left = QVBoxLayout()
        left.setSpacing(1)
        name = QLabel(person.get("name", ""))
        name.setFont(font(21, 700))
        name.setStyleSheet(f"color: {C.TEXT.name()}; background: transparent;")
        left.addWidget(name)
        if person.get("latin"):
            left.addWidget(_label(person["latin"], 12, 400, C.DIM))
        role = _label(f"{person.get('identity', '')}  ·  {person.get('years', '')}", 12, 400, C.MUTED)
        role.setWordWrap(True)
        left.addWidget(role)
        ident.addLayout(left, 1)
        self.lay.addLayout(ident)

        self.lay.addWidget(TextBlock(person.get("headline", ""), 14, 600, C.ACCENT, 3, 1.55).fit())

        story = QLabel()
        story.setWordWrap(True)
        story.setTextFormat(Qt.TextFormat.RichText)
        story.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        safe = person.get("story", "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
        story.setText(f"<p style='line-height:175%; margin:0;'>{safe}</p>")
        story.setFont(font(13))
        story.setStyleSheet(f"color: {C.TEXT_SOFT.name()}; background: transparent;")
        story.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.lay.addWidget(story)

        self.lay.addWidget(SectionHeader("三个时刻"))
        for moment in person.get("moments", []):
            row = QHBoxLayout()
            row.setSpacing(10)
            year = QLabel(moment.get("year", ""))
            year.setFixedWidth(52)
            year.setFont(mono(13, 500))
            year.setStyleSheet(f"color: {C.ACCENT.name()}; background: transparent;")
            row.addWidget(year, 0, Qt.AlignmentFlag.AlignTop)
            row.addWidget(TextBlock(moment.get("text", ""), 13, 400, C.TEXT_SOFT, 4, 1.55).fit(), 1)
            self.lay.addLayout(row)

        if person.get("qualities"):
            self.lay.addWidget(SectionHeader("可迁移的品质"))
            qrow = QHBoxLayout()
            qrow.setSpacing(5)
            for q in person["qualities"][:3]:
                qrow.addWidget(TagLabel(q, "accent"))
            qrow.addStretch(1)
            self.lay.addLayout(qrow)

        if person.get("essay_angle"):
            self.lay.addWidget(SectionHeader("作文可用"))
            self.lay.addWidget(TextBlock(person["essay_angle"], 13, 400, C.TEXT_SOFT, 6, 1.6).fit())

        quote = person.get("quote") or {}
        if quote.get("text"):
            self.lay.addSpacing(2)
            qtext = TextBlock(f"“{quote['text']}”", 15, 500, C.TEXT, 5, 1.6).fit()
            self.lay.addWidget(qtext)
            self.lay.addWidget(_label(f"—— {quote.get('source', '')}", 12, 400, C.DIM))

        actions = QHBoxLayout()
        actions.setSpacing(16)
        change = TextButton("换一位", C.ACCENT, 13, "refresh")
        change.clicked.connect(on_next)
        actions.addWidget(change)
        if person.get("source_url"):
            read = TextButton("延伸阅读", C.MUTED, 13, "arrow_up_right")
            read.clicked.connect(lambda: on_url(person.get("source_url", "")))
            actions.addWidget(read)
        actions.addStretch(1)
        self.lay.addLayout(actions)
        self.lay.addStretch(1)


class PeoplePage(ScrollPage):
    open_url = Signal(str)

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.people: list[dict] = []
        self.index = 0
        self.view = PersonView()
        self.layout_content.addWidget(self.view)
        self.layout_content.addStretch(1)

    def set_edition(self, edition: dict | None) -> None:
        self.people = []
        if edition:
            if edition.get("person"):
                self.people.append(edition["person"])
            self.people.extend(edition.get("person_alternates") or [])
        self.index = 0
        self._build()

    def _build(self) -> None:
        if not self.people:
            clear_layout(self.view.lay)
            self.view.lay.addWidget(_label("今日版生成后，这里会有一位人物。", 13, 400, C.MUTED))
            return
        self.view.build(self.people[self.index], self.index, len(self.people), self.prev, self.next, self.open_url.emit)

    def prev(self) -> None:
        if self.people:
            self.index = (self.index - 1) % len(self.people)
            self._build()
            self.scroll_top()

    def next(self) -> None:
        if self.people:
            self.index = (self.index + 1) % len(self.people)
            self._build()
            self.scroll_top()


class QuotesPage(ScrollPage):
    copy_requested = Signal(str)

    def set_edition(self, edition: dict | None) -> None:
        clear_layout(self.layout_content)
        if not edition:
            self.layout_content.addWidget(_label("今日版生成后，这里会有三句话。", 13, 400, C.MUTED))
            self.layout_content.addStretch(1)
            return
        self.layout_content.addWidget(TextBlock("把一句话带到明天", 19, 700, C.TEXT, 1, 1.4).fit())
        self.layout_content.addWidget(TextBlock("选一句，用自己的话解释它为什么成立，再举一个今天新闻里的例子。三句话就够。", 13, 400, C.MUTED, 3, 1.55).fit())
        self.layout_content.addSpacing(2)
        for idx, quote in enumerate(edition.get("quotes", []), 1):
            card = QuoteCard(quote, idx)
            card.copy_clicked.connect(self.copy_requested)
            self.layout_content.addWidget(card)
        self.layout_content.addStretch(1)


class ArchivePage(ScrollPage):
    open_entry = Signal(dict)
    open_library = Signal()

    def set_data(self, entries: list[dict], edition: dict | None) -> None:
        entries = entries or []
        clear_layout(self.layout_content)
        self.layout_content.addWidget(TextBlock("时间会筛掉噪音", 19, 700, C.TEXT, 1, 1.4).fit())
        from core.paths import load_config
        update_time = load_config().get("update_time", "07:15")
        head = f"已存 {len(entries)} 天。每天 {update_time} 自动筛选，分栏文档都保存在本机。"
        self.layout_content.addWidget(TextBlock(head, 13, 400, C.MUTED, 3, 1.55).fit())
        row = QHBoxLayout()
        lib = TextButton("打开档案文件夹", C.ACCENT, 13, "arrow_up_right")
        lib.clicked.connect(self.open_library)
        row.addWidget(lib)
        row.addStretch(1)
        self.layout_content.addLayout(row)
        self.layout_content.addWidget(Hairline())
        for entry in entries:
            card = ArchiveRow(entry)
            card.clicked.connect(self.open_entry)
            self.layout_content.addWidget(card)
        if not entries:
            hint = _label("从今天开始，这里会积累每天的档案。", 13, 400, C.MUTED)
            hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.layout_content.addSpacing(24)
            self.layout_content.addWidget(hint)
        self.layout_content.addStretch(1)
