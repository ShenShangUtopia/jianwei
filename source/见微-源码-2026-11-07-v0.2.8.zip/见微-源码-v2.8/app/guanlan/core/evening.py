"""Build the 22:20 evening review (暮省) as plain data.

The deck is assembled from the already-curated edition; no model call is made here.
Playback is native: see app/native/evening.py. Nothing here needs a browser.
"""
from __future__ import annotations

import json
import logging
import os
import random
import re
import sys
import threading
from datetime import datetime
from pathlib import Path

from .paths import ASSET_DIR, DATA_DIR, LATEST_PATH, LOG_DIR, ROOT, ensure_dirs

log = logging.getLogger("guanlan.evening")

EVENING_DIR = ROOT / "晚间暮省"
ARCHIVE_DIR = EVENING_DIR / "archive"
HISTORY_PATH = DATA_DIR / "evening_history.json"
RUNTIME_DIR = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "Guanlan" / "evening"
TODAY_DECK = RUNTIME_DIR / "deck.json"
TEXTURE_DIR = ASSET_DIR / "evening"

THEMES = [
    ("tide", "观澜"),
    ("ridge", "远山"),
    ("stars", "观星"),
    ("lamp", "灯下"),
    ("moon", "月白"),
]

THEME_NAMES = dict(THEMES)
LEGACY_THEMES = {"midnight": "stars", "rice": "moon", "jade": "ridge", "amber": "lamp"}   # 旧版记录里的名字

# Four compositions per scene: 20 issues before any repeat, and the nightly
# edition changes shape, not only colour.
COVER_LAYOUTS = [
    ("left", "左栏"),
    ("center", "居中"),
    ("offset", "错版"),
    ("stack", "竖题"),
]
COVER_NAMES = dict(COVER_LAYOUTS)


def _setup_logging() -> None:
    ensure_dirs()
    EVENING_DIR.mkdir(parents=True, exist_ok=True)
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    if log.handlers:
        return
    log.setLevel(logging.INFO)
    handler = logging.FileHandler(LOG_DIR / "evening.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    log.addHandler(handler)
    log.propagate = False


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _clip(text: str, limit: int) -> str:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    for mark in ("。", "！", "？", "；"):
        idx = cut.rfind(mark)
        if idx >= limit * 0.55:
            return cut[: idx + 1]
    return cut.rstrip("，、；： ") + "…"


def _duration(text: str, base: int = 14, cap: int = 28, floor: int = 16) -> int:
    value = base + len(re.sub(r"\s+", "", text or "")) / 55.0
    return int(max(floor, min(cap, value)))


def _issue_number(edition: dict) -> int:
    try:
        return int(datetime.fromisoformat(str(edition.get("date"))).timetuple().tm_yday)
    except Exception:
        try:
            return int(edition.get("edition") or 1)
        except Exception:
            return 1


def _history_by_date(history: list) -> list[dict]:
    by_date: dict[str, dict] = {}
    for item in history:
        if not isinstance(item, dict) or not item.get("date"):
            continue
        theme = str(item.get("theme") or "")
        theme = LEGACY_THEMES.get(theme, theme)
        if theme not in THEME_NAMES:
            continue
        cover = str(item.get("cover") or "left")
        if cover not in COVER_NAMES:
            cover = "left"
        by_date[str(item["date"])] = {
            "date": str(item["date"]),
            "theme": theme,
            "cover": cover,
            "name": THEME_NAMES[theme],
            "cover_name": COVER_NAMES[cover],
            "generated_at": str(item.get("generated_at") or ""),
        }
    return [by_date[key] for key in sorted(by_date)]


def _select_design(
    theme_override: str | None = None,
    cover_override: str | None = None,
    today: str | None = None,
) -> tuple[str, str]:
    """Pick today's material + composition.

    One issue is fixed per date. All 20 scene/composition pairs are used
    before any repeat, and the last two scenes cannot repeat.
    """
    history = _history_by_date(_read_json(HISTORY_PATH, []))
    today = today or datetime.now().astimezone().date().isoformat()
    if not theme_override and not cover_override:
        for item in reversed(history):
            if item["date"] == today:
                return item["theme"], item["cover"]

    recent = history[-(len(THEMES) * len(COVER_LAYOUTS)):]
    used = {f"{item['theme']}:{item['cover']}" for item in recent}
    recent_themes = {item["theme"] for item in recent[-2:]}
    candidates = [
        (theme, cover)
        for theme, _ in THEMES
        for cover, _ in COVER_LAYOUTS
        if f"{theme}:{cover}" not in used and theme not in recent_themes
    ]
    if not candidates:
        candidates = [
            (theme, cover)
            for theme, _ in THEMES
            for cover, _ in COVER_LAYOUTS
            if f"{theme}:{cover}" not in used
        ]
    if not candidates:
        candidates = [(theme, cover) for theme, _ in THEMES for cover, _ in COVER_LAYOUTS]

    if theme_override in THEME_NAMES:
        candidates = [item for item in candidates if item[0] == theme_override] or [
            (theme_override, cover) for cover, _ in COVER_LAYOUTS
        ]
    if cover_override in COVER_NAMES:
        candidates = [item for item in candidates if item[1] == cover_override] or [
            (theme, cover_override) for theme, _ in THEMES
        ]

    theme, cover = random.SystemRandom().choice(candidates)
    if theme_override or cover_override:
        return theme, cover

    history.append({
        "date": today,
        "theme": theme,
        "cover": cover,
        "name": THEME_NAMES[theme],
        "cover_name": COVER_NAMES[cover],
        "design": f"{theme}:{cover}",
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    })
    _atomic_write(HISTORY_PATH, json.dumps(history[-90:], ensure_ascii=False, indent=2))
    return theme, cover


def _ensure_edition() -> dict:
    edition = _read_json(LATEST_PATH, None)
    today = datetime.now().astimezone().date().isoformat()
    edition_date = str(edition.get("date") or "") if isinstance(edition, dict) else ""
    if isinstance(edition, dict) and edition.get("lead"):
        # 版次就是今天，或者比今天还新（系统时钟回拨过）：直接用，不要触发联网刷新。
        if edition_date and edition_date >= today:
            return edition
    # 联网刷新限制在 90 秒内：抓取可能卡住，不能让它把暮省拖死。
    try:
        from .curator import run as curator_run
        log.info("latest edition is not today; force refresh before evening page")
        box = {}

        def _fetch() -> None:
            try:
                box["r"] = curator_run(force=True, log_fn=lambda *_: None)
            except Exception as exc:  # noqa: BLE001
                box["e"] = exc

        worker = threading.Thread(target=_fetch, daemon=True)
        worker.start()
        worker.join(90)
        if worker.is_alive():
            log.warning("evening refresh timed out after 90s; using latest edition")
        elif "e" in box:
            log.exception("evening refresh failed; falling back to latest edition", exc_info=box["e"])
        elif isinstance(box.get("r"), dict):
            refreshed = box["r"].get("edition")
            if isinstance(refreshed, dict) and refreshed.get("lead"):
                return refreshed
    except Exception:
        log.exception("evening refresh failed; falling back to latest edition")
    if isinstance(edition, dict) and edition.get("lead"):
        return edition
    raise RuntimeError("没有可用的今日版数据，无法生成暮省页面。")


def _date_long(edition: dict) -> str:
    raw = str(edition.get("date") or "")
    try:
        dt = datetime.fromisoformat(raw)
        weekday = edition.get("weekday") or "周" + "一二三四五六日"[dt.weekday()]
        return f"{dt.year}年{dt.month}月{dt.day}日 · {weekday}"
    except Exception:
        return str(edition.get("date_label") or raw) + " · " + str(edition.get("weekday") or "")


def _meta(story: dict, suffix: str = "") -> str:
    bits = [story.get("source", ""), story.get("published_display", "")]
    text = "  ·  ".join(str(x) for x in bits if x)
    if suffix:
        text += "  ·  " + suffix
    return text


def _lead_slide(story: dict, index: int) -> dict:
    return dict(kind="lead", duration=32, section="今日焦点", rail_index=index, rail_label="今日焦点",
                title=story.get("display_title") or story.get("title") or "今日焦点",
                question=str(story.get("question") or "").strip(),
                summary=_clip(story.get("summary") or "", 290),
                meta=_meta(story, str(story.get("read_minutes", 3)) + " 分钟"))


def _story_slide(story: dict, index: int) -> dict:
    title = story.get("display_title") or story.get("title") or ""
    summary = _clip(story.get("summary") or "", 240)
    section = story.get("section_label") or "世界脉络"
    tags = [str(story[k]) for k in ("region", "lens") if story.get(k)]
    return dict(kind="story", duration=_duration(summary + title, base=15, cap=26, floor=18), section=section, rail_index=index, rail_label=section,
                tags=tags, title=title, summary=summary, meta=_meta(story, str(story.get("read_minutes", 2)) + " 分钟"))


def _person_slide(person: dict, index: int) -> dict:
    name = person.get("name") or "今日人物"
    moments = [dict(year=str(m.get("year") or ""), text=str(m.get("text") or "")) for m in (person.get("moments") or [])[:3] if isinstance(m, dict)]
    return dict(kind="person", duration=34, section="人物", rail_index=index, rail_label="人物", name=name,
                latin=f"{person.get('latin') or ''}  {person.get('years') or ''}".strip(), identity=person.get("identity") or "", headline=person.get("headline") or "",
                story=_clip(person.get("story") or "", 260), monogram=person.get("monogram") or name[:1], moments=moments)


def _people_slide(people: list, index: int) -> dict:
    cards = []
    for person in people[:3]:
        if not isinstance(person, dict):
            continue
        name = person.get("name") or "人物"
        quote = person.get("quote") or {}
        moment = next((m for m in person.get("moments") or [] if isinstance(m, dict) and m.get("text")), None)
        cards.append(dict(name=name, latin=person.get("latin") or "", years=person.get("years") or "", identity=person.get("identity") or "",
                          headline=_clip(person.get("headline") or "", 60), story=_clip(person.get("story") or "", 132), monogram=person.get("monogram") or name[:1],
                          quote=_clip(quote.get("text") or "", 46) if isinstance(quote, dict) else "",
                          moment=dict(year=str(moment.get("year") or ""), text=_clip(moment.get("text") or "", 34)) if moment else None))
    return dict(kind="people", duration=44, section="人物", rail_index=index, rail_label="人物", title="今夜三个人", sub="三种选择，三条路", cards=cards)


def _quotes_slide(quotes: list, index: int) -> dict:
    cards = [dict(text=str(q.get("text") or ""), author=f"—— {q.get('author') or ''}，{q.get('source') or ''}", use=str(q.get("use") or "")) for q in quotes[:3] if isinstance(q, dict)]
    if not cards:
        cards = [dict(text="今夜，把一句话留给明天。", author="", use="")]
    return dict(kind="quotes", duration=30, section="今日金句", rail_index=index, rail_label="今日三句", title="把一句话，带到明天", cards=cards)


def _term_slide(term: dict, index: int) -> dict:
    return dict(kind="term", duration=26, section="格局词条", rail_index=index, rail_label="格局词典", term=term.get("term") or "", en=term.get("en") or "",
                definition=_clip(term.get("definition") or "", 260),
                side=[["为什么值得知道", _clip(term.get("why") or "", 220)], ["高考连接", _clip(term.get("exam") or "", 220)], ["容易误解", _clip(term.get("misread") or "", 180)]])


def build_deck(edition: dict, theme: str, cover: str = "left") -> dict:
    theme = LEGACY_THEMES.get(theme, theme)
    if theme not in THEME_NAMES:
        theme = THEMES[0][0]
    if cover not in COVER_NAMES:
        cover = "left"
    lead = edition.get("lead") or {}
    stories = [s for s in edition.get("stories") or [] if isinstance(s, dict)]
    person = edition.get("person") or {}
    alternates = [p for p in edition.get("person_alternates") or [] if isinstance(p, dict)]
    term = edition.get("term") or {}
    slides = [_lead_slide(lead, 1)]
    index = 2
    for story in stories[:6]:
        slides.append(_story_slide(story, index))
        index += 1
    people, seen = [], set()
    for candidate in [person, *alternates]:
        if not isinstance(candidate, dict) or not candidate.get("name"):
            continue
        key = str(candidate.get("id") or candidate.get("name"))
        if key not in seen:
            seen.add(key)
            people.append(candidate)
    if len(people) >= 2:
        slides.append(_people_slide(people, index))
        index += 1
    elif person:
        slides.append(_person_slide(person, index))
        index += 1
    slides.append(_quotes_slide(edition.get("quotes") or [], index))
    index += 1
    if term:
        slides.append(_term_slide(term, index))
        index += 1
    slides.append(dict(kind="end", duration=12, section="今夜已尽", sub="把世界放回远处，把自己还给自己。"))
    date_short = str(edition.get("date_label") or edition.get("date") or "")
    return dict(date=str(edition.get("date") or ""), title=f"暮省 · {date_short}", theme=theme, cover=cover, issue=f"{_issue_number(edition):03d}",
                edition=f"{int(edition.get('edition') or 1):03d}", date_long=_date_long(edition), date_short=(date_short + "  " + str(edition.get("weekday") or "")).strip(),
                count=int(edition.get("read_count") or len(stories) + 1), minutes=int(edition.get("reading_minutes") or 15), slides=slides)


def texture_path(theme: str) -> Path:
    name = f"{theme}.jpg"
    # 打包后 ASSET_DIR 指向见微自己的 assets，观澜的素材在 guanlan/assets 下
    for folder in (TEXTURE_DIR, Path(getattr(sys, "_MEIPASS", TEXTURE_DIR)) / "guanlan" / "assets" / "evening"):
        if (folder / name).is_file():
            return folder / name
    return TEXTURE_DIR / name


def archived_dates() -> list:
    """能重播的往期（新到旧）。1.x 留下的 .html 不算，那些可以直接双击看。"""
    try:
        return sorted((p.stem for p in ARCHIVE_DIR.glob("*.json")), reverse=True)
    except OSError:
        return []


def load_archived(date: str):
    return _read_json(ARCHIVE_DIR / f"{date}.json", None)


_LOCK_HANDLE = None


def _acquire_lock() -> bool:
    """同一时刻只允许一个暮省实例（内部定时 + 计划任务可能同时触发）。"""
    global _LOCK_HANDLE
    if os.name != "nt":
        return True
    try:
        import msvcrt
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        fh = open(RUNTIME_DIR / "evening.lock", "a+")
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        fh.seek(0)
        fh.truncate()
        fh.write(str(os.getpid()))
        fh.flush()
        _LOCK_HANDLE = fh
        return True
    except Exception:
        return False


def prepare(theme: str | None = None, cover: str | None = None):
    """生成今晚的 deck 并存档。返回 (状态, deck)：状态 ok / busy（已有实例在播）/ failed。"""
    _setup_logging()
    if not _acquire_lock():
        log.info("another evening instance is running; skip this trigger")
        return "busy", None
    try:
        edition = _ensure_edition()
        selected, selected_cover = _select_design(theme, cover)
        deck = build_deck(edition, selected, selected_cover)
        text = json.dumps(deck, ensure_ascii=False, indent=1)
        _atomic_write(TODAY_DECK, text)
        _atomic_write(ARCHIVE_DIR / f"{edition.get('date', 'undated')}.json", text)
        log.info("evening deck built theme=%s cover=%s issue=%s date=%s", selected, selected_cover, deck["issue"], edition.get("date"))
        return "ok", deck
    except Exception:
        log.exception("evening deck failed")
        return "failed", None
