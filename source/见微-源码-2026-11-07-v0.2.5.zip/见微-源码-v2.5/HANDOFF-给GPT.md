# 见微 2.4 交接文档（给 GPT / 其他接手的 AI）

## 当前交付：2.4.0（2026-11-06）

前端美术与按键重做（「青瓷仪器」），功能和数据格式不变，详见 `RELEASE-2.4.md`。改界面时：颜色、字体只从 `native/design/tokens.py` 取；学习界面的控件样式都在 `design/widgets.py` 的 `qss()`，别再写局部样式表（尤其别给按钮写 `min-height`，它会覆盖 setFixedHeight，窄栏的键曾因此塌掉）；图标加到 `design/icons.py`。`ui_kit.py` 的 `_LEGACY` 把 `pages.py` 里的旧配色字面量映射到新主题，`#FFFFFF` 会被映射成卡片色，窄栏上的白字要写 `white`。主题切换走 `ui_kit.apply_theme`（会同步 tokens）。新增自测 `native.design.selftest`。发行输出 `release-2.4-2026-11-06`。


## 当前交付：2.3.0（2026-11-06）

画笔与互通阶段 1–5 已完成。下方阶段 1/2 记录为历史状态，不能据此判断当前阶段未开始。版本源为 `app/store.py`。

核心接口：`kit/clip.py` 的 ClipStore/ClipBus 由 NativeWindow 显式持有；`lecture/board_transfer.py`、`lecture/transfer.py` 与 `lecture/inserts.py` 管理双向传送与虚拟插页；`kit/bench_transfer.py` 为五个工作台添加参考图、批注、状态快照、脱离窗口；`clip_ui.py`/`transfer_router.py` 管理通用交互与素材篮。数据新增 clips/、workbench-notes/、workbench-state/；几何画板仍以 lab-math.json 为权威存档，关闭时刷新，不用二级缓存覆盖它。

Clip v1 只接受受控 UUID/本地资产名，矢量笔迹与图像分层；state_graph 使用受限数据图，无任意类反序列化。素材篮裁剪索引不删除已被插页引用的资产。插页使用稳定 history_id，清空笔迹后也持久记录空层。原文件及动画映射不变。

新增专项：`native.kit.clip_selftest`（11 项）、`native.kit.workbench_selftest`（五工作台及比例标定）、`native.kit.interop_selftest`（17 项）。既有课件、析题、题库 412 次、67 实验/5 工作台回归通过。所有测试用 test_runtime + 隔离数据，不启动 Word、不强杀、不读真实密钥；自测环境跳过后台 OCR/联网预热，Qt 回调异常算失败。真机边界与复现步骤见 RELEASE-2.3.md。

发行用 `python tools/release.py build` → `smoke` → `pack`；只在独立 release-2.3-2026-11-06/source 调用 build.build()，不覆盖 src2/dist 或桌面快捷方式。打包核对源码指纹、冻结版结果、ZIP CRC、SHA256；桌面 AI 只新增 v2.3 压缩包。

## 画笔与互通：阶段 2 + 测试弹窗治理（2026-11-06）

阶段 2 已实现，阶段 3–5（Clip/插页、工作台互通、素材篮/拖放与打包）尚未开始。本次没有重新打包。

- `kit/pen_bar.py`：课件与黑板复用同一 PenBar，支持横/竖布局、昼夜令牌、颜色、粗细、工具、撤销/重做，以及「更多」菜单。四个共享预设和吸附开关存用户目录 `pen-settings.json`；不支持/损坏的预设文件不覆盖。P/H/E/L/V 统一；黑板文字 T、课件截取 S 保留。
- `kit/pen_session.py`：独立交互层，注入 get/live/commit/坐标变换回调；原课件页映射、黑板条目拖动保持原逻辑。新增形状、激光、套索移动/缩放/复制/删除、停笔 500ms 吸附（移动恢复手写）、两种橡皮。擦除与变换每次手势作为一个撤销步骤；取消、切页、切工具恢复未提交笔迹。激光纯内存，1 秒淡出。
- `kit/pen_tools.py`：形状由普通 v1 笔画的 points + shape 元数据表示，旧存储可读；局部擦除通过线段/圆相交计算生成可编辑残段。圆心在空白内不会整笔擦掉圆形。变换保留压力、来源扩展字段，复制分配新 id。
- `kit/pen.py`：高亮采用 Multiply 并隔离 painter 状态，避免覆盖黑字；压感绘制平滑化，黑板粉笔开始真正使用 tablet 压力。课件/黑板分开缓存 marker 和普通笔迹，不每帧重画已完成笔画。
- 输入：鼠标/手写笔共用操作；笔尾橡皮；笔接触时抑制触摸与合成鼠标，单指操作、双指平移缩放，并有菜单缩放替代。只做了合成触摸与压力数据测试，未在真实触屏、压感笔或第二屏上验收，不能声称硬件已验证。
- 新增 `python -m native.kit.pen_tools_selftest <隔离目录>`（15 项），main.py --self-test 同时执行两组画笔测试。专项输出 PEN_PHASE2 OK 15，进程 TEST_PROCESS_EXIT 0；200 笔、800×450 缓存重绘实测约 1.08 ms/帧（离屏数据，不是放映帧率承诺）。阶段 1 的 14 项再次通过；课件全套最终输出 LECTURE OK / TEST_PROCESS_EXIT 0。曾有缩略图断言因固定 250ms 等待不足而失败，改为最多 3 秒等待图标就绪后通过。相关文件 pyflakes 无告警。

**用户明确要求后台测试不要再弹 python.exe 错误报告。** 新增 `kit/test_runtime.py`：测试入口先给当前测试进程设置 Windows SetErrorMode 标志 0x8003（含 SEM_NOGPFAULTERRORBOX），保留文字诊断，不修改注册表/系统全局设置、不结束其他进程。所有独立自测入口改用 runtime.application/run；移除题库、析题、课件原来的 os._exit，先停 timers/ctx/worker、关闭并延迟销毁控件，再销毁 QApplication，保留强引用避免提前析构。生产正常启动不启用弹窗抑制。保护标志读取验证通过，基础 Qt 清理与阶段 2 完整专项均正常退出 0。

后续执行测试必须沿用这些入口和隔离的 JIANWEI_HOME/LOCALAPPDATA；不要绕回旧 os._exit 或在未设置保护前运行会加载 Qt 的临时脚本。不得故意制造崩溃验证弹窗。

## 画笔与互通：阶段 1（2026-11-06）

用户已确认 `DESIGN-画笔与互通.md`。阶段 1 已完成，阶段 2–5 尚未实现；此轮没有打包或更换用户程序。

- `kit/pen.py` 是共享绘制、命中、平滑和 History 模型，格式 `v:1,id,tool,color,width,points,pressure,t`，保留未知扩展与 shape/fill 元数据。旧 `pts` 深拷贝迁移，不舍入原坐标/压力；旧时间未知记 null，相同旧笔画分配稳定且互异的 id。
- `lecture/ink.py` 为旧接口兼容层；旧 new_stroke 返回的 pts 与 points 指向同一列表。课件/黑板改为直接使用 kit.pen；落盘只有 points，不重复保存点列。保留既有绘制与缓存行为，黑板原有条目+笔画整体撤销不改。
- `kit/pen_store.py` 在读写边界迁移：课件 `{version:1,pages:{页号:[笔画]}}`；黑板根节点加 version，保留 boards/cur 与扩展。原路径仍是 ink.json / board/board.json。首次实际迁移保存先写 `.legacy-<内容摘要>.bak`，含 BOM 的原字节完整保留。QLockFile + 原字节比较防止多窗口互相覆盖，QSaveFile 原子提交且禁止直接覆盖回退；失败不覆盖原文件。
- 损坏/未来版本存档只读保护，播放器显示持续提示。读取本身不写磁盘；没有用户真实存档参与测试。保护提示不代表新笔迹已保存，重新打开正确文件或升级程序后再继续编辑。
- 新增 `python -m native.kit.pen_selftest <隔离目录>`（14 项），并接入 main.py --self-test，写 pen-result.txt。覆盖模型、深拷贝、逐像素绘制等价、撤销/重做、兼容 API、旧存档备份/重开、版本保护、并发锁、写失败。课件自测新增版本与点列断言。
- 验证：PEN_PHASE1 OK 14；LECTURE OK；67 实验 + 5 工作台昼夜 SELFTEST OK；ANALYSIS SELFTEST OK；题库 BANK SELFTEST OK 412 runs 0 errors，但题库的 os._exit 在离屏退出时仍触发既有 access violation（本次未修改题库退出流程）。课件独立入口也有既有退出异常现象，不能把功能检查结果当作正常退出验证。相关变更 pyflakes 无告警。
- 新模块由显式 import 引用且 build.py 已 collect-submodules native；不是动态注册的实验/工作台，不需要在 lab/all_modules.py 增加注册项。

## 接手更新：课件导入体验（2026-11-06）

后续动画/兼容修复：`effects.Run.paint` 用 save/restore 隔离 opacity/clip，并保留外层裁剪；达到结束时间直接绘制目标帧，未知图层方向安全回退。`convert.py` 新增 PPSM、TXT/MD、常见图片；WPS/旧后缀按 ZIP 内部结构或 RTF 文件头转交正确解析器。`portable.py` 做文本编码识别（UTF-8 BOM / UTF-16 BOM / GB18030）、图片 EXIF 方向、多帧导入；`build.py` 保留 TIFF 插件。新增 15 项格式/合成回归，课件全套输出 LECTURE OK；此轮未验证打包版或真实 Office 转换。动作路径、音视频限制仍在。

`lecture/page.py` 新增名称/原文件名即时搜索、批量任务总进度、导入时继续添加、路径去重、跳过无效路径、取消等待项、失败汇总与一键重试、打开刚导入的课件。取消仅针对尚未开始项，不中断 COM 转换。`library.py` 增加检查、复制、预览生成阶段提示。保留既有内容哈希去重与笔迹。课件离屏全套回归通过（新增搜索、排队去重、取消、重试共 5 项）；未启动 Office、未联网，也未改用户课件数据。本次为源码变更，尚未重新打包。

> 写于 2026-11-06。当前版本 **v2.2.0**（`app/native/store.py` 的 `VERSION`）。
> 更细的改动史见同目录 `HANDOFF.md`（1.x 的 §1–§27、2.0 暮省、2.0 课件）和 `DESIGN-2.0.md`（架构设计）。

## 1. 这是什么

「见微」是用户（高中生，使用中文）的 Windows 桌面学习软件，托盘常驻：

| 模块 | 内容 |
|---|---|
| 习题 | 206 题题库、知识卡、错题本、提示 |
| 实验 | 67 个数理化生实验（原「格物实验台」） |
| 工作 | 五个自由工作台：电路、力学、化学、几何画板、场景搭建 |
| 析题 | 贴题目 → DeepSeek 读题列式、程序求解校验、分步图解（参照 VeloΦ 的思路） |
| 课件 | 导入 Word/PPT → 转 PDF 放映（含动画）、手写笔勾画、框选截取、送黑板、联网查询并由 DeepSeek 核查 |
| 观澜 / 倒计时胶囊 / 暮省 | 新闻浮窗、倒计时、晚间复习（暮省）均已原生化 |

**2.0 起完全不依赖浏览器内核**：全部 Python + PySide6（QPainter）原生绘制，没有 QtWebEngine、没有 HTML。1.x 在 `../src`，只负责导出旧数据，不再迭代。

## 2. 目录

```
jianwei/
  src-orig/        1.x 原始包（勿动）
  src/             1.x 工作副本（v1.7，导出旧数据用）
  src2/            ← 2.x，当前工作区
    app/
      main.py                 入口；--self-test <dir> 跑全部自测
      guanlan/                观澜新闻 + 暮省数据（core/evening.py 只产 deck 数据）
      native/
        main_win.py           主窗口（习题·实验·工作·析题·课件 左侧窄栏）
        shell.py / pages.py   托盘、页面
        store.py              数据存储、VERSION
        design/               设计令牌与控件
        kit/                  Ctx/D/View/compileExpr、bench.py、home.py
        lab/                  studio.py + exps/（67 实验）+ benches/（5 工作台）
        bank/                 题库、知识卡、四种引擎、错题本
        analysis/             析题：protocol.md、llm 流式+修正、17 个题型 tasks_*、viz、offline
        lecture/              课件模块（见 §4）
    build.py                  打包（只能调用 build.build()）
    make_shortcut.py          桌面 见微.lnk
    README-使用说明.md        给用户看的说明
```

## 3. 环境与命令（必须照做）

- 解释器：`F:\space for Claude\jianwei\.venv\Scripts\python.exe`（PySide6 + PyInstaller + **requests + beautifulsoup4**，缺了绿色版里观澜/搜索会静默失效）。
- 离屏自测环境变量：`QT_QPA_PLATFORM=offscreen`、`QT_QPA_FONTDIR=C:\Windows\Fonts`，**`JIANWEI_HOME` 指向临时目录**；测暮省/课件还要把 `LOCALAPPDATA` 也指向临时目录（否则会读写用户真实数据，当晚暮省还会被 deck.json 跳过）。
- 自测入口（在 `src2/app` 下）：
  - `python -m native.selftest <dir>`（实验 + 工作台）
  - `python -m native.bank.selftest <dir>`
  - `python -m native.analysis.selftest <dir>`
  - `python -m native.lecture.selftest <dir>`（119 项）
  - `python main.py --self-test <dir> --no-single`（整合，结果写 `lecture-result.txt`）
- 打包：`import build; build.build()`。**不要直接运行 build.py**（会改用户桌面的快捷方式）。产物 zip 放用户桌面 `AI\`。
- 新增实验 / 工作台文件必须登记到 `native/lab/all_modules.py`（打包后 pkgutil 找不到模块）。
- 离屏测试结尾 `os._exit` 的 0xC0000005 是退出时的假象，真窗口退出码 0。
- 导入 `ui_kit` 前必须已有 QApplication，否则进程直接崩（0xC0000409）。
- 输入框要 `ClickFocus`，否则快捷键要先点一下。

## 4. 课件模块（2.1–2.2，最新工作）

所有文件在 `app/native/lecture/`。

**核心思想：一切转成 PDF，再用 QtPdf 渲染放映。**

- `convert.py`：优先走 COM（隔离的 PowerShell 子进程；PowerPoint/KWPP 处理 PPT，WPS 优先、其次 Word 处理 Word；宏禁用；只退出自己启动的实例），失败或没装 Office 则走内置渲染。
- `builtin.py`：无 Office 时自己画 pptx——文字、形状、图片、表格、图表（从缓存画柱/线/饼）、SmartArt 绘制部分、EMF/WMF（通过 GDI+ PowerShell 转 PNG）、`custGeom`、`mc:AlternateContent`。
- `legacy.py`：读 CFB 格式的 `.ppt`（文字/位置/图片）、`.doc`（文字/图片）、`.rtf`；界面标「简化显示」，无动画、无原配色。
- **动画**：`anim.py` 解析 `p:timing` 得到「步骤计划」，每个动画步骤对应 PDF 的一页（COM 脚本复制幻灯片并隐藏形状/设段落透明度；内置渲染则跳过绘制）。`effects.py` 比较前后两页（Difference 合成 → 灰度 → 字节映射成 Alpha8 蒙版）把变化部分抠成图层，再做淡入/飞入/擦除/缩放/旋转/脉冲等动画；切换效果（淡/推/覆盖/擦/切）和 `advTm` 自动换片也在此。`anim.json` 映射「PDF 页 ↔ 幻灯片」，缺失则恒等映射。
- `pageview.py`：核心播放控件。`PageView.page` = 幻灯片序号，`PageView.pdf` = PDF 页序号；笔迹按幻灯片存，换步骤不丢。
- `lookup.py`：联网查询。并发多来源（360、搜狗、必应 www4+`mkt=zh-CN`、头条），相关性过滤 ≥0.3；遇验证码/403/429 **不绕过**，该来源静音 15 分钟；`_verify` 流式调用 DeepSeek，对每条给 keep/doubt/drop + 理由，结论带 `[n]` 引用，引用被筛掉的条目会去掉；零结果时 `_knowledge` 兜底并标注“未经资料核对”。**只核查标题+摘要，不打开原网页**（界面上已写明）。
- 其余：`panel.py`（查询面板、Card 徽标/折叠）、`player.py`、`page.py`、`library.py`（课件库、缩略图取末帧）、`board.py`（黑板）、`ink.py`（笔）。

## 5. 实测数据（源码版，1920×1080，本机）

- PPT 经 PowerPoint 导入 6 页/9 步 3.8 秒；内置 0.1 秒；旧 .ppt 经 PowerPoint 5.5 秒。
- 动画每步启动 ≤28 ms，放映 50–59 fps。
- 联网：首条结果 0.7–1.6 秒，首条核查 2.1–3.0 秒，全部核查完 3.2–4.6 秒。

## 6. 已知限制

- 不播放视频/音频；动作路径与强调动画只显示成一次脉冲。
- 无 Office 时：旧 .ppt/.doc 为简化显示（无动画、无原配色、表格/形状底色可能缺失，.doc 样式丢失）。
- DeepSeek 核查只基于摘要，不能保证内容正确，重要信息需用户点开核对。
- 搜索靠网页抓取：频繁请求会触发 360/搜狗验证码；百度要验证码，**不要尝试绕过**。必应对程序访问结果偏弱。
- 触屏双指捏合没有移植（有按钮替代）。

## 7. 未验证项（接手后优先补）

1. 一台**真正没装 Office/WPS 的电脑**（目前只是用 `use_com=False` 模拟）。
2. 手写笔压感、第二块屏幕投放。
3. **打包版**里的 COM 转换与联网/DeepSeek（打包版自测只验证了离线+假来源）。
4. 头条解析器只用样本验证过，没在真网络上验证。

## 8. 约束与坑（务必遵守）

- **不要强杀进程**（自动模式会拒绝）。本机 Word 打开文件会报「could not fire the event」并留下退不掉的 WINWORD 后台进程（11048、11896、20340 仍在，需用户手动结束/重启）——**测试不要再启动 Word**，文档优先走 WPS。
- **DeepSeek 密钥**在 `%LOCALAPPDATA%\Jianwei\deepseek.env`，不要打印、不要写进代码或文档。
- 连续密集测搜索会触发验证码；真实联网测试要少跑。
- 桌面快捷方式：WshShortcut 无法保存到含中文的路径，`make_shortcut.py` 先存 ASCII 路径再移动；读 .lnk 同理。
- 打包后观澜素材在 `_MEIPASS/guanlan/assets`，不是 `ASSET_DIR`。
- 改 lab/ 与旧 gewu/ 的内容仅限 1.x；2.x 无 Web 部分。
- 用户偏好：中文沟通；放手让 AI 全力优化美化；交付物 zip 放桌面 `AI\`，不覆盖原件。

## 9. 现有产物

`C:\Users\华为\Desktop\AI\`：
- `见微-绿色版-2026-11-05-v2.2.zip`（约 34 MB）
- `见微-源码-2026-11-05-v2.2.zip`（约 1.5 MB）
- 同目录还有 2.0 与 1.7 的旧包。

桌面 `见微.lnk` 指向 `src2\dist\Jianwei\Jianwei.exe`（即最新版）。

## 10. 可以交给 GPT 的候选任务

- 视频/音频播放；动作路径与强调动画的真实还原。
- 搜索来源的稳定性（更多可用来源、本地缓存、请求节流）；核查时按需抓取原网页前几百字。
- 旧 `.ppt` 无 Office 时的动画与配色。
- 真机（无 Office）与打包版的回归测试。
- 手写笔压感曲线、多屏放映（演讲者视图）。
- 课件库的整理（分组、搜索、最近打开）。


### 2.3 发行环境补充
PyInstaller 曾从 PATH 中的 Poppler 收入非 Windows 接口的 icuuc.dll，导致冻结版 QtCore 导入失败。build.prune 现在剔除意外收入的 icuuc/icudt，使用 Windows 系统 ICU。自测最外层捕获启动异常写 app.log 并返回 1，避免 PyInstaller 模态错误框。当前构建目录为 release-2.3-2026-11-06/source-final；旧失败构建未强杀、未用于交付。修正参数面板后 67 实验/5 工作台昼夜全量回归再次通过。

最终冻结版验收（2026-11-06）：returncode=0；pen=PEN_OK、clip=OK、work-transfer=OK、interop=OK、lecture=LECTURE_OK，TEST_PROCESS_EXIT 0。报告：release-2.3-2026-11-06/frozen-verification.json；修正后使用 Windows 系统 ICU，冻结版启动及全部专项通过。

## 2.3.1 PPT 转换加速（2026-11-06）

动画的每个画面曾重复解码相同图片并创建 QTextLayout。builtin.Package 现在按素材名复用解码图，使用 64 MiB LRU 上限和 QImage 隐式共享副本；关系表按 part 缓存，返回独立字典。SlidePainter 按文字节点、尺寸、母版/版式、主题及样式复用排版，段落隐藏只改变绘制，不改变行位；每张幻灯片结束即释放上一张排版，最多 256 条。

新增 native.lecture.speed_selftest（受 test_runtime 保护、隔离数据、不调用 Office）：含共享图片、段落交替隐藏的 4 张/40 画面夹具，逐页像素和 PDF 文字层比较一致；布局计算 80→8，图片解码 40→1。预热后本机对比 3.0993s→0.1086s，约 28.54 倍，仅代表该重复资源夹具，不代表 Office COM 或所有真实课件。课件完整回归 LECTURE OK / TEST_PROCESS_EXIT 0。大图超过预算仍正常解码但不常驻缓存，返回图修改不会污染缓存。

版本 app/store.py=2.3.1；tools/release.py 当前输出 release-2.3.1-2026-11-06，保留 v2.3 包；冻结自测纳入 ppt-speed-result.txt。

同一夹具的中间 PDF 由 70,843,346 字节降为 1,825,701 字节：重复使用 QImage 还使 PDF 写出器复用图片资源，减少反复压缩与重复嵌入。逐页图像和可选中文字仍相同。

2.3.1 冻结版最终验收：pen、clip、work-transfer、interop、lecture、ppt-speed 六组均通过，进程返回 0（frozen-test-a0a93248）。本版源码与绿色包均按新版本命名，不覆盖 v2.3。
