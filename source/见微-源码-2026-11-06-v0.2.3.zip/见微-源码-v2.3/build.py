"""见微 · 打包（PyInstaller onedir）+ 桌面快捷方式。

用法：python build.py            # 打包
      python build.py --shortcut # 只重建桌面快捷方式
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
DIST = ROOT / "dist"


def build() -> int:
    for junk in (ROOT / "build", DIST, ROOT / "Jianwei.spec"):
        if junk.is_dir():
            shutil.rmtree(junk, ignore_errors=True)
        elif junk.exists():
            junk.unlink()
    args = [
        sys.executable, "-m", "PyInstaller", "--noconfirm", "--onedir", "--windowed",
        "--name", "Jianwei",
        "--icon", str(APP / "assets" / "icon.ico"),
        "--add-data", f"{APP / 'native' / 'bank' / 'questions.json'};native/bank",
        "--add-data", f"{APP / 'native' / 'bank' / 'cards.json'};native/bank",
        "--add-data", f"{APP / 'native' / 'analysis' / 'protocol.md'};native/analysis",
        "--add-data", f"{APP / 'guanlan'};guanlan",
        "--add-data", f"{APP / 'assets'};assets",
        "--paths", str(APP / "guanlan"),
        "--hidden-import", "core.paths", "--hidden-import", "core.evening",
        "--hidden-import", "core.curator", "--hidden-import", "core.autostart",
        "--collect-submodules", "core", "--collect-submodules", "ui",
        # 学习窗口全部是原生控件；实验和工作台靠 pkgutil 动态导入，要显式收进来
        "--paths", str(APP),
        "--collect-submodules", "native", "--hidden-import", "PySide6.QtSvg", "--hidden-import", "PySide6.QtPdf",
        "--exclude-module", "PySide6.QtWebEngineCore", "--exclude-module", "PySide6.QtWebEngineWidgets", "--exclude-module", "PySide6.QtWebChannel",
        "--exclude-module", "PySide6.QtQml", "--exclude-module", "PySide6.QtQuick",
        "--noconsole",
        str(APP / "main.py"),
    ]
    print(" ".join(args[:8]), "…")
    code = subprocess.call(args, cwd=ROOT)
    if code == 0:
        prune(DIST / "Jianwei" / "_internal")
    return code


# ---------------------------------------------------------------- 瘦身
# 见微 2.0 只用 Widgets：从真正用到的模块出发沿 PE 导入表找依赖，其余 Qt DLL / .pyd 删掉。
KEEP_PYD = {"QtCore", "QtGui", "QtWidgets", "QtNetwork", "QtSvg", "QtPdf"}   # QtPdf：课件翻页和取文字


def _pe_imports(path: Path) -> list[str]:
    import struct
    b = path.read_bytes()
    pe = struct.unpack_from("<I", b, 0x3C)[0]
    nsec, optsize = struct.unpack_from("<H", b, pe + 6)[0], struct.unpack_from("<H", b, pe + 20)[0]
    opt = pe + 24
    dd = opt + (112 if struct.unpack_from("<H", b, opt)[0] == 0x20B else 96)
    secs = [struct.unpack_from("<IIII", b, opt + optsize + i * 40 + 8) for i in range(nsec)]

    def off(rva: int):
        for vs, va, rs, rp in secs:
            if va <= rva < va + max(vs, rs):
                return rva - va + rp
        return None
    out, o = [], off(struct.unpack_from("<I", b, dd + 8)[0])
    while o is not None:
        name_rva = struct.unpack_from("<I", b, o + 12)[0]
        if not name_rva:
            break
        no = off(name_rva)
        out.append(b[no:b.index(b"\0", no)].decode("ascii", "replace").lower())
        o += 20
    return out


def prune(internal: Path) -> None:
    # Qt 6.12 uses Windows' unversioned ICU API. A Poppler icuuc.dll found
    # through PATH exports version-suffixed symbols and breaks QtCore startup.
    # No in-process Poppler dependency exists in this application.
    for stray in [internal / "icuuc.dll", *internal.glob("icudt*.dll")]:
        if stray.is_file():
            stray.unlink()
    qt = internal / "PySide6"
    if not qt.is_dir():
        return
    before = sum(f.stat().st_size for f in internal.rglob("*") if f.is_file())
    # 插件只留窗口、样式和常用图片格式：其余（虚拟键盘、PDF、QML……）会把 Quick 等大库牵进来
    keep_plug = {"platforms": {"qwindows", "qoffscreen", "qminimal"}, "styles": None, "imageformats": {"qjpeg", "qico", "qgif", "qsvg", "qwebp", "qtiff"}, "iconengines": None}
    plug = qt / "plugins"
    if plug.is_dir():
        for sub in list(plug.iterdir()):
            if sub.name not in keep_plug:
                shutil.rmtree(sub, ignore_errors=True)
            elif keep_plug[sub.name] is not None:
                for f in sub.glob("*.dll"):
                    if f.stem not in keep_plug[sub.name]:
                        f.unlink()
    for name in ("opengl32sw.dll", "d3dcompiler_47.dll"):   # Widgets 用软件绘制，不需要
        for f in qt.glob(name):
            f.unlink()
    roots = [*[qt / f"{m}.pyd" for m in KEEP_PYD],
             *(qt / "plugins").rglob("*.dll"), *qt.glob("pyside6*.dll"), *internal.glob("shiboken6/*.dll")]
    need, todo = set(), [p for p in roots if p.exists()]
    while todo:
        p = todo.pop()
        for d in _pe_imports(p):
            if d.startswith("qt6") and d not in need:
                need.add(d)
                if (qt / d).exists():
                    todo.append(qt / d)
    removed = []
    for f in qt.glob("Qt6*.dll"):
        if f.name.lower() not in need:
            removed.append(f)
    for f in qt.glob("Qt*.pyd"):
        if f.stem not in KEEP_PYD:
            removed.append(f)
    removed += [f for f in (qt / "translations").glob("*.qm") if "zh_CN" not in f.name]
    for f in removed:
        try:
            f.unlink()
        except OSError:
            pass
    shutil.rmtree(qt / "qml", ignore_errors=True)  # Widgets 程序用不到 QML 插件
    shutil.rmtree(qt / "resources", ignore_errors=True)
    after = sum(f.stat().st_size for f in internal.rglob("*") if f.is_file())
    print(f"prune: {len(removed)} files + qml/, {before / 1e6:.0f} MB → {after / 1e6:.0f} MB")


def shortcut() -> None:
    """桌面快捷方式交给 make_shortcut.py（UTF-16LE VBS，规避 PowerShell 中文编码坑）。"""
    subprocess.call([sys.executable, str(ROOT / "make_shortcut.py")])


if __name__ == "__main__":
    if "--shortcut" in sys.argv:
        shortcut()
    else:
        code = build()
        if code == 0:
            shortcut()
        sys.exit(code)
