"""线性图标：1.6px 圆头描边，坐标系 0..18，按目标矩形缩放。"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QPainter, QPainterPath, QPen


def draw_icon(p: QPainter, name: str, rect, color, width: float = 1.6) -> None:
    r = QRectF(rect)
    s = min(r.width(), r.height()) / 18.0
    p.save()
    p.translate(r.x() + (r.width() - 18 * s) / 2, r.y() + (r.height() - 18 * s) / 2)
    p.scale(s, s)
    pen = QPen(color, width / s)   # 描边保持屏幕上 width 像素，不随图标缩放变粗变细
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    f = _ICONS.get(name)
    if f:
        f(p, color)
    p.restore()


def _menu(p, c):
    for y in (5, 9, 13):
        p.drawLine(QPointF(3, y), QPointF(15, y))


def _search(p, c):
    p.drawEllipse(QPointF(8, 8), 4.6, 4.6)
    p.drawLine(QPointF(11.4, 11.4), QPointF(15, 15))


def _sun(p, c):
    p.drawEllipse(QPointF(9, 9), 3.4, 3.4)
    for k in range(8):
        a = k * math.pi / 4
        p.drawLine(QPointF(9 + 5.4 * math.cos(a), 9 + 5.4 * math.sin(a)), QPointF(9 + 7 * math.cos(a), 9 + 7 * math.sin(a)))


def _moon(p, c):
    path = QPainterPath(QPointF(12.5, 3.2))
    path.arcTo(QRectF(2.5, 2.5, 13, 13), 60, 250)
    path.cubicTo(9, 13, 7, 7, 12.5, 3.2)
    p.drawPath(path)


def _reset(p, c):
    path = QPainterPath()
    path.arcMoveTo(QRectF(3, 3, 12, 12), 60)
    path.arcTo(QRectF(3, 3, 12, 12), 60, 280)
    p.drawPath(path)
    p.drawLine(QPointF(12, 2.5), QPointF(12.2, 5.6))
    p.drawLine(QPointF(12.2, 5.6), QPointF(9.2, 5.8))


def _camera(p, c):
    p.drawRoundedRect(QRectF(2.5, 5, 13, 9.5), 2, 2)
    p.drawEllipse(QPointF(9, 9.8), 2.8, 2.8)
    p.drawLine(QPointF(6.5, 5), QPointF(7.6, 3.2))
    p.drawLine(QPointF(7.6, 3.2), QPointF(10.4, 3.2))
    p.drawLine(QPointF(10.4, 3.2), QPointF(11.5, 5))


def _full(p, c):
    for (x, y, dx, dy) in ((3, 3, 1, 1), (15, 3, -1, 1), (3, 15, 1, -1), (15, 15, -1, -1)):
        p.drawLine(QPointF(x, y), QPointF(x + 4 * dx, y))
        p.drawLine(QPointF(x, y), QPointF(x, y + 4 * dy))


def _side(p, c):
    p.drawRoundedRect(QRectF(2.5, 3.5, 13, 11), 2, 2)
    p.drawLine(QPointF(11, 3.5), QPointF(11, 14.5))


def _home(p, c):
    p.drawPolyline([QPointF(2.5, 9), QPointF(9, 3), QPointF(15.5, 9)])
    p.drawPolyline([QPointF(4.5, 7.5), QPointF(4.5, 15), QPointF(13.5, 15), QPointF(13.5, 7.5)])


def _grid(p, c):
    for v in (3, 9, 15):
        p.drawLine(QPointF(v, 3), QPointF(v, 15))
        p.drawLine(QPointF(3, v), QPointF(15, v))


def _play(p, c):
    path = QPainterPath(QPointF(5.5, 3.5))
    path.lineTo(14, 9)
    path.lineTo(5.5, 14.5)
    path.closeSubpath()
    p.drawPath(path)


def _pause(p, c):
    p.drawLine(QPointF(6.5, 4), QPointF(6.5, 14))
    p.drawLine(QPointF(11.5, 4), QPointF(11.5, 14))


def _spark(p, c):
    path = QPainterPath(QPointF(9, 2.5))
    path.quadTo(9.6, 8.4, 15.5, 9)
    path.quadTo(9.6, 9.6, 9, 15.5)
    path.quadTo(8.4, 9.6, 2.5, 9)
    path.quadTo(8.4, 8.4, 9, 2.5)
    p.drawPath(path)


_ICONS = {"menu": _menu, "search": _search, "sun": _sun, "moon": _moon, "reset": _reset, "camera": _camera,
          "full": _full, "side": _side, "home": _home, "grid": _grid, "play": _play, "pause": _pause, "spark": _spark}
