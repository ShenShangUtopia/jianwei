"""见微 2.0 通用控件与样式表（全部从 tokens 取色，切主题后调用 qss() 重新套用）。"""
from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QLayout, QPushButton, QSizePolicy, QWidget, QWidgetItem

from .tokens import RADIUS, T, family, font, qc


def qss() -> str:
    """2.0 原生界面的样式表：纸面、细线、单色相阶梯。"""
    t = T
    ui, mono = family("ui"), family("mono")
    return f"""
QWidget#jw2 {{ background:{t.bg}; color:{t.fg}; font-family:"{ui}"; font-size:13px; }}
QWidget#jw2 QToolTip {{ background:{t.raised}; color:{t.fg}; border:1px solid {t.line2}; padding:5px 8px; border-radius:6px; }}
QFrame#panel, QWidget#panel {{ background:{t.surface}; }}
QLabel {{ background:transparent; color:{t.fg}; }}
QLabel#grpTitle {{ color:{t.muted}; font-size:11.5px; font-weight:600; letter-spacing:1.2px; padding:2px 0 0 0; }}
QLabel#ctlLabel {{ color:{t.soft}; font-size:12.5px; }}
QLabel#ctlValue {{ color:{t.accent}; font-family:"{mono}"; font-size:12.5px; }}
QLabel#note {{ color:{t.muted}; font-size:12px; }}
QLabel#err {{ color:{t.bad}; font-size:11.5px; }}
QLabel#out {{ background:{t.raised}; border:1px solid {t.line}; border-radius:{RADIUS['md']}px; padding:8px 10px; }}
QPushButton#btn, QPushButton#seg {{ background:{t.raised}; color:{t.fg}; border:1px solid {t.line2};
  border-radius:{RADIUS['sm']}px; padding:5px 11px; font-size:12.5px; }}
QPushButton#btn:hover, QPushButton#seg:hover {{ background:{t.hover}; }}
QPushButton#btn:pressed {{ background:{t.press}; }}
QPushButton#btn:checked, QPushButton#seg:checked {{ background:{t.accent}; color:{t.stage}; border-color:{t.accent}; }}
QPushButton#pri {{ background:{t.accent}; color:{t.stage}; border:1px solid {t.accent}; border-radius:{RADIUS['sm']}px;
  padding:5px 12px; font-size:12.5px; font-weight:600; }}
QPushButton#pri:hover {{ background:{qc(t.accent).lighter(112).name()}; }}
QLineEdit, QPlainTextEdit, QComboBox {{ background:{t.stage}; color:{t.fg}; border:1px solid {t.line2};
  border-radius:{RADIUS['sm']}px; padding:4px 8px; selection-background-color:{t.accent}; font-family:"{mono}"; font-size:12.5px; }}
QComboBox {{ font-family:"{ui}"; }}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border-color:{t.accent}; }}
QComboBox::drop-down {{ border:none; width:18px; }}
QComboBox QAbstractItemView {{ background:{t.raised}; color:{t.fg}; border:1px solid {t.line2}; selection-background-color:{t.hover}; selection-color:{t.fg}; }}
QCheckBox {{ color:{t.soft}; font-size:12.5px; spacing:7px; }}
QCheckBox::indicator {{ width:15px; height:15px; border:1px solid {t.line2}; border-radius:4px; background:{t.stage}; }}
QCheckBox::indicator:checked {{ background:{t.accent}; border-color:{t.accent}; }}
QSlider::groove:horizontal {{ height:4px; background:{t.line}; border-radius:2px; }}
QSlider::sub-page:horizontal {{ height:4px; background:{t.accent}; border-radius:2px; }}
QSlider::handle:horizontal {{ width:14px; height:14px; margin:-6px 0; border-radius:7px; background:{t.stage}; border:2px solid {t.accent}; }}
QSlider::handle:horizontal:hover {{ background:{t.accent}; }}
QScrollArea {{ background:transparent; border:none; }}
QScrollArea > QWidget > QWidget {{ background:transparent; }}
QScrollBar:vertical {{ background:transparent; width:8px; margin:2px; }}
QScrollBar::handle:vertical {{ background:{t.line2}; border-radius:3px; min-height:30px; }}
QScrollBar::handle:vertical:hover {{ background:{t.faint}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ height:0; background:transparent; }}
QScrollBar:horizontal {{ height:0; }}
QTextBrowser {{ background:transparent; border:none; color:{t.soft}; font-size:13px; }}
"""


class FlowLayout(QLayout):
    """按钮自动换行。"""

    def __init__(self, parent=None, spacing: int = 6):
        super().__init__(parent)
        self._items: list = []
        self.setSpacing(spacing)
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):  # noqa: N802
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):  # noqa: N802
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):  # noqa: N802
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):  # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self):  # noqa: N802
        return True

    def heightForWidth(self, w):  # noqa: N802
        return self._layout(QRect(0, 0, w, 0), True)

    def setGeometry(self, r):  # noqa: N802
        super().setGeometry(r)
        self._layout(r, False)

    def sizeHint(self):  # noqa: N802
        return self.minimumSize()

    def minimumSize(self):  # noqa: N802
        s = QSize()
        for it in self._items:
            s = s.expandedTo(it.minimumSize())
        return s

    def _layout(self, rect, test):
        x, y, line = rect.x(), rect.y(), 0
        sp = self.spacing()
        for it in self._items:
            hint = it.sizeHint()
            nx = x + hint.width() + sp
            if nx - sp > rect.right() + 1 and line > 0:
                x, y = rect.x(), y + line + sp
                nx, line = x + hint.width() + sp, 0
            if not test:
                it.setGeometry(QRect(QPoint(x, y), hint))
            x, line = nx, max(line, hint.height())
        return y + line - rect.y()


class Segmented(QWidget):
    """顶栏的模式切换：一排文字按钮，选中项下方一道细线。"""
    changed = Signal(str)

    def __init__(self, items: list[tuple[str, str]], value: str):
        super().__init__()
        self.items, self.value, self.hover = items, value, None
        self.setMouseTracking(True)
        self.setFixedHeight(34)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._f = font(13.5, 500)
        from PySide6.QtGui import QFontMetrics
        fm = QFontMetrics(self._f)
        self._w = [fm.horizontalAdvance(t) + 28 for _, t in items]
        self.setFixedWidth(sum(self._w))

    def _at(self, x):
        acc = 0
        for (k, _), w in zip(self.items, self._w):
            if acc <= x < acc + w:
                return k
            acc += w
        return None

    def set_value(self, v: str) -> None:
        self.value = v
        self.update()

    def mouseMoveEvent(self, e):  # noqa: N802
        h = self._at(e.position().x())
        if h != self.hover:
            self.hover = h
            self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = None
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        k = self._at(e.position().x())
        if k and k != self.value:
            self.value = k
            self.update()
            self.changed.emit(k)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setFont(self._f)
        x = 0
        for (k, t), w in zip(self.items, self._w):
            on = k == self.value
            if k == self.hover and not on:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.hover))
                p.drawRoundedRect(x + 3, 3, w - 6, self.height() - 6, 7, 7)
            p.setPen(qc(T.fg if on else T.muted))
            p.drawText(QRect(x, 0, w, self.height() - 3), int(Qt.AlignmentFlag.AlignCenter), t)
            if on:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.accent))
                p.drawRoundedRect(x + w / 2 - 10, self.height() - 4, 20, 2.5, 1.2, 1.2)
            x += w
        p.end()


class TabBar(QWidget):
    """侧栏标签：参数 / 原理 / 讲题。"""
    changed = Signal(int)

    def __init__(self, labels: list[str]):
        super().__init__()
        self.labels, self.cur = labels, 0
        self.setFixedHeight(40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_index(self, i: int) -> None:
        self.cur = i
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        i = int(e.position().x() / max(1, self.width()) * len(self.labels))
        i = max(0, min(len(self.labels) - 1, i))
        if i != self.cur:
            self.cur = i
            self.update()
            self.changed.emit(i)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w = self.width() / len(self.labels)
        p.setFont(font(13, 500))
        for i, t in enumerate(self.labels):
            p.setPen(qc(T.fg if i == self.cur else T.muted))
            p.drawText(QRect(int(i * w), 0, int(w), self.height() - 2), int(Qt.AlignmentFlag.AlignCenter), t)
        p.setPen(QPen(qc(T.line), 1))
        p.drawLine(0, self.height() - 1, self.width(), self.height() - 1)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qc(T.accent))
        p.drawRoundedRect(int(self.cur * w + w / 2 - 14), self.height() - 3, 28, 3, 1.5, 1.5)
        p.end()


class IconButton(QPushButton):
    """画在 QPainter 上的线性图标按钮（顶栏、画布工具条用）。"""

    def __init__(self, icon: str, tip: str = "", size: int = 30, checkable: bool = False):
        super().__init__()
        self.icon, self._hover = icon, False
        self.setFixedSize(size, size)
        self.setToolTip(tip)
        self.setCheckable(checkable)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFlat(True)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self, e):  # noqa: N802
        self._hover = True
        self.update()

    def leaveEvent(self, e):  # noqa: N802
        self._hover = False
        self.update()

    def paintEvent(self, _e):  # noqa: N802
        from .icons import draw_icon
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self.isChecked() or self._hover or self.isDown():
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qc(T.accent, 0.16) if self.isChecked() else qc(T.hover))
            p.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 8, 8)
        col = qc(T.accent if self.isChecked() else (T.fg if self._hover else T.muted))
        m = self.width() * 0.24
        draw_icon(p, self.icon, self.rect().adjusted(int(m), int(m), -int(m), -int(m)), col)
        p.end()


def hline() -> QWidget:
    w = QWidget()
    w.setFixedHeight(1)
    w.setStyleSheet(f"background:{T.line};")
    return w


def _unused() -> None:  # 保持导入整洁
    _ = (QColor, QSizePolicy, QWidgetItem)
