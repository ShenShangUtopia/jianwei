"""见微 2.0 设计令牌：界面色（昼 / 夜）、数据色板、字体、间距、圆角、动效。

界面与实验画布都从这里取色；切换主题只需 set_theme()，再让窗口重画。
数据色板改编自 Okabe–Ito（色盲友好），按昼 / 夜各调一套明度，保证在纸底和墨底上都够对比。
"""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase

DAY = {
    # 纸面
    "bg": "#F3EEE6", "surface": "#FBF8F3", "raised": "#FFFFFF", "stage": "#FFFDF9",
    "fg": "#0B1F4F", "soft": "#33456E", "muted": "#5F6E8C", "faint": "#93A0B8",
    "line": "#E2E0DA", "line2": "#D3D0C8", "hover": "#EDE8DF", "press": "#E4DED3",
    # 画布
    "grid": "#ECEAE4", "grid2": "#DAD8D1", "axis": "#7E879A",
    # 语义
    "accent": "#2B55A6", "gold": "#B8893A", "ok": "#2E8B57", "bad": "#C8372D", "warn": "#C98A00",
    # 学科
    "math": "#2B55A6", "phys": "#B5502B", "chem": "#0F7D78", "bio": "#53831F",
    # 数据（Okabe–Ito 改编）
    "c1": "#0072B2", "c2": "#D55E00", "c3": "#009E73", "c4": "#C98A00", "c5": "#A35A98", "c6": "#3A9AD9",
    "shadow": "rgba(11,31,79,0.10)",
}
NIGHT = {
    "bg": "#0A111E", "surface": "#111B2D", "raised": "#16223A", "stage": "#0C1525",
    "fg": "#E6EDF7", "soft": "#C4D0E3", "muted": "#9AA9C0", "faint": "#66758F",
    "line": "#243149", "line2": "#2E3C57", "hover": "#18253B", "press": "#1E2D47",
    "grid": "#142036", "grid2": "#22304A", "axis": "#7C8CA6",
    "accent": "#86ADF0", "gold": "#E4B863", "ok": "#5CC98A", "bad": "#FF6B5E", "warn": "#F2C14E",
    "math": "#86ADF0", "phys": "#EE8A5E", "chem": "#4CC3B5", "bio": "#9CCC5A",
    "c1": "#5AB0F0", "c2": "#FF8A4C", "c3": "#3CCB9A", "c4": "#F2C14E", "c5": "#D68FC0", "c6": "#7CC8F2",
    "shadow": "rgba(0,0,0,0.45)",
}

_theme = "day"
_subject = "math"


class _Palette(dict):
    """T.fg / T['fg'] 两种写法都行；T.c 是数据色列表；T.accent 跟当前学科走。"""

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError as e:
            raise AttributeError(k) from e


T = _Palette()


def _rebuild() -> None:
    src = NIGHT if _theme == "night" else DAY
    T.clear()
    T.update(src)
    T["accent"] = src.get(_subject, src["accent"])
    T["c"] = [src[f"c{i}"] for i in range(1, 7)]
    T["dark"] = _theme == "night"


def set_theme(name: str) -> None:
    global _theme
    _theme = "night" if name == "night" else "day"
    _rebuild()


def set_subject(subj: str) -> None:
    global _subject
    _subject = subj
    _rebuild()


def theme() -> str:
    return _theme


def qc(c, a: float | None = None) -> QColor:
    """'#rrggbb' / 'rgba(...)' / QColor → QColor，可另给透明度。"""
    if isinstance(c, QColor):
        col = QColor(c)
    elif isinstance(c, str) and c.startswith("rgb"):   # rgb(...) / rgba(...)
        parts = [x.strip() for x in c[c.index("(") + 1:c.index(")")].split(",")]
        col = QColor(int(float(parts[0])), int(float(parts[1])), int(float(parts[2])))
        if len(parts) > 3:
            col.setAlphaF(max(0.0, min(1.0, float(parts[3]))))
    else:
        col = QColor(c)
    if a is not None:
        col.setAlphaF(max(0.0, min(1.0, a)))
    return col


def alpha(c, a: float) -> QColor:
    return qc(c, a)


def css(c, a: float | None = None) -> str:
    """样式表里用的颜色字符串（带透明度时写成 rgba()）。"""
    col = qc(c, a)
    if col.alpha() == 255:
        return col.name()
    return f"rgba({col.red()},{col.green()},{col.blue()},{col.alphaF():.3f})"


# ---------------------------------------------------------------- 字体
SIZE = {"xs": 11, "sm": 12, "md": 13, "lg": 15, "xl": 18, "h2": 22, "h1": 28}
SPACE = {"xs": 4, "sm": 8, "md": 12, "lg": 16, "xl": 24}
RADIUS = {"sm": 6, "md": 10, "lg": 14}
MOTION = {"fast": 120, "base": 160, "slow": 240}

_fam: dict = {}


def _pick(cands: list[str]) -> str:
    have = set(QFontDatabase.families())
    for f in cands:
        if f in have:
            return f
    return cands[-1]


def family(kind: str) -> str:
    if kind not in _fam:
        _fam[kind] = _pick({
            "ui": ["Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans SC", "PingFang SC", "sans-serif"],
            "num": ["Cambria", "Georgia", "Times New Roman", "serif"],
            "mono": ["Cascadia Mono", "Consolas", "IBM Plex Mono", "monospace"],
            "serif": ["Noto Serif SC", "SimSun", "Songti SC", "serif"],
        }[kind])
    return _fam[kind]


_fonts: dict = {}


def font(px: float = 13, weight: int = 400, kind: str = "ui", spacing: float = 0.0) -> QFont:
    key = (round(px, 2), weight, kind, spacing)
    f = _fonts.get(key)
    if f is None:
        f = QFont(family(kind))
        f.setPixelSize(max(6, int(round(px))))
        f.setWeight(QFont.Weight(weight))
        if spacing:
            f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
        f.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
        _fonts[key] = f
    return f


_rebuild()
