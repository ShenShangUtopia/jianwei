"""见微 2.0 的学习窗口：习题台 · 实验台 · 工作台 · 析题 · 课件，全部原生（不依赖网页与浏览器内核）。

左边一条窄栏切换模式；每个模式第一次用到时才创建，打开快、占内存少。
"""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QVBoxLayout, QWidget

from .design import tokens
from .design.tokens import T
from .kit.home import home

MODES = (("desk", "习题"), ("lab", "实验"), ("bench", "工作"), ("analysis", "析题"), ("lecture", "课件"))


class NativeWindow(QWidget):
    def __init__(self, theme="day"):
        super().__init__()
        self.setObjectName("jw2")
        self.setWindowTitle("见微")
        self.resize(1440, 900)
        self.setMinimumSize(1000, 620)
        tokens.set_theme(theme)
        self.pages = {}
        from .kit.clip import ClipBus
        from .kit.transfer_router import TransferRouter
        self.clip_bus = ClipBus(self)
        self.transfer_router = TransferRouter(self,self.clip_bus)
        self.material_basket = None
        self.clip_bus.basket_requested.connect(self.show_materials)
        self.mode = None
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        self.rail = QFrame()
        self.rail.setObjectName("modeRail")
        self.rail.setFixedWidth(58)
        v = QVBoxLayout(self.rail)
        v.setContentsMargins(6, 10, 6, 10)
        v.setSpacing(6)
        self.btns = {}
        for key, text in MODES:
            b = QPushButton(text)
            b.setCheckable(True)
            b.setFixedHeight(46)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _c=False, k=key: self.goto(k))
            v.addWidget(b)
            self.btns[key] = b
        v.addStretch(1)
        materials = QPushButton("素材")
        materials.clicked.connect(self.show_materials)
        v.addWidget(materials)
        h.addWidget(self.rail)
        self.stack = QStackedWidget()
        h.addWidget(self.stack, 1)
        self.transfer_notice = QLabel(self)
        self.transfer_notice.setWordWrap(True)
        self.transfer_notice.hide()
        self.clip_bus.error.connect(self.show_transfer_error)
        self._restore()
        self.apply_theme()

    # ---- 模式
    def page(self, key):
        if key in self.pages:
            return self.pages[key]
        if key == "desk":
            from .bank.desk import Desk
            w = Desk("night" if T.dark else "day")
        elif key in ("lab", "bench"):
            from .lab.studio import Studio
            if "lab" in self.pages or "bench" in self.pages:   # 实验台和工作台共用一个窗口体
                w = self.pages.get("lab") or self.pages.get("bench")
            else:
                w = Studio("night" if T.dark else "day",self.clip_bus)
        elif key == "lecture":
            from .lecture.page import LecturePage
            w = LecturePage(self.clip_bus)
        else:
            from .analysis.page import AnalysisPage
            w = AnalysisPage()
            self.transfer_router.bind_analysis(w)
        self.pages[key] = w
        if self.stack.indexOf(w) < 0:
            self.stack.addWidget(w)
        return w

    def goto(self, key, sub=""):
        w = self.page(key)
        self.mode = key
        for k, b in self.btns.items():
            b.setChecked(k == key)
        self.stack.setCurrentWidget(w)
        if key in ("lab", "bench"):
            from .kit.bench import bench
            if key == "bench":
                bid = sub or (w.cur_bench.id if w.cur_bench else (bench.list[0].id if bench.list else None))
                if bid:
                    w.open_bench(bid)
            elif sub.startswith("subj/"):
                w.set_subj(sub[5:])
                w.go_home()
            elif sub:
                w.open(sub)
            elif w.cur_bench:
                w.go_home()
            else:
                w.set_subj(w.subj)
        elif key == "desk" and sub:
            w.open(sub)
        self.sync_theme(w)
        return w

    def sync_theme(self, w=None):
        w = w or self.stack.currentWidget()
        if w is not None and hasattr(w, "apply_theme"):
            w.apply_theme()
        self.apply_theme()

    def set_theme(self, theme):
        tokens.set_theme(theme)
        self.sync_theme()
        lecture = self.pages.get("lecture")
        if lecture is not None and lecture is not self.stack.currentWidget():
            lecture.apply_theme()
        if self.material_basket:
            self.material_basket.apply_theme()

    def show_materials(self):
        if self.material_basket is None:
            from .kit.clip_ui import MaterialBasket
            self.material_basket = MaterialBasket(self.clip_bus,self)
        self.present()
        self.material_basket.setVisible(not self.material_basket.isVisible())
        self.material_basket.raise_()

    def show_transfer_error(self,text):
        self.transfer_notice.setText(text)
        self.transfer_notice.setStyleSheet(f"background:{T.surface};color:{T.bad};border:1px solid {T.line};padding:10px;")
        self.transfer_notice.setFixedWidth(min(700,max(240,self.width()-100)))
        self.transfer_notice.adjustSize()
        self.transfer_notice.move(76,12)
        self.transfer_notice.show()
        self.transfer_notice.raise_()
        QTimer.singleShot(7000,self,self.transfer_notice.hide)

    def resizeEvent(self,event):  # noqa: N802
        super().resizeEvent(event)
        basket = getattr(self,"material_basket",None)
        if basket:
            basket.setGeometry(max(0,self.width()-300),0,300,self.height())

    def apply_theme(self):
        t = T
        self.setStyleSheet(f"""
QFrame#modeRail {{ background:{t.surface}; border-right:1px solid {t.line}; }}
QFrame#modeRail QPushButton {{ border:none; border-radius:8px; background:transparent; color:{t.muted}; font-size:13px; }}
QFrame#modeRail QPushButton:hover {{ background:{tokens.css(t.fg, 0.06)}; color:{t.fg}; }}
QFrame#modeRail QPushButton:checked {{ background:{tokens.css(t.accent, 0.14)}; color:{t.accent}; font-weight:700; }}
QWidget#jw2 {{ background:{t.bg}; }}
""")

    # ---- 打开入口（给本体外壳用）
    def open_question(self, qid=""):
        self.goto("desk", qid)
        self.present()

    def open_lab(self, mode=""):
        if mode == "import":
            self.goto("analysis")
        elif mode == "bench":
            self.goto("bench")
        elif mode.startswith("bench/"):
            self.goto("bench", mode[6:])
        else:
            self.goto("lab", mode)
        self.present()

    def open_lecture(self):
        self.goto("lecture")
        self.present()

    def open_import(self):
        d = self.goto("desk")
        self.present()
        QTimer.singleShot(0, d.show_import)

    def present(self):
        self.showNormal() if self.isMinimized() else self.show()
        self.raise_()
        self.activateWindow()

    # ---- 窗口位置
    def _geom_file(self) -> Path:
        return home() / "window-native.json"

    def _restore(self):
        try:
            g = json.loads(self._geom_file().read_text(encoding="utf-8"))
            self.resize(int(g["w"]), int(g["h"]))
            self.move(int(g["x"]), int(g["y"]))
        except (OSError, ValueError, KeyError, TypeError):
            pass

    def closeEvent(self, e):  # noqa: N802
        try:
            self._geom_file().write_text(json.dumps(dict(x=self.x(), y=self.y(), w=self.width(), h=self.height())), encoding="utf-8")
        except OSError:
            pass
        desk = self.pages.get("desk")
        if desk:
            desk.pause()
        e.accept()

    def shutdown(self):
        self.transfer_router.closing = True
        for studio in {self.pages[k] for k in ("lab","bench") if k in self.pages}:
            studio._close_exp()
        a = self.pages.get("analysis")
        if a:
            a.shutdown()
        lec = self.pages.get("lecture")
        if lec:
            lec.shutdown()
