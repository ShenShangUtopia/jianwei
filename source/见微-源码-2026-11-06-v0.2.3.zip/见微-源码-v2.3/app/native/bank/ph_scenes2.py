"""物理场景（二）：串并联电路、平行板偏转、一维碰撞、卫星圆轨道、电场线与等势面。"""
from __future__ import annotations

import math

from ..design.tokens import alpha, qc
from ..kit.core import clamp
from ..kit.draw import D
from .ph_core import (INF, PI, TAU, Chip, Scene, bars_panel, cos, dim_line, dot, fill_circle, fmt, hypot, label, march_squares, nice, on_color, p_arrow, path_point,
                      path_table, plabel, polyline, ring_world, scene, sin, sqrt, stroke_arc, tag_box, vec, view_rect)
from .sb_core import C


@scene("circuit")
class Circuit(Scene):
    sliders = [("E", "电动势 E", 1.5, 12, 0.5, 1), ("r", "内阻 r", 0.1, 2, 0.1, 1), ("R1", "电阻 R₁", 1, 20, 0.5, 1), ("R2", "电阻 R₂", 1, 20, 0.5, 1)]
    hints = ["闭合电路欧姆定律：I = E / (R外 + r)。", "路端电压 U = E − Ir，外电阻越大，U 越接近 E。", "滑动变阻器改变外电阻，电流、电压与功率随之改变。"]
    hot = [[1], [1, 2], [0, 2, 3]]
    mode = 0

    def defaults(self):
        return dict(E=6, r=0.5, R1=4, R2=6)

    def make_chips(self):
        return [Chip("连接方式", ["串联", "并联"], lambda i: setattr(self, "mode", i))]

    def aux(self, src):
        v = src.get("Emf", src.get("emf"))
        if v is not None and src.get("E") is None:
            try:
                self.P.E = float(v)
            except (TypeError, ValueError):
                pass

    def duration(self):
        return 8

    def calc(self, t):
        P = self.P
        R3 = 2 + 8 * (0.5 - 0.5 * cos(TAU * t / 8))
        if self.mode == 0:
            Rt = P.R1 + P.R2 + R3 + P.r
            I = P.E / Rt
            return dict(R3=R3, Rt=Rt, I=I, U=P.E - I * P.r, P1=I * I * P.R1, I1=I, I2=I)
        Rp = P.R1 * P.R2 / (P.R1 + P.R2)
        Rt = Rp + R3 + P.r
        I = P.E / Rt
        Up = I * Rp
        I1, I2 = Up / P.R1, Up / P.R2
        return dict(R3=R3, Rt=Rt, I=I, U=P.E - I * P.r, P1=I1 * I1 * P.R1, I1=I1, I2=I2)

    def r_base(self):
        P = self.P
        return P.R1 + P.R2 + P.r if self.mode == 0 else P.R1 * P.R2 / max(P.R1 + P.R2, 1e-6) + P.r

    def draw(self, cv, t, lv):
        P, g, w, h = self.P, cv.g, cv.w, cv.h
        for x in range(20, int(w), 40):
            D.line(g, x + 0.5, 0, x + 0.5, h, C.grid2, 1)
        for y in range(20, int(h), 40):
            D.line(g, 0, y + 0.5, w, y + 0.5, C.grid2, 1)
        c = self.calc(t)
        xL, xR, yT, yB = w * 0.16, w * 0.85, h * 0.24, h * 0.8
        yM = (yT + yB) / 2
        ink2, acc = C.ink2, C.accent
        r_base = self.r_base()
        i_max = P.E / max(r_base + 2, 1e-6)

        def wire(x1, y1, x2, y2):
            D.line(g, x1, y1, x2, y2, ink2, 1.8)

        def flow(x1, y1, x2, y2, amp):
            if amp < 1e-9:
                return
            ln = hypot(x2 - x1, y2 - y1)
            if ln < 4:
                return
            n = clamp((amp / i_max) * 1.05, 0.3, 1.2)   # 电流可能只有 mA 级：按本电路最大电流归一，保证看得见在流
            speed, spacing = 12 + 42 * n, 36 - 12 * n
            ux, uy = (x2 - x1) / ln, (y2 - y1) / ln
            s = (t * speed) % spacing
            while s < ln:
                D.circle(g, x1 + ux * s, y1 + uy * s, 2.5, acc)
                s += spacing
            ang = math.atan2(y2 - y1, x2 - x1)
            mx, my = x1 + (x2 - x1) * 0.56, y1 + (y2 - y1) * 0.56
            D.poly(g, [(mx, my), (mx - 8 * cos(ang - 0.4), my - 8 * sin(ang - 0.4)), (mx - 8 * cos(ang + 0.4), my - 8 * sin(ang + 0.4))], acc)

        def res(cx, cy, text):
            D.rect(g, cx - 26, cy - 8, 52, 16, C.card, C.ink, 1.6)
            D.text(g, text, cx, cy + 1, C.ink, size=11, bold=True, align="center")
        wire(xL, yB, xL, yM + 8)
        wire(xL, yM - 8, xL, yT)
        wire(xL, yT, xR, yT)
        wire(xR, yT, xR, yB)
        wire(xL, yB, xR, yB)
        D.line(g, xL - 14, yM - 8, xL + 14, yM - 8, C.ink, 2.4)
        D.line(g, xL - 7, yM + 8, xL + 7, yM + 8, C.ink, 2.4)
        D.text(g, "+", xL - 20, yM - 8, acc, size=12, bold=True, align="right")
        D.text(g, "−", xL - 20, yM + 10, acc, size=12, bold=True, align="right")
        back = [(xR, yT, xR, yB), (xR, yB, xL, yB), (xL, yB, xL, yM + 8), (xL, yM - 8, xL, yT)]
        if self.mode == 0:
            r1, r2 = w * 0.37, w * 0.63
            res(r1, yT, "R₁")
            res(r2, yT, "R₂")
            for s in [(xL, yT, r1 - 26, yT), (r1 + 26, yT, r2 - 26, yT), (r2 + 26, yT, xR, yT)] + back:
                flow(*s, c["I"])
        else:
            xa, xb, y2 = w * 0.33, w * 0.71, yT + h * 0.16
            xm = (xa + xb) / 2
            D.rect(g, xm - 40, yT - 2, 80, 4, C.paper)   # 上支路的电阻盖在干路上
            res(xm, yT, "R₁")
            wire(xa, yT, xa, y2)
            wire(xa, y2, xm - 26, y2)
            res(xm, y2, "R₂")
            wire(xm + 26, y2, xb, y2)
            wire(xb, yT, xb, y2)
            for s, amp in [((xL, yT, xa, yT), c["I"]), ((xa, yT, xm - 26, yT), c["I1"]), ((xm + 26, yT, xb, yT), c["I1"]), ((xa, y2, xm - 26, y2), c["I2"]), ((xm + 26, y2, xb, y2), c["I2"]), ((xb, yT, xR, yT), c["I"])]:
                flow(*s, amp)
            for s in back:
                flow(*s, c["I"])
            D.text(g, f"I₁={fmt(c['I1'], 2)}A", xm, yT - 18, acc, size=10, bold=True, mono=True, align="center")
            D.text(g, f"I₂={fmt(c['I2'], 2)}A", xm, y2 - 16, acc, size=10, bold=True, mono=True, align="center")
        box = w * 0.52
        res(box, yB, "R₃")
        wx = box - 26 + 52 * clamp((c["R3"] - 2) / 8, 0, 1)
        D.line(g, wx, yB - 26, wx, yB - 9, acc, 1.4)
        D.poly(g, [(wx, yB - 8), (wx - 5, yB - 18), (wx + 5, yB - 18)], acc)
        D.text(g, f"滑动变阻器 R₃ = {fmt(c['R3'], 1)} Ω", box, yB + 28, C.ink, size=11, bold=True, align="center")
        D.text(g, f"I = {fmt(c['I'], 3)} A", xR * 0.55, yB - 82, acc, size=11.5, bold=True, mono=True)
        D.text(g, f"U = {fmt(c['U'], 2)} V", xR * 0.55, yB - 64, C.jade, size=11.5, bold=True, mono=True)
        i_min = P.E / max(r_base + 10, 1e-6)
        norm = clamp((c["I"] - i_min) / max(i_max - i_min, 1e-9), 0, 1)
        mA, mR = w * 0.23, 17
        D.circle(g, mA, yB, mR, C.card, ink2, 1.5)
        stroke_arc(cv, mA, yB, mR - 5, -PI / 2 - 0.55, -PI / 2 + 0.55, C.faint, 1)
        na = -PI / 2 + norm * 0.85 - 0.18
        D.line(g, mA, yB, mA + cos(na) * (mR - 7), yB + sin(na) * (mR - 7), acc, 2)
        D.circle(g, mA, yB, 2, C.ink)
        plabel(cv, mA, yB + mR + 11, f"A  {fmt(c['I'], 3)} A", ink2, 9.5, align="center")
        if lv >= 1:
            plabel(cv, xL + 4, yT - 14, f"E = {fmt(P.E, 1)} V   r = {fmt(P.r, 1)} Ω", C.soft, 10)
            plabel(cv, xR - 4, yT - 14, f"R₁ = {fmt(P.R1, 1)} Ω   R₂ = {fmt(P.R2, 1)} Ω", C.soft, 10, align="right")
        if lv >= 2:
            plabel(cv, w * 0.5, h * 0.07, f"P₁ = {fmt(c['P1'], 2)} W   P总 = {fmt(P.E * c['I'], 2)} W", ink2, 10.5, align="center")

    def readouts(self, t):
        c = self.calc(t)
        return [("总电阻", fmt(c["Rt"], 2), "Ω"), ("干路电流", fmt(c["I"], 3), "A"), ("路端电压", fmt(c["U"], 2), "V"), ("R₁ 功率", fmt(c["P1"], 4), "W")]

    def status(self, t):
        d = sin(TAU * t / 8)
        return "滑片右移 · R₃ 增大" if d > 0.05 else "滑片左移 · R₃ 减小" if d < -0.05 else "滑片到达端点"


@scene("efield")
class Efield(Scene):
    one_shot = True
    sliders = [("E", "电场强度 E", 0, 30, 1, 0), ("q", "电荷量 q (µC)", 0.5, 3, 0.1, 2), ("m", "质量 m", 0.5, 3, 0.1, 1), ("v0", "入射速度 v₀", 1.5, 5, 0.1, 1)]
    hints = ["粒子以水平初速度进入匀强电场，水平方向匀速。", "竖直方向受电场力 qE，加速度 a = qE/m，做类平抛。", "由板长求板内时间，再求偏转量与出射偏角。"]
    hot = [[1], [0], [1, 2, 3]]
    sign = 1
    LP, D_ = 1.0, 0.5

    def defaults(self):
        return dict(E=6, q=1, m=2, v0=3)

    def make_chips(self):
        return [Chip("电荷种类", ["正电荷", "负电荷"], lambda i: setattr(self, "sign", -1 if i else 1))]

    def aux(self, src):
        q = src.get("q")
        if isinstance(q, (int, float)) and 0 < q < 1e-3:
            self.P.q = q * 1e6   # 以库仑给出时换算成 µC

    def flight(self):
        P = self.P
        a = self.sign * P.q * P.E / max(P.m, 1e-6)
        t1 = self.LP / max(P.v0, 0.01)
        y1 = 0.5 * a * t1 * t1
        hit = abs(y1) >= self.D_ / 2
        t_hit = sqrt(self.D_ / abs(a)) if abs(a) > 1e-9 else INF
        return dict(a=a, t1=t1, y1=y1, hit=hit, T=min(t1, t_hit) if hit else t1, t_hit=t_hit, vy1=a * t1)

    def duration(self):
        f = self.flight()
        return f["T"] + (0.42 if f["hit"] else 0.22)

    def draw(self, cv, t, lv):
        P, LP, Dd, sign = self.P, self.LP, self.D_, self.sign
        f = self.flight()
        a, t1, y1, hit, t_hit = f["a"], f["t1"], f["y1"], f["hit"], f["t_hit"]
        now = clamp(t, 0, f["T"] + 0.42)
        mag = min(900, 0.16 / abs(y1)) if (not hit and 1e-12 < abs(y1) < 0.14) else 1   # 偏转极小时纵向放大

        def yd(v):
            return v * mag
        view_rect(cv, -0.42, LP + 0.62, -Dd * 0.78, Dd * 0.78, 0.02, False)
        cv.grid(0.2)
        g = cv.g
        D.line(g, cv.px(-0.06), cv.py(Dd / 2), cv.px(LP + 0.06), cv.py(Dd / 2), C.ink2, 5)
        D.line(g, cv.px(-0.06), cv.py(-Dd / 2), cv.px(LP + 0.06), cv.py(-Dd / 2), C.ink2, 5)
        for i in range(4):
            x = 0.1 + i * (LP - 0.2) / 3
            label(cv, x, Dd / 2, "+", C.accent, 12, align="center", oy=-11, halo=False, weight=700)
            label(cv, x, -Dd / 2, "−", C.jade, 12, align="center", oy=11, halo=False, weight=700)
            cv.arrow(x, Dd / 2 - 0.035, x, -Dd / 2 + 0.035, C.data[3], 1, 6, [3, 5])
        label(cv, LP + 0.09, 0, "E", C.data[2], 11, weight=700)
        t_end = t_hit if hit else t1
        polyline(cv, [(P.v0 * t_end * i / 48, yd(0.5 * a * (t_end * i / 48) ** 2)) for i in range(49)], C.data[3], 1.1, [4, 4], 0.85)
        tr = min(now, t_end)
        polyline(cv, [(P.v0 * tr * i / 40, yd(0.5 * a * (tr * i / 40) ** 2)) for i in range(41)], C.ink2, 1.9)
        if not hit and now > t1:
            te = min(now - t1, 0.24)
            yE, vs = yd(y1), yd(a * t1)
            xe, ye = LP + P.v0 * te, yE + vs * te
            cv.line(LP, yE, xe, ye, C.ink2, 1.9)
            dot(cv, xe, ye, 4.6, C.ink, C.paper, 1.5)
            label(cv, xe, ye, "出射", C.jade, 9.5, ox=7, oy=-8)
        cv.arrow(-0.38, 0, -0.06, 0, C.data[2], 1.4, 7, [4, 4])
        label(cv, -0.2, 0, "v₀", C.data[2], 10, align="center", oy=-10)
        if hit and now >= t_hit:
            xe, ye, vvy = P.v0 * t_hit, sign * Dd / 2, a * t_hit
            k = clamp((now - t_hit) / 0.42, 0, 1)
            for r in range(3):
                ph = (k + r / 3) % 1
                stroke_arc(cv, cv.px(xe), cv.py(ye), 8 + 34 * ph, 0, TAU, C.accent, 1.4, 0.55 * (1 - ph))
        elif now <= t1:
            xe, ye, vvy = P.v0 * now, 0.5 * a * now * now, a * now
        else:
            xe, ye, vvy = P.v0 * now, y1 + f["vy1"] * (now - t1), f["vy1"]
        dot(cv, xe, yd(ye), 5.2, C.ink, C.paper, 1.6)
        if mag > 1.1:
            plabel(cv, 14, cv.h - 34, f"纵向位移放大 ×{fmt(mag, 0)}（便于观察）", C.faint, 9.5, weight=500)
        if lv >= 1:
            vt = sqrt(P.v0 ** 2 + vvy ** 2) or 1
            X, Y = cv.px(xe), cv.py(yd(ye))
            ux, uy = P.v0 / vt * 30, vvy / vt * 30
            p_arrow(cv, X, Y, X + ux, Y, C.jade, 1.5, 6)
            p_arrow(cv, X, Y, X, Y - uy, C.accent, 1.5, 6)
            p_arrow(cv, X, Y, X + ux, Y - uy, C.gold, 1.6, 6)
            plabel(cv, X + ux + 4, Y - uy - 8, "v", C.gold, 10, weight=700)
            label(cv, 0.08, Dd * 0.70, f"a = {fmt(abs(a), 1)} m/s²", C.accent, 10.5, ox=6)
            label(cv, 0.08, Dd * 0.58, f"t = {fmt(now, 2)} s", C.soft, 9.5, ox=6)
        if lv >= 2:
            ys = sign * Dd / 2 if hit else y1
            dim_line(cv, (LP, 0), (LP, yd(ys)), f"y = {fmt(abs(ys) * 1000, 1)} mm", C.accent, -12, 0)
            if not hit:
                label(cv, LP + 0.12, yd(ys) + 0.05, f"θ = {fmt(math.degrees(math.atan(abs(a) * t1 / P.v0)), 1)}°", C.jade, 10.5, oy=-6)
            else:
                label(cv, LP * 0.55, sign * Dd * 0.34, "粒子打在极板上", C.accent, 10.5)
        elif lv == 0:
            label(cv, 0.1, Dd * 0.66, f"E = {fmt(P.E, 0)}   q = {fmt(P.q, 2)} µC   m = {fmt(P.m, 1)}", C.soft, 10)

    def readouts(self, t):
        P = self.P
        f = self.flight()
        a = f["a"]
        stop = min(t, f["t_hit"]) if f["hit"] else min(t, f["t1"])
        y = 0.5 * a * stop * stop
        ve = sqrt(P.v0 ** 2 + (a * f["t_hit"]) ** 2) if f["hit"] else sqrt(P.v0 ** 2 + f["vy1"] ** 2)
        return [("加速度 a", fmt(abs(a), 2), "m/s²"), ("偏转量 y", fmt(abs(y) * 1000, 2), "mm"), ("出射速度", fmt(ve, 2), "m/s"), ("偏转角 θ", fmt(math.degrees(math.atan(abs(a) * min(stop, f["t1"]) / P.v0)), 1), "°")]

    def status(self, t):
        f = self.flight()
        if f["hit"] and t >= f["t_hit"]:
            return "粒子撞板 · 偏转结束"
        return "射出极板 · 匀速直线" if t >= f["t1"] else "板间偏转 · 类平抛"


@scene("collision")
class Collision(Scene):
    one_shot = True
    sliders = [("m1", "质量 m₁", 0.5, 5, 0.1, 1), ("m2", "质量 m₂", 0.5, 5, 0.1, 1), ("v1", "初速 v₁", -6, 10, 0.5, 1), ("v2", "初速 v₂", -6, 10, 0.5, 1)]
    hints = ["先明确系统：两球组成的系统在水平方向不受外力。", "动量守恒 m₁v₁ + m₂v₂ = m₁v₁′ + m₂v₂′。", "弹性碰撞动能也守恒；完全非弹性碰撞两球共速。"]
    hot = [[1], [2], [0, 1, 3]]
    X1, X2 = -2.2, 2.2
    ei = 0

    def defaults(self):
        return dict(m1=2, m2=1, v1=4, v2=-1)

    def make_chips(self):
        return [Chip("碰撞类型", ["弹性", "非弹性", "完全非弹性"], lambda i: setattr(self, "ei", i))]

    def ev(self):
        P = self.P
        e = (1, 0.6, 0)[self.ei]
        m1, m2, v1, v2 = P.m1, P.m2, P.v1, P.v2
        r1, r2 = 0.16 + 0.05 * m1, 0.16 + 0.05 * m2
        tc = (self.X2 - r2 - (self.X1 + r1)) / (v1 - v2) if v1 > v2 else INF
        v1p = ((m1 - e * m2) * v1 + (1 + e) * m2 * v2) / (m1 + m2)
        v2p = ((m2 - e * m1) * v2 + (1 + e) * m1 * v1) / (m1 + m2)
        E0 = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2
        E1 = 0.5 * m1 * v1p * v1p + 0.5 * m2 * v2p * v2p
        return dict(e=e, r1=r1, r2=r2, tc=tc, v1p=v1p, v2p=v2p, p=m1 * v1 + m2 * v2, E0=E0, E1=E1, dE=max(0, E0 - E1))

    def pos(self, t, g):
        P, tc = self.P, g["tc"]
        if not math.isfinite(tc) or t <= tc:
            s = min(t, tc) if math.isfinite(tc) else t
            return self.X1 + P.v1 * s, self.X2 + P.v2 * s
        return self.X1 + P.v1 * tc + g["v1p"] * (t - tc), self.X2 + P.v2 * tc + g["v2p"] * (t - tc)

    def duration(self):
        tc = self.ev()["tc"]
        return min(4, tc + 1.1) if math.isfinite(tc) else 2.4

    def draw(self, cv, t, lv):
        P, g_ = self.P, self.ev()
        x1, x2 = self.pos(t, g_)
        tc = g_["tc"]
        view_rect(cv, -3.2, 3.2, -0.3, 1.25, 0.02, False)
        cv.grid(0.5)
        cv.line(cv.xr[0], 0, cv.xr[1], 0, C.line, 2.5)
        y1, y2 = g_["r1"], g_["r2"]
        g = cv.g
        for x in (x1, x2):
            g.begin_path()
            g.ellipse(cv.px(x), cv.py(0), 14, 3)
            g.p.fillPath(g.path, alpha(qc(C.line), 0.5))
        c1, c2 = C.ink, C.ink2
        D.circle(g, cv.px(x1), cv.py(y1), max(6, y1 * cv.sx()), c1, C.paper, 1.5)
        D.circle(g, cv.px(x2), cv.py(y2), max(6, y2 * cv.sx()), c2, C.paper, 1.5)
        label(cv, x1, y1, "m₁", on_color(c1), 9.5, align="center", halo=False)
        label(cv, x2, y2, "m₂", on_color(c2), 9.5, align="center", halo=False)
        if lv >= 1:
            v1, v2 = (P.v1, P.v2) if t <= tc else (g_["v1p"], g_["v2p"])
            sc = 0.34 / max(1, abs(P.v1), abs(P.v2), abs(g_["v1p"]), abs(g_["v2p"]))
            vec(cv, x1, y1, v1 * sc, 0, C.accent, 2, "v₁", 10)
            vec(cv, x2, y2, v2 * sc, 0, C.accent, 2, "v₂", 10)
            if abs(t - tc) < 0.05:
                ring_world(cv, (x1 + x2) / 2, 0.35, 0.22, C.accent, 1.4, [3, 3])
        cur = g_["E0"] if t <= tc else g_["E1"]
        bars_panel(cv, 14, 48, 158, [("动量 p", f"{fmt(g_['p'], 1)} kg·m/s", 1, C.ink), ("动能 E", f"{fmt(cur, 2)} J", cur / g_["E0"] if g_["E0"] > 1e-9 else 0, C.gold)], "守恒量")
        D.text(g, f"碰前动能 {fmt(g_['E0'], 2)} J", 14, 138, C.faint, size=10)
        if lv >= 2:
            label(cv, 0, 1.05, f"v₁′ = {fmt(g_['v1p'], 2)} m/s   v₂′ = {fmt(g_['v2p'], 2)} m/s", C.ink, 10.5, align="center")
            label(cv, 0, 0.9, f"ΔE = {fmt(g_['dE'], 2)} J", C.accent, 10.5, align="center")
        elif lv == 0:
            label(cv, 0, 1.05, f"m₁ = {fmt(P.m1, 1)} kg   m₂ = {fmt(P.m2, 1)} kg", C.soft, 10.5, align="center")

    def readouts(self, t):
        g = self.ev()
        return [("碰后 v₁′", fmt(g["v1p"], 2), "m/s"), ("碰后 v₂′", fmt(g["v2p"], 2), "m/s"), ("总动量 p", fmt(g["p"], 2), "kg·m/s"), ("动能损失", fmt(g["dE"], 2), "J")]

    def status(self, t):
        g = self.ev()
        if not math.isfinite(g["tc"]):
            return "两球未相碰"
        if t < g["tc"] - 0.03:
            return "接近中"
        if abs(t - g["tc"]) <= 0.03:
            return "碰撞瞬间"
        return "碰后共速" if g["e"] == 0 else "碰后分离"


@scene("gravity")
class Gravity(Scene):
    sliders = [("r", "轨道半径 r /10⁶m", 6.8, 42, 0.2, 1)]
    hints = ["卫星做匀速圆周运动，万有引力提供向心力。", "由 GMm/r² = mv²/r 得 v = √(GM/r)。", "周期 T = 2πr/v，轨道越高，线速度越小、周期越长。"]
    hot = [[2], [0], [0, 1]]
    GM, RE = 3.986e14, 6.371e6

    def defaults(self):
        return dict(r=12)

    def aux(self, src):
        r = src.get("r")
        if isinstance(r, (int, float)) and r > 1e4:
            self.P.r = r / 1e6   # 以米给出时换算成 10⁶ m

    def data(self):
        r = self.P.r * 1e6
        v = sqrt(self.GM / r)
        return r, v, TAU * r / v, self.GM / (r * r)

    def duration(self):
        return 8

    def draw(self, cv, t, lv):
        r, v, Tp, _ = self.data()
        view_rect(cv, -r * 1.2, r * 1.2, -r * 1.2, r * 1.2, 0.02, True)
        cv.grid(nice(r * 2.4))
        g = cv.g
        D.circle(g, cv.px(0), cv.py(0), self.RE * cv.sx(), C.data[3], C.data[2], 1.4)
        label(cv, 0, 0, "地球", C.ink2, 10, align="center", halo=False, weight=700)
        ring_world(cv, 0, 0, r, C.data[2], 1.2, [5, 5])
        th = -PI / 2 + TAU * t / 8
        x, y = r * cos(th), r * sin(th)
        for k in range(36, 0, -1):
            tp = th - k * 0.048
            fill_circle(cv, cv.px(r * cos(tp)), cv.py(r * sin(tp)), 1.9, C.accent, 0.34 * (1 - k / 40))
        cv.line(0, 0, x, y, C.data[2], 1, [4, 5])
        label(cv, x / 2, y / 2, f"r = {fmt(self.P.r, 1)}×10⁶ m", C.soft, 10, align="center", oy=-8)
        if lv >= 1:
            vec(cv, x, y, -sin(th) * r * 0.26, cos(th) * r * 0.26, C.accent, 2, "v")
            vec(cv, x, y, -cos(th) * r * 0.17, -sin(th) * r * 0.17, C.jade, 2, "a")
        dot(cv, x, y, 5.5, C.ink, C.paper, 1.6)
        if lv >= 2:
            label(cv, 0, -r * 1.05, f"v = {fmt(v / 1000, 2)} km/s", C.ink2, 10.5, align="center")
            label(cv, 0, -r * 1.14, f"T = {fmt(Tp / 3600, 2)} h", C.accent, 10.5, align="center")
        elif lv == 0:
            label(cv, 0, r * 1.06, "GM = 3.986×10¹⁴ m³/s²", C.soft, 10, align="center")

    def readouts(self, t):
        r, v, Tp, a = self.data()
        return [("线速度 v", fmt(v / 1000, 2), "km/s"), ("周期 T", fmt(Tp / 3600, 2), "h"), ("轨道半径", fmt(r / 1000, 0), "km"), ("向心加速度", fmt(a, 2), "m/s²")]

    def status(self, t):
        return f"圆轨道 · 已转过 {fmt((t / 8) % 1 * 360, 0)}°"


@scene("efield2")
class Efield2(Scene):
    sliders = [("q1", "电荷 q₁ (µC)", 0.5, 8, 0.5, 1), ("q2", "电荷 q₂ (µC)", 0.5, 8, 0.5, 1), ("qp", "探针电荷 q (µC)", -4, 4, 0.5, 1)]
    hints = ["电场线从正电荷出发、指向负电荷；同号时互相排斥、彼此绕开。", "等势面处处与电场线垂直，电势 V = kΣq/r 相同的地方连成一条线。", "带电粒子沿电场线方向受 qE 作用；正电荷顺着电场线加速，负电荷反向。"]
    hot = [[0, 1], [2], [0, 1, 2, 3]]
    has_drag = True

    def __init__(self):
        self.C1, self.C2 = [-1.3, 0.0], [1.3, 0.0]
        self.sign2, self.drag_idx = -1, -1
        self.key = None
        self.lines, self.tabs, self.contours = [], [], []
        self.probe, self.probe_tab, self.probe_len = [(0, 0), (1, 0)], [0, 1], 0
        super().__init__()

    def defaults(self):
        return dict(q1=5, q2=5, qp=1)

    def make_chips(self):
        return [Chip("电荷组合", ["异号", "同号"], lambda i: setattr(self, "sign2", 1 if i else -1))]

    def q2v(self):
        return self.sign2 * abs(self.P.q2)

    def charges(self):
        return [(self.C1[0], self.C1[1], self.P.q1), (self.C2[0], self.C2[1], self.q2v())]

    def field(self, x, y):
        ex = ey = 0.0
        for cx, cy, q in self.charges():
            dx, dy = x - cx, y - cy
            d2 = dx * dx + dy * dy + 0.012
            inv = q / (d2 * sqrt(d2))
            ex += dx * inv
            ey += dy * inv
        return ex, ey

    def pot(self, x, y):
        return sum(q / sqrt((x - cx) ** 2 + (y - cy) ** 2 + 0.012) for cx, cy, q in self.charges())

    def ensure(self, cv):
        P = self.P
        key = (P.q1, P.q2, self.sign2, tuple(self.C1), tuple(self.C2), cv.w, cv.h)
        if key == self.key:
            return
        self.key = key
        chs, xr, yr = self.charges(), cv.xr, cv.yr
        opp = self.q2v() < 0
        lines, tabs = [], []
        homes = [0] if opp else [0, 1]   # 异号只从正电荷发出，线自然汇入负电荷；同号两个电荷各自发出
        for hi in homes:
            hx, hy, hq = chs[hi]
            sg = 1 if hq > 0 else -1
            count = 16 if opp else 11
            for k in range(count):
                a = (k + 0.5) / count * TAU
                x, y = hx + 0.18 * cos(a), hy + 0.18 * sin(a)
                pts = [(x, y)]
                for _s in range(520):
                    ex, ey = self.field(x, y)
                    m = sqrt(ex * ex + ey * ey)
                    if m < 1e-9:
                        break
                    x += sg * ex / m * 0.035
                    y += sg * ey / m * 0.035
                    if x < xr[0] - 0.2 or x > xr[1] + 0.2 or y < yr[0] - 0.2 or y > yr[1] + 0.2:
                        break
                    end = any(j != hi and chs[j][2] * hq < 0 and hypot(x - chs[j][0], y - chs[j][1]) < 0.12 for j in range(2))
                    pts.append((x, y))
                    if end:
                        break
                if len(pts) > 6:
                    lines.append(pts)
                    tabs.append(path_table(pts))
        bi, bl, best = 0, 0, -1
        for i, tb in enumerate(tabs):
            ln = tb[-1]
            last = lines[i][-1]
            score = ln
            if opp and hypot(last[0] - self.C2[0], last[1] - self.C2[1]) < 0.45:
                score = 1000 - ln   # 异号时优先选真正连到负电荷的最短一条
            if score > best:
                best, bi, bl = score, i, ln
        self.lines, self.tabs = lines, tabs
        self.probe = lines[bi] if lines else [(0, 0), (1, 0)]
        self.probe_tab = tabs[bi] if tabs else [0, 1]
        self.probe_len = bl
        sc = max(1, P.q1, abs(self.q2v()))
        base = [v * sc / 5 for v in (1.2, 2.8, 6.2)]
        groups = []
        for idx, lvl in enumerate(base + [-v for v in base]):
            segs = march_squares(self.pot, xr, yr, lvl, 46, 32)
            if segs:
                groups.append(dict(segs=segs, pos=lvl > 0, a=0.24 if idx < 3 else 0.16, rank=1 if idx < 3 else 2))
        if opp:
            zs = march_squares(self.pot, xr, yr, 0, 46, 32)
            if zs:
                groups.append(dict(segs=zs, zero=True, a=0.26, rank=1, dash=[3, 6]))
        self.contours = groups

    def read_values(self):
        chs = self.charges()
        ex, ey = self.field(0, 0)
        K, MU = 9e9, 1e-6
        return sqrt(ex * ex + ey * ey) * K * MU / 1000, self.pot(0, 0) * K * MU / 1000, hypot(chs[0][0] - chs[1][0], chs[0][1] - chs[1][1])

    def duration(self):
        return 5.2

    def drag(self, phase, x, y):
        if phase == "down":
            d1, d2 = hypot(x - self.C1[0], y - self.C1[1]), hypot(x - self.C2[0], y - self.C2[1])
            self.drag_idx = -1 if min(d1, d2) > 0.62 else 0 if d1 <= d2 else 1
        elif phase == "up":
            self.drag_idx = -1
        elif phase == "move" and self.drag_idx >= 0:
            c, o = (self.C2, self.C1) if self.drag_idx else (self.C1, self.C2)
            nx, ny = clamp(x, -3.1, 3.1), clamp(y, -1.9, 1.9)
            if hypot(nx - o[0], ny - o[1]) >= 0.5:
                c[0], c[1] = nx, ny

    def draw(self, cv, t, lv):
        P = self.P
        view_rect(cv, -3.2, 3.2, -2.0, 2.0, 0.02, True)
        self.ensure(cv)
        cv.grid(nice(cv.xr[1] - cv.xr[0]), False, C.grid2)
        g = cv.g
        from PySide6.QtGui import QPainterPath
        for gr in self.contours:
            if lv < 2 and gr["rank"] > 1:
                continue
            path = QPainterPath()
            for a, b in gr["segs"]:
                path.moveTo(cv.px(a[0]), cv.py(a[1]))
                path.lineTo(cv.px(b[0]), cv.py(b[1]))
            col = qc(C.faint if gr.get("zero") else C.data[2] if gr.get("pos") else C.jade)
            g.p.strokePath(path, g._pen(alpha(col, gr["a"] * (1 if lv >= 1 else 0.55)), 1, gr.get("dash") or []))
        for i, pts in enumerate(self.lines):
            polyline(cv, pts, C.data[2], 1.25, None, 0.55)
            dp = path_point(pts, self.tabs[i], (t * 0.16 + i * 0.09) % 1)
            dot(cv, dp[0], dp[1], 2.2, C.data[2])
            if lv >= 1 and i % 2 == 0:
                p = path_point(pts, self.tabs[i], 0.58)
                X, Y = cv.px(p[0]), cv.py(p[1])
                p_arrow(cv, X, Y, X + cos(p[2]) * 7, Y - sin(p[2]) * 7, C.data[2], 1.2, 5)
        if lv >= 1:
            tag_box(cv, cv.w * 0.5, 18, "实线：电场线　细线：等势面", C.ink2, "center")
        dir_f = 1 if P.qp >= 0 else -1
        frac = (t / 5.2) % 1
        s = frac * 2 if frac < 0.5 else 2 - frac * 2
        f0 = 0 if dir_f > 0 else 1
        trail = [path_point(self.probe, self.probe_tab, f0 + (s - f0) * i / 72)[:2] for i in range(73)]
        polyline(cv, self.probe, C.gold, 1, None, 0.25)
        polyline(cv, trail, C.accent, 2, None, 0.9)
        pp = path_point(self.probe, self.probe_tab, s)
        ang = pp[2] + (0 if dir_f > 0 else PI)
        X, Y = cv.px(pp[0]), cv.py(pp[1])
        p_arrow(cv, X, Y, X + cos(ang) * 24, Y - sin(ang) * 24, C.accent, 1.8, 7)
        if lv >= 2:
            ex, ey = self.field(pp[0], pp[1])
            m = sqrt(ex * ex + ey * ey) or 1
            p_arrow(cv, X, Y, X + ex / m * dir_f * 28, Y - ey / m * dir_f * 28, C.gold, 1.6, 6)
            plabel(cv, X + 30, Y - 13, "E", C.gold, 10, weight=700)
        fill_circle(cv, X, Y, 9, C.accent, 0.16)
        dot(cv, pp[0], pp[1], 4.4, C.accent, C.paper, 1.4)
        plabel(cv, X + 9, Y - 9, "q", C.accent, 10, weight=700)
        for i, (cx, cy, q) in enumerate(self.charges()):
            pos = q > 0
            col = C.accent if pos else C.ink2
            CX, CY = cv.px(cx), cv.py(cy)
            fill_circle(cv, CX, CY, 17, col, 0.13)
            D.circle(g, CX, CY, 11, col, C.paper, 2)
            D.text(g, "+" if pos else "−", CX, CY + 1, on_color(col), size=14, bold=True, align="center")
            plabel(cv, CX, CY + 26, f"{'q₂' if i else 'q₁'} = {'+' if pos else '−'}{fmt(abs(q), 1)} µC", col, 10.5, weight=700, align="center")
        if lv == 0:
            tag_box(cv, 14, cv.h - 40, "拖动电荷可改位置", C.soft)
        if lv >= 2:
            e_m, v_m, _ = self.read_values()
            plabel(cv, 14, cv.h - 40, f"中点 E = {fmt(e_m, 1)} kN/C　V = {fmt(v_m, 1)} kV", C.soft, 10, weight=500)

    def readouts(self, t):
        e_m, v_m, d = self.read_values()
        return [("中点场强 E", fmt(e_m, 1), "kN/C"), ("中点电势 V", fmt(v_m, 1), "kV"), ("电荷间距", fmt(d, 2), "m"), ("探针轨迹长", fmt(self.probe_len, 2), "m")]

    def status(self, t):
        frac = (t / 5.2) % 1
        s = frac * 2 if frac < 0.5 else 2 - frac * 2
        return ("同号相斥" if self.q2v() > 0 else "异号相吸") + " · " + ("出发" if s < 0.08 else "到达终点" if s > 0.92 else "向远" if frac < 0.5 else "回程")
