"""2.0 原生界面自测：离屏打开实验台，逐个挂载实验并截图（昼 / 夜），汇报出错的实验。

用法：python -m native.selftest <输出目录> [实验 id ...]
"""
from __future__ import annotations

from .kit import test_runtime

test_runtime.configure()

import os
import sys
import time
from pathlib import Path


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    out = Path(argv.pop(0) if argv else "selftest-out")
    out.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    if os.path.isdir(r"C:\Windows\Fonts"):
        os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")   # 离屏平台默认不找系统字体，中文会成方块
    app = test_runtime.application(sys.argv[:1])
    from PySide6.QtWidgets import QFileDialog
    QFileDialog.getSaveFileName = staticmethod(lambda *_a, **_k: ("", ""))   # 自测会按到「导出」：模态文件框会一直等人
    QFileDialog.getOpenFileName = staticmethod(lambda *_a, **_k: ("", ""))
    from .design import tokens
    from .kit.registry import lab
    from .lab.studio import Studio

    w = Studio("day")
    w.resize(1440, 900)
    w.show()
    app.processEvents()
    w.grab().save(str(out / "home-day.png"))
    from .kit.bench import bench
    want = argv or [e.id for e in lab.list] + ["bench:" + k.id for k in bench.list]
    ids = [i for i in want if not i.startswith("bench:")]
    bids = [i[6:] for i in want if i.startswith("bench:")]
    bad = []
    errs: list = []
    import traceback
    sys.excepthook = lambda et, ev, tb: errs.append(''.join(traceback.format_exception_only(et, ev)).strip())

    def spin(n=4):
        for _ in range(n):
            app.processEvents()
            if w.ctx:
                w.ctx.stage.repaint()
            time.sleep(0.01)
    for theme in ("day", "night"):
        tokens.set_theme(theme)
        w.apply_theme()
        for bid in bids:
            t0 = time.perf_counter()
            w.open_bench(bid)
            errs.clear()
            spin(30)
            if theme == "day":
                # 素材栏：每一项点一次、能拖的拖到画布中央一次；每次之后把检查器里的按钮也按一遍
                for it in [b.it for b in w.B.pal.all]:
                    if it.get("click"):
                        it["click"]()
                        spin(3)
                    if it.get("drop"):
                        it["drop"](w.ctx.stage.width() / 2, w.ctx.stage.height() / 2)
                        spin(3)
                    for ctl in list(w.ctx.ctrls):
                        if ctl["kind"] == "button":
                            try:
                                ctl["press"]()
                            except RuntimeError:   # 按钮已随检查器重建被删
                                pass
                            spin(2)
                if w.ctx.stage.key_fn:
                    for k in ("r", "Delete", "Escape"):
                        w.ctx.stage.key_fn(k, None)
                        spin(2)
                spin(20)
            err = (w.ctx.stage.error if w.ctx else "未打开") or (errs[0] if errs else None)
            ms = (time.perf_counter() - t0) * 1000
            w.grab().save(str(out / f"bench-{bid}-{theme}.png"))
            if err:
                bad.append((bid, theme, err))
            print(f"{theme:5s} bench:{bid:8s} {ms:7.0f} ms  {'ERR ' + err if err else 'ok'}", flush=True)
        for eid in ids:
            t0 = time.perf_counter()
            w.open(eid)
            errs.clear()
            t_end = time.perf_counter() + 0.5   # 让动画循环跑一会儿：循环里的错误只会在计时器回调中出现
            while time.perf_counter() < t_end:
                app.processEvents()
                w.ctx.stage.repaint()
                time.sleep(0.01)
            # 每个按钮按一次（开始、预设、清空……），再跑一会儿：按钮背后的代码路径也要走到
            for ctl in list(w.ctx.ctrls) if theme == "day" else []:
                if ctl["kind"] == "button":
                    ctl["press"]()
                    for _ in range(4):
                        app.processEvents()
                        w.ctx.stage.repaint()
                        time.sleep(0.01)
            err =(w.ctx.stage.error if w.ctx else "未打开") or (errs[0] if errs else None)
            ms = (time.perf_counter() - t0) * 1000
            w.grab().save(str(out / f"{eid}-{theme}.png"))
            if err:
                bad.append((eid, theme, err))
            print(f"{theme:5s} {eid:14s} {ms:7.0f} ms  {'ERR ' + err if err else 'ok'}", flush=True)
    w.go_home()
    tokens.set_theme("night")
    w.apply_theme()
    app.processEvents()
    w.grab().save(str(out / "home-night.png"))
    import pathlib
    import re
    here = pathlib.Path(__file__).parent / "lab"
    listed = set(re.findall(r"\w+", (here / "all_modules.py").read_text(encoding="utf-8")))
    miss = [p.stem for d in ("exps", "benches") for p in (here / d).glob("*.py") if p.stem != "__init__" and p.stem not in listed]
    if miss:
        bad.append(("all_modules.py 漏了", miss))
        print("all_modules.py 漏了：", miss, flush=True)
    print("SELFTEST", "FAIL" if bad else "OK", len(ids), "experiments", len(bids), "benches", flush=True)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(test_runtime.run(main))
