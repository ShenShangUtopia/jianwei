"""格物实验台（原生）：画布优先的工作室窗口。

┌ 顶栏：品牌 · 学科切换 · 搜索 · 昼夜 · 侧栏 ───────────────────────────────┐
│ 目录抽屉 │ 标题条（实验名 · 册次 · 单元）                    │ 侧栏：参数 / 原理 │
│ 册次     │ ┌ 画布 ─────────────────────────────┐            │                  │
│  · 实验  │ │ 浮动工具条（复位 · 截图 · 全屏）  │            │ 控件分组、读数   │
│          │ └──────────────────────────────────┘            │                  │
└──────────────────────────────────────────────────────────────────────────────┘
"""
from __future__ import annotations

from PySide6.QtCore import QRect, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QFontMetrics, QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import (QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QScrollArea, QSizePolicy,
                               QStackedWidget, QTextBrowser, QVBoxLayout, QWidget)

from ..design import tokens
from ..design.tokens import RADIUS, T, font, qc
from ..design.widgets import IconButton, Segmented, TabBar, qss
from ..kit.bench import BenchAPI, BenchTabs, Palette, bench, paint_svg
from ..kit.ctx import Ctx
from ..kit.registry import SUBJECTS, lab

SUBJ_ITEMS = [(k, v["name"]) for k, v in SUBJECTS.items()]


# ---------------------------------------------------------------- 目录
class NavList(QWidget):
    """目录：册次标题 + 实验条目，自己画（比 QListWidget 好控制留白和选中态）。"""
    picked = Signal(str)
    ROW, HEAD = 46, 34

    def __init__(self):
        super().__init__()
        self.rows: list[tuple] = []   # ("head", text) / ("item", exp)
        self.cur, self.hover = None, -1
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_rows(self, rows, cur) -> None:
        self.rows, self.cur = rows, cur
        h = sum(self.HEAD if r[0] == "head" else self.ROW for r in rows) + 12
        self.setMinimumHeight(h)
        self.setFixedHeight(h)
        self.update()

    def _at(self, y):
        acc = 6
        for i, r in enumerate(self.rows):
            hh = self.HEAD if r[0] == "head" else self.ROW
            if acc <= y < acc + hh:
                return i
            acc += hh
        return -1

    def mouseMoveEvent(self, e):  # noqa: N802
        i = self._at(e.position().y())
        if i != self.hover:
            self.hover = i
            self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = -1
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        i = self._at(e.position().y())
        if i >= 0 and self.rows[i][0] == "item":
            self.picked.emit(self.rows[i][1].id)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        y, w = 6, self.width()
        for i, r in enumerate(self.rows):
            if r[0] == "head":
                p.setFont(font(11.5, 600, spacing=1.0))
                p.setPen(qc(T.faint))
                p.drawText(QRect(16, y, w - 24, self.HEAD), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom), r[1])
                y += self.HEAD
                continue
            e = r[1]
            box = QRectF(8, y + 2, w - 16, self.ROW - 4)
            on = self.cur == e.id
            if on or i == self.hover:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.accent, 0.12) if on else qc(T.hover))
                p.drawRoundedRect(box, 8, 8)
            if on:
                p.setBrush(qc(T.accent))
                p.drawRoundedRect(QRectF(8, y + 12, 3, self.ROW - 24), 1.5, 1.5)
            p.setFont(font(13, 600 if on else 500))
            p.setPen(qc(T.fg))
            fm = QFontMetrics(p.font())
            p.drawText(QRect(20, y + 5, w - 34, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                       fm.elidedText(e.title, Qt.TextElideMode.ElideRight, w - 34))
            p.setFont(font(11, 400))
            p.setPen(qc(T.muted))
            fm = QFontMetrics(p.font())
            sub = r[2] if len(r) > 2 else e.unit
            p.drawText(QRect(20, y + 24, w - 34, 16), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                       fm.elidedText(sub, Qt.TextElideMode.ElideRight, w - 34))
            y += self.ROW
        p.end()


# ---------------------------------------------------------------- 首页
class HomeView(QWidget):
    """首页：四科统计 + 每册一张卡片（卡片里列出实验，点击打开）。"""
    picked = Signal(str)

    def __init__(self):
        super().__init__()
        self.hit: list[tuple[QRectF, str]] = []
        self.hover = None
        self.setMouseTracking(True)

    def layout_height(self, w: int) -> int:
        return self._paint(None, w)

    def mouseMoveEvent(self, e):  # noqa: N802
        h = next((k for r, k in self.hit if r.contains(e.position())), None)
        if h != self.hover:
            self.hover = h
            self.setCursor(Qt.CursorShape.PointingHandCursor if h else Qt.CursorShape.ArrowCursor)
            self.update()

    def mousePressEvent(self, e):  # noqa: N802
        h = next((k for r, k in self.hit if r.contains(e.position())), None)
        if h:
            self.picked.emit(h)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        h = self._paint(p, self.width())
        p.end()
        if abs(self.minimumHeight() - h) > 2:
            self.setMinimumHeight(h)

    def _paint(self, p, W) -> int:
        pad, y = 40, 36
        if p:
            self.hit = []
            p.setFont(font(26, 700, spacing=1.0))
            p.setPen(qc(T.fg))
            p.drawText(QRect(pad, y, W - 2 * pad, 40), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "格物 · 高中理科实验台")
            p.setFont(font(13.5))
            p.setPen(qc(T.muted))
            p.drawText(QRect(pad, y + 44, W - 2 * pad, 24), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                       "按新课标的必修与选择性必修组织。每个实验都能自由调参、拖拽、重复，右侧给出实时读数。")
        y += 92
        # 自由工作台：一排横幅卡片
        if bench.list:
            n = len(bench.list)
            bw = (W - 2 * pad - (n - 1) * 14) / n
            for i, k in enumerate(bench.list):
                x = pad + i * (bw + 14)
                r = QRectF(x, y, bw, 96)
                if p:
                    sc = (tokens.NIGHT if T.dark else tokens.DAY)[k.subj]
                    on = self.hover == "bench:" + k.id
                    p.setPen(qc(sc, 0.6) if on else qc(T.line))
                    p.setBrush(qc(T.hover) if on else qc(T.surface))
                    p.drawRoundedRect(r, RADIUS["lg"], RADIUS["lg"])
                    wide = bw >= 270   # 卡片窄时缩小插图，把宽度让给标题
                    tx = 116 if wide else 66
                    if k.art:
                        paint_svg(p, k.art, QRectF(x + 12, y + 14, 92, 68) if wide else QRectF(x + 8, y + 26, 52, 40))
                    p.setFont(font(15 if wide else 13, 700))
                    p.setPen(qc(T.fg))
                    p.drawText(QRect(int(x + tx), int(y + 12), int(bw - tx - 8), 24), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), k.title)
                    p.setFont(font(11.5 if wide else 10.5))
                    p.setPen(qc(T.muted))
                    p.drawText(QRectF(x + tx, y + 38, bw - tx - 8, 50), int(Qt.AlignmentFlag.AlignLeft | Qt.TextFlag.TextWordWrap), k.sub)
                    p.setBrush(qc(sc))
                    p.setPen(Qt.PenStyle.NoPen)
                    p.drawRoundedRect(QRectF(x + tx, y + 8, 22, 3), 1.5, 1.5)
                    self.hit.append((r, "bench:" + k.id))
            y += 118
        # 四科统计
        sw = (W - 2 * pad - 3 * 14) / 4
        for i, (k, name) in enumerate(SUBJ_ITEMS):
            x = pad + i * (sw + 14)
            if p:
                r = QRectF(x, y, sw, 78)
                p.setPen(qc(T.line))
                p.setBrush(qc(T.surface))
                p.drawRoundedRect(r, RADIUS["lg"], RADIUS["lg"])
                p.setFont(font(30, 600, "num"))
                p.setPen(qc(tokens.DAY[k] if not T.dark else tokens.NIGHT[k]))
                p.drawText(QRect(int(x + 18), int(y + 8), int(sw), 40), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), str(len(lab.of(k))))
                p.setFont(font(12.5))
                p.setPen(qc(T.muted))
                p.drawText(QRect(int(x + 18), int(y + 46), int(sw), 22), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), f"{name}实验")
        y += 110
        # 每科每册
        cols = max(1, int((W - 2 * pad + 14) // 300))
        cw = (W - 2 * pad - (cols - 1) * 14) / cols
        for k, meta in SUBJECTS.items():
            es = lab.of(k)
            if not es:
                continue
            sc = tokens.DAY[k] if not T.dark else tokens.NIGHT[k]
            if p:
                p.setFont(font(17, 700))
                p.setPen(qc(T.fg))
                p.drawText(QRect(pad, y, 400, 28), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), meta["name"])
                p.setBrush(qc(sc))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawRoundedRect(QRectF(pad, y + 30, 26, 3), 1.5, 1.5)
            y += 44
            cards = [(i, b, [e for e in es if e.book == i]) for i, b in enumerate(meta["books"])]
            cards = [c for c in cards if c[2]]
            for row0 in range(0, len(cards), cols):
                row = cards[row0:row0 + cols]
                hh = max(52 + 30 * len(c[2]) for c in row)
                for j, (_, book, items) in enumerate(row):
                    x = pad + j * (cw + 14)
                    if p:
                        p.setPen(qc(T.line))
                        p.setBrush(qc(T.surface))
                        p.drawRoundedRect(QRectF(x, y, cw, hh), RADIUS["lg"], RADIUS["lg"])
                        p.setFont(font(12, 600, spacing=0.6))
                        p.setPen(qc(T.muted))
                        p.drawText(QRect(int(x + 16), int(y + 12), int(cw - 32), 22), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), book)
                    yy = y + 42
                    for e in items:
                        r = QRectF(x + 8, yy, cw - 16, 28)
                        if p:
                            if self.hover == e.id:
                                p.setPen(Qt.PenStyle.NoPen)
                                p.setBrush(qc(T.hover))
                                p.drawRoundedRect(r, 7, 7)
                            p.setBrush(qc(sc))
                            p.setPen(Qt.PenStyle.NoPen)
                            p.drawEllipse(QRectF(x + 16, yy + 11, 6, 6))
                            p.setFont(font(13, 500))
                            p.setPen(qc(T.fg))
                            fm = QFontMetrics(p.font())
                            p.drawText(QRect(int(x + 30), int(yy), int(cw - 46), 28), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                                       fm.elidedText(e.title, Qt.TextElideMode.ElideRight, int(cw - 46)))
                            self.hit.append((r, e.id))
                        yy += 30
                y += hh + 14
            y += 18
        return int(y + 20)


# ---------------------------------------------------------------- 画布区
class StageHost(QFrame):
    """装画布的圆角卡片。"""

    def __init__(self, studio: "Studio"):
        super().__init__()
        self.studio = studio
        self.setObjectName("stageHost")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(1, 1, 1, 1)


def tool_strip(studio: "Studio") -> QFrame:
    """标题条右侧的工具组（不压在画布上：实验内容可能画满整块画布）。"""
    box = QFrame()
    box.setObjectName("toolStrip")
    tl = QHBoxLayout(box)
    tl.setContentsMargins(3, 3, 3, 3)
    tl.setSpacing(2)
    for icon, tip, fn in (("reset", "复位视图（双击画布同效）", studio.reset_view),
                          ("camera", "把画面存成图片", studio.snapshot),
                          ("full", "全屏（F11）", studio.toggle_full)):
        b = IconButton(icon, tip, 30)
        b.clicked.connect(fn)
        tl.addWidget(b)
    return box


# ---------------------------------------------------------------- 窗口
class Studio(QWidget):
    def __init__(self, theme: str = "day", bus=None):
        super().__init__()
        self.setObjectName("jw2")
        self.setWindowTitle("格物 · 实验台")
        self.resize(1360, 860)
        tokens.set_theme(theme)
        lab.load()
        bench.load()
        self.subj, self.cur, self.ctx = "math", None, None
        self.cur_bench, self.B = None, None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._topbar())
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        body.addWidget(self._drawer())
        self.center = QStackedWidget()
        body.addWidget(self.center, 1)
        self.side = self._sidebar()
        body.addWidget(self.side)
        root.addLayout(body, 1)

        # 首页
        self.home = HomeView()
        self.home.picked.connect(lambda k: self.open_bench(k[6:]) if k.startswith("bench:") else self.open(k))
        hs = QScrollArea()
        hs.setWidgetResizable(True)
        hs.setWidget(self.home)
        self.center.addWidget(hs)
        # 实验页
        self.exp_page = QWidget()
        ev = QVBoxLayout(self.exp_page)
        ev.setContentsMargins(18, 14, 14, 16)
        ev.setSpacing(10)
        hrow = QHBoxLayout()
        hrow.setSpacing(10)
        self.head = QLabel()
        self.head.setTextFormat(Qt.TextFormat.RichText)
        hrow.addWidget(self.head, 1)
        self.bench_tabs_box = QHBoxLayout()
        hrow.addLayout(self.bench_tabs_box)
        hrow.addWidget(tool_strip(self))
        ev.addLayout(hrow)
        self.stage_host = StageHost(self)
        ev.addWidget(self.stage_host, 1)
        self.center.addWidget(self.exp_page)

        QShortcut(QKeySequence("F11"), self, activated=self.toggle_full)
        QShortcut(QKeySequence("Ctrl+F"), self, activated=lambda: self.search.setFocus())
        QShortcut(QKeySequence("Esc"), self, activated=self.go_home)
        from ..kit.clip import ClipBus
        from ..kit.bench_transfer import BenchTransfer
        self.clip_bus = bus or ClipBus(self)
        self.clip_transfer = BenchTransfer(self,self.clip_bus)
        self.apply_theme()
        self.set_subj("math")
        self.go_home()

    # ---- 结构
    def _topbar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("topbar")
        bar.setFixedHeight(54)
        h = QHBoxLayout(bar)
        h.setContentsMargins(16, 0, 12, 0)
        h.setSpacing(10)
        home = IconButton("home", "首页（Esc）", 32)
        home.clicked.connect(self.go_home)
        h.addWidget(home)
        brand = QLabel("格物")
        brand.setObjectName("brand")
        h.addWidget(brand)
        sub = QLabel("实验台")
        sub.setObjectName("brandSub")
        h.addWidget(sub)
        h.addSpacing(18)
        self.subj_bar = Segmented(SUBJ_ITEMS, "math")
        self.subj_bar.changed.connect(lambda k: (self.set_subj(k), self.go_home() if self.cur and self.cur.subj != k else None))
        h.addWidget(self.subj_bar)
        h.addSpacing(8)
        wb = IconButton("grid", "自由工作台：自己挑器材和药品", 32)
        wb.clicked.connect(lambda: self.open_bench((self.cur_bench or bench.list[0]).id) if bench.list else None)
        h.addWidget(wb)
        h.addStretch(1)
        self.search = QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("搜索实验、知识点…（Ctrl+F）")
        self.search.setFixedWidth(260)
        self.search.textChanged.connect(lambda _t: self.refresh_nav())
        h.addWidget(self.search)
        self.theme_btn = IconButton("moon", "切换昼 / 夜", 32)
        self.theme_btn.clicked.connect(self.toggle_theme)
        h.addWidget(self.theme_btn)
        side = self.side_btn = IconButton("side", "显示 / 收起侧栏", 32, checkable=True)
        side.setChecked(True)
        side.toggled.connect(lambda on: self.side.setVisible(on and self.cur is not None))
        h.addWidget(side)
        return bar

    def _drawer(self) -> QWidget:
        box = QFrame()
        box.setObjectName("drawer")
        box.setFixedWidth(256)
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 6, 0, 0)
        self.nav = NavList()
        self.nav.picked.connect(self.open)
        self.drawer_stack = QStackedWidget()
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setWidget(self.nav)
        self.drawer_stack.addWidget(sc)
        self.pal_scroll = QScrollArea()   # 工作台模式：素材栏
        self.pal_scroll.setWidgetResizable(True)
        self.drawer_stack.addWidget(self.pal_scroll)
        v.addWidget(self.drawer_stack)
        return box

    def _sidebar(self) -> QWidget:
        box = QFrame()
        box.setObjectName("sidebar")
        box.setFixedWidth(340)
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        self.tabs = TabBar(["参数", "原理", "讲题"])
        v.addWidget(self.tabs)
        self.side_stack = QStackedWidget()
        self.tabs.changed.connect(self.side_stack.setCurrentIndex)
        # 参数
        self.panel_scroll = QScrollArea()
        self.panel_scroll.setWidgetResizable(True)
        self.panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.side_stack.addWidget(self.panel_scroll)
        # 原理
        self.info = QTextBrowser()
        self.info.setOpenExternalLinks(False)
        self.info.document().setDocumentMargin(18)
        self.side_stack.addWidget(self.info)
        # 讲题（题目分析接入后填充）
        self.talk = QLabel("这里将显示题目分析的讲解：答案 → 过程 → 解释，并和画面里的读数逐项比对。")
        self.talk.setObjectName("note")
        self.talk.setWordWrap(True)
        self.talk.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.talk.setContentsMargins(18, 18, 18, 18)
        self.side_stack.addWidget(self.talk)
        v.addWidget(self.side_stack, 1)
        return box

    # ---- 主题
    def apply_theme(self) -> None:
        if hasattr(self,"clip_transfer") and self.clip_transfer.pen_bar is not None:
            self.clip_transfer.pen_bar.apply_theme()
        t = T
        self.setStyleSheet(qss() + f"""
QFrame#topbar {{ background:{t.surface}; border-bottom:1px solid {t.line}; }}
QFrame#drawer {{ background:{t.surface}; border-right:1px solid {t.line}; }}
QFrame#sidebar {{ background:{t.surface}; border-left:1px solid {t.line}; }}
QFrame#stageHost {{ background:{t.stage}; border:1px solid {t.line}; border-radius:{RADIUS['lg']}px; }}
QFrame#toolStrip {{ background:{tokens.css(t.raised, 0.92)}; border:1px solid {t.line}; border-radius:10px; }}
QLabel#brand {{ font-size:19px; font-weight:700; letter-spacing:3px; color:{t.fg}; }}
QLabel#brandSub {{ font-size:12px; color:{t.muted}; letter-spacing:2px; padding-top:3px; }}
QLineEdit#search {{ font-family:"{tokens.family('ui')}"; padding:6px 10px; border-radius:16px; background:{t.bg}; }}
""")
        self.theme_btn.icon = "sun" if T.dark else "moon"
        self.info.document().setDefaultStyleSheet(
            f"p{{margin:0 0 10px 0;line-height:160%;}} .fb{{font-family:'{tokens.family('num')}';color:{t.fg};"
            f"background:{t.bg};padding:8px;}} .f{{font-family:'{tokens.family('mono')}';color:{t.accent};}}"
            f"h3{{font-size:14px;color:{t.fg};margin:14px 0 6px 0;}} li{{margin-bottom:6px;}}")
        self.refresh_info()
        self.update()
        if self.ctx:
            self.ctx.draw()

    def toggle_theme(self) -> None:
        tokens.set_theme("day" if T.dark else "night")
        self.apply_theme()

    # ---- 目录 / 首页 / 实验
    def set_subj(self, k: str) -> None:
        self.subj = k
        tokens.set_subject(k)
        self.subj_bar.set_value(k)
        self.refresh_nav()
        self.apply_theme()

    def refresh_nav(self) -> None:
        q = self.search.text().strip()
        rows = []
        if q:
            hits = [e for e in lab.list if e.matches(q)]
            rows.append(("head", f"搜索「{q}」· {len(hits)} 项"))
            rows += [("item", e, f"{SUBJECTS[e.subj]['name']} · {e.unit}") for e in hits]
        else:
            for i, b in enumerate(SUBJECTS[self.subj]["books"]):
                es = [e for e in lab.of(self.subj) if e.book == i]
                if es:
                    rows.append(("head", b))
                    rows += [("item", e) for e in es]
            if not rows:
                rows.append(("head", "这一科的实验正在改写为原生版"))
        self.nav.set_rows(rows, self.cur.id if self.cur else None)

    def go_home(self) -> None:
        self._close_exp()
        self.cur = None
        self.center.setCurrentIndex(0)
        self.side.setVisible(False)   # 首页没有参数可调，侧栏收起让卡片铺开
        self.refresh_nav()
        self.refresh_info()

    def _close_exp(self) -> None:
        if hasattr(self,"clip_transfer"):
            self.clip_transfer.before_close()
        if self.ctx:
            self.ctx.dispose()
            self.ctx.stage.setParent(None)
            self.ctx.stage.deleteLater()
            self.ctx = None
        if self.cur_bench:
            self.cur_bench, self.B = None, None
            while self.bench_tabs_box.count():
                w = self.bench_tabs_box.takeAt(0).widget()
                if w:
                    w.setParent(None)
                    w.deleteLater()
            self.drawer_stack.setCurrentIndex(0)

    def _new_ctx(self):
        panel = QWidget()
        panel.setObjectName("panel")
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(18, 12, 18, 18)
        pv.setSpacing(4)
        self.ctx = Ctx(self.stage_host, panel)
        self.stage_host.lay.addWidget(self.ctx.stage)
        return panel, pv

    def open_bench(self, bid: str) -> None:
        k = bench.by_id.get(bid)
        if not k:
            return
        self._close_exp()
        self.cur = None
        if k.subj != self.subj:
            self.set_subj(k.subj)
        self.cur_bench = k
        sc = (tokens.NIGHT if T.dark else tokens.DAY)[k.subj]
        self.head.setText(f"<span style='font-size:21px;font-weight:700;color:{T.fg}'>{k.title}</span>"
                          f"&nbsp;&nbsp;<span style='color:{sc};font-size:12.5px'>● 自由工作台</span>")
        self.head.setToolTip(k.sub)
        tabs = BenchTabs(k.id)
        tabs.picked.connect(self.open_bench)
        self.bench_tabs_box.addWidget(tabs)
        panel, pv = self._new_ctx()
        pal = Palette()
        self.pal_scroll.setWidget(pal)
        self.drawer_stack.setCurrentIndex(1)
        self.B = BenchAPI(self.ctx, pal, self.refresh_info)
        self.panel_scroll.setWidget(panel)
        # 工作台在 init 里就按画布宽度摆放器材：先把版面排好，让画布拿到真实尺寸
        self.center.setCurrentIndex(1)
        self.side.setVisible(self.side_btn.isChecked())
        for lay in (self.layout(), self.exp_page.layout(), self.stage_host.lay):
            lay.activate()
        self.ctx.stage.c.w, self.ctx.stage.c.h = max(10, self.ctx.stage.width()), max(10, self.ctx.stage.height())
        try:
            k.init(self.B)
        except Exception as exc:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            self.ctx.stage.error = f"{type(exc).__name__}: {exc}"
        self.center.setCurrentIndex(1)
        self.side.setVisible(self.side_btn.isChecked())
        self.refresh_info()
        self.ctx.draw()

        self.clip_transfer.mount()

    def open(self, eid: str) -> None:
        e = lab.by_id.get(eid)
        if not e:
            return
        self._close_exp()
        self.cur = e
        if e.subj != self.subj:
            self.set_subj(e.subj)
        meta = SUBJECTS[e.subj]
        sc = (tokens.NIGHT if T.dark else tokens.DAY)[e.subj]
        self.head.setText(f"<span style='font-size:21px;font-weight:700;color:{T.fg}'>{e.title}</span>"
                          f"&nbsp;&nbsp;<span style='color:{sc};font-size:12.5px'>● {meta['name']} · {meta['books'][e.book]}</span>"
                          f"&nbsp;&nbsp;<span style='color:{T.muted};font-size:12.5px'>{e.unit}</span>")
        self.head.setToolTip("")
        panel, pv = self._new_ctx()
        try:
            e.init(self.ctx)
        except Exception as exc:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            self.ctx.stage.error = f"{type(exc).__name__}: {exc}"
        pv.addStretch(1)
        self.panel_scroll.setWidget(panel)
        self.center.setCurrentIndex(1)
        self.side.setVisible(self.side_btn.isChecked())
        self.refresh_nav()
        self.refresh_info()
        self.ctx.draw()

    def refresh_info(self) -> None:
        e = self.cur
        k = self.cur_bench
        if k:
            B = self.B
            html = [f"<h3>{k.title}</h3><p>{k.desc}</p>"]
            if B and B.log.rows:
                html.append("<h3>实验记录</h3><ol>" + "".join(f"<li>{r}</li>" for r in B.log.rows) + "</ol>")
            for title, items in (B.tip_secs if B else []):
                html.append(f"<h3>{title}</h3><ol>" + "".join(f"<li>{t}</li>" for t in items) + "</ol>")
            self.info.setHtml("".join(html))
            return
        if not e:
            self.info.setHtml("<h3>格物实验台</h3><p>从左侧目录或首页卡片选一个实验。画布上可以拖动、滚轮缩放、双击复位；"
                              "右侧「参数」里调参数、看读数，「原理」里是公式与探究建议。</p>")
            return
        tasks = "".join(f"<li>{t}</li>" for t in e.tasks)
        self.info.setHtml(f"<h3>原理与公式</h3>{e.info}" + (f"<h3>探究建议</h3><ol>{tasks}</ol>" if tasks else ""))

    # ---- 工具条
    def reset_view(self) -> None:
        if self.ctx and self.ctx.stage.mouse:
            from PySide6.QtCore import QPointF
            from PySide6.QtGui import QMouseEvent
            ev = QMouseEvent(QMouseEvent.Type.MouseButtonDblClick, QPointF(1, 1), QPointF(1, 1),
                             Qt.MouseButton.LeftButton, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
            self.ctx.stage.mouse("dbl", ev)

    def snapshot(self) -> None:
        if not self.ctx:
            return
        name = (self.cur.title if self.cur else self.cur_bench.title if self.cur_bench else "格物") + ".png"
        path, _ = QFileDialog.getSaveFileName(self, "保存画面", name, "PNG 图片 (*.png)")
        if path:
            self.ctx.stage.grab().save(path, "PNG")

    def toggle_full(self) -> None:
        self.showNormal() if self.isFullScreen() else self.showFullScreen()


def _unused():
    _ = (QSize, QSizePolicy)
