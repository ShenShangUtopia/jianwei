"""几何画板的模型层（由 legacy/lab-math.js 改写）：仿射矩阵、对象、历史、预设、变换、作图工具、命中测试。

核心模型：每个点 / 曲线自己保存「原像坐标 + 累计仿射矩阵 m」，实线画当前像，虚线画原像 ghost；
右侧与画布同时显示 3×3 变换矩阵。对象都是 dict，点坐标用 (x, y) 元组。
"""
from __future__ import annotations

import copy
import json
import math
import re
import time

from ...kit.core import PI, TAU, clamp
from ...kit.expr import compile_expr

IDENT = [1, 0, 0, 0, 1, 0, 0, 0, 1]
TYPE_NAMES = {"point": "点", "segment": "线段", "line": "直线", "circle": "圆", "polygon": "多边形", "vector": "向量", "function": "函数",
              "mdist": "距离", "mangle": "角度", "marea": "面积"}
COLOR_KEYS = [("accent", "朱砂"), ("jade", "青瓷"), ("ink2", "靛蓝"), ("data1", "雾蓝"), ("gold", "金")]
PRESETS = [
    {"id": "triangle", "name": "三角形变换演示", "desc": "幽灵原图 + 四种一键演示"},
    {"id": "quadratic", "name": "二次函数", "desc": "y = a(x−h)² + k"},
    {"id": "trig", "name": "三角函数", "desc": "y = A sin(Bx+φ) + k"},
    {"id": "inverse", "name": "反比例", "desc": "y = k / x"},
    {"id": "circletangent", "name": "圆与切线", "desc": "切点、半径与切线方程"},
]


def is_num(v):
    return isinstance(v, (int, float)) and math.isfinite(v)


def num(v, d=2):
    """去掉末尾 0 的定点数（JW.num）。"""
    if not is_num(v):
        return "—"
    s = f"{v:.{max(0, d)}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def fmt_m(v):
    r = round(v * 1000) / 1000
    if r == 0:
        return "0"
    return str(int(r)) if r == int(r) else str(r)


def fmt_angle(rad):
    return num(math.degrees(rad), 1) + "°"


def fmt_pt(p):
    return f"({num(p[0], 2)}, {num(p[1], 2)})"


def truncate(s, n):
    s = str(s or "")
    return s[:n - 1] + "…" if len(s) > n else s


def pretty_expr(expr):
    return re.sub(r"\bPI\b", "π", str(expr or "").replace("(PI)", "π"))


# ---------------------------------------------------------------- 仿射矩阵
def mat_mul(A, B):
    return [A[r * 3] * B[c] + A[r * 3 + 1] * B[3 + c] + A[r * 3 + 2] * B[6 + c] for r in range(3) for c in range(3)]


def apply_m(m, x, y):
    m = m or IDENT
    return m[0] * x + m[1] * y + m[2], m[3] * x + m[4] * y + m[5]


def invert_m(m):
    m = m or IDENT
    a, b, c, d, e, f = m[:6]
    det = a * e - b * d
    if not math.isfinite(det) or abs(det) < 1e-12:
        return list(IDENT)
    ia, ib, id_, ie = e / det, -b / det, -d / det, a / det
    return [ia, ib, -(ia * c + ib * f), id_, ie, -(id_ * c + ie * f), 0, 0, 1]


def is_i(m):
    return not m or all(abs(m[i] - IDENT[i]) <= 1e-6 for i in range(9))


def translate_m(dx, dy):
    return [1, 0, dx, 0, 1, dy, 0, 0, 1]


def rotate_m(rad, p):
    cs, sn = math.cos(rad), math.sin(rad)
    return [cs, -sn, p[0] - cs * p[0] + sn * p[1], sn, cs, p[1] - sn * p[0] - cs * p[1], 0, 0, 1]


def scale_m(k, p):
    return [k, 0, p[0] - k * p[0], 0, k, p[1] - k * p[1], 0, 0, 1]


def reflect_point_m(p):
    return [-1, 0, 2 * p[0], 0, -1, 2 * p[1], 0, 0, 1]


def reflect_line_m(a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    ln = math.hypot(dx, dy) or 1
    dx, dy = dx / ln, dy / ln
    cs, sn = dx * dx - dy * dy, 2 * dx * dy
    return [cs, sn, a[0] - (cs * a[0] + sn * a[1]), sn, -cs, a[1] - (sn * a[0] - cs * a[1]), 0, 0, 1]


def matrix_rows(m):
    m = m or IDENT
    rows = []
    for r in range(3):
        inner = f"[{fmt_m(m[r * 3])}, {fmt_m(m[r * 3 + 1])}, {fmt_m(m[r * 3 + 2])}]"
        rows.append(("[" if r == 0 else " ") + inner + ("]" if r == 2 else ","))
    return rows


# ---------------------------------------------------------------- 距离
def dist_seg(px, py, x1, y1, x2, y2):
    dx, dy = x2 - x1, y2 - y1
    t = clamp(((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy or 1), 0, 1)
    return math.hypot(px - (x1 + t * dx), py - (y1 + t * dy))


def dist_line(px, py, x1, y1, x2, y2):
    dx, dy = x2 - x1, y2 - y1
    return abs((px - x1) * dy - (py - y1) * dx) / (math.hypot(dx, dy) or 1)


def dist_poly(px, py, pts):
    return min(dist_seg(px, py, *pts[i], *pts[(i + 1) % len(pts)]) for i in range(len(pts)))


def point_in_poly(x, y, pts):
    inside = False
    j = len(pts) - 1
    for i in range(len(pts)):
        xi, yi = pts[i]
        xj, yj = pts[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def normalize_expr(raw):
    s = str(raw or "").strip()
    s = re.sub(r"^y\s*=\s*", "", s, flags=re.I)
    s = re.sub(r"^f\s*\(\s*x\s*\)\s*=\s*", "", s, flags=re.I)
    return s.replace("²", "^2").replace("³", "^3").replace("−", "-").replace("·", "*").replace("π", "(pi)")


def compile_checked(expr):
    fn = compile_expr(expr)
    ok = False
    for x in (0.37, 1, 2):
        try:
            if math.isfinite(fn(x)):
                ok = True
        except (ValueError, ZeroDivisionError, OverflowError, TypeError):
            pass
    if not ok:
        raise ValueError("表达式没有可绘制的实数值")
    return fn


def safe_fn(fn):
    def g(x):
        try:
            y = fn(x)
            return y if isinstance(y, (int, float)) else float("nan")
        except (ValueError, ZeroDivisionError, OverflowError, TypeError):
            return float("nan")
    return g


class GeoCore:
    """画板状态与全部非绘制逻辑。界面通过覆盖 toast / refresh_all / render / update_status 接入。"""

    def __init__(self):
        self.w, self.h = 800, 600
        self.view = {"cx": 0.0, "cy": 0.0, "scale": 52.0}
        self.objects: list = []
        self.selection: list = []
        self.tool = "select"
        self.draft = None
        self.handle = None
        self.measure_mode = "dist"
        self.measure_picks: list = []
        self.pivot_mode = "origin"
        self.axis_mode = "x"
        self.preset = ""
        self.params: dict = {}
        self.last_transform = None
        self.show_grid = True
        self.snap_grid = True
        self.show_measure = True
        self.show_annotation = True
        self.hover = None
        self.snap_info = None
        self.past: list = []
        self.future: list = []
        self.limit = 64
        self._seq = 0
        self.tx = {"dx": "2", "dy": "1", "angle": "60", "k": "1.5"}

    # 界面钩子
    def toast(self, msg, ms=2000):
        pass

    def refresh_all(self):
        pass

    def render(self):
        pass

    def schedule_save(self):
        pass

    def update_status(self):
        pass

    def update_history_ui(self):
        pass

    def update_tool_ui(self):
        pass

    # ---- 对象
    def uid(self, prefix):
        self._seq += 1
        return f"{prefix}_{int(time.time() * 1000):x}{self._seq:x}"

    def by_id(self, i):
        for o in self.objects:
            if o["id"] == i:
                return o
        return None

    def find_role(self, role):
        for o in self.objects:
            if o.get("role") == role:
                return o
        return None

    def next_point_name(self):
        used = {o.get("name") for o in self.objects if o["type"] == "point"}
        for i in range(676):
            s, n = "", i
            while n >= 0:
                s = chr(65 + n % 26) + s
                n = n // 26 - 1
            if s not in used:
                return s
        return f"P{len(self.objects)}"

    @staticmethod
    def ref_ids(o):
        if not o:
            return []
        t = o["type"]
        if t == "point":
            return [o["id"]]
        if t in ("segment", "line", "vector", "mdist"):
            return [x for x in (o.get("a"), o.get("b")) if x]
        if t == "circle":
            return [x for x in (o.get("c"), o.get("r")) if x]
        if t == "polygon":
            return list(o.get("pts") or [])
        if t == "mangle":
            return [x for x in (o.get("a"), o.get("b"), o.get("c")) if x]
        if t == "marea":
            return [o["poly"]] if o.get("poly") else []
        return []

    def dep_points(self, o):
        out = []
        for i in self.ref_ids(o):
            p = self.by_id(i)
            if p and p["type"] == "point":
                out.append(p)
        return out

    @staticmethod
    def cur_of_point(p):
        if not p or p["type"] != "point":
            return None
        return apply_m(p.get("m"), p["x"], p["y"])

    def cur_of_id(self, i):
        o = self.by_id(i)
        return self.cur_of_point(o) if o and o["type"] == "point" else None

    def current_circle(self, o):
        c, rp = self.cur_of_id(o.get("c")), self.cur_of_id(o.get("r"))
        if not c or not rp:
            return None
        return {"c": c, "r": math.hypot(rp[0] - c[0], rp[1] - c[1])}

    def segment_len(self, o):
        a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
        return math.hypot(b[0] - a[0], b[1] - a[1]) if a and b else 0.0

    def poly_pts(self, o):
        return [p for p in (self.cur_of_id(i) for i in o.get("pts") or []) if p]

    def polygon_area(self, o):
        pts = self.poly_pts(o)
        if len(pts) < 3:
            return 0.0
        s = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))
        return abs(s) / 2

    def polygon_perimeter(self, o):
        pts = self.poly_pts(o)
        return sum(math.hypot(pts[(i + 1) % len(pts)][0] - pts[i][0], pts[(i + 1) % len(pts)][1] - pts[i][1]) for i in range(len(pts)))

    @staticmethod
    def centroid_of(pts):
        if not pts:
            return 0.0, 0.0
        return sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)

    def angle_of(self, o):
        a, b, c = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b")), self.cur_of_id(o.get("c"))
        if not a or not b or not c:
            return 0.0
        u = (a[0] - b[0], a[1] - b[1])
        v = (c[0] - b[0], c[1] - b[1])
        d = math.hypot(*u) * math.hypot(*v)
        return math.acos(clamp((u[0] * v[0] + u[1] * v[1]) / d, -1, 1)) if d > 1e-12 else 0.0

    def name_of(self, i):
        return (self.by_id(i) or {}).get("name", "")

    def object_label(self, o):
        if not o:
            return "对象"
        t = o["type"]
        if t == "point":
            return o.get("name") or "P"
        if t in ("segment", "line", "vector"):
            if o.get("name"):
                return o["name"]
            return (self.name_of(o.get("a")) or "A") + (self.name_of(o.get("b")) or "B")
        if t == "circle":
            return "⊙" + (self.name_of(o.get("c")) or "O")
        if t == "polygon":
            names = "".join(self.name_of(i) for i in o.get("pts") or [])
            return "△" + names if len(names) == 3 else names or "多边形"
        if t == "function":
            return "f(x) = " + truncate(pretty_expr(o["expr"]), 14)
        if t == "mdist":
            return "距离 " + self.name_of(o.get("a")) + self.name_of(o.get("b"))
        if t == "mangle":
            return "∠" + self.name_of(o.get("a")) + self.name_of(o.get("b")) + self.name_of(o.get("c"))
        if t == "marea":
            return "面积 " + self.object_label(self.by_id(o.get("poly")))
        return TYPE_NAMES.get(t, "对象")

    def object_meta(self, o):
        if not o:
            return ""
        t = o["type"]
        if t == "point":
            return fmt_pt(self.cur_of_point(o))
        if t == "segment":
            return "长度 " + num(self.segment_len(o), 2)
        if t == "line":
            return "过两点"
        if t == "vector":
            a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
            return f"分量 ({num(b[0] - a[0], 2)}, {num(b[1] - a[1], 2)})" if a and b else ""
        if t == "circle":
            c = self.current_circle(o)
            return "r = " + num(c["r"], 2) if c else ""
        if t == "polygon":
            return f"{len(o.get('pts') or [])} 个顶点"
        if t == "function":
            return "y = " + truncate(pretty_expr(o["expr"]), 22)
        if t == "mdist":
            return num(self.segment_len(o), 2)
        if t == "mangle":
            return fmt_angle(self.angle_of(o))
        if t == "marea":
            p = self.by_id(o.get("poly"))
            return "S = " + num(self.polygon_area(p), 2) if p else ""
        return ""

    def create_point(self, x, y, name=None, color="ink2", aux=False, role="", m=None):
        o = {"id": self.uid("p"), "type": "point", "x": x, "y": y, "m": list(m or IDENT), "name": name or self.next_point_name(), "color": color,
             "width": 1, "hidden": False, "aux": aux, "role": role, "dash": False}
        self.objects.append(o)
        return o

    def create_shape(self, typ, data=None, color=None, width=None, aux=False, role="", dash=False, name=None):
        o = {"id": self.uid(typ[:2]), "type": typ, "color": color or ("jade" if typ in ("circle", "polygon") else "ink2"), "width": width or 2,
             "hidden": False, "aux": aux, "role": role, "dash": dash}
        if name:
            o["name"] = name
        o.update(data or {})
        self.objects.append(o)
        return o

    def add_function(self, expr, color="data1", width=2.2, aux=False, role=""):
        expr = normalize_expr(expr)
        if not expr:
            raise ValueError("请输入函数表达式")
        fn = compile_checked(expr)
        o = {"id": self.uid("fn"), "type": "function", "expr": expr, "fn": safe_fn(fn), "m": list(IDENT), "color": color, "width": width, "hidden": False,
             "aux": aux, "role": role, "dash": False}
        self.objects.append(o)
        return o

    def set_function_expr(self, o, expr):
        if not o:
            return None
        expr = normalize_expr(expr)
        o["fn"] = safe_fn(compile_checked(expr))
        o["expr"] = expr
        return o

    @staticmethod
    def strip_object(o):
        c = {k: v for k, v in o.items() if k != "fn"}
        if c.get("m"):
            c["m"] = list(c["m"])
        if c.get("pts"):
            c["pts"] = list(c["pts"])
        return c

    @staticmethod
    def hydrate_object(o):
        if not o:
            return o
        if o["type"] == "function":
            try:
                o["fn"] = safe_fn(compile_expr(o["expr"]))
            except Exception:  # noqa: BLE001
                o["fn"] = lambda _x: float("nan")
        if not o.get("m"):
            o["m"] = list(IDENT)
        return o

    # ---- 坐标
    def X(self, x):
        return self.w / 2 + (x - self.view["cx"]) * self.view["scale"]

    def Y(self, y):
        return self.h / 2 - (y - self.view["cy"]) * self.view["scale"]

    def world_at(self, sx, sy):
        return self.view["cx"] + (sx - self.w / 2) / self.view["scale"], self.view["cy"] - (sy - self.h / 2) / self.view["scale"]

    def screen_of(self, p):
        return self.X(p[0]), self.Y(p[1])

    @staticmethod
    def nice_step(px_per_unit, target):
        raw = max(1e-9, target / px_per_unit)
        p = 10 ** math.floor(math.log10(raw))
        n = raw / p
        return (1 if n <= 1.2 else 2 if n <= 2.2 else 5 if n <= 5.2 else 10) * p

    def grid_steps(self):
        major = self.nice_step(self.view["scale"], 58)
        return major, major / 5

    @staticmethod
    def tick_text(v, step):
        dec = 0 if step >= 1 else min(3, max(0, math.ceil(-math.log10(step))))
        return num(v, dec)

    def set_view(self, cx=None, cy=None, scale=None):
        if is_num(cx):
            self.view["cx"] = cx
        if is_num(cy):
            self.view["cy"] = cy
        if is_num(scale):
            self.view["scale"] = clamp(scale, 5, 420)

    def bounds_all(self):
        xs, ys = [], []

        def add(p):
            if p and math.isfinite(p[0]) and math.isfinite(p[1]):
                xs.append(p[0])
                ys.append(p[1])
        for o in self.objects:
            if o["hidden"] or o["aux"]:
                continue
            t = o["type"]
            if t == "point":
                add(self.cur_of_point(o))
            elif t == "function":
                for i in range(81):
                    x = -8 + i * 16 / 80
                    y = o["fn"](x)
                    if math.isfinite(y):
                        add(apply_m(o["m"], x, y))
            else:
                for p in self.dep_points(o):
                    add(self.cur_of_point(p))
            if t == "circle":
                c = self.current_circle(o)
                if c:
                    add((c["c"][0] - c["r"], c["c"][1] - c["r"]))
                    add((c["c"][0] + c["r"], c["c"][1] + c["r"]))
        if not xs:
            return None
        return min(xs), max(xs), min(ys), max(ys)

    def fit_view(self):
        b = self.bounds_all()
        if not b:
            self.view = {"cx": 0.0, "cy": 0.0, "scale": 52.0}
        else:
            pad = 92
            sw, sh = max(0.8, b[1] - b[0]), max(0.8, b[3] - b[2])
            self.view["scale"] = clamp(min((self.w - pad) / sw, (self.h - pad) / sh), 6, 240)
            self.view["cx"], self.view["cy"] = (b[0] + b[1]) / 2, (b[2] + b[3]) / 2
        self.render()
        self.schedule_save()

    def selection_bounds(self):
        xs, ys = [], []
        for i in self.expand_selection(self.selection):
            o = self.by_id(i)
            if not o or o["hidden"]:
                continue
            if o["type"] == "point":
                p = self.cur_of_point(o)
                xs.append(p[0])
                ys.append(p[1])
            elif o["type"] == "function":
                for k in range(61):
                    x = -6 + k * 12 / 60
                    y = o["fn"](x)
                    if math.isfinite(y):
                        p = apply_m(o["m"], x, y)
                        xs.append(p[0])
                        ys.append(p[1])
        # 圆的对象中心应按整圆包围盒算，而不是「圆心 + 半径点」的包围盒
        for i in self.selection:
            o = self.by_id(i)
            if o and o["type"] == "circle" and not o["hidden"]:
                c = self.current_circle(o)
                if c:
                    xs += [c["c"][0] - c["r"], c["c"][0] + c["r"]]
                    ys += [c["c"][1] - c["r"], c["c"][1] + c["r"]]
        if not xs:
            return None
        return min(xs), max(xs), min(ys), max(ys)

    def get_pivot(self):
        if self.pivot_mode == "center":
            b = self.selection_bounds()
            if b:
                return (b[0] + b[1]) / 2, (b[2] + b[3]) / 2
            return self.view["cx"], self.view["cy"]
        if self.pivot_mode.startswith("point:"):
            c = self.cur_of_point(self.by_id(self.pivot_mode[6:]))
            if c:
                return c
        return 0.0, 0.0

    def selection_matrix(self):
        for i in self.selection:
            o = self.by_id(i)
            if not o:
                continue
            if o["type"] in ("point", "function"):
                return o.get("m") or IDENT
            d = self.dep_points(o)
            if d:
                return d[0].get("m") or IDENT
        return None

    # ---- 历史
    def snapshot(self):
        return json.dumps({"objects": [self.strip_object(o) for o in self.objects], "selection": list(self.selection), "lastTransform": self.last_transform,
                           "preset": self.preset, "params": self.params})

    def push_history(self):
        self.past.append(self.snapshot())
        if len(self.past) > self.limit:
            self.past.pop(0)
        self.future.clear()
        self.update_history_ui()

    def restore_snapshot(self, s):
        try:
            d = json.loads(s)
        except ValueError:
            return
        self.objects = [self.hydrate_object(o) for o in d.get("objects") or []]
        self.selection = [i for i in d.get("selection") or [] if self.by_id(i)]
        self.last_transform = d.get("lastTransform")
        self.preset = d.get("preset") or ""
        self.params = d.get("params") or {}
        self.draft = self.handle = None
        self.measure_picks = []
        self.refresh_all()
        self.render()
        self.schedule_save()

    def do_undo(self, silent=False):
        if not self.past:
            return False
        self.future.append(self.snapshot())
        self.restore_snapshot(self.past.pop())
        self.update_history_ui()
        if not silent:
            self.toast("已撤销")
        return True

    def do_redo(self, silent=False):
        if not self.future:
            return False
        self.past.append(self.snapshot())
        self.restore_snapshot(self.future.pop())
        self.update_history_ui()
        if not silent:
            self.toast("已重做")
        return True

    # ---- 选择与增删
    def expand_selection(self, ids):
        out, seen = [], set()

        def add(i):
            if not i or i in seen:
                return
            o = self.by_id(i)
            if not o:
                return
            seen.add(i)
            out.append(i)
            if o["type"] in ("segment", "line", "vector", "circle", "polygon"):
                for r in self.ref_ids(o):
                    add(r)
        for i in ids or []:
            add(i)
        return out

    def select_objects(self, ids, additive=False):
        if not additive:
            self.selection = []
        for i in ids or []:
            if not self.by_id(i):
                continue
            if i in self.selection:
                if additive:
                    self.selection.remove(i)
            else:
                self.selection.append(i)
        self.refresh_all()
        self.render()

    def select_one(self, i, additive=False):
        self.select_objects([i], additive)

    def remove_objects(self, ids):
        dele = set(ids)
        changed = True
        while changed:
            changed = False
            for o in self.objects:
                if o["id"] in dele:
                    continue
                if any(r in dele for r in self.ref_ids(o)):
                    dele.add(o["id"])
                    changed = True
        before = len(self.objects)
        self.objects = [o for o in self.objects if o["id"] not in dele]
        self.selection = [i for i in self.selection if i not in dele]
        self.measure_picks = [i for i in self.measure_picks if i not in dele]
        self.draft = None
        self.refresh_all()
        self.render()
        self.schedule_save()
        return before - len(self.objects)

    def delete_selection(self):
        if not self.selection:
            self.toast("先选中要删除的对象")
            return
        self.push_history()
        n = self.remove_objects(list(self.selection))
        self.toast(f"已删除 {n} 个对象 · Ctrl+Z 可撤销")

    def clear_scene(self):
        if not self.objects:
            self.toast("画布已经是空的")
            return
        self.push_history()
        self.objects, self.selection = [], []
        self.last_transform = None
        self.preset, self.params = "", {}
        self.draft = self.handle = None
        self.measure_picks = []
        self.refresh_all()
        self.render()
        self.schedule_save()
        self.toast("已清空 · Ctrl+Z 可撤销")

    # ---- 预设
    def build_preset_objects(self, pid):
        p = self.params
        if pid == "triangle":
            A = self.create_point(-3, -1.1, name="A")
            B = self.create_point(0, -1.1, name="B")
            C = self.create_point(-1.5, 1.6, name="C")
            return {"poly": self.create_shape("polygon", {"pts": [A["id"], B["id"], C["id"]]}, color="jade", width=2.2, role="triangle")}
        if pid == "quadratic":
            fn = self.add_function(f"{p['a']}*(x-({p['h']}))^2+({p['k']})", role="qfunc")
            self.create_point(p["h"], p["k"], name="V", color="accent", role="qvertex")
            return {"fn": fn}
        if pid == "trig":
            return {"fn": self.add_function(f"{p['A']}*sin({p['B']}*x+({p['phi']}))+({p['k']})", role="tfunc")}
        if pid == "inverse":
            return {"fn": self.add_function(f"({p['k']})/x", role="ifunc")}
        if pid == "circletangent":
            O = self.create_point(0, 0, name="O", role="ctO")
            R = self.create_point(p["r"], 0, name="R", role="ctR")
            th = p["theta"] * PI / 180
            Pp = self.create_point(p["r"] * math.cos(th), p["r"] * math.sin(th), name="P", color="accent", role="ctP")
            Tt = self.create_point(Pp["x"] - math.sin(th) * 3.4, Pp["y"] + math.cos(th) * 3.4, name="T", role="ctT", aux=True)
            circle = self.create_shape("circle", {"c": O["id"], "r": R["id"]}, color="jade", width=2.2, role="ctCircle")
            self.create_shape("segment", {"a": O["id"], "b": Pp["id"]}, color="soft", width=1.1, dash=True, aux=True, role="ctGuide")
            self.create_shape("line", {"a": Pp["id"], "b": Tt["id"]}, color="accent", width=2, role="ctLine", name="切线")
            return {"circle": circle}
        return None

    @staticmethod
    def preset_view(pid):
        return {"triangle": {"cx": 0.0, "cy": 0.0, "scale": 54.0}, "quadratic": {"cx": 0.0, "cy": 1.2, "scale": 47.0}, "trig": {"cx": 0.0, "cy": 0.3, "scale": 44.0},
                "inverse": {"cx": 0.0, "cy": 0.0, "scale": 43.0}, "circletangent": {"cx": 0.0, "cy": 0.15, "scale": 54.0}}.get(pid, {"cx": 0.0, "cy": 0.0, "scale": 52.0})

    @staticmethod
    def default_params(pid):
        return {"quadratic": {"a": 0.8, "h": -1, "k": -1.5}, "trig": {"A": 1.6, "B": 1.2, "phi": 0.55, "k": 0.2}, "inverse": {"k": 4},
                "circletangent": {"r": 2, "theta": 52}}.get(pid, {})

    def apply_preset(self, pid, no_history=False, silent=False, preview=False):
        d = next((x for x in PRESETS if x["id"] == pid), None)
        if not d:
            return
        if not no_history:
            self.push_history()
        self.objects, self.selection = [], []
        self.draft = self.handle = None
        self.measure_picks = []
        self.last_transform = None
        self.tool = "select"
        self.preset = pid
        self.params = self.default_params(pid)
        self.view = dict(self.preset_view(pid))
        built = self.build_preset_objects(pid)
        if pid == "triangle" and built:
            self.selection = [built["poly"]["id"]]
        elif built and built.get("fn"):
            self.selection = [built["fn"]["id"]]
        elif pid == "circletangent" and built:
            self.selection = [built["circle"]["id"]]
        if preview and pid == "triangle" and built:
            r = math.radians(22)
            self.apply_transform(rotate_m(r, (0, 0)), {"type": "rotate", "label": "绕原点旋转 22°", "params": {"angle": 22, "rad": r, "pivot": (0, 0)}}, silent=True, no_history=True)
            self.selection = [built["poly"]["id"]]
        self.refresh_all()
        self.render()
        if not silent:
            self.schedule_save()
            self.toast(d["name"] + " · 已载入")

    def refresh_preset_objects(self):
        p = self.params
        if self.preset == "quadratic":
            f, v = self.find_role("qfunc"), self.find_role("qvertex")
            if f:
                self.set_function_expr(f, f"{p['a']}*(x-({p['h']}))^2+({p['k']})")
            if v:
                v["x"], v["y"] = p["h"], p["k"]
        elif self.preset == "trig":
            f = self.find_role("tfunc")
            if f:
                self.set_function_expr(f, f"{p['A']}*sin({p['B']}*x+({p['phi']}))+({p['k']})")
        elif self.preset == "inverse":
            f = self.find_role("ifunc")
            k = p["k"]
            if abs(k) < 0.25:
                k = -0.5 if k < 0 else 0.5
            if f:
                self.set_function_expr(f, f"({k})/x")
        elif self.preset == "circletangent":
            O, R, Pp, Tt = self.find_role("ctO"), self.find_role("ctR"), self.find_role("ctP"), self.find_role("ctT")
            r, th = max(0.3, p["r"]), p["theta"] * PI / 180
            if R:
                R["x"], R["y"] = r, 0
            if Pp:
                Pp["x"], Pp["y"] = r * math.cos(th), r * math.sin(th)
            if Tt:
                Tt["x"] = Pp["x"] - math.sin(th) * 3.4 if Pp else 0
                Tt["y"] = Pp["y"] + math.cos(th) * 3.4 if Pp else 1
            if O:
                O["x"], O["y"] = 0, 0

    def triangle_demo(self, kind):
        poly = self.find_role("triangle")
        if not poly:
            self.toast("请先载入三角形预设")
            return
        self.selection = [poly["id"]]
        self.tool = "select"
        self.draft = self.handle = None
        if kind == "translate":
            T, meta = translate_m(2, 1), {"type": "translate", "label": "平移 (2, 1)", "params": {"dx": 2, "dy": 1}}
        elif kind == "rotate":
            r = math.radians(60)
            T, meta = rotate_m(r, (0, 0)), {"type": "rotate", "label": "绕原点旋转 60°", "params": {"angle": 60, "rad": r, "pivot": (0, 0)}}
        elif kind == "scale":
            T, meta = scale_m(1.5, (0, 0)), {"type": "scale", "label": "以原点为中心缩放 k=1.5", "params": {"k": 1.5, "pivot": (0, 0)}}
        else:
            T, meta = reflect_line_m((0, 0), (1, 0)), {"type": "sym-line", "label": "关于 x 轴对称", "params": {"axisLabel": "x 轴", "axis": [(0, 0), (1, 0)]}}
        self.apply_transform(T, meta)

    def tangent_equation(self):
        p = self.params
        th, r = p["theta"] * PI / 180, p["r"]
        return f"{fmt_m(math.cos(th))}x + {fmt_m(math.sin(th))}y = {num(r, 2)}"

    # ---- 变换
    def apply_transform(self, T, meta=None, silent=False, no_history=False):
        meta = meta or {}
        targets = [self.by_id(i) for i in self.expand_selection(self.selection)]
        movable = [o for o in targets if o and o["type"] in ("point", "function")]
        if not movable:
            if not silent:
                self.toast("先选中要变换的对象")
            return False
        if not no_history:
            self.push_history()
        for o in movable:
            o["m"] = mat_mul(T, o.get("m") or IDENT)
        self.last_transform = {"type": meta.get("type", "transform"), "label": meta.get("label", "变换"), "matrix": list(T), "params": meta.get("params", {})}
        self.refresh_all()
        self.render()
        self.schedule_save()
        if not silent:
            self.toast(meta.get("label", "变换") + " · 已应用，虚线为原像")
        return True

    def numeric_apply(self, kind):
        if not self.selection:
            self.toast("先选中对象")
            return

        def val(k):
            try:
                return float(self.tx[k])
            except (TypeError, ValueError):
                return None
        if kind == "translate":
            dx, dy = val("dx"), val("dy")
            if dx is None or dy is None:
                self.toast("请输入平移量 dx / dy")
                return
            self.apply_transform(translate_m(dx, dy), {"type": "translate", "label": f"平移 ({num(dx, 2)}, {num(dy, 2)})", "params": {"dx": dx, "dy": dy}})
        elif kind == "rotate":
            deg = val("angle")
            if deg is None:
                self.toast("请输入旋转角度")
                return
            pv = self.get_pivot()
            r = math.radians(deg)
            self.apply_transform(rotate_m(r, pv), {"type": "rotate", "label": f"绕 {fmt_pt(pv)} 旋转 {num(deg, 1)}°", "params": {"angle": deg, "rad": r, "pivot": pv}})
        elif kind == "scale":
            k = val("k")
            if k is None or abs(k) < 0.02:
                self.toast("缩放比 k 需大于 0")
                return
            pv = self.get_pivot()
            self.apply_transform(scale_m(k, pv), {"type": "scale", "label": f"以 {fmt_pt(pv)} 为中心缩放 k={num(k, 2)}", "params": {"k": k, "pivot": pv}})

    def axis_info(self):
        if self.axis_mode == "y":
            return {"label": "y 轴", "a": (0, 0), "b": (0, 1)}
        if self.axis_mode.startswith("line:"):
            line = self.by_id(self.axis_mode[5:])
            if line:
                a, b = self.cur_of_id(line.get("a")), self.cur_of_id(line.get("b"))
                if a and b:
                    return {"label": "直线 " + self.object_label(line), "a": a, "b": b}
        return {"label": "x 轴", "a": (0, 0), "b": (1, 0)}

    def apply_sym_point(self):
        if not self.selection:
            self.toast("先选中对象")
            return
        pv = self.get_pivot()
        self.apply_transform(reflect_point_m(pv), {"type": "sym-point", "label": f"关于点 {fmt_pt(pv)} 对称", "params": {"pivot": pv}})

    def apply_sym_line(self):
        if not self.selection:
            self.toast("先选中对象")
            return
        ax = self.axis_info()
        self.apply_transform(reflect_line_m(ax["a"], ax["b"]), {"type": "sym-line", "label": f"关于{ax['label']}对称", "params": {"axisLabel": ax["label"], "axis": [ax["a"], ax["b"]]}})

    def begin_handle(self, kind):
        if not self.selection:
            self.toast("先选中对象")
            return
        self.draft = None
        self.tool = "select"
        self.update_tool_ui()
        self.handle = {"kind": kind, "phase": "wait"}
        self.update_status()
        self.render()
        self.toast("在画布上拖动以" + {"rotate": "旋转", "scale": "缩放"}.get(kind, "平移"))

    def start_handle_drag(self, world):
        h = self.handle
        if not h or h["phase"] != "wait":
            return False
        targets = [o for o in (self.by_id(i) for i in self.expand_selection(self.selection)) if o and o["type"] in ("point", "function")]
        if not targets:
            self.toast("先选中可变换对象")
            self.handle = None
            return False
        pv = self.get_pivot()
        h.update(phase="drag", pivot=pv, startWorld=world, targets=[{"id": o["id"], "m": list(o.get("m") or IDENT)} for o in targets],
                 futureBefore=list(self.future), historyPushed=False, moved=False, preview=None)
        if h["kind"] == "rotate":
            h["a0"] = 0.0 if math.hypot(world[0] - pv[0], world[1] - pv[1]) < 1e-6 else math.atan2(world[1] - pv[1], world[0] - pv[0])
        if h["kind"] == "scale":
            r0 = math.hypot(world[0] - pv[0], world[1] - pv[1])
            h["r0"] = 1.0 if r0 < 1e-6 else r0
        return True

    def update_handle_drag(self, world):
        h = self.handle
        if not h or h["phase"] != "drag":
            return
        pv = h["pivot"]
        if h["kind"] == "translate":
            dx, dy = world[0] - h["startWorld"][0], world[1] - h["startWorld"][1]
            if math.hypot(dx, dy) * self.view["scale"] < 2:
                return
            T, typ = translate_m(dx, dy), "translate"
            label, params = f"平移 ({num(dx, 2)}, {num(dy, 2)})", {"dx": dx, "dy": dy}
        elif h["kind"] == "rotate":
            a = math.atan2(world[1] - pv[1], world[0] - pv[0]) - h["a0"]
            while a > PI:
                a -= TAU
            while a < -PI:
                a += TAU
            if abs(math.degrees(a)) < 0.4:
                return
            T, typ = rotate_m(a, pv), "rotate"
            label, params = f"绕 {fmt_pt(pv)} 旋转 {fmt_angle(a)}", {"angle": math.degrees(a), "rad": a, "pivot": pv}
        else:
            k = clamp(math.hypot(world[0] - pv[0], world[1] - pv[1]) / h["r0"], 0.1, 8)
            if abs(k - 1) * 100 < 0.5:
                return
            T, typ = scale_m(k, pv), "scale"
            label, params = f"以 {fmt_pt(pv)} 为中心缩放 k={num(k, 2)}", {"k": k, "pivot": pv}
        if not h["historyPushed"]:
            self.push_history()
            h["historyPushed"] = True
        h["preview"] = {"type": typ, "label": label, "matrix": list(T), "params": params}
        h["moved"] = True
        for t in h["targets"]:
            o = self.by_id(t["id"])
            if o and o["type"] in ("point", "function"):
                o["m"] = mat_mul(T, t["m"])
        self.render()

    def finish_handle(self):
        h = self.handle
        if not h or h["phase"] != "drag":
            return
        self.handle = None
        if h["moved"] and h["preview"]:
            self.last_transform = copy.deepcopy(h["preview"])
            self.refresh_all()
            self.render()
            self.schedule_save()
            self.toast(h["preview"]["label"] + " · 已应用")
        else:
            self.render()
            self.update_status()

    def cancel_handle(self):
        h = self.handle
        if not h:
            return False
        if h.get("historyPushed"):
            for t in h["targets"]:
                o = self.by_id(t["id"])
                if o and o["type"] in ("point", "function"):
                    o["m"] = list(t["m"])
            self.past.pop()
            self.future = list(h.get("futureBefore") or [])
        self.handle = None
        self.update_history_ui()
        self.update_status()
        self.render()
        self.schedule_save()
        return True

    # ---- 作图工具
    def snap_world(self, world, exclude=None, fine=False):
        best, best_d = None, 14 * 14
        wx, wy = self.X(world[0]), self.Y(world[1])
        for o in self.objects:
            if o["type"] != "point" or o["hidden"] or o["aux"] or o["id"] == exclude:
                continue
            c = self.cur_of_point(o)
            dx, dy = self.X(c[0]) - wx, self.Y(c[1]) - wy
            d = dx * dx + dy * dy
            if d < best_d:
                best_d, best = d, o
        if best:
            c = self.cur_of_point(best)
            return {"x": c[0], "y": c[1], "point": best}
        if self.snap_grid and not fine:
            step = self.grid_steps()[1]
            return {"x": round(world[0] / step) * step, "y": round(world[1] / step) * step, "step": step}
        return {"x": world[0], "y": world[1]}

    def resolve_point(self, world, exclude=None):
        s = self.snap_world(world, exclude)
        return s.get("point") or self.create_point(s["x"], s["y"])

    def start_draft(self, tool):
        fb = list(self.future)
        self.push_history()
        self.draft = {"tool": tool, "ids": [], "cursor": None, "backup": [self.strip_object(o) for o in self.objects],
                      "prevSelection": list(self.selection), "futureBefore": fb}
        self.measure_picks = []

    def cancel_draft(self):
        d = self.draft
        if not d:
            return False
        self.objects = [self.hydrate_object(o) for o in d["backup"]]
        self.selection = d["prevSelection"]
        self.draft = None
        self.past.pop()
        self.future = list(d.get("futureBefore") or [])
        self.update_history_ui()
        self.refresh_all()
        self.render()
        return True

    def finish_draft(self):
        d = self.draft
        if not d:
            return False
        points = [p for p in (self.by_id(i) for i in d["ids"]) if p]
        created = None
        if d["tool"] in ("segment", "line", "vector"):
            if len(points) < 2:
                return False
            created = self.create_shape(d["tool"], {"a": points[0]["id"], "b": points[1]["id"]})
        elif d["tool"] == "circle":
            if len(points) < 2:
                return False
            c, rp = self.cur_of_point(points[0]), self.cur_of_point(points[1])
            if not c or not rp or math.hypot(rp[0] - c[0], rp[1] - c[1]) < 0.04:
                return False
            created = self.create_shape("circle", {"c": points[0]["id"], "r": points[1]["id"]})
        elif d["tool"] == "polygon":
            if len(points) < 3:
                return False
            created = self.create_shape("polygon", {"pts": [p["id"] for p in points]})
        if not created:
            return False
        self.selection = [created["id"]]
        self.draft = None
        self.measure_picks = []
        self.tool = "select"
        self.update_tool_ui()
        self.refresh_all()
        self.render()
        self.schedule_save()
        self.toast("已创建" + TYPE_NAMES.get(created["type"], "对象"))
        return True

    def draft_add_point(self, world):
        d = self.draft
        if not d:
            return
        last = self.by_id(d["ids"][-1]) if d["ids"] else None
        if last:
            c = self.cur_of_point(last)
            if c and math.hypot(c[0] - world[0], c[1] - world[1]) * self.view["scale"] < 4:
                return
        if d["tool"] == "polygon" and len(d["ids"]) >= 3:
            f = self.cur_of_id(d["ids"][0])
            if f and math.hypot(f[0] - world[0], f[1] - world[1]) * self.view["scale"] < 16:
                self.finish_draft()
                return
        p = self.resolve_point(world)
        d["ids"].append(p["id"])
        if d["tool"] != "polygon" and len(d["ids"]) >= 2:
            self.finish_draft()
        else:
            self.update_status()
            self.render()
            self.schedule_save()

    def add_function_from_input(self, raw):
        try:
            expr = normalize_expr(raw)
            if not expr:
                raise ValueError("请输入函数表达式")
            compile_checked(expr)
            self.push_history()
            o = self.add_function(expr)
        except Exception as exc:  # noqa: BLE001
            self.toast(str(exc) or "表达式无效")
            return False
        self.selection = [o["id"]]
        self.tool = "select"
        self.update_tool_ui()
        self.refresh_all()
        self.render()
        self.schedule_save()
        self.toast("已绘制 f(x) = " + truncate(pretty_expr(o["expr"]), 20))
        return True

    def measure_pick(self, world):
        hit = self.hit_test(self.X(world[0]), self.Y(world[1]))
        if self.measure_mode == "area":
            if hit and hit["type"] == "polygon":
                self.push_history()
                m = self.create_shape("marea", {"poly": hit["id"]}, color="accent", role="measure")
                self.selection = [m["id"]]
                self.refresh_all()
                self.render()
                self.schedule_save()
                self.toast("面积 " + num(self.polygon_area(hit), 2))
            else:
                self.toast("面积测量：请点击一个多边形内部")
            return
        if not hit or hit["type"] != "point":
            self.toast("角度测量：请点三个点" if self.measure_mode == "angle" else "距离测量：请点两个点")
            return
        if hit["id"] in self.measure_picks:
            return
        self.measure_picks.append(hit["id"])
        need = 3 if self.measure_mode == "angle" else 2
        if len(self.measure_picks) >= need:
            self.push_history()
            pk = self.measure_picks
            if self.measure_mode == "angle":
                m = self.create_shape("mangle", {"a": pk[0], "b": pk[1], "c": pk[2]}, color="accent", role="measure")
            else:
                m = self.create_shape("mdist", {"a": pk[0], "b": pk[1]}, color="accent", role="measure")
            self.measure_picks = []
            self.selection = [m["id"]]
            self.refresh_all()
            self.render()
            self.schedule_save()
            self.toast("已添加角度测量" if self.measure_mode == "angle" else "已添加距离测量")
        else:
            self.update_status()
            self.render()

    # ---- 命中测试
    def hit_test(self, lx, ly):
        best, score = None, 1e9
        for o in reversed(self.objects):
            if o["hidden"] or o["aux"] or o["type"] != "point":
                continue
            p = self.cur_of_point(o)
            d = math.hypot(self.X(p[0]) - lx, self.Y(p[1]) - ly)
            if d <= 11 and d < score:
                best, score = o, d
        if best:
            return best
        for o in reversed(self.objects):
            if o["hidden"]:
                continue
            d = 1e9
            t = o["type"]
            if t in ("segment", "vector"):
                a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
                if a and b:
                    d = dist_seg(lx, ly, self.X(a[0]), self.Y(a[1]), self.X(b[0]), self.Y(b[1]))
            elif t == "line":
                a, b = self.cur_of_id(o.get("a")), self.cur_of_id(o.get("b"))
                if a and b:
                    d = dist_line(lx, ly, self.X(a[0]), self.Y(a[1]), self.X(b[0]), self.Y(b[1]))
            elif t == "circle":
                c = self.current_circle(o)
                if c:
                    d = abs(math.hypot(lx - self.X(c["c"][0]), ly - self.Y(c["c"][1])) - c["r"] * self.view["scale"])
            elif t == "polygon":
                pts = [self.screen_of(p) for p in self.poly_pts(o)]
                if len(pts) >= 3:
                    d = 0 if point_in_poly(lx, ly, pts) else dist_poly(lx, ly, pts)
            elif t == "function":
                d = self.dist_to_function(o, lx, ly)
            if d <= 8 and d < score:
                best, score = o, d
        return best

    def fn_x_range(self, o):
        inv = invert_m(o["m"])
        xs = [apply_m(inv, *p)[0] for p in (self.world_at(0, 0), self.world_at(self.w, 0), self.world_at(0, self.h), self.world_at(self.w, self.h))]
        return clamp(min(xs), -1e4, 1e4), clamp(max(xs), -1e4, 1e4)

    def dist_to_function(self, o, sx, sy):
        best = 1e9
        x0, x1 = self.fn_x_range(o)
        prev = None
        n = 180
        for i in range(n + 1):
            x = x0 + (x1 - x0) * i / n
            y = o["fn"](x)
            if not math.isfinite(y):
                prev = None
                continue
            s = self.screen_of(apply_m(o["m"], x, y))
            if prev:
                best = min(best, dist_seg(sx, sy, prev[0], prev[1], s[0], s[1]))
            prev = s
        return best
