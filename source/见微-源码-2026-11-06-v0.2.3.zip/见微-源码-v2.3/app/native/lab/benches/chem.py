"""自由工作台 · 化学（由 gewu/bench-chem.js 改写）：台面、容器、试剂、反应、检验。模型和数据在 chem_model.py。"""
from __future__ import annotations

import math
import random

from ...design.tokens import T, alpha, qc
from ...kit.bench import bench
from ...kit import state_graph
from ...kit.core import PI, TAU, clamp, fmt, lerp, rnd, sci
from ...kit.draw import D, Gradient
from .chem_model import (ART, COAT, COATN, DISP, DSV, EV, HD, HF, HM, IC, KD, MI, NIT, NM, PC, PD, PDN, PHP, PK, PM, PN, PRE, RG, RG_BY, SO, VT, css, eqm, hx,
                         ic_bottle, ic_dropper, ic_solid, mix3, ramp, swatch, tint, tint_oil)

DH = {"n:s": 57.3, "n:a": 56.1, "n:b": 52.2, "n:ab": 50.4}   # 中和热（kJ/mol）：弱酸、弱碱电离要吸热，放出的热量比强酸强碱少
BF = {"H2": 90, "O2": 260, "CO2": 110, "NO": 140}
FREE_GAS = {"H2": 0.0, "O2": 0.0, "CO2": 0.0, "NO": 0.0, "NH3": 0.0}


def _add(t, k, x):
    t[k] = t.get(k, 0) + x


def _hexc(c):
    return qc(css(c)).name()


def _eq(v):
    """平衡结果带缓存：总量和温度都没变（静置的容器）就不重算，这是工作台最耗时的一步。"""
    t = v["tot"]
    key = (tuple(sorted(t.items())), v["V"], round(v["T"], 1))
    if v.get("_ek") == key:
        return v["e"]
    e = v["e"] = eqm(t, v["V"], v["e"]["pH"] if v.get("e") else None, v["T"])
    v["_ek"] = key
    return e


@bench.reg(id="chem", subj="chem", short="化学", title="化学工作台", sub="试剂 · 器材 · 反应现象与方程式",
           desc="试管、烧杯、锥形瓶、酒精灯，三十多种试剂和十余种固体。滴加、倾倒、加热、萃取、检验气体，自动显示沉淀、气泡、颜色变化、温度、pH 和离子方程式。",
           art=ART)
def chem(B):
    L = B.L
    c = L.canvas()
    st = {"amt": 2.0, "speed": 1.0}
    objs: list = []
    cnt = {"tube": 0, "beaker": 0, "flask": 0}
    W = {"sel": None, "uid": 0, "S": 1.0, "TY": 0.0, "clock": 0.0, "ui": None, "tip": ""}
    records: list = []

    def vessels():
        return [o for o in objs if o["kind"] == "v"]

    def lamps():
        return [o for o in objs if o["kind"] == "lamp"]

    def layout():
        W["S"] = clamp(min(c.h / 460, c.w / 500), 0.62, 1.6)
        W["TY"] = c.h - 66 * W["S"]

    # ---- 对象
    def outer_w(v):
        return (VT[v["type"]].W + 3) * W["S"]

    def half_w(o):
        return max(52 * W["S"], outer_w(o["v"]) if o.get("v") else 0) if o["kind"] == "lamp" else outer_w(o)

    def base(v):
        return (W["TY"] - (84 if v["type"] == "tube" else 112) * W["S"] if v.get("lamp") else W["TY"]) - v["lift"]

    def top_y(v):
        return base(v) - VT[v["type"]].H * W["S"]

    def ok_x(o, x):
        hw = half_w(o)
        if x < hw + 6 or x > c.w - hw - 6:
            return False
        for u in objs:
            if u is o or u is o.get("v") or u is o.get("lamp") or (u["kind"] == "v" and u.get("lamp")):
                continue
            if abs(u["x"] - x) <= hw + half_w(u) + 8 * W["S"]:
                return False
        return True

    def near_free(o, x0):
        d = 0
        while d < c.w:
            if ok_x(o, x0 - d):
                return x0 - d
            if ok_x(o, x0 + d):
                return x0 + d
            d += 6
        return clamp(x0, 40, c.w - 40)

    def uid():
        W["uid"] += 1
        return W["uid"]

    def new_v(typ, x=None):
        if len(vessels()) >= 8:
            B.toast("台面上最多放 8 个容器")
            return None
        cnt[typ] += 1
        v = {"kind": "v", "id": uid(), "type": typ, "x": 0.0, "name": f"{VT[typ].n} {cnt[typ]}", "tot": {}, "V": 0.0, "T": 25.0, "solids": [], "pp": {}, "bub": [], "ev": set(),
             "gas": dict(FREE_GAS), "bacc": 0.0, "tacc": 0.0, "added": [], "ind": {}, "feed": [], "anims": [], "lamp": None, "lift": 0.0, "foam": 0.0, "last": "", "stir": 0.0,
             "test": None, "pour": None, "oil": 0.0, "ex": 0.0, "prevA": {}, "e": None}
        v["e"] = eqm(v["tot"], 0)
        objs.append(v)
        v["x"] = near_free(v, c.w / 2 if x is None else x)
        return v

    def new_lamp(x=None):
        if len(lamps()) >= 3:
            B.toast("最多放 3 盏酒精灯")
            return None
        o = {"kind": "lamp", "id": uid(), "x": 0.0, "lit": False, "v": None}
        objs.append(o)
        o["x"] = near_free(o, c.w / 2 if x is None else x)
        return o

    def select(o):
        if W["sel"] is not o:
            W["sel"] = o
            inspect()
        L.draw()

    def remove(o):
        if o["kind"] == "v" and o.get("lamp"):
            o["lamp"]["v"] = None
        if o["kind"] == "lamp" and o.get("v"):
            o["v"]["lamp"] = None
            o["v"]["x"] = near_free(o["v"], o["x"] + 80 * W["S"])
        objs.remove(o)
        if W["sel"] is o:
            W["sel"] = None
            inspect()

    def empty(v):
        v.update(tot={}, V=0.0, T=25.0, solids=[], pp={}, bub=[], added=[], ind={}, feed=[], foam=0.0, last="", oil=0.0, ex=0.0, prevA={})
        v["ev"].clear()
        v["gas"] = dict(FREE_GAS)
        v["e"] = eqm(v["tot"], 0)
        v["_ek"] = None

    def liq(v):
        return v["V"] + (v["oil"] or 0)   # 水层 + CCl₄ 层的总体积

    def lvl(v):
        return VT[v["type"]].lvl(liq(v))

    def aq_f(v, k):
        o = v["oil"] or 0
        if o <= 0 or not v["ex"]:
            return 1.0
        Dk = KD[k]
        return 1 - v["ex"] * Dk * o / (Dk * o + max(v["V"], 0.05))

    def note(v, f):
        if f in v["added"]:
            v["added"].remove(f)
        v["added"].append(f)
        if len(v["added"]) > 6:
            v["added"].pop(0)

    # ---- 记录与事件
    def render_log():
        lb = (W["ui"] or W.get("uil") or {}).get("log") if (W["ui"] or W.get("uil")) else None
        if lb is None:
            return
        try:
            if records:
                lb.setText("<br>".join(records[:8]))
            else:
                lb.setText("还没有发生反应。往容器里加试剂试试。")
        except RuntimeError:
            pass

    def say(v, eq_, ph):
        eqh = f"<b>{eq_}</b><br>" if eq_ else ""
        rec = f"{eqh}<span style='color:{T.muted}'>{v['name']}：</span>{ph}"
        records.insert(0, rec)
        del records[80:]
        B.log.add(rec)
        B.toast(rec, ms=4800)
        render_log()

    def ev(v, key):
        if key in v["ev"]:
            return
        v["ev"].add(key)
        d = EV.get(key)
        if d:
            def f(x):
                return x(v, v["e"]) if callable(x) else x
            say(v, f(d[0]), f(d[1]))

    def ppt_on(v, k, e):
        if k == "CuO":
            return
        if k == "Fe3" and (e["p"]["Fe2"] > 0.002 or "r:Fe(OH)2-air" in v["ev"]):
            return
        if k == "CaCO3" and v["T"] > 60 and "CO₂" in v["added"]:
            return say(v, "Ca(HCO₃)₂ =△= CaCO₃↓ + CO₂↑ + H₂O", "受热后溶液又变浑浊")
        if k == "CaCO3" and v["last"] == "CO2":
            return say(v, "CO₂ + Ca²⁺ + 2OH⁻ = CaCO₃↓ + H₂O", "澄清石灰水变浑浊")
        if k == "CaOH" and v["last"] == "CaO":
            return say(v, "", "生成的 Ca(OH)₂ 微溶，液体变浑浊（石灰乳）")
        if k == "CaOH" and v["T"] > 33 and v["last"] not in ("NaOH", "NaOHs", "Na", "Na2O2"):
            return say(v, "", "溶液变浑浊：Ca(OH)₂ 的溶解度随温度升高而减小")
        # [Al(OH)₄]⁻、[Zn(OH)₄]²⁻ 遇酸或 CO₂ 重新生成沉淀
        if k == "Al" and v["prevA"].get("Al", 0) > 0.002:
            co2 = v["last"] == "CO2"
            return say(v, "[Al(OH)₄]⁻ + CO₂ = Al(OH)₃↓ + HCO₃⁻" if co2 else "[Al(OH)₄]⁻ + H⁺ = Al(OH)₃↓ + H₂O",
                       "生成白色胶状沉淀" + ("（CO₂ 过量时沉淀也不溶解）" if co2 else "（酸过量时沉淀又会溶解）"))
        if k == "Zn" and v["prevA"].get("Zn", 0) > 0.002:
            return say(v, "[Zn(OH)₄]²⁻ + 2H⁺ = Zn(OH)₂↓ + 2H₂O", "生成白色沉淀")
        # Al³⁺、Fe³⁺ 与 HCO₃⁻、CO₃²⁻ 相互促进水解
        add_ = v["added"]
        ib = len(add_) - 1 - add_[::-1].index("NaHCO₃") if "NaHCO₃" in add_ else -1
        ic = len(add_) - 1 - add_[::-1].index("Na₂CO₃") if "Na₂CO₃" in add_ else -1
        if k in ("Al", "Fe3") and (ib >= 0 or ic >= 0) and "dh" not in v["ev"]:
            v["ev"].add("dh")
            v["ev"].add("r:CO2")
            Mn, Pp = ("Al", "白色沉淀") if k == "Al" else ("Fe", "红褐色沉淀")
            return say(v, f"{Mn}³⁺ + 3HCO₃⁻ = {Mn}(OH)₃↓ + 3CO₂↑" if ib > ic else f"2{Mn}³⁺ + 3CO₃²⁻ + 3H₂O = 2{Mn}(OH)₃↓ + 3CO₂↑",
                       f"生成{Pp}，同时产生大量气泡：两种离子的水解相互促进" + ("（泡沫灭火器的原理）" if k == "Al" and ib > ic else ""))
        f = HF.get(k)
        if not f:
            return
        nh = v["last"] == "NH3" and len(f) > 1
        say(v, f[1 if nh else 0], (PDN.get(k) if nh else None) or PD[k])

    def ppt_off(v, k, e):
        if v["V"] < 0.05:
            return
        if k == "Fe2" and e["p"]["Fe3"] > 0.002:
            return
        if k == "Cu" and v["tot"].get("CuO", 0) > 0.002:
            return
        if k == "Al" and e["pH"] > 9:
            return say(v, "Al(OH)₃ + OH⁻ = [Al(OH)₄]⁻", "白色沉淀溶解：Al(OH)₃ 是两性氢氧化物（旧教材写作 Al(OH)₃ + OH⁻ = AlO₂⁻ + 2H₂O）")
        if k == "Cu" and e["cuN"] > 0.001:
            v["ev"].add("c:CuN")
            return say(v, "Cu(OH)₂ + 4NH₃ = [Cu(NH₃)₄]²⁺ + 2OH⁻", "蓝色沉淀溶解，得到深蓝色溶液")
        if k == "Ag" and e["agN"] > 0.001:
            return say(v, "AgOH + 2NH₃·H₂O = [Ag(NH₃)₂]⁺ + OH⁻ + 2H₂O", "沉淀恰好溶解，得到银氨溶液")
        if k == "Zn" and e["znN"] > 0.001:
            return say(v, "Zn(OH)₂ + 4NH₃ = [Zn(NH₃)₄]²⁺ + 2OH⁻", "白色沉淀溶解")
        if k == "Zn" and e["znO"] > 0.001 and e["pH"] > 9:
            return say(v, "Zn(OH)₂ + 2OH⁻ = [Zn(OH)₄]²⁻", "白色沉淀溶解：Zn(OH)₂ 也是两性氢氧化物")
        if k == "CaOH":
            return say(v, "", "浑浊消失：Ca(OH)₂ 溶解")
        if k == "CaCO3" and v["last"] == "CO2":
            return say(v, "CaCO₃ + CO₂ + H₂O = Ca(HCO₃)₂", "浑浊消失，溶液重新变澄清")
        if HD.get(k) and e["pH"] < 7:
            return say(v, HD[k], "沉淀溶解，产生气泡" if k.endswith("CO3") else "沉淀溶解")
        say(v, "", PN[k] + " 沉淀溶解")

    def indicators(v, e):
        t, s = v["tot"], v["ind"]
        if v["V"] < 0.05:
            return
        pH = e["pH"]
        if t.get("phth", 0) > 0.05:
            n = "r" if pH > 9 else "n" if pH < 8.2 else s.get("phth")
            if n != s.get("phth"):
                if n == "r":
                    say(v, "", "酚酞变红：溶液呈碱性（pH > 8.2）")
                elif s.get("phth") == "r":
                    say(v, "", "红色褪去：溶液不再呈碱性")
                s["phth"] = n
        if t.get("lit", 0) > 0.05:
            n = "r" if pH < 5 else "b" if pH > 8 else "p"
            if n != s.get("lit"):
                if n == "r":
                    say(v, "", "石蕊变红：溶液呈酸性")
                elif n == "b":
                    say(v, "", "石蕊变蓝：溶液呈碱性")
                elif s.get("lit"):
                    say(v, "", "石蕊呈紫色：溶液接近中性")
                s["lit"] = n
        if t.get("mo", 0) > 0.05:
            n = "r" if pH < 3.1 else "y" if pH > 4.4 else "o"
            if n != s.get("mo"):
                say(v, "", "甲基橙变红（pH < 3.1）" if n == "r" else "甲基橙呈黄色（pH > 4.4）" if n == "y" else "甲基橙呈橙色（pH 3.1~4.4）")
                s["mo"] = n

    def flag(v, key, on, off):
        if on:
            ev(v, key)
        elif off:
            v["ev"].discard(key)

    # ---- 加入、混合与倾倒
    def heat_cap(v):
        return v["V"] * 4.18 + (v["oil"] or 0) * 1.35 + VT[v["type"]].glass

    def acid_base(e, V):
        return e["h"] * V + e["hac"], e["oh"] * V + e["nh3"]

    def mix(v, tt, mL, Tin):
        V0 = v["V"]
        e0, er = eqm(v["tot"], V0, None, v["T"]), eqm(tt, mL, None, Tin)
        a0, b0 = acid_base(e0, V0) if V0 > 0 else (0, 0)
        ar, br = acid_base(er, mL)
        C0, Cr = heat_cap(v), mL * 4.18
        for k, x in tt.items():
            _add(v["tot"], k, x)
        v["T"] = (C0 * v["T"] + Cr * Tin) / (C0 + Cr)
        v["V"] += mL
        e1 = v["e"] = eqm(v["tot"], v["V"], None, v["T"])
        v["_ek"] = None
        a1, b1 = acid_base(e1, v["V"])
        nW = max(0, min(a0 + ar, b0 + br, (a0 + ar + b0 + br - a1 - b1) / 2))
        if nW < 0.03:
            return None
        wa = (e0["hac"] if V0 > 0 else 0) + er["hac"] > (e0["h"] * V0 if V0 > 0 else 0) + er["h"] * mL
        wb = (e0["nh3"] if V0 > 0 else 0) + er["nh3"] > (e0["oh"] * V0 if V0 > 0 else 0) + er["oh"] * mL
        k = "n:ab" if wa and wb else "n:a" if wa else "n:b" if wb else "n:s"
        dT = DH[k] * nW / heat_cap(v)
        v["T"] += dT
        return {"dT": dT, "k": k}

    def neutral(v, r):
        if not r or r["dT"] < 0.3:   # 例如向 Na₂CO₃ 溶液中加酸：中和的只是少量 OH⁻，不单独提示
            return
        if r["k"] not in v["ev"]:
            v["ev"].add(r["k"])
            say(v, EV[r["k"]][0], f"酸碱中和，放出热量，温度升高 {fmt(r['dT'], 1)} °C" + ("" if r["k"] == "n:s" else "（有弱酸或弱碱参加，电离要吸热，中和放出的热量比强酸与强碱少）"))
        elif r["dT"] >= 0.5:
            B.toast(f"{v['name']}：中和放热，温度升高 {fmt(r['dT'], 1)} °C")

    def queued(v):
        return sum(a.get("mL", 0) for a in v["anims"])

    def add_reagent(v, r):
        if r["id"] == "CO2":
            if v["V"] + queued(v) < 0.5:
                B.toast("容器里没有水溶液，CO₂ 无处吸收")
                return

            def go():
                v["feed"].append({"k": "C", "rate": 0.3, "left": 0.3})
                v["last"] = "CO2"
                note(v, "CO₂")
            v["anims"].append({"k": "gas", "t": 0.0, "go": go})
            return
        cap = VT[v["type"]].cap
        mL = 0.1 if r.get("drop") else st["amt"]
        if liq(v) + queued(v) + mL > cap + 1e-9:
            mL = cap - liq(v) - queued(v)
            if mL < 0.01:
                B.toast(f"{v['name']} 已经满了")
                return
            B.toast(f"{v['name']} 只能再装 {fmt(mL, 1)} mL")
        if r.get("oil"):
            def go_oil():
                first = not v["oil"]
                v["oil"] += mL
                v["T"] = (heat_cap(v) * v["T"] - mL * 1.35 * (v["T"] - 25)) / heat_cap(v)
                v["last"] = r["id"]
                note(v, r["f"])
                if first:
                    say(v, "", "CCl₄ 与水互不相溶，密度比水大，沉在下层。点「振荡 / 搅拌」让两层充分接触" if v["V"] > 0.3 else "CCl₄ 是无色油状液体，不溶于水")
            v["anims"].append({"k": "drip" if mL < 0.5 else "stream", "t": 0.0, "mL": mL, "col": swatch(r), "go": go_oil})
            return
        tt = {k: x * mL for k, x in r["a"].items()}

        def go():
            v["last"] = r["id"]
            note(v, r["f"])
            neutral(v, mix(v, tt, mL, 25))
        v["anims"].append({"k": "drip" if mL < 0.5 else "stream", "t": 0.0, "mL": mL, "col": swatch(r), "go": go})

    def add_solid(v, k):
        if len(v["solids"]) + sum(1 for a in v["anims"] if a["k"] == "solid") >= 4:
            B.toast("一个容器里最多放 4 块固体")
            return
        d = SO[k]
        s = {"k": k, "n": d["mm"], "n0": d["mm"], "coat": {}, "lx": rnd(-0.5, 0.5), "seed": rnd(0, 100), "vx": 0.0}

        def go():
            v["solids"].append(s)
            note(v, d["f"])
            v["last"] = k
            if k == "Na" and v["V"] < 0.3:
                B.toast("钠要放进水里才会反应")
        v["anims"].append({"k": "solid", "t": 0.0, "s": s, "go": go})

    def transfer(v, u, fr):
        Lq = liq(v)
        if Lq <= 1e-6 or fr <= 0:
            return True
        room_ = VT[u["type"]].cap - liq(u)
        mL = min(Lq * fr, room_)
        if mL <= 1e-6:
            return False
        k = mL / Lq
        Vw, Vo = v["V"] * k, (v["oil"] or 0) * k
        tt = {}
        for s in v["tot"]:
            tt[s] = v["tot"][s] * k
            v["tot"][s] -= tt[s]
        v["V"] -= Vw
        v["oil"] -= Vo
        if liq(v) < 1e-4:
            v["V"], v["oil"] = 0.0, 0.0
            for s in v["tot"]:
                v["tot"][s] = 0
        for a in list(v["added"]):
            note(u, a)
        if Vo > 0:
            u["ex"] = min(u["ex"], v["ex"]) if u["oil"] > 0 else v["ex"]
            u["oil"] += Vo
        u["last"] = v["last"]
        r = mix(u, tt, Vw, v["T"])
        v["e"] = eqm(v["tot"], v["V"], None, v["T"])
        v["_ek"] = None
        if r and v["pour"]:
            v["pour"]["dT"] = v["pour"].get("dT", 0) + r["dT"]
            v["pour"]["k"] = r["k"]
        else:
            neutral(u, r)
        return mL >= Lq * fr - 1e-6

    def start_pour(v, u):
        if liq(v) < 0.01:
            B.toast(f"{v['name']} 是空的")
            v["lift"] = 0.0
            v["x"] = near_free(v, v.get("homeX", v["x"]))
            return
        if v.get("lamp"):
            v["lamp"]["v"] = None
            v["lamp"] = None
        v["pour"] = {"to": u, "t": 0.0, "done": 0.0, "full": False}

    # ---- 反应
    def solid_pos(v, s, lv):
        hw = max(0, VT[v["type"]].hw(5) - 9)
        if s["k"] == "Na":
            return s["lx"] * hw, lv - 2.5 if lv > 3 else 3
        return s["lx"] * hw, 3

    def spawn(v, src):
        t = VT[v["type"]]
        lv = lvl(v)
        if lv < 3 or len(v["bub"]) > 180:
            return
        if isinstance(src, dict) and src.get("k"):
            x, y = solid_pos(v, src, lv)
            x += rnd(-4, 4)
            y += rnd(0, 5)
        elif src == "tube":
            x, y = t.hw(8) * 0.45, 7
        else:
            y = rnd(2, lv * 0.8) if src == "w" else rnd(1, 6)
            x = rnd(-1, 1) * max(0, t.hw(y) - 3)
        v["bub"].append({"x": x, "y": min(y, lv - 1), "r": rnd(1.2, 3), "vy": rnd(35, 80), "w": rnd(0, TAU)})

    def gas(v, k, n, src):
        v["gas"][k] += n
        v["bacc"] += n * BF[k]
        m = 0
        while v["bacc"] >= 1 and m < 8:
            m += 1
            v["bacc"] -= 1
            spawn(v, src)
        if v["bacc"] > 3:
            v["bacc"] = 3

    def react(v, h):
        t = v["tot"]
        e = _eq(v)
        V = max(v["V"], 0.05)
        wet = v["V"] > 0.3
        Tf = 2 ** ((v["T"] - 25) / 10)
        hac = e["hac"] / V
        acid = e["h"] * V + e["hac"]
        d = e["dis"]
        eh = e["h"]
        heat = 0.0
        co2src = None
        for f in v["feed"]:
            x = min(f["left"], f["rate"] * h)
            f["left"] -= x
            _add(t, f["k"], x)
        if v["feed"]:
            v["feed"] = [f for f in v["feed"] if f["left"] > 1e-7]
        if wet:
            for s in v["solids"]:
                if s["n"] <= 1e-6:
                    continue
                k_ = s["k"]
                A = SO[k_]["A"] * ((s["n"] / s["n0"]) ** 2) ** (1 / 3)
                if k_ == "Na":
                    x = min(s["n"], 1.2 * A * h)
                    s["n"] -= x
                    _add(t, "Na", x)
                    gas(v, "H2", x / 2, s)
                    heat += 184 * x
                    ev(v, "m:Na")
                    continue
                ds = DSV.get(k_)
                if ds:   # 溶解或与水反应的固体
                    x = min(s["n"], ds["r"] * A * h)
                    s["n"] -= x
                    for kk, q in ds["add"].items():
                        _add(t, kk, q * x)
                    heat += ds["H"] * x
                    if k_ == "Na2O2":   # 2Na₂O₂ + 2H₂O：部分先生成 H₂O₂
                        gas(v, "O2", 0.35 * x, s)
                        _add(t, "H2O2", 0.3 * x)
                    if x / h > 1e-3:
                        ev(v, ds["ev"])
                    continue
                if k_ == "CaCO3":
                    pas = (d.get("SO4") or 0) / V > 0.05
                    x = min(s["n"], 0.08 * (eh + 0.05 * hac) * A * Tf * (0.06 if pas else 1) * h, 0.3 * acid / 2)
                    if x > 0:
                        s["n"] -= x
                        _add(t, "Ca", x)
                        _add(t, "C", x)
                        heat += 15 * x
                        co2src = s
                        if x / h > 4e-3:
                            ev(v, "m:CaCO3-HAc" if hac > eh * 5 else "m:CaCO3")
                        if pas and x / h < 2e-3 and "m:CaCO3" in v["ev"]:
                            ev(v, "m:CaCO3-SO4")
                    continue
                if d["NO3"] / V > 0.3 and eh > 0.1 and k_ in NIT:   # 稀硝酸把金属氧化，放出 NO 而不是 H₂
                    ion, z, kk = NIT[k_]
                    x = min(s["n"], kk * eh * A * Tf * h, 0.3 * eh * V * 3 / (4 * z))
                    if x > 1e-9:
                        s["n"] -= x
                        _add(t, ion, x)
                        _add(t, "NO3", -z * x / 3)
                        gas(v, "NO", z * x / 3, s)
                        heat += 120 * x
                        if x / h > 5e-4:
                            ev(v, "x:" + k_)
                    continue
                km = {"Zn": 0.1, "Fe": 0.03, "Mg": 0.6, "Al": 0.05}.get(k_)
                if km:
                    z = 3 if k_ == "Al" else 2
                    cell = 4 if s["coat"].get("Cu", 0) + s["coat"].get("Ag", 0) > 0.02 else 1   # 析出的铜与原金属构成原电池
                    x = min(s["n"], km * cell * (eh + 0.05 * hac) * A * Tf * h, 0.3 * acid / z)
                    if x > 1e-9:
                        s["n"] -= x
                        _add(t, MI[k_], x)
                        gas(v, "H2", x * z / 2, s)
                        heat += HM[k_] * x
                        if x / h > 1e-3:
                            ev(v, f"m:{k_}-H")
                            if cell > 1:
                                ev(v, "g:cell")
                    if k_ == "Al" and e["oh"] > 0.01:
                        y = min(s["n"], 0.04 * e["oh"] * A * Tf * h, 0.3 * e["oh"] * V)
                        if y > 0:
                            s["n"] -= y
                            _add(t, "Al", y)
                            gas(v, "H2", 1.5 * y, s)
                            heat += 400 * y
                            if y / h > 1e-3:
                                ev(v, "m:Al-OH")
                for ion, nu, dep in DISP.get(k_, ()):
                    av = d["Cu"] + e["cuN"] if ion == "Cu" else d["Ag"] + e["agN"] if ion == "Ag" else d["Zn"] + e["znN"] if ion == "Zn" else d[ion]
                    if not (av > 1e-7) or (ion == "Fe2" and d["Fe3"] > 1e-5):   # Fe³⁺ 先被还原
                        continue
                    kr = 0.06 if ion in ("Fe2", "Zn") else 0.2
                    x = min(s["n"], kr * av / V * A * Tf * h / nu, 0.5 * av / nu)
                    if x <= 0:
                        continue
                    s["n"] -= x
                    _add(t, MI[k_], x)
                    _add(t, ion, -nu * x)
                    if dep:
                        s["coat"][dep] = s["coat"].get(dep, 0) + nu * x
                    else:
                        _add(t, "Fe2", nu * x)
                    heat += 60 * x
                    if x / h > 3e-4:
                        ev(v, f"d:{k_}-{ion}")
        hp = t.get("H2O2", 0)
        if hp > 1e-6 and wet:
            mn = next((s for s in v["solids"] if s["k"] == "MnO2"), None)
            fe = d["Fe3"] / V
            kc = (0.08 if mn else 0) + 3 * fe
            kk = (kc + 3e-4) * Tf
            x = min(hp, hp * kk * h)
            _add(t, "H2O2", -x)
            gas(v, "O2", x / 2, mn or "w")
            heat += 98 * x
            if x / h > 2e-3:
                ev(v, "h2o2-MnO2" if mn else "h2o2-Fe3" if kc > 3e-4 * Tf else "h2o2-heat")
        fr = min(1, 10 * h)
        if eh > 1e-3 and d["MnO4"] > 1e-8:
            x = min(d["MnO4"], d["Fe2"] / 5) * fr
            if x > 1e-9:
                _add(t, "MnO4", -x)
                _add(t, "Mn", x)
                _add(t, "Fe2", -5 * x)
                _add(t, "Fe3", 5 * x)
                ev(v, "r:MnO4-Fe2")
            y = min(t.get("MnO4", 0) / 2, t.get("H2O2", 0) / 5) * fr
            if y > 1e-9:
                _add(t, "MnO4", -2 * y)
                _add(t, "Mn", 2 * y)
                _add(t, "H2O2", -5 * y)
                gas(v, "O2", 5 * y, "w")
                ev(v, "r:MnO4-H2O2")
        if t.get("Cl2", 0) > 1e-8:
            x = min(t["Cl2"], d["I"] / 2) * fr
            if x > 1e-9:
                _add(t, "Cl2", -x)
                _add(t, "I", -2 * x)
                _add(t, "I2", x)
                _add(t, "Cl", 2 * x)
                ev(v, "r:Cl2-I")
            x = min(t["Cl2"], min(d["Fe2"], t.get("Fe2", 0)) / 2) * fr
            if x > 1e-9:
                _add(t, "Cl2", -x)
                _add(t, "Fe2", -2 * x)
                _add(t, "Fe3", 2 * x)
                _add(t, "Cl", 2 * x)
                ev(v, "r:Cl2-Fe2")
            x = min(t["Cl2"], (d.get("Br") or 0) / 2) * fr   # 还原性 I⁻ > Fe²⁺ > Br⁻
            if x > 1e-9 and not (d["I"] > 1e-6) and not (d["Fe2"] > 1e-6):
                _add(t, "Cl2", -x)
                _add(t, "Br", -2 * x)
                _add(t, "Br2", x)
                _add(t, "Cl", 2 * x)
                ev(v, "r:Cl2-Br")
            if t["Cl2"] / V > 2e-3:
                for k in ("phth", "lit", "mo"):
                    if t.get(k, 0) > 0.05:
                        t[k] *= math.exp(-0.5 * h)
                        ev(v, "r:bleach")
        if t.get("Br2", 0) > 1e-8:
            x = min(t["Br2"], d["I"] / 2) * fr
            if x > 1e-9:
                _add(t, "Br2", -x)
                _add(t, "I", -2 * x)
                _add(t, "I2", x)
                _add(t, "Br", 2 * x)
                ev(v, "r:Br2-I")
            x = min(t["Br2"], min(d["Fe2"], t.get("Fe2", 0)) / 2) * fr
            if x > 1e-9:
                _add(t, "Br2", -x)
                _add(t, "Fe2", -2 * x)
                _add(t, "Fe3", 2 * x)
                _add(t, "Br", 2 * x)
                ev(v, "r:Br2-Fe2")
        # H₂O₂ 在强碱性溶液中使酚酞褪色（Na₂O₂ 与水的实验）
        if t.get("H2O2", 0) / V > 4e-3 and e["pH"] > 11.5 and t.get("phth", 0) > 0.05 and wet:
            t["phth"] *= math.exp(-0.12 * h)
            if t["phth"] < 0.5:
                ev(v, "r:H2O2-phth")
        # 氨的挥发：受热时加快（铵盐与碱共热放出 NH₃）
        if e["nh3"] > 1e-6 and wet:
            x = e["nh3"] * 0.0015 * 2 ** ((v["T"] - 25) / 10) * h
            _add(t, "N", -x)
            v["gas"]["NH3"] += x
            if v["T"] > 50 and x / h > 1e-3:
                ev(v, "r:NH3")
        if d["NO3"] / V > 0.3 and eh > 0.1 and d["Fe2"] > 1e-7:
            x = d["Fe2"] * min(1, 1.5 * h) / 3
            _add(t, "Fe2", -3 * x)
            _add(t, "Fe3", 3 * x)
            _add(t, "NO3", -x)
            gas(v, "NO", x, "w")
            if x / h > 1e-4:
                ev(v, "r:Fe2-HNO3")
        fi = min(d["Fe3"], d["I"], t.get("I", 0)) * min(1, 1.5 * h) / 2
        if fi > 1e-9:
            _add(t, "Fe3", -2 * fi)
            _add(t, "Fe2", 2 * fi)
            _add(t, "I", -2 * fi)
            _add(t, "I2", fi)
            if fi / h > 1e-4:
                ev(v, "r:Fe3-I")
        if eh > 1e-2 and t.get("H2O2", 0) > 1e-7 and d["I"] > 1e-7:
            x = 0.3 * min(t["H2O2"], d["I"] / 2) * h
            _add(t, "H2O2", -x)
            _add(t, "I", -2 * x)
            _add(t, "I2", x)
            if x / h > 1e-4:
                ev(v, "r:H2O2-I")
        p = e["p"]
        if p["Fe2"] > 1e-6:
            x = p["Fe2"] * 0.05 * Tf * h
            _add(t, "Fe2", -x)
            _add(t, "Fe3", x)
            if p["Fe2"] > 0.004 and p["Fe3"] > 0.15 * p["Fe2"]:
                ev(v, "r:Fe(OH)2-air")
        if v["T"] > 75 and p["Cu"] > 1e-6:
            x = p["Cu"] * 0.3 * h
            _add(t, "Cu", -x)
            _add(t, "CuO", x)
            if p["Cu"] > 0.004:
                ev(v, "r:CuO")
        if t.get("CuO", 0) > 1e-7 and eh > 1e-3:
            x = min(t["CuO"], (0.3 * t["CuO"] + 0.01) * h, 0.3 * eh * V / 2)
            _add(t, "CuO", -x)
            _add(t, "Cu", x)
            if x / h > 1e-3:
                ev(v, "r:CuO-H")
        # CO₂ 逸出
        c0 = e["h2co3"] / V
        sat = 0.034 * clamp(1.4 - v["T"] / 60, 0.15, 1)
        xc = (c0 - sat) * V * min(1, 4 * h) if c0 > sat else c0 * V * 0.003 * Tf * h
        if v["T"] > 95:
            xc += c0 * V * 0.2 * h
        if xc > 0 and wet:
            _add(t, "C", -xc)
            gas(v, "CO2", xc, co2src or ("w" if c0 > sat else "b"))
            if (xc / h > 3e-3 and not co2src and v["last"] != "CO2" and not v["feed"]
                    and not ((t.get("Al", 0) > 0.01 or t.get("Fe3", 0) > 0.01) and any(a in ("NaHCO₃", "Na₂CO₃") for a in v["added"]))):
                ev(v, "r:CO2")
        # 温度
        C = heat_cap(v)
        v["T"] += heat / C
        if v.get("lamp") and v["lamp"]["lit"]:
            v["T"] += 60 * h / C
        v["T"] -= (v["T"] - 25) * 0.004 * h * (2 if v["type"] == "tube" else 1)
        if v["T"] > 100 and v["V"] > 0:
            ex = (v["T"] - 100) * C
            v["T"] = 100.0
            v["V"] = max(0.0, v["V"] - ex / 2260)
            if v["V"] > 0:
                ev(v, "r:boil")
        if v["T"] > 300:
            v["T"] = 300.0
        if v["oil"] > 0 and v["T"] > 76:
            v["oil"] = max(0.0, v["oil"] - 0.02 * (v["T"] - 76) * h)
            if "w:CCl4" not in v["ev"]:
                v["ev"].add("w:CCl4")
                B.toast(f"{v['name']}：CCl₄ 沸点约 77 °C，受热挥发（蒸气有毒，实验中不要加热）", ms=5000)
        for k in t:
            if t[k] < 0:
                t[k] = 0

    def after(v, sd, dt):
        e = _eq(v)
        t = v["tot"]
        V = max(v["V"], 0.05)
        d = e["dis"]
        # 萃取：振荡时卤素单质很快在两层间达到分配平衡，静置时很慢
        if v["oil"] > 0 and v["V"] > 0.1:
            v["ex"] += (1 - v["ex"]) * (1 - math.exp(-(2.5 if v["stir"] > 0 else 0.01) * dt))
            if v["ex"] > 0.85 and v["stir"] <= 0:
                if t.get("I2", 0) > 2e-4:
                    ev(v, "k:I2")
                if t.get("Br2", 0) > 2e-4:
                    ev(v, "k:Br2")
        # 向 Na₂CO₃ 溶液中逐滴加酸：先生成 HCO₃⁻
        if ("Na₂CO₃" in v["added"] and v["last"] in ("HCl", "H2SO4", "HNO3", "HAc") and e["hco3"] > 0.6 * (e["hco3"] + e["co3"] + e["h2co3"])
                and e["hco3"] > 0.05 and "r:CO2" not in v["ev"]):
            ev(v, "r:CO3-H1")
        decay = math.exp(-sd / 5)
        pp = v["pp"]
        for k in PK:
            a = t.get("CuO", 0) if k == "CuO" else e["p"].get(k, 0)
            o = pp.get(k)
            if o is None:
                if a <= 0:
                    continue
                o = pp[k] = {"amt": 0.0, "sus": 0.0}
            if a > o["amt"]:
                o["sus"] += a - o["amt"]
            else:
                o["sus"] = o["sus"] * a / o["amt"] if o["amt"] > 0 else 0.0
            o["amt"] = a
            o["sus"] = min(o["sus"] * decay, a)
            if a > 0.004 and "p:" + k not in v["ev"]:
                v["ev"].add("p:" + k)
                ppt_on(v, k, e)
            elif a < 0.002 and "p:" + k in v["ev"]:
                v["ev"].discard("p:" + k)
                ppt_off(v, k, e)
        v["prevA"] = {"Al": e["alO"], "Zn": e["znO"]}
        fs = min(d["Fe3"], d["SCN"]) / V
        flag(v, "c:FeSCN", fs > 3e-4, fs < 1e-4)
        i2v = t.get("I2", 0) / V
        flag(v, "c:starch", t.get("starch", 0) > 0.05 and i2v > 3e-5, i2v < 1e-5)
        flag(v, "c:CuN", e["cuN"] / V > 5e-3 and not (e["p"]["Cu"] > 0.004), e["cuN"] / V < 1e-3)
        if v["T"] < 95:
            v["ev"].discard("r:boil")
        indicators(v, e)
        kg = math.exp(-dt / 12)
        for k in v["gas"]:
            v["gas"][k] *= kg
        # 气泡与泡沫（按真实时间）
        lv = lvl(v)
        if v["feed"]:
            v["tacc"] += dt * 30
            while v["tacc"] > 1:
                v["tacc"] -= 1
                spawn(v, "tube")
        if v["T"] > 99 and v["V"] > 0.3 and v.get("lamp") and v["lamp"]["lit"]:
            v["tacc"] += dt * 26
            while v["tacc"] > 1:
                v["tacc"] -= 1
                spawn(v, "b")
        pop = 0
        if v["bub"]:
            for b in v["bub"]:
                b["y"] += b["vy"] * dt
                b["w"] += dt * 6
                b["x"] += math.sin(b["w"]) * 0.3
                if b["y"] >= lv - 1:
                    pop += 1
            v["bub"] = [b for b in v["bub"] if b["y"] < lv - 1]
        v["foam"] = min(1, v["foam"] * math.exp(-dt * 1.5) + pop * 0.015)
        hw = max(1, VT[v["type"]].hw(max(lv, 5)) - 9)
        for s in v["solids"]:
            if s["k"] == "Na" and s["n"] > 1e-4 and v["V"] > 0.3:
                s["vx"] += rnd(-1, 1) * 260 * dt
                s["vx"] *= math.exp(-dt * 1.2)
                s["lx"] += s["vx"] * dt / hw
                if abs(s["lx"]) > 0.85:
                    s["lx"] = math.copysign(0.85, s["lx"])
                    s["vx"] *= -0.6
        v["solids"] = [s for s in v["solids"] if s["n"] > s["n0"] * 0.004 or any(x > 0.01 for x in s["coat"].values()) or s["k"] == "MnO2"]
        if v["stir"] > 0:
            v["stir"] -= dt
            for o in pp.values():
                o["sus"] = o["amt"]
        if v["test"]:
            v["test"]["t"] += dt
            if v["test"]["t"] > 2.2:
                v["test"] = None

    # ---- 检验与操作
    def test(v, k):
        g_ = v["gas"]
        th = 0.012
        if k == "burn":
            if g_["H2"] > th:
                res, msg = "pop", "气体被点燃，发出轻微的“噗”声：是 H₂（若听到尖锐的爆鸣声，说明 H₂ 中混有空气，点燃前必须验纯）"
            elif g_["O2"] > th:
                res, msg = "bright", "木条燃烧得更旺：气体是 O₂（助燃）"
            elif g_["CO2"] > th:
                res, msg = "out", "燃着的木条熄灭：气体不支持燃烧，可能是 CO₂（N₂ 等也能使木条熄灭，要用澄清石灰水确认）"
            else:
                res, msg = "none", "木条照常燃烧：容器口没有收集到明显的气体"
        elif k == "lime":
            res, msg = ("cloudy", "澄清石灰水变浑浊：气体是 CO₂（CO₂ + Ca(OH)₂ = CaCO₃↓ + H₂O）") if g_["CO2"] > th else ("clear", "澄清石灰水没有变浑浊：容器口没有 CO₂")
        elif k == "litmus":
            res, msg = ("blue", "湿润的红色石蕊试纸变蓝：气体是 NH₃（NH₃ + H₂O ⇌ NH₃·H₂O，溶液显碱性）") if g_["NH3"] > 0.004 else ("red", "湿润的红色石蕊试纸不变色：没有检出 NH₃")
        else:
            res, msg = ("relight", "带火星的木条复燃：气体是 O₂") if g_["O2"] > th else ("ember", "木条没有复燃")
        v["test"] = {"k": k, "t": 0.0, "res": res}
        say(v, "", msg)

    def on_lamp(v):
        lp = next((l_ for l_ in lamps() if not l_["v"]), None)
        if not lp:
            B.toast("酒精灯上已经有容器了" if lamps() else "先从左侧添加一盏酒精灯")
            return
        if v.get("lamp"):
            return
        v["lamp"] = lp
        lp["v"] = v
        v["x"] = lp["x"]
        v["lift"] = 0.0
        inspect()

    def toggle_lamp(l_):
        l_["lit"] = not l_["lit"]
        B.toast("点燃酒精灯（用火柴点燃，不能用另一盏酒精灯引燃）" if l_["lit"] else "用灯帽盖灭酒精灯")
        sel = W["sel"]
        if sel is l_ or (sel and sel.get("lamp") is l_):
            inspect()

    # ---- 绘制
    def pcol(k, v):
        if k == "Fe2":
            a = v["pp"]["Fe2"]["amt"] if "Fe2" in v["pp"] else 0
            b = v["pp"]["Fe3"]["amt"] if "Fe3" in v["pp"] else 0
            return mix3(hx(PC["Fe2"]), (0.43, 0.5, 0.38), clamp(b / (a + b + 1e-9) * 3, 0, 1))
        return hx(PC[k])

    def mixc(lst):
        w = 0.0
        r = [0.0, 0.0, 0.0]
        for col, k in lst:
            w += k
            for i in range(3):
                r[i] += col[i] * k
        return tuple(x / w for x in r) if w else (1.0, 1.0, 1.0)

    def room_base():
        g = c.g
        S, TY = W["S"], W["TY"]
        wall = Gradient("linear", (0, 0, 0, TY), [(0, T.stage), (1, "#141c19" if T.dark else "#eef2f0")])
        D.rect(g, 0, 0, c.w, TY, wall)
        tile = 48 * S
        y, r = TY - tile, 0
        while y > 0:
            D.line(g, 0, y, c.w, y, T.grid, 1)
            x = (r % 2) * tile / 2
            while x < c.w:
                D.line(g, x, y, x, y + tile, T.grid, 1)
                x += tile
            y -= tile
            r += 1
        wood = ("#3c322a", "#221c17") if T.dark else ("#e8dbc2", "#c9b48d")
        D.rect(g, 0, TY, c.w, c.h - TY, Gradient("linear", (0, TY, 0, c.h), [(0, wood[0]), (1, wood[1])]))
        g.stroke_style, g.line_width = alpha("#000000" if T.dark else "#8c7651", 0.08), 1
        for i in range(1, 5):
            y = TY + (c.h - TY) * i / 5
            g.begin_path()
            g.move_to(0, y)
            g.bezier_to(c.w * 0.3, y + 3, c.w * 0.7, y - 3, c.w, y)
            g.stroke()
        D.line(g, 0, TY + 0.5, c.w, TY + 0.5, "#5d4e40" if T.dark else "#f6ecd9", 2)
        D.line(g, 0, TY + 2.5, c.w, TY + 2.5, alpha("#000000", 0.35 if T.dark else 0.08), 2)

    def room(g):
        S, TY = W["S"], W["TY"]
        L.cached(("room", round(S, 4), round(TY, 2)), room_base)
        for l_ in lamps():
            if l_["lit"]:
                D.rect(g, l_["x"] - 120 * S, TY - 120 * S, 240 * S, 240 * S,
                       Gradient("radial", (l_["x"], TY, 120 * S), [(0, "rgba(255,170,70,.22)"), (1, "rgba(255,170,70,0)")]))
        g.fill_style = alpha("#000000", 0.35 if T.dark else 0.12)
        for o in objs:
            if o["kind"] == "v" and (o.get("lamp") or o["pour"] or o["lift"] > 2):
                continue
            g.begin_path()
            g.ellipse(o["x"], TY + 2 * S, (50 if o["kind"] == "lamp" else VT[o["type"]].W + 6) * S, 5 * S)
            g.fill()

    def draw_lamp(g, l_):
        S, TY = W["S"], W["TY"]
        x, s = l_["x"], S
        ty = TY - 112 * s
        metal = "#8a949c" if T.dark else "#5b636a"
        if l_["v"] and l_["v"]["type"] == "tube":   # 试管直接在外焰上加热，用试管夹夹持
            hy = base(l_["v"]) - VT["tube"].H * s * 0.78
            g.line_cap = "round"
            D.line(g, x + 14 * s, hy, x + 120 * s, hy + 26 * s, "#a87a45", 6 * s)
            D.line(g, x + 14 * s, hy - 4 * s, x + 60 * s, hy + 6 * s, "#8c6236", 2 * s)
            g.line_cap = "butt"
            D.rect(g, x - 16 * s, hy - 5 * s, 30 * s, 10 * s, None, "#8c6236", 2 * s)
        else:
            g.line_cap = "round"
            D.line(g, x - 40 * s, ty, x - 50 * s, TY, metal, 3 * s)
            D.line(g, x + 40 * s, ty, x + 50 * s, TY, metal, 3 * s)
            D.line(g, x + 3 * s, ty, x + 6 * s, TY - 4 * s, alpha(metal, 0.45), 2.4 * s)
            D.line(g, x - 46 * s, ty, x + 46 * s, ty, metal, 3 * s)
            D.rect(g, x - 44 * s, ty - 4 * s, 88 * s, 4 * s, "#59605f" if T.dark else "#a7aba6")   # 陶土网
            mesh = alpha("#c9cfcc" if T.dark else "#ffffff", 0.35)
            for i in range(-40, 41, 6):
                D.line(g, x + i * s, ty - 4 * s, x + i * s, ty, mesh, 1)
            g.line_cap = "butt"
        by, bw, bh = TY, 27 * s, 40 * s

        def body():
            g.begin_path()
            g.move_to(x - bw, by)
            g.line_to(x - bw, by - bh * 0.45)
            g.quad_to(x - bw, by - bh, x - 8 * s, by - bh)
            g.line_to(x + 8 * s, by - bh)
            g.quad_to(x + bw, by - bh, x + bw, by - bh * 0.45)
            g.line_to(x + bw, by)
            g.close_path()
        body()
        g.fill_style = "rgba(180,210,230,.08)" if T.dark else "rgba(200,225,240,.35)"
        g.fill()
        g.save()
        g.clip_path()
        D.rect(g, x - bw, by - bh * 0.5, 2 * bw, bh, "rgba(120,170,220,.28)" if T.dark else "rgba(110,160,210,.3)")
        g.restore()
        body()
        g.stroke_style, g.line_width = alpha(T.fg, 0.5), 1.6
        g.stroke()
        D.rect(g, x - 7 * s, by - bh - 8 * s, 14 * s, 8 * s, "#7b8288" if T.dark else "#8f979d")
        D.rect(g, x - 1.6 * s, by - bh - 15 * s, 3.2 * s, 7 * s, "#3b302a")
        if l_["lit"]:
            clock = W["clock"]
            f = 1 + 0.08 * math.sin(clock * 17) + 0.05 * math.sin(clock * 29)
            fy, fh, fw = by - bh - 14 * s, 34 * s * f, 9 * s
            D.rect(g, x - 60 * s, fy - fh - 50 * s, 120 * s, 120 * s,
                   Gradient("radial", (x, fy - fh * 0.4, 60 * s), [(0, "rgba(255,170,60,.28)"), (1, "rgba(255,170,60,0)")]))
            for w, hh, col in ((fw, fh, "rgba(255,140,40,.85)"), (fw * 0.62, fh * 0.72, "rgba(255,214,90,.95)"), (fw * 0.3, fh * 0.32, "rgba(110,150,255,.8)")):
                g.begin_path()
                g.move_to(x, fy - hh)
                g.bezier_to(x + w * 1.1, fy - hh * 0.45, x + w, fy, x, fy)
                g.bezier_to(x - w, fy, x - w * 1.1, fy - hh * 0.45, x, fy - hh)
                g.fill_style = col
                g.fill()

    def draw_solid(g, v, s, lv):
        d = SO[s["k"]]
        f = (max(s["n"], 0) / s["n0"]) ** (1 / 3)
        x, y = solid_pos(v, s, lv)
        cs = sorted(s["coat"].items(), key=lambda p: -p[1])
        ctot = sum(p[1] for p in cs)
        ca = min(0.9, ctot * 1.2)
        cc = COAT[cs[0][0]] if cs else "#000000"
        k = s["k"]

        def blob(r, fill, cy):
            pts = []
            for i in range(9):
                a = i / 9 * TAU
                q = r * (0.8 + 0.22 * math.sin(s["seed"] + i * 2.3))
                pts.append((x + math.cos(a) * q, cy - math.sin(a) * q * 0.8))
            D.poly(g, pts, fill)

        def shape(fill, a):
            g.global_alpha = a
            if k == "Zn":
                blob(6 * f + 2, fill, -(y + 4 * f + 1))
            elif k == "CaCO3":
                blob(9 * f + 2.5, fill, -(y + 6 * f + 1))
            elif k == "CaO":
                blob(7 * f + 1.5, fill, -(y + 5 * f + 1))
            elif k == "NaOHs":
                for i in range(4):
                    D.circle(g, x + (i - 1.5) * 6 * f, -(y + 2.2 * f), 2.6 * f + 0.6, fill)
            elif k == "Na":
                D.circle(g, x, -y, 4.5 * f + 1.2, fill)
            elif k in ("MnO2", "Na2O2", "NH4NO3"):
                kk = 1 if k == "MnO2" else f
                w = (VT[v["type"]].hw(3) - 2) * (1 if k == "MnO2" else 0.35 + 0.65 * kk)
                pts = [(-w, 0)]
                for i in range(11):
                    pts.append((-w + 2 * w * i / 10, -(3 + 1.2 * math.sin(s["seed"] + i)) * kk * (1 + 1.6 * math.sin(PI * i / 10) * (0 if k == "MnO2" else 1))))
                pts.append((w, 0))
                D.poly(g, pts, fill)
            else:
                ln = min(VT[v["type"]].H * 0.5, 72) if k == "Fe" else 38 if k == "Cu" else 36 * f + 6 if k == "Mg" else 18 * f + 4
                lean = 1.38 if v["type"] == "tube" else 1.25 if k == "Cu" else 0.16
                wd = 3.6 if k == "Fe" else 4.5 if k == "Cu" else 2.2 if k == "Mg" else 3
                x2, y2 = x + math.cos(lean) * ln, -(y + math.sin(lean) * ln)
                g.line_cap = "round"
                D.line(g, x, -y - 1, x2, y2, fill, wd)
                g.line_cap = "butt"
                if k == "Fe":
                    D.line(g, x2 - 4, y2, x2 + 4, y2, fill, 3)
            g.global_alpha = 1
        shape(d["col"], 1)
        if ca > 0.02:
            shape(cc, ca)
        if k == "Na" and s["n"] > 1e-4 and v["V"] > 0.3:
            for _ in range(5):
                D.circle(g, x + rnd(-7, 7), -y - rnd(0, 3), rnd(0.8, 1.8), "rgba(255,255,255,.7)")

    def draw_vessel(g, v, X, Yb, ang):
        t = VT[v["type"]]
        Pf, H = t.p, t.H
        e = v["e"]
        lv = lvl(v)
        clock = W["clock"]
        g.save()
        g.translate(X, Yb)
        if ang:
            g.rotate(ang)
        g.scale(W["S"], W["S"])

        def path():
            g.begin_path()
            g.move_to(-Pf[-1][0], -H)
            for q in reversed(Pf):
                g.line_to(-q[0], -q[1])
            for q in Pf:
                g.line_to(q[0], -q[1])
        g.save()
        path()
        g.clip_path()
        D.rect(g, -t.W - 4, -H - 2, 2 * t.W + 8, H + 4, "rgba(160,200,225,.05)" if T.dark else "rgba(120,170,205,.07)")
        if lv > 0.4:
            fI, fB = aq_f(v, "I2"), aq_f(v, "Br2")
            tr = tint(v["tot"], v["V"], e, fI, fB)
            lc = (tr[0] * 0.66, tr[1] * 0.84, tr[2] * 0.97)
            a = min(0.92, 0.3 + 0.6 * (1 - (tr[0] + tr[1] + tr[2]) / 3))

            def fill_liq(col):
                if ang:
                    g.save()
                    g.rotate(-ang)
                    D.rect(g, -400, max(-lv, -H * math.cos(ang) - 8), 800, 800, col)
                    g.restore()
                else:
                    D.rect(g, -t.W - 3, -lv, 2 * t.W + 6, lv + 3, col)
            fill_liq(css(lc, a))
            if not ang and v["oil"] > 0.01:   # 下层 CCl₄
                lo = t.lvl(v["oil"])
                to = tint_oil(v["tot"].get("I2", 0) * (1 - fI), v["tot"].get("Br2", 0) * (1 - fB), v["oil"])
                oc = (to[0] * 0.7, to[1] * 0.78, to[2] * 0.9)
                D.rect(g, -t.W - 3, -lo, 2 * t.W + 6, lo + 3, css(oc, min(0.94, 0.38 + 0.6 * (1 - (to[0] + to[1] + to[2]) / 3))))
                if v["V"] > 0.1:
                    sw = t.hw(lo)
                    D.line(g, -sw, -lo, sw, -lo, "rgba(255,255,255,.4)", 1)
            sus = 0.0
            sl = []
            for k, o in v["pp"].items():
                if o["sus"] > 1e-5:
                    sus += o["sus"]
                    sl.append((pcol(k, v), o["sus"]))
            if sus > 1e-5:
                sc = mixc(sl)
                cs = sus / max(v["V"], 0.1)
                fill_liq(css(sc, min(0.86, 1 - math.exp(-cs * 25))))
                if not ang:   # 悬浮的颗粒
                    n = min(110, round(cs * 3000) + 6)
                    pc_ = css(tuple(x * 0.62 for x in sc), 0.6)

                    def fr(q):
                        return q - math.floor(q)
                    for i in range(n):
                        y = ((fr(math.sin(i * 78.233 + v["id"]) * 12345.678) * lv - clock * 2.5 * (1 + i % 3)) % lv + lv) % lv
                        x = (fr(math.sin(i * 12.9898 + v["id"]) * 43758.5453) * 2 - 1) * max(0, t.hw(y) - 2)
                        D.rect(g, x - 0.8, -y - 0.8, 1.6, 1.6, pc_)
            if not ang:
                sw = t.hw(lv)
                D.line(g, -sw, -lv, sw, -lv, "rgba(255,255,255,.55)", 1.2)
                if v["foam"] > 0.05:
                    i = -sw + 3
                    while i < sw - 2:
                        D.circle(g, i + math.sin(i * 7.3) * 1.2, -lv - 1, 1.2 + v["foam"] * 1.6 * (0.6 + 0.4 * math.sin(i * 3.1 + clock * 3)), "rgba(255,255,255,.5)")
                        i += 4
        # 沉在底部的沉淀
        st_ = 0.0
        sl2 = []
        for k, o in v["pp"].items():
            s = o["amt"] - o["sus"]
            if s > 1e-5:
                st_ += s
                sl2.append((pcol(k, v), s))
        if st_ > 2e-4:
            w = t.hw(3) + 2
            hg = min(max(lv * 0.7, 3) if lv > 2 else 24, 1.5 + 9 * math.sqrt(st_) * 14 / max(14, t.hw(3)))
            col = mixc(sl2)
            pts = [(-w, 2)] + [(-w + 2 * w * i / 14, -hg * (0.78 + 0.22 * math.sin(i * 1.7 + v["id"]))) for i in range(15)] + [(w, 2)]
            D.poly(g, pts, css(col, 0.95), css(tuple(x * 0.62 for x in col), 0.9), 1)
            dot = css(tuple(x * 0.78 for x in col), 0.9)
            for i in range(18):
                px = -w + (math.sin(i * 12.9898 + v["id"]) * 0.5 + 0.5) * 2 * w
                py = -(math.sin(i * 78.233) * 0.5 + 0.5) * hg * 0.8
                D.rect(g, px, py, 1.4, 1.4, dot)
        for s in v["solids"]:
            draw_solid(g, v, s, lv)
        for b in v["bub"]:
            D.circle(g, b["x"], -b["y"], b["r"], "rgba(255,255,255,.18)", "rgba(255,255,255,.75)", 0.8)
        g.restore()
        # 玻璃
        if W["sel"] is v:   # 选中：一圈柔和的光（宽描边叠一层代替 shadowBlur）
            path()
            g.stroke_style, g.line_width = alpha(T.accent, 0.22), 8
            g.stroke()
            path()
            g.stroke_style, g.line_width = alpha(T.accent, 0.9), 3.2
            g.stroke()
        glass = "rgba(210,228,238,.62)" if T.dark else "rgba(60,80,92,.62)"
        path()
        g.stroke_style, g.line_width = glass, 2
        g.stroke()
        rim = Pf[-1][0]
        D.line(g, -rim - 3, -H, rim + 3, -H, "rgba(210,228,238,.7)" if T.dark else "rgba(60,80,92,.7)", 2.4)
        hl = []
        y = H * 0.16
        while y <= H * 0.84:
            hl.append((-t.hw(y) + 5, -y))
            y += 3
        D.poly(g, hl, None, "rgba(255,255,255,.35)", 2.4, close=False)
        if v["type"] == "beaker":
            g.begin_path()
            g.move_to(-rim - 3, -H)
            g.quad_to(-rim - 9, -H - 2, -rim - 10, -H - 6)
            g.stroke_style, g.line_width = glass, 2
            g.stroke()
            for m in (50, 100, 150):
                y = t.lvl(m)
                D.line(g, rim - 14, -y, rim - 2, -y, alpha(T.fg, 0.45), 1)
                D.text(g, str(m), rim - 16, -y, alpha(T.fg, 0.5), size=8, align="right", mono=True)
        g.restore()

    def draw_anims(g, v):
        S = W["S"]
        clock = W["clock"]
        X = v["x"]
        top = top_y(v)
        surf = base(v) - lvl(v) * S
        for a in v["anims"]:
            if a["k"] == "drip":
                tip = top - 10 * S
                p = clamp(a["t"] / 0.45, 0, 1)
                D.rrect(g, X - 4 * S, tip - 44 * S, 8 * S, 12 * S, 3 * S, "#b54a3c")
                D.rect(g, X - 2.5 * S, tip - 32 * S, 5 * S, 30 * S, "rgba(200,220,235,.25)" if T.dark else "rgba(150,190,215,.35)", alpha(T.fg, 0.5), 1)
                if p < 1:
                    D.circle(g, X, lerp(tip, surf, p * p), 2.6 * S, a["col"])
            elif a["k"] == "stream":
                bx, by = X + 26 * S, top - 30 * S
                g.save()
                g.translate(bx, by)
                g.rotate(-2.1)
                D.rrect(g, -9 * S, -26 * S, 18 * S, 30 * S, 3 * S, "rgba(200,220,235,.2)" if T.dark else "rgba(255,255,255,.6)", alpha(T.fg, 0.5), 1.2)
                D.rect(g, -8 * S, -12 * S, 16 * S, 15 * S, a["col"])
                g.restore()
                if a["t"] < 0.55:
                    g.begin_path()
                    g.move_to(bx - 14 * S, by + 6 * S)
                    g.quad_to(X + 4 * S, by + 10 * S, X + 2 * S, surf)
                    g.stroke_style, g.line_width = a["col"], 3 * S
                    g.stroke()
            elif a["k"] == "solid":
                p = clamp(a["t"] / 0.5, 0, 1)
                y = lerp(top - 26 * S, base(v) - 6 * S, p * p)
                D.circle(g, X, y, 4 * S, SO[a["s"]["k"]]["col"], alpha(T.fg, 0.4), 1)
        if v["gas"]["NO"] > 0.003:   # NO 在容器口遇空气变成红棕色的 NO₂
            k = clamp(v["gas"]["NO"] * 25, 0.15, 1)
            for i in range(5):
                p = (clock * 0.35 + i / 5) % 1
                sx = X + math.sin(clock * 1.3 + i * 1.7) * 10 * S * p
                D.circle(g, sx, top - 4 * S - p * 50 * S, (5 + p * 12) * S, f"rgba(176,84,34,{(1 - p) * 0.5 * k:.3f})")
        if v["T"] > 70 and v["V"] > 0.05:   # 水蒸气
            k = clamp((v["T"] - 70) / 30, 0, 1)
            rgb = "220,228,235" if T.dark else "140,152,162"
            for i in range(4):
                p = (clock * 0.45 + i / 4) % 1
                sx = X + math.sin(clock * 1.7 + i * 2) * 8 * S * p
                D.circle(g, sx, top - 6 * S - p * 60 * S, (4 + p * 10) * S, f"rgba({rgb},{(1 - p) * 0.45 * k:.3f})")
        if v["feed"]:
            tx = X + VT[v["type"]].hw(8) * 0.45 * S
            D.line(g, tx, top - 40 * S, tx, base(v) - 7 * S, "rgba(210,228,238,.6)" if T.dark else "rgba(60,80,92,.55)", 3 * S)
            D.text(g, "CO₂", tx + 6 * S, top - 34 * S, T.muted, size=11)
        if v["stir"] > 0:
            sx = X + math.sin(clock * 9) * VT[v["type"]].hw(10) * 0.5 * S
            D.line(g, sx - 8 * S, top - 30 * S, sx, base(v) - 6 * S, "rgba(220,235,245,.75)" if T.dark else "rgba(80,100,112,.7)", 3 * S)
        q = v["test"]
        if q and q["k"] in ("lime", "litmus"):
            mx, my = X + 4 * S, top - 8 * S
            p = clamp((q["t"] - 0.3) / 0.9, 0, 1)
            if q["k"] == "lime":   # 蘸有澄清石灰水的玻璃片
                D.rect(g, mx - 26 * S, my - 3 * S, 52 * S, 4 * S, "rgba(200,225,240,.35)" if T.dark else "rgba(170,205,225,.55)", alpha(T.fg, 0.45), 1)
                w = p if q["res"] == "cloudy" else 0
                g.begin_path()
                g.ellipse(mx, my + 2.5 * S, 9 * S, 3 * S)
                g.fill_style = f"rgba({int(lerp(190, 248, w))},{int(lerp(220, 248, w))},{int(lerp(240, 244, w))},{0.55 + 0.4 * w:.3f})"
                g.fill()
            else:   # 湿润的红色石蕊试纸
                c0, c1 = (214, 72, 82), (62, 98, 214)
                w = p if q["res"] == "blue" else 0
                D.line(g, mx + 30 * S, my - 34 * S, mx + 4 * S, my - 2 * S, "#b88a52", 2.4 * S)
                g.save()
                g.translate(mx, my)
                g.rotate(-0.9)
                D.rect(g, -4 * S, -2 * S, 22 * S, 7 * S, f"rgba({int(lerp(c0[0], c1[0], w))},{int(lerp(c0[1], c1[1], w))},{int(lerp(c0[2], c1[2], w))},1)")
                g.restore()
        elif q:
            mx, my = X + 6 * S, top - 4 * S
            ex, ey = mx + 70 * S, my - 46 * S
            g.line_cap = "round"
            D.line(g, ex, ey, mx, my, "#b88a52", 3.2 * S)
            g.line_cap = "butt"
            res, qt = q["res"], q["t"]
            lit = res in ("bright", "none") or (res == "relight" and qt > 0.5) or (res == "pop" and qt > 0.6)
            if res == "pop" and 0.25 < qt < 0.6:
                D.circle(g, mx, my, (qt - 0.25) * 120 * S, f"rgba(255,220,120,{0.6 - (qt - 0.25):.3f})")
            if lit:
                k = 1.8 if res == "bright" else 1.3 if res == "relight" else 1
                fh = 14 * S * k * (1 + 0.1 * math.sin(clock * 20))
                g.begin_path()
                g.move_to(mx, my - fh)
                g.quad_to(mx + 6 * S * k, my - fh * 0.3, mx, my + 2)
                g.quad_to(mx - 6 * S * k, my - fh * 0.3, mx, my - fh)
                g.fill_style = "rgba(255,160,50,.9)"
                g.fill()
            else:
                D.circle(g, mx, my, 2.4 * S, "#555555" if res == "out" else "#ff6a2a")
                if res == "out":
                    for i in range(4):
                        D.circle(g, mx + math.sin(qt * 3 + i) * 4 * S, my - (qt * 30 + i * 8) * S, 3 * S, "rgba(150,150,150,.3)")

    def pour_pose(v):   # 倾倒时源容器的位置与角度
        p = v["pour"]
        u = p["to"]
        S = W["S"]
        H = VT[v["type"]].H * S
        ang = (1 if u["x"] >= v.get("homeX", v["x"]) else -1) * 1.85 * clamp(p["t"] / 0.4, 0, 1) ** 0.7
        mx = u["x"] - math.copysign(1, ang or 1) * outer_w(u) * 0.35
        my = top_y(u) - 10 * S
        return mx - H * math.sin(ang), my + H * math.cos(ang), ang, mx, my

    def draw():
        layout()
        g = c.g
        c.clear()
        S, TY = W["S"], W["TY"]
        sel = W["sel"]
        room(g)
        for l_ in lamps():
            draw_lamp(g, l_)
        vs = sorted((v for v in vessels() if not v["pour"]), key=lambda v: v is sel)
        for v in vs:
            v["x"] = clamp(v["x"], outer_w(v) + 4, c.w - outer_w(v) - 4)
            draw_vessel(g, v, v["x"], base(v), 0)
            draw_anims(g, v)
        for v in vessels():
            if v["pour"]:
                qx, qy, ang, mx, my = pour_pose(v)
                draw_vessel(g, v, qx, qy, ang)
                if 0.35 < v["pour"]["t"] < 1.15 and liq(v) > 0.01:
                    u = v["pour"]["to"]
                    sy = base(u) - lvl(u) * S
                    tr = tint(v["tot"], v["V"], v["e"])
                    D.line(g, mx, my, mx + (u["x"] - mx) * 0.2, sy, css((tr[0] * 0.66, tr[1] * 0.84, tr[2] * 0.97), 0.85), 4 * S)
        for v in vessels():
            if v["pour"] or v["lift"] > 2:
                continue
            ly = TY + 17 * S
            D.text(g, v["name"], v["x"], ly, T.accent if sel is v else T.fg, size=12.5 * S, align="center", bold=True)
            sub = " + ".join(v["added"][-3:]) or "空"
            D.text(g, "…" + sub[-21:] if len(sub) > 22 else sub, v["x"], ly + 16 * S, T.muted, size=11 * S, align="center")
            D.text(g, f"{fmt(liq(v), 1)} mL · {fmt(v['T'], 0)} °C", v["x"], ly + 31 * S, T.bad if v["T"] > 40 else T.muted, size=10.5 * S, align="center", mono=True)
        for l_ in lamps():
            if not l_["v"]:
                D.text(g, "酒精灯" + ("（燃着）" if l_["lit"] else ""), l_["x"], TY + 17 * S, T.accent if sel is l_ else T.muted, size=12 * S, align="center")
        if not vessels():
            D.text(g, "从左侧添加试管、烧杯或锥形瓶", c.w / 2, c.h * 0.42, T.muted, size=15, align="center")
    L.on_draw(draw)

    # ---- 交互
    def hit_obj(x, y):
        S, TY = W["S"], W["TY"]
        for o in reversed(objs):
            if o["kind"] == "v" and not o["pour"] and abs(x - o["x"]) < outer_w(o) + 6 and top_y(o) - 12 < y < base(o) + 6:
                return o
        for o in objs:
            if o["kind"] == "lamp" and abs(x - o["x"]) < 50 * S and TY - 118 * S < y < TY + 4:
                return o
        return None

    def vessel_at(x, y):
        S = W["S"]
        return next((v for v in vessels() if not v["pour"] and abs(x - v["x"]) < outer_w(v) + 22 * S and top_y(v) - 90 * S < y < base(v) + 40 * S), None)

    def settle(v):
        S = W["S"]
        tgt = next((u for u in vessels() if u is not v and not u["pour"] and abs(u["x"] - v["x"]) < (outer_w(u) + outer_w(v)) * 0.8
                    and v["lift"] > 25 * S and base(v) < top_y(u) + 36 * S), None)
        if tgt:
            start_pour(v, tgt)
            return
        v["lift"] = 0.0
        lp = next((l_ for l_ in lamps() if not l_["v"] and abs(l_["x"] - v["x"]) < 46 * S), None)
        if lp:
            v["lamp"] = lp
            lp["v"] = v
            v["x"] = lp["x"]
            inspect()
            return
        v["x"] = near_free(v, v["x"])

    def hit(x, y):
        o = hit_obj(x, y)
        return {"o": o, "ox": x - o["x"], "y0": y, "b0": base(o) if o["kind"] == "v" else 0, "moved": False} if o else None

    def down(_x, _y, h):
        if h:
            select(h["o"])

    def drag(h, x, y, _dx, _dy):
        o = h["o"]
        if o["kind"] == "v" and o["pour"]:
            return
        if not h["moved"]:
            h["moved"] = True
            if o["kind"] == "v":
                o["homeX"] = o["x"]
                if o.get("lamp"):
                    o["lamp"]["v"] = None
                    o["lamp"] = None
                    inspect()
        if o["kind"] == "v":
            o["x"] = clamp(x - h["ox"], 20, c.w - 20)
            o["lift"] = max(0.0, W["TY"] - (h["b0"] + y - h["y0"]))
        else:
            o["x"] = clamp(x - h["ox"], 40, c.w - 40)
            if o["v"]:
                o["v"]["x"] = o["x"]

    def up(h):
        if not h or not h["moved"]:
            return
        if h["o"]["kind"] == "v":
            settle(h["o"])
        else:
            h["o"]["x"] = near_free(h["o"], h["o"]["x"])
            if h["o"]["v"]:
                h["o"]["v"]["x"] = h["o"]["x"]

    def click(_x, _y, h):
        if not h:
            select(None)
        elif h["o"]["kind"] == "lamp":
            toggle_lamp(h["o"])
    L.interact(c, hit=hit, down=down, drag=drag, up=up, click=click)

    def on_key(k, _e):
        if k in ("Delete", "Backspace") and W["sel"]:
            remove(W["sel"])
            return True
        return False
    L.on_key(on_key)

    # ---- 示例实验：摆好容器和药品，提示下一步
    def scene(p):
        objs.clear()
        for k in cnt:
            cnt[k] = 0
        W["sel"] = None
        records.clear()
        B.log.clear()
        st["amt"] = float(p.get("amt", 2))
        st["speed"] = float(p.get("speed", 1))
        W["tip"] = p.get("tip", "")
        layout()
        n = len(p["v"])
        vs = []
        for i, d in enumerate(p["v"]):
            x = c.w * (i + 0.7) / (n + 0.4)
            if d.get("lamp"):
                new_lamp(x)
                continue
            v = new_v(d["t"], x)
            vs.append(v)
            for id_, mL in d.get("r") or []:
                r = RG_BY[id_]
                if r.get("oil"):
                    v["oil"] += mL
                    note(v, r["f"])
                    continue
                mix(v, {k: x_ * mL for k, x_ in r["a"].items()}, mL, 25)
                note(v, r["f"])
                v["last"] = id_
            for k in d.get("s") or []:
                v["solids"].append({"k": k, "n": SO[k]["mm"], "n0": SO[k]["mm"], "coat": {}, "lx": rnd(-0.4, 0.4), "seed": rnd(0, 100), "vx": 0.0})
                note(v, SO[k]["f"])
            v["e"] = eqm(v["tot"], v["V"])
            v["_ek"] = None
        if vs:
            W["sel"] = None
            select(vs[0])
        else:
            inspect()
        if W["tip"]:
            B.toast(f"<b>下一步</b><br>{W['tip']}", ms=9000)

    # ---- 检查器
    def inspect():
        B.clear_panel()
        W["ui"] = None
        W["uil"] = None
        if W["tip"]:
            L.group("实验提示")
            L.note(W["tip"])
        sel = W["sel"]
        ui = None
        if sel and sel["kind"] == "v":
            v = sel
            L.group(v["name"])
            ui = {"v": v, "m": L.out()}
            L.group("溶液中的主要粒子")
            ui["sp"] = L.out()
            L.group("沉淀与固体")
            ui["pp"] = L.out()
            L.group("检验与操作")
            L.button("燃着的木条", lambda _b: test(v, "burn"))
            L.button("带火星的木条", lambda _b: test(v, "glow"))
            L.button("澄清石灰水", lambda _b: test(v, "lime"))
            L.button("湿润的红色石蕊试纸", lambda _b: test(v, "litmus"))
            L.button("振荡 / 搅拌", lambda _b: v.__setitem__("stir", 1.2))
            if v.get("lamp"):
                L.button("熄灭酒精灯" if v["lamp"]["lit"] else "点燃酒精灯", lambda _b: toggle_lamp(v["lamp"]))
            else:
                L.button("放到酒精灯上", lambda _b: on_lamp(v))
            others = [u for u in vessels() if u is not v]
            if others:
                L.group("")
                s = L.select("倒入另一个容器（也可以直接把容器拖到另一个容器上方）", [[u["id"], u["name"]] for u in others], others[0]["id"], lambda _v: None)

                def pour(_b):
                    u = next((o for o in objs if str(o["id"]) == s.v), None)
                    if u:
                        v["homeX"] = v["x"]
                        start_pour(v, u)
                L.button("倒入", pour)
            L.button("清空", lambda _b: empty(v))
            L.button("移走", lambda _b: remove(v))
        elif sel and sel["kind"] == "lamp":
            lamp = sel
            L.group("酒精灯")
            L.note("点击酒精灯可以点燃或熄灭。试管可以用试管夹夹持，直接在外焰上加热；烧杯、锥形瓶要垫陶土网加热。水温最高到 100 °C 并逐渐蒸发。")
            L.button("熄灭" if lamp["lit"] else "点燃", lambda _b: toggle_lamp(lamp), True)
            L.button("移走", lambda _b: remove(lamp))
        else:
            L.group("使用方法")
            L.note("<b>选容器</b>：点击台面上的容器。<br><b>加药品</b>：点左侧的试剂加入选中的容器，或把试剂拖到任意容器上。<br>"
                   "<b>倾倒</b>：把一个容器拖到另一个容器上方后松开。<br><b>加热</b>：把容器拖到酒精灯上，点击酒精灯点燃。<br>选中后按 Delete 可移走。")
        L.group("每次加入的液体")
        L.seg("", [[0.1, "2 滴"], [1.0, "1 mL"], [2.0, "2 mL"], [5.0, "5 mL"], [20.0, "20 mL"]], st["amt"], lambda x: st.__setitem__("amt", float(x)))
        L.note("指示剂每次固定加 2 滴。")
        L.group("时间")
        L.seg("", [[1.0, "1×"], [5.0, "5×"], [20.0, "20×"]], st["speed"], lambda x: st.__setitem__("speed", float(x)))
        L.group("反应记录")
        lb = L.note("")
        L.panel_lay.addStretch(1)
        if ui is not None:
            ui["log"] = lb
            W["ui"] = ui
        else:
            W["uil"] = {"log": lb}
        render_log()
        refresh()

    def fc(x):
        return (fmt(x, 3) if x >= 0.01 else sci(x, 1)) + " mol/L"

    def refresh():
        ui = W["ui"]
        if not ui:
            return
        v = ui["v"]
        e, V, t = v["e"], v["V"], v["tot"]
        try:
            ui["m"].set([
                ["体积", f"水层 {fmt(V, 1)} + CCl₄ {fmt(v['oil'], 1)} mL" if v["oil"] > 0.01 else f"{fmt(V, 1)} / {VT[v['type']].cap} mL"],
                ["温度", f"{fmt(v['T'], 1)} °C"],
                ["pH 计", fmt(e["pH"], 2) if V > 0.05 else "—"],
                ["pH 试纸", f"<span style='color:{_hexc(ramp(PHP, e['pH']))}'>■</span> 约 {round(clamp(e['pH'], 0, 14))}"] if V > 0.05 else None,
            ])
            if V < 0.05:
                ui["sp"].set(f"<span style='color:{T.muted}'>{'只有四氯化碳，没有水溶液。' if v['oil'] > 0.01 else '容器里没有液体。'}</span>")
            else:
                rows = []

                def put(n, mm):
                    x = mm / V
                    if x > 1e-4:
                        rows.append((n, x))
                for k, n in NM.items():
                    put(n, e["dis"].get(k) or 0)
                if e["h"] > 1e-4:
                    rows.append(("H⁺", e["h"]))
                if e["oh"] > 1e-4:
                    rows.append(("OH⁻", e["oh"]))
                for n, x in (("[Cu(NH₃)₄]²⁺", e["cuN"]), ("[Ag(NH₃)₂]⁺", e["agN"]), ("[Zn(NH₃)₄]²⁺", e["znN"]), ("[Al(OH)₄]⁻", e["alO"]), ("[Zn(OH)₄]²⁻", e["znO"]),
                             ("NH₃·H₂O", e["nh3"]), ("NH₄⁺", e["nh4"]), ("CH₃COOH", e["hac"]), ("CH₃COO⁻", e["ac"]),
                             ("H₂CO₃", e["h2co3"]), ("HCO₃⁻", e["hco3"]), ("CO₃²⁻", e["co3"]),
                             ("H₂O₂", t.get("H2O2", 0)), ("I₂", t.get("I2", 0) * aq_f(v, "I2")), ("Br₂", t.get("Br2", 0) * aq_f(v, "Br2")), ("Cl₂", t.get("Cl2", 0))):
                    put(n, x)
                rows.sort(key=lambda r: -r[1])
                out = [[n, fc(x)] for n, x in rows[:12]]
                pH = e["pH"]
                ind = []
                if t.get("phth", 0) > 0.05:
                    ind.append("酚酞" + ("（红）" if pH > 9 else "（浅红）" if pH > 8.2 else "（无色）"))
                if t.get("lit", 0) > 0.05:
                    ind.append("石蕊" + ("（红）" if pH < 5 else "（蓝）" if pH > 8 else "（紫）"))
                if t.get("mo", 0) > 0.05:
                    ind.append("甲基橙" + ("（红）" if pH < 3.1 else "（黄）" if pH > 4.4 else "（橙）"))
                if t.get("starch", 0) > 0.05:
                    ind.append("淀粉" + ("（蓝）" if t.get("I2", 0) / V > 3e-5 else ""))
                if ind:
                    out.append(["指示剂", " ".join(ind)])
                if v["oil"] > 0.01:
                    ci = t.get("I2", 0) * (1 - aq_f(v, "I2")) / v["oil"]
                    cb = t.get("Br2", 0) * (1 - aq_f(v, "Br2")) / v["oil"]
                    parts = ([f"I₂ {fc(ci)}"] if ci > 1e-4 else []) + ([f"Br₂ {fc(cb)}"] if cb > 1e-4 else [])
                    out.append(["CCl₄ 层", "，".join(parts) or "无色"])
                ui["sp"].set(out if out else f"<span style='color:{T.muted}'>只有水。</span>")
            pr = []
            for k in PK:
                o = v["pp"].get(k)
                if o and o["amt"] > 0.002:
                    pr.append([f"<span style='color:{_hexc(pcol(k, v))}'>■</span> {PN[k]}{'' if k == 'CuO' else ' ↓'}", f"{fmt(o['amt'] * PM[k], 1)} mg"])
            for s in v["solids"]:
                ct = [COATN[k] for k, x in s["coat"].items() if x > 0.01]
                pr.append([f"<span style='color:{qc(SO[s['k']]['col']).name()}'>■</span> {SO[s['k']]['n']}" + (f"（表面附着{'、'.join(ct)}）" if ct else ""),
                           f"{fmt(s['n'] * SO[s['k']]['M'] / 1000, 3)} g"])
            ui["pp"].set(pr if pr else f"<span style='color:{T.muted}'>没有沉淀或固体。</span>")
        except RuntimeError:   # 检查器刚被重建
            pass
    L.every(250, refresh)

    # ---- 素材栏
    def target():
        sel = W["sel"]
        return sel if sel and sel["kind"] == "v" else None

    def r_item(r):
        def clk():
            v = target()
            if not v:
                B.toast("先点选一个容器，或把试剂拖到容器上")
                return
            add_reagent(v, r)

        def drp(x, y):
            v = vessel_at(x, y)
            if not v:
                B.toast("把试剂拖到容器上")
                return
            select(v)
            add_reagent(v, r)
        col = qc(swatch(r))
        hexa = col.name()
        return {"icon": (ic_dropper if r.get("drop") else ic_bottle)(hexa), "label": r["n"], "sub": r["f"] + (" · " + r["c"] if r.get("c") else ""), "click": clk, "drop": drp}

    def s_item(k):
        def clk():
            v = target()
            if not v:
                B.toast("先点选一个容器")
                return
            add_solid(v, k)

        def drp(x, y):
            v = vessel_at(x, y)
            if not v:
                B.toast("把固体拖到容器上")
                return
            select(v)
            add_solid(v, k)
        return {"icon": ic_solid(SO[k]["col"]), "label": SO[k]["n"], "sub": SO[k]["f"], "click": clk, "drop": drp}

    def v_item(typ, sub):
        def clk():
            v = new_v(typ, c.w / 2)
            if v:
                select(v)

        def drp(x, _y):
            v = new_v(typ, x)
            if v:
                select(v)
        return {"icon": IC[typ], "label": VT[typ].n, "sub": sub, "click": clk, "drop": drp}

    def lamp_click():
        l_ = new_lamp(c.w * 0.8)
        if l_:
            select(l_)

    def lamp_drop(x, _y):
        l_ = new_lamp(x)
        if l_:
            select(l_)

    def co2_click():
        v = target()
        if not v:
            B.toast("先点选一个容器")
            return
        add_reagent(v, {"id": "CO2"})

    def co2_drop(x, y):
        v = vessel_at(x, y)
        if not v:
            B.toast("拖到容器上")
            return
        select(v)
        add_reagent(v, {"id": "CO2"})
    blank = {"v": [{"t": "tube"}, {"t": "beaker"}, {"t": "flask"}, {"lamp": 1}]}
    B.palette([
        {"title": "示例实验", "items": [{"icon": IC["demo"], "label": n, "sub": s, "click": (lambda p=p: scene(p))} for n, s, p in PRE]},
        {"title": "器材", "items": [v_item("tube", "20 mL"), v_item("beaker", "200 mL"), v_item("flask", "250 mL"),
                                  {"icon": IC["lamp"], "label": "酒精灯", "sub": "带三脚架和陶土网", "click": lamp_click, "drop": lamp_drop},
                                  {"icon": IC["bin"], "label": "清空台面", "sub": "恢复空的试管、烧杯、锥形瓶", "click": lambda: scene(blank)}]},
        {"title": "酸和碱", "items": [r_item(r) for r in RG if r["s"] == "acid"]},
        {"title": "盐溶液", "items": [r_item(r) for r in RG if r["s"] == "salt"]},
        {"title": "氧化剂和还原剂", "items": [r_item(r) for r in RG if r["s"] == "redox"]},
        {"title": "指示剂", "items": [r_item(r) for r in RG if r["s"] == "ind"]},
        {"title": "固体", "items": [s_item(k) for k in SO]},
        {"title": "水、溶剂和气体", "items": [r_item(r) for r in RG if r["s"] == "gas"] + [{"icon": IC["gas"], "label": "通入 CO₂", "sub": "每次约 0.3 mmol", "click": co2_click, "drop": co2_drop}]},
    ])
    B.tips([("可以试试", [
        "试管里加硫酸铜溶液，再逐滴（2 滴）加氢氧化钠溶液；然后加稀硫酸。", "氯化铝溶液里逐滴加氢氧化钠溶液至过量；换一支试管改用氨水，对比现象。",
        "澄清石灰水中反复通入 CO₂，先浑浊后澄清；再放到酒精灯上加热。", "硫酸亚铁溶液中加氢氧化钠溶液，把时间调到 20×，看沉淀颜色的变化。",
        "铁钉放进硫酸铜溶液；铜片放进硝酸银溶液或氯化铁溶液。", "锥形瓶里放氢氧化钠溶液和酚酞，再分次加入稀盐酸，注意颜色和温度。",
        "过氧化氢溶液中加二氧化锰，用带火星的木条检验；锌粒与稀盐酸，用燃着的木条检验。", "FeCl₃ 溶液滴入 KSCN；FeSO₄ 溶液先加 KSCN，再加氯水。",
        "烧杯里加水和酚酞，放入一小块金属钠。", "大理石分别放入稀盐酸、稀硫酸和醋酸中，比较反应快慢。"])])

    # ---- 主循环
    def tick(dt):
        W["clock"] += dt
        sd = dt * st["speed"]
        n = max(1, math.ceil(sd / 0.05))
        h = sd / n
        for v in vessels():
            for a in v["anims"]:
                a["t"] += dt
                due = 0.45 if a["k"] == "drip" else 0.3 if a["k"] == "stream" else 0.35 if a["k"] == "gas" else 0.5
                if not a.get("done") and a["t"] >= due:
                    a["done"] = True
                    a["go"]()
            v["anims"] = [a for a in v["anims"] if a["t"] < (0.6 if a["k"] == "stream" else 0.55)]
            if v["pour"]:
                p = v["pour"]
                p["t"] += dt
                want = clamp((p["t"] - 0.35) / 0.7, 0, 1)
                if want > p["done"] and not p["full"]:
                    fr = (want - p["done"]) / ((1 - p["done"]) or 1)
                    if not transfer(v, p["to"], fr):
                        p["full"] = True
                        B.toast(f"{p['to']['name']} 装满了")
                    p["done"] = want
                if p["t"] > 1.4:
                    v["pour"] = None
                    v["lift"] = 0.0
                    v["x"] = near_free(v, v.get("homeX", v["x"]))
                    if p.get("dT"):
                        neutral(p["to"], {"dT": p["dT"], "k": p["k"]})
            for _ in range(n):
                react(v, h)
            after(v, sd, dt)
        L.draw()
    L.loop(tick)

    # 初始台面
    layout()
    scene(blank)
    W["sel"] = None
    select(objs[0] if objs else None)
    def snapshot_transfer():
        return state_graph.encode(dict(objs=objs,st=st,cnt=cnt,W={k:v for k,v in W.items() if k!="ui"},records=records))
    def restore_transfer(snapshot):
        data=state_graph.decode(snapshot)
        objs[:]=data["objs"]
        st.clear(); st.update(data["st"])
        cnt.clear(); cnt.update(data["cnt"])
        W.clear(); W.update(data["W"])
        W["ui"]=None
        records[:]=data["records"]
        select(W.get("sel"))
        L.draw()
    B.transfer(snapshot_transfer,restore_transfer)


def _unused():
    _ = (random, PI)
