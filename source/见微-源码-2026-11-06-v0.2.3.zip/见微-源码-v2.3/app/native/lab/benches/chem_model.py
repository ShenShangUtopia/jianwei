"""化学工作台的溶液模型（由 gewu/bench-chem.js 改写）：试剂、固体、事件文案、容器轮廓、溶液平衡 eqm()、颜色。

每个容器记录各物质的总量（mmol）、体积（mL）和温度。每一步：
1. 先处理与 pH 无关的沉淀（AgI、AgBr、AgCl、BaSO₄，以及微溶的 CaSO₄）；
2. 用电荷守恒二分求 [H⁺]，同时按溶度积决定氢氧化物（含微溶的 Ca(OH)₂）、碳酸盐沉淀，
   按配合平衡处理铜氨、银氨、锌氨离子和 [Al(OH)₄]⁻、[Zn(OH)₄]²⁻；
3. 金属与酸、置换、大理石、H₂O₂ 分解、固体溶解等按速率进行，离子间的氧化还原近似瞬时完成。
溶度积等常数取教材常用值，个别（CaCO₃、Zn(OH)₂ 溶于强碱和氨水）为了现象能演示而做了放大。
四氯化碳单独记体积（下层），卤素单质在两层之间按分配系数分配。
"""
from __future__ import annotations

import math

from ...kit.core import PI, clamp, lerp

NM = {"Na": "Na⁺", "K": "K⁺", "Ca": "Ca²⁺", "Ba": "Ba²⁺", "Mg": "Mg²⁺", "Cu": "Cu²⁺", "Fe2": "Fe²⁺", "Fe3": "Fe³⁺", "Al": "Al³⁺", "Zn": "Zn²⁺", "Ag": "Ag⁺",
      "Mn": "Mn²⁺", "Cl": "Cl⁻", "Br": "Br⁻", "SO4": "SO₄²⁻", "NO3": "NO₃⁻", "I": "I⁻", "SCN": "SCN⁻", "MnO4": "MnO₄⁻"}
# 氢氧化物：金属、OH⁻ 个数、Ksp
HY = [("Fe3", 3, 4e-38), ("Al", 3, 1.3e-33), ("Cu", 2, 2.2e-20), ("Zn", 2, 3e-17), ("Fe2", 2, 4.9e-17), ("Mg", 2, 5.6e-12), ("Ag", 1, 2e-8)]
KSP = {h[0]: h[2] for h in HY}
PK = ["AgCl", "AgBr", "AgI", "BaSO4", "CaSO4", "CaCO3", "BaCO3", "CaOH", "Fe3", "Al", "Cu", "Zn", "Fe2", "Mg", "Ag", "CuO"]
PN = {"AgCl": "AgCl", "AgBr": "AgBr", "AgI": "AgI", "BaSO4": "BaSO₄", "CaSO4": "CaSO₄", "CaCO3": "CaCO₃", "BaCO3": "BaCO₃", "CaOH": "Ca(OH)₂", "Fe3": "Fe(OH)₃",
      "Al": "Al(OH)₃", "Cu": "Cu(OH)₂", "Zn": "Zn(OH)₂", "Fe2": "Fe(OH)₂", "Mg": "Mg(OH)₂", "Ag": "Ag₂O", "CuO": "CuO"}
PM = {"AgCl": 143.3, "AgBr": 187.8, "AgI": 234.8, "BaSO4": 233.4, "CaSO4": 136.1, "CaCO3": 100.1, "BaCO3": 197.3, "CaOH": 74.1, "Fe3": 106.9, "Al": 78, "Cu": 97.6,
      "Zn": 99.4, "Fe2": 89.9, "Mg": 58.3, "Ag": 115.9, "CuO": 79.5}
PC = {"AgCl": "#f3f3ef", "AgBr": "#efe3a6", "AgI": "#ecd468", "BaSO4": "#f5f5f2", "CaSO4": "#f4f4f0", "CaCO3": "#f2f2ee", "BaCO3": "#f2f2ee", "CaOH": "#f3f3ef",
      "Fe3": "#a5532b", "Al": "#e9eef3", "Cu": "#4a8edb", "Zn": "#f1f1ee", "Fe2": "#e4ebdf", "Mg": "#f0f1ee", "Ag": "#4b3d31", "CuO": "#24211f"}
PD = {"AgCl": "生成白色沉淀（不溶于稀硝酸）", "AgBr": "生成浅黄色沉淀（不溶于稀硝酸）", "AgI": "生成黄色沉淀（不溶于稀硝酸）", "BaSO4": "生成白色沉淀（不溶于稀盐酸）",
      "CaSO4": "生成白色沉淀（CaSO₄ 微溶，浓度较大时析出）", "CaCO3": "生成白色沉淀", "BaCO3": "生成白色沉淀", "CaOH": "生成白色沉淀（Ca(OH)₂ 微溶）",
      "Fe3": "生成红褐色沉淀", "Al": "生成白色胶状沉淀", "Cu": "生成蓝色絮状沉淀", "Zn": "生成白色沉淀",
      "Fe2": "生成白色絮状沉淀（在空气中迅速变成灰绿色，最后变成红褐色）", "Mg": "生成白色沉淀", "Ag": "生成棕褐色沉淀（AgOH 不稳定，转化为 Ag₂O）"}
PDN = {"Ag": "生成白色沉淀（继续滴加氨水，沉淀会溶解）"}   # 用氨水沉淀时的现象
HF = {
    "Fe3": ["Fe³⁺ + 3OH⁻ = Fe(OH)₃↓", "Fe³⁺ + 3NH₃·H₂O = Fe(OH)₃↓ + 3NH₄⁺"], "Al": ["Al³⁺ + 3OH⁻ = Al(OH)₃↓", "Al³⁺ + 3NH₃·H₂O = Al(OH)₃↓ + 3NH₄⁺"],
    "Cu": ["Cu²⁺ + 2OH⁻ = Cu(OH)₂↓", "Cu²⁺ + 2NH₃·H₂O = Cu(OH)₂↓ + 2NH₄⁺"], "Zn": ["Zn²⁺ + 2OH⁻ = Zn(OH)₂↓", "Zn²⁺ + 2NH₃·H₂O = Zn(OH)₂↓ + 2NH₄⁺"],
    "Fe2": ["Fe²⁺ + 2OH⁻ = Fe(OH)₂↓", "Fe²⁺ + 2NH₃·H₂O = Fe(OH)₂↓ + 2NH₄⁺"], "Mg": ["Mg²⁺ + 2OH⁻ = Mg(OH)₂↓", "Mg²⁺ + 2NH₃·H₂O = Mg(OH)₂↓ + 2NH₄⁺"],
    "Ag": ["2Ag⁺ + 2OH⁻ = Ag₂O↓ + H₂O", "Ag⁺ + NH₃·H₂O = AgOH↓ + NH₄⁺"],
    "AgCl": ["Ag⁺ + Cl⁻ = AgCl↓"], "AgBr": ["Ag⁺ + Br⁻ = AgBr↓"], "AgI": ["Ag⁺ + I⁻ = AgI↓"], "BaSO4": ["Ba²⁺ + SO₄²⁻ = BaSO₄↓"], "CaSO4": ["Ca²⁺ + SO₄²⁻ = CaSO₄↓"],
    "CaCO3": ["Ca²⁺ + CO₃²⁻ = CaCO₃↓"], "BaCO3": ["Ba²⁺ + CO₃²⁻ = BaCO₃↓"], "CaOH": ["Ca²⁺ + 2OH⁻ = Ca(OH)₂↓"],
}
HD = {
    "Fe3": "Fe(OH)₃ + 3H⁺ = Fe³⁺ + 3H₂O", "Al": "Al(OH)₃ + 3H⁺ = Al³⁺ + 3H₂O", "Cu": "Cu(OH)₂ + 2H⁺ = Cu²⁺ + 2H₂O", "Zn": "Zn(OH)₂ + 2H⁺ = Zn²⁺ + 2H₂O",
    "Fe2": "Fe(OH)₂ + 2H⁺ = Fe²⁺ + 2H₂O", "Mg": "Mg(OH)₂ + 2H⁺ = Mg²⁺ + 2H₂O", "Ag": "Ag₂O + 2H⁺ = 2Ag⁺ + H₂O",
    "CaCO3": "CaCO₃ + 2H⁺ = Ca²⁺ + CO₂↑ + H₂O", "BaCO3": "BaCO₃ + 2H⁺ = Ba²⁺ + CO₂↑ + H₂O",
}


def _ev_h2o2_phth(v, _e):
    return "溶液先变红，随后红色褪去：Na₂O₂ 与水反应的过程中生成了 H₂O₂，具有强氧化性（漂白作用）" if "Na₂O₂" in v["added"] else "酚酞的红色逐渐褪去：H₂O₂ 具有强氧化性（漂白作用）"


def _ev_nh3(v, _e):
    return "NH₄⁺ + OH⁻ =△= NH₃↑ + H₂O" if any("NH₄" in a for a in v["added"]) else "NH₃·H₂O =△= NH₃↑ + H₂O"


def _ev_co2(v, e):
    if v["T"] > 60 and e["pH"] > 6.5:
        return "2HCO₃⁻ =△= CO₃²⁻ + CO₂↑ + H₂O"
    if "r:CO3-H1" in v["ev"] or ("NaHCO₃" in v["added"] and "Na₂CO₃" not in v["added"]):
        return "HCO₃⁻ + H⁺ = CO₂↑ + H₂O"
    return "CO₃²⁻ + 2H⁺ = CO₂↑ + H₂O"


# 一次性事件：[方程式, 现象]（可以是 fn(v, e)）
EV = {
    "m:Na": ["2Na + 2H₂O = 2Na⁺ + 2OH⁻ + H₂↑", "钠浮在水面上，熔成闪亮的小球，四处游动，发出嘶嘶声"],
    "m:Zn-H": ["Zn + 2H⁺ = Zn²⁺ + H₂↑", "锌粒表面产生气泡"],
    "m:Mg-H": ["Mg + 2H⁺ = Mg²⁺ + H₂↑", "反应剧烈，产生大量气泡，容器外壁发热"],
    "m:Fe-H": ["Fe + 2H⁺ = Fe²⁺ + H₂↑", "铁表面缓慢产生气泡，溶液逐渐变为浅绿色"],
    "m:Al-H": ["2Al + 6H⁺ = 2Al³⁺ + 3H₂↑", "铝片表面产生气泡"],
    "m:Al-OH": ["2Al + 2OH⁻ + 6H₂O = 2[Al(OH)₄]⁻ + 3H₂↑", "铝片在碱溶液中溶解，产生气泡（旧教材写作 2Al + 2OH⁻ + 2H₂O = 2AlO₂⁻ + 3H₂↑）"],
    "g:cell": ["", "金属表面析出的铜（或银）与原金属在酸中构成原电池，产生气泡的速率明显加快"],
    "m:CaCO3": ["CaCO₃ + 2H⁺ = Ca²⁺ + CO₂↑ + H₂O", "大理石表面产生大量气泡"],
    "m:CaCO3-HAc": ["CaCO₃ + 2CH₃COOH = Ca²⁺ + 2CH₃COO⁻ + CO₂↑ + H₂O", "产生气泡，比盐酸中慢（醋酸是弱酸）"],
    "m:CaCO3-SO4": ["", "生成的 CaSO₄ 微溶，覆盖在大理石表面，反应逐渐停止"],
    "d:Zn-Cu": ["Zn + Cu²⁺ = Zn²⁺ + Cu", "锌表面析出红色的铜，溶液蓝色变浅"],
    "d:Fe-Cu": ["Fe + Cu²⁺ = Fe²⁺ + Cu", "铁表面析出红色的铜，溶液由蓝色逐渐变为浅绿色"],
    "d:Mg-Cu": ["Mg + Cu²⁺ = Mg²⁺ + Cu", "镁条表面析出红色的铜"],
    "d:Al-Cu": ["2Al + 3Cu²⁺ = 2Al³⁺ + 3Cu", "铝片表面析出红色的铜，溶液蓝色变浅"],
    "d:Cu-Ag": ["Cu + 2Ag⁺ = Cu²⁺ + 2Ag", "铜片表面析出银白色的银，溶液逐渐变蓝"],
    "d:Zn-Ag": ["Zn + 2Ag⁺ = Zn²⁺ + 2Ag", "锌表面析出银白色固体"],
    "d:Fe-Ag": ["Fe + 2Ag⁺ = Fe²⁺ + 2Ag", "铁表面析出银白色固体"],
    "d:Mg-Ag": ["Mg + 2Ag⁺ = Mg²⁺ + 2Ag", "镁条表面析出银白色固体"],
    "d:Al-Ag": ["Al + 3Ag⁺ = Al³⁺ + 3Ag", "铝片表面析出银白色固体"],
    "d:Fe-Fe3": ["Fe + 2Fe³⁺ = 3Fe²⁺", "溶液由黄色变为浅绿色"],
    "d:Cu-Fe3": ["Cu + 2Fe³⁺ = Cu²⁺ + 2Fe²⁺", "铜片被溶解，溶液变为蓝绿色（印刷电路板的腐蚀原理）"],
    "d:Zn-Fe3": ["Zn + 2Fe³⁺ = Zn²⁺ + 2Fe²⁺", "溶液黄色变浅"],
    "d:Mg-Fe3": ["Mg + 2Fe³⁺ = Mg²⁺ + 2Fe²⁺", "溶液黄色变浅"],
    "d:Al-Fe3": ["Al + 3Fe³⁺ = Al³⁺ + 3Fe²⁺", "溶液黄色变浅"],
    "d:Zn-Fe2": ["Zn + Fe²⁺ = Zn²⁺ + Fe", "锌表面附着一层黑色的铁粉，溶液浅绿色逐渐褪去"],
    "d:Mg-Fe2": ["Mg + Fe²⁺ = Mg²⁺ + Fe", "镁条表面附着黑色的铁粉，溶液浅绿色逐渐褪去"],
    "d:Al-Fe2": ["2Al + 3Fe²⁺ = 2Al³⁺ + 3Fe", "铝片表面附着黑色的铁粉"],
    "d:Mg-Zn": ["Mg + Zn²⁺ = Mg²⁺ + Zn", "镁条表面析出银灰色的锌"],
    "d:Al-Zn": ["2Al + 3Zn²⁺ = 2Al³⁺ + 3Zn", "铝片表面析出银灰色的锌"],
    "x:Cu": ["3Cu + 8H⁺ + 2NO₃⁻ = 3Cu²⁺ + 2NO↑ + 4H₂O", "铜片逐渐溶解，溶液变蓝；产生无色气体，在容器口变成红棕色（2NO + O₂ = 2NO₂）"],
    "x:Fe": ["Fe + 4H⁺ + NO₃⁻ = Fe³⁺ + NO↑ + 2H₂O", "铁溶解，溶液变黄，容器口出现红棕色气体"],
    "x:Zn": ["3Zn + 8H⁺ + 2NO₃⁻ = 3Zn²⁺ + 2NO↑ + 4H₂O", "锌溶解但不放出 H₂，容器口出现红棕色气体"],
    "x:Mg": ["3Mg + 8H⁺ + 2NO₃⁻ = 3Mg²⁺ + 2NO↑ + 4H₂O", "镁条溶解，容器口出现红棕色气体"],
    "x:Al": ["Al + 4H⁺ + NO₃⁻ = Al³⁺ + NO↑ + 2H₂O", "铝片溶解，容器口出现红棕色气体"],
    "r:Fe2-HNO3": ["3Fe²⁺ + 4H⁺ + NO₃⁻ = 3Fe³⁺ + NO↑ + 2H₂O", "溶液由浅绿色变为黄色，容器口出现红棕色气体"],
    "h2o2-MnO2": ["2H₂O₂ =MnO₂= 2H₂O + O₂↑", "迅速产生大量气泡，MnO₂ 作催化剂"],
    "h2o2-Fe3": ["2H₂O₂ =Fe³⁺= 2H₂O + O₂↑", "产生大量气泡，Fe³⁺ 起催化作用"],
    "h2o2-heat": ["2H₂O₂ =△= 2H₂O + O₂↑", "受热后 H₂O₂ 分解加快，产生气泡"],
    "r:MnO4-Fe2": ["MnO₄⁻ + 5Fe²⁺ + 8H⁺ = Mn²⁺ + 5Fe³⁺ + 4H₂O", "高锰酸钾的紫红色褪去"],
    "r:MnO4-H2O2": ["2MnO₄⁻ + 5H₂O₂ + 6H⁺ = 2Mn²⁺ + 5O₂↑ + 8H₂O", "紫红色褪去，产生气泡"],
    "r:Cl2-I": ["Cl₂ + 2I⁻ = 2Cl⁻ + I₂", "溶液变为黄褐色"],
    "r:Cl2-Fe2": ["Cl₂ + 2Fe²⁺ = 2Fe³⁺ + 2Cl⁻", "溶液由浅绿色变为黄色"],
    "r:Fe3-I": ["2Fe³⁺ + 2I⁻ = 2Fe²⁺ + I₂", "生成 I₂，溶液颜色加深"],
    "r:H2O2-I": ["H₂O₂ + 2I⁻ + 2H⁺ = I₂ + 2H₂O", "溶液逐渐变为黄褐色"],
    "r:Cl2-Br": ["Cl₂ + 2Br⁻ = 2Cl⁻ + Br₂", "溶液由无色变为橙黄色"],
    "r:Br2-I": ["Br₂ + 2I⁻ = 2Br⁻ + I₂", "溶液由橙黄色变为黄褐色"],
    "r:Br2-Fe2": ["Br₂ + 2Fe²⁺ = 2Fe³⁺ + 2Br⁻", "溴水褪色，溶液变为黄色"],
    "r:bleach": ["Cl₂ + H₂O ⇌ H⁺ + Cl⁻ + HClO", "HClO 有漂白性，指示剂的颜色逐渐褪去"],
    "r:H2O2-phth": ["", _ev_h2o2_phth],
    "r:CO3-H1": ["CO₃²⁻ + H⁺ = HCO₃⁻", "开始时没有气泡：CO₃²⁻ 先与 H⁺ 结合成 HCO₃⁻，H⁺ 再多时才放出 CO₂"],
    "r:NH3": [_ev_nh3, "产生有刺激性气味的气体，能使湿润的红色石蕊试纸变蓝（检验 NH₄⁺）"],
    "s:Na2O2": ["2Na₂O₂ + 2H₂O = 4Na⁺ + 4OH⁻ + O₂↑", "淡黄色固体溶解，产生大量气泡，放出热量；气体能使带火星的木条复燃"],
    "s:CaO": ["CaO + H₂O = Ca(OH)₂", "生石灰与水反应，放出大量的热"],
    "s:NaOH": ["", "NaOH 固体溶于水时放出大量的热，溶液温度明显升高"],
    "s:NH4NO3": ["", "NH₄NO₃ 固体溶于水时吸收热量，溶液温度降低"],
    "k:I2": ["", "振荡后静置：液体分层，下层（CCl₄ 层）呈紫红色，上层颜色变浅。I₂ 在 CCl₄ 中的溶解度比在水中大得多（萃取）"],
    "k:Br2": ["", "振荡后静置：液体分层，下层（CCl₄ 层）呈橙红色，上层颜色变浅（萃取）"],
    "r:Fe(OH)2-air": ["4Fe(OH)₂ + O₂ + 2H₂O = 4Fe(OH)₃", "白色沉淀迅速变成灰绿色，最后变成红褐色"],
    "r:CuO": ["Cu(OH)₂ =△= CuO + H₂O", "蓝色沉淀受热变成黑色"],
    "r:CuO-H": ["CuO + 2H⁺ = Cu²⁺ + H₂O", "黑色固体溶解，溶液变蓝"],
    "r:CO2": [_ev_co2, "产生大量气泡（CO₂）"],
    "r:boil": ["", "溶液沸腾"],
    "c:FeSCN": ["Fe³⁺ + 3SCN⁻ = Fe(SCN)₃", "溶液变成红色（检验 Fe³⁺）"],
    "c:starch": ["", "淀粉遇 I₂ 变蓝"],
    "c:CuN": ["Cu²⁺ + 4NH₃ = [Cu(NH₃)₄]²⁺", "溶液变为深蓝色"],
    "n:s": ["H⁺ + OH⁻ = H₂O", "酸碱中和"], "n:a": ["CH₃COOH + OH⁻ = CH₃COO⁻ + H₂O", "酸碱中和"],
    "n:b": ["NH₃·H₂O + H⁺ = NH₄⁺ + H₂O", "酸碱中和"], "n:ab": ["CH₃COOH + NH₃·H₂O = CH₃COO⁻ + NH₄⁺ + H₂O", "酸碱中和"],
}


def _rg(s, id_, n, f, c, a, **o):
    return {"s": s, "id": id_, "n": n, "f": f, "c": c, "a": a, **o}


# 试剂：a 为每毫升所含物质的量（mmol），即 mol/L
RG = [
    _rg("acid", "HCl", "稀盐酸", "HCl", "1 mol/L", {"Cl": 1}),
    _rg("acid", "H2SO4", "稀硫酸", "H₂SO₄", "0.5 mol/L", {"SO4": 0.5}),
    _rg("acid", "HNO3", "稀硝酸", "HNO₃", "2 mol/L", {"NO3": 2}),
    _rg("acid", "HAc", "醋酸", "CH₃COOH", "1 mol/L", {"A": 1}),
    _rg("acid", "NaOH", "氢氧化钠溶液", "NaOH", "1 mol/L", {"Na": 1}),
    _rg("acid", "NH3", "氨水", "NH₃·H₂O", "2 mol/L", {"N": 2}),
    _rg("acid", "CaOH2", "澄清石灰水", "Ca(OH)₂", "0.02 mol/L", {"Ca": 0.02}),
    _rg("salt", "NaCl", "氯化钠溶液", "NaCl", "0.5 mol/L", {"Na": 0.5, "Cl": 0.5}),
    _rg("salt", "Na2CO3", "碳酸钠溶液", "Na₂CO₃", "0.5 mol/L", {"Na": 1, "C": 0.5}),
    _rg("salt", "NaHCO3", "碳酸氢钠溶液", "NaHCO₃", "0.5 mol/L", {"Na": 0.5, "C": 0.5}),
    _rg("salt", "Na2SO4", "硫酸钠溶液", "Na₂SO₄", "0.5 mol/L", {"Na": 1, "SO4": 0.5}),
    _rg("salt", "NH4Cl", "氯化铵溶液", "NH₄Cl", "1 mol/L", {"N": 1, "Cl": 1}),
    _rg("salt", "CuSO4", "硫酸铜溶液", "CuSO₄", "0.5 mol/L", {"Cu": 0.5, "SO4": 0.5}),
    _rg("salt", "ZnSO4", "硫酸锌溶液", "ZnSO₄", "0.5 mol/L", {"Zn": 0.5, "SO4": 0.5005}),
    _rg("salt", "FeCl3", "氯化铁溶液", "FeCl₃", "0.2 mol/L", {"Fe3": 0.2, "Cl": 0.7}),
    _rg("salt", "FeSO4", "硫酸亚铁溶液", "FeSO₄", "0.2 mol/L", {"Fe2": 0.2, "SO4": 0.205}),
    _rg("salt", "AlCl3", "氯化铝溶液", "AlCl₃", "0.5 mol/L", {"Al": 0.5, "Cl": 1.52}),
    _rg("salt", "MgCl2", "氯化镁溶液", "MgCl₂", "0.5 mol/L", {"Mg": 0.5, "Cl": 1}),
    _rg("salt", "CaCl2", "氯化钙溶液", "CaCl₂", "0.5 mol/L", {"Ca": 0.5, "Cl": 1}),
    _rg("salt", "BaCl2", "氯化钡溶液", "BaCl₂", "0.2 mol/L", {"Ba": 0.2, "Cl": 0.4}),
    _rg("salt", "AgNO3", "硝酸银溶液", "AgNO₃", "0.1 mol/L", {"Ag": 0.1, "NO3": 0.1}),
    _rg("salt", "KBr", "溴化钾溶液", "KBr", "0.1 mol/L", {"K": 0.1, "Br": 0.1}),
    _rg("salt", "KI", "碘化钾溶液", "KI", "0.1 mol/L", {"K": 0.1, "I": 0.1}),
    _rg("salt", "KSCN", "硫氰化钾溶液", "KSCN", "0.1 mol/L", {"K": 0.1, "SCN": 0.1}),
    _rg("redox", "H2O2", "过氧化氢溶液", "H₂O₂", "3%", {"H2O2": 0.9}),
    _rg("redox", "KMnO4", "酸性高锰酸钾", "KMnO₄", "0.02 mol/L，含 H₂SO₄", {"K": 0.02, "MnO4": 0.02, "SO4": 0.5}),
    _rg("redox", "Cl2", "新制氯水", "Cl₂", "约 0.04 mol/L", {"Cl2": 0.04, "Cl": 0.02}),
    _rg("redox", "Br2", "溴水", "Br₂", "约 0.02 mol/L", {"Br2": 0.02}),
    _rg("redox", "I2", "碘水", "I₂", "0.005 mol/L", {"I2": 0.005, "K": 0.01, "I": 0.01}),
    _rg("ind", "phth", "酚酞试液", "酚酞", "", {"phth": 20}, drop=True),
    _rg("ind", "lit", "紫色石蕊试液", "石蕊", "", {"lit": 20}, drop=True),
    _rg("ind", "mo", "甲基橙试液", "甲基橙", "", {"mo": 20}, drop=True),
    _rg("ind", "starch", "淀粉溶液", "淀粉", "", {"starch": 20}, drop=True),
    _rg("gas", "H2O", "蒸馏水", "H₂O", "", {}),
    _rg("gas", "CCl4", "四氯化碳", "CCl₄", "不溶于水，密度比水大", {}, oil=True),
]
RG_BY = {r["id"]: r for r in RG}
SO = {
    "Zn": {"n": "锌粒", "f": "Zn", "mm": 3, "A": 1, "M": 65.4, "col": "#9aa3a8"},
    "Fe": {"n": "铁钉", "f": "Fe", "mm": 15, "A": 1, "M": 55.8, "col": "#6d747a"},
    "Mg": {"n": "镁条", "f": "Mg", "mm": 2, "A": 3, "M": 24.3, "col": "#c9ced2"},
    "Al": {"n": "铝片", "f": "Al", "mm": 3.5, "A": 1.5, "M": 27, "col": "#d4d8dc"},
    "Cu": {"n": "铜片", "f": "Cu", "mm": 8, "A": 1, "M": 63.5, "col": "#c27140"},
    "Na": {"n": "金属钠", "f": "Na", "mm": 2.2, "A": 1, "M": 23, "col": "#e2e4de"},
    "CaCO3": {"n": "大理石", "f": "CaCO₃", "mm": 10, "A": 1.5, "M": 100.1, "col": "#dedad0"},
    "MnO2": {"n": "二氧化锰", "f": "MnO₂", "mm": 2, "A": 1, "M": 86.9, "col": "#2b2724"},
    "Na2O2": {"n": "过氧化钠", "f": "Na₂O₂", "mm": 3, "A": 1, "M": 78, "col": "#ecd577"},
    "CaO": {"n": "生石灰", "f": "CaO", "mm": 5, "A": 1, "M": 56.1, "col": "#e9e7dc"},
    "NaOHs": {"n": "氢氧化钠固体", "f": "NaOH(s)", "mm": 25, "A": 1.2, "M": 40, "col": "#f4f4f0"},
    "NH4NO3": {"n": "硝酸铵固体", "f": "NH₄NO₃(s)", "mm": 25, "A": 1.2, "M": 80, "col": "#efeee6"},
}
# 能溶于水（或与水反应）的固体：速率、进入溶液的粒子（每 mmol）、放热 J/mmol（负值为吸热）
DSV = {
    "Na2O2": {"r": 1, "add": {"Na": 2}, "H": 143, "ev": "s:Na2O2"},
    "CaO": {"r": 0.8, "add": {"Ca": 1}, "H": 65, "ev": "s:CaO"},
    "NaOHs": {"r": 2.5, "add": {"Na": 1}, "H": 44.5, "ev": "s:NaOH"},
    "NH4NO3": {"r": 2.5, "add": {"N": 1, "NO3": 1}, "H": -25.7, "ev": "s:NH4NO3"},
}
MI = {"Zn": "Zn", "Fe": "Fe2", "Mg": "Mg", "Al": "Al", "Cu": "Cu"}
COAT = {"Cu": "#b4552d", "Ag": "#d8dadb", "Fe": "#3b3c3e", "Zn": "#9ea6ac"}
COATN = {"Cu": "铜", "Ag": "银", "Fe": "铁", "Zn": "锌"}
NIT = {"Cu": ("Cu", 2, 0.06), "Fe": ("Fe3", 3, 0.04), "Zn": ("Zn", 2, 0.1), "Mg": ("Mg", 2, 0.4), "Al": ("Al", 3, 0.04)}   # 稀硝酸：产物离子、失电子数、速率
HM = {"Zn": 153, "Fe": 89, "Mg": 467, "Al": 530}   # 每 mmol 金属与酸反应放热（J）
DISP = {   # 金属 → [离子, 每 mol 金属消耗的离子, 析出物]
    "Zn": [("Cu", 1, "Cu"), ("Ag", 2, "Ag"), ("Fe3", 2, None), ("Fe2", 1, "Fe")], "Fe": [("Cu", 1, "Cu"), ("Ag", 2, "Ag"), ("Fe3", 2, None)],
    "Mg": [("Cu", 1, "Cu"), ("Ag", 2, "Ag"), ("Fe3", 2, None), ("Fe2", 1, "Fe"), ("Zn", 1, "Zn")],
    "Al": [("Cu", 1.5, "Cu"), ("Ag", 3, "Ag"), ("Fe3", 3, None), ("Fe2", 1.5, "Fe"), ("Zn", 1.5, "Zn")], "Cu": [("Ag", 2, "Ag"), ("Fe3", 2, None)],
}
KD = {"I2": 85, "Br2": 27}   # 卤素单质在 CCl₄ 与水之间的分配系数


# ---------------------------------------------------------------- 容器轮廓
def prof(k):
    """容器内壁轮廓：[(半宽, 高)]（px，自底向上）。"""
    if k == "tube":
        r = 13
        p = [(r * math.sin(i / 8 * PI / 2), r - r * math.cos(i / 8 * PI / 2)) for i in range(9)]
        p.append((r, 165))
        return p
    if k == "beaker":
        return [(50, 0), (55, 4), (56, 10), (56, 132)]
    return [(54, 0), (59, 4), (60, 10), (20, 94), (16, 106), (16, 152)]


class VType:
    def __init__(self, k, n, cap, full, glass):
        self.k, self.n, self.cap, self.full, self.glass = k, n, cap, full, glass
        p = self.p = prof(k)
        self.H = p[-1][1]
        self.W = max(q[0] for q in p)
        cum = [0.0]
        for y in range(1, int(self.H) + 1):
            cum.append(cum[-1] + PI * self.hw(y - 0.5) ** 2)
        self.cum = cum
        self.sc = cap / cum[round(self.H * full)]

    def hw(self, y):
        p = self.p
        for i in range(1, len(p)):
            if y <= p[i][1]:
                return lerp(p[i - 1][0], p[i][0], (y - p[i - 1][1]) / ((p[i][1] - p[i - 1][1]) or 1))
        return p[-1][0]

    def lvl(self, V):
        q = V / self.sc
        if q <= 0:
            return 0.0
        cum = self.cum
        for y in range(1, len(cum)):
            if cum[y] >= q:
                return y - 1 + (q - cum[y - 1]) / (cum[y] - cum[y - 1])
        return float(self.H)


VT = {"tube": VType("tube", "试管", 20, 0.9, 8), "beaker": VType("beaker", "烧杯", 200, 0.9, 40), "flask": VType("flask", "锥形瓶", 250, 0.74, 50)}


# ---------------------------------------------------------------- 溶液平衡
K1, K2, KN, KA = 4.5e-7, 4.7e-11, 5.6e-10, 1.75e-5
LG = {"Cu": (1e15, 4), "Zn": (3e11, 4), "Ag": (1.7e7, 2)}   # 氨配合物：β、配体数


def _sq(a, b, k):
    return max(0.0, min(a, b, ((a + b) - math.sqrt((a - b) ** 2 + 4 * k)) / 2))


def eqm(t: dict, Vml: float, pHg=None, T: float = 25) -> dict:
    def g(k):
        x = t.get(k, 0)
        return x if x > 0 else 0.0
    V = max(Vml, 0.05)
    Ag, I, Br, Cl, Ba, SO4 = g("Ag"), g("I"), g("Br"), g("Cl"), g("Ba"), g("SO4")
    pAgI = min(Ag, I)
    Ag -= pAgI
    I -= pAgI
    pAgBr = min(Ag, Br)
    Ag -= pAgBr
    Br -= pAgBr
    pAgCl = min(Ag, Cl)
    Ag -= pAgCl
    Cl -= pAgCl
    pBaSO4 = min(Ba, SO4)
    Ba -= pBaSO4
    SO4 -= pBaSO4
    pCaSO4 = _sq(g("Ca"), SO4, 4.9e-5 * V * V)   # CaSO₄ 微溶
    SO4 -= pCaSO4
    q0 = g("Na") + g("K") + 2 * g("Mn") - Cl - Br - 2 * SO4 - g("NO3") - I - g("SCN") - g("MnO4")
    Ct, Nt, At, Ca0 = g("C"), g("N"), g("A"), g("Ca") - pCaSO4
    kCa = 5e-5 * 10 ** (-(T - 25) * 0.014)   # Ca(OH)₂ 微溶，溶解度随温度升高而减小
    M = {"Fe3": g("Fe3"), "Al": g("Al"), "Cu": g("Cu"), "Zn": g("Zn"), "Fe2": g("Fe2"), "Mg": g("Mg"), "Ag": Ag}
    cplx = Nt > 0 and (M["Cu"] or M["Zn"] or M["Ag"])
    out = {}

    def f(h, keep=False):
        oh = 1e-14 / h
        if cplx:   # 氨的物料守恒：游离 NH₃ + NH₄⁺ + 配位的 NH₃ = 总量
            def used(x):
                s = x * V * (1 + h / KN)
                for k, (b, nl) in LG.items():
                    m = M[k]
                    if not m:
                        continue
                    n = 1 if k == "Ag" else 2
                    cx = 1 + b * x ** nl
                    d = min(m, KSP[k] / oh ** n * cx * V)
                    s += nl * d * (1 - 1 / cx)
                return s
            lo2, hi2 = 0.0, Nt / V
            for _ in range(22):
                mm = (lo2 + hi2) / 2
                if used(mm) > Nt:
                    hi2 = mm
                else:
                    lo2 = mm
            nh3 = lo2
            nh4 = nh3 * V * h / KN
        else:
            nh4 = Nt * h / (h + KN)
            nh3 = (Nt - nh4) / V
        Dn = h * h + h * K1 + K1 * K2
        a0, a1, a2 = h * h / Dn, h * K1 / Dn, K1 * K2 / Dn
        pCa = _sq(Ca0, Ct, 2e-7 * V * V / a2) if Ct > 0 and Ca0 > 0 else 0.0
        pBa = _sq(Ba, Ct - pCa, 5e-8 * V * V / a2) if Ct - pCa > 0 and Ba > 0 else 0.0
        C = Ct - pCa - pBa
        ac = At * KA / (h + KA)
        caF = Ca0 - pCa
        dCa = min(caF, kCa / (oh * oh) * V)
        q = q0 + 2 * dCa + 2 * (Ba - pBa) + nh4 - C * (a1 + 2 * a2) - ac + (h - oh) * V
        free, pm = {}, {}
        cuN = agN = znN = alO = znO = 0.0
        for k, n, ks in HY:
            m = M[k]
            free[k] = 0.0
            pm[k] = 0.0
            if not m:
                continue
            fr = ks / oh ** n
            cx = 1.0
            if k == "Cu":
                cx += 1e15 * nh3 ** 4
            elif k == "Zn":
                cx += 3e11 * nh3 ** 4
            elif k == "Ag":
                cx += 1.7e7 * nh3 ** 2
            # 两性：Al(OH)₃ + OH⁻ ⇌ [Al(OH)₄]⁻，Zn(OH)₂ + 2OH⁻ ⇌ [Zn(OH)₄]²⁻
            an = 10 * oh if k == "Al" else 3 * oh * oh if k == "Zn" else 0.0
            za = 1 if k == "Al" else 2
            capT = (fr * cx + an) * V
            dd = min(m, capT)
            fc = fr * cx / (fr * cx + an) if capT > 0 else 1.0
            q += dd * (fc * n - (1 - fc) * za)
            pm[k] = m - dd
            free[k] = dd * fc / cx
            if keep:
                cn = dd * fc * (1 - 1 / cx)
                if k == "Cu":
                    cuN = cn
                elif k == "Ag":
                    agN = cn
                elif k == "Zn":
                    znN = cn
                    znO = dd * (1 - fc)
                if k == "Al":
                    alO = dd * (1 - fc)
        if keep:
            out.update(h=h, oh=oh,
                       p={"AgI": pAgI, "AgBr": pAgBr, "AgCl": pAgCl, "BaSO4": pBaSO4, "CaSO4": pCaSO4, "CaCO3": pCa, "BaCO3": pBa, "CaOH": caF - dCa, **pm},
                       dis={"Na": g("Na"), "K": g("K"), "Mn": g("Mn"), "Cl": Cl, "Br": Br, "SO4": SO4, "NO3": g("NO3"), "I": I, "SCN": g("SCN"),
                            "MnO4": g("MnO4"), "Ca": dCa, "Ba": Ba - pBa, **free},
                       cuN=cuN, agN=agN, znN=znN, alO=alO, znO=znO, h2co3=C * a0, hco3=C * a1, co3=C * a2, nh3=nh3 * V, nh4=nh4, hac=At - ac, ac=ac)
        return q

    lo, hi, it = -16.0, 1.5, 46
    if pHg is not None and math.isfinite(pHg):
        a, b = -pHg - 0.5, -pHg + 0.5
        if f(10 ** a) < 0 < f(10 ** b):
            lo, hi, it = a, b, 20
    if f(10 ** hi) < 0:
        lo = hi
    elif f(10 ** lo) > 0:
        hi = lo
    else:
        for _ in range(it):
            mm = (lo + hi) / 2
            if f(10 ** mm) > 0:
                hi = mm
            else:
                lo = mm
    h = 10 ** ((lo + hi) / 2)
    f(h, True)
    out["pH"] = -math.log10(h)
    return out


# ---------------------------------------------------------------- 颜色
def hx(c: str):
    n = int(c[1:], 16)
    return ((n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255)


def css(c, a=1.0) -> str:
    return f"rgba({round(clamp(c[0], 0, 1) * 255)},{round(clamp(c[1], 0, 1) * 255)},{round(clamp(c[2], 0, 1) * 255)},{a:.3f})"


def mix3(a, b, t):
    return (lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t))


def ramp(stops, x):
    if x <= stops[0][0]:
        return stops[0][1]
    for i in range(1, len(stops)):
        if x <= stops[i][0]:
            return mix3(stops[i - 1][1], stops[i][1], (x - stops[i - 1][0]) / (stops[i][0] - stops[i - 1][0]))
    return stops[-1][1]


LIT = [(4.5, (0.92, 0.33, 0.38)), (6.5, (0.62, 0.42, 0.78)), (8.5, (0.32, 0.48, 0.95))]
MO = [(3.1, (0.95, 0.28, 0.26)), (3.75, (1, 0.58, 0.24)), (4.4, (1, 0.86, 0.32))]
PHP = [(p, hx(c)) for p, c in ((1, "#d7262b"), (3, "#f0702b"), (5, "#f2c230"), (7, "#5ea93c"), (9, "#23908a"), (11, "#2b5ea8"), (13, "#4a368e"))]


def tint(t, Vml, e, aq=1.0, aqB=None):
    """溶液对 r、g、b 的透射率；aq、aqB：I₂、Br₂ 留在水层的比例。"""
    aqB = aq if aqB is None else aqB
    V = max(Vml, 0.05)
    rgb = [1.0, 1.0, 1.0]

    def ap(Tr, s):
        if not (s > 1e-3):
            return
        s = min(s, 6)
        rgb[0] *= Tr[0] ** s
        rgb[1] *= Tr[1] ** s
        rgb[2] *= Tr[2] ** s
    dis = e["dis"]

    def d(k):
        return (dis.get(k) or 0) / V
    ap((0.55, 0.78, 0.96), d("Cu") / 0.1)
    ap((0.2, 0.3, 0.9), e["cuN"] / V / 0.02)
    ap((0.99, 0.8, 0.38), d("Fe3") / 0.1)
    ap((0.86, 0.97, 0.84), d("Fe2") / 0.1)
    ap((0.85, 0.12, 0.1), min(d("Fe3"), d("SCN")) / 0.004)
    ap((0.62, 0.12, 0.62), d("MnO4") / 0.0015)
    i2 = (t.get("I2") or 0) * aq / V
    if (t.get("starch") or 0) > 0.05:
        ap((0.12, 0.16, 0.5), i2 / 0.0004)
    else:
        ap((0.96, 0.66, 0.24), i2 / 0.004)
    ap((0.99, 0.76, 0.4), (t.get("Br2") or 0) * aqB / V / 0.005)
    ap((0.93, 0.98, 0.72), (t.get("Cl2") or 0) / V / 0.04)

    def s(u):
        return min(3, (u or 0) * 3 / math.sqrt(Vml + 1))
    pH = e["pH"]
    if (t.get("phth") or 0) > 0.05:
        ap((0.98, 0.3, 0.62), 1.4 * s(t["phth"]) * clamp((pH - 8.2) / 1.8, 0, 1))
    if (t.get("lit") or 0) > 0.05:
        ap(ramp(LIT, pH), s(t["lit"]))
    if (t.get("mo") or 0) > 0.05:
        ap(ramp(MO, pH), s(t["mo"]))
    return tuple(rgb)


def tint_oil(i2, br2, Vo):
    """CCl₄ 层：I₂ 紫红色，Br₂ 橙红色。"""
    V = max(Vo, 0.05)
    rgb = [1.0, 1.0, 1.0]
    for Tr, s in (((0.8, 0.3, 0.72), i2 / V / 0.006), ((0.97, 0.52, 0.26), br2 / V / 0.012)):
        if s > 1e-3:
            s = min(s, 6)
            for i in range(3):
                rgb[i] *= Tr[i] ** s
    return tuple(rgb)


_sw: dict = {}


def swatch(r) -> str:
    if r["id"] in _sw:
        return _sw[r["id"]]
    if r.get("oil"):
        col = "rgba(225,232,236,.75)"
    else:
        tt = {k: x * 2 for k, x in r["a"].items()}
        c = tint(tt, 2, eqm(tt, 2))
        col = "rgba(150,195,220,.4)" if c[0] + c[1] + c[2] > 2.9 else css(c)
    _sw[r["id"]] = col
    return col


# ---------------------------------------------------------------- 图标
def ic_bottle(c):
    return ('<svg viewBox="0 0 24 24"><path d="M9.5 2.5h5v3l2.5 3.5v11a1.5 1.5 0 0 1-1.5 1.5h-7A1.5 1.5 0 0 1 7 20V9l2.5-3.5z" fill="none" stroke="currentColor" stroke-width="1.3"/>'
            f'<path d="M7.7 11.5h8.6v8.3a.9.9 0 0 1-.9.9H8.6a.9.9 0 0 1-.9-.9z" fill="{c}"/></svg>')


def ic_dropper(c):
    return ('<svg viewBox="0 0 24 24"><path d="M10 2.5h4v5h-4z" fill="#b54a3c"/><path d="M10.6 7.5v9.5L12 21l1.4-4V7.5" fill="none" stroke="currentColor" stroke-width="1.3"/>'
            f'<path d="M10.9 12h2.2v4.6L12 19.6l-1.1-3z" fill="{c}"/></svg>')


def ic_solid(c):
    return f'<svg viewBox="0 0 24 24"><path d="M5 15l4-6 6-1 4 5-2 6-8 1z" fill="{c}" stroke="currentColor" stroke-width="1.1"/></svg>'


IC = {
    "tube": '<svg viewBox="0 0 24 24"><path d="M10 2.5h4M10.6 3v15a1.4 1.4 0 0 0 2.8 0V3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M10.6 12h2.8v6a1.4 1.4 0 0 1-2.8 0z" fill="#6fb6e0"/></svg>',
    "beaker": '<svg viewBox="0 0 24 24"><path d="M5 4h14M6 4v15a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V4" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M6.7 12h10.6v7.3H6.7z" fill="#6fb6e0"/></svg>',
    "flask": '<svg viewBox="0 0 24 24"><path d="M9.5 3h5M10 3v6l-5 10a1 1 0 0 0 1 1.4h12a1 1 0 0 0 1-1.4l-5-10V3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M7.4 15h9.2l2.2 4.6H5.2z" fill="#6fb6e0"/></svg>',
    "lamp": '<svg viewBox="0 0 24 24"><path d="M12 3c2 3 2.4 4.6 0 7-2.4-2.4-2-4 0-7z" fill="#f29a2e"/><path d="M11 10h2v3h-2zM7 15a5 4 0 0 1 10 0v5H7z" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',
    "gas": '<svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="3" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="15" cy="9" r="4" fill="none" stroke="currentColor" stroke-width="1.3"/><circle cx="16" cy="18" r="2" fill="none" stroke="currentColor" stroke-width="1.3"/></svg>',
    "demo": '<svg viewBox="0 0 24 24"><path d="M9 3h6M10 3v6l-5 9a1.4 1.4 0 0 0 1.2 2.1h11.6A1.4 1.4 0 0 0 19 18l-5-9V3" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M7.3 14h9.4l1.6 3H5.7z" fill="#e85a9a"/></svg>',
    "bin": '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>',
}

ART = """<svg viewBox="0 0 160 110"><rect x="0" y="92" width="160" height="18" fill="currentColor" opacity=".08"/>
  <path d="M30 26h40M34 26v62a4 4 0 0 0 4 4h24a4 4 0 0 0 4-4V26" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M35.5 58h29v29.5a3 3 0 0 1-3 3h-23a3 3 0 0 1-3-3z" fill="#4a8edb" opacity=".75"/>
  <circle cx="44" cy="70" r="2.4" fill="#fff" opacity=".8"/><circle cx="52" cy="62" r="1.6" fill="#fff" opacity=".8"/>
  <path d="M100 14h16M102 14v28l-18 40a5 5 0 0 0 5 7h38a5 5 0 0 0 5-7l-18-40V14" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M92 66h32l9 19a3 3 0 0 1-3 4H86a3 3 0 0 1-3-4z" fill="#e85a9a" opacity=".7"/>
  <path d="M136 10v34" stroke="currentColor" stroke-width="1.6"/><circle cx="136" cy="50" r="2.2" fill="#e85a9a"/></svg>"""


def _t1(r, s=None):
    return {"t": "tube", "r": r, "s": s or []}


PRE = [
    ["铜盐与碱、氨水", "氨水过量时沉淀溶解", {"amt": 1, "v": [_t1([("CuSO4", 2)]), _t1([("CuSO4", 2)])], "tip": "试管 1 每次加入 1 mL 氢氧化钠溶液，试管 2 每次加入 1 mL 氨水，都加到过量，比较两支试管的现象。"}],
    ["氢氧化铝的两性", "NaOH 过量时沉淀溶解", {"amt": 1, "v": [_t1([("AlCl3", 2)]), _t1([("AlCl3", 2)])], "tip": "试管 1 逐次加入氢氧化钠溶液，试管 2 逐次加入氨水，各加 5 次以上，看沉淀能否溶解。"}],
    ["石灰水与 CO₂", "浑浊 → 澄清 → 加热又浑浊", {"speed": 5, "v": [_t1([("CaOH2", 10)]), {"lamp": 1}], "tip": "选中试管，多次点击「通入 CO₂」；溶液重新澄清后，点「放到酒精灯上」并点燃酒精灯。"}],
    ["中和反应与指示剂", "颜色、pH 和温度", {"amt": 1, "v": [{"t": "flask", "r": [("NaOH", 10), ("phth", 0.1)]}], "tip": "每次加入 1 mL 稀盐酸，注意溶液颜色、pH 和温度；红色恰好褪去时接近中和点。"}],
    ["金属活动性顺序", "四组置换反应对比", {"speed": 5, "v": [_t1([("CuSO4", 5)], ["Zn"]), _t1([("CuSO4", 5)], ["Fe"]), _t1([("AgNO3", 5)], ["Cu"]), _t1([("FeSO4", 5)], ["Cu"])],
                                       "tip": "观察哪些金属表面有固体析出、溶液颜色怎样变化；铜放进硫酸亚铁溶液里有没有变化？"}],
    ["气体的制取与检验", "H₂、O₂、CO₂", {"v": [_t1([("HCl", 5)], ["Zn"]), _t1([("H2O2", 5)], ["MnO2"]), {"t": "beaker", "r": [("HCl", 20)], "s": ["CaCO3"]}],
                                     "tip": "依次选中三个容器，用「燃着的木条」和「带火星的木条」检验产生的气体。"}],
    ["Fe²⁺ 和 Fe³⁺ 的检验", "KSCN 与氯水", {"amt": 0.1, "v": [_t1([("FeCl3", 2)]), _t1([("FeSO4", 2)])], "tip": "两支试管各加入硫氰化钾溶液；再向试管 2 加入新制氯水，观察颜色变化。"}],
    ["亚铁盐与碱", "白色 → 灰绿 → 红褐", {"speed": 20, "v": [_t1([("FeSO4", 2)])], "tip": "加入 2 mL 氢氧化钠溶液。时间已调到 20×，注意沉淀颜色的变化。"}],
    ["钠与水", "浮、熔、游、响、红", {"v": [{"t": "beaker", "r": [("H2O", 50), ("phth", 0.1)]}], "tip": "选中烧杯，放入一块金属钠。"}],
    ["铜与稀硝酸", "无色 NO 在管口变红棕色", {"speed": 5, "v": [_t1([("HNO3", 5)], ["Cu"])], "tip": "观察铜片溶解、溶液变蓝，以及试管口气体颜色的变化。"}],
    ["卤素的氧化性", "Cl₂ 把 I⁻ 氧化成 I₂", {"amt": 0.1, "v": [_t1([("KI", 2), ("starch", 0.1)])], "tip": "向试管中加入新制氯水，观察溶液颜色。"}],
    ["大理石与三种酸", "盐酸、硫酸、醋酸对比", {"v": [_t1([("HCl", 6)], ["CaCO3"]), _t1([("H2SO4", 6)], ["CaCO3"]), _t1([("HAc", 6)], ["CaCO3"])], "speed": 5,
                                       "tip": "比较三支试管中气泡的多少；稀硫酸中的反应为什么会逐渐停止？"}],
    ["卤素单质的氧化性", "Cl₂ > Br₂ > I₂", {"amt": 1, "v": [_t1([("KBr", 3)]), _t1([("KI", 3)]), _t1([("KI", 3)])],
                                         "tip": "试管 1、2 各加 1 mL 新制氯水，试管 3 加 1 mL 溴水；再各加 1 mL 四氯化碳，点「振荡 / 搅拌」，比较下层的颜色。"}],
    ["萃取碘水中的碘", "CCl₄ 层变紫红色", {"amt": 2, "v": [_t1([("I2", 10)])], "tip": "加入 2 mL 四氯化碳，观察分层；点「振荡 / 搅拌」后静置，比较上下两层的颜色。"}],
    ["卤化银沉淀", "AgCl 白、AgBr 浅黄、AgI 黄", {"amt": 0.1, "v": [_t1([("NaCl", 2)]), _t1([("KBr", 2)]), _t1([("KI", 2)])],
                                             "tip": "三支试管各滴加 2 滴硝酸银溶液，比较沉淀颜色；再加入稀硝酸，沉淀溶解吗？"}],
    ["碳酸钠与盐酸", "滴加顺序不同，现象不同", {"amt": 1, "v": [_t1([("Na2CO3", 4)]), _t1([("HCl", 4)])],
                                        "tip": "试管 1：每次加 1 mL 稀盐酸，开始时有没有气泡？试管 2：每次加 1 mL 碳酸钠溶液，立刻就有气泡。"}],
    ["过氧化钠与水", "放出 O₂，酚酞先红后褪", {"v": [{"t": "beaker", "r": [("H2O", 30), ("phth", 0.1)]}], "speed": 5, "tip": "放入过氧化钠，观察气泡和温度；用带火星的木条检验气体；注意酚酞颜色的变化。"}],
    ["铵盐的检验", "NH₄⁺ 与碱共热放出 NH₃", {"speed": 5, "v": [_t1([("NH4Cl", 3), ("NaOH", 3)]), {"lamp": 1}], "tip": "把试管放到酒精灯上并点燃，温度升高后用「湿润的红色石蕊试纸」检验管口的气体。"}],
    ["溶解时的热效应", "NaOH 放热、NH₄NO₃ 吸热", {"v": [{"t": "beaker", "r": [("H2O", 20)]}, {"t": "beaker", "r": [("H2O", 20)]}], "tip": "烧杯 1 放入氢氧化钠固体，烧杯 2 放入硝酸铵固体，比较温度变化。"}],
    ["Al³⁺ 与 HCO₃⁻", "泡沫灭火器原理", {"amt": 5, "v": [_t1([("AlCl3", 3)])], "tip": "加入 5 mL 碳酸氢钠溶液，观察沉淀和气泡。"}],
    ["氢氧化锌的两性", "溶于强碱，也溶于氨水", {"amt": 1, "v": [_t1([("ZnSO4", 2)]), _t1([("ZnSO4", 2)])], "tip": "试管 1 每次加 1 mL 氢氧化钠溶液，试管 2 每次加 1 mL 氨水，各加到过量。"}],
    ["原电池加快反应", "锌粒表面析出铜", {"speed": 5, "amt": 0.1, "v": [_t1([("H2SO4", 8)], ["Zn"]), _t1([("H2SO4", 8)], ["Zn"])], "tip": "向试管 2 滴加 2 滴硫酸铜溶液，比较两支试管产生气泡的快慢。"}],
    ["锌置换铁", "活动性 Zn > Fe > Cu", {"speed": 20, "v": [_t1([("FeSO4", 6)], ["Zn"]), _t1([("FeSO4", 6)], ["Cu"])], "tip": "观察锌粒、铜片表面的变化；时间已调到 20×。"}],
]
