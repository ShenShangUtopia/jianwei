"""自由工作台 · 力学与电磁场（由 gewu/bench-phys.js 改写）。

单位：m、kg、s、C、N/C、T；点电荷 Q 以 nC 计（k = 9×10⁹ N·m²/C²）。
每帧分成若干子步：先算力（重力、电场力、库仑力、弹簧弹力、空气阻力），
半步加速 → 在磁场中按洛伦兹力精确旋转速度 → 再半步加速（Boris 方法）→ 位移，
最后处理绳、杆约束，与地面、斜面、挡板、点电荷的碰撞（含摩擦）以及物体之间的碰撞。
"""
from __future__ import annotations

import copy
import math
import time

from PySide6.QtCore import QPointF

from ...design.tokens import T, alpha
from ...kit.bench import bench
from ...kit import state_graph
from ...kit.core import PI, TAU, clamp, fmt, lerp
from ...kit.draw import D, Gradient
from ...kit.view import View

KQ = 9      # Q 以 nC 计：kQ = 9×10⁹ × Q×10⁻⁹ = 9Q
VS = 0.3    # 速度箭头：每 1 m/s 画 0.3 m

ART = ("""<svg viewBox="0 0 160 110"><rect x="0" y="92" width="160" height="18" fill="currentColor" opacity=".08"/>
  <rect x="78" y="10" width="72" height="62" fill="#16968a" opacity=".1" stroke="#16968a" stroke-dasharray="4 3"/>"""
       + "".join(f'<circle cx="{92 + i * 22}" cy="{22 + j * 19}" r="5" fill="none" stroke="#16968a" stroke-width="1.4"/>'
                 f'<circle cx="{92 + i * 22}" cy="{22 + j * 19}" r="1.5" fill="#16968a"/>' for i in range(3) for j in range(3))
       + '<path d="M14 30 Q 50 30 66 60 T 100 92" fill="none" stroke="currentColor" stroke-dasharray="3 4" stroke-width="1.6"/>'
       + "".join(f'<circle cx="{14 + i * 13}" cy="{30 + i * i * 2.6}" r="4" fill="#d6522b" opacity="{0.3 + i * 0.15:.2f}"/>' for i in range(5))
       + '<path d="M14 92 L58 92 L58 66 Z" fill="currentColor" opacity=".18"/><rect x="30" y="74" width="12" height="12" transform="rotate(-31 36 80)" fill="#2c6fd1"/></svg>')


def _svg(s):
    return f'<svg viewBox="0 0 24 24">{s}</svg>'


ICON = {
    "ball": _svg('<circle cx="12" cy="12" r="7" fill="#d6522b"/>'), "block": _svg('<rect x="5" y="7" width="14" height="11" rx="1.5" fill="#2c6fd1"/>'),
    "pos": _svg('<circle cx="12" cy="12" r="7" fill="#d6522b"/><path d="M8.5 12h7M12 8.5v7" stroke="#fff" stroke-width="2"/>'),
    "neg": _svg('<circle cx="12" cy="12" r="7" fill="#2c6fd1"/><path d="M8.5 12h7" stroke="#fff" stroke-width="2"/>'),
    "ramp": _svg('<path d="M3 19h18V7z" fill="currentColor" opacity=".35" stroke="currentColor" stroke-width="1.2"/>'),
    "wall": _svg('<path d="M10 3v18" stroke="currentColor" stroke-width="3"/><path d="M12 5l3-3M12 9l3-3M12 13l3-3M12 17l3-3M12 21l3-3" stroke="currentColor" stroke-width="1"/>'),
    "belt": _svg('<rect x="2.5" y="9" width="19" height="7" rx="3.5" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="6" cy="12.5" r="2" fill="currentColor"/>'
                 '<circle cx="18" cy="12.5" r="2" fill="currentColor"/><path d="M10 6h5l-1.5-1.5M15 6l-1.5 1.5" fill="none" stroke="currentColor" stroke-width="1.2"/>'),
    "board": _svg('<path d="M3 15L21 9" stroke="currentColor" stroke-width="3"/>'),
    "spring": _svg('<path d="M2 12h3l1.5-4 3 8 3-8 3 8 3-8 1.5 4h2" fill="none" stroke="currentColor" stroke-width="1.5"/>'),
    "rope": _svg('<path d="M6 3h12M12 3v12" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="17" r="3.5" fill="#d6522b"/>'),
    "rod": _svg('<path d="M6 3h12" stroke="currentColor" stroke-width="1.5"/><path d="M12 3v12" stroke="currentColor" stroke-width="3.5"/><circle cx="12" cy="17" r="3.5" fill="#d6522b"/>'),
    "ef": _svg('<rect x="3" y="3" width="18" height="18" fill="#8457c4" opacity=".12" stroke="#8457c4" stroke-dasharray="3 2"/><path d="M8 6v10M16 6v10" stroke="#8457c4" stroke-width="1.5"/>'
               '<path d="M5.5 14L8 18l2.5-4M13.5 14l2.5 4 2.5-4" fill="none" stroke="#8457c4" stroke-width="1.5"/>'),
    "bo": _svg('<rect x="3" y="3" width="18" height="18" fill="#16968a" opacity=".12" stroke="#16968a" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="5" fill="none" stroke="#16968a" stroke-width="1.5"/>'
               '<circle cx="12" cy="12" r="1.6" fill="#16968a"/>'),
    "bi": _svg('<rect x="3" y="3" width="18" height="18" fill="#16968a" opacity=".12" stroke="#16968a" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="5" fill="none" stroke="#16968a" stroke-width="1.5"/>'
               '<path d="M9.3 9.3l5.4 5.4M14.7 9.3l-5.4 5.4" stroke="#16968a" stroke-width="1.5"/>'),
    "qp": _svg('<circle cx="12" cy="12" r="5" fill="#d6522b"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l2.8 2.8M16.2 16.2L19 19M19 5l-2.8 2.8M7.8 16.2L5 19" stroke="#d6522b" stroke-width="1.2"/>'),
    "qn": _svg('<circle cx="12" cy="12" r="5" fill="#2c6fd1"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="#2c6fd1" stroke-width="1.2"/>'),
    "arc": _svg('<path d="M5 6a8 8 0 0 0 14 9" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="9" cy="14" r="2.2" fill="#d6522b"/>'),
    "pulley": _svg('<path d="M8 2h8M12 2v5" stroke="currentColor" stroke-width="1.4"/><circle cx="12" cy="10" r="3.5" fill="none" stroke="currentColor" stroke-width="1.6"/>'
                   '<path d="M8.5 10v8M15.5 10v5" stroke="currentColor" stroke-width="1.2"/><rect x="6" y="18" width="5" height="4" fill="#2c6fd1"/><circle cx="15.5" cy="17" r="2.4" fill="#d6522b"/>'),
    "planet": _svg('<circle cx="12" cy="12" r="6" fill="#3d7fc4"/><ellipse cx="12" cy="12" rx="10.5" ry="3.5" fill="none" stroke="currentColor" stroke-width="1.1" transform="rotate(-20 12 12)"/>'),
    "bc": _svg('<circle cx="12" cy="12" r="9" fill="#16968a" opacity=".12" stroke="#16968a" stroke-dasharray="3 2"/><circle cx="12" cy="12" r="4" fill="none" stroke="#16968a" stroke-width="1.5"/>'
               '<circle cx="12" cy="12" r="1.4" fill="#16968a"/>'),
    "demo": _svg('<path d="M5 18c4-12 10-12 14 0" fill="none" stroke="currentColor" stroke-dasharray="2 2.5" stroke-width="1.5"/><circle cx="5" cy="18" r="2" fill="currentColor"/>'),
}
LN = {"spring": "弹簧", "rope": "细绳", "rod": "轻杆"}
TRANSIENT = {"trail", "strobe", "hist", "aN", "aF", "aT", "N", "F", "Tn", "fs", "fe", "fg", "fx", "fy", "touch", "bz"}


def _dash_line(g, x1, y1, x2, y2, col, w, dash, offset):
    pen = g._pen(col, w, dash)
    pen.setDashOffset(offset / max(0.5, w))
    g.p.setPen(pen)
    g.p.drawLine(QPointF(x1, y1), QPointF(x2, y2))


def _sgn(v):
    return (v > 0) - (v < 0)


@bench.reg(id="phys", subj="phys", short="力学与电磁", title="力学与电磁场", sub="物体 · 斜面 · 圆弧 · 弹簧 · 绳 · 滑轮 · 电场 · 磁场 · 点电荷 · 星球",
           desc="把小球、木块、斜面、圆弧轨道、传送带、弹簧、细绳、定滑轮、匀强电场、匀强（圆形）磁场、点电荷和星球放到场景里，设定初速度后运行，看轨迹、频闪照片、受力分析和 v–t 图。",
           art=ART)
def mech(B):
    L = B.L
    c = L.canvas()
    view = View(c, -1, 23, -1.6, 13, equal=True)
    env = {"grav": True, "g": 9.8, "ground": True, "gmu": 0.0, "air": 0.0}
    show = {"trail": True, "vel": True, "force": False, "strobe": False, "lines": True, "graph": "v"}
    S = {"objs": [], "sel": None, "uid": 0, "run": False, "simT": 0.0, "speed": 1.0, "snap": None, "strobeT": 0.0, "held": None,
         "panned": False, "lastP": None, "lines": ("", [])}
    ui: dict = {}
    cnt: dict = {}

    def nm(k):
        cnt[k] = cnt.get(k, 0) + 1
        return f"{k} {cnt[k]}"

    def nid():
        S["uid"] += 1
        return S["uid"]

    # ---- 对象
    def mk(kind, **o):
        base = {
            "body": dict(shape="ball", name="", x=0, y=0, vx=0, vy=0, m=1, r=0.4, q=0, e=0.6, ang=0),
            "ramp": dict(x=3, ang=30, len=8, mu=0.2, dir=1),
            "wall": dict(x1=0, y1=0, x2=0, y2=3, mu=0),
            "link": dict(mode="spring", ax=0, ay=0, a=None, b=None, k=40, L0=3, len=3, damp=0),
            "ef": dict(x=5, y=2, w=10, h=7, E=10, dir=270),
            "bf": dict(x=5, y=2, w=10, h=7, B=1),
            "pc": dict(x=11, y=6, Q=10),
            "arc": dict(x=11, y=3, R=3, a0=-90, a1=90, mu=0),
            "pulley": dict(x=11, y=8, a=None, b=None, len=6),
            "planet": dict(x=11, y=6, GM=400, R=1.5),
        }[kind]
        names = {"ramp": "斜面", "wall": "挡板", "ef": "匀强电场", "bf": "匀强磁场", "pc": "点电荷", "arc": "圆弧轨道", "pulley": "定滑轮", "planet": "星球"}
        q = {"kind": kind, "id": nid(), **base}
        if kind == "body":
            q["ci"] = q["id"] % 6
        if kind in names and "name" not in o:
            q["name"] = nm(names[kind])
        q.update(o)
        return q

    def ball(**o):
        if "name" not in o:
            o["name"] = nm("带电小球" if o.get("q") else "小球")
        return mk("body", **o)

    def block(**o):
        o.setdefault("name", nm("木块"))
        return mk("body", **{"shape": "block", "r": 0.5, "e": 0, **o})

    def objs():
        return S["objs"]

    def by_id(i):
        return next((o for o in S["objs"] if o["id"] == i), None)

    def ramp_pts(r):
        a = r["ang"] * PI / 180
        return r["x"], r["x"] + r["dir"] * r["len"] * math.cos(a), r["len"] * math.sin(a)

    def inside(o, x, y):
        if o.get("circ"):
            return math.hypot(x - o["x"] - o["w"] / 2, y - o["y"] - o["h"] / 2) <= min(o["w"], o["h"]) / 2
        return o["x"] <= x <= o["x"] + o["w"] and o["y"] <= y <= o["y"] + o["h"]

    def on_arc(o, a):
        return ((a - o["a0"]) % 360 + 360) % 360 <= min(360, o["a1"] - o["a0"]) + 1e-9

    def arc_end(o, a):
        return o["x"] + o["R"] * math.cos(a * PI / 180), o["y"] + o["R"] * math.sin(a * PI / 180)

    def ends(k, by=None):
        b = by.get(k["b"]) if by is not None else by_id(k["b"])
        a = (by.get(k["a"]) if by is not None else by_id(k["a"])) if k["a"] is not None else None
        return b, a, (a["x"] if a else k["ax"]), (a["y"] if a else k["ay"])

    # ---- 物理
    def fields_at(x, y):
        Ex = Ey = Bz = 0.0
        for o in S["objs"]:
            kd = o["kind"]
            if kd == "ef" and inside(o, x, y):
                a = o["dir"] * PI / 180
                Ex += o["E"] * math.cos(a)
                Ey += o["E"] * math.sin(a)
            elif kd == "bf" and inside(o, x, y):
                Bz += o["B"]
            elif kd == "pc":
                dx, dy = x - o["x"], y - o["y"]
                r = max(0.25, math.hypot(dx, dy))
                k = KQ * o["Q"] / r ** 3
                Ex += k * dx
                Ey += k * dy
        return Ex, Ey, Bz

    def contact(b, nx, ny, mu, sx=0.0, sy=0.0):
        b["touch"] = (nx, ny)
        vn = b["vx"] * nx + b["vy"] * ny
        if vn >= 0:
            return
        e = b["e"] if -vn > 0.5 else 0
        jn = -(1 + e) * vn
        b["vx"] += jn * nx
        b["vy"] += jn * ny
        b["aN"][0] += jn * nx * b["m"]
        b["aN"][1] += jn * ny * b["m"]
        tx, ty = -ny, nx
        vt = (b["vx"] - sx) * tx + (b["vy"] - sy) * ty
        jt = min(abs(vt), mu * jn)   # 摩擦冲量不超过 μ × 法向冲量
        if jt > 0:
            s = _sgn(vt)
            b["vx"] -= s * jt * tx
            b["vy"] -= s * jt * ty
            b["aF"][0] -= s * jt * tx * b["m"]
            b["aF"][1] -= s * jt * ty * b["m"]

    def seg(b, x1, y1, x2, y2, mu, belt=0.0):
        dx, dy = x2 - x1, y2 - y1
        L2 = dx * dx + dy * dy or 1e-9
        t = clamp(((b["x"] - x1) * dx + (b["y"] - y1) * dy) / L2, 0, 1)
        px, py = x1 + t * dx, y1 + t * dy
        nx, ny = b["x"] - px, b["y"] - py
        d = math.hypot(nx, ny)
        if d >= b["r"] or d < 1e-9:
            return
        nx, ny = nx / d, ny / d
        b["x"], b["y"] = px + nx * b["r"], py + ny * b["r"]
        L1 = math.sqrt(L2)
        contact(b, nx, ny, mu, belt * dx / L1, belt * dy / L1)

    def step(h):
        allo = S["objs"]
        held = S["held"]
        bs = [o for o in allo if o["kind"] == "body"]
        by = {b["id"]: b for b in bs}
        links = [o for o in allo if o["kind"] == "link"]
        pls = [o for o in allo if o["kind"] == "planet"]
        for b in bs:
            b["fx"], b["fy"] = 0.0, (-b["m"] * env["g"] if env["grav"] else 0.0)
            b["fs"], b["fe"], b["fg"], b["bz"] = [0.0, 0.0], [0.0, 0.0], [0.0, 0.0], 0.0
            for p in pls:   # 万有引力 F = GMm/r²，指向星球中心
                dx, dy = b["x"] - p["x"], b["y"] - p["y"]
                r = max(p["R"] * 0.5, math.hypot(dx, dy))
                k = -p["GM"] * b["m"] / r ** 3
                b["fg"][0] += k * dx
                b["fg"][1] += k * dy
                b["fx"] += k * dx
                b["fy"] += k * dy
        for k in links:
            if k["mode"] != "spring":
                continue
            b, a, ax, ay = ends(k, by)
            if not b:
                continue
            dx, dy = b["x"] - ax, b["y"] - ay
            d = math.hypot(dx, dy) or 1e-9
            ux, uy = dx / d, dy / d
            F = -k["k"] * (d - k["L0"])
            if k["damp"]:
                F -= k["damp"] * ((b["vx"] - (a["vx"] if a else 0)) * ux + (b["vy"] - (a["vy"] if a else 0)) * uy)
            b["fx"] += F * ux
            b["fy"] += F * uy
            b["fs"][0] += F * ux
            b["fs"][1] += F * uy
            if a:
                a["fx"] -= F * ux
                a["fy"] -= F * uy
                a["fs"][0] -= F * ux
                a["fs"][1] -= F * uy
        for b in bs:
            if b is held:
                continue
            if b["q"]:
                Ex, Ey, Bz = fields_at(b["x"], b["y"])
                b["fe"] = [b["q"] * Ex, b["q"] * Ey]
                b["fx"] += b["fe"][0]
                b["fy"] += b["fe"][1]
                b["bz"] = Bz
            if env["air"]:
                b["fx"] -= env["air"] * b["vx"]
                b["fy"] -= env["air"] * b["vy"]
            ax, ay = b["fx"] / b["m"], b["fy"] / b["m"]
            b["vx"] += ax * h / 2
            b["vy"] += ay * h / 2
            if b["bz"]:
                th = -b["q"] * b["bz"] / b["m"] * h
                cs, sn = math.cos(th), math.sin(th)
                vx = b["vx"]
                b["vx"], b["vy"] = vx * cs - b["vy"] * sn, vx * sn + b["vy"] * cs
            b["vx"] += ax * h / 2
            b["vy"] += ay * h / 2
            b["x"] += b["vx"] * h
            b["y"] += b["vy"] * h
        for _it in range(2):
            for k in links:
                if k["mode"] == "spring":
                    continue
                b, a, ax, ay = ends(k, by)
                if not b:
                    continue
                dx, dy = b["x"] - ax, b["y"] - ay
                d = math.hypot(dx, dy) or 1e-9
                if k["mode"] == "rope" and d <= k["len"]:
                    continue
                ux, uy = dx / d, dy / d
                err = d - k["len"]
                wb = 0 if b is held else 1 / b["m"]
                wa = 1 / a["m"] if a and a is not held else 0
                ws = wa + wb
                if not ws:
                    continue
                b["x"] -= ux * err * wb / ws
                b["y"] -= uy * err * wb / ws
                if a:
                    a["x"] += ux * err * wa / ws
                    a["y"] += uy * err * wa / ws
                rv = (b["vx"] - (a["vx"] if a else 0)) * ux + (b["vy"] - (a["vy"] if a else 0)) * uy
                if k["mode"] == "rod" or rv > 0:
                    j = rv / ws
                    b["vx"] -= ux * j * wb
                    b["vy"] -= uy * j * wb
                    b["aT"][0] -= ux * j
                    b["aT"][1] -= uy * j
                    if a:
                        a["vx"] += ux * j * wa
                        a["vy"] += uy * j * wa
                        a["aT"][0] += ux * j
                        a["aT"][1] += uy * j
        for _it in range(2):   # 定滑轮：两段绳长之和不超过总长，两侧拉力相等
            for p in allo:
                if p["kind"] != "pulley":
                    continue
                A, Bb = by.get(p["a"]), by.get(p["b"])
                if not A or not Bb:
                    continue
                d1 = math.hypot(A["x"] - p["x"], A["y"] - p["y"]) or 1e-9
                d2 = math.hypot(Bb["x"] - p["x"], Bb["y"] - p["y"]) or 1e-9
                err = d1 + d2 - p["len"]
                if err <= 0:
                    continue
                u1 = ((A["x"] - p["x"]) / d1, (A["y"] - p["y"]) / d1)
                u2 = ((Bb["x"] - p["x"]) / d2, (Bb["y"] - p["y"]) / d2)
                wa = 0 if A is held else 1 / A["m"]
                wb = 0 if Bb is held else 1 / Bb["m"]
                ws = wa + wb
                if not ws:
                    continue
                A["x"] -= u1[0] * err * wa / ws
                A["y"] -= u1[1] * err * wa / ws
                Bb["x"] -= u2[0] * err * wb / ws
                Bb["y"] -= u2[1] * err * wb / ws
                rv = A["vx"] * u1[0] + A["vy"] * u1[1] + Bb["vx"] * u2[0] + Bb["vy"] * u2[1]
                if rv > 0:
                    j = rv / ws
                    A["vx"] -= u1[0] * j * wa
                    A["vy"] -= u1[1] * j * wa
                    Bb["vx"] -= u2[0] * j * wb
                    Bb["vy"] -= u2[1] * j * wb
                    A["aT"][0] -= u1[0] * j
                    A["aT"][1] -= u1[1] * j
                    Bb["aT"][0] -= u2[0] * j
                    Bb["aT"][1] -= u2[1] * j
        for b in bs:
            if b is held:
                continue
            b["touch"] = None
            if env["ground"] and b["y"] - b["r"] < 0:
                b["y"] = b["r"]
                contact(b, 0, 1, env["gmu"])
            for o in allo:
                kd = o["kind"]
                if kd == "ramp":
                    fx, tx, ty = ramp_pts(o)
                    seg(b, fx, 0, tx, ty, o["mu"])
                    seg(b, tx, ty, tx, 0, o["mu"])
                elif kd == "wall":
                    seg(b, o["x1"], o["y1"], o["x2"], o["y2"], o["mu"], o.get("belt") or 0)
                elif kd in ("pc", "planet"):
                    dx, dy = b["x"] - o["x"], b["y"] - o["y"]
                    d = math.hypot(dx, dy)
                    R = b["r"] + (0.25 if kd == "pc" else o["R"])
                    if 1e-9 < d < R:
                        b["x"], b["y"] = o["x"] + dx / d * R, o["y"] + dy / d * R
                        contact(b, dx / d, dy / d, 0.5 if kd == "planet" else 0)
                elif kd == "arc":   # 圆弧轨道：物体在弧的内侧或外侧都能接触
                    dx, dy = b["x"] - o["x"], b["y"] - o["y"]
                    d = math.hypot(dx, dy)
                    if d > 1e-9 and on_arc(o, math.atan2(dy, dx) * 180 / PI):
                        gap = d - o["R"]
                        if abs(gap) < b["r"]:
                            s = -1 if gap < 0 else 1
                            nr = o["R"] + s * b["r"]
                            b["x"], b["y"] = o["x"] + dx / d * nr, o["y"] + dy / d * nr
                            contact(b, s * dx / d, s * dy / d, o["mu"])
                    else:
                        for a in (o["a0"], o["a1"]):   # 两个端点
                            ex, ey = arc_end(o, a)
                            qx, qy = b["x"] - ex, b["y"] - ey
                            qq = math.hypot(qx, qy)
                            if 1e-9 < qq < b["r"]:
                                b["x"], b["y"] = ex + qx / qq * b["r"], ey + qy / qq * b["r"]
                                contact(b, qx / qq, qy / qq, o["mu"])
        n = len(bs)
        for i in range(n):
            p = bs[i]
            for j in range(i + 1, n):
                q = bs[j]
                dx, dy = q["x"] - p["x"], q["y"] - p["y"]
                d = math.hypot(dx, dy)
                R = p["r"] + q["r"]
                if d >= R or d < 1e-9 or p.get("nc") or q.get("nc"):   # nc：带电粒子束，彼此不碰撞
                    continue
                nx, ny = dx / d, dy / d
                wp = 0 if p is held else 1 / p["m"]
                wq = 0 if q is held else 1 / q["m"]
                ws = wp + wq
                if not ws:
                    continue
                ov = R - d
                p["x"] -= nx * ov * wp / ws
                p["y"] -= ny * ov * wp / ws
                q["x"] += nx * ov * wq / ws
                q["y"] += ny * ov * wq / ws
                rv = (q["vx"] - p["vx"]) * nx + (q["vy"] - p["vy"]) * ny
                if rv >= 0:
                    continue
                J = -(1 + min(p["e"], q["e"])) * rv / ws
                p["vx"] -= J * wp * nx
                p["vy"] -= J * wp * ny
                q["vx"] += J * wq * nx
                q["vy"] += J * wq * ny

    def energy(b):
        Ek = 0.5 * b["m"] * (b["vx"] ** 2 + b["vy"] ** 2)
        Eg = b["m"] * env["g"] * b["y"] if env["grav"] else 0.0
        Es = Ee = Ep = 0.0
        for k in S["objs"]:
            if k["kind"] == "link" and k["mode"] == "spring" and b["id"] in (k["b"], k["a"]):
                q, _a, ax, ay = ends(k)
                if q:
                    Es += 0.5 * k["k"] * (math.hypot(q["x"] - ax, q["y"] - ay) - k["L0"]) ** 2
            elif k["kind"] == "pc" and b["q"]:
                Ee += KQ * k["Q"] * b["q"] / max(0.25, math.hypot(b["x"] - k["x"], b["y"] - k["y"]))
            elif k["kind"] == "planet":   # 引力势能（无穷远处为零）
                Ep -= k["GM"] * b["m"] / max(k["R"] * 0.5, math.hypot(b["x"] - k["x"], b["y"] - k["y"]))
        return Ek, Eg, Es, Ee, Ep

    # ---- 快照、播放与编辑
    def save():
        return copy.deepcopy(([{k: v for k, v in o.items() if k not in TRANSIENT} for o in S["objs"]], dict(env)))

    def clear_marks():
        for o in S["objs"]:
            if o["kind"] == "body":
                o["trail"], o["strobe"], o["hist"] = [], [], []
        S["strobeT"] = 0.0

    def edited():
        if not S["run"]:
            S["simT"], S["snap"] = 0.0, None
            clear_marks()

    def reset(*_):
        S["run"] = False
        if S["snap"]:
            objs_, env_ = copy.deepcopy(S["snap"])
            S["objs"] = objs_
            env.update(env_)
            sid = S["sel"]["id"] if S["sel"] else None
            S["sel"] = by_id(sid) if sid else None
        S["simT"], S["snap"] = 0.0, None
        clear_marks()
        inspect()

    def toggle_run(*_):
        if not S["run"] and not S["snap"]:
            S["snap"] = save()
        S["run"] = not S["run"]
        b = ui.get("play")
        if b is not None:
            try:
                b.setText("暂停" if S["run"] else "播放")
            except RuntimeError:
                pass

    def frame(sd):
        bs = [o for o in S["objs"] if o["kind"] == "body"]
        for b in bs:
            b["aN"], b["aF"], b["aT"] = [0.0, 0.0], [0.0, 0.0], [0.0, 0.0]
            b.setdefault("trail", [])
            b.setdefault("strobe", [])
            b.setdefault("hist", [])
        n = max(1, math.ceil(sd / 0.0015))
        h = sd / n
        for _ in range(n):
            step(h)
            S["simT"] += h
            S["strobeT"] += h
            if S["strobeT"] >= 0.1:
                S["strobeT"] -= 0.1
                for b in bs:
                    b["strobe"].append((b["x"], b["y"], b["ang"]))
                    if len(b["strobe"]) > 120:
                        b["strobe"].pop(0)
        for b in bs:
            b["N"] = (b["aN"][0] / sd, b["aN"][1] / sd)
            b["F"] = (b["aF"][0] / sd, b["aF"][1] / sd)
            b["Tn"] = (b["aT"][0] / sd, b["aT"][1] / sd)
            tl = b["trail"]
            if not tl or math.hypot(tl[-1][0] - b["x"], tl[-1][1] - b["y"]) > 0.03:
                tl.append((b["x"], b["y"]))
                if len(tl) > 2500:
                    tl.pop(0)
            Ek, Eg, Es, Ee, Ep = energy(b)
            b["hist"].append((S["simT"], b["vx"], b["vy"], math.hypot(b["vx"], b["vy"]), b["x"], b["y"], Ek, Eg + Es + Ee + Ep))
            if len(b["hist"]) > 5000:
                b["hist"].pop(0)

    # ---- 绘制
    def P(x, y):
        return view.X(x), view.Y(y)

    def draw_fields(g):
        sel = S["sel"]
        for o in S["objs"]:
            if o["kind"] not in ("ef", "bf"):
                continue
            x0, y1 = P(o["x"], o["y"] + o["h"])
            w, h = o["w"] * view.sx, o["h"] * view.sy
            col = T.c5 if o["kind"] == "ef" else T.c3

            def shape():
                g.begin_path()
                if o.get("circ"):
                    g.arc(x0 + w / 2, y1 + h / 2, min(w, h) / 2, 0, TAU)
                else:
                    g.rect(x0, y1, w, h)
            shape()
            g.fill_style = alpha(col, 0.13 if sel is o else 0.08)
            g.fill()
            g.dash, g.stroke_style, g.line_width = [6, 4], alpha(col, 0.95 if sel is o else 0.6), 2 if sel is o else 1.2
            g.stroke()
            g.dash = []
            if o.get("circ") and sel is o:
                D.rect(g, x0, y1, w, h, None, alpha(col, 0.4), 1)
            g.save()
            shape()
            g.clip_path()
            if o["kind"] == "ef":
                a = o["dir"] * PI / 180
                ux, uy, st = math.cos(a) * 0.35, math.sin(a) * 0.35, 1.3
                if o["E"] > 0:
                    x = o["x"] + st / 2
                    while x < o["x"] + o["w"]:
                        y = o["y"] + st / 2
                        while y < o["y"] + o["h"]:
                            view.vec(x - ux, y - uy, x + ux, y + uy, alpha(col, 0.75), 1.4)
                            y += st
                        x += st
            elif o["B"]:
                rr = clamp(3 + abs(o["B"]) * 1.6, 3, 9)
                cc, cd = alpha(col, 0.75), alpha(col, 0.88)
                x = o["x"] + 0.5
                while x < o["x"] + o["w"]:
                    y = o["y"] + 0.5
                    while y < o["y"] + o["h"]:
                        px, py = P(x, y)
                        D.circle(g, px, py, rr, None, cc, 1.3)
                        if o["B"] > 0:
                            D.circle(g, px, py, 1.6, cd)
                        else:
                            d = rr * 0.62
                            D.line(g, px - d, py - d, px + d, py + d, cd, 1.3)
                            D.line(g, px - d, py + d, px + d, py - d, cd, 1.3)
                        y += 1
                    x += 1
            g.restore()
            if o["kind"] == "ef":
                D.text(g, f"E = {fmt(o['E'], 1)} N/C", x0 + 6, y1 + 12, col, size=12, bold=True)
            else:
                D.text(g, f"B = {fmt(abs(o['B']), 2)} T {'⊙ 向外' if o['B'] >= 0 else '⊗ 向里'}", x0 + 6, y1 + h - 10, col, size=12, bold=True)
            if sel is o:
                D.rect(g, x0 + w - 6, y1 - 6, 12, 12, T.stage, col, 2)

    def field_lines(g):
        pcs = [o for o in S["objs"] if o["kind"] == "pc" and o["Q"]]
        if not show["lines"] or not pcs:
            return
        key = repr(([(o["x"], o["y"], o.get("Q"), o.get("E"), o.get("dir"), o.get("w"), o.get("h"))
                     for o in S["objs"] if o["kind"] in ("pc", "ef")], int(view.x0), int(view.x1), int(view.y0), int(view.y1)))
        if key != S["lines"][0]:
            lines = []
            for p in pcs:
                sg, n = _sgn(p["Q"]), 12
                for i in range(n):
                    x, y = p["x"] + 0.3 * math.cos(i / n * TAU + 0.13), p["y"] + 0.3 * math.sin(i / n * TAU + 0.13)
                    pts = [(x, y)]
                    for _s in range(360):
                        Ex, Ey, _b = fields_at(x, y)
                        m = math.hypot(Ex, Ey)
                        if m < 1e-9:
                            break
                        x += sg * Ex / m * 0.07
                        y += sg * Ey / m * 0.07
                        pts.append((x, y))
                        if x < view.x0 - 1 or x > view.x1 + 1 or y < view.y0 - 1 or y > view.y1 + 1:
                            break
                        if any(q is not p and math.hypot(x - q["x"], y - q["y"]) < 0.28 for q in pcs):
                            break
                    lines.append((sg, pts))
            S["lines"] = (key, lines)
        for sg, pts in S["lines"][1]:
            col = alpha(T.c2 if sg > 0 else T.c1, 0.38)
            D.poly(g, [P(*q) for q in pts], None, col, 1.1, close=False)
            if len(pts) > 24:
                mid, nx = pts[22], pts[23]
                a, b2 = (mid, nx) if sg > 0 else (nx, mid)
                D.arrow(g, *P(*a), *P(*b2), alpha(T.c2 if sg > 0 else T.c1, 0.6), 1.1, 7)

    def hatch(g, x1, y1, x2, y2, side=1):   # 沿线段一侧画短斜线
        L2 = math.hypot(x2 - x1, y2 - y1) or 1
        n = max(1, int(L2 // 9))
        ux, uy = (x2 - x1) / L2, (y2 - y1) / L2
        nx, ny = -uy * side, ux * side
        col = alpha(T.axis, 0.55)
        for i in range(n + 1):
            px, py = x1 + ux * i * 9, y1 + uy * i * 9
            D.line(g, px, py, px + nx * 7 - ux * 5, py + ny * 7 - uy * 5, col, 1)

    def draw_ground(g):
        if env["ground"]:
            y = view.Y(0)
            D.rect(g, 0, y, c.w, c.h - y, alpha(T.axis, 0.07))
            D.line(g, 0, y, c.w, y, T.axis, 2)
            hatch(g, 0, y, c.w, y, -1)
            if env["gmu"]:
                D.text(g, f"地面 μ = {fmt(env['gmu'], 2)}", c.w - 8, y + 14, T.muted, size=11, align="right")

    def draw_static(g):
        sel = S["sel"]
        for o in S["objs"]:
            kd = o["kind"]
            if kd == "ramp":
                fx, tx, ty = ramp_pts(o)
                A, Bp, C = P(fx, 0), P(tx, ty), P(tx, 0)
                D.poly(g, [A, Bp, C], alpha(T.axis, 0.28 if sel is o else 0.18), T.accent if sel is o else T.axis, 2.2 if sel is o else 1.6)
                r0 = 26
                a0 = 0 if o["dir"] > 0 else PI
                a1 = -o["ang"] * PI / 180 if o["dir"] > 0 else PI + o["ang"] * PI / 180
                g.begin_path()
                g.arc(A[0], A[1], r0, min(a0, a1), max(a0, a1))
                g.stroke_style, g.line_width = T.muted, 1
                g.stroke()
                D.text(g, f"θ={fmt(o['ang'], 0)}°", A[0] + o["dir"] * (r0 + 6), A[1] - 9, T.muted, size=11, align="left" if o["dir"] > 0 else "right")
                if o["mu"]:
                    D.text(g, f"μ={fmt(o['mu'], 2)}", (A[0] + Bp[0]) / 2 + o["dir"] * 6, (A[1] + Bp[1]) / 2 + 14, T.muted, size=11, align="center")
                if sel is o:
                    D.circle(g, Bp[0], Bp[1], 6, T.stage, T.accent, 2)
            elif kd == "wall" and o.get("belt") is not None:   # 传送带：两个滚轮 + 移动的带面
                A, Bp = P(o["x1"], o["y1"]), P(o["x2"], o["y2"])
                L1 = math.hypot(Bp[0] - A[0], Bp[1] - A[1]) or 1
                ux, uy = (Bp[0] - A[0]) / L1, (Bp[1] - A[1]) / L1
                nx, ny = uy, -ux
                r = 0.28 * view.sx
                s = 1 if ny > 0 else -1
                ox, oy = nx * r * s, ny * r * s
                col = T.accent if sel is o else T.axis
                D.line(g, A[0] + 2 * ox, A[1] + 2 * oy, Bp[0] + 2 * ox, Bp[1] + 2 * oy, alpha(col, 0.6), 2)
                _dash_line(g, A[0], A[1], Bp[0], Bp[1], col, 3.2, [8, 6], -S["simT"] * o["belt"] * view.sx)
                for x, y in (A, Bp):
                    cx, cy = x + ox, y + oy
                    a = S["simT"] * o["belt"] / 0.28
                    D.circle(g, cx, cy, r, alpha(T.axis, 0.15), col, 1.6)
                    D.line(g, cx, cy, cx + math.cos(-a) * r, cy + math.sin(-a) * r, col, 1.4)
                D.text(g, f"v带 = {fmt(o['belt'], 1)} m/s" + (f"  μ={fmt(o['mu'], 2)}" if o["mu"] else ""), (A[0] + Bp[0]) / 2,
                       (A[1] + Bp[1]) / 2 + 2 * oy + 14 * (_sgn(oy) or 1), T.muted, size=11, align="center")
                if sel is o:
                    D.circle(g, A[0], A[1], 6, T.stage, T.accent, 2)
                    D.circle(g, Bp[0], Bp[1], 6, T.stage, T.accent, 2)
            elif kd == "wall":
                A, Bp = P(o["x1"], o["y1"]), P(o["x2"], o["y2"])
                g.line_cap = "round"
                D.line(g, A[0], A[1], Bp[0], Bp[1], T.accent if sel is o else T.axis, 4)
                g.line_cap = "butt"
                hatch(g, A[0], A[1], Bp[0], Bp[1], 1)
                if sel is o:
                    D.circle(g, A[0], A[1], 6, T.stage, T.accent, 2)
                    D.circle(g, Bp[0], Bp[1], 6, T.stage, T.accent, 2)
        for o in S["objs"]:
            kd = o["kind"]
            if kd == "arc":   # 圆弧轨道：外侧画短斜线
                cx, cy = P(o["x"], o["y"])
                Rp = o["R"] * view.sx
                col = T.accent if sel is o else T.axis
                span = min(360, o["a1"] - o["a0"])
                g.begin_path()
                g.arc(cx, cy, Rp, -o["a0"] * PI / 180, -(o["a0"] + span) * PI / 180, True)
                g.stroke_style, g.line_width, g.line_cap = col, 4, "round"
                g.stroke()
                g.line_cap = "butt"
                n = max(4, int(span * PI / 180 * Rp / 9))
                hc = alpha(T.axis, 0.5)
                for i in range(n + 1):
                    a = (o["a0"] + span * i / n) * PI / 180
                    ux, uy = math.cos(a), -math.sin(a)
                    D.line(g, cx + ux * (Rp + 2), cy + uy * (Rp + 2), cx + ux * (Rp + 8) - uy * 4, cy + uy * (Rp + 8) + ux * 4, hc, 1)
                if o["mu"]:
                    D.text(g, f"μ={fmt(o['mu'], 2)}", cx, cy, T.muted, size=11, align="center")
                if sel is o:
                    D.circle(g, cx, cy, 4, T.accent)
                    D.text(g, f"R = {fmt(o['R'], 2)} m", cx + 8, cy - 10, T.accent, size=11)
            elif kd == "planet":
                x, y = P(o["x"], o["y"])
                r = o["R"] * view.sx
                gl = Gradient("radial", (x, y, r * 1.5), [(0, alpha("#5aa0e8", 0.35)), (0.6, alpha("#5aa0e8", 0.35)), (1, alpha("#5aa0e8", 0))])
                D.rect(g, x - r * 1.6, y - r * 1.6, r * 3.2, r * 3.2, gl)
                gr = Gradient("radial", (x, y, r, x - r * 0.35, y - r * 0.35), [(0, "#9fd0ff"), (0.55, "#3d7fc4"), (1, "#1f4f86")])
                D.circle(g, x, y, r, gr, T.accent if sel is o else alpha(T.fg, 0.3), 2.4 if sel is o else 1)
                g.save()
                g.begin_path()
                g.arc(x, y, r, 0, TAU)
                g.clip_path()
                g.fill_style = "rgba(90,170,90,.55)"
                for i in range(4):
                    g.begin_path()
                    g.ellipse(x + math.cos(i * 2.1) * r * 0.45, y + math.sin(i * 1.7) * r * 0.4, r * 0.32, r * 0.18, i)
                    g.fill()
                g.restore()
                D.text(g, f"GM = {fmt(o['GM'], 0)} m³/s²", x + r + 6, y - r - 4, T.muted, size=11)
            elif kd == "pulley":
                x, y = P(o["x"], o["y"])
                col = T.accent if sel is o else T.fg
                r = max(7, 0.3 * view.sx)
                D.line(g, x, y, x, y - r - 14, alpha(T.axis, 0.8), 2)
                D.rect(g, x - 12, y - r - 18, 24, 5, alpha(T.axis, 0.5))
                for i in (o["a"], o["b"]):
                    q = by_id(i)
                    if q:
                        qx, qy = P(q["x"], q["y"])
                        D.line(g, x, y, qx, qy, col, 1.4)
                D.circle(g, x, y, r, T.stage, col, 2)
                D.circle(g, x, y, 2.4, col)
        field_lines(g)
        for o in S["objs"]:
            if o["kind"] != "pc":
                continue
            x, y = P(o["x"], o["y"])
            r = 0.25 * view.sx
            col = T.c2 if o["Q"] >= 0 else T.c1
            D.rect(g, x - r * 4, y - r * 4, r * 8, r * 8, Gradient("radial", (x, y, r * 4), [(0, alpha(col, 0.35)), (1, alpha(col, 0))]))
            D.circle(g, x, y, r, col, T.fg if sel is o else None, 2)
            D.text(g, "+" if o["Q"] >= 0 else "−", x, y + 1, "#ffffff", size=max(11, r * 1.3), align="center", bold=True)
            D.text(g, f"{'+' if o['Q'] >= 0 else ''}{fmt(o['Q'], 0)} nC", x + r + 4, y - r - 4, col, size=11)
        for k in S["objs"]:
            if k["kind"] != "link":
                continue
            b, a, ax, ay = ends(k)
            if not b:
                continue
            A, Bp = P(ax, ay), P(b["x"], b["y"])
            col = T.accent if sel is k else T.fg
            if k["mode"] == "spring":
                D.spring(g, A[0], A[1], Bp[0], Bp[1], 12, 6, col, 1.6)
            else:
                D.line(g, A[0], A[1], Bp[0], Bp[1], col, 4 if k["mode"] == "rod" else 1.4)
            if not a:
                D.rect(g, A[0] - 9, A[1] - 3, 18, 6, alpha(T.axis, 0.5))
                D.circle(g, A[0], A[1], 3.5, T.stage, col, 1.6)

    def draw_body(g, b, x, y, ang, ghost):
        r = b["r"] * view.sx
        col = T.c[b["ci"] % 6]
        if ghost:
            g.global_alpha = 0.28
        if b["shape"] == "ball":
            gr = Gradient("radial", (x, y, r, x - r * 0.35, y - r * 0.35), [(0, alpha("#ffffff", 0.85 * (0.28 if ghost else 1))),
                                                                          (0.25, alpha(col, 0.28 if ghost else 1)), (1, alpha(col, 0.28 if ghost else 1))])
            D.circle(g, x, y, r, gr, alpha(T.fg, 0.5), 1)
        else:
            g.save()
            g.translate(x, y)
            g.rotate(-ang)
            D.rrect(g, -r, -r, 2 * r, 2 * r, min(4, r * 0.2), col, alpha(T.fg, 0.45), 1)
            if not ghost and r > 12:
                D.text(g, f"{fmt(b['m'], 1)}kg", 0, 0, "#ffffff", size=min(12, r * 0.55), align="center", mono=True)
            g.restore()
        if b["q"] and not ghost:
            D.text(g, "+" if b["q"] > 0 else "−", x, y + 1, "#ffffff", size=max(11, r), align="center", bold=True)
        g.global_alpha = 1

    def draw_bodies(g):
        sel = S["sel"]
        bs = [o for o in S["objs"] if o["kind"] == "body"]
        if show["trail"]:
            for b in bs:
                tl = b.get("trail") or []
                if len(tl) < 2:
                    continue
                D.poly(g, [P(*p) for p in tl] + [P(b["x"], b["y"])], None, alpha(T.c[b["ci"] % 6], 0.55), 1.6, close=False)
        if show["strobe"]:
            for b in bs:
                for s in b.get("strobe") or []:
                    draw_body(g, b, view.X(s[0]), view.Y(s[1]), s[2], True)
        for b in bs:
            if b["shape"] == "block" and b.get("touch"):
                tgt = math.atan2(b["touch"][0], b["touch"][1])
                d = tgt - b["ang"]
                d = math.atan2(math.sin(d), math.cos(d))
                b["ang"] += d * 0.35
            x, y = P(b["x"], b["y"])
            draw_body(g, b, x, y, b["ang"], False)
            if sel is b:
                g.dash = [4, 3]
                D.circle(g, x, y, b["r"] * view.sx + 5, None, T.accent, 1.6)
                g.dash = []
        if show["vel"]:
            for b in bs:
                v = math.hypot(b["vx"], b["vy"])
                if v < 0.02:
                    continue
                view.vec(b["x"], b["y"], b["x"] + b["vx"] * VS, b["y"] + b["vy"] * VS, T.c1, 2)
                if sel is b:
                    view.label(f"v={fmt(v, 2)} m/s", b["x"] + b["vx"] * VS, b["y"] + b["vy"] * VS, T.c1, size=11)
        b = sel if sel and sel["kind"] == "body" else None
        if b and not S["run"]:
            hx, hy = v_handle(b)
            px, py = P(hx, hy)
            if math.hypot(b["vx"], b["vy"]) < 0.02:
                D.line(g, view.X(b["x"]), view.Y(b["y"]), px, py, alpha(T.c1, 0.6), 1.2, [3, 3])
                D.text(g, "拖动设置初速度", px + 10, py, T.muted, size=11)
            D.circle(g, px, py, 6.5, T.stage, T.c1, 2)
        if b and show["force"]:
            draw_forces(b)

    def draw_forces(b):
        F = []

        def mag(v):
            return math.hypot(v[0], v[1]) if v else 0
        if env["grav"]:
            F.append(("G", 0, -b["m"] * env["g"], T.c2))
        for key_, n, col in (("N", "N", T.c1), ("F", "f", T.c4), ("Tn", "T", T.c3), ("fs", "F弹", T.c3), ("fe", "F电", T.c5), ("fg", "F引", T.c2)):
            v = b.get(key_)
            if v and mag(v) > 1e-3:
                F.append((n, v[0], v[1], col))
        if b["q"] and b.get("bz"):
            fx, fy = b["q"] * b["vy"] * b["bz"], -b["q"] * b["vx"] * b["bz"]
            if math.hypot(fx, fy) > 1e-3:
                F.append(("F洛", fx, fy, T.c6))
        if not F:
            return
        mx = max(math.hypot(f[1], f[2]) for f in F)
        k = 2.4 / mx
        for n, fx, fy, col in F:
            view.vec(b["x"], b["y"], b["x"] + fx * k, b["y"] + fy * k, col, 2.4)
            view.label(f"{n} {fmt(math.hypot(fx, fy), 2)} N", b["x"] + fx * k, b["y"] + fy * k, col, dx=6, dy=-8 if fy > 0 else 10, size=11, bold=True)

    def graph(g):
        sel = S["sel"]
        b = sel if sel and sel["kind"] == "body" else None
        if not b or show["graph"] == "none" or len(b.get("hist") or []) < 3:
            return
        w, h = min(300, c.w * 0.44), 112
        x, y = c.w - w - 12, 36
        D.rrect(g, x - 34, y - 22, w + 44, h + 46, 6, alpha(T.surface, 0.92), T.line, 1)
        H = b["hist"]
        t0 = max(0, H[-1][0] - 20)
        rows = [r for r in H if r[0] >= t0]

        def pts(i):
            return [(r[0], r[i]) for r in rows]
        if show["graph"] == "v":
            ser = [{"pts": pts(3), "color": T.c1}, {"pts": pts(1), "color": T.c2, "dash": [4, 3], "w": 1.4}, {"pts": pts(2), "color": T.c3, "dash": [4, 3], "w": 1.4}]
            title, leg = "v–t（m/s）", [("|v|", T.c1), ("vₓ", T.c2), ("v_y", T.c3)]
        elif show["graph"] == "x":
            ser = [{"pts": pts(4), "color": T.c1}, {"pts": pts(5), "color": T.c2}]
            title, leg = "x–t、y–t（m）", [("x", T.c1), ("y", T.c2)]
        else:
            ser = [{"pts": pts(6), "color": T.c1}, {"pts": pts(7), "color": T.c2}, {"pts": [(r[0], r[6] + r[7]) for r in rows], "color": T.c4, "w": 2.2}]
            title, leg = "能量–t（J）", [("Eₖ", T.c1), ("Eₚ", T.c2), ("总", T.c4)]
        allv = [p[1] for s in ser for p in s["pts"]]
        lo = min([0] + allv)
        hi = max(allv + [lo + 1e-6])
        D.chart(g, x, y, w, h, ser, title=title, xl="t/s", ymin=lo - (hi - lo) * 0.05, ymax=hi + (hi - lo) * 0.08)
        for i, (n, col) in enumerate(leg):
            D.text(g, n, x + w - 8 - (len(leg) - 1 - i) * 38, y - 10, col, size=11, align="right", bold=True)

    def v_handle(b):
        v = math.hypot(b["vx"], b["vy"])
        return (b["x"] + b["r"] + 0.7, b["y"]) if v < 0.02 else (b["x"] + b["vx"] * VS, b["y"] + b["vy"] * VS)

    def home_view():   # 地面贴近底部：按画布宽高比确定显示范围
        k = c.h / max(1, c.w)
        view.home = [-1, 23, -1.4, -1.4 + 24 * k] if 24 * k >= 14.6 else [11 - 7.3 / k, 11 + 7.3 / k, -1.4, 13.2]
        if not S["panned"]:
            view.r = list(view.home)

    def draw():
        home_view()
        view.fit()
        sel = S["sel"]
        # 底图（网格、场区域、地面）只随视图和场变化：缓存成一张图
        fkey = (tuple(round(v, 4) for v in (view.x0, view.x1, view.y0, view.y1)), env["ground"], env["gmu"],
                sel["id"] if sel and sel["kind"] in ("ef", "bf") else None,
                tuple((o["id"], o["x"], o["y"], o["w"], o["h"], o.get("E"), o.get("dir"), o.get("B"), o.get("circ"))
                      for o in S["objs"] if o["kind"] in ("ef", "bf")))

        def base():
            view.begin(xl="x/m", yl="y/m")
            draw_fields(c.g)
            draw_ground(c.g)
        L.cached(fkey, base)
        g = c.g
        draw_static(g)
        draw_bodies(g)
        graph(g)
        simT = S["simT"]
        tl = f"t = {fmt(simT, 2)} s" + ("" if S["run"] else "　已暂停" if simT > 0 else "　按「播放」开始")
        tx = clamp(view.X(0) + 44, 8, c.w * 0.4)
        D.rrect(g, tx, 6, D.measure(tl, 13, True, True) + 16, 22, 5, alpha(T.surface, 0.9), T.line, 1)
        D.text(g, tl, tx + 8, 17, T.fg if S["run"] else T.muted, size=13, mono=True, bold=True)
        if not any(o["kind"] == "body" for o in S["objs"]):
            D.text(g, "从左侧选一个示例，或拖入小球、木块", c.w / 2, c.h * 0.4, T.muted, size=15, align="center")
    L.on_draw(draw)

    # ---- 交互
    def hit_test(px, py):
        wx, wy = view.ix(px), view.iy(py)
        sel = S["sel"]

        def near(x, y, r=9):
            return math.hypot(px - view.X(x), py - view.Y(y)) < r
        if sel and sel["kind"] == "body" and not S["run"]:
            hx, hy = v_handle(sel)
            if near(hx, hy, 10):
                return {"t": "vel", "o": sel}
        if sel and sel["kind"] in ("ef", "bf") and near(sel["x"] + sel["w"], sel["y"] + sel["h"], 11):
            return {"t": "size", "o": sel}
        if sel and sel["kind"] == "ramp":
            _fx, tx, ty = ramp_pts(sel)
            if near(tx, ty, 10):
                return {"t": "rtop", "o": sel}
        if sel and sel["kind"] == "wall":
            if near(sel["x1"], sel["y1"]):
                return {"t": "w1", "o": sel}
            if near(sel["x2"], sel["y2"]):
                return {"t": "w2", "o": sel}
        bs = [o for o in S["objs"] if o["kind"] == "body"]
        for b in reversed(bs):
            if math.hypot(wx - b["x"], wy - b["y"]) < b["r"] + 6 / view.sx:
                return {"t": "body", "o": b, "ox": wx - b["x"], "oy": wy - b["y"]}
        for k in S["objs"]:
            if k["kind"] == "link" and k["a"] is None and near(k["ax"], k["ay"], 10):
                return {"t": "anchor", "o": k}
        for o in S["objs"]:
            if o["kind"] == "pc" and near(o["x"], o["y"], 0.25 * view.sx + 6):
                return {"t": "move", "o": o}
        for o in S["objs"]:
            if o["kind"] == "pulley" and near(o["x"], o["y"], max(7, 0.3 * view.sx) + 5):
                return {"t": "move", "o": o}
        for o in S["objs"]:
            if o["kind"] == "planet" and math.hypot(wx - o["x"], wy - o["y"]) < o["R"] + 4 / view.sx:
                return {"t": "move", "o": o}
        for o in S["objs"]:
            if o["kind"] == "arc":
                d = math.hypot(wx - o["x"], wy - o["y"])
                if (abs(d - o["R"]) * view.sx < 8 and on_arc(o, math.atan2(wy - o["y"], wx - o["x"]) * 180 / PI)) or near(o["x"], o["y"], 8):
                    return {"t": "move", "o": o}

        def dseg(x1, y1, x2, y2):
            ax, ay, bx, by = view.X(x1), view.Y(y1), view.X(x2), view.Y(y2)
            dx, dy = bx - ax, by - ay
            t = clamp(((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1), 0, 1)
            return math.hypot(px - ax - t * dx, py - ay - t * dy)
        for k in S["objs"]:
            if k["kind"] == "link":
                b, _a, ax, ay = ends(k)
                if b and dseg(ax, ay, b["x"], b["y"]) < 7:
                    return {"t": "link", "o": k}
        for o in S["objs"]:
            if o["kind"] == "wall" and dseg(o["x1"], o["y1"], o["x2"], o["y2"]) < 8:
                return {"t": "move", "o": o}
        for o in S["objs"]:
            if o["kind"] == "ramp":
                fx, tx, ty = ramp_pts(o)
                lo, hi = min(fx, tx), max(fx, tx)
                if lo <= wx <= hi and 0 <= wy <= ty * abs(wx - fx) / (abs(tx - fx) or 1):
                    return {"t": "move", "o": o}
        for o in reversed(S["objs"]):
            if o["kind"] in ("ef", "bf") and inside(o, wx, wy):
                return {"t": "move", "o": o}
        return None

    def down(x, y, h):
        if h and h != "__pan":
            select(h["o"])
            if h["t"] == "body" and S["run"]:
                S["held"] = h["o"]
                S["lastP"] = (view.ix(x), view.iy(y), time.perf_counter() * 1000)

    def drag(h, x, y, dx, dy):
        o = h["o"]
        wx, wy = view.ix(x), view.iy(y)
        ddx, ddy = dx / view.sx, -dy / view.sy

        def sn(v):
            return round(v * 10) / 10
        t = h["t"]
        if t == "body":
            o["x"] = wx - h["ox"]
            o["y"] = max(o["r"] if env["ground"] else -1e9, wy - h["oy"])
            if S["run"]:
                now = time.perf_counter() * 1000
                lp = S["lastP"] or (wx, wy, now - 16)
                S["held"] = o
                dtp = max(1, now - lp[2]) / 1000
                o["vx"] = lerp(o["vx"], (wx - lp[0]) / dtp, 0.5)
                o["vy"] = lerp(o["vy"], (wy - lp[1]) / dtp, 0.5)
                S["lastP"] = (wx, wy, now)
            else:
                edited()
        elif t == "vel":
            vx, vy = (wx - o["x"]) / VS, (wy - o["y"]) / VS
            if math.hypot(vx, vy) < 0.3:
                vx = vy = 0
            o["vx"], o["vy"] = round(vx * 10) / 10, round(vy * 10) / 10
            edited()
            refresh_props()
        elif t == "size":
            o["w"], o["h"] = max(1, sn(wx - o["x"])), max(1, sn(wy - o["y"]))
        elif t == "rtop":
            d2 = wx - o["x"]
            o["dir"] = 1 if d2 >= 0 else -1
            o["ang"] = clamp(round(math.atan2(max(0.1, wy), abs(d2)) * 180 / PI), 5, 75)
            o["len"] = clamp(sn(math.hypot(d2, wy)), 1, 24)
            edited()
        elif t == "w1":
            o["x1"], o["y1"] = sn(wx), sn(wy)
            edited()
        elif t == "w2":
            o["x2"], o["y2"] = sn(wx), sn(wy)
            edited()
        elif t == "anchor":
            o["ax"], o["ay"] = wx, wy
            edited()
        elif t == "link":
            if o["a"] is None:
                o["ax"] += ddx
                o["ay"] += ddy
                edited()
        elif t == "move":
            if o["kind"] == "ramp":
                o["x"] += ddx
            elif o["kind"] == "wall":
                o["x1"] += ddx
                o["x2"] += ddx
                o["y1"] += ddy
                o["y2"] += ddy
            else:
                o["x"] += ddx
                o["y"] += ddy
            if o["kind"] == "pulley" and not S["run"]:
                A, Bb = by_id(o["a"]), by_id(o["b"])
                if A and Bb:
                    o["len"] = math.hypot(A["x"] - o["x"], A["y"] - o["y"]) + math.hypot(Bb["x"] - o["x"], Bb["y"] - o["y"])
            edited()

    def up(h):
        if not h or h == "__pan":
            return
        if h["t"] == "body" and S["held"] is h["o"]:
            S["held"] = None
        if h["t"] == "anchor":
            k = h["o"]
            b = next((o for o in S["objs"] if o["kind"] == "body" and o["id"] != k["b"] and math.hypot(o["x"] - k["ax"], o["y"] - k["ay"]) < o["r"] + 0.2), None)
            if b:
                k["a"] = b["id"]
                B.toast(f"{LN[k['mode']]}的另一端连到了{b['name']}")
        if h["t"] == "move" and h["o"]["kind"] == "wall":
            o = h["o"]
            for kk in ("x1", "x2", "y1", "y2"):
                o[kk] = round(o[kk] * 10) / 10
        if S["sel"] is h["o"]:
            refresh_props()

    def click(_x, _y, h):
        if not h or h == "__pan":
            select(None)

    def dbl(_x, _y):
        S["panned"] = False

    def wheel(_x, _y, _s):
        S["panned"] = True
        return False
    L.interact(c, view=view, pan=lambda: S.__setitem__("panned", True), hit=hit_test, down=down, drag=drag, up=up, click=click, dbl=dbl, wheel=wheel)

    def on_key(k, _e):
        if k in ("Delete", "Backspace") and S["sel"]:
            remove(S["sel"])
            return True
        if k == " ":
            toggle_run()
            return True
        return False
    L.on_key(on_key)

    # ---- 添加与删除
    def place(o):
        S["objs"].append(o)
        if o["kind"] == "body":
            o["trail"], o["strobe"], o["hist"] = [], [], []
        edited()
        select(o)
        return o

    def remove(o):
        S["objs"] = [q for q in S["objs"] if q is not o and not (q["kind"] in ("link", "pulley") and o["id"] in (q.get("b"), q.get("a")))]
        if S["sel"] is o:
            S["sel"] = None
        edited()
        inspect()

    def add_link(mode, at_=None):
        b = None
        if at_:
            best = 3
            for o in S["objs"]:
                if o["kind"] == "body":
                    d = math.hypot(o["x"] - at_[0], o["y"] - at_[1])
                    if d < best:
                        best, b = d, o
        elif S["sel"] and S["sel"]["kind"] == "body":
            b = S["sel"]
        if not b:
            B.toast(f"先选中一个物体，或把{LN[mode]}拖到物体上")
            return
        if at_ and math.hypot(at_[0] - b["x"], at_[1] - b["y"]) > 1.2:
            ax, ay = at_
        elif mode == "spring":
            ax, ay = b["x"] - 3, b["y"]
        else:
            ax, ay = b["x"], b["y"] + 4
        d = round(math.hypot(b["x"] - ax, b["y"] - ay), 2)
        place(mk("link", mode=mode, name=nm(LN[mode]), ax=ax, ay=ay, b=b["id"], L0=d, len=d))
        B.toast(f"{LN[mode]}一端连在{b['name']}上，另一端固定；拖动固定端可以移动，拖到另一个物体上就连接两个物体")

    def add_pulley(at_=None):   # 把离放置点最近的两个物体用跨过定滑轮的细绳连起来
        bs = [o for o in S["objs"] if o["kind"] == "body"]
        if len(bs) < 2:
            B.toast("定滑轮要连接两个物体：先放两个小球或木块")
            return
        p0 = at_ or ((bs[0]["x"] + bs[1]["x"]) / 2, max(bs[0]["y"], bs[1]["y"]) + 3)
        bs.sort(key=lambda q: math.hypot(q["x"] - p0[0], q["y"] - p0[1]))
        A, Bb = bs[0], bs[1]
        ln = round(math.hypot(A["x"] - p0[0], A["y"] - p0[1]) + math.hypot(Bb["x"] - p0[0], Bb["y"] - p0[1]), 2)
        place(mk("pulley", x=p0[0], y=p0[1], a=A["id"], b=Bb["id"], len=ln))
        B.toast(f"细绳跨过定滑轮连接{A['name']}和{Bb['name']}；拖动滑轮可以移动它")

    def centre():
        view.fit()
        return round((view.x0 + view.x1) / 2), round(view.y0 + (view.y1 - view.y0) * 0.62)

    def at(x, y):
        view.fit()
        return view.ix(x), view.iy(y)

    # ---- 示例场景
    def preset(fn):
        S.update(run=False, objs=[], sel=None, held=None, snap=None, simT=0.0)
        cnt.clear()
        env.update(grav=True, g=9.8, ground=True, gmu=0.0, air=0.0)
        show.update(trail=True, vel=True, force=False, strobe=False, lines=True, graph="v")
        first = fn()
        S["panned"] = False
        for o in S["objs"]:
            if o["kind"] == "body":
                o["trail"], o["strobe"], o["hist"] = [], [], []
        S["sel"] = first or next((o for o in S["objs"] if o["kind"] == "body"), None)
        inspect()
        L.draw()

    O = S  # 简写

    def p_proj():
        show["strobe"] = True
        O["objs"].append(ball(x=1, y=10, vx=5))

    def p_oblique():
        show["strobe"] = True
        O["objs"].append(ball(x=1, y=0.4, vx=7, vy=10))

    def p_ramp():
        r = mk("ramp", x=13, dir=-1, ang=30, len=11, mu=0.2)
        O["objs"].append(r)
        _fx, tx, ty = ramp_pts(r)
        a = 30 * PI / 180
        O["objs"].append(block(x=tx + 0.9 * math.cos(a) + math.sin(a) * 0.5, y=ty - 0.9 * math.sin(a) + math.cos(a) * 0.5))
        show["force"] = True

    def p_pend():
        L0, a = 7, 20 * PI / 180
        b = ball(x=11 + L0 * math.sin(a), y=11.5 - L0 * math.cos(a), e=0.3)
        O["objs"] += [b, mk("link", mode="rope", name=nm("细绳"), ax=11, ay=11.5, b=b["id"], len=L0)]
        show["graph"] = "E"

    def p_vcircle():
        L0 = 3.5
        b = ball(x=11, y=6.5 - L0, vx=round(math.sqrt(5 * 9.8 * L0) + 0.3, 1), e=0)
        O["objs"] += [b, mk("link", mode="rope", name=nm("细绳"), ax=11, ay=6.5, b=b["id"], len=L0)]
        env["ground"] = False
        show["force"] = True

    def p_spring():
        O["objs"].append(mk("wall", x1=2, y1=0, x2=2, y2=3))
        b = block(x=7.5, y=0.5, m=1)
        O["objs"] += [b, mk("link", mode="spring", name=nm("弹簧"), ax=2, ay=0.5, b=b["id"], k=20, L0=4)]
        show["graph"] = "x"

    def p_belt():
        O["objs"].append(mk("wall", name=nm("传送带"), x1=1, y1=1.2, x2=21, y2=1.2, mu=0.3, belt=4))
        O["objs"].append(block(x=2.5, y=1.7))
        show.update(graph="v", force=True)

    def p_belt2():
        O["objs"].append(mk("wall", name=nm("传送带"), x1=2, y1=1, x2=19, y2=8, mu=0.6, belt=3))
        a = math.atan2(7, 17)
        O["objs"].append(block(x=3 - math.sin(a) * 0.5, y=1 + math.tan(a) + math.cos(a) * 0.5))
        show.update(graph="v", force=True)

    def p_coll():
        O["objs"] += [ball(x=4, y=0.5, r=0.5, vx=4, e=1), ball(x=12, y=0.6, r=0.6, m=2, e=1)]
        show["graph"] = "v"

    def nograv():
        env.update(grav=False, ground=False)

    def p_edefl():
        nograv()
        O["objs"] += [mk("ef", x=6, y=1, w=12, h=10, E=6, dir=270), ball(x=1, y=9, vx=6, q=1)]
        show["strobe"] = True

    def p_bcirc():
        nograv()
        O["objs"] += [mk("bf", x=3, y=-1, w=19, h=13, B=1), ball(x=6, y=5, vy=4, q=1)]
        show["force"] = True

    def p_pm():
        nograv()
        O["objs"] += [mk("bf", x=8, y=-1, w=14, h=13, B=-1), ball(x=1, y=6, vx=4, q=1), ball(x=1, y=5, vx=4, q=-1, ci=0)]

    def p_vsel():
        nograv()
        O["objs"] += [mk("ef", x=5, y=2, w=13, h=8, E=4, dir=270), mk("bf", x=5, y=2, w=13, h=8, B=-1),
                      ball(x=1, y=6, vx=4, q=1, r=0.3), ball(x=1, y=7.5, vx=6, q=1, r=0.3), ball(x=1, y=4.5, vx=2.5, q=1, r=0.3)]

    def p_coul():
        nograv()
        O["objs"] += [mk("pc", x=11, y=6, Q=-20), ball(x=11, y=10, vx=round(math.sqrt(9 * 20 / 4), 2), q=1, r=0.3)]
        show["graph"] = "E"

    def p_air():
        env["air"] = 2
        O["objs"] += [ball(x=7, y=12, m=1, e=0), ball(x=14, y=12, m=4, r=0.5, e=0)]
        show["graph"] = "v"

    def p_up():
        show["strobe"] = True
        O["objs"].append(ball(x=8, y=0.4, vy=13, e=0))
        show["graph"] = "v"

    def p_half():
        O["objs"] += [mk("arc", x=14, y=3, R=3, a0=-90, a1=90), ball(x=3, y=0.3, r=0.3, vx=12.5, e=0.1)]
        show.update(strobe=True, force=True)

    def p_loop():
        O["objs"] += [mk("arc", x=7, y=7, R=7, a0=180, a1=270), mk("arc", x=15, y=2.5, R=2.5, a0=-90, a1=220), ball(x=0.35, y=6.9, r=0.3, e=0.1)]
        show.update(graph="E", force=True)

    def p_atwood():
        A, Bb = block(x=10.3, y=6, m=1, r=0.45), block(x=11.7, y=6, m=2, r=0.45)
        O["objs"] += [A, Bb, mk("pulley", x=11, y=11.5, a=A["id"], b=Bb["id"], len=round(math.hypot(0.7, 5.5) * 2, 3))]
        show.update(graph="v", force=True)
        return Bb

    def p_conn():
        O["objs"].append(mk("wall", name=nm("桌面"), x1=1, y1=6, x2=13, y2=6))
        A, Bb = block(x=4, y=6.5, m=2), ball(x=13.6, y=3, m=1, r=0.4, e=0)
        O["objs"] += [A, Bb, mk("pulley", x=13.6, y=6.5, a=A["id"], b=Bb["id"], len=9.6 + 3.5)]
        show.update(graph="v", force=True)
        return A

    def p_sat():
        nograv()
        O["objs"].append(mk("planet", x=11, y=6, GM=400, R=1.5))
        s = ball(name=nm("卫星"), x=11, y=10, vx=-10, r=0.25, e=1)
        O["objs"] += [s, ball(name=nm("卫星"), x=11, y=2, vx=11, r=0.25, e=1, ci=3)]
        show["graph"] = "E"
        return s

    def p_ms():
        nograv()
        O["objs"] += [mk("ef", x=0.5, y=9, w=3.5, h=2.2, E=8, dir=0), mk("bf", x=4, y=-1.5, w=18, h=14, B=2),
                      ball(x=0.8, y=10, q=1, m=1, r=0.18, nc=True), ball(x=0.8, y=10.6, q=1, m=2, r=0.18, nc=True, ci=3)]
        show["lines"] = False

    def p_focus():
        nograv()
        O["objs"].append(mk("bf", x=7, y=2, w=8, h=8, B=1, circ=True))
        for k in range(-2, 3):
            O["objs"].append(ball(x=1, y=6 + 1.5 * k, vx=4, q=1, r=0.15, nc=True, ci=k + 2))

    PRE = [
        ["平抛运动", "频闪照片：水平匀速、竖直自由落体", p_proj], ["斜抛运动", "最高点速度水平", p_oblique],
        ["斜面上的木块", "μ < tanθ 时加速下滑", p_ramp], ["单摆", "摆长 7 m，偏角 20°", p_pend],
        ["竖直面内的圆周运动", "最低点 v₀ = √(5gL) 时恰好过最高点", p_vcircle], ["弹簧振子", "光滑水平面，弹簧原长 4 m，拉长 1.5 m 后释放", p_spring],
        ["水平传送带", "先加速，共速后匀速", p_belt], ["倾斜传送带", "μ > tanθ 时物体被带上去", p_belt2],
        ["两球碰撞", "弹性碰撞，m₂ = 2m₁", p_coll], ["电场中的偏转", "类平抛：qE 竖直向下", p_edefl],
        ["磁场中的圆周运动", "r = mv/(qB)", p_bcirc], ["正负粒子在磁场中", "偏转方向相反", p_pm],
        ["速度选择器", "v = E/B 时做匀速直线运动", p_vsel], ["点电荷周围的圆周运动", "库仑力提供向心力", p_coul],
        ["空气阻力中的下落", "f = kv，最终匀速：v = mg/k", p_air], ["竖直上抛", "上升、下落时间相等", p_up],
        ["半圆轨道", "从最高点飞出后做平抛", p_half], ["竖直圆轨道（过山车）", "h ≥ 2.5R 才能通过最高点", p_loop],
        ["阿特伍德机", "a = (m₂−m₁)g/(m₁+m₂)", p_atwood], ["连接体", "光滑桌面 + 定滑轮：a = m₂g/(m₁+m₂)", p_conn],
        ["卫星的轨道", "圆轨道与椭圆轨道", p_sat], ["质谱仪", "加速后进入磁场，r = √(2mU/q)/B", p_ms],
        ["圆形磁场：磁聚焦", "轨迹半径 = 磁场半径时汇聚于一点", p_focus], ["空白场景", "只有地面", lambda: None],
    ]

    # ---- 检查器
    def select(o):
        if S["sel"] is not o:
            S["sel"] = o
            inspect()
        L.draw()

    def inspect():
        B.clear_panel()
        ui.clear()
        L.group("运行")
        ui["play"] = L.button("暂停" if S["run"] else "播放", toggle_run, True)

        def one(_b):
            if not S["snap"]:
                S["snap"] = save()
            frame(0.02 * S["speed"])
            L.draw()
        L.button("单步", one)
        L.button("重置", reset)
        L.seg("倍速", [[0.25, "¼×"], [0.5, "½×"], [1.0, "1×"], [2.0, "2×"]], S["speed"], lambda v: S.__setitem__("speed", float(v)))
        L.note("空格键播放/暂停（先点一下画布）。运行中可以用鼠标抓住物体甩出去。")
        if S["sel"]:
            props(S["sel"])
        L.group("环境")

        def env_set(k):
            return lambda v: (env.__setitem__(k, v), edited())
        L.check("重力", env["grav"], env_set("grav"))
        L.slider("重力加速度 g", 1, 20, 0.1, env["g"], env_set("g"), "m/s²")
        L.check("地面", env["ground"], env_set("ground"))
        L.slider("地面摩擦因数 μ", 0, 1, 0.05, env["gmu"], env_set("gmu"))
        L.slider("空气阻力系数（f = kv）", 0, 2, 0.05, env["air"], env_set("air"), "kg/s")
        L.group("显示")

        def sh(k):
            return lambda v: (show.__setitem__(k, v), L.draw())
        L.check("轨迹", show["trail"], sh("trail"))
        L.check("速度矢量", show["vel"], sh("vel"))
        L.check("受力分析（选中的物体）", show["force"], sh("force"))
        L.check("频闪照片（每 0.1 s）", show["strobe"], sh("strobe"))
        L.check("点电荷的电场线", show["lines"], sh("lines"))
        L.select("图像（选中的物体）", [["none", "不显示"], ["v", "v–t 图"], ["x", "x–t、y–t 图"], ["E", "能量–时间图"]], show["graph"], sh("graph"))
        L.note("拖动空白处平移，滚轮缩放，双击复位视图。")
        L.panel_lay.addStretch(1)

    def props(o):
        def ed(f):
            def cb(v):
                f(v)
                edited()
                refresh_props()
                L.draw()
            return cb

        def st(k, conv=float):
            return ed(lambda v: o.__setitem__(k, conv(v)))
        kd = o["kind"]
        L.group(o.get("name") or "")
        if kd == "body":
            L.slider("质量 m", 0.1, 10, 0.1, o["m"], st("m"), "kg")
            L.slider("半径" if o["shape"] == "ball" else "半边长", 0.1, 1.5, 0.05, o["r"], st("r"), "m")
            L.slider("电荷量 q", -5, 5, 0.1, o["q"], st("q"), "C")
            L.slider("恢复系数 e（1 为弹性碰撞）", 0, 1, 0.05, o["e"], st("e"))
            ui["vx"] = L.slider("速度 vₓ", -30, 30, 0.1, o["vx"], st("vx"), "m/s")
            ui["vy"] = L.slider("速度 v_y", -30, 30, 0.1, o["vy"], st("vy"), "m/s")
            ui["out"] = L.out()
            L.button("删除", lambda _b: remove(o))
            L.button("清除轨迹", lambda _b: o.update(trail=[], strobe=[]))
        elif kd == "ramp":
            L.slider("倾角 θ", 5, 75, 1, o["ang"], st("ang"), "°")
            L.slider("斜面长度", 1, 24, 0.1, o["len"], st("len"), "m")
            L.slider("动摩擦因数 μ", 0, 1, 0.01, o["mu"], st("mu"))
            L.seg("朝向", [[1, "右端高"], [-1, "左端高"]], o["dir"], st("dir", int))
            ui["out"] = L.out()
            L.note("拖动斜面平移，拖动顶点调整倾角和长度。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "wall":
            L.slider("摩擦因数 μ", 0, 1, 0.05, o["mu"], st("mu"))
            if o.get("belt") is not None:
                L.slider("带速（正值：从第一个端点向第二个端点）", -10, 10, 0.1, o["belt"], st("belt"), "m/s")
            L.note("物体与带面有相对滑动时受滑动摩擦力 μN，与带面共速后一起运动。拖动两端可以把传送带倾斜放置。" if o.get("belt") is not None else "拖动两端的圆点改变位置和方向。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "link":
            if o["mode"] == "spring":
                L.slider("劲度系数 k", 1, 500, 1, o["k"], st("k"), "N/m")
                L.slider("原长 L₀", 0.2, 12, 0.1, o["L0"], st("L0"), "m")
                L.slider("阻尼", 0, 5, 0.1, o["damp"], st("damp"), "kg/s")
            else:
                L.slider("绳长" if o["mode"] == "rope" else "杆长", 0.2, 12, 0.1, o["len"], st("len"), "m")
            ui["out"] = L.out()
            if o["a"] is not None:
                def unfix(_b):
                    a = by_id(o["a"])
                    if a:
                        o["ax"], o["ay"] = a["x"], a["y"] + 1.5
                    o["a"] = None
                    edited()
                    inspect()
                L.button("改为一端固定", unfix)
            L.button("删除", lambda _b: remove(o))
        elif kd == "ef":
            L.slider("场强 E", 0, 100, 0.5, o["E"], st("E"), "N/C")
            L.slider("方向（与 x 轴夹角）", 0, 345, 15, o["dir"], st("dir"), "°")
            L.slider("宽度", 1, 30, 0.5, o["w"], st("w"), "m")
            L.slider("高度", 1, 20, 0.5, o["h"], st("h"), "m")
            L.note("拖动区域平移，拖动右上角改变大小。只对带电物体起作用。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "arc":
            L.slider("半径 R", 0.5, 10, 0.1, o["R"], st("R"), "m")

            def a0(v):
                o["a0"] = v
                if o["a1"] <= v:
                    o["a1"] = v + 10
            L.slider("起始角（与 x 轴夹角，逆时针）", -180, 360, 5, o["a0"], ed(a0), "°")
            L.slider("终止角", -180, 540, 5, o["a1"], ed(lambda v: o.__setitem__("a1", max(o["a0"] + 10, v))), "°")
            L.slider("动摩擦因数 μ", 0, 1, 0.01, o["mu"], st("mu"))
            ui["out"] = L.out()
            L.note("拖动圆弧或圆心平移。−90° 是最低点，90° 是最高点；起始角 −90°、终止角 90° 就是开口向左的半圆轨道。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "pulley":
            L.slider("绳长", 0.5, 30, 0.1, o["len"], st("len"), "m")
            ui["out"] = L.out()
            L.note("轻绳、光滑轻质滑轮：两侧绳的拉力大小相等。拖动滑轮移动位置（绳长随之更新）。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "planet":
            L.slider("GM（引力常量 × 质量）", 20, 3000, 10, o["GM"], st("GM"), "m³/s²")
            L.slider("半径 R", 0.3, 4, 0.1, o["R"], st("R"), "m")
            ui["out"] = L.out()
            L.note("万有引力 F = GMm/r²，星球固定不动。通常关掉「重力」和「地面」再用。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "bf":
            L.seg("形状", [[0, "矩形"], [1, "圆形"]], 1 if o.get("circ") else 0, ed(lambda v: o.__setitem__("circ", bool(int(v)))))
            L.seg("方向", [[1, "⊙ 垂直纸面向外"], [-1, "⊗ 垂直纸面向里"]], 1 if o["B"] >= 0 else -1, ed(lambda v: o.__setitem__("B", abs(o["B"]) * int(v))))
            L.slider("磁感应强度 B", 0, 10, 0.05, abs(o["B"]), ed(lambda v: o.__setitem__("B", (1 if o["B"] >= 0 else -1) * v)), "T")
            L.slider("宽度", 1, 30, 0.5, o["w"], st("w"), "m")
            L.slider("高度", 1, 20, 0.5, o["h"], st("h"), "m")
            L.note("洛伦兹力 F = qvB，始终与速度垂直。")
            L.button("删除", lambda _b: remove(o))
        elif kd == "pc":
            L.slider("电荷量 Q", -100, 100, 1, o["Q"], st("Q"), "nC")
            L.note("库仑力 F = kQq/r²，k = 9×10⁹ N·m²/C²。点电荷固定不动。")
            L.button("删除", lambda _b: remove(o))
        refresh_props()

    def refresh_props():
        o = S["sel"]
        out = ui.get("out")
        if not o or not out:
            return
        kd = o["kind"]
        g_ = env["g"]
        try:
            if kd == "body":
                v = math.hypot(o["vx"], o["vy"])
                Ek, Eg, Es, Ee, Ep = energy(o)
                rows = [["位置", f"({fmt(o['x'], 2)}, {fmt(o['y'], 2)}) m"], ["速度大小", f"{fmt(v, 3)} m/s"],
                        ["速度方向", f"{fmt(round(math.atan2(o['vy'], o['vx']) * 1800 / PI) / 10, 1)}°" if v > 0.01 else "—"], ["动能 Eₖ", f"{fmt(Ek, 3)} J"]]
                if env["grav"]:
                    rows.append(["重力势能（地面为零）", f"{fmt(Eg, 3)} J"])
                if Es:
                    rows.append(["弹性势能", f"{fmt(Es, 3)} J"])
                if Ee:
                    rows.append(["电势能", f"{fmt(Ee, 3)} J"])
                if Ep:
                    rows.append(["引力势能（无穷远处为零）", f"{fmt(Ep, 3)} J"])
                rows += [["机械能（含以上势能）", f"{fmt(Ek + Eg + Es + Ee + Ep, 3)} J"], ["动量 p", f"{fmt(o['m'] * v, 3)} kg·m/s"]]
                pl = next((q for q in S["objs"] if q["kind"] == "planet"), None)
                if pl:
                    r = math.hypot(o["x"] - pl["x"], o["y"] - pl["y"]) or 1e-9
                    rows += [["到星球中心 r", f"{fmt(r, 3)} m"], ["该处圆轨道速度 √(GM/r)", f"{fmt(math.sqrt(pl['GM'] / r), 3)} m/s"],
                             ["该处逃逸速度 √(2GM/r)", f"{fmt(math.sqrt(2 * pl['GM'] / r), 3)} m/s"]]
                if o["q"]:
                    Ex, Ey, Bz = fields_at(o["x"], o["y"])
                    if Bz:
                        rows += [["回旋半径 mv/(|q|B)", f"{fmt(o['m'] * v / abs(o['q'] * Bz), 3)} m"], ["周期 2πm/(|q|B)", f"{fmt(TAU * o['m'] / abs(o['q'] * Bz), 3)} s"]]
                    if Ex or Ey:
                        rows.append(["所在处场强", f"{fmt(math.hypot(Ex, Ey), 3)} N/C"])
                out.set(rows)
                for k in ("vx", "vy"):
                    s = ui.get(k)
                    if s and not s.sl.isSliderDown():
                        s.set(round(o[k] * 100) / 100, True)
            elif kd == "ramp":
                a = o["ang"] * PI / 180
                out.set([["tan θ", fmt(math.tan(a), 3)], ["μ < tan θ 时", "物体会下滑"], ["光滑时下滑加速度 g sin θ", f"{fmt(g_ * math.sin(a), 3)} m/s²"],
                         ["有摩擦时 g(sin θ − μcos θ)", f"{fmt(max(0, g_ * (math.sin(a) - o['mu'] * math.cos(a))), 3)} m/s²"]])
            elif kd == "arc":
                out.set([["最低点", f"y = {fmt(o['y'] - o['R'], 2)} m"], ["小球恰好通过最高点（内侧）", "v顶 = √(gR)"], ["此时最低点速度", f"√(5gR) = {fmt(math.sqrt(5 * g_ * o['R']), 3)} m/s"]])
            elif kd == "pulley":
                A, Bb = by_id(o["a"]), by_id(o["b"])
                if not A or not Bb:
                    return
                T1 = math.hypot(*A["Tn"]) if A.get("Tn") else 0
                out.set([["连接", f"{A['name']}（{fmt(A['m'], 1)} kg）、{Bb['name']}（{fmt(Bb['m'], 1)} kg）"], ["绳的拉力", f"{fmt(T1, 3)} N" if S["run"] or S["simT"] else "—"],
                         ["两侧都竖直悬挂时 a", f"{fmt(abs(A['m'] - Bb['m']) * g_ / (A['m'] + Bb['m']), 3)} m/s²"]])
            elif kd == "planet":
                out.set([["表面重力加速度 GM/R²", f"{fmt(o['GM'] / o['R'] ** 2, 3)} m/s²"], ["第一宇宙速度 √(GM/R)", f"{fmt(math.sqrt(o['GM'] / o['R']), 3)} m/s"],
                         ["第二宇宙速度 √(2GM/R)", f"{fmt(math.sqrt(2 * o['GM'] / o['R']), 3)} m/s"]])
            elif kd == "link":
                b, _a, ax, ay = ends(o)
                if not b:
                    return
                d = math.hypot(b["x"] - ax, b["y"] - ay)
                if o["mode"] == "spring":
                    out.set([["当前长度", f"{fmt(d, 3)} m"], ["形变量 x", f"{fmt(d - o['L0'], 3)} m"], ["弹力 kx", f"{fmt(o['k'] * abs(d - o['L0']), 3)} N"],
                             ["振动周期 2π√(m/k)", f"{fmt(TAU * math.sqrt(b['m'] / o['k']), 3)} s"]])
                else:
                    out.set([["当前长度", f"{fmt(d, 3)} m"], ["拉力", f"{fmt(math.hypot(*b['Tn']), 3)} N" if b.get("Tn") else "—"],
                             ["小角度周期 2π√(L/g)", f"{fmt(TAU * math.sqrt(o['len'] / g_), 3)} s"]])
        except RuntimeError:   # 检查器刚被重建
            pass
    L.every(150, refresh_props)

    # ---- 素材栏
    def obj(icon, label, sub, make):
        return {"icon": icon, "label": label, "sub": sub, "click": lambda: place(make(*centre())), "drop": lambda px, py: place(make(*at(px, py)))}

    def lnk(mode, icon, sub):
        return {"icon": icon, "label": LN[mode], "sub": sub, "click": lambda: add_link(mode), "drop": lambda px, py: add_link(mode, at(px, py))}

    def planet_at(x, y):
        env.update(grav=False, ground=False)
        B.toast("已关闭重力和地面，物体只受星球的引力")
        o = mk("planet", x=x, y=y)
        return o
    B.palette([
        {"title": "示例场景", "items": [{"icon": ICON["demo"], "label": n, "sub": s, "click": (lambda f=f: preset(f))} for n, s, f in PRE]},
        {"title": "物体", "items": [
            obj(ICON["ball"], "小球", "1 kg", lambda x, y: ball(x=x, y=max(0.4, y))),
            obj(ICON["block"], "木块", "1 kg", lambda x, y: block(x=x, y=max(0.5, y))),
            obj(ICON["pos"], "带正电小球", "q = +1 C", lambda x, y: ball(x=x, y=max(0.4, y), q=1, ci=1)),
            obj(ICON["neg"], "带负电小球", "q = −1 C", lambda x, y: ball(x=x, y=max(0.4, y), q=-1, ci=0))]},
        {"title": "器材", "items": [
            obj(ICON["ramp"], "斜面", "可调倾角和摩擦", lambda x, y: mk("ramp", x=x - 4)),
            obj(ICON["wall"], "竖直挡板", "拖动两端调整", lambda x, y: mk("wall", x1=x, y1=0, x2=x, y2=3)),
            obj(ICON["belt"], "传送带", "带速和摩擦可调", lambda x, y: mk("wall", name=nm("传送带"), x1=x - 4, y1=max(0.6, y - 1), x2=x + 4, y2=max(0.6, y - 1), mu=0.3, belt=3)),
            obj(ICON["board"], "木板", "可倾斜放置", lambda x, y: mk("wall", name=nm("木板"), x1=x - 3, y1=max(0.5, y - 1), x2=x + 3, y2=max(0.5, y - 1), mu=0.2)),
            obj(ICON["arc"], "圆弧轨道", "半圆、圆环、四分之一圆弧", lambda x, y: mk("arc", x=x, y=max(3, y))),
            lnk("spring", ICON["spring"], "连到物体上"), lnk("rope", ICON["rope"], "只能拉，不能推"), lnk("rod", ICON["rod"], "长度不变"),
            {"icon": ICON["pulley"], "label": "定滑轮", "sub": "连接最近的两个物体", "click": lambda: add_pulley(), "drop": lambda px, py: add_pulley(at(px, py))}]},
        {"title": "场", "items": [
            obj(ICON["ef"], "匀强电场", "方向可调", lambda x, y: mk("ef", x=x - 5, y=max(0, y - 4))),
            obj(ICON["bo"], "匀强磁场 ⊙", "垂直纸面向外", lambda x, y: mk("bf", x=x - 5, y=max(0, y - 4), B=1)),
            obj(ICON["bi"], "匀强磁场 ⊗", "垂直纸面向里", lambda x, y: mk("bf", x=x - 5, y=max(0, y - 4), B=-1)),
            obj(ICON["bc"], "圆形磁场区域", "⊙，半径可调", lambda x, y: mk("bf", x=x - 4, y=y - 4, w=8, h=8, B=1, circ=True)),
            obj(ICON["planet"], "星球", "万有引力 F = GMm/r²", planet_at),
            obj(ICON["qp"], "正点电荷", "Q = +10 nC", lambda x, y: mk("pc", x=x, y=y, Q=10)),
            obj(ICON["qn"], "负点电荷", "Q = −10 nC", lambda x, y: mk("pc", x=x, y=y, Q=-10))]},
    ])
    B.tips([
        ("怎么用", ["左侧先选一个<b>示例场景</b>，或者把物体、器材、场拖进画面。", "点选物体后，拖动它旁边的蓝色圆点设定初速度；右侧可以改质量、电荷量、恢复系数等。",
                  "按<b>播放</b>运行，<b>重置</b>回到播放前的状态。打开<b>频闪照片</b>、<b>受力分析</b>和 <b>v–t 图</b>对照讲解。",
                  "弹簧、细绳、轻杆拖到物体上即可连接；把它的固定端拖到另一个物体上，就把两个物体连在一起。"]),
        ("模型说明", ["物体按质点处理（只平动、不滚动），木块不转动，碰撞时按接触面法线方向计算，摩擦力取 μN。", "绳、杆、滑轮都是轻质的，滑轮光滑，同一根绳上拉力处处相等；星球固定不动。",
                   "电荷量、场强取便于观察的理想化数值；带电物体之间的库仑力不计。", "积分步长约 1.5 ms，长时间运行会有很小的能量误差。"]),
    ])

    # ---- 主循环
    def tick(dt):
        if S["run"]:
            frame(dt * S["speed"])
        L.draw()
    L.loop(tick)
    preset(PRE[0][2])
    def snapshot_transfer():
        return state_graph.encode(dict(S=S,env=env,show=show,cnt=cnt,view=view.r))
    def restore_transfer(snapshot):
        data=state_graph.decode(snapshot)
        S.clear(); S.update(data["S"])
        env.clear(); env.update(data["env"])
        show.clear(); show.update(data["show"])
        cnt.clear(); cnt.update(data["cnt"])
        view.r=list(data["view"])
        S["run"]=False
        S["held"]=None
        inspect()
        L.draw()
    B.transfer(snapshot_transfer,restore_transfer)
