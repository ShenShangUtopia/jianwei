"""物理场景搭建的底层（由 legacy/lab-phys.js 改写）：相机、画笔、物体类型注册表。

物体、参数、状态都用 NS（可以 o.p.m、o.s.v 这样写），和旧引擎一一对应，便于照着改写。
当前场景 S、相机 cam、画笔 g 放在模块级 E 里，每帧由 scene.py 设置。
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF

from ...design.tokens import T, alpha as _alpha, qc
from ...kit.core import PI, TAU, clamp
from ...kit.draw import D

DT = 1 / 240            # 固定子步
ORBIT_UNIT = 1e7        # 引力场景：1 世界单位 = 10^7 m（≈ 1.6 个地球半径）
ORBIT_SCALE = 1200      # 轨道演示的时间倍率（读数是真实量纲）


class NS(dict):
    """dict + 属性访问；缺的键读出来是 None（旧引擎大量依赖 undefined 为假）。"""

    def __getattr__(self, k):
        return self.get(k)

    def __setattr__(self, k, v):
        self[k] = v

    def __deepcopy__(self, memo):
        import copy
        return NS({k: copy.deepcopy(v, memo) for k, v in self.items()})


class _C:
    """旧引擎的 JW.C 调色板，映射到 2.0 令牌（昼夜自动跟随）。"""
    ink = property(lambda s: T.fg)
    ink2 = property(lambda s: T.math)
    accent = property(lambda s: T.phys)
    jade = property(lambda s: T.chem)
    gold = property(lambda s: T.c4)
    soft = property(lambda s: T.muted)
    faint = property(lambda s: T.axis)
    paper = property(lambda s: T.stage)
    card = property(lambda s: T.surface)
    line = property(lambda s: T.line)
    line2 = property(lambda s: T.grid)
    grid = property(lambda s: T.grid)
    grid2 = property(lambda s: T.grid2)
    data = property(lambda s: [T.math, T.c1, T.c3, T.c4, T.c5])


C = _C()


class _Engine:
    g = None
    S: NS = None
    cam: NS = NS(x=0.0, y=1.4, scale=70.0)
    w = 800
    h = 600


E = _Engine()


def rad(d):
    return d * PI / 180


def deg(r):
    return r * 180 / PI


def sign(v):
    return (v > 0) - (v < 0)


def num(v, d=2):
    s = f"{v:.{max(0, d)}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def fmt(v, d=2):
    return num(v, 2 if d is None else d) if isinstance(v, (int, float)) and math.isfinite(v) else "—"


def fmt_e(v, d=2):
    """科学计数：1.23e+7 → 1.23×10⁷。"""
    if not (isinstance(v, (int, float)) and math.isfinite(v)):
        return "—"
    if v == 0:
        return "0"
    e = math.floor(math.log10(abs(v)))
    sup = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")
    return f"{num(v / 10 ** e, d)}×10{str(e).translate(sup)}"


def px(x):
    return (x - E.cam.x) * E.cam.scale + E.w / 2


def py(y):
    return E.h / 2 - (y - E.cam.y) * E.cam.scale


def wx(p):
    return (p - E.w / 2) / E.cam.scale + E.cam.x


def wy(p):
    return (E.h / 2 - p) / E.cam.scale + E.cam.y


def sp(m):
    return m * E.cam.scale


def half_w():
    return E.w / (2 * E.cam.scale)


def half_h():
    return E.h / (2 * E.cam.scale)


def with_alpha(col, a):
    return _alpha(col, clamp(a, 0, 1))


def line_w(pts, color=None, w=None, dash=None, alpha=None):
    if not pts or len(pts) < 2:
        return
    col = color if color is not None else C.ink
    if alpha is not None:
        col = _alpha(qc(col), qc(col).alphaF() * alpha)
    g = E.g
    g.line_cap, g.line_join = "round", "round"
    D.poly(g, [(px(p[0]), py(p[1])) for p in pts], None, col, w or 1.5, close=False) if not dash else _dash_poly(pts, col, w or 1.5, dash)
    g.line_cap, g.line_join = "butt", "miter"


def _dash_poly(pts, col, w, dash):
    g = E.g
    g.begin_path()
    for i, p in enumerate(pts):
        (g.line_to if i else g.move_to)(px(p[0]), py(p[1]))
    g.stroke_style, g.line_width, g.dash = col, w, dash
    g.stroke()
    g.dash = []


def poly_w(pts, fill=None, stroke=None, w=None, alpha=None, dash=None):
    if not pts or len(pts) < 2:
        return
    g = E.g
    scr = [(px(p[0]), py(p[1])) for p in pts]
    if fill is not None:
        D.poly(g, scr, _alpha(qc(fill), qc(fill).alphaF() * alpha) if alpha is not None else fill)
    if stroke is not None:
        g.begin_path()
        for i, p in enumerate(scr):
            (g.line_to if i else g.move_to)(p[0], p[1])
        g.close_path()
        g.stroke_style, g.line_width, g.dash, g.line_join = stroke, w or 1.4, dash or [], "round"
        g.stroke()
        g.dash, g.line_join = [], "miter"


def circle_p(X, Y, R, fill=None, stroke=None, w=None, dash=None):
    if not (math.isfinite(X) and math.isfinite(Y) and math.isfinite(R)) or R <= 0:
        return
    g = E.g
    if dash and stroke is not None:
        if fill is not None:
            D.circle(g, X, Y, R, fill)
        g.begin_path()
        g.arc(X, Y, R, 0, TAU)
        g.stroke_style, g.line_width, g.dash = stroke, w or 1.4, dash
        g.stroke()
        g.dash = []
    else:
        D.circle(g, X, Y, R, fill, stroke if stroke is not None and w != 0 else None, w or 1.4)


def circle_w(x, y, r_m, fill=None, stroke=None, w=None, dash=None):
    circle_p(px(x), py(y), max(1.2, sp(r_m)), fill, stroke, w, dash)


def rect_w(x, y, w_m, h_m, fill=None, stroke=None, lw=None, dash=None):
    g = E.g
    X, Y, W, H = px(x), py(y + h_m), sp(w_m), sp(h_m)
    if fill is not None:
        D.rect(g, X, Y, W, H, fill)
    if stroke is not None:
        p = g._pen(stroke, lw or 1.4, dash or [])
        g.p.setPen(p)
        from PySide6.QtCore import Qt
        g.p.setBrush(Qt.BrushStyle.NoBrush)
        g.p.drawRect(QRectF(X, Y, W, H))


def round_rect_p(X, Y, W, H, r, fill=None, stroke=None, lw=None, dash=None):
    r = max(0.0, min(r, abs(W) / 2, abs(H) / 2))
    g = E.g
    if dash and stroke is not None:
        if fill is not None:
            D.rrect(g, X, Y, W, H, r, fill)
        g.begin_path()
        g.round_rect(X, Y, W, H, r)
        g.stroke_style, g.line_width, g.dash = stroke, lw or 1.4, dash
        g.stroke()
        g.dash = []
    else:
        D.rrect(g, X, Y, W, H, r, fill, stroke, lw or 1.4)


def arrow_p(X, Y, X2, Y2, color=None, w=None, head=None):
    dx, dy = X2 - X, Y2 - Y
    ln = math.hypot(dx, dy)
    if ln < 1.2:
        return
    col = color if color is not None else C.ink2
    a = math.atan2(dy, dx)
    h = min(head or 8, ln * 0.45)
    g = E.g
    g.line_cap = "round"
    D.line(g, X, Y, X2, Y2, col, w or 1.6)
    g.line_cap = "butt"
    D.poly(g, [(X2, Y2), (X2 - h * math.cos(a - 0.42), Y2 - h * math.sin(a - 0.42)), (X2 - h * math.cos(a + 0.42), Y2 - h * math.sin(a + 0.42))], col)


def txt_p(X, Y, s, color=None, size=11, weight=600, align="left", mono=False, halo=True, halo_color=None, base="middle"):
    """halo：文字描一圈背景色，压在曲线上也看得清（少量文字用，省去 strokeText）。"""
    g = E.g
    bold = (weight or 600) >= 600
    if halo:
        hc = halo_color if halo_color is not None else E.S.bg
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            D.text(g, s, X + dx, Y + dy, hc, size=size, bold=bold, mono=mono, align=align, base=base)
    D.text(g, s, X, Y, color if color is not None else C.ink, size=size, bold=bold, mono=mono, align=align, base=base)


def txt(x, y, s, ox=0, oy=0, **o):
    txt_p(px(x) + ox, py(y) + oy, s, **o)


def arrow_w(x, y, dx, dy, color=None, w=None, head=None, label=None):
    X, Y, X2, Y2 = px(x), py(y), px(x + dx), py(y + dy)
    if math.hypot(X2 - X, Y2 - Y) < 1.2:
        return
    arrow_p(X, Y, X2, Y2, color, w, head)
    if label:
        right = X2 >= X
        txt_p(X2 + (5 if right else -5), Y2 + (-10 if dy >= 0 else 11), label, color=color, size=10, weight=700, align="left" if right else "right")


def arc_w(cx, cy, r_m, a0, a1, color, w=None, dash=None):
    pts = [(cx + r_m * math.cos(a0 + (a1 - a0) * i / 40), cy + r_m * math.sin(a0 + (a1 - a0) * i / 40)) for i in range(41)]
    if dash:
        _dash_poly(pts, color, w or 1.2, dash)
    else:
        D.poly(E.g, [(px(p[0]), py(p[1])) for p in pts], None, color, w or 1.2, close=False)


def tag_p(X, Y, s, color, align=None):
    w = D.measure(s, 10, True) + 12
    h = 17
    x = X - (w / 2 if align == "center" else w if align == "right" else 0)
    round_rect_p(x, Y - h / 2, w, h, 5, with_alpha(E.S.bg, 0.86), with_alpha(color, 0.5), 1)
    D.text(E.g, s, x + 6, Y + 0.5, color, size=10, bold=True)


def push_trail(o, x, y, dt, gap=0.05):
    if not E.S.show.trail:
        return
    if o.trail is None:
        o.trail = []
    o._tt = (o._tt or 0) + dt
    if o._tt < gap:
        return
    o._tt = 0
    o.trail.append((x, y))
    if len(o.trail) > 1600:
        o.trail.pop(0)


def draw_trail(o, color=None, a=None):
    if not E.S.show.trail or not o.trail or len(o.trail) < 2:
        return
    g = E.g
    g.line_cap, g.line_join = "round", "round"
    D.poly(g, [(px(p[0]), py(p[1])) for p in o.trail], None, with_alpha(color if color is not None else C.accent, 0.5 if a is None else a), 1.6, close=False)
    g.line_cap, g.line_join = "butt", "miter"


def vel_arrow(x, y, vx, vy, label=None, color=None, k=None):
    if not E.S.show.vectors:
        return
    s = 0.24 if k is None else k
    arrow_w(x, y, vx * s, vy * s, color if color is not None else C.accent, 1.8, 8, label)


def force_arrow(x, y, ax, ay, label=None, color=None):
    if not E.S.show.vectors:
        return
    arrow_w(x, y, ax * 0.06, ay * 0.06, color if color is not None else C.jade, 1.5, 7, label)


def rot_rect_p(cx, cy, ang, X, Y, W, H, r, fill=None, stroke=None, lw=None):
    """在 (cx, cy) 处旋转 ang 后画圆角矩形（屏幕坐标）。"""
    g = E.g
    g.save()
    g.translate(cx, cy)
    g.rotate(ang)
    round_rect_p(X, Y, W, H, r, fill, stroke, lw)
    g.restore()


# ---------------------------------------------------------------- 类型注册表
TYPES: dict = {}
GROUPS = [("kin", "运动学"), ("mech", "力学"), ("elec", "电学"), ("mag", "磁场"), ("efield", "电场"), ("optics", "光学"), ("wave", "波"), ("grav", "万有引力")]


def param(k, label, unit, mn, mx, step, dflt, dec):
    return NS(k=k, label=label, unit=unit, min=mn, max=mx, step=step, **{"def": dflt}, dec=dec)


def define(typ, name, group, z, hit, desc, params, init=None, step=None, draw=None, read=None, bounds=None, on_param=None, snap_y=None, sel_ring=None, **extra):
    TYPES[typ] = NS(type=typ, name=name, group=group, z=z, hit=hit, desc=desc, params=[p if isinstance(p, NS) else param(*p) for p in params], init=init, step=step, draw=draw, read=read,
                    bounds=bounds, on_param=on_param, snapY=snap_y, selRing=sel_ring, **extra)
    return TYPES[typ]


def types_of_group(g):
    return [k for k, v in TYPES.items() if v.group == g]


def _unused():
    _ = (QPointF, deg)
