"""自由工作台 · 物理场景搭建（由 legacy/lab-phys.js 改写）：场景、1/240 s 定步长仿真、预设、时间轴与检查器。

物体类型在 scene_types1 / scene_types2，画笔在 scene_core。场景状态留在模块里（E.S），切走再回来不丢。
"""
from __future__ import annotations

import math

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QPainter, QPainterPath
from PySide6.QtWidgets import QFileDialog, QFrame, QHBoxLayout, QLabel, QPushButton, QSlider

from ...design.tokens import T as TK, css
from ...kit.bench import bench
from ...kit import state_graph
from ...kit.core import clamp
from ...kit.draw import D
from . import scene_types1, scene_types2  # noqa: F401  注册物体类型
from .scene_core import (C, DT, E, GROUPS, NS, TYPES, fmt, half_h, half_w, line_w, px, py, round_rect_p, sp, tag_p, txt, txt_p, types_of_group, with_alpha, wx, wy)
from .scene_types1 import center_body, circuit_info

ART = """<svg viewBox="0 0 160 110"><g fill="none" stroke="currentColor" stroke-width="2.2">
  <path d="M80 12q10 43 0 86q-10-43 0-86z" fill="currentColor" fill-opacity=".1"/>
  <path d="M14 34L80 55L146 78M14 55H146M14 76L80 55L146 32" stroke-width="1.5" opacity=".75"/>
  <path d="M8 55H152" stroke-width="1" stroke-dasharray="3 4" opacity=".45"/></g>
  <path d="M14 34v42" stroke="#d99a00" stroke-width="4" stroke-linecap="round"/>
  <path d="M140 46v18" stroke="currentColor" stroke-width="2.6"/><path d="M134 50l6-6 6 6" fill="none" stroke="currentColor" stroke-width="2"/></svg>"""


def _ic(s):
    return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{s}</svg>'


GROUP_ICON = {
    "kin": _ic('<path d="M3 18c5-12 13-12 18 0" stroke-dasharray="2 3"/><circle cx="16" cy="9" r="2.4" fill="#d6522b" stroke="none"/>'),
    "mech": _ic('<path d="M3 20h18L3 7z"/><rect x="7" y="9" width="5" height="4" transform="rotate(35 9 11)" fill="#2c6fd1" stroke="none"/>'),
    "elec": _ic('<path d="M3 12h7M14 12h7M10 7v10"/><path d="M14 4v16"/>'),
    "mag": _ic('<rect x="3" y="9" width="18" height="6"/><path d="M12 9v6"/><path d="M3 5c6-3 12-3 18 0"/>'),
    "efield": _ic('<circle cx="12" cy="12" r="3.5" fill="#d6522b" stroke="none"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>'),
    "optics": _ic('<path d="M12 3q4 9 0 18q-4-9 0-18z"/><path d="M2 12h20" stroke-dasharray="2 3"/>'),
    "wave": _ic('<path d="M2 12c2.5-6 5-6 7 0s4.500 6 6.500 0 4-6 6.500 0"/>'),
    "grav": _ic('<circle cx="12" cy="12" r="4" fill="#3d7fc4" stroke="none"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(-20 12 12)"/>'),
    "preset": _ic('<path d="M5 18c4-12 10-12 14 0" stroke-dasharray="2 2.5"/><circle cx="5" cy="18" r="2" fill="currentColor"/>'),
}


def default_show():
    return NS(grid=True, scale=True, vectors=True, trail=True, field=True, rays=True, ground=False)


def new_scene():
    return NS(objects=[], sel=None, t=0.0, playing=False, speed=1, g=9.8, show=default_show(), preset="projectile", bg="#ffffff", seq=0)


def spawn(typ, x, y, pr=None):
    Ty = TYPES.get(typ)
    if not Ty:
        return None
    S = E.S
    S.seq += 1
    o = NS(id=f"ob{S.seq}", type=typ, x=x, y=y, p=NS(), s=NS(), visible=True, trail=[], _tt=0)
    for d in Ty.params:
        o.p[d.k] = d["def"]
    for k, v in (pr or {}).items():
        if k in o.p:
            o.p[k] = v
    S.objects.append(o)   # 先进场景：卫星的 init 要在场景里找中心天体
    if Ty.init:
        Ty.init(o)
    return o


def sim_step(dt):
    S = E.S
    S.t += dt
    for o in S.objects:
        if o.visible:
            st = TYPES[o.type].step
            if st:
                st(o, dt)


def reinit(o):
    o.trail, o._tt = [], 0
    init = TYPES[o.type].init
    if init:
        init(o)


PRESETS = [
    NS(id="freefall", name="自由落体", select="projectile", cam=(0, 3.4, 66), show=dict(ground=True), build=lambda: spawn("projectile", -0.6, 7.4, dict(v0=0, th=90, m=1))),
    NS(id="incline", name="斜面下滑", select="incline", cam=(0.4, 1.05, 92), show=dict(ground=True), build=lambda: spawn("incline", -1.9, 0, dict(th=32, mu=0.15, m=1, L=3.4, v0=0))),
    NS(id="projectile", name="平抛运动", select="projectile", cam=(-1.3, 2.6, 104), show=dict(ground=True), build=lambda: spawn("projectile", -3.4, 3.0, dict(v0=7, th=0, m=1))),
    NS(id="pendulum", name="单摆", select="pendulum", cam=(0, 1.35, 120), show=dict(ground=False), build=lambda: spawn("pendulum", 0, 2.9, dict(L=1.45, th0=40, m=0.5, damp=0.01))),
    NS(id="circular", name="圆周运动", select="circular", cam=(0, 1.5, 115), show=dict(ground=False), build=lambda: spawn("circular", 0, 1.5, dict(R=1.15, v=2.2, m=0.5))),
    NS(id="collision", name="两球碰撞", select="collision", cam=(0, 0.95, 112), show=dict(ground=True), build=lambda: spawn("collision", -1.4, 0.3, dict(m1=2, m2=1, v1=2.2, v2=-1.2, e=0.9))),
    NS(id="bfield", name="磁场回旋", select="particle", cam=(0.1, 1.9, 96), show=dict(ground=False),
       build=lambda: (spawn("bfield", 0.15, 1.9, dict(B=0.8, dir=-1, w=3.4, h=2.8)), spawn("particle", -2.45, 1.05, dict(q=1, m=1, v0=1.2, th=0)))),
    NS(id="plates", name="平行板偏转", select="particle", cam=(0, 1.95, 150), show=dict(ground=False),
       build=lambda: (spawn("plates", 0.2, 1.8, dict(U=10, d=0.6, len=1.6, pol=1)), spawn("particle", -2.1, 2.05, dict(q=0.12, m=1, v0=2.4, th=0)))),
    NS(id="lens", name="凸透镜成像", select="convex", cam=(0.2, 1.55, 104), show=dict(ground=False, vectors=False),
       build=lambda: (spawn("lightsrc", -1.6, 1.45, dict(h=0.55)), spawn("convex", 0.2, 1.45, dict(f=0.9)), spawn("screen", 2.0, 1.45, dict(L=1.4)))),
    NS(id="mirror", name="平面镜反射", select="mirror", cam=(0.2, 1.5, 108), show=dict(ground=False, vectors=False),
       build=lambda: (spawn("mirror", 0.2, 1.5, dict(L=2.2, ang=0)), spawn("lightsrc", -1.4, 1.05, dict(h=0.55)))),
    NS(id="wave", name="绳波传播", select="string", cam=(0, 1.35, 92), show=dict(ground=False, vectors=False),
       build=lambda: (spawn("wavesrc", -2.6, 1.16, dict(f=1.2, A=0.3)), spawn("string", -2.6, 1.16, dict(L=5.2, lam=1.1)))),
    NS(id="orbit", name="卫星圆轨道", select="satellite", cam=(0, 1.8, 118), show=dict(ground=False, field=False),
       build=lambda: (spawn("body", 0, 1.8, dict(M=1)), spawn("satellite", 1.75, 1.8, dict(v=0)))),
]


def nice_step(target):
    mag = 10 ** math.floor(math.log10(target))
    n = target / mag
    return (1 if n < 1.5 else 2 if n < 3.5 else 5 if n < 7.5 else 10) * mag


def draw_grid(g):
    cam = E.cam
    step = nice_step(68 / cam.scale)
    x1, y1 = cam.x + half_w(), cam.y + half_h()
    path = QPainterPath()
    x = math.floor((cam.x - half_w()) / step) * step
    while x <= x1 + 1e-9:
        X = round(px(x)) + 0.5
        path.moveTo(X, 0)
        path.lineTo(X, E.h)
        x += step
    y = math.floor((cam.y - half_h()) / step) * step
    while y <= y1 + 1e-9:
        Y = round(py(y)) + 0.5
        path.moveTo(0, Y)
        path.lineTo(E.w, Y)
        y += step
    aa = g.p.testRenderHint(QPainter.RenderHint.Antialiasing)
    g.p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
    g.p.strokePath(path, g._pen(C.grid, 1, []))
    g.p.setRenderHint(QPainter.RenderHint.Antialiasing, aa)
    ax = px(0) if abs(cam.x) < half_w() else None
    ay = py(0) if abs(cam.y) < half_h() else None
    axis = with_alpha(C.ink2, 0.3)
    if ax is not None:
        D.line(g, ax, 0, ax, E.h, axis, 1)
    if ay is not None:
        D.line(g, 0, ay, E.w, ay, axis, 1)
    lab = step * max(1, round(150 / (step * cam.scale)))
    if ay is not None:
        ly = clamp(ay + 10, 10, E.h - 8)
        x = math.ceil((cam.x - half_w()) / lab) * lab
        while x <= x1:
            X = px(x)
            if abs(x) >= 1e-9 and 18 <= X <= E.w - 18:
                D.text(g, fmt(x, 1), X, ly, C.faint, size=9.5, align="center")
            x += lab
    if ax is not None:
        lx = clamp(ax - 5, 22, E.w - 4)
        y = math.ceil((cam.y - half_h()) / lab) * lab
        while y <= y1:
            Y = py(y)
            if abs(y) >= 1e-9 and 13 <= Y <= E.h - 13:
                D.text(g, fmt(y, 1), lx, Y, C.faint, size=9.5, align="right")
            y += lab


def draw_ground():
    cam = E.cam
    if abs(cam.y) > half_h() + 0.3:
        return
    step = nice_step(68 / cam.scale)
    line_w([(cam.x - half_w(), 0), (cam.x + half_w(), 0)], with_alpha(C.ink, 0.42), 1.4)
    x = math.ceil((cam.x - half_w()) / step) * step
    hatch = with_alpha(C.ink2, 0.4)
    while x <= cam.x + half_w():
        line_w([(x, 0), (x - 0.1, -0.1)], hatch, 1)
        x += step
    txt(cam.x + half_w() - 0.15, -0.24, "地面", align="right", size=9.5, color=C.faint)


class SceneBench:
    def __init__(self, B):
        self.B, self.L = B, B.L
        self.c = B.L.canvas()
        self.ui = NS()
        self.drag = None
        self.seeking = False
        self.was_playing = False
        self.coord = ""
        self.bar_dark = None
        self._bar()

    # ---- 时间轴（浮在画布左下角的小条）
    def _bar(self):
        stage = self.L.stage
        bar = self.bar = QFrame(stage)
        bar.setObjectName("timebar")
        h = QHBoxLayout(bar)
        h.setContentsMargins(10, 5, 10, 5)
        h.setSpacing(6)
        self.t_label = QLabel("t = 0 s")
        self.t_label.setMinimumWidth(78)
        h.addWidget(self.t_label)

        def btn(text, fn, tip):
            b = QPushButton(text)
            b.setObjectName("btn")
            b.setToolTip(tip)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False: fn())
            h.addWidget(b)
            return b
        self.play_btn = btn("播放", self.toggle_play, "播放 / 暂停（空格，先点一下画布）")
        btn("单步", self.step_once, "单步（→）")
        btn("复位", self.reset_scene, "复位到 t = 0")
        self.speed_btn = btn("1×", self.cycle_speed, "播放倍速")
        sl = self.time_slider = QSlider(Qt.Orientation.Horizontal)
        sl.setRange(0, 400)
        sl.setMinimumWidth(180)
        sl.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        sl.sliderPressed.connect(self._seek_start)
        sl.valueChanged.connect(self._seek_move)
        sl.sliderReleased.connect(self._seek_end)
        h.addWidget(sl, 1)
        h.addWidget(QLabel("20 s"))
        bar.show()

    def _place_bar(self):
        if self.bar_dark != TK.dark:
            self.bar_dark = TK.dark
            self.bar.setStyleSheet(f"QFrame#timebar{{background:{css(TK.raised, 0.94)};border:1px solid {TK.line};border-radius:10px;}}"
                                   f"QLabel{{color:{TK.soft};font-size:12px;background:transparent;}}")
        w = clamp(E.w - 170, 300, 640)
        h = self.bar.sizeHint().height()
        self.bar.setGeometry(150, E.h - h - 8, int(w), h)

    def _seek_start(self):
        self.seeking = True
        self.was_playing = E.S.playing
        E.S.playing = False

    def _seek_move(self, v):
        if self.seeking:
            self.seek_to(v * 0.05)
            self.refresh_dynamic()
            self.L.draw()

    def _seek_end(self):
        if self.seeking:
            self.seeking = False
            E.S.playing = self.was_playing
            self.refresh_dynamic()

    def toggle_play(self):
        E.S.playing = not E.S.playing
        self.refresh_dynamic()

    def step_once(self):
        E.S.playing = False
        for _ in range(12):
            sim_step(DT)
        self.refresh_dynamic()
        self.L.draw()

    def reset_scene(self):
        S = E.S
        S.t, S.playing = 0.0, False
        for o in S.objects:
            reinit(o)
        self.refresh_all()
        self.L.draw()

    def cycle_speed(self):
        lst = [0.25, 0.5, 1, 2, 4]
        S = E.S
        S.speed = lst[(lst.index(S.speed) + 1) % len(lst)] if S.speed in lst else 1
        self.refresh_dynamic()

    def seek_to(self, target):
        S = E.S
        target = clamp(target, 0, 20)
        S.t = 0.0
        for o in S.objects:
            reinit(o)
        guard = 0
        while S.t < target - 1e-9 and guard < 9000:
            sim_step(min(DT, target - S.t))
            guard += 1

    def tick(self, dt):
        self._sync_size()
        S = E.S
        if S.playing:
            remain, guard = dt * S.speed, 0
            while remain > 1e-9 and guard < 900:
                h = min(DT, remain)
                sim_step(h)
                remain -= h
                guard += 1
            self.refresh_dynamic()
        self.L.draw()

    def _sync_size(self):
        E.w, E.h = self.c.w, self.c.h

    def refresh_dynamic(self):
        S = E.S
        try:
            self.play_btn.setText("暂停" if S.playing else "播放")
            self.t_label.setText(f"t = {fmt(S.t, 2)} s")
            self.speed_btn.setText(f"{S.speed}×")
            if not self.seeking:
                self.time_slider.blockSignals(True)
                self.time_slider.setValue(round(min(20, S.t) / 0.05))
                self.time_slider.blockSignals(False)
        except RuntimeError:
            pass

    # ---- 增删改
    def add_object(self, typ, at=None):
        Ty = TYPES.get(typ)
        S = E.S
        self._sync_size()
        x, y = E.cam.x, E.cam.y
        if at:
            x, y = at
        elif Ty.snapY is not None:
            y = Ty.snapY
        if any(abs(o.x - x) < 0.18 and abs(o.y - y) < 0.18 for o in S.objects):
            x += 0.7
        o = spawn(typ, x, y)
        if typ == "satellite" and not center_body(o):
            spawn("body", x - 1.7, y)
            Ty.init(o)
        S.sel, S.preset = o, ""
        self.refresh_all()
        self.L.draw()
        self.B.toast("已添加 " + Ty.name, ms=1500)
        return o

    def remove_object(self, o):
        S = E.S
        if o in S.objects:
            S.objects = [q for q in S.objects if q is not o]
            if S.sel is o:
                S.sel = None
            S.preset = ""
            self.refresh_all()
            self.L.draw()
            self.B.toast("已删除 " + TYPES[o.type].name, ms=1500)

    def duplicate(self, o):
        S = E.S
        n = spawn(o.type, o.x + 0.6, o.y + 0.15)
        n.p.update(o.p)
        reinit(n)
        S.sel, S.preset = n, ""
        self.refresh_all()
        self.L.draw()

    def set_param(self, o, k, v):
        Ty = TYPES[o.type]
        o.p[k] = v
        o.trail, o._tt = [], 0
        if Ty.on_param:
            Ty.on_param(o, k)
        elif Ty.init:
            Ty.init(o)
        E.S.preset = ""
        self.update_readouts()
        self.L.draw()

    def load_preset(self, pid, autoplay=False):
        P = next((p for p in PRESETS if p.id == pid), None)
        if not P:
            return
        S = E.S
        S.objects, S.sel, S.t, S.playing = [], None, 0.0, False
        S.g = 9.8
        S.show = NS({**default_show(), **P.show})
        E.cam = NS(x=float(P.cam[0]), y=float(P.cam[1]), scale=float(P.cam[2]))
        P.build()
        S.preset = pid
        S.sel = next((o for o in S.objects if o.type == P.select), S.objects[0] if S.objects else None)
        S.playing = autoplay
        self.refresh_all()
        self.L.draw()

    def clear_scene(self):
        S = E.S
        S.objects, S.sel, S.t, S.playing, S.preset = [], None, 0.0, False, ""
        self.refresh_all()
        self.L.draw()
        self.B.toast("场景已清空", ms=1500)

    # ---- 绘制
    def draw(self):
        c = self.c
        E.g, E.w, E.h = c.g, c.w, c.h
        S = E.S
        S.bg = TK.stage
        c.clear()
        g = c.g
        self._place_bar()
        if S.show.grid:
            draw_grid(g)
        if S.show.ground:
            draw_ground()
        for o in sorted((o for o in S.objects if o.visible), key=lambda o: TYPES[o.type].z or 2):
            TYPES[o.type].draw(o)
        if S.sel and S.sel.visible:
            self.draw_selection(S.sel)
        if not S.objects:
            W, H = min(470, c.w * 0.68), 96
            round_rect_p((c.w - W) / 2, (c.h - H) / 2, W, H, 16, with_alpha(S.bg, 0.92), with_alpha(C.ink2, 0.18), 1)
            txt_p(c.w / 2, c.h / 2 - 15, "空场景", align="center", size=21, weight=700, color=C.ink2)
            txt_p(c.w / 2, c.h / 2 + 20, "从左侧物体库点选或拖入物体，也可以选一个预设场景", align="center", size=11.5, color=C.faint)
        if S.show.scale:
            step = nice_step(92 / E.cam.scale)
            W = step * E.cam.scale
            X0, Y = 16, c.h - 22
            col = with_alpha(C.ink, 0.55)
            D.line(g, X0, Y, X0 + W, Y, col, 1.2)
            D.line(g, X0, Y - 4, X0, Y + 4, col, 1.2)
            D.line(g, X0 + W, Y - 4, X0 + W, Y + 4, col, 1.2)
            txt_p(X0 + 2, Y - 12, f"{step:g} m", size=10, color=C.faint)
        if self.coord:
            D.text(g, self.coord, c.w - 12, 14, with_alpha(C.soft, 0.9), size=11, align="right", mono=True)

    def draw_selection(self, o):
        Ty = TYPES[o.type]
        g = E.g
        if Ty.selRing:
            R = max(12, sp(Ty.selRing(o)))
            g.begin_path()
            g.arc(px(o.x), py(o.y), R, 0, 6.2832)
            g.stroke_style, g.line_width, g.dash = with_alpha(C.accent, 0.85), 1.15, [4, 5]
            g.stroke()
            g.dash = []
            return
        b = Ty.bounds(o) if Ty.bounds else NS(x0=o.x - 0.5, x1=o.x + 0.5, y0=o.y - 0.5, y1=o.y + 0.5)
        X0, X1, Y0, Y1 = px(b.x0) - 6, px(b.x1) + 6, py(b.y1) - 6, py(b.y0) + 6
        round_rect_p(X0, Y0, max(10, X1 - X0), max(10, Y1 - Y0), 10, None, with_alpha(C.accent, 0.5), 1.1, [4, 5])

    # ---- 指针
    def pick_at(self, X, Y):
        best, area = None, math.inf
        for o in E.S.objects:
            if not o.visible:
                continue
            Ty = TYPES[o.type]
            b = Ty.bounds(o) if Ty.bounds else NS(x0=o.x - 0.5, x1=o.x + 0.5, y0=o.y - 0.5, y1=o.y + 0.5)
            X0, X1, Y0, Y1 = px(b.x0) - 6, px(b.x1) + 6, py(b.y1) - 6, py(b.y0) + 6
            if X0 <= X <= X1 and Y0 <= Y <= Y1:
                a = max(1, (X1 - X0) * (Y1 - Y0))
                if a < area:
                    area, best = a, o
        return best

    def on_mouse(self, kind, e):
        self._sync_size()
        if kind == "wheel":
            p = e.position()
            wx0, wy0 = wx(p.x()), wy(p.y())
            cam = E.cam
            cam.scale = clamp(cam.scale * math.exp(e.angleDelta().y() * 0.0016), 10, 420)
            cam.x = wx0 - (p.x() - E.w / 2) / cam.scale
            cam.y = wy0 + (p.y() - E.h / 2) / cam.scale
            self.L.draw()
            return
        if kind == "leave" or kind == "dbl":
            return
        p = e.position()
        x, y = p.x(), p.y()
        S = E.S
        if kind == "down":
            if e.button() != Qt.MouseButton.LeftButton:
                return
            hit = self.pick_at(x, y)
            if hit:
                self.select(hit)
                self.drag = NS(mode="obj", o=hit, lx=x, ly=y)
            else:
                if S.sel:
                    self.select(None)
                self.drag = NS(mode="pan", lx=x, ly=y)
        elif kind == "move":
            self.coord = f"x {fmt(wx(x), 2)} m · y {fmt(wy(y), 2)} m"
            d = self.drag
            if d:
                dx, dy = x - d.lx, y - d.ly
                d.lx, d.ly = x, y
                cam = E.cam
                if d.mode == "pan":
                    cam.x -= dx / cam.scale
                    cam.y += dy / cam.scale
                else:
                    d.o.x += dx / cam.scale
                    d.o.y -= dy / cam.scale
                    d.o.trail, d.o._tt = [], 0
                    self.update_readouts()
            self.L.draw()
        elif kind == "up":
            self.drag = None

    def on_key(self, k, _e):
        S = E.S
        if k == "Escape":
            if S.sel:
                self.select(None)
            return True
        if k in ("Delete", "Backspace"):
            if S.sel:
                self.remove_object(S.sel)
            return True
        if k == " ":
            self.toggle_play()
            return True
        if k == "ArrowRight":
            self.step_once()
            return True
        return False

    # ---- 检查器
    def select(self, o):
        E.S.sel = o
        self.refresh_all()
        self.L.draw()

    def refresh_all(self):
        self.refresh_dynamic()
        self.build_panel()

    def build_panel(self):
        B, L = self.B, self.L
        S = E.S
        B.clear_panel()
        self.ui = NS()
        o = S.sel
        if not o:
            L.group("属性检查器")
            L.note("点选画布上的物体，即可调整参数、看实时读数。")
        else:
            Ty = TYPES[o.type]
            L.group(Ty.name + ("" if o.visible else " · 已隐藏"))
            for d in Ty.params:
                self.param_row(o, d)
            L.button("复制", lambda _b: self.duplicate(o))
            L.button("删除", lambda _b: self.remove_object(o))
            L.group("实时读数")
            self.ui.read = L.out()
            self.update_readouts()
        L.group(f"场景对象 · {len(S.objects)}")
        if not S.objects:
            L.note("场景还是空的。")
        for q in S.objects:
            self.object_row(q)
        L.group("场景设置")

        def set_g(v):
            S.g = v
        L.slider("重力 g", 0, 20, 0.1, S.g, set_g, "m/s²")

        def tog(k):
            return lambda v: (S.show.__setitem__(k, v), L.draw())
        for k, n in (("grid", "网格"), ("vectors", "矢量"), ("trail", "轨迹"), ("field", "场线"), ("rays", "光路"), ("scale", "比例尺"), ("ground", "地面")):
            L.check(n, bool(S.show[k]), tog(k))
        L.group("")
        L.button("导出 PNG", lambda _b: self.export_png())
        L.button("清空场景", lambda _b: self.clear_scene())
        L.note("拖动空白处平移，滚轮缩放。空格播放/暂停，→ 单步，Delete 删除（先点一下画布）。")
        L.panel_lay.addStretch(1)

    def param_row(self, o, d):
        L = self.L
        if d.kind == "bool":
            L.check(d.label, bool(o.p[d.k]), lambda v, k=d.k: self.set_param(o, k, bool(v)))
        elif d.kind == "enum":
            L.seg(d.label, [[op.v, op.label] for op in d.options], o.p[d.k], lambda v, k=d.k: self.set_param(o, k, v))
        else:
            L.slider(d.label, d.min, d.max, d.step, o.p[d.k], lambda v, k=d.k: self.set_param(o, k, v), d.unit or "", d.dec)

    def object_row(self, q):
        fr = QFrame()
        h = QHBoxLayout(fr)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(4)
        Ty = TYPES[q.type]
        name = QPushButton(Ty.name)
        name.setObjectName("seg")
        name.setCheckable(True)
        name.setChecked(E.S.sel is q)
        name.setToolTip(Ty.desc or Ty.name)
        name.setCursor(Qt.CursorShape.PointingHandCursor)
        name.setStyleSheet("QPushButton{text-align:left;padding-left:10px;" + (f"color:{TK.faint};" if not q.visible else "") + "}")
        name.clicked.connect(lambda _=False, o=q: self.select(o))
        eye = QPushButton("隐" if q.visible else "显")
        eye.setObjectName("btn")
        eye.setFixedWidth(40)
        eye.setToolTip("隐藏" if q.visible else "显示")

        def flip(_=False, o=q):
            o.visible = not o.visible
            self.build_panel()
            self.L.draw()
        eye.clicked.connect(flip)
        h.addWidget(name, 1)
        h.addWidget(eye)
        self.L._add(fr)

    def update_readouts(self):
        S = E.S
        box = self.ui.read
        if not box or not S.sel:
            return
        rd = TYPES[S.sel.type].read
        rows = rd(S.sel) if rd else []
        try:
            if rows:
                box.set([[r[0], f"{r[1]} {r[2]}".strip()] for r in rows])
            else:
                box.set(f"<span style='color:{TK.muted}'>该对象暂无实时读数</span>")
        except RuntimeError:
            pass

    def export_png(self):
        path, _ = QFileDialog.getSaveFileName(self.L.stage, "导出 PNG", "物理场景.png", "PNG 图片 (*.png)")
        if path:
            self.bar.hide()
            self.L.stage.grab().save(path, "PNG")
            self.bar.show()
            self.B.toast("已导出 PNG")


@bench.reg(id="scene", subj="phys", short="场景搭建", title="物理场景搭建", sub="运动学 · 力学 · 电学 · 磁场 · 电场 · 光学 · 波 · 万有引力",
           desc="从八个章节的物体库里点选物体放到画布上：小车、单摆、带电粒子、透镜、平面镜、波源、卫星……改质量、电荷、初速和焦距，播放、单步、拖时间轴，看轨迹、矢量与实时读数。",
           art=ART)
def scene(B):
    sb = SceneBench(B)
    L = B.L
    first = E.S is None
    if first:
        E.S = new_scene()
    E.w, E.h = sb.c.w, sb.c.h
    L.on_draw(sb.draw)
    L.stage.mouse = sb.on_mouse
    L.on_key(sb.on_key)
    secs = [{"title": "预设场景", "items": [{"icon": GROUP_ICON["preset"], "label": p.name, "click": (lambda i=p.id: sb.load_preset(i, True))} for p in PRESETS]}]
    for key, name in GROUPS:
        items = []
        for tk in types_of_group(key):
            Ty = TYPES[tk]
            items.append({"icon": GROUP_ICON[key], "label": Ty.name, "sub": Ty.desc, "click": (lambda t=tk: sb.add_object(t)),
                          "drop": (lambda x, y, t=tk: sb.add_object(t, (wx(x), wy(y))))})
        secs.append({"title": name, "items": items})
    B.palette(secs)
    B.tips([("怎么用", ["左栏按章节列出 30 类物体，点一下放到画布中央，也可以拖到指定位置；「预设场景」是 12 个现成场景（透镜成像、卫星变轨……）。",
                     "点选画布上的物体，右栏修改参数，读数实时更新。", "画布底部的时间轴：播放 / 单步 / 复位 / 倍速，也可以直接拖动进度。",
                     "右栏「场景设置」里可开关矢量、轨迹、网格和比例尺，导出 PNG。"])])
    L.loop(sb.tick)
    if first or not E.S.objects:
        sb.load_preset("projectile", False)
    else:
        sb.refresh_all()
    def snapshot_transfer():
        return state_graph.encode(dict(scene=E.S,cam=E.cam))
    def restore_transfer(snapshot):
        data=state_graph.decode(snapshot,NS)
        E.S=data["scene"]
        E.cam=data["cam"]
        E.S.playing=False
        sb.refresh_all()
        L.draw()
    B.transfer(snapshot_transfer,restore_transfer,sb)


def _unused():
    _ = (QRectF, circuit_info, tag_p, scene_types1, scene_types2)
