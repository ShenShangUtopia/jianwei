"""读 PPT 的动画：把每张幻灯片拆成若干「画面」，每点一下进到下一个画面。

做法：每个画面渲染成 PDF 的一页（哪些形状、哪些段落此时不显示，由这里算出来），放映时比较前后两页的像素，
把变化的部分拿出来做淡入、飞入、擦除等效果。这样不管是 Office、WPS 还是内置排版画的页面，动画都一样播。

只支持 .pptx 这类新格式（旧版 .ppt 由 Office / WPS 先转存成 .pptx）。
"""
from __future__ import annotations

from .builtin import _find_ph, _i, A, Deck, EMU_PT, P

DIRS = {1: "t", 2: "r", 4: "b", 8: "l"}
MAX_DUR = 5000


def _cond_delay(ctn) -> int:
    for c in ctn.findall(f"{P}stCondLst/{P}cond"):
        d = c.get("delay")
        if d and d.lstrip("-").isdigit():
            return int(d)
    return 0


def _effects_in(ctn, base=0):
    """时间树里的每个动画节点，带上累计的延迟。"""
    out = []
    for par in ctn.findall(f"{P}childTnLst/{P}par"):
        c = par.find(P + "cTn")
        if c is None:
            continue
        delay = base + _cond_delay(c)
        if c.get("presetClass") or c.get("nodeType") in ("clickEffect", "withEffect", "afterEffect"):
            out.append((c, delay))
        else:
            out.extend(_effects_in(c, delay))
    return out


def _target(ctn):
    """(形状 id, 段落范围或 None)。"""
    for sp in ctn.iter(P + "spTgt"):
        spid = _i(sp.get("spid"), -1)
        rg = sp.find(f"{P}txEl/{P}pRg")
        if rg is not None:
            return spid, (_i(rg.get("st")), _i(rg.get("end")))
        return spid, None
    return None, None


def _effect_of(ctn):
    cls = ctn.get("presetClass") or "entr"
    sub = _i(ctn.get("presetSubtype"))
    durs = [_i(c.get("dur")) for c in ctn.iter(P + "cTn") if str(c.get("dur") or "").isdigit()]
    dur = min(MAX_DUR, max(durs + [1]))
    name, direction = "appear", DIRS.get(sub & 15, "b")
    filters = [e.get("filter") or "" for e in ctn.iter(P + "animEffect")]
    if any(f.startswith("wipe") for f in filters):
        name = "wipe"
        f = next(f for f in filters if f.startswith("wipe"))
        direction = {"left": "l", "right": "r", "up": "t", "down": "b"}.get(f[f.find("(") + 1:].rstrip(")"), direction)
    elif filters:
        name = "fade"
    moved = False
    for an in ctn.iter(P + "anim"):
        attr = " ".join(x.text or "" for x in an.iter(P + "attrName"))
        vals = [v.get("val") or "" for v in an.iter(P + "strVal")]
        if "ppt_w" in attr or "ppt_h" in attr:
            name = "zoom"
        elif ("ppt_x" in attr or "ppt_y" in attr) and vals:
            far = vals[0] if cls != "exit" else vals[-1]
            if far.startswith("0-") or far.startswith("1+") or far.startswith("-") or far.startswith("1.") or far.startswith("0.") and not far.startswith("#"):
                moved = True
                if "ppt_x" in attr and (far.startswith("0-") or far.startswith("-")):
                    direction = "l"
                elif "ppt_x" in attr:
                    direction = "r"
                elif far.startswith("0-") or far.startswith("-"):
                    direction = "t"
                else:
                    direction = "b"
            elif "#" in far and far.strip() not in ("#ppt_x", "#ppt_y") and name != "zoom":
                name = "float"
                direction = "t" if "-" in far else "b"
                if "ppt_x" in attr:
                    direction = "l" if "-" in far else "r"
    if moved:
        name = "fly"
    if any(True for _ in ctn.iter(P + "animScale")) and name in ("appear", "fade"):
        name = "zoom"
    if any(True for _ in ctn.iter(P + "animRot")):
        name = "spin"
    if cls in ("emph", "path"):
        name = "pulse"
    return cls, name, direction, dur


def _shape_el(tree, spid):
    for tag in ("sp", "pic", "graphicFrame", "cxnSp", "grpSp"):
        for el in tree.iter(P + tag):
            for nv in el:
                c = nv.find(P + "cNvPr")
                if c is not None:
                    if _i(c.get("id"), -1) == spid:
                        return el
                    break
    return None


def _name_of(el):
    for nv in el:
        c = nv.find(P + "cNvPr")
        if c is not None:
            return c.get("name") or ""
    return ""


def _rect(deck, el, layout, master):
    """形状的位置（占整页的比例）；旋转的形状返回 None，比较整页。"""
    if el is None:
        return None
    x = None
    for pr in (el.find(P + "spPr"), el.find(P + "grpSpPr")):
        if pr is not None and pr.find(A + "xfrm") is not None:
            x = pr.find(A + "xfrm")
    if x is None:
        x = el.find(P + "xfrm")
    if x is None and el.tag == P + "sp":
        ph = el.find(f"{P}nvSpPr/{P}nvPr/{P}ph")
        for tree in (layout, master):
            found = _find_ph(tree, ph)
            if found is not None and found.find(f"{P}spPr/{A}xfrm") is not None:
                x = found.find(f"{P}spPr/{A}xfrm")
                break
    if x is None or x.get("rot"):
        return None
    off, ext = x.find(A + "off"), x.find(A + "ext")
    if off is None or ext is None:
        return None
    w, h = deck.w * EMU_PT, deck.h * EMU_PT
    return [_i(off.get("x")) / w, _i(off.get("y")) / h, _i(ext.get("cx")) / w, _i(ext.get("cy")) / h]


def _transition(slide):
    tr = next(slide.iter(P + "transition"), None)
    if tr is None:
        return None, None
    adv = None
    if tr.get("advTm") is not None and str(tr.get("advTm")).isdigit():
        adv = int(tr.get("advTm")) / 1000
    kind = "fade"
    direction = "l"
    for ch in tr:
        tag = ch.tag.split("}")[1]
        if tag in ("cut",):
            kind = "cut"
        elif tag in ("push", "cover", "pull"):
            kind = "push" if tag == "push" else "cover"
            direction = (ch.get("dir") or "l")[0]
        elif tag in ("wipe", "split", "wheel", "wedge", "blinds", "checker", "comb", "strips"):
            kind = "wipe"
            direction = (ch.get("dir") or "l")[0]
        break
    if len(tr) == 0 and adv is not None:
        return None, adv
    dur = {"slow": 900, "med": 600, "fast": 350}.get(tr.get("spd") or "fast", 500)
    for k, v in tr.attrib.items():
        if k.endswith("}dur") and str(v).isdigit():
            dur = int(v)
    return dict(kind=kind, dir=direction, dur=min(dur, 3000)), adv


def parse(path) -> dict:
    """返回 {slides: [{index, frames: [{hide, effects, auto}], transition, adv, names}], w, h}。隐藏的幻灯片不放映。"""
    d = Deck(path)
    out = dict(slides=[], hidden=[], w=d.w, h=d.h)
    for i, name in enumerate(d.slides):
        slide = d.part(name)
        if slide.get("show") == "0":
            out["hidden"].append(i + 1)
            continue
        rels = d.pk.rels(name)
        layout_name = next((t for t in rels.values() if "slideLayout" in t), None)
        layout = d.part(layout_name) if layout_name else None
        master_name = next((t for t in d.pk.rels(layout_name).values() if "slideMaster" in t), None) if layout_name else None
        master = d.part(master_name) if master_name else None
        trans, adv = _transition(slide)
        rec = dict(index=i + 1, frames=[], transition=trans, adv=adv, names={})
        timing = slide.find(P + "timing")
        main = None
        if timing is not None:
            main = next((c for c in timing.iter(P + "cTn") if c.get("nodeType") == "mainSeq"), None)
        groups = []
        if main is not None:
            for par in main.findall(f"{P}childTnLst/{P}par"):
                c = par.find(P + "cTn")
                if c is not None:
                    groups.append(_effects_in(c))
        items = [e for g in groups for e in g]
        # 一开始就看不见的：第一个动画是「进入」的对象
        hidden, seen = set(), set()
        parsed = []
        for ctn, delay in items:
            spid, rng = _target(ctn)
            if spid is None or spid < 0:
                continue
            cls, eff, direction, dur = _effect_of(ctn)
            keys = [(spid, p) for p in range(rng[0], rng[1] + 1)] if rng else [(spid, None)]
            for k in keys:
                if k not in seen:
                    seen.add(k)
                    if cls == "entr":
                        hidden.add(k)
            parsed.append((ctn.get("nodeType") or "clickEffect", cls, eff, direction, dur, delay, spid, keys))
        tree = slide.find(f"{P}cSld/{P}spTree")
        frames = [dict(hide=sorted(hidden, key=str), effects=[], auto=False)]
        state = set(hidden)
        frame_base = 0
        for node, cls, eff, direction, dur, delay, spid, keys in parsed:
            el = _shape_el(tree, spid)
            if el is not None:
                rec["names"][str(spid)] = _name_of(el)
            joins = node == "withEffect" and len(frames) > 1
            if not joins:
                frames.append(dict(hide=[], effects=[], auto=node != "clickEffect"))
                frame_base = delay   # 新画面从它自己的第一个动画算起
            if cls == "entr":
                state -= set(keys)
            elif cls == "exit":
                state |= set(keys)
            f = frames[-1]
            f["hide"] = sorted(state, key=str)
            f["effects"].append(dict(kind="in" if cls == "entr" else "out" if cls == "exit" else "emph", effect=eff, dir=direction, dur=dur, delay=max(0, delay - frame_base), rect=_rect(d, el, layout, master)))
        rec["frames"] = frames
        out["slides"].append(rec)
    return out


def needs_steps(plan) -> bool:
    return bool(plan["hidden"]) or any(len(s["frames"]) > 1 for s in plan["slides"])


def has_motion(plan) -> bool:
    return needs_steps(plan) or any(s["transition"] or s["adv"] for s in plan["slides"])


def frame_count(plan) -> int:
    return sum(len(s["frames"]) for s in plan["slides"])


def hide_sets(frame):
    """(整个隐藏的形状 id, {形状 id: 隐藏的段落})。"""
    shapes, paras = set(), {}
    for spid, para in frame["hide"]:
        if para is None:
            shapes.add(spid)
        else:
            paras.setdefault(spid, set()).add(para)
    return shapes, paras


def com_plan(plan) -> dict:
    """给 PowerShell 脚本的指令：每张幻灯片复制成几份，各隐藏哪些内容。"""
    slides = []
    for s in plan["slides"]:
        frames = []
        for f in s["frames"]:
            shapes, paras = hide_sets(f)
            frames.append(dict(shapes=[dict(id=i, name=s["names"].get(str(i), "")) for i in sorted(shapes)],
                               paras=[dict(id=i, name=s["names"].get(str(i), ""), n=sorted(v)) for i, v in sorted(paras.items())]))
        slides.append(dict(index=s["index"], frames=frames))
    return dict(delete=plan["hidden"], slides=slides)


def timeline(plan) -> dict:
    """放映器用：PDF 第几页属于第几张幻灯片的第几步。"""
    frames, slides, page = [], [], 0
    for si, s in enumerate(plan["slides"]):
        first = page
        for step, f in enumerate(s["frames"]):
            frames.append(dict(page=page, slide=si, step=step, auto=bool(f["auto"]), effects=f["effects"]))
            page += 1
        slides.append(dict(first=first, last=page - 1, transition=s["transition"], adv=s["adv"]))
    return dict(frames=frames, slides=slides)


def identity(pages: int) -> dict:
    return dict(frames=[dict(page=i, slide=i, step=0, auto=False, effects=[]) for i in range(pages)],
                slides=[dict(first=i, last=i, transition=None, adv=None) for i in range(pages)])
