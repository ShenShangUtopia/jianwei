"""工作台外围互通层：参考图、批注、快照与独立画布，不改仿真内部逻辑。"""
from __future__ import annotations

import copy

from PySide6.QtCore import QBuffer, QEvent, QIODevice, QObject, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QImage, QPainter, QPen
from PySide6.QtWidgets import QCheckBox, QFrame, QHBoxLayout, QInputDialog, QMenu, QPushButton, QVBoxLayout, QWidget

from ..lecture.board import BoardCanvas
from ..lecture.board_transfer import crop_ink
from .clip import read_json, write_json
from .home import home
from .pen_bar import PenBar
from . import pen_tools


class Notes(BoardCanvas):
    clip_background = "transparent"

    def paintEvent(self,event):  # noqa: N802
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing|QPainter.RenderHint.SmoothPixmapTransform)
        self.paint_materials(p)
        p.save()
        p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Multiply)
        p.drawPixmap(0,0,self._strokes_layer(True))
        p.restore()
        p.drawPixmap(0,0,self._strokes_layer())
        if self.active is not None:
            from . import pen
            p.save()
            p.translate(self.dx,self.dy)
            p.scale(self.scale,self.scale)
            pen.draw(p,self.active)
            p.restore()
        if self.sel is not None:
            p.setPen(QPen(QColor("#5799E5"),1.5,Qt.PenStyle.DashLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            r = self.to_view_rect(QRectF(self.sel["x"],self.sel["y"],self.sel["w"],self.sel["h"]))
            p.drawRect(r)
            p.drawRect(QRectF(r.right()-5,r.bottom()-5,10,10))
        self.pen_session.paint(p)
        p.end()

    def paint_materials(self,p):
        p.save()
        p.translate(self.dx,self.dy)
        p.scale(self.scale,self.scale)
        for item in self.board["items"]:
            self._draw_item(p,item)
        p.restore()

    def clip_origin(self,rect):
        return dict(type="bench:"+self.bench_id,ref=dict(bench_id=self.bench_id),rect=[rect.x(),rect.y(),rect.width(),rect.height()])


class CanvasWindow(QWidget):
    def __init__(self,owner):
        super().__init__(owner.studio.window(),Qt.WindowType.Window)
        self.owner = owner
        self.setWindowTitle("见微 · 独立工作台画布")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)

    def closeEvent(self,event):  # noqa: N802
        QTimer.singleShot(0,self.owner.studio,self.owner.reattach)
        event.accept()


class BenchTransfer(QObject):
    def __init__(self,studio,bus):
        super().__init__(studio)
        self.studio,self.bus = studio,bus
        self.notes = self.bar = self.pen_bar = None
        self.window = None
        self.state_error = ""

    def before_close(self):
        if self.window:
            self.reattach()
        if self.notes is not None:
            self.notes.pen_session.reset()
            self.notes.save()
            if self.studio.B and self.notes.bench_id=="draw":
                self.studio.B.transfer_model.save_state()
            if self.studio.B and self.notes.bench_id!="draw" and self.studio.B.transfer_snapshot and not self.state_error:
                try:
                    write_json(home()/"workbench-state"/(self.notes.bench_id+".json"),dict(version=1,engine=self.studio.B.transfer_snapshot()))
                except (OSError,ValueError,TypeError) as exc:
                    self.bus.error.emit("工作台状态未保存："+str(exc))
            self.notes.deleteLater()
            self.notes = None
        if self.bar is not None:
            self.bar.hide()
            self.bar.deleteLater()
            self.bar = None
        self.pen_bar = None
        self.interactions = []

    def mount(self):
        studio,B = self.studio,self.studio.B
        bid = studio.cur_bench.id
        self.state_error = ""
        saved = home()/"workbench-state"/(bid+".json")
        try:
            state = read_json(saved) if bid!="draw" else None
            if state is not None:
                if not isinstance(state,dict) or state.get("version") != 1:
                    raise ValueError("存档版本不支持，已保护原文件")
                if B.transfer_restore:
                    B.transfer_restore(state["engine"])
        except (OSError,ValueError,TypeError,KeyError) as exc:
            self.state_error = str(exc)
            B.toast("工作台状态已保护："+str(exc))
        notes = Notes(home()/"workbench-notes"/bid)
        self.notes = notes
        notes.bench_id,notes.clip_store = bid,self.bus.store
        notes.transfer_zoom = self.zoom_geometry
        notes.transfer_reset = self.reset_geometry
        notes.setParent(B.stage)
        notes.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent,False)
        notes.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground,True)
        notes.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents,True)
        notes.setGeometry(B.stage.rect())
        notes.setStyleSheet("background:transparent;")
        notes.color = "#E5484D"
        notes.storage_error.connect(self.bus.error)
        notes.origin_requested.connect(self.bus.origin_requested)
        notes.show()
        notes.raise_()
        B.stage.installEventFilter(self)
        from .clip_ui import ClipInteraction
        self.interactions = [ClipInteraction(B.stage,self.bus,self.snapshot,self.receive,self),
                             ClipInteraction(notes,self.bus,self.snapshot,self.receive,self,
                                             origin=lambda:notes.sel.get("origin",{}) if notes.sel else {})]
        B.stage.overlays.append(lambda _g:self.sync_geometry())
        self.bar = QFrame()
        layout = QHBoxLayout(self.bar)
        layout.setContentsMargins(0,0,0,0)
        self.enabled = QCheckBox("批注 / 编辑参考图")
        self.enabled.toggled.connect(lambda on:notes.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents,not on))
        layout.addWidget(self.enabled)
        self.pen_bar = PenBar(notes,notes.pen_session,board=True)
        notes.tool_changed.connect(lambda tool:self.enabled.setChecked(True) if tool!="move" else None)
        layout.addWidget(self.pen_bar)
        button = QPushButton("互通 / 底图")
        button.clicked.connect(self.menu)
        layout.addWidget(button)
        button = QPushButton("独立画布")
        button.setToolTip("画布和批注工具放入独立窗口，器材栏与参数保留在主窗口")
        button.clicked.connect(self.detach)
        layout.addWidget(button)
        layout.addStretch(1)
        studio.exp_page.layout().insertWidget(1,self.bar)
        self.sync_geometry()

    def sync_geometry(self):
        if self.notes is None or self.studio.B is None:
            return
        stage = self.studio.B.stage
        if self.notes.size()!=stage.size():
            self.notes.setGeometry(stage.rect())
        calibration = self.notes.store.data.get("calibration")
        model = self.studio.B.transfer_model
        if self.notes.bench_id=="draw" and calibration and model:
            view = model.view
            factor = view["scale"]/calibration["scale"]
            self.notes.scale = factor
            self.notes.dx = stage.width()/2-(view["cx"]-calibration["cx"])*view["scale"]-calibration["width"]/2*factor
            self.notes.dy = stage.height()/2+(view["cy"]-calibration["cy"])*view["scale"]-calibration["height"]/2*factor
        self.notes.update()

    def eventFilter(self,watched,event):  # noqa: N802
        if event.type()==QEvent.Type.Resize:
            self.sync_geometry()
        return False

    def receive(self,clip):
        if self.notes is None:
            return
        item = self.notes.receive_clip(clip)
        item.update(opacity=.5,locked=True)
        self.notes._touch()
        self.studio.B.toast("已作为参考图加入；互通菜单可调透明度、解锁或标定比例尺")

    def snapshot(self,vector=False,ink_only=False):
        B,notes = self.studio.B,self.notes
        if B is None or notes is None:
            raise ValueError("请先打开一个工作台")
        stage = B.stage
        image = QImage(stage.size(),QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        painter = QPainter(image)
        stage.render(painter,QPointF().toPoint(),renderFlags=QWidget.RenderFlag.DrawWindowBackground)
        notes.paint_materials(painter)
        painter.end()
        svg = None
        if vector:
            if notes.bench_id not in ("draw","scene"):
                raise ValueError("这个工作台只支持位图快照")
            from PySide6.QtSvg import QSvgGenerator
            buffer = QBuffer()
            buffer.open(QIODevice.OpenModeFlag.WriteOnly)
            generator = QSvgGenerator()
            generator.setOutputDevice(buffer)
            generator.setSize(stage.size())
            generator.setViewBox(stage.rect())
            painter = QPainter(generator)
            stage.render(painter,QPointF().toPoint(),renderFlags=QWidget.RenderFlag.DrawWindowBackground)
            notes.paint_materials(painter)
            painter.end()
            svg = bytes(buffer.data())
        strokes = pen_tools.transform(notes.board["strokes"],notes.dx,notes.dy,notes.scale)
        strokes = crop_ink(strokes,QRectF(stage.rect()))
        state = dict(version=1,bench_id=notes.bench_id,engine=B.transfer_snapshot() if B.transfer_snapshot else None,
                     notes=copy.deepcopy(dict(notes.store.data,boards=notes.boards,cur=notes.cur)))
        clip = self.bus.store.create(image=None if ink_only else image,ink=strokes,svg=svg if not ink_only else None,
                    width=stage.width(),height=stage.height(),origin=notes.clip_origin(QRectF(stage.rect())),state=state)
        clip["origin"]["ref"]["clip_id"] = clip["id"]
        write_json(self.bus.store.path(clip["id"])/"clip.json",clip)
        return clip

    def restore(self,clip):
        if not clip.get("state"):
            raise ValueError("素材没有工作台快照")
        state = read_json(self.bus.store.asset(clip,"state"))
        if not isinstance(state,dict) or state.get("version")!=1 or state.get("bench_id")!=self.notes.bench_id:
            raise ValueError("工作台快照版本或类型不匹配")
        if state.get("engine") is not None and self.studio.B.transfer_restore:
            self.studio.B.transfer_restore(state["engine"])
        from .pen_store import migrate_board
        notes_state = migrate_board(state["notes"])
        self.notes.boards,self.notes.cur = notes_state["boards"],notes_state["cur"]
        self.notes.store.data = notes_state
        self.notes._touch()
        self.sync_geometry()

    def calibrate(self):
        model = self.studio.B.transfer_model
        images = self.notes.board["items"]
        if self.notes.bench_id!="draw" or not model or not images:
            self.studio.B.toast("请先在几何画板加入参考图")
            return
        item = self.notes.sel or images[-1]
        distance,ok = QInputDialog.getDouble(self.studio,"底图比例尺","所选图像的整个宽度对应多少坐标单位？",10,.001,1e9,3)
        if not ok:
            return
        k = item["w"]*self.notes.scale/distance
        left = item["x"]*self.notes.scale+self.notes.dx
        bottom = (item["y"]+item["h"])*self.notes.scale+self.notes.dy
        model.view.update(scale=k,cx=(self.notes.width()/2-left)/k,cy=(bottom-self.notes.height()/2)/k)
        self.notes.store.data["calibration"] = dict(model.view,width=self.notes.width(),height=self.notes.height())
        model.refresh_all()
        model.schedule_save()
        self.notes._touch()

    def zoom_geometry(self,factor,old_center,new_center):
        if self.notes is None or self.notes.bench_id!="draw" or not self.notes.store.data.get("calibration"):
            return False
        model = self.studio.B.transfer_model
        view = model.view
        w,h = self.notes.width(),self.notes.height()
        x = view["cx"]+(old_center.x()-w/2)/view["scale"]
        y = view["cy"]-(old_center.y()-h/2)/view["scale"]
        view["scale"] = max(5,min(420,view["scale"]*factor))
        view["cx"],view["cy"] = x-(new_center.x()-w/2)/view["scale"],y+(new_center.y()-h/2)/view["scale"]
        model.render()
        model.schedule_save()
        self.sync_geometry()
        return True

    def reset_geometry(self):
        if self.notes is None or self.notes.bench_id!="draw":
            return False
        calibration = self.notes.store.data.get("calibration")
        if not calibration:
            return False
        model = self.studio.B.transfer_model
        model.view.update({k:calibration[k] for k in ("cx","cy","scale")})
        model.render()
        model.schedule_save()
        self.sync_geometry()
        return True

    def menu(self):
        menu = QMenu(self.studio)
        for target,label in (("board","送到黑板"),("lecture","存为课件插页"),("basket","放入素材篮")):
            menu.addAction(label,lambda _=False,t=target:self.bus.send(self.snapshot(),t,self))
        if self.notes.bench_id in ("draw","scene"):
            menu.addAction("以矢量图形送到黑板",lambda:self.bus.send(self.snapshot(vector=True),"board",self))
        menu.addAction("仅发送批注到黑板",lambda:self.bus.send(self.snapshot(ink_only=True),"board",self))
        menu.addSeparator()
        menu.addAction("标定底图比例尺（几何画板）",self.calibrate)
        menu.addAction("参考图透明度…",self.opacity)
        menu.addAction("锁定全部参考图",lambda:self.lock_images(True))
        menu.addAction("解锁全部参考图",lambda:self.lock_images(False))
        from PySide6.QtWidgets import QApplication
        menu.addAction("复制当前快照",lambda:QApplication.clipboard().setMimeData(self.bus.store.mime(self.snapshot())))
        menu.addAction("粘贴参考图",lambda:self.receive(self.bus.store.from_mime(QApplication.clipboard().mimeData())))
        menu.exec(self.bar.mapToGlobal(self.bar.rect().bottomLeft()))

    def opacity(self):
        value,ok = QInputDialog.getDouble(self.studio,"参考图透明度","0 最透明，1 完全不透明",.5,.05,1,2)
        if ok:
            for item in self.notes.board["items"]:
                item["opacity"] = value
            self.notes._touch()

    def lock_images(self,on):
        for item in self.notes.board["items"]:
            item["locked"] = on
        self.notes._touch()

    def detach(self):
        if self.window:
            self.reattach()
            return
        self.window = CanvasWindow(self)
        self.window.layout().addWidget(self.bar)
        self.window.layout().addWidget(self.studio.stage_host,1)
        self.window.resize(1100,740)
        other = next((s for s in QGuiApplication.screens() if s is not self.studio.screen()),None)
        if other:
            self.window.setGeometry(other.geometry())
            self.window.showFullScreen()
        else:
            self.window.show()

    def reattach(self):
        if not self.window:
            return
        window,self.window = self.window,None
        self.studio.exp_page.layout().insertWidget(1,self.bar)
        self.studio.exp_page.layout().addWidget(self.studio.stage_host,1)
        window.hide()
        window.deleteLater()
        self.bar.show()
        self.studio.stage_host.show()
