"""共享画笔工具条；横/竖布局，四个持久样式预设，使用原生设计令牌。"""
from __future__ import annotations

import copy

from PySide6.QtCore import Qt, QSignalBlocker
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QColorDialog, QComboBox, QDoubleSpinBox, QFrame,
                              QHBoxLayout, QMenu, QPushButton, QSizePolicy, QVBoxLayout)

from ..design.tokens import T
from .home import load_json, save_json

TOOLS = [("pointer","指针 V"),("pen","笔 P"),("marker","荧光笔 H"),("chalk","粉笔"),
         ("eraser","橡皮 E"),("lasso","套索"),("laser","激光笔 L"),
         ("line","直线"),("rect","矩形"),("ellipse","圆 / 椭圆"),("arrow","箭头"),("axes","坐标轴")]
DEFAULTS = [dict(tool="pen",color="#E5484D",width=3.5),dict(tool="pen",color="#2F6FED",width=2),
            dict(tool="marker",color="#FFD60A",width=3.5),dict(tool="chalk",color="#F4F1E8",width=4)]


class PenBar(QFrame):
    def __init__(self, target, session, parent=None, vertical=False, board=False):
        super().__init__(parent)
        self.target, self.session, self.board = target, session, board
        self.setObjectName("penBar")
        self.settings_error = ""
        layout = QVBoxLayout(self) if vertical else QHBoxLayout(self)
        layout.setContentsMargins(4,4,4,4)
        layout.setSpacing(4)
        self.tool_box = QComboBox()
        self.tool_box.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.tool_box.setToolTip("统一画笔工具；套索圈选后拖动移动，拖右下角缩放")
        for key,label in TOOLS + ([] if board else [("select","截取 S")]):
            self.tool_box.addItem(label,"move" if board and key == "pointer" else key)
        self.tool_box.currentIndexChanged.connect(lambda i: self.set_tool(self.tool_box.itemData(i)))
        layout.addWidget(self.tool_box)
        self.color_btn = QPushButton("颜色")
        self.color_btn.setFixedWidth(48)
        self.color_btn.setToolTip("选择画笔颜色")
        self.color_btn.clicked.connect(self.choose_color)
        layout.addWidget(self.color_btn)
        self.width_box = QDoubleSpinBox()
        self.width_box.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.width_box.setRange(.5,30)
        self.width_box.setSingleStep(.5)
        self.width_box.setSuffix(" px")
        self.width_box.setToolTip("屏幕笔宽；荧光笔自动加宽")
        self.width_box.setFixedWidth(85)
        self.width_box.valueChanged.connect(lambda v: setattr(target,"width_px",v))
        layout.addWidget(self.width_box)
        for title,tip,fn in (("↶","撤销 Ctrl+Z",target.undo),("↷","重做 Ctrl+Y",target.redo)):
            self.button(layout,title,tip,fn)
        self.more = self.button(layout,"更多","橡皮方式、形状吸附、套索操作与共享预设",self.open_menu)
        if not vertical:
            layout.addStretch(1)
        self.apply_theme()
        self.reload_settings()
        self.sync()

    @staticmethod
    def button(layout,label,tip,fn):
        b = QPushButton(label)
        b.setSizePolicy(QSizePolicy.Policy.Fixed,QSizePolicy.Policy.Preferred)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setToolTip(tip)
        b.clicked.connect(fn)
        layout.addWidget(b)
        return b

    def apply_theme(self):
        self.setStyleSheet(f"""
QFrame#penBar {{ background:{T.surface}; border:1px solid {T.line}; border-radius:8px; }}
QFrame#penBar QPushButton, QFrame#penBar QComboBox, QFrame#penBar QDoubleSpinBox {{
background:{T.surface};color:{T.fg};border:1px solid {T.line};border-radius:5px;padding:5px;font-size:12px; }}
QFrame#penBar QPushButton:hover {{ background:{T.hover};border-color:{T.accent}; }}
QFrame#penBar QComboBox QAbstractItemView {{ background:{T.surface};color:{T.fg};selection-background-color:{T.hover}; }}
""")

    def sync(self):
        with QSignalBlocker(self.tool_box):
            self.tool_box.setCurrentIndex(self.tool_box.findData(self.target.tool))
        with QSignalBlocker(self.width_box):
            self.width_box.setValue(self.target.width_px)
        self.color_btn.setStyleSheet(f"border-bottom:4px solid {self.target.color};")

    def set_tool(self,tool):
        self.target.set_tool(tool)
        if hasattr(self.target,"activity"):
            self.target.activity.emit()
        self.sync()

    def choose_color(self):
        color = QColorDialog.getColor(QColor(self.target.color),self,"画笔颜色")
        if color.isValid():
            self.target.color = color.name()
            if self.target.tool in ("pointer","move","eraser","laser","lasso","select"):
                self.set_tool("pen")
            self.sync()

    def reload_settings(self):
        data = load_json("pen-settings.json",None)
        self.slots = copy.deepcopy(DEFAULTS)
        if data is None:
            # 已存在但不能解析时，不用默认预设覆盖原文件。
            from .home import home
            if (home()/"pen-settings.json").exists():
                self.settings_error = "预设文件无法读取，已保护原文件"
            return
        if not isinstance(data,dict) or data.get("version") != 1:
            self.settings_error = "预设文件版本不支持，已保护原文件"
            return
        slots = data.get("slots")
        if not isinstance(slots,list) or len(slots) != 4:
            self.settings_error = "预设列表无效，已保护原文件"
            return
        for slot in slots:
            if (not isinstance(slot,dict) or slot.get("tool") not in dict(TOOLS) or
                not isinstance(slot.get("color"),str) or not QColor(slot["color"]).isValid() or
                not isinstance(slot.get("width"),(int,float)) or not .5 <= slot["width"] <= 30):
                self.settings_error = "预设样式无效，已保护原文件"
                return
        self.slots = slots
        self.session.snap_enabled = bool(data.get("snap",True))
        self.settings_error = ""

    def save_settings(self):
        if self.settings_error:
            self.more.setToolTip(self.settings_error)
            return
        try:
            save_json("pen-settings.json",dict(version=1,slots=self.slots,snap=self.session.snap_enabled))
        except OSError as exc:
            self.more.setToolTip("预设未保存："+str(exc))

    def save_slot(self,index):
        tool = "pointer" if self.target.tool == "move" else self.target.tool
        if tool not in dict(TOOLS):
            return
        self.slots[index] = dict(tool=tool,
                                 color=self.target.color,width=self.target.width_px)
        self.save_settings()

    def use_slot(self,index):
        slot = self.slots[index]
        self.target.color,self.target.width_px = slot["color"],slot["width"]
        self.set_tool("move" if self.board and slot["tool"] == "pointer" else slot["tool"])

    def open_menu(self):
        self.reload_settings()
        menu = QMenu(self)
        menu.setStyleSheet(f"QMenu{{background:{T.surface};color:{T.fg};padding:5px;}} QMenu::item:selected{{background:{T.hover};}}")
        for key,label in (("stroke","整笔橡皮"),("pixel","局部橡皮（保留剩余笔画）")):
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(self.session.eraser_mode == key)
            action.triggered.connect(lambda _=False,k=key:setattr(self.session,"eraser_mode",k))
        action = menu.addAction("停笔 0.5 秒识别形状")
        action.setCheckable(True)
        action.setChecked(self.session.snap_enabled)
        action.triggered.connect(lambda on:(setattr(self.session,"snap_enabled",on),self.save_settings()))
        menu.addSeparator()
        for key,label in (("copy","复制选中笔迹"),("delete","删除选中笔迹"),("larger","放大选中笔迹"),("smaller","缩小选中笔迹")):
            action = menu.addAction(label)
            action.setEnabled(bool(self.session.ids))
            action.triggered.connect(lambda _=False,k=key:self.session.selection_action(k))
        menu.addSeparator()
        for key,label in (("in","放大画布"),("out","缩小画布"),("reset","复位视图")):
            menu.addAction(label,lambda _=False,k=key:self.session.view_action(k))
        menu.addSeparator()
        for index in range(4):
            slot = self.slots[index]
            sub = menu.addMenu(f"预设 {index+1} · {dict(TOOLS)[slot['tool']]} · {slot['width']:g}px")
            sub.addAction("使用",lambda _=False,i=index:self.use_slot(i))
            action = sub.addAction("保存当前样式",lambda _=False,i=index:self.save_slot(i))
            action.setEnabled(not self.settings_error and self.target.tool in [k for k,_ in TOOLS]+["move"])
        if self.settings_error:
            menu.addAction(self.settings_error).setEnabled(False)
        menu.exec(self.more.mapToGlobal(self.more.rect().bottomLeft()))
