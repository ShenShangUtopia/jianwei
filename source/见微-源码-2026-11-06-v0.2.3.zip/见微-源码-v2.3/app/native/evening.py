"""暮省全屏播放（原生）：4 种材质 × 4 种封面版式，全部 QPainter 绘制，不需要浏览器。

deck 是 guanlan/core/evening.py 生成的纯数据（JSON 可存）。尺寸都按屏幕宽度算（对应旧 CSS 的 clamp(min, vw, max)）；
一页内容放不下时整页字号按比例缩小，不会出现被截断的文字。

操作：空格暂停、← → 翻页、Esc 退出、F11 切窗口；静候封面上按 →、空格或单击直接开始。
"""
from __future__ import annotations

import math
import sys
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetricsF, QGuiApplication, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QRadialGradient, QTextLayout, QTextOption, QTransform)
from PySide6.QtWidgets import QApplication, QMessageBox, QWidget

SERIF = ["Source Han Serif SC", "Noto Serif SC", "Songti SC", "STSong", "SimSun", "serif"]
SANS = ["Noto Sans SC", "Microsoft YaHei UI", "Microsoft YaHei", "DengXian", "sans-serif"]
MONO = ["Georgia", "Times New Roman", "Microsoft YaHei UI", "serif"]
COVER_MS = 180000

THEMES = dict(
    midnight=dict(bg="#06111d", bg2="#0d1b2b", ink="#f2ecdf", soft="#d6cec0", muted="#95a3b3", dim="#5f7182", accent="#c9a86a", accent2="#e8d4a6", accent3="#6f93a8", line=(201, 168, 106, 0.22), mark2="accent3", date="accent2", over=((6, 17, 29, 0.54), (13, 27, 43, 0.5))),
    rice=dict(bg="#bfb19b", bg2="#d1c4ae", ink="#211e19", soft="#3d372d", muted="#544a3c", dim="#736553", accent="#9f3c2c", accent2="#762b21", accent3="#3e5a60", line=(80, 60, 40, 0.22), mark2="accent", date="accent", over=((191, 177, 155, 0.62), (209, 196, 174, 0.56))),
    jade=dict(bg="#071410", bg2="#0d241c", ink="#e9f0e8", soft="#c9d8d0", muted="#93ada1", dim="#5f796d", accent="#a9c7b3", accent2="#e4dcc4", accent3="#c7a46e", line=(169, 199, 179, 0.22), mark2="accent3", date="accent3", over=((6, 17, 14, 0.6), (12, 33, 25, 0.55))),
    amber=dict(bg="#0d0a08", bg2="#1b130d", ink="#f3e8d7", soft="#d8c5ad", muted="#b3a18b", dim="#7f6e5b", accent="#d58b4b", accent2="#f0c48a", accent3="#6f8e88", line=(213, 139, 75, 0.22), mark2="accent2", date="accent2", over=((12, 9, 7, 0.58), (27, 18, 11, 0.52))),
)
MARK_SIZE = dict(midnight=(132, 21, 300), rice=(126, 19, 260), jade=(126, 19, 270), amber=(132, 20, 286))


def rgba(c, a=None):
    if isinstance(c, tuple):
        q = QColor(c[0], c[1], c[2])
        q.setAlphaF(c[3] if a is None else a)
        return q
    q = QColor(c)
    if a is not None:
        q.setAlphaF(a)
    return q


def ease(t):
    """cubic-bezier(.2,.7,.2,1) 的近似：快起慢收。"""
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def make_font(families, px, weight=400, spacing=0.0):
    f = QFont()
    f.setFamilies(families)
    f.setPixelSize(max(6, int(round(px))))
    f.setWeight(QFont.Weight(weight))
    f.setHintingPreference(QFont.HintingPreference.PreferNoHinting)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return f


class Text:
    """一段排好版的文字：知道自己多高，可以画到任意位置。"""

    def __init__(self, text, font, color, width, lh=1.5, justify=False, align="left", max_lines=0, balance=False):
        self.text, self.font, self.color, self.width = str(text or ""), font, color, max(10.0, width)
        self.lh = font.pixelSize() * lh
        self.justify, self.align, self.max_lines = justify, align, max_lines
        self.clipped = False
        self.lines = self._layout(self.width)
        if balance and self.lines > 1:   # 标题各行尽量等长（对应 text-wrap: balance）
            lo, hi, n = self.width * 0.45, self.width, self.lines
            for _i in range(8):
                mid = (lo + hi) / 2
                if self._layout(mid) <= n:
                    hi = mid
                else:
                    lo = mid
            self.lines = self._layout(hi)
        self.h = self.lines * self.lh if self.text else 0.0

    def _layout(self, w):
        lay = QTextLayout(self.text, self.font)
        opt = QTextOption()
        opt.setWrapMode(QTextOption.WrapMode.WordWrap)
        opt.setAlignment({"center": Qt.AlignmentFlag.AlignHCenter, "right": Qt.AlignmentFlag.AlignRight}.get(self.align, Qt.AlignmentFlag.AlignJustify if self.justify else Qt.AlignmentFlag.AlignLeft))
        lay.setTextOption(opt)
        lay.beginLayout()
        n = 0
        self.clipped = False
        while True:
            ln = lay.createLine()
            if not ln.isValid():
                break
            if self.max_lines and n >= self.max_lines:
                self.clipped = True
                ln.setLineWidth(-1)
                break
            ln.setLineWidth(w)
            ln.setPosition(QPointF(0, n * self.lh + (self.lh - ln.height()) / 2))
            n += 1
        lay.endLayout()
        self.layout = lay
        self.lay_w = w
        return n

    def draw(self, p, x, y):
        if not self.text:
            return
        dx = (self.width - self.lay_w) if self.align == "right" else (self.width - self.lay_w) / 2 if self.align == "center" else 0
        p.setPen(self.color)
        self.layout.draw(p, QPointF(x + dx, y))

    def natural_width(self):
        return QFontMetricsF(self.font).horizontalAdvance(self.text)


def stack_h(items):
    return sum(m + (it.h if it else 0) for it, m in items)


def stack(p, x, y, items):
    for it, m in items:
        y += m
        if it:
            it.draw(p, x, y)
            y += it.h
    return y


class Rule:
    """一条线也可以排进 stack。"""

    def __init__(self, w, color, thick=1.0):
        self.w, self.color, self.h = w, color, thick

    def draw(self, p, x, y):
        p.fillRect(QRectF(x, y, self.w, self.h), self.color)


class Painter:
    """按当前窗口尺寸和主题画封面、HUD、各页内容。"""

    def __init__(self, deck, w, h, texture=None, dpr=1.0):
        self.deck, self.W, self.H, self.dpr = deck, w, h, dpr
        self.theme = deck.get("theme") if deck.get("theme") in THEMES else "midnight"
        self.cover_kind = deck.get("cover") if deck.get("cover") in ("left", "center", "offset", "stack") else "left"
        self.t = THEMES[self.theme]
        self.texture = QImage(str(texture)) if texture else QImage()
        self.line = rgba(self.t["line"])
        self.fit = {}

    # ---- 尺寸
    def c(self, lo, vw, hi):
        return max(lo, min(hi, self.W * vw / 100))

    def col(self, k, a=None):
        return rgba(self.t[k], a)

    def pix(self):
        pm = QPixmap(int(self.W * self.dpr), int(self.H * self.dpr))
        pm.setDevicePixelRatio(self.dpr)
        pm.fill(Qt.GlobalColor.transparent)
        return pm

    @staticmethod
    def begin(pm):
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        return p

    # ---- 材质底板
    def _ellipse(self, p, rx, ry, fx, fy, color, stop):
        """radial-gradient(rx ry at fx% fy%, color, transparent stop%)。"""
        cx, cy = self.W * fx, self.H * fy
        g = QRadialGradient(QPointF(0, 0), 1)
        c0 = QColor(color)
        c1 = QColor(color)
        c1.setAlphaF(0)
        g.setColorAt(0, c0)
        g.setColorAt(stop, c1)
        g.setColorAt(1, c1)
        b = QBrush(g)
        b.setTransform(QTransform().translate(cx, cy).scale(rx, ry))
        p.fillRect(QRectF(0, 0, self.W, self.H), b)

    def plate(self, cover):
        pm = self.pix()
        p = self.begin(pm)
        W, H, th = self.W, self.H, self.theme
        g = QLinearGradient(0, 0, W, H)
        g.setColorAt(0, QColor(self.t["bg"]))
        g.setColorAt(1, QColor(self.t["bg2"]))
        p.fillRect(QRectF(0, 0, W, H), g)
        if not self.texture.isNull():
            tw, th_ = self.texture.width(), self.texture.height()
            k = max(W / tw, H / th_)
            sw, sh = tw * k, th_ * k
            p.drawImage(QRectF((W - sw) / 2, (H - sh) / 2, sw, sh), self.texture)
        ov = QLinearGradient(0, 0, W, H)
        ov.setColorAt(0, rgba(self.t["over"][0]))
        ov.setColorAt(1, rgba(self.t["over"][1]))
        p.fillRect(QRectF(0, 0, W, H), ov)
        if th == "midnight":
            self._ellipse(p, 900, 620, 0.18, 0.10, rgba((201, 168, 106, 0.13)), 0.62)
            self._ellipse(p, 800, 700, 0.88, 0.84, rgba((111, 147, 168, 0.17)), 0.60)
            p.fillRect(QRectF(W - 1, 0, 1, H), rgba((201, 168, 106, 0.18)))
        elif th == "rice":
            self._ellipse(p, 900, 600, 0.14, 0.12, rgba((159, 60, 44, 0.075)), 0.64)
            self._ellipse(p, 900, 700, 0.86, 0.88, rgba((62, 90, 96, 0.11)), 0.62)
            path = QPainterPath()
            for x in range(0, int(W), 4):
                path.addRect(QRectF(x, 0, 1, H))
            p.fillPath(path, rgba((80, 60, 40, 0.03)))
        elif th == "jade":
            self._ellipse(p, 900, 620, 0.78, 0.22, rgba((120, 180, 150, 0.14)), 0.62)
            self._ellipse(p, 760, 620, 0.12, 0.82, rgba((199, 164, 110, 0.12)), 0.64)
            for x in range(0, int(W), 104):
                p.fillRect(QRectF(x, 0, 1, H), rgba((169, 199, 179, 0.06)))
        else:
            self._ellipse(p, 900, 700, 0.75, 0.12, rgba((213, 139, 75, 0.09)), 0.60)
            self._ellipse(p, 800, 680, 0.18, 0.86, rgba((111, 142, 136, 0.10)), 0.64)
            p.setPen(Qt.PenStyle.NoPen)
            for x in range(7, int(W), 26):   # 胶片齿孔
                p.setBrush(rgba((213, 139, 75, 0.28)))
                p.drawEllipse(QPointF(x, 7), 1.6, 1.6)
                p.setBrush(rgba((213, 139, 75, 0.18)))
                p.drawEllipse(QPointF(x, H - 17), 1.6, 1.6)
        if cover:
            self._cover_grid(p)
        p.end()
        return pm

    def _cover_grid(self, p):
        W, H, th = self.W, self.H, self.theme
        if th == "jade":
            return
        if th == "amber":
            m = self.c(16, 2.2, 30)
            p.setPen(QPen(rgba((213, 139, 75, 0.18)), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(QRectF(m, m, W - 2 * m, H - 2 * m))
        step = 54 if th == "rice" else 72
        layer = self.pix()
        q = self.begin(layer)
        col = rgba((255, 255, 255, 0.018 * (0.35 if th == "rice" else 1)))
        for y in range(0, int(H), step):
            q.fillRect(QRectF(0, y, W, 1), col)
        for x in range(0, int(W), step):
            q.fillRect(QRectF(x, 0, 1, H), col)
        q.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)   # 只留中间，四周淡出
        g = QRadialGradient(QPointF(0, 0), 1)
        g.setColorAt(0.15, QColor(0, 0, 0, 255))
        g.setColorAt(0.78, QColor(0, 0, 0, 0))
        b = QBrush(g)
        b.setTransform(QTransform().translate(W / 2, H / 2).scale(W * 0.71, H * 0.71))
        q.fillRect(QRectF(0, 0, W, H), b)
        q.end()
        p.drawPixmap(0, 0, layer)

    # ---- 封面（动态部分由 alpha 控制）
    def cover_static(self):
        """封面上不动的文字；暮、省二字和短线单独画，好做入场动画。返回 (pixmap, 动态元素的位置)。"""
        pm = self.pix()
        p = self.begin(pm)
        W, H, d, k = self.W, self.H, self.deck, self.cover_kind
        padx, pady = self.c(30, 6, 112), self.c(26, 4.2, 66)
        bot = self.c(24, 3.2, 48)
        hud_f = make_font(MONO, self.c(10, 0.78, 13), 400, self.c(10, 0.78, 13) * 0.18)
        brand_f = make_font(MONO, self.c(10, 0.78, 13), 400, self.c(10, 0.78, 13) * 0.26)
        Text("GUANLAN / EVENING REVIEW", brand_f, self.col("accent"), W).draw(p, padx, pady)
        no = Text(f"NO.{d.get('issue', '')}", hud_f, self.col("muted"), 300, align="right")
        no.draw(p, W - padx - 108 - 300, pady)
        Text("观澜 · 每日视界", make_font(SANS, self.c(10, 0.78, 13), 400, 2), self.col("dim"), W).draw(p, padx, H - bot - self.c(10, 0.78, 13) * 1.5)
        mark_size = self.c(*MARK_SIZE[self.theme])
        if k == "offset":
            mark_size = self.c(140, 19, 272)
        elif k == "stack":
            mark_size = self.c(104, 13, 180)
        # 矮屏幕别让大字把封面撑破
        mark_size = min(mark_size, H * (0.30 if k == "stack" else 0.42))
        ey_f = make_font(SANS, self.c(10, 0.78, 13), 400, self.c(10, 0.78, 13) * 0.52)
        ki_f = make_font(SERIF, self.c(15, 1.2, 20), 400, self.c(15, 1.2, 20) * 0.18)
        da_f = make_font(SERIF, self.c(23, 2.3, 38), 400, self.c(23, 2.3, 38) * 0.08)
        me_f = make_font(MONO, self.c(11, 0.95, 15), 400, self.c(11, 0.95, 15) * 0.18)
        meta = f"今日 {d.get('count', 0)} 则 · 约 {d.get('minutes', 15)} 分钟"
        ey, ki, da = "晚间副刊", "今夜，先静三分钟", d.get("date_long", "")
        line_w = self.c(100, 10, 170)
        anim = dict(mark_size=mark_size, line_w=line_w)
        area_top, area_bot = pady + 30, H - bot - 30
        if k == "offset":
            lw = min(W - 2 * padx, 1540)
            x0 = (W - lw) / 2 if lw < W - 2 * padx else padx
            gap = self.c(30, 5, 88)
            lcol = (lw - gap) * 0.82 / 2.0
            items = [(Text(ey, ey_f, self.col("accent"), lcol), 0), (Text(ki, ki_f, self.col("soft"), lcol, lh=1.6), self.c(10, 1.2, 18)),
                     (Text(da, da_f, self.col(self.t["date"]), lcol, lh=1.3), self.c(28, 4, 58))]
            h1 = stack_h(items)
            lmargin = self.c(14, 1.8, 24)
            metat = Text(meta, me_f, self.col("muted"), lcol, lh=1.5)
            total = h1 + lmargin * 2 + 1 + metat.h
            y0 = (area_top + area_bot - total) / 2
            y = stack(p, x0, y0, items)
            anim.update(line_x=x0, line_y=y + lmargin, line_grad="left")
            metat.draw(p, x0, y + lmargin * 2 + 1)
            anim.update(mark_x=x0 + lw - mark_size * 2.1, mark_y=(area_top + area_bot) / 2 - mark_size * 0.5, mark_stack=False)
        else:
            center = k == "center"
            flip = k == "left" and self.theme == "jade"   # 青绿版的左版式靠右，和经线纹理相配
            main_w = min(W - 2 * padx, 1120 if center else 920 if k == "stack" else 1180)
            x0 = (W - main_w) / 2 if center else (W - padx - main_w) if flip else padx
            align = "center" if center else "right" if flip else "left"
            mark_h = mark_size * (1.96 if k == "stack" else 0.92)
            e_m, k_m = self.c(28, 4, 58), self.c(30, 3.4, 54)
            d_m = self.c(26, 2.4, 38) if k == "stack" else self.c(22, 2.2, 32)
            l_m = self.c(20, 2.2, 30)
            te, tk = Text(ey, ey_f, self.col("accent"), main_w, align=align), Text(ki, ki_f, self.col("soft"), main_w, lh=1.6, align=align)
            td, tm = Text(da, da_f, self.col(self.t["date"]), main_w, lh=1.3, align=align), Text(meta, me_f, self.col("muted"), main_w, lh=1.5, align=align)
            total = te.h + e_m + tk.h + k_m + mark_h + d_m + td.h + l_m * 2 + 1 + tm.h
            if total > area_bot - area_top:   # 矮屏幕压缩留白
                shrink = max(0.25, 1 - (total - (area_bot - area_top)) / max(1, e_m + k_m + d_m + 2 * l_m))
                e_m, k_m, d_m, l_m = e_m * shrink, k_m * shrink, d_m * shrink, l_m * shrink
                total = te.h + e_m + tk.h + k_m + mark_h + d_m + td.h + l_m * 2 + 1 + tm.h
            y = (area_top + area_bot - total) / 2
            te.draw(p, x0, y)
            y += te.h + e_m
            tk.draw(p, x0, y)
            y += tk.h + k_m
            mw = mark_size * 2.09
            anim.update(mark_x=(W - mw) / 2 if center else (W - padx - mw) if flip else x0, mark_y=y, mark_stack=k == "stack")
            y += mark_h + d_m
            td.draw(p, x0, y)
            y += td.h + l_m
            anim.update(line_x=(W - line_w) / 2 if center else (W - padx - line_w) if flip else x0, line_y=y, line_grad="center" if center else "left")
            y += 1 + l_m
            tm.draw(p, x0, y)
        p.end()
        anim.update(padx=padx, bot=bot)
        return pm, anim

    # ---- 页眉
    def hud(self):
        pm = self.pix()
        p = self.begin(pm)
        W, d = self.W, self.deck
        padx, top = self.c(28, 5, 88), self.c(22, 3, 46)
        fs = self.c(11, 0.86, 14)
        brand = Text("暮省", make_font(SERIF, self.c(17, 1.5, 23), 400, self.c(17, 1.5, 23) * 0.22), self.col("accent"), 200)
        brand.draw(p, padx, top)
        Text(d.get("date_short", ""), make_font(MONO, fs, 400, fs * 0.14), self.col("muted"), 500).draw(p, padx + brand.natural_width() + 18, top + (brand.h - fs * 1.5) / 2)
        pad_b = self.c(12, 1.4, 20)
        y = top + brand.h + pad_b
        p.fillRect(QRectF(padx, y, W - 2 * padx, 1), self.line)
        p.end()
        return pm, dict(padx=padx, top=top, hud_h=brand.h, rule_y=y, fs=fs)

    def hud_right(self, p, section, count, geo):
        W = self.W
        fs = geo["fs"]
        f = make_font(MONO, fs, 400, fs * 0.14)
        fm = QFontMetricsF(f)
        x = W - geo["padx"] - 108
        y = geo["top"] + (geo["hud_h"] - fs * 1.5) / 2
        for text, key in ((count, "dim"), (section, "accent2"), (f"NO.{self.deck.get('issue', '')}", "dim")):
            w = fm.horizontalAdvance(text) + 2
            x -= w
            Text(text, f, self.col(key), w + 6).draw(p, x, y)
            x -= 24

    # ---- 一页内容
    def slide_area(self, geo):
        padx = geo["padx"]
        bot = self.c(18, 2.4, 34) + self.c(10, 1.2, 16) + 1
        pad_y = self.c(26, 4, 64)
        return padx, geo["rule_y"] + 1 + pad_y, self.W - 2 * padx, self.H - bot - pad_y - geo["rule_y"] - 1 - pad_y

    def slide(self, s, geo):
        """把一页画成透明 pixmap；放不下时整页缩小。"""
        pm = self.pix()
        p = self.begin(pm)
        x, y, w, h = self.slide_area(geo)
        kind = s.get("kind")
        if kind != "end":
            gap = self.c(30, 5, 88)
            rail_w = max(80, (w - gap) * 0.23 / 1.23)
            self._rail(p, s, x, y, rail_w, h)
            bx, bw = x + rail_w + gap, w - rail_w - gap
        else:
            bx, bw = x, w
        fn = getattr(self, "_s_" + str(kind), None)
        scale = 1.0
        if fn:
            while True:
                body_h, draw = fn(s, bw, scale)
                if body_h <= h or scale <= 0.55:
                    break
                scale -= 0.04
            self.fit[id(s)] = (scale, body_h, h)
            draw(p, bx, y + (h - body_h) / 2)
        p.end()
        return pm

    def _rail(self, p, s, x, y, w, h):
        pad = self.c(8, 1.4, 20)
        right = x + w
        p.fillRect(QRectF(right, y, 1, h), self.line)
        idx = make_font(SERIF, self.c(24, 2.8, 48))
        Text(f"{int(s.get('rail_index') or 0):02d}", idx, self.col("accent"), w).draw(p, x, y + pad)
        size = self.c(10, 0.78, 13)
        f = make_font(SANS, size)
        step = size * 1.5
        label = str(s.get("rail_label") or "")
        lx = right - self.c(16, 2, 28) - size
        seal = self.theme == "rice"
        by = y + h - pad - (self.c(62, 6, 82) if seal else 0)
        ly = by - len(label) * step
        p.setPen(self.col("muted"))
        p.setFont(f)
        for i, ch in enumerate(label):
            p.drawText(QRectF(lx - size / 2, ly + i * step, size * 2, step), Qt.AlignmentFlag.AlignCenter, ch)
        if seal:   # 宣纸版的朱印
            sz = self.c(36, 3.2, 46)
            sx, sy = right - sz, y + h - sz
            p.setPen(QPen(rgba((159, 60, 44, 0.62)), 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(QRectF(sx, sy, sz, sz))
            p.setPen(rgba((159, 60, 44, 0.82)))
            p.setFont(make_font(SERIF, self.c(18, 1.7, 24)))
            p.drawText(QRectF(sx, sy, sz, sz), Qt.AlignmentFlag.AlignCenter, "观")

    def _h2(self, text, w, px, scale=1.0, balance=True):
        """标题 + 各材质的装饰线，返回 stack 项。"""
        t = Text(text, make_font(SERIF, px * scale, 500), self.col("ink"), w, lh=1.22, balance=balance)
        pad = self.c(12, 1.4, 18)
        items = []
        if self.theme == "midnight":
            items += [(Rule(w, rgba((201, 168, 106, 0.24))), 0), (None, pad)]
        elif self.theme == "jade":
            items += [(Rule(w, rgba((169, 199, 179, 0.18))), 0), (None, pad)]
        items.append((t, 0))
        if self.theme == "rice":
            items += [(None, self.c(10, 1.2, 16)), (Rule(w, rgba((159, 60, 44, 0.3))), 0)]
        return items

    def _meta(self, s, w, scale=1.0):
        fs = self.c(14, 1, 16) * max(scale, 0.8)
        return Text(s.get("meta", ""), make_font(MONO + SANS, fs, 400, fs * 0.06), self.col("muted"), w)

    def _s_lead(self, s, w, scale):
        w = min(w, 1220, self.W * 0.88)
        items = self._h2(s.get("title"), w, self.c(40, 5.1, 86), scale)
        items.append((None, self.c(18, 2.2, 30) * scale))
        q = s.get("question")
        qt = None
        if q:
            pad = self.c(16, 1.6, 22)
            qw = min(w, 980) - pad
            e = Text("留一个问题", make_font(SANS, 10, 400, 2.2), self.col("muted"), qw, lh=1.6)
            body = Text(q, make_font(SERIF, self.c(18, 1.45, 24) * scale), self.col("accent2"), qw, lh=1.7)
            qt = _Quote(e, body, pad, self.col("accent"))
            items += [(qt, 0), (None, self.c(22, 2.6, 34) * scale)]
        items.append((Text(s.get("summary"), make_font(SANS, self.c(18, 1.5, 25) * scale), self.col("soft"), min(w, 980), lh=1.9 if scale > 0.8 else 1.7, justify=True), 0))
        items.append((self._meta(s, w, scale), self.c(22, 2.5, 36) * scale))
        return stack_h(items), lambda p, x, y: stack(p, x, y, items)

    def _s_story(self, s, w, scale):
        w = min(w, 1160, self.W * 0.88)
        items = []
        if s.get("tags"):
            items += [(_Pills(s["tags"], self), 0), (None, 20 * scale)]
        items += self._h2(s.get("title"), w, self.c(34, 4.2, 72), scale, balance=False)
        items.append((None, self.c(18, 2.2, 30) * scale))
        items.append((Text(s.get("summary"), make_font(SANS, self.c(17, 1.35, 22) * scale), self.col("soft"), min(w, 980), lh=1.9 if scale > 0.8 else 1.7, justify=True), 0))
        items.append((self._meta(s, w, scale), self.c(22, 2.5, 36) * scale))
        return stack_h(items), lambda p, x, y: stack(p, x, y, items)

    def _seal(self, p, cx, cy, r, ch, inner=True):
        p.setPen(QPen(self.col("accent"), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx, cy), r, r)
        if inner:
            p.setPen(QPen(self.line, 1))
            p.drawEllipse(QPointF(cx, cy), r - 14, r - 14)
        p.setPen(self.col("accent2"))
        p.setFont(make_font(SERIF, r * 0.84))
        p.drawText(QRectF(cx - r, cy - r, 2 * r, 2 * r), Qt.AlignmentFlag.AlignCenter, str(ch)[:2])

    def _s_person(self, s, w, scale):
        w = min(w, 1160, self.W * 0.88)
        seal = self.c(150, 14, 240) * scale
        gap = self.c(34, 5, 78)
        rw = w - seal - gap
        n = Text(s.get("name"), make_font(SERIF, self.c(42, 4.6, 78) * scale, 500), self.col("ink"), rw, lh=1.1)
        lat = Text(s.get("latin"), make_font(MONO, self.c(10, 0.8, 13), 400, 2), self.col("accent"), rw)
        ide = Text(s.get("identity"), make_font(SANS, self.c(16, 1.2, 20) * scale), self.col("muted"), rw)
        hd = Text(s.get("headline"), make_font(SERIF, self.c(20, 1.8, 30) * scale), self.col("accent2"), rw, lh=1.6)
        st = Text(s.get("story"), make_font(SANS, self.c(15, 1.1, 18) * scale), self.col("soft"), rw, lh=1.85, justify=True)
        items = [(n, 0), (lat, 10), (ide, 12), (hd, 20 * scale), (st, 16 * scale)]
        moments = s.get("moments") or []
        if moments:
            items += [(None, self.c(20, 2.4, 32) * scale), (Rule(rw, self.line), 0), (None, self.c(14, 1.8, 24) * scale), (_Moments(moments, rw, self, scale), 0)]
        H = stack_h(items)

        def draw(p, x, y):
            self._seal(p, x + seal / 2, y + H / 2, seal / 2, s.get("monogram", ""))
            stack(p, x + seal + gap, y, items)
        return max(H, seal), draw

    def _s_people(self, s, w, scale):
        w = min(w, 1540, self.W * 0.94)
        h2 = Text(s.get("title", "今夜三个人"), make_font(SERIF, self.c(32, 3.4, 54) * scale, 500), self.col("ink"), w * 0.6, lh=1.15)
        sub = Text(s.get("sub", ""), make_font(SERIF, self.c(15, 1.15, 19) * scale, 400, 1), self.col("muted"), w * 0.4, align="right")
        pb = self.c(14, 1.6, 20)
        head_h = h2.h + pb + 1
        cards = s.get("cards") or []
        n = max(1, len(cards))
        gap = self.c(22, 3, 44)
        cw = (w - gap * (n - 1)) / n
        built = [self._card(c, cw, scale) for c in cards]
        ch = max([b[0] for b in built] + [0])
        vg = self.c(24, 3, 42) * scale

        def draw(p, x, y):
            h2.draw(p, x, y)
            sub.draw(p, x + w * 0.6, y + h2.h - sub.h)
            p.fillRect(QRectF(x, y + h2.h + pb, w, 1), self.line)
            yy = y + head_h + vg
            for i, b in enumerate(built):
                b[1](p, x + i * (cw + gap), yy, ch)
        return head_h + vg + ch, draw

    def _card(self, c, w, scale):
        size = self.c(44, 4, 58) * scale
        top_x = size + 14
        name = Text(c.get("name"), make_font(SERIF, self.c(28, 2.8, 42) * scale), self.col("ink"), w - top_x, lh=1.1)
        lat = Text(" · ".join(x for x in (c.get("latin"), c.get("years")) if x), make_font(MONO, 9, 400, 1.2), self.col("accent"), w - top_x)
        top_h = max(size, name.h + 5 + lat.h)
        ide = Text(c.get("identity"), make_font(SANS, self.c(12, 0.92, 15) * scale), self.col("muted"), w, lh=1.6)
        hl = Text(c.get("headline"), make_font(SERIF, self.c(17, 1.35, 22) * scale), self.col("accent2"), w, lh=1.65)
        st = Text(c.get("story"), make_font(SANS, self.c(13, 0.95, 16) * scale), self.col("soft"), w, lh=1.85)
        items = [(ide, 8), (hl, 12), (st, 12)]
        mo = c.get("moment")
        if mo:
            items.append((_MomentBar(mo, w, self, scale), 16))
        q = c.get("quote")
        qt = Text(f"“{q}”", make_font(SERIF, self.c(12, 0.9, 15) * scale), self.col("muted"), w, lh=1.65) if q else None
        pt = self.c(16, 1.7, 22)
        body = top_h + 14 + stack_h(items)
        qh = (16 + 16 + qt.h) if qt else 0
        H = 1 + pt + body + qh

        def draw(p, x, y, full):
            p.fillRect(QRectF(x, y, w, 1), self.col("accent"))
            yy = y + 1 + pt
            cy = yy + top_h / 2
            self._seal(p, x + size / 2, cy, size / 2, c.get("monogram", ""), inner=False)
            name.draw(p, x + top_x, cy - (name.h + 5 + lat.h) / 2)
            lat.draw(p, x + top_x, cy - (name.h + 5 + lat.h) / 2 + name.h + 5)
            stack(p, x, yy + top_h + 14, items)
            if qt:   # 金句贴底
                qy = y + full - qt.h
                p.fillRect(QRectF(x, qy - 16, w, 1), self.line)
                qt.draw(p, x, qy)
        return H, draw

    def _s_quotes(self, s, w, scale):
        h2 = self._h2(s.get("title", "把一句话，带到明天"), w, self.c(34, 4.2, 72), scale, balance=False)
        cards = s.get("cards") or []
        n = max(1, len(cards))
        gap = self.c(18, 2.5, 34)
        cw = (w - gap * (n - 1)) / n
        built = []
        pt = self.c(20, 2.4, 34) * scale
        for c in cards:
            bq = Text(c.get("text"), make_font(SERIF, self.c(20, 1.65, 28) * scale), self.col("ink"), cw, lh=1.72)
            au = Text(c.get("author"), make_font(MONO + SANS, self.c(10, 0.8, 12), 400, 1.2), self.col("accent2"), cw, lh=1.5)
            us = Text(c.get("use"), make_font(SANS, self.c(12, 0.9, 14) * scale), self.col("muted"), cw, lh=1.65)
            built.append((bq, au, us))
        tail = max([b[1].h + 12 + b[2].h for b in built] + [0])
        top = max([b[0].h for b in built] + [0])
        ch = max(1 + pt + top + 22 + tail, self.H * 0.26 * scale)
        h2h = stack_h(h2)
        m = self.c(18, 2.2, 30) * scale + 6

        def draw(p, x, y):
            yy = stack(p, x, y, h2) + m
            for i, (bq, au, us) in enumerate(built):
                cx = x + i * (cw + gap)
                p.fillRect(QRectF(cx, yy, cw, 1), self.col("accent"))
                bq.draw(p, cx, yy + 1 + pt)
                bottom = yy + ch
                us.draw(p, cx, bottom - us.h)
                au.draw(p, cx, bottom - us.h - 12 - au.h)
        return h2h + m + ch, draw

    def _s_term(self, s, w, scale):
        gap = self.c(34, 5, 84)
        lw = (w - gap) * 1.05 / 2
        rw = (w - gap) * 0.95 / 2
        word = Text(s.get("term"), make_font(SERIF, self.c(56, 7, 118) * scale), self.col("ink"), lw, lh=1.1)
        en = Text(s.get("en"), make_font(MONO, self.c(10, 0.8, 13), 400, 2), self.col("accent"), lw)
        de = Text(s.get("definition"), make_font(SANS, self.c(17, 1.35, 22) * scale), self.col("soft"), lw, lh=1.85, justify=True)
        left = [(word, 0), (en, 14), (de, self.c(22, 2.6, 36) * scale)]
        pad = self.c(20, 3, 44)
        tw = rw - pad
        right = []
        for i, (k, v) in enumerate(s.get("side") or []):
            right.append((Text(k, make_font(SANS, self.c(13, 1, 16) * scale, 400, 1.5), self.col("accent2"), tw), 16 if i else 0))
            right.append((Text(v, make_font(SANS, self.c(13, 1, 16) * scale), self.col("muted"), tw, lh=1.8), 4))
        lh, rh = stack_h(left), stack_h(right)
        H = max(lh, rh)

        def draw(p, x, y):
            stack(p, x, y + (H - lh) / 2, left)
            rx = x + lw + gap
            p.fillRect(QRectF(rx, y + (H - rh) / 2, 1, rh), self.line)
            stack(p, rx + pad, y + (H - rh) / 2, right)
        return H, draw

    def _s_end(self, s, w, scale):
        mk = Text("今夜已尽", make_font(SERIF, self.c(62, 9, 148) * scale, 400, self.c(62, 9, 148) * 0.08 * scale), self.col("ink"), w, lh=1.2, align="center")
        sub = Text(s.get("sub", ""), make_font(SERIF, self.c(17, 1.4, 24) * scale), self.col("muted"), w, align="center")
        hint = Text("Esc 退出  ·  空格暂停  ·  ← → 翻页", make_font(SANS, self.c(10, 0.8, 12), 400, 1.5), self.col("dim"), w, align="center")
        items = [(mk, 0), (sub, 22), (hint, 48)]
        return stack_h(items), lambda p, x, y: stack(p, x, y, items)


class _Quote:
    """左边一条竖线的「留一个问题」。"""

    def __init__(self, e, body, pad, color):
        self.e, self.body, self.pad, self.color = e, body, pad, color
        self.h = e.h + 8 + body.h

    def draw(self, p, x, y):
        p.fillRect(QRectF(x, y, 2, self.h), self.color)
        self.e.draw(p, x + self.pad, y)
        self.body.draw(p, x + self.pad, y + self.e.h + 8)


class _Pills:
    def __init__(self, tags, P):
        self.P = P
        self.fs = P.c(9, 0.72, 11)
        self.f = make_font(MONO + SANS, self.fs, 400, self.fs * 0.12)
        self.tags = [str(t) for t in tags]
        self.h = self.fs * 1.5 + 10

    def draw(self, p, x, y):
        fm = QFontMetricsF(self.f)
        for t in self.tags:
            w = fm.horizontalAdvance(t) + 22
            p.setPen(QPen(self.P.line, 1))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(QRectF(x, y, w, self.h), self.h / 2, self.h / 2)
            p.setFont(self.f)
            p.setPen(self.P.col("muted"))
            p.drawText(QRectF(x, y, w, self.h), Qt.AlignmentFlag.AlignCenter, t)
            x += w + 10


class _Moments:
    def __init__(self, moments, w, P, scale):
        gap = P.c(14, 2, 26)
        self.cw = (w - gap * 2) / 3
        self.gap = gap
        fs = P.c(12, 0.9, 15) * scale
        self.cols = [(Text(m.get("year"), make_font(MONO, fs, 400, fs * 0.14), P.col("accent"), self.cw), Text(m.get("text"), make_font(SANS, fs), P.col("muted"), self.cw, lh=1.55)) for m in moments[:3]]
        self.h = max([a.h + 7 + b.h for a, b in self.cols] + [0])

    def draw(self, p, x, y):
        for i, (a, b) in enumerate(self.cols):
            cx = x + i * (self.cw + self.gap)
            a.draw(p, cx, y)
            b.draw(p, cx, y + a.h + 7)


class _MomentBar:
    def __init__(self, m, w, P, scale):
        fs = P.c(11, 0.82, 13) * scale
        self.a = Text(m.get("year"), make_font(MONO, fs, 400, fs * 0.1), P.col("accent2"), w - 12, lh=1.65)
        self.b = Text(m.get("text"), make_font(SANS, fs), P.col("muted"), w - 12, lh=1.65)
        self.color = P.col("accent")
        self.h = self.a.h + self.b.h

    def draw(self, p, x, y):
        p.fillRect(QRectF(x, y, 2, self.h), self.color)
        self.a.draw(p, x + 12, y)
        self.b.draw(p, x + 12, y + self.a.h)


class EveningWindow(QWidget):
    def __init__(self, deck, texture=None, cover_ms=COVER_MS):
        super().__init__()
        self.deck, self.texture = deck, texture
        self.cover_ms = cover_ms
        self.slides = deck.get("slides") or []
        self.setWindowTitle(deck.get("title") or "暮省")
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.phase = "cover"
        self.t0 = time.perf_counter()
        self.cur = 0
        self.prev_i = None
        self.slide_t = 0.0
        self.paused, self.ended = False, False
        self.total, self.remaining, self.started = 1.0, 1.0, 0.0
        self.controls_until = time.perf_counter() + 3.2
        self.hits = []
        self.P = None
        self.cache = {}
        self.exit_hover = False
        self.tick = QTimer(self)
        self.tick.setTimerType(Qt.TimerType.PreciseTimer)
        self.tick.timeout.connect(self._tick)
        self.tick.start(16)
        self._last_soft = 0.0
        self.preload = QTimer(self)
        self.preload.setSingleShot(True)
        self.preload.timeout.connect(self._preload_next)

    # ---- 素材
    def _prepare(self):
        w, h = self.width(), self.height()
        key = (w, h, self.devicePixelRatioF())
        if self.P and self.P_key == key:
            return
        self.P_key = key
        self.P = Painter(self.deck, w, h, self.texture, self.devicePixelRatioF())
        self.cache = {}
        self.plate_cover = self.P.plate(True)
        self.plate_deck = self.P.plate(False)
        self.cover_pm, self.cover_anim = self.P.cover_static()
        self.hud_pm, self.geo = self.P.hud()

    def _slide_pm(self, i):
        if i not in self.cache:
            self.cache[i] = self.P.slide(self.slides[i], self.geo)
        return self.cache[i]

    def _preload_next(self):
        if self.P and self.cur + 1 < len(self.slides):
            self._slide_pm(self.cur + 1)

    # ---- 状态
    def skip_cover(self):
        if self.phase == "cover":
            self.phase = "leaving"
            self.t0 = time.perf_counter()
            self.update()

    def show_slide(self, i, animate=True):
        if not self.slides:
            return
        i = max(0, min(len(self.slides) - 1, i))
        self.prev_i = self.cur if animate and i != self.cur else None
        self.cur = i
        self.ended = False
        self.paused = False
        d = max(6.0, float(self.slides[i].get("duration") or 20))
        self.total = self.remaining = d
        self.started = self.slide_t = time.perf_counter()
        self.preload.start(1000)   # 等这页的入场动画走完再排下一页
        self.wake()
        self.update()

    def next_slide(self):
        if self.ended:
            return
        if self.cur >= len(self.slides) - 1:
            self.finish()
        else:
            self.show_slide(self.cur + 1)

    def finish(self):
        self.ended, self.paused = True, False
        self.controls_until = math.inf
        self.update()

    def toggle_pause(self):
        if self.ended:
            self.controls_until = 0
            self.show_slide(0)
            return
        now = time.perf_counter()
        if not self.paused:
            self.paused = True
            self.remaining = max(0.6, self.remaining - (now - self.started))
        else:
            self.paused = False
            self.started = now
        self.wake()
        self.update()

    def go(self, delta):
        if self.phase == "cover":
            self.skip_cover()
            return
        if self.phase != "deck":
            return
        if delta > 0 and self.cur >= len(self.slides) - 1:
            self.finish()
            return
        if self.ended:
            self.controls_until = 0
        self.show_slide(self.cur + delta)

    def wake(self):
        if not self.ended:
            self.controls_until = time.perf_counter() + 3.2
        self.setCursor(Qt.CursorShape.ArrowCursor)

    def bar_ratio(self):
        if self.ended:
            return 1.0
        left = self.remaining if self.paused else self.remaining - (time.perf_counter() - self.started)
        return max(0.0, min(1.0, 1 - left / self.total))

    # ---- 节拍：动画时全屏重绘，静止时只刷进度条
    def _tick(self):
        now = time.perf_counter()
        el = now - self.t0
        if self.phase == "cover":
            if el * 1000 >= self.cover_ms:
                self.skip_cover()
            elif el < 2.0:
                self.update()
            elif now - self._last_soft > 0.25:
                self._last_soft = now
                self.update()
            return
        if self.phase == "leaving":
            if el >= 0.9:
                self.phase = "deck"
                self.t0 = now
                self.prev_i = None
                self.cur = 0
                self.show_slide(0, animate=False)
            self.update()
            return
        if self.phase != "deck":
            return
        if not self.paused and not self.ended and now - self.started >= self.remaining:
            self.next_slide()
        if el < 0.9 or now - self.slide_t < 0.85:
            self.update()
        elif now - self._last_soft > 0.1:
            self._last_soft = now
            if self.controls_until != math.inf and now > self.controls_until:
                if self.cursor().shape() != Qt.CursorShape.BlankCursor:
                    self.setCursor(Qt.CursorShape.BlankCursor)
                    self.update()
            self.update(0, self.height() - 120, self.width(), 120)   # 进度条与控制条都在底部

    # ---- 绘制
    def paintEvent(self, _e):
        self._prepare()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self.hits = []
        now = time.perf_counter()
        if self.phase in ("cover", "leaving"):
            if self.phase == "leaving":
                k = min(1.0, (now - self.t0) / 0.9)
                p.drawPixmap(0, 0, self.plate_deck)
                p.setOpacity(1 - k)
                s = 1 + 0.025 * ease(k)
                p.translate(self.width() / 2, self.height() / 2)
                p.scale(s, s)
                p.translate(-self.width() / 2, -self.height() / 2)
                self._paint_cover(p, 9.0)
                p.resetTransform()
                p.setOpacity(1)
            else:
                self._paint_cover(p, now - self.t0)
        else:
            self._paint_deck(p, now)
        self._paint_exit(p)
        p.end()

    def _paint_cover(self, p, el):
        P, W, H = self.P, self.width(), self.height()
        p.drawPixmap(0, 0, self.plate_cover)
        p.save()
        p.setOpacity(p.opacity() * ease(el / 1.15))
        p.drawPixmap(0, 0, self.cover_pm)
        p.restore()
        a = self.cover_anim
        # 暮省二字：上浮淡入
        k = ease((el - 0.08) / 1.5)
        size = a["mark_size"]
        f = make_font(SERIF, size, 500)
        p.save()
        p.setOpacity(p.opacity() * k)
        p.setFont(f)
        dy = 18 * (1 - k)
        x, y = a["mark_x"], a["mark_y"] + dy
        fm = QFontMetricsF(f)
        base = y + fm.ascent() - (fm.height() - size * 0.92) / 2
        step = size * 1.045
        mark2 = P.col(P.t["mark2"])
        for shadow in (True, False):
            for i, ch in enumerate("暮省"):
                if a["mark_stack"]:
                    cx, cy = x + (size * 0.5 if i else 0), base + i * size * 0.98
                else:
                    cx, cy = x + i * step, base - (size * 0.03 if self.P.theme == "midnight" and i == 0 else 0)
                if shadow:
                    if P.theme != "rice":
                        p.setPen(QColor(0, 0, 0, 60))
                        p.drawText(QPointF(cx, cy + size * 0.05), ch)
                else:
                    p.setPen(mark2 if i else P.col("ink"))
                    p.drawText(QPointF(cx, cy), ch)
        p.restore()
        # 短线：展开
        k = ease((el - 0.38) / 1.2)
        lw, lx, ly = a["line_w"], a["line_x"], a["line_y"]
        g = QLinearGradient(lx, 0, lx + lw, 0)
        if a["line_grad"] == "center":
            c0 = QColor(P.t["accent"])
            c0.setAlpha(0)
            g.setColorAt(0, c0)
            g.setColorAt(0.5, QColor(P.t["accent"]))
            g.setColorAt(1, c0)
            draw_x = lx + lw * (1 - k) / 2
        else:
            c0 = QColor(P.t["accent"])
            c0.setAlpha(0)
            g.setColorAt(0, QColor(P.t["accent"]))
            g.setColorAt(0.6, QColor(P.t["accent3"]))
            g.setColorAt(1, c0)
            draw_x = lx
        p.fillRect(QRectF(draw_x, ly, lw * k, 1), g)
        # 倒计时与进度
        left = max(0.0, self.cover_ms / 1000 - el)
        s = math.ceil(left)
        fs = P.c(10, 0.78, 13)
        foot_y = H - a["bot"] - fs * 1.5
        cd = Text(f"{s // 60:02d}:{s % 60:02d}", make_font(MONO, fs, 400, fs * 0.2), P.col("accent2"), fs * 6, align="right")
        cd.draw(p, W - a["padx"] - 108 - fs * 6, foot_y)
        lb = Text("静候  ·  按 → 开始", make_font(SANS, fs * 0.9, 400, 1), P.col("dim"), 220, align="right")
        lb.draw(p, W - a["padx"] - 108 - fs * 6 - 8 - 220, foot_y + 1)
        ratio = min(1.0, el * 1000 / self.cover_ms)
        p.fillRect(QRectF(0, H - 2, W, 2), QColor(255, 255, 255, 13))
        bar = QLinearGradient(0, 0, W, 0)
        bar.setColorAt(0, QColor(P.t["accent"]))
        bar.setColorAt(1, QColor(P.t["accent2"]))
        p.fillRect(QRectF(0, H - 2, W * ratio, 2), bar)

    def _paint_deck(self, p, now):
        P, W, H = self.P, self.width(), self.height()
        p.drawPixmap(0, 0, self.plate_deck)
        p.setOpacity(ease((now - self.t0) / 0.9))
        p.drawPixmap(0, 0, self.hud_pm)
        s = self.slides[self.cur] if self.slides else {}
        P.hud_right(p, s.get("section", "暮省"), f"{self.cur + 1:02d} / {len(self.slides):02d}", self.geo)
        base = p.opacity()
        e = now - self.slide_t
        if self.prev_i is not None and e < 0.65:
            p.setOpacity(base * (1 - min(1, e / 0.65)))
            p.drawPixmap(0, 0, self._slide_pm(self.prev_i))
        if self.slides:
            k = min(1.0, e / 0.65)
            dy = 28 * (1 - ease(e / 0.8))
            p.setOpacity(base * k)
            p.drawPixmap(QPointF(0, dy), self._slide_pm(self.cur))
        p.setOpacity(1)
        # 进度条
        padx, by = self.geo["padx"], H - P.c(18, 2.4, 34) - 1
        bw = W - 2 * padx
        p.fillRect(QRectF(padx, by, bw, 1), QColor(255, 255, 255, 18) if P.theme != "rice" else QColor(0, 0, 0, 24))
        g = QLinearGradient(padx, 0, padx + bw, 0)
        g.setColorAt(0, QColor(P.t["accent"]))
        g.setColorAt(1, QColor(P.t["accent2"]))
        p.fillRect(QRectF(padx, by, bw * self.bar_ratio(), 1), g)
        if now < self.controls_until:
            self._paint_controls(p, by)

    def _paint_controls(self, p, by):
        P, W = self.P, self.width()
        fs = P.c(11, 0.8, 13)
        f = make_font(SANS, fs)
        fm = QFontMetricsF(f)
        hint = "空格暂停 · ← → 翻页 · Esc 退出"
        h_f = make_font(SANS, 10, 400, 0.8)
        h_w = QFontMetricsF(h_f).horizontalAdvance(hint) + 18
        pause = "重播" if self.ended else ("继续" if self.paused else "暂停")
        btns = [("←", "prev"), (pause, "pause"), ("→", "next")]
        tail = ("关闭", "close")
        widths = [fm.horizontalAdvance(t) + 22 for t, _k in btns]
        cw = fm.horizontalAdvance(tail[0]) + 22
        total = sum(widths) + h_w + cw + 6 * 6
        H_ = fs * 1.5 + 14 + 12
        x, y = W - self.geo["padx"] - total, by - 16 - H_
        rice = P.theme == "rice"
        p.setPen(QPen(P.line, 1))
        p.setBrush(QColor(245, 240, 230, 225) if rice else QColor(8, 14, 22, 184))
        p.drawRoundedRect(QRectF(x, y, total, H_), 10, 10)
        cx = x + 6
        p.setFont(f)
        for (t, k), w in zip(btns, widths):
            r = QRectF(cx, y + 6, w, H_ - 12)
            self.hits.append((r, k))
            p.setFont(f)
            p.setPen(P.col("muted"))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, t)
            cx += w + 6
        p.setFont(h_f)
        p.setPen(P.col("dim"))
        p.drawText(QRectF(cx, y + 6, h_w, H_ - 12), Qt.AlignmentFlag.AlignCenter, hint)
        cx += h_w + 6
        r = QRectF(cx, y + 6, cw, H_ - 12)
        self.hits.append((r, "close"))
        p.setFont(f)
        p.setPen(P.col("muted"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, tail[0])

    def _paint_exit(self, p):
        P = self.P
        m = P.c(12, 1.5, 20)
        fs = P.c(10, 0.72, 11)
        f = make_font(SANS, fs, 400, fs * 0.18)
        text = "退出"
        w = QFontMetricsF(f).horizontalAdvance(text) + 26
        h = fs * 1.5 + 14
        r = QRectF(self.width() - m - w, m, w, h)
        self.hits.append((r, "close"))
        rice = P.theme == "rice"
        p.setPen(QPen(P.col("accent") if self.exit_hover else P.line, 1))
        p.setBrush(QColor(214, 201, 180, 240) if rice else QColor(8, 14, 22, 200 if self.exit_hover else 97))
        p.drawRoundedRect(r, h / 2, h / 2)
        p.setFont(f)
        p.setPen(QColor("#332e26") if rice else P.col("ink" if self.exit_hover else "soft"))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, text)

    # ---- 操作
    def _act(self, k):
        if k == "close":
            self.close()
        elif k == "pause":
            self.toggle_pause()
        elif k == "next":
            self.go(1)
        elif k == "prev":
            self.go(-1)

    def keyPressEvent(self, e):
        k = e.key()
        if k == Qt.Key.Key_Escape:
            self.close()
        elif k == Qt.Key.Key_Space:
            self.skip_cover() if self.phase == "cover" else self.toggle_pause() if self.phase == "deck" else None
        elif k in (Qt.Key.Key_Right, Qt.Key.Key_PageDown, Qt.Key.Key_Down):
            self.go(1)
        elif k in (Qt.Key.Key_Left, Qt.Key.Key_PageUp, Qt.Key.Key_Up):
            self.go(-1)
        elif k == Qt.Key.Key_F11:
            self.showNormal() if self.isFullScreen() else self.showFullScreen()
        else:
            super().keyPressEvent(e)

    def mouseMoveEvent(self, e):
        self.wake()
        pos = e.position()
        hover = any(r.contains(pos) and k == "close" and r.top() < 80 for r, k in self.hits)
        if hover != self.exit_hover:
            self.exit_hover = hover
        self.update()

    def mousePressEvent(self, e):
        pos = e.position()
        for r, k in self.hits:
            if r.contains(pos):
                self._act(k)
                return
        if self.phase == "cover":
            self.skip_cover()

    def closeEvent(self, e):
        self.tick.stop()
        super().closeEvent(e)


def play(deck, texture=None) -> int:
    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("见微暮省")
    win = EveningWindow(deck, texture)
    win.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
    screen = QGuiApplication.primaryScreen()
    if screen is not None:
        win.setGeometry(screen.geometry())
    win.showFullScreen()
    win.raise_()
    win.activateWindow()
    return app.exec()


def notify_failure(message) -> int:
    """没有内容可播时给个交代（8 秒后自己消失，不挡夜里的自动触发）。"""
    app = QApplication.instance() or QApplication(sys.argv[:1])
    box = QMessageBox(QMessageBox.Icon.Information, "暮省", message)
    QTimer.singleShot(8000, box.close)
    box.show()
    box.finished.connect(lambda _r: app.quit())
    QTimer.singleShot(8200, app.quit)
    return app.exec()

