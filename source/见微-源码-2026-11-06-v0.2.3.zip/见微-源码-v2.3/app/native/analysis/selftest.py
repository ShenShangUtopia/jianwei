"""析题流程自测（不联网）：假的 AI 引擎走完「读题 → 校验修正 → 程序求解 → 核对 → 纠错」，离线读题器，11+6 个题型图解。

python -m native.analysis.selftest <输出目录>
"""
from __future__ import annotations

from ..kit import test_runtime

test_runtime.configure()

import json
import os
import sys
import time
import traceback


class FakeEngine:
    """按顺序吐回答；记下收到的消息，方便检查修正轮次。"""

    name = "fake"

    def __init__(self, replies):
        self.replies = list(replies)
        self.seen = []
        self.calls = 0

    def ask(self, messages, deep=False, on_text=None, on_think=None, status=None):
        self.calls += 1
        self.seen.append(messages)
        r = self.replies.pop(0) if self.replies else "{}"
        text = r if isinstance(r, str) else json.dumps(r, ensure_ascii=False)
        if on_text:
            on_text(text[: len(text) // 2])
            on_text(text)
        return text, False


GOOD = dict(subject="物理", topic="斜面", module=None, summary="物块沿斜面下滑", knowns=["θ=37°"], assumptions=[], method="牛二", steps=["受力", "列式", "求解"], answer="a=4 m/s²，t=2 s", check="ok", pitfalls=["摩擦力"],
            model=dict(knowns=[dict(name="th", value=37, unit="°"), dict(name="L", value=8, unit="m"), dict(name="mu", value=0.25, unit=""), dict(name="g", value=10, unit="m/s²")], unknowns=[dict(name="a", unit="m/s²"), dict(name="t", unit="s", guess=2, min=0)],
                       equations=[dict(eq="a = g*sin(th) - mu*g*cos(th)", why="牛二"), dict(eq="L = 1/2*a*t^2", why="匀加速")], asks=[dict(prompt="加速度", expr="a", unit="m/s²", claimed=4), dict(prompt="时间", expr="t", unit="s", claimed=2)]))
PROBLEM = "质量 2 kg 的物块从倾角 37° 的斜面顶端由静止滑下，斜面长 8 m，μ = 0.25，g 取 10 m/s²，sin37° = 0.6，cos37° = 0.8。求加速度和滑到底端的时间。"
VIZ_TASKS = [
    dict(kind="func", f="x^3-3*x", domain=[-3, 3], asks=[dict(what="zeros"), dict(what="local_max"), dict(what="max"), dict(what="tangent", x=2), dict(what="integral", a=0, b=2), dict(what="value", x=1), dict(what="monotonic")]),
    dict(kind="conic", curve="x^2/16+y^2/9=1", line="y=x+1", asks=[dict(what="intersections"), dict(what="chord"), dict(what="midpoint"), dict(what="area"), dict(what="distance")]),
    dict(kind="solid", points=dict(A=[0, 0, 0], B=[2, 0, 0], C=[2, 2, 0], D=[0, 2, 0], A1=[0, 0, 2], B1=[2, 0, 2], C1=[2, 2, 2], D1=[0, 2, 2]), asks=[dict(what="angle_line_plane", line=["A1", "C"], plane=["A", "B", "C"]), dict(what="dihedral", edge=["B", "D"], faces=["A1", "A"]), dict(what="distance", between=["A", "C1"]), dict(what="volume", points=["A", "B", "D", "A1"]), dict(what="distance_point_plane", point="A", plane=["A1", "B", "D"]), dict(what="angle_lines", lines=[["A", "B"], ["A1", "C"]]), dict(what="area", points=["A", "B", "C", "D"])]),
    dict(kind="prob", dist=dict(type="binomial", n=5, p=0.3), asks=[dict(what="P", event="X>=2"), dict(what="E"), dict(what="D")]),
    dict(kind="prob", dist=dict(type="normal", mu=100, sigma=10), asks=[dict(what="P", event="90<X<110"), dict(what="D")]),
    dict(kind="seq", type="recur", a1=1, rule="2*a+1", asks=[dict(what="term", n=6), dict(what="sum", n=6)]),
    dict(kind="reaction", equation="2KMnO4+16HCl=2KCl+2MnCl2+5Cl2↑+8H2O", given=[dict(species="KMnO4", mass=15.8)], asks=[dict(what="volume", species="Cl2")]),
    dict(kind="solution", components=[dict(name="Na2CO3", type="salt_weak_acid", Ka=[4.4e-7, 4.7e-11], c=0.1)], asks=[dict(what="pH")]),
    dict(kind="solution", components=[dict(name="NH4Cl", type="salt_weak_base", Kb=[1.8e-5], c=0.1)], asks=[dict(what="pH")]),
    dict(kind="equilibrium", reaction="N2+3H2⇌2NH3", V_L=2, initial=dict(N2=1, H2=3), at_eq=dict(NH3=dict(mol=0.4)), asks=[dict(what="K")]),
    dict(kind="cross", loci=[dict(alleles=["A", "a"]), dict(alleles=["B", "b"])], parents=["AaBb", "AaBb"], asks=[dict(what="phenotype_ratio"), dict(what="P", phenotype="A_bb")]),
    dict(kind="cross", loci=[dict(alleles=["A", "a"])], parents=["Aa", "Aa"], lethal=["AA"], asks=[dict(what="P", genotype="aa")]),
    dict(kind="dna", seq="TACGGATCCATT", strand="template", asks=[dict(what="mrna"), dict(what="protein")]),
    dict(kind="foodweb", links={"鹰": {"兔": 0.5, "鼠": 0.5}, "兔": {"草": 1}, "鼠": {"草": 1}}, efficiency=0.1, asks=[dict(what="producer", consumer="鹰", amount=1)]),
]
PHYS = [
    (dict(kind="projectile", v0=20, angle=30, h0=0, g=10, asks=[dict(what="range", claimed=34.64), dict(what="time", claimed=2), dict(what="max_height", claimed=5), dict(what="impact_speed", claimed=20)]), [True, True, True, True]),
    (dict(kind="projectile", v0=15, angle=0, h0=20, g=10, asks=[dict(what="time", claimed=2), dict(what="range", claimed=30)]), [True, True]),
    (dict(kind="incline", angle=36.8699, mu=0.25, m=2, L=8, g=10, asks=[dict(what="a", claimed=4), dict(what="time", claimed=2), dict(what="v_end", claimed=8), dict(what="N", claimed=16), dict(what="f", claimed=4)]), [True] * 5),
    (dict(kind="incline", angle=10, mu=0.5, m=1, L=2, g=10, asks=[dict(what="a", claimed=0), dict(what="moves")]), [True, None]),
    (dict(kind="collision", m1=2, m2=1, v1=4, v2=-1, e=1, asks=[dict(what="v1_after", claimed=2 / 3), dict(what="v2_after", claimed=17 / 3), dict(what="momentum", claimed=7), dict(what="energy_loss", claimed=0)]), [True] * 4),
    (dict(kind="collision", m1=1, m2=1, v1=4, v2=0, e=0, asks=[dict(what="v1_after", claimed=2), dict(what="energy_loss", claimed=4)]), [True, True]),
    (dict(kind="circuit", E=6, r=1, R1=2, R2=3, mode="series", asks=[dict(what="I", claimed=1), dict(what="U", claimed=5), dict(what="efficiency", claimed=5 / 6)]), [True] * 3),
    (dict(kind="circuit", E=6, r=0.8, R1=2, R2=3, mode="parallel", asks=[dict(what="I", claimed=3), dict(what="I1", claimed=1.8), dict(what="P_out", claimed=10.8)]), [True] * 3),
    (dict(kind="lens", f=10, u=30, h=2, asks=[dict(what="v", claimed=15), dict(what="m", claimed=0.5), dict(what="nature")]), [True, True, None]),
    (dict(kind="lens", f=10, u=5, asks=[dict(what="v", claimed=-10), dict(what="m", claimed=2)]), [True, True]),
    (dict(kind="field", q=1.6e-19, m=9.1e-31, v0=1e7, E=1e4, L=0.05, d=0.02, asks=[dict(what="time", claimed=5e-9), dict(what="deflection")]), [True, None]),
    (dict(kind="field", q=1.6e-19, m=1.67e-27, v0=1e6, B=0.5, asks=[dict(what="r", claimed=0.020875), dict(what="T")]), [True, None]),
]
OFFLINE = [("从 20 m 高处以 15 m/s 的速度水平抛出一个小球，g 取 10 m/s²，求落地时间和水平位移。", "projectile", {"落地时间": 2, "水平射程": 30}), ("质量 2 kg 的物块沿倾角 30° 的光滑斜面下滑，斜面长 5 m，g=10，求加速度。", "incline", {"加速度": 5}),
           ("质量为 2 kg 的小球以 4 m/s 的速度与质量 1 kg、速度 1 m/s 的小球相向运动发生弹性碰撞。", "collision", {}), ("电动势 6 V、内阻 1 Ω 的电源接 2 Ω 和 3 Ω 的串联电阻，求电流。", "circuit", {"干路电流": 1}), ("凸透镜焦距为 10 cm，物距为 30 cm，求像距。", "lens", {"像距": 15}),
           ("已知 f(x)=x^3-3x，求极值和零点。", "func", {}), ("已知椭圆 x²/16+y²/9=1，直线 y=x+1 与椭圆相交，求弦长。", "conic", {"弦长": 6.6511}), ("某 DNA 模板链 TACGGATCC，求 mRNA。", "dna", {}), ("AaBb × AaBb 杂交，求表现型比。", "cross", {})]


def main(argv=None):
    import faulthandler
    faulthandler.enable()
    argv = list(sys.argv[1:] if argv is None else argv)
    out = argv[0] if argv else "analysis-selftest"
    os.makedirs(out, exist_ok=True)
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    if os.path.isdir(r"C:\Windows\Fonts"):
        os.environ.setdefault("QT_QPA_FONTDIR", r"C:\Windows\Fonts")
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv[:1])
    from ..design import tokens
    from . import lesson, llm, offline, tasks
    from .page import AnalysisPage
    from .viz import make_viz
    fails = []

    def check(name, ok, info=""):
        print(("ok  " if ok else "FAIL"), name, info if not ok else "", flush=True)
        if not ok:
            fails.append(name)
    try:
        # ---- JSON 宽松解析
        check("lenient 数", llm.parse_json('{"a": 1.8×10⁻⁵, "b": 2×10^-3, "c": 1/16,}') == dict(a=1.8e-5, b=2e-3, c="1/16"), llm.lenient('{"a": 1.8×10⁻⁵}'))
        check("lenient 字符串不动", llm.parse_json('前缀 ```json {"a": "1×10^2, }"} ``` 后缀')["a"] == "1×10^2, }")
        p = llm.peek('{"topic":"斜面","summary":"物块","steps":["受力","列')
        check("peek 半截", p["topic"] == "斜面" and p["steps"] == ["受力", "列"], p)
        # ---- 校验 + 修正：先给坏的，修正后给好的
        bad = dict(GOOD, steps=[], model=dict(GOOD["model"], equations=[dict(eq="a = g*sin(th")]))
        eng = FakeEngine(["这不是 JSON", bad, GOOD])
        L = lesson.analyze(PROBLEM, eng, set(), "目录", status=lambda _m: None)
        check("修正两轮后通过", eng.calls == 3 and L["calc"]["verdict"] == "solved", eng.calls)
        check("修正消息带错误清单", "steps 不能为空" in eng.seen[2][-1]["content"], eng.seen[2][-1]["content"][:80])
        check("读不出 JSON 的提示", "不是一个合法的 JSON" in eng.seen[1][-1]["content"])
        check("方程模型复算一致", all(r["ok"] for r in L["calc"]["rows"]) and lesson.status_of(L) == "verified", L["calc"]["rows"])
        check("角度对齐进了假设", any("36.8" in a for a in L["assumptions"]), L["assumptions"])
        # ---- 答案错 → 纠错
        wrong = json.loads(json.dumps(GOOD))
        wrong["answer"] = "a=5"
        wrong["model"]["asks"][0]["claimed"] = 5
        eng = FakeEngine([wrong, dict(error="摩擦力漏了", answer="a=4 m/s²，t=2 s", steps=["改正"], model_wrong=False)])
        L = lesson.analyze(PROBLEM, eng, set(), "", status=lambda _m: None)
        check("不符时让 AI 复查", eng.calls == 2 and L["answer"].startswith("a=4") and L["recheck"]["oldAnswer"] == "a=5", L.get("recheck"))
        check("复查证据带程序的值", "按方程模型算得 4" in eng.seen[1][0]["content"], eng.seen[1][0]["content"][:200])
        # ---- task 路线
        g2 = dict(GOOD, subject="数学", topic="椭圆", answer="96√3/25", task=dict(kind="conic", curve="x^2/16+y^2/9=1", line="y=x+1", asks=[dict(what="chord", prompt="弦长", claimed="96√3/25")]))
        g2.pop("model")
        L = lesson.analyze("椭圆弦长", FakeEngine([g2]), set(), "", status=lambda _m: None)
        check("task 路线核对通过", L["taskRes"][0]["rows"][0]["ok"] is True and lesson.status_of(L) == "verified")
        # ---- 方程矛盾 → 复查
        contra = dict(GOOD, model=dict(unknowns=[dict(name="x"), dict(name="y")], equations=[dict(eq="x+y=1"), dict(eq="x+y=2")], asks=[dict(expr="x", claimed=1)]))
        eng = FakeEngine([contra, GOOD])
        L = lesson.analyze(PROBLEM, eng, set(), "", status=lambda _m: None)
        check("矛盾方程复查后解出", L["calc"]["verdict"] == "solved" and "互相矛盾" in eng.seen[1][-1]["content"])
        # ---- 模型两轮都修不好：退回不带模型
        junk = dict(GOOD, model=dict(unknowns=[], equations=[], asks=[]))
        eng = FakeEngine([junk, junk, junk])
        L = lesson.analyze(PROBLEM, eng, set(), "", status=lambda _m: None)
        check("退回不带模型", eng.calls == 3 and not L.get("calc") and "calcNote" in L, L.get("calcNote"))
        # ---- 物理题型 + 独立核对
        for spec, want in PHYS:
            r = tasks.build(spec)
            if not r["ok"]:
                check(f"phys {spec['kind']}", False, r["errors"])
                continue
            res = r["result"]
            got = [x["ok"] for x in res["rows"]]
            check(f"phys {spec['kind']} {spec['asks'][0]['what']}", got == want and res["failed_checks"] == 0, (got, [c["text"] for c in res["checks"] if not c["ok"]], [x["text"] for x in res["rows"]]))
        L = lesson.analyze_offline("物块沿倾角 37° 的光滑斜面下滑，斜面长 3 m，g 取 10 m/s²，sin37° = 0.6，求加速度。")
        check("题型角度对齐", abs(lesson.task_rows(L)[0]["value"] - 6) < 1e-3 and any("36.8" in d for d in L["taskRes"][0]["detail"]), lesson.task_rows(L))
        check("phys 错参数退回", not tasks.build(dict(kind="collision", m1=1, m2=1, v1=0, v2=1, asks=[dict(what="momentum")]))["ok"])
        check("目录含物理题型", "projectile" in tasks.catalog() and "foodweb" in tasks.catalog())
        # ---- 离线读题
        for text, kind, want in OFFLINE:
            L = lesson.analyze_offline(text)
            ok = not L.get("unsupported") and L["task"]["kind"] == kind
            if ok:
                rows = {r["prompt"]: r for r in lesson.task_rows(L)}
                for k, v in want.items():
                    ok = ok and k in rows and abs(rows[k]["value"] - v) < 1e-2 * max(1, abs(v))
            check(f"offline {kind}", ok, (L.get("summary"), L.get("task"), [(r["prompt"], r["text"]) for r in lesson.task_rows(L)]))
        check("offline 认不出", lesson.analyze_offline("今天天气怎么样").get("unsupported") is True)
        check("offline 引用名", offline.first(offline.quantities("质量 2 kg，速度 3 m/s，高 5 m"), "m", "高") == 5)
        # ---- 图解：每个题型每一步，昼夜都画
        for spec in VIZ_TASKS + [s for s, _ in PHYS[:0]]:
            r = tasks.build(spec)
            check(f"viz build {spec['kind']}", r["ok"], r.get("errors"))
            if not r["ok"]:
                continue
            for theme in ("day", "night"):
                tokens.set_theme(theme)
                w = make_viz(r["result"])
                w.resize(760, 520)
                w.setStyleSheet(__import__("native.design.widgets", fromlist=["qss"]).qss() if False else "")
                w.show()
                for k in range(len(w.stages)):
                    w.go(k)
                    w.canvas.repaint()
                    if w.canvas.err:
                        check(f"viz {spec['kind']} 第 {k} 步", False, w.canvas.err)
                        w.canvas.err = None
                app.processEvents()
                if theme == "day":
                    w.grab().save(os.path.join(out, f"viz-{spec['kind']}-{spec.get('type') or spec.get('dist', {}).get('type') or len(spec.get('components', []))}-{spec['asks'][0]['what']}.png"))
                w.close()
        tokens.set_theme("day")
        # ---- 页面：离线走一遍；票据丢弃过时回答
        page = AnalysisPage(engine_factory=lambda _c: FakeEngine([GOOD]))
        page.resize(1500, 900)
        page.show()
        page.engine_box.setCurrentIndex(1)
        page.go(OFFLINE[0][0])
        t0 = time.time()
        while not page.go_btn.isEnabled() and time.time() - t0 < 20:
            app.processEvents()
            time.sleep(0.01)
        app.processEvents()
        check("离线页面出结果", page.L and page.L["task"]["kind"] == "projectile" and page.right.currentIndex() == 1)
        page.ctx.stage.repaint()
        check("页面里的仿真没出错", not page.ctx.stage.error, page.ctx.stage.error)
        page.grab().save(os.path.join(out, "page-offline.png"))
        page.engine_box.setCurrentIndex(1)
        page.go(OFFLINE[6][0])
        t0 = time.time()
        while not page.go_btn.isEnabled() and time.time() - t0 < 20:
            app.processEvents()
            time.sleep(0.01)
        app.processEvents()
        page.grab().save(os.path.join(out, "page-conic.png"))
        # AI 路线：engine_box 选 AI，用假引擎；选了实验 → 配置 → 不核对（程序已核对）
        lab_ids = None
        from ..kit.registry import lab
        lab.load()
        lab_ids = list(lab.by_id)
        with_mod = dict(GOOD, module=next((i for i in lab_ids if "incline" in i or "ramp" in i), lab_ids[0]))
        page2 = AnalysisPage(engine_factory=lambda _c: FakeEngine([with_mod, dict(settings=[], press=[], watch=["看加速度"], caveats="")]))
        page2.resize(1500, 900)
        page2.show()
        page2.engine_box.setCurrentIndex(0)
        import native.analysis.llm as _llm
        _llm_av = _llm.available
        _llm.available = lambda: True
        page2.go(PROBLEM)
        t0 = time.time()
        while time.time() - t0 < 25 and not (page2.L and page2.L.get("verify")):
            app.processEvents()
            time.sleep(0.01)
        _llm.available = _llm_av
        check("AI 页面：选实验并配置", page2.L and page2.L.get("applied") is not None and page2.L.get("verify"), page2.status_l.text())
        page2.ctx.stage.repaint()
        check("实验正常", not page2.ctx.stage.error, page2.ctx.stage.error)
        page2.grab().save(os.path.join(out, "page-ai.png"))
        # 票据：旧回答不写入
        page2.rev = 99
        page2._on_done(5, dict(problem="旧", answer="旧", ticket=dict(id="x")))
        check("过时回答被丢弃", page2.L.get("problem") != "旧")
        check("记录已存", len(lesson.history()) >= 2)
        # 第 3 步的比较
        rows = lesson.compare_pairs([dict(quantity="a", readout="加速度", answer_value=4), dict(quantity="比例", readout="比", answer_value="3:1"), dict(quantity="t", readout="时间", answer_value=9)], "加速度：4.0 m/s²\n比：6 : 2\n时间：2.00 s")
        check("读数比较", [r["ok"] for r in rows] == [True, True, False], rows)
    except Exception:  # noqa: BLE001
        fails.append("exception")
        print(traceback.format_exc(), flush=True)
    print("ANALYSIS SELFTEST", "FAIL " + ",".join(fails) if fails else "OK", flush=True)
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(test_runtime.run(main))
