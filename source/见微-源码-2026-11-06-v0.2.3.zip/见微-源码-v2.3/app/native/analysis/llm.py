"""DeepSeek 对话（不依赖网页与本机服务）：流式接收、JSON 宽松解析、校验 + 最多两轮修正。

全部是普通函数，在工作线程里调用；界面通过 on_text / on_think / status 回调拿进度。密钥只留在本机数据目录。
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path


class AskError(Exception):
    def __init__(self, msg, transient=False, busy=False, raw=""):
        super().__init__(msg)
        self.transient, self.busy, self.raw = transient, busy, raw


def _env_file():
    base = os.environ.get("JIANWEI_HOME") or os.path.join(os.environ.get("LOCALAPPDATA", str(Path.home())), "Jianwei")
    return Path(base) / "deepseek.env"


def settings():
    env = {}
    try:
        for line in _env_file().read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    except OSError:
        pass

    def get(k, d=""):
        return os.environ.get(k) or env.get(k) or d
    return dict(key=get("DEEPSEEK_API_KEY"), model=get("DEEPSEEK_MODEL", "deepseek-chat"), base=get("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/"))


def save_key(key):
    p = _env_file()
    p.parent.mkdir(parents=True, exist_ok=True)
    env = {}
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    except OSError:
        pass
    if key:
        env["DEEPSEEK_API_KEY"] = key
    else:
        env.pop("DEEPSEEK_API_KEY", None)
    p.write_text("".join(f"{k}={v}\n" for k, v in env.items()), encoding="utf-8")


def available():
    return bool(settings()["key"])


def chat_once(system, messages, model, on_text=None, on_think=None, cancel=None):
    """一次流式请求，返回 (正文, 是否被截断)。"""
    ds = settings()
    if not ds["key"]:
        raise AskError("还没有填 DeepSeek 密钥")
    msgs = [dict(role="system", content=system)] + [dict(role=m["role"], content=str(m["content"])) for m in messages[:12]]
    payload = dict(model=model, messages=msgs, temperature=0.2, stream=True)
    if "reasoner" not in model:   # deepseek-reasoner 不支持 JSON 模式
        payload["response_format"] = dict(type="json_object")
        payload["max_tokens"] = 8192
    req = urllib.request.Request(ds["base"] + "/chat/completions", data=json.dumps(payload).encode("utf-8"), headers={"Content-Type": "application/json", "Authorization": "Bearer " + ds["key"]})
    try:
        resp = urllib.request.urlopen(req, timeout=300)   # noqa: S310  base 是用户自己的设置
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        raise AskError(f"DeepSeek 返回 {e.code}：{detail}", e.code in (429, 500, 502, 503, 504), e.code == 429) from e
    except OSError as e:
        raise AskError(f"连接 DeepSeek 失败：{e}", True) from e
    text, think, finish, done = "", 0, None, False
    try:
        with resp:
            for raw in resp:
                if cancel and cancel():
                    raise AskError("已取消")
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    done = True
                    break
                try:
                    ch = (json.loads(data).get("choices") or [{}])[0]
                except ValueError:
                    continue
                delta = ch.get("delta") or {}
                if delta.get("content"):
                    text += delta["content"]
                    if on_text:
                        on_text(text)
                if delta.get("reasoning_content"):
                    think += len(delta["reasoning_content"])
                    if on_think:
                        on_think(think)
                finish = ch.get("finish_reason") or finish
    except OSError as e:
        raise AskError(f"连接中断：{e}", True) from e
    if not done and not finish:
        raise AskError("回答中途断开", True)
    return text, finish == "length"


class Engine:
    """一个分析引擎。测试时可以换成假的：只要有 ask(messages, ...) 就行。"""

    name = "deepseek"

    def __init__(self, system, cancel=None):
        self.system = system
        self.calls = 0
        self.cancel = cancel

    def ask(self, messages, deep=False, on_text=None, on_think=None, status=None):
        model = "deepseek-reasoner" if deep else settings()["model"]

        def once():
            self.calls += 1
            return chat_once(self.system, messages, model, on_text, on_think, self.cancel)
        try:
            return once()
        except AskError as e:
            if not e.transient:
                raise
            if status:
                status("连接不稳定，正在重试…")
            time.sleep(4 if e.busy else 1.5)
            return once()


# ---------------------------------------------------------------- JSON
def lenient(t):
    """模型常见的 JSON 小毛病（只改字符串外面）：1.8×10⁻⁵、1.8×10^-5 这种数，裸写的分数 1/16，结尾多余的逗号。"""
    sup = "⁰¹²³⁴⁵⁶⁷⁸⁹"

    def fix(x):
        x = re.sub(r"(\d(?:\.\d+)?)\s*[×xX*]\s*10\s*\^\s*\(?\s*([-−]?\d+)\s*\)?", lambda m: f"{m.group(1)}e{m.group(2).replace('−', '-')}", x)
        x = re.sub(r"(\d(?:\.\d+)?)\s*[×xX*]\s*10([⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)", lambda m: m.group(1) + "e" + "".join("-" if c == "⁻" else "" if c == "⁺" else str(sup.index(c)) for c in m.group(2)), x)
        x = re.sub(r"([:\[,]\s*)(-?\d+(?:\.\d+)?\s*/\s*\d+(?:\.\d+)?)(?=\s*[,\]}])", r'\1"\2"', x)
        return re.sub(r",(\s*[}\]])", r"\1", x)
    out, seg, in_str, esc = "", "", False, False
    for ch in t:
        if in_str:
            out += ch
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        elif ch == '"':
            out += fix(seg) + ch
            seg = ""
            in_str = True
        else:
            seg += ch
    return out + fix(seg)


def parse_json(text):
    s = re.sub(r"```(?:json)?", "", str(text or ""))
    a, b = s.find("{"), s.rfind("}")
    if a < 0 or b < a:
        raise ValueError("模型没有返回 JSON")
    body = s[a:b + 1]
    try:
        return json.loads(body)
    except ValueError:
        return json.loads(lenient(body))


def try_parse(text):
    try:
        j = parse_json(text)
        return j if isinstance(j, dict) else None
    except ValueError:
        return None


def peek(text):
    """从还没写完的 JSON 里取出 summary 和 steps，给实时草稿用。"""
    def un(s):
        try:
            return json.loads('"' + re.sub(r"\\$", "", s) + '"')
        except ValueError:
            return s.replace("\\n", " ").replace('\\"', '"')

    def st(key):
        m = re.search(rf'"{key}"\s*:\s*"((?:[^"\\]|\\.)*)', text)
        return un(m.group(1)) if m else ""

    def arr(key):
        m = re.search(rf'"{key}"\s*:\s*\[', text)
        if not m:
            return []
        out, i = [], m.end()
        while i < len(text):
            ch = text[i]
            if ch == "]":
                break
            if ch == '"':
                s = re.match(r'"((?:[^"\\]|\\.)*)("?)', text[i:])
                out.append(un(s.group(1)))
                i += s.end()
                if not s.group(2):
                    break
                continue
            i += 1
        return out
    return dict(topic=st("topic"), summary=st("summary"), knowns=arr("knowns"), steps=arr("steps"), answer=st("answer"))


def unreadable(text, truncated):
    if not str(text or "").strip():
        return "你的上一条回复是空的。请直接输出要求的 JSON 对象（不要思考过程、不要 Markdown、不要解释）。"
    if truncated:
        return "你的上一条回复太长，被截断了，不是完整的 JSON。请重新输出一个更简短但完整的 JSON 对象：步骤写得精炼些，可选字段可以省略。"
    return f"你的上一条回复不是一个合法的 JSON 对象（开头是：{json.dumps(str(text).strip()[:120], ensure_ascii=False)}）。请只输出一个 JSON 对象：以 {{ 开头、以 }} 结尾，不要 Markdown 代码块、注释或解释文字。"


def repair_msg(errors):
    return "程序检查你的 JSON 时发现以下问题，请改正后重新输出完整的 JSON（只改有问题的部分，其余保持不变）：\n" + "\n".join(f"- {e}" for e in errors)


def ask_json(engine, first, check, repairs=2, status=None, **live):
    """问一个必须回 JSON 的问题，用 check 校验：不合格就把问题发回去修正（默认最多两轮，最后一轮允许深度思考）。

    check(json) → {ok, value} 或 {ok: False, errors, fallback?}；fallback 是去掉不合格的可选部分后仍可用的结果。
    """
    msgs = list(first) if isinstance(first, list) else [dict(role="user", content=first)]
    fallback, last = None, None
    for rnd in range(repairs + 1):
        text, trunc = engine.ask(msgs, deep=(rnd == 2), status=status, **live)
        js = try_parse(text)
        res = check(js) if js is not None else None
        conv = msgs + [dict(role="assistant", content=text)]
        if res and res.get("ok"):
            return dict(ok=True, value=res["value"], msgs=conv, repairs=rnd)
        if res and res.get("fallback"):
            fallback = dict(ok=True, value=res["fallback"], msgs=conv, repairs=rnd, dropped=res.get("errors"))
        last = (text, trunc, js, res)
        if rnd >= repairs:
            break
        if status:
            status(f"AI 的输出没有通过校验，正在让它修正（第 {rnd + 1} 次）…")
        msgs = msgs + [dict(role="assistant", content=text or "（空）"), dict(role="user", content=repair_msg(res["errors"]) if js is not None else unreadable(text, trunc))]
    if fallback:
        return fallback
    text, trunc, js, res = last
    if js is not None:
        msg = f"AI 的输出没有通过校验（已修正 {repairs} 次）：{'；'.join(res['errors'][:3])}"
    else:
        msg = "AI 的回答太长被截断，没有得到完整的 JSON" if trunc else f"AI 没有按要求输出 JSON（已重试 {repairs} 次）"
    raise AskError(msg, raw=str(text or "")[:1500])
