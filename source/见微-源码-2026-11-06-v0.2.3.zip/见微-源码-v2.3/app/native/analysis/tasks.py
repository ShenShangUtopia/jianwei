"""题型求解器入口：catalog() 给 AI 的目录，build(spec) 校验并求解。"""
from __future__ import annotations

import traceback

from . import tasks_math, tasks_phys, tasks_sci  # noqa: F401  注册题型
from . import solver as Solver
from .task_core import ORDER, REG, TaskError, compare, roots  # noqa: F401
from .tasks_sci import parse_equation


def catalog():
    return "\n\n".join(f"### {REG[i]['subj']} · {REG[i]['title']}（kind: {i}）\n{REG[i]['doc']}" for i in ORDER)


def task_list():
    return [dict(id=i, subj=REG[i]["subj"], title=REG[i]["title"]) for i in ORDER]


def build(spec, problem=""):
    """返回 {ok, result} 或 {ok: False, errors}；result 只含普通数据，可存进本机记录。"""
    if not isinstance(spec, dict):
        return dict(ok=False, errors=["task 必须是对象，含 kind 与 asks"])
    kind = spec.get("kind")
    if kind not in ORDER:
        return dict(ok=False, errors=[f"task.kind「{kind}」不存在，可选：{'、'.join(ORDER)}"])
    t = REG[kind]
    note = ""
    if "angle" in spec and problem:   # sin37° = 0.6 → 36.87°：和按题目近似值手算的答案一致
        try:
            table = Solver.stated_angles(problem)
            ang = float(spec["angle"])
        except (TypeError, ValueError):
            table, ang = {}, None
        if ang in table:
            spec = dict(spec, angle=table[ang])
            note = f"按题目给出的三角函数值，{ang:g}° 取为 {table[ang]}°"
    try:
        r = t["run"](spec)
    except TaskError as e:
        return dict(ok=False, errors=[f"task（{t['title']}）：{m}" for m in e.list])
    except Exception as e:  # noqa: BLE001  模型给的参数千奇百怪，算错也要变成可修正的反馈
        traceback.print_exc()
        return dict(ok=False, errors=[f"task（{t['title']}）计算出错：{e}"])
    rows = []
    for row in r["rows"]:
        ok = compare(row, parse_equation)
        rows.append(dict(prompt=str(row["prompt"]), kind=row["kind"], text=row["text"], value=None if row["kind"] == "equation" else row.get("value"), unit=row.get("unit") or "", claimed=row.get("claimed"), ok=ok))
    checks = r.get("checks") or []
    failed = [c for c in checks if not c["ok"]]
    if failed:   # 两种方法对不上：不当作答案显示，标成待复核
        for row in rows:
            row["ok"] = False if row["kind"] == "num" else row["ok"]
    return dict(ok=True, result=dict(kind=t["id"], title=t["title"], subj=t["subj"], rows=rows, detail=(r.get("detail") or []) + ([note] if note else []), viz=r.get("viz"), checks=checks, failed_checks=len(failed)))
