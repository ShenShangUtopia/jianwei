"""Thin line icons, drawn rather than loaded, so they match every size."""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen


def draw_icon(painter: QPainter, name: str, rect: QRectF, color: QColor, width: float = 1.5) -> None:
    painter.save()
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    pen = QPen(color, width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()
    cx, cy = x + w / 2, y + h / 2
    s = min(w, h)

    if name == "refresh":
        arc = QRectF(cx - s * 0.32, cy - s * 0.32, s * 0.64, s * 0.64)
        painter.drawArc(arc, 35 * 16, 285 * 16)
        p = QPointF(cx + s * 0.27, cy - s * 0.36)
        painter.drawLine(p, QPointF(p.x() + s * 0.01, p.y() - s * 0.18))
        painter.drawLine(p, QPointF(p.x() - s * 0.17, p.y() + s * 0.01))
    elif name == "pin":
        path = QPainterPath()
        path.moveTo(cx + s * 0.18, cy - s * 0.34)
        path.lineTo(cx - s * 0.22, cy + s * 0.06)
        path.lineTo(cx - s * 0.02, cy + s * 0.26)
        path.lineTo(cx + s * 0.34, cy - s * 0.10)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawLine(QPointF(cx - s * 0.08, cy + s * 0.18), QPointF(cx - s * 0.32, cy + s * 0.38))
    elif name == "collapse":
        painter.drawLine(QPointF(cx - s * 0.22, cy - s * 0.24), QPointF(cx + s * 0.04, cy))
        painter.drawLine(QPointF(cx + s * 0.04, cy), QPointF(cx - s * 0.22, cy + s * 0.24))
        painter.setPen(QPen(color, width * 0.75))
        painter.drawLine(QPointF(cx + s * 0.18, cy - s * 0.18), QPointF(cx + s * 0.36, cy))
        painter.drawLine(QPointF(cx + s * 0.36, cy), QPointF(cx + s * 0.18, cy + s * 0.18))
    elif name == "expand":
        painter.drawLine(QPointF(cx + s * 0.22, cy - s * 0.24), QPointF(cx - s * 0.04, cy))
        painter.drawLine(QPointF(cx - s * 0.04, cy), QPointF(cx + s * 0.22, cy + s * 0.24))
        painter.setPen(QPen(color, width * 0.75))
        painter.drawLine(QPointF(cx - s * 0.18, cy - s * 0.18), QPointF(cx - s * 0.36, cy))
        painter.drawLine(QPointF(cx - s * 0.36, cy), QPointF(cx - s * 0.18, cy + s * 0.18))
    elif name == "sliders":
        for i, dy in enumerate((-0.26, 0.0, 0.26)):
            yy = cy + s * dy
            painter.drawLine(QPointF(cx - s * 0.34, yy), QPointF(cx + s * 0.34, yy))
            kx = cx + s * (0.14 if i == 0 else -0.12 if i == 1 else 0.04)
            painter.setBrush(color)
            painter.drawEllipse(QPointF(kx, yy), s * 0.06, s * 0.06)
            painter.setBrush(Qt.BrushStyle.NoBrush)
    elif name == "arrow_up_right":
        painter.drawLine(QPointF(cx - s * 0.22, cy + s * 0.22), QPointF(cx + s * 0.22, cy - s * 0.22))
        painter.drawLine(QPointF(cx - s * 0.02, cy - s * 0.22), QPointF(cx + s * 0.22, cy - s * 0.22))
        painter.drawLine(QPointF(cx + s * 0.22, cy - s * 0.22), QPointF(cx + s * 0.22, cy + s * 0.02))
    elif name == "arrow_right":
        painter.drawLine(QPointF(cx - s * 0.30, cy), QPointF(cx + s * 0.28, cy))
        painter.drawLine(QPointF(cx + s * 0.08, cy - s * 0.20), QPointF(cx + s * 0.28, cy))
        painter.drawLine(QPointF(cx + s * 0.28, cy), QPointF(cx + s * 0.08, cy + s * 0.20))
    elif name == "arrow_left":
        painter.drawLine(QPointF(cx + s * 0.30, cy), QPointF(cx - s * 0.28, cy))
        painter.drawLine(QPointF(cx - s * 0.08, cy - s * 0.20), QPointF(cx - s * 0.28, cy))
        painter.drawLine(QPointF(cx - s * 0.28, cy), QPointF(cx - s * 0.08, cy + s * 0.20))
    elif name == "chevron_right":
        painter.drawLine(QPointF(cx - s * 0.10, cy - s * 0.20), QPointF(cx + s * 0.10, cy))
        painter.drawLine(QPointF(cx + s * 0.10, cy), QPointF(cx - s * 0.10, cy + s * 0.20))
    elif name == "chevron_left":
        painter.drawLine(QPointF(cx + s * 0.10, cy - s * 0.20), QPointF(cx - s * 0.10, cy))
        painter.drawLine(QPointF(cx - s * 0.10, cy), QPointF(cx + s * 0.10, cy + s * 0.20))
    elif name == "close":
        painter.drawLine(QPointF(cx - s * 0.22, cy - s * 0.22), QPointF(cx + s * 0.22, cy + s * 0.22))
        painter.drawLine(QPointF(cx + s * 0.22, cy - s * 0.22), QPointF(cx - s * 0.22, cy + s * 0.22))
    elif name == "copy":
        r1 = QRectF(cx - s * 0.28, cy - s * 0.30, s * 0.40, s * 0.48)
        r2 = QRectF(cx - s * 0.12, cy - s * 0.16, s * 0.40, s * 0.48)
        painter.drawRoundedRect(r1, 2, 2)
        painter.drawRoundedRect(r2, 2, 2)
    elif name == "folder":
        path = QPainterPath()
        path.moveTo(cx - s * 0.34, cy - s * 0.18)
        path.lineTo(cx - s * 0.06, cy - s * 0.18)
        path.lineTo(cx + s * 0.02, cy - s * 0.28)
        path.lineTo(cx + s * 0.34, cy - s * 0.28)
        path.lineTo(cx + s * 0.34, cy + s * 0.26)
        path.lineTo(cx - s * 0.34, cy + s * 0.26)
        path.closeSubpath()
        painter.drawPath(path)
    elif name == "check":
        painter.drawLine(QPointF(cx - s * 0.24, cy), QPointF(cx - s * 0.05, cy + s * 0.20))
        painter.drawLine(QPointF(cx - s * 0.05, cy + s * 0.20), QPointF(cx + s * 0.26, cy - s * 0.22))
    elif name == "clock":
        painter.drawEllipse(QRectF(cx - s * 0.30, cy - s * 0.30, s * 0.60, s * 0.60))
        painter.drawLine(QPointF(cx, cy - s * 0.18), QPointF(cx, cy))
        painter.drawLine(QPointF(cx, cy), QPointF(cx + s * 0.16, cy + s * 0.08))
    elif name == "spark":
        path = QPainterPath()
        path.moveTo(cx, cy - s * 0.34)
        path.lineTo(cx + s * 0.08, cy - s * 0.05)
        path.lineTo(cx + s * 0.34, cy)
        path.lineTo(cx + s * 0.08, cy + s * 0.05)
        path.lineTo(cx, cy + s * 0.34)
        path.lineTo(cx - s * 0.08, cy + s * 0.05)
        path.lineTo(cx - s * 0.34, cy)
        path.lineTo(cx - s * 0.08, cy - s * 0.05)
        path.closeSubpath()
        painter.drawPath(path)
    elif name == "play":
        path = QPainterPath()
        path.moveTo(cx - s * 0.18, cy - s * 0.28)
        path.lineTo(cx + s * 0.28, cy)
        path.lineTo(cx - s * 0.18, cy + s * 0.28)
        path.closeSubpath()
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        painter.drawPath(path)
    elif name == "pause":
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        painter.drawRoundedRect(QRectF(cx - s * 0.24, cy - s * 0.28, s * 0.15, s * 0.56), 1.2, 1.2)
        painter.drawRoundedRect(QRectF(cx + s * 0.09, cy - s * 0.28, s * 0.15, s * 0.56), 1.2, 1.2)
    elif name == "minus":
        painter.drawLine(QPointF(cx - s * 0.24, cy), QPointF(cx + s * 0.24, cy))
    painter.restore()
