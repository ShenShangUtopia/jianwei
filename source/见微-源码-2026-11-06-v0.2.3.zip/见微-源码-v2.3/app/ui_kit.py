"""见微 · 视觉底座：青瓷蓝 · 简洁明快。"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPainter, QPen
import re

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget


_THEMES = {
    "day": dict(
        PAPER="#F7F2EB", SIDE="#FBF8F3", CARD="#FFFFFF", INK="#081F5C", INK2="#334EAC",
        SOFT="#5F6E8C", FAINT="#93A0B8", LINE="#E6EAF1", LINE2="#F0F2F6",
        ACCENT="#B4553C", JADE="#3F6F62", DEEP="#050C1C", WINDOW_LINE="#E2E7F0"
    ),
    "night": dict(
        PAPER="#0B1322", SIDE="#0E1728", CARD="#141F33", INK="#EAF1FA", INK2="#9CC1EA",
        SOFT="#A9B8CE", FAINT="#7C8CA6", LINE="#27354D", LINE2="#1C2940",
        ACCENT="#E4B863", JADE="#7FD1B9", DEEP="#050B16", WINDOW_LINE="#243349"
    ),
}
CURRENT_THEME = "day"


class C:
    PAPER = QColor("#F7F2EB")
    SIDE = QColor("#FBF8F3")
    CARD = QColor("#FFFFFF")
    INK = QColor("#081F5C")
    INK2 = QColor("#334EAC")
    SOFT = QColor("#5F6E8C")
    FAINT = QColor("#93A0B8")
    LINE = QColor("#E6EAF1")
    LINE2 = QColor("#F0F2F6")
    ACCENT = QColor("#B4553C")
    JADE = QColor("#3F6F62")
    DEEP = QColor("#050C1C")


def apply_theme(name: str) -> str:
    """切到 day / night，并把 C.* 与 C.*H 都更新（内联样式用字符串拼接读 H 版）。"""
    global CURRENT_THEME
    pal = _THEMES.get(name) or _THEMES["day"]
    CURRENT_THEME = name if name in _THEMES else "day"
    for k, v in pal.items():
        setattr(C, k, QColor(v))
        setattr(C, k + "H", v)
    return CURRENT_THEME


def theme() -> str:
    return CURRENT_THEME


def _swap(text: str) -> str:
    """把白天色值替换成当前主题色值（夜间用）。"""
    if CURRENT_THEME == "day":
        return text
    day, night = _THEMES["day"], _THEMES["night"]
    out = text
    for k, v in day.items():
        to = night.get(k)
        if to and to.lower() != v.lower():
            out = re.sub(re.escape(v), to, out, flags=re.I)
    return out


def qss() -> str:
    out = _swap(QSS)
    if CURRENT_THEME == "night":
        out += ("\nQPushButton#btn{background:#182539;border:1px solid #2A3850;color:#9CC1EA;border-radius:8px;}"
                "QPushButton#btn:hover{border-color:#4A6182;}"
                "QPushButton#btn-primary{background:#E4B863;border:1px solid #E4B863;color:#22190A;border-radius:8px;}"
                "QPushButton#btn-primary:hover{background:#F3DCA8;border-color:#F3DCA8;}"
                "QPushButton#btn-soft{background:#16233A;border:1px solid #27354D;color:#9CC1EA;border-radius:8px;}"
                "QPushButton#btn-soft:hover{background:#1C2B44;border-color:#3A4C68;}"
                "QPushButton#btn-danger{background:#182539;border:1px solid #3A2E2A;color:#E9A08A;border-radius:8px;}"
                "QPushButton#chip{background:#16233A;border:1px solid #27354D;color:#A9B8CE;border-radius:8px;}"
                "QPushButton#ghost{background:transparent;border:1px solid #27354D;color:#A9B8CE;}"
                "QPushButton#ghost:hover{border-color:#3F5478;color:#EAF1FA;}"
                "QCheckBox{color:#C9D6E6;}"
                "QCheckBox::indicator{width:14px;height:14px;border-radius:4px;border:1px solid #3A4C68;background:#101B2C;}"
                "QCheckBox::indicator:checked{background:#E4B863;border-color:#E4B863;}"
                "QLineEdit{background:#101B2C;border:1px solid #27354D;color:#EAF1FA;border-radius:6px;padding:4px 8px;}"
                "QSlider::groove:horizontal{background:#27354D;height:3px;border-radius:2px;}"
                "QSlider::sub-page:horizontal{background:#C9A55A;height:3px;border-radius:2px;}"
                "QSlider::handle:horizontal{background:#E4B863;width:12px;margin:-5px 0;border-radius:6px;}"
                "QComboBox{background:#101B2C;border:1px solid #27354D;color:#EAF1FA;border-radius:6px;padding:3px 8px;}"
                "QFrame#card{border-radius:12px;}"
                "QPushButton#nav{border-radius:8px;}"
                "QPushButton#nav:checked{border-radius:8px;}"
                "QPushButton#nav:hover{border-radius:8px;}")
    return out


def restyle_tree(root) -> None:
    """夜间：把控件里写死的白天色值就地换掉；回到白天时按 origStyle 原样还原。

    页面每次切主题都会重建，但标题栏、侧栏不重建——以前白天直接 return，
    夜 → 昼之后它们还留着夜间的浅色字（「见微」几乎看不见）。
    """
    if root is None:
        return
    try:
        widgets = [root] + root.findChildren(QWidget)
    except Exception:
        return
    for w in widgets:
        try:
            orig = w.property("origStyle")
            if orig is None:
                orig = w.styleSheet() or ""
                w.setProperty("origStyle", orig)
            want = _swap(orig) if CURRENT_THEME == "night" else orig
            if w.styleSheet() != want:
                w.setStyleSheet(want)
        except Exception:
            continue


def _pick(cands: list[str]) -> str:
    fams = set(QFontDatabase.families())
    for c in cands:
        if c in fams:
            return c
    return cands[-1]


UI = _pick(["Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC", "Segoe UI"])
NUM = _pick(["Cambria", "Georgia", "Times New Roman"])   # Cambria 是等高数字；Georgia 的旧式数字 3 4 5 7 9 会掉到基线下
MONO = _pick(["Consolas", "Cascadia Mono", "Courier New"])


def f(size: float = 13, weight: int = 400, spacing: float = 0.0) -> QFont:
    font = QFont(UI)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    return font


def serif(size: float = 40, weight: int = 600, spacing: float = 0.0) -> QFont:
    font = QFont(NUM)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    if spacing:
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return font


def mono(size: float = 13, weight: int = 400) -> QFont:
    font = QFont(MONO)
    font.setPixelSize(max(1, int(round(size))))
    font.setWeight(QFont.Weight(weight))
    return font


QSS = f"""
QWidget {{ color: #081F5C; font-family: '{UI}'; }}
QToolTip {{
    background: #081F5C; color: #F7F2EB; border: none; padding: 5px 8px; font-size: 11px;
}}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 9px; margin: 2px 0; }}
QScrollBar::handle:vertical {{ background: #D9E0EC; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #C3CEDF; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
QFrame#card {{ background: #FFFFFF; border: 1px solid #E3E8F1; border-radius: 12px; }}
QPushButton#ghost {{ color: #5F6E8C; background: transparent; border: 1px solid #E6EAF1; border-radius: 12px; padding: 0 10px; }}
QPushButton#ghost:hover {{ color: #081F5C; background: #F5F7FC; border-color: #DDE4F0; }}
QPushButton {{ border: none; background: transparent; }}
QPushButton#btn {{
    background: #FFFFFF; border: 1px solid #DFE5EF; border-radius: 10px;
    padding: 7px 14px; color: #334EAC; font-size: 12px;
}}
QPushButton#btn:hover {{ border-color: #334EAC; }}
QPushButton#btn-primary {{
    background: #081F5C; border: 1px solid #081F5C; border-radius: 10px;
    padding: 7px 14px; color: #F7F2EB; font-size: 12px;
}}
QPushButton#btn-primary:hover {{ background: #0D2A72; border-color: #0D2A72; }}
QPushButton#btn-soft {{
    background: #F4F6FB; border: 1px solid #E3E9F3; border-radius: 10px;
    padding: 7px 14px; color: #334EAC; font-size: 12px;
}}
QPushButton#btn-soft:hover {{ background: #EBF0F9; border-color: #C9D6EA; }}
QPushButton#btn-danger {{
    background: #FFFFFF; border: 1px solid #EADCD7; border-radius: 10px;
    padding: 7px 14px; color: #B4553C; font-size: 12px;
}}
QPushButton#chip {{
    background: #FFFFFF; border: 1px solid #E6EAF1; border-radius: 8px;
    padding: 5px 11px; color: #5F6E8C; font-size: 11.5px;
}}
QPushButton#chip:hover {{ border-color: #B9C6DB; }}
QPushButton#chip:checked {{ border-color: #081F5C; color: #081F5C; font-weight: 600; }}
QPushButton#nav {{
    text-align: left; padding: 0 0 0 14px; border-radius: 8px;
    color: #5F6E8C; font-size: 13px; border-left: 2px solid transparent;
}}
QPushButton#nav:hover {{ color: #081F5C; background: #F5F7FC; }}
QPushButton#nav:checked {{ color: #081F5C; font-weight: 600; border-left: 2px solid #081F5C; background: #FFFFFF; border-radius: 8px; }}
QLabel#kicker {{ color: #93A0B8; font-size: 10px; }}
QLabel#h2 {{ color: #081F5C; font-size: 17px; font-weight: 600; }}
QLabel#body {{ color: #44557A; font-size: 12.5px; }}
QSlider::groove:horizontal {{ height: 2px; background: #E6EAF1; }}
QSlider::sub-page:horizontal {{ background: #081F5C; height: 2px; }}
QSlider::handle:horizontal {{ width: 11px; height: 11px; margin: -5px 0; border-radius: 6px;
    background: #081F5C; border: 2px solid #FFFFFF; }}
QCheckBox {{ color: #44557A; font-size: 12px; spacing: 8px; }}
QCheckBox::indicator {{ width: 13px; height: 13px; border: 1px solid #C9D3E3; border-radius: 2px; background: #FFFFFF; }}
QCheckBox::indicator:checked {{ background: #081F5C; border-color: #081F5C; }}
QLineEdit, QDateEdit {{
    background: #FFFFFF; border: 1px solid #E6EAF1; border-radius: 3px;
    padding: 6px 9px; color: #081F5C; font-size: 12px;
}}
QLineEdit:focus {{ border-color: #334EAC; }}
QComboBox {{ background: #FFFFFF; border: 1px solid #E6EAF1; border-radius: 3px; padding: 5px 9px; font-size: 12px; }}
"""


def label(text: str, size: float = 12.5, color: QColor | None = None,
          weight: int = 400, wrap: bool = False, spacing: float = 0.0) -> QLabel:
    w = QLabel(text)
    w.setFont(f(size, weight, spacing))
    w.setStyleSheet(f"color:{color.name() if color else '#44557A'}; background: transparent;")
    w.setWordWrap(wrap)
    w.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
    return w


def kicker(text: str) -> QLabel:
    w = QLabel(text)
    w.setObjectName("kicker")
    w.setFont(f(10, 600, 2.4))
    w.setStyleSheet("color:#93A0B8;background:transparent;")
    return w


def divider(vertical: bool = False) -> QFrame:
    line = QFrame()
    line.setFixedHeight(1) if not vertical else line.setFixedWidth(1)
    line.setStyleSheet("background:#EDF0F6;border:none;")
    return line


class Card(QFrame):
    def __init__(self, title: str = "", sub: str = "", pad: tuple[int, int, int, int] = (20, 18, 20, 18)):
        super().__init__()
        self.setObjectName("card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(*pad)
        self.body.setSpacing(9)
        if title:
            head = QHBoxLayout()
            head.setSpacing(8)
            t = QLabel(title)
            t.setFont(f(13, 600, 0.4))
            t.setStyleSheet("color:#081F5C;background:transparent;")
            head.addWidget(t)
            self.head = head
            if sub:
                s = QLabel(sub)
                s.setFont(f(10.5))
                s.setStyleSheet("color:#93A0B8;background:transparent;")
                head.addWidget(s, 0, Qt.AlignmentFlag.AlignBottom)
            head.addStretch(1)
            self.body.addLayout(head)
        self._title = title

    def add(self, w):
        if isinstance(w, QWidget):
            self.body.addWidget(w)
        else:
            self.body.addLayout(w)
        return w


class Btn(QPushButton):
    def __init__(self, text: str, variant: str = "", tip: str = ""):
        super().__init__(text)
        self.setObjectName({"primary": "btn-primary", "soft": "btn-soft",
                            "danger": "btn-danger"}.get(variant, "btn"))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(f(12, 600 if variant == "primary" else 400))
        if tip:
            self.setToolTip(tip)


class Chip(QPushButton):
    def __init__(self, text: str):
        super().__init__(text)
        self.setObjectName("chip")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(f(11.5))


class TickRow(QWidget):
    """1 格 = 1 周：瓷器的刻度，不是进度条。"""

    def __init__(self, total: int = 32, filled: int = 12, label_text: str = ""):
        super().__init__()
        self.total, self.filled, self.label_text = total, filled, label_text
        self.setFixedHeight(34)
        self.setMinimumWidth(240)

    def set(self, total: int, filled: int, label_text: str = ""):
        self.total, self.filled, self.label_text = total, max(0, filled), label_text
        self.update()

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        w = self.width()
        right_pad = 92 if self.label_text else 0
        gap = 3.0
        cell = max(1.6, (w - right_pad - gap * (self.total - 1)) / max(1, self.total))
        y = 12
        for i in range(self.total):
            x = i * (cell + gap)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(C.INK if i < self.filled else C.LINE)
            p.drawRect(QRectF(x, y, cell, 9))
        if self.label_text:
            p.setPen(QPen(C.FAINT))
            p.setFont(f(10.5))
            p.drawText(QRectF(w - right_pad + 10, y - 4, right_pad - 10, 18),
                       int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), self.label_text)
        p.end()


class Dot(QWidget):
    def __init__(self, color: QColor = C.JADE, size: int = 6):
        super().__init__()
        self.color, self.size = color, size
        self.setFixedSize(size, size)

    def paintEvent(self, _ev) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(self.color)
        p.drawEllipse(QRectF(0, 0, self.size, self.size))
        p.end()


def nav_icon(name: str, color: QColor, size: int = 18):
    """侧栏线性图标（1.6px 圆头描边，2 倍像素绘制保证清晰）。"""
    from PySide6.QtGui import QPainterPath, QPixmap
    import math
    dpr = 2
    pm = QPixmap(size * dpr, size * dpr)
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    pen = QPen(color, 1.6)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    s = size / 18.0
    p.scale(s, s)
    if name == "today":        # 日历：方框、顶栏、两枚挂钉、今日一点
        p.drawRoundedRect(QRectF(2.5, 3.8, 13, 11.7), 2.4, 2.4)
        p.drawLine(QPointF(2.5, 7.4), QPointF(15.5, 7.4))
        p.drawLine(QPointF(6, 2.2), QPointF(6, 5))
        p.drawLine(QPointF(12, 2.2), QPointF(12, 5))
        p.setBrush(color)
        p.drawEllipse(QPointF(11.4, 11.4), 1.3, 1.3)
    elif name == "guanlan":    # 观澜：两道波
        for y0, amp in ((7.0, 1.6), (11.6, 1.6)):
            path = QPainterPath(QPointF(2, y0))
            for i in range(1, 29):
                x = 2 + i * 0.5
                path.lineTo(x, y0 + amp * math.sin((x - 2) / 14 * 2 * math.pi * 1.5))
            p.drawPath(path)
    elif name == "countdown":  # 沙漏
        p.drawLine(QPointF(4, 2.5), QPointF(14, 2.5))
        p.drawLine(QPointF(4, 15.5), QPointF(14, 15.5))
        path = QPainterPath(QPointF(5, 2.5))
        path.cubicTo(5, 7, 8.6, 7.6, 8.6, 9)
        path.cubicTo(8.6, 10.4, 5, 11, 5, 15.5)
        p.drawPath(path)
        path = QPainterPath(QPointF(13, 2.5))
        path.cubicTo(13, 7, 9.4, 7.6, 9.4, 9)
        path.cubicTo(9.4, 10.4, 13, 11, 13, 15.5)
        p.drawPath(path)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(color)
        tri = QPainterPath(QPointF(6.4, 15))
        tri.lineTo(11.6, 15)
        tri.lineTo(9, 12.4)
        tri.closeSubpath()
        p.drawPath(tri)
    elif name == "studio":     # 习题：纸页 + 两行 + 勾
        p.drawRoundedRect(QRectF(3.2, 2.2, 11.6, 13.6), 2.2, 2.2)
        p.drawLine(QPointF(6, 6), QPointF(12, 6))
        p.drawLine(QPointF(6, 8.8), QPointF(10.4, 8.8))
        path = QPainterPath(QPointF(6.2, 12))
        path.lineTo(7.8, 13.4)
        path.lineTo(11.4, 10.6)
        p.drawPath(path)
    elif name == "lab":        # 锥形瓶 + 液面
        path = QPainterPath(QPointF(7, 2.4))
        path.lineTo(7, 7)
        path.lineTo(3, 14)
        path.quadTo(2.6, 15.6, 4.4, 15.6)
        path.lineTo(13.6, 15.6)
        path.quadTo(15.4, 15.6, 15, 14)
        path.lineTo(11, 7)
        path.lineTo(11, 2.4)
        p.drawPath(path)
        p.drawLine(QPointF(6, 2.4), QPointF(12, 2.4))
        p.drawLine(QPointF(5, 11.4), QPointF(13, 11.4))
    elif name == "settings":   # 三条滑杆
        for y, kx in ((4.5, 11.5), (9, 6.5), (13.5, 10)):
            p.drawLine(QPointF(2.5, y), QPointF(kx - 2.6, y))
            p.drawLine(QPointF(kx + 2.6, y), QPointF(15.5, y))
            p.drawEllipse(QPointF(kx, y), 1.9, 1.9)
    p.end()
    return pm


def row(*widgets, spacing: int = 8, stretch_last: bool = False) -> QHBoxLayout:
    lay = QHBoxLayout()
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(spacing)
    for w in widgets:
        if w is None:
            lay.addStretch(1)
        elif isinstance(w, QWidget):
            lay.addWidget(w)
        else:
            lay.addLayout(w)
    if stretch_last:
        lay.addStretch(1)
    return lay
