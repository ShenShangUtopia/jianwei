"""析题页（原生）：左边贴题，中间讲题卡（答案 → 过程 → 解释 + 程序核对），右边图解 / 仿真 / 实验。

AI 与网络都在工作线程；每次分析带票据（ticket），只有当前这道题的回答能写进界面，过时的回答直接丢弃。
"""
from __future__ import annotations

import html
import json
import re
import traceback

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QTextDocument
from PySide6.QtWidgets import (QComboBox, QFrame, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton, QScrollArea, QSplitter, QStackedWidget, QTabWidget, QVBoxLayout, QWidget)

from ..design import tokens
from ..design.tokens import T, qc
from ..design.widgets import qss
from ..kit.ctx import Ctx
from ..kit.registry import lab
from . import lesson as Lesson
from . import llm
from .viz import make_viz

E = html.escape
STATUS = dict(verified=("程序核对通过", "ok"), solved=("程序已求解", "ok"), conflict=("程序与解答不符，待复核", "bad"), unchecked=("没有可核对的数值", "muted"))


class Worker(QThread):
    status = Signal(int, str)
    draft = Signal(int, object)
    finished_ok = Signal(int, object)
    failed = Signal(int, str)

    def __init__(self, rev, fn):
        super().__init__()
        self.rev, self.fn = rev, fn
        self.cancelled = False

    def run(self):
        try:
            r = self.fn(lambda m: self.status.emit(self.rev, str(m)), lambda d: self.draft.emit(self.rev, d), lambda: self.cancelled)
            self.finished_ok.emit(self.rev, r)
        except llm.AskError as e:
            self.failed.emit(self.rev, str(e))
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self.failed.emit(self.rev, f"{type(e).__name__}: {e}")


def catalog_text():
    lab.load()
    return "\n".join(f"{e.id}｜{e.subj}｜{e.unit}｜{e.title}｜{e.kw or ''}" for e in lab.list)


class AnalysisPage(QWidget):
    def __init__(self, engine_factory=None):
        super().__init__()
        self.setObjectName("jw2")
        self.engine_factory = engine_factory or (lambda cancel: llm.Engine(Lesson.protocol(), cancel))
        self.rev = 0
        self.worker = None
        self.L = None
        self.ctx = None
        self.workers = []
        split = QSplitter(Qt.Orientation.Horizontal)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(split)
        split.addWidget(self._left())
        self.card_scroll = QScrollArea()
        self.card_scroll.setWidgetResizable(True)
        self.card_host = QWidget()
        self.card_lay = QVBoxLayout(self.card_host)
        self.card_lay.setContentsMargins(18, 14, 18, 14)
        self.card_lay.setSpacing(8)
        self.card_scroll.setWidget(self.card_host)
        split.addWidget(self.card_scroll)
        self.right = QStackedWidget()
        self.empty = QLabel("分析后这里显示分步图解或仿真。")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setObjectName("note")
        self.right.addWidget(self.empty)
        split.addWidget(self.right)
        split.setSizes([300, 520, 620])
        self.apply_theme()
        self.show_welcome()
        self.refresh_history()

    def _left(self):
        box = QFrame()
        box.setObjectName("drawer")
        v = QVBoxLayout(box)
        v.setContentsMargins(14, 12, 14, 12)
        v.setSpacing(6)
        v.addWidget(QLabel("<b>题目</b>"))
        self.text = QPlainTextEdit()
        self.text.setPlaceholderText("把题目粘贴到这里，例如：从 20 m 高处以 15 m/s 的速度水平抛出一个小球，不计空气阻力，求落地时间和水平位移。")
        v.addWidget(self.text, 2)
        row = QHBoxLayout()
        self.engine_box = QComboBox()
        self.engine_box.addItem("AI 读题（DeepSeek）", "ai")
        self.engine_box.addItem("离线读题", "offline")
        if not llm.available():
            self.engine_box.setCurrentIndex(1)
        row.addWidget(self.engine_box, 1)
        self.go_btn = QPushButton("分析")
        self.go_btn.setObjectName("pri")
        self.go_btn.clicked.connect(lambda: self.go())
        row.addWidget(self.go_btn)
        v.addLayout(row)
        self.key_btn = QPushButton("DeepSeek 密钥…")
        self.key_btn.clicked.connect(self.edit_key)
        v.addWidget(self.key_btn)
        self.status_l = QLabel("")
        self.status_l.setWordWrap(True)
        self.status_l.setObjectName("note")
        v.addWidget(self.status_l)
        v.addWidget(QLabel("<b>记录</b>"))
        self.hist = QListWidget()
        self.hist.itemClicked.connect(self.open_history)
        v.addWidget(self.hist, 1)
        return box

    def edit_key(self):
        key, ok = QInputDialog.getText(self, "DeepSeek 密钥", "密钥只保存在本机数据目录，不会上传到别处。留空则清除。", QLineEdit.EchoMode.Password)
        if ok:
            llm.save_key(key.strip())
            self.engine_box.setCurrentIndex(0 if key.strip() else 1)

    def apply_theme(self):
        self.setStyleSheet(qss())
        if self.L:
            self.render(self.L)

    # ---- 讲题卡
    def _clear_card(self):
        lay = self.card_lay
        while lay.count():
            w = lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()

    def _p(self, s, name=None):
        lb = QLabel(s)
        lb.setWordWrap(True)
        lb.setTextFormat(Qt.TextFormat.RichText)
        lb.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        if name:
            lb.setObjectName(name)
        self.card_lay.addWidget(lb)
        return lb

    def _h(self, s):
        return self._p(s, "grpTitle")

    def show_welcome(self):
        self._clear_card()
        self._p("<span style='font-size:18px;font-weight:700'>析题</span>")
        self._p("AI 只读题、选路线、填参数；<b>数全部由程序算</b>；每个答案都要过独立核对才算数。没有密钥也能用离线读题器处理常见题型。", "note")
        self.card_lay.addStretch(1)

    def show_draft(self, d):
        self._clear_card()
        self._p(f"<span style='font-size:17px;font-weight:700'>{E(d.get('topic') or '正在生成')}</span>　<span style='color:{qc(T.muted).name()}'>AI 正在写，程序随后核对</span>")
        if d.get("summary"):
            self._p(f"<b>题意：</b>{E(d['summary'])}")
        if d.get("knowns"):
            self._h("已知")
            self._p("<br>".join(E(x) for x in d["knowns"]))
        if d.get("steps"):
            self._h("解题步骤")
            self._p("<br>".join(f"{i + 1}. {E(x)}" for i, x in enumerate(d["steps"])))
        if d.get("answer"):
            self._p(f"<b>答案（待核对）：</b>{E(d['answer'])}")
        self.card_lay.addStretch(1)

    def render(self, L):
        self._clear_card()
        ok_c, bad_c, mut = qc(T.ok).name(), qc(T.bad).name(), qc(T.muted).name()
        st = Lesson.status_of(L)
        label, tone = STATUS[st]
        col = dict(ok=ok_c, bad=bad_c, muted=mut)[tone]
        self._p(f"<span style='font-size:17px;font-weight:700'>{E(L.get('topic') or '讲题')}</span>　<span style='color:{mut}'>{E(L.get('subject') or '')}</span>　<span style='color:{col};font-weight:600'>{label}</span>")
        if L.get("summary"):
            self._p(f"<b>题意：</b>{E(L['summary'])}")
        if L.get("unsupported"):
            self.card_lay.addStretch(1)
            return
        # 答案 → 过程 → 解释（VeloΦ 的三段）
        self._h("答案")
        ans = str(L.get("answer") or "—")
        if st == "conflict":
            self._p(f"<span style='color:{bad_c}'>{E(ans)}（程序核对不符，先看下面的核对表）</span>")
        else:
            self._p(f"<b>{E(ans)}</b>")
        rc = L.get("recheck") or {}
        if rc.get("oldAnswer"):
            self._p(f"AI 复查后改了答案。原答案：{E(str(rc['oldAnswer']))}" + (f"　错在：{E(rc.get('check') or '')}" if rc.get("check") else ""), "note")
        elif rc.get("disputed"):
            self._p(f"AI 复查后仍坚持原答案，和程序不一致，请老师判断。{E(rc.get('check') or '')}", "note")
        for t in L.get("taskRes") or []:
            self._task_block(t, ok_c, bad_c, mut)
        if L.get("calc"):
            self._calc_block(L["calc"], ok_c, bad_c, mut)
        if L.get("calcNote"):
            self._p(E(L["calcNote"]), "note")
        if L.get("verify"):
            self._verify_block(L["verify"], ok_c, bad_c)
        if L.get("knowns"):
            self._h("已知")
            self._p("<br>".join(E(x) for x in L["knowns"]))
        if L.get("assumptions"):
            self._h("假设")
            self._p("<br>".join(E(x) for x in L["assumptions"]), "note")
        if L.get("method"):
            self._h("思路")
            self._p(E(L["method"]))
        if L.get("steps"):
            self._h("解题步骤")
            self._p("<br>".join(f"{i + 1}. {E(x)}" for i, x in enumerate(L["steps"])))
        if L.get("conclusion"):
            self._h("结论")
            self._p(E(L["conclusion"]))
        if L.get("check"):
            self._h("检验")
            self._p(E(L["check"]))
        if L.get("pitfalls"):
            self._h("易错点")
            self._p("<br>".join(E(x) for x in L["pitfalls"]))
        if L.get("watch"):
            self._h("观察")
            self._p("<br>".join(E(x) for x in L["watch"]))
        if L.get("caveats"):
            self._p(E(L["caveats"]), "note")
        self.card_lay.addStretch(1)

    def _task_block(self, t, ok_c, bad_c, mut):
        self._h(f"程序求解 · {t['title']}")
        rows = []
        for r in t["rows"]:
            mark = "" if r["ok"] is None else f"<span style='color:{ok_c}'>✓</span>" if r["ok"] else f"<span style='color:{bad_c}'>✗</span>"
            cl = f"<span style='color:{mut}'>　AI：{E(json.dumps(r['claimed'], ensure_ascii=False) if isinstance(r['claimed'], (list, dict)) else str(r['claimed']))}</span>" if r.get("claimed") not in (None, "") else ""
            rows.append(f"{E(r['prompt'])}：<b>{E(str(r['text']))}</b> {mark}{cl}")
        self._p("<br>".join(rows))
        if t.get("checks"):
            self._p("<br>".join(f"<span style='color:{ok_c if c['ok'] else bad_c}'>{'✓' if c['ok'] else '✗'}</span> {E(c['text'])}" for c in t["checks"]), "note")
        if t.get("detail"):
            self._p("<br>".join(E(d) for d in t["detail"]), "note")

    def _calc_block(self, c, ok_c, bad_c, mut):
        self._h(f"方程模型 · {Lesson.Solver.VERDICT.get(c['verdict'], c['verdict'])}")
        rows = []
        for r in c["rows"]:
            mark = "" if r["ok"] is None else f"<span style='color:{ok_c}'>✓</span>" if r["ok"] else f"<span style='color:{bad_c}'>✗</span>"
            cl = f"<span style='color:{mut}'>　AI：{E(str(r['claimed']))}</span>" if r.get("claimed") not in (None, "") else ""
            rows.append(f"{E(r['prompt'])}：<b>{Lesson.fmt_num(r['value'])}{' ' + E(r['unit']) if r['unit'] else ''}</b> {mark}{cl}")
        self._p("<br>".join(rows))
        self._p("<br>".join(E(e["text"]) + (f"（{E(e['why'])}）" if e["why"] else "") for e in c["equations"]), "note")
        if c.get("conflicts"):
            self._p("矛盾的方程：" + "；".join(E(x["text"]) for x in c["conflicts"]), "note")
        if c.get("undetermined"):
            self._p("不能确定：" + "、".join(E(x) for x in c["undetermined"]), "note")

    def _verify_block(self, v, ok_c, bad_c):
        self._h("实验核对")
        if v.get("rows"):
            self._p("<br>".join(f"{E(str(r['quantity']))}：答案 {E(r['answer'])}，读数「{E(r['readout'])}」{E(r['measured'])} <span style='color:{ok_c if r['ok'] else bad_c}'>{'✓' if r['ok'] else '✗'}</span>" for r in v["rows"]))
        if v.get("check"):
            self._p(E(v["check"]), "note")

    # ---- 右栏
    def _set_right(self, w):
        while self.right.count() > 1:
            old = self.right.widget(1)
            self.right.removeWidget(old)
            old.setParent(None)
            old.deleteLater()
        if w is None:
            self.right.setCurrentIndex(0)
            return
        self.right.addWidget(w)
        self.right.setCurrentWidget(w)

    def _close_ctx(self):
        if self.ctx:
            self.ctx.dispose()
            self.ctx = None

    def _mount_scene(self, sc, cue=""):
        from ..bank.views import safe_mount
        box = QWidget()
        h = QHBoxLayout(box)
        h.setContentsMargins(0, 0, 0, 0)
        host = QFrame()
        hv = QVBoxLayout(host)
        hv.setContentsMargins(1, 1, 1, 1)
        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(12, 10, 12, 10)
        ctx = Ctx(host, panel)
        hv.addWidget(ctx.stage)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(260)
        q = dict(id="lesson", steps=["a", "b", "c"], view=dict(engine="physics", kind=sc.get("kind"), params=sc.get("params") or {}, cue=cue))
        view, err = safe_mount(ctx, q)
        pv.addStretch(1)
        scroll.setWidget(panel)
        h.addWidget(host, 1)
        h.addWidget(scroll)
        self.ctx = ctx
        self.scene_view = view
        if view:
            view.apply_step(2)
        if err:
            ctx.stage.error = err
        return box

    def _mount_exp(self, e):
        box = QWidget()
        h = QHBoxLayout(box)
        h.setContentsMargins(0, 0, 0, 0)
        host = QFrame()
        hv = QVBoxLayout(host)
        hv.setContentsMargins(1, 1, 1, 1)
        panel = QWidget()
        pv = QVBoxLayout(panel)
        pv.setContentsMargins(12, 10, 12, 10)
        ctx = Ctx(host, panel)
        hv.addWidget(ctx.stage)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(270)
        e.init(ctx)
        pv.addStretch(1)
        scroll.setWidget(panel)
        h.addWidget(host, 1)
        h.addWidget(scroll)
        self.ctx = ctx
        self.exp_panel = panel
        return box

    def visuals(self, L):
        """有题型图解就放图解；物理题型放仿真；否则放实验（路线 module）。"""
        self._close_ctx()
        tabs = QTabWidget()
        for t in L.get("taskRes") or []:
            v = t.get("viz") or {}
            if v.get("scene"):
                tabs.addTab(self._mount_scene(v["scene"], L.get("summary") or ""), f"仿真 · {t['title']}")
            else:
                try:
                    w = make_viz(t)
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
                    w = None
                if w:
                    tabs.addTab(w, t["title"])
        if tabs.count():
            self._set_right(tabs)
            return "viz"
        lab.load()
        e = lab.by_id.get(L.get("module")) if L.get("module") else None
        if e:
            try:
                self._set_right(self._mount_exp(e))
                return "exp"
            except Exception:  # noqa: BLE001
                traceback.print_exc()
        self._set_right(None)
        return None

    # ---- 流程
    def go(self, text=None):
        text = (text if text is not None else self.text.toPlainText()).strip()
        if not text:
            self.status_l.setText("先把题目粘贴进来")
            return
        self.rev += 1
        if self.worker:
            self.worker.cancelled = True
        rev = self.rev
        use_ai = self.engine_box.currentData() == "ai" and (llm.available() or self.engine_factory.__name__ != "<lambda>")
        lab.load()
        ids = set(lab.by_id)
        cat = catalog_text()
        self.go_btn.setEnabled(False)
        self.status_l.setText("开始分析…")
        factory = self.engine_factory

        def job(status, draft, cancelled):
            engine = factory(cancelled) if use_ai else None
            L = Lesson.analyze(text, engine, ids, cat, status, draft, rev)
            L["_engine"] = engine
            return L
        self._start(rev, job, self._on_done)

    def _start(self, rev, job, done):
        w = Worker(rev, job)
        w.status.connect(self._on_status)
        w.draft.connect(self._on_draft)
        w.failed.connect(self._on_fail)
        w.finished_ok.connect(done)
        self.worker = w
        self.workers.append(w)
        w.finished.connect(lambda wk=w: self.workers.remove(wk) if wk in self.workers else None)
        w.start()

    def _on_status(self, rev, m):
        if rev == self.rev:
            self.status_l.setText(m)

    def _on_draft(self, rev, d):
        if rev == self.rev and (d.get("summary") or d.get("steps")):
            self.show_draft(d)

    def _on_fail(self, rev, m):
        if rev == self.rev:
            self.go_btn.setEnabled(True)
            self.status_l.setText(f"分析失败：{m}")

    def _on_done(self, rev, L):
        if rev != self.rev:   # 票据：过时的回答直接丢弃
            return
        self.go_btn.setEnabled(True)
        engine = L.pop("_engine", None)
        self.L = L
        self.render(L)
        route = self.visuals(L)
        Lesson.save_lesson(L)
        self.refresh_history()
        self.status_l.setText("分析完成")
        if route == "exp" and engine:
            self._configure(L, engine)

    # ---- 第 2、3 步：配置实验、用读数核对
    def _configure(self, L, engine):
        e = lab.by_id[L["module"]]
        rev = self.rev
        ctx = self.ctx
        snapshot = []
        for c in ctx.ctrls:
            s = dict(c)
            if c["kind"] in ("select", "choice"):
                opts = c["options"]()
                s["options"] = lambda o=opts: o
            if c["kind"] == "slider":
                lo, hi = c["minF"](), c["maxF"]()
                s["minF"], s["maxF"] = (lambda v=lo: v), (lambda v=hi: v)
            snapshot.append(s)
        ctl_json = Lesson.controls(ctx)
        problem = L["problem"]

        def job(status, _draft, _c):
            status("第 2 步：配置实验参数…")
            user = f"## 题目\n{problem}\n\n## 第一步结果\n{json.dumps({k: L.get(k) for k in ('summary', 'knowns', 'steps', 'answer', 'scenario')}, ensure_ascii=False)}\n\n## 实验「{e.title}」原理\n{re.sub(r'<[^>]+>', ' ', getattr(e, 'info', '') or '')}\n\n## 控件列表\n{json.dumps(ctl_json, ensure_ascii=False)}\n\n## 任务\n执行协议中的第二步，只输出 JSON。"
            return llm.ask_json(engine, user, lambda j: Lesson.check2(j, snapshot, problem), status=status)["value"]

        def done(r2, B):
            if r2 != self.rev or self.ctx is not ctx:
                return
            Lesson.apply_settings(L, B, ctx)
            self.render(L)
            Lesson.save_lesson(L)
            verified = any(r.get("ok") for r in Lesson.task_rows(L) + ((L.get("calc") or {}).get("rows") or [])) and Lesson.status_of(L) != "conflict"
            if verified:
                L["verify"] = dict(consistent=True, rows=[], check="程序已经核对过，不再用实验读数核对。")
                self.render(L)
                self.status_l.setText("分析完成")
                return
            self.status_l.setText("第 3 步：等实验跑稳，读数核对…")
            QTimer.singleShot(2500 if L.get("applied", {}).get("ok") else 800, lambda: self._verify(L, engine, ctx))
        self._start(rev, job, done)

    def readouts(self):
        out = []
        panel = getattr(self, "exp_panel", None)
        if not panel:
            return ""
        for lb in panel.findChildren(QLabel, "out"):
            doc = QTextDocument()
            doc.setHtml(lb.text())
            for line in doc.toPlainText().split("\n"):
                line = re.sub(r"\s*\t\s*", "：", line.strip())
                if line:
                    out.append(line)
        return "\n".join(out)

    def _verify(self, L, engine, ctx):
        if self.ctx is not ctx:
            return
        ctx.draw()
        reading = self.readouts()
        if not reading.strip():
            L["verify"] = dict(consistent=True, rows=[], check="实验面板没有可读的数值，未核对。")
            self.render(L)
            self.status_l.setText("分析完成")
            return
        rev = self.rev

        def job(status, _d, _c):
            status("第 3 步：把答案和读数配对…")
            base = f"## 题目\n{L['problem']}\n\n## 解答\n{json.dumps(dict(steps=L.get('steps'), answer=L.get('answer')), ensure_ascii=False)}\n\n## 实验设置\n{'；'.join((L.get('applied') or {}).get('ok') or [])}\n\n## 实验读数\n{reading}\n\n## 任务\n执行协议中的第三步，只输出 JSON。"
            C = llm.ask_json(engine, base, lambda j: dict(ok=True, value=j) if isinstance(j.get("pairs", []), list) else dict(ok=False, errors=["pairs 必须是数组"]), repairs=1, status=status)["value"]
            rows = Lesson.compare_pairs(C.get("pairs"), reading)
            L["verify"] = dict(consistent=all(r["ok"] for r in rows), rows=rows, check="" if rows else (C.get("note") or "实验中没有与答案直接对应的读数，未核对。"))
            if not L["verify"]["consistent"]:
                status("数值与实验不符，正在重新检查解答…")
                bad = "\n".join(f"{r['quantity']}：原答案换算为 {r['answer']}，实验读数「{r['readout']}」为 {r['measured']}" for r in rows if not r["ok"])
                Lesson.correct(L, f"实验按精确公式或数值模拟计算，读数可信，除非实验设置与题目不对应。\n实验设置：{'；'.join((L.get('applied') or {}).get('ok') or [])}\n不符的项目：\n{bad}", engine, status)
            return L

        def done(r2, _L):
            if r2 == self.rev:
                self.render(L)
                Lesson.save_lesson(L)
                self.status_l.setText("分析完成")
        self._start(rev, job, done)

    # ---- 记录
    def refresh_history(self):
        self.hist.clear()
        for x in Lesson.history():
            it = QListWidgetItem((x.get("topic") or x.get("problem") or "题目")[:24])
            it.setData(Qt.ItemDataRole.UserRole, x.get("ticket", {}).get("id"))
            it.setToolTip(str(x.get("problem") or "")[:200])
            self.hist.addItem(it)

    def open_history(self, it):
        qid = it.data(Qt.ItemDataRole.UserRole)
        L = next((x for x in Lesson.history() if x.get("ticket", {}).get("id") == qid), None)
        if L:
            self.rev += 1
            self.L = L
            self.text.setPlainText(L.get("problem") or "")
            self.render(L)
            self.visuals(L)

    def shutdown(self):
        self.rev += 1
        self._close_ctx()
        for w in list(self.workers):
            w.cancelled = True
            w.wait(1500)


_ = tokens
