"""自由工作台：注册表、素材栏（点击 / 拖到画布）、提示气泡。对应旧版 gewu/bench.js。

每个工作台用 @bench.reg(id=, subj=, short=, title=, sub=, desc=, art=) 注册 init(B)。
B 提供：
  B.L              实验上下文（Ctx），画布和右侧检查器都在它上面
  B.palette(secs)  左侧素材栏：[{title, items: [{id, icon, label, sub, title, click, drop(x, y)}]}]
  B.active(id)     高亮当前工具
  B.toast(html)    画布右上角的提示气泡
  B.clear_panel()  清空检查器（重新 inspect 前调用）
  B.tips(secs)     「原理」页里的使用说明：[(标题, [条目 html…])]
  B.log            实验记录（工作台自己往里 add 行，显示在「原理」页顶部）
icon 可以是 SVG 字符串（currentColor 会换成前景色），也可以是 fn(p: QPainter, rect: QRectF)。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from PySide6.QtCore import QByteArray, QMimeData, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QDrag, QFontMetrics, QPainter, QPixmap
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from ..design.tokens import T, font, qc

MIME = "application/x-jw-palette"


# ---------------------------------------------------------------- 注册表
@dataclass
class BenchKit:
    id: str
    subj: str
    short: str
    title: str
    sub: str = ""
    desc: str = ""
    art: str = ""
    init: Callable | None = None
    extra: dict = field(default_factory=dict)


class _Benches:
    def __init__(self):
        self.list: list[BenchKit] = []
        self.by_id: dict[str, BenchKit] = {}
        self._loaded = False

    def reg(self, **meta):
        def deco(fn):
            k = BenchKit(init=fn, **meta)
            if k.id not in self.by_id:
                self.list.append(k)
            self.by_id[k.id] = k
            return fn
        return deco

    def load(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        from ..lab import all_modules  # noqa: F401  显式导入，打包后也找得到


bench = _Benches()


# ---------------------------------------------------------------- SVG 图标
_svg_cache: dict = {}


def paint_svg(p: QPainter, svg: str, rect: QRectF) -> None:
    from PySide6.QtSvg import QSvgRenderer
    src = (svg.replace("currentColor", T.fg).replace("var(--surface,#fff)", T.surface)
           .replace("var(--surface)", T.surface))
    r = _svg_cache.get(src)
    if r is None:
        if not src.lstrip().startswith("<svg") or "xmlns" in src:
            data = src
        else:
            data = src.replace("<svg", "<svg xmlns='http://www.w3.org/2000/svg'", 1)
        r = QSvgRenderer(QByteArray(data.encode("utf-8")))
        if len(_svg_cache) > 400:
            _svg_cache.clear()
        _svg_cache[src] = r
    if r.isValid():
        vb = r.viewBoxF()
        if vb.width() > 0 and vb.height() > 0:   # 等比放进 rect
            k = min(rect.width() / vb.width(), rect.height() / vb.height())
            w, h = vb.width() * k, vb.height() * k
            rect = QRectF(rect.center().x() - w / 2, rect.center().y() - h / 2, w, h)
        r.render(p, rect)


def paint_icon(p: QPainter, icon, rect: QRectF) -> None:
    if not icon:
        return
    if callable(icon):
        icon(p, rect)
    elif isinstance(icon, str) and "<svg" in icon:
        paint_svg(p, icon, rect)
    else:   # 单个字符 / emoji
        p.setFont(font(rect.height() * 0.7))
        p.setPen(qc(T.fg))
        p.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), str(icon))


# ---------------------------------------------------------------- 素材栏
class PalItem(QWidget):
    """一条素材：图标 + 名称 + 小字。点击执行 click；按住拖到画布执行 drop(x, y)。"""
    H = 44

    def __init__(self, it: dict, pal: "Palette"):
        super().__init__()
        self.it, self.pal = it, pal
        self.on = False
        self.hover = False
        self._press = None
        self.setFixedHeight(self.H)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if it.get("title"):
            self.setToolTip(it["title"])
        elif it.get("sub"):
            self.setToolTip(f"{it['label']}：{it['sub']}")

    def enterEvent(self, _e):  # noqa: N802
        self.hover = True
        self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = False
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = e.position()

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._press is None or not self.it.get("drop"):
            return
        d = e.position() - self._press
        if abs(d.x()) + abs(d.y()) < 8:
            return
        self._press = None
        Palette.dragging = self.it
        drag = QDrag(self)
        md = QMimeData()
        md.setData(MIME, QByteArray(b"1"))
        drag.setMimeData(md)
        pm = self.grab()
        drag.setPixmap(pm)
        drag.setHotSpot(e.position().toPoint())
        drag.exec(Qt.DropAction.CopyAction)
        Palette.dragging = None

    def mouseReleaseEvent(self, e):  # noqa: N802
        if self._press is not None and e.button() == Qt.MouseButton.LeftButton:
            self._press = None
            fn = self.it.get("click")
            if fn:
                fn()

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w = self.width()
        box = QRectF(6, 2, w - 12, self.H - 4)
        if self.on or self.hover:
            p.setPen(qc(T.accent, 0.5) if self.on else Qt.PenStyle.NoPen)
            p.setBrush(qc(T.accent, 0.12) if self.on else qc(T.hover))
            p.drawRoundedRect(box, 8, 8)
        paint_icon(p, self.it.get("icon"), QRectF(14, 9, 26, 26))
        sub = self.it.get("sub") or ""
        p.setFont(font(12.5, 600 if self.on else 500))
        p.setPen(qc(T.fg))
        fm = QFontMetrics(p.font())
        ty = 5 if sub else 12
        p.drawText(QRectF(48, ty, w - 56, 20), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                   fm.elidedText(self.it.get("label", ""), Qt.TextElideMode.ElideRight, w - 56))
        if sub:
            p.setFont(font(10.5))
            p.setPen(qc(T.muted))
            fm = QFontMetrics(p.font())
            p.drawText(QRectF(48, 23, w - 56, 16), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                       fm.elidedText(sub, Qt.TextElideMode.ElideRight, w - 56))
        p.end()


class Palette(QWidget):
    dragging: dict | None = None   # 正在拖的素材（拖放只在本进程内）

    def __init__(self):
        super().__init__()
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(4, 8, 4, 16)
        self.lay.setSpacing(0)
        self.items: dict[str, PalItem] = {}
        self.all: list[PalItem] = []

    def set_sections(self, secs) -> None:
        while self.lay.count():
            w = self.lay.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        self.items, self.all = {}, []
        for s in secs:
            h = QLabel(s["title"])
            h.setObjectName("grpTitle")
            h.setContentsMargins(12, 10, 8, 4)
            self.lay.addWidget(h)
            for it in s["items"]:
                b = PalItem(it, self)
                self.lay.addWidget(b)
                self.all.append(b)
                if it.get("id"):
                    self.items[it["id"]] = b
        self.lay.addStretch(1)

    def active(self, iid) -> None:
        for k, b in self.items.items():
            if b.on != (k == iid):
                b.on = k == iid
                b.update()


# ---------------------------------------------------------------- 提示气泡
class Toasts:
    def __init__(self, stage: QWidget):
        self.stage = stage
        self.labels: list[QLabel] = []

    def show(self, html: str, cls: str | None = None, ms: int = 2600) -> None:
        lb = QLabel(html, self.stage)
        lb.setTextFormat(Qt.TextFormat.RichText)
        lb.setWordWrap(True)
        lb.setMaximumWidth(360)
        col = T.bad if cls == "bad" else T.ok if cls == "ok" else T.accent
        lb.setStyleSheet(f"QLabel{{background:{T.raised};color:{T.fg};border:1px solid {T.line};border-left:3px solid {col};"
                         f"border-radius:8px;padding:7px 11px;font-size:12.5px;}}")
        lb.adjustSize()
        lb.show()
        lb.raise_()
        self.labels.insert(0, lb)
        while len(self.labels) > 3:
            self._drop(self.labels[-1])
        self._place()
        QTimer.singleShot(ms, lb, lambda: self._drop(lb))

    def _drop(self, lb: QLabel) -> None:
        if lb in self.labels:
            self.labels.remove(lb)
            lb.hide()
            lb.deleteLater()
            self._place()

    def _place(self) -> None:
        y = 12
        for lb in self.labels:
            lb.move(max(8, self.stage.width() - lb.width() - 12), y)
            y += lb.height() + 6


# ---------------------------------------------------------------- 工作台 API
class Log:
    """实验记录：工作台 add 一行，显示在「原理」页。"""

    def __init__(self, on_change):
        self.rows: list[str] = []
        self.on_change = on_change

    def add(self, html: str) -> None:
        self.rows.insert(0, html)   # 新的在上
        if len(self.rows) > 80:
            self.rows.pop()
        self.on_change()

    def clear(self) -> None:
        self.rows.clear()
        self.on_change()


class BenchAPI:
    def __init__(self, L, palette: Palette, on_tips):
        self.L = L
        self.stage = L.stage
        self.pal = palette
        self._toasts = Toasts(L.stage)
        self.tip_secs: list = []
        self._on_tips = on_tips
        self.log = Log(on_tips)
        self.drop_ok = True
        L.stage.setAcceptDrops(True)
        L.stage.drop_fn = self._drop

    @property
    def items(self):
        return self.pal.items

    def _drop(self, x, y) -> None:
        it = Palette.dragging
        if it and it.get("drop"):
            it["drop"](x, y)
            self.L.draw()

    def palette(self, secs) -> None:
        self.pal.set_sections(secs)

    def active(self, iid) -> None:
        self.pal.active(iid)

    def toast(self, html: str, cls: str | None = None, ms: int = 2600) -> None:
        self._toasts.show(html, cls, ms)

    def clear_panel(self) -> None:
        L = self.L
        lay = L.panel_lay
        while lay.count():
            item = lay.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        L.box, L._row, L._gt = None, None, ""
        L.ctrls = []

    def tips(self, secs) -> None:
        self.tip_secs = list(secs)
        self._on_tips()


class BenchTabs(QWidget):
    """标题条上的工作台切换（小号分段条）。"""
    picked = Signal(str)

    def __init__(self, cur: str):
        super().__init__()
        self.cur = cur
        self.hit: list = []
        self.hover = None
        self.setMouseTracking(True)
        self.setFixedHeight(30)
        self._w = 0
        self._layout()

    def _layout(self):
        fm = QFontMetrics(font(12.5, 500))
        x, self.hit = 2, []
        for k in bench.list:
            w = fm.horizontalAdvance(k.short) + 26
            self.hit.append((QRectF(x, 2, w, 26), k.id, k.short))
            x += w + 2
        self.setFixedWidth(int(x + 2))

    def mouseMoveEvent(self, e):  # noqa: N802
        h = next((k for r, k, _ in self.hit if r.contains(e.position())), None)
        if h != self.hover:
            self.hover = h
            self.setCursor(Qt.CursorShape.PointingHandCursor if h else Qt.CursorShape.ArrowCursor)
            self.update()

    def leaveEvent(self, _e):  # noqa: N802
        self.hover = None
        self.update()

    def mousePressEvent(self, e):  # noqa: N802
        h = next((k for r, k, _ in self.hit if r.contains(e.position())), None)
        if h and h != self.cur:
            self.picked.emit(h)

    def paintEvent(self, _e):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(qc(T.line))
        p.setBrush(qc(T.bg))
        p.drawRoundedRect(QRectF(0.5, 0.5, self.width() - 1, self.height() - 1), 9, 9)
        for r, k, t in self.hit:
            on = k == self.cur
            if on or k == self.hover:
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(qc(T.accent) if on else qc(T.hover))
                p.drawRoundedRect(r, 7, 7)
            p.setFont(font(12.5, 600 if on else 500))
            p.setPen(qc("#ffffff" if on else T.soft))
            p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), t)
        p.end()


def _unused():
    _ = (QPixmap, QPointF)
