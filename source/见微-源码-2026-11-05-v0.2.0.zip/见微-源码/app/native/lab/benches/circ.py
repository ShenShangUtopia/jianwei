"""自由工作台 · 电路（由 gewu/bench-circ.js 改写）。

元件放在两个格点之间。用节点电压法求解：每个元件化成电导（必要时并联电流源）——
导线、电流表、闭合的开关取 0.1 mΩ，电压表取 10 MΩ；电池是电动势 E 串联内阻 r（诺顿等效）；
电容器用后向欧拉伴随模型随时间充放电；二极管按导通（Vf + 5 Ω）/截止分段线性迭代。
"""
from __future__ import annotations

import copy
import math

from ...design.tokens import T, alpha, qc
from ...kit.bench import bench
from ...kit.core import TAU, clamp, fmt, lerp
from ...kit.draw import D

CT = {
    "wire": {"n": "导线", "d": {}},
    "bat": {"n": "电池", "d": {"E": 3, "r": 0.5}},
    "res": {"n": "定值电阻", "d": {"R": 10}},
    "rh": {"n": "滑动变阻器", "d": {"Rmax": 20, "k": 0.5}},
    "rh3": {"n": "变阻器（三接线柱）", "d": {"Rmax": 20, "k": 0.5}},
    "bulb": {"n": "小灯泡", "d": {"R": 10, "P0": 0.9}},
    "led": {"n": "发光二极管", "d": {"Vf": 2, "col": "#ff4a3d"}},
    "cap": {"n": "电容器", "d": {"C": 4700}},
    "sw": {"n": "开关", "d": {"on": False}},
    "am": {"n": "电流表", "d": {}},
    "vm": {"n": "电压表", "d": {}},
}
GW = 1e4   # 导线等的电导（S）


def nf(v, d=3):
    """画布上的数字。"""
    if abs(v) < 1e-6:
        return "0"
    if abs(v) < 1e-3:
        return f"{v:.1e}"
    return fmt(v, d)


def gauss_solve(A, b):
    n = len(b)
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(A[r][i]))
        A[i], A[p] = A[p], A[i]
        b[i], b[p] = b[p], b[i]
        d = A[i][i] or 1e-30
        Ai = A[i]
        for r in range(i + 1, n):
            f = A[r][i] / d
            if not f:
                continue
            Ar = A[r]
            for k in range(i, n):
                Ar[k] -= f * Ai[k]
            b[r] -= f * b[i]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = b[i] - sum(A[i][k] * x[k] for k in range(i + 1, n))
        x[i] = s / (A[i][i] or 1e-30)
    return x


ART = """<svg viewBox="0 0 160 110"><g fill="none" stroke="currentColor" stroke-width="2.2">
  <path d="M30 26H130V84H30z"/></g><rect x="22" y="44" width="16" height="22" fill="var(--surface,#fff)"/>
  <path d="M22 50h16M26 60h8" stroke="currentColor" stroke-width="2.6"/>
  <circle cx="80" cy="26" r="20" fill="#ffd34d" opacity=".45"/><circle cx="80" cy="26" r="11" fill="var(--surface,#fff)" stroke="currentColor" stroke-width="2.2"/><path d="M72 18l16 16M88 18L72 34" stroke="currentColor" stroke-width="2"/>
  <rect x="64" y="77" width="32" height="14" fill="var(--surface,#fff)" stroke="currentColor" stroke-width="2.2"/>
  <circle cx="130" cy="55" r="11" fill="var(--surface,#fff)" stroke="currentColor" stroke-width="2.2"/><text x="130" y="60" font-size="13" text-anchor="middle" fill="currentColor" font-weight="700">A</text>
  """ + "".join(f'<circle cx="{40 + i * 15}" cy="84" r="2.4" fill="#d99a00"/>' for i in range(6)) + "</svg>"


def _svg(s):
    return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">{s}</svg>'


ICON = {
    "select": _svg('<path d="M6 3l12 9-5.5 1L15 20l-2.5 1-2.5-6.5L6 18z" fill="currentColor" stroke="none"/>'),
    "wire": _svg('<path d="M3 17h7V7h11"/><circle cx="3" cy="17" r="1.6" fill="currentColor"/><circle cx="21" cy="7" r="1.6" fill="currentColor"/>'),
    "bat": _svg('<path d="M2 12h7M15 12h7"/><path d="M9 8v8" stroke-width="3.4"/><path d="M15 4v16"/>'),
    "res": _svg('<path d="M2 12h4M18 12h4"/><rect x="6" y="8.5" width="12" height="7"/>'),
    "rh": _svg('<path d="M2 12h4M18 12h4"/><rect x="6" y="8.5" width="12" height="7"/><path d="M5 19L19 5M15 5h4v4"/>'),
    "bulb": '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#ffd34d" opacity=".35"/><circle cx="12" cy="12" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/>'
            '<path d="M7.4 7.4l9.2 9.2M16.6 7.4l-9.2 9.2" stroke="currentColor" stroke-width="1.4"/></svg>',
    "led": '<svg viewBox="0 0 24 24"><path d="M6 6v12l10-6z" fill="#ff4a3d"/><path d="M17 6v12M2 12h4M17 12h5" stroke="currentColor" stroke-width="1.6"/>'
           '<path d="M12 5l3-3M15 7l3-3" stroke="#ff4a3d" stroke-width="1.3"/></svg>',
    "cap": _svg('<path d="M2 12h8M14 12h8M10 5v14M14 5v14" />'),
    "sw": _svg('<path d="M2 15h4M18 15h4"/><circle cx="7" cy="15" r="1.6"/><circle cx="17" cy="15" r="1.6"/><path d="M8 14l8-7"/>'),
    "am": _svg('<circle cx="12" cy="12" r="8"/><path d="M9 16l3-8 3 8M10 13.5h4"/>'),
    "vm": _svg('<circle cx="12" cy="12" r="8"/><path d="M9 8l3 8 3-8"/>'),
    "rh3": _svg('<path d="M1 14h3M20 14h3"/><rect x="4" y="11" width="16" height="6"/><path d="M12 3v5"/><path d="M10 6.5l2 3 2-3" fill="currentColor"/>'),
    "demo": _svg('<rect x="3" y="5" width="18" height="14" rx="1"/><circle cx="12" cy="5" r="2.6" fill="#ffd34d"/>'),
}


def W(x1, y1, x2, y2):
    return ["wire", x1, y1, x2, y2]


PRE = [
    ["串联电路", "两只灯泡串联，电压表测 L1 两端电压", [
        ["bat", 2, 8, 2, 5], W(2, 5, 2, 2), ["sw", 2, 2, 5, 2], W(5, 2, 6, 2), ["bulb", 6, 2, 8, 2], W(8, 2, 10, 2), ["bulb", 10, 2, 12, 2], W(12, 2, 14, 2),
        W(14, 2, 14, 4), ["am", 14, 4, 14, 6], W(14, 6, 14, 8), W(14, 8, 2, 8), W(6, 2, 6, 4), W(8, 2, 8, 4), ["vm", 6, 4, 8, 4]]],
    ["并联电路", "两条支路各接一只电流表", [
        ["bat", 2, 9, 2, 6], W(2, 6, 2, 2), ["sw", 2, 2, 4, 2], W(4, 2, 7, 2), W(7, 2, 12, 2), ["am", 7, 2, 7, 4], ["bulb", 7, 4, 7, 6], W(7, 6, 7, 9),
        W(12, 2, 12, 4), ["bulb", 12, 4, 12, 6, {"R": 20}], ["am", 12, 6, 12, 8], W(12, 8, 12, 9), W(12, 9, 7, 9), W(7, 9, 2, 9)]],
    ["伏安法测电阻", "电流表外接，滑动变阻器限流", [
        ["bat", 2, 9, 2, 6, {"E": 6, "r": 0.5}], W(2, 6, 2, 2), ["sw", 2, 2, 4, 2], ["rh", 4, 2, 7, 2, {"Rmax": 50, "k": 0.4}], W(7, 2, 8, 2), ["am", 8, 2, 10, 2], W(10, 2, 10, 4),
        ["res", 10, 4, 10, 7, {"R": 20, "name": "待测电阻 Rx"}], W(10, 7, 10, 9), W(10, 9, 2, 9), W(10, 4, 13, 4), ["vm", 13, 4, 13, 7], W(13, 7, 10, 7)]],
    ["测电源的电动势和内阻", "改变变阻器，记录 U、I 作 U–I 图", [
        ["bat", 3, 8, 3, 5, {"E": 1.5, "r": 1}], W(3, 5, 3, 2), ["sw", 3, 2, 6, 2], ["am", 6, 2, 9, 2], W(9, 2, 12, 2), ["rh", 12, 2, 12, 8, {"Rmax": 20, "k": 0.5}], W(12, 8, 3, 8),
        W(3, 5, 1, 5), W(3, 8, 1, 8), ["vm", 1, 5, 1, 8]]],
    ["电容器的充电和放电", "先合 S1 充电，再断开 S1、合上 S2 放电", [
        ["bat", 2, 8, 2, 5, {"E": 6, "r": 0.2}], W(2, 5, 2, 2), ["sw", 2, 2, 5, 2, {"name": "开关 S1"}], ["res", 5, 2, 8, 2, {"R": 200}], W(8, 2, 10, 2), ["am", 10, 2, 10, 4],
        ["cap", 10, 4, 10, 6, {"C": 4700}], W(10, 6, 10, 8), W(10, 8, 2, 8),
        W(10, 2, 15, 2), ["sw", 15, 2, 15, 5, {"name": "开关 S2"}], ["bulb", 15, 5, 15, 8, {"R": 100, "P0": 0.4}], W(15, 8, 10, 8), W(10, 4, 13, 4), ["vm", 13, 4, 13, 6], W(13, 6, 10, 6)]],
    ["二极管的单向导电性", "两只二极管方向相反，只有一只发光", [
        ["bat", 2, 8, 2, 5, {"E": 5, "r": 0.5}], W(2, 5, 2, 2), ["sw", 2, 2, 5, 2], W(5, 2, 7, 2), W(7, 2, 12, 2), ["led", 7, 2, 7, 5], ["res", 7, 5, 7, 8, {"R": 100}], W(7, 8, 2, 8),
        ["led", 12, 5, 12, 2, {"col": "#2fbf5f"}], ["res", 12, 5, 12, 8, {"R": 100}], W(12, 8, 7, 8)]],
    ["滑动变阻器的分压接法", "灯泡两端电压可以从 0 调起", [
        ["bat", 2, 9, 2, 6, {"E": 6, "r": 0.3}], W(2, 6, 2, 3), ["sw", 2, 3, 5, 3], W(5, 3, 6, 3), ["rh3", 6, 3, 10, 3, {"Rmax": 20, "k": 0.5}], W(10, 3, 12, 3), W(12, 3, 12, 9), W(12, 9, 2, 9),
        W(8, 2, 8, 1), W(8, 1, 14, 1), ["am", 14, 1, 14, 3], ["bulb", 14, 3, 14, 6, {"R": 12, "P0": 3}], W(14, 6, 14, 9), W(14, 9, 12, 9), W(14, 3, 16, 3), ["vm", 16, 3, 16, 6], W(16, 6, 14, 6)]],
    ["空白电路板", "", []],
]


def _hexv(h):
    c = qc(h)
    return c.red(), c.green(), c.blue()


@bench.reg(id="circ", subj="phys", short="电路", title="电路实验板", sub="电池 · 电阻 · 灯泡 · 开关 · 变阻器 · 电表 · 电容 · 二极管",
           desc="在格点上拖出导线和元件，连成任意电路。实时求解每个元件的电压和电流，灯泡按功率发光，电流用流动的光点表示，可以做串并联、伏安法、测电源电动势和电容充放电。",
           art=ART)
def circ(B):
    L = B.L
    c = L.canvas()
    S = {"comps": [], "sel": None, "tool": "select", "uid": 0, "preview": None, "G": 40, "ox": 30, "oy": 30,
         "pot": {}, "vmin": 0.0, "vmax": 1.0, "sig": ""}
    ui: dict = {}
    opt = {"flow": True, "pot": False, "tags": True}
    cnt: dict = {}

    def layout():
        G = clamp(round(min(c.w / 17, c.h / 13)), 30, 48)
        S.update(G=G, ox=G * 0.8, oy=G * 0.8)

    def X(i):
        return S["ox"] + i * S["G"]

    def Y(j):
        return S["oy"] + j * S["G"]

    def snap(x, y):
        return [round((x - S["ox"]) / S["G"]), round((y - S["oy"]) / S["G"])]

    def mk(t, a, b, o=None, count=True):
        if count:
            cnt[t] = cnt.get(t, 0) + 1
        S["uid"] += 1
        q = {"t": t, "id": S["uid"], "name": CT[t]["n"] + ("" if t == "wire" else f" {cnt.get(t, 1)}"), "a": list(a), "b": list(b),
             "I": 0.0, "U": 0.0, "P": 0.0, "ph": 0.0, "v": 0.0}
        q.update(copy.deepcopy(CT[t]["d"]))
        q.update(o or {})
        return q

    def same(p, q):
        return p[0] == q[0] and p[1] == q[1]

    def cPt(q):   # 三接线柱变阻器的滑片接线柱：在元件中点旁边一格
        def sg(v):
            return (v > 0) - (v < 0)
        return [round((q["a"][0] + q["b"][0]) / 2) + sg(q["b"][1] - q["a"][1]), round((q["a"][1] + q["b"][1]) / 2) - sg(q["b"][0] - q["a"][0])]

    def R1(q):
        return max(0.05, q["Rmax"] * q["k"])

    def R2(q):
        return max(0.05, q["Rmax"] * (1 - q["k"]))

    def key(p):
        return f"{p[0]},{p[1]}"

    # ---- 求解
    def solve(dt):
        comps = S["comps"]
        nodes: dict = {}

        def nid(p):
            k = key(p)
            if k not in nodes:
                nodes[k] = len(nodes)
            return nodes[k]
        for q in comps:
            q["na"], q["nb"] = nid(q["a"]), nid(q["b"])
            if q["t"] == "rh3":
                q["nc"] = nid(cPt(q))
        n = len(nodes)
        if not n:
            return
        V = None
        for _it in range(12):
            A = [[0.0] * n for _ in range(n)]
            J = [0.0] * n

            def st(a, b, g):
                A[a][a] += g
                A[b][b] += g
                A[a][b] -= g
                A[b][a] -= g

            def src(a, b, i):
                J[a] -= i
                J[b] += i
            for q in comps:
                a, b, t = q["na"], q["nb"], q["t"]
                if a == b:
                    continue
                if t in ("wire", "am"):
                    st(a, b, GW)
                elif t == "sw":
                    st(a, b, GW if q["on"] else 1e-10)
                elif t == "vm":
                    st(a, b, 1e-7)
                elif t == "res":
                    st(a, b, 1 / q["R"])
                elif t == "bulb":
                    st(a, b, 1e-10 if q.get("blown") else 1 / q["R"])
                elif t == "rh":
                    st(a, b, 1 / max(0.05, q["Rmax"] * q["k"]))
                elif t == "rh3":
                    st(a, q["nc"], 1 / R1(q))
                    st(q["nc"], b, 1 / R2(q))
                elif t == "bat":
                    g = 1 / max(q["r"], 1e-3)
                    st(a, b, g)
                    src(a, b, q["E"] * g)
                elif t == "cap":
                    g = q["C"] * 1e-6 / dt
                    st(a, b, g)
                    src(b, a, g * q["v"])
                elif t == "led":
                    g = 0.2 if q.get("on") else 1e-9
                    st(a, b, g)
                    if q.get("on"):
                        src(b, a, g * q["Vf"])
            for i in range(n):
                A[i][i] += 1e-9
            V = gauss_solve(A, J)
            ch = False
            for q in comps:
                if q["t"] == "led":
                    u = V[q["na"]] - V[q["nb"]]
                    on = (u - q["Vf"]) * 0.2 > 0 if q.get("on") else u > q["Vf"]
                    if on != bool(q.get("on")):
                        q["on"] = on
                        ch = True
            if not ch:
                break
        bat = next((q for q in comps if q["t"] == "bat"), None)
        ref = V[bat["na"]] if bat else min(V)
        pot = {}
        vmin, vmax = math.inf, -math.inf
        for k, i in nodes.items():
            v = V[i] - ref
            pot[k] = v
            vmin, vmax = min(vmin, v), max(vmax, v)
        if vmax - vmin < 1e-6:
            vmax = vmin + 1
        S.update(pot=pot, vmin=vmin, vmax=vmax)
        for q in comps:
            u = 0.0 if q["na"] == q["nb"] else V[q["na"]] - V[q["nb"]]
            t = q["t"]
            i = 0.0
            if t in ("wire", "am"):
                i = u * GW
            elif t == "sw":
                i = u * (GW if q["on"] else 1e-10)
            elif t == "vm":
                i = u * 1e-7
            elif t == "res":
                i = u / q["R"]
            elif t == "bulb":
                i = 0.0 if q.get("blown") else u / q["R"]
            elif t == "rh":
                i = u / max(0.05, q["Rmax"] * q["k"])
            elif t == "rh3":
                vc = V[q["nc"]]
                i = (V[q["na"]] - vc) / R1(q)
                q["I2"] = (vc - V[q["nb"]]) / R2(q)
                q["Uc"] = V[q["nc"]] - V[q["nb"]]
            elif t == "bat":
                g = 1 / max(q["r"], 1e-3)
                i = g * u + q["E"] * g
            elif t == "cap":
                g = q["C"] * 1e-6 / dt
                i = g * u - g * q["v"]
                q["v"] = u
            elif t == "led":
                i = (u - q["Vf"]) * 0.2 if q.get("on") else 0.0
            q["U"], q["I"] = u, i
            q["P"] = -u * i if t == "bat" else (i * i * R1(q) + q["I2"] ** 2 * R2(q)) if t == "rh3" else u * i
            if t == "bulb" and not q.get("blown"):
                if q["P"] > 2.6 * q["P0"]:
                    q["over"] = q.get("over", 0) + dt
                    if q["over"] > 0.4:
                        q["blown"] = True
                        B.toast(f"{q['name']}烧坏了：实际功率远大于额定功率", "bad")
                        if S["sel"] is q:
                            inspect()
                else:
                    q["over"] = 0

    # ---- 绘制
    def pot_col(v):
        t = clamp((v - S["vmin"]) / (S["vmax"] - S["vmin"]), 0, 1)
        a, b = _hexv(T.c1), _hexv(T.c2)
        return f"rgb({int(lerp(a[0], b[0], t))},{int(lerp(a[1], b[1], t))},{int(lerp(a[2], b[2], t))})"

    def wire_col(q, end=None):
        return pot_col(S["pot"].get(key(end or q["a"]), 0)) if opt["pot"] else alpha(T.fg, 0.82)

    def tag(g, q, s, col, side=-1):
        ax, ay, bx, by = X(q["a"][0]), Y(q["a"][1]), X(q["b"][0]), Y(q["b"][1])
        L2 = math.hypot(bx - ax, by - ay) or 1
        nx, ny = -(by - ay) / L2, (bx - ax) / L2
        if ny > 0 or (ny == 0 and nx > 0):
            nx, ny = -nx, -ny
        w = D.measure(s, 11.5, True, True) + 10
        dd = 16 + abs(nx) * w / 2 + abs(ny) * 8
        d = dd if side < 0 else -dd
        mx = clamp((ax + bx) / 2 + nx * d, w / 2 + 2, c.w - w / 2 - 2)
        my = clamp((ay + by) / 2 + ny * d, 11, c.h - 11)
        D.rrect(g, mx - w / 2, my - 9, w, 18, 4, alpha(T.surface, 0.92), alpha(col, 0.6), 1)
        D.text(g, s, mx, my + 0.5, col, size=11.5, align="center", mono=True, bold=True)

    def draw_comp(g, q):
        ax, ay, bx, by = X(q["a"][0]), Y(q["a"][1]), X(q["b"][0]), Y(q["b"][1])
        Lp = math.hypot(bx - ax, by - ay)
        if Lp < 1:
            return
        t = q["t"]
        ux, uy = (bx - ax) / Lp, (by - ay) / Lp
        mx, my = (ax + bx) / 2, (ay + by) / 2
        hs = 0 if t == "wire" else max(15, Lp / 2 - 8) if t == "rh3" else min(18, Lp / 2 - 2)
        cl = None
        if t == "rh3":
            cp = cPt(q)
            cx, cy = X(cp[0]), Y(cp[1])
            dx, dy = cx - mx, cy - my
            cl = {"x": dx * ux + dy * uy, "y": -dx * uy + dy * ux, "cx": cx, "cy": cy, "col": wire_col(q, cp)}
        g.line_cap = "round"
        if S["sel"] is q:
            D.line(g, ax, ay, bx, by, alpha(T.accent, 0.28), 12)
            if cl:
                D.line(g, mx, my, cl["cx"], cl["cy"], alpha(T.accent, 0.28), 12)
        D.line(g, ax, ay, mx - ux * hs, my - uy * hs, wire_col(q, q["a"]), 2.4)
        D.line(g, mx + ux * hs, my + uy * hs, bx, by, wire_col(q, q["b"]), 2.4)
        g.line_cap = "butt"
        if opt["flow"] and abs(q["I"]) > 2e-4 and t != "vm" and not (t == "sw" and not q["on"]):
            sp = 14
            off = q["ph"] % sp
            col = alpha(T.c4, clamp(0.45 + abs(q["I"]) * 0.4, 0.45, 0.95))
            s = off
            while s < Lp:
                D.circle(g, ax + ux * s, ay + uy * s, 2.3, col)
                s += sp
        if t == "wire":
            return
        g.save()
        g.translate(mx, my)
        ang = math.atan2(uy, ux)
        g.rotate(ang)
        fg, bg = T.fg, T.stage
        if t == "bat":
            D.rect(g, -hs, -16, 2 * hs, 32, bg)
            D.line(g, -hs, 0, -4, 0, fg, 2.4)
            D.line(g, 4, 0, hs, 0, fg, 2.4)
            D.line(g, -4, -8, -4, 8, fg, 5)
            D.line(g, 4, -15, 4, 15, fg, 2.2)
            D.text(g, "+", 11, -12, T.c2, size=12, bold=True, align="center")
            D.text(g, "−", -11, -12, T.c1, size=12, bold=True, align="center")
        elif t in ("res", "rh"):
            D.rect(g, -15, -6, 30, 12, bg, fg, 2)
            if t == "rh":
                D.arrow(g, -13, 11, 15, -12, T.accent, 1.6, 7)
                D.line(g, -15 + 30 * q["k"], -6, -15 + 30 * q["k"], -12, T.accent, 2)
        elif t == "rh3":
            sd = (1 if cl["y"] > 0 else -1) if cl["y"] else -1
            wx = -hs + 2 * hs * q["k"]
            D.rect(g, -hs, -6, 2 * hs, 12, bg, fg, 2)
            x = -hs + 5
            while x < hs - 2:
                D.line(g, x, -5, x, 5, alpha(fg, 0.25), 1)
                x += 5
            g.line_cap = "round"
            D.poly(g, [(cl["x"], cl["y"]), (cl["x"], sd * 17), (wx, sd * 17)], None, cl["col"], 2.4, close=False)
            g.line_cap = "butt"
            D.arrow(g, wx, sd * 17, wx, sd * 7, T.accent, 2, 8)
            D.circle(g, cl["x"], cl["y"], 3.5, T.stage, fg, 1.6)
        elif t == "bulb":
            br = 0 if q.get("blown") else clamp(q["P"] / q["P0"], 0, 1.6)
            if br > 0.02:
                r = 14 + 30 * math.sqrt(br)
                m1 = min(1, br)
                gl = g.radial_gradient(0, 0, r, [(0, f"rgba(255,230,120,{0.95 * m1:.3f})"), (0.1, f"rgba(255,230,120,{0.95 * m1:.3f})"),
                                                 (0.42, f"rgba(255,200,70,{0.5 * m1:.3f})"), (1, "rgba(255,190,60,0)")])
                D.rect(g, -r, -r, 2 * r, 2 * r, gl)
            D.circle(g, 0, 0, 12, f"rgba(255,240,170,{0.35 + 0.6 * min(1, br):.3f})" if br > 0.02 else bg, T.muted if q.get("blown") else fg, 2)
            d = 8.2
            if q.get("blown"):
                D.line(g, -d, -d, -2, -2, T.muted, 1.8)
                D.line(g, 2, 2, d, d, T.muted, 1.8)
                D.line(g, -d, d, d, -d, T.muted, 1.8)
            else:
                D.line(g, -d, -d, d, d, fg, 1.8)
                D.line(g, -d, d, d, -d, fg, 1.8)
        elif t == "led":
            lit = q.get("on") and q["I"] > 1e-3
            if lit:
                r = 30
                D.rect(g, -r, -r, 2 * r, 2 * r, g.radial_gradient(0, 0, r, [(0, alpha(q["col"], 0.85)), (0.07, alpha(q["col"], 0.85)), (1, alpha(q["col"], 0))]))
            else:
                D.rect(g, -hs, -12, 2 * hs, 24, bg)
            D.poly(g, [(-8, -9), (-8, 9), (7, 0)], q["col"] if lit else bg, fg, 1.8)
            D.line(g, 8, -9, 8, 9, fg, 2.2)
            D.line(g, -8, 0, -hs, 0, fg, 2.4)
            D.line(g, 8, 0, hs, 0, fg, 2.4)
            D.arrow(g, 1, -11, 8, -18, q["col"] if lit else T.muted, 1.2, 5)
            D.arrow(g, 6, -9, 13, -16, q["col"] if lit else T.muted, 1.2, 5)
        elif t == "cap":
            D.rect(g, -hs, -14, 2 * hs, 28, bg)
            D.line(g, -hs, 0, -4, 0, fg, 2.4)
            D.line(g, 4, 0, hs, 0, fg, 2.4)
            D.line(g, -4, -12, -4, 12, fg, 2.6)
            D.line(g, 4, -12, 4, 12, fg, 2.6)
            qn = clamp(abs(q["U"]) / 3, 0, 1)
            if qn > 0.03:
                pa = -1 if q["U"] > 0 else 1
                g.global_alpha = 0.4 + 0.6 * qn
                D.text(g, "+", 9 * pa, -16, T.c2, size=11, bold=True, align="center")
                D.text(g, "−", -9 * pa, -16, T.c1, size=11, bold=True, align="center")
                g.global_alpha = 1
        elif t == "sw":
            D.rect(g, -hs, -14, 2 * hs, 22, bg)
            D.line(g, -hs, 0, -12, 0, fg, 2.4)
            D.line(g, 12, 0, hs, 0, fg, 2.4)
            D.circle(g, -12, 0, 3, bg, fg, 1.8)
            D.circle(g, 12, 0, 3, bg, fg, 1.8)
            g.line_cap = "round"
            if q["on"]:
                D.line(g, -12, 0, 12, -1, T.accent, 2.6)
            else:
                D.line(g, -12, 0, 9, -12, fg, 2.6)
            g.line_cap = "butt"
        elif t in ("am", "vm"):
            D.circle(g, 0, 0, 13, bg, fg, 2)
            g.rotate(-ang)
            D.text(g, "A" if t == "am" else "V", 0, 1, T.c1 if t == "am" else T.c5, size=14, bold=True, align="center")
        g.restore()
        if S["sel"] is q:
            for p in (q["a"], q["b"]):
                D.circle(g, X(p[0]), Y(p[1]), 5.5, T.stage, T.accent, 2)
        if not opt["tags"]:
            return
        if t == "am":
            tag(g, q, f"{nf(abs(q['I']), 3)} A", T.c1)
        elif t == "vm":
            tag(g, q, f"{nf(abs(q['U']), 3)} V", T.c5)
        elif t == "bat":
            tag(g, q, f"{nf(q['E'], 1)} V  r={nf(q['r'], 1)} Ω", T.muted)
            if abs(q["I"]) > 3:
                tag(g, q, f"短路！{nf(abs(q['I']), 1)} A", T.bad, 1)
        elif t == "res":
            tag(g, q, f"{nf(q['R'], 1)} Ω", T.muted)
        elif t == "rh":
            tag(g, q, f"{nf(q['Rmax'] * q['k'], 1)} Ω", T.muted)
        elif t == "rh3":
            tag(g, q, f"{nf(q['Rmax'], 0)} Ω  滑片 {round(q['k'] * 100)}%", T.muted, 1)
        elif t == "bulb":
            tag(g, q, "已烧坏" if q.get("blown") else f"{nf(q['P'], 2)} W", T.bad if q.get("blown") else T.muted)
        elif t == "cap":
            tag(g, q, f"{nf(q['C'], 0)} μF {nf(abs(q['U']), 2)} V", T.muted)
        elif t == "sw":
            tag(g, q, "闭合" if q["on"] else "断开", T.accent if q["on"] else T.muted)

    def board(g, ni, nj):
        G = S["G"]
        bx0, by0 = X(0) - G * 0.55, Y(0) - G * 0.55
        bw, bh = ni * G + G * 1.1, nj * G + G * 1.1
        bgr = g.linear_gradient(0, by0, 0, by0 + bh, [(0, alpha(T.chem, 0.07 if T.dark else 0.05)), (1, alpha(T.chem, 0.12 if T.dark else 0.09))])
        D.rrect(g, bx0, by0, bw, bh, 12, bgr, alpha(T.chem, 0.25), 1)
        gl = alpha(T.chem, 0.08)
        for i in range(5, ni, 5):
            D.line(g, X(i), by0 + 6, X(i), by0 + bh - 6, gl, 1)
        for j in range(5, nj, 5):
            D.line(g, bx0 + 6, Y(j), bx0 + bw - 6, Y(j), gl, 1)
        dot = alpha(T.fg, 0.22)
        for i in range(ni + 1):
            for j in range(nj + 1):
                D.circle(g, X(i), Y(j), 1.5, dot)

    def draw():
        layout()
        g = c.g
        c.clear()
        G = S["G"]
        ni = int((c.w - S["ox"] - G * 0.6) // G)
        nj = int((c.h - S["oy"] - G * 0.6 - 18) // G)
        L.cached(("board", G, ni, nj), lambda: board(c.g, ni, nj))
        comps = S["comps"]
        for q in sorted(comps, key=lambda q: q["t"] != "wire"):
            draw_comp(g, q)
        deg: dict = {}
        for q in comps:
            for p in ([q["a"], q["b"], cPt(q)] if q["t"] == "rh3" else [q["a"], q["b"]]):
                deg[key(p)] = deg.get(key(p), 0) + 1
        for k, d in deg.items():
            if d >= 3:
                i, j = map(int, k.split(","))
                D.circle(g, X(i), Y(j), 4, pot_col(S["pot"].get(k, 0)) if opt["pot"] else T.fg)
        pv, tool = S["preview"], S["tool"]
        if pv and pv.get("b") and not same(pv["a"], pv["b"]):
            g.global_alpha = 0.55
            ghost = mk(tool, pv["a"], pv["b"], count=False)
            ghost["id"] = -1
            draw_comp(g, ghost)
            g.global_alpha = 1
        if pv:
            D.circle(g, X(pv["a"][0]), Y(pv["a"][1]), 5, T.accent)
        tip = "选择 / 移动：点元件选中，拖动元件移动，拖动端点改接线，点开关切换通断" if tool == "select" else f"放置{CT[tool]['n']}：在两个格点之间拖动；按 Esc 回到选择"
        D.text(g, tip, 10, c.h - 12, T.muted, size=12)
        if not comps:
            D.text(g, "从左侧选一个示例电路，或选「导线」在格点间拖动连线", c.w / 2, c.h * 0.42, T.muted, size=15, align="center")
    L.on_draw(draw)

    # ---- 交互
    def dseg(px, py, q):
        ax, ay, bx, by = X(q["a"][0]), Y(q["a"][1]), X(q["b"][0]), Y(q["b"][1])
        dx, dy = bx - ax, by - ay
        t = clamp(((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1), 0, 1)
        return math.hypot(px - ax - t * dx, py - ay - t * dy)

    def hit_comp(x, y):
        for q in sorted(S["comps"], key=lambda q: q["t"] == "wire"):
            if dseg(x, y, q) < (7 if q["t"] == "wire" else 14):
                return q
            if q["t"] == "rh3":
                cp = cPt(q)
                if math.hypot(x - X(cp[0]), y - Y(cp[1])) < 12:
                    return q
        return None

    def hit(x, y):
        if S["tool"] != "select":
            return {"t": "draw", "a": snap(x, y)}
        sel = S["sel"]
        if sel:
            for w in ("a", "b"):
                if math.hypot(x - X(sel[w][0]), y - Y(sel[w][1])) < 9:
                    return {"t": "end", "q": sel, "w": w}
        q = hit_comp(x, y)
        return {"t": "comp", "q": q, "g0": snap(x, y), "a0": list(q["a"]), "b0": list(q["b"])} if q else None

    def down(_x, _y, h):
        if not h:
            return
        if h["t"] == "draw":
            S["preview"] = {"a": h["a"]}
        else:
            select(h["q"])

    def drag(h, x, y, _dx, _dy):
        p = snap(x, y)
        if h["t"] == "draw":
            h["b"] = p
            S["preview"]["b"] = p
        elif h["t"] == "end":
            if not same(p, h["q"]["b" if h["w"] == "a" else "a"]):
                h["q"][h["w"]] = p
        elif h["t"] == "comp":
            di, dj = p[0] - h["g0"][0], p[1] - h["g0"][1]
            h["q"]["a"] = [h["a0"][0] + di, h["a0"][1] + dj]
            h["q"]["b"] = [h["b0"][0] + di, h["b0"][1] + dj]

    def up(h):
        if h and h["t"] == "draw":
            if h.get("b") and not same(h["a"], h["b"]):
                q = mk(S["tool"], h["a"], h["b"])
                S["comps"].append(q)
                if S["tool"] != "wire":
                    select(q)
            S["preview"] = None
        if h and h["t"] != "draw" and S["sel"]:
            refresh()

    def click(_x, _y, h):
        if not h:
            select(None)
            return
        if h["t"] == "draw":
            if S["tool"] != "wire":
                q = mk(S["tool"], h["a"], [h["a"][0] + 2, h["a"][1]])
                S["comps"].append(q)
                select(q)
            S["preview"] = None
            h["b"] = None
            return
        if h["t"] == "comp" and h["q"]["t"] == "sw":
            h["q"]["on"] = not h["q"]["on"]
            inspect()

    def wheel(x, y, steps):
        q = hit_comp(x, y)
        if not q or q["t"] not in ("rh", "rh3"):
            return False
        q["k"] = clamp(round((q["k"] + (0.02 if steps > 0 else -0.02)) * 100) / 100, 0, 1)
        if S["sel"] is q:
            inspect()
        else:
            select(q)
        return True
    L.interact(c, hit=hit, down=down, drag=drag, up=up, click=click, wheel=wheel)

    def set_tool(t):
        S["tool"] = t
        B.active("tool-select" if t == "select" else "tool-" + t)
        S["preview"] = None
        L.draw()

    def rotate(q):
        dx, dy = q["b"][0] - q["a"][0], q["b"][1] - q["a"][1]
        q["b"] = [q["a"][0] - dy, q["a"][1] + dx]

    def remove(q):
        S["comps"] = [r for r in S["comps"] if r is not q]
        if S["sel"] is q:
            S["sel"] = None
            inspect()

    def on_key(k, _e):
        if k == "Escape":
            set_tool("select")
            return True
        if k in ("Delete", "Backspace") and S["sel"]:
            remove(S["sel"])
            return True
        if k in ("r", "R") and S["sel"]:
            rotate(S["sel"])
            return True
        return False
    L.on_key(on_key)

    # ---- 示例电路
    def build(lst):
        S["comps"], S["sel"] = [], None
        cnt.clear()
        for row in lst:
            t, x1, y1, x2, y2 = row[:5]
            S["comps"].append(mk(t, [x1, y1], [x2, y2], row[5] if len(row) > 5 else None))
        set_tool("select")
        inspect()

    # ---- 检查器
    def select(q):
        if S["sel"] is not q:
            S["sel"] = q
            inspect()
        L.draw()

    def inspect():
        B.clear_panel()
        ui.clear()
        q = S["sel"]
        if q:
            def ed(f):
                def cb(v):
                    f(v)
                    refresh()
                    L.draw()
                return cb
            L.group(q["name"])
            t = q["t"]
            if t == "bat":
                L.slider("电动势 E", 0, 12, 0.1, q["E"], ed(lambda v: q.__setitem__("E", v)), "V")
                L.slider("内阻 r", 0, 5, 0.1, q["r"], ed(lambda v: q.__setitem__("r", v)), "Ω")
            elif t == "res":
                L.slider("电阻 R", 1, 500, 1, q["R"], ed(lambda v: q.__setitem__("R", v)), "Ω")
            elif t in ("rh", "rh3"):
                L.slider("滑片位置（接入比例）" if t == "rh" else "滑片位置（从第一个端点算起）", 0, 1, 0.01, q["k"], ed(lambda v: q.__setitem__("k", v)))
                L.slider("最大阻值", 5, 200, 1, q["Rmax"], ed(lambda v: q.__setitem__("Rmax", v)), "Ω")
                L.note("鼠标悬停在变阻器上滚动滚轮，也可以移动滑片。")
            elif t == "bulb":
                L.slider("灯丝电阻 R", 1, 200, 1, q["R"], ed(lambda v: q.__setitem__("R", v)), "Ω")
                L.slider("额定功率", 0.05, 5, 0.05, q["P0"], ed(lambda v: q.__setitem__("P0", v)), "W")
                if q.get("blown"):
                    L.button("换一只新灯泡", lambda _b: (q.update(blown=False, over=0), inspect()), True)
            elif t == "cap":
                L.slider("电容 C", 100, 20000, 100, q["C"], ed(lambda v: q.__setitem__("C", v)), "μF")
            elif t == "led":
                L.slider("导通电压", 1.5, 3.5, 0.1, q["Vf"], ed(lambda v: q.__setitem__("Vf", v)), "V")
                L.select("颜色", [["#ff4a3d", "红"], ["#2fbf5f", "绿"], ["#3d8bff", "蓝"], ["#ffd23d", "黄"]], q["col"], lambda v: q.__setitem__("col", v))
            elif t == "sw":
                L.button("断开" if q["on"] else "闭合", lambda _b: (q.__setitem__("on", not q["on"]), inspect()), True)
            ui["out"] = L.out()
            L.group("")
            if t != "wire":
                L.button("旋转 90°", lambda _b: rotate(q))
            L.button("删除", lambda _b: remove(q))
        L.group("电表读数")
        ui["meters"] = L.out()
        L.group("显示")
        L.check("电流流动（光点从高电势流向低电势）", opt["flow"], lambda v: opt.__setitem__("flow", v))
        L.check("按电势给导线着色（蓝低红高）", opt["pot"], lambda v: opt.__setitem__("pot", v))
        L.check("显示数值标签", opt["tags"], lambda v: opt.__setitem__("tags", v))
        L.note("快捷键（先点一下画布）：Esc 回到选择，Delete 删除，R 旋转。电压表、电流表视为理想电表。")
        L.panel_lay.addStretch(1)
        refresh()

    def refresh():
        q = S["sel"]
        if ui.get("out") and q:
            I, U, t = abs(q["I"]), abs(q["U"]), q["t"]
            rows = []
            if t == "bat":
                term = -q["U"]
                rows += [["电流", f"{nf(q['I'], 3)} A"], ["端电压 U", f"{nf(term, 3)} V"], ["内电压 Ir", f"{nf(q['I'] * q['r'], 3)} V"],
                         ["总功率 EI", f"{nf(q['E'] * q['I'], 3)} W"], ["输出功率 UI", f"{nf(term * q['I'], 3)} W"]]
                if q["E"] * q["I"] > 1e-6:
                    rows.append(["效率 U/E", f"{nf(term / q['E'] * 100, 1)} %"])
            elif t == "am":
                rows.append(["示数", f"{nf(I, 4)} A"])
            elif t == "vm":
                rows.append(["示数", f"{nf(U, 4)} V"])
            elif t in ("sw", "wire"):
                rows.append(["电流", f"{nf(I, 4)} A"])
            else:
                rows += [["电压 U", f"{nf(U, 3)} V"], ["电流 I", f"{nf(I, 4)} A"], ["功率 P", f"{nf(abs(q['P']), 3)} W"]]
                if t == "rh":
                    rows.append(["接入电阻", f"{nf(q['Rmax'] * q['k'], 2)} Ω"])
                if t == "rh3":
                    rows += [["滑片两侧电阻", f"{nf(R1(q), 2)} Ω / {nf(R2(q), 2)} Ω"], ["滑片与第二端之间电压", f"{nf(abs(q.get('Uc', 0)), 3)} V"],
                             ["滑片引出电流", f"{nf(abs(q['I'] - q.get('I2', 0)), 4)} A"]]
                if t == "cap":
                    rows += [["电荷量 Q = CU", f"{nf(q['C'] * U, 1)} μC"], ["时间常数参考 τ = RC", "与串联电阻有关"]]
                if t == "bulb":
                    rows.append(["亮度（P/P额）", "烧坏" if q.get("blown") else f"{nf(abs(q['P']) / q['P0'] * 100, 0)} %"])
                if t == "led":
                    rows.append(["状态", "导通发光" if q.get("on") and q["I"] > 1e-3 else "截止"])
            ui["out"].set(rows)
        if ui.get("meters"):
            m = [q for q in S["comps"] if q["t"] in ("am", "vm")]
            ui["meters"].set([[q["name"], f"{nf(abs(q['I']), 4)} A" if q["t"] == "am" else f"{nf(abs(q['U']), 4)} V"] for q in m]
                             if m else f"<span style='color:{T.muted}'>电路里还没有电表。</span>")
    L.every(200, refresh)

    # ---- 素材栏
    def t_item(t, sub):
        def dropped(x, y):
            a = snap(x, y)
            q = mk(t, a, [a[0] + 2, a[1]])
            S["comps"].append(q)
            select(q)
        return {"id": "tool-" + t, "icon": ICON[t], "label": CT[t]["n"], "sub": sub, "click": lambda: set_tool(t), "drop": dropped}
    B.palette([
        {"title": "示例电路", "items": [{"icon": ICON["demo"], "label": n, "sub": s, "click": (lambda lst=lst: build(lst))} for n, s, lst in PRE]},
        {"title": "工具", "items": [{"id": "tool-select", "icon": ICON["select"], "label": "选择 / 移动", "sub": "Esc", "click": lambda: set_tool("select")}, t_item("wire", "在格点间拖动")]},
        {"title": "电源和开关", "items": [t_item("bat", "3 V，内阻 0.5 Ω"), t_item("sw", "点击切换通断")]},
        {"title": "用电器", "items": [t_item("res", "10 Ω"), t_item("rh", "0~20 Ω"), t_item("rh3", "分压接法用"), t_item("bulb", "3 V 0.9 W"), t_item("led", "单向导电"), t_item("cap", "4700 μF")]},
        {"title": "电表", "items": [t_item("am", "理想电流表"), t_item("vm", "理想电压表")]},
    ])
    B.tips([
        ("怎么用", ["先在左侧选一种元件（或导线），然后在电路板的两个格点之间<b>拖动</b>，就放好了一个元件；单击格点会放一个两格长的元件。也可以把左侧元件直接拖到电路板上。",
                  "回到<b>选择 / 移动</b>：点元件选中，拖动它整体移动，拖动两端的圆点改接到别的格点。端点落在同一个格点上就连通了。",
                  "点击开关切换通断；右侧可以改电动势、内阻、电阻、滑片位置、电容等，读数实时更新。",
                  "灯泡亮度按实际功率显示，功率远超额定值会烧坏；电池电流过大会提示短路。"]),
        ("可以试试", ["串联电路中拧下（删除）一只灯泡，另一只会怎样？并联电路呢？", "伏安法：把电流表改成内接，比较两种接法测得的 R = U/I 与真实值的偏差。",
                    "测电源电动势和内阻：多次改变滑片，记录 U、I，看 U = E − Ir。", "电容器充放电：观察电流表示数从大到小、放电时方向反向，灯泡逐渐变暗。"]),
    ])

    # ---- 主循环
    def tick(dt):
        comps = S["comps"]
        sig = "|".join(",".join(str(q.get(k)) for k in ("t", "a", "b", "E", "r", "R", "Rmax", "k", "on", "blown", "C", "Vf")) for q in comps)
        if sig != S["sig"] or any(q["t"] == "cap" or q.get("over", 0) > 0 for q in comps):
            solve(max(dt, 1e-3))
            S["sig"] = sig
        for q in comps:
            s = (1 if q["I"] > 0 else -1 if q["I"] < 0 else 0) * min(150, 70 * math.sqrt(abs(q["I"])))
            q["ph"] += s * dt
        L.draw()
    L.loop(tick)
    build(PRE[0][2])


def _unused():
    _ = TAU
